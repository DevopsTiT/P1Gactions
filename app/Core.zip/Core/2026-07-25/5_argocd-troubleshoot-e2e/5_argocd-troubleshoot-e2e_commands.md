# ArgoCD Troubleshooting — Commands Reference

---

## Phase 0: Orient — Check ArgoCD Health First

```bash
# Verify all ArgoCD components are running before diagnosing app issues
kubectl get pods -n argocd -o wide

# Check for any pods NOT in Running state
kubectl get pods -n argocd --field-selector=status.phase!=Running

# Check resource usage of ArgoCD components (OOM / CPU pressure)
kubectl top pods -n argocd

# Quick overview of all apps and their sync+health state
argocd app list

# Verify argocd CLI is authenticated
argocd account get-user-info

# Login if not authenticated (in-cluster)
ARGOCD_PASS=$(kubectl get secret argocd-initial-admin-secret \
  -n argocd -o jsonpath='{.data.password}' | base64 -d)
argocd login argocd.internal \
  --username admin \
  --password "$ARGOCD_PASS" \
  --insecure   # remove if TLS is properly configured
```

---

## Phase 1: App-Level Investigation

```bash
APP_NAME="payments-api"

# Full status: sync state, health state, resource list, last sync message
argocd app get $APP_NAME

# Force a re-poll from Git RIGHT NOW (bypasses 3-min cache)
argocd app get $APP_NAME --refresh

# Hard refresh — clears repo-server cache AND re-polls (use if --refresh not enough)
argocd app get $APP_NAME --hard-refresh

# Show what differs between Git and live cluster
argocd app diff $APP_NAME

# Diff a specific resource only
argocd app diff $APP_NAME --resource apps:Deployment:payments-api

# Show sync history: timestamps, Git revisions, success/failure
argocd app history $APP_NAME

# Show last sync operation result in detail
argocd app get $APP_NAME --show-operation

# List all resources managed by this app with their individual status
kubectl get application $APP_NAME -n argocd \
  -o jsonpath='{.status.resources[*]}' | jq '.'
```

---

## Phase 2: Sync Troubleshooting

```bash
APP_NAME="payments-api"
NAMESPACE="payment"

# Basic manual sync
argocd app sync $APP_NAME

# Sync with pruning (removes resources deleted from Git)
argocd app sync $APP_NAME --prune

# Dry-run sync (shows what would change — does NOT apply)
argocd app sync $APP_NAME --dry-run

# Force sync (overwrites resource even if it conflicts)
argocd app sync $APP_NAME --force

# Sync only one specific resource (not the whole app)
argocd app sync $APP_NAME --resource apps:Deployment:payments-api

# Sync to a specific Git revision (not HEAD)
argocd app sync $APP_NAME --revision abc1234def

# If a sync is stuck — terminate the in-progress operation
argocd app terminate-op $APP_NAME

# Check whether a SyncWindow is blocking auto-sync
argocd app get $APP_NAME | grep -i "sync window"
argocd proj windows list <PROJECT_NAME>

# Force sync even during a deny SyncWindow
argocd app sync $APP_NAME --force

# Enable / disable auto-sync
argocd app set $APP_NAME --sync-policy automated
argocd app set $APP_NAME --auto-prune
argocd app set $APP_NAME --self-heal
argocd app set $APP_NAME --sync-policy none   # disable auto-sync (before rollback)
```

---

## Phase 3: Health / Pod Investigation

```bash
NAMESPACE="payment"
APP_LABEL="app=payments-api"

# Get Kubernetes events for the namespace (most useful for Degraded)
kubectl get events -n $NAMESPACE --sort-by='.lastTimestamp' | tail -30

# Get all pods and their status
kubectl get pods -n $NAMESPACE -o wide

# Get pods matching the app's label selector
kubectl get pods -n $NAMESPACE -l $APP_LABEL -o wide

# Describe a failing pod — read Events section at the bottom
POD_NAME=$(kubectl get pods -n $NAMESPACE -l $APP_LABEL \
  -o jsonpath='{.items[0].metadata.name}')
kubectl describe pod $POD_NAME -n $NAMESPACE

# Logs from current pod run
kubectl logs $POD_NAME -n $NAMESPACE --tail=100

# Logs from the PREVIOUS (crashed) run
kubectl logs $POD_NAME -n $NAMESPACE --previous --tail=100

# Check rollout status (is a Deployment rolling out successfully?)
kubectl rollout status deployment/payments-api -n $NAMESPACE

# Check endpoint (does the Service have healthy backends?)
kubectl get endpoints -n $NAMESPACE payments-api

# Check if PVC is bound
kubectl get pvc -n $NAMESPACE

# Check if a Secret referenced by pods exists
kubectl get secret <SECRET_NAME> -n $NAMESPACE

# Check if a ConfigMap referenced by pods exists
kubectl get configmap <CONFIG_NAME> -n $NAMESPACE

# Simulate ArgoCD permission check
kubectl auth can-i create deployment \
  --as=system:serviceaccount:argocd:argocd-application-controller \
  -n $NAMESPACE
```

---

## Phase 4: Repository and Rendering Investigation

```bash
REPO_URL="https://github.com/company/k8s-manifests"

# List all registered repos
argocd repo list

# Get details and connection test for a specific repo
argocd repo get $REPO_URL

# Update credentials for a repo (GitHub PAT rotation)
NEW_PAT="ghp_newTokenHere"
argocd repo add $REPO_URL \
  --username git \
  --password $NEW_PAT \
  --upsert

# Update SSH key credential
argocd repo add git@github.com:company/k8s-manifests \
  --ssh-private-key-path ~/.ssh/argocd_deploy_key \
  --upsert

# Check the webhook secret ArgoCD expects from GitHub
kubectl get secret argocd-secret -n argocd \
  -o jsonpath='{.data.webhook\.github\.secret}' | base64 -d
echo ""  # newline

# Manually render a Helm chart (to reproduce rendering errors locally)
helm template payments-api ./chart \
  --values ./chart/values-prod.yaml \
  --debug 2>&1 | head -80

# Manually render Kustomize (to reproduce rendering errors locally)
kustomize build apps/payments-api/

# Search for a Helm chart version
helm search repo stable/payments --versions | head -10
```

---

## Phase 5: Cluster and RBAC Investigation

```bash
# List all clusters ArgoCD is managing
argocd cluster list

# Get details of a specific cluster
argocd cluster get https://prod-eks.example.com

# Re-add a cluster with fresh credentials
CONTEXT_NAME="prod-eks-context"
argocd cluster add $CONTEXT_NAME --name prod-eks --upsert

# Check ArgoCD's ClusterRole and ClusterRoleBinding
kubectl get clusterrolebinding -o wide | grep argocd
kubectl describe clusterrole argocd-application-controller

# Get an AppProject's full configuration
argocd proj get payments

# Allow a cluster-scoped resource type in a project
argocd proj allow-cluster-resource payments \
  "rbac.authorization.k8s.io" "ClusterRole"

# Allow all cluster resources (less restrictive — use carefully)
argocd proj allow-cluster-resource payments "" "*"
```

---

## Phase 6: Component Log Deep-Dive

```bash
# Application controller — handles sync/health decisions
# Most important component to check when apps show Unknown or sync is frozen
kubectl logs -n argocd \
  deploy/argocd-application-controller \
  --tail=200 | grep -iE "error|warn|fatal"

# Follow live during an active sync
kubectl logs -n argocd \
  deploy/argocd-application-controller -f \
  | grep -iE "error|warn|sync"

# Repo server — handles Git cloning and manifest rendering
# Check when repo connection fails or Helm/Kustomize rendering errors occur
kubectl logs -n argocd \
  deploy/argocd-repo-server \
  --tail=200 | grep -iE "error|warn|fatal"

# API server — handles CLI and Web UI requests
# Check when argocd CLI commands time out or return 500
kubectl logs -n argocd \
  deploy/argocd-server \
  --tail=100 | grep -iE "error|warn"

# Notifications controller
kubectl logs -n argocd \
  deploy/argocd-notifications-controller \
  --tail=100 | grep -iE "error|warn|send"

# ApplicationSet controller
kubectl logs -n argocd \
  deploy/argocd-applicationset-controller \
  --tail=100 | grep -iE "error|warn"
```

---

## Phase 7: Rollback

```bash
APP_NAME="payments-api"

# Step 1: find the last known-good sync ID
argocd app history $APP_NAME
# Note the ID (e.g. 10) of the last Succeeded sync

# Step 2: disable auto-sync BEFORE rolling back
# (otherwise ArgoCD re-syncs to HEAD immediately after rollback)
argocd app set $APP_NAME --sync-policy none

# Step 3: roll back to sync ID 10
argocd app rollback $APP_NAME 10

# Step 4: verify the rollback took effect
argocd app get $APP_NAME
# Expect: Synced + Healthy + revision = <the rolled-back revision>

# Step 5: after fixing Git, re-enable auto-sync
argocd app set $APP_NAME --sync-policy automated
argocd app set $APP_NAME --auto-prune
argocd app set $APP_NAME --self-heal
```

---

## Phase 8: Notifications Test

```bash
NAMESPACE="argocd"
APP_NAME="payments-api"

# Check notifications controller pod is running
kubectl get pods -n $NAMESPACE | grep notifications

# Check controller logs for send errors
kubectl logs -n $NAMESPACE \
  deploy/argocd-notifications-controller --tail=50

# Check app has notification subscription annotations
kubectl get application $APP_NAME -n $NAMESPACE \
  -o jsonpath='{.metadata.annotations}' | jq '.'

# Manually trigger a test notification
argocd admin notifications trigger run on-sync-failed $APP_NAME \
  --recipient slack:payments-alerts \
  -n $NAMESPACE

# Check notification secrets are present
kubectl get secret argocd-notifications-secret \
  -n $NAMESPACE -o yaml | grep -v "password\|token" | head -20
```

---

## Phase 9: Weekly Health Check Script

```bash
#!/usr/bin/env bash
set -euo pipefail
# Run weekly — summarises ArgoCD app health across all apps

echo "=== ArgoCD Weekly Health Check: $(date) ==="

echo ""
echo "--- Component Status ---"
kubectl get pods -n argocd \
  --no-headers \
  -o custom-columns="NAME:.metadata.name,STATUS:.status.phase,RESTARTS:.status.containerStatuses[0].restartCount"

echo ""
echo "--- App Summary ---"
argocd app list \
  --output wide \
  | awk 'NR==1 || $2!="Synced" || $3!="Healthy" {print}'

echo ""
echo "--- OutOfSync Apps ---"
argocd app list | awk '$2 != "Synced" && NR > 1 {print $1, $2, $3}'

echo ""
echo "--- Apps with recent SyncFailed ---"
for app in $(argocd app list -o name); do
  STATUS=$(argocd app get "$app" \
    -o json 2>/dev/null \
    | jq -r '.status.operationState.phase // "N/A"')
  if [ "$STATUS" = "Failed" ]; then
    echo "  FAILED: $app"
  fi
done

echo ""
echo "=== Check complete ==="
```
