# ArgoCD — E2E Troubleshooting Logic, Flow & Reference

---

## E2E Flow Summary

```
1. ALWAYS-ON FOUNDATIONS
   → ArgoCD server, repo-server, application-controller, dex, redis all Running
   → Git repository reachable and credentials valid
   → RBAC and SSO configured; projects scoped to allowed clusters/namespaces
   → Notifications and Slack/PagerDuty webhooks active

2. DAILY (automated)
   → Applications in Synced + Healthy state
   → No OutOfSync drift — Git is the source of truth
   → Image updater (if used) opening PRs or committing tag bumps
   → Sync windows enforced for production (no weekend syncs without approval)

3. WHEN AN ALERT FIRES ("App X is OutOfSync / Degraded / Unknown")
   → Identify: which app, which resource, which sync state
   → Check: app diff, sync status, sync errors, resource events
   → Resolve: manual sync, fix manifest, refresh repo, check RBAC
   → Verify: app returns to Synced + Healthy

4. WEEKLY REVIEW
   → Audit OutOfSync apps not auto-synced (manual drift, skipped resources)
   → Review sync history for repeated failures
   → Prune orphaned resources from previous deployments
   → Check ArgoCD component resource usage (controller CPU/memory)

5. MONTHLY CYCLE
   → Rotate repo credentials (GitHub PAT, SSH key)
   → Review AppProject policies (source repos, destination clusters)
   → Upgrade ArgoCD version if minor release available
   → Test disaster recovery: delete and re-sync a non-critical app

6. ESCALATION / REGRESSION
   → App stuck in Syncing for > 5 minutes → check controller logs
   → Repo-server OOMKill → increase memory limit
   → All apps Unknown → check application-controller crash loop
   → Git webhook not triggering → check webhook secret + network policy
```

---

## Decision Tree — "What Is Wrong With My App?"

```
App is not in Synced + Healthy state
│
├─ Status: OutOfSync
│   ├─ Was Git changed but ArgoCD hasn't picked it up yet?
│   │     → Wait up to 3 minutes (default poll interval)
│   │        OR: argocd app get <name> --refresh   (force re-poll)
│   │
│   ├─ argocd app diff <name> shows differences?
│   │     YES → the live cluster diverges from Git
│   │           → Was the change intentional? (manual kubectl apply)
│   │              YES → update Git to match, OR argocd app sync --prune
│   │              NO  → argocd app sync to restore Git state
│   │
│   └─ No diff shown but still OutOfSync?
│         → Likely a resource that ArgoCD can't track (CRD, external)
│            → Check: argocd app get <name> --show-managed-fields
│            → Add a resource exclusion if the resource fluctuates externally
│
├─ Status: Degraded
│   ├─ Which resource is Degraded?
│   │     argocd app get <name>  → look for resources with status ≠ Healthy
│   │
│   ├─ Deployment is Degraded → pods not coming up
│   │     → kubectl describe pod -n <ns> <pod>  (look at Events section)
│   │     → kubectl logs <pod> -n <ns> --previous
│   │     → Common causes: ImagePullBackOff, CrashLoopBackOff, OOMKilled
│   │
│   ├─ Service is Degraded → no endpoints
│   │     → kubectl get endpoints -n <ns> <svc>
│   │     → Selector labels may not match pod labels
│   │
│   └─ PVC is Degraded → storage issue
│         → kubectl describe pvc -n <ns> <pvc>
│         → StorageClass may be missing or PV not bound
│
├─ Status: Progressing (stuck — not completing)
│   ├─ How long has it been Progressing?
│   │     > 10 minutes → something is stuck
│   │
│   ├─ Deployment rollout stuck
│   │     → kubectl rollout status deployment/<name> -n <ns>
│   │     → kubectl describe pod -n <ns>  (look for Pending pods)
│   │     → Common: insufficient node resources, node selector mismatch
│   │
│   └─ Hook job not completing
│         → kubectl get jobs -n <ns>
│         → kubectl logs job/<hook-job> -n <ns>
│
├─ Status: Unknown
│   ├─ ArgoCD cannot determine the state
│   │
│   ├─ application-controller is down or restarting?
│   │     → kubectl get pods -n argocd
│   │     → kubectl logs -n argocd deploy/argocd-application-controller
│   │
│   └─ Cluster unreachable (managed cluster)?
│         → argocd cluster list  → check STATUS column
│         → argocd cluster get <server-url>
│
├─ Status: SyncFailed
│   ├─ argocd app get <name>  → read the "Message" field
│   │
│   ├─ "permission denied" or "forbidden"
│   │     → ArgoCD service account lacks RBAC permission
│   │     → kubectl get clusterrolebinding | grep argocd
│   │
│   ├─ "resource already exists" / "conflict"
│   │     → Resource exists in cluster not created by ArgoCD
│   │        → argocd app sync --force  (overwrites)
│   │        → OR: adopt the resource: kubectl annotate resource/name \
│   │              app.kubernetes.io/instance=<argocd-app-name>
│   │
│   ├─ "error converting YAML to JSON"
│   │     → Malformed YAML in Git
│   │        → argocd app get <name>  → read the error
│   │        → Fix the manifest in Git; push; ArgoCD re-syncs
│   │
│   └─ Sync hook failure
│         → kubectl get jobs -n <ns> -l "argocd.argoproj.io/hook=Sync"
│         → kubectl logs job/<hook-job> -n <ns>
│
└─ Status: Missing
      → The resource exists in Git but not in the cluster
      → Likely pruning is disabled and it was deleted manually
      → argocd app sync --prune  (re-creates it)
      → OR: re-enable auto-sync with prune
```

---

## Tool Map

| Tool | What It Does | When to Use | Cadence |
|---|---|---|---|
| `argocd app get <name>` | Full app status: sync state, health, resource list, last sync message | First command on any app issue | Every incident |
| `argocd app diff <name>` | Shows what differs between Git and live cluster | Diagnosing OutOfSync | On OutOfSync |
| `argocd app sync <name>` | Triggers a sync of the app to Git state | Restoring after drift or manual fix | On demand |
| `argocd app logs <name>` | Streams logs from all pods in the app | Pod-level log investigation | On Degraded |
| `argocd cluster list` | Lists registered clusters and their connection status | Diagnosing Unknown state | On Unknown |
| `argocd repo list` | Lists registered repositories and their health | Diagnosing repo connection errors | On sync failure |
| `kubectl logs -n argocd` | ArgoCD component logs (controller, repo-server, server) | Deep diagnosis of ArgoCD-level failures | When app-level investigation hits a wall |
| `argocd app history <name>` | Sync history: timestamps, Git revisions, success/failure | Understanding repeated failures | Weekly review |
| `kubectl get applications -n argocd` | Raw CRD view of all apps; shows conditions | Scripted checks, CI integration | Monitoring |

---

## Part 1 — ArgoCD Components: What Each Does and How to Check It

**Understanding which component handles which function is required for root-cause diagnosis.**

```
Component                   Role
──────────────────────────────────────────────────────────────────────
argocd-server               API server + Web UI; handles argocd CLI requests
argocd-application-controller  Watches cluster state; computes sync/health status
argocd-repo-server          Clones repos; renders manifests (Helm, Kustomize, plain YAML)
argocd-dex-server           SSO/OIDC authentication proxy (optional but common)
argocd-redis                Cache for rendered manifests and app state
argocd-applicationset-controller  Generates Applications from ApplicationSet templates
argocd-notifications-controller   Sends Slack/email/PagerDuty notifications
```

### Check All Components Are Running

```bash
kubectl get pods -n argocd -o wide
kubectl get pods -n argocd --field-selector=status.phase!=Running
```

### Check a Component's Logs

```bash
# Application controller (most important — handles sync/health decisions)
kubectl logs -n argocd deploy/argocd-application-controller --tail=100

# Repo server (handles Git cloning and manifest rendering)
kubectl logs -n argocd deploy/argocd-repo-server --tail=100

# API server (handles CLI and UI requests)
kubectl logs -n argocd deploy/argocd-server --tail=100

# Follow logs live during a sync
kubectl logs -n argocd deploy/argocd-application-controller -f
```

### Check Component Resource Usage

```bash
kubectl top pods -n argocd
# If repo-server is OOMKilled: increase memory limit in the argocd deployment
# Typical: repo-server needs 256Mi-512Mi; controller needs 512Mi-1Gi for large clusters
```

---

## Part 2 — App State Investigation

### Get Full App Status (Start Here)

```bash
# Full status: sync state, health state, last sync message, resource list
argocd app get <APP_NAME>

# Force a refresh from Git before checking (bypasses the 3-min poll cache)
argocd app get <APP_NAME> --refresh

# Show all resources with their individual sync and health status
argocd app get <APP_NAME> --show-operation
```

**Reading the output:**

```
Name:               payments-api
Project:            payments
Server:             https://kubernetes.default.svc
Namespace:          payment
URL:                https://argocd.internal/applications/payments-api
Repo:               https://github.com/company/k8s-manifests
Target Revision:    HEAD
Path:               apps/payments-api
SyncPolicy:         Automated (Prune: true, SelfHeal: true)

SYNC STATUS:        OutOfSync    ← the problem
HEALTH STATUS:      Degraded     ← secondary problem

Operation:          Sync
Message:            ComparisonError: ...  ← read this carefully

RESOURCE           VERSION  KIND        NAMESPACE  NAME              STATUS    HEALTH
/                  v1       Service     payment    payments-api      Synced    Healthy
apps/              v1       Deployment  payment    payments-api      OutOfSync Degraded ← this one
```

### Show the Diff

```bash
# What differs between Git and the live cluster
argocd app diff <APP_NAME>

# Diff only a specific resource
argocd app diff <APP_NAME> --resource apps:Deployment:payments-api

# Output diff in summary only (no full YAML)
argocd app diff <APP_NAME> --summary
```

### Show Sync History

```bash
# List past syncs: when, which Git revision, success or failure
argocd app history <APP_NAME>

# Example output:
# ID  DATE                           REVISION
# 10  2026-07-24 14:32:01 +0000 UTC  abc1234 (main)   ← last successful
# 11  2026-07-24 15:10:03 +0000 UTC  def5678 (main)   ← this one failed
```

---

## Part 3 — Sync Troubleshooting

### Trigger a Manual Sync

```bash
# Basic sync
argocd app sync <APP_NAME>

# Sync and prune resources deleted from Git
argocd app sync <APP_NAME> --prune

# Sync only specific resources (not the whole app)
argocd app sync <APP_NAME> --resource apps:Deployment:payments-api

# Force sync even if up-to-date (useful when ArgoCD is stuck)
argocd app sync <APP_NAME> --force

# Sync and apply in dry-run mode (shows what would change, doesn't apply)
argocd app sync <APP_NAME> --dry-run

# Sync a specific Git revision (not HEAD)
argocd app sync <APP_NAME> --revision abc1234
```

### Sync Stuck / Never Completes

```bash
# Check if another sync operation is already in progress
argocd app get <APP_NAME> --show-operation
# Look for: Operation: Sync, Phase: Running — if this persists > 5 min:

# Terminate the stuck operation
argocd app terminate-op <APP_NAME>

# Then retry the sync
argocd app sync <APP_NAME>
```

### SyncFailed — Read the Error Message

```bash
# The error message is in the "Message" field of argocd app get
argocd app get <APP_NAME>

# Common SyncFailed messages and what they mean:
#
# "error converting YAML to JSON: yaml: line 23: ..."
#   → YAML syntax error at line 23 of the manifest
#   → Fix the manifest in Git; push; ArgoCD re-syncs automatically
#
# "namespaces 'payment' not found"
#   → The destination namespace doesn't exist in the cluster
#   → Fix: add CreateNamespace=true to syncPolicy, or create the namespace first
#
# "resource already exists and is not managed by ArgoCD"
#   → A resource with the same name was created outside of ArgoCD
#   → Fix option 1: argocd app sync <name> --force
#   → Fix option 2: kubectl annotate <resource> app.kubernetes.io/instance=<app-name>
#
# "Unauthorized" / "forbidden"
#   → ArgoCD service account lacks permission to create/update that resource type
#   → Check: kubectl get clusterrolebinding | grep argocd
#   → Fix: add the needed RBAC rule to the ArgoCD cluster role
```

### Resource Exclusions (Stop ArgoCD Tracking a Fluctuating Resource)

```bash
# If a resource changes constantly outside Git (e.g. HPA replica count,
# metrics-related CRDs), add it to resource exclusions in the ConfigMap:

kubectl edit configmap argocd-cm -n argocd
# Add under data:
# resource.exclusions: |
#   - apiGroups:
#     - "autoscaling"
#     kinds:
#     - HorizontalPodAutoscaler
#     clusters:
#     - "*"
```

---

## Part 4 — Health Troubleshooting

### App is Degraded — Find the Unhealthy Resource

```bash
# List all resources with non-Healthy status
argocd app get <APP_NAME> | grep -v "Healthy\|Synced"

# Get Kubernetes events for the namespace (most useful for Degraded)
kubectl get events -n <NAMESPACE> --sort-by='.lastTimestamp' | tail -30

# Describe the specific failing resource (e.g. a Deployment)
kubectl describe deployment <DEPLOY_NAME> -n <NAMESPACE>
# Look at: Conditions section and Events section at the bottom

# Check pod status for the deployment
kubectl get pods -n <NAMESPACE> -l app=<DEPLOY_NAME> -o wide

# Check pod logs (current + previous crash)
kubectl logs <POD_NAME> -n <NAMESPACE> --tail=100
kubectl logs <POD_NAME> -n <NAMESPACE> --previous --tail=100
```

### Common Degraded Causes and Fixes

```
CrashLoopBackOff:
  → kubectl logs <pod> --previous  → application startup error
  → Common: bad env var, missing secret, wrong DB connection string
  → Fix: correct the config in Git; sync

ImagePullBackOff / ErrImagePull:
  → kubectl describe pod <pod>  → Events section → exact error
  → Common causes:
      Image tag doesn't exist in the registry
      ECR auth token expired (re-login or check IRSA for the node)
      Private registry secret not present in the namespace
  → Fix: check the image tag in Git; check imagePullSecrets

OOMKilled:
  → kubectl describe pod <pod>  → Containers → Last State: OOMKilled
  → Pod is exceeding its memory limit
  → Fix: increase resources.limits.memory in the Deployment spec in Git

Pending (pod never scheduled):
  → kubectl describe pod <pod>  → Events: "0/3 nodes available..."
  → Common causes: insufficient CPU/memory, node selector mismatch, taint toleration missing
  → Fix: check node capacity (kubectl describe nodes); fix node selector or tolerations

CreateContainerConfigError:
  → kubectl describe pod <pod>  → Events: "secret X not found"
  → A referenced Secret or ConfigMap doesn't exist in the namespace
  → Fix: ensure the Secret/ConfigMap is defined in Git and ArgoCD syncs it first
         (use sync waves to control order: secret wave=0, deployment wave=1)
```

---

## Part 5 — Repo and Git Troubleshooting

### Check Repository Status

```bash
# List all registered repos and their connection status
argocd repo list

# Expected output:
# TYPE  NAME  REPO                                       INSECURE  STATUS      MESSAGE
# git         https://github.com/company/k8s-manifests  false     Successful

# If STATUS = Failed:
argocd repo get https://github.com/company/k8s-manifests
# Reads: "error: authentication required"  → credentials invalid or expired
```

### Fix a Failed Repository Connection

```bash
# Update a repo's credentials (GitHub PAT rotation)
argocd repo add https://github.com/company/k8s-manifests \
  --username git \
  --password <NEW_PAT_TOKEN> \
  --upsert   # updates existing instead of creating a duplicate

# Update SSH key credential
argocd repo add git@github.com:company/k8s-manifests \
  --ssh-private-key-path ~/.ssh/argocd_deploy_key \
  --upsert

# Test the connection after updating
argocd repo get https://github.com/company/k8s-manifests
```

### Force ArgoCD to Re-Fetch From Git

```bash
# Refresh an app (re-polls the repo right now, bypasses 3-min cache)
argocd app get <APP_NAME> --refresh

# Hard refresh (re-renders the manifests from scratch, clears repo-server cache)
argocd app get <APP_NAME> --hard-refresh

# If git webhook is not triggering ArgoCD:
# Check that the webhook secret matches in both GitHub and ArgoCD's ConfigMap
kubectl get secret argocd-secret -n argocd -o jsonpath='{.data.webhook\.github\.secret}' | base64 -d
# Compare with the secret set in GitHub: Settings → Webhooks → Secret field
```

### Helm Chart Troubleshooting

```bash
# If an app uses Helm and fails to render:
# 1. Check the app's error message
argocd app get <APP_NAME>
# Look for: "error while templating..."

# 2. Manually render the Helm chart to see the error
helm template <RELEASE_NAME> <CHART_PATH_OR_URL> \
  --values values.yaml \
  --debug 2>&1 | head -50

# 3. Check if the chart version exists in the Helm repo
helm search repo <CHART_NAME> --versions | head -10

# 4. Update the Helm repo cache in ArgoCD
argocd app get <APP_NAME> --hard-refresh
```

### Kustomize Troubleshooting

```bash
# If ArgoCD fails to render a Kustomize app:
# Render locally to see the error
kustomize build <PATH_TO_KUSTOMIZATION_DIR>

# Common errors:
# "accumulating resources: could not make domain-qualified resource ID"
#   → A referenced base path doesn't exist
#   → Check the resources: entries in kustomization.yaml

# "json: cannot unmarshal string into Go value"
#   → A patch has wrong structure
#   → kustomize build --load-restrictor=LoadRestrictionsNone <path>
```

---

## Part 6 — Cluster and RBAC Troubleshooting

### Check Registered Clusters

```bash
# List all clusters ArgoCD manages
argocd cluster list

# Example output:
# SERVER                              NAME        VERSION  STATUS   MESSAGE
# https://kubernetes.default.svc      in-cluster  1.27     OK
# https://prod-eks.example.com        prod-eks    1.27     Unknown  dial tcp: i/o timeout

# Cluster shows Unknown:
argocd cluster get https://prod-eks.example.com
# Look for the specific connection error

# Re-add a cluster with fresh credentials
argocd cluster add <KUBECTL_CONTEXT_NAME> --name prod-eks --upsert
```

### Fix RBAC / Permission Errors

```bash
# ArgoCD gets "forbidden" when syncing a resource
# Step 1: check what permissions ArgoCD's service account has
kubectl get clusterrolebinding -o wide | grep argocd

# Step 2: check the specific ClusterRole
kubectl describe clusterrole argocd-application-controller

# Step 3: test if the service account can perform the failing action
kubectl auth can-i create deployment \
  --as=system:serviceaccount:argocd:argocd-application-controller \
  -n payment
# Expected: yes
# If "no": add the permission to the ClusterRole

# Step 4: if ArgoCD manages resources cluster-wide, it needs cluster-admin
# or a custom ClusterRole with the specific resource types it deploys
```

### AppProject Restrictions Blocking a Sync

```bash
# If sync fails with "application references project '<name>' which does not permit..."
argocd proj get <PROJECT_NAME>

# Check what source repos, destination clusters, and namespaces are allowed
# Example restrictive project:
#   Source repos:  https://github.com/company/k8s-manifests
#   Destinations:  cluster: in-cluster, namespace: payment
#   Cluster resource whitelist: [empty] ← blocks cluster-scoped resources

# Fix: add the missing resource type to the project whitelist
argocd proj allow-cluster-resource <PROJECT_NAME> "" "*"   # allow all cluster resources
# OR be specific:
argocd proj allow-cluster-resource <PROJECT_NAME> "rbac.authorization.k8s.io" "ClusterRole"
```

---

## Part 7 — Auto-Sync and Self-Heal Troubleshooting

### Check Auto-Sync Configuration

```bash
argocd app get <APP_NAME> | grep -A5 "Sync Policy"
# Expected for production:
# Sync Policy:         Automated
#   Prune:             true
#   Self Heal:         true
#   Allow Empty:       false

# Enable auto-sync on an app (if disabled)
argocd app set <APP_NAME> --sync-policy automated
argocd app set <APP_NAME> --auto-prune
argocd app set <APP_NAME> --self-heal
```

### Why Auto-Sync Isn't Triggering

```bash
# 1. Is the app inside a Sync Window that blocks syncs?
argocd app get <APP_NAME> | grep -i "sync window"
# If "Sync Windows: sync not allowed" appears → a SyncWindow is blocking it

# Check configured SyncWindows
argocd proj windows list <PROJECT_NAME>
# Example output:
# ID  STATUS    KIND    SCHEDULE       DURATION  APPLICATIONS  NAMESPACES  CLUSTERS
# 0   Active    deny    0 20 * * 5     60h       *             production  *
# → deny window from 8 PM Friday for 60h = no syncs Fri night through Mon morning

# Force a sync even during a deny window (use during emergencies)
argocd app sync <APP_NAME> --force

# 2. Is self-heal disabled?
argocd app get <APP_NAME> | grep "Self Heal"
# If "false": enable it: argocd app set <APP_NAME> --self-heal

# 3. Is the Git change being picked up?
argocd app get <APP_NAME> --refresh
# If status changes after --refresh: webhook is not working
# If status does not change: the Git change may not be in the tracked path
```

---

## Part 8 — ArgoCD UI vs CLI Investigation

### In the ArgoCD Web UI

```
Application list view:
  → Colour codes: green = Synced+Healthy, yellow = OutOfSync, red = Degraded
  → Click an app → App detail view

App detail view:
  → Left panel: Sync Status, Health Status, last sync time, repo, revision
  → Resource graph: visual tree of all Kubernetes resources
    → Resources show colour-coded health: green/yellow/red/grey
    → Click a resource → opens a side panel with:
        Summary tab: labels, annotations, owner references
        Events tab:  Kubernetes events for that resource
        Logs tab:    (for Pods) live log stream
        Diff tab:    what differs from Git

Sync button (top right of app view):
  → Synchronize: opens sync dialog
      ✓ Prune: delete resources removed from Git
      ✓ Dry Run: show what would change without applying
      ✓ Force: overwrite even if resource already exists
      ✓ Apply Only: skip pre/post sync hooks
  → Click "Synchronize"

History and Rollback:
  → App detail → History tab
  → Click any past sync → Rollback button
  → Rolls back to that Git revision
```

---

## Part 9 — Notifications Troubleshooting

```bash
# ArgoCD notifications not firing (Slack/PagerDuty silent on app events)

# 1. Check notifications controller is running
kubectl get pods -n argocd | grep notifications

# 2. Check controller logs for errors
kubectl logs -n argocd deploy/argocd-notifications-controller --tail=50

# 3. Check the notification ConfigMap
kubectl get configmap argocd-notifications-cm -n argocd -o yaml
# Look for: triggers, templates, and subscriptions

# 4. Check app has the correct annotation for notifications
kubectl get application <APP_NAME> -n argocd -o yaml | grep notifications
# Expected annotation:
# notifications.argoproj.io/subscribe.on-sync-failed.slack: payments-alerts

# 5. Manually trigger a test notification
argocd admin notifications trigger run on-sync-failed <APP_NAME> \
  --recipient slack:payments-alerts \
  -n argocd

# 6. Check secrets for notification services
kubectl get secret argocd-notifications-secret -n argocd -o yaml
# Verify: slack-token, pagerduty-token, etc. are present and base64-encoded correctly
```

---

## Part 10 — Rollback

```bash
# Roll back to a previous Git revision via CLI

# Step 1: find the revision ID you want to roll back to
argocd app history <APP_NAME>
# Note the ID of the last known-good sync (e.g. ID=10)

# Step 2: roll back
argocd app rollback <APP_NAME> 10

# Step 3: verify
argocd app get <APP_NAME>
# Expect: Synced + Healthy + revision = abc1234 (the rolled-back revision)

# IMPORTANT: auto-sync will try to re-sync to HEAD immediately after rollback
# Disable auto-sync before rolling back if you need time to fix Git:
argocd app set <APP_NAME> --sync-policy none
argocd app rollback <APP_NAME> 10
# Fix the issue in Git
# Then re-enable:
argocd app set <APP_NAME> --sync-policy automated
```

---

## Common Mistakes and Correct Approaches

| Mistake | What Goes Wrong | Correct Approach |
|---|---|---|
| Syncing without `--prune` when resources were deleted from Git | Deleted resources stay in the cluster; app shows Synced but has orphans | Always enable prune in auto-sync policy; or `argocd app sync --prune` manually |
| Using `--force` without understanding why sync failed | Overwrites a resource that may have been intentionally customised outside Git | Read the error message first; only use `--force` when you are certain the cluster version should be replaced |
| Ignoring `OutOfSync` apps because auto-sync is on | An app that auto-sync can't fix accumulates drift that gets worse | Alert on OutOfSync apps that stay OutOfSync after 2 auto-sync attempts |
| Rolling back without disabling auto-sync | ArgoCD re-syncs to HEAD immediately, undoing the rollback | Disable auto-sync first; rollback; fix Git; re-enable |
| Not using sync waves for ordered deployment | Secret doesn't exist when the Deployment tries to mount it → CrashLoop on first sync | Use `argocd.argoproj.io/sync-wave: "0"` on Secrets and `"1"` on Deployments |
| Storing large Helm values files not tracked by ArgoCD | ArgoCD renders from Git; untracked values produce different output | All values must be in Git; use `--values` paths relative to the repo |
| AppProject with empty cluster resource whitelist | CRDs, ClusterRoles, Namespaces fail to sync | Explicitly whitelist cluster-scoped resource types the app needs |
| Webhook secret mismatch between GitHub and ArgoCD | GitHub sends webhooks; ArgoCD ignores them (HMAC validation fails); poll-based delay only | Compare `argocd-secret webhook.github.secret` with GitHub webhook secret field |
