# ArgoCD Troubleshooting — Glossary

**ArgoCD**
A GitOps continuous delivery tool for Kubernetes. It monitors a Git repository for Kubernetes manifests and automatically syncs the cluster to match what is in Git. If someone manually changes something in the cluster, ArgoCD detects the drift and can revert it.

**GitOps**
An operational model where Git is the single source of truth for infrastructure and application configuration. All changes go through Git commits and pull requests. ArgoCD is the engine that enforces this — it continuously reconciles the live cluster state to match the Git state.

**Application (ArgoCD)**
ArgoCD's primary object. An Application defines: which Git repo and path to watch, which Kubernetes cluster and namespace to deploy to, and how to sync. Every app has a sync status and a health status.

**Sync Status**
Whether the live cluster matches Git. Values: `Synced` (cluster matches Git exactly), `OutOfSync` (they differ), `Unknown` (ArgoCD cannot determine — usually a component issue).

**Health Status**
Whether the deployed resources are working correctly. Values: `Healthy` (all resources operating normally), `Degraded` (something is failing), `Progressing` (resources are updating/starting), `Suspended` (intentionally paused), `Missing` (resource exists in Git but not in cluster), `Unknown` (health cannot be determined).

**OutOfSync**
The app's live cluster state differs from Git. Causes: someone ran `kubectl apply` manually outside ArgoCD, a resource field changed automatically (e.g. HPA), or Git was updated and ArgoCD hasn't synced yet. Not always an error — depends on whether auto-sync is on.

**Degraded**
One or more resources in the app are not healthy — pods are crashing, a deployment rollout failed, or a service has no endpoints. ArgoCD sets this based on Kubernetes resource conditions.

**SyncFailed**
ArgoCD attempted to sync (apply resources to the cluster) and the operation failed. The error message in `argocd app get` explains why — common causes: YAML syntax error, RBAC permission denied, resource already exists, namespace missing.

**Progressing**
A resource is in the middle of an update (e.g. a Deployment is rolling out new pods) and hasn't finished yet. ArgoCD sets the app to Progressing until the rollout completes. If it stays Progressing for more than ~10 minutes, something is stuck.

**Auto-Sync**
An ArgoCD feature that automatically triggers a sync whenever it detects a difference between Git and the live cluster. When enabled, ArgoCD effectively enforces that the cluster always matches Git — manual changes get reverted automatically.

**Self-Heal**
An ArgoCD auto-sync option that triggers a re-sync when the cluster drifts from Git due to changes made outside ArgoCD (e.g. someone ran `kubectl edit`). Without self-heal, auto-sync only fires when Git changes, not when the cluster changes.

**Prune**
An ArgoCD sync option that deletes resources from the cluster that exist in the cluster but have been removed from Git. Without prune, old resources accumulate after you remove them from your manifests.

**`argocd app diff`**
A CLI command that shows the exact differences between what is in Git and what is running in the cluster — like a `git diff` but for Kubernetes resources. The first command to run when diagnosing an OutOfSync app.

**`argocd app sync`**
A CLI command that triggers ArgoCD to apply the Git state to the cluster immediately, without waiting for the automatic poll cycle.

**`argocd app get --refresh`**
Forces ArgoCD to re-poll the Git repository right now instead of waiting for the 3-minute poll interval. Useful when you just pushed a change and want ArgoCD to pick it up immediately.

**`argocd app get --hard-refresh`**
Clears the repo-server's rendered manifest cache AND re-polls Git. Stronger than `--refresh`. Used when a Helm or Kustomize rendering error might be cached from a previous failure.

**Poll Interval**
The frequency at which ArgoCD checks Git for changes — default is 3 minutes. Between polls, changes in Git are not picked up unless a webhook or `--refresh` triggers an immediate check.

**argocd-application-controller**
The most critical ArgoCD component. It continuously watches both the cluster state and the Git state, computes the diff, and decides whether the app is Synced/OutOfSync/Healthy/Degraded. If this crashes, all apps show Unknown.

**argocd-repo-server**
The ArgoCD component that clones Git repositories and renders manifests (evaluating Helm templates, running Kustomize builds). If this is unhealthy, apps fail to sync because ArgoCD cannot read the manifests.

**argocd-server**
The ArgoCD API server that handles requests from the Web UI and the `argocd` CLI. If this is down, you can't interact with ArgoCD but syncs can still run (they're controlled by the application-controller).

**argocd-dex-server**
The optional SSO/OIDC authentication proxy in ArgoCD. Used to enable login via Google, GitHub, LDAP, or other identity providers. If dex crashes, only local username/password login works.

**argocd-redis**
The Redis cache ArgoCD uses to store rendered manifests, app state, and session data. ArgoCD is functional without it but much slower — it will re-render manifests from scratch on every request.

**AppProject**
An ArgoCD object that defines policy boundaries for a group of Applications: which Git repos are allowed as sources, which clusters and namespaces are valid destinations, and which Kubernetes resource types can be deployed. Prevents one team from deploying to another team's namespace.

**Cluster Resource Whitelist**
An AppProject setting that lists the cluster-scoped resource types (CRDs, ClusterRoles, Namespaces) that apps in this project are allowed to create. If empty, apps in the project cannot create any cluster-scoped resources — causing sync failures for apps that need them.

**Sync Wave**
An ArgoCD annotation (`argocd.argoproj.io/sync-wave: "N"`) that controls the order in which resources are applied during a sync. Lower numbers are applied first. Used to ensure Secrets and ConfigMaps are created (wave 0) before the Deployments that reference them (wave 1).

**Sync Hook**
A Kubernetes Job or Pod with an ArgoCD hook annotation (`argocd.argoproj.io/hook: PreSync`, `Sync`, or `PostSync`) that ArgoCD runs at a specific point in the sync lifecycle. Used for database migrations, smoke tests, or cleanup tasks.

**Sync Window**
A time-based policy on an AppProject that either allows or denies syncs during specific time periods. Example: deny syncs to production Friday evening through Monday morning. Apps inside a deny window won't auto-sync even if Git changes.

**Resource Exclusion**
A global ArgoCD configuration that tells ArgoCD to ignore specific resource types when computing the diff. Used for resources that change constantly outside Git (HPA replica counts, certain CRDs) to prevent false OutOfSync alerts.

**`--force` (sync flag)**
A `argocd app sync` flag that tells ArgoCD to overwrite a resource in the cluster even if it conflicts with an existing resource not managed by ArgoCD. Use with caution — it overwrites without asking.

**Rollback**
The ArgoCD operation that re-syncs an app to a previous Git revision from its sync history. Requires disabling auto-sync first, or auto-sync will immediately re-sync to HEAD and undo the rollback.

**Orphaned Resource**
A Kubernetes resource running in the cluster that was once managed by ArgoCD but is no longer in Git. ArgoCD marks it as an orphan (OutOfSync) but won't delete it unless prune is enabled.

**Webhook (Git)**
An HTTP POST request that GitHub/GitLab sends to ArgoCD immediately when a new commit is pushed. ArgoCD uses it to trigger an immediate refresh instead of waiting for the poll interval. If the webhook secret doesn't match, ArgoCD silently ignores the webhook.

**HMAC Validation**
The security check ArgoCD performs on incoming GitHub webhooks. GitHub signs the webhook payload with a shared secret; ArgoCD re-computes the signature and rejects the webhook if they don't match. A mismatch means webhooks silently fail.

**CrashLoopBackOff**
A Kubernetes pod status where the container starts, crashes, and Kubernetes restarts it in a loop. Visible in `kubectl describe pod` under State. Indicates an application error (bad config, missing secret, startup crash) rather than an ArgoCD problem.

**ImagePullBackOff**
A Kubernetes pod status where the container runtime cannot pull the container image. Causes: wrong image tag, ECR auth expired, missing `imagePullSecrets`. Visible in `kubectl describe pod` under Events.

**OOMKilled**
A Kubernetes pod termination reason where the container was killed by the OS because it exceeded its memory limit. Visible in `kubectl describe pod` under `Last State: OOMKilled`. Fix: increase `resources.limits.memory` in the Deployment spec.

**Helm**
A Kubernetes package manager that uses templates (charts) with configurable values files to generate Kubernetes manifests. ArgoCD can deploy Helm charts directly — the repo-server renders the chart before applying it. Helm rendering errors show in `argocd app get` as a message.

**Kustomize**
A Kubernetes configuration management tool that applies patches and overlays to base YAML without templating. ArgoCD runs `kustomize build` in the repo-server to render the final manifests. Kustomize build errors show in `argocd app get`.

**`label_values()` / selector mismatch**
A common cause of Services showing Degraded: the Service's `selector` labels don't match the pod's `labels`. The Service has no endpoints (`kubectl get endpoints`) because no pods match the selector.

**ArgoCD Notifications**
An ArgoCD component (`argocd-notifications-controller`) that sends messages to external systems (Slack, PagerDuty, email) when specific app events occur (sync failed, health degraded, sync succeeded). Configured via a ConfigMap and triggered by annotations on Application objects.

**`argocd admin notifications trigger run`**
A CLI command that manually fires a notification trigger for an app without waiting for the real event. Used to test whether notification routing and contact credentials are correctly configured.

**`argocd cluster list`**
Lists all Kubernetes clusters registered with ArgoCD and their connection status. If a cluster shows `Unknown` or an error, apps targeting that cluster will show Unknown health — ArgoCD cannot read their state.

**`argocd cluster add`**
Registers a new Kubernetes cluster with ArgoCD using credentials from your local kubeconfig. Creates a ServiceAccount and ClusterRoleBinding in the target cluster so ArgoCD can deploy to it.

**`kubectl auth can-i`**
A kubectl command that checks whether a given service account is allowed to perform a specific action on a resource. Used to verify whether ArgoCD's service account has the permissions it needs to create/update the resources it's trying to sync.

**`argocd app terminate-op`**
Cancels an in-progress sync operation that is stuck (e.g. a sync that has been running for more than 5 minutes with no progress). After terminating, you can retry the sync cleanly.

**ApplicationSet**
An ArgoCD CRD that generates multiple Applications from a template, driven by a generator (e.g. one app per cluster, one app per Git directory, one app per GitHub PR). Managed by the `argocd-applicationset-controller`.
