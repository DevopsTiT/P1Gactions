# GitOps Troubleshoot — Commands Reference

## Phase 0: Orient — ArgoCD and App Health Snapshot

```bash
# ── ArgoCD component health ──

# Check all ArgoCD pods are Running
kubectl get pods -n argocd \
  -o custom-columns='NAME:.metadata.name,STATUS:.status.phase,RESTARTS:.status.containerStatuses[0].restartCount,AGE:.metadata.creationTimestamp'

# Find any ArgoCD pod not in Running state
kubectl get pods -n argocd \
  --field-selector='status.phase!=Running' 2>/dev/null \
  | grep -v "Completed"

# Check ArgoCD component logs for recent errors
kubectl logs -n argocd deployment/argocd-application-controller --tail=50 | grep -E "error|panic|fatal"
kubectl logs -n argocd deployment/argocd-repo-server --tail=50 | grep -E "error|panic|fatal"
kubectl logs -n argocd deployment/argocd-server --tail=50 | grep -E "error|panic|fatal"

# ── Application status snapshot ──

# List all ArgoCD Applications with health and sync status
kubectl get applications -n argocd \
  -o custom-columns='NAME:.metadata.name,HEALTH:.status.health.status,SYNC:.status.sync.status,REVISION:.status.sync.revision'

# Find apps that are NOT Healthy or NOT Synced
kubectl get applications -n argocd -o json \
  | jq -r '.items[] |
    select(.status.health.status != "Healthy" or .status.sync.status != "Synced") |
    "\(.metadata.name): health=\(.status.health.status) sync=\(.status.sync.status)"'

# Find apps stuck in Progressing for more than 10 minutes
kubectl get applications -n argocd -o json \
  | jq -r '.items[] |
    select(.status.health.status == "Progressing") |
    "\(.metadata.name): progressing since \(.status.reconciledAt)"'

# Show last sync time and result for all apps
kubectl get applications -n argocd -o json \
  | jq -r '.items[] | "\(.metadata.name): last_sync=\(.status.operationState.finishedAt // "never") result=\(.status.operationState.phase // "unknown")"'
```

## Phase 1: OutOfSync Investigation

```bash
# ── Identify what is OutOfSync ──

APP="catalog-service"

# Get full app status detail
kubectl get application "$APP" -n argocd -o json \
  | jq '{
      name: .metadata.name,
      health: .status.health.status,
      sync: .status.sync.status,
      revision: .status.sync.revision,
      lastSync: .status.operationState.finishedAt,
      lastSyncResult: .status.operationState.phase,
      message: .status.operationState.message
    }'

# Show which specific resources are OutOfSync
kubectl get application "$APP" -n argocd -o json \
  | jq -r '.status.resources[] |
    select(.status == "OutOfSync") |
    "\(.kind)/\(.name): \(.status) health=\(.health.status // "N/A")"'

# argocd CLI: show diff between Git and cluster
argocd app diff "$APP"

# argocd CLI: get app summary with all details
argocd app get "$APP"

# ── Check for config drift (OutOfSync with no recent Git commit) ──

# Show the last 5 Git commits for the tracked branch (requires repo access)
# First, find the repo URL from the app spec
REPO=$(kubectl get application "$APP" -n argocd \
  -o jsonpath='{.spec.source.repoURL}')
echo "Tracked repo: $REPO"

# Get the current revision ArgoCD has synced to
CURRENT_REV=$(kubectl get application "$APP" -n argocd \
  -o jsonpath='{.status.sync.revision}')
echo "Currently synced to: $CURRENT_REV"

# Get the revision ArgoCD desires (HEAD of tracked branch)
DESIRED_REV=$(kubectl get application "$APP" -n argocd \
  -o jsonpath='{.status.operationState.syncResult.revision}')
echo "Desired revision: $DESIRED_REV"
```

## Phase 2: SyncFailed Debugging

```bash
APP="catalog-service"

# ── Get the sync failure error message ──

# Show the full sync operation message
kubectl get application "$APP" -n argocd -o json \
  | jq -r '.status.operationState | {phase, message, startedAt, finishedAt}'

# Show per-resource sync results (find which resource failed)
kubectl get application "$APP" -n argocd -o json \
  | jq -r '.status.operationState.syncResult.resources[] |
    select(.status == "SyncFailed" or .hookPhase == "Failed") |
    "\(.kind)/\(.name): \(.message)"'

# argocd CLI: shows most recent sync result with error details
argocd app get "$APP" --show-operation

# ── Common sync error checks ──

# Check if target namespace exists
NAMESPACE=$(kubectl get application "$APP" -n argocd \
  -o jsonpath='{.spec.destination.namespace}')
kubectl get namespace "$NAMESPACE" 2>&1 || echo "NAMESPACE MISSING: $NAMESPACE"

# Check if ArgoCD ServiceAccount has permissions in target namespace
kubectl auth can-i create deployments \
  --as=system:serviceaccount:argocd:argocd-application-controller \
  -n "$NAMESPACE"

kubectl auth can-i create services \
  --as=system:serviceaccount:argocd:argocd-application-controller \
  -n "$NAMESPACE"

# Check for resources in the cluster NOT owned by ArgoCD (potential conflict)
kubectl get deployments -n "$NAMESPACE" -o json \
  | jq -r '.items[] |
    select(.metadata.annotations."managed-by" != "argocd" and
           .metadata.labels."app.kubernetes.io/managed-by" != "Helm") |
    "NOT MANAGED BY ARGOCD: Deployment/\(.metadata.name)"'

# Check for failed hook Jobs still in the namespace
kubectl get jobs -n "$NAMESPACE" \
  -o custom-columns='NAME:.metadata.name,SUCCEEDED:.status.succeeded,FAILED:.status.failed,AGE:.metadata.creationTimestamp' \
  | grep -v "1 " | grep -v "NAME"
# → Any job with FAILED > 0 may be a stuck sync hook

# Get logs from a failed hook job
HOOK_JOB="db-migration-hook"
kubectl logs job/"$HOOK_JOB" -n "$NAMESPACE" --tail=50
```

## Phase 3: Degraded App Investigation

```bash
NAMESPACE="catalog-ns"
APP_LABEL="app=catalog-service"

# ── Pod health investigation ──

# Find all non-Running pods in the namespace
kubectl get pods -n "$NAMESPACE" \
  --field-selector='status.phase!=Running,status.phase!=Succeeded' \
  -o custom-columns='NAME:.metadata.name,STATUS:.status.phase,RESTARTS:.status.containerStatuses[0].restartCount'

# Get restart counts (high restarts = CrashLoopBackOff)
kubectl get pods -n "$NAMESPACE" -l "$APP_LABEL" \
  -o custom-columns='NAME:.metadata.name,STATUS:.status.phase,RESTARTS:.status.containerStatuses[0].restartCount,IMAGE:.spec.containers[0].image'

# Get pod events (OOMKilled, ImagePullBackOff, etc.)
kubectl get events -n "$NAMESPACE" \
  --field-selector type=Warning \
  --sort-by='.lastTimestamp' \
  -o custom-columns='TIME:.lastTimestamp,REASON:.reason,OBJECT:.involvedObject.name,MSG:.message' \
  | tail -20

# ── CrashLoopBackOff: get previous container logs ──

POD=$(kubectl get pods -n "$NAMESPACE" -l "$APP_LABEL" \
  -o jsonpath='{.items[0].metadata.name}')

# Logs from the current (possibly just-restarted) container
kubectl logs -n "$NAMESPACE" "$POD" --tail=100

# Logs from the PREVIOUS crashed container (the crash reason)
kubectl logs -n "$NAMESPACE" "$POD" --previous --tail=100

# ── ImagePullBackOff: diagnose ──

# Check which image is failing to pull
kubectl describe pod "$POD" -n "$NAMESPACE" \
  | grep -A 5 "Failed to pull image"

# Verify the image tag exists in ECR (read-only)
IMAGE=$(kubectl get pod "$POD" -n "$NAMESPACE" \
  -o jsonpath='{.spec.containers[0].image}')
REPO=$(echo "$IMAGE" | cut -d: -f1 | cut -d/ -f2-)
TAG=$(echo "$IMAGE" | cut -d: -f2)
REGION="ap-northeast-1"

aws ecr describe-images \
  --repository-name "$REPO" \
  --image-ids imageTag="$TAG" \
  --region "$REGION" \
  --query 'imageDetails[0].[imageDigest,imagePushedAt]' \
  --output table 2>&1 || echo "IMAGE TAG NOT FOUND: $TAG in $REPO"

# ── OOMKilled: check memory usage vs limits ──

# Current memory usage vs limits
kubectl top pods -n "$NAMESPACE" -l "$APP_LABEL"

# Get the configured memory limit
kubectl get pod "$POD" -n "$NAMESPACE" -o json \
  | jq -r '.spec.containers[] | "\(.name): request=\(.resources.requests.memory // "none") limit=\(.resources.limits.memory // "none")'

# Get termination reason (OOMKilled confirmation)
kubectl get pod "$POD" -n "$NAMESPACE" -o json \
  | jq -r '.status.containerStatuses[].lastState.terminated |
    "reason=\(.reason // "N/A") exitCode=\(.exitCode // "N/A")'
```

## Phase 4: ArgoCD Component Recovery

```bash
# ── Restart ArgoCD components ──

# Restart application controller (fixes stuck reconciliation)
kubectl rollout restart deployment/argocd-application-controller -n argocd
kubectl rollout status deployment/argocd-application-controller -n argocd

# Restart repo server (fixes git auth or disk cache issues)
kubectl rollout restart deployment/argocd-repo-server -n argocd
kubectl rollout status deployment/argocd-repo-server -n argocd

# Restart ArgoCD UI/API server
kubectl rollout restart deployment/argocd-server -n argocd
kubectl rollout status deployment/argocd-server -n argocd

# ── Repository credential check and repair ──

# List all connected repositories and their status
argocd repo list

# Test a specific repo connection
argocd repo get https://github.com/org/k8s-manifests

# Remove a broken repo credential
argocd repo rm https://github.com/org/k8s-manifests

# Re-add repo with SSH key
argocd repo add git@github.com:org/k8s-manifests.git \
  --ssh-private-key-path ~/.ssh/argocd_deploy_key

# Re-add repo with HTTPS token
argocd repo add https://github.com/org/k8s-manifests \
  --username x-token-auth \
  --password <github-pat>

# ── Cluster credential check ──

# List all registered clusters and connection status
argocd cluster list

# Re-register an external cluster (refreshes ServiceAccount token)
# First, switch kubectl context to the target cluster:
kubectl config use-context <target-cluster-context>
argocd cluster add <target-cluster-context> --in-cluster=false
```

## Phase 5: Config Drift Detection and Remediation

```bash
APP="catalog-service"
NAMESPACE="catalog-ns"

# ── Detect config drift ──

# Show the full diff between Git (desired) and cluster (live)
argocd app diff "$APP"

# Show only resources that differ (without the full YAML)
argocd app diff "$APP" --summary

# Check if self-heal is enabled (prevents drift from persisting)
kubectl get application "$APP" -n argocd -o json \
  | jq '{
      autoSync: .spec.syncPolicy.automated,
      selfHeal: .spec.syncPolicy.automated.selfHeal,
      prune: .spec.syncPolicy.automated.prune
    }'

# ── Force sync to restore Git state (overwrite drift) ──

# Sync with prune (removes resources deleted from Git)
argocd app sync "$APP" --prune

# Force sync (applies even if resource is locked or conflicted)
argocd app sync "$APP" --force

# Dry-run sync (shows what WOULD change without applying)
argocd app sync "$APP" --dry-run

# ── Check if manual kubectl edits are happening (audit) ──

# Check Kubernetes audit log for non-ArgoCD changes to a deployment
# (requires audit logging enabled on the cluster)
# This example queries CloudWatch Logs if using EKS with CloudWatch audit logs
aws logs filter-log-events \
  --log-group-name "/aws/eks/prod/cluster" \
  --filter-pattern '{ $.objectRef.resource = "deployments" && $.user.username != "system:serviceaccount:argocd:argocd-application-controller" && $.verb = "patch" }' \
  --start-time "$(date -v-1H -u +%s)000" \
  --query 'events[*].message' \
  --output text \
  | python3 -c "import sys,json; [print(json.loads(l).get('user',{}).get('username','?'), json.loads(l).get('objectRef',{}).get('name','?')) for l in sys.stdin if l.strip()]" \
  2>/dev/null | head -20
```

## Phase 6: Rollback Operations

```bash
APP="catalog-service"

# ── View deployment history ──

# List all sync history with Git SHAs
argocd app history "$APP"

# ── Roll back to a previous revision ──

# Roll back to the immediately previous revision (N-1)
argocd app rollback "$APP"

# Roll back to a specific revision number (from history list)
REVISION_ID=14
argocd app rollback "$APP" "$REVISION_ID"

# ── After rollback: verify recovery ──

# Watch app health and sync status (updates every 2 seconds)
watch -n 2 "argocd app get $APP | grep -E 'Health Status|Sync Status|Revision'"

# Check pods are running the old image
kubectl get pods -n catalog-ns -l app=catalog-service \
  -o custom-columns='NAME:.metadata.name,IMAGE:.spec.containers[0].image,STATUS:.status.phase'

# ── Re-enable auto-sync after a rollback (when the fix is ready) ──

# After pushing the fix commit to Git, enable auto-sync to resume normal GitOps:
argocd app set "$APP" --sync-policy automated --auto-prune --self-heal
```

## Phase 7: Monthly GitOps Health Review Script

```bash
#!/usr/bin/env bash
set -euo pipefail

# Monthly GitOps Health Review
# Run: first Monday of each month before the team review meeting
# Requires: kubectl configured, argocd CLI logged in

TODAY=$(date +%Y-%m-%d)
ARGOCD_NS="argocd"

echo "════════════════════════════════════════════════════════"
echo "Monthly GitOps Health Review — ${TODAY}"
echo "════════════════════════════════════════════════════════"

echo ""
echo "── 1. ARGOCD COMPONENT HEALTH ──"
kubectl get pods -n "$ARGOCD_NS" \
  -o custom-columns='NAME:.metadata.name,STATUS:.status.phase,RESTARTS:.status.containerStatuses[0].restartCount' \
  | grep -v "Completed"

echo ""
echo "── 2. APPS NOT HEALTHY OR NOT SYNCED ──"
kubectl get applications -n "$ARGOCD_NS" -o json \
  | jq -r '.items[] |
    select(.status.health.status != "Healthy" or .status.sync.status != "Synced") |
    "  \(.metadata.name): health=\(.status.health.status) sync=\(.status.sync.status)"' \
  | sort

echo ""
echo "── 3. APPS WITH AUTO-SYNC DISABLED (manual-only) ──"
kubectl get applications -n "$ARGOCD_NS" -o json \
  | jq -r '.items[] |
    select(.spec.syncPolicy.automated == null) |
    "  \(.metadata.name): AUTO-SYNC=DISABLED (manual only)"'

echo ""
echo "── 4. APPS WITHOUT SELF-HEAL ENABLED ──"
kubectl get applications -n "$ARGOCD_NS" -o json \
  | jq -r '.items[] |
    select(.spec.syncPolicy.automated != null and .spec.syncPolicy.automated.selfHeal != true) |
    "  \(.metadata.name): selfHeal=false — drift will persist until manual sync"'

echo ""
echo "── 5. APPS WITHOUT PRUNE ENABLED ──"
kubectl get applications -n "$ARGOCD_NS" -o json \
  | jq -r '.items[] |
    select(.spec.syncPolicy.automated != null and .spec.syncPolicy.automated.prune != true) |
    "  \(.metadata.name): prune=false — deleted resources will linger in cluster"'

echo ""
echo "── 6. APPS USING :latest IMAGE TAG ──"
for app in $(kubectl get applications -n "$ARGOCD_NS" -o jsonpath='{.items[*].metadata.name}'); do
  ns=$(kubectl get application "$app" -n "$ARGOCD_NS" \
    -o jsonpath='{.spec.destination.namespace}' 2>/dev/null || echo "")
  if [ -n "$ns" ]; then
    kubectl get pods -n "$ns" -o json 2>/dev/null \
      | jq -r --arg app "$app" \
        '.items[].spec.containers[] | select(.image | endswith(":latest")) |
         "  APP=\($app) image=\(.image)"' 2>/dev/null || true
  fi
done

echo ""
echo "── 7. REGISTERED REPO STATUS ──"
argocd repo list 2>/dev/null || echo "  (argocd CLI not logged in; run: argocd login <host>)"

echo ""
echo "════════════════════════════════════════════════════════"
echo "Review checklist:"
echo "  □ Investigate any non-Healthy or non-Synced apps above"
echo "  □ Enable auto-sync + self-heal on all non-Tier-1 apps"
echo "  □ Enable prune on all apps to prevent resource accumulation"
echo "  □ Replace :latest image tags with pinned versions in Git"
echo "  □ Rotate any repo credentials expiring within 30 days"
echo "════════════════════════════════════════════════════════"
```
