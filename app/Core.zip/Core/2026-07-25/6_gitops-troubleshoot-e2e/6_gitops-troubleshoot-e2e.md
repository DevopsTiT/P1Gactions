# GitOps Troubleshoot — E2E Logic, Flow & Reference

---

## E2E Flow Summary

```
1. ALWAYS-ON FOUNDATIONS
   → ArgoCD Application Controller healthy (pod Running in argocd namespace)
   → Repo Server reachable (can clone the tracked Git repo)
   → Every app has sync policy defined; self-heal and prune configured
   → Webhook from Git → ArgoCD registered (prevents 3-min polling lag)
   → RBAC: no team can kubectl-edit production resources directly

2. DAILY (automated checks)
   → Scan Applications list: any Degraded or OutOfSync apps?
   → Confirm no apps stuck in "Progressing" > 10 minutes
   → Check ArgoCD component health (controller, repo-server, server pods)
   → Alert if any app's last-sync-time > 30 minutes (stale sync state)

3. WHEN AN ALERT FIRES ("App X is OutOfSync / Degraded / SyncFailed")
   → Identify: is it a Git problem, a cluster problem, or an application problem?
   → Git problem   → fix the manifest in the repo; push; re-sync
   → Cluster problem → fix infra (node, namespace, RBAC); re-sync
   → App problem   → fix the application code/config in Git; push; re-sync
   → Never fix directly in cluster — always fix in Git first

4. MONTHLY REVIEW
   → Audit: any apps with manual sync history (should be automated in staging)
   → Drift report: apps that had OutOfSync events caused by direct cluster edits
   → Prune audit: orphaned resources that weren't pruned (prune=false apps)
   → Secret management review: any secrets stored in Git plaintext?

5. QUARTERLY CYCLE
   → ArgoCD version upgrade review: check release notes for breaking changes
   → RBAC policy review: who has sync/delete access to which projects?
   → Repository credential rotation: rotate SSH keys and PATs for repo access
   → App of Apps structure review: any orphaned child apps with no parent?

6. ROLLBACK / REGRESSION
   → Deploy-triggered regression: ArgoCD History → Rollback to last known-good SHA
   → Config drift found: sync immediately to restore Git state
   → Broken ArgoCD itself: kubectl rollout restart in argocd namespace
   → Corrupted Application CR: delete and re-create from Git manifest
```

---

## Decision Tree

```
"GitOps / ArgoCD is broken — what is wrong?"
│
├─ App shows OutOfSync
│   ├─ Was there a recent Git push?
│   │   ├─ YES → Normal: click Sync (or wait for auto-sync)
│   │   │         Check diff first to confirm changes are expected
│   │   └─ NO  → Config drift: someone kubectl-edited the cluster directly
│   │             → Open Diff view → identify the drifted field
│   │             → Fix in Git (if change was intentional) OR sync to revert
│   │
│   └─ Sync is failing (SyncFailed, not just OutOfSync)?
│       → Go to "Sync Failures" branch below
│
├─ App shows Degraded (Synced but unhealthy)
│   ├─ Which resource is red in the tree?
│   │   ├─ Pod → CrashLoopBackOff → check pod logs (previous container)
│   │   ├─ Pod → OOMKilled        → check memory limit; increase in Git
│   │   ├─ Pod → ImagePullBackOff → check image tag exists in ECR
│   │   ├─ Pod → Pending          → check node capacity / taints
│   │   └─ Deployment → 0/N ready → check ReplicaSet events
│   │
│   └─ All pods green but app still Degraded?
│       → Check custom health check resource (Rollout, VirtualService)
│       → Check if health annotation is wrong in ArgoCD app spec
│
├─ Sync Failures
│   ├─ "namespace not found"
│   │   → Create namespace or enable AUTO-CREATE NAMESPACE in app spec
│   │
│   ├─ "resource already exists" (403/409)
│   │   → Resource was created outside ArgoCD; adopt it OR delete and let ArgoCD create
│   │   → Add annotation: argocd.argoproj.io/managed-by: argocd
│   │
│   ├─ "unable to replace resource" (immutable field change)
│   │   → You changed an immutable field (e.g. Job selector, PVC storageClass)
│   │   → Delete the resource manually → sync → ArgoCD recreates it
│   │
│   ├─ "permission denied" (RBAC)
│   │   → ArgoCD's ServiceAccount lacks permission to manage this resource type
│   │   → Add the resource type to the ArgoCD ClusterRole OR use a Project allow list
│   │
│   ├─ "hook failed" (sync hook error)
│   │   → A pre-sync or post-sync Job/Hook failed
│   │   → Check the hook Pod's logs → fix the hook script in Git
│   │
│   └─ "repo not found" / "authentication failed"
│       → Broken repo credentials → go to Settings → Repositories → reconnect
│
├─ ArgoCD itself is broken
│   ├─ UI not loading        → check argocd-server pod; check Ingress/LB
│   ├─ Apps not auto-syncing → check argocd-application-controller pod
│   ├─ Can't clone repos     → check argocd-repo-server pod; check credentials
│   └─ Notifications broken  → check argocd-notifications-controller pod
│
└─ App is stuck in "Progressing" forever
    ├─ Deployment rollout stalled → pods failing to come up → check pod logs
    ├─ Argo Rollout paused        → check rollout status; promote or abort
    └─ Post-sync hook running forever → check hook pod; has it timed out?
```

---

## Tool Map

| Tool | What It Does | When to Use | Cadence |
|---|---|---|---|
| ArgoCD UI → Applications list | Health + Sync status at a glance for all apps | Daily health check; first view during any incident | Daily |
| ArgoCD UI → Diff view | Side-by-side Git vs cluster YAML comparison | Any OutOfSync app; before every sync of a risky change | On OutOfSync |
| ArgoCD UI → History + Rollback | Past sync list with Git SHAs; rollback to any revision | Deploy regression; "what was running before?" | On regression |
| ArgoCD UI → Logs tab | Pod log stream directly in browser | CrashLoopBackOff; startup errors; any Degraded pod | On Degraded |
| `argocd app get` CLI | Shows app sync/health status + last sync details | Scripted health checks; CI/CD gate verification | Automated |
| `argocd app diff` CLI | Prints Git-vs-cluster diff in terminal | Pre-sync review in CI/CD pipelines | Before sync |
| `argocd app sync` CLI | Triggers a sync programmatically | Automated deploy pipelines | On merge |
| `argocd app rollback` CLI | Rolls back to a previous revision by number | Automated rollback in CI/CD | On regression |
| `kubectl get applications -n argocd` | Raw Application CRD state | When ArgoCD UI is down | Fallback |
| `kubectl logs -n argocd` | ArgoCD component logs (controller, repo-server) | When apps fail to sync for no visible reason | On mystery failures |
| `argocd admin app generate-spec` | Generates an Application manifest from CLI args | Creating app manifests for App of Apps | Setup |

---

## Part 1 — OutOfSync: Diagnosing and Resolving

**Without understanding why an app is OutOfSync you can sync blindly and deploy a breaking change, or you can sync and wipe a legitimate manual fix someone made under pressure.**

**With a disciplined diff-first approach:** every sync is a deliberate choice — you know exactly what will change in the cluster before it happens.

### OutOfSync Causes and How to Identify Each

```
Cause A: New Git commit not yet applied (expected OutOfSync)
  Signal: Recent commit visible in GitHub; Sync status just flipped to OutOfSync
  Diff shows: new image tag, updated env var, added resource
  Action: Review diff → sync (this is the normal deploy flow)

Cause B: Config drift — someone kubectl-edited the cluster directly
  Signal: No recent Git commit; OutOfSync appeared without a push
  Diff shows: cluster side has a value NOT present in Git
              e.g. memory: "512Mi" in Git  vs  memory: "256Mi" in cluster
  Action:
    If the manual change was WRONG → sync to restore Git state (drift is erased)
    If the manual change was CORRECT → update Git to match, then sync
    Either way: investigate WHO made the change (kubectl auth log / CloudTrail)
    Fix root cause: enable self-heal to prevent recurrence

Cause C: Resource created outside ArgoCD (exists in cluster, not in Git)
  Signal: Diff shows cluster has a resource that Git does not define
  Diff shows: red "cluster only" resource (not in Git)
  Action:
    Option A: Add the resource manifest to Git (adopt it)
    Option B: Delete the resource from the cluster (if it shouldn't exist)
    Never leave it; over time these accumulate and create confusion

Cause D: ArgoCD ignored a resource type (ignoreDifferences config)
  Signal: App looks OutOfSync but diff shows trivial fields (e.g. lastAppliedConfig)
  Action: Add an ignoreDifferences rule in the Application spec for that field
  (See Part 4 — ignoreDifferences)
```

### Reading the Diff View

```
ArgoCD Diff panel layout (App detail → click OutOfSync badge):

DESIRED STATE (Git)          │  LIVE STATE (Cluster)
─────────────────────────    │  ─────────────────────────
image: catalog:v2.3.1        │  image: catalog:v2.3.0   ← different
replicas: 3                  │  replicas: 3
resources:                   │  resources:
  limits:                    │    limits:
    memory: "512Mi"          │      memory: "256Mi"     ← drifted

Lines with no highlight = identical (no diff)
Lines highlighted green  = in Git but NOT in cluster (will be added on sync)
Lines highlighted red    = in cluster but NOT in Git (will be removed on sync if PRUNE=true)
Lines highlighted yellow = value differs between Git and cluster

Before syncing: confirm every highlighted line is expected.
If you see an unexpected deletion (red line): check PRUNE setting.
If you see an unexpected addition (green line): confirm it is the right change.
```

---

## Part 2 — SyncFailed: Root Causes and Fixes

**SyncFailed means ArgoCD tried to apply manifests but Kubernetes rejected them.** This is different from Degraded (manifests applied but the app is unhealthy). SyncFailed means nothing was deployed yet.

### Error: namespace not found

```
Symptom:
  App: SyncFailed
  Error: "namespaces 'catalog-ns' not found"

Cause: The destination namespace does not exist in the cluster.

Fix Option A — Enable AUTO-CREATE NAMESPACE in the Application spec:
  spec:
    syncPolicy:
      syncOptions:
        - CreateNamespace=true

Fix Option B — Create the namespace manually then re-sync:
  kubectl create namespace catalog-ns

Fix Option C — Add a Namespace manifest to Git:
  Add namespace.yaml to the app's Git path:
    apiVersion: v1
    kind: Namespace
    metadata:
      name: catalog-ns
  Commit and push → ArgoCD creates the namespace as part of the sync

Root cause check:
  In production, namespaces should be created by a platform/infra team via Git.
  Option A (auto-create) is convenient but bypasses namespace governance.
  Prefer Option C for production environments.
```

### Error: resource already exists (409 Conflict)

```
Symptom:
  App: SyncFailed
  Error: 'Operation cannot be fulfilled on deployments.apps "catalog-service":
         the object has been modified; please apply your changes to the latest version'
  OR: "resource already exists and is not managed by ArgoCD"

Cause: A Deployment, Service, or ConfigMap already exists in the cluster
       but was NOT created by ArgoCD (no `managed-by: argocd` annotation).

Fix Option A — Adopt the resource (tell ArgoCD to take ownership):
  kubectl annotate deployment catalog-service -n catalog-ns \
    argocd.argoproj.io/managed-by=argocd

Fix Option B — Delete and let ArgoCD recreate:
  kubectl delete deployment catalog-service -n catalog-ns
  → Then sync → ArgoCD creates it fresh with the correct annotations
  WARNING: causes brief downtime; use during a maintenance window

Fix Option C — Use server-side apply (prevents most conflicts):
  Add to Application spec:
    syncPolicy:
      syncOptions:
        - ServerSideApply=true
  → Kubernetes handles merge conflicts server-side instead of client-side
  → Recommended for all new ArgoCD applications
```

### Error: immutable field change

```
Symptom:
  App: SyncFailed
  Error: "field is immutable" or "invalid: spec.selector: field is immutable"

Cause: You tried to change a field that Kubernetes does not allow changing
       after a resource is created.

Commonly immutable fields:
  Deployment:  spec.selector (the pod label selector)
  Job:         spec.selector, spec.template
  PVC:         spec.storageClassName, spec.accessModes
  Service:     spec.clusterIP (when changing from ClusterIP to NodePort)

Fix:
  1. Delete the resource from the cluster:
     kubectl delete deployment catalog-service -n catalog-ns
     (or the specific resource type that is immutable)

  2. Sync ArgoCD → it recreates the resource with the new spec

  WARNING: Deleting a Deployment causes pod downtime.
    For zero-downtime: create a new Deployment with a new name first,
    shift traffic to it, delete the old one, rename if needed.

  Prevention: avoid changing spec.selector in production Deployments.
    Use different names (blue/green) if the selector must change.
```

### Error: permission denied (RBAC)

```
Symptom:
  App: SyncFailed
  Error: "deployments.apps is forbidden: User 'system:serviceaccount:argocd:argocd-application-controller'
         cannot create resource 'deployments' in namespace 'catalog-ns'"

Cause: The ArgoCD ServiceAccount (argocd-application-controller) lacks
       permission to manage this resource type in this namespace.

Fix Option A — Extend ArgoCD's ClusterRole:
  kubectl edit clusterrole argocd-application-controller
  → Add the missing resource to the rules section:
    - apiGroups: ["apps"]
      resources: ["deployments"]
      verbs: ["get","list","watch","create","update","patch","delete"]

Fix Option B — Add a RoleBinding in the target namespace:
  If you prefer not to give ArgoCD cluster-wide access:
  kubectl create rolebinding argocd-deploy-catalog \
    --clusterrole=argocd-application-controller \
    --serviceaccount=argocd:argocd-application-controller \
    --namespace=catalog-ns

Fix Option C — Use ArgoCD Project's cluster resource allow list:
  Settings → Projects → [project name] → Cluster Resource Allow List
  → Add the resource group/kind that is being blocked

Root cause check: ArgoCD running with a custom/restricted ServiceAccount?
  Check: kubectl get clusterrolebinding -l app.kubernetes.io/name=argocd
  If custom RBAC was applied during install: verify all needed resource types are allowed
```

### Error: hook failed

```
Symptom:
  App: SyncFailed
  Error: "one or more sync tasks are not valid" or "hook failed"
  In the resource tree: a Job resource shows as 🔴 Failed

Cause: A pre-sync, sync, or post-sync hook Job failed to complete successfully.

Hooks are Kubernetes Jobs annotated with:
  argocd.argoproj.io/hook: PreSync    (run before manifests are applied)
  argocd.argoproj.io/hook: PostSync   (run after all resources are healthy)
  argocd.argoproj.io/hook: SyncFail   (run only when sync fails — for cleanup)

Fix:
  1. Click the failed Job in the resource tree → LOGS tab
     → Read the output to understand why the hook failed
     → Common causes: DB migration script error, smoke test failure,
       network unreachable, missing secret

  2. Fix the hook script in Git → commit → push

  3. Clean up the failed hook Job (ArgoCD may not auto-delete it):
     kubectl delete job <hook-job-name> -n <namespace>

  4. Re-sync

Hook deletion policy (set in Git to control lifecycle):
  argocd.argoproj.io/hook-delete-policy: HookSucceeded    ← delete after success
  argocd.argoproj.io/hook-delete-policy: HookFailed       ← delete after failure
  argocd.argoproj.io/hook-delete-policy: BeforeHookCreation ← delete before re-run
  Best practice: HookSucceeded in production (keeps failures visible for debugging)
```

---

## Part 3 — Degraded: App Deployed but Unhealthy

**Degraded means ArgoCD successfully applied the Git manifests, but the running application is not healthy.** The GitOps layer worked; the application layer is broken.

### CrashLoopBackOff

```
Signal in ArgoCD:
  Resource tree: Pod shows 🔴 CrashLoopBackOff
  Restart count increases every few minutes

Investigation path:
  Click the pod → LOGS tab → toggle "previous" checkbox
  → Shows logs from the crashed container instance (not the current restarting one)

Common causes and Git-level fixes:

  Cause: Missing environment variable
    Log: "required env var DB_HOST not set" or panic/nil pointer
    Fix in Git: add the env var to the Deployment's env section
                OR add a reference to the Secret/ConfigMap that holds it

  Cause: Wrong Secret name in envFrom
    Log: "secret 'db-credentials-prod' not found" in events
    Fix in Git: correct the secretName in the envFrom or env.valueFrom.secretKeyRef

  Cause: Application startup error (code bug)
    Log: stack trace with a known error (e.g. database migration fails)
    Fix in Git: fix the code → push → ArgoCD deploys new image → pod restarts cleanly

  Cause: Liveness probe too aggressive
    Events: "liveness probe failed; killing container"
    Fix in Git: increase initialDelaySeconds or failureThreshold on the liveness probe
```

### ImagePullBackOff

```
Signal in ArgoCD:
  Resource tree: Pod shows ⚠️ ImagePullBackOff or ErrImagePull
  Events tab: "failed to pull image ... 404 Not Found" or "unauthorized"

Cause A: Image tag does not exist in ECR
  Fix in Git:
    Check ECR for the correct tag
    Update the image tag in the Deployment manifest
    Push → sync

Cause B: ECR credentials not configured for the namespace
  Fix: create an imagePullSecret in the namespace and reference it:
    kubectl create secret docker-registry ecr-credentials \
      --docker-server=<account>.dkr.ecr.<region>.amazonaws.com \
      --docker-username=AWS \
      --docker-password=$(aws ecr get-login-password) \
      -n catalog-ns
    Add to Deployment in Git:
      spec.template.spec.imagePullSecrets:
        - name: ecr-credentials
  Better approach: use IRSA + ECR pull-through cache (no secrets needed)

Cause C: Image tag is "latest" and ECR has no "latest" tag
  Fix in Git: never use ":latest"; always use a specific SHA or semantic version tag
```

### Pod Stuck in Pending

```
Signal in ArgoCD:
  Resource tree: Pod shows ⚫ Pending for more than 2 minutes
  Events tab: "0/3 nodes are available: 3 Insufficient memory"
             OR: "0/3 nodes are available: node(s) had taint that pod didn't tolerate"

Cause A: Insufficient node resources (CPU or memory)
  Event: "Insufficient memory" or "Insufficient cpu"
  Fix: scale up node group OR reduce the pod's resource requests in Git

Cause B: Taint/Toleration mismatch
  Event: "node(s) had taint that pod didn't tolerate"
  Fix in Git: add the toleration to the pod spec
    tolerations:
      - key: "dedicated"
        operator: "Equal"
        value: "payments"
        effect: "NoSchedule"

Cause C: NodeSelector or Affinity rule has no matching nodes
  Event: "node(s) didn't match node selector"
  Fix in Git: correct the nodeSelector or affinity rule to match existing node labels

Cause D: PVC not bound (waiting for storage)
  Event: "persistentvolumeclaim 'data-vol' not found" or "waiting for first consumer"
  Fix in Git: ensure PVC manifest is in the repo and ArgoCD synced it
              Check StorageClass is available in the cluster
```

---

## Part 4 — ArgoCD Component Failures

**When ArgoCD itself is broken, no apps sync — the whole GitOps pipeline is down.**

### argocd-application-controller Pod Failing

```
What breaks: apps do not auto-sync; health/sync status stops updating
Signal: no apps have updated since a certain time; controller pod is Restarting

Check:
  kubectl get pods -n argocd
  kubectl logs -n argocd deployment/argocd-application-controller --tail=100

Common causes:
  OOMKilled:
    The controller processed too many apps/resources and ran out of memory
    Fix: increase controller memory limit:
      kubectl edit deployment argocd-application-controller -n argocd
      → increase resources.limits.memory (e.g. 512Mi → 2Gi)
      → In production: set this in the ArgoCD Helm values and re-deploy

  Stuck processing a corrupted Application CR:
    Logs: "panic" or infinite loop on a specific app name
    Fix: kubectl delete application <stuck-app-name> -n argocd
    (Deletes the ArgoCD app record; does NOT delete the deployed K8s resources)
    → Re-create the Application from Git

  Leader election failed (if multiple replicas):
    Logs: "failed to acquire leader lease"
    Fix: kubectl delete pods -l app.kubernetes.io/name=argocd-application-controller -n argocd
    → Pods restart and re-elect a leader
```

### argocd-repo-server Pod Failing

```
What breaks: ArgoCD cannot clone repos or render Helm/Kustomize templates
             All syncs fail with "repo server unavailable"

Check:
  kubectl logs -n argocd deployment/argocd-repo-server --tail=100

Common causes:
  SSH key or HTTPS token expired/rotated:
    Logs: "authentication failed" or "repository not found"
    Fix: Settings → Repositories → disconnect and reconnect with new credentials
         OR: kubectl edit secret repo-<hash> -n argocd → update the credential

  Disk full (repo cache):
    Logs: "no space left on device"
    Fix: kubectl exec -n argocd deployment/argocd-repo-server -- du -sh /tmp
         → Restart the pod (clears the cache):
           kubectl rollout restart deployment/argocd-repo-server -n argocd

  Helm plugin or custom tool crash:
    Logs: "plugin 'helm-secrets' not found" or exec errors
    Fix: ensure custom plugins are installed in the repo-server image
         OR: rebuild ArgoCD image with the plugin included
```

### argocd-server (UI/API) Not Responding

```
What breaks: UI unreachable; argocd CLI fails with connection refused
Signal: https://<argocd-host> returns 502 / 504; kubectl can still reach the cluster

Check:
  kubectl get pods -n argocd -l app.kubernetes.io/name=argocd-server
  kubectl describe ingress argocd-server-ingress -n argocd  (if using Ingress)

Common causes:
  Pod crashed: restart it:
    kubectl rollout restart deployment/argocd-server -n argocd

  Ingress/LB misconfigured after a cluster change:
    Check: kubectl get ingress -n argocd
    Check: kubectl get service argocd-server -n argocd
    Verify LoadBalancer external IP is still valid

  TLS cert expired:
    Logs: "certificate has expired"
    Fix: kubectl delete secret argocd-secret -n argocd
         (ArgoCD regenerates a self-signed cert on restart)
         Or: renew the cert-manager certificate
```

---

## Part 5 — ignoreDifferences: Suppressing False OutOfSync

Some Kubernetes controllers mutate resources after ArgoCD applies them (adding fields ArgoCD didn't set). ArgoCD then sees these added fields as OutOfSync — even though the desired state is actually met.

```
Common false-OutOfSync sources:

  1. kube-controller-manager adds to Deployment spec:
     spec.template.spec.serviceAccountName: default
     spec.template.spec.securityContext: {}
     → These are added by K8s automatically; ArgoCD sees them as "not in Git"

  2. Cert-manager injects annotations into Ingress:
     annotations:
       cert-manager.io/certificate-name: ...
     → Not in Git; ArgoCD thinks it is a cluster-only field

  3. Istio injects sidecar annotation:
     annotations:
       sidecar.istio.io/status: ...

  4. Horizontal Pod Autoscaler modifies Deployment replicas:
     spec.replicas: 5   (HPA set it to 5; Git says 3)
     → ArgoCD wants to reset replicas back to 3 on every sync (fight with HPA)

Fix: ignoreDifferences in the Application spec

For fields added by controllers:
  spec:
    ignoreDifferences:
      - group: apps
        kind: Deployment
        jsonPointers:
          - /spec/template/spec/serviceAccountName
          - /spec/template/spec/securityContext

For HPA managing replicas (most important):
  spec:
    ignoreDifferences:
      - group: apps
        kind: Deployment
        jsonPointers:
          - /spec/replicas

  Also add to syncPolicy to prevent ArgoCD from resetting replicas:
    spec:
      syncPolicy:
        syncOptions:
          - RespectIgnoreDifferences=true

For annotation injection (Istio, cert-manager):
  spec:
    ignoreDifferences:
      - group: networking.k8s.io
        kind: Ingress
        managedFieldsManagers:
          - cert-manager-controller
      - group: apps
        kind: Deployment
        managedFieldsManagers:
          - istio-sidecar-injector
```

---

## Part 6 — Secrets in GitOps: Safe Patterns

**Never store plaintext secrets in Git.** This is the most critical GitOps security rule. Even private repos can be leaked. Even encrypted repos are dangerous if the key is also in the repo.

```
Pattern                   Tool              How It Works
──────────────────────────────────────────────────────────────────────────────────────
Sealed Secrets            Bitnami Sealed    Encrypt secret with cluster-specific key;
                          Secrets           store encrypted SealedSecret in Git;
                                           controller decrypts to K8s Secret in-cluster

External Secrets          External Secrets  Reference to secret location in Git
Operator                  Operator (ESO)    (AWS Secrets Manager ARN, Vault path);
                                           ESO fetches and creates K8s Secret in-cluster

AWS Secrets Manager +     IRSA + ESO        Pod uses IAM role to access Secrets Manager;
IRSA                                        no secret values ever stored anywhere in Git

Vault Agent Sidecar       HashiCorp Vault   Vault agent sidecar injects secrets into
                                           pod's filesystem at runtime; Git has only
                                           the Vault path reference

SOPS                      Mozilla SOPS      Encrypt values in YAML with AWS KMS or GPG;
                                           store encrypted YAML in Git; ArgoCD plugin
                                           decrypts at sync time

BAD (never do this):
  Plain text Secret in Git   N/A            Anyone with repo read access has all secrets
  Base64 in Git              N/A            Base64 is NOT encryption; it is encoding
──────────────────────────────────────────────────────────────────────────────────────

Detecting secrets in Git (run in CI to prevent accidental commits):
  trufflehog git <repo-url>
  gitleaks detect --source . --verbose
```

---

## Part 7 — Multi-Cluster GitOps Troubleshooting

```
In multi-cluster setups, an ArgoCD in cluster-A deploys to cluster-B.
Additional failure modes appear beyond single-cluster:

Failure 1: External cluster unreachable
  Signal: App targeting external cluster shows "cluster unreachable"
  Check: argocd cluster list → shows connection status per cluster
  Causes:
    - API server IP changed (EKS control plane update)
    - Kubeconfig/ServiceAccount token expired
    - Network policy blocking ArgoCD → cluster API server

  Fix:
    argocd cluster rm https://<old-cluster-url>
    argocd cluster add <new-context-name>
    → Re-registers the cluster with fresh credentials

Failure 2: Cross-cluster RBAC gap
  Signal: SyncFailed with "forbidden" on the target cluster
  Cause: ArgoCD's ServiceAccount in cluster-A has no ClusterRole in cluster-B
  Fix: re-run argocd cluster add (which creates the ServiceAccount and ClusterRole
       in the target cluster) → confirm with:
       kubectl get clusterrolebinding argocd-manager-role-binding --context <cluster-B>

Failure 3: App deployed to wrong cluster
  Signal: Resource exists in cluster-A but Git says cluster-B
  Cause: Wrong destination.server in the Application spec
  Fix in Git: correct destination.server URL → sync
  Prevention: use ArgoCD Projects to restrict which clusters apps can target

Failure 4: Clock skew causing token expiry
  Signal: "token has expired" errors in repo-server or controller logs
  Cause: Node time drifted; OIDC/JWT tokens appear expired
  Fix: verify NTP on nodes → kubectl debug node/<node> -- chronyc tracking
```

---

## Common Mistakes and Correct Approaches

| Mistake | What Goes Wrong | Correct Approach |
|---|---|---|
| Syncing without reading the diff | Unexpected deletion (PRUNE) wipes a ConfigMap that wasn't in Git | Always open Diff view before syncing a resource you didn't just add to Git |
| Fixing cluster resources directly instead of in Git | Self-heal reverts the fix within 3 minutes; incident repeats | Fix in Git first; push; let ArgoCD sync the fix to the cluster |
| Using `:latest` image tag | ArgoCD sees no diff (same tag); new image is never deployed | Pin image tag to a SHA or semantic version; ArgoCD detects the change |
| Storing secrets in Git base64-encoded | "It's encoded not plain text" — false. Base64 is readable. Repo leak = all secrets leaked | Use Sealed Secrets or External Secrets Operator; never store any secret value in Git |
| Not setting PRUNE=true | Deleted manifests leave ghost Services and Deployments; future deploys hit naming conflicts | Always enable PRUNE; resources removed from Git should be removed from the cluster |
| Setting ignoreDifferences for replicas but not RespectIgnoreDifferences | ArgoCD still resets replicas to Git value on every sync; HPA is constantly overridden | Add both ignoreDifferences AND `RespectIgnoreDifferences=true` syncOption |
| Auto-sync enabled on prod Tier-1 services | Any Git push deploys to production without human review | Tier-1: Manual sync policy; human must click SYNC after reviewing diff |
| Not configuring Git webhooks | ArgoCD polls Git every 3 minutes; deploy lag is up to 3 minutes | Register a webhook in GitHub → ArgoCD to trigger instant refresh on push |
| Leaving failed hook Jobs in the namespace | Next sync sees the old failed Job; conflicts with recreation; sync fails again | Set hook-delete-policy: HookFailed to auto-clean failed Jobs |
| App of Apps parent not in Git | Child apps are created via the parent; if parent is deleted, children are orphaned | Store the root/parent Application manifest in Git; bootstrap it once manually |
