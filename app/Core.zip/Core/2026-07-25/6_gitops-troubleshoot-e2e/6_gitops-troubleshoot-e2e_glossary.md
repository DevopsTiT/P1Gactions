# GitOps Troubleshoot — Glossary

Every term, tool, and concept from the troubleshoot guide explained for an SRE beginner.

---

**GitOps**
An operational model where the desired state of Kubernetes infrastructure is stored in Git, and automated tooling continuously reconciles the live cluster to match. Changes are made by Git commits — not `kubectl apply`. ArgoCD is the most common GitOps tool for Kubernetes.

**ArgoCD**
A Kubernetes-native continuous delivery controller that watches a Git repository and keeps the cluster in sync with it. Runs inside Kubernetes itself. Core components: Application Controller (reconciles state), Repo Server (clones Git), ArgoCD Server (UI/API).

**Application (ArgoCD)**
An ArgoCD custom resource (`kind: Application`) that pairs a Git source (repo + path + revision) with a Kubernetes destination (cluster + namespace). It is the unit of deployment in ArgoCD — one Application per deployed service (usually).

**Sync**
The act of ArgoCD applying the manifests from Git to the Kubernetes cluster. A sync makes the cluster match Git. Triggered manually (click SYNC) or automatically (auto-sync policy). Equivalent to `kubectl apply -f <all-files-in-git-path>`.

**Sync Status**
Whether the live Kubernetes cluster currently matches the Git state. `Synced` = they match. `OutOfSync` = they differ. `SyncFailed` = ArgoCD tried to sync but Kubernetes rejected the manifests.

**Health Status**
Whether the deployed application is actually running. `Healthy` = all pods Running and ready. `Degraded` = pods crashing. `Progressing` = rollout in progress. `Missing` = resource is in Git but not in the cluster. Independent of Sync Status — you can be `Synced` but `Degraded`.

**OutOfSync**
Git and the cluster disagree. Caused by: a new Git commit not yet applied (expected), someone `kubectl edit`ing a resource directly (config drift), or a controller adding fields ArgoCD didn't set (false positive).

**SyncFailed**
ArgoCD attempted to apply manifests from Git but Kubernetes rejected them. The cluster was NOT changed. The error message in the app detail explains why (namespace missing, RBAC blocked, immutable field, hook failed, etc.).

**Degraded**
A Health Status: ArgoCD successfully applied the manifests, but the pods are not running. Caused by: CrashLoopBackOff, OOMKilled, ImagePullBackOff, Pending (no available nodes), or a failing readiness probe.

**Progressing**
A Health Status meaning a rollout is currently in progress (pods are restarting with new config). Expected during a sync. If it never resolves to `Healthy`, the new pods are failing to start.

**Config drift**
The state where a Kubernetes resource was manually edited (via `kubectl edit` or `kubectl patch`) without a corresponding Git commit. ArgoCD detects this as `OutOfSync` with no recent Git push. The GitOps equivalent of infrastructure drift.

**Self-heal**
An ArgoCD sync policy setting (`selfHeal: true`) that automatically reverts manual cluster changes back to the Git state within seconds of detection. Enforces GitOps compliance. When enabled, `kubectl edit` on a managed resource is immediately overwritten.

**PRUNE**
An ArgoCD sync option that deletes Kubernetes resources present in the cluster but absent from Git. Without PRUNE, resources you remove from Git stay in the cluster forever — accumulating ghost Deployments, Services, and ConfigMaps.

**Auto-sync**
An ArgoCD sync policy setting (`automated: {}`) that triggers a sync automatically when ArgoCD detects a new Git commit. No human has to click SYNC. Combined with self-heal and prune for full GitOps automation.

**ignoreDifferences**
An ArgoCD Application field that tells ArgoCD to ignore specific YAML fields when comparing Git vs cluster. Used when Kubernetes controllers (HPA, Istio, cert-manager) mutate resources after ArgoCD applies them, causing perpetual false `OutOfSync` status.

**RespectIgnoreDifferences**
A sync option (`syncOptions: - RespectIgnoreDifferences=true`) that tells ArgoCD not to overwrite ignored fields during a sync. Required alongside `ignoreDifferences` for HPA-managed replicas — otherwise ArgoCD resets replicas to the Git value on every sync.

**Application Controller**
The ArgoCD component (a Kubernetes Deployment) that continuously watches Application resources, compares Git state to cluster state, and triggers syncs. If this pod is down: no auto-syncs, no health updates, no diff detection.

**Repo Server**
The ArgoCD component that clones the Git repositories tracked by Applications, runs Helm/Kustomize rendering, and returns the final Kubernetes manifests. If this pod is down: all syncs fail with "repo server unavailable."

**ArgoCD Server**
The ArgoCD component serving the web UI and the gRPC/REST API. If this pod is down: the UI is inaccessible and the `argocd` CLI cannot connect — but existing auto-syncs may still run (Application Controller is separate).

**argocd-notifications-controller**
An ArgoCD component that sends notifications (Slack, webhook, email) when app sync events occur. Separate from the main controller — notifications failing does not stop syncs.

**Webhook (Git → ArgoCD)**
A POST request sent from GitHub/GitLab to ArgoCD immediately when a branch is pushed. Triggers an instant repo refresh instead of waiting up to 3 minutes for the polling cycle. Required for fast deploys (< 30 second detect-to-sync latency).

**Reconciliation**
The continuous loop where ArgoCD compares the desired state (Git) with the actual state (cluster) and decides whether a sync is needed. Runs every 3 minutes by polling, or immediately on a webhook push.

**ArgoCD Project**
A grouping object that restricts what Applications in the group can do: which Git repos they can source from, which clusters and namespaces they can deploy to, and which Kubernetes resource types they can manage. The main RBAC mechanism in ArgoCD.

**App of Apps**
An ArgoCD pattern where a parent Application's Git path contains ArgoCD Application manifests (not workload manifests). The parent app deploys child apps automatically. Used to manage many services declaratively from one Git commit.

**Sync Hook**
A Kubernetes Job annotated with `argocd.argoproj.io/hook: PreSync|PostSync|SyncFail` that ArgoCD runs at specific points in the sync lifecycle. Common use: database migration (PreSync), smoke test (PostSync). If a hook Job fails, the sync is marked `SyncFailed`.

**hook-delete-policy**
An annotation on hook Jobs (`argocd.argoproj.io/hook-delete-policy`) controlling when ArgoCD deletes the Job after it runs. `HookSucceeded` deletes on success; `HookFailed` deletes on failure; `BeforeHookCreation` deletes before the next run. Without this, failed Jobs accumulate and block future syncs.

**ServerSideApply**
A Kubernetes feature (and ArgoCD sync option) where the API server handles merge conflicts server-side instead of client-side. Prevents the "resource already exists" 409 conflict when ArgoCD tries to apply a resource that another system partially manages.

**Immutable field**
A Kubernetes resource field that cannot be changed after the resource is created. Examples: `spec.selector` on a Deployment, `spec.storageClassName` on a PVC. Changing an immutable field requires deleting the resource and recreating it — ArgoCD cannot update it in place.

**Sealed Secrets**
A Kubernetes-native secret encryption tool by Bitnami. Encrypts a Secret into a `SealedSecret` resource using a cluster-specific keypair. The `SealedSecret` YAML is safe to store in Git; the controller decrypts it to a regular K8s Secret inside the cluster.

**External Secrets Operator (ESO)**
A Kubernetes operator that reads secret references (AWS Secrets Manager ARN, HashiCorp Vault path) from Git and fetches the actual secret values at runtime, creating K8s Secrets in the cluster. Secret values never touch Git.

**IRSA (IAM Roles for Service Accounts)**
AWS mechanism that lets a Kubernetes pod assume an IAM role via a Kubernetes ServiceAccount annotation. Used with ESO to give the operator permission to read from AWS Secrets Manager without storing any AWS credentials in Git or the cluster.

**SOPS (Secrets OPerationS)**
A Mozilla tool that encrypts specific values in YAML/JSON files using AWS KMS, GCP KMS, or GPG. The encrypted YAML is stored in Git; an ArgoCD plugin (helm-secrets or argocd-vault-plugin) decrypts at sync time. Values are never in plaintext in the repo.

**trufflehog / gitleaks**
Open-source secret-scanning tools that scan Git history for accidentally committed secrets (API keys, tokens, passwords). Run in CI pipelines to block commits containing credential patterns before they reach the default branch.

**CrashLoopBackOff**
A Kubernetes pod state where the container crashes on startup and Kubernetes retries with increasing delays. The word "BackOff" means the retry interval grows: 10s, 20s, 40s, up to 5 minutes. Diagnosed by reading the PREVIOUS container's logs (not the current one, which just started).

**OOMKilled**
"Out Of Memory Killed" — the Linux kernel killed the container because it exceeded its `resources.limits.memory`. The pod restarts and the termination reason appears as `OOMKilled` in `kubectl describe pod`. Fix: increase the memory limit in the manifest in Git.

**ImagePullBackOff**
A Kubernetes pod state where the container image cannot be pulled from the registry. Causes: image tag does not exist, registry credentials not configured, network unreachable. Check with `kubectl describe pod` → Events section.

**Pending (pod)**
A Kubernetes pod that has been accepted by the API server but not yet scheduled to a node. The scheduler cannot find a suitable node. Causes: insufficient CPU/memory, taint/toleration mismatch, node selector with no matching node, PVC not bound.

**`kubectl auth can-i`**
A kubectl command that checks whether a specific user or ServiceAccount has permission to perform an action. Used to diagnose ArgoCD RBAC errors: `kubectl auth can-i create deployments --as=system:serviceaccount:argocd:argocd-application-controller -n <namespace>`.

**`argocd app diff`**
An ArgoCD CLI command that prints the diff between the Git desired state and the live cluster state for an Application. The terminal equivalent of the ArgoCD UI diff view. Useful for CI/CD pre-sync checks.

**`argocd app sync`**
An ArgoCD CLI command that triggers a sync for a named Application. Accepts flags: `--dry-run` (simulate), `--prune` (delete removed resources), `--force` (force apply on conflict), `--revision` (sync specific SHA/tag).

**`argocd app rollback`**
An ArgoCD CLI command that reverts an Application to a previous sync revision. Takes a revision ID from `argocd app history`. Rolls back by re-applying the manifests from the specified Git SHA.

**`argocd repo list`**
An ArgoCD CLI command that lists all connected Git repositories and their connection status (Successful / Failed). The first check when syncs fail with "repository not found" errors.

**`argocd cluster list`**
An ArgoCD CLI command that lists all registered Kubernetes clusters and their connection status. In multi-cluster setups, shows which clusters ArgoCD can deploy to and flags any with connection errors.

**Deploy Key (GitHub)**
An SSH public key added to a specific GitHub repository that grants read (or write) access. Used by ArgoCD's SSH-based repository connection so it can clone private repos. Scoped to one repo — more secure than a personal access token with broad access.

**Personal Access Token (PAT)**
A GitHub credential used for HTTPS Git operations. Required when connecting a private repo to ArgoCD via HTTPS. Should be scoped to `repo:read` only for ArgoCD. Stored in a Kubernetes Secret in the `argocd` namespace; must be rotated before expiry.

**`kubectl rollout restart`**
A kubectl command that performs a rolling restart of all pods in a Deployment without changing any configuration. Used to recover ArgoCD components without downtime: `kubectl rollout restart deployment/argocd-application-controller -n argocd`.

**Kubernetes audit log**
A log of every API server request, including who made it (`user`), what they did (`verb`: create/patch/delete), and on which resource. Required to detect manual `kubectl edit` changes that caused config drift. On EKS, shipped to CloudWatch Logs.

**CloudWatch Logs (EKS audit)**
AWS CloudWatch log group `/aws/eks/<cluster>/cluster` that receives Kubernetes audit logs when audit logging is enabled on EKS. Used to find which user made a direct `kubectl patch` or `kubectl edit` on a managed resource, bypassing GitOps.
