# EKS Best Practices Parts — Glossary

**EKS (Elastic Kubernetes Service)**
AWS's managed Kubernetes service where AWS runs and maintains the control plane (API server, etcd, scheduler, controller-manager). You manage worker nodes and your workloads. You pay for control plane uptime plus the EC2 instances running pods.

**Control Plane**
The Kubernetes brain: the API server receives kubectl commands; etcd stores all cluster state; the scheduler decides which node to place each pod on; the controller-manager runs reconciliation loops. In EKS, AWS operates these and you cannot access them directly.

**Worker Node**
An EC2 instance that runs pods. Each node runs kubelet (registers the node with the API server), kube-proxy (manages network rules), and the VPC CNI plugin (assigns pod IPs). You own and manage these in EKS.

**VPC CIDR**
The IP address range for your Virtual Private Cloud. In EKS, pods get real VPC IP addresses (not NAT), so the VPC and subnet CIDRs must be large enough to hold all pods across all nodes. A /16 VPC (65,536 IPs) with /22 subnets (1,022 IPs each) is the recommended minimum.

**VPC CNI (Virtual Private Cloud Container Network Interface)**
An AWS-developed CNI plugin that assigns real VPC IP addresses directly to Kubernetes pods. Runs as the `aws-node` DaemonSet on every node. Each pod gets a routable IP from the VPC subnet — pods are visible to other AWS resources like RDS and ElastiCache without any NAT.

**ENI (Elastic Network Interface)**
A virtual network card that can be attached to an EC2 instance. VPC CNI attaches multiple ENIs to each node and uses their secondary IP addresses to assign IPs to pods. The maximum pods per node is determined by the number of ENIs and IPs per ENI for that instance type.

**Prefix Delegation**
A VPC CNI mode that assigns a /28 IP prefix (16 addresses) to each ENI slot instead of a single IP address. This dramatically increases the number of pods a single node can run — a node that supports 56 pods normally can support 240+ with prefix delegation.

**IP Exhaustion**
A condition where a VPC subnet has no more available IP addresses to assign to new pods. Pods fail with errors like "failed to set up sandbox container network." Prevented by using large private subnets (/22 or larger) and/or enabling prefix delegation.

**Private Endpoint (EKS)**
An EKS cluster configuration where the Kubernetes API server is only accessible from within the VPC. Engineers must use VPN or Direct Connect to run kubectl. Prevents the API server from being reachable from the internet.

**Public Endpoint (EKS)**
An EKS cluster configuration where the API server has a public DNS name. Should be restricted to known IP CIDRs (office, VPN exit nodes) — never open to 0.0.0.0/0 in production.

**NAT Gateway**
An AWS service that allows private subnet resources (nodes, pods) to make outbound internet connections (for image pulls, AWS API calls) without having a public IP themselves. Inbound connections from the internet are blocked. One NAT Gateway per AZ is the HA pattern.

**VPC Endpoint**
A private network connection between your VPC and AWS services that doesn't leave the AWS network. Allows pods to call S3, Secrets Manager, ECR, etc. without going through the internet or NAT Gateway. Faster, cheaper, and more secure than internet routing.

**Managed Node Group**
An AWS-managed collection of EC2 instances (an Auto Scaling Group) where AWS handles node provisioning, AMI updates, and graceful draining before termination. The recommended approach for most production workloads.

**Launch Template**
An EC2 launch template specifying node configuration: AMI, instance type, EBS volume size, IMDSv2 settings, and security options. Required for production node groups to ensure consistent, secure node configuration.

**AL2023 (Amazon Linux 2023)**
The recommended operating system for EKS worker nodes. An EKS-optimised version includes the correct kubelet, containerd, and kernel configuration for running Kubernetes. More secure and updated than the previous Amazon Linux 2.

**IMDSv2 (Instance Metadata Service version 2)**
A security enhancement for the EC2 instance metadata service that requires a session token before returning credentials. Prevents SSRF attacks from reaching the metadata service to steal the node's IAM role credentials. Required for all EKS nodes in production.

**hop limit**
An HTTP header field that limits how many network hops a request can make. Setting `http_put_response_hop_limit = 1` on EKS nodes means only the node itself can reach the IMDS — containers cannot, which blocks SSRF-based credential theft.

**SSRF (Server-Side Request Forgery)**
A web attack where malicious input causes a server to make HTTP requests to internal addresses. Against IMDSv1, an SSRF attack could fetch `http://169.254.169.254/latest/meta-data/iam/security-credentials/` to steal IAM credentials. IMDSv2 blocks this.

**Spot Instance**
An EC2 instance using spare AWS capacity at up to 90% discount. AWS can reclaim it with a 2-minute warning (Spot interruption). Use for stateless workloads that can be rescheduled. Requires an interruption handler to drain nodes gracefully.

**Spot Interruption**
An AWS event where EC2 reclaims a Spot instance, given with 2 minutes notice. The AWS Node Termination Handler or Karpenter intercepts this notice and drains the node before termination, allowing pods to reschedule gracefully.

**IRSA (IAM Roles for Service Accounts)**
An EKS feature that associates an IAM role with a Kubernetes ServiceAccount. Pods using that ServiceAccount receive temporary, automatically rotated AWS credentials scoped to only that role. The correct way to give pods AWS API access — no static credentials needed.

**OIDC Provider (IAM)**
An AWS IAM identity provider that enables EKS's OIDC endpoint to issue tokens that AWS can verify. Required for IRSA: it creates a trust relationship between Kubernetes ServiceAccount tokens and AWS IAM roles.

**Trust Policy (IAM)**
The JSON policy attached to an IAM role that defines who can assume it. For IRSA: the trust policy uses `StringEquals` to restrict assumption to a specific Kubernetes ServiceAccount in a specific namespace — preventing other ServiceAccounts from assuming the role.

**aws-auth ConfigMap**
A Kubernetes ConfigMap in the kube-system namespace that maps AWS IAM roles and users to Kubernetes usernames and groups. The mechanism that allows `kubectl` users (identified by IAM) to be given Kubernetes RBAC permissions.

**RBAC (Role-Based Access Control)**
Kubernetes's permission system. Roles define what actions are allowed on what resources. RoleBindings assign Roles to users or groups. ClusterRoles/ClusterRoleBindings operate cluster-wide. No developer should have `cluster-admin` access.

**cluster-admin**
A Kubernetes ClusterRole that grants unrestricted access to all resources in all namespaces. The equivalent of root. Never grant to developers — they should have namespace-scoped read-only access.

**Pod Security Standards (PSS)**
Kubernetes's built-in security policy mechanism (replaces PodSecurityPolicy). Applied as labels on namespaces. `restricted` = strictest (no root, no privileged, no host namespaces). `baseline` = moderate. `privileged` = no restrictions.

**securityContext**
A Kubernetes spec section that defines security settings for a pod or container: which user to run as, whether to allow privilege escalation, whether the root filesystem is read-only, and which Linux capabilities to drop.

**allowPrivilegeEscalation**
A container security setting. When `false`, the container process cannot gain more privileges than its parent — blocking setuid binaries and sudo. Set to `false` in all production containers.

**readOnlyRootFilesystem**
A container security setting that makes the container's root filesystem read-only. Prevents malware from writing to the container filesystem. Requires using `emptyDir` volumes for any writable paths (tmp, cache).

**GuardDuty EKS Protection**
A GuardDuty feature that analyses EKS audit logs and (with runtime monitoring) in-container behaviour. Detects: privilege escalation, crypto mining, suspicious network connections, `kubectl exec` into production pods, and IAM credential misuse.

**Resource Requests**
The CPU and memory a container is guaranteed to receive. The Kubernetes scheduler uses requests to decide if a node has capacity for a pod. Without requests, the scheduler has no data and may overcommit nodes.

**Resource Limits**
The maximum CPU and memory a container can use. Memory: exceeding the limit causes an OOMKill. CPU: exceeding the limit causes throttling (slowdown, not kill). Both must be set on every production container.

**QoS Class**
Kubernetes categorises pods based on resource settings. `Guaranteed` (requests = limits) = highest eviction priority — last to be evicted. `Burstable` (requests < limits) = medium. `BestEffort` (no requests/limits) = first to be evicted under pressure.

**LimitRange**
A Kubernetes namespace-level object that sets default and maximum resource requests/limits. Automatically applies defaults to containers that don't specify their own. Prevents containers with no resource settings from being admitted to the namespace.

**ResourceQuota**
A Kubernetes namespace-level object that caps the total CPU, memory, and number of objects that can be created in a namespace. Prevents one team from consuming all cluster resources.

**Liveness Probe**
A Kubernetes health check that kills and restarts a container if it fails N times. Used to detect deadlocks or unrecoverable states. Should only check if the process is responsive — never check external dependencies (DB, Redis).

**Readiness Probe**
A Kubernetes health check that removes a pod from Service endpoints if it fails. The container is not restarted — just taken out of load balancing rotation. Used to signal when a pod is ready to handle traffic.

**Startup Probe**
A Kubernetes health check that prevents the liveness probe from firing during application startup. Once the startup probe succeeds, it is disabled and liveness/readiness take over. Required for any app with startup time > 30 seconds.

**initialDelaySeconds**
The time Kubernetes waits after a container starts before running the first probe check. If set too short, the liveness probe fires before the app has finished starting up and kills the pod repeatedly.

**PodDisruptionBudget (PDB)**
A Kubernetes policy that limits how many pods can be unavailable simultaneously during voluntary disruptions (node drain, rolling update, Cluster Autoscaler scale-down). `minAvailable: 1` guarantees at least one pod is always running.

**Voluntary Disruption**
A planned pod eviction: node drain for maintenance, Cluster Autoscaler removing an underutilised node, a rolling deployment updating pods. PDBs protect against these. Contrast with involuntary disruption (node failure, OOMKill) which PDBs do not protect against.

**Topology Spread Constraints**
Pod scheduling rules that distribute pods evenly across topology domains (AZs, nodes) to maximise availability. `maxSkew: 1` across AZs ensures an AZ failure only takes down a fraction of capacity, not all replicas.

**maxSkew**
The maximum allowed difference in pod count between any two topology zones. `maxSkew: 1` means one zone can have at most 1 more pod than another. Lower values = more even distribution = better AZ resilience.

**DoNotSchedule**
A topology spread constraint mode where the Kubernetes scheduler refuses to place a pod if doing so would violate the `maxSkew` constraint. The pod waits (Pending) until it can be placed without violating the spread rule.

**HPA (Horizontal Pod Autoscaler)**
A Kubernetes resource that automatically adjusts the number of pod replicas based on observed metrics (CPU, memory, or custom metrics). Requires `minReplicas`, `maxReplicas`, and one or more metric targets.

**KEDA (Kubernetes Event-Driven Autoscaling)**
An open-source Kubernetes add-on that enables HPA scaling based on external event sources: SQS queue depth, Kafka consumer lag, Prometheus metrics, database row count, etc. Extends HPA beyond built-in CPU/memory scaling.

**Cluster Autoscaler (CA)**
A Kubernetes add-on that automatically adjusts the number of nodes by modifying Auto Scaling Group desired counts. Scales up when pods are Pending (insufficient resources); scales down when nodes are underutilised.

**balance-similar-node-groups**
A Cluster Autoscaler configuration that distributes new nodes evenly across multiple similar node groups (and their AZs) when scaling up. Without this, CA may add all new nodes to a single AZ.

**Karpenter**
An open-source Kubernetes node provisioner that directly launches EC2 instances (no ASG required) matched exactly to pending pod requirements. Faster than Cluster Autoscaler, better bin-packing, and supports automatic node consolidation.

**NodePool (Karpenter)**
A Karpenter resource that defines the requirements for nodes Karpenter can provision: instance types, capacity type (Spot/on-demand), architecture, and disruption policy. Replaces the CA node group discovery model.

**EC2NodeClass (Karpenter)**
A Karpenter resource that defines EC2-specific configuration for Karpenter-provisioned nodes: AMI family, IAM role, subnet and security group selectors, and EBS volume configuration.

**Consolidation (Karpenter)**
A Karpenter feature that replaces multiple underutilised nodes with fewer, more efficiently utilised nodes. For example, replacing 5 underutilised m5.xlarge nodes with 2 well-utilised m5.2xlarge nodes — reducing cost while maintaining capacity.

**expireAfter (Karpenter NodePool)**
A Karpenter NodePool setting that forces nodes to be replaced after a specified duration. Used to ensure nodes are periodically rotated to fresh AMIs with the latest security patches — without any manual intervention.

**CoreDNS**
The cluster-internal DNS server. Resolves Kubernetes service names to ClusterIPs. Runs as a Deployment in kube-system. Must be scaled up for large clusters; a failed CoreDNS causes all service-name-based communication to fail.

**ndots**
A DNS resolver option that controls how many dots must appear in a name before treating it as fully qualified. Kubernetes default is 5, causing 4 extra failed DNS lookups for every external name. Reducing to 2 significantly decreases DNS traffic.

**NodeLocal DNSCache**
A DaemonSet that runs a DNS cache on every node. Pods query the local cache (no network hop) for known names. Only cache misses go to CoreDNS, reducing CoreDNS load by 70-90% and eliminating conntrack table pressure from DNS UDP traffic.

**conntrack table**
A Linux kernel table that tracks network connections for stateful packet inspection. Every DNS UDP query creates a conntrack entry. In busy clusters, the conntrack table can fill up, causing DNS resolution failures cluster-wide.

**Container Insights**
An AWS CloudWatch feature that collects and visualises metrics from EKS clusters at node, pod, container, and cluster levels. Deployed via the `amazon-cloudwatch-observability` add-on.

**Fluent Bit**
A lightweight log shipper that runs as a DaemonSet on each node. Reads container logs from disk (stdout/stderr), parses JSON fields, and forwards them to CloudWatch Logs, S3, Loki, or other backends.

**Structured Logging**
The practice of formatting application log output as JSON with consistent field names (timestamp, level, message, traceId). Enables filtering by field value in CloudWatch Log Insights, Grafana Loki, and other log analysis tools.

**CloudWatch Log Insights**
An AWS service for querying CloudWatch log data using a SQL-like syntax. Enables filtering logs by field value, aggregating error counts, and joining across log groups — powerful for incident investigation.

**kubent (kube-no-trouble)**
An open-source tool that scans a Kubernetes cluster for deprecated or removed API versions in use. Run before every EKS version upgrade to find manifests that must be updated before the API version is removed.

**Version Skew**
The difference in Kubernetes minor version between components. The kubelet (node) must be within 2 minor versions of the API server; kubectl must be within 1 minor version. In EKS: always upgrade the control plane first, then add-ons, then nodes.

**Admission Webhook**
A Kubernetes API server extension that intercepts resource creation/modification requests. Mutating webhooks can modify the resource (e.g. inject sidecars). Validating webhooks can reject non-compliant resources (e.g. OPA/Gatekeeper policy violations).

**aws-iam-authenticator**
The component that authenticates AWS IAM identities (roles, users) to the Kubernetes API server. It validates the AWS SigV4-signed token in `kubectl` requests and maps the IAM identity to a Kubernetes username via the `aws-auth` ConfigMap.

**SSM Session Manager**
An AWS Systems Manager feature that provides interactive shell access to EC2 instances without opening port 22 or managing SSH keys. The recommended way to access EKS worker nodes for debugging. Session activity is logged to CloudWatch.
