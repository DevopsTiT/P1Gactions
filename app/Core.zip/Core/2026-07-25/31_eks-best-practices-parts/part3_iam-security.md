# EKS Best Practices — Part 3: IAM and Security — IRSA, RBAC, Pod Security

> **Security in EKS has four layers: how pods authenticate to AWS (IRSA), how humans authenticate to Kubernetes (aws-auth + RBAC), what pods are allowed to do inside the cluster (Pod Security Standards), and how the cluster itself is hardened.**

---

## IRSA: The Only Correct Way to Give Pods AWS Access

### Why Static Credentials Are Dangerous

```
WRONG approach #1: Mount AWS credentials as environment variables
  env:
    - name: AWS_ACCESS_KEY_ID
      value: "AKIAIOSFODNN7EXAMPLE"
    - name: AWS_SECRET_ACCESS_KEY
      value: "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"

  Problems:
    → Static keys: if leaked, valid until manually rotated
    → Visible in kubernetes secret, pod spec, and deployment YAML
    → A compromised pod = permanent access to AWS until key is manually revoked
    → Key rotation requires updating deployments and triggering restarts

WRONG approach #2: Use the node's instance profile for application pods
  Every pod on the node shares the node's IAM role.
  
  Problems:
    → A compromised pod in the payments namespace can call:
        aws s3 cp s3://hr-data-bucket/employees.csv .   ← full HR data
    → The node IAM role has permissions for ALL workloads on that node
    → No audit trail: CloudTrail shows the instance ID, not the pod name

CORRECT approach: IRSA (IAM Roles for Service Accounts)
  → Each ServiceAccount gets its own IAM role
  → Pods get temporary, auto-rotated credentials (15-minute lifetime)
  → Credentials are scoped ONLY to that ServiceAccount's IAM role
  → CloudTrail shows: assumed by payments-api ServiceAccount in namespace payments
```

### IRSA Setup: Step by Step

```bash
# Step 1: Create the IAM OIDC provider for the cluster
# (Required once per cluster; maps the EKS OIDC issuer to an AWS identity provider)
eksctl utils associate-iam-oidc-provider \
  --cluster prod-eks \
  --region ap-northeast-1 \
  --approve

# OR via Terraform:
# data "aws_eks_cluster" "main" { name = "prod-eks" }
# resource "aws_iam_openid_connect_provider" "eks" {
#   url             = data.aws_eks_cluster.main.identity[0].oidc[0].issuer
#   client_id_list  = ["sts.amazonaws.com"]
#   thumbprint_list = [data.tls_certificate.eks.certificates[0].sha1_fingerprint]
# }

# Step 2: Get the OIDC issuer URL for the trust policy
OIDC_ISSUER=$(aws eks describe-cluster \
  --name prod-eks \
  --query 'cluster.identity.oidc.issuer' \
  --output text | sed 's|https://||')
echo "OIDC Issuer: $OIDC_ISSUER"
```

### IAM Role Trust Policy for IRSA

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::123456789012:oidc-provider/oidc.eks.ap-northeast-1.amazonaws.com/id/EXAMPLED539D4633E53DE1B71EXAMPLE"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "oidc.eks.ap-northeast-1.amazonaws.com/id/EXAMPLED539D4633E53DE1B71EXAMPLE:sub":
            "system:serviceaccount:payments:payments-api",
          "oidc.eks.ap-northeast-1.amazonaws.com/id/EXAMPLED539D4633E53DE1B71EXAMPLE:aud":
            "sts.amazonaws.com"
        }
      }
    }
  ]
}
```

**Key elements of the trust policy:**
- `Federated`: the OIDC provider ARN for this specific EKS cluster
- `sub` condition: scoped to exactly one ServiceAccount (`namespace:name`)
- `StringEquals` (not `StringLike`): exact match prevents privilege escalation via wildcard

### ServiceAccount Annotation

```yaml
# serviceaccount.yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: payments-api
  namespace: payments
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::123456789012:role/payments-api-role
    eks.amazonaws.com/token-expiration: "3600"   # token lifetime in seconds (optional; default 86400)
```

### Deployment Using the ServiceAccount

```yaml
# deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: payments-api
  namespace: payments
spec:
  template:
    spec:
      serviceAccountName: payments-api   # ← links to the IRSA annotation
      containers:
        - name: api
          image: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payments-api:v2.3.1
          # The pod automatically gets AWS_ROLE_ARN and AWS_WEB_IDENTITY_TOKEN_FILE env vars
          # The AWS SDK reads these automatically — no code changes needed
```

---

## IAM Role Scoping: Least Privilege

```
Rule: every IRSA role MUST have the MINIMUM permissions needed for that specific workload.

❌ Bad (wildcard permissions):
  Effect: Allow
  Action: s3:*
  Resource: "*"
  → This pod can read, write, delete ANY S3 bucket in the account
  → A compromised pod = total S3 access

✅ Good (scoped permissions):
  Effect: Allow
  Action:
    - s3:GetObject
    - s3:PutObject
  Resource:
    - arn:aws:s3:::payments-data-bucket/*
  → This pod can only read/write objects in one specific bucket
  → A compromised pod = only payments-data-bucket access

How to audit IRSA roles:
  # List all IAM roles that have EKS-related trust policies
  aws iam list-roles \
    --query 'Roles[?contains(AssumeRolePolicyDocument.Statement[].Principal.Federated, `oidc`)].[RoleName]' \
    --output text

  # Check a specific role's inline policies
  aws iam list-role-policies --role-name payments-api-role
  aws iam get-role-policy \
    --role-name payments-api-role \
    --policy-name inline-policy

  # Use IAM Access Analyzer to find roles with overly permissive policies
  aws accessanalyzer list-findings \
    --analyzer-arn arn:aws:access-analyzer:ap-northeast-1:123456789012:analyzer/default
```

---

## Kubernetes RBAC for Teams

### Principle of Least Privilege in Kubernetes

```
WRONG:
  ClusterRoleBinding: developer → cluster-admin
  → Developer can delete any resource in any namespace
  → Developer can modify RBAC itself
  → Developer can read secrets from ALL namespaces (including production passwords)

CORRECT:
  RoleBinding: developer → read-only Role → specific namespace only
  → Developer can get/list/watch pods, deployments, services in their namespace
  → Developer can read logs and exec into pods (for debugging)
  → Developer cannot delete, modify, or access other teams' namespaces
```

### Namespace-Scoped Role for Developers

```yaml
# rbac-role.yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  namespace: payments
  name: payments-developer
rules:
  # Read-only access to most resources
  - apiGroups: ["", "apps", "batch", "autoscaling"]
    resources:
      - pods
      - deployments
      - replicasets
      - services
      - configmaps
      - jobs
      - cronjobs
      - horizontalpodautoscalers
    verbs: ["get", "list", "watch"]

  # Log access and exec for debugging
  - apiGroups: [""]
    resources:
      - pods/log
      - pods/exec
      - pods/portforward
    verbs: ["get", "create"]

  # Read events (useful for debugging scheduling issues)
  - apiGroups: [""]
    resources: ["events"]
    verbs: ["get", "list", "watch"]

  # No access to: Secrets, ServiceAccounts, RBAC objects, NetworkPolicies
```

```yaml
# rbac-binding.yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: payments-developer-binding
  namespace: payments
subjects:
  - kind: Group
    name: payments-team         # IAM Identity Center group name
    apiGroup: rbac.authorization.k8s.io
roleRef:
  kind: Role
  name: payments-developer
  apiGroup: rbac.authorization.k8s.io
```

### aws-auth ConfigMap: Mapping IAM to Kubernetes

```yaml
# aws-auth ConfigMap (in kube-system namespace)
# Maps IAM roles and users to Kubernetes usernames and groups

apiVersion: v1
kind: ConfigMap
metadata:
  name: aws-auth
  namespace: kube-system
data:
  mapRoles: |
    # Platform SRE team: admin access to all namespaces
    - rolearn: arn:aws:iam::123456789012:role/PlatformSRERole
      username: platform-sre
      groups:
        - system:masters   # cluster-admin equivalent

    # Payments team: developer access to payments namespace only
    - rolearn: arn:aws:iam::123456789012:role/PaymentsDeveloperRole
      username: payments-developer
      groups:
        - payments-team   # maps to the RoleBinding subject above

    # Karpenter node role: allows nodes to join the cluster
    - rolearn: arn:aws:iam::123456789012:role/KarpenterNodeRole-prod-eks
      username: system:node:{{EC2PrivateDNSName}}
      groups:
        - system:bootstrappers
        - system:nodes

    # Read-only for auditors
    - rolearn: arn:aws:iam::123456789012:role/AuditorRole
      username: auditor
      groups:
        - view-only
```

---

## Pod Security Standards

### What Pod Security Standards Enforce

```
Kubernetes 1.23+ replaces deprecated PodSecurityPolicy with Pod Security Standards (PSS).
PSS is enforced via namespace-level labels — no admission controller needed.

Three levels:
  privileged:   No restrictions (use for system namespaces: kube-system)
  baseline:     Prevents known privilege escalation (for legacy apps)
  restricted:   Most secure; required for production application namespaces

Enforcement modes per level:
  enforce:  reject pods that violate the policy
  warn:     allow pods but display a warning
  audit:    allow pods but record to audit log
```

### Namespace Labels for Production

```yaml
# namespace.yaml — apply to all production application namespaces
apiVersion: v1
kind: Namespace
metadata:
  name: payments
  labels:
    pod-security.kubernetes.io/enforce: restricted
    pod-security.kubernetes.io/warn:    restricted
    pod-security.kubernetes.io/audit:   restricted
    environment: production
    team: payments
    managed-by: terraform
```

### Deployment securityContext for Restricted Policy

```yaml
# deployment.yaml — securityContext required to comply with restricted PSS
spec:
  template:
    spec:
      # Pod-level security context
      securityContext:
        runAsNonRoot: true         # container process must not run as root
        runAsUser: 1000            # specific non-root UID
        runAsGroup: 3000
        fsGroup: 2000              # group ID for mounted volumes
        seccompProfile:
          type: RuntimeDefault     # use the container runtime's default seccomp profile

      containers:
        - name: api
          image: payments-api:v2.3.1
          # Container-level security context
          securityContext:
            allowPrivilegeEscalation: false  # cannot gain more privileges than parent process
            readOnlyRootFilesystem: true     # container cannot write to its own filesystem
            capabilities:
              drop: ["ALL"]                  # drop all Linux capabilities
              add:  ["NET_BIND_SERVICE"]     # add back only what is needed (if port < 1024)

          # If readOnlyRootFilesystem: true but app needs to write temp files:
          volumeMounts:
            - name: tmp
              mountPath: /tmp
            - name: cache
              mountPath: /app/cache

      volumes:
        - name: tmp
          emptyDir: {}    # writable in-memory temp volume
        - name: cache
          emptyDir: {}
```

### What the Restricted Policy Blocks

```
Blocked by restricted policy:
  ✗ privileged: true              → full host access; root in the cluster
  ✗ hostPID: true                 → can inspect all host processes
  ✗ hostNetwork: true             → pod uses the node's network stack
  ✗ hostIPC: true                 → can communicate with host processes via IPC
  ✗ hostPath volumes              → can mount any directory from the host
  ✗ runAsUser: 0                  → running as root
  ✗ allowPrivilegeEscalation: true → can escalate to root via setuid binaries
  ✗ capabilities: add: [SYS_ADMIN] → powerful capabilities that bypass security

All of these are real attack vectors used in container escape exploits.
Enforcing restricted PSS significantly reduces the attack surface.
```

---

## GuardDuty EKS Protection

```bash
# Enable EKS Protection in GuardDuty (run in the security/management account)
DETECTOR_ID=$(aws guardduty list-detectors \
  --region ap-northeast-1 \
  --query 'DetectorIds[0]' \
  --output text)

# Enable EKS Audit Log Monitoring
aws guardduty update-detector \
  --detector-id $DETECTOR_ID \
  --features '[{"Name":"EKS_AUDIT_LOGS","Status":"ENABLED"}]' \
  --region ap-northeast-1

# Enable EKS Runtime Monitoring (in-container threat detection)
aws guardduty update-detector \
  --detector-id $DETECTOR_ID \
  --features '[{"Name":"EKS_RUNTIME_MONITORING","Status":"ENABLED","AdditionalConfiguration":[{"Name":"EKS_ADDON_MANAGEMENT","Status":"ENABLED"}]}]' \
  --region ap-northeast-1

# What EKS Protection detects:
#   → kubectl exec into production pods (unusual in prod)
#   → Privilege escalation inside containers
#   → Crypto mining processes running in pods
#   → Suspicious outbound connections (C2 communication)
#   → IAM credential theft via pod metadata service
```
