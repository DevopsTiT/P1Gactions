# EKS Best Practices — Part 2: Node Groups — Configuration and Lifecycle

> **Nodes are the EC2 instances that run your pods. How you configure and maintain them determines cluster stability, security patch cadence, and cost efficiency.**

---

## Node Type Decision

### Managed Node Groups vs Self-Managed vs Karpenter vs Fargate

```
Option                  When to Use                           Key Tradeoffs
───────────────────────────────────────────────────────────────────────────────
Managed Node Groups     Standard workloads; most teams         AWS handles provisioning,
(RECOMMENDED default)   Don't need custom OS or kernel params  AMI updates, and draining
                                                                Limited launch template flexibility

Self-Managed            Custom OS (Bottlerocket, RHEL)         Full control = full responsibility
Node Groups             Custom kernel parameters               Manual AMI updates; no AWS drain support
                        Non-standard bootstrap scripts         Avoid unless specific requirement

Karpenter               Production scale (100+ nodes)          Best bin-packing; fastest provisioning
(RECOMMENDED at scale)  Cost critical; Spot/on-demand mixing   More complex initial setup
                        Heterogeneous instance type needs       No ASG — Karpenter manages EC2 directly

Fargate                 Short-lived batch jobs                  No node management overhead
                        Teams with no ops capacity              Higher per-pod cost; no DaemonSets;
                        Compliance: no shared nodes             no SSH; limited instance types
```

**Recommendation for most production clusters:**
- Start with managed node groups
- Add Karpenter when cluster reaches 50+ nodes or cost optimization becomes critical
- Use Fargate for isolated batch workloads only

---

## Launch Template: Non-Negotiables

Every managed node group must use a launch template. Default settings are not production-ready.

### AMI Selection

```bash
# Always use the EKS-optimised AL2023 AMI
# Get the latest AMI ID for a specific k8s version:
aws ssm get-parameter \
  --name /aws/service/eks/optimized-ami/1.30/amazon-linux-2023/x86_64/standard/recommended/image_id \
  --region ap-northeast-1 \
  --query 'Parameter.Value' \
  --output text

# Pin the AMI ID in the launch template:
# → Ensures all nodes use the same tested image
# → Prevents auto-upgrade to an AMI with a breaking change
# → Rotate quarterly or within 2 weeks of a CVE patch release
```

### Instance Type Selection

```
For managed node groups (one type per group):
  m5.2xlarge    → 8 vCPU, 32GB RAM — standard balanced compute
                   Good for: general web services, APIs
  r5.2xlarge    → 8 vCPU, 64GB RAM — memory-optimised
                   Good for: in-memory caches, JVM workloads
  c5.2xlarge    → 8 vCPU, 16GB RAM — compute-optimised
                   Good for: CPU-intensive batch processing

  Avoid t3/t2 instances:
    → CPU credits are exhausted under sustained load
    → Pod performance becomes unpredictable
    → Never use burstable instances for production API servers

For Karpenter (multiple types, let Karpenter pick):
  values: ["m5.xlarge","m5.2xlarge","m5a.2xlarge","r5.xlarge","r5.2xlarge"]
  → Karpenter selects the cheapest type that fits pending pods
  → More types = better Spot availability; fewer interruptions
```

### IMDSv2 (Required — Blocks SSRF Attacks)

```hcl
# In the launch template (Terraform):
metadata_options {
  http_endpoint               = "enabled"
  http_tokens                 = "required"    # IMDSv2: require session token
  http_put_response_hop_limit = 1             # prevents containers from reaching IMDS
}

# Why http_put_response_hop_limit = 1:
# → Default hop limit = 2: allows a container to hop through the node to reach IMDS
# → Hop limit = 1: only the node itself can reach IMDS; containers cannot
# → This closes the SSRF-to-IAM-credential attack path
# → Required for all production nodes; also enforceable via SCP
```

### EBS Root Volume

```hcl
# Default 20GB fills up quickly with container images
# Production minimum: 50GB

block_device_mappings {
  device_name = "/dev/xvda"
  ebs {
    volume_size           = 50            # GB
    volume_type           = "gp3"         # lower cost than gp2; better baseline performance
    throughput            = 125           # MB/s (gp3 default)
    iops                  = 3000          # gp3 default; increase for high I/O nodes
    encrypted             = true
    kms_key_id            = aws_kms_key.node_ebs.arn
    delete_on_termination = true
  }
}

# Why 50GB minimum:
# → Each container image layer is cached on disk
# → A node running 10 different service images = 5-15GB image cache
# → Kubernetes log files accumulate
# → At 20GB: nodes hit DiskPressure within days of operation
```

### Maximum Pods Per Node

```
Max pods is determined by the instance type's ENI limits:

  Instance   ENIs  IPs/ENI  Max pods (normal)  Max pods (prefix delegation)
  m5.large   3     10       27                  54
  m5.xlarge  4     15       58                  116
  m5.2xlarge 4     15       58                  116
  m5.4xlarge 8     30       234                 468

Formula (normal): (ENIs × IPs/ENI) - (number of ENIs)
  m5.2xlarge: (4 × 15) - 4 = 56 pods (aws-node DaemonSet uses 2 IPs)

Enable prefix delegation to double or triple pod density:
  → Each ENI gets a /28 prefix (16 IPs) instead of single IPs
  → m5.2xlarge with prefix delegation: 4 × 16 = 64 pods per ENI = 240+ pods per node
  → Requires VPC CNI 1.11+; see Part 6 for configuration
```

---

## Node Group Lifecycle: AMI Updates

### Why Regular AMI Updates Are Required

```
EKS nodes use the kubelet binary from the AMI.
The kubelet must stay within 2 minor versions of the control plane.

An outdated AMI means:
  → Missing security patches (kernel CVEs, containerd CVEs)
  → Old kubelet may not support new Kubernetes features
  → After a cluster version upgrade, nodes on old AMI may lose control plane compatibility

SLA for AMI updates:
  → Monthly: check for new recommended AMI in SSM Parameter Store
  → Within 2 weeks: apply a patch release containing a CVE fix
  → Within 1 month: apply after a Kubernetes minor version upgrade
```

### AMI Update Procedure

```bash
CLUSTER_NAME="prod-eks"
NODEGROUP="workers"
K8S_VERSION="1.30"
REGION="ap-northeast-1"

# Step 1: Get the latest recommended AMI ID
LATEST_AMI=$(aws ssm get-parameter \
  --name /aws/service/eks/optimized-ami/${K8S_VERSION}/amazon-linux-2023/x86_64/standard/recommended/image_id \
  --region $REGION \
  --query 'Parameter.Value' \
  --output text)

echo "Latest AMI: $LATEST_AMI"

# Step 2: Get the current launch template ID for the node group
LT_ID=$(aws eks describe-nodegroup \
  --cluster-name $CLUSTER_NAME \
  --nodegroup-name $NODEGROUP \
  --query 'nodegroup.launchTemplate.id' \
  --output text)

# Step 3: Create a new launch template version with the new AMI
aws ec2 create-launch-template-version \
  --launch-template-id $LT_ID \
  --source-version '$Latest' \
  --launch-template-data "{\"ImageId\":\"$LATEST_AMI\"}"

# Step 4: Trigger the rolling update (drains nodes one at a time, respects PDBs)
aws eks update-nodegroup-version \
  --cluster-name $CLUSTER_NAME \
  --nodegroup-name $NODEGROUP \
  --launch-template id=$LT_ID,version=$NEW_LT_VERSION \
  --region $REGION

# Step 5: Monitor the update progress
aws eks describe-nodegroup \
  --cluster-name $CLUSTER_NAME \
  --nodegroup-name $NODEGROUP \
  --query 'nodegroup.{status:status, health:health}' \
  --output json
```

### Rolling Update Behaviour

```
When aws eks update-nodegroup-version runs:
  1. EKS cordons the first old node (no new pods scheduled)
  2. EKS drains the node (evicts pods, respecting PDBs)
  3. EKS terminates the old node
  4. EKS launches a new node with the new AMI
  5. New node joins the cluster and becomes Ready
  6. Repeat for the next node

Pod Disruption Budgets (PDBs) BLOCK the drain if evicting a pod would
violate the PDB. The update waits until it's safe to drain.
Without PDBs: all pods on a node could be evicted simultaneously → downtime.

Force flag usage:
  --force: terminates the old node even if PDBs would block the drain
  AVOID using --force in production — it bypasses PDB safety
  ONLY use if a PDB is misconfigured and blocking a critical security patch
```

---

## Spot Instances: Best Practices

### When to Use Spot

```
Use Spot for:
  ✓ Stateless workers (batch processing, data pipelines)
  ✓ Dev and staging node groups
  ✓ Burst capacity alongside on-demand base
  ✓ Jobs that can be rescheduled on interruption

Avoid Spot for:
  ✗ Stateful applications (databases with local storage)
  ✗ Single-replica services with no redundancy
  ✗ Any service without a PDB and at least 2 replicas
```

### Spot Interruption Handling

```
AWS gives a 2-minute warning before a Spot node is reclaimed.
You must handle this or pods are hard-terminated.

Option A: AWS Node Termination Handler (NTH)
  → Runs as a DaemonSet
  → Receives EC2 interruption notices via SQS
  → Cordons and drains the node within the 2-minute window
  → Pods are gracefully rescheduled to other nodes

Option B: Karpenter native interruption handling
  → Karpenter 0.19+: built-in interruption handling
  → No NTH needed when using Karpenter
  → Uses SQS queue; provisions replacement node before the interruption
```

### Instance Type Diversification

```
Critical rule: always use multiple instance families for Spot node groups.
If only one family is configured and AWS reclaims all capacity → all pods evicted.

Karpenter NodePool for Spot + on-demand with diversification:
  apiVersion: karpenter.sh/v1beta1
  kind: NodePool
  metadata:
    name: default
  spec:
    template:
      spec:
        requirements:
          - key: karpenter.sh/capacity-type
            operator: In
            values: ["spot", "on-demand"]
          - key: node.kubernetes.io/instance-type
            operator: In
            values: [
              "m5.2xlarge",    # Intel
              "m5a.2xlarge",   # AMD (lower cost)
              "m4.2xlarge",    # older generation; good Spot availability
              "m5n.2xlarge",   # enhanced networking
              "m5d.2xlarge",   # NVMe local storage (if needed)
            ]
    disruption:
      consolidationPolicy: WhenUnderutilized
      consolidateAfter: 30s

# Why diversification works:
# → AWS Spot is priced per instance family and AZ independently
# → If m5.2xlarge capacity is reclaimed, m5a.2xlarge may still be available
# → More types = lower probability of simultaneous interruption across all types
```
