# EKS Best Practices — Part 0: Overview, E2E Flow & Decision Tree

---

## E2E Flow Summary

```
1. ALWAYS-ON FOUNDATIONS
   → VPC: private subnets for nodes; public subnets for ALBs only
   → EKS control plane: private endpoint; no public endpoint in production
   → Node groups: managed node groups with launch templates; AL2023 AMI
   → IRSA on every ServiceAccount; no static IAM credentials anywhere
   → aws-auth ConfigMap + RBAC scoped per team; no cluster-admin for developers
   → kube-proxy, CoreDNS, VPC CNI add-ons managed and version-pinned

2. DAILY (automated)
   → Cluster Autoscaler or Karpenter scaling nodes to demand
   → HPA scaling pods to CPU/memory/custom metrics
   → Pod Disruption Budgets ensuring zero-downtime during node rotation
   → Container Insights / Prometheus scraping cluster metrics
   → GuardDuty EKS Protection monitoring audit logs and runtime behaviour

3. WHEN AN ALERT FIRES ("Pod OOM / Node NotReady / Deployment Degraded")
   → Identify: node issue, pod issue, or networking issue
   → Node: check instance health, taints, capacity
   → Pod: check logs, events, resource limits
   → Network: check Security Groups, ENI limits, CoreDNS
   → Never ssh directly to nodes — use SSM Session Manager

4. WEEKLY REVIEW
   → Audit unused namespaces; enforce LimitRange and ResourceQuota per namespace
   → Check for pods without resource requests/limits
   → Review Karpenter/CA decisions: any pending pods > 5 minutes?
   → Rotate node groups: check AMI version vs latest AL2023

5. MONTHLY CYCLE
   → EKS cluster version upgrade: follow n-1 skew rule
   → Add-on version review: VPC CNI, CoreDNS, kube-proxy
   → IRSA role audit: any roles with wildcard permissions?
   → Karpenter/CA configuration review: spot vs on-demand ratio

6. ROLLBACK / REGRESSION
   → Pod crash after deploy: ArgoCD rollback to last SHA
   → Node group upgrade failure: roll back launch template version
   → Networking regression: check Security Group changes, ENI limit
   → Control plane unreachable: check private endpoint VPN/DX connection
```

---

## Decision Tree — "Something is wrong with my EKS cluster"

```
"EKS problem — what layer?"
│
├─ Pods not scheduling
│   ├─ kubectl get events -n <ns> → "Insufficient cpu/memory"
│   │     → Scale node group or reduce pod resource requests
│   ├─ "node(s) had taint" → add toleration to pod spec
│   ├─ "didn't match nodeSelector" → fix nodeSelector in pod spec
│   └─ Pending > 5 min with no event → check Cluster Autoscaler logs
│
├─ Pods crashing (CrashLoopBackOff / OOMKilled)
│   ├─ kubectl logs <pod> --previous → read crash reason
│   ├─ OOMKilled → increase resources.limits.memory in Deployment
│   ├─ Missing env/secret → check envFrom and secretRef names
│   └─ App startup error → fix application code; rebuild image
│
├─ Node NotReady
│   ├─ kubectl describe node → check Conditions section
│   ├─ DiskPressure → clean up disk or expand EBS
│   ├─ MemoryPressure → evict pods; scale cluster
│   ├─ NetworkUnavailable → check VPC CNI pod in kube-system
│   └─ Node cordoned accidentally → kubectl uncordon <node>
│
├─ Networking issue (service unreachable / DNS failure)
│   ├─ kubectl get endpoints → no endpoints = selector mismatch
│   ├─ DNS failure → kubectl logs -n kube-system -l k8s-app=kube-dns
│   ├─ ALB not routing → check target group health; Security Groups
│   └─ Cross-namespace service → use full DNS: svc.namespace.svc.cluster.local
│
├─ IAM / RBAC issue
│   ├─ "Forbidden" in kubectl → check aws-auth ConfigMap
│   ├─ Pod getting AccessDenied to AWS → check IRSA annotation on ServiceAccount
│   └─ "Not authorized" to eks API → check IAM policy has eks:DescribeCluster
│
└─ Control plane issue
    ├─ kubectl times out → check private endpoint; VPN/DX
    ├─ API server slow → check etcd metrics; control plane logs in CloudWatch
    └─ Admission webhook failing → check webhook pod; use --dry-run=server to test
```

---

## Tool Map

| Tool / Service | What It Does | When to Use | Cadence |
|---|---|---|---|
| `kubectl get events` | Shows all Kubernetes events (scheduling failures, OOM kills) | First command on any pod issue | On every incident |
| `kubectl describe pod/node` | Full spec + status + events for one resource | Pod not scheduling, CrashLoop, node NotReady | On every incident |
| `kubectl top nodes/pods` | Live CPU + memory usage | Capacity planning, OOM investigation | Daily |
| Cluster Autoscaler / Karpenter | Automatically adds/removes nodes | Scaling decisions | Continuously |
| HPA (Horizontal Pod Autoscaler) | Scales pod replicas on CPU/memory/custom metrics | Handling traffic spikes | Continuously |
| IRSA (IAM Roles for Service Accounts) | Per-pod IAM identity without static keys | Any pod needing AWS API access | Always configured |
| VPC CNI | Assigns ENIs and IPs to pods from VPC CIDR | Networking foundation | Monitor for IP exhaustion |
| AWS Load Balancer Controller | Provisions ALB/NLB from Ingress/Service annotations | Exposing services | On Ingress creation |
| Container Insights / CloudWatch | Cluster-level metrics and logs from nodes | Monitoring, alerting | Continuously |
| GuardDuty EKS Protection | Threat detection on k8s audit logs + runtime | Security monitoring | Continuously |
| SSM Session Manager | Shell access to EC2 nodes without SSH | Node-level debugging | On node issues |
| `aws eks update-kubeconfig` | Fetch cluster kubeconfig | Connecting to the cluster | On setup / role change |

---

## Part Index

| Part | File | What It Covers |
|---|---|---|
| Part 1 | part1_networking.md | VPC/subnet design, Security Groups, private endpoint |
| Part 2 | part2_node-groups.md | Managed vs Karpenter vs Fargate, launch template, AMI lifecycle, Spot |
| Part 3 | part3_iam-security.md | IRSA setup, IAM scoping, Kubernetes RBAC, Pod Security Standards |
| Part 4 | part4_workloads.md | Resource requests/limits, health probes, PDB, topology spread |
| Part 5 | part5_autoscaling.md | HPA, Cluster Autoscaler, Karpenter NodePool + EC2NodeClass |
| Part 6 | part6_addons.md | Add-on roles, VPC CNI IP exhaustion + prefix delegation, CoreDNS |
| Part 7 | part7_observability.md | Container Insights, Prometheus/Grafana, logging architecture |
| Part 8 | part8_upgrades.md | Upgrade order, version skew, step-by-step upgrade, kubent |
| Mistakes | part9_common-mistakes.md | 10 mistakes with consequences and correct approaches |
