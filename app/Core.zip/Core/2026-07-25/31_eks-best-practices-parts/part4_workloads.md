# EKS Best Practices — Part 4: Workload Best Practices — Resources, Probes, and Disruption

> **Kubernetes does not automatically know how much CPU/memory your app needs, when it's healthy, or how to safely evict it. You must configure all of this explicitly. Missing any one of these causes incidents.**

---

## Resource Requests and Limits

### Why Both Are Required

```
Without resource requests:
  The Kubernetes scheduler treats the pod as if it needs 0 CPU and 0 memory.
  The pod is scheduled on any node regardless of actual capacity.
  Under load: the pod consumes all node resources → OOMKills other pods.
  The scheduler has no data for bin-packing decisions → poor node utilisation.

Without resource limits:
  A memory leak or CPU spike in one pod can starve all other pods on the same node.
  One misbehaving application can cause a node-wide incident.
  No OOMKill protection: memory grows until the node itself crashes.
```

### Resource Configuration Pattern

```yaml
# In every container spec:
resources:
  requests:
    cpu:    "100m"     # millicores: 100m = 0.1 CPU core
    memory: "128Mi"    # mebibytes
  limits:
    cpu:    "500m"     # throttle if above this (NOT killed — CPU is compressible)
    memory: "512Mi"    # OOMKill if above this (memory is NOT compressible)
```

### CPU: Requests vs Limits

```
CPU is COMPRESSIBLE:
  Kubernetes CFS (Completely Fair Scheduler) throttles CPU usage.
  A pod exceeding its CPU limit is slowed down, not killed.
  This means: high CPU = poor performance (latency spikes), not crashes.

Set CPU requests to average utilisation:
  If the app uses 150m CPU on average, set requests to 100-150m.
  Requests tell the scheduler what to reserve.

Set CPU limits to 3-5× the request:
  Allows bursting above normal usage.
  Example: requests = 100m, limits = 500m
  → App can burst to 500m briefly without being throttled.

Warning: Very high CPU limits (10×+ the request) can cause noisy-neighbour problems.
```

### Memory: Requests and Limits Must Be Carefully Matched

```
Memory is NOT compressible:
  If a pod uses more than its memory limit: OOMKill — the process is killed immediately.
  No warning, no graceful shutdown, no retry — just a hard kill.

QoS Classes based on memory settings:

  Guaranteed (recommended for production, critical services):
    requests.memory == limits.memory (exact same value)
    → Highest eviction priority: LAST to be evicted under node memory pressure
    → Pod gets a stable, guaranteed memory allocation

  Burstable (acceptable for non-critical):
    requests.memory < limits.memory
    → Can use more memory than requested
    → Second to be evicted under memory pressure
    → Suitable for: batch jobs, data processing

  BestEffort (NEVER for production):
    No requests or limits set
    → First to be evicted under ANY memory pressure
    → OOMKilled before other pods under pressure
```

### Namespace LimitRange: Enforce Defaults

```yaml
# limitrange.yaml — applied to every namespace
# Automatically adds defaults when a Deployment doesn't specify resources
apiVersion: v1
kind: LimitRange
metadata:
  name: default-limits
  namespace: payments
spec:
  limits:
    - type: Container
      default:             # applied if container has NO limits set
        cpu:    "500m"
        memory: "256Mi"
      defaultRequest:      # applied if container has NO requests set
        cpu:    "100m"
        memory: "128Mi"
      max:                 # hard ceiling — no container can exceed this
        cpu:    "2"
        memory: "2Gi"
      min:                 # minimum values (prevents containers claiming 0 resources)
        cpu:    "10m"
        memory: "16Mi"
```

### Namespace ResourceQuota: Prevent Runaway Teams

```yaml
# resourcequota.yaml — applied per namespace
# Prevents one team from consuming all cluster resources
apiVersion: v1
kind: ResourceQuota
metadata:
  name: payments-quota
  namespace: payments
spec:
  hard:
    requests.cpu:    "10"       # total CPU requests across all pods
    requests.memory: "20Gi"    # total memory requests
    limits.cpu:      "20"      # total CPU limits
    limits.memory:   "40Gi"    # total memory limits
    pods:            "100"     # max number of pods
    services:        "20"
    persistentvolumeclaims: "10"
```

---

## Health Probes: All Three Are Required

### Liveness Probe: Kill and Restart

```yaml
livenessProbe:
  httpGet:
    path: /healthz       # a dedicated health endpoint (not the API endpoint)
    port: 8080
  initialDelaySeconds: 30    # wait 30s before first check (for app startup)
  periodSeconds: 10          # check every 10 seconds
  failureThreshold: 3        # 3 consecutive failures → kill and restart container
  successThreshold: 1        # 1 success after failure = healthy again
  timeoutSeconds: 5          # request must respond within 5 seconds
```

**What it does:** If the liveness probe fails N times consecutively, Kubernetes kills the container and restarts it. Use for: detecting deadlocks, stuck processes, or unrecoverable application states.

**Danger:** If `initialDelaySeconds` is too short, liveness probe kills a healthy pod that hasn't finished starting up. Use startup probes (below) to protect slow-starting apps.

**Use httpGet, not exec:**
- `exec` forks a new process on every probe check — expensive at scale
- `httpGet` makes a simple HTTP request — cheap and non-invasive

### Readiness Probe: Remove from Load Balancing

```yaml
readinessProbe:
  httpGet:
    path: /ready       # can return 503 during startup, migration, or overload
    port: 8080
  initialDelaySeconds: 5     # shorter than liveness — should succeed quickly
  periodSeconds: 5
  failureThreshold: 3        # 3 failures → remove from Service endpoints
  successThreshold: 2        # must pass 2 checks to be re-added to endpoints
```

**What it does:** If the readiness probe fails, the pod is removed from the Service's endpoint list — no traffic is routed to it. The container is NOT killed. Traffic stops until the probe passes again.

**Use for:**
- Slow startup: app takes 20s to initialise → readiness fails during that time → no traffic
- DB migration: pod runs migration on startup → readiness fails until migration completes
- Overload: app returns 503 when overwhelmed → readiness removes it from rotation
- Rolling deploy: new pod doesn't receive traffic until it's actually ready

### Startup Probe: Protect Slow-Starting Apps

```yaml
startupProbe:
  httpGet:
    path: /healthz
    port: 8080
  failureThreshold: 30    # 30 × 10s = 5 minutes max startup time
  periodSeconds: 10       # check every 10 seconds
```

**What it does:** Prevents liveness probe from firing during application startup. Once the startup probe succeeds (once), it is disabled and liveness/readiness take over.

**Required for:**
- JVM applications (Spring Boot, Quarkus): may need 60+ seconds to JIT-compile
- Apps that run database migrations on startup
- Any app with startup time > `liveness.initialDelaySeconds`

### Health Endpoint Best Practices

```
/healthz (liveness):
  Should return 200 as long as the process is alive.
  Should NOT check external dependencies (DB, Redis, downstream services).
  If it checks DB: DB outage → all pods restart → cascading failure.
  Fast check: can the process respond? That's all.

/ready (readiness):
  CAN check external dependencies (DB connection, cache warmup).
  Should return 503 when the pod cannot serve traffic correctly.
  More strict than liveness.
  Example: check that DB connection pool has active connections.

Dedicated health endpoints:
  Do NOT use your API endpoints as health checks (/api/v1/users for readiness).
  Health checks should be lightweight, dedicated, and not authenticated.
  The kubelet doesn't send auth headers by default.
```

---

## Pod Disruption Budgets

### Why PDBs Are Required for Production

```
A PDB sets the minimum number of pods that must remain available
during a VOLUNTARY disruption:
  → Node drain (for AMI update, node group rotation)
  → kubectl drain (for maintenance)
  → Cluster Autoscaler scale-down
  → Rolling deployment

WITHOUT a PDB:
  A node drain evicts ALL pods on the node simultaneously.
  If a Deployment has 3 replicas on one node → all 3 evicted at once → zero availability.
  Service is down until pods are rescheduled and pass readiness probes.

WITH a PDB (minAvailable: 1):
  Node drain evicts 1 pod.
  Waits until that pod is rescheduled and passes readiness probes.
  Then evicts the next pod.
  At least 1 pod is always available throughout the entire drain process.
```

### PDB Configuration

```yaml
# pdb.yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: payments-api-pdb
  namespace: payments
spec:
  minAvailable: 1       # at least 1 pod always available
  selector:
    matchLabels:
      app: payments-api

# OR use maxUnavailable (better for large deployments):
spec:
  maxUnavailable: 1     # at most 1 pod can be unavailable at any time
  # For 10 replicas: 9 always available; 1 can be drained at a time
  # For 100 replicas: 99 always available; 1 can be drained
```

**minAvailable vs maxUnavailable:**
```
Use minAvailable for critical services (payments, auth, checkout):
  minAvailable: 1 → at least 1 pod always up, no matter what
  minAvailable: "50%" → at least half always up

Use maxUnavailable for high-replica services:
  maxUnavailable: 1 → drains 1 at a time regardless of total replica count
  maxUnavailable: "10%" → can drain up to 10% simultaneously (faster for large deployments)
```

---

## Topology Spread Constraints

### Why Single-AZ Deployments Are Dangerous

```
Without topology spread:
  The Kubernetes scheduler places pods on any available node.
  All 3 replicas of payments-api may land on nodes in ap-northeast-1a.
  If ap-northeast-1a has an AZ outage:
    → All 3 replicas are gone simultaneously
    → Service is down until pods reschedule to other AZs
    → PDB doesn't help here — this is an involuntary disruption

With topology spread:
  1 pod in ap-northeast-1a, 1 in ap-northeast-1c, 1 in ap-northeast-1d
  AZ failure only takes down 1 of 3 pods.
  Service continues with 2/3 capacity while the third reschedules.
```

### Topology Spread Configuration

```yaml
# In the Deployment spec:
spec:
  template:
    spec:
      topologySpreadConstraints:
        # Spread across AZs
        - maxSkew: 1
          topologyKey: topology.kubernetes.io/zone    # AZ label on nodes
          whenUnsatisfiable: DoNotSchedule            # hard constraint: don't violate
          labelSelector:
            matchLabels:
              app: payments-api

        # Additionally: spread across individual nodes
        - maxSkew: 1
          topologyKey: kubernetes.io/hostname         # node label
          whenUnsatisfiable: DoNotSchedule
          labelSelector:
            matchLabels:
              app: payments-api
```

**maxSkew explained:**
```
maxSkew: 1 means: the pod count difference between any two zones cannot exceed 1.

If ap-northeast-1a has 3 pods and ap-northeast-1c has 1 pod:
  Difference = 2 → violates maxSkew: 1
  The scheduler WILL NOT add another pod to ap-northeast-1a
  It must add the next pod to ap-northeast-1c or ap-northeast-1d

maxSkew: 2 → allows a 2-pod difference (less strict)
maxSkew: 0 → all zones must have EXACTLY the same count (very strict, may cause pending)
```

**whenUnsatisfiable modes:**
```
DoNotSchedule (hard constraint):
  If spreading would violate maxSkew, the pod stays PENDING.
  Use for: critical services that must be spread (payments, auth)
  
ScheduleAnyway (soft constraint):
  If spreading would violate maxSkew, schedule anyway (best-effort).
  Use for: non-critical services where some skew is acceptable
  Use during: node scaling events when AZs are temporarily imbalanced
```

---

## Graceful Shutdown

```yaml
# Every container should handle SIGTERM gracefully
spec:
  template:
    spec:
      terminationGracePeriodSeconds: 60   # default is 30s; increase for slow-shutting apps

      containers:
        - name: api
          lifecycle:
            preStop:
              exec:
                command: ["/bin/sh", "-c", "sleep 10"]
              # preStop hook: wait 10 seconds before the main process gets SIGTERM
              # During this window: Service endpoints are removed (no new requests)
              # After this window: SIGTERM sent; app should finish in-flight requests

# Why preStop sleep:
# → When a pod is terminating, the Service endpoint removal and SIGTERM happen simultaneously
# → There may be a brief window where requests arrive AFTER the pod starts shutting down
# → The preStop sleep gives the Service endpoints time to propagate before the app terminates
# → Prevents: connection refused errors during rolling deploys
```
