# EKS Best Practices — Part 7: Observability — Monitoring and Logging

> **Without observability, you only know something is broken when users report it. With proper monitoring and logging, you detect degradation before it becomes an outage and diagnose root cause in minutes instead of hours.**

---

## Three Pillars of EKS Observability

```
METRICS  → What is happening? (CPU, memory, request rate, error rate)
  → Container Insights for AWS-native CloudWatch integration
  → Prometheus for granular k8s metrics with Grafana dashboards

LOGS     → What did the application say?
  → Control plane logs: API server audit, scheduler, controller-manager
  → Application logs: structured JSON → Fluent Bit → CloudWatch / S3

TRACES   → How long did each step take?
  → AWS X-Ray or OpenTelemetry (advanced; not covered here)
```

---

## Container Insights: AWS-Native Metrics

### What It Provides

```
Container Insights collects metrics at every level of the cluster:

Cluster level:
  → Number of nodes (ready vs total)
  → Number of pods (running vs total)
  → Cluster CPU and memory utilisation

Node level:
  → CPU utilisation and throttling
  → Memory utilisation and working set
  → Network bytes in/out
  → Disk utilisation on root volume
  → Number of pods per node

Pod level:
  → CPU usage and limits
  → Memory usage and limits
  → Network bytes in/out
  → Number of container restarts

Container level:
  → Per-container CPU and memory (when multiple containers per pod)
```

### Enable Container Insights

```bash
# Method A: eksctl (simplest)
eksctl enable addon \
  --name amazon-cloudwatch-observability \
  --cluster prod-eks \
  --region ap-northeast-1

# Method B: Helm
helm repo add aws-observability https://aws-observability.github.io/helm-charts
helm install amazon-cloudwatch-observability aws-observability/amazon-cloudwatch-observability \
  --namespace amazon-cloudwatch \
  --create-namespace \
  --set clusterName=prod-eks \
  --set serviceAccount.annotations."eks\.amazonaws\.com/role-arn"=arn:aws:iam::123456789012:role/CloudWatchAgentRole

# IRSA permissions required for the agent:
# cloudwatch:PutMetricData
# cloudwatch:GetMetricStatistics
# cloudwatch:ListMetrics
# ec2:DescribeInstances
# ec2:DescribeVolumes
# logs:CreateLogGroup
# logs:CreateLogStream
# logs:PutLogEvents
```

### CloudWatch Alarms for EKS

```bash
CLUSTER_NAME="prod-eks"
REGION="ap-northeast-1"
SNS_ARN="arn:aws:sns:ap-northeast-1:123456789012:sre-alerts"

# Alarm 1: High node CPU utilisation
aws cloudwatch put-metric-alarm \
  --alarm-name "EKS-NodeCPUHigh-${CLUSTER_NAME}" \
  --namespace ContainerInsights \
  --metric-name node_cpu_utilization \
  --dimensions Name=ClusterName,Value=$CLUSTER_NAME \
  --statistic Average \
  --period 300 \
  --threshold 85 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 2 \
  --alarm-actions $SNS_ARN \
  --region $REGION

# Alarm 2: Pods in Pending state (node capacity insufficient)
aws cloudwatch put-metric-alarm \
  --alarm-name "EKS-PendingPodsHigh-${CLUSTER_NAME}" \
  --namespace ContainerInsights \
  --metric-name pod_number_of_running_containers \
  --dimensions Name=ClusterName,Value=$CLUSTER_NAME Name=pod_status,Value=Pending \
  --statistic Sum \
  --period 300 \
  --threshold 5 \
  --comparison-operator GreaterThanOrEqualToThreshold \
  --evaluation-periods 1 \
  --alarm-actions $SNS_ARN \
  --region $REGION

# Alarm 3: Container restarts (CrashLoopBackOff indicator)
aws cloudwatch put-metric-alarm \
  --alarm-name "EKS-ContainerRestarts-${CLUSTER_NAME}" \
  --namespace ContainerInsights \
  --metric-name pod_number_of_container_restarts \
  --dimensions Name=ClusterName,Value=$CLUSTER_NAME \
  --statistic Sum \
  --period 300 \
  --threshold 10 \
  --comparison-operator GreaterThanThreshold \
  --evaluation-periods 1 \
  --alarm-actions $SNS_ARN \
  --region $REGION
```

---

## Prometheus + Grafana: Granular Metrics

### Why Prometheus in Addition to Container Insights

```
Container Insights:
  ✓ No configuration; just enable and it works
  ✓ Integrated with AWS Console and CloudWatch Alarms
  ✗ Metrics are pre-aggregated at 1-minute intervals
  ✗ Cannot alert on application-level metrics
  ✗ No custom PromQL queries
  ✗ Cannot correlate Kubernetes events with metrics

Prometheus:
  ✓ 15-second scrape intervals; sub-minute alerting
  ✓ Scrapes any app that exposes /metrics in Prometheus format
  ✓ PromQL: powerful query language for advanced alerts
  ✓ Alerts on application metrics (HTTP error rate, queue depth)
  ✓ Native integration with Grafana dashboards
  ✗ Requires management: storage, HA, retention configuration
  ✗ More configuration work
```

### Key Prometheus Alerts for EKS

```yaml
# alerting-rules.yaml
groups:
  - name: kubernetes-workloads
    rules:
      # CrashLoopBackOff detection
      - alert: PodCrashLooping
        expr: |
          increase(kube_pod_container_status_restarts_total[10m]) > 5
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "Pod {{ $labels.pod }} is restarting frequently"
          description: "{{ $labels.pod }} in namespace {{ $labels.namespace }} restarted {{ $value }} times in 10 minutes"

      # Node NotReady
      - alert: NodeNotReady
        expr: kube_node_status_condition{condition="Ready",status="false"} == 1
        for: 2m
        labels:
          severity: critical
        annotations:
          summary: "Node {{ $labels.node }} is NotReady"

      # Deployment replicas unavailable
      - alert: DeploymentReplicasUnavailable
        expr: |
          kube_deployment_status_replicas_available /
          kube_deployment_spec_replicas < 0.5
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "Deployment {{ $labels.deployment }} has < 50% replicas available"

      # High pending pod count
      - alert: PodsPendingTooLong
        expr: |
          sum by (namespace) (kube_pod_status_phase{phase="Pending"}) > 0
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "Pods pending in namespace {{ $labels.namespace }}"

      # API server latency
      - alert: APIServerHighLatency
        expr: |
          histogram_quantile(0.99,
            rate(apiserver_request_duration_seconds_bucket{verb!~"WATCH|LIST"}[5m])
          ) > 1
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "API server P99 latency > 1 second"
```

### Essential Grafana Dashboards

```
Dashboard ID  Name                              What It Shows
──────────────────────────────────────────────────────────────────────────────
1860          Node Exporter Full                Node-level: CPU, memory, disk, network, load
315           Kubernetes cluster monitoring     Cluster-level: pod count, deployment status
6417          Kubernetes pods and namespaces    Pod-level: resource usage per namespace
10257         Kubernetes API server             API server: request rate, latency, error rate
13659         AWS EKS monitoring               EKS-specific: node group health, scaling events
3662          Prometheus self-monitoring        Prometheus: memory, TSDB, rule evaluation
```

---

## Logging Architecture

### Control Plane Logs (Enable These)

```bash
# Enable all control plane log types
aws eks update-cluster-config \
  --name prod-eks \
  --region ap-northeast-1 \
  --logging '{"clusterLogging":[{"types":["api","audit","authenticator","controllerManager","scheduler"],"enabled":true}]}'

# Or via Terraform:
# resource "aws_eks_cluster" "main" {
#   enabled_cluster_log_types = [
#     "api",               # API server audit log — who made what request
#     "audit",             # k8s audit log — RBAC decisions, access denied
#     "authenticator",     # aws-iam-authenticator — IAM→k8s auth attempts
#     "controllerManager", # what controllers are doing (deployment rollouts etc.)
#     "scheduler",         # scheduling decisions for each pod
#   ]
# }

# Logs appear in CloudWatch under /aws/eks/<cluster-name>/cluster
```

**What each log type tells you:**

| Log type | When to query it |
|---|---|
| `api` | "What API calls are being made? Who is calling the API?" |
| `audit` | "Who was denied access? Which RBAC rule blocked them?" |
| `authenticator` | "Why can't this IAM role/user authenticate to kubectl?" |
| `controllerManager` | "Why isn't my Deployment rolling out? What are controllers deciding?" |
| `scheduler` | "Why is a specific pod Pending? What scheduling decisions were made?" |

### Application Logs: Structured JSON

```
Requirement: ALL application containers MUST log structured JSON to stdout/stderr.

Why structured JSON:
  → Fluent Bit can parse each field independently
  → CloudWatch Log Insights can filter by field value (level="error")
  → No regex needed — structured data is directly queryable
  → Consistent format across all services enables cross-service queries

Required JSON log format:
  {
    "timestamp":  "2026-07-25T09:30:00Z",    # ISO 8601 format
    "level":      "error",                    # debug/info/warn/error
    "message":    "database connection failed",
    "service":    "payments-api",
    "traceId":    "abc123def456",             # for distributed tracing
    "userId":     "user_789",                 # for user-scoped debugging
    "duration_ms": 1234,                      # for latency tracking
    "error":      "connection timeout after 5s"
  }

What NOT to log:
  → Plaintext multi-line logs (hard to parse)
  → Passwords, API keys, credit card numbers (PII/secrets in logs = compliance violation)
  → Unstructured messages: "Something went wrong on line 42"
```

### Fluent Bit: Shipping Logs to CloudWatch

```yaml
# fluentbit-configmap.yaml (key configuration sections)
apiVersion: v1
kind: ConfigMap
metadata:
  name: fluent-bit-config
  namespace: amazon-cloudwatch
data:
  fluent-bit.conf: |
    [SERVICE]
        Flush         5
        Daemon        Off
        Log_Level     info
        Parsers_File  parsers.conf

    [INPUT]
        Name              tail
        Tag               kube.*
        Path              /var/log/containers/*.log
        Parser            docker
        DB                /var/log/flb_kube.db
        Mem_Buf_Limit     50MB
        Skip_Long_Lines   On
        Refresh_Interval  10

    [FILTER]
        Name                kubernetes
        Match               kube.*
        Kube_URL            https://kubernetes.default.svc:443
        Kube_CA_File        /var/run/secrets/kubernetes.io/serviceaccount/ca.crt
        Kube_Token_File     /var/run/secrets/kubernetes.io/serviceaccount/token
        Merge_Log           On          # merges JSON log fields into the record
        Keep_Log            Off
        K8S-Logging.Parser  On
        K8S-Logging.Exclude On

    [OUTPUT]
        Name                cloudwatch_logs
        Match               *
        region              ap-northeast-1
        log_group_name      /eks/prod-eks/application
        log_stream_prefix   ${HOSTNAME}-
        auto_create_group   true
```

### CloudWatch Log Insights Query Examples

```
# Find all errors in the payments namespace in the last hour:
fields @timestamp, kubernetes.namespace_name, kubernetes.pod_name, message, error
| filter kubernetes.namespace_name = "payments"
| filter level = "error"
| sort @timestamp desc
| limit 100

# Count error rate per service:
fields service, level
| filter level = "error"
| stats count() by service
| sort count desc

# Find the slowest requests:
fields service, message, duration_ms
| filter ispresent(duration_ms)
| stats avg(duration_ms), max(duration_ms), count() by service
| sort max(duration_ms) desc

# Find connection timeouts:
fields @timestamp, service, error
| filter error like /timeout/
| sort @timestamp desc
| limit 50
```

---

## Observability Quick Reference

```
Problem                           Where to look
──────────────────────────────────────────────────────────────────────────────
Pod CrashLoopBackOff              kubectl logs <pod> --previous
                                  Container Insights: pod_number_of_container_restarts
                                  Prometheus: kube_pod_container_status_restarts_total

Node NotReady                     kubectl describe node
                                  Container Insights: NodeNotReady alarm
                                  CloudWatch: /aws/eks/<cluster>/cluster → scheduler

Pending pods                      kubectl describe pod → Events section
                                  Karpenter logs: kubectl logs -n kube-system -l app.kubernetes.io/name=karpenter
                                  Cluster Autoscaler logs: kubectl logs -n kube-system -l app=cluster-autoscaler

Service unreachable               kubectl get endpoints -n <ns>
                                  kubectl logs -n kube-system -l k8s-app=kube-dns (CoreDNS)
                                  Container Insights: network metrics

API server slow                   CloudWatch: /aws/eks/<cluster>/cluster → api log type
                                  Prometheus: apiserver_request_duration_seconds_bucket

IAM auth failure                  CloudWatch: /aws/eks/<cluster>/cluster → authenticator log
                                  kubectl logs on the specific pod
```
