# EKS Best Practices — Part 8: Upgrades — EKS Version and Add-on Management

> **EKS upgrades have a strict ordering and a support window. Skipping a version is not supported. Add-ons must be updated immediately after the control plane. A disciplined upgrade process prevents version skew incidents.**

---

## EKS Version Lifecycle

```
EKS releases a new Kubernetes minor version approximately every 3-4 months.
AWS supports a version for approximately 14 months after it is made available.

Version support timeline example:
  Kubernetes 1.27: Available 2023-05 → End of Support 2024-07 (14 months)
  Kubernetes 1.28: Available 2023-09 → End of Support 2025-01
  Kubernetes 1.29: Available 2024-01 → End of Support 2025-03
  Kubernetes 1.30: Available 2024-05 → End of Support 2025-07

What happens when support ends:
  → AWS sends deprecation notices 60 days before end of support
  → 30 days before: auto-upgrade warnings appear in console
  → After end of support: AWS may auto-upgrade the cluster (with notice)
  → Auto-upgrade can cause issues if you haven't prepared

Recommendation:
  → Stay no more than 2 minor versions behind the latest
  → Upgrade at least once every 6-9 months
  → Never wait until the last week before end-of-support
```

---

## Version Skew Rules

```
Control plane version:   1.30  (must be upgraded first)
Node group version:      within 2 minor versions of control plane
  → 1.30 control plane: nodes can be 1.28, 1.29, or 1.30
  → 1.30 control plane: nodes CANNOT be 1.27 or older

kubectl version:         within 1 minor version of API server
  → 1.30 API server: kubectl must be 1.29, 1.30, or 1.31
  → Using kubectl 1.27 against 1.30 API server: unsupported; unexpected behaviour

Add-on version compatibility:
  → VPC CNI, CoreDNS, kube-proxy: each has a supported range for each EKS version
  → Update add-ons IMMEDIATELY after control plane upgrade
  → Running incompatible add-on versions causes networking instability

Upgrade order (NEVER reverse this):
  1. Control plane first (EKS managed)
  2. Add-ons second (VPC CNI, CoreDNS, kube-proxy)
  3. Node groups last (new AMI with new kubelet)
```

---

## Pre-Upgrade Checklist

### Step 1: Read the EKS Release Notes

```bash
# EKS release notes: https://docs.aws.amazon.com/eks/latest/userguide/kubernetes-versions.html
# Check for:
#   → Removed API versions (apps/v1beta1, extensions/v1beta1, etc.)
#   → Changed default values in kube-apiserver flags
#   → Deprecated features with hard removal dates
#   → Breaking changes in add-on versions
```

### Step 2: Detect Deprecated API Versions (kubent)

```bash
# Install kubent (kube-no-trouble):
brew install kubent                # macOS
# OR:
sh -c "$(curl -sSL https://git.io/install-kubent)"

# Scan the cluster for deprecated API versions:
kubent --target-version 1.30

# Example output:
# [WARNING] Found deprecated API versions:
#   apps/v1beta1 - Deployment/payments-api (payments namespace)
#   → This API was REMOVED in Kubernetes 1.16
#   → You must update the manifest to use apps/v1 before upgrading

# Also available as kubectl plugin:
kubectl krew install deprecations
kubectl deprecations --version 1.30
```

**What to do with deprecated APIs:**
```
1. Find all manifests using the deprecated API version:
   grep -r "apiVersion: apps/v1beta1" environments/
   grep -r "apiVersion: extensions/v1beta1" environments/

2. Update each manifest to the stable API version:
   apps/v1beta1 → apps/v1  (Deployment, StatefulSet, DaemonSet)
   extensions/v1beta1 → networking.k8s.io/v1  (Ingress)
   rbac.authorization.k8s.io/v1beta1 → rbac.authorization.k8s.io/v1

3. Deploy the updated manifests BEFORE upgrading the control plane
   (the old API version still works in the current version; update while you can)

4. Re-run kubent to confirm no deprecated APIs remain
```

### Step 3: Review Add-on Compatibility

```bash
CLUSTER_NAME="prod-eks"
CURRENT_VERSION=$(aws eks describe-cluster \
  --name $CLUSTER_NAME \
  --query 'cluster.version' \
  --output text)

TARGET_VERSION="1.30"

# Check compatible add-on versions for the target Kubernetes version
for ADDON in vpc-cni coredns kube-proxy; do
  echo "=== $ADDON ==="
  aws eks describe-addon-versions \
    --kubernetes-version $TARGET_VERSION \
    --addon-name $ADDON \
    --query 'addons[0].addonVersions[0:3].{version:addonVersion, default:compatibilities[0].defaultVersion}' \
    --output table
done
```

---

## Upgrade Procedure: Step by Step

### Step 1: Upgrade the Control Plane

```bash
CLUSTER_NAME="prod-eks"
TARGET_VERSION="1.30"
REGION="ap-northeast-1"

# Trigger the control plane upgrade
aws eks update-cluster-version \
  --name $CLUSTER_NAME \
  --kubernetes-version $TARGET_VERSION \
  --region $REGION

# Monitor the upgrade status (takes 15-20 minutes)
# Check every 2 minutes:
watch -n 120 "aws eks describe-cluster \
  --name $CLUSTER_NAME \
  --region $REGION \
  --query 'cluster.{status:status, version:version}' \
  --output table"

# Wait for status = ACTIVE and version = 1.30
aws eks wait cluster-active \
  --name $CLUSTER_NAME \
  --region $REGION

echo "Control plane upgrade complete"
```

**What happens during control plane upgrade:**
```
AWS performs a rolling update of the control plane components:
  → API servers are replaced one at a time (zero downtime)
  → etcd is upgraded (your data is preserved)
  → controller-manager and scheduler are replaced
  → The cluster endpoint remains the same throughout

Your workloads continue running during the upgrade.
Only `kubectl` may briefly return errors if you hit a node being replaced.
The upgrade takes 15-20 minutes for most clusters.
```

### Step 2: Update Add-ons (Immediately After Control Plane)

```bash
# Update all three core add-ons to compatible versions for the new k8s version
for ADDON in vpc-cni coredns kube-proxy; do
  # Get the latest compatible version
  LATEST=$(aws eks describe-addon-versions \
    --kubernetes-version $TARGET_VERSION \
    --addon-name $ADDON \
    --region $REGION \
    --query 'addons[0].addonVersions[0].addonVersion' \
    --output text)

  echo "Updating $ADDON to $LATEST"
  
  aws eks update-addon \
    --cluster-name $CLUSTER_NAME \
    --addon-name $ADDON \
    --addon-version $LATEST \
    --resolve-conflicts OVERWRITE \
    --region $REGION

  # Wait for the add-on update to complete
  aws eks wait addon-active \
    --cluster-name $CLUSTER_NAME \
    --addon-name $ADDON \
    --region $REGION

  echo "$ADDON update complete"
done
```

### Step 3: Update Node Groups (Rolling)

```bash
# For each node group: update to the new AMI version
NODEGROUPS=$(aws eks list-nodegroups \
  --cluster-name $CLUSTER_NAME \
  --region $REGION \
  --query 'nodegroups[]' \
  --output text)

for NODEGROUP in $NODEGROUPS; do
  echo "Updating node group: $NODEGROUP"
  
  aws eks update-nodegroup-version \
    --cluster-name $CLUSTER_NAME \
    --nodegroup-name $NODEGROUP \
    --region $REGION
    # Omitting --release-version uses the latest for the new k8s version

  # Monitor the update
  aws eks wait nodegroup-active \
    --cluster-name $CLUSTER_NAME \
    --nodegroup-name $NODEGROUP \
    --region $REGION

  echo "Node group $NODEGROUP update complete"
done
```

### Step 4: Verify the Upgrade

```bash
# All nodes should show the new version
kubectl get nodes -o wide
# Expected: all nodes show v1.30.x

# All pods should be Running
kubectl get pods -A | grep -v "Running\|Completed" | grep -v NAME

# Check add-on versions
kubectl get daemonset aws-node -n kube-system \
  -o jsonpath='{.spec.template.spec.containers[0].image}'

kubectl get deployment coredns -n kube-system \
  -o jsonpath='{.spec.template.spec.containers[0].image}'

# Verify the cluster version
aws eks describe-cluster \
  --name $CLUSTER_NAME \
  --query 'cluster.{version:version, status:status}' \
  --output table

# Run a smoke test: create and delete a test pod
kubectl run smoke-test --image=nginx:alpine --restart=Never
kubectl wait pod smoke-test --for=condition=ready --timeout=60s
kubectl delete pod smoke-test
echo "Smoke test passed"
```

---

## Karpenter Node Upgrade (expireAfter)

```yaml
# Karpenter NodePool with automatic node rotation:
spec:
  disruption:
    expireAfter: 720h   # expire nodes after 30 days
    # When a node reaches expiry:
    #   1. Karpenter cordons the node
    #   2. Karpenter provisions a new node with the latest AMI
    #   3. Karpenter drains and terminates the old node
    # → Nodes are always on a recent AMI without manual intervention
    # → PDBs are respected during draining
```

---

## Common Upgrade Mistakes

| Mistake | Consequence | Fix |
|---|---|---|
| Upgrading from 1.27 → 1.30 (skipping versions) | Not supported; clusters in undefined state | Must upgrade one minor version at a time: 1.27 → 1.28 → 1.29 → 1.30 |
| Upgrading node groups before add-ons | Nodes run new kubelet with old VPC CNI → networking instability | Always: control plane → add-ons → nodes |
| Not running kubent before upgrading | Old API version in manifest causes post-upgrade failures | Run kubent and fix all deprecated APIs before any upgrade |
| Waiting until end-of-support to upgrade | Last-minute rush, no testing time, forced auto-upgrade | Upgrade within 6 months of a version's release; never wait until the last 30 days |
| Using --force on node group update | PDBs bypassed; pods evicted without replacement; service downtime | Only use --force if a PDB is misconfigured and blocking a critical security patch |
