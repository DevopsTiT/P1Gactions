# EKS Best Practices — Part 1: Networking — VPC and Subnet Design

> **The most important decisions in EKS networking cannot be changed after cluster creation without recreating the cluster. Get the VPC design right upfront — every other networking decision flows from it.**

---

## Why Networking Is the Foundation

```
Everything else in EKS depends on the network:
  → Pod scheduling requires IP addresses (VPC CNI assigns one VPC IP per pod)
  → ALB routing requires subnets tagged correctly for the Load Balancer Controller
  → Security Groups control which components can talk to each other
  → The control plane endpoint determines who can run kubectl from where

Getting any of these wrong at cluster creation means:
  → IP exhaustion: pods can't start (no IPs available)
  → ALB creation failures: missing subnet tags
  → Security vulnerabilities: control plane reachable from internet
  → Networking complexity: debugging takes hours instead of minutes
```

---

## Subnet Architecture

### VPC CIDR and Subnet Sizing

```
VPC CIDR: 10.0.0.0/16  (65,536 IPs — never use /24 for a production cluster)

Public subnets (1 per AZ — for ALBs and NAT Gateways ONLY):
  10.0.1.0/24   ap-northeast-1a  (256 IPs)
  10.0.2.0/24   ap-northeast-1c  (256 IPs)
  10.0.3.0/24   ap-northeast-1d  (256 IPs)

Private subnets (1 per AZ — for EKS nodes and pods):
  10.0.10.0/22  ap-northeast-1a  (1,022 IPs) ← large; pods get VPC IPs
  10.0.14.0/22  ap-northeast-1c  (1,022 IPs)
  10.0.18.0/22  ap-northeast-1d  (1,022 IPs)
```

### Why Large Private Subnets Are Required

```
AWS VPC CNI assigns one VPC IP to EACH pod (not just each node).
Every pod gets its own routable IP from the VPC subnet.

IP usage per node:
  1 IP for the EC2 node itself
  N IPs for the pods running on that node

Example:
  m5.2xlarge with 30 pods = 31 IPs consumed from the subnet

For a cluster with 30 nodes × 30 pods each:
  30 × 31 = 930 IPs consumed

A /24 subnet has 256 IPs → exhausted immediately.
A /22 subnet has 1,022 IPs → supports 30+ nodes comfortably.

Rule: private subnets must be at least /22 (/21 or larger for large clusters).
      Never use /24 or smaller for EKS node subnets.
```

### Network Architecture Diagram

```
Internet
    │
    ▼
Internet Gateway
    │
    ▼
Public Subnet (each AZ)         ← ALB, NAT Gateway ONLY
  10.0.1.0/24 (ap-northeast-1a)
  10.0.2.0/24 (ap-northeast-1c)
  10.0.3.0/24 (ap-northeast-1d)
    │
    │ (private → public for outbound only, via NAT Gateway)
    ▼
Private Subnet (each AZ)        ← EKS nodes, pods, RDS, ElastiCache
  10.0.10.0/22 (ap-northeast-1a)
  10.0.14.0/22 (ap-northeast-1c)
  10.0.18.0/22 (ap-northeast-1d)

Traffic flow:
  Internet → ALB (public subnet) → pods (private subnet)
  Pods → NAT Gateway (public subnet) → Internet (for image pull, AWS API)
  Pods → VPC Endpoints → AWS services (S3, Secrets Manager — no internet needed)
```

---

## Required Subnet Tags

Subnet tags are required for the AWS Load Balancer Controller to discover which subnets to use. **Missing tags cause ALB/NLB creation to fail silently with cryptic errors — always add these at VPC creation time.**

```
Public subnets (for internet-facing ALBs):
  Key:   kubernetes.io/role/elb
  Value: "1"

Private subnets (for internal NLBs and pod networking):
  Key:   kubernetes.io/role/internal-elb
  Value: "1"

Both subnet types (ownership indicator):
  For subnets owned by this cluster only:
    Key:   kubernetes.io/cluster/<CLUSTER_NAME>
    Value: "owned"

  For subnets shared between multiple clusters:
    Key:   kubernetes.io/cluster/<CLUSTER_NAME>
    Value: "shared"
    (Apply this tag for EACH cluster that shares the subnet)

Additional tag required for Karpenter subnet discovery:
  Key:   karpenter.sh/discovery
  Value: <CLUSTER_NAME>
```

**Terraform example for subnet tags:**

```hcl
resource "aws_subnet" "private" {
  for_each          = local.private_subnets
  vpc_id            = aws_vpc.main.id
  cidr_block        = each.value.cidr
  availability_zone = each.value.az

  tags = {
    Name                                          = "private-${each.value.az}"
    "kubernetes.io/role/internal-elb"             = "1"
    "kubernetes.io/cluster/${var.cluster_name}"   = "owned"
    "karpenter.sh/discovery"                      = var.cluster_name
  }
}

resource "aws_subnet" "public" {
  for_each          = local.public_subnets
  vpc_id            = aws_vpc.main.id
  cidr_block        = each.value.cidr
  availability_zone = each.value.az

  tags = {
    Name                                        = "public-${each.value.az}"
    "kubernetes.io/role/elb"                    = "1"
    "kubernetes.io/cluster/${var.cluster_name}" = "owned"
  }
}
```

---

## Security Groups

### Control Plane Security Group

```
EKS Control Plane Security Group:
  Inbound:
    Port 443 (HTTPS) from node Security Group
      → Nodes communicate with the API server
    Port 443 (HTTPS) from admin CIDR (office IP / VPN)
      → kubectl access from authorized locations

  Outbound:
    All traffic
      → Control plane reaches nodes via kubelet (port 10250)
      → Control plane reaches services via NodePort
```

### Node Security Group

```
Node Security Group:
  Inbound:
    Port 10250 from control plane SG
      → kubelet API (health checks, log streaming, exec)
    All traffic from node SG to itself
      → Pod-to-pod communication within the cluster
      → This self-referencing rule is essential for internal service mesh
    Port <pod port> (e.g. 8080) from ALB SG
      → ALB routes traffic directly to pod ports

  Outbound:
    All traffic
      → Pods pull container images from ECR (HTTPS 443)
      → Pods call AWS APIs (HTTPS 443 to AWS endpoints)
      → Pods communicate with external services

Rule: use Security Group IDs as sources — NEVER wide CIDRs for internal traffic.
  ❌ Source: 10.0.0.0/8  → any host in the entire internal network can reach pods
  ✅ Source: sg-0abc123  → only resources in that specific SG can reach pods
```

### ALB Security Group

```
ALB Security Group:
  Inbound:
    Port 443 (HTTPS) from 0.0.0.0/0
      → Internet-facing ALB accepts traffic from anywhere
    Port 80 (HTTP) from 0.0.0.0/0 (optional — redirect to HTTPS)

  Outbound:
    Port <pod port> (e.g. 8080) to node Security Group
      → ALB routes to pod ports on nodes
      → Must match the containerPort in your Kubernetes Deployment

  Note: ALB target groups can use IP mode (routes directly to pod IP)
        or instance mode (routes to node, then kube-proxy forwards to pod).
        IP mode is recommended: more efficient, fewer hops.
```

### Security Group Common Mistakes

```
❌ Node SG inbound allows 0.0.0.0/0 on all ports
   → Any host on the internet can reach your pods if they get a public IP
   Fix: scope inbound to control plane SG and ALB SG only

❌ ALB SG allows 0.0.0.0/0 outbound to all ports
   → ALB can reach any resource on any port (overly permissive)
   Fix: outbound only to node SG on pod port (e.g. 8080)

❌ Missing self-referencing node SG rule
   → Pods on different nodes cannot communicate
   → Service-to-service calls fail within the cluster
   Fix: add inbound rule: all traffic from node SG to itself
```

---

## EKS Private Endpoint Configuration

### Production: Private Endpoint Only

```
Endpoint Access: Private only
  → kubectl commands route through the VPC (requires VPN or AWS Direct Connect)
  → The Kubernetes API server is not reachable from the internet at all
  → EC2 nodes reach the control plane via the private endpoint within the VPC
  → No attack surface on the API server from the internet

Setup requirement:
  Engineers must be on VPN (or using a bastion host) to run kubectl
  CI/CD must run inside the VPC (self-hosted runner on EC2 or Fargate)

Terraform:
  resource "aws_eks_cluster" "main" {
    vpc_config {
      endpoint_private_access = true
      endpoint_public_access  = false   # private only in production
      public_access_cidrs     = []
    }
  }
```

### Development: Public + Private Endpoint (Acceptable)

```
Endpoint Access: Public + Private
  → kubectl from developer laptops works without VPN
  → MUST restrict public_access_cidrs to known IPs only

  resource "aws_eks_cluster" "dev" {
    vpc_config {
      endpoint_private_access = true
      endpoint_public_access  = true
      public_access_cidrs     = [
        "203.0.113.0/24",   # office CIDR
        "198.51.100.5/32",  # engineer A home IP
      ]
      # NEVER: public_access_cidrs = ["0.0.0.0/0"]
      # → Allows anyone on the internet to attempt API server authentication
    }
  }
```

### Why the API Server Must Be Private

```
The Kubernetes API server is the control plane for the entire cluster.
  → It authenticates all kubectl commands (who can do what)
  → It receives all admission webhook calls (OPA, cert-manager, Istio)
  → It processes all Deployment, Service, and ConfigMap changes

If the API server is public with 0.0.0.0/0:
  → Brute-force authentication attempts are possible
  → Every CVE in the Kubernetes API server is exploitable from internet
  → DDoS against the API server = cluster management unavailable
  → Any leaked kubeconfig = immediate cluster access from anywhere

Historical incidents: multiple Kubernetes API servers exposed to 0.0.0.0/0
have been compromised for crypto mining and lateral movement to cloud accounts.
```

---

## VPC Endpoints: Keep Traffic Off the Internet

```
Add VPC endpoints to keep AWS API traffic inside the VPC:
  → Pods calling S3, Secrets Manager, ECR, STS never leave the VPC
  → Faster (no internet round-trip)
  → No NAT Gateway cost for those calls
  → Required for private-endpoint-only clusters (no internet for pods)

Essential VPC Interface Endpoints for EKS:
  com.amazonaws.<region>.ec2
  com.amazonaws.<region>.ecr.api
  com.amazonaws.<region>.ecr.dkr
  com.amazonaws.<region>.s3 (Gateway endpoint — free)
  com.amazonaws.<region>.sts
  com.amazonaws.<region>.secretsmanager
  com.amazonaws.<region>.ssm
  com.amazonaws.<region>.ssmmessages  ← for SSM Session Manager access to nodes
  com.amazonaws.<region>.logs
```

---

## Terraform Networking Example

```hcl
# vpc.tf — minimal EKS-ready VPC setup

resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true   # required for EKS and ECR VPC endpoint resolution
  enable_dns_support   = true
  tags = {
    Name = "${var.cluster_name}-vpc"
  }
}

resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id
}

resource "aws_nat_gateway" "main" {
  for_each      = toset(["ap-northeast-1a", "ap-northeast-1c", "ap-northeast-1d"])
  allocation_id = aws_eip.nat[each.key].id
  subnet_id     = aws_subnet.public[each.key].id
  # One NAT Gateway per AZ: if one AZ's NAT fails, other AZs continue working
}
```
