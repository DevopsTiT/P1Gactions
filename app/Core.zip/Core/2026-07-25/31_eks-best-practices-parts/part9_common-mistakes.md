# EKS Best Practices — Part 9: Common Mistakes

> The 10 mistakes that cause the most production incidents, security vulnerabilities, and operational pain in EKS clusters — with the exact consequence and the correct approach for each.

---

## Mistake Decision Tree

```
"Something went wrong — which mistake pattern is this?"

├─ Control plane accessible from internet / kubectl works without VPN
│     → Mistake 1: Public EKS endpoint with 0.0.0.0/0

├─ A compromised pod accessed S3/DynamoDB data it shouldn't have
│     → Mistake 2: Node instance profile used by application pods

├─ Pods from one team are OOMKilling pods from another team on the same node
│     → Mistake 3: No resource requests/limits on containers

├─ Node drain during AMI update took the service offline
│     → Mistake 4: No PodDisruptionBudget

├─ An AZ failure brought down all replicas simultaneously
│     → Mistake 5: Single AZ node group

├─ ArgoCD rolled back but the exact same image ran again — same bug
│     → Mistake 6: Using :latest image tag

├─ Kubernetes is routing traffic to a pod that is still starting up
│     → Mistake 7: No liveness/readiness/startup probes

├─ Cluster Autoscaler added all nodes to one AZ — cross-AZ costs high
│     → Mistake 8: CA without balance-similar-node-groups

├─ After EKS upgrade, intermittent DNS and networking failures
│     → Mistake 9: Skipping add-on updates after control plane upgrade

├─ Payments team's batch job exhausted all cluster CPU — other teams' pods pending
│     → Mistake 10: No namespace ResourceQuota
```

---

## Mistake 1 — Public EKS Endpoint with 0.0.0.0/0

**Symptom:**
```
The EKS cluster API server is accessible from any IP address on the internet.
Security scanner shows: Kubernetes API server exposed publicly.
Engineers can run kubectl from home without VPN.
```

**Consequence:**
```
→ Every CVE in the Kubernetes API server is directly exploitable from the internet
→ Brute-force authentication attempts against the API server
→ Any leaked kubeconfig = immediate cluster access from anywhere in the world
→ Cryptocurrency mining clusters compromise exposed API servers within minutes of public exposure
→ DDoS against the API server makes cluster management unavailable during incidents
```

**Correct approach:**
```
Production: private endpoint only
  endpoint_private_access = true
  endpoint_public_access  = false
  → Engineers must use VPN or Direct Connect to run kubectl
  → CI/CD runners must be inside the VPC (self-hosted on EC2 or EKS Fargate)

Development: public + private with restricted CIDR
  endpoint_public_access  = true
  public_access_cidrs     = ["203.0.113.0/24"]  # office CIDR only
  NEVER: public_access_cidrs = ["0.0.0.0/0"]

Verify current setting:
  aws eks describe-cluster --name prod-eks \
    --query 'cluster.resourcesVpcConfig.{private:endpointPrivateAccess, public:endpointPublicAccess, cidrs:publicAccessCidrs}'
```

---

## Mistake 2 — Node Instance Profile Used by Application Pods

**Symptom:**
```
All pods on a node share the same IAM role (the node's instance profile).
An application pod can successfully call AWS APIs it should not have access to.
A compromised pod in the payments namespace can access the HR S3 bucket.
```

**Consequence:**
```
→ A single compromised pod gets the full permissions of the node's IAM role
→ Node IAM roles typically have broad permissions (ECR pull, CloudWatch, etc.)
→ Lateral movement: attacker moves from one pod to access all AWS services the node can reach
→ No per-pod audit trail: CloudTrail shows the instance ID, not the pod identity
→ Blast radius of any pod compromise = entire node's AWS access scope
```

**Correct approach:**
```
Use IRSA for every pod that needs AWS access:

  1. Create IAM OIDC provider for the cluster
  2. Create a scoped IAM role per ServiceAccount:
       payments-api role: only s3:GetObject on payments-data-bucket/*
       orders-api role:   only sqs:ReceiveMessage on orders-queue
  3. Annotate ServiceAccount:
       eks.amazonaws.com/role-arn: arn:aws:iam::123456789012:role/payments-api-role
  4. Reference in Deployment:
       spec.serviceAccountName: payments-api

Audit existing pods for instance profile misuse:
  kubectl get pods -A -o json \
    | jq '.items[] | select(.spec.serviceAccountName == "default") | .metadata.namespace + "/" + .metadata.name'
  # Pods using default SA may be using the node profile
```

---

## Mistake 3 — No Resource Requests/Limits on Containers

**Symptom:**
```
A batch job or memory-leaking service expands to consume all node resources.
Other pods on the same node are OOMKilled despite being healthy.
Pods are scheduled onto already-full nodes because requests are 0.
```

**Consequence:**
```
→ Noisy neighbour: one poorly-configured pod affects all pods on the node
→ Scheduler bin-packing is ineffective (treats all resourceless pods as 0-cost)
→ OOMKilled cascade: one pod's memory leak kills other pods on the node
→ CPU starvation: a CPU-intensive pod consumes all node CPU; other pods experience latency
→ Impossible to enforce cost attribution (ResourceQuota requires requests to work)
```

**Correct approach:**
```
Every container must have requests and limits:
  resources:
    requests:
      cpu:    "100m"
      memory: "128Mi"
    limits:
      cpu:    "500m"
      memory: "512Mi"

Enforce defaults at namespace level with LimitRange:
  apiVersion: v1
  kind: LimitRange
  spec:
    limits:
      - type: Container
        defaultRequest: {cpu: "100m", memory: "128Mi"}
        default:        {cpu: "500m", memory: "256Mi"}
        max:            {cpu: "2",    memory: "2Gi"}

Enforce caps with ResourceQuota:
  apiVersion: v1
  kind: ResourceQuota
  spec:
    hard:
      requests.cpu: "10"
      requests.memory: "20Gi"
      limits.cpu: "20"
      limits.memory: "40Gi"

Find pods without resource limits:
  kubectl get pods -A -o json \
    | jq '[.items[] | select(.spec.containers[].resources.limits == null) | .metadata.namespace + "/" + .metadata.name]'
```

---

## Mistake 4 — No PodDisruptionBudget

**Symptom:**
```
An AMI update runs during business hours.
The node drain evicts all 3 replicas of payments-api simultaneously.
The service is down for 3 minutes while pods reschedule and pass readiness probes.
```

**Consequence:**
```
→ Node drain = all pods on the node evicted at once → service unavailability
→ Cluster Autoscaler scale-down = same problem: removes underutilised node with all its pods
→ Even a rolling deploy can cause downtime if the old pods terminate before new ones are ready
→ Compounded by topology spread: if all pods are in one AZ and that AZ's nodes drain = total outage
```

**Correct approach:**
```
Every production Deployment with > 1 replica must have a PDB:

  apiVersion: policy/v1
  kind: PodDisruptionBudget
  metadata:
    name: payments-api-pdb
    namespace: payments
  spec:
    minAvailable: 1        # at least 1 pod always available during voluntary disruptions
    selector:
      matchLabels:
        app: payments-api

  Effect: kubectl drain waits until a replacement pod is Ready before evicting the next pod.
  The drain takes longer but the service stays up throughout.

Find Deployments without PDBs:
  # Get all Deployments in production namespaces
  kubectl get deployments -n payments -o json | jq '.items[].metadata.name'
  # Get all PDBs and their selectors
  kubectl get pdb -n payments -o json | jq '.items[].spec.selector.matchLabels'
  # Compare: any Deployment not covered by a PDB = risk
```

---

## Mistake 5 — Single AZ Node Group

**Symptom:**
```
All node groups are deployed to a single Availability Zone.
The team chose the cheapest option without considering HA.
```

**Consequence:**
```
→ An AZ failure (AWS outage, maintenance event) takes down the entire cluster
→ All pods on all nodes in that AZ evicted simultaneously
→ PDBs don't help — this is an involuntary disruption (AWS hardware failure)
→ Even with 3 replicas: all 3 in the same AZ = complete outage
→ Historical incidents: single-AZ EKS clusters experience multi-hour outages during AZ events
```

**Correct approach:**
```
Always deploy node groups across at least 3 AZs:

  resource "aws_eks_node_group" "workers" {
    subnet_ids = [
      aws_subnet.private["ap-northeast-1a"].id,
      aws_subnet.private["ap-northeast-1c"].id,
      aws_subnet.private["ap-northeast-1d"].id,
    ]
    scaling_config {
      desired_size = 9   # 3 per AZ
      min_size     = 3   # 1 per AZ minimum
      max_size     = 30
    }
  }

Add topology spread constraints to ensure pods are spread:
  topologySpreadConstraints:
    - maxSkew: 1
      topologyKey: topology.kubernetes.io/zone
      whenUnsatisfiable: DoNotSchedule
      labelSelector:
        matchLabels:
          app: payments-api
```

---

## Mistake 6 — Using :latest Image Tag

**Symptom:**
```
A new Docker image was pushed to ECR as "payments-api:latest".
Nothing was changed in Kubernetes manifests — image tag is still ":latest".
The new image is not deployed. The old (buggy) image continues running.
OR: a rollback is triggered but the "previous" image is also :latest — same bug runs.
```

**Consequence:**
```
→ ArgoCD detects no change (Git says :latest; cluster also runs :latest → no diff)
→ Rollbacks are meaningless: :latest always points to the newest image
→ You cannot tell what version is running in production
→ Reproducibility is impossible: what was running at 14:32 yesterday?
→ Debugging is harder: "which version has this bug?" → impossible with :latest
```

**Correct approach:**
```
Always pin to a specific, immutable tag in all manifests:

Option A — Semantic version tag:
  image: payments-api:2.3.1
  → CI builds and tags the image with the version
  → Git manifest is updated with the new tag
  → ArgoCD detects the tag change → deploys

Option B — Git SHA tag (most immutable):
  image: payments-api@sha256:abc1234def5678
  → Impossible to be confused with another image
  → The exact binary is always reproducible

Option C — ArgoCD Image Updater:
  → Watches ECR for new tags matching a pattern
  → Updates the Git manifest automatically
  → No manual Git commit needed for image updates
```

---

## Mistake 7 — No Liveness/Readiness Probes

**Symptom:**
```
A pod starts up but takes 45 seconds to connect to the database and become ready.
Kubernetes routes traffic to it immediately → users get connection refused.
OR: A pod enters a deadlock state → it's Running but returning 500 errors.
Kubernetes keeps routing traffic to the deadlocked pod forever.
```

**Consequence:**
```
→ No readiness: new pods receive traffic before they're ready → errors during rolling deploys
→ No liveness: deadlocked or stuck pods continue receiving traffic indefinitely
→ No startup: liveness probe fires during slow startup → pod restarted repeatedly → never starts
→ Rolling deploys cause brief error spikes visible to users
→ Degraded pods stay in rotation until manually investigated
```

**Correct approach:**
```
All three probes on every container:

  startupProbe:              # prevents liveness from firing during startup
    httpGet: {path: /healthz, port: 8080}
    failureThreshold: 30     # 5 minutes max startup time
    periodSeconds: 10

  livenessProbe:             # kills and restarts stuck containers
    httpGet: {path: /healthz, port: 8080}
    initialDelaySeconds: 30
    periodSeconds: 10
    failureThreshold: 3

  readinessProbe:            # removes from load balancing until ready
    httpGet: {path: /ready, port: 8080}
    initialDelaySeconds: 5
    periodSeconds: 5
    failureThreshold: 3

  Dedicated health endpoints:
    /healthz → is the process alive? (NEVER check DB connections)
    /ready   → can this pod serve traffic? (CAN check DB connections)
```

---

## Mistake 8 — Cluster Autoscaler Without balance-similar-node-groups

**Symptom:**
```
CA adds 10 new nodes during a traffic spike.
All 10 nodes land in ap-northeast-1a.
Application traffic now crosses AZ boundaries → inter-AZ data transfer costs spike.
Pod scheduling is unbalanced → some AZs have 30 pods per node, others have 5.
```

**Consequence:**
```
→ All new nodes in one AZ = increased cross-AZ latency for pod-to-pod traffic
→ Inter-AZ data transfer: $0.01/GB between AZs; significant at scale
→ Unbalanced pod distribution = AZ failure risk reintroduced despite multi-AZ node groups
→ Scale-down: CA removes nodes from one AZ but not others → permanent AZ imbalance
```

**Correct approach:**
```
Set balance-similar-node-groups: "true" in CA Helm values:

  extraArgs:
    balance-similar-node-groups: "true"
    # CA groups node groups that have similar instance types and settings
    # When scaling up: distributes new nodes evenly across these groups (and their AZs)
    # When scaling down: removes nodes evenly to maintain balance

Verify CA is balancing:
  kubectl logs -n kube-system \
    -l app=cluster-autoscaler --tail=200 \
    | grep -i "balance\|node group"
```

---

## Mistake 9 — Skipping Add-on Updates After Control Plane Upgrade

**Symptom:**
```
EKS control plane upgraded from 1.29 to 1.30.
VPC CNI, CoreDNS, and kube-proxy still on 1.29-compatible versions.
Intermittent pod creation failures: "failed to set up sandbox container network"
DNS resolution starts failing for some pods.
```

**Consequence:**
```
→ Version skew between control plane and add-ons causes subtle networking bugs
→ VPC CNI interacts with the EC2 API using version-specific assumptions
→ CoreDNS may have bug fixes required for the new k8s version
→ kube-proxy rules may not handle new network topology correctly
→ These failures are intermittent and hard to diagnose — symptoms look unrelated to the upgrade
```

**Correct approach:**
```
Immediately after control plane upgrade — before updating nodes:

  for ADDON in vpc-cni coredns kube-proxy; do
    LATEST=$(aws eks describe-addon-versions \
      --kubernetes-version 1.30 \
      --addon-name $ADDON \
      --query 'addons[0].addonVersions[0].addonVersion' \
      --output text)
    aws eks update-addon \
      --cluster-name prod-eks \
      --addon-name $ADDON \
      --addon-version $LATEST \
      --resolve-conflicts OVERWRITE
  done

The upgrade order is non-negotiable:
  1. Control plane → 2. Add-ons → 3. Node groups
```

---

## Mistake 10 — No Namespace ResourceQuota

**Symptom:**
```
The data engineering team runs a large Spark job in the analytics namespace.
The job requests 200 CPU cores — exhausting all cluster CPU.
The payments API pods in the payments namespace enter Pending state.
Payment processing is unavailable.
```

**Consequence:**
```
→ One team can accidentally (or deliberately) exhaust all cluster resources
→ Other teams' pods enter Pending state and cannot serve traffic
→ HPA cannot scale up other pods even during traffic spikes
→ Karpenter/CA provisions new nodes for the resource-hungry workload
   but also depletes the IP pool for the entire cluster
→ No cost attribution: impossible to track per-team AWS spend
```

**Correct approach:**
```
Apply ResourceQuota to every namespace:

  apiVersion: v1
  kind: ResourceQuota
  metadata:
    name: payments-quota
    namespace: payments
  spec:
    hard:
      requests.cpu:    "10"      # total CPU requests for all pods in namespace
      requests.memory: "20Gi"
      limits.cpu:      "20"
      limits.memory:   "40Gi"
      pods:            "100"     # max pods in this namespace
      services:        "20"

Check current ResourceQuota usage:
  kubectl get resourcequota -n payments -o yaml
  kubectl describe resourcequota payments-quota -n payments
  # Shows: used vs hard limit for each resource

Find namespaces without ResourceQuota:
  for NS in $(kubectl get namespaces -o name | grep -v "kube-\|amazon-\|cert-"); do
    NS_NAME=${NS#namespace/}
    QUOTA=$(kubectl get resourcequota -n $NS_NAME 2>/dev/null | wc -l)
    if [ "$QUOTA" -lt 2 ]; then
      echo "NO QUOTA: $NS_NAME"
    fi
  done
```

---

## Summary Table

| # | Mistake | Primary Consequence | Fix Summary |
|---|---|---|---|
| 1 | Public endpoint 0.0.0.0/0 | API server exploitable from internet | Private endpoint + VPN/DX for kubectl |
| 2 | Node instance profile for app pods | Compromised pod = full node IAM access | IRSA per ServiceAccount |
| 3 | No resource requests/limits | Noisy neighbour; pods starve each other | LimitRange + ResourceQuota per namespace |
| 4 | No PodDisruptionBudget | Node drain = all pods offline simultaneously | PDB minAvailable: 1 on every prod Deployment |
| 5 | Single AZ node group | AZ failure = entire cluster down | 3 AZ node groups + topology spread constraints |
| 6 | :latest image tag | Deploys don't happen; rollbacks are meaningless | Pin to SHA or semantic version tag |
| 7 | No health probes | Traffic to unhealthy pods; deadlocks undetected | All three probes on every container |
| 8 | CA without balance-similar-node-groups | All new nodes in one AZ; cross-AZ cost spike | `balance-similar-node-groups: "true"` |
| 9 | Skip add-on updates after upgrade | Version skew → intermittent networking failures | Update add-ons immediately after control plane |
| 10 | No namespace ResourceQuota | One team exhausts cluster CPU; other teams pending | ResourceQuota per namespace with CPU/memory caps |
