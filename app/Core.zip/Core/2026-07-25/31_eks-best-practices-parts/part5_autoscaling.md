# EKS Best Practices — Part 5: Autoscaling — Cluster and Pod

> **Autoscaling in EKS has two independent layers: pod scaling (HPA scales how many pod replicas run) and node scaling (Karpenter/CA scales how many EC2 nodes run). Both must be configured for the cluster to handle variable load without manual intervention.**

---

## The Two Scaling Layers

```
Traffic spike arrives →

  Layer 1: HPA detects CPU/memory above threshold
    → HPA creates more pod replicas
    → New pods go Pending (no nodes available)

  Layer 2: Karpenter/CA detects Pending pods
    → Provisions a new EC2 node to fit the pending pods
    → Pods become Running; service scales to meet demand

Traffic drops →

  Layer 1: HPA detects low CPU/memory
    → HPA reduces pod replicas (terminates excess pods)

  Layer 2: Karpenter detects underutilised nodes
    → Consolidates pods onto fewer nodes
    → Terminates empty/underutilised nodes
    → Cost reduces automatically

Both layers must be configured. HPA without node autoscaling = pods pending forever.
Node autoscaling without HPA = fixed replica count; nodes scale but pods don't.
```

---

## HPA: Horizontal Pod Autoscaler

### CPU-Based HPA (Built-In — No Extra Setup)

```yaml
# hpa.yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: payments-api-hpa
  namespace: payments
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: payments-api

  minReplicas: 3     # never go below 3 (ensures HA across 3 AZs)
  maxReplicas: 30    # upper bound on scaling; prevents runaway cost

  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70   # scale up when avg CPU across all pods > 70%
          # scale down when avg CPU < 70% × (1 - tolerance)
          # Default tolerance = 10% → scale down trigger ≈ 63%

  behavior:
    scaleUp:
      stabilizationWindowSeconds: 60    # wait 60s before scaling up again
      policies:
        - type: Percent
          value: 100                    # can double replica count per step
          periodSeconds: 60
    scaleDown:
      stabilizationWindowSeconds: 300   # wait 5 min before scaling down (prevents flapping)
      policies:
        - type: Pods
          value: 2                      # remove max 2 pods per step
          periodSeconds: 60
```

**Why minReplicas: 3 (not 1 or 2):**
```
With 1 replica: a pod restart = 100% downtime
With 2 replicas: one in each of 2 AZs; a single AZ failure = 50% capacity loss
With 3 replicas: one per AZ; an AZ failure = 67% capacity remains; service continues
The 3-AZ minimum is the production high-availability baseline.
```

### Memory-Based HPA

```yaml
metrics:
  - type: Resource
    resource:
      name: memory
      target:
        type: AverageValue
        averageValue: 400Mi   # scale up when avg memory per pod > 400Mi
```

**Warning about memory HPA:** Memory is not released back to the OS when freed in many runtimes (JVM, Go). Memory-based HPA can cause scale-up without corresponding scale-down. Use CPU for primary HPA; add memory as secondary if needed.

### Custom Metrics HPA with KEDA

KEDA (Kubernetes Event-Driven Autoscaling) enables scaling on SQS queue depth, Kafka lag, Prometheus metrics, and more.

```yaml
# keda-scaledobject.yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: payments-worker-scaler
  namespace: payments
spec:
  scaleTargetRef:
    name: payments-worker
  minReplicaCount: 1
  maxReplicaCount: 50
  triggers:
    - type: aws-sqs-queue
      metadata:
        queueURL: https://sqs.ap-northeast-1.amazonaws.com/123456789012/payments-orders
        queueLength: "10"         # scale up when > 10 messages per replica
        awsRegion: ap-northeast-1
      authenticationRef:
        name: keda-sqs-auth       # IRSA-based auth for KEDA to read SQS metrics
```

### HPA + ArgoCD: Prevent Replica Fights

```
Problem: HPA scales replicas to 7; Git says spec.replicas: 3
         ArgoCD syncs and resets replicas to 3 (fighting HPA)

Fix: in the ArgoCD Application spec:
  spec:
    ignoreDifferences:
      - group: apps
        kind: Deployment
        jsonPointers:
          - /spec/replicas   # ArgoCD stops watching this field
    syncPolicy:
      syncOptions:
        - RespectIgnoreDifferences=true  # ArgoCD stops resetting this field

Both settings are required:
  ignoreDifferences: don't SHOW the diff
  RespectIgnoreDifferences: don't RESET the value during sync
```

---

## Cluster Autoscaler

### How CA Works

```
CA watches for:
  Pending pods:     no node has enough resources → scale UP
  Underutilised:    nodes < N% utilised for > M minutes → scale DOWN

Scale-up trigger:
  Pod enters Pending state (not scheduling due to insufficient resources)
  CA calculates: which node group would fit this pod?
  CA increases the ASG desired count for that node group

Scale-down trigger:
  CA periodically checks all nodes
  Node is below scale-down-utilization-threshold for scale-down-unneeded-time
  CA drains the node (respecting PDBs) and terminates it
```

### Required Node Group Tags

```
For CA to discover and manage a node group, the ASG MUST have these tags:

  k8s.io/cluster-autoscaler/enabled:          "true"
  k8s.io/cluster-autoscaler/<CLUSTER_NAME>:   "owned"

Without these tags: CA ignores the node group entirely.
```

### CA Helm Configuration (Key Settings)

```yaml
# values.yaml for cluster-autoscaler Helm chart
autoDiscovery:
  clusterName: prod-eks

extraArgs:
  # Balance nodes across AZs (prevents all nodes landing in one AZ)
  balance-similar-node-groups: "true"

  # Allow nodes with system DaemonSet pods to scale down
  skip-nodes-with-system-pods: "false"

  # Wait before considering a new node for scale-down
  # (prevents removing a node that was just added)
  scale-down-delay-after-add: "2m"

  # Wait before considering scale-down of underutilised node
  scale-down-unneeded-time: "5m"

  # Node is a candidate for scale-down if it uses < 50% of requests
  scale-down-utilization-threshold: "0.5"

  # How CA selects which node group to expand
  # Options: random, most-pods, least-waste, price, priority
  expander: "least-waste"   # pick the node type that wastes least capacity

  # Prevents CA from reducing to fewer nodes than the min ASG size
  skip-nodes-with-local-storage: "false"
```

### IRSA Permissions for CA

```json
{
  "Effect": "Allow",
  "Action": [
    "ec2:DescribeInstances",
    "ec2:DescribeInstanceTypes",
    "ec2:DescribeImages",
    "ec2:DescribeLaunchTemplateVersions",
    "autoscaling:DescribeAutoScalingGroups",
    "autoscaling:DescribeAutoScalingInstances",
    "autoscaling:DescribeLaunchConfigurations",
    "autoscaling:DescribeScalingActivities",
    "autoscaling:SetDesiredCapacity",
    "autoscaling:TerminateInstanceInAutoScalingGroup",
    "eks:DescribeNodegroup"
  ],
  "Resource": "*"
}
```

---

## Karpenter: Recommended for Production Scale

### Why Karpenter Over Cluster Autoscaler

```
CA limitations:
  → Bound to ASGs: can only use instance types defined in the node group
  → Slow: scale-up can take 3-5 minutes (ASG → EC2 → join → pod scheduling)
  → Over-provisioning: often requests a node that's larger than needed

Karpenter advantages:
  → Directly provisions EC2 instances (no ASG)
  → Selects the exact instance type that fits the pending pod
  → Scale-up: 60 seconds from pending pod to running pod
  → Consolidation: automatically replaces multiple small nodes with one large node
  → Supports Spot and on-demand in the same NodePool
  → Better cost efficiency: no wasted capacity
```

### NodePool: Replaces CA Node Groups

```yaml
# nodepool.yaml
apiVersion: karpenter.sh/v1beta1
kind: NodePool
metadata:
  name: default
spec:
  template:
    metadata:
      labels:
        managed-by: karpenter
        cluster: prod-eks
    spec:
      nodeClassRef:
        name: default    # references EC2NodeClass below

      requirements:
        # Capacity type: try Spot first, fall back to on-demand
        - key: karpenter.sh/capacity-type
          operator: In
          values: ["spot", "on-demand"]

        # Architecture
        - key: kubernetes.io/arch
          operator: In
          values: ["amd64"]

        # Instance types: multiple families for Spot availability
        - key: node.kubernetes.io/instance-type
          operator: In
          values:
            - m5.xlarge
            - m5.2xlarge
            - m5a.2xlarge      # AMD; often cheaper Spot
            - m5n.2xlarge      # enhanced networking
            - r5.xlarge        # memory-optimised
            - r5.2xlarge

      # Taints for isolation (optional: separate node pool for specific workloads)
      # taints:
      #   - key: workload
      #     value: payments
      #     effect: NoSchedule

  # Node expiration: replace nodes older than 30 days (AMI freshness)
  limits:
    cpu: 1000          # maximum CPU across all Karpenter-managed nodes
    memory: 4000Gi

  disruption:
    consolidationPolicy: WhenUnderutilized  # consolidate if node is underutilised
    consolidateAfter: 30s                   # how long to wait before consolidating
    expireAfter: 720h                       # expire nodes after 30 days (forces AMI update)
```

### EC2NodeClass: Node Configuration

```yaml
# ec2nodeclass.yaml
apiVersion: karpenter.k8s.aws/v1beta1
kind: EC2NodeClass
metadata:
  name: default
spec:
  amiFamily: AL2023                        # Amazon Linux 2023 (EKS-optimised)
  role: "KarpenterNodeRole-prod-eks"       # IAM role for the node instances

  # Subnet discovery by tag
  subnetSelectorTerms:
    - tags:
        karpenter.sh/discovery: "prod-eks"   # matches the subnet tag set in Part 1

  # Security Group discovery by tag
  securityGroupSelectorTerms:
    - tags:
        karpenter.sh/discovery: "prod-eks"

  # EBS configuration (same as launch template in Part 2)
  blockDeviceMappings:
    - deviceName: /dev/xvda
      ebs:
        volumeSize: 50Gi
        volumeType: gp3
        iops: 3000
        throughput: 125
        encrypted: true
        kmsKeyID: "arn:aws:kms:ap-northeast-1:123456789012:key/abc-def-123"

  # User data for node bootstrap customisation (optional)
  # userData: |
  #   #!/bin/bash
  #   /etc/eks/bootstrap.sh prod-eks

  metadataOptions:
    httpEndpoint: enabled
    httpProtocolIPv6: disabled
    httpPutResponseHopLimit: 1      # IMDSv2 enforcement
    httpTokens: required            # IMDSv2 required
```

### Karpenter IRSA Permissions

```json
{
  "Effect": "Allow",
  "Action": [
    "ec2:RunInstances",
    "ec2:CreateLaunchTemplate",
    "ec2:CreateFleet",
    "ec2:DescribeInstances",
    "ec2:DescribeInstanceTypes",
    "ec2:DescribeSubnets",
    "ec2:DescribeSecurityGroups",
    "ec2:DescribeImages",
    "ec2:DescribeSpotPriceHistory",
    "ec2:TerminateInstances",
    "ec2:CreateTags",
    "iam:PassRole",
    "ssm:GetParameter",
    "pricing:GetProducts"
  ],
  "Resource": "*"
}
```

---

## VPA: Vertical Pod Autoscaler (Recommendation Mode)

```
VPA in recommendation mode watches actual pod resource usage and
suggests optimal requests/limits — without automatically changing them.

Use VPA recommendations to:
  → Right-size resource requests (avoid over-provisioning)
  → Identify OOM risk before it happens in production

VPA in auto mode:
  → Can automatically update resource requests
  → Causes pod restarts (eviction) when applying new values
  → Use CAREFULLY in production — unexpected restarts

Installation:
  kubectl apply -f https://github.com/kubernetes/autoscaler/releases/latest/download/vpa-v1-crd.yaml

VPA object:
  apiVersion: autoscaling.k8s.io/v1
  kind: VerticalPodAutoscaler
  metadata:
    name: payments-api-vpa
    namespace: payments
  spec:
    targetRef:
      apiVersion: apps/v1
      kind: Deployment
      name: payments-api
    updatePolicy:
      updateMode: "Off"   # recommendation only; no auto-updates
```
