# EKS Best Practices — Part 6: Add-ons — Version Management and Configuration

> **EKS add-ons are the critical infrastructure components that make the cluster work: networking (VPC CNI), DNS (CoreDNS), and network rules (kube-proxy). They must stay version-compatible with the control plane and be correctly configured for your cluster size.**

---

## Add-on Roles and Dependencies

```
Add-on                    What Breaks If It Fails                Version Coupling
──────────────────────────────────────────────────────────────────────────────────
VPC CNI (aws-node)        New pods cannot get IP addresses        Must match EKS version range
CoreDNS                   All service name DNS resolution fails   Must match EKS version range
kube-proxy                Node-level network rules stop working   Must match EKS version range
AWS Load Balancer Ctrl    No new ALBs/NLBs can be created         Independent; update separately
EBS CSI Driver            No new PersistentVolumes from EBS       Needs IRSA role
EFS CSI Driver            No new shared filesystem mounts         Needs IRSA role
```

**Version coupling rule:** After every EKS control plane version upgrade, immediately update VPC CNI, CoreDNS, and kube-proxy to versions compatible with the new control plane. Running mismatched versions causes networking instability.

---

## VPC CNI: Pod IP Management

### How VPC CNI Works

```
The aws-node DaemonSet runs on every node.
It manages ENI attachments and pre-allocates IPs for pods.

IP pre-allocation pool:
  Each node maintains a "warm" pool of IPs ready to assign to new pods.
  When a pod starts: an IP is taken from the warm pool immediately.
  The warm pool is then refilled asynchronously (a new IP is assigned to the ENI).

Why this matters:
  Too many warm IPs = subnet IP exhaustion (IPs held but unused)
  Too few warm IPs = pod startup delay (must wait for new IP assignment)
```

### VPC CNI Configuration (aws-node DaemonSet Environment Variables)

```bash
# View current VPC CNI configuration
kubectl get daemonset aws-node -n kube-system -o yaml | grep -A30 env

# Key environment variables and what to set them to:

WARM_IP_TARGET = 2        # Keep 2 spare IPs per node (after pods are using theirs)
                          # Good default for moderate-sized subnets
                          # Reduce to 1 for very small subnets (/23 or smaller)

MINIMUM_IP_TARGET = 3     # Always keep at least 3 IPs on a node, even when idle
                          # Prevents cold start delay when first pods land on a new node

WARM_ENI_TARGET = 1       # Keep 1 warm ENI per node (with a /28 prefix in prefix delegation mode)
                          # Set to 0 if IP exhaustion is a concern; but may slow pod startup

# Configure by patching the DaemonSet:
kubectl set env daemonset aws-node \
  -n kube-system \
  WARM_IP_TARGET=2 \
  MINIMUM_IP_TARGET=3 \
  WARM_ENI_TARGET=1
```

### Prefix Delegation: Double Pod Density

```
Normal mode:
  Each IP slot on an ENI = 1 IP address for 1 pod
  m5.2xlarge: 4 ENIs × 15 secondary IPs = 60 IPs - 4 (node) = 56 max pods

Prefix delegation mode:
  Each IP slot on an ENI = a /28 prefix = 16 IP addresses
  m5.2xlarge: 4 ENIs × 15 slots × 16 IPs = 960 IPs
  Practical max: ~240+ pods per node (limited by other factors)

When to enable prefix delegation:
  → Large clusters where subnet IP space is running low
  → Clusters with many small pods (microservices, sidecar-heavy workloads)
  → Clusters using instance types with few ENIs (t3, c5 series)

Enable prefix delegation:
  kubectl set env daemonset aws-node -n kube-system \
    ENABLE_PREFIX_DELEGATION=true \
    WARM_PREFIX_TARGET=1

Requirements:
  → VPC CNI version 1.11.0 or later
  → Subnet must have sufficient contiguous /28 blocks available
  → Nitro-based instance types only (most modern instance types)
```

### Diagnosing IP Exhaustion

```bash
# Check available IPs in each private subnet
for SUBNET in $(aws ec2 describe-subnets \
  --filters "Name=tag:kubernetes.io/role/internal-elb,Values=1" \
  --query 'Subnets[*].SubnetId' --output text); do
  
  aws ec2 describe-subnets \
    --subnet-ids $SUBNET \
    --query 'Subnets[0].{ID:SubnetId, AZ:AvailabilityZone, AvailableIPs:AvailableIpAddressCount}' \
    --output table
done

# Check how many IPs aws-node has allocated per node
kubectl get node -o json \
  | jq '.items[] | {
      name: .metadata.name,
      allocatedIPs: (.metadata.annotations["vpc.amazonaws.com/node-ip-allocated-count"] // "0")
    }'

# Signs of IP exhaustion:
# → Pods stuck in ContainerCreating
# → Events: "Failed to create pod sandbox: failed to set up sandbox container network"
# → Events: "add cmd: failed to assign an ip address to container"
```

---

## CoreDNS: Scaling and Configuration

### What CoreDNS Does

```
CoreDNS is the cluster-internal DNS server.
Every pod DNS query goes through CoreDNS:
  payments-api calls: http://orders-service.orders.svc.cluster.local
  → DNS query to CoreDNS → returns 10.100.45.23 (ClusterIP)
  → TCP connection established

Without CoreDNS working:
  ALL service-to-service communication by name fails
  Only direct IP-to-IP connections work (not usable in practice)
  This is a cluster-wide outage
```

### CoreDNS Scaling Rules

```bash
# Default deployment: 2 replicas — insufficient for > 20 nodes

# Scale CoreDNS based on cluster size:
# < 20 nodes:    2 replicas (default)
# 20-100 nodes:  4 replicas
# 100-300 nodes: 6 replicas
# > 300 nodes:   8 replicas + NodeLocal DNSCache

kubectl scale deployment coredns -n kube-system --replicas=4

# OR configure auto-scaling via cluster-proportional-autoscaler (dns-autoscaler):
# → Automatically scales CoreDNS based on node count
# → Helm chart: cluster-proportional-autoscaler
```

### CoreDNS Configuration: Reduce DNS Lookup Overhead

**The ndots problem:**
```
By default, pods have ndots=5 in /etc/resolv.conf.
This means: before treating a name as fully qualified, Kubernetes tries
5 different search path combinations first.

For a call to: api.external.com
Kubernetes tries (in order):
  1. api.external.com.payments.svc.cluster.local → NXDOMAIN
  2. api.external.com.svc.cluster.local          → NXDOMAIN
  3. api.external.com.cluster.local              → NXDOMAIN
  4. api.external.com.ap-northeast-1.compute.internal → NXDOMAIN
  5. api.external.com                            → SUCCESS

Each failed lookup is a round-trip to CoreDNS.
Result: 4 failed DNS lookups + 1 success = 5× the expected DNS traffic.
```

**Fix: reduce ndots in pod spec:**
```yaml
spec:
  template:
    spec:
      dnsPolicy: ClusterFirst
      dnsConfig:
        options:
          - name: ndots
            value: "2"    # reduces failed lookups from 4 to 1 for external names
          - name: timeout
            value: "5"
          - name: attempts
            value: "2"
```

### NodeLocal DNSCache: Required for High-Throughput Clusters

```
Problem NodeLocal DNSCache solves:
  DNS queries use UDP. Every DNS connection creates a conntrack table entry.
  A busy cluster with 100 pods × 100 DNS queries/second = 10,000 conntrack entries/second.
  The Linux conntrack table has a finite size (default: 131072 entries).
  When the table fills: DNS queries fail → ALL pod-to-pod communication breaks.

NodeLocal DNSCache solution:
  A DaemonSet runs a local DNS cache on each node (port 169.254.20.10).
  Pods query the local cache (same-node, no network hop).
  Cache serves responses immediately for known names.
  Only cache misses go to CoreDNS (vastly reduces CoreDNS traffic).
  Cache queries use TCP (not UDP) → no conntrack pressure.

Effect:
  → CoreDNS load reduces by 70-90%
  → conntrack table pressure eliminated
  → DNS latency reduces by 50-80% (local cache vs network round-trip)

Install:
  kubectl apply -f https://raw.githubusercontent.com/kubernetes/kubernetes/master/cluster/addons/dns/nodelocaldns/nodelocaldns.yaml
```

---

## Add-on Version Management

### Check Current Add-on Versions

```bash
CLUSTER_NAME="prod-eks"
REGION="ap-northeast-1"

# List all installed add-ons with current versions
aws eks list-addons \
  --cluster-name $CLUSTER_NAME \
  --region $REGION \
  --output text \
  | while read addon; do
      aws eks describe-addon \
        --cluster-name $CLUSTER_NAME \
        --addon-name $addon \
        --region $REGION \
        --query '{addon:addon.addonName, version:addon.addonVersion, status:addon.status}' \
        --output json
    done | jq '.'
```

### Find Compatible Add-on Versions

```bash
K8S_VERSION=$(aws eks describe-cluster \
  --name $CLUSTER_NAME \
  --query 'cluster.version' \
  --output text)

# Get available versions for a specific add-on
aws eks describe-addon-versions \
  --kubernetes-version $K8S_VERSION \
  --addon-name vpc-cni \
  --query 'addons[0].addonVersions[0:5].{version:addonVersion, default:compatibilities[0].defaultVersion}' \
  --output table
```

### Update Add-ons After Control Plane Upgrade

```bash
# After upgrading the EKS control plane version:
# Immediately update all three core add-ons to compatible versions

for ADDON in vpc-cni coredns kube-proxy; do
  LATEST=$(aws eks describe-addon-versions \
    --kubernetes-version $K8S_VERSION \
    --addon-name $ADDON \
    --query 'addons[0].addonVersions[0].addonVersion' \
    --output text)
  
  echo "Updating $ADDON to $LATEST"
  aws eks update-addon \
    --cluster-name $CLUSTER_NAME \
    --addon-name $ADDON \
    --addon-version $LATEST \
    --resolve-conflicts OVERWRITE \
    --region $REGION
done
```

---

## AWS Load Balancer Controller

```
The AWS Load Balancer Controller provisions ALBs and NLBs from Kubernetes objects.
It is NOT an EKS managed add-on — it's deployed via Helm.

Requires:
  → IRSA role with permissions to create/manage load balancers
  → Subnet tags (kubernetes.io/role/elb = "1") — see Part 1
  → Cluster tag on subnets (kubernetes.io/cluster/<name> = "owned")

IRSA permissions needed:
  elasticloadbalancing:CreateLoadBalancer
  elasticloadbalancing:CreateTargetGroup
  elasticloadbalancing:RegisterTargets
  ec2:DescribeVpcs
  ec2:DescribeSubnets
  ec2:DescribeSecurityGroups
  ... (full policy: https://raw.githubusercontent.com/kubernetes-sigs/aws-load-balancer-controller/main/docs/install/iam_policy.json)

Ingress annotation for ALB:
  annotations:
    kubernetes.io/ingress.class: alb
    alb.ingress.kubernetes.io/scheme: internet-facing
    alb.ingress.kubernetes.io/target-type: ip            # route to pod IPs directly
    alb.ingress.kubernetes.io/certificate-arn: arn:aws:acm:...
    alb.ingress.kubernetes.io/ssl-redirect: '443'
    alb.ingress.kubernetes.io/healthcheck-path: /health
```
