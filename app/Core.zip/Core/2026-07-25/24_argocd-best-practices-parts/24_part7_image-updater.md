# ArgoCD Best Practices — Part 7: Image Updater — Closing the CD Loop

> **Without Image Updater:** a new Docker image is built in CI but ArgoCD never knows — someone must manually edit the image tag in Git and push.
> **With Image Updater:** ArgoCD watches the container registry and writes back the new tag to Git automatically — closing the full CI→CD loop.

---

## The CD Gap Without Image Updater

```
WITHOUT Image Updater:
  CI builds image → pushes to ECR (tag: v2.4.1)
  ArgoCD: still deploying v2.4.0 (what's in Git)
  
  To deploy v2.4.1:
    Option A: manually edit overlays/prod/kustomization.yaml → set newTag: v2.4.1 → commit → push
    Option B: CI pipeline script: git pull → sed -i 's/v2.4.0/v2.4.1/' → git commit -m "..." → git push
    Option C: ask a human to log into ArgoCD and override the image tag
  
  Problems:
    → Manual edits are error-prone (wrong file, wrong tag, conflicts)
    → CI-triggered git commits create commit noise ("chore: bump image to v2.4.1" ×20/day)
    → No audit trail connecting the CI build to the Git change

WITH Image Updater:
  CI builds image → pushes to ECR (tag: v2.4.1)
  Image Updater polls ECR → detects v2.4.1 matches the configured update strategy
  Image Updater writes back to Git: kustomization.yaml newTag: v2.4.1
  ArgoCD detects the Git change → syncs → deploys v2.4.1
  
  Full loop: code push → CI build → registry → Image Updater Git commit → ArgoCD sync → deployed
  Time: ~3-5 minutes end-to-end
```

---

## Image Updater Installation

```bash
# Install via kubectl:
kubectl apply -n argocd -f \
  https://raw.githubusercontent.com/argoproj-labs/argocd-image-updater/stable/manifests/install.yaml

# OR via Helm:
helm repo add argo https://argoproj.github.io/argo-helm
helm upgrade --install argocd-image-updater argo/argocd-image-updater \
  --namespace argocd \
  --set config.argocd.serverAddress=https://argocd-server.argocd.svc.cluster.local \
  --set config.argocd.insecure=false \
  --set config.argocd.plaintext=false

# Verify it's running:
kubectl get pods -n argocd | grep image-updater
```

---

## Update Strategies

| Strategy | How Tag Is Chosen | Best For | Example |
|---|---|---|---|
| `semver` | Latest tag matching a semver constraint | Release-based workflows | `>=1.2.0 <2.0.0` |
| `latest` | Always the most recently pushed tag | Dev environments | Any latest tag |
| `name` | Alphabetically latest tag matching a regex | Custom naming schemes | `'^v.*'` |
| `digest` | Pins to exact image SHA, not tag | Maximum immutability | SHA: `sha256:abc123` |

---

## Full Application Annotation Setup (Kustomize + Git Write-back)

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: payment-api-staging
  namespace: argocd
  annotations:
    # List all images to track (format: alias=registry/repo)
    argocd-image-updater.argoproj.io/image-list: |
      payment-api=123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-api

    # Update strategy for the 'payment-api' alias
    argocd-image-updater.argoproj.io/payment-api.update-strategy: semver

    # Only consider tags matching this regex
    argocd-image-updater.argoproj.io/payment-api.allow-tags: '^v[0-9]+\.[0-9]+\.[0-9]+$'

    # Semver constraint: only minor/patch updates; never major version bump
    argocd-image-updater.argoproj.io/payment-api.semver-constraint: '>=1.0.0 <2.0.0'

    # Write the new tag back to Git (creates a commit)
    argocd-image-updater.argoproj.io/write-back-method: git

    # Which branch to commit to
    argocd-image-updater.argoproj.io/git-branch: main

    # Format of the commit message
    argocd-image-updater.argoproj.io/git-commit-message: |
      chore(image-updater): update payment-api to {{image_name}}:{{image_tag}}

    # For Kustomize: which parameter to update
    argocd-image-updater.argoproj.io/payment-api.kustomize.image-name: payment-api
```

---

## Write-Back Methods

### Method 1: Git Write-back (Recommended)

```yaml
# Image Updater commits the new tag directly to Git.
# This preserves the audit trail: Git history shows exactly when each tag was deployed.
# ArgoCD then detects the Git change and syncs normally.

argocd-image-updater.argoproj.io/write-back-method: git

# Required: Git credentials for writing back
# Configure in argocd-image-updater-config ConfigMap:
```

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: argocd-image-updater-config
  namespace: argocd
data:
  # Git credentials for write-back (SSH or HTTPS token)
  git.user: argocd-image-updater
  git.email: argocd-image-updater@company.com
  # The actual credential is stored in a Secret referenced by the Application's repo
```

### Method 2: ArgoCD Parameter Override (No Git Commit)

```yaml
# Image Updater overrides the image parameter in the Application spec directly.
# Does NOT commit to Git.
# Faster (no Git roundtrip) but: no Git audit trail, override visible in ArgoCD UI.
# Suitable for dev environments where commit noise is unwanted.

argocd-image-updater.argoproj.io/write-back-method: argocd
```

---

## Registry Access Configuration

### ECR (AWS)

```yaml
# argocd-image-updater-config ConfigMap
data:
  registries.conf: |
    registries:
    - name: AWS ECR
      api_url: https://123456789012.dkr.ecr.ap-northeast-1.amazonaws.com
      prefix: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com
      credentials: ext:/scripts/ecr-login.sh    # script returns "AWS:<token>"
      default: true
```

```bash
# ecr-login.sh (stored as a ConfigMap, mounted into the Image Updater pod)
#!/bin/bash
aws ecr get-login-password --region ap-northeast-1 | \
  awk '{print "AWS:" $0}'
```

```yaml
# Better: use IRSA (no stored credentials)
# Annotate the Image Updater ServiceAccount with the IRSA role:
kubectl annotate serviceaccount argocd-image-updater \
  -n argocd \
  eks.amazonaws.com/role-arn=arn:aws:iam::123456789012:role/ArgoCD-Image-Updater-Role

# IAM role policy needs:
# ecr:GetAuthorizationToken
# ecr:BatchCheckLayerAvailability
# ecr:DescribeImages
# ecr:ListImages
```

### Docker Hub / GHCR

```yaml
# Store credentials as a Secret:
kubectl create secret docker-registry registry-creds \
  --docker-server=https://index.docker.io/v1/ \
  --docker-username=myuser \
  --docker-password=mytoken \
  --namespace argocd

# Reference in Application annotations:
argocd-image-updater.argoproj.io/payment-api.pull-secret: |
  secret:argocd/registry-creds
```

---

## Kustomize Write-back: How It Works

```
Before Image Updater update:
  overlays/staging/kustomization.yaml:
    images:
      - name: payment-api
        newTag: v2.3.0

After Image Updater detects v2.4.1 in ECR:
  Image Updater creates a file: .argocd-source-payment-api-staging.yaml
  (in the same path as the Application's Kustomize source)
  Content:
    kustomize:
      images:
        - payment-api=123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-api:v2.4.1

  Image Updater commits this file to Git with the configured commit message.
  ArgoCD detects the commit → syncs → new tag deployed.
```

---

## Helm Write-back

```yaml
# For Helm-based Applications:
metadata:
  annotations:
    argocd-image-updater.argoproj.io/image-list: payment-api=myorg/payment-api
    argocd-image-updater.argoproj.io/payment-api.update-strategy: semver
    argocd-image-updater.argoproj.io/write-back-method: git

    # Tell Image Updater which Helm parameter to update:
    argocd-image-updater.argoproj.io/payment-api.helm.image-name: image.repository
    argocd-image-updater.argoproj.io/payment-api.helm.image-tag: image.tag
```

---

## Multi-Image Application

```yaml
# Application with multiple containers to track:
metadata:
  annotations:
    argocd-image-updater.argoproj.io/image-list: |
      api=myorg/payment-api,
      worker=myorg/payment-worker

    # Strategy per image:
    argocd-image-updater.argoproj.io/api.update-strategy: semver
    argocd-image-updater.argoproj.io/api.allow-tags: '^v[0-9]+\.[0-9]+\.[0-9]+$'

    argocd-image-updater.argoproj.io/worker.update-strategy: latest
    argocd-image-updater.argoproj.io/worker.allow-tags: '^latest$'
```

---

## Monitoring Image Updater

```bash
# Check Image Updater logs for update activity:
kubectl logs -n argocd deployment/argocd-image-updater --tail=100 -f

# Look for lines like:
# "Successfully updated image payment-api from v2.3.0 to v2.4.1"
# "Committed 1 image update(s) to Git"
# "Unable to fetch tags for image: ..." → registry access issue

# Check which tags Image Updater sees for an image:
argocd-image-updater tag list 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-api \
  --credentials registries-ecr
```

---

## Common Image Updater Mistakes

| Mistake | Consequence | Fix |
|---|---|---|
| `write-back-method: argocd` in production | No Git audit trail; tag overrides lost on ArgoCD restart | Use `git` write-back in production; `argocd` only in dev |
| `update-strategy: latest` in production | Any push to `:latest` tag auto-deploys to production | Use `semver` with constraint in production; `latest` only in dev |
| No `allow-tags` regex | Image Updater picks up test/RC tags (e.g. `v1.0.0-rc1`) | Set `allow-tags: '^v[0-9]+\.[0-9]+\.[0-9]+$'` to allow only stable releases |
| No IRSA for ECR access | Image Updater uses stored credentials that expire | Use IRSA (node IAM role or ServiceAccount annotation) for ECR auth |
| Image Updater commits to protected branch | Git push rejected; Image Updater silently stops working | Use a deployment branch or configure branch protection exceptions for the Image Updater bot user |
