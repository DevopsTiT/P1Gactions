# ArgoCD Best Practices — Part 4: Sync Waves and Hooks — Ordering Within a Sync

> **Without ordering:** all resources apply simultaneously — CRDs created after the CR that references them, Secrets after the Deployment that mounts them → sync fails.
> **With sync waves + hooks:** explicit ordering ensures dependencies are healthy before dependents apply.

---

## Why Ordering Matters

```
Without waves: ArgoCD applies all resources in a single batch.
Kubernetes processes them in the order it receives them.
This causes races:

Race 1: CRD vs CR
  CRD for "PrometheusRule" is applied at same time as a PrometheusRule CR.
  If CRD isn't registered yet: CR creation fails ("no kind PrometheusRule").

Race 2: Secret vs Deployment
  Deployment references a Secret by name.
  Secret applied after Deployment: pod starts with missing Secret → CrashLoopBackOff.
  Even if Secret arrives 5 seconds later, the pod is already in a crash loop.

Race 3: DB migration vs app deployment
  New application version requires a DB schema migration.
  Deployment and migration job apply simultaneously.
  App pods start before migration completes → DB schema mismatch → 500 errors.

With sync waves + hooks:
  Resources are grouped into waves.
  Wave N applies only after ALL resources in wave N-1 are Healthy.
  Hooks run at specific lifecycle events (PreSync, PostSync).
```

---

## Sync Wave Mechanics

```
Wave execution order:
  ─────────────────────────────────────────────────────────
  Wave -5  → applied first; must be Healthy before wave -4 starts
  Wave -4
  ...
  Wave 0   → DEFAULT wave (no annotation = wave 0)
  ...
  Wave 5
  Wave 10  → applied last
  ─────────────────────────────────────────────────────────

"Healthy" means:
  For Deployments: all desired pods are Available
  For Jobs: all pods completed successfully
  For Services: created (Services are always considered Healthy immediately)

Wave progression:
  ArgoCD applies Wave -5 → waits → all Healthy? → applies Wave 0 → waits → all Healthy? → etc.
  If ANY resource in wave N is Degraded: sync stops; later waves do not apply.
```

---

## Recommended Wave Assignments

```
Wave -5:  Namespaces, CRDs, PersistentVolumeClaims
          (cluster-level prerequisites; everything else depends on these)

Wave -1:  Secrets, ConfigMaps
          (pods need these to start; mount failures cause CrashLoopBackOff)
          Note: default wave is 0; using -1 explicitly for config is optional

Wave 0:   (default — no annotation needed)
          RBAC resources, ServiceAccounts, Services
          ConfigMaps and Secrets if you prefer keeping wave 0 default

Wave 1:   Deployments, StatefulSets, DaemonSets
          (workloads; start after their config is present)

Wave 5:   Ingresses, HPA, PodDisruptionBudgets
          (routing and scaling rules; configured after pods are healthy)

Wave 10:  Integration smoke-test Jobs, cache-warm Jobs
          (verification steps after everything is deployed and healthy)
```

---

## Setting Wave Annotations

```yaml
# Set sync wave on a Namespace (must apply before anything inside it)
apiVersion: v1
kind: Namespace
metadata:
  name: payments-prod
  annotations:
    argocd.argoproj.io/sync-wave: "-5"

---
# Set sync wave on a Secret (must exist before Deployment mounts it)
apiVersion: v1
kind: Secret
metadata:
  name: db-credentials
  namespace: payments-prod
  annotations:
    argocd.argoproj.io/sync-wave: "-1"
type: Opaque
data:
  password: <base64>

---
# Deployment in default wave 0 — starts after wave -1 Secrets are present
apiVersion: apps/v1
kind: Deployment
metadata:
  name: payment-api
  namespace: payments-prod
  # No sync-wave annotation = wave 0 (default)
spec:
  ...

---
# HPA in wave 5 — only after Deployment is Healthy (Running pods)
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: payment-api-hpa
  namespace: payments-prod
  annotations:
    argocd.argoproj.io/sync-wave: "5"
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: payment-api
  minReplicas: 3
  maxReplicas: 10
```

---

## Hook Types

| Hook | When It Runs | Typical Use | Blocks sync until |
|---|---|---|---|
| `PreSync` | BEFORE any resource is applied | DB migration, backup, drain | Job completes (Success or Failure) |
| `Sync` | DURING the sync alongside wave resources | Rarely used directly | Job completes |
| `PostSync` | AFTER all resources reach Healthy | Smoke tests, cache warm, notification | Job completes |
| `SyncFail` | IF the sync fails | Rollback script, failure alert | Job completes |
| `PostDelete` | AFTER the Application is deleted | Cleanup external resources, DNS records | Job completes |

---

## PreSync Hook: DB Migration

```yaml
# This Job runs BEFORE any Deployment is applied.
# ArgoCD waits for the Job to complete successfully before applying wave 0+.
# If the Job fails → sync stops → Deployments do NOT update → old version stays running.

apiVersion: batch/v1
kind: Job
metadata:
  name: payment-db-migrate
  namespace: payments-prod
  annotations:
    argocd.argoproj.io/hook: PreSync
    argocd.argoproj.io/hook-delete-policy: HookSucceeded
    # HookSucceeded: delete the Job when it completes successfully
    # (keeps namespace clean; failed Jobs are kept for debugging)
spec:
  backoffLimit: 3           # retry up to 3 times before marking failed
  activeDeadlineSeconds: 300 # fail if migration takes > 5 minutes
  template:
    spec:
      restartPolicy: OnFailure
      serviceAccountName: migration-runner
      containers:
      - name: migrate
        image: myorg/payment-api:v2.4.1   # same image as the app
        command: ["/app/migrate", "--direction=up"]
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: db-credentials
              key: url
```

### hook-delete-policy Values

```yaml
# Controls when the hook resource is deleted after it finishes:

argocd.argoproj.io/hook-delete-policy: HookSucceeded
# Delete ONLY when the hook Job succeeds.
# Failed Jobs are KEPT → allows debugging failed migrations.
# RECOMMENDED: use this always.

argocd.argoproj.io/hook-delete-policy: HookFailed
# Delete ONLY when the hook Job fails.
# Successful Jobs are kept (clutters namespace).

argocd.argoproj.io/hook-delete-policy: BeforeHookCreation
# Delete the OLD hook Job before creating a new one on the next sync.
# Useful when you always want a fresh Job, regardless of last outcome.

# NOT SETTING THIS AT ALL:
# Hook Job stays in namespace forever.
# After 10 syncs: 10 Jobs cluttering the namespace.
# Always set hook-delete-policy.
```

---

## PostSync Hook: Smoke Test

```yaml
# Runs AFTER all resources are Healthy.
# If this Job fails: ArgoCD marks the sync as SyncFailed (even though resources are healthy).
# Useful for catching: app starts but returns 500, health endpoint broken.

apiVersion: batch/v1
kind: Job
metadata:
  name: payment-smoke-test
  namespace: payments-prod
  annotations:
    argocd.argoproj.io/hook: PostSync
    argocd.argoproj.io/hook-delete-policy: HookSucceeded
    argocd.argoproj.io/sync-wave: "10"   # run last within PostSync
spec:
  backoffLimit: 1
  activeDeadlineSeconds: 120
  template:
    spec:
      restartPolicy: Never
      containers:
      - name: smoke-test
        image: curlimages/curl:8.0
        command:
          - /bin/sh
          - -c
          - |
            set -e
            echo "Testing /health endpoint..."
            curl -sf http://payment-api.payments-prod.svc.cluster.local:8080/health
            echo "Testing /ready endpoint..."
            curl -sf http://payment-api.payments-prod.svc.cluster.local:8080/ready
            echo "All smoke tests passed."
```

---

## SyncFail Hook: Failure Notification

```yaml
# Runs ONLY when the sync fails (any resource errors out, or a hook fails).
# Use for: alerting, automatic rollback trigger, incident ticket creation.

apiVersion: batch/v1
kind: Job
metadata:
  name: sync-fail-notify
  namespace: payments-prod
  annotations:
    argocd.argoproj.io/hook: SyncFail
    argocd.argoproj.io/hook-delete-policy: HookSucceeded
spec:
  template:
    spec:
      restartPolicy: Never
      containers:
      - name: notify
        image: curlimages/curl:8.0
        env:
        - name: SLACK_WEBHOOK
          valueFrom:
            secretKeyRef:
              name: slack-credentials
              key: webhook-url
        command:
          - /bin/sh
          - -c
          - |
            curl -X POST "$SLACK_WEBHOOK" \
              -H "Content-Type: application/json" \
              -d '{"text":":red_circle: ArgoCD sync FAILED for payment-api-prod"}'
```

---

## Combining Waves and Hooks

```
Full sync timeline for a production deploy:

PreSync hook (wave 0):
  → Job: payment-db-migrate   ← DB migration runs first; blocks everything else
  ArgoCD waits for Job SUCCESS before proceeding.

Sync wave -5:
  → Namespace: payments-prod  ← ensure namespace exists

Sync wave -1:
  → Secret: db-credentials    ← ensure secrets are present
  → ConfigMap: payment-config

Sync wave 0 (default):
  → Deployment: payment-api   ← pods start after Secrets are present
  → Service: payment-api
  ArgoCD waits for Deployment to be Healthy (all pods Available).

Sync wave 5:
  → HPA: payment-api-hpa      ← scaling rules applied after pods are running
  → Ingress: payment-api

Sync wave 10:
  → (nothing; PostSync hook handles smoke tests)

PostSync hook:
  → Job: payment-smoke-test   ← runs after everything is Healthy
  If smoke test fails → sync marked SyncFailed → SyncFail hook triggers Slack alert

Total sync time: ~3-5 minutes (migration 1 min, pods start 1-2 min, smoke test 30s)
```

---

## Troubleshooting Stuck Syncs

```bash
# Check what is blocking the sync:
argocd app get <app-name>
# Look for: SyncStatus, OperationState

# View all resources and their sync state:
argocd app resources <app-name>

# A hook Job is failing and blocking the sync:
kubectl logs -n <namespace> job/<hook-job-name>
# Fix the hook Job → push fix to Git → re-sync

# Sync is stuck because a hook is running and hasn't finished:
argocd app terminate-op <app-name>
# This kills the current sync operation
# Then: fix the hook → push to Git → argocd app sync <app-name>

# Check if a wave is waiting for a Deployment to become Healthy:
kubectl get deployment <dep-name> -n <namespace>
kubectl get pods -n <namespace> | grep <dep-name>
# If pods are Pending or CrashLoopBackOff → fix the pods → wave can proceed
```

---

## Common Wave and Hook Mistakes

| Mistake | Consequence | Fix |
|---|---|---|
| No `hook-delete-policy` | Hook Jobs pile up; namespace clutter; future hooks may conflict with old Jobs | Always set `argocd.argoproj.io/hook-delete-policy: HookSucceeded` |
| Waves on every single resource | Every resource waits serially → sync takes 10+ minutes | Only use waves for genuine ordering dependencies |
| DB migration in PostSync instead of PreSync | New app version deploys before DB schema is ready → errors in production | DB migrations: always PreSync |
| No `activeDeadlineSeconds` on hook Jobs | A stuck migration holds the sync indefinitely | Always set a timeout: `activeDeadlineSeconds: 300` |
| SyncFail hook also fails | The failure notification fails silently | Make SyncFail hooks simple and robust; use a reliable HTTP endpoint |
| Hook job references a Secret that doesn't exist yet | PreSync hook fails before migration can even start | Use sync wave -5 on Secrets to ensure they exist before PreSync hooks run |
