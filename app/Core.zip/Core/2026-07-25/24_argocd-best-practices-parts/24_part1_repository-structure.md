# ArgoCD Best Practices — Part 1: Repository Structure

> **Without structure:** any developer can push any manifest to any repo, and ArgoCD syncs it everywhere — no blast radius control, no review gate.
> **With structure:** each team owns a specific path; AppProject restricts what ArgoCD will read from where.

---

## Why Repository Structure Matters

```
ArgoCD reads manifests from Git and applies them to clusters.
If structure is absent:
  → Any engineer can modify any namespace's deployment
  → A typo in a shared base breaks all environments simultaneously
  → No clear ownership; impossible to audit "who deployed what"
  → Rollback is unclear (which path represents which environment?)

If structure is enforced:
  → Each path maps to exactly one Application (env + namespace + team)
  → Base changes require review; overlay changes only affect that environment
  → AppProject prevents Application A from reading Application B's path
  → git log on a specific path = complete audit trail for that environment
```

---

## Pattern 1: Monorepo (Single Repo, All Teams)

```
gitops-monorepo/
├── apps/
│   ├── payments/
│   │   ├── base/                   ← shared manifests (same for all envs)
│   │   │   ├── deployment.yaml
│   │   │   ├── service.yaml
│   │   │   └── kustomization.yaml
│   │   └── overlays/
│   │       ├── dev/
│   │       │   ├── kustomization.yaml    ← patches: image tag, replicas, env vars
│   │       │   └── config-patch.yaml
│   │       ├── staging/
│   │       │   ├── kustomization.yaml
│   │       │   └── resource-patch.yaml
│   │       └── prod/
│   │           ├── kustomization.yaml
│   │           └── resource-patch.yaml
│   │
│   ├── notifications/
│   │   ├── base/
│   │   └── overlays/
│   │       ├── dev/
│   │       ├── staging/
│   │       └── prod/
│   │
│   └── platform/                   ← SRE-owned infra (prometheus, ingress, cert-manager)
│       ├── base/
│       └── overlays/
│           └── prod/
│
└── bootstrap/                      ← App-of-Apps root (see Pattern 3)
    ├── apps-dev.yaml
    ├── apps-staging.yaml
    └── apps-prod.yaml
```

### Monorepo: ArgoCD Application pointing to an overlay

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: payments-prod
  namespace: argocd
spec:
  project: payments
  source:
    repoURL: https://github.com/myorg/gitops-monorepo
    targetRevision: main
    path: apps/payments/overlays/prod    # ← exact overlay path
  destination:
    server: https://kubernetes.default.svc
    namespace: payments-prod
  syncPolicy:
    syncOptions:
      - CreateNamespace=true
      - ApplyOutOfSyncOnly=true
```

### Monorepo: Pros and Cons

```
PROS:
  + Single PR changes both base and overlay → one review covers the full change
  + Easy to make cross-cutting changes (bump base image for all envs in one PR)
  + Simple repository management (one set of branch protections, one CI pipeline)

CONS:
  - Merge conflicts when many teams work simultaneously
  - A broken base/kustomization.yaml can fail multiple teams' Applications
  - CODEOWNERS required to prevent Team A from editing Team B's path
  - Repository grows large; git clone is slower

Best for: Small to medium organizations (≤ 20 teams), single product
```

---

## Pattern 2: Per-Team Repo (Federated)

```
payments-gitops/           ← owned by payments team
├── base/
│   ├── deployment.yaml
│   ├── service.yaml
│   └── kustomization.yaml
└── overlays/
    ├── dev/
    │   └── kustomization.yaml
    ├── staging/
    │   └── kustomization.yaml
    └── prod/
        └── kustomization.yaml

notifications-gitops/      ← owned by notifications team
├── base/
└── overlays/
    ├── dev/
    ├── staging/
    └── prod/

platform-gitops/           ← owned by SRE team
├── base/
└── overlays/
    └── prod/
```

### Per-Team Repo: AppProject restricts which repo each project can use

```yaml
apiVersion: argoproj.io/v1alpha1
kind: AppProject
metadata:
  name: payments
  namespace: argocd
spec:
  sourceRepos:
    - 'https://github.com/myorg/payments-gitops'   # ← ONLY this repo
    # payments team CANNOT use notifications-gitops or platform-gitops
  destinations:
    - namespace: payments-*
      server: https://kubernetes.default.svc
```

### Per-Team Repo: Pros and Cons

```
PROS:
  + Blast radius isolated: payments team cannot accidentally affect notifications
  + Independent CI/CD pipelines per team (no waiting on each other)
  + Clearer ownership; CODEOWNERS is the entire repo
  + Smaller repos = faster clones, simpler history

CONS:
  - Cross-cutting changes require PRs in multiple repos
  - Platform team must coordinate base changes with each team's overlay
  - More ArgoCD Applications to manage (one per repo per environment)

Best for: Large organizations (20+ teams), compliance environments, regulated industries
```

---

## Pattern 3: App-of-Apps (Bootstrap Root)

```
A root Application whose source is a directory of Application CRDs.
Syncing the root creates all child Applications.
Child Applications then sync their own workloads.

Structure:
  bootstrap/
  ├── applications/
  │   ├── payments-dev.yaml      ← Application CRD pointing to payments/overlays/dev
  │   ├── payments-staging.yaml
  │   ├── payments-prod.yaml
  │   ├── notifications-dev.yaml
  │   └── platform-prod.yaml
  └── root-app.yaml              ← The root Application (bootstrap/applications/)
```

```yaml
# root-app.yaml — the single app you apply manually once to bootstrap everything
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: root-app
  namespace: argocd
spec:
  project: platform
  source:
    repoURL: https://github.com/myorg/gitops-monorepo
    targetRevision: main
    path: bootstrap/applications      # watches this directory
  destination:
    server: https://kubernetes.default.svc
    namespace: argocd
  syncPolicy:
    automated:
      selfHeal: true
      prune: false    # ← CRITICAL: never auto-prune on root app
                      # Deleting a child Application YAML would cascade-delete all its resources
```

### App-of-Apps: Rules

```
Rule 1: Root app MUST have prune: false (or no prune at all)
  → Reason: if you delete payments-prod.yaml from the repo,
    ArgoCD with prune would delete the payments-prod Application,
    which would then delete all payment pods/services/PVCs in production

Rule 2: Root app source path contains ONLY Application CRDs — never workload manifests
  → Mixing Application CRDs with Deployments causes ordering confusion

Rule 3: Use sync waves to order child Application creation
  → Namespaces and CRDs in wave -5, Applications in wave 0
  → Prevents the child app from syncing before its namespace exists

Rule 4: One root app per cluster (or one per environment: root-dev, root-staging, root-prod)
```

---

## Pattern 4: ApplicationSet (Dynamic Generation)

```
Instead of writing one Application YAML per environment/team manually,
ApplicationSet generates them from a template + generator.

Structure:
  bootstrap/
  └── applicationsets/
      ├── payments-appset.yaml      ← generates dev + staging + prod Applications
      └── platform-appset.yaml

A single ApplicationSet for payments team replaces 3 Application YAMLs (dev/staging/prod).
```

```yaml
# payments-appset.yaml
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: payments
  namespace: argocd
spec:
  generators:
    - list:
        elements:
          - env: dev
            namespace: payments-dev
            server: https://kubernetes.default.svc
          - env: staging
            namespace: payments-staging
            server: https://kubernetes.default.svc
          - env: prod
            namespace: payments-prod
            server: https://prod-cluster.company.internal
  template:
    metadata:
      name: 'payments-{{env}}'
    spec:
      project: payments
      source:
        repoURL: https://github.com/myorg/payments-gitops
        targetRevision: main
        path: 'overlays/{{env}}'
      destination:
        server: '{{server}}'
        namespace: '{{namespace}}'
      syncPolicy:
        automated:
          selfHeal: true
          prune: '{{env}}' != 'prod'    # auto-prune dev/staging; manual for prod
```

---

## Kustomize Overlay Best Practices

```yaml
# overlays/prod/kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

resources:
  - ../../base              # always reference base by relative path

namespace: payments-prod    # override namespace for all resources in this overlay

images:
  - name: myorg/payment-api
    newTag: v2.4.1          # pinned tag — NOT latest; updated by CI or Image Updater

patches:
  - target:
      kind: Deployment
      name: payment-api
    patch: |
      - op: replace
        path: /spec/replicas
        value: 3            # prod gets 3 replicas; base has 1
  - target:
      kind: Deployment
      name: payment-api
    patch: |
      - op: replace
        path: /spec/template/spec/containers/0/resources/limits/memory
        value: "1Gi"        # prod gets more memory than dev

configMapGenerator:
  - name: payment-config
    literals:
      - LOG_LEVEL=info       # prod is info; dev overlay sets debug
      - DB_HOST=prod-db.internal
    options:
      disableNameSuffixHash: true   # stable name (no hash suffix); avoids unnecessary rollouts
```

---

## Helm Values Overlay Best Practices

```
For Helm-based applications, use values files per environment:

helm-chart/
├── Chart.yaml
├── templates/
│   └── ...
└── values/
    ├── values.yaml          ← base defaults
    ├── values-dev.yaml      ← dev overrides (small replicas, debug logs)
    ├── values-staging.yaml  ← staging overrides
    └── values-prod.yaml     ← prod overrides (HA replicas, resource limits)
```

```yaml
# Application using Helm with environment-specific values file
spec:
  source:
    repoURL: https://github.com/myorg/payments-gitops
    targetRevision: main
    path: helm-chart
    helm:
      valueFiles:
        - values/values.yaml           # base first
        - values/values-prod.yaml      # env-specific overrides on top
      parameters:
        - name: image.tag
          value: v2.4.1               # can also override individual params
```

---

## Comparison Table

| Pattern | Pros | Cons | Best For |
|---|---|---|---|
| Monorepo | Single PR for cross-env changes; easy to manage | Merge conflicts at scale; one broken base = all teams affected | Small–medium orgs (≤ 20 teams) |
| Per-team repo | Isolated blast radius; independent ownership | Cross-cutting changes need multiple PRs | Large orgs, regulated industries |
| App-of-Apps | Bootstrap entire cluster from one root apply | One bad commit in bootstrap breaks everything if prune is on | Platform teams managing cluster addons |
| ApplicationSet | Generates all apps dynamically; no manual Application YAML per env | More complex YAML; harder to debug individual app issues | Multi-cluster, many environments, many teams |

---

## Common Mistakes in Repository Structure

| Mistake | Consequence | Fix |
|---|---|---|
| `targetRevision: HEAD` without branch protection | Any commit to main immediately syncs to prod | Use `targetRevision: main` with required reviews on main branch |
| Storing environment-specific secrets in Git plaintext | Credentials visible to anyone with repo access | Use Sealed Secrets, External Secrets Operator, or Vault + ESO |
| Root app-of-apps with `prune: true` | Deleting an Application YAML deletes all its live resources | Disable prune on the root app; enable only on leaf apps |
| Base and overlay in same directory | Cannot apply different configs per environment | Always separate: `base/` contains shared; `overlays/<env>/` contains env-specific |
| One Application covering multiple teams' paths | Single Application RBAC cannot grant per-team access | One Application per team per environment; use AppProject for RBAC |
