# ArgoCD Best Practices — Part 0: E2E Flow, Decision Tree & Tool Map

> **Core rule:** Git is the ONLY source of truth. No `kubectl apply` outside ArgoCD in production. Every change is a Git commit — reviewed, auditable, and reversible.

---

## E2E Flow Summary

```
1. ALWAYS-ON FOUNDATIONS
   → Git repo is the ONLY source of truth (no kubectl apply outside ArgoCD)
   → One ArgoCD instance per cluster (or multi-cluster with hub-spoke model)
   → RBAC defined in argocd-rbac-cm; SSO integrated via Dex or OIDC
   → AppProject per team — restricts source repos, destination clusters, resource kinds
   → Notifications controller watching all Applications for sync/health changes

2. DAILY (automated)
   → ArgoCD polls Git every 3 min (default) or receives webhook push event
   → Sync triggered automatically (auto-sync) or manually by operator
   → Resource health assessed: Healthy / Progressing / Degraded / Missing
   → Automated self-healing kicks in if live state drifts from desired state
   → Audit trail: every sync recorded with Git commit SHA + timestamp

3. WHEN ALERT FIRES ("Application OutOfSync / Degraded")
   → Check ArgoCD UI: Application → Events + Conditions
   → argocd app diff <name>          → see exact diff between Git and live cluster
   → argocd app sync <name> --dry-run → confirm what would change
   → argocd app sync <name> --prune   → if orphaned resources block sync
   → If hook failure: argocd app terminate-op <name> then re-sync

4. PROMOTION / DEPLOY CYCLE
   → Dev:     PR merged → auto-sync to dev namespace
   → Staging: tag or overlay promotion → auto-sync to staging
   → Prod:    PR approval + manual sync gate (selfHeal: true, automated: false)
   → Rollback: argocd app rollback <name> <revision-id>

5. MONTHLY REVIEW
   → Rotate ArgoCD admin password and API tokens
   → Review AppProject source/dest allow-lists for stale entries
   → Audit RBAC roles — remove unused service account bindings
   → Check ArgoCD upgrade path (releases ~every 2 months)

6. ROLLBACK / REGRESSION
   → argocd app history <name>         → pick last-known-good revision
   → argocd app rollback <name> <id>   → pins to that Git SHA
   → After fix: argocd app sync <name> → return to HEAD
```

---

## Decision Tree

```
"Why is my ArgoCD Application not healthy?"
│
├─ Is the app shown in ArgoCD UI?
│   ├─ NO → app not created yet
│   │       kubectl apply -f application.yaml  OR  argocd app create ...
│   │
│   └─ YES → What is the sync status?
│            │
│            ├─ OutOfSync
│            │   ├─ Is auto-sync enabled?
│            │   │   ├─ YES → check sync wave / hook failures blocking the sync
│            │   │   │        argocd app sync <name> --dry-run to see what it would do
│            │   │   └─ NO  → manual trigger: argocd app sync <name>
│            │   │
│            │   └─ Does diff show unexpected changes?
│            │       ├─ Drift from live → self-heal disabled?
│            │       │   YES → enable syncPolicy.automated.selfHeal: true
│            │       │   NO  → sync manually: argocd app sync <name>
│            │       │
│            │       └─ Orphaned resources blocking sync
│            │           → add --prune flag: argocd app sync <name> --prune
│            │
│            └─ Synced → What is the health status?
│                 │
│                 ├─ Healthy
│                 │   → Check if notifications are noisy (false alarm / flapping)
│                 │
│                 ├─ Progressing
│                 │   → Deployment/Rollout not finished
│                 │   → Wait OR check pod logs: kubectl logs -n <ns> ...
│                 │   → Is it stuck Progressing for > 10 min?
│                 │     → check if pods are Pending/CrashLoopBackOff
│                 │
│                 ├─ Degraded
│                 │   ├─ CrashLoopBackOff / ImagePullBackOff
│                 │   │   → fix image/config in Git → push → re-sync
│                 │   ├─ Hook Job failed
│                 │   │   → argocd app terminate-op <name>
│                 │   │   → fix hook manifest in Git → re-sync
│                 │   └─ Custom health check returning Degraded
│                 │       → review Lua health check script in argocd-cm
│                 │
│                 └─ Missing
│                     ├─ Resource deleted outside ArgoCD
│                     │   → re-sync (with selfHeal enabled, auto-recovered)
│                     └─ Namespace missing
│                         → add namespace creation to Application or cluster bootstrap
```

---

## Tool Map

| Tool | What It Does | When to Use | Cadence |
|---|---|---|---|
| `argocd app list` | Shows all apps + sync/health status | Morning health check | Daily |
| `argocd app diff` | Diff Git state vs live cluster | Before sync in prod | Per deploy |
| `argocd app sync` | Triggers sync for one app | Manual deploys, recovery | Per incident |
| `argocd app rollback` | Pins app to a past Git revision | Prod regression | Per incident |
| `argocd app history` | Lists all past sync revisions | Finding last-good SHA | Per incident |
| `argocd app terminate-op` | Kills stuck sync/hook operation | Hook failure unblocking | Per incident |
| `argocd app set` | Patches app config in-place | Quick param override | Ad-hoc |
| `argocd proj list` | Lists all AppProjects | RBAC/tenant audit | Monthly |
| `argocd account list` | Lists local accounts | Access review | Monthly |
| `argocd admin export` | Full backup of ArgoCD state | Before upgrade | Per upgrade |
| `kubectl -n argocd logs` | Raw ArgoCD component logs | Deep debug | Per incident |

---

## First-Responder Commands (copy-paste)

```bash
# 1. Health of all applications
argocd app list

# 2. Detailed status of one app
argocd app get <app-name>

# 3. What is the exact diff between Git and live?
argocd app diff <app-name>

# 4. What would a sync do? (dry run — no changes)
argocd app sync <app-name> --dry-run

# 5. Trigger manual sync
argocd app sync <app-name>

# 6. Trigger sync and allow pruning of orphaned resources
argocd app sync <app-name> --prune

# 7. Kill a stuck sync/hook operation
argocd app terminate-op <app-name>

# 8. Show all past sync revisions
argocd app history <app-name>

# 9. Roll back to a specific past revision
argocd app rollback <app-name> <revision-id>

# 10. Deep debug: ArgoCD component logs
kubectl logs -n argocd deployment/argocd-application-controller --tail=100
kubectl logs -n argocd deployment/argocd-repo-server --tail=100
kubectl logs -n argocd deployment/argocd-server --tail=100
```

---

## Promotion Workflow (Dev → Staging → Prod)

```
Trigger: developer merges PR to main

Dev (automatic):
  Git push → webhook hits ArgoCD → auto-sync → pods updated in dev namespace
  Time: ~30 seconds from push to deployed

Staging (automatic with window):
  CI/CD updates staging overlay (kustomization.yaml image tag or values.yaml)
  Git push → ArgoCD auto-sync during business hours sync window
  Time: ~1-2 minutes

Production (manual gate):
  Operator reviews diff: argocd app diff payment-api-prod
  Operator triggers: argocd app sync payment-api-prod
  OR: GitOps PR approval in GitHub → auto-sync (if allowed by syncWindow)
  Time: human-dependent (5-30 min for review + approval)

Rollback (any env):
  argocd app history payment-api-prod
  → REVISION  DATE                    DEPLOYED TO
    4         2026-07-25T10:00:00Z    prod (current)
    3         2026-07-24T15:00:00Z    prod (last good)
  
  argocd app rollback payment-api-prod 3
  → Syncs to the Git commit SHA from revision 3
  → Application is pinned at revision 3
  → To unpin: argocd app sync payment-api-prod (returns to HEAD)
```
