# ArgoCD Best Practices — Part 6: ApplicationSet — Dynamic Application Generation

> **Without ApplicationSet:** an ops engineer manually creates one Application YAML per environment per team — 50 teams × 3 envs = 150 files to maintain.
> **With ApplicationSet:** a single template + a generator produces all Applications automatically. Add a team or cluster, and their Applications appear with zero manual YAML.

---

## Why ApplicationSet

```
Problem at scale:
  10 teams × 3 environments = 30 Application YAMLs
  50 teams × 3 environments = 150 Application YAMLs
  Adding a new cluster = 150+ more Application YAMLs

Without ApplicationSet:
  → Someone must create a PR to add each new Application YAML manually
  → Easy to forget an environment (payment-api-prod exists but payment-api-staging missing)
  → Inconsistent configurations (staging has different syncPolicy than dev by mistake)
  → Renaming a team requires updating 3 files

With ApplicationSet:
  → One YAML template generates all Applications
  → Add an element to the generator list → new Applications created automatically
  → Template ensures consistency across all generated Applications
  → Remove an element → Applications are automatically deleted
```

---

## ApplicationSet Generators

| Generator | What It Iterates | Example Use |
|---|---|---|
| `list` | Hardcoded list of parameter maps | Fixed environment list: dev/staging/prod |
| `clusters` | Registered ArgoCD clusters | Deploy add-on to every cluster |
| `git` (directories) | Directories matching a pattern in a Git repo | One app per team folder |
| `git` (files) | JSON/YAML files matching a pattern | Per-team config files drive per-team apps |
| `matrix` | Cartesian product of two generators | Every team × every cluster |
| `merge` | Merge results from multiple generators | Override specific cluster settings |
| `pullRequest` | Open PRs from GitHub/GitLab/Bitbucket | Preview environment per PR |
| `scmProvider` | Repos in a GitHub Org / Bitbucket workspace | Auto-create apps for every repo |

---

## Generator 1: List (Simple, Explicit)

```yaml
# One ApplicationSet, three Applications (dev, staging, prod)
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: payments
  namespace: argocd
spec:
  goTemplate: true    # use Go template syntax ({{.env}}) instead of {{env}}
  generators:
    - list:
        elements:
          - env: dev
            namespace: payments-dev
            syncPolicy: "auto"
            targetRevision: main
          - env: staging
            namespace: payments-staging
            syncPolicy: "auto"
            targetRevision: main
          - env: prod
            namespace: payments-prod
            syncPolicy: "manual"
            targetRevision: main

  template:
    metadata:
      name: 'payments-{{.env}}'
      labels:
        app.kubernetes.io/part-of: payments
        environment: '{{.env}}'
    spec:
      project: payments
      source:
        repoURL: https://github.com/myorg/payments-gitops
        targetRevision: '{{.targetRevision}}'
        path: 'overlays/{{.env}}'
      destination:
        server: https://kubernetes.default.svc
        namespace: '{{.namespace}}'
      syncPolicy:
        automated: {}   # controlled per-element by syncPolicy param below
        syncOptions:
          - CreateNamespace=true
          - ApplyOutOfSyncOnly=true
```

---

## Generator 2: Git Directories (One App Per Folder)

```yaml
# Scans a Git repo for directories matching a pattern.
# Each matching directory becomes one Application.
# Used for: cluster add-ons, platform components, one team per folder.

apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: cluster-addons
  namespace: argocd
spec:
  generators:
    - git:
        repoURL: https://github.com/myorg/gitops-monorepo
        revision: HEAD
        directories:
          - path: cluster-addons/*      # matches: cluster-addons/cert-manager,
                                        #          cluster-addons/ingress-nginx, etc.
          - path: cluster-addons/experimental/*
            exclude: true               # exclude experimental subdirectory

  template:
    metadata:
      name: '{{path.basename}}'         # app name = directory name (e.g. cert-manager)
    spec:
      project: platform
      source:
        repoURL: https://github.com/myorg/gitops-monorepo
        targetRevision: HEAD
        path: '{{path}}'                # full path: cluster-addons/cert-manager
      destination:
        server: https://kubernetes.default.svc
        namespace: '{{path.basename}}'  # namespace same as folder name
      syncPolicy:
        automated:
          selfHeal: true
          prune: true
        syncOptions:
          - CreateNamespace=true
```

---

## Generator 3: Clusters (Deploy to Every Cluster)

```yaml
# Every cluster registered in ArgoCD gets this application deployed.
# Great for: cluster-level infra (metrics-server, node-exporter, CSI drivers).

apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: metrics-server-all-clusters
  namespace: argocd
spec:
  generators:
    - clusters:
        selector:
          matchLabels:
            cluster-type: production    # only production clusters (set label during: argocd cluster add)
        values:
          region: '{{metadata.labels.region}}'   # use cluster labels as template variables

  template:
    metadata:
      name: 'metrics-server-{{name}}'   # {{name}} = cluster name
    spec:
      project: platform
      source:
        repoURL: https://github.com/myorg/gitops-monorepo
        targetRevision: HEAD
        path: cluster-addons/metrics-server
      destination:
        server: '{{server}}'           # {{server}} = cluster API server URL
        namespace: kube-system
      syncPolicy:
        automated:
          selfHeal: true
```

---

## Generator 4: Matrix (Teams × Environments)

```yaml
# Cartesian product: every team gets apps in every environment.
# 5 teams × 3 environments = 15 Applications automatically.

apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: all-team-apps
  namespace: argocd
spec:
  generators:
    - matrix:
        generators:
          # First generator: teams
          - git:
              repoURL: https://github.com/myorg/gitops-monorepo
              revision: HEAD
              files:
                - path: teams/*/config.json     # one config.json per team
          # Second generator: environments
          - list:
              elements:
                - env: dev
                  server: https://dev-cluster.company.internal
                - env: staging
                  server: https://kubernetes.default.svc
                - env: prod
                  server: https://prod-cluster.company.internal

  template:
    metadata:
      name: '{{team}}-{{env}}'            # e.g. payments-dev, payments-prod
    spec:
      project: '{{team}}'
      source:
        repoURL: '{{gitopsRepo}}'         # from team's config.json
        targetRevision: main
        path: 'overlays/{{env}}'
      destination:
        server: '{{server}}'
        namespace: '{{team}}-{{env}}'
```

```json
// teams/payments/config.json
{
  "team": "payments",
  "gitopsRepo": "https://github.com/myorg/payments-gitops",
  "slackChannel": "#payments-deploys"
}
```

---

## Generator 5: Pull Request (Preview Environments)

```yaml
# Creates a preview environment Application for every open PR.
# PR merged or closed → Application automatically deleted.
# Great for: integration testing, QA review before merge.

apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: payments-preview
  namespace: argocd
spec:
  generators:
    - pullRequest:
        github:
          owner: myorg
          repo: payments-api
          tokenRef:
            secretName: github-token    # Secret with GitHub API token for PR listing
            key: token
          labels:
            - preview                   # only create preview for PRs with this label
        requeueAfterSeconds: 60         # re-check for new/closed PRs every 60 seconds

  template:
    metadata:
      name: 'preview-pr-{{number}}'    # e.g. preview-pr-142
    spec:
      project: payments
      source:
        repoURL: https://github.com/myorg/payments-api
        targetRevision: '{{head_sha}}'  # exact commit SHA from the PR head
        path: overlays/dev
        kustomize:
          images:
            - 'myorg/payment-api:pr-{{number}}'    # CI builds and pushes this tag for each PR
      destination:
        server: https://kubernetes.default.svc
        namespace: 'preview-pr-{{number}}'
      syncPolicy:
        automated:
          selfHeal: true
          prune: true
        syncOptions:
          - CreateNamespace=true
```

---

## Preventing ApplicationSet from Overwriting Manual Changes

```yaml
# Problem: you manually patch an Application (e.g. override an image tag for testing).
# ApplicationSet reconciles and reverts your change within minutes.

# Solution: ignoreApplicationDifferences
spec:
  ignoreApplicationDifferences:
    - jsonPointers:
        - /spec/source/targetRevision   # don't revert if someone pinned a revision
        - /spec/source/helm/values      # don't revert manual values overrides
    - name: payments-prod               # only ignore on this specific generated app
      jsonPointers:
        - /spec/syncPolicy              # don't revert if prod sync policy was changed
```

---

## Template Safeguards

```yaml
# Prevent ApplicationSet from deleting Applications if a generator error occurs
spec:
  # If the Git repo is unreachable (generator failure), don't delete existing Applications
  syncPolicy:
    preserveResourcesOnDeletion: true

  # Apply updates to existing Applications (required for reconciliation to work)
  # If false, ApplicationSet only creates but never updates Applications
  template:
    spec:
      syncPolicy:
        automated:
          selfHeal: true
```

---

## Common ApplicationSet Mistakes

| Mistake | Consequence | Fix |
|---|---|---|
| No `preserveResourcesOnDeletion` | Generator Git repo goes offline → all Applications deleted → all workloads deleted | Set `syncPolicy.preserveResourcesOnDeletion: true` |
| Matrix generator with too many combinations | 50 teams × 10 envs × 5 clusters = 2,500 Applications; ArgoCD overwhelmed | Limit scope; use separate ApplicationSets per cluster |
| `prune: true` on cluster generator | Adding then removing a cluster label deletes all its Applications | Careful with cluster labels; use `prune: false` on cluster-scoped apps |
| No label filter on pullRequest generator | Creates preview for every PR including chore/docs branches | Use `labels: [preview]`; require label on PRs that need preview |
| Hard-coded secrets in ApplicationSet template | Template YAML is in Git → secrets visible | Reference external secrets; never inline sensitive params |
