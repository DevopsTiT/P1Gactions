# ArgoCD Best Practices — Part 5: RBAC and SSO — Access Control

> **Without RBAC:** anyone who can reach the ArgoCD UI can sync or delete any application.
> **With RBAC:** roles are scoped to projects and actions; federated via your IdP — no shared passwords.

---

## Why ArgoCD RBAC Matters

```
ArgoCD has power to:
  → Deploy to production clusters
  → Delete Deployments, Services, PVCs
  → Override Git state and sync custom parameters
  → View all Secrets referenced by Applications (via pod exec / logs)
  → Access multiple clusters from a single control plane

Without proper RBAC:
  → Any developer who logs in can trigger production syncs
  → A compromised account can delete production Applications
  → No audit trail of who triggered which sync

With proper RBAC:
  → Developers: read-only view of their team's apps
  → Team deployers: can sync their team's apps, no other team's
  → SRE: can sync any app, manage AppProjects
  → Admins: full control (2-3 people maximum)
  → All tied to IdP groups — no individual user management in ArgoCD
```

---

## RBAC Architecture

```
ArgoCD RBAC is stored in two ConfigMaps in the argocd namespace:

argocd-rbac-cm:
  policy.csv    → role definitions and assignments
  policy.default → default role for authenticated users who have no explicit role
  scopes        → which OIDC/LDAP claims to use for group matching

argocd-cm:
  url           → ArgoCD external URL
  oidc.config   → SSO/OIDC provider configuration
  admin.enabled → whether local 'admin' account is active

Evaluation order:
  1. Is user 'admin'? → full access (bypass all RBAC)
  2. Is user explicitly denied? → deny
  3. Does user match a role? → apply role policies
  4. Does user match policy.default? → apply default role
  5. Deny everything else
```

---

## RBAC Policy Format

```
Policy syntax:
  p, <role/user>, <resource>, <action>, <object>, <effect>

Resources:
  applications       → Application CRDs
  repositories       → Git repository access
  clusters           → registered cluster management
  projects           → AppProject management
  accounts           → user account management (tokens, passwords)
  gpgkeys            → GPG key management
  logs               → pod log access via ArgoCD
  exec               → kubectl exec via ArgoCD
  extensions         → proxy extensions

Actions per resource:
  applications:  get, create, update, delete, sync, override, action
  repositories:  get, create, update, delete
  clusters:      get, create, update, delete
  logs:          get
  exec:          create

Object format:
  For applications: <project-name>/<app-name>  or  <project-name>/*  for all apps

Effect:
  allow  → grant the permission
  deny   → explicitly deny (deny takes precedence over allow)
```

---

## Complete argocd-rbac-cm Example

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: argocd-rbac-cm
  namespace: argocd
data:
  # Default role for authenticated users who don't match any explicit role
  # Use role:readonly so authenticated users can see apps but not change them
  policy.default: role:readonly

  # Which OIDC/LDAP attributes contain group membership
  scopes: '[groups, email]'

  policy.csv: |
    # ─────────────────────────────────────────────────────────────────
    # Platform / SRE team — full control
    # ─────────────────────────────────────────────────────────────────
    g, sre-team,    role:admin

    # ─────────────────────────────────────────────────────────────────
    # Payments team — can view and sync their own apps
    # ─────────────────────────────────────────────────────────────────
    p, role:payments-dev, applications, get,      payments/*, allow
    p, role:payments-dev, applications, sync,     payments/*, allow
    p, role:payments-dev, applications, override, payments/*, allow
    p, role:payments-dev, logs,         get,      payments/*, allow

    g, payments-team, role:payments-dev

    # ─────────────────────────────────────────────────────────────────
    # Notifications team — can view and sync their own apps
    # ─────────────────────────────────────────────────────────────────
    p, role:notifications-dev, applications, get,  notifications/*, allow
    p, role:notifications-dev, applications, sync, notifications/*, allow
    p, role:notifications-dev, logs,         get,  notifications/*, allow

    g, notifications-team, role:notifications-dev

    # ─────────────────────────────────────────────────────────────────
    # All engineers — read-only view across all projects
    # ─────────────────────────────────────────────────────────────────
    p, role:global-readonly, applications, get, */*, allow
    p, role:global-readonly, repositories, get, *,   allow

    g, engineers, role:global-readonly

    # ─────────────────────────────────────────────────────────────────
    # CI/CD service accounts — can sync specific apps automatically
    # ─────────────────────────────────────────────────────────────────
    p, role:ci-payments, applications, get,  payments/*, allow
    p, role:ci-payments, applications, sync, payments/payment-api-dev, allow
    p, role:ci-payments, applications, sync, payments/payment-api-staging, allow
    # CI cannot sync production — human must sync prod

    g, service-account:ci-payments, role:ci-payments

    # ─────────────────────────────────────────────────────────────────
    # Explicitly deny exec access to everyone except SRE
    # (exec = kubectl exec into pods via ArgoCD UI)
    # ─────────────────────────────────────────────────────────────────
    p, role:payments-dev, exec, create, */*, deny
    p, role:notifications-dev, exec, create, */*, deny
```

---

## SSO via OIDC (Okta / Google / GitHub)

```yaml
# argocd-cm ConfigMap
apiVersion: v1
kind: ConfigMap
metadata:
  name: argocd-cm
  namespace: argocd
data:
  url: https://argocd.company.com

  # OIDC configuration — example with Okta
  oidc.config: |
    name: Okta
    issuer: https://company.okta.com/oauth2/default
    clientID: argocd
    clientSecret: $oidc.okta.clientSecret       # references a Secret key
    requestedScopes:
      - openid
      - profile
      - email
      - groups                                  # fetch group membership
    requestedIDTokenClaims:
      groups:
        essential: true                          # fail login if groups claim missing
    # Map Okta groups to ArgoCD roles in argocd-rbac-cm
```

```yaml
# The clientSecret should reference a Kubernetes Secret, not be inline:
apiVersion: v1
kind: Secret
metadata:
  name: argocd-secret
  namespace: argocd
type: Opaque
stringData:
  oidc.okta.clientSecret: "<client-secret-from-okta>"
  # ArgoCD uses $oidc.okta.clientSecret syntax to read from this Secret
```

---

## SSO via Dex (GitHub OAuth)

```yaml
# argocd-cm — Dex connector for GitHub
data:
  url: https://argocd.company.com

  dex.config: |
    connectors:
    - type: github
      id: github
      name: GitHub
      config:
        clientID: <github-oauth-app-client-id>
        clientSecret: $dex.github.clientSecret
        redirectURI: https://argocd.company.com/api/dex/callback
        orgs:
        - name: myorg               # only members of this GitHub org can log in
          teams:                    # map GitHub teams to groups
            - sre
            - payments-team
            - notifications-team
            - developers
```

```yaml
# argocd-rbac-cm — map GitHub teams to roles
policy.csv: |
  g, myorg:sre,                role:admin
  g, myorg:payments-team,      role:payments-dev
  g, myorg:notifications-team, role:notifications-dev
  g, myorg:developers,         role:global-readonly
```

---

## Disable Local Admin Account (After SSO Is Working)

```yaml
# argocd-cm — disable the local 'admin' account
data:
  admin.enabled: "false"    # login with username 'admin' is blocked

# IMPORTANT: do this ONLY after:
#   1. SSO is fully working
#   2. At least one SSO user has role:admin
#   3. You have tested SSO login as an admin

# To re-enable if SSO breaks:
# kubectl patch configmap argocd-cm -n argocd \
#   --type merge -p '{"data":{"admin.enabled":"true"}}'
# kubectl rollout restart deployment argocd-server -n argocd
```

---

## API Tokens for CI/CD

```bash
# Create a service account for CI/CD pipelines (not for humans):
argocd account create --account ci-payments

# Generate a token with expiry (rotate regularly — 90 days max):
argocd account generate-token --account ci-payments --expires-in 90d
# Output: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
# Store this token in Jenkins Credentials / GitHub Actions Secrets / Vault

# List all accounts and their last login:
argocd account list

# Delete an account (when CI service is decommissioned):
argocd account delete --account ci-old-service

# What the CI token can do is defined in argocd-rbac-cm:
# g, service-account:ci-payments, role:ci-payments
# The role is defined in policy.csv above — limited to syncing specific apps
```

---

## RBAC Audit Commands

```bash
# Who has admin access? (should be very few people)
kubectl get configmap argocd-rbac-cm -n argocd \
  -o jsonpath='{.data.policy\.csv}' | grep "role:admin"

# What groups are mapped to each role?
kubectl get configmap argocd-rbac-cm -n argocd \
  -o jsonpath='{.data.policy\.csv}' | grep "^g,"

# List all local accounts (non-SSO):
argocd account list

# Check if any account has no expiry (long-lived token risk):
argocd account list --output json | jq '.[] | select(.tokens != null) |
  {name: .name, tokens: [.tokens[] | select(.expiresAt == 0)]}'
# Any token with expiresAt=0 = never expires → regenerate with expiry

# What can a specific group do?
argocd auth can-i sync applications --group=payments-team
# Returns: yes / no
```

---

## Monthly Access Review Checklist

```bash
# 1. Review all accounts and token expiry:
argocd account list

# 2. Check if any token is older than 90 days:
argocd account list --output json | \
  jq -r '.[] | select(.tokens != null) | .tokens[] | select(.issuedAt < (now - 7776000)) |
    "Account: \(.account), Token: \(.id), Issued: \(.issuedAt | todate)"'
# Rotate any token older than 90 days

# 3. Verify IdP groups still exist (teams change over time):
kubectl get configmap argocd-rbac-cm -n argocd \
  -o jsonpath='{.data.policy\.csv}' | grep "^g,"
# Cross-reference each group name with your IdP (Okta/GitHub/LDAP)
# Remove mappings for groups that no longer exist

# 4. Check no '*' exists in sensitive permissions:
kubectl get configmap argocd-rbac-cm -n argocd \
  -o jsonpath='{.data.policy\.csv}' | grep "delete.*\*"
# Any delete permission with wildcard = review carefully

# 5. Rotate admin password if local admin is still enabled:
argocd account update-password --current-password <old> --new-password <new>
```

---

## Common RBAC Mistakes

| Mistake | Consequence | Fix |
|---|---|---|
| `role:admin` for all users | Any authenticated user can delete production apps | Use `role:readonly` as default; explicit roles per team |
| Individual user entries in policy.csv | Policy becomes unmaintainable as people join/leave | Map IdP GROUPS to roles; never map individual users |
| Long-lived CI tokens with no expiry | Compromised token has indefinite access | Always set expiry: `--expires-in 90d`; rotate in CI secrets |
| Forgetting to disable local admin after SSO setup | Two admin paths = two attack surfaces | Set `admin.enabled: "false"` in argocd-cm once SSO works |
| `exec: create` permission for developers | Developers can exec into any pod managed by ArgoCD | Explicitly deny exec for non-SRE roles |
| Not scoping CI tokens to specific apps | CI can sync any app in the project | Define granular policies: `sync, payments/payment-api-dev, allow` not `sync, payments/*, allow` |
