# ArgoCD Best Practices — Part 2: AppProject — Multi-Tenancy and Blast Radius

> **Without AppProject:** every team's Application can deploy to any cluster and any namespace, pull from any repo — a misconfigured app can overwrite another team's production.
> **With AppProject:** source repos, destination clusters/namespaces, and allowed resource kinds are explicitly whitelisted per tenant. Deny by default.

---

## Why AppProject Exists

```
ArgoCD's default project ('default') has no restrictions:
  sourceRepos: ['*']         ← any Git repo
  destinations:
    - server: '*'            ← any cluster
      namespace: '*'         ← any namespace

Without AppProject:
  → Team A's Application can accidentally deploy to Team B's namespace
  → A compromised CI token could push malicious manifests that get synced everywhere
  → No audit trail of which team is allowed to deploy where
  → No ability to restrict dangerous resource kinds (ClusterRoleBinding, NetworkPolicy)

With AppProject:
  → Team A can ONLY read from their designated Git repo
  → Team A can ONLY deploy to namespaces matching payments-*
  → Team A CANNOT create ClusterRoleBindings or modify ResourceQuotas
  → RBAC roles scoped to the project — no cross-project privilege escalation
```

---

## Full AppProject Example (Production-Ready)

```yaml
apiVersion: argoproj.io/v1alpha1
kind: AppProject
metadata:
  name: payments
  namespace: argocd
  annotations:
    # Who owns this project — helps during access reviews
    owner: payments-team@company.com
    last-reviewed: "2026-07-01"
spec:
  description: "GitOps project for the payments domain (payment-api, payment-worker)"

  # Which Git repositories this project's Applications may read from
  # Rule: never use '*' in production
  sourceRepos:
    - 'https://github.com/myorg/payments-gitops'
    - 'https://github.com/myorg/payments-helm-charts'  # if using a separate chart repo

  # Which cluster+namespace combos this project may deploy to
  destinations:
    - namespace: 'payments-*'                           # wildcard namespace family
      server: https://kubernetes.default.svc            # local cluster
    - namespace: 'monitoring'                           # if team deploys its own dashboards
      server: https://kubernetes.default.svc

  # Cluster-scoped resource kinds this project MAY create
  # Keep this list minimal — Namespace is usually the only one teams need
  clusterResourceWhitelist:
    - group: ''
      kind: Namespace

  # Namespace-scoped resource kinds this project may NOT create
  # Prevents privilege escalation and quota manipulation
  namespaceResourceBlacklist:
    - group: ''
      kind: ResourceQuota         # teams cannot set their own quotas
    - group: 'rbac.authorization.k8s.io'
      kind: ClusterRoleBinding    # teams cannot create cluster-wide RBAC

  # Time windows during which sync is allowed (or denied)
  syncWindows:
    - kind: allow
      schedule: '0 9 * * 1-5'    # Mon-Fri 09:00 UTC
      duration: 8h                # until 17:00 UTC
      applications:
        - '*'
      manualSync: true            # still allow manual sync outside the window for emergencies

  # Project-scoped roles and who can use them
  roles:
    - name: payments-deployer
      description: "Can view and sync payments applications"
      policies:
        - p, proj:payments:payments-deployer, applications, get,      payments/*, allow
        - p, proj:payments:payments-deployer, applications, sync,     payments/*, allow
        - p, proj:payments:payments-deployer, applications, override, payments/*, allow
      groups:
        - payments-team           # all members of the payments-team IdP group
        - sre-oncall              # SRE on-call can sync anything

    - name: payments-readonly
      description: "Read-only view of payments applications"
      policies:
        - p, proj:payments:payments-readonly, applications, get, payments/*, allow
      groups:
        - developers              # all engineers can view but not sync
```

---

## Key AppProject Fields Explained

### sourceRepos

```yaml
# Restricts which Git repositories this project's Applications can use

# WRONG — too permissive:
sourceRepos:
  - '*'

# CORRECT — explicit list:
sourceRepos:
  - 'https://github.com/myorg/payments-gitops'
  - 'https://github.com/myorg/shared-helm-charts'

# What happens if an Application references a repo NOT in this list?
# → Application creation fails with:
#   "application repo https://github.com/other-team/repo is not permitted in project payments"
```

### destinations

```yaml
# Controls which cluster+namespace combos are allowed

# Pattern A: specific namespace
destinations:
  - namespace: payments-prod
    server: https://kubernetes.default.svc

# Pattern B: wildcard namespace family (recommended for teams with dev/staging/prod)
destinations:
  - namespace: 'payments-*'
    server: https://kubernetes.default.svc

# Pattern C: multi-cluster
destinations:
  - namespace: 'payments-*'
    server: https://kubernetes.default.svc      # local cluster
  - namespace: 'payments-*'
    server: https://dr-cluster.company.internal  # DR cluster

# What happens if an Application targets a destination NOT in this list?
# → Application creation fails with:
#   "application destination {server: ..., namespace: payments-other} is not permitted in project payments"
```

### clusterResourceWhitelist vs Blacklist

```yaml
# Cluster-scoped resources (not tied to any namespace):
# Namespace, ClusterRole, ClusterRoleBinding, StorageClass, PersistentVolume, CRDs

# Whitelist (allow ONLY these cluster-scoped resource kinds):
clusterResourceWhitelist:
  - group: ''
    kind: Namespace     # teams can create namespaces (needed for CreateNamespace=true)

# Namespace-scoped blacklist (deny THESE specific resource kinds):
namespaceResourceBlacklist:
  - group: ''
    kind: ResourceQuota               # platform team sets quotas; teams cannot override
  - group: 'rbac.authorization.k8s.io'
    kind: ClusterRoleBinding          # prevents privilege escalation
  - group: 'policy'
    kind: PodSecurityPolicy           # deprecated but still block if present

# Allow all namespace-scoped resources EXCEPT the blacklisted ones (default behaviour):
# No namespaceResourceWhitelist needed unless you want a full whitelist approach
```

### syncWindows

```yaml
# Control when auto-sync (or manual sync) is allowed or denied

# Example: block ALL deploys on weekends except by SRE team
syncWindows:
  - kind: deny
    schedule: '0 0 * * 6-7'    # Saturday and Sunday midnight UTC
    duration: 48h               # for the entire weekend
    manualSync: false           # even manual sync is blocked during this window
    # SRE can override by using argocd app sync --server-side during a deny window
    # only if the Application has an AppProject role with override permission

  - kind: allow
    schedule: '0 8 * * 1-5'    # Weekdays 08:00 UTC
    duration: 10h               # until 18:00 UTC
    applications:
      - '*'
    manualSync: true            # manual sync always allowed during business hours

# Window evaluation order: deny windows take precedence over allow windows
```

---

## Project-Scoped RBAC Roles

```
ArgoCD RBAC policy format:
  p, <role>, <resource>, <action>, <object>, <effect>

Resources: applications, repositories, clusters, projects, gpgkeys, exec, logs
Actions:   get, create, update, delete, sync, override, action

Example policies for a deployer role:
  # Can view any application in the payments project
  p, proj:payments:payments-deployer, applications, get, payments/*, allow

  # Can sync any application in the payments project
  p, proj:payments:payments-deployer, applications, sync, payments/*, allow

  # Can view logs of pods (via argocd app logs or kubectl exec via ArgoCD)
  p, proj:payments:payments-deployer, logs, get, payments/*, allow

  # CANNOT delete applications
  # (omitting 'delete' permission = deny by default)

  # CANNOT access other projects
  # (permissions are project-scoped: payments/* only)
```

```yaml
# Assign role to IdP groups (mapped via argocd-rbac-cm):
roles:
  - name: payments-deployer
    policies:
      - p, proj:payments:payments-deployer, applications, get,  payments/*, allow
      - p, proj:payments:payments-deployer, applications, sync, payments/*, allow
      - p, proj:payments:payments-deployer, logs, get, payments/*, allow
    groups:
      - payments-team     # all members of this IdP group get this role
      - sre-oncall        # SRE on-call team can also sync payments apps
```

---

## Multi-Cluster Project Configuration

```yaml
# If your organization runs multiple clusters (prod-us, prod-eu, dr-cluster):
spec:
  destinations:
    - namespace: 'payments-*'
      server: https://prod-us.company.internal    # US production
    - namespace: 'payments-*'
      server: https://prod-eu.company.internal    # EU production
    - namespace: 'payments-*'
      server: https://dr.company.internal         # Disaster recovery

  # Register each cluster in ArgoCD first:
  # argocd cluster add prod-us-context --name prod-us
  # argocd cluster add prod-eu-context --name prod-eu
```

---

## Monthly Project Review Checklist

```bash
# List all projects and their sync status:
argocd proj list

# Check if any project has '*' in sourceRepos (should not):
kubectl get appproject -n argocd -o json | \
  jq -r '.items[] | select(.spec.sourceRepos[] == "*") | .metadata.name'
# Any output = over-permissive project; review and restrict

# Check if any project has '*' destination namespace (should not):
kubectl get appproject -n argocd -o json | \
  jq -r '.items[] | select(.spec.destinations[].namespace == "*") | .metadata.name'

# Review stale roles — groups that no longer exist in the IdP:
kubectl get appproject payments -n argocd \
  -o jsonpath='{.spec.roles[*].groups}' | jq .
# Cross-reference with your IdP (Okta/LDAP/GitHub) group list

# Check syncWindows are still correct (schedule, duration, manual):
kubectl get appproject -n argocd -o yaml | grep -A 10 syncWindows
```

---

## Common Mistakes in AppProject Configuration

| Mistake | Consequence | Correct Approach |
|---|---|---|
| `sourceRepos: ['*']` | Any Git repo can be used; supply chain risk | Explicit list of approved repos only |
| `destinations: [{namespace: '*'}]` | Team can deploy to any namespace including kube-system | Use namespace wildcard scoped to team: `payments-*` |
| No `namespaceResourceBlacklist` | Teams can create ClusterRoleBindings → privilege escalation | Block at minimum: ResourceQuota, ClusterRoleBinding |
| `role:admin` for all team members | Full cluster access to everyone | Least-privilege project roles: read for devs, sync for deployers |
| Not reviewing `syncWindows` quarterly | Teams may deploy during change freezes | Include syncWindow review in quarterly access review |
| One AppProject for all teams | No blast radius isolation | One AppProject per team/domain |
