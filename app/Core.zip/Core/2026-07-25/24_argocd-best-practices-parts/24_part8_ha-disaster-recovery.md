# ArgoCD Best Practices — Part 8: High Availability and Disaster Recovery

> **Without HA:** single ArgoCD pod — a crash means no sync, no visibility, and blocked deployments.
> **With HA:** each component scaled separately; state in Redis cluster; failover is automatic.

---

## ArgoCD Components and Their Roles

```
argocd-server (API / UI):
  → Handles all argocd CLI calls and UI requests
  → Stateless — can run multiple replicas behind a load balancer
  → If down: UI is inaccessible; existing workloads continue running (K8s is unaffected)

argocd-repo-server (Git clone + manifest rendering):
  → Clones Git repositories; runs Kustomize/Helm to render manifests
  → CPU-intensive (manifest rendering for large apps)
  → Stateless — safe to scale horizontally
  → If down: no new syncs; existing deployed state is frozen

argocd-application-controller (reconciliation loop):
  → Watches all Application CRDs; compares desired vs live state
  → Manages the sync operation lifecycle
  → If down: no sync, no health updates, no drift detection
  → Supports sharding for large clusters (one shard per cluster subset)

argocd-dex-server (SSO broker):
  → Handles OIDC/LDAP authentication
  → If down: users cannot log in (but in-flight sessions remain valid for token TTL)

argocd-redis (state cache):
  → Caches application state, Git repo cache, cluster cache
  → If down: ArgoCD falls back to slower paths (re-fetches from API server / Git)
  → State is rebuilt automatically on Redis restart (not a data store — cache only)

argocd-notifications (alerting):
  → Sends notifications to Slack/PagerDuty/Teams/email
  → Leader-elected: only one instance processes notifications at a time
  → If down: no new alerts; silently misses sync events until restarted
```

---

## HA Deployment: Replica Targets

```
Component                    Single instance    HA minimum    Notes
──────────────────────────── ──────────────── ──────────── ──────────────────────────
argocd-server                1                3            Stateless; scale freely
argocd-repo-server           1                3            CPU-bound; scale for parallel syncs
argocd-application-controller 1               1 per shard  Scale via sharding (see below)
argocd-dex-server            1                2            Stateless; any replica handles auth
argocd-redis                 1                3 (Sentinel) or 6 (Cluster)
argocd-notifications         1                1            Leader-elected; 1 active instance
```

---

## Step-by-Step: Enable HA with Helm

```bash
# Install ArgoCD in HA mode using the official Helm chart:
helm repo add argo https://argoproj.github.io/argo-helm
helm repo update

helm upgrade --install argocd argo/argo-cd \
  --namespace argocd \
  --create-namespace \
  --values argocd-ha-values.yaml
```

```yaml
# argocd-ha-values.yaml
global:
  image:
    tag: "v2.11.3"    # pin exact version; never use latest

server:
  replicas: 3
  resources:
    requests:
      cpu: "200m"
      memory: "256Mi"
    limits:
      cpu: "1"
      memory: "512Mi"
  pdb:
    enabled: true
    minAvailable: 2   # always keep 2 servers available during disruptions

repoServer:
  replicas: 3
  resources:
    requests:
      cpu: "500m"      # rendering is CPU-intensive
      memory: "512Mi"
    limits:
      cpu: "2"
      memory: "1Gi"
  pdb:
    enabled: true
    minAvailable: 2

applicationController:
  replicas: 1           # scale via sharding; not replica count
  resources:
    requests:
      cpu: "500m"
      memory: "512Mi"
    limits:
      cpu: "2"
      memory: "2Gi"
  env:
    - name: ARGOCD_CONTROLLER_SHARDING_ALGORITHM
      value: consistent-hashing

dex:
  resources:
    requests:
      cpu: "50m"
      memory: "64Mi"

redis-ha:
  enabled: true         # use Redis HA (Sentinel) instead of single Redis
  haproxy:
    enabled: true
  redis:
    resources:
      requests:
        cpu: "100m"
        memory: "128Mi"

notifications:
  enabled: true
  resources:
    requests:
      cpu: "100m"
      memory: "128Mi"
```

---

## Application Controller Sharding

```
The application controller is the bottleneck at scale.
It reconciles every Application CRD continuously.
With 500+ Applications across multiple clusters: one controller becomes overwhelmed.

Sharding distributes Applications across multiple controller instances:
  Shard 0: Applications 0-99
  Shard 1: Applications 100-199
  Shard 2: Applications 200-299

Each shard runs as a separate StatefulSet replica.
```

```yaml
# Enable sharding in the application controller:
applicationController:
  replicas: 3    # 3 shards
  env:
    - name: ARGOCD_CONTROLLER_REPLICAS
      value: "3"
    - name: ARGOCD_CONTROLLER_SHARDING_ALGORITHM
      value: consistent-hashing    # or: round-robin (legacy)
```

---

## Redis HA: Sentinel vs Cluster Mode

```
Redis Sentinel (default HA mode — recommended for most):
  3 Redis nodes: 1 primary + 2 replicas
  3 Sentinel processes: monitor primary health, elect new primary on failure
  HAProxy: single endpoint that routes to current primary
  
  Topology: primary → replica-1, replica-2
  Failover: Sentinel detects primary down → elects a replica as new primary → ~5-10 seconds
  
  Sufficient for: ArgoCD (Redis is cache only; brief unavailability = slowness, not data loss)

Redis Cluster mode (for very large deployments):
  6+ nodes: data sharded across 3+ primary-replica pairs
  More complex; use only if Redis is a bottleneck (rarely is for ArgoCD)
```

---

## Backup: ArgoCD State Export

### What to Back Up

```
ArgoCD state stored in Kubernetes (not in Redis):
  Kubernetes resources in the argocd namespace:
    Application CRDs           → the application configurations
    AppProject CRDs            → project configurations
    ArgoCD ConfigMaps          → argocd-cm, argocd-rbac-cm, argocd-known-hosts
    ArgoCD Secrets             → argocd-secret (admin password, OIDC secrets), repo credentials
    Cluster Secrets            → cluster API server credentials
    Repository Secrets         → Git repository credentials

What NOT to back up:
    Redis data                 → cache only; rebuilt automatically
    Deployment history in etcd → rebuilt from Applications on restore
```

### Export All ArgoCD State

```bash
# Full export (Applications, AppProjects, Settings, Repos, Clusters):
argocd admin export > argocd-backup-$(date +%Y%m%d-%H%M%S).yaml

# Verify backup file is not empty:
wc -l argocd-backup-*.yaml
cat argocd-backup-*.yaml | grep "kind:" | sort | uniq -c

# Store backup in S3:
aws s3 cp argocd-backup-$(date +%Y%m%d).yaml \
  s3://company-argocd-backups/$(date +%Y/%m/%d)/ \
  --sse aws:kms

# Automated daily backup (CronJob):
```

```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: argocd-backup
  namespace: argocd
spec:
  schedule: "0 2 * * *"    # daily at 02:00 UTC
  jobTemplate:
    spec:
      template:
        spec:
          serviceAccountName: argocd-backup-sa    # needs: get/list on ArgoCD CRDs
          containers:
          - name: backup
            image: quay.io/argoproj/argocd:v2.11.3
            command:
              - /bin/sh
              - -c
              - |
                argocd admin export > /tmp/backup.yaml
                aws s3 cp /tmp/backup.yaml \
                  s3://company-argocd-backups/$(date +%Y%m%d).yaml \
                  --sse aws:kms
            env:
            - name: ARGOCD_SERVER
              value: argocd-server.argocd.svc.cluster.local
            - name: ARGOCD_AUTH_TOKEN
              valueFrom:
                secretKeyRef:
                  name: argocd-backup-token
                  key: token
          restartPolicy: OnFailure
```

### Restore from Backup

```bash
# Restore to a fresh ArgoCD instance:
# 1. Install ArgoCD (same version as the backup — check version in the backup YAML header)
helm upgrade --install argocd argo/argo-cd \
  --namespace argocd \
  --version <same-chart-version>

# 2. Wait for ArgoCD to be ready:
kubectl wait --for=condition=available deployment/argocd-server -n argocd --timeout=300s

# 3. Import the backup:
argocd admin import < argocd-backup-20260725-020000.yaml

# 4. Verify restoration:
argocd app list    # all Applications should appear
argocd proj list   # all AppProjects should appear

# 5. Check sync status:
argocd app list | grep -v Synced
# Any OutOfSync apps need manual sync to reconcile with current cluster state

# 6. Test connectivity to all registered clusters:
argocd cluster list

# Total restore time: ~10-15 minutes for a typical cluster
```

---

## Upgrade Procedure

```bash
# Check current version:
argocd version --client
argocd version --server   # if server is accessible

# 1. Read release notes for breaking changes:
# https://github.com/argoproj/argo-cd/releases

# 2. Take a backup BEFORE upgrading:
argocd admin export > argocd-pre-upgrade-$(argocd version --short --client).yaml
aws s3 cp argocd-pre-upgrade-*.yaml s3://company-argocd-backups/pre-upgrade/

# 3. Upgrade one minor version at a time (never skip minor versions):
# v2.9 → v2.10 → v2.11 (not v2.9 → v2.11 directly)

# 4. Upgrade with Helm:
helm upgrade argocd argo/argo-cd \
  --namespace argocd \
  --version <new-chart-version> \
  --values argocd-ha-values.yaml \
  --set global.image.tag=v2.11.3

# 5. Watch rollout:
kubectl rollout status deployment/argocd-server -n argocd
kubectl rollout status deployment/argocd-repo-server -n argocd
kubectl rollout status statefulset/argocd-application-controller -n argocd

# 6. Verify all Applications are still healthy:
argocd app list | grep -v Healthy

# 7. Verify UI is accessible and SSO login works
```

---

## Disaster Recovery Checklist

```
Scenario: ArgoCD controller pod crashes / namespace lost

1. □ Assess: is the cluster still running? (Kubernetes is independent of ArgoCD)
   kubectl get pods -A | grep -v Running | grep -v Completed
   → If cluster is fine: applications continue serving traffic even without ArgoCD

2. □ Restore ArgoCD from latest backup:
   argocd admin import < s3://company-argocd-backups/latest.yaml

3. □ Verify Applications are restored and connected to clusters:
   argocd app list
   argocd cluster list

4. □ Re-sync any Applications that drifted during the outage:
   argocd app list | grep OutOfSync | awk '{print $1}' | xargs -I{} argocd app sync {}

5. □ Confirm notifications are working (trigger a test notification):
   argocd admin notifications trigger test --application <any-app>

6. □ Post-incident: document cause + improve monitoring

Quarterly drill:
  □ Restore ArgoCD from backup into a staging cluster
  □ Verify all Applications show correct sync status
  □ Test the restore takes < 30 minutes (your actual RTO)
```

---

## Monitoring ArgoCD Health

```bash
# Prometheus metrics exposed by ArgoCD server (scrape /metrics):
argocd_app_info                    # app health/sync status per app
argocd_app_sync_total              # total sync operations (success/failure)
argocd_cluster_api_resource_objects # resources tracked per cluster
argocd_repo_pending_requests_total # pending Git requests (queue depth)

# Key alerts to configure:
# 1. Application Degraded for > 5 minutes:
#    argocd_app_info{health_status="Degraded"} > 0
#
# 2. Application OutOfSync for > 30 minutes:
#    argocd_app_info{sync_status="OutOfSync"} > 0 and time() - argocd_app_info{} > 1800
#
# 3. ArgoCD component down:
#    up{job="argocd-server"} == 0
#
# 4. Redis unavailable:
#    argocd_redis_request_duration_seconds_count == 0

# Check ArgoCD component health:
kubectl get pods -n argocd
kubectl top pods -n argocd    # check resource usage
```

---

## Common HA and DR Mistakes

| Mistake | Consequence | Fix |
|---|---|---|
| No backup before upgrade | Upgrade fails partway; state corrupted; no restore path | Always `argocd admin export` before any upgrade |
| Single Redis in production | Redis crash = ArgoCD goes slow/unstable; state loss during upgrade | Enable Redis HA (Sentinel) with 3 replicas |
| No PodDisruptionBudget on argocd-server | Node drain removes all server replicas simultaneously | Add PDB: `minAvailable: 2` for server and repo-server |
| Restore test never performed | DR plan exists on paper but fails when actually needed | Quarterly restore drill to staging cluster |
| Upgrading multiple minor versions at once | Breaking changes stack; harder to diagnose failures | One minor version at a time: v2.9 → v2.10 → v2.11 |
| No monitoring of ArgoCD components | Controller crash goes unnoticed for hours | Alert on `up{job="argocd-*"} == 0` |
