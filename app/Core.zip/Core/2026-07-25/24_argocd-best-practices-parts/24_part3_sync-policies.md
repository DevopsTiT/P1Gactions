# ArgoCD Best Practices — Part 3: Sync Policies — Auto vs Manual and Self-Heal

> **Without a sync policy:** ArgoCD detects drift but does nothing — operator must sync manually every time.
> **With a tuned sync policy:** lower environments converge automatically; production requires human intent.

---

## What "Sync" Means in ArgoCD

```
ArgoCD sync = applying the desired state (Git manifests) to the live cluster

Three questions a sync policy answers:
  1. WHEN does sync happen?
     → Automatically (on Git change or drift detection)
     → OR manually (operator runs: argocd app sync)

  2. What happens if resources exist in the cluster but NOT in Git? (orphaned)
     → prune: true  → ArgoCD deletes them (dangerous in prod)
     → prune: false → ArgoCD leaves them (default; safe default)

  3. What happens if a human manually changes something in the cluster (drift)?
     → selfHeal: true  → ArgoCD reverts the change back to Git state
     → selfHeal: false → drift is shown as OutOfSync but not auto-corrected

These three settings have different risk profiles per environment.
```

---

## Recommended Sync Policy Matrix

| Environment | `automated` | `selfHeal` | `prune` | Sync Window | Rationale |
|---|---|---|---|---|---|
| Dev | ✅ enabled | ✅ enabled | ✅ enabled | None (always) | Fastest feedback loop; full automation |
| Staging | ✅ enabled | ✅ enabled | ✅ enabled | Business hours | Mimics prod process; still fast |
| Production | ❌ disabled | ✅ enabled | ❌ disabled | Manual only | Human intent required; prune off = safety net |

---

## Dev Application: Fully Automated

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: payment-api-dev
  namespace: argocd
spec:
  project: payments
  source:
    repoURL: https://github.com/myorg/payments-gitops
    targetRevision: main
    path: overlays/dev
  destination:
    server: https://kubernetes.default.svc
    namespace: payments-dev
  syncPolicy:
    automated:
      selfHeal: true      # revert any manual kubectl changes immediately
      prune: true         # delete resources removed from Git
    syncOptions:
      - CreateNamespace=true           # create namespace if missing
      - ApplyOutOfSyncOnly=true        # only re-apply resources that differ (faster)
      - ServerSideApply=true           # use server-side apply (handles large CRDs)
      - PrunePropagationPolicy=foreground  # wait for dependent resources to delete
```

**Behaviour:**
- Developer merges PR → ArgoCD syncs within 3 min (polling) or instantly (webhook)
- A developer `kubectl delete deployment payment-api -n payments-dev` → ArgoCD restores it within 3 min
- A developer removes a resource from Git → ArgoCD deletes the live resource

---

## Staging Application: Automated with Business Hours Window

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: payment-api-staging
  namespace: argocd
spec:
  project: payments
  source:
    repoURL: https://github.com/myorg/payments-gitops
    targetRevision: main
    path: overlays/staging
  destination:
    server: https://kubernetes.default.svc
    namespace: payments-staging
  syncPolicy:
    automated:
      selfHeal: true
      prune: true
    syncOptions:
      - CreateNamespace=true
      - ApplyOutOfSyncOnly=true
```

```yaml
# Sync window is defined at the AppProject level (Part 2)
# Or you can define it inline on the Application:
syncPolicy:
  syncOptions:
    - CreateNamespace=true
  # Add syncWindows inside AppProject, not on individual Applications
  # AppProject-level windows apply to all Applications in that project
```

---

## Production Application: Manual Sync, Self-Heal Only

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: payment-api-prod
  namespace: argocd
spec:
  project: payments
  source:
    repoURL: https://github.com/myorg/payments-gitops
    targetRevision: main
    path: overlays/prod
  destination:
    server: https://kubernetes.default.svc
    namespace: payments-prod
  syncPolicy:
    # NO automated block = manual sync only
    # selfHeal: true inside automated is omitted here intentionally
    # → someone must run: argocd app sync payment-api-prod
    syncOptions:
      - CreateNamespace=false            # namespace should already exist in prod
      - ApplyOutOfSyncOnly=true          # efficient: only re-apply changed resources
      - PrunePropagationPolicy=foreground
      - RespectIgnoreDifferences=true    # honour ignoreDifferences below
  ignoreDifferences:
    # Ignore fields that change in live cluster but aren't meaningful to reconcile:
    - group: apps
      kind: Deployment
      jsonPointers:
        - /spec/replicas     # HPA manages replicas; ignore drift here
    - group: ""
      kind: Service
      jsonPointers:
        - /spec/clusterIP    # auto-assigned; not in Git; would always show as diff
```

### Why Manual Sync in Production?

```
With automated sync + push to main:
  Anyone who merges a PR to main immediately triggers production deployment.
  A bad merge (typo, wrong image tag, broken config) = instant prod outage.
  No human review of the diff before it applies.

With manual sync:
  1. PR merged to main (code reviewed in GitHub)
  2. ArgoCD shows: payment-api-prod is OutOfSync
  3. Operator runs: argocd app diff payment-api-prod  → reviews exactly what changes
  4. Operator runs: argocd app sync payment-api-prod  → intentional deployment
  5. Operator watches: argocd app get payment-api-prod -w (monitors health)
  
  Adds ~5 minutes to deployment time; eliminates "accidental deploys to production".
```

---

## Self-Heal: What It Does and When to Use It

```
selfHeal: true means:
  ArgoCD continuously compares live state vs Git state.
  Any deviation (drift) is corrected by re-applying Git manifests.
  Correction happens within 3 minutes of drift detection.

When to enable selfHeal:
  → ALL environments: it enforces GitOps discipline
    "The cluster must always reflect Git" is the core GitOps promise
  → selfHeal: true is safe even in production because it only corrects DRIFT,
    it does not trigger deploys when Git changes (that's automated.selfHeal)

When NOT to worry about selfHeal:
  → If your team intentionally runs commands like kubectl scale or kubectl patch,
    selfHeal will revert them → this is expected behaviour
  → Solution: make the change in Git first, THEN the cluster converges

What selfHeal does NOT do:
  → It does NOT auto-deploy new commits to production
    (that would require automated.selfHeal which is different from just selfHeal: true)
  → It only reverts DRIFT (changes made outside ArgoCD), not new Git commits
```

---

## Prune: What It Does and When to Use It

```
prune: true means:
  Resources that exist in the cluster but do NOT exist in Git are DELETED.

Example:
  Git has: deployment.yaml, service.yaml, configmap.yaml
  Cluster has: deployment, service, configmap, secret (secret was added manually)
  
  With prune: true  → secret is DELETED
  With prune: false → secret remains (ArgoCD just shows it as "extraneous")

DANGER in production:
  - A Secret created by an operator (ExternalSecretsOperator output) is not in Git
    → With prune: true, ArgoCD deletes the Secret → application loses credentials
  - A PVC created by a StatefulSet is not in Git
    → With prune: true, ArgoCD deletes the PVC → DATA LOSS
  
  NEVER enable prune: true in production without auditing every resource in the namespace.

Safe to enable prune:
  → Dev and staging (ephemeral data, no PVCs with critical data)
  → Environments where ALL resources are managed by Git (no operators creating secondary resources)

Safe way to prune in production:
  argocd app sync payment-api-prod --prune --dry-run
  → Shows what WOULD be deleted → review → then run without --dry-run
```

---

## syncOptions Explained

```yaml
syncOptions:
  - CreateNamespace=true
    # ArgoCD creates the namespace if it doesn't exist before syncing resources into it
    # Alternative: manage namespace as a manifest in Git (more control)

  - ApplyOutOfSyncOnly=true
    # Only re-apply resources that have a diff vs live state
    # Skips resources that are already in sync → faster syncs, less load on API server
    # RECOMMENDED: enable always

  - ServerSideApply=true
    # Use kubectl apply --server-side instead of client-side apply
    # Handles: large ConfigMaps, CRDs with many fields, annotation size limits
    # Required for some large CRDs (Prometheus, Istio)

  - PrunePropagationPolicy=foreground
    # When deleting resources, wait for dependents to be deleted first (foreground cascading)
    # Prevents orphaned child resources
    # Alternatives: background (faster but may orphan), orphan (don't delete children)

  - RespectIgnoreDifferences=true
    # When pruning, don't delete resources that would normally be ignored
    # Use when ignoreDifferences is defined to prevent unexpected deletions

  - Replace=true
    # Use kubectl replace instead of apply for this resource
    # Use only when a resource cannot be updated in-place (some CRDs, immutable fields)
    # CAUTION: replace deletes and recreates, causing downtime for Deployments
```

---

## ignoreDifferences: Suppress Noise

```yaml
# Fields that the cluster modifies automatically (not controlled by Git)
# Without this, ArgoCD constantly shows these as OutOfSync even when nothing changed

spec:
  ignoreDifferences:
    # HPA modifies replicas — ArgoCD should not fight HPA
    - group: apps
      kind: Deployment
      jsonPointers:
        - /spec/replicas

    # Kubernetes auto-assigns clusterIP to Services
    - group: ""
      kind: Service
      jsonPointers:
        - /spec/clusterIP
        - /spec/clusterIPs

    # Webhooks auto-inject caBundle
    - group: admissionregistration.k8s.io
      kind: MutatingWebhookConfiguration
      jqPathExpressions:
        - '.webhooks[]?.clientConfig.caBundle'

    # Cert-manager injects CA into CRDs
    - group: apiextensions.k8s.io
      kind: CustomResourceDefinition
      jqPathExpressions:
        - '.spec.conversion.webhook.clientConfig.caBundle'
```

---

## Common Sync Policy Mistakes

| Mistake | Consequence | Fix |
|---|---|---|
| `automated: {}` in production | Any PR merge auto-deploys to prod without human review | Remove `automated` block; use manual sync with diff review |
| `prune: true` in prod with untracked resources | PVCs, Secrets from operators get deleted → data loss or outage | Audit all resources in namespace; disable prune in prod; use `--prune` flag per-sync with dry-run |
| No `selfHeal` anywhere | Manual `kubectl patch` creates permanent drift; no GitOps enforcement | Enable `selfHeal: true` in all environments |
| Missing `ApplyOutOfSyncOnly=true` | Every sync re-applies all resources even unchanged ones; noisy | Add to syncOptions in every Application |
| Not using `ignoreDifferences` for HPA-managed replicas | ArgoCD perpetually shows Deployment as OutOfSync (replicas differ) | Add `ignoreDifferences` for `/spec/replicas` on HPA-managed Deployments |
