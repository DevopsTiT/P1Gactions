# ArgoCD Best Practices Parts — Glossary

Every term used across all 10 part files, explained for an SRE beginner.

---

## Core ArgoCD Concepts

**ArgoCD**
A declarative GitOps continuous delivery tool for Kubernetes. Watches a Git repository for manifest changes and automatically synchronises the cluster state to match. The cluster always reflects what's in Git.

**GitOps**
An operational model where Git is the single source of truth for infrastructure and application configuration. All changes go through Git (PR → review → merge) rather than direct `kubectl apply` commands. Makes every change auditable and reversible.

**Application (ArgoCD CRD)**
The primary ArgoCD resource. Defines: which Git repo and path to read, which cluster and namespace to deploy to, and what sync policy to use. Each Application manages a specific set of Kubernetes resources.

**AppProject**
An ArgoCD CRD that groups Applications and enforces multi-tenancy boundaries. Restricts: which Git repos can be used (sourceRepos), which clusters/namespaces can be targeted (destinations), which resource kinds are allowed or blocked, and which users can sync.

**ApplicationSet**
An ArgoCD CRD that generates multiple Application objects from a single template + generator. Instead of writing one Application YAML per environment/team manually, ApplicationSet produces all of them automatically from a template.

**Sync**
The act of applying the desired state from Git to the live cluster. ArgoCD compares what's in Git with what's running in Kubernetes and applies the differences. Can be automatic (auto-sync) or manual (triggered by an operator).

**Sync Status**
Whether the live cluster state matches Git. `Synced` = cluster matches Git exactly. `OutOfSync` = there is a difference between Git and what's running. Does not describe whether the running application is healthy — that's Health Status.

**Health Status**
Whether the running Kubernetes resources are functioning correctly. `Healthy` = all resources are running and passing health checks. `Progressing` = deployment in progress. `Degraded` = something is broken (CrashLoopBackOff, ImagePullBackOff). `Missing` = resource does not exist in the cluster.

**Drift**
When the live cluster state diverges from what's in Git — usually because someone ran `kubectl edit` or `kubectl patch` directly. ArgoCD detects drift and shows `OutOfSync`. With `selfHeal: true`, ArgoCD automatically corrects drift.

**Self-Heal**
An ArgoCD sync policy setting (`selfHeal: true`) that automatically corrects any drift — reverting manual kubectl changes back to the Git-desired state within 3 minutes.

**Prune**
An ArgoCD sync policy setting (`prune: true`) that deletes resources from the cluster if they no longer exist in Git. Dangerous in production — can delete operator-generated resources (Secrets, PVCs) not tracked in Git.

**argocd-rbac-cm**
A Kubernetes ConfigMap in the `argocd` namespace that contains ArgoCD's RBAC policy rules. Defines roles, what each role can do, and which IdP groups map to which roles. The authoritative access control configuration.

**argocd-cm**
A Kubernetes ConfigMap in the `argocd` namespace that contains ArgoCD's core configuration: URL, SSO/OIDC settings, custom health checks (Lua scripts), ignore differences, and resource exclusions.

---

## Sync Policy Terms

**automated (syncPolicy)**
An ArgoCD Application setting that enables automatic syncing when ArgoCD detects a difference between Git and the cluster. Without this, all syncs are manual. `selfHeal` and `prune` are sub-settings within `automated`.

**syncOptions**
A list of flags that modify sync behaviour for a specific Application. Examples: `CreateNamespace=true` (create namespace if missing), `ApplyOutOfSyncOnly=true` (only re-apply changed resources), `ServerSideApply=true`.

**syncWindow**
A time window defined in an AppProject (or on an Application) that controls when syncs are allowed or denied. Example: deny syncs on weekends; allow only during business hours. Enforces change management processes.

**ignoreDifferences**
An Application-level setting that tells ArgoCD to ignore specific fields when comparing Git state to live state. Used for fields that Kubernetes or operators modify automatically (e.g. HPA-managed `replicas`, auto-assigned `clusterIP`).

**ApplyOutOfSyncOnly=true**
A syncOption that skips re-applying resources that are already in sync with Git. Only applies resources with actual differences. Makes syncs faster and reduces unnecessary API server load.

**ServerSideApply=true**
A syncOption that uses kubectl's server-side apply mode instead of client-side apply. Required for large objects (CRDs with many fields) that exceed annotation size limits.

**PrunePropagationPolicy=foreground**
A syncOption that makes ArgoCD wait for dependent resources to be fully deleted before proceeding. Prevents orphaned child resources. Options: foreground (wait), background (fast, may orphan), orphan (don't delete children).

---

## Sync Wave and Hook Terms

**Sync Wave**
A number assigned to a Kubernetes resource via annotation (`argocd.argoproj.io/sync-wave`). Resources in lower-numbered waves are applied and must reach Healthy status before resources in higher waves are applied. Creates ordered dependency resolution within a sync.

**Wave 0**
The default wave. Resources with no `sync-wave` annotation are in wave 0. Applied after any negative-wave resources are healthy.

**Hook**
A Kubernetes resource (usually a Job) annotated with `argocd.argoproj.io/hook: <type>`. Runs at a specific point in the sync lifecycle. Types: PreSync, Sync, PostSync, SyncFail, PostDelete.

**PreSync hook**
A Job that runs BEFORE ArgoCD applies any resources. Blocks the sync until it completes. Used for database migrations, pre-deployment backups, and drain operations.

**PostSync hook**
A Job that runs AFTER all Application resources reach Healthy status. Used for smoke tests, cache warming, and post-deployment notifications.

**SyncFail hook**
A Job that runs ONLY when a sync fails. Used for failure notifications (Slack alerts), automatic rollback triggers, and incident ticket creation.

**hook-delete-policy**
An annotation on a hook resource that controls when it is deleted. `HookSucceeded` = delete when the hook completes successfully (keeps failed Jobs for debugging). `BeforeHookCreation` = delete the old hook before creating a new one on the next sync. Always set this — without it, hook Jobs pile up indefinitely.

**activeDeadlineSeconds**
A Kubernetes Job field that sets a maximum execution time. After this many seconds, the Job is marked failed. Essential for hook Jobs to prevent indefinite blocking of the sync.

---

## Multi-Tenancy Terms

**sourceRepos**
An AppProject field listing which Git repositories are allowed as sources for Applications in this project. Never use `*` in production — explicitly list approved repositories only.

**destinations**
An AppProject field listing which cluster+namespace combinations are allowed targets. Use namespace wildcards like `payments-*` to scope a team to their namespace family without over-permissiveness.

**clusterResourceWhitelist**
An AppProject field that explicitly lists which cluster-scoped resource kinds (Namespace, ClusterRole, etc.) this project's Applications are allowed to create. Keep this minimal — most teams only need `Namespace`.

**namespaceResourceBlacklist**
An AppProject field that prevents Applications from creating specific namespace-scoped resource kinds. Use to block privilege escalation: deny `ClusterRoleBinding`, `ResourceQuota`, `PodSecurityPolicy`.

**Blast radius**
The maximum scope of damage if something goes wrong. Without AppProjects, all teams share the same blast radius (any app can affect any namespace). With AppProjects, each team's blast radius is limited to their allowed namespaces.

---

## RBAC and SSO Terms

**policy.csv**
The RBAC policy content stored in `argocd-rbac-cm`. Contains `p` (permission) and `g` (group mapping) lines. Format: `p, <role>, <resource>, <action>, <object>, allow/deny`.

**role:readonly**
ArgoCD's built-in read-only role. Can view all Applications, Projects, and Repositories. Cannot sync, delete, or modify anything. The recommended default for all authenticated users.

**role:admin**
ArgoCD's built-in full-admin role. Can do anything including deleting Applications and their managed resources, modifying AppProjects, and managing cluster credentials. Grant only to platform/SRE team.

**policy.default**
The RBAC role assigned to authenticated users who don't match any explicit role or group mapping. Set to `role:readonly` so authenticated but unconfigured users can view but not change anything.

**Dex**
An identity service bundled with ArgoCD that acts as an OIDC broker. Connects to external identity providers (GitHub, LDAP, SAML, Google) and translates their auth into OIDC tokens that ArgoCD can consume. You configure connectors in `argocd-cm.dex.config`.

**OIDC (OpenID Connect)**
An authentication protocol built on OAuth 2.0. ArgoCD uses it to verify user identity and group membership from an external provider (Okta, Google, GitHub). The token contains `groups` claims that ArgoCD maps to roles.

**SSO (Single Sign-On)**
Authentication where users log in once via their organisation's identity provider (IdP) and access multiple services. In ArgoCD: configured via Dex or direct OIDC. Eliminates per-user password management in ArgoCD.

**API token**
A long-lived (or time-limited) credential for CI/CD systems and automation tools to authenticate to ArgoCD without interactive login. Generated via `argocd account generate-token`. Always set an expiry; rotate regularly (90 days max).

**scopes**
An `argocd-rbac-cm` field that tells ArgoCD which claims from the OIDC token to use when evaluating group membership. Set to `[groups, email]` to use both claims.

---

## ApplicationSet Terms

**Generator**
The part of an ApplicationSet that produces a list of parameter sets. Each parameter set is used to fill in the Application template. Generator types: list, clusters, git, matrix, pullRequest.

**List generator**
The simplest ApplicationSet generator. You hardcode a list of parameter maps (e.g. dev, staging, prod). One Application is generated per list element.

**Git generator (directories)**
Scans a Git repository for directories matching a pattern. Creates one Application per matching directory. Used for "one folder = one app" patterns (cluster add-ons, team apps).

**Matrix generator**
Produces the Cartesian product of two generators. Example: 5 teams × 3 environments = 15 Applications, automatically. Avoids repetitive manual YAML.

**Pull Request generator**
Creates one Application per open Pull Request in a Git provider. Enables preview environments for every PR. Applications are automatically deleted when the PR is closed or merged.

**preserveResourcesOnDeletion**
An ApplicationSet `syncPolicy` setting. When `true`, if the ApplicationSet itself is deleted or a generator fails, existing Applications (and their managed resources) are NOT deleted. Safety net against accidental mass deletion.

**ignoreApplicationDifferences**
An ApplicationSet spec field that prevents the ApplicationSet controller from overwriting manual changes to generated Applications. Useful when operators manually patch specific Application fields.

**goTemplate**
An ApplicationSet `spec` field that enables Go template syntax (`{{.env}}`) instead of the default double-brace syntax (`{{env}}`). Allows more complex template logic.

---

## Image Updater Terms

**ArgoCD Image Updater**
A companion tool for ArgoCD that automatically updates container image tags in Git (or ArgoCD parameters) when new image versions are pushed to a container registry. Closes the CI→CD loop.

**Update strategy (Image Updater)**
How Image Updater decides which new tag to use. `semver` = latest matching semantic version constraint. `latest` = most recently pushed tag. `digest` = pin to exact image SHA.

**Write-back method**
How Image Updater applies the new tag. `git` = commits the new tag to the Git repository (preserves audit trail; recommended). `argocd` = overrides the Application parameter directly without a Git commit (faster; no audit trail).

**allow-tags**
An Image Updater annotation that filters which tags are considered for updates using a regular expression. Example: `'^v[0-9]+\.[0-9]+\.[0-9]+$'` allows only tags like `v1.2.3` and rejects `latest`, `main`, or `v1.0.0-rc1`.

**semver constraint**
A constraint string for the `semver` update strategy. Example: `>=1.0.0 <2.0.0` means: use the highest stable tag that is at least 1.0.0 but less than 2.0.0. Prevents accidental major version upgrades.

**IRSA (IAM Roles for Service Accounts)**
AWS mechanism to give the Image Updater pod an IAM role for ECR access, without storing static credentials. Annotate the Image Updater ServiceAccount with the IAM role ARN.

---

## HA and DR Terms

**argocd-application-controller**
The ArgoCD component that runs the reconciliation loop — continuously comparing desired Git state to live cluster state and triggering syncs when differences are found. Most critical component; if down, no syncs happen.

**argocd-repo-server**
The ArgoCD component that clones Git repositories and renders manifests (runs Kustomize, Helm, Jsonnet). CPU-intensive. Scale horizontally for faster parallel syncs.

**argocd-server**
The ArgoCD API server and UI backend. Stateless; handles all argocd CLI commands and web UI requests. Scale to 2-3 replicas for HA.

**Redis (ArgoCD)**
An in-memory cache used by ArgoCD to store application state, cluster state, and Git repo cache. Cache only — not a persistent data store. Data is rebuilt automatically after Redis restart. Use Redis Sentinel (3 replicas) for HA.

**Redis Sentinel**
A Redis HA configuration with 3 nodes (1 primary + 2 replicas) and Sentinel processes that monitor health and elect a new primary if the current one fails. Recommended for ArgoCD HA deployments.

**Sharding (application-controller)**
Distributing ArgoCD Applications across multiple application-controller instances so each instance manages a subset. Improves scalability for clusters with 500+ Applications or many registered clusters.

**argocd admin export**
A command that exports the complete ArgoCD state (Applications, AppProjects, repositories, cluster credentials, settings) to a YAML file. Run before every upgrade and store in S3.

**argocd admin import**
A command that restores ArgoCD state from a previously exported YAML file. Used during disaster recovery to rebuild all Applications and configuration from a backup.

**PodDisruptionBudget (PDB)**
A Kubernetes object that prevents too many pods of a deployment from being unavailable simultaneously. ArgoCD components (server, repo-server) should have `minAvailable: 2` to ensure HA during node drains and upgrades.

---

## Repository Structure Terms

**Monorepo**
A single Git repository containing manifests for all teams and applications. Pros: simple management, easy cross-team changes. Cons: merge conflicts at scale, one broken path affects all teams.

**Per-team repo (federated)**
Separate Git repositories per team. Each team owns and manages their own manifests independently. Pros: isolated blast radius. Cons: cross-cutting changes require multiple PRs.

**App-of-Apps**
A pattern where a root Application's source is a directory of Application CRDs. Syncing the root creates all child Applications, bootstrapping the entire cluster from a single `kubectl apply`.

**Base (Kustomize)**
The `base/` directory containing shared Kubernetes manifests that are common across all environments. Overlays patch the base to produce environment-specific configurations.

**Overlay (Kustomize)**
An `overlays/<env>/` directory containing environment-specific patches (image tags, replica counts, resource limits, config values) that are applied on top of the base. Each overlay produces a complete set of manifests for one environment.

**kustomization.yaml**
The Kustomize control file in each directory. Lists the resources to include, images to override, patches to apply, and namespace to set. ArgoCD reads this file when the Application's source uses Kustomize.

**targetRevision**
An Application field specifying which Git ref (branch, tag, or commit SHA) to read from. `main` follows the latest commit on main. `v1.2.3` is pinned to a tag. Using a tag in production is safer — no surprise changes.

**configMapGenerator (Kustomize)**
A Kustomize feature that generates a ConfigMap from literal values or files. With `disableNameSuffixHash: true`, the generated ConfigMap has a stable name (no hash appended), preventing unnecessary pod restarts on every sync.

**Helm values file**
A YAML file containing configuration values for a Helm chart. Multiple values files can be layered (base values + env-specific override) to produce environment-specific configurations without duplicating the entire chart.

---

## Secrets Management Terms

**Sealed Secrets**
A Kubernetes operator from Bitnami that encrypts Kubernetes Secrets into `SealedSecret` objects safe to commit to Git. Only the cluster's Sealed Secrets controller can decrypt them. Git sees only the encrypted form.

**External Secrets Operator (ESO)**
A Kubernetes operator that reads secrets from external stores (AWS Secrets Manager, HashiCorp Vault, Azure Key Vault) and creates Kubernetes Secrets. The actual secret values never touch Git — only references are in Git.

**ExternalSecret (CRD)**
The ESO custom resource that describes which external secret to fetch and how to project it into a Kubernetes Secret. Safe to commit to Git because it contains only references, not actual secret values.

**Vault (HashiCorp)**
A dedicated secrets management platform. Stores secrets with fine-grained access control, dynamic secrets (generated on demand), and audit logging. Integrated with ArgoCD via the Vault plugin or External Secrets Operator.

**kubeseal**
The CLI tool for Sealed Secrets. `kubeseal --cert pub-cert.pem < secret.yaml > sealed-secret.yaml` encrypts a Kubernetes Secret into a SealedSecret. The public cert is safe to share; decryption requires the private key in the cluster.

---

## Notification Terms

**argocd-notifications**
An ArgoCD component that sends alerts when Application sync/health state changes. Integrates with: Slack, PagerDuty, GitHub (commit status), Microsoft Teams, email. Leader-elected: one instance active at a time.

**Trigger (notifications)**
A condition that causes a notification to be sent. Examples: `on-sync-failed`, `on-health-degraded`, `on-deployed`. Defined in the `argocd-notifications-cm` ConfigMap.

**Template (notifications)**
The message format for a notification. Uses Go templates. Can include: app name, sync status, health status, Git commit SHA, revision, who triggered the sync.

**Subscription (notifications)**
The mapping between a trigger and a destination (Slack channel, PagerDuty service). Defined as annotations on Application objects or globally in the notifications ConfigMap.
