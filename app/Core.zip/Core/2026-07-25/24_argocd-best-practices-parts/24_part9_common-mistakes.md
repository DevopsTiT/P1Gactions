# ArgoCD Best Practices — Part 9: Common Mistakes and Correct Approaches

> **Every mistake here has caused a production incident or a prolonged investigation.** Read this before designing your ArgoCD setup to avoid the patterns that routinely cause trouble.

---

## Mistake 1: `role:admin` for All Users

```
MISTAKE:
  argocd-rbac-cm policy.csv:
    g, developers, role:admin
  
  "All developers need to be able to sync things"

WHY IT FAILS:
  role:admin means full control over:
    → All Applications in all projects
    → All AppProject definitions (can modify source/destination allow-lists)
    → All cluster credentials stored in ArgoCD
    → Ability to delete production Applications and their resources
    → Ability to register new clusters

  One compromised developer account = full cluster access.
  One accidental click = production Application deleted.

CORRECT APPROACH:
  Default for authenticated users: role:readonly
    → Can see all apps; cannot change anything

  Per-team deployer role: scoped to their project
    p, role:payments-dev, applications, get,  payments/*, allow
    p, role:payments-dev, applications, sync, payments/*, allow
    g, payments-team, role:payments-dev
    → Can sync their own apps; cannot touch notifications/ or platform/

  role:admin: SRE team only (2-3 people)
    g, sre-team, role:admin
```

---

## Mistake 2: `prune: true` in Production With Untracked Resources

```
MISTAKE:
  syncPolicy:
    automated:
      selfHeal: true
      prune: true   ← enabled in prod
  
  "We want the cluster to match Git exactly"

WHY IT FAILS:
  Kubernetes operators and controllers create secondary resources that ArgoCD
  did not create and that are NOT in Git:
  
  ExternalSecretsOperator creates: Secret (the actual secret value)
  cert-manager creates: Certificate, CertificateRequest, Order, Challenge objects
  StatefulSet creates: PVC (from volumeClaimTemplates)
  Prometheus Operator creates: ServiceMonitor, PrometheusRule for injected monitoring
  
  With prune: true:
    ArgoCD sees these resources in the cluster.
    They are not in Git.
    ArgoCD deletes them.
    
  Result:
    → All Secrets created by ExternalSecretsOperator: DELETED
    → All pods that mount these secrets: CrashLoopBackOff
    → Potential data loss if PVCs are deleted

CORRECT APPROACH:
  # Never enable prune: true on production applications.
  
  # When you need to prune orphaned resources:
  argocd app sync payment-api-prod --prune --dry-run
  → Reviews what would be deleted BEFORE it happens
  → Confirm it's safe, then remove --dry-run
  
  # For operator-generated resources: add to ignoreDifferences
  spec:
    ignoreDifferences:
      - group: ""
        kind: Secret
        name: payment-api-tls-cert   # cert-manager output; ignore; don't prune
```

---

## Mistake 3: No AppProject — Using the `default` Project

```
MISTAKE:
  All Applications created with: project: default
  
  "We have a small team; AppProjects seem complex"

WHY IT FAILS:
  The default project has:
    sourceRepos: ['*']     ← any Git repo
    destinations:
      - server: '*'        ← any cluster
        namespace: '*'     ← any namespace
  
  This means:
    → Team A's Application can accidentally be pointed at Team B's namespace
    → A Jenkinsfile error creates an Application that deploys to kube-system
    → No RBAC scoping: Team A developers can sync Team B's production applications
    → Supply chain risk: an Application can reference ANY Git repo (including external)

CORRECT APPROACH:
  One AppProject per team or domain:
  
  apiVersion: argoproj.io/v1alpha1
  kind: AppProject
  metadata:
    name: payments
    namespace: argocd
  spec:
    sourceRepos:
      - 'https://github.com/myorg/payments-gitops'   # ONLY this repo
    destinations:
      - namespace: 'payments-*'                       # ONLY payments namespaces
        server: https://kubernetes.default.svc
  
  Even for a single team, AppProject provides:
    → Explicit source/dest allow-list (visible documentation of intent)
    → Role scoping (RBAC doesn't bleed across projects)
    → syncWindows for deployment governance
```

---

## Mistake 4: Storing Secrets in Git Plaintext

```
MISTAKE:
  # overlays/prod/secret.yaml
  apiVersion: v1
  kind: Secret
  metadata:
    name: db-credentials
  type: Opaque
  stringData:
    password: "super-secret-production-password"

WHY IT FAILS:
  → Secret is visible to everyone with repo access
  → Git history preserves the secret forever (even after deletion)
  → Anyone who clones the repo, opens a PR, or has read access sees prod credentials
  → CI/CD systems, code scanners, and GitHub's own search can index it

CORRECT APPROACH — Option A: Sealed Secrets
  kubeseal --cert pub-cert.pem < secret.yaml > sealed-secret.yaml
  # sealed-secret.yaml is safe to commit (encrypted; only the cluster can decrypt)

CORRECT APPROACH — Option B: External Secrets Operator
  apiVersion: external-secrets.io/v1beta1
  kind: ExternalSecret
  metadata:
    name: db-credentials
  spec:
    refreshInterval: 1h
    secretStoreRef:
      name: aws-secretsmanager
      kind: SecretStore
    target:
      name: db-credentials
    data:
      - secretKey: password
        remoteRef:
          key: prod/payment-service/db
          property: password
  # The ExternalSecret references AWS Secrets Manager; the actual value never touches Git

CORRECT APPROACH — Option C: Vault + ESO
  # Same as ESO but with HashiCorp Vault as the backend
  # SecretStore configured with Vault AppRole credentials
```

---

## Mistake 5: Sync Waves on All Resources

```
MISTAKE:
  annotations:
    argocd.argoproj.io/sync-wave: "0"   on every ConfigMap
    argocd.argoproj.io/sync-wave: "1"   on every Deployment
    argocd.argoproj.io/sync-wave: "2"   on every Service
    argocd.argoproj.io/sync-wave: "3"   on every Ingress
  
  "We want everything in a specific order"

WHY IT FAILS:
  Wave N waits for ALL resources in wave N-1 to be Healthy before starting.
  10 ConfigMaps in wave 0 → must all be Healthy → then 5 Deployments in wave 1 →
  must all be Healthy → then 3 Services in wave 2 → etc.
  
  Result: a sync that could complete in 30 seconds takes 5+ minutes.
  
  Also: Kubernetes Services are Healthy immediately (they're just records).
  ConfigMaps and Secrets are Healthy immediately.
  Only Deployments, StatefulSets, and Jobs have meaningful Healthy states.

CORRECT APPROACH:
  Use waves ONLY for genuine ordering dependencies:
  
  Wave -5: Namespaces, CRDs (must exist before anything else)
  Wave -1: Secrets, ConfigMaps (if pods would crash without them)
  Wave 0:  Deployments, Services (default; no annotation needed)
  Wave 5:  HPAs, Ingresses (after pods are healthy)
  Wave 10: Smoke test Jobs (PostSync hook is usually better here)
  
  For 80% of applications: no waves needed at all.
  For 15%: only Namespace in -5, everything else in default 0.
  For 5%: PreSync hook for DB migration + default wave for everything else.
```

---

## Mistake 6: `hook-delete-policy` Not Set

```
MISTAKE:
  metadata:
    annotations:
      argocd.argoproj.io/hook: PreSync
      # No hook-delete-policy

WHY IT FAILS:
  The hook Job is never deleted after it completes.
  After 10 deploys: 10 completed migration Jobs in the namespace.
  After 100 deploys: 100 Jobs.
  
  Problems:
    → Namespace clutter; confusing during incident investigation
    → kubectl get jobs returns a long list of stale entries
    → Some future Job names may conflict with old Jobs (same Job name cannot be re-created)
    → etcd bloat: each Job object is stored in the Kubernetes API

CORRECT APPROACH:
  Always set hook-delete-policy:
  
  metadata:
    annotations:
      argocd.argoproj.io/hook: PreSync
      argocd.argoproj.io/hook-delete-policy: HookSucceeded
      # Delete the Job only when it succeeds
      # Failed Jobs are kept → you can debug with: kubectl logs job/<name>
      # After fixing: kubectl delete job <name> manually
```

---

## Mistake 7: Polling Git Only (No Webhook)

```
MISTAKE:
  ArgoCD default: polls Git every 3 minutes.
  No webhook configured.
  
  "3 minutes is fine; we don't need webhooks"

WHY IT FAILS:
  Problem A: 3-minute lag is noticeable for incident response
    → Hotfix committed → must wait up to 3 min before ArgoCD detects change
    → Then sync takes 1-2 min → total: up to 5 min from commit to deployed
  
  Problem B: For busy repos, GitHub rate-limits API polling
    → Multiple repos × multiple branches = many API calls per minute
    → GitHub rate limit (5,000 requests/hour for OAuth) can be hit
    → When rate-limited: ArgoCD cannot detect new commits → deployments freeze

CORRECT APPROACH:
  Configure webhook from GitHub/GitLab → ArgoCD:
  
  1. In ArgoCD: the webhook receiver is at /api/webhook
  2. In GitHub repo Settings → Webhooks → Add webhook:
     Payload URL: https://argocd.company.com/api/webhook
     Content type: application/json
     Secret: <same as webhooks.github.secret in argocd-secret>
     Events: push, pull_request
  
  With webhook:
    Push event → GitHub sends webhook → ArgoCD receives → immediate sync trigger
    No more 3-minute lag for most deployments
  
  Keep polling as fallback (for webhook delivery failures):
    ApplicationController polling interval: 3 minutes (default; keep it)
```

---

## Mistake 8: App-of-Apps Root With Auto-Prune

```
MISTAKE:
  root-app.yaml:
    syncPolicy:
      automated:
        selfHeal: true
        prune: true    ← enabled on root app

WHY IT FAILS:
  The root app reads Application CRDs from the bootstrap/applications/ directory.
  If you delete payments-prod.yaml from that directory (e.g. to rename it):
  
  1. ArgoCD detects: payments-prod Application no longer in Git
  2. prune: true → ArgoCD deletes the payments-prod Application CRD
  3. Deleting the Application CRD triggers Application finalizer
  4. Finalizer deletes ALL resources managed by the Application:
     Deployments, Services, PVCs, Secrets, Ingresses — all gone
  5. Production is wiped

CORRECT APPROACH:
  root-app.yaml:
    syncPolicy:
      automated:
        selfHeal: true
        prune: false    ← NEVER prune on root app
  
  To remove an Application: delete it manually
    argocd app delete payments-prod --cascade=false  (keeps resources)
    argocd app delete payments-prod --cascade=true   (removes resources — intentional)
  
  Then remove the Application YAML from Git.
  The root app will no longer manage it, but won't auto-delete it.
```

---

## Mistake 9: Ignoring Health Checks for Custom CRDs

```
MISTAKE:
  Using a custom Operator (e.g. Crossplane, Knative, Cert-manager).
  ArgoCD shows the CRD instances as "Healthy" immediately.
  
  "The Application is Healthy" (even though the Crossplane managed resource
  is actually failing to provision)

WHY IT FAILS:
  ArgoCD only knows the health of resources it has built-in health checks for:
    Deployment, StatefulSet, DaemonSet, Pod, Service, Job, PVC, Ingress, etc.
  
  For custom CRDs, ArgoCD defaults to "Healthy" on creation.
  It cannot introspect the custom resource's status without a Lua health check.
  
  Result: Application shows Healthy, but the actual workload is broken.
  Sync completes → no alerts fire → incident discovered by users.

CORRECT APPROACH:
  Write a Lua health check for each CRD kind you use:
  
  # In argocd-cm ConfigMap:
  data:
    resource.customizations.health.cert-manager.io_Certificate: |
      hs = {}
      if obj.status ~= nil then
        if obj.status.conditions ~= nil then
          for _, condition in ipairs(obj.status.conditions) do
            if condition.type == "Ready" then
              if condition.status == "True" then
                hs.status = "Healthy"
                hs.message = condition.message
                return hs
              elseif condition.status == "False" then
                hs.status = "Degraded"
                hs.message = condition.message
                return hs
              end
            end
          end
        end
        hs.status = "Progressing"
        hs.message = "Certificate is not yet ready"
      else
        hs.status = "Progressing"
        hs.message = "Waiting for status"
      end
      return hs
```

---

## Mistake 10: No Multi-Cluster Isolation

```
MISTAKE:
  ArgoCD manages prod, staging, and dev clusters.
  All service accounts for agents use the same ArgoCD credentials.
  
  "One ArgoCD is simpler to manage"

WHY IT FAILS:
  If a developer's AppProject misconfiguration or a compromised token
  allows writing to the production cluster:
    → Lateral movement: compromise dev cluster credentials → access prod cluster
    → ArgoCD server stores credentials for ALL registered clusters in etcd
    → An attacker who compromises ArgoCD can write to all clusters
  
  Also:
    → A mis-configured ApplicationSet can accidentally generate Applications
      that target the production cluster

CORRECT APPROACH:
  Option A: Hub-spoke model with restricted cluster access
    Hub ArgoCD: manages ALL clusters but with strict AppProject per cluster
    Each cluster: registered with a service account that has ONLY the permissions
    that AppProject needs (not cluster-admin)
  
  Option B: Separate ArgoCD per environment tier
    Dev ArgoCD: manages dev cluster only
    Staging ArgoCD: manages staging cluster only
    Prod ArgoCD: manages production cluster; access controlled via separate SSO groups
    
    Cons: multiple ArgoCD instances to manage
    Pros: full blast radius isolation; compromise of dev ArgoCD cannot touch prod

  Minimum: use AppProject destination restrictions so that Team A's Application
  cannot target Team B's namespace or a different cluster.
```

---

## Master Checklist: ArgoCD Setup Audit

```
Run this audit on your ArgoCD instance quarterly:

□ 1. No '*' in sourceRepos of any AppProject:
     kubectl get appproject -n argocd -o json | jq -r '.items[] |
       select(.spec.sourceRepos[] == "*") | .metadata.name'
     # Any output = fix it

□ 2. No '*' in destinations namespace of any AppProject:
     kubectl get appproject -n argocd -o json | jq -r '.items[] |
       select(.spec.destinations[].namespace == "*") | .metadata.name'

□ 3. Local admin account disabled:
     kubectl get configmap argocd-cm -n argocd \
       -o jsonpath='{.data.admin\.enabled}'
     # Should return: false

□ 4. No tokens with no expiry:
     argocd account list --output json | jq '.[] | select(.tokens != null) |
       .tokens[] | select(.expiresAt == 0) | .account'

□ 5. Default RBAC role is readonly:
     kubectl get configmap argocd-rbac-cm -n argocd \
       -o jsonpath='{.data.policy\.default}'
     # Should return: role:readonly

□ 6. No prune on root App-of-Apps:
     kubectl get application root-app -n argocd \
       -o jsonpath='{.spec.syncPolicy.automated.prune}'
     # Should return: false or nothing

□ 7. No plaintext secrets in Git (check manifests for Secret kind):
     git grep -r "kind: Secret" -- '*.yaml' | grep -v sealed | grep -v ExternalSecret

□ 8. All hook Jobs have hook-delete-policy:
     kubectl get jobs -A -o json | jq -r '.items[] |
       select(.metadata.annotations["argocd.argoproj.io/hook"] != null) |
       select(.metadata.annotations["argocd.argoproj.io/hook-delete-policy"] == null) |
       .metadata.namespace + "/" + .metadata.name'

□ 9. Backup taken in last 24 hours:
     aws s3 ls s3://company-argocd-backups/ | tail -5
     # Confirm there's a recent backup

□ 10. ArgoCD components all have PodDisruptionBudgets:
     kubectl get pdb -n argocd
```
