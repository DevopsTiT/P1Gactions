# Terraform Best Practices — Part 8: Resource Lifecycle — Prevent Accidental Destruction

> **The problem:** `terraform destroy` or a careless refactor can delete a production database. `lifecycle` blocks are the safety net that forces deliberate, intentional destruction of critical resources.

---

## What Lifecycle Blocks Do

```hcl
resource "aws_db_instance" "production" {
  lifecycle {
    prevent_destroy       = true   # block terraform destroy
    ignore_changes        = [...]  # ignore specific field changes
    create_before_destroy = true   # zero-downtime replacement
    replace_triggered_by  = [...]  # force replace when something else changes
  }
}
```

```
Each lifecycle argument serves a distinct purpose:

  prevent_destroy:       refuses to apply any plan that would DELETE this resource
  ignore_changes:        tells Terraform not to touch specific fields
                         (even if they differ between code and real state)
  create_before_destroy: creates the NEW resource before deleting the OLD one
                         (zero-downtime replacement for dependent resources)
  replace_triggered_by:  forces this resource to be replaced when a referenced
                         resource changes (used for EC2 when AMI changes)
```

---

## prevent_destroy: The Most Important Lifecycle Setting

```hcl
# Apply to every stateful production resource that would cause data loss if deleted

resource "aws_db_instance" "production" {
  identifier     = "company-prod-payments-rds"
  engine         = "postgres"
  engine_version = "15.4"

  lifecycle {
    prevent_destroy = true
    # Effect: if any plan would DESTROY this resource, terraform plan/apply fails with:
    # "Error: Instance cannot be destroyed
    #  on main.tf line 4, in resource "aws_db_instance" "production":
    #  4:   lifecycle {
    #  Resource company-prod-payments-rds has lifecycle.prevent_destroy set,
    #  but the plan calls for this resource to be destroyed."
    # This forces a deliberate two-step process to delete the database
  }
}

resource "aws_s3_bucket" "data" {
  bucket = "company-payment-data"
  lifecycle {
    prevent_destroy = true
  }
}

resource "aws_kms_key" "rds_encryption" {
  description = "KMS key for RDS encryption"
  lifecycle {
    prevent_destroy = true
    # KMS key deletion makes all data encrypted with it PERMANENTLY UNREADABLE
  }
}

resource "aws_eks_cluster" "production" {
  lifecycle {
    prevent_destroy = true
  }
}
```

**Resources that MUST have prevent_destroy = true in production:**

```
✓ aws_db_instance / aws_rds_cluster      — database deletion = data loss
✓ aws_s3_bucket (with data)              — bucket deletion removes all objects
✓ aws_kms_key                            — key deletion makes encrypted data unreadable
✓ aws_eks_cluster                        — cluster deletion = all workloads down
✓ aws_elasticache_cluster                — cache cluster deletion (stateful)
✓ aws_efs_file_system                    — shared filesystem deletion = data loss
✓ aws_dynamodb_table                     — table deletion = all data gone
✓ aws_secretsmanager_secret              — secret deletion breaks dependent services
```

**How to intentionally destroy a prevent_destroy resource (when needed):**

```bash
# Step 1: Remove prevent_destroy from the code (in a separate PR)
# git commit message: "Remove prevent_destroy from staging-rds for decommission"

# Step 2: Plan the destruction
terraform plan -destroy
# Review: confirm ONLY the intended resource is being destroyed

# Step 3: Apply
terraform apply -destroy -target=aws_db_instance.staging
# -target limits the destroy to only this resource

# Step 4: Restore prevent_destroy on the replacement resource
# This forces an intentional, reviewable step before any critical destruction
```

---

## ignore_changes: Prevent Overwriting External Changes

```hcl
resource "aws_db_instance" "main" {
  password = data.aws_secretsmanager_secret_version.db_pass.secret_string

  lifecycle {
    ignore_changes = [
      password,
      # Why: Secrets Manager automatic rotation changes the password externally.
      # If Terraform tracked this, every plan after rotation would show:
      # "~ password = (sensitive value) -> (sensitive value)" and try to reset it.
      # ignore_changes tells Terraform: "you set this on first create; leave it alone"

      snapshot_identifier,
      # Why: set on first create (from a snapshot); ignore on subsequent plans.
      # After creation, the DB exists and this field is no longer relevant.

      engine_version,
      # Why: minor version upgrades are applied in maintenance windows by AWS.
      # Terraform would see: engine_version "15.4" → "15.5" and try to revert it.
      # ignore_changes prevents this unwanted revert.
    ]
  }
}

resource "aws_autoscaling_group" "app" {
  lifecycle {
    ignore_changes = [
      desired_capacity,
      # Why: ASG desired capacity is managed by Cluster Autoscaler / KEDA.
      # If Terraform tracked this, every CA scale-up would show as drift.
      # Terraform set the initial value; CA manages it after that.
    ]
  }
}

resource "aws_eks_node_group" "workers" {
  lifecycle {
    ignore_changes = [
      scaling_config[0].desired_size,
      # Same reason as ASG: Cluster Autoscaler manages the count after initial creation
    ]
  }
}
```

**When NOT to use ignore_changes:**

```
Do NOT ignore_changes for fields that should be tracked:
  × Don't ignore instance_class (you want Terraform to apply instance type upgrades)
  × Don't ignore tags (you want tag changes to propagate)
  × Don't ignore security group rules (security changes must be tracked)

ignore_changes = all is a code smell:
  lifecycle {
    ignore_changes = all   ← means "Terraform doesn't manage this resource"
  }
  If a resource should not be managed by Terraform, use terraform state rm instead
```

---

## create_before_destroy: Zero-Downtime Replacement

```hcl
resource "aws_security_group" "app" {
  name   = "${local.name_prefix}-app-sg"
  vpc_id = var.vpc_id

  lifecycle {
    create_before_destroy = true
    # Why: Security Groups attached to resources cannot be deleted while in use.
    # If a SG rename forces replacement:
    #   Without create_before_destroy:
    #     1. Terraform destroys the old SG  ← ERROR: SG is still attached to EC2/RDS
    #     2. Terraform creates the new SG
    #   With create_before_destroy:
    #     1. Terraform creates the NEW SG (with new name)
    #     2. Terraform switches all attachments to the new SG
    #     3. Terraform destroys the OLD SG (now detached; deletion succeeds)
  }
}

resource "aws_launch_template" "app" {
  name_prefix = "${local.name_prefix}-lt-"
  # name_prefix (not name) + create_before_destroy = safe rolling replacement

  lifecycle {
    create_before_destroy = true
  }
}

resource "aws_acm_certificate" "main" {
  domain_name       = "*.payments.example.com"
  validation_method = "DNS"

  lifecycle {
    create_before_destroy = true
    # Why: when renewing/replacing a certificate, create the new one first.
    # This ensures the ALB listener is never pointing at an expired cert.
  }
}
```

---

## replace_triggered_by: Force Replacement on Change

```hcl
# Force EC2 instance replacement when the AMI changes
resource "aws_instance" "app" {
  ami           = data.aws_ami.amazon_linux.id
  instance_type = "m5.large"

  lifecycle {
    replace_triggered_by = [
      data.aws_ami.amazon_linux.id
      # When the AMI ID changes (new AMI available), this forces:
      # terraform plan -/+ destroy and recreate aws_instance.app
      # The instance gets a fresh OS with the new AMI
    ]
  }
}

# Force RDS parameter group replacement when a setting changes that requires
# a group recreation (not all parameter changes take effect without a restart)
resource "aws_db_parameter_group" "main" {
  name   = "${local.name_prefix}-pg"
  family = "postgres15"

  parameter {
    name  = "shared_preload_libraries"
    value = "pg_stat_statements"
  }

  lifecycle {
    create_before_destroy = true
    # Parameter group names must be unique; create the new one before deleting old
  }
}
```

---

## Lifecycle Best Practices Summary

```
Resource Type               prevent_destroy  ignore_changes           create_before_destroy
─────────────────────────────────────────────────────────────────────────────────────────
Production RDS              true             [password, engine_version] false (usually)
Production S3 with data     true             []                         false
KMS Key                     true             []                         false
EKS Cluster (prod)          true             []                         false
Security Group              false            []                         true (for renames)
Launch Template             false            []                         true
ACM Certificate             false            []                         true
ASG / Node Group            false            [desired_capacity]         false
Secrets Manager secret      true             [secret_string]            false
Dev/staging resources       false            []                         false (easy teardown)
```

---

## Common Lifecycle Mistakes

| Mistake | Consequence | Fix |
|---|---|---|
| No `prevent_destroy` on production database | `terraform apply` during refactor destroys 2 years of production data | Add `prevent_destroy = true` to every stateful production resource |
| `ignore_changes = all` | Terraform tracks nothing; resource drifts undetected | Only ignore specific fields you have a documented reason to ignore |
| Missing `create_before_destroy` on Security Groups | SG rename causes deletion before creation; attached resources return error | Add `create_before_destroy = true` to all Security Group resources |
| Forgetting to remove `prevent_destroy` before legitimate decommission | Decommission is blocked; engineer removes it in a rush without a PR review | Plan the removal in a dedicated PR; document the reason in the commit message |
