# Terraform Best Practices — Part 0: Overview, E2E Flow & Decision Tree

---

## E2E Flow Summary

```
1. ALWAYS-ON FOUNDATIONS
   → Remote state backend (S3 + DynamoDB) with encryption and locking
   → State is never stored locally or in Git
   → One workspace or one state file per environment (dev/staging/prod)
   → All providers and modules pinned to exact versions
   → Pre-commit hooks: fmt, validate, tflint, tfsec run on every commit

2. DAILY (team workflow)
   → Every change goes through PR: plan output is posted as a comment
   → No one runs terraform apply manually from their laptop in production
   → CI/CD pipeline (GitHub Actions / Atlantis) is the only apply path
   → Drift detection: scheduled plan runs compare state to real infra

3. WHEN MAKING A CHANGE
   → Write code → run fmt + validate + plan locally
   → Open PR → CI posts plan output → team reviews the plan (not just the code)
   → Merge → CI applies automatically (or requires manual approval for prod)
   → Verify: check the resource in AWS console / kubectl / argocd

4. MONTHLY REVIEW
   → Audit: any resources in AWS not tracked by Terraform state?
   → Unused variables, outputs, and modules → clean up
   → Provider and module version upgrades (check changelogs for breaking changes)
   → Cost review: Terraform-managed vs total AWS spend (untracked = manual = risk)

5. QUARTERLY CYCLE
   → Terraform version upgrade (test in dev first; then staging; then prod)
   → Module catalog review: any duplicated logic that should become a shared module?
   → State file health check: any dangling resources, tainted resources, deposed instances?
   → RBAC review: who has terraform apply access in CI? Who can push to the Terraform repo?

6. ROLLBACK / INCIDENT
   → Bad apply: revert the Git commit → CI applies the previous state
   → Resource needs emergency manual fix: fix in console → import into Terraform → update code
   → State corruption: restore from S3 versioned backup → investigate what diverged
   → Never use terraform destroy unless explicitly decommissioning; prefer targeted removals
```

---

## Decision Tree — "How should I structure this Terraform change?"

```
"How should I structure this Terraform change?"
│
├─ Is this a new resource or a change to existing?
│   ├─ NEW resource → write in the correct module or root → plan → PR
│   └─ CHANGE to existing → check if the change is destructive (forces replacement)
│       ├─ Destructive (recreate) → plan carefully; schedule maintenance window
│       └─ Non-destructive (in-place update) → standard PR flow
│
├─ Should this be a module or root-level code?
│   ├─ Used in more than one environment/team → module
│   ├─ Specific to one app/environment → root-level
│   └─ Third-party best practice exists → use a maintained community module
│
├─ Which environment does this touch?
│   ├─ dev     → apply can be automated on merge; low risk
│   ├─ staging → automated apply after plan review
│   └─ prod    → manual approval gate before apply; plan must be reviewed by ≥2 people
│
├─ Does this change touch the state backend or provider config?
│   → Extra caution: wrong change here locks out the whole team
│   → Test in dev; never change backend config and resource config in the same PR
│
├─ Is a resource drifting (plan shows unexpected changes)?
│   ├─ Resource was manually modified in console → update Terraform code to match OR
│   │   import the change → codify → never leave drift unresolved
│   └─ Provider updated and field interpretation changed → pin provider version until tested
│
└─ Need to remove a resource from Terraform management (not delete it)?
    → terraform state rm <resource.address>
    → Does NOT delete the real resource; only removes it from state tracking
```

---

## Tool Map

| Tool | What It Does | When to Use | Cadence |
|---|---|---|---|
| `terraform fmt` | Auto-formats all .tf files to canonical style | Before every commit | Every change |
| `terraform validate` | Checks syntax and internal consistency | Before plan | Every change |
| `terraform plan` | Shows what WILL change before applying | Before every apply | Every change |
| `terraform apply` | Applies the plan to real infrastructure | After plan review | Via CI only (prod) |
| `terraform state` | Inspect, move, import, remove state entries | Refactoring; drift fix; import | On demand |
| `terraform import` | Brings an existing resource under Terraform management | When manual resource needs tracking | On demand |
| `tflint` | Lints Terraform code for common mistakes and best practices | Pre-commit / CI | Every PR |
| `tfsec` / `checkov` | Security scanning of Terraform code (open S3 buckets, missing encryption) | Pre-commit / CI | Every PR |
| `terraform-docs` | Auto-generates module documentation from variables/outputs | Module publishing | On module change |
| Atlantis | Self-hosted PR automation: plan on PR open, apply on merge | CI/CD for Terraform | Always-on |
| `terraform workspace` | Manages multiple state files per repo (dev/staging/prod) | Multi-env management | Setup |
| `terragrunt` | DRY wrapper for Terraform: eliminates duplicated backend configs | Large multi-account orgs | Setup |

---

## Part Index

| Part | File | Content |
|---|---|---|
| Part 1 | part1_state-management.md | S3+DynamoDB backend, state key naming, lock table, state rules |
| Part 2 | part2_code-structure.md | Repo layout, module design, outputs, cross-stack data sharing |
| Part 3 | part3_version-pinning.md | Provider pinning, lock file, upgrade workflow |
| Part 4 | part4_variables-locals-outputs.md | Types, validation, object types, locals, tfvars per env |
| Part 5 | part5_tagging-strategy.md | Tag enforcement, merge(), propagation, required tag set |
| Part 6 | part6_cicd-pipeline.md | GitHub Actions workflow, OIDC IAM roles, apply-only-via-CI |
| Part 7 | part7_secrets-management.md | Secrets Manager, SSM, random_password — never in code |
| Part 8 | part8_resource-lifecycle.md | prevent_destroy, ignore_changes, create_before_destroy |
| Part 9 | part9_import.md | CLI import, import block, generate-config-out |
| Part 10 | part10_drift-detection.md | plan --detailed-exitcode, scheduled drift, resolution options |
| Mistakes | part11_common-mistakes.md | 10 mistakes with symptoms and correct approaches |
