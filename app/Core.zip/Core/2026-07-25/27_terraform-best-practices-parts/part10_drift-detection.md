# Terraform Best Practices — Part 10: Drift Detection and Compliance

> **Drift = the real infrastructure no longer matches the Terraform state.** Causes: manual console changes, AWS automatic updates (minor version patches, security group rule changes), or broken applies. Undetected drift accumulates until it causes an incident.

---

## What Drift Looks Like

```
Scenario A: Developer hotfix under pressure
  → Production is down at 2 AM
  → Engineer logs into AWS console → changes RDS parameter group → service recovers
  → No time to update Terraform
  → Next plan: "~ parameter_group_name = company-prod-pg → default.postgres15"
  → Team doesn't know why; someone applies → production regresses to the old parameter group

Scenario B: AWS automatic update
  → AWS minor-version patches RDS engine: 15.4 → 15.5
  → Terraform has: engine_version = "15.4"
  → Next plan: "~ engine_version = 15.4 → 15.5"
  → Engineer applies without reading: engine is downgraded (rolling restart happens)

Scenario C: Untracked resource
  → Data analyst created an S3 bucket "company-analytics-raw" directly in console
  → It's not in Terraform state
  → No tags, no encryption, no lifecycle policy
  → AWS Config flags it as non-compliant
  → Nobody knows who owns it or what it contains

Drift is always a liability:
  → Security: untracked resources have no enforced security standards
  → Compliance: auditors ask "show me all production resources" — untracked = gap
  → Cost: untracked resources may be paying for unused capacity
  → Reliability: drift means the next apply may produce unexpected changes
```

---

## Detecting Drift: terraform plan

The simplest drift detector is `terraform plan`. A non-empty plan = drift (or a pending change).

```bash
# Run plan with detailed exit code
terraform plan -detailed-exitcode

# Exit codes:
# 0 = no changes (infrastructure matches Terraform state — no drift)
# 1 = error (plan failed to run — check credentials, syntax)
# 2 = changes detected (drift OR a pending code change)

# Use -detailed-exitcode in automation:
terraform plan -detailed-exitcode -no-color 2>&1
EXIT_CODE=$?
if [ $EXIT_CODE -eq 2 ]; then
  echo "DRIFT DETECTED — review the plan output"
  exit 1
elif [ $EXIT_CODE -eq 1 ]; then
  echo "PLAN FAILED — check errors above"
  exit 1
else
  echo "No drift detected"
fi
```

---

## Scheduled Drift Detection in GitHub Actions

Run a plan every weekday morning. If the plan is non-empty, create a GitHub issue.

```yaml
# .github/workflows/drift-detection.yml
name: Terraform Drift Detection

on:
  schedule:
    - cron: '0 9 * * 1-5'   # 9:00 AM UTC, Monday through Friday
  workflow_dispatch:           # allow manual trigger

env:
  TF_VERSION: "1.8.0"
  AWS_REGION: "ap-northeast-1"

jobs:
  drift-check:
    name: "Check for Drift — ${{ matrix.path }}"
    runs-on: ubuntu-latest
    strategy:
      matrix:
        path:
          - environments/prod/networking
          - environments/prod/platform
          - environments/prod/payment-service
      fail-fast: false   # continue checking all paths even if one drifts

    permissions:
      id-token: write
      contents: read
      issues: write

    steps:
      - uses: actions/checkout@v4

      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: ${{ env.TF_VERSION }}

      - name: Configure AWS Credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/github-actions-terraform-plan
          aws-region: ${{ env.AWS_REGION }}

      - name: Terraform Init
        run: terraform init
        working-directory: ${{ matrix.path }}

      - name: Check for Drift
        id: plan
        run: |
          terraform plan \
            -detailed-exitcode \
            -no-color \
            2>&1 | tee plan_output.txt
          echo "exit_code=${PIPESTATUS[0]}" >> $GITHUB_OUTPUT
        working-directory: ${{ matrix.path }}
        continue-on-error: true

      - name: Open GitHub Issue if Drift Found
        if: steps.plan.outputs.exit_code == '2'
        uses: actions/github-script@v7
        with:
          script: |
            const path = '${{ matrix.path }}';
            const body = `## Terraform Drift Detected

            **Path:** \`${path}\`
            **Detected at:** ${{ github.event.head_commit.timestamp || 'scheduled run' }}

            Terraform plan shows infrastructure that does not match the Terraform state.
            This means either:
            - A resource was modified manually in the AWS console
            - An AWS-managed update changed a resource attribute
            - A recent apply failed partway through

            **Action required:**
            1. Review the plan output in the workflow run
            2. Either update Terraform code to accept the change OR run terraform apply to revert
            3. Investigate and document the root cause
            4. Close this issue once drift is resolved

            > Workflow run: ${{ github.server_url }}/${{ github.repository }}/actions/runs/${{ github.run_id }}
            `;

            // Check if a drift issue already exists for this path
            const issues = await github.rest.issues.listForRepo({
              owner: context.repo.owner,
              repo: context.repo.repo,
              labels: ['terraform-drift'],
              state: 'open'
            });

            const exists = issues.data.some(i => i.title.includes(path));
            if (!exists) {
              await github.rest.issues.create({
                owner: context.repo.owner,
                repo: context.repo.repo,
                title: `🚨 Terraform Drift: ${path}`,
                body,
                labels: ['terraform-drift', 'terraform', 'prod']
              });
            }
```

---

## Resolving Drift: Three Options

### Option A — Codify the Manual Change (Accept the Drift)

Use when the manual change was correct and should be kept.

```bash
# Example: engineer changed RDS parameter group manually — it was a correct fix

# Step 1: Read the plan to understand exactly what drifted
terraform plan
# Output:
# ~ resource "aws_db_parameter_group" "main" {
#     ~ parameter {
#         ~ value = "0" -> "1"   (the engineer changed log_connections to on)
#       }
#   }

# Step 2: Update the Terraform code to match the real state
# In main.tf: change log_connections default from "0" to "1"

# Step 3: Plan again — should show no changes now
terraform plan
# Expected: "No changes. Your infrastructure matches the configuration."

# Step 4: Commit the code change
git add main.tf
git commit -m "fix: enable log_connections on RDS parameter group (was manually set in prod)"

# Step 5: PR and merge (CI will run a plan to verify)
```

### Option B — Revert the Drift (Apply Terraform State)

Use when the manual change was wrong or unauthorised.

```bash
# The real infrastructure was changed away from what Terraform expects.
# Applying will revert it back to the Terraform-defined state.

# Step 1: Review the plan carefully
terraform plan
# Confirm: "yes, I want the real resource to be changed back to this"

# Step 2: Apply
terraform apply
# Terraform updates the real resource to match the .tf code

# Step 3: Document in Slack/ticket: what drifted, who changed it, why it was reverted
```

### Option C — Remove from State (Stop Tracking the Resource)

Use when a resource should no longer be managed by Terraform (but should not be deleted).

```bash
# Example: a manually-created resource that you want to leave as-is but not manage

# terraform state rm removes the resource from Terraform state
# It does NOT delete the real resource in AWS
terraform state rm aws_db_instance.legacy_db

# After removal:
# - terraform plan no longer shows this resource
# - terraform apply no longer touches this resource
# - The real RDS instance continues running unchanged
```

---

## Finding Resources Not Managed by Terraform

Terraform only knows about resources in its state. Resources created manually are invisible to it.

```bash
# Method 1: AWS Config rule for required tags
# Resources without managed-by=terraform are potentially untracked

aws resourcegroupstaggingapi get-resources \
  --region ap-northeast-1 \
  --query 'ResourceTagMappingList[?!contains(Tags[*].Key, `ManagedBy`)].[ResourceARN]' \
  --output table

# Method 2: Compare AWS resources to Terraform state for a specific service
# Example: find RDS instances not in Terraform state

# Get all RDS instances in AWS
aws rds describe-db-instances \
  --query 'DBInstances[*].DBInstanceIdentifier' \
  --output text

# Get all RDS instances in Terraform state
terraform state list | grep aws_db_instance

# Compare the two lists — anything in AWS but not in state = untracked

# Method 3: Use cloud-custodian or Steampipe for large-scale drift analysis
# Steampipe query: find all S3 buckets without managed-by=terraform tag
# select name, tags from aws_s3_bucket
# where tags -> 'ManagedBy' is distinct from '"terraform"'
```

---

## Drift from AWS Automatic Updates

Some drift is caused by AWS itself (not manual changes):

```
Drift source                          How to handle
──────────────────────────────────────────────────────────────────────────
Minor engine version upgrades (RDS)   Add to ignore_changes: [engine_version]
AMI patch versions (launch template)  Update Terraform to use SSM parameter for latest AMI
Certificate expiry rotation (ACM)     ACM auto-renews; use ignore_changes: [tags]
EKS platform version updates          Tracked in Terraform; accept and apply
IAM policy timestamp changes          Use ignore_changes: [update_date]
S3 bucket policy owner updates        Use ignore_changes: [policy] carefully
```

---

## Common Drift Detection Mistakes

| Mistake | Consequence | Fix |
|---|---|---|
| Running drift detection with `plan` only (no `-detailed-exitcode`) | Exit code is always 0; CI never reports drift | Use `-detailed-exitcode`; exit code 2 = drift |
| Drift issue created once but never resolved | Issue backlog grows; drift becomes "normal" | SLO: resolve all drift issues within 1 week; add to on-call responsibilities |
| All drift treated as "apply to revert" | A correct manual hotfix is reverted; incident repeats | Investigate FIRST: was the manual change correct? Codify it if so. |
| No scheduled drift detection | Drift accumulates for months unnoticed | Scheduled weekday plan runs with GitHub issue on drift |
| Drift detection only for prod | Dev/staging drift is also a signal of process gaps | Run drift detection across all environments |
