# Terraform Best Practices — Part 5: Tagging Strategy

> **Every AWS resource managed by Terraform must have consistent tags.** Tags are how you trace cost, enforce compliance, find orphaned resources, and prove to auditors that every resource is managed as infrastructure-as-code.

---

## Why Tags Are Critical

```
Without tags:
  AWS bill shows $12,000/month; you cannot tell which team or service spent what
  An EC2 instance exists with no owner; nobody knows if it's safe to delete
  Compliance audit asks: "Which resources are in scope for PCI DSS?" — no answer
  A Terraform state gets corrupted; no way to identify which resources belong to it

With consistent tags:
  Cost Explorer: filter by team=payments → see exact spend per team
  AWS Config rule: flag any resource missing managed-by=terraform → untracked resources
  Security audit: filter by environment=prod → see all production resources in scope
  After a state corruption: find resources by terraform managed-by tag → re-import
```

---

## The Required Tag Set

```
Minimum required tags on every resource:

Tag Key       Example Values              Purpose
────────────────────────────────────────────────────────────────────────
environment   dev | staging | prod        Environment isolation; compliance scope
team          payments | platform | sre   Cost attribution; ownership
managed-by    terraform                   Identifies IaC-managed resources
project       company-name               Top-level cost group
cost-center   CC-1234                    Finance allocation; chargeback
```

**Additional tags for specific contexts:**

```
Tag Key       Example Values              When to Use
────────────────────────────────────────────────────────────────────────
Name          company-prod-rds            Human-readable; AWS console display
              payments-api-sg
data-class    public | internal |         For compliance (PCI, HIPAA): classify
              confidential | restricted   data sensitivity
backup        required | not-required     For backup automation scripts
service       payments-api                For microservice-specific billing
version       v2.3.1                     For immutable infra (AMIs, Lambda)
```

---

## Implementing Tags via locals.common_tags

```hcl
# locals.tf — the tag map is defined once and applied everywhere

locals {
  common_tags = {
    Project     = var.project
    Environment = var.environment
    Team        = var.team
    ManagedBy   = "terraform"
    CostCenter  = var.cost_center
  }
}
```

```hcl
# variables.tf — the inputs that feed the tag map

variable "project" {
  description = "Project name applied to all resource tags"
  type        = string
}

variable "environment" {
  description = "Deployment environment: dev | staging | prod"
  type        = string
  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment must be one of: dev, staging, prod."
  }
}

variable "team" {
  description = "Team responsible for this infrastructure"
  type        = string
}

variable "cost_center" {
  description = "Finance cost center code for chargeback"
  type        = string
}
```

---

## Applying Tags with merge()

The `merge()` function applies common tags first, then resource-specific tags. If a key exists in both, the resource-specific value wins.

```hcl
# main.tf — apply tags on every resource

resource "aws_db_instance" "main" {
  identifier    = "${local.name_prefix}-rds"
  instance_class = var.rds_config.instance_class

  tags = merge(local.common_tags, {
    Name      = "${local.name_prefix}-rds"
    Role      = "database"
    DataClass = "confidential"
  })
  # Result:
  # {
  #   "Project"     = "company",
  #   "Environment" = "prod",
  #   "Team"        = "payments",
  #   "ManagedBy"   = "terraform",
  #   "CostCenter"  = "CC-1234",
  #   "Name"        = "company-prod-rds",
  #   "Role"        = "database",
  #   "DataClass"   = "confidential"
  # }
}

resource "aws_security_group" "app" {
  name   = "${local.name_prefix}-app-sg"
  vpc_id = var.vpc_id

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-app-sg"
    Role = "application"
  })
}

resource "aws_s3_bucket" "data" {
  bucket = "${local.name_prefix}-payment-data"

  tags = merge(local.common_tags, {
    Name      = "${local.name_prefix}-payment-data"
    DataClass = "restricted"
    Backup    = "required"
  })
}
```

---

## Tag Propagation to EC2 Instances via ASG

Auto Scaling Groups create EC2 instances. To tag those instances, use `propagate_at_launch = true`.

```hcl
resource "aws_autoscaling_group" "app" {
  name                = "${local.name_prefix}-asg"
  min_size            = 2
  max_size            = 10
  desired_capacity    = 3
  vpc_zone_identifier = var.private_subnet_ids

  # Static Name tag with propagation
  tag {
    key                 = "Name"
    value               = "${local.name_prefix}-instance"
    propagate_at_launch = true
  }

  # Propagate all common tags dynamically (no hardcoding)
  dynamic "tag" {
    for_each = local.common_tags
    content {
      key                 = tag.key
      value               = tag.value
      propagate_at_launch = true
    }
  }
  # Every EC2 instance launched by this ASG gets all common_tags + Name tag
}
```

---

## Default Tags Provider Configuration (Apply Everywhere Automatically)

AWS provider 3.38+ supports `default_tags` — applies to ALL resources managed by that provider instance.

```hcl
# providers.tf

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project    = var.project
      ManagedBy  = "terraform"
      CostCenter = var.cost_center
    }
  }
}
```

**With default_tags:** you don't need to add `Project`, `ManagedBy`, and `CostCenter` to every resource's `tags` block. They are applied automatically.

```hcl
# With default_tags, the resource only needs its own specific tags:
resource "aws_instance" "app" {
  ami           = data.aws_ami.amazon_linux.id
  instance_type = "m5.large"

  tags = {
    Name        = "${local.name_prefix}-app"
    Environment = var.environment   # still add per-resource where it varies
    Team        = var.team
  }
  # default_tags adds: Project, ManagedBy, CostCenter automatically
}
```

**Tradeoff:** `default_tags` and `tags` on resources can conflict. Use consistently across the whole provider block; don't mix half default_tags and half explicit tags.

---

## Enforcing Tags via AWS Config

Use an AWS Config rule to alert on resources missing required tags:

```hcl
resource "aws_config_config_rule" "required_tags" {
  name = "required-tags-check"

  source {
    owner             = "AWS"
    source_identifier = "REQUIRED_TAGS"
  }

  input_parameters = jsonencode({
    tag1Key   = "ManagedBy"
    tag1Value = "terraform"
    tag2Key   = "Environment"
    tag3Key   = "Team"
    tag4Key   = "CostCenter"
  })

  # This rule flags any resource missing these tags as NON_COMPLIANT
  # Integrate with Security Hub to see compliance score
}
```

**Use in cost reports:**

```bash
# Cost Explorer CLI: see spend per team
aws ce get-cost-and-usage \
  --time-period Start=2026-07-01,End=2026-07-31 \
  --granularity MONTHLY \
  --metrics UnblendedCost \
  --group-by Type=TAG,Key=Team \
  --query 'ResultsByTime[0].Groups[*].{Team:Keys[0], Cost:Metrics.UnblendedCost.Amount}' \
  --output table

# Find untagged resources (missing managed-by=terraform):
aws resourcegroupstaggingapi get-resources \
  --tag-filters "Key=ManagedBy,Values=terraform" \
  --query 'length(ResourceTagMappingList)'
```

---

## Common Tagging Mistakes

| Mistake | Consequence | Fix |
|---|---|---|
| Inconsistent tag key casing | `Environment` and `environment` are different tags; AWS Config rules miss half the resources | Define tag keys once in `locals.common_tags`; never type them manually in resource blocks |
| Not tagging ALL resource types | Security Groups, IAM roles, KMS keys, CloudWatch alarms have no tags; invisible in billing | Every resource that supports tags must have `tags = merge(local.common_tags, {...})` |
| Tags only on compute (EC2, RDS) | Storage (S3, EBS), networking (VPC, SG), and security (KMS) costs are unattributed | Apply to every tagable resource type |
| Tag values with spaces | `"Cost Center"` → becomes `"Cost+Center"` in some AWS APIs; breaks filters | Use hyphens: `"cost-center"` or underscores: `"cost_center"` |
| No `propagate_at_launch` on ASG tags | EC2 instances launched by the ASG have no tags; cost and compliance tools can't see them | Add `propagate_at_launch = true` on every ASG tag block |
