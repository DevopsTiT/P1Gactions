# Terraform Best Practices — Part 9: Import — Bringing Manual Resources Under Terraform

> **The problem it solves:** Someone created a VPC, RDS instance, or S3 bucket manually in the AWS console. Terraform doesn't know it exists. If you run `terraform apply` with that resource defined in code, Terraform tries to create a duplicate. Import tells Terraform: "that real resource IS this code block."

---

## What Import Does (and Does Not Do)

```
terraform import:
  DOES:  add an existing AWS resource to the Terraform state file
  DOES:  allow Terraform to manage the resource going forward
  DOES NOT: generate .tf code for the resource (you write that manually)
  DOES NOT: change the real resource (no API calls other than a read)
  DOES NOT: automatically reconcile the code with the real resource
            (you must manually align your .tf code with what was imported)

After import, running terraform plan may show changes:
  → These are differences between your .tf code and the real resource's configuration
  → You must adjust the .tf code until the plan shows "No changes"
  → Only then is the resource fully managed by Terraform
```

---

## Method 1: CLI Import (Terraform < 1.5)

The traditional way. Requires the resource block to exist in your .tf files before importing.

```bash
# Step 1: Write the resource block in your .tf code FIRST
# This is required — terraform import needs the resource address to map to

# Example: import an existing EC2 instance
# First, add to main.tf:
# resource "aws_instance" "web_server" {
#   ami           = "ami-0abc123"
#   instance_type = "m5.large"
# }

# Step 2: Find the AWS resource identifier
# EC2 instance:   instance ID (i-0123456789abcdef)
# S3 bucket:      bucket name
# RDS instance:   DB identifier
# SG:             security group ID (sg-0abc123)
# VPC:            vpc ID (vpc-0abc123)
# IAM role:       role name
# Route53 record: ZONE_ID_DNS_NAME_TYPE

# Step 3: Run the import
terraform import aws_instance.web_server i-0123456789abcdef
terraform import aws_s3_bucket.data company-payment-data
terraform import aws_db_instance.main prod-payments-rds
terraform import aws_security_group.app sg-0abc1234def56789a
terraform import aws_iam_role.eks_node_role eks-node-role-prod
terraform import aws_route53_record.api Z1234567890/api.example.com/A

# Step 4: Run plan to see what differs between your code and the imported state
terraform plan
# You will likely see many changes — your .tf code doesn't match the real config
# Example output:
# ~ resource "aws_instance" "web_server" {
#     ~ instance_type = "m5.large" -> "t3.medium"   ← real instance is t3.medium
#     ~ tags = {
#         + "Environment" = null -> "prod"           ← code has a tag the real resource doesn't
#       }
#   }

# Step 5: Reconcile — update your .tf code to match the real resource
# OR update the real resource (via apply) to match what you want in code
# Goal: terraform plan shows "No changes. Your infrastructure matches the configuration."
```

---

## Method 2: Import Block (Terraform 1.5+ — Preferred)

Declarative: define the import in your .tf code instead of running a CLI command. No CLI command needed; the import happens during `terraform apply`.

```hcl
# import.tf — declare what to import

# Import an existing EC2 instance
import {
  to = aws_instance.web_server
  id = "i-0123456789abcdef"
}

# Import an existing RDS instance
import {
  to = aws_db_instance.main
  id = "prod-payments-rds"
}

# Import an existing S3 bucket
import {
  to = aws_s3_bucket.data
  id = "company-payment-data"
}

# Import an existing Security Group
import {
  to = aws_security_group.app
  id = "sg-0abc1234def56789a"
}
```

**How to use the import block:**

```bash
# 1. Add the import block to import.tf
# 2. Add the matching resource block to main.tf (or another .tf file)
# 3. Run plan — Terraform shows the import will happen:
terraform plan
# Output:
#   Plan: 1 to import, 0 to add, 0 to change, 0 to destroy.

# 4. Apply — runs the import and the plan
terraform apply
# The import block is consumed (you can delete it after apply or leave it)

# Benefits over CLI import:
# → Import is documented in code (visible in PR review)
# → Import can be reviewed before applying
# → Import is repeatable if state is lost
# → No need to remember the correct CLI command format for each resource type
```

---

## Method 3: Generate Config from Import (Terraform 1.6+)

Terraform can generate the .tf code for you from an existing resource. Use this as a starting point — never commit the generated code directly without reviewing.

```bash
# 1. Add the import block (no resource block yet — you want Terraform to generate it)
# import.tf:
# import {
#   to = aws_db_instance.main
#   id = "prod-payments-rds"
# }

# 2. Generate the config
terraform plan -generate-config-out=imported_resources.tf

# Terraform writes the full resource block to imported_resources.tf
# Example output in imported_resources.tf:
# resource "aws_db_instance" "main" {
#   allocated_storage                     = 500
#   auto_minor_version_upgrade            = true
#   backup_retention_period               = 14
#   backup_window                         = "03:00-04:00"
#   copy_tags_to_snapshot                 = false
#   db_name                               = "payments"
#   db_subnet_group_name                  = "company-prod-subnet-group"
#   deletion_protection                   = true
#   engine                                = "postgres"
#   engine_version                        = "15.4"
#   identifier                            = "prod-payments-rds"
#   instance_class                        = "db.r6g.large"
#   ... (many more generated fields)
# }

# 3. REVIEW and CLEAN UP the generated code:
#   → Remove computed-only fields (Terraform will set these automatically)
#   → Remove fields you don't want to manage
#   → Replace hardcoded values with variables and locals
#   → Add lifecycle blocks where needed
#   → Remove the redundant fields (the generated code is verbose)

# 4. Apply the import
terraform apply

# 5. Verify the plan shows "No changes" after the import
terraform plan
# Expected: "No changes. Your infrastructure matches the configuration."
```

---

## Finding the Correct Import ID per Resource Type

```
Resource Type                    ID Format                           Example
─────────────────────────────────────────────────────────────────────────────────────────
aws_instance                     instance-id                         i-0abc123def456789a
aws_s3_bucket                    bucket-name                         company-payment-data
aws_db_instance                  db-identifier                       prod-payments-rds
aws_rds_cluster                  cluster-identifier                  prod-aurora-cluster
aws_security_group               sg-id                               sg-0abc123
aws_vpc                          vpc-id                              vpc-0abc123
aws_subnet                       subnet-id                           subnet-0abc123
aws_iam_role                     role-name                           eks-node-role
aws_iam_policy                   arn                                 arn:aws:iam::123:policy/MyPolicy
aws_eks_cluster                  cluster-name                        prod-eks
aws_eks_node_group               cluster-name:node-group-name        prod-eks:workers
aws_kms_key                      key-id                              1234abcd-12ab-34cd-56ef-...
aws_secretsmanager_secret        arn OR name                         prod/payment-service/db-password
aws_cloudwatch_log_group         name                                /aws/eks/prod-eks
aws_route53_record               zone-id_record-name_record-type     Z1234_api.example.com_A
aws_alb (aws_lb)                 arn                                 arn:aws:elasticloadbalancing:...
aws_elasticache_cluster          cluster-id                          prod-redis
aws_dynamodb_table               table-name                          payments-table

# Find the correct import ID in the AWS provider docs:
# https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/<resource>
# Look for the "Import" section at the bottom of each resource's docs page
```

---

## Common Import Scenarios

### Scenario 1: VPC Created Manually Before Terraform

```bash
# 1. Get the VPC ID
aws ec2 describe-vpcs --filters "Name=tag:Name,Values=prod-vpc" \
  --query 'Vpcs[0].VpcId' --output text
# Output: vpc-0abc1234def56789a

# 2. Write the resource block in main.tf
# resource "aws_vpc" "main" {
#   cidr_block           = "10.0.0.0/16"
#   enable_dns_hostnames = true
#   enable_dns_support   = true
#   tags = { Name = "prod-vpc" }
# }

# 3. Import
terraform import aws_vpc.main vpc-0abc1234def56789a

# 4. Plan — reconcile any differences
terraform plan
```

### Scenario 2: EKS Cluster Created by eksctl

```bash
# Find the cluster name
aws eks list-clusters --query 'clusters' --output text

# Import
terraform import aws_eks_cluster.main prod-eks

# Plan — eksctl may have set fields Terraform doesn't manage
# May show: dns_cluster_ip, bootstrap_extra_args, etc.
# Adjust code OR add ignore_changes for eksctl-managed fields
```

### Scenario 3: Import Multiple Resources at Once (Using Import Blocks)

```hcl
# import.tf — batch import of a VPC and its subnets

import {
  to = aws_vpc.main
  id = "vpc-0abc1234def56789a"
}

import {
  to = aws_subnet.private[0]
  id = "subnet-0aaa1111"
}

import {
  to = aws_subnet.private[1]
  id = "subnet-0bbb2222"
}

import {
  to = aws_subnet.private[2]
  id = "subnet-0ccc3333"
}
```

---

## Post-Import Checklist

```
After importing resources:

  ✅ Run terraform plan — plan shows "No changes"
     (if there are changes: update .tf code to match real resource, or accept and apply)

  ✅ Remove the import block from import.tf
     (import blocks are one-time; leave them in if you want documentation)

  ✅ Add lifecycle blocks where needed
     (prevent_destroy for production databases, ignore_changes for externally managed fields)

  ✅ Add the resource to the appropriate module
     (if it should be managed via a shared module, refactor now)

  ✅ Add tags via merge(local.common_tags, {...})
     (manually-created resources often have inconsistent or missing tags)

  ✅ Verify in CI
     (push the code; confirm the plan in the PR shows no unexpected changes)
```
