# Terraform Best Practices — Part 4: Variables, Locals, and Outputs

> **The key principle:** Variables for values that differ between callers. Locals for derived/computed values. Outputs for values other stacks or modules need. Keeping these three roles distinct makes code readable, safe, and reusable.

---

## Variables: Inputs to a Module or Root

### Rules for Variable Declarations

```
Every variable must have:
  ✓ type        — prevents passing a string where a number is expected
  ✓ description — explains what the variable is used for and what values are valid
  ✓ validation  — catches invalid inputs before apply (not after)
  ✗ default     — only if the value has a safe universal default; prod-critical
                   values should have no default (force the caller to be explicit)
```

### Basic Types

```hcl
# variables.tf

variable "environment" {
  type        = string
  description = "Deployment environment: dev | staging | prod"

  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment must be one of: dev, staging, prod."
  }
}

variable "replica_count" {
  type        = number
  description = "Number of RDS read replicas to create"
  default     = 0

  validation {
    condition     = var.replica_count >= 0 && var.replica_count <= 5
    error_message = "replica_count must be between 0 and 5."
  }
}

variable "enable_enhanced_monitoring" {
  type        = bool
  description = "Enable RDS Enhanced Monitoring (60-second intervals)"
  default     = false
}
```

### Object Types for Related Settings

```hcl
# Instead of 8 separate variables for RDS configuration,
# group them into one typed object:

variable "rds_config" {
  description = "RDS instance configuration"
  type = object({
    instance_class      = string
    allocated_storage   = number
    multi_az            = bool
    deletion_protection = bool
    backup_retention    = optional(number, 7)   # optional with default
    engine_version      = optional(string, "15")
  })

  # Default safe for dev; prod overrides all fields in terraform.tfvars
  default = {
    instance_class      = "db.t3.medium"
    allocated_storage   = 100
    multi_az            = false
    deletion_protection = true
  }
}

# Access in resource:
resource "aws_db_instance" "main" {
  instance_class      = var.rds_config.instance_class
  allocated_storage   = var.rds_config.allocated_storage
  multi_az            = var.rds_config.multi_az
  deletion_protection = var.rds_config.deletion_protection
}
```

### Map and List Types

```hcl
variable "subnet_ids" {
  description = "List of private subnet IDs for the RDS subnet group"
  type        = list(string)
  # No default — caller must provide this from the networking stack
}

variable "additional_tags" {
  description = "Additional tags to merge with the common tag set"
  type        = map(string)
  default     = {}
}

variable "alarm_thresholds" {
  description = "CloudWatch alarm thresholds"
  type = map(number)
  default = {
    cpu_high        = 80
    free_storage_low = 10
    connections_high = 500
  }
}
```

### Sensitive Variables

```hcl
variable "master_password" {
  description = "RDS master user password — provide via Secrets Manager data source, not directly"
  type        = string
  sensitive   = true
  # sensitive = true:
  #   → Value is redacted as "(sensitive value)" in plan and apply output
  #   → Value is still stored in state (state must be encrypted)
  #   → Does NOT prevent the value from being in the state file
  #   → Does NOT prevent a developer from reading the state file directly
}
```

### CloudWatch Retention Validation (Real-World Example)

```hcl
variable "log_retention_days" {
  type        = number
  description = "CloudWatch Logs retention period in days"
  default     = 30

  validation {
    condition = contains(
      [1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1827, 3653],
      var.log_retention_days
    )
    error_message = "log_retention_days must be a valid CloudWatch retention period."
  }
  # CloudWatch only accepts specific values — this validation catches invalid inputs
  # at plan time rather than producing a cryptic AWS API error at apply time
}
```

---

## Locals: Computed and Derived Values

Locals are values computed from variables (or other locals). They are NOT inputs — callers cannot override them.

### When to Use Locals

```
Use locals for:
  → Name prefixes that combine project + environment
  → Tag maps that are applied to every resource
  → Conditional logic (prod gets multi-AZ, dev doesn't)
  → Environment-specific lookup tables (instance size by env)
  → Anything you'd otherwise compute inline in a resource block

Do NOT use locals for:
  → Values that should be configurable by the caller → use variables
  → Hardcoded values that should be data sources → use data blocks
```

### Common Locals Patterns

```hcl
# locals.tf

locals {
  # Name prefix: used to name every resource consistently
  # Result: "company-prod" or "company-dev"
  name_prefix = "${var.project}-${var.environment}"

  # Tag map applied to every resource via merge()
  common_tags = {
    Project     = var.project
    Environment = var.environment
    ManagedBy   = "terraform"
    Owner       = var.team
    CostCenter  = var.cost_center
  }

  # Boolean derived from environment (not a separate variable)
  is_production = var.environment == "prod"
  multi_az      = local.is_production  # prod = true; non-prod = false

  # Environment-specific instance size (map lookup)
  rds_instance_class = {
    dev     = "db.t3.small"
    staging = "db.t3.medium"
    prod    = "db.r6g.large"
  }[var.environment]

  # CIDR blocks with computed derivations
  vpc_cidr = var.vpc_cidr_block
  # Derive /22 subnets from the VPC /16 CIDR (for 3 AZs)
  private_subnet_cidrs = [
    cidrsubnet(local.vpc_cidr, 6, 0),   # 10.0.0.0/22
    cidrsubnet(local.vpc_cidr, 6, 1),   # 10.0.4.0/22
    cidrsubnet(local.vpc_cidr, 6, 2),   # 10.0.8.0/22
  ]
}
```

### Using Locals in Resources

```hcl
# main.tf

resource "aws_db_instance" "main" {
  identifier     = "${local.name_prefix}-rds"   # "company-prod-rds"
  instance_class = local.rds_instance_class      # from lookup table
  multi_az       = local.multi_az                # true in prod only

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-rds"
    Role = "database"
  })
  # merge() applies common_tags first, then resource-specific tags
  # If a key appears in both: the right-most value wins
}

resource "aws_cloudwatch_log_group" "app" {
  name              = "/aws/eks/${local.name_prefix}/application"
  retention_in_days = local.is_production ? 365 : 30
  tags              = local.common_tags
}
```

---

## Outputs: Values for Other Modules and Stacks

### Rules for Outputs

```
Output every value that another module or stack might need.
Do NOT output sensitive values without the sensitive = true flag.
Do NOT output internal implementation details (resource arguments).

Output names should be consistent across modules:
  endpoint          → connection string
  arn               → ARN of the resource
  id                → resource ID
  security_group_id → SG ID for use in ingress rules
  name              → resource name
```

```hcl
# outputs.tf — module/rds-postgres

output "endpoint" {
  description = "RDS connection endpoint (hostname:port)"
  value       = aws_db_instance.this.endpoint
}

output "db_name" {
  description = "Name of the PostgreSQL database"
  value       = aws_db_instance.this.db_name
}

output "arn" {
  description = "ARN of the RDS instance"
  value       = aws_db_instance.this.arn
}

output "security_group_id" {
  description = "Security Group ID of the RDS instance. Reference this in your application's SG ingress rule."
  value       = aws_security_group.rds.id
}

output "instance_identifier" {
  description = "RDS DB instance identifier"
  value       = aws_db_instance.this.id
}

# Sensitive output — value is redacted in plan/apply but still accessible
output "master_username" {
  description = "RDS master username"
  value       = aws_db_instance.this.username
  sensitive   = true
}
```

---

## terraform.tfvars: Environment-Specific Values

```hcl
# environments/prod/payment-service/terraform.tfvars
# Committed to Git — contains NO secrets

project     = "company"
environment = "prod"
team        = "payments"
cost_center = "CC-1234"

rds_config = {
  instance_class      = "db.r6g.large"
  allocated_storage   = 500
  multi_az            = true
  deletion_protection = true
  backup_retention    = 14
  engine_version      = "15"
}

log_retention_days = 365
alarm_thresholds = {
  cpu_high         = 70
  free_storage_low = 50   # GB
  connections_high = 1000
}
```

```hcl
# environments/dev/payment-service/terraform.tfvars
# Same file structure; different values

project     = "company"
environment = "dev"
team        = "payments"
cost_center = "CC-1234"

rds_config = {
  instance_class      = "db.t3.small"
  allocated_storage   = 20
  multi_az            = false
  deletion_protection = false  # allow easy teardown in dev
  backup_retention    = 1
  engine_version      = "15"
}

log_retention_days = 7
alarm_thresholds = {
  cpu_high         = 90   # less strict in dev
  free_storage_low = 5
  connections_high = 100
}
```

---

## Common Variables/Locals/Outputs Mistakes

| Mistake | What Goes Wrong | Fix |
|---|---|---|
| No type on variables | `var.count` receives "3" (string) instead of 3 (number); resource for_each fails | Always declare type; use `number`, `string`, `bool`, `list(string)`, `object({...})` |
| No validation on environment variables | Invalid value `"production"` (should be `"prod"`) only fails at apply time with cryptic error | Add `validation` block with `contains()` check |
| Secrets in .tfvars | Password committed to Git; visible in plan output and PR comments | Use `data.aws_secretsmanager_secret_version` or `data.aws_ssm_parameter`; never put secrets in tfvars |
| Missing `sensitive = true` on password variable | Password appears in plan output in CI; visible in PR comments | Add `sensitive = true` to any variable or output holding a secret |
| Hardcoding environment-specific logic in resources | Adding `if environment == "prod"` inline everywhere; duplication; hard to read | Use locals for conditional values; `local.multi_az = var.environment == "prod"` |
| Outputs without descriptions | Other engineers don't know what `output "id"` refers to | Every output needs a description explaining what the value is and how to use it |
