# Terraform Best Practices — Part 1: State Management

> **The foundation of everything.** Without proper state management, two engineers corrupt state simultaneously, secrets end up in Git, and one bad plan destroys infrastructure in the wrong environment.

---

## What Terraform State Is and Why It Matters

```
Terraform state (.tfstate) is a JSON file that maps:
  your .tf code resource blocks  →  real AWS resource IDs

Without state:
  Terraform doesn't know that aws_instance.web = i-0abc123 in EC2
  Every plan would try to create everything from scratch
  Every apply would duplicate resources

With state:
  Terraform knows exactly which real resource each block manages
  Plans show only what will CHANGE, not what already exists
  Outputs from one stack can be consumed by another stack

State contains:
  → Every resource's real AWS ID (instance IDs, ARNs, endpoint addresses)
  → All attribute values at last apply time (including sensitive values like passwords)
  → Dependency graph between resources
  → Module structure

This is why state must be:
  → Remote (not on a developer's laptop)
  → Encrypted (it contains plaintext passwords and keys)
  → Versioned (so you can roll back after a bad apply)
  → Locked (so two people can't apply simultaneously and corrupt it)
```

---

## Remote Backend: S3 + DynamoDB

The S3 + DynamoDB backend is the standard for AWS-based Terraform deployments.

```hcl
# backend.tf — the FIRST file to configure in any Terraform project
# Create this BEFORE writing any resource code

terraform {
  backend "s3" {
    bucket         = "company-terraform-state"
    key            = "prod/payment-service/terraform.tfstate"
    region         = "ap-northeast-1"
    encrypt        = true                      # AES-256 encryption at rest via KMS
    dynamodb_table = "terraform-state-lock"    # prevents concurrent applies
    profile        = "terraform-deploy"        # AWS profile with minimal IAM permissions
  }
}
```

**Each field explained:**

| Field | Purpose | Common Mistake |
|---|---|---|
| `bucket` | S3 bucket storing the state file | Using the same bucket for state and application data |
| `key` | Path within the bucket to this state file | Using the same key for multiple environments |
| `region` | AWS region of the S3 bucket | Must match the bucket's actual region |
| `encrypt` | Encrypts state at rest | Setting to false — state contains plaintext passwords |
| `dynamodb_table` | Locks state during apply to prevent concurrent runs | Not creating the table first (chicken-and-egg: bootstrap manually) |
| `profile` | AWS CLI profile used to access the backend | Using AdministratorAccess for the Terraform profile |

---

## State Key Naming Convention

The state key is the path in S3 to this state file. It determines what a single `terraform destroy` would affect — the **blast radius**.

```
Pattern: <environment>/<service-or-layer>/<component>/terraform.tfstate

Examples:
  prod/networking/vpc/terraform.tfstate
  prod/platform/eks-cluster/terraform.tfstate
  prod/platform/eks-addons/terraform.tfstate
  prod/payment-service/rds/terraform.tfstate
  prod/payment-service/s3-buckets/terraform.tfstate
  staging/payment-service/rds/terraform.tfstate
  dev/payment-service/rds/terraform.tfstate

Rules:
  → Never share a state file between prod and staging
    (a bad prod apply must NEVER be able to affect staging resources)
  → Never share a state file between unrelated services
    (payment-service and auth-service in the same state = both destroyed together)
  → Each state file = one blast radius
  → Smaller state files = faster plans, less risk, easier debugging
  → A state file with 500+ resources is a smell: split it up
```

**Why small state files are better:**

```
Large state file (bad):
  All 300 AWS resources in one state file
  terraform plan reads all 300 resources from AWS APIs → slow (3-5 minutes)
  A mistake in one resource's config could cascade to others
  "blast radius" of terraform destroy = entire infrastructure

Small state files (correct):
  networking/vpc: 15 resources (VPC, subnets, route tables)
  platform/eks:   40 resources (cluster, node groups, addons)
  payment/rds:    8 resources (DB instance, SGs, parameter group)
  terraform plan for payment/rds reads only 8 resources → fast (15 seconds)
  A mistake in RDS config cannot affect the VPC or EKS cluster
```

---

## DynamoDB Lock Table: Bootstrap Setup

The DynamoDB table must exist BEFORE you configure the S3 backend. This is a one-time bootstrap.

```hcl
# bootstrap/main.tf — run this ONCE manually to create the backend infrastructure
# After this, everything else uses the remote backend

provider "aws" {
  region = "ap-northeast-1"
}

resource "aws_dynamodb_table" "terraform_lock" {
  name         = "terraform-state-lock"
  billing_mode = "PAY_PER_REQUEST"  # no need to provision capacity for lock ops
  hash_key     = "LockID"           # required attribute name for Terraform locking

  attribute {
    name = "LockID"
    type = "S"   # S = String
  }

  tags = {
    Name      = "Terraform State Lock"
    ManagedBy = "terraform-bootstrap"
  }
}

resource "aws_s3_bucket" "terraform_state" {
  bucket = "company-terraform-state"
}

resource "aws_s3_bucket_versioning" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id
  versioning_configuration {
    status = "Enabled"
    # Every state file write creates a new version in S3
    # If a bad apply corrupts state: download the previous version from S3
    # Versions are retained indefinitely unless you set a lifecycle policy
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.terraform_state.arn  # use a CMK for audit trail
    }
  }
}

resource "aws_s3_bucket_public_access_block" "terraform_state" {
  bucket                  = aws_s3_bucket.terraform_state.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
  # State bucket MUST be private — it contains all your infrastructure secrets
}

resource "aws_kms_key" "terraform_state" {
  description             = "KMS key for Terraform state encryption"
  deletion_window_in_days = 30
  enable_key_rotation     = true   # rotate annually; CloudTrail logs every decrypt
}
```

**How locking works:**

```
Engineer A runs: terraform apply
  → Terraform writes a LockID entry to DynamoDB
  → LockID = "company-terraform-state/prod/payment-service/terraform.tfstate"

Engineer B runs: terraform apply simultaneously
  → Terraform tries to write the same LockID to DynamoDB
  → DynamoDB conditional write fails (LockID already exists)
  → Terraform returns: "Error acquiring the state lock"
  → Engineer B must wait until Engineer A's apply completes

Engineer A's apply completes:
  → Terraform deletes the LockID from DynamoDB
  → Engineer B's terraform apply can now proceed

Stuck lock (apply was killed mid-run):
  → LockID remains in DynamoDB even though no apply is running
  → Fix: terraform force-unlock <LOCK_ID>
  → CAUTION: only run this if you are CERTAIN no apply is in progress
```

---

## State File Rules (Non-Negotiable)

```
NEVER:
  × Commit .tfstate files to Git
    Reason: state contains plaintext passwords, private keys, and resource IDs
    Even "empty" state files should not be in Git

  × Store state locally for production infrastructure
    Reason: if the engineer's laptop is lost, the state is gone
    Without state, Terraform cannot manage existing resources

  × Share one state file between prod and staging
    Reason: a mistake in prod Terraform code could plan changes to staging resources
    The blast radius must be isolated

  × Run terraform apply without a plan file
    Use: terraform plan -out=tfplan → terraform apply tfplan
    Reason: the applied changes are EXACTLY what was reviewed in the plan
    Without -out: a new plan is generated at apply time (may differ from what was reviewed)

ALWAYS:
  ✓ Add *.tfstate and *.tfstate.backup to .gitignore
  ✓ Enable S3 versioning on the state bucket (rollback safety net)
  ✓ Enable S3 Object Lock for compliance-critical environments
    (prevents deletion of state versions even by admins)
  ✓ Enable KMS encryption on the state bucket with CloudTrail KMS data events
    (every read of the state is audited)
  ✓ Use separate AWS accounts for separate environments
    (complete isolation: prod IAM cannot touch staging resources)
  ✓ Monitor the DynamoDB lock table
    (a stuck lock blocks all applies — alert if a lock exists for > 30 minutes)
```

---

## IAM Permissions for the State Backend

```
Minimum IAM permissions for the Terraform CI role accessing the S3 backend:

{
  "Effect": "Allow",
  "Action": [
    "s3:GetObject",
    "s3:PutObject",
    "s3:DeleteObject"
  ],
  "Resource": "arn:aws:s3:::company-terraform-state/prod/payment-service/*"
  # Scoped to the specific key prefix — not the entire bucket
}

{
  "Effect": "Allow",
  "Action": [
    "s3:ListBucket"
  ],
  "Resource": "arn:aws:s3:::company-terraform-state"
}

{
  "Effect": "Allow",
  "Action": [
    "dynamodb:GetItem",
    "dynamodb:PutItem",
    "dynamodb:DeleteItem"
  ],
  "Resource": "arn:aws:dynamodb:ap-northeast-1:123456789012:table/terraform-state-lock"
}

{
  "Effect": "Allow",
  "Action": [
    "kms:GenerateDataKey",
    "kms:Decrypt"
  ],
  "Resource": "arn:aws:kms:ap-northeast-1:123456789012:key/<STATE_BUCKET_KMS_KEY_ARN>"
}
```

---

## State Recovery: What to Do When State Is Corrupted

```
State corruption is rare but possible. Symptoms:
  → terraform plan shows all resources as new (state is empty or missing)
  → terraform plan shows resources that don't exist in AWS
  → plan errors with: "Error reading state: ..."

Recovery procedure:
  1. Do NOT run terraform apply on a corrupted state
     This could CREATE duplicate resources or try to destroy existing ones

  2. List state versions in S3:
     aws s3api list-object-versions \
       --bucket company-terraform-state \
       --prefix prod/payment-service/terraform.tfstate \
       --query 'Versions[*].{VersionId:VersionId, LastModified:LastModified}' \
       --output table

  3. Download the last known-good version:
     aws s3api get-object \
       --bucket company-terraform-state \
       --key prod/payment-service/terraform.tfstate \
       --version-id <PREVIOUS_VERSION_ID> \
       terraform.tfstate.backup

  4. Push the good version back as current:
     aws s3 cp terraform.tfstate.backup \
       s3://company-terraform-state/prod/payment-service/terraform.tfstate

  5. Run terraform plan to verify the state is consistent
     Make sure the plan shows no unexpected changes

  6. Investigate the root cause before running any apply
```

---

## .gitignore for Terraform Projects

```gitignore
# .gitignore — must be in every Terraform repository root

# State files — NEVER commit
*.tfstate
*.tfstate.backup

# Local terraform directory (downloaded providers and modules)
.terraform/

# Plan output files (may contain sensitive resource attributes)
*.tfplan
*.tfplan.json

# Local variable overrides (developer-specific; not for sharing)
*.auto.tfvars
.terraform.tfvars
terraform.tfvars.local

# IDE
.idea/
.vscode/

# OS
.DS_Store
Thumbs.db

# DO NOT ignore .terraform.lock.hcl — commit this file
```
