# Terraform Best Practices — Part 6: CI/CD Pipeline — The Only Apply Path

> **The #1 Terraform best practice:** No one runs `terraform apply` manually from their laptop in staging or production. The CI/CD pipeline is the only apply path. This creates a mandatory audit trail, enforces plan review, and eliminates "works on my machine" apply problems.

---

## Why CI/CD for Terraform

```
Without CI/CD (manual apply from laptop):
  → No audit trail: "who applied what at 2 AM last Tuesday?"
  → No enforced review: engineer applies without a second pair of eyes
  → Different Terraform versions on different laptops → inconsistent plans
  → Engineer's AWS credentials can see/change everything in the account
  → Plan is never shared — team doesn't know what's being applied
  → A mistake under pressure at 3 AM applies to production immediately

With CI/CD pipeline:
  → Every apply is triggered by a Git merge (full audit trail in Git log)
  → Plan output is posted as a PR comment — team reviews WHAT will change
  → Terraform version is pinned in the CI config — always consistent
  → CI assumes an IAM role with only the permissions Terraform needs
  → Prod applies require a manual approval gate (second human must approve)
  → All applies are logged in GitHub Actions / Atlantis history
```

---

## GitHub Actions Workflow: Plan on PR, Apply on Merge

```yaml
# .github/workflows/terraform.yml
name: Terraform CI/CD

on:
  pull_request:
    branches: [main]
    paths:
      - 'environments/**'
      - 'modules/**'
  push:
    branches: [main]
    paths:
      - 'environments/**'
      - 'modules/**'

env:
  TF_VERSION: "1.8.0"        # pinned; never use "latest"
  AWS_REGION: "ap-northeast-1"

jobs:
  # ──────────────────────────────────────────────────────────────
  # JOB 1: Plan on Pull Request
  # Shows what WILL change; posts as a PR comment
  # Does NOT apply anything
  # ──────────────────────────────────────────────────────────────
  plan:
    name: "Terraform Plan"
    if: github.event_name == 'pull_request'
    runs-on: ubuntu-latest
    permissions:
      id-token: write        # OIDC: exchange GitHub token for AWS credentials
      contents: read
      pull-requests: write   # post plan output as a PR comment

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup Terraform
        uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: ${{ env.TF_VERSION }}

      - name: Configure AWS Credentials (OIDC — no stored secrets)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/github-actions-terraform-plan
          aws-region: ${{ env.AWS_REGION }}
          # This role has ReadOnlyAccess + S3/DynamoDB for state backend
          # It CANNOT create, modify, or delete any AWS resource

      - name: Terraform Init
        run: terraform init
        working-directory: environments/prod/payment-service

      - name: Terraform Format Check
        run: terraform fmt -check -recursive
        # Fails the pipeline if any .tf file is not correctly formatted
        # Enforces: run terraform fmt before committing

      - name: Terraform Validate
        run: terraform validate
        working-directory: environments/prod/payment-service

      - name: tflint (Lint)
        uses: terraform-linters/setup-tflint@v4
        with:
          tflint_version: latest
      - run: tflint --init && tflint
        working-directory: environments/prod/payment-service

      - name: Terraform Plan
        id: plan
        run: |
          terraform plan \
            -no-color \
            -detailed-exitcode \
            -out=tfplan \
            2>&1 | tee plan_output.txt
        working-directory: environments/prod/payment-service
        continue-on-error: true
        # -no-color: plain text in PR comment (no ANSI escape codes)
        # -detailed-exitcode: exit 2 = changes (used to detect drift in scheduled runs)
        # -out=tfplan: saves the plan to a file (apply uses EXACTLY this plan)

      - name: Post Plan as PR Comment
        uses: actions/github-script@v7
        if: always()
        with:
          script: |
            const fs = require('fs');
            const plan = fs.readFileSync('environments/prod/payment-service/plan_output.txt', 'utf8');
            const truncated = plan.length > 60000 ? plan.slice(0, 60000) + '\n... (truncated)' : plan;
            const outcome = '${{ steps.plan.outcome }}';
            const body = `### Terraform Plan — \`environments/prod/payment-service\`
            **Outcome:** ${outcome === 'success' ? '✅ Success' : '❌ Failed'}
            <details><summary>Plan Output</summary>

            \`\`\`hcl
            ${truncated}
            \`\`\`
            </details>`;
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body
            });

  # ──────────────────────────────────────────────────────────────
  # JOB 2: Apply on Merge to main
  # Only runs after PR is merged — not on the PR itself
  # Prod: requires manual approval in GitHub environment settings
  # ──────────────────────────────────────────────────────────────
  apply:
    name: "Terraform Apply"
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: production      # GitHub Environment with required reviewers
    # "production" environment requires a named person to click "Approve"
    # before this job runs — this is the manual approval gate for prod
    permissions:
      id-token: write
      contents: read

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup Terraform
        uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: ${{ env.TF_VERSION }}

      - name: Configure AWS Credentials (Apply role — more permissions)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/github-actions-terraform-apply
          aws-region: ${{ env.AWS_REGION }}
          # Apply role: ReadOnly + write permissions for specific managed resources
          # Still NOT AdministratorAccess — only what Terraform specifically needs

      - name: Terraform Init
        run: terraform init
        working-directory: environments/prod/payment-service

      - name: Terraform Apply
        run: terraform apply -auto-approve
        working-directory: environments/prod/payment-service
        # -auto-approve: skips the interactive prompt (safe in CI; human reviewed the plan on PR)
```

---

## GitHub Environment Approval Gate (For Production)

```
Setup in GitHub UI:
  Repository → Settings → Environments → New environment → "production"

  Protection rules:
    ✓ Required reviewers: add 2+ team members
    ✓ Wait timer: 0 minutes (or set a delay if desired)
    ✓ Deployment branches: main only

Effect:
  When the "apply" job starts for the "production" environment,
  GitHub pauses the workflow and sends a notification to the required reviewers.
  One of them must click "Approve" before the apply runs.
  This is the mandatory human gate for every production Terraform apply.
```

---

## IAM Roles for CI/CD: Two Separate Roles

### Plan Role (Read-Only)

```hcl
# iam.tf — separate roles for plan and apply

resource "aws_iam_openid_connect_provider" "github_actions" {
  url            = "https://token.actions.githubusercontent.com"
  client_id_list = ["sts.amazonaws.com"]
  thumbprint_list = ["6938fd4d98bab03faadb97b34396831e3780aea1"]
  # This allows GitHub Actions to get temporary AWS credentials via OIDC
  # No stored AWS access keys in GitHub — zero long-lived credentials
}

resource "aws_iam_role" "github_actions_plan" {
  name = "github-actions-terraform-plan"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Federated = aws_iam_openid_connect_provider.github_actions.arn
      }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringLike = {
          # Only jobs from this specific repo can assume this role
          "token.actions.githubusercontent.com:sub" = "repo:company/infrastructure:*"
        }
        StringEquals = {
          "token.actions.githubusercontent.com:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })
}

# Plan role permissions:
# 1. ReadOnlyAccess to describe AWS resources (for plan)
resource "aws_iam_role_policy_attachment" "plan_readonly" {
  role       = aws_iam_role.github_actions_plan.name
  policy_arn = "arn:aws:iam::aws:policy/ReadOnlyAccess"
}

# 2. State backend access (S3 read + DynamoDB lock)
resource "aws_iam_role_policy" "plan_state_backend" {
  role = aws_iam_role.github_actions_plan.name
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["s3:GetObject", "s3:ListBucket"]
        Resource = [
          "arn:aws:s3:::company-terraform-state",
          "arn:aws:s3:::company-terraform-state/*"
        ]
      },
      {
        Effect   = "Allow"
        Action   = ["dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:DeleteItem"]
        Resource = "arn:aws:dynamodb:ap-northeast-1:123456789012:table/terraform-state-lock"
      }
    ]
  })
}
```

### Apply Role (Write Permissions Scoped to Managed Resources)

```hcl
resource "aws_iam_role" "github_actions_apply" {
  name = "github-actions-terraform-apply"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Federated = aws_iam_openid_connect_provider.github_actions.arn
      }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        # Only runs triggered by push to main branch can assume the apply role
        StringEquals = {
          "token.actions.githubusercontent.com:ref"  = "refs/heads/main"
          "token.actions.githubusercontent.com:aud"  = "sts.amazonaws.com"
        }
        StringLike = {
          "token.actions.githubusercontent.com:sub" = "repo:company/infrastructure:*"
        }
      }
    }]
  })
}

# Apply role permissions:
# NOT AdministratorAccess — scoped to only what Terraform manages
# Example: if Terraform manages RDS, EKS, S3, and IAM roles,
# the apply role gets write access to exactly those services

resource "aws_iam_role_policy" "apply_permissions" {
  role = aws_iam_role.github_actions_apply.name
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      # State backend — read and write
      {
        Effect   = "Allow"
        Action   = ["s3:GetObject", "s3:PutObject", "s3:DeleteObject", "s3:ListBucket"]
        Resource = [
          "arn:aws:s3:::company-terraform-state",
          "arn:aws:s3:::company-terraform-state/*"
        ]
      },
      {
        Effect   = "Allow"
        Action   = ["dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:DeleteItem"]
        Resource = "arn:aws:dynamodb:ap-northeast-1:123456789012:table/terraform-state-lock"
      },
      # RDS permissions (example scoped permissions)
      {
        Effect   = "Allow"
        Action   = [
          "rds:CreateDBInstance", "rds:ModifyDBInstance",
          "rds:DeleteDBInstance", "rds:DescribeDBInstances",
          "rds:CreateDBSubnetGroup", "rds:ModifyDBSubnetGroup"
        ]
        Resource = "arn:aws:rds:ap-northeast-1:123456789012:db:*"
      }
      # ... add for each service Terraform manages
    ]
  })
}
```

---

## Drift Detection: Scheduled Plan

```yaml
# Add to .github/workflows/terraform.yml

drift-detection:
  name: "Drift Detection"
  runs-on: ubuntu-latest
  schedule:
    - cron: '0 9 * * 1-5'   # 9 AM UTC every weekday
  permissions:
    id-token: write
    contents: read
    issues: write   # create an issue if drift is found

  steps:
    - uses: actions/checkout@v4
    - uses: hashicorp/setup-terraform@v3
      with:
        terraform_version: ${{ env.TF_VERSION }}

    - name: Configure AWS Credentials
      uses: aws-actions/configure-aws-credentials@v4
      with:
        role-to-assume: arn:aws:iam::123456789012:role/github-actions-terraform-plan
        aws-region: ${{ env.AWS_REGION }}

    - name: Terraform Init
      run: terraform init
      working-directory: environments/prod/payment-service

    - name: Check for Drift
      id: drift
      run: |
        terraform plan -detailed-exitcode -no-color 2>&1
      working-directory: environments/prod/payment-service
      continue-on-error: true
      # Exit code 0 = no changes (clean)
      # Exit code 2 = changes detected (DRIFT!)

    - name: Create Issue if Drift Detected
      if: steps.drift.outputs.exitcode == '2'
      uses: actions/github-script@v7
      with:
        script: |
          github.rest.issues.create({
            owner: context.repo.owner,
            repo: context.repo.repo,
            title: '🚨 Terraform Drift Detected — environments/prod/payment-service',
            body: 'Terraform plan detected infrastructure drift. Review and resolve.',
            labels: ['terraform-drift', 'prod']
          });
```

---

## Common CI/CD Mistakes

| Mistake | Consequence | Fix |
|---|---|---|
| `terraform apply` from laptop in production | No audit trail; no plan review; inconsistent Terraform version | CI/CD is the only apply path; remove production IAM access from developer laptops |
| Using `AdministratorAccess` for the CI apply role | If CI is compromised, attacker has full AWS access | Scope the apply role to only the services Terraform manages |
| Long-lived AWS access keys in GitHub secrets | Key rotation is manual; if leaked, attacker has persistent access | Use OIDC: no stored credentials; GitHub exchanges a token for temporary AWS creds |
| No manual approval gate for prod | Every merge to main immediately applies to production | Set up a GitHub Environment with required reviewers for the apply job |
| Plan not posted as PR comment | Reviewers only see code changes; miss destructive resource changes | Post plan output to PR using github-script action |
