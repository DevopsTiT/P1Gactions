# Terraform Best Practices — Part 11: Common Mistakes

> The 10 mistakes that cause the most production incidents, state corruption events, and wasted engineer time in Terraform deployments — with the exact symptom, root cause, and correct approach.

---

## Mistake Decision Tree

```
"Something went wrong with Terraform — which pattern is this?"

├─ State is missing or shows all resources as new
│     → Mistake 1: State locally stored or committed to Git

├─ Provider version changed; plan shows unexpected resource changes
│     → Mistake 2: No version pinning on providers

├─ "Who applied that at 2 AM?" — no audit trail
│     → Mistake 3: terraform apply from laptop in production

├─ A change to payment-service state affected auth-service resources
│     → Mistake 4: One state file for all environments/services

├─ A VPC was recreated and now 30 files have wrong subnet IDs
│     → Mistake 5: Hardcoded resource IDs (VPC ID, subnet IDs)

├─ DB password is visible in PR comments / CI logs
│     → Mistake 6: Secrets in .tf files or tfvars

├─ terraform apply during refactor deleted a production database
│     → Mistake 7: No prevent_destroy on production stateful resources

├─ A resource rename caused create+destroy; service was down
│     → Mistake 8: Plan not reviewed before apply

├─ All envs in one workspace; prod apply wiped staging
│     → Mistake 9: Using terraform workspace for environment isolation

├─ Untagged resources accumulate; billing report is useless
│     → Mistake 10: No tagging strategy
```

---

## Mistake 1 — State Stored Locally or in Git

**Symptom:**
```
terraform plan shows all 200 resources as "to be created"
OR: .tfstate file found in a GitHub repository
OR: two engineers apply simultaneously; state is corrupted;
    one apply partially applied and overwrote the other's changes
```

**Root cause:**
```
State file stored on a developer's laptop or committed to Git.

On-laptop state:
  → Deleted when the laptop is reformatted or lost
  → Different state file for each developer → inconsistent plans
  → Two simultaneous applies corrupt the state (no locking)

In Git state:
  → Contains plaintext passwords, private keys, resource IDs
  → Every team member has a copy of all production secrets
  → Git history retains the state even after it's deleted
```

**Correct approach:**
```
backend "s3" {
  bucket         = "company-terraform-state"
  key            = "prod/payment-service/terraform.tfstate"
  encrypt        = true
  dynamodb_table = "terraform-state-lock"
}

Add to .gitignore:
  *.tfstate
  *.tfstate.backup
  .terraform/

Never commit .tfstate. Never.
```

---

## Mistake 2 — No Version Pinning on Providers

**Symptom:**
```
Monday morning: terraform plan fails with:
  "Error: Unsupported argument. An argument named 'master_user_secret' is not expected here."
  (A new AWS provider version removed or renamed a field)

OR: Engineer A's plan shows 5 changes; Engineer B's plan shows 0 changes
    for the exact same code on the same infrastructure.
```

**Root cause:**
```
Provider version not pinned. When terraform init runs:
  → Each run may download a different (newer) provider version
  → A new minor version can change resource schemas, add required fields, rename arguments
  → Different engineers get different provider versions on different days
```

**Correct approach:**
```hcl
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.50"   # allows 5.50.x to 5.59.x; blocks 6.x
    }
  }
}
# Commit .terraform.lock.hcl to Git — pins exact version for everyone
```

---

## Mistake 3 — Running terraform apply from a Laptop in Production

**Symptom:**
```
Post-incident review: "Who applied that RDS parameter change?"
GitHub Actions history: nothing.
Nobody knows. No audit trail. No plan was shared for review.

OR: Engineer applies with the wrong AWS profile → changes land in prod when they meant staging
OR: Engineer runs apply on an outdated local copy of the code → apply reverts a recent PR
```

**Root cause:**
```
Production IAM access and Terraform apply are available from developer laptops.
There is no enforcement that only CI/CD can apply.
```

**Correct approach:**
```
Rule: CI/CD is the only apply path for staging and production.
      Developers can run plan locally for review, never apply.

Enforcement:
  → Production IAM role does not include write permissions for developers
  → CI assumes a separate apply role via OIDC (no long-lived keys)
  → All applies are triggered by merging to main (Git is the audit trail)
  → GitHub Environment "production" requires ≥1 manual approver before apply runs
```

---

## Mistake 4 — One State File for All Environments/Services

**Symptom:**
```
A plan for a payment-service change shows:
  "~ resource aws_db_instance.auth_service_db"  ← why is auth in here?

OR: prod state file has 800 resources; every plan takes 8 minutes
OR: a bad payment-service Terraform config causes auth-service resources to be destroyed
```

**Root cause:**
```
All services and/or all environments share one state file.
State files should represent one blast radius — what terraform destroy would affect.
A state with 800 resources means terraform destroy deletes all 800 simultaneously.
```

**Correct approach:**
```
One state file per environment per service:
  prod/networking/vpc/terraform.tfstate      (15 resources)
  prod/platform/eks-cluster/terraform.tfstate (40 resources)
  prod/payment-service/rds/terraform.tfstate  (8 resources)
  staging/payment-service/rds/terraform.tfstate
  dev/payment-service/rds/terraform.tfstate

Each state file = one blast radius.
A bad apply in prod/payment-service CANNOT affect prod/networking.
```

---

## Mistake 5 — Hardcoding Resource IDs (VPC IDs, Subnet IDs)

**Symptom:**
```
The production VPC was recreated during a disaster recovery exercise.
The new VPC has different subnet IDs.
32 Terraform files have hardcoded subnet IDs.
Engineer spends 4 hours updating every file.
Misses one → apply creates a resource in the wrong subnet.
```

**Root cause:**
```
subnet_ids = ["subnet-0a1b2c3d", "subnet-0e4f5a6b"]
These IDs change when the VPC is recreated.
Hardcoding IDs breaks the single source of truth principle.
```

**Correct approach:**
```hcl
data "terraform_remote_state" "networking" {
  backend = "s3"
  config = {
    bucket = "company-terraform-state"
    key    = "prod/networking/vpc/terraform.tfstate"
    region = "ap-northeast-1"
  }
}

subnet_ids = data.terraform_remote_state.networking.outputs.private_subnet_ids
# VPC is recreated → networking state outputs the new subnet IDs
# All stacks reading from networking state automatically get the new IDs
```

---

## Mistake 6 — Secrets in .tf Files or .tfvars Committed to Git

**Symptom:**
```
Security scanner alerts: "AWS secret key found in git commit abc1234"
OR: engineer pushes terraform.tfvars with db_password = "Prod$ecret!123"
OR: PR comment shows the plan output with a password in plaintext
```

**Root cause:**
```
variable "db_password" { default = "Prod$ecret!123" }
OR
db_password = "Prod$ecret!123"  # in terraform.tfvars

Git history is permanent. Even after the file is deleted, the secret exists
in git log forever. Anyone with repo access has the secret.
```

**Correct approach:**
```hcl
data "aws_secretsmanager_secret_version" "db_password" {
  secret_id = "prod/payment-service/db-password"
}

resource "aws_db_instance" "main" {
  password = data.aws_secretsmanager_secret_version.db_password.secret_string
}

# Secret ARN/name is safe in Git. The value never appears in code.
# Add to CI: gitleaks detect or trufflehog git to block secret commits
```

---

## Mistake 7 — No prevent_destroy on Production Stateful Resources

**Symptom:**
```
Engineer refactors the module structure. During the refactor,
the resource block for aws_db_instance is removed from one module
and moved to another. Terraform sees this as:
  - destroy aws_db_instance.old_module.main
  + create  aws_db_instance.new_module.main

Engineer applies. The production database is destroyed.
3 years of payment data is gone.
```

**Root cause:**
```
No lifecycle { prevent_destroy = true } on the RDS resource.
Terraform treats a resource address change as destroy + create.
No error was raised because prevent_destroy was not set.
```

**Correct approach:**
```hcl
resource "aws_db_instance" "production" {
  lifecycle {
    prevent_destroy = true
  }
}

# When refactoring module structure:
# Use: terraform state mv old_module.aws_db_instance.main new_module.aws_db_instance.main
# This moves the state entry without destroying the real resource
# NEVER rename + apply without using state mv first
```

---

## Mistake 8 — Not Reviewing the Plan Output Before Apply

**Symptom:**
```
Engineer sees "Plan: 3 to add, 2 to change, 0 to destroy" and clicks apply.
The "2 to change" includes:
  -/+ resource "aws_db_instance" "main" (forces replacement)
     ~ multi_az = true -> false
The RDS instance is destroyed and recreated without Multi-AZ.
Service is down for 15 minutes during recreation.
```

**Root cause:**
```
Plan was not read line by line.
"-/+" means: destroy the old resource AND create a new one (not an in-place update).
"forces replacement" is present in the plan output but was missed.
```

**Correct approach:**
```
Before every apply, read the plan output completely:
  "to add"     → new resources (safe unless something unexpected)
  "to change"  → in-place updates (usually safe; read what changes)
  "to destroy" → STOP and understand why before proceeding
  "-/+"        → STOP: destroy + recreate (downtime; data loss risk)
  "forces replacement" → same as above

In CI: post the full plan as a PR comment.
      Require ≥2 reviewers to approve any plan with "to destroy" lines.
      Use a conftest/OPA policy to block applies with unexpected destroys:
        rego: deny if any resource in the plan has change.actions containing "delete"
```

---

## Mistake 9 — Using terraform workspace for Environment Isolation

**Symptom:**
```
Engineer selects the wrong workspace:
  terraform workspace select prod   ← meant to select dev
  terraform apply
  → applies to production
  → no different IAM role, no different approval gate, no safety net
  → one wrong command bypasses all prod safeguards
```

**Root cause:**
```
terraform workspace select prod changes where state is read but:
  → uses the same .tf code as all other workspaces
  → uses the same AWS credentials as all other workspaces
  → no mandatory human approval before running apply
  → easy to accidentally select the wrong workspace
  → workspace names are not visible in the terminal prompt by default
```

**Correct approach:**
```
Use separate directories (and separate backend keys) for environments:
  environments/dev/payment-service/     ← always points to dev state
  environments/staging/payment-service/ ← always points to staging state
  environments/prod/payment-service/    ← always points to prod state

Benefits over workspaces:
  → Different backend key = different state = impossible to mix up
  → Different CI/CD roles per directory (dev role ≠ prod role)
  → Different tfvars per directory (dev: t3.small; prod: r6g.large)
  → GitHub Environment approval gate only on prod directory workflow
  → Engineer must explicitly change directories (not just type a workspace name)
```

---

## Mistake 10 — No Tagging Strategy

**Symptom:**
```
Finance team: "Which team spent $23,000 on RDS this month?"
Answer: unknown. Resources have no Team tag.

Compliance audit: "List all production resources in scope."
Answer: unknown. No Environment tag to filter by.

An orphaned EC2 instance (i-0abc123) has been running for 6 months.
Nobody knows who created it, which service it belongs to, or if it's safe to delete.
```

**Root cause:**
```
Tags are added ad-hoc, inconsistently, or not at all.
No enforced standard. No validation that tags are present.
```

**Correct approach:**
```hcl
# locals.tf — define once; apply everywhere
locals {
  common_tags = {
    Project     = var.project
    Environment = var.environment
    Team        = var.team
    ManagedBy   = "terraform"
    CostCenter  = var.cost_center
  }
}

# main.tf — every resource uses merge()
resource "aws_db_instance" "main" {
  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-rds"
    Role = "database"
  })
}

# Enforcement:
# 1. AWS Config rule: "required-tags" → NON_COMPLIANT if ManagedBy or Environment missing
# 2. tfsec/checkov in CI: fail PR if any resource block has no tags argument
# 3. tflint rule: flag resources without tags
```

---

## Summary Table

| # | Mistake | Primary Symptom | Fix Summary |
|---|---|---|---|
| 1 | State locally/in Git | State corruption; secrets in repo | S3 + DynamoDB backend; never commit .tfstate |
| 2 | No provider version pins | Plan breaks after provider auto-upgrade | `~> X.Y` in required_providers; commit .terraform.lock.hcl |
| 3 | Manual apply from laptop | No audit trail; wrong AWS profile apply | CI/CD only; GitHub Environment approval for prod |
| 4 | One state file for all environments | 8-minute plans; cross-env blast radius | One state file per env per service |
| 5 | Hardcoded IDs | 30 files break when VPC is recreated | `data.terraform_remote_state` for cross-stack references |
| 6 | Secrets in .tf/tfvars | Credentials in Git history forever | `data.aws_secretsmanager_secret_version`; never in code |
| 7 | No prevent_destroy on prod DB | Module refactor destroys production database | `lifecycle { prevent_destroy = true }` on all stateful prod resources |
| 8 | Plan not reviewed before apply | Unnoticed destroy recreates RDS; 15-min downtime | Read plan line by line; block PRs with unexpected destroy |
| 9 | Workspace for env isolation | Wrong workspace → prod apply with no safety net | Separate directories per environment; separate state keys |
| 10 | No tagging strategy | Unattributed costs; orphaned resources; compliance gaps | `local.common_tags` + `merge()` on every resource |
