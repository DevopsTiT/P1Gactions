# GitOps Troubleshooting — Part 4: ArgoCD Component Failures

> **The principle:** When ArgoCD itself is broken, no apps sync — the entire GitOps pipeline is down. Each component handles a distinct function; knowing which one failed tells you exactly what is broken.

---

## ArgoCD Component Map

```
Component                         Responsibility
──────────────────────────────────────────────────────────────────────────────
argocd-application-controller     Watches cluster + Git state; computes sync/health
                                  The core reconciliation loop.
                                  If DOWN: apps stop syncing; health stops updating

argocd-repo-server                Clones Git repos; renders Helm/Kustomize templates
                                  If DOWN: all syncs fail; ArgoCD cannot read manifests

argocd-server                     Hosts the Web UI and REST/gRPC API
                                  Handles argocd CLI commands
                                  If DOWN: UI unreachable; CLI fails; syncs STILL run

argocd-dex-server                 SSO/OIDC auth proxy (optional)
                                  If DOWN: SSO login fails; local admin login still works

argocd-redis                      Cache for manifests, app state, session tokens
                                  If DOWN: ArgoCD works but is slower; re-renders each time

argocd-applicationset-controller  Generates Applications from ApplicationSet templates
                                  If DOWN: new ApplicationSets not processed; existing apps unaffected

argocd-notifications-controller   Sends Slack/PagerDuty/email on app events
                                  If DOWN: notifications silent; apps still sync normally
```

---

## Quick Component Health Check

```bash
# See all ArgoCD pods at a glance
kubectl get pods -n argocd -o wide

# Pods NOT in Running state (the problem list)
kubectl get pods -n argocd --field-selector=status.phase!=Running

# Restart counts (high restart count = crashing repeatedly)
kubectl get pods -n argocd \
  -o custom-columns="NAME:.metadata.name,STATUS:.status.phase,RESTARTS:.status.containerStatuses[0].restartCount"

# Resource usage (looking for OOMKilled causes)
kubectl top pods -n argocd
```

---

## Component 1 — argocd-application-controller Failing

**What breaks when this fails:**
- Apps stop auto-syncing
- App health and sync status stop updating (frozen)
- All apps may show `Unknown` status

### Symptom: OOMKilled

```
Check:
  kubectl describe pod -n argocd \
    -l app.kubernetes.io/name=argocd-application-controller | grep -A5 "OOMKilled"

  kubectl top pods -n argocd | grep controller

Cause:
  The controller processes every resource in every tracked app on every reconciliation loop.
  Large clusters (100+ apps, 1000+ resources) require significantly more memory.

Fix:
  # Immediate (not persisted across pod restarts):
  kubectl set resources deployment argocd-application-controller \
    -n argocd \
    --limits=memory=2Gi \
    --requests=memory=1Gi

  # Permanent (via Helm values — commit this to Git):
  # In your ArgoCD Helm values.yaml:
  # controller:
  #   resources:
  #     limits:
  #       memory: 2Gi
  #     requests:
  #       memory: 1Gi

Tuning parameters (if memory increase alone isn't enough):
  # Reduce reconciliation frequency for large clusters:
  kubectl edit configmap argocd-cmd-params-cm -n argocd
  # Add:
  #   controller.operation.processors: "10"   (default: 10)
  #   controller.status.processors: "20"      (default: 20)
  #   controller.repo.server.timeout.seconds: "60"
```

### Symptom: Stuck on a Corrupted Application CR

```
Check:
  kubectl logs -n argocd \
    deploy/argocd-application-controller --tail=100 | grep -i "panic\|error"
  # Look for: repeated "panic" on a specific app name, or infinite error loop

Cause:
  An Application CR was created with an invalid spec or corrupted during an edit.
  The controller gets stuck trying to reconcile it.

Fix:
  # Delete the stuck Application (this does NOT delete the deployed K8s resources):
  kubectl delete application <STUCK_APP_NAME> -n argocd

  # Re-create it from your Git-stored Application manifest:
  kubectl apply -f apps/<app-name>.yaml -n argocd

  # Or re-create via CLI:
  argocd app create <APP_NAME> \
    --repo https://github.com/company/k8s-manifests \
    --path apps/catalog \
    --dest-server https://kubernetes.default.svc \
    --dest-namespace catalog-ns
```

### Symptom: Leader Election Failed (Multi-Replica Setup)

```
Check:
  kubectl logs -n argocd \
    -l app.kubernetes.io/name=argocd-application-controller --tail=50 \
    | grep "leader"
  # Look for: "failed to acquire leader lease"

Cause:
  Multiple controller replicas are configured and they cannot agree on a leader.
  This leaves the controller in a non-functional state.

Fix:
  # Delete all controller pods — they restart and re-elect a leader:
  kubectl delete pods -n argocd \
    -l app.kubernetes.io/name=argocd-application-controller
```

---

## Component 2 — argocd-repo-server Failing

**What breaks when this fails:**
- All syncs fail with `repo server unavailable`
- ArgoCD cannot clone repos or render Helm/Kustomize templates
- `argocd app diff` fails

### Symptom: Authentication Failure (Credential Expired)

```
Check:
  kubectl logs -n argocd deploy/argocd-repo-server --tail=100 \
    | grep -i "auth\|credential\|permission"
  # Look for: "authentication failed", "repository not found", "403 Forbidden"

Cause:
  GitHub PAT expired, SSH deploy key rotated, or Bitbucket token revoked.

Fix — Update via ArgoCD UI:
  Settings → Repositories → Find the repo → Disconnect → Reconnect with new credentials

Fix — Update via CLI:
  # For HTTPS with PAT:
  argocd repo add https://github.com/company/k8s-manifests \
    --username git \
    --password <NEW_PAT_TOKEN> \
    --upsert

  # For SSH:
  argocd repo add git@github.com:company/k8s-manifests \
    --ssh-private-key-path ~/.ssh/new_argocd_deploy_key \
    --upsert

Prevention:
  → Set PAT expiry to "no expiry" for machine-to-machine tokens
  → Or: set a calendar reminder to rotate 2 weeks before expiry
  → Store the rotation procedure in your runbook
```

### Symptom: Disk Full (Repo Cache)

```
Check:
  kubectl exec -n argocd deploy/argocd-repo-server -- df -h /tmp
  kubectl logs -n argocd deploy/argocd-repo-server --tail=50 \
    | grep "no space left"

Cause:
  The repo-server clones repos into /tmp as a cache.
  With many repos or large repos, /tmp fills up.

Fix (immediate):
  # Restart the pod — clears the /tmp cache:
  kubectl rollout restart deployment/argocd-repo-server -n argocd

Fix (long-term):
  # Increase the repo-server's ephemeral storage limit:
  kubectl edit deployment argocd-repo-server -n argocd
  # Add to containers[0].resources:
  #   limits:
  #     ephemeral-storage: "10Gi"
  #   requests:
  #     ephemeral-storage: "2Gi"
```

### Symptom: Helm Plugin or Custom Tool Not Found

```
Check:
  kubectl logs -n argocd deploy/argocd-repo-server --tail=100 \
    | grep -i "plugin\|not found\|exec"
  # Look for: "plugin 'helm-secrets' not found" or "exec: not found"

Cause:
  ArgoCD is configured to use a custom tool (helm-secrets, SOPS plugin, etc.)
  but it is not installed in the repo-server container image.

Fix:
  Option A: Use an init container to install the plugin at startup
    (configured in ArgoCD Helm values; requires ArgoCD restart)

  Option B: Build a custom ArgoCD image that includes the plugin:
    FROM quay.io/argoproj/argocd:v2.x.x
    USER root
    RUN curl -L https://... -o /usr/local/bin/helm-secrets && chmod +x /usr/local/bin/helm-secrets
    USER argocd
    → Build, push to ECR, update argocd-repo-server image in Helm values

  Option C: Remove the plugin dependency and use a different approach
    (e.g. replace helm-secrets with External Secrets Operator)
```

---

## Component 3 — argocd-server (UI / API) Not Responding

**What breaks when this fails:**
- Web UI returns 502 or 504
- `argocd` CLI fails with "connection refused" or timeout
- Note: syncs may STILL RUN — the controller is independent

### Symptom: Pod Crashed

```
Check:
  kubectl get pods -n argocd \
    -l app.kubernetes.io/name=argocd-server
  kubectl logs -n argocd deploy/argocd-server --tail=50

Fix:
  kubectl rollout restart deployment/argocd-server -n argocd
```

### Symptom: Ingress or Load Balancer Misconfigured

```
Check:
  # Is the argocd-server Service healthy?
  kubectl get service argocd-server -n argocd
  kubectl get endpoints -n argocd argocd-server

  # Is the Ingress configured correctly?
  kubectl get ingress -n argocd
  kubectl describe ingress argocd-server -n argocd
  # Look for: backend service name, port, host rules

  # Is the LoadBalancer external IP still valid?
  kubectl get svc argocd-server -n argocd -o jsonpath='{.status.loadBalancer.ingress}'

Common causes:
  → Cluster upgrade changed the LoadBalancer IP
  → Ingress controller restarted and lost its external address
  → TLS cert expired on the Ingress

Fix: update the DNS record to point to the new external IP
     Or: kubectl delete svc argocd-server -n argocd && reapply (triggers new LB provisioning)
```

### Symptom: TLS Certificate Expired

```
Check:
  kubectl logs -n argocd deploy/argocd-server --tail=50 | grep "cert\|tls\|expired"

Fix (self-signed cert — ArgoCD-managed):
  kubectl delete secret argocd-secret -n argocd
  kubectl rollout restart deployment/argocd-server -n argocd
  # ArgoCD regenerates a fresh self-signed cert on restart

Fix (cert-manager managed cert):
  kubectl delete certificate argocd-server-tls -n argocd
  # cert-manager re-issues immediately
  # Or: kubectl annotate certificate argocd-server-tls \
  #       cert-manager.io/renew-before=720h  ← renew 30 days early going forward
```

---

## Component 4 — argocd-notifications-controller Failing

**What breaks when this fails:**
- No Slack/PagerDuty/email messages on sync failures, app health changes
- Everything else still works (syncs continue)

```
Check:
  kubectl get pods -n argocd | grep notifications
  kubectl logs -n argocd deploy/argocd-notifications-controller --tail=50

Common causes:
  → Slack webhook URL changed or expired
  → PagerDuty integration key rotated
  → Notification template has a syntax error

Fix — Test notifications manually:
  argocd admin notifications trigger run on-sync-failed <APP_NAME> \
    --recipient slack:payments-alerts \
    -n argocd
  # If this fails: read the error to find which config is wrong

Fix — Check notification secrets:
  kubectl get secret argocd-notifications-secret -n argocd -o yaml
  # Verify all tokens are present and correctly base64-encoded
```

---

## Full Component Recovery Sequence

```
When ArgoCD is completely broken (all components):

1. Check all pods:
   kubectl get pods -n argocd

2. Restart all ArgoCD components in order:
   kubectl rollout restart deployment/argocd-redis -n argocd
   kubectl rollout restart deployment/argocd-repo-server -n argocd
   kubectl rollout restart deployment/argocd-server -n argocd
   kubectl rollout restart deployment/argocd-application-controller -n argocd

3. Watch pods come back:
   kubectl get pods -n argocd -w

4. Verify health:
   argocd app list

5. If an Application CR is corrupted and blocking the controller:
   kubectl delete application <CORRUPTED_APP> -n argocd
   # Re-create it from Git
```
