# GitOps Troubleshooting — Part 7: Multi-Cluster GitOps

> **The principle:** In multi-cluster setups, ArgoCD in one cluster deploys to others. Each additional cluster adds new failure modes around connectivity, credentials, RBAC, and destination routing.

---

## Multi-Cluster Architecture Overview

```
Single-cluster (simple):
  ArgoCD (in-cluster)  →  deploys to  →  same cluster (kubernetes.default.svc)

Multi-cluster (production pattern):
  ArgoCD (Management cluster)  →  deploys to  →  prod-eks
                                              →  staging-eks
                                              →  dev-eks

  ArgoCD communicates with each target cluster via its API server.
  Each cluster requires:
    → A registered cluster entry in ArgoCD (argocd cluster add)
    → A ServiceAccount + ClusterRoleBinding in the target cluster
    → Network connectivity from management cluster to target cluster API server
```

---

## Failure 1 — External Cluster Unreachable

**Signal:** App targeting an external cluster shows `Unknown` or `cluster unreachable` in ArgoCD.

```
Check:
  # List all clusters and their connection status
  argocd cluster list

  # Output:
  # SERVER                              NAME      VERSION  STATUS   MESSAGE
  # https://kubernetes.default.svc      in-cluster  1.27   OK
  # https://prod-eks.example.com        prod-eks    1.27   Unknown  dial tcp: i/o timeout
  #                                                                  ↑ this cluster is unreachable

  # Get details for the failing cluster
  argocd cluster get https://prod-eks.example.com
```

### Root Cause A — API Server IP Changed (EKS Control Plane Update)

```
EKS may change the control plane endpoint IP after:
  → A cluster version upgrade
  → An AWS control plane maintenance event

How to check:
  # Get current EKS endpoint
  aws eks describe-cluster \
    --name prod-eks \
    --region ap-northeast-1 \
    --query 'cluster.endpoint' \
    --output text

  # Compare with what ArgoCD has registered
  argocd cluster get https://prod-eks.example.com \
    | grep Server

Fix:
  # Remove the old cluster registration
  argocd cluster rm https://old-prod-eks.example.com

  # Re-add with fresh kubeconfig (gets the current endpoint and token)
  aws eks update-kubeconfig \
    --name prod-eks \
    --region ap-northeast-1

  argocd cluster add prod-eks-context \
    --name prod-eks \
    --upsert
```

### Root Cause B — ServiceAccount Token Expired

```
ArgoCD uses a ServiceAccount token in the target cluster for authentication.
These tokens can expire (especially if the cluster enforces short token lifetimes).

How to check:
  argocd cluster get https://prod-eks.example.com
  # Error: "Unauthorized" or "token has expired"

Fix:
  # Re-run cluster add — it creates a fresh ServiceAccount and token:
  argocd cluster add prod-eks-context --name prod-eks --upsert

  # This creates/updates:
  # → ServiceAccount: argocd-manager in kube-system of the target cluster
  # → ClusterRoleBinding: argocd-manager-role-binding
  # → Secret with the new token stored in ArgoCD's argocd namespace
```

### Root Cause C — Network Policy Blocking Connectivity

```
A NetworkPolicy in the management cluster may block the ArgoCD components
from reaching the target cluster's API server.

How to check:
  # Test connectivity from the repo-server (or application-controller)
  kubectl exec -n argocd deploy/argocd-repo-server -- \
    curl -k -s -o /dev/null -w "%{http_code}" \
    https://prod-eks.example.com

  # Expected: 401 (API server reachable but unauthorized — correct)
  # If timeout or connection refused: network path is blocked

Fix:
  # Check NetworkPolicy in argocd namespace
  kubectl get networkpolicy -n argocd

  # If a deny-all policy exists: add an egress rule allowing
  # argocd-application-controller → target cluster API server port (443)
  # NetworkPolicy egress to the cluster's API server CIDR on port 443
```

---

## Failure 2 — Cross-Cluster RBAC Gap

**Signal:** Apps in the target cluster show SyncFailed with "forbidden" even though the same app works on the management cluster.

```
Cause:
  ArgoCD's ServiceAccount (argocd-manager) exists in the target cluster
  but does not have sufficient permissions to deploy certain resource types.

Check:
  # Verify the ServiceAccount exists in the target cluster
  kubectl get sa argocd-manager -n kube-system \
    --context prod-eks-context

  # Verify the ClusterRoleBinding exists
  kubectl get clusterrolebinding argocd-manager-role-binding \
    --context prod-eks-context

  # Check what permissions the ClusterRole grants
  kubectl describe clusterrole argocd-manager-role \
    --context prod-eks-context

  # Simulate whether ArgoCD can perform a specific action
  kubectl auth can-i create deployment \
    --as=system:serviceaccount:kube-system:argocd-manager \
    -n catalog-ns \
    --context prod-eks-context
  # Expected: yes
  # If "no": add the permission

Fix:
  # Re-running argocd cluster add repairs the ClusterRole and ClusterRoleBinding:
  argocd cluster add prod-eks-context \
    --name prod-eks \
    --upsert
  # This recreates argocd-manager-role with all default permissions

  # If a specific resource type is missing (custom CRD or non-standard resource):
  kubectl edit clusterrole argocd-manager-role --context prod-eks-context
  # Add the missing resource type under rules
```

---

## Failure 3 — App Deployed to Wrong Cluster

**Signal:** Resources appear in cluster-A but Git's Application spec says they should be in cluster-B. Or vice versa.

```
Cause:
  The Application spec's destination.server URL is incorrect.

  Example (wrong):
    spec:
      destination:
        server: https://staging-eks.example.com  ← this is staging!
        namespace: catalog-ns
  
  But the app was meant for production.

Check:
  argocd app get <APP_NAME> | grep "Dest Server"
  # Verify this URL matches the intended cluster

  argocd cluster list
  # Compare server URLs to find the correct one

Fix in Git:
  Correct destination.server in the Application manifest:
    spec:
      destination:
        server: https://prod-eks.example.com   ← correct
        namespace: catalog-ns

  Commit → sync → ArgoCD syncs the app to the correct cluster.

  Clean up the wrongly deployed resources:
    kubectl delete namespace catalog-ns \
      --context staging-eks-context
    (if the namespace was created on the wrong cluster)

Prevention:
  Use AppProjects to restrict which clusters each project is allowed to deploy to:
    argocd proj get payments
    # Check "Destinations" section — only listed clusters/namespaces are allowed
```

---

## Failure 4 — Clock Skew Causing Token Expiry

**Signal:** Authentication errors appear intermittently — "token has expired" — even though the token was just generated.

```
Cause:
  OIDC/JWT tokens have issue and expiry timestamps.
  If a node's clock drifts (NTP not working), the token may appear expired
  to the target cluster even though it was just issued.

How to check:
  kubectl debug node/<NODE_NAME> -it \
    --image=ubuntu -- bash

  # Inside the debug pod:
  chronyc tracking
  # Look for: "System time" offset — if > 30 seconds, clock is drifted

  # Or from the node directly:
  kubectl get node <NODE_NAME> -o yaml \
    | grep -A5 "conditions"
  # Look for: NodeClock condition

Fix:
  # On EKS: nodes normally sync NTP via the Amazon Time Sync Service
  # A drifted node should be replaced (drain and terminate)
  kubectl drain <NODE_NAME> --ignore-daemonsets --delete-emptydir-data
  # Then terminate in EC2 console; ASG replaces it with a fresh node

  # Verify NTP on the new node:
  kubectl debug node/<NEW_NODE> -it \
    --image=ubuntu -- chronyc tracking
```

---

## Multi-Cluster App Configuration

### Application Spec for Multi-Cluster

```yaml
# This Application runs on the management cluster (argocd namespace)
# but deploys resources to prod-eks
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: catalog-prod
  namespace: argocd
spec:
  project: payments

  source:
    repoURL: https://github.com/company/k8s-manifests
    targetRevision: HEAD
    path: apps/catalog/overlays/prod   # Kustomize overlay for prod

  destination:
    server: https://prod-eks.example.com  # target cluster (not in-cluster)
    namespace: catalog-ns

  syncPolicy:
    automated:
      prune: true
      selfHeal: true
    syncOptions:
      - CreateNamespace=true
      - ServerSideApply=true
```

### AppProject Restricting Target Clusters

```yaml
# Prevents teams from deploying to prod from a staging project
apiVersion: argoproj.io/v1alpha1
kind: AppProject
metadata:
  name: payments
  namespace: argocd
spec:
  sourceRepos:
    - https://github.com/company/k8s-manifests

  destinations:
    - server: https://prod-eks.example.com
      namespace: "catalog-*"           # only catalog namespaces
    - server: https://staging-eks.example.com
      namespace: "*"                   # all namespaces on staging

  # Blocks: deploying catalog to auth namespace, deploying to dev cluster, etc.
```

---

## Multi-Cluster Commands Reference

```bash
# List all registered clusters
argocd cluster list

# Get details + connection test for a specific cluster
argocd cluster get https://prod-eks.example.com

# Re-add / update a cluster (repairs SA, ClusterRole, token)
argocd cluster add prod-eks-context --name prod-eks --upsert

# Remove a cluster
argocd cluster rm https://prod-eks.example.com

# List all apps targeting a specific cluster
argocd app list \
  | grep "prod-eks.example.com"

# Check cluster-specific RBAC
kubectl auth can-i create deployment \
  --as=system:serviceaccount:kube-system:argocd-manager \
  -n catalog-ns \
  --context prod-eks-context
```
