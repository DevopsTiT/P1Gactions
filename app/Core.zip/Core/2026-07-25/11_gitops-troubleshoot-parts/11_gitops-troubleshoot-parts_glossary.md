# GitOps Troubleshooting Parts — Glossary

**GitOps**
An operational model where Git is the single source of truth for all infrastructure and application configuration. Every change goes through a Git commit and pull request. A reconciliation tool (ArgoCD) enforces that the live cluster always matches what is in Git.

**ArgoCD**
A Kubernetes-native continuous delivery tool that implements GitOps. It watches a Git repository for Kubernetes manifests and automatically applies them to a cluster. It detects drift (when the cluster differs from Git) and can automatically restore the desired state.

**Application (ArgoCD)**
ArgoCD's primary object — a Kubernetes custom resource that defines: which Git repo and path to watch, which cluster and namespace to deploy to, and how to sync (manual or automatic). Every app has a sync status and a health status.

**Sync Status**
Whether the live cluster matches Git. `Synced` = cluster matches Git exactly. `OutOfSync` = they differ. `Unknown` = ArgoCD cannot determine (usually a component failure).

**Health Status**
Whether deployed resources are working. `Healthy` = all good. `Degraded` = something is failing (pod crashing, etc.). `Progressing` = update in progress. `Missing` = in Git but not in cluster. `Unknown` = cannot determine.

**OutOfSync**
The cluster state differs from the Git state. May be caused by: a new Git commit not yet applied, direct cluster edits (config drift), a resource created outside ArgoCD, or Kubernetes injecting default fields.

**Config Drift**
When someone changes a Kubernetes resource directly (via `kubectl edit` or `kubectl apply`) without updating Git. ArgoCD detects the discrepancy and (if self-heal is on) automatically reverts the cluster to Git state.

**Self-Heal**
An ArgoCD auto-sync option that triggers a re-sync whenever the cluster drifts from Git — not just when Git changes. Ensures that direct cluster edits are automatically reverted. Should be enabled in production to enforce GitOps.

**Prune**
An ArgoCD sync option that deletes resources from the cluster that exist in the cluster but have been removed from Git. Without prune, old resources accumulate as orphans after you delete them from your manifests.

**SyncFailed**
ArgoCD attempted to apply the Git manifests to the cluster and Kubernetes rejected the apply. The manifests were NOT applied — nothing changed. The error message in `argocd app get` explains why.

**Degraded**
ArgoCD successfully applied Git manifests, but the running workload is not healthy. Pods may be crashing, failing to start, or not serving traffic. The GitOps layer worked; the application layer is broken.

**Progressing**
A resource is currently updating (e.g. a Deployment rolling out new pods) and has not yet completed. ArgoCD sets the app to Progressing until the rollout completes or times out.

**Auto-Sync**
An ArgoCD setting that automatically triggers a sync whenever ArgoCD detects a difference between Git and the live cluster. When on, any Git push deploys automatically without human intervention.

**Sync Policy**
The configuration on an Application that controls how syncs are triggered: automated (auto-sync) or manual (human must click Sync). Also controls options like prune, selfHeal, and CreateNamespace.

**syncOptions**
A list of fine-grained sync behaviour flags on an Application. Examples: `CreateNamespace=true` (create namespace if missing), `ServerSideApply=true` (use Kubernetes server-side apply), `RespectIgnoreDifferences=true` (don't reset ignored fields during sync).

**ignoreDifferences**
An Application-level configuration that tells ArgoCD to skip specific fields when computing the diff. Used for fields that Kubernetes controllers add automatically (defaulting, HPA replicas, Istio injection) that are not in Git but are not real diffs.

**RespectIgnoreDifferences**
A syncOption that tells ArgoCD not to reset ignored fields during sync. Without it, `ignoreDifferences` only suppresses the display of the diff but ArgoCD still applies the Git value (overwriting HPA changes, for example).

**jsonPointers**
A notation used in `ignoreDifferences` to reference specific fields in a Kubernetes resource. `"/spec/replicas"` refers to `spec.replicas`. Based on RFC 6901 JSON Pointer syntax.

**managedFieldsManagers**
An alternative to jsonPointers in `ignoreDifferences`. Names a Kubernetes field manager (the component that set the field) — ArgoCD ignores all fields set by that manager. More robust than jsonPointers for injected annotations.

**argocd-application-controller**
The most critical ArgoCD component. Continuously watches both the cluster state and Git state, computes diffs, and drives the reconciliation loop. If this pod crashes, all apps stop syncing and health status freezes.

**argocd-repo-server**
The ArgoCD component that clones Git repositories and renders manifests (running Helm template, Kustomize build, or plain YAML). If this fails, all syncs fail because ArgoCD cannot read the manifests from Git.

**argocd-server**
The ArgoCD API server and Web UI host. Handles requests from the browser and `argocd` CLI. If this fails, the UI and CLI are unavailable — but syncs may still run (the application-controller is independent).

**argocd-dex-server**
The optional SSO/OIDC authentication proxy in ArgoCD. If this fails, SSO login (Google, GitHub, LDAP) stops working. Local `admin` username/password login still works.

**argocd-redis**
ArgoCD's cache layer. Stores rendered manifests, app state, and session data. If Redis fails, ArgoCD re-renders manifests from scratch on every request and is slower, but still functional.

**argocd-notifications-controller**
Sends notifications to Slack, PagerDuty, or email when app events occur (sync failed, health degraded, etc.). If this fails, notifications are silent but syncs continue.

**argocd-applicationset-controller**
Generates multiple Application objects from templates, driven by generators (list of clusters, Git directories, GitHub PRs). If this fails, existing apps are unaffected but no new ApplicationSets are processed.

**AppProject**
An ArgoCD object that defines policy boundaries for a group of Applications: which Git repos are allowed as sources, which clusters and namespaces are valid destinations, and which Kubernetes resource types can be deployed. Prevents cross-team access.

**Cluster Resource Allow List**
An AppProject setting listing the cluster-scoped resource types (CRDs, ClusterRoles, Namespaces) that apps in this project are allowed to create. An empty list blocks all cluster-scoped resources.

**App of Apps**
An ArgoCD pattern where one parent Application manages a set of Application manifests in Git. When the parent syncs, it creates/updates all child Applications. The standard pattern for managing many apps at scale. The root Application must itself be stored in Git.

**Sync Wave**
An annotation (`argocd.argoproj.io/sync-wave: "N"`) that controls the order in which resources are applied during a sync. Lower numbers run first. Used to ensure Secrets are created before the Deployments that reference them.

**Sync Hook**
A Kubernetes Job with an ArgoCD hook annotation that ArgoCD runs at a specific point in the sync lifecycle: PreSync (before), Sync (during), PostSync (after), or SyncFail (on failure). Used for database migrations, smoke tests, and cleanup tasks.

**hook-delete-policy**
An annotation on a sync hook Job that controls when ArgoCD deletes the Job after it runs. `HookSucceeded` = delete after success. `HookFailed` = delete after failure. `BeforeHookCreation` = delete before the next sync re-creates it.

**CrashLoopBackOff**
A Kubernetes pod status where the container starts, crashes, and Kubernetes restarts it with exponential backoff. Indicates an application error. Investigate with `kubectl logs <pod> --previous`.

**ImagePullBackOff**
A Kubernetes pod status where the container runtime cannot pull the container image. Caused by: wrong tag, expired ECR credentials, missing imagePullSecret.

**OOMKilled**
A Kubernetes pod termination reason — the container exceeded its `resources.limits.memory` and the Linux kernel killed the process. No application log output; visible in `kubectl describe pod` under Last State.

**Pending (pod)**
A Kubernetes pod state where the pod was created but cannot be scheduled to any node. Caused by: insufficient node resources, taint/toleration mismatch, nodeSelector with no matching nodes, or PVC not bound.

**imagePullSecrets**
A Kubernetes pod spec field that references a Secret containing container registry credentials. Required for pulling images from private registries (ECR, private Docker Hub) when IRSA or instance role authentication is not configured.

**IRSA (IAM Roles for Service Accounts)**
An EKS feature that associates an IAM role with a Kubernetes ServiceAccount. Pods using that ServiceAccount get AWS credentials scoped to that role — without storing any credentials in files or environment variables.

**Sealed Secrets**
A Bitnami tool that lets you encrypt Kubernetes Secrets using a cluster-specific public key. The encrypted SealedSecret can be safely stored in Git. Only the cluster's controller (with the matching private key) can decrypt it.

**External Secrets Operator (ESO)**
A Kubernetes operator that reads secret references from Git (ExternalSecret CRs) and fetches the actual values from AWS Secrets Manager, Vault, or other backends, then creates K8s Secrets in the cluster automatically.

**SOPS (Mozilla SOPS)**
A command-line tool that encrypts individual values within a YAML file using AWS KMS, GPG, or Azure Key Vault. The encrypted YAML can be stored in Git. An ArgoCD plugin decrypts at sync time.

**Sealed Secrets private key backup**
A copy of the controller's private key stored securely outside the cluster. Required for disaster recovery — if the cluster is rebuilt, the private key must be restored to decrypt old SealedSecrets. Never store this in Git.

**trufflehog**
An open-source tool that scans Git history for leaked credentials using regex patterns and entropy analysis. Run in CI pipelines before merge to prevent secrets from entering Git.

**gitleaks**
An open-source tool that scans Git repositories (staged or committed) for hardcoded credentials. Fast, configurable, and widely used as a pre-commit hook or CI gate.

**Base64**
A binary-to-text encoding scheme. Kubernetes Secrets store values as base64-encoded strings. This is NOT encryption — it is encoding. Any person with access to the encoded string can decode it in one command. Never treat base64 as a security measure.

**argocd-manager**
The ServiceAccount ArgoCD creates in target clusters (in the `kube-system` namespace) when you register an external cluster with `argocd cluster add`. It has a ClusterRoleBinding that gives ArgoCD permission to manage resources in the target cluster.

**argocd cluster add**
An ArgoCD CLI command that registers an external Kubernetes cluster. It creates the `argocd-manager` ServiceAccount and ClusterRoleBinding in the target cluster and stores the connection credentials in ArgoCD's namespace on the management cluster.

**NTP (Network Time Protocol)**
The protocol that keeps system clocks synchronised. Clock skew (clocks out of sync) causes OIDC/JWT token validation failures — tokens appear expired before they actually are. In AWS: nodes use the Amazon Time Sync Service for NTP.

**Clock Skew**
A difference between the clock on a node and the actual current time. Even a few seconds of skew can cause authentication failures with systems that validate timestamps strictly (OIDC, JWT, TLS certificates).

**Server-Side Apply (SSA)**
A Kubernetes API operation mode that lets the server handle field ownership and conflict resolution. Enabled in ArgoCD with `ServerSideApply=true` syncOption. More robust than client-side apply for resources managed by multiple controllers.

**Webhook (Git)**
An HTTP POST notification that GitHub/GitLab/Bitbucket sends to ArgoCD immediately when a new commit is pushed. Without a webhook, ArgoCD polls Git every 3 minutes. With a webhook, ArgoCD picks up changes within seconds of a push.

**Poll Interval**
The frequency at which ArgoCD checks Git for changes when no webhook is configured. Default: 3 minutes. Can be reduced but at the cost of increased Git API calls and ArgoCD load.

**Sync Window**
A time-based policy on an AppProject that either allows or denies syncs during specific time windows. Used to prevent deployments to production during business hours or weekends. Apps inside a deny window won't auto-sync.

**Orphaned Resource**
A Kubernetes resource running in the cluster that was once managed by ArgoCD but is no longer defined in Git. ArgoCD marks it as OutOfSync. With PRUNE enabled: it is deleted on next sync. Without PRUNE: it accumulates indefinitely.
