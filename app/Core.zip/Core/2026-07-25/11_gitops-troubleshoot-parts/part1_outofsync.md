# GitOps Troubleshooting — Part 1: OutOfSync

> **The principle:** OutOfSync is not always an emergency — it depends on WHY it is out of sync. Before touching the Sync button, always understand what changed and in which direction.

---

## What OutOfSync Means

```
OutOfSync means: the live state in the Kubernetes cluster
                 does NOT match the desired state in Git.

Two possible directions:
  A. Git is ahead of the cluster
     → A new commit was pushed; ArgoCD hasn't applied it yet
     → This is the NORMAL deploy flow — sync to apply

  B. The cluster is ahead of Git
     → Someone changed a resource directly in the cluster (kubectl edit, kubectl apply)
     → Git is the source of truth; the cluster has drifted
     → This is CONFIG DRIFT — fix in Git OR sync to revert the cluster
```

---

## The Four Causes of OutOfSync

### Cause A — New Git Commit Not Yet Applied (Expected)

```
Signal:
  → You (or a colleague) just pushed a commit to the tracked branch
  → ArgoCD hasn't picked it up yet (up to 3 minutes if no webhook)
  → The diff shows: new image tag, updated env var, added resource

What to do:
  1. argocd app diff <APP> — review what will change
  2. Confirm every changed line is expected from the commit you pushed
  3. argocd app sync <APP>  (or click Sync in UI)

This is the standard deploy workflow.
Never skip step 1 — the diff confirms the deployment is exactly what you intended.
```

### Cause B — Config Drift (Direct Cluster Edit)

```
Signal:
  → No recent Git commit in the tracked branch
  → OutOfSync appeared without a push to Git
  → The diff shows: a value in the CLUSTER that is NOT in Git
    (or a cluster value that DIFFERS from Git)

Example diff:
  Git state:     memory: "512Mi"
  Cluster state: memory: "256Mi"   ← someone set this manually

Investigation:
  → Who made the change?
    kubectl get events -n <namespace> | grep "FieldManager"
    OR: check AWS CloudTrail for kubectl API calls (if using EKS)
    OR: check git history — maybe the Git value was wrong originally

Decision:
  If the manual change was WRONG (cluster has old/incorrect value):
    → Sync to restore Git state (drift is erased; cluster returns to 512Mi)

  If the manual change was CORRECT (someone fixed a bug under pressure):
    → Update Git to match the cluster change first
    → Commit and push the correction
    → Then sync (or auto-sync applies it)
    → Git stays the source of truth

Root cause prevention:
  → Enable self-heal on the app:
      argocd app set <APP> --self-heal
  → Add RBAC to prevent direct kubectl edits to production:
      Use OPA/Gatekeeper or Kyverno to block kubectl apply on production namespaces
```

### Cause C — Resource Exists in Cluster But Not in Git

```
Signal:
  → The diff shows a resource in the cluster that has NO matching entry in Git
  → Colour in diff: red "cluster only" block

This happens when:
  → Someone ran `kubectl create` or `kubectl apply` manually outside ArgoCD
  → An operator created a resource ArgoCD doesn't track
  → A migration left behind a resource that was never cleaned up

Decision:
  If the resource SHOULD be managed by ArgoCD:
    → Add its manifest to Git → commit → sync
    → ArgoCD takes ownership and tracks it going forward

  If the resource SHOULD NOT exist:
    → kubectl delete <resource> -n <namespace>
    → Then sync — ArgoCD's prune removes it going forward if it returns

  Never leave "cluster only" resources unresolved.
  They accumulate and cause future naming conflicts or unexpected behaviour.
```

### Cause D — Kubernetes Controller Added Fields (False OutOfSync)

```
Signal:
  → No code change, no manual change — but ArgoCD keeps showing OutOfSync
  → The diff shows trivial fields like:
      spec.template.spec.serviceAccountName: default
      spec.template.spec.securityContext: {}
  → These are added by kube-controller-manager after the resource is created

These are NOT real diffs — they are Kubernetes defaults that ArgoCD
didn't set but Kubernetes injected.

Fix: add ignoreDifferences to the Application spec
  (See Part 5 — ignoreDifferences for the full configuration)

Quick fix in the Application spec:
  spec:
    ignoreDifferences:
      - group: apps
        kind: Deployment
        jsonPointers:
          - /spec/template/spec/serviceAccountName
          - /spec/template/spec/securityContext
```

---

## Reading the Diff View in Detail

### ArgoCD UI Diff Layout

```
DESIRED STATE (Git)            │  LIVE STATE (Cluster)
───────────────────────────    │  ───────────────────────────
image: catalog:v2.3.1          │  image: catalog:v2.3.0    ← highlighted yellow
replicas: 3                    │  replicas: 3               (same — no highlight)
resources:                     │  resources:
  limits:                      │    limits:
    memory: "512Mi"            │      memory: "256Mi"       ← highlighted yellow
    cpu: "500m"                │      cpu: "500m"           (same — no highlight)
env:                           │  env:
  - name: DB_HOST              │    - name: DB_HOST         (same)
    value: "db.prod.internal"  │      value: "db.prod.internal"
```

**Colour codes:**

```
No highlight (white)   → identical in Git and cluster; no change
Yellow highlight       → value differs between Git and cluster
Green in Git column    → field exists in Git but NOT in cluster
                         (will be ADDED to cluster on sync)
Red in cluster column  → field exists in cluster but NOT in Git
                         (will be REMOVED from cluster on sync IF prune is enabled)
                         (will be LEFT if prune is disabled)
```

### What to Check Before Every Sync

```
Checklist before clicking Sync:

  ✅ Are all yellow lines the change I intended?
     → If I pushed a new image tag: yellow lines should show old→new tag

  ✅ Are all green lines (additions) expected?
     → New ConfigMap, new env var — do I recognise these from the commit?

  ✅ Are there any red lines (deletions)?
     → If PRUNE is ON: these resources will be deleted from the cluster
     → If PRUNE is OFF: they will remain as orphans
     → Is this deletion intentional?

  ✅ Are there any unexpected red lines from resources I didn't touch?
     → If yes: a prune may wipe something important
     → Check the commit diff in GitHub first — confirm what files changed

  ⚠️ Never sync if you see unexpected red (deletion) lines without understanding why.
```

---

## Diagnosing OutOfSync via CLI

```bash
APP_NAME="catalog-service"

# 1. Get the current sync status
argocd app get $APP_NAME

# 2. Show the full diff (Git vs cluster)
argocd app diff $APP_NAME

# 3. Force a refresh from Git (bypasses 3-min poll cache)
argocd app get $APP_NAME --refresh

# 4. If still OutOfSync after refresh — check when Git was last polled
argocd app get $APP_NAME \
  -o json | jq '.status.observedAt'

# 5. Check sync history to see if this has been happening repeatedly
argocd app history $APP_NAME

# 6. Get raw Application CRD to see full conditions
kubectl get application $APP_NAME -n argocd \
  -o jsonpath='{.status.conditions}' | jq '.'
```

---

## Resolving OutOfSync

```bash
APP_NAME="catalog-service"

# Standard sync (apply Git state to cluster)
argocd app sync $APP_NAME

# Sync and DELETE resources removed from Git (prune)
argocd app sync $APP_NAME --prune

# Dry-run: show what would change WITHOUT applying
argocd app sync $APP_NAME --dry-run

# Sync only one specific resource (not the whole app)
argocd app sync $APP_NAME \
  --resource apps:Deployment:catalog-service

# Sync to a specific historical Git SHA (not HEAD)
argocd app sync $APP_NAME --revision abc1234

# Enable self-heal so drift is auto-corrected in future
argocd app set $APP_NAME --self-heal
```

---

## Common OutOfSync Mistakes

| Mistake | What Goes Wrong | Fix |
|---|---|---|
| Clicking Sync without reading the diff | A prune deletes a ConfigMap that wasn't in Git; service crashes | Always check diff first; look for red lines |
| Treating all OutOfSync as urgent | Normal after every Git push; creates alert fatigue | Only alert on OutOfSync that persists > 5 minutes after an auto-sync attempt |
| Fixing drift directly in the cluster | Self-heal reverts it within minutes | Fix in Git; let ArgoCD apply it |
| Using `:latest` image tag | ArgoCD sees no image change; new image never deploys | Pin to a specific SHA or semantic version tag |
