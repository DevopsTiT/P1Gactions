# GitOps Troubleshooting — Part 6: Secrets in GitOps — Safe Patterns

> **The rule:** Never store plaintext secrets in Git. Not in a private repo. Not base64-encoded. Not in a .gitignore'd file. A repo that contains a secret is a secret that has already been leaked — you just don't know it yet.

---

## Why This Is Critical

```
What gets stolen when a Git repo is leaked:
  Plaintext secret:    Immediate, unambiguous credential exposure
  Base64 secret:       Same as plaintext — base64 is encoding, NOT encryption
                       echo "c2VjcmV0" | base64 -d  → secret (2 seconds)

Attack surface:
  Anyone with read access to the repo has ALL secrets
  Git history is permanent — deleting a file doesn't remove it from history
  GitHub/GitLab/Bitbucket breach → all repos exposed at once
  A leaked CI/CD token with repo:read scope = full secret exposure

Real incidents caused by secrets in Git:
  → Uber breach (2016): AWS keys in GitHub → S3 access → 57M records
  → Toyota (2023): AWS key in public GitHub repo for 5 years
  → Twitch (2021): source code leaked → embedded keys and tokens
```

---

## Pattern 1 — Sealed Secrets (Bitnami)

**Best for:** Teams that want secrets in Git without a secret manager dependency.

```
How it works:
  1. A controller runs in the cluster with a private key
  2. You encrypt a secret with the controller's PUBLIC key:
       kubeseal --fetch-cert https://argocd.internal/api/v1/... > pub-cert.pem
       kubectl create secret generic db-credentials \
         --from-literal=password=mysecret \
         --dry-run=client -o yaml \
         | kubeseal --cert pub-cert.pem --format yaml \
         > sealed-db-credentials.yaml
  3. Store sealed-db-credentials.yaml in Git (safe — only the cluster can decrypt it)
  4. ArgoCD syncs the SealedSecret → controller decrypts → creates a real K8s Secret

Security model:
  → Encrypted with cluster-specific key
  → Only the cluster that has the private key can decrypt it
  → If the Git repo leaks: attacker gets only encrypted data (useless without the key)

Troubleshooting:
  # Secret not decrypted (K8s Secret not created):
  kubectl get sealedsecret -n catalog-ns
  kubectl describe sealedsecret db-credentials -n catalog-ns
  # Look for: "failed to unseal" in events

  # Common cause: controller's private key was regenerated (cluster re-created)
  # Fix: re-seal all secrets with the new public key from the new cluster

Limitation:
  If you rotate the cluster (DR, recreation), all sealed secrets must be
  re-sealed because the private key is gone.
  Fix: back up the controller's private key:
    kubectl get secret -n kube-system \
      -l sealedsecrets.bitnami.com/sealed-secrets-key \
      -o yaml > sealed-secrets-private-key-backup.yaml
  Store this backup securely outside of Git.
```

---

## Pattern 2 — External Secrets Operator (ESO)

**Best for:** Teams already using AWS Secrets Manager, HashiCorp Vault, or GCP Secret Manager.

```
How it works:
  1. ESO controller runs in the cluster
  2. You store an ExternalSecret CR in Git (contains only the reference, not the value):
       apiVersion: external-secrets.io/v1beta1
       kind: ExternalSecret
       metadata:
         name: db-credentials
         namespace: catalog-ns
       spec:
         refreshInterval: 1h
         secretStoreRef:
           name: aws-secrets-manager
           kind: ClusterSecretStore
         target:
           name: db-credentials   ← name of the K8s Secret to create
           creationPolicy: Owner
         data:
           - secretKey: password       ← key in the K8s Secret
             remoteRef:
               key: /catalog/db-password  ← ARN/path in Secrets Manager
               property: password

  3. ArgoCD syncs the ExternalSecret to the cluster
  4. ESO fetches the value from AWS Secrets Manager and creates the K8s Secret
  5. On `refreshInterval`: ESO re-fetches and updates the Secret automatically

Security model:
  → Git contains ONLY the reference (the ARN/path) — no values
  → Values live in AWS Secrets Manager with IAM access control + CloudTrail audit
  → Rotation: update the value in Secrets Manager → ESO picks it up on next refresh

Troubleshooting:
  # Check ExternalSecret status
  kubectl get externalsecret -n catalog-ns
  kubectl describe externalsecret db-credentials -n catalog-ns
  # Look for: Ready condition, Last Refresh time, any error message

  # Common errors:
  # "SecretStore not found"
  #   → The ClusterSecretStore 'aws-secrets-manager' doesn't exist or isn't Ready
  #   kubectl get clustersecretstore aws-secrets-manager
  #   kubectl describe clustersecretstore aws-secrets-manager
  #
  # "AccessDenied"
  #   → ESO's IAM role lacks secretsmanager:GetSecretValue permission
  #   → Check IRSA annotation on ESO's ServiceAccount
  #   → Add the permission to the IAM role
  #
  # "SecretNotFound"
  #   → The ARN/path in remoteRef doesn't match the secret's actual name in AWS
  #   → Verify: aws secretsmanager describe-secret --secret-id /catalog/db-password
```

---

## Pattern 3 — SOPS (Mozilla SOPS) with ArgoCD Plugin

**Best for:** Teams that want encrypted YAML files directly in Git without an external secret manager.

```
How it works:
  1. Use SOPS to encrypt secret values in a YAML file using AWS KMS or GPG:
       sops --encrypt \
         --kms arn:aws:kms:ap-northeast-1:123456789012:key/abc-def \
         secrets.yaml > secrets.enc.yaml
  2. Store the encrypted secrets.enc.yaml in Git
  3. ArgoCD uses an ArgoCD plugin (KSOPS or argocd-vault-plugin) to decrypt
     at sync time using the cluster's IAM role (IRSA)

  The decrypted secret values never exist on disk — they go directly to kubectl apply.

Security model:
  → Encrypted with AWS KMS; only the IAM role with kms:Decrypt permission can decrypt
  → Each key rotation requires re-encrypting the file (less convenient)
  → Git history contains only encrypted values

Troubleshooting:
  # Plugin not found:
  kubectl logs -n argocd deploy/argocd-repo-server | grep "plugin\|sops"
  # Plugin must be installed in the repo-server image or as an init container

  # KMS access denied:
  # Verify the repo-server's IRSA role has kms:Decrypt permission
  kubectl get sa argocd-repo-server -n argocd -o yaml
  # Check the iam.amazonaws.com/role annotation
```

---

## Pattern 4 — AWS Secrets Manager + IRSA (No Secrets Anywhere)

**Best for:** AWS-native teams; the cleanest architecture — no secrets in any file.

```
How it works:
  Pod → uses IRSA → assumes IAM role → calls secretsmanager:GetSecretValue at runtime
  → Secret value is fetched directly from Secrets Manager by the application code
  → No K8s Secret object needed; no file on disk; nothing in Git

Git contains only:
  serviceAccountName: catalog-api
  (the ServiceAccount that has the IRSA annotation with the IAM role ARN)

Application code:
  import boto3
  secret = boto3.client('secretsmanager').get_secret_value(
    SecretId='/catalog/db-password'
  )['SecretString']

Security model:
  → Zero secrets in Git, K8s Secrets, environment variables, or config files
  → IAM controls which pods can access which secrets
  → CloudTrail: every GetSecretValue call is audited with pod identity
  → Automatic rotation supported (Secrets Manager rotates; app re-fetches on next call)

Troubleshooting:
  # Pod getting AccessDenied from Secrets Manager:
  kubectl describe pod <POD> -n catalog-ns | grep -A5 "AWS_ROLE_ARN"
  # Verify IRSA annotation is on the ServiceAccount:
  kubectl get sa catalog-api -n catalog-ns -o yaml | grep iam.amazonaws.com
  # Verify the IAM role trust policy allows the ServiceAccount
  # Verify the IAM role has secretsmanager:GetSecretValue on the specific ARN
```

---

## What NOT to Do — Anti-Patterns

```
Anti-Pattern 1: Plaintext Secret in Git
  apiVersion: v1
  kind: Secret
  data:
    password: bXlzZWNyZXQ=   ← this is base64("mysecret") — NOT encrypted
  
  Why it's wrong: base64 -d outputs it in 1 second. It's plaintext.
  Anyone with repo read access has the secret.
  It's in git history forever even after you delete the file.

Anti-Pattern 2: .gitignore'd secrets file
  secrets.yaml added to .gitignore
  
  Why it's wrong:
    → Cannot be deployed by ArgoCD (file not in Git)
    → Developer accidentally commits it → leak
    → No audit trail of what values were set when
    → GitOps requires EVERYTHING in Git

Anti-Pattern 3: Encrypting with OpenSSL and committing the key
  git repo contains: secrets.enc (encrypted) AND encryption.key
  
  Obvious: storing the key next to the ciphertext defeats encryption entirely.

Anti-Pattern 4: Secret values in ConfigMaps
  Developers sometimes put "non-sensitive" values in ConfigMaps but these
  often include API keys, feature flags with sensitive logic, etc.
  Treat ConfigMaps as public — use ExternalSecret/SealedSecret for anything
  that shouldn't be read by anyone with kubectl access.
```

---

## Detecting Secrets in Git (Run in CI)

```bash
# trufflehog — scans git history for credentials (regex + entropy analysis)
trufflehog git https://github.com/company/k8s-manifests \
  --only-verified \
  --json | jq '.SourceMetadata.Data.Git'

# gitleaks — fast credential scanner
gitleaks detect \
  --source . \
  --verbose \
  --report-path /tmp/gitleaks-report.json
cat /tmp/gitleaks-report.json | jq '.[] | {file: .File, line: .StartLine, rule: .RuleID}'

# Run these in a pre-commit hook or CI pipeline stage:
# If either returns findings → fail the pipeline and alert security team
```

---

## Secret Pattern Decision Matrix

| Situation | Recommended Pattern |
|---|---|
| Already using AWS Secrets Manager | External Secrets Operator (ESO) |
| No external secret manager; want simplicity | Sealed Secrets (Bitnami) |
| App code already calls Secrets Manager directly | IRSA + direct SDK call (no K8s Secret needed) |
| Multi-cloud or self-hosted; already using Vault | ESO with Vault SecretStore |
| YAML encryption in Git preferred; AWS KMS available | SOPS with ArgoCD plugin |
| Any of the above fails: | Never fall back to plaintext; fix the pattern |
