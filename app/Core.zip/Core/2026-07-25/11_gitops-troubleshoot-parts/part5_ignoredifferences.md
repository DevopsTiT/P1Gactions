# GitOps Troubleshooting — Part 5: ignoreDifferences — Suppressing False OutOfSync

> **The principle:** Some Kubernetes controllers mutate resources after ArgoCD applies them, adding fields that were never in Git. ArgoCD then reports OutOfSync even though the cluster is behaving exactly as desired. `ignoreDifferences` tells ArgoCD to stop watching those fields.

---

## What ignoreDifferences Does

```
ArgoCD computes OutOfSync by comparing:
  Git state (what the manifest says)
  vs
  Live cluster state (what actually exists)

Problem: Kubernetes itself modifies resources after they are applied.
         ArgoCD sees those modifications as "cluster changed something Git didn't set"
         → App shows OutOfSync, even though everything is correct.

ignoreDifferences:
  A list of field paths (jsonPointers) or field managers (managedFieldsManagers)
  that ArgoCD should SKIP when computing the diff.

  → The app shows Synced even if those fields differ between Git and cluster.
  → Everything else is still tracked and diff'd normally.
```

---

## When You Need ignoreDifferences

The most reliable signal: app constantly flips to OutOfSync within seconds of syncing, with no Git changes.

```
Check if this is the cause:
  argocd app diff <APP_NAME>
  # If the diff shows ONLY fields like:
  #   spec.template.spec.serviceAccountName: default
  #   spec.template.spec.securityContext: {}
  #   metadata.annotations.last-applied-configuration
  # → These are Kubernetes-injected fields. Use ignoreDifferences.
```

---

## Common False OutOfSync Sources

### 1 — kube-controller-manager Adds Default Fields to Deployments

```
Fields Kubernetes injects after creation (not in your Git manifest):
  spec.template.spec.serviceAccountName: default
  spec.template.spec.securityContext: {}
  spec.template.spec.terminationGracePeriodSeconds: 30
  spec.template.spec.dnsPolicy: ClusterFirst
  spec.template.spec.schedulerName: default-scheduler
  spec.progressDeadlineSeconds: 600
  spec.revisionHistoryLimit: 10

These are Kubernetes defaults — the cluster adds them automatically.
Your Git manifest doesn't include them.
ArgoCD sees them as "cluster has extra fields" → OutOfSync.

Fix in Application spec:
  spec:
    ignoreDifferences:
      - group: apps
        kind: Deployment
        jsonPointers:
          - /spec/template/spec/serviceAccountName
          - /spec/template/spec/securityContext
          - /spec/progressDeadlineSeconds
          - /spec/revisionHistoryLimit
```

### 2 — HPA Modifies Deployment Replicas (Most Important)

```
Problem:
  Git says: spec.replicas: 3
  HPA scales the Deployment to: spec.replicas: 7 (during high traffic)
  ArgoCD sees: cluster has 7, Git says 3 → OutOfSync
  ArgoCD syncs: resets replicas back to 3 (overrides the HPA!)
  HPA scales back to 7 → ArgoCD syncs again → infinite fight

This is a critical misconfiguration: ArgoCD and HPA fight over replicas.

Full fix (two parts required):

  Part 1 — ignoreDifferences for the replicas field:
  spec:
    ignoreDifferences:
      - group: apps
        kind: Deployment
        jsonPointers:
          - /spec/replicas

  Part 2 — RespectIgnoreDifferences syncOption:
  spec:
    syncPolicy:
      syncOptions:
        - RespectIgnoreDifferences=true
  
  Why both are needed:
    ignoreDifferences: tells ArgoCD not to SHOW it as a diff
    RespectIgnoreDifferences: tells ArgoCD not to RESET it during sync
    Without Part 2: ArgoCD still resets replicas to Git value on every sync,
    even though it doesn't show it in the diff view.
```

### 3 — cert-manager Injects Annotations into Ingress

```
Problem:
  You have cert-manager installed. It adds annotations to your Ingress:
    annotations:
      cert-manager.io/certificate-name: catalog-tls
      cert-manager.io/common-name: catalog.example.com

  These annotations were NOT in your Git manifest.
  ArgoCD sees them → OutOfSync.

Fix:
  spec:
    ignoreDifferences:
      - group: networking.k8s.io
        kind: Ingress
        managedFieldsManagers:
          - cert-manager-controller

  managedFieldsManagers tells ArgoCD to ignore all fields
  written by the cert-manager-controller field manager.
  This is more reliable than listing individual annotation paths.
```

### 4 — Istio Injects Sidecar Annotation into Pods/Deployments

```
Problem:
  Istio's injection webhook adds a status annotation to pods:
    annotations:
      sidecar.istio.io/status: '{"version":"abc123","initContainers":["istio-init"],...}'

  This changes after every Istio version upgrade.
  ArgoCD sees it → OutOfSync after every Istio update.

Fix:
  spec:
    ignoreDifferences:
      - group: apps
        kind: Deployment
        managedFieldsManagers:
          - istio-sidecar-injector
```

### 5 — Webhook Mutation (Generic)

```
Problem:
  Any mutating admission webhook can add/change fields after apply.
  Common examples:
    - OPA/Gatekeeper adding defaults
    - Kyverno applying policies
    - Custom operators adding annotations

Fix (generic pattern — inspect with kubectl):
  # Find out WHO is setting the field:
  kubectl get deployment <NAME> -n <NS> \
    -o json | jq '.metadata.managedFields[] | {manager: .manager, operation: .operation, fieldsV1: .fieldsV1}'
  # The "manager" field shows which component set each field
  # Use that manager name in managedFieldsManagers

  spec:
    ignoreDifferences:
      - group: apps
        kind: Deployment
        managedFieldsManagers:
          - <the-manager-name-from-above>
```

---

## Full ignoreDifferences Example (Production-Ready)

```yaml
# In the Application spec or Application template (App of Apps):
spec:
  ignoreDifferences:
    # HPA replicas — prevent ArgoCD/HPA fight
    - group: apps
      kind: Deployment
      jsonPointers:
        - /spec/replicas

    # Kubernetes-injected defaults
    - group: apps
      kind: Deployment
      jsonPointers:
        - /spec/template/spec/serviceAccountName
        - /spec/template/spec/securityContext
        - /spec/progressDeadlineSeconds

    # cert-manager annotations on Ingress
    - group: networking.k8s.io
      kind: Ingress
      managedFieldsManagers:
        - cert-manager-controller

    # Istio sidecar injection
    - group: apps
      kind: Deployment
      managedFieldsManagers:
        - istio-sidecar-injector

  syncPolicy:
    syncOptions:
      # Required partner to ignoreDifferences for replicas
      - RespectIgnoreDifferences=true
      # Recommended for all apps
      - ServerSideApply=true
```

---

## Debugging: Is This a Real Diff or a False Diff?

```bash
# Step 1: show the full diff
argocd app diff <APP_NAME>

# Step 2: if the diff shows ONLY injected fields — add ignoreDifferences
# If the diff shows YOUR fields (image tag, env vars) — it is a real diff

# Step 3: find who set a specific field using managedFields
kubectl get deployment <NAME> -n <NS> \
  -o jsonpath='{.metadata.managedFields}' | jq '.[] | {manager, operation}'

# Step 4: after adding ignoreDifferences, force re-sync to clear the diff
argocd app sync <APP_NAME> --force

# Step 5: verify the app is now Synced
argocd app get <APP_NAME>
```

---

## Common ignoreDifferences Mistakes

| Mistake | What Goes Wrong | Fix |
|---|---|---|
| Only setting ignoreDifferences without RespectIgnoreDifferences | ArgoCD doesn't show the replicas diff but still resets replicas to Git value on every sync | Add `RespectIgnoreDifferences=true` to syncOptions |
| Using jsonPointers for dynamic annotation values | Annotation value changes (e.g. cert serial number); jsonPointer still matches → still OutOfSync | Use `managedFieldsManagers` instead of `jsonPointers` for injected annotations |
| Suppressing real diffs with ignoreDifferences | A genuine config change is hidden; team doesn't notice | Only suppress fields that are ALWAYS injected by controllers; never suppress app-owned fields |
