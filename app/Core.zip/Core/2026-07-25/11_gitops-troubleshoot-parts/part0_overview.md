# GitOps Troubleshooting — Part 0: Overview, E2E Flow & Decision Tree

---

## E2E Flow Summary

```
1. ALWAYS-ON FOUNDATIONS
   → ArgoCD Application Controller healthy (pod Running in argocd namespace)
   → Repo Server reachable (can clone the tracked Git repo)
   → Every app has sync policy defined; self-heal and prune configured
   → Webhook from Git → ArgoCD registered (prevents 3-min polling lag)
   → RBAC: no team can kubectl-edit production resources directly

2. DAILY (automated checks)
   → Scan Applications list: any Degraded or OutOfSync apps?
   → Confirm no apps stuck in "Progressing" > 10 minutes
   → Check ArgoCD component health (controller, repo-server, server pods)
   → Alert if any app's last-sync-time > 30 minutes (stale sync state)

3. WHEN AN ALERT FIRES ("App X is OutOfSync / Degraded / SyncFailed")
   → Identify: is it a Git problem, a cluster problem, or an application problem?
   → Git problem   → fix the manifest in the repo; push; re-sync
   → Cluster problem → fix infra (node, namespace, RBAC); re-sync
   → App problem   → fix the application code/config in Git; push; re-sync
   → NEVER fix directly in the cluster — always fix in Git first

4. MONTHLY REVIEW
   → Audit: any apps with manual sync history (should be automated in staging)
   → Drift report: apps that had OutOfSync events caused by direct cluster edits
   → Prune audit: orphaned resources that weren't pruned (prune=false apps)
   → Secret management review: any secrets stored in Git plaintext?

5. QUARTERLY CYCLE
   → ArgoCD version upgrade review: check release notes for breaking changes
   → RBAC policy review: who has sync/delete access to which projects?
   → Repository credential rotation: rotate SSH keys and PATs for repo access
   → App of Apps structure review: any orphaned child apps with no parent?

6. ROLLBACK / REGRESSION
   → Deploy-triggered regression: ArgoCD History → Rollback to last known-good SHA
   → Config drift found: sync immediately to restore Git state
   → Broken ArgoCD itself: kubectl rollout restart in argocd namespace
   → Corrupted Application CR: delete and re-create from Git manifest
```

---

## Decision Tree — "GitOps / ArgoCD is broken — what is wrong?"

```
"GitOps / ArgoCD is broken — what is wrong?"
│
├─ App shows OutOfSync
│   ├─ Was there a recent Git push?
│   │   ├─ YES → Normal: click Sync (or wait for auto-sync)
│   │   │         Check diff first to confirm changes are expected
│   │   └─ NO  → Config drift: someone kubectl-edited the cluster directly
│   │             → Open Diff view → identify the drifted field
│   │             → Fix in Git (if change was intentional) OR sync to revert
│   │
│   └─ Sync is failing (SyncFailed, not just OutOfSync)?
│       → Go to "Sync Failures" branch below
│
├─ App shows Degraded (Synced but unhealthy)
│   ├─ Which resource is red in the tree?
│   │   ├─ Pod → CrashLoopBackOff → check pod logs (previous container)
│   │   ├─ Pod → OOMKilled        → check memory limit; increase in Git
│   │   ├─ Pod → ImagePullBackOff → check image tag exists in ECR
│   │   ├─ Pod → Pending          → check node capacity / taints
│   │   └─ Deployment → 0/N ready → check ReplicaSet events
│   │
│   └─ All pods green but app still Degraded?
│       → Check custom health check resource (Rollout, VirtualService)
│       → Check if health annotation is wrong in ArgoCD app spec
│
├─ Sync Failures
│   ├─ "namespace not found"
│   │   → Create namespace or enable AUTO-CREATE NAMESPACE in app spec
│   │
│   ├─ "resource already exists" (403/409)
│   │   → Resource was created outside ArgoCD; adopt it OR delete and let ArgoCD create
│   │   → Add annotation: argocd.argoproj.io/managed-by: argocd
│   │
│   ├─ "unable to replace resource" (immutable field change)
│   │   → You changed an immutable field (e.g. Job selector, PVC storageClass)
│   │   → Delete the resource manually → sync → ArgoCD recreates it
│   │
│   ├─ "permission denied" (RBAC)
│   │   → ArgoCD's ServiceAccount lacks permission to manage this resource type
│   │   → Add the resource type to the ArgoCD ClusterRole OR use a Project allow list
│   │
│   ├─ "hook failed" (sync hook error)
│   │   → A pre-sync or post-sync Job/Hook failed
│   │   → Check the hook Pod's logs → fix the hook script in Git
│   │
│   └─ "repo not found" / "authentication failed"
│       → Broken repo credentials → go to Settings → Repositories → reconnect
│
├─ ArgoCD itself is broken
│   ├─ UI not loading        → check argocd-server pod; check Ingress/LB
│   ├─ Apps not auto-syncing → check argocd-application-controller pod
│   ├─ Can't clone repos     → check argocd-repo-server pod; check credentials
│   └─ Notifications broken  → check argocd-notifications-controller pod
│
└─ App is stuck in "Progressing" forever
    ├─ Deployment rollout stalled → pods failing to come up → check pod logs
    ├─ Argo Rollout paused        → check rollout status; promote or abort
    └─ Post-sync hook running forever → check hook pod; has it timed out?
```

---

## Tool Map

| Tool | What It Does | When to Use | Cadence |
|---|---|---|---|
| ArgoCD UI → Applications list | Health + Sync status at a glance for all apps | Daily health check; first view during any incident | Daily |
| ArgoCD UI → Diff view | Side-by-side Git vs cluster YAML comparison | Any OutOfSync app; before every sync of a risky change | On OutOfSync |
| ArgoCD UI → History + Rollback | Past sync list with Git SHAs; rollback to any revision | Deploy regression; "what was running before?" | On regression |
| ArgoCD UI → Logs tab | Pod log stream directly in browser | CrashLoopBackOff; startup errors; any Degraded pod | On Degraded |
| `argocd app get` CLI | Shows app sync/health status + last sync details | Scripted health checks; CI/CD gate verification | Automated |
| `argocd app diff` CLI | Prints Git-vs-cluster diff in terminal | Pre-sync review in CI/CD pipelines | Before sync |
| `argocd app sync` CLI | Triggers a sync programmatically | Automated deploy pipelines | On merge |
| `argocd app rollback` CLI | Rolls back to a previous revision by number | Automated rollback in CI/CD | On regression |
| `kubectl get applications -n argocd` | Raw Application CRD state | When ArgoCD UI is down | Fallback |
| `kubectl logs -n argocd` | ArgoCD component logs (controller, repo-server) | When apps fail to sync for no visible reason | On mystery failures |
| `argocd admin app generate-spec` | Generates an Application manifest from CLI args | Creating app manifests for App of Apps | Setup |

---

## Part Index

| Part | File | What It Covers |
|---|---|---|
| Part 1 | part1_outofsync.md | OutOfSync causes (drift, commit, external resource), reading the diff view |
| Part 2 | part2_syncfailed.md | All SyncFailed errors: namespace missing, conflict, immutable field, RBAC, hooks |
| Part 3 | part3_degraded.md | Degraded app causes: CrashLoop, ImagePull, Pending, OOM |
| Part 4 | part4_component-failures.md | ArgoCD component failures: controller, repo-server, UI/API server |
| Part 5 | part5_ignoredifferences.md | False OutOfSync from controller mutations, HPA replicas, Istio/cert-manager |
| Part 6 | part6_secrets.md | Safe secret patterns: Sealed Secrets, ESO, SOPS, IRSA — and what NOT to do |
| Part 7 | part7_multi-cluster.md | Multi-cluster failures: unreachable cluster, cross-cluster RBAC, wrong destination |
| Mistakes | part8_common-mistakes.md | 10 common GitOps mistakes with symptoms and correct approaches |
