# GitOps Troubleshooting — Part 3: Degraded (App Deployed but Unhealthy)

> **The principle:** Degraded means ArgoCD successfully applied the Git manifests to the cluster — the GitOps sync layer worked. The problem is at the application layer: pods are not running correctly. Every fix must go back into Git.

---

## Degraded vs SyncFailed

```
SyncFailed: ArgoCD tried to apply Git → Kubernetes rejected the apply
            Nothing changed in the cluster. Fix: correct the manifest in Git.

Degraded:   ArgoCD successfully applied Git → Resources exist in the cluster
            BUT the running workload is unhealthy (pods crashing, not starting, etc.)
            The GitOps layer worked. The application/config layer is broken.
```

---

## How to Identify Which Resource Is Degraded

```
ArgoCD UI:
  → App detail view → resource tree
  → Look for any resource with a 🔴 red icon (Degraded)
  → Click that resource → Events tab
  → Click that pod → Logs tab

ArgoCD CLI:
  argocd app get <APP_NAME>
  # Scroll to the RESOURCE section
  # Look for any resource with STATUS ≠ Healthy

Kubernetes directly:
  kubectl get pods -n <NAMESPACE> -o wide
  # Look for: CrashLoopBackOff, ImagePullBackOff, Pending, OOMKilled, Error

  kubectl get events -n <NAMESPACE> \
    --sort-by='.lastTimestamp' | tail -30
  # Events often contain the root cause in plain English
```

---

## Cause 1 — CrashLoopBackOff

```
Signal in ArgoCD:
  Resource tree: Pod shows 🔴 CrashLoopBackOff
  Restart count increases every few minutes (visible in resource tree)

What is happening:
  The container starts → crashes (exits with non-zero code) →
  Kubernetes restarts it → crashes again → Kubernetes adds exponential
  back-off delay between restarts (hence "BackOff")

Investigation:
  # In UI: click the pod → Logs tab → toggle ☑ "previous" checkbox
  # This shows logs from the CRASHED container instance (not the current restarting one)

  # In CLI:
  POD=$(kubectl get pods -n <NS> -l app=catalog -o jsonpath='{.items[0].metadata.name}')
  kubectl logs $POD -n <NS> --previous --tail=100

  # Read the last lines before exit — they contain the crash reason
```

### CrashLoop Root Causes and Git-Level Fixes

```
Root Cause A: Missing environment variable
  Log output: "required env var DB_HOST not set"
              OR: panic / nil pointer dereference
  Fix in Git:
    Add the env var to the Deployment spec:
      env:
        - name: DB_HOST
          value: "db.prod.internal"
    OR: reference a Secret/ConfigMap that holds it:
      env:
        - name: DB_HOST
          valueFrom:
            secretKeyRef:
              name: db-credentials
              key: host

Root Cause B: Wrong Secret name in envFrom
  Log output: pod events show "secret 'db-credentials-prod' not found"
  Fix in Git:
    Correct the secretName in envFrom:
      envFrom:
        - secretRef:
            name: db-credentials   ← must match exact Secret name in the cluster

Root Cause C: Application startup error (code bug or bad config)
  Log output: stack trace, "database migration failed", "connection refused to Redis"
  Fix in Git:
    Fix the application code → push → CI builds a new image →
    Update the image tag in Git → ArgoCD deploys the fix

Root Cause D: Liveness probe too aggressive
  Event output: "Liveness probe failed; killing container"
  The container is healthy but takes > N seconds to start responding
  Fix in Git:
    Increase probe timing in the Deployment:
      livenessProbe:
        httpGet:
          path: /health
          port: 8080
        initialDelaySeconds: 30   ← was 5 (too short for slow startup)
        failureThreshold: 5       ← was 3
        periodSeconds: 10
```

---

## Cause 2 — ImagePullBackOff / ErrImagePull

```
Signal in ArgoCD:
  Resource tree: Pod shows ⚠️ ImagePullBackOff or ErrImagePull
  Events tab: "failed to pull image ... 404 Not Found"
              OR: "unauthorized: authentication required"
              OR: "manifest for image:tag not found"

What is happening:
  Kubernetes is trying to pull the container image but cannot:
  either the image tag doesn't exist, or authentication failed.
```

### ImagePullBackOff Root Causes and Fixes

```
Root Cause A: Image tag does not exist in ECR / registry
  Event: "manifest for catalog:v2.3.1 not found in registry"
  
  Investigation:
    # Check what tags exist in ECR
    aws ecr list-images \
      --repository-name catalog \
      --query 'imageIds[*].imageTag' \
      --output table

  Fix in Git:
    Correct the image tag in the Deployment spec:
      image: 123456789.dkr.ecr.ap-northeast-1.amazonaws.com/catalog:v2.3.0
    Commit → sync

Root Cause B: ECR authentication not configured for the namespace
  Event: "unauthorized: authentication required"
  
  Fix (short-term): create an imagePullSecret in the namespace:
    kubectl create secret docker-registry ecr-credentials \
      --docker-server=<account>.dkr.ecr.<region>.amazonaws.com \
      --docker-username=AWS \
      --docker-password=$(aws ecr get-login-password --region ap-northeast-1) \
      -n catalog-ns

  Add to Deployment in Git:
    spec:
      template:
        spec:
          imagePullSecrets:
            - name: ecr-credentials

  Better long-term fix (no secrets needed):
    Use IRSA on the node group with ecr:GetAuthorizationToken permission
    Use ECR pull-through cache
    → Node's instance role automatically authenticates to ECR

Root Cause C: Using ":latest" tag with no "latest" image in registry
  Event: "manifest for catalog:latest not found"
  Fix in Git:
    Never use :latest in production.
    Always pin to a specific SHA or semantic version:
      image: catalog@sha256:abc123...  ← most precise; immutable
      image: catalog:2.3.1            ← semantic version; still good
    The image updater tool (ArgoCD Image Updater) can automate tag bumps
```

---

## Cause 3 — Pod Stuck in Pending

```
Signal in ArgoCD:
  Resource tree: Pod shows ⚫ Pending (grey icon, not starting)
  Duration: more than 2 minutes without transitioning to Running

What is happening:
  The pod was created but Kubernetes cannot schedule it to any node.
  The pod is waiting in the scheduler queue.
  
  Investigation:
    kubectl describe pod <POD_NAME> -n <NS>
    # Scroll to Events section at the bottom
    # The event message will say exactly why scheduling failed
```

### Pending Root Causes and Fixes

```
Root Cause A: Insufficient node resources (most common)
  Event: "0/3 nodes are available: 3 Insufficient memory"
         "0/3 nodes are available: 3 Insufficient cpu"

  Options:
    Fix in Git (reduce the request):
      resources:
        requests:
          memory: "128Mi"   ← was 512Mi; reduce if the app can run with less
          cpu: "100m"

    Fix in infrastructure (scale the node group):
      # EKS: increase node group min/max size in Terraform/ASG
      # Or: add a new node group
      # Then re-schedule: kubectl delete pod <PENDING_POD> (it will reschedule)

Root Cause B: Taint / Toleration mismatch
  Event: "0/3 nodes are available: 3 node(s) had taint that pod didn't tolerate"
  
  Investigation:
    kubectl describe nodes | grep Taints
    # Example: Taints: dedicated=payments:NoSchedule

  Fix in Git: add the toleration to the Deployment:
    spec:
      template:
        spec:
          tolerations:
            - key: "dedicated"
              operator: "Equal"
              value: "payments"
              effect: "NoSchedule"

Root Cause C: NodeSelector or Affinity has no matching nodes
  Event: "0/3 nodes are available: 3 node(s) didn't match node selector"

  Investigation:
    kubectl get nodes --show-labels | grep <label>
    # Check if the label your nodeSelector references actually exists on any node

  Fix in Git: correct the nodeSelector or affinity to match actual node labels:
    spec:
      template:
        spec:
          nodeSelector:
            kubernetes.io/arch: amd64   ← verify this label exists on nodes

Root Cause D: PVC not bound (StatefulSet or pod with volume)
  Event: "persistentvolumeclaim 'data-vol' not found"
         OR: "pod has unbound immediate PersistentVolumeClaims"

  Fix:
    kubectl get pvc -n <NS>
    # If PVC is Pending: check StorageClass exists and provisioner is running
    kubectl get storageclass
    kubectl get pods -n kube-system | grep provisioner
    # If StorageClass missing: add it to Git; sync; PVC will bind
```

---

## Cause 4 — OOMKilled

```
Signal in ArgoCD:
  Resource tree: Pod shows restarting; Degraded
  kubectl describe pod: "Last State: Terminated  Reason: OOMKilled"
  No log output (the process was killed by the OS, not the application)

What is happening:
  The container used more memory than its resources.limits.memory allows.
  The Linux kernel OOM killer terminated the process.
  There is NO application log output — the kill is external to the app.

Investigation:
  kubectl describe pod <POD_NAME> -n <NS>
  # Look for:
  #   Last State:
  #     Terminated:
  #       Reason:    OOMKilled
  #       Exit Code: 137

  # Check current vs limit:
  kubectl top pods -n <NS>

Fix in Git:
  Increase the memory limit in the Deployment:
    resources:
      requests:
        memory: "256Mi"   ← minimum guaranteed to the pod
      limits:
        memory: "1Gi"     ← maximum before OOMKill (was 512Mi — increase this)

Long-term:
  → Set VPA (Vertical Pod Autoscaler) in recommendation mode to suggest
    correct resource values based on actual usage
  → Alert on OOMKilled events: kubectl get events | grep OOMKilled
```

---

## Cause 5 — All Pods Running But App Still Degraded

```
This is a less common case where Kubernetes reports pods as Running
but ArgoCD still marks the app as Degraded.

Possible causes:

A: Custom health check resource (Argo Rollouts)
   If the app uses an Argo Rollout (canary/blue-green), ArgoCD derives
   health from the Rollout object, not the Deployment.
   
   Check:
     kubectl get rollout <NAME> -n <NS>
     kubectl argo rollouts status <NAME> -n <NS>
   
   If Rollout is paused (waiting for manual promotion):
     kubectl argo rollouts promote <NAME> -n <NS>

B: VirtualService health (Istio)
   If ArgoCD has a custom health check for VirtualService and the VS
   has an error, the app shows Degraded despite healthy pods.
   
   Check:
     kubectl describe virtualservice <NAME> -n <NS>

C: Wrong health annotation in Application spec
   If spec.ignoreDifferences or a custom health check is misconfigured,
   ArgoCD may compute health incorrectly.
   
   Check:
     argocd app get <NAME> -o yaml | grep -A10 "health:"
```

---

## Investigation Command Reference

```bash
NS="catalog-ns"
APP="catalog-service"

# Get events sorted by time (most useful first step)
kubectl get events -n $NS --sort-by='.lastTimestamp' | tail -30

# Get all pods and their status
kubectl get pods -n $NS -o wide

# Describe a failing pod (shows Events section at bottom)
kubectl describe pod <POD_NAME> -n $NS

# Get previous container logs (crashed run)
kubectl logs <POD_NAME> -n $NS --previous --tail=100

# Check resource usage
kubectl top pods -n $NS

# Check PVCs
kubectl get pvc -n $NS

# Check node capacity
kubectl describe nodes | grep -A5 "Allocated resources"

# Check node taints
kubectl describe nodes | grep -A2 "Taints"

# Check endpoints (service routing)
kubectl get endpoints -n $NS $APP
```
