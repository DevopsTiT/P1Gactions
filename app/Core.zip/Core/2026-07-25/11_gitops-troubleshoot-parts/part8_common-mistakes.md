# GitOps Troubleshooting — Part 8: Common Mistakes

> The 10 mistakes that cause the most incidents, wasted debugging time, and recurring failures in GitOps environments — with the exact symptom, root cause, and correct approach for each.

---

## Mistake Decision Tree — "Which mistake matches my problem?"

```
Something is broken. Which pattern does it match?

├─ I synced and something unexpected was deleted
│     → Mistake 1: Synced without reading the diff (prune wipe)

├─ I fixed something in the cluster; ArgoCD reverted it within minutes
│     → Mistake 2: Fixed directly in cluster instead of in Git

├─ I pushed a new Docker image; ArgoCD didn't deploy it
│     → Mistake 3: Using :latest tag

├─ Our Git repo had a secret in it (plaintext or base64)
│     → Mistake 4: Secret in Git

├─ Old Services/Deployments are accumulating from past deployments
│     → Mistake 5: PRUNE not enabled

├─ ArgoCD keeps resetting our HPA's replica count every sync
│     → Mistake 6: ignoreDifferences set but RespectIgnoreDifferences missing

├─ A Git push went straight to production without review
│     → Mistake 7: Auto-sync enabled on production Tier-1 service

├─ ArgoCD takes 3 minutes to pick up a Git push
│     → Mistake 8: Git webhook not configured

├─ An old failed hook Job causes every re-sync to fail
│     → Mistake 9: Failed hook Jobs left in namespace

└─ ArgoCD was deleted and child apps are orphaned
      → Mistake 10: App of Apps parent not in Git
```

---

## Mistake 1 — Syncing Without Reading the Diff

**Symptom:**
```
After a sync, a ConfigMap, Service, or Secret is missing from the cluster.
Application starts failing because a required config is gone.
The team looks at the diff view — there were red (deletion) lines they didn't see.
```

**Root cause:**
```
Prune was enabled (as it should be).
A resource that existed in the cluster was NOT present in Git.
On sync, ArgoCD deleted it as an orphan.

Common reasons the resource wasn't in Git:
  → It was created manually before GitOps was set up
  → It was created by a CI/CD pipeline that doesn't use ArgoCD
  → It was deleted from Git accidentally as part of a refactor
```

**Correct approach:**
```
Rule: always open the Diff view BEFORE clicking Sync.
      Read every highlighted line — not just the green (additions) but also
      the red (deletions) and yellow (changes).

Checklist before sync:
  ✅ Are all yellow lines the config change I intended?
  ✅ Are all green lines (additions) expected from this commit?
  ✅ Are there any red lines? Do I understand WHY each resource is being deleted?
  ⚠️ If there are unexpected red lines: stop; investigate before syncing.

In CI/CD pipelines:
  argocd app diff <APP> --exit-code
  # Exits non-zero if there are diffs → review before proceeding with sync
```

---

## Mistake 2 — Fixing Directly in the Cluster Instead of in Git

**Symptom:**
```
An engineer applies a hotfix directly: kubectl edit deployment catalog-service
The app recovers. 3 minutes later, ArgoCD reverts the fix. The incident repeats.
Cycle continues until someone realises ArgoCD is overwriting the fix.
```

**Root cause:**
```
Self-heal is enabled (as it should be in production).
When ArgoCD detects that the cluster drifted from Git,
it automatically syncs back to Git state — overwriting the manual fix.

Git is the source of truth.
The cluster is the destination, not the source.
```

**Correct approach:**
```
Rule: ALWAYS fix in Git first.

Correct incident workflow:
  1. Identify the fix needed (e.g. increase memory limit)
  2. Make the change in Git: update resources.limits.memory in the Deployment
  3. Open a PR (for production changes) OR push directly to the branch (for P1 emergencies)
  4. ArgoCD syncs the fix to the cluster automatically (self-heal or auto-sync)
  5. The fix persists — Git is updated, ArgoCD doesn't revert it

If you MUST make an immediate manual fix in a P1 emergency:
  1. Apply the fix in the cluster: kubectl edit deployment ...
  2. IMMEDIATELY create a PR to update Git to match
  3. Merge and sync within 10 minutes — before self-heal reverts it
  4. Never leave Git diverged from the cluster fix

Prevention:
  Use RBAC to block direct kubectl apply on production namespaces.
  Use OPA/Gatekeeper or Kyverno to enforce GitOps-only changes:
    "Only ArgoCD's ServiceAccount may create/update resources in namespace production."
```

---

## Mistake 3 — Using `:latest` Image Tag

**Symptom:**
```
A new Docker image was built and pushed to ECR as "catalog:latest".
ArgoCD is watching the repo. Git hasn't changed.
The new image is never deployed — the old container keeps running.
```

**Root cause:**
```
ArgoCD computes OutOfSync by comparing Git manifests to cluster state.
If the image tag in Git is "catalog:latest" and the cluster is also running
"catalog:latest", ArgoCD sees: no diff → no sync needed.

ArgoCD does NOT compare image digests by default.
It only compares what's in the YAML — and "latest" == "latest" always.
```

**Correct approach:**
```
Rule: never use :latest in Git manifests. Always use a specific, immutable tag.

Option A — Semantic version tag:
  image: catalog:2.3.1
  Push catalog:2.3.1 to ECR → update Git manifest → ArgoCD detects change → deploys.

Option B — Git SHA tag (most immutable):
  image: catalog@sha256:abc1234...
  Every commit produces a unique, immutable digest — no ambiguity.

Option C — ArgoCD Image Updater (automates tag bumping):
  argocd-image-updater watches ECR for new tags.
  When a new tag matching your pattern (semver, newest, etc.) appears:
  → It updates the Git manifest (or ArgoCD annotation) with the new tag
  → ArgoCD syncs automatically
  → No manual Git commit needed for image updates

  Configure:
  kubectl annotate application catalog-service \
    argocd-image-updater.argoproj.io/image-list="catalog=<account>.dkr.ecr.<region>.amazonaws.com/catalog" \
    argocd-image-updater.argoproj.io/catalog.update-strategy="semver" \
    argocd-image-updater.argoproj.io/catalog.tag-match="^[0-9]+\.[0-9]+\.[0-9]+$"
```

---

## Mistake 4 — Storing Secrets in Git (Plaintext or Base64)

**Symptom:**
```
Secret scanner (trufflehog / gitleaks) finds a credential in the repo.
OR: a teammate notices a passwords.yaml committed by mistake.
OR: the repo is leaked / made public accidentally.
```

**Root cause:**
```
Developers commit K8s Secret manifests to Git as part of the app setup.
They may know that base64 is "encoding" but treat it as safe.
Base64 is NOT encryption — one command decodes it:
  echo "c2VjcmV0" | base64 -d  →  secret

Even in private repos: repo leaks happen. CI/CD tokens with repo:read access
are frequently stolen. One leaked token = all secrets in all repos exposed.
```

**Correct approach:**
```
Use one of these patterns (see Part 6 for full detail):
  Sealed Secrets:       Encrypt with cluster key; store ciphertext in Git
  External Secrets Operator: Store reference in Git; fetch value from AWS Secrets Manager
  SOPS + KMS:           Encrypt YAML values with AWS KMS; store encrypted YAML
  IRSA + direct SDK:    No secret in Git at all; app fetches from Secrets Manager directly

Add to CI pipeline (prevent future accidents):
  gitleaks detect --source . --verbose
  trufflehog git .
  → Fail the pipeline if secrets are detected
  → Block the merge until the secret is removed from history
```

---

## Mistake 5 — PRUNE Not Enabled (Orphaned Resources Accumulate)

**Symptom:**
```
A Service or Deployment was removed from Git during a refactor.
After multiple syncs, the old resources are still running in the cluster.
Weeks later: a naming conflict occurs when a new app tries to create
a resource with the same name that the orphan already occupies.
```

**Root cause:**
```
PRUNE is set to false (or not set — defaults to false).
When ArgoCD syncs, it applies what is in Git but does NOT delete
resources that exist in the cluster but are gone from Git.
"orphaned" resources accumulate silently.
```

**Correct approach:**
```
Always enable PRUNE in the Application sync policy:
  spec:
    syncPolicy:
      automated:
        prune: true       ← enables deletion of resources removed from Git
        selfHeal: true

For manual sync: always add --prune flag:
  argocd app sync <APP> --prune

Before enabling prune on an existing app:
  1. Run argocd app diff <APP> to see what would be pruned
  2. Confirm all red (deleted) lines are genuinely orphaned
  3. Enable prune after confirming

Exception: some resources should NOT be pruned automatically:
  PVCs (persistent data) — accidental prune = data loss
  For these: add a resource-level annotation in Git:
    argocd.argoproj.io/managed-by-cluster-policy: "no-prune"
  OR: use resource hooks with specific delete policies
```

---

## Mistake 6 — ignoreDifferences Without RespectIgnoreDifferences

**Symptom:**
```
HPA scales the Deployment to 7 replicas during peak traffic.
ArgoCD syncs every few minutes and resets replicas back to 3 (from Git).
HPA scales back to 7. ArgoCD resets again. Infinite loop.
The app suffers from constant replica churn — pods restarting repeatedly.
```

**Root cause:**
```
ignoreDifferences was added to suppress the replicas diff in the UI.
But RespectIgnoreDifferences=true was NOT added to syncOptions.

ignoreDifferences: "don't SHOW me the replicas diff"
RespectIgnoreDifferences: "don't RESET replicas during sync"

Without the second part: ArgoCD still applies spec.replicas: 3 from Git
on every sync, fighting the HPA.
```

**Correct approach:**
```
Always add BOTH when managing HPA-controlled replicas:

  spec:
    ignoreDifferences:
      - group: apps
        kind: Deployment
        jsonPointers:
          - /spec/replicas

    syncPolicy:
      syncOptions:
        - RespectIgnoreDifferences=true   ← THE CRITICAL MISSING PIECE

Test after adding:
  1. HPA scales to 7
  2. Trigger a manual sync: argocd app sync <APP>
  3. Verify: kubectl get deployment <NAME> -n <NS> -o jsonpath='{.spec.replicas}'
  4. Expected: still 7 (ArgoCD did not reset it)
```

---

## Mistake 7 — Auto-Sync Enabled on Production Tier-1 Services

**Symptom:**
```
A developer pushes a change to the main branch to fix a bug.
ArgoCD immediately deploys it to production — no human review.
The change has a typo in a config value → production is down.
```

**Root cause:**
```
Auto-sync with selfHeal=true means every Git push to the tracked branch
immediately deploys to production.
There is no "are you sure?" step.
```

**Correct approach:**
```
Tiered sync policy by environment:

  Development / Feature branches:
    syncPolicy.automated: true, selfHeal: true, prune: true
    → Auto-sync fine; fast iteration; mistakes are low-impact

  Staging:
    syncPolicy.automated: true, selfHeal: true, prune: true
    → Auto-sync fine; required for automated test pipelines

  Production Tier-2 (non-critical services):
    syncPolicy.automated: true
    Add sync window: deny window during business hours
    → Deploys happen only during low-traffic hours

  Production Tier-1 (critical revenue path: payments, auth, checkout):
    syncPolicy: null   ← NO auto-sync
    Require: human reviews the diff in ArgoCD UI, clicks Sync
    Require: sync only after a PR is merged with 2+ approvals in Git

  Implementation (Tier-1 no auto-sync):
    argocd app set <APP> --sync-policy none
    → ArgoCD detects OutOfSync but does NOT apply automatically
    → A human must manually trigger the sync
```

---

## Mistake 8 — Git Webhook Not Configured

**Symptom:**
```
A developer pushes a commit and waits for the deploy.
ArgoCD picks it up after 3 minutes (sometimes up to 5 minutes).
Incident resolution is slow — fix is in Git but not in cluster.
```

**Root cause:**
```
ArgoCD polls Git every 3 minutes by default.
Without a webhook, ArgoCD never knows a push happened immediately.
The 3-minute lag is the poll interval.
```

**Correct approach:**
```
Register a webhook in GitHub → ArgoCD:
  1. GitHub: repo Settings → Webhooks → Add webhook
     Payload URL:  https://argocd.internal/api/webhook
     Content type: application/json
     Secret:       <shared secret>
     Events:       Just the push event

  2. In ArgoCD: the secret must match what's stored in argocd-secret:
     kubectl get secret argocd-secret -n argocd \
       -o jsonpath='{.data.webhook\.github\.secret}' | base64 -d
     # This must match the secret you set in GitHub

  3. Test: push a commit → ArgoCD should pick it up within 5 seconds

Result with webhook:
  Git push → GitHub sends webhook → ArgoCD receives → refreshes immediately
  Lag: 2-5 seconds (network + processing)

Without webhook:
  Git push → ArgoCD polls on its own schedule → lag: 0-3 minutes
```

---

## Mistake 9 — Failed Hook Jobs Left in the Namespace

**Symptom:**
```
A sync hook (db-migrate Job) failed during the last deployment.
The team fixed the migration script and pushed to Git.
On the next sync: the same error appears — "job already exists" or
"cannot create job db-migrate: already exists".
The new Job can never be created because the old failed Job is still there.
```

**Root cause:**
```
By default, ArgoCD does not delete failed hook Jobs.
This is by design: you need to see the failure logs.
But if you don't clean up the failed Job manually, the next sync fails
because Kubernetes rejects creating a Job with the same name.
```

**Correct approach:**
```
Set hook deletion policy on ALL hook Jobs in Git:

  metadata:
    annotations:
      argocd.argoproj.io/hook: PreSync
      argocd.argoproj.io/hook-delete-policy: BeforeHookCreation

  BeforeHookCreation:
    → Deletes the old Job (if it exists) BEFORE creating the new one
    → Even if the old run failed, the namespace is clean for the new sync
    → You lose the logs from the old failed run — read them before re-syncing

  Other options:
    HookSucceeded:    Delete after successful completion (keep failures visible)
    HookFailed:       Delete after failure (auto-clean; lose logs)
    BeforeHookCreation: Delete before next run (recommended for most cases)

  Manual cleanup before re-syncing:
    kubectl delete job db-migrate -n catalog-ns
    argocd app sync <APP>
```

---

## Mistake 10 — App of Apps Parent Not in Git

**Symptom:**
```
The management team deletes the parent ArgoCD Application ("app of apps")
thinking it only deletes the ArgoCD record, not the deployed resources.
The parent is gone. All child Applications it generated are now orphaned:
  → ArgoCD no longer tracks them
  → They still run in the cluster
  → No auto-sync; no health monitoring; no managed lifecycle

OR: the team rebuilds the management cluster after a disaster.
ArgoCD is reinstalled. The parent Application was never in Git.
All child apps must be manually recreated.
```

**Root cause:**
```
The root Application manifest (the one that generates child apps via App of Apps)
was created via the ArgoCD UI or CLI — not committed to Git.
If ArgoCD is wiped, the root is gone.
```

**Correct approach:**
```
Rule: the root Application manifest MUST be stored in Git.
      Everything ArgoCD manages should itself be managed by Git.

Bootstrap sequence (GitOps-correct):
  1. Install ArgoCD on the management cluster (via Helm from Git)
  2. Apply the root Application ONE TIME manually:
     kubectl apply -f bootstrap/root-app.yaml -n argocd
  3. The root Application syncs itself and all child apps from Git
  4. From this point: all changes (new apps, deleted apps) go through Git

root-app.yaml (store in Git at: bootstrap/root-app.yaml):
  apiVersion: argoproj.io/v1alpha1
  kind: Application
  metadata:
    name: root-app
    namespace: argocd
    finalizers:
      - resources-finalizer.argocd.argoproj.io
  spec:
    project: default
    source:
      repoURL: https://github.com/company/k8s-manifests
      targetRevision: HEAD
      path: apps/         ← directory containing all child Application manifests
    destination:
      server: https://kubernetes.default.svc
      namespace: argocd
    syncPolicy:
      automated:
        prune: true
        selfHeal: true

Disaster recovery test:
  Quarterly: wipe ArgoCD (delete namespace) → reinstall → apply root-app.yaml
  → Verify all child apps come back within 5 minutes
  → This tests that Git truly contains all Application manifests
```

---

## Summary Table

| # | Mistake | Symptom | Fix |
|---|---|---|---|
| 1 | Sync without reading diff | Resource unexpectedly deleted (prune) | Always check diff; look for red deletion lines |
| 2 | Fix directly in cluster | ArgoCD reverts fix in 3 minutes | Fix in Git first; PR → merge → auto-sync |
| 3 | `:latest` image tag | New image never deploys | Pin to SHA or semantic version; use Image Updater |
| 4 | Secrets in Git | Credential exposure on repo leak | Sealed Secrets / ESO / SOPS / IRSA |
| 5 | PRUNE disabled | Orphaned resources accumulate; future conflicts | Enable `prune: true` in syncPolicy |
| 6 | ignoreDifferences without RespectIgnoreDifferences | HPA fight; replicas reset every sync | Add `RespectIgnoreDifferences=true` to syncOptions |
| 7 | Auto-sync on Tier-1 production | Every push deploys without review | Disable auto-sync on Tier-1; require manual sync |
| 8 | No Git webhook | 3-minute deploy lag | Register webhook: GitHub → ArgoCD API endpoint |
| 9 | Failed hook Jobs not cleaned | Next sync fails: Job already exists | Set `hook-delete-policy: BeforeHookCreation` |
| 10 | App of Apps parent not in Git | Disaster recovery fails; orphaned apps | Commit root Application manifest to Git |
