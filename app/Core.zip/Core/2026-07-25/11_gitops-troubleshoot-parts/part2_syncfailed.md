# GitOps Troubleshooting — Part 2: SyncFailed

> **The principle:** SyncFailed means ArgoCD tried to apply the manifests from Git to the cluster and Kubernetes rejected them. The manifests were never applied — nothing changed in the cluster. This is distinct from Degraded (manifests applied, app is unhealthy).

---

## SyncFailed vs OutOfSync vs Degraded

```
OutOfSync:    Git and cluster differ — ArgoCD has NOT tried to fix it yet
SyncFailed:   ArgoCD tried to apply Git → cluster rejected the apply
Degraded:     ArgoCD successfully applied Git → but the app is unhealthy

SyncFailed always has an error message.
Read the "Message" field in argocd app get before doing anything else.
```

---

## How to Read the SyncFailed Error

```bash
# This is the first command to run on any SyncFailed app
argocd app get <APP_NAME>

# Look for:
# SYNC STATUS:   SyncFailed
# Message:       <the exact Kubernetes error message>

# The message tells you exactly which resource failed and why.
# Example messages:
#   "namespaces 'catalog-ns' not found"
#   "deployments.apps 'catalog' already exists"
#   "spec.selector: field is immutable"
#   "system:serviceaccount:argocd:argocd-application-controller cannot create deployments"
#   "hook 'db-migrate' failed: exit code 1"
```

---

## Error 1 — "namespace not found"

**Full error:** `namespaces 'catalog-ns' not found`

```
Cause:
  The destination namespace in the Application spec does not exist in the cluster.
  ArgoCD tries to create resources in that namespace before it exists.

Fix Option A — AUTO-CREATE NAMESPACE (fastest; less control):
  Add to the Application spec in Git:

    spec:
      syncPolicy:
        syncOptions:
          - CreateNamespace=true

  → ArgoCD creates the namespace automatically before applying resources
  → Namespace has no resource quotas or labels unless you also add a Namespace manifest

Fix Option B — Create the namespace manually first:

  kubectl create namespace catalog-ns
  → Then re-sync the app

Fix Option C — Add a Namespace manifest to Git (recommended for production):
  Create namespace.yaml in the app's Git path:

    apiVersion: v1
    kind: Namespace
    metadata:
      name: catalog-ns
      labels:
        team: catalog
        env: production

  Commit and push → ArgoCD creates the namespace as part of the normal sync.
  This approach gives you full control: resource quotas, labels, and annotations
  are all defined in Git.

When to use which:
  Dev / staging → Option A (CreateNamespace=true) is fine
  Production    → Option C (Namespace in Git) enforces governance
```

---

## Error 2 — "resource already exists" (409 Conflict)

**Full error:** `deployments.apps "catalog-service" already exists` or `resource already exists and is not managed by ArgoCD`

```
Cause:
  A resource with the same name already exists in the cluster,
  but it was NOT created by ArgoCD (no argocd.argoproj.io/app annotation).
  ArgoCD refuses to overwrite resources it doesn't own.

This happens when:
  → Someone ran kubectl apply manually before ArgoCD was set up
  → A Helm release was deployed first, then converted to ArgoCD
  → A CI/CD pipeline and ArgoCD are both managing the same app

Fix Option A — Adopt the resource (give ArgoCD ownership):
  Tell ArgoCD to take ownership of the existing resource:

  kubectl annotate deployment catalog-service -n catalog-ns \
    argocd.argoproj.io/managed-by=argocd \
    app.kubernetes.io/instance=<ARGOCD_APP_NAME>

  → ArgoCD now treats this resource as part of the app
  → On next sync: ArgoCD updates it to match Git state

Fix Option B — Delete and let ArgoCD recreate:
  kubectl delete deployment catalog-service -n catalog-ns
  → Then sync → ArgoCD creates it fresh with correct annotations

  WARNING: causes pod downtime.
  Use during a scheduled maintenance window.
  For stateless apps with multiple replicas: drain the old deployment
  gracefully before deleting.

Fix Option C — Use Server-Side Apply (prevents most future conflicts):
  Add to the Application spec:

  spec:
    syncPolicy:
      syncOptions:
        - ServerSideApply=true

  → Kubernetes merges fields server-side instead of replacing the whole object
  → More conflict-tolerant; recommended for all new ArgoCD applications
  → Note: not compatible with all resource types (test before enabling in prod)

Decision matrix:
  One-off resource from before ArgoCD was set up → Option A (annotate)
  Resource that a pipeline also manages           → Fix the pipeline; remove it
  New app setup going forward                     → Option C (ServerSideApply)
```

---

## Error 3 — "field is immutable" (Immutable Field Change)

**Full error:** `spec.selector: field is immutable` or `invalid: spec.template: field is immutable`

```
Cause:
  You changed a field in Git that Kubernetes does not allow changing
  on a resource that already exists. Kubernetes rejects the update entirely.

Commonly immutable fields:
  Resource          Immutable fields
  ──────────────────────────────────────────────────────────────────────
  Deployment        spec.selector (the pod label selector)
  StatefulSet       spec.selector, spec.serviceName
  Job               spec.selector, spec.template
  PVC               spec.storageClassName, spec.accessModes, spec.volumeName
  Service           spec.clusterIP (when changing type from ClusterIP)

Example scenario:
  You added a new label to the pod template AND the selector in Git:
    selector.matchLabels:
      app: catalog
      version: v2    ← new label added

  Kubernetes rejects this because spec.selector was set at creation time
  and cannot be changed without recreating the resource.

Fix (standard path):
  Step 1: Delete the immutable resource from the cluster:
    kubectl delete deployment catalog-service -n catalog-ns

  Step 2: Sync the app — ArgoCD recreates the resource with the new spec:
    argocd app sync <APP_NAME>

  WARNING for Deployments:
    Deleting a Deployment terminates all pods in it immediately.
    This causes downtime unless you have a load balancer routing to another Deployment.

Zero-downtime path:
  1. Create a new Deployment with a different name in Git: catalog-service-v2
  2. Sync → ArgoCD creates catalog-service-v2 alongside catalog-service
  3. Shift traffic: update the Service selector to match catalog-service-v2
  4. Sync again → Service selector updated; traffic shifts to new Deployment
  5. Delete catalog-service from Git → sync with prune → ArgoCD removes old Deployment

Prevention:
  → Never change spec.selector on a live Deployment
  → Use different Deployment names (blue/green) if the selector must change
  → Set immutable fields once at creation time; do not modify them in Git
```

---

## Error 4 — "permission denied" (RBAC)

**Full error:** `system:serviceaccount:argocd:argocd-application-controller cannot create resource 'deployments' in namespace 'catalog-ns': forbidden`

```
Cause:
  ArgoCD's service account (argocd-application-controller) lacks permission
  to create, update, or delete this resource type in this namespace (or cluster-wide).

  This happens when:
  → ArgoCD was installed with a restricted ClusterRole (not cluster-admin)
  → A new resource type (CRD, ClusterRole, Namespace) was added to the app
    that the ArgoCD ClusterRole doesn't include
  → AppProject has an empty cluster resource allow list

Diagnosis:
  # Test whether ArgoCD's service account can perform the action
  kubectl auth can-i create deployment \
    --as=system:serviceaccount:argocd:argocd-application-controller \
    -n catalog-ns
  # Expected: yes
  # If "no": permission is missing

  # Show ArgoCD's current ClusterRole
  kubectl describe clusterrole argocd-application-controller

Fix Option A — Extend the ArgoCD ClusterRole:
  kubectl edit clusterrole argocd-application-controller
  → Add the missing resource type:

  - apiGroups: ["apps"]
    resources: ["deployments"]
    verbs: ["get","list","watch","create","update","patch","delete"]

  → Or add a wildcard for all resource types if ClusterRole scope allows:
  - apiGroups: ["*"]
    resources: ["*"]
    verbs: ["*"]
  (Only use wildcard if ArgoCD manages cluster-admin-level resources)

Fix Option B — Add a RoleBinding in the specific namespace:
  If you prefer namespace-scoped permissions (more restrictive):

  kubectl create rolebinding argocd-catalog-deploy \
    --clusterrole=argocd-application-controller \
    --serviceaccount=argocd:argocd-application-controller \
    --namespace=catalog-ns

Fix Option C — Update AppProject's cluster resource allow list:
  In the ArgoCD UI: Settings → Projects → [project name]
  → Cluster Resource Allow List → add the blocked resource group and kind

  OR via CLI:
  argocd proj allow-cluster-resource <PROJECT> \
    "rbac.authorization.k8s.io" "ClusterRole"

Root cause check:
  # Was ArgoCD installed with a custom restricted ServiceAccount?
  kubectl get clusterrolebinding \
    -l app.kubernetes.io/name=argocd \
    -o wide
```

---

## Error 5 — "hook failed"

**Full error:** `one or more sync tasks are not valid` or hook Job shows 🔴 Failed in resource tree

```
Cause:
  A sync hook (a Kubernetes Job annotated as a pre-sync, sync, or post-sync hook)
  failed to complete successfully. ArgoCD marks the sync as Failed
  because the hook is part of the sync lifecycle.

Hook types:
  PreSync:     runs BEFORE any manifests are applied
               (use for: database migration check, readiness gate)
  Sync:        runs DURING the sync alongside resource application
  PostSync:    runs AFTER all resources are applied and healthy
               (use for: smoke test, cache warm-up, notification)
  SyncFail:    runs ONLY WHEN the sync fails
               (use for: cleanup, alerting, rollback trigger)

Investigation:
  Step 1: Find the failed hook Job in the resource tree
    → In UI: App detail view → resource tree → look for a Job with 🔴 icon
    → In CLI: kubectl get jobs -n <namespace> -l argocd.argoproj.io/hook=PreSync

  Step 2: Read the hook's logs
    POD=$(kubectl get pods -n <namespace> \
      -l job-name=<hook-job-name> \
      -o jsonpath='{.items[0].metadata.name}')
    kubectl logs $POD -n <namespace>

  Common hook failure causes:
    → Database migration script failed (SQL error, schema conflict)
    → Smoke test endpoint returned non-200
    → Network unreachable (hook ran before DNS was ready)
    → Missing secret referenced in the hook Job's env
    → Timeout (hook took longer than backoffLimit allows)

Fix:
  1. Read the logs → understand the root cause
  2. Fix the hook script or resource it depends on (in Git)
  3. Clean up the failed Job:
     kubectl delete job <hook-job-name> -n <namespace>
     (ArgoCD won't re-run a hook if the Job still exists from the failed run)
  4. Re-sync

Best practice — Hook deletion policy:
  Set this annotation on the hook Job in Git:
    argocd.argoproj.io/hook-delete-policy: HookSucceeded
  → ArgoCD deletes the Job automatically after a successful run
  → A failed Job is KEPT (so you can read its logs)
  → Use BeforeHookCreation to delete any previous run before the next sync
```

---

## Error 6 — "repo not found" / "authentication failed"

**Full error:** `repository not found` or `authentication required` or `failed to fetch`

```
Cause:
  ArgoCD cannot clone or access the Git repository.
  Credentials expired, rotated, or were never configured.

Diagnosis:
  argocd repo list
  # Look for: STATUS = Failed  MESSAGE = authentication failed

  argocd repo get https://github.com/company/k8s-manifests
  # Shows the specific connection error

Common causes:
  GitHub PAT expired:
    GitHub PATs have configurable expiry (30/60/90 days or no expiry)
    Fix: generate a new PAT → argocd repo add <url> --username git \
           --password <NEW_PAT> --upsert

  SSH deploy key revoked or rotated:
    Fix: generate a new SSH key → add to GitHub repo as deploy key
         → argocd repo add git@github.com:company/repo \
             --ssh-private-key-path ~/.ssh/new_key --upsert

  Repo moved or renamed:
    Fix: update the repo URL in the ArgoCD Application spec in Git
         → argocd repo rm <old-url>
         → argocd repo add <new-url> --username git --password <PAT>
         → Update spec.source.repoURL in Application manifest

  Network policy blocking repo-server → GitHub:
    Fix: check NetworkPolicy in argocd namespace
         Ensure repo-server can reach github.com:443
         kubectl exec -n argocd deploy/argocd-repo-server -- \
           curl -s https://github.com
```

---

## Sync Commands Reference

```bash
APP_NAME="catalog-service"

# Manual sync
argocd app sync $APP_NAME

# Sync with prune (removes deleted resources)
argocd app sync $APP_NAME --prune

# Force sync (overwrites resources not owned by ArgoCD)
argocd app sync $APP_NAME --force

# Dry run (preview — no apply)
argocd app sync $APP_NAME --dry-run

# Sync to a specific Git SHA
argocd app sync $APP_NAME --revision abc1234

# Terminate a stuck in-progress sync
argocd app terminate-op $APP_NAME

# Re-sync after fixing a failed hook
kubectl delete job db-migrate -n catalog-ns
argocd app sync $APP_NAME
```
