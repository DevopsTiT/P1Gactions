# Terraform Best Practices — Commands Reference

## Phase 0: Orient — Check Environment and State

```bash
# ── Terraform version and provider info ──

# Show installed Terraform version
terraform version

# List all providers and their versions in the current workspace
terraform providers

# Show current workspace
terraform workspace show

# List all workspaces (if using workspaces)
terraform workspace list

# ── State inspection ──

# List all resources tracked in state
terraform state list

# List resources matching a filter
terraform state list 'aws_db_instance.*'
terraform state list 'module.rds.*'

# Show the full state of a specific resource
terraform state show aws_db_instance.main

# Show the full state output (human-readable)
terraform show

# Check for a DynamoDB lock (stuck apply blocks everyone)
aws dynamodb scan --table-name terraform-state-lock \
  --query 'Items[*].[LockID.S,Info.S]' \
  --output table

# Check state bucket versioning is enabled
STATE_BUCKET="company-terraform-state"
aws s3api get-bucket-versioning --bucket "$STATE_BUCKET" \
  --query 'Status' --output text
# Expected: Enabled

# List all state file versions (for rollback visibility)
aws s3api list-object-versions \
  --bucket "$STATE_BUCKET" \
  --prefix "prod/payment-service/terraform.tfstate" \
  --query 'Versions[*].[VersionId,LastModified,Size]' \
  --output table | head -20
```

## Phase 1: Local Development Workflow

```bash
# ── Before every commit ──

# 1. Format all .tf files (modifies files in place)
terraform fmt -recursive

# 2. Check format without modifying (for CI)
terraform fmt -check -recursive

# 3. Validate syntax and internal consistency
terraform init -backend=false   # init without connecting to state (fast; for validation)
terraform validate

# 4. Run tflint (catches provider-specific issues fmt/validate miss)
tflint --init    # first time only
tflint --recursive

# 5. Run tfsec (security checks)
tfsec .
# OR: checkov
checkov -d .

# ── Plan workflow ──

# Navigate to the environment directory you are changing
cd environments/prod/payment-service

# Initialize (downloads providers; connects to remote state)
terraform init

# Plan with output saved to a file (apply this file to prevent plan drift)
terraform plan -out=tfplan.binary

# Show the saved plan (human-readable)
terraform show tfplan.binary

# Apply ONLY the saved plan (not a fresh plan — prevents surprises)
terraform apply tfplan.binary
```

## Phase 2: Targeted Operations

```bash
NAMESPACE="payment"
ENV="prod"

# ── Target a specific resource (careful — use sparingly) ──

# Plan only one resource (useful when one resource needs fixing)
terraform plan -target=aws_db_instance.main

# Apply only one resource
terraform apply -target=aws_db_instance.main

# WARNING: -target bypasses dependency checking
# After a targeted apply, ALWAYS run a full terraform plan to check for inconsistencies

# ── Refresh state from real AWS (re-reads actual resource values) ──
terraform refresh
# Equivalent to: terraform apply -refresh-only
# Use when: AWS changed a value outside Terraform (security group rule auto-added, etc.)
# After refresh: run plan to see if state now matches code

# ── Refresh-only (dry run of refresh — shows what would change in state) ──
terraform plan -refresh-only
```

## Phase 3: State Operations

```bash
# ── Move a resource to a different state address (rename without recreate) ──

# Before renaming a resource in code, move it in state:
# Old code: resource "aws_instance" "web"
# New code: resource "aws_instance" "application_server"
terraform state mv aws_instance.web aws_instance.application_server
# Now rename in the .tf file → plan shows 0 changes (no recreate)

# Move a resource into a module:
# Old: resource "aws_db_instance" "main"
# New: module "rds" → resource "aws_db_instance" "this"
terraform state mv aws_db_instance.main module.rds.aws_db_instance.this

# ── Remove a resource from state without deleting it ──

# Remove tracking without destroying the real resource
# Use when: you want Terraform to stop managing something but not delete it
terraform state rm aws_instance.legacy_server
# The EC2 instance still exists; Terraform just forgets it

# ── Pull the remote state to a local file (for inspection) ──
terraform state pull > /tmp/current-state.json
# Review: cat /tmp/current-state.json | python3 -m json.tool | head -100

# ── Push a local state to remote (DANGEROUS — overwrites remote state) ──
# Only use after restoring from a backup
# terraform state push /tmp/restored-state.json
# DO NOT run this casually

# ── Release a stuck DynamoDB lock ──
LOCK_ID=$(aws dynamodb scan --table-name terraform-state-lock \
  --query 'Items[0].LockID.S' --output text)
echo "Lock ID: $LOCK_ID"

# Only release if the apply process is confirmed dead (not just slow)
# Verify: is there an active CI/CD job running? If YES: wait for it
# If NO: release the lock
aws dynamodb delete-item \
  --table-name terraform-state-lock \
  --key "{\"LockID\":{\"S\":\"$LOCK_ID\"}}"
```

## Phase 4: Import Existing Resources

```bash
# ── Import a manually created resource into Terraform state ──

# Example 1: import an EC2 instance
# First: write the resource block in your .tf file
# Then:
INSTANCE_ID="i-0123456789abcdef"
terraform import aws_instance.web_server "$INSTANCE_ID"

# Example 2: import an S3 bucket
terraform import aws_s3_bucket.data company-payment-data

# Example 3: import an RDS instance
terraform import aws_db_instance.main prod-payments-rds

# Example 4: import a security group rule
# Format: security_group_id_type_protocol_from_port-to_port_source
terraform import aws_security_group_rule.allow_http "sg-12345678_ingress_tcp_80_80_0.0.0.0/0"

# After every import: check the plan to see if your .tf code matches
terraform plan
# Adjust your .tf code until plan shows no undesired changes

# Terraform 1.5+ import block (in .tf file, no CLI needed)
# Add to main.tf:
# import {
#   to = aws_instance.web_server
#   id = "i-0123456789abcdef"
# }
# Then run: terraform plan (import happens as part of plan)
# Then run: terraform apply to persist it

# Terraform 1.6+ generate config for an imported resource
terraform plan -generate-config-out=generated.tf
# Review and clean up generated.tf before committing
```

## Phase 5: Drift Detection

```bash
# ── Detect drift between Terraform state and real AWS ──

# Run plan and check exit code (use in CI/CD scheduled jobs)
terraform plan -detailed-exitcode
# Exit 0: no changes
# Exit 1: error
# Exit 2: changes present (drift detected)
echo "Plan exit code: $?"

# Drift detection CI script
terraform plan -detailed-exitcode -out=/dev/null 2>&1
EXIT_CODE=$?
if [ "$EXIT_CODE" -eq 2 ]; then
  echo "DRIFT DETECTED: Terraform plan shows changes"
  echo "Review and apply, or update the .tf code to match current state"
  exit 1
elif [ "$EXIT_CODE" -eq 1 ]; then
  echo "PLAN ERROR: Check Terraform configuration"
  exit 1
else
  echo "No drift detected"
fi

# Find AWS resources NOT tagged with managed-by=terraform (may be untracked)
aws resourcegroupstaggingapi get-resources \
  --tag-filters 'Key=managed-by,Values=[]' \
  --resource-type-filters ec2:instance rds:db \
  --query 'ResourceTagMappingList[*].ResourceARN' \
  --output text \
  | tr '\t' '\n' \
  | head -20
# These resources lack managed-by:terraform tag → investigate if they should be imported
```

## Phase 6: Security and Compliance Checks

```bash
# ── tfsec: security scanning ──

# Scan current directory
tfsec .

# Scan with specific severity threshold (only show HIGH and CRITICAL)
tfsec . --minimum-severity HIGH

# Output as JSON (for CI integration)
tfsec . --format json --out tfsec-results.json

# ── checkov: compliance scanning ──

# Scan for misconfigurations
checkov -d .

# Scan specific file
checkov -f main.tf

# Check only specific rules (e.g., CKV_AWS_* for AWS checks)
checkov -d . --check CKV_AWS_17,CKV_AWS_23

# ── Sensitive value check: ensure no secrets in plan output ──

# Show plan without sensitive values (sensitive = true variables are redacted)
terraform plan -no-color 2>&1 | grep -v "sensitive"

# Confirm .gitignore is protecting sensitive files
cat .gitignore | grep -E "tfstate|tfvars|.terraform/"
# Expected lines:
# *.tfstate
# *.tfstate.backup
# .terraform/
# *.tfplan
# terraform.tfvars  (if it contains sensitive local overrides)
```

## Phase 7: Monthly Maintenance Script

```bash
#!/usr/bin/env bash
set -euo pipefail

# Monthly Terraform maintenance checks
# Run: first Monday of each month
# Requires: terraform, aws CLI, tflint, tfsec

TODAY=$(date +%Y-%m-%d)
STATE_BUCKET="company-terraform-state"
REGION="ap-northeast-1"

echo "════════════════════════════════════════════════════════"
echo "Monthly Terraform Maintenance — ${TODAY}"
echo "════════════════════════════════════════════════════════"

echo ""
echo "── 1. TERRAFORM VERSION ──"
terraform version

echo ""
echo "── 2. STATE BUCKET HEALTH ──"
# Versioning enabled?
VERSIONING=$(aws s3api get-bucket-versioning \
  --bucket "$STATE_BUCKET" \
  --query 'Status' --output text 2>/dev/null || echo "ERROR")
echo "  S3 versioning: $VERSIONING"

# Encryption enabled?
ENCRYPTION=$(aws s3api get-bucket-encryption \
  --bucket "$STATE_BUCKET" \
  --query 'ServerSideEncryptionConfiguration.Rules[0].ApplyServerSideEncryptionByDefault.SSEAlgorithm' \
  --output text 2>/dev/null || echo "NOT CONFIGURED")
echo "  S3 encryption: $ENCRYPTION"

# Public access blocked?
PUBLIC=$(aws s3api get-public-access-block \
  --bucket "$STATE_BUCKET" \
  --query 'PublicAccessBlockConfiguration.BlockPublicAcls' \
  --output text 2>/dev/null || echo "NOT CONFIGURED")
echo "  Block public access: $PUBLIC"

echo ""
echo "── 3. STATE LOCK TABLE HEALTH ──"
aws dynamodb describe-table \
  --table-name terraform-state-lock \
  --region "$REGION" \
  --query 'Table.{Status:TableStatus,ItemCount:ItemCount}' \
  --output table 2>/dev/null || echo "  Lock table not found or no access"

echo ""
echo "── 4. ACTIVE LOCKS (should be empty outside of apply runs) ──"
aws dynamodb scan \
  --table-name terraform-state-lock \
  --region "$REGION" \
  --query 'Items[*].[LockID.S]' \
  --output text 2>/dev/null | head -10 || echo "  No active locks"

echo ""
echo "── 5. STATE FILE INVENTORY ──"
aws s3 ls "s3://$STATE_BUCKET/" --recursive \
  | grep "terraform.tfstate$" \
  | awk '{print "  " $4}' \
  | sort

echo ""
echo "── 6. FORMAT CHECK (all environments) ──"
for env_dir in environments/*/; do
  cd "$env_dir" 2>/dev/null || continue
  if terraform fmt -check -recursive -list=false 2>/dev/null; then
    echo "  $env_dir: formatted ✓"
  else
    echo "  $env_dir: FORMAT ISSUES FOUND — run terraform fmt -recursive"
  fi
  cd - > /dev/null
done

echo ""
echo "════════════════════════════════════════════════════════"
echo "Checklist:"
echo "  □ Run tfsec on any modules changed this month"
echo "  □ Review provider versions in versions.tf — any minor updates available?"
echo "  □ Check for resources in AWS with no managed-by:terraform tag"
echo "  □ Verify all state files have a corresponding directory in environments/"
echo "════════════════════════════════════════════════════════"
```
