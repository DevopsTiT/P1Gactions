# Terraform Best Practices — Logic, Flow & Reference

---

## E2E Flow Summary

```
1. ALWAYS-ON FOUNDATIONS
   → Remote state backend (S3 + DynamoDB) with encryption and locking
   → State is never stored locally or in Git
   → One workspace or one state file per environment (dev/staging/prod)
   → All providers and modules pinned to exact versions
   → Pre-commit hooks: fmt, validate, tflint, tfsec run on every commit

2. DAILY (team workflow)
   → Every change goes through PR: plan output is posted as a comment
   → No one runs terraform apply manually from their laptop in production
   → CI/CD pipeline (GitHub Actions / Atlantis) is the only apply path
   → Drift detection: scheduled plan runs compare state to real infra

3. WHEN MAKING A CHANGE
   → Write code → run fmt + validate + plan locally
   → Open PR → CI posts plan output → team reviews the plan (not just the code)
   → Merge → CI applies automatically (or requires manual approval for prod)
   → Verify: check the resource in AWS console / kubectl / argocd

4. MONTHLY REVIEW
   → Audit: any resources in AWS not tracked by Terraform state?
   → Unused variables, outputs, and modules → clean up
   → Provider and module version upgrades (check changelogs for breaking changes)
   → Cost review: Terraform-managed vs total AWS spend (untracked = manual = risk)

5. QUARTERLY CYCLE
   → Terraform version upgrade (test in dev first; then staging; then prod)
   → Module catalog review: any duplicated logic that should become a shared module?
   → State file health check: any dangling resources, tainted resources, deposed instances?
   → RBAC review: who has terraform apply access in CI? Who can push to the Terraform repo?

6. ROLLBACK / INCIDENT
   → Bad apply: revert the Git commit → CI applies the previous state
   → Resource needs emergency manual fix: fix in console → import into Terraform → update code
   → State corruption: restore from S3 versioned backup → investigate what diverged
   → Never use terraform destroy unless explicitly decommissioning; prefer targeted removals
```

---

## Decision Tree

```
"How should I structure this Terraform change?"
│
├─ Is this a new resource or a change to existing?
│   ├─ NEW resource → write in the correct module or root → plan → PR
│   └─ CHANGE to existing → check if the change is destructive (forces replacement)
│       ├─ Destructive (recreate) → plan carefully; schedule maintenance window
│       └─ Non-destructive (in-place update) → standard PR flow
│
├─ Should this be a module or root-level code?
│   ├─ Used in more than one environment/team → module
│   ├─ Specific to one app/environment → root-level
│   └─ Third-party best practice exists → use a maintained community module
│
├─ Which environment does this touch?
│   ├─ dev     → apply can be automated on merge; low risk
│   ├─ staging → automated apply after plan review
│   └─ prod    → manual approval gate before apply; plan must be reviewed by ≥2 people
│
├─ Does this change touch the state backend or provider config?
│   → Extra caution: wrong change here locks out the whole team
│   → Test in dev; never change backend config and resource config in the same PR
│
├─ Is a resource drifting (plan shows unexpected changes)?
│   ├─ Resource was manually modified in console → update Terraform code to match OR
│   │   import the change → codify → never leave drift unresolved
│   └─ Provider updated and field interpretation changed → pin provider version until tested
│
└─ Need to remove a resource from Terraform management (not delete it)?
    → terraform state rm <resource.address>
    → Does NOT delete the real resource; only removes it from state tracking
```

---

## Tool Map

| Tool | What It Does | When to Use | Cadence |
|---|---|---|---|
| `terraform fmt` | Auto-formats all .tf files to canonical style | Before every commit | Every change |
| `terraform validate` | Checks syntax and internal consistency | Before plan | Every change |
| `terraform plan` | Shows what WILL change before applying | Before every apply | Every change |
| `terraform apply` | Applies the plan to real infrastructure | After plan review | Via CI only (prod) |
| `terraform state` | Inspect, move, import, remove state entries | Refactoring; drift fix; import | On demand |
| `terraform import` | Brings an existing resource under Terraform management | When manual resource needs tracking | On demand |
| `tflint` | Lints Terraform code for common mistakes and best practices | Pre-commit / CI | Every PR |
| `tfsec` / `checkov` | Security scanning of Terraform code (open S3 buckets, missing encryption) | Pre-commit / CI | Every PR |
| `terraform-docs` | Auto-generates module documentation from variables/outputs | Module publishing | On module change |
| Atlantis | Self-hosted PR automation: plan on PR open, apply on merge | CI/CD for Terraform | Always-on |
| `terraform workspace` | Manages multiple state files per repo (dev/staging/prod) | Multi-env management | Setup |
| `terragrunt` | DRY wrapper for Terraform: eliminates duplicated backend configs | Large multi-account orgs | Setup |

---

## Part 1 — State Management: The Foundation

**Without proper state management:** Two engineers run `terraform apply` simultaneously and corrupt the state file. A local state file gets deleted and 200 resources become untracked. Someone commits the state file to Git containing plaintext RDS passwords.

**With proper state management:** State is remote, encrypted, versioned, and locked. Two simultaneous applies are blocked. State is never in Git.

### Remote Backend: S3 + DynamoDB

```hcl
# backend.tf — the FIRST file to configure in any Terraform project
terraform {
  backend "s3" {
    bucket         = "company-terraform-state"          # versioning enabled on this bucket
    key            = "prod/payment-service/terraform.tfstate"
    region         = "ap-northeast-1"
    encrypt        = true                               # AES-256 encryption at rest
    dynamodb_table = "terraform-state-lock"             # prevents concurrent applies
    profile        = "terraform-deploy"                 # AWS profile with minimal IAM permissions
  }
}
```

### State Key Naming Convention

```
Pattern: <environment>/<service-or-layer>/<component>/terraform.tfstate

Examples:
  prod/networking/vpc/terraform.tfstate
  prod/platform/eks-cluster/terraform.tfstate
  prod/payment-service/rds/terraform.tfstate
  staging/payment-service/rds/terraform.tfstate
  dev/payment-service/rds/terraform.tfstate

Rules:
  Never share a state file between environments (prod and staging MUST be separate)
  Never share a state file between unrelated services
  Each state file = one blast radius (what terraform destroy would affect)
  Smaller state files = faster plans, less risk, easier debugging
```

### DynamoDB Lock Table Setup

```hcl
# One-time bootstrap (create this BEFORE the backend config above)
resource "aws_dynamodb_table" "terraform_lock" {
  name         = "terraform-state-lock"
  billing_mode = "PAY_PER_REQUEST"
  hash_key     = "LockID"

  attribute {
    name = "LockID"
    type = "S"
  }
}

resource "aws_s3_bucket" "terraform_state" {
  bucket = "company-terraform-state"
}

resource "aws_s3_bucket_versioning" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id
  versioning_configuration {
    status = "Enabled"   # every state file version is preserved for rollback
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "aws:kms"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "terraform_state" {
  bucket                  = aws_s3_bucket.terraform_state.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}
```

### State File Rules

```
NEVER:
  × Commit .tfstate files to Git
  × Store state locally for production infrastructure
  × Share one state file between prod and staging
  × Run terraform apply without a plan file (use -out and apply the plan file)

ALWAYS:
  ✓ Add *.tfstate and *.tfstate.backup to .gitignore
  ✓ Enable S3 versioning on the state bucket (rollback safety net)
  ✓ Enable S3 object lock or MFA delete for compliance environments
  ✓ Use separate AWS accounts for separate environments (prevents blast radius)
  ✓ Monitor the DynamoDB lock table (a stuck lock blocks all applies)
```

---

## Part 2 — Code Structure: Modules and Repository Layout

**Without structure:** All resources are in one `main.tf` file. Every environment duplicates the same code. A change to the VPC breaks all services. Nobody knows where to add a new resource.

**With structure:** Each layer is independent. Modules are reusable. A new service can be added without touching networking or the EKS cluster.

### Repository Structure

```
infrastructure/
├── modules/                          ← shared reusable modules
│   ├── eks-cluster/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   └── README.md                 ← auto-generated by terraform-docs
│   ├── rds-postgres/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── outputs.tf
│   └── vpc/
│       ├── main.tf
│       ├── variables.tf
│       └── outputs.tf
│
├── environments/
│   ├── dev/
│   │   ├── networking/
│   │   │   ├── backend.tf            ← remote state config
│   │   │   ├── main.tf               ← calls modules/vpc
│   │   │   ├── variables.tf
│   │   │   └── terraform.tfvars      ← dev-specific values
│   │   └── payment-service/
│   │       ├── backend.tf
│   │       ├── main.tf
│   │       ├── variables.tf
│   │       └── terraform.tfvars
│   ├── staging/
│   │   └── ... (same structure)
│   └── prod/
│       └── ... (same structure)
│
└── .github/
    └── workflows/
        └── terraform.yml             ← CI/CD pipeline
```

### Module Design Rules

```hcl
# modules/rds-postgres/variables.tf
# Every variable must have: description, type, and a validation where appropriate

variable "instance_class" {
  description = "RDS instance class (e.g. db.t3.medium)"
  type        = string
  default     = "db.t3.medium"

  validation {
    condition     = can(regex("^db\\.", var.instance_class))
    error_message = "instance_class must start with 'db.' (e.g. db.t3.medium)"
  }
}

variable "environment" {
  description = "Deployment environment: dev | staging | prod"
  type        = string

  validation {
    condition     = contains(["dev", "staging", "prod"], var.environment)
    error_message = "environment must be one of: dev, staging, prod"
  }
}

variable "deletion_protection" {
  description = "Prevent accidental deletion of the RDS instance"
  type        = bool
  default     = true    # safe default; override to false only in dev
}
```

```hcl
# modules/rds-postgres/outputs.tf
# Output everything a consumer might need; nothing more

output "endpoint" {
  description = "RDS instance endpoint (host:port)"
  value       = aws_db_instance.this.endpoint
}

output "db_name" {
  description = "Database name"
  value       = aws_db_instance.this.db_name
}

output "security_group_id" {
  description = "Security group ID for the RDS instance (use in consumer's ingress rules)"
  value       = aws_security_group.rds.id
  # Outputs let consumers reference this module's resources without tight coupling
}
```

### Root Module Calling a Shared Module

```hcl
# environments/prod/payment-service/main.tf

module "rds" {
  source = "../../../modules/rds-postgres"
  # Always pin modules to a specific version tag (never use HEAD/main directly)
  # For local modules: use relative path; for registry: use version = "x.y.z"

  environment        = "prod"
  instance_class     = "db.r6g.large"
  deletion_protection = true
  db_name            = "payments"

  # Cross-module data reference (not hardcoded)
  vpc_id             = data.terraform_remote_state.networking.outputs.vpc_id
  subnet_ids         = data.terraform_remote_state.networking.outputs.private_subnet_ids
}
```

### Cross-Stack Data Sharing (Remote State as Data Source)

```hcl
# Read outputs from the networking stack's state
# Instead of hardcoding VPC IDs or subnet IDs
data "terraform_remote_state" "networking" {
  backend = "s3"
  config = {
    bucket  = "company-terraform-state"
    key     = "prod/networking/vpc/terraform.tfstate"
    region  = "ap-northeast-1"
  }
}

# Use it:
vpc_id     = data.terraform_remote_state.networking.outputs.vpc_id
subnet_ids = data.terraform_remote_state.networking.outputs.private_subnet_ids

# Why remote state over hardcoding:
# → VPC ID changes if the VPC is recreated (rare but happens)
# → Hardcoded IDs in many places = many files to update
# → Remote state reference = one source of truth
```

---

## Part 3 — Version Pinning: Reproducibility and Safety

**Without pinning:** A provider release on a Monday breaks all your plans by Tuesday because the new version changed a resource schema. A `terraform init` produces different code depending on when it runs.

**With pinning:** Every `terraform init` produces exactly the same provider binaries as the previous one. Upgrades are deliberate and reviewed.

### Pin Everything

```hcl
# versions.tf — lives in every root module and every shared module

terraform {
  required_version = ">= 1.6.0, < 2.0.0"
  # Allows patch and minor updates within 1.x; blocks 2.0 (potentially breaking)

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.50"      # allows 5.50.x, 5.51.x but NOT 6.x
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.30"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.13"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }
}
```

### Lock File: Commit It to Git

```
# .terraform.lock.hcl is auto-generated by terraform init
# It pins the EXACT provider versions (including checksums)
# ALWAYS commit this file to Git

# .gitignore should include:
*.tfstate
*.tfstate.backup
.terraform/           ← the downloaded providers directory (large; don't commit)
*.tfplan              ← plan output files (may contain sensitive values)
.terraform.tfvars     ← local override vars that should not be shared

# .gitignore should NOT include:
# .terraform.lock.hcl ← this MUST be committed
```

### Provider Upgrade Workflow

```
Step 1: Create an upgrade branch
  git checkout -b chore/upgrade-aws-provider-5.60

Step 2: Update versions.tf
  version = "~> 5.60"   (was ~> 5.50)

Step 3: Regenerate the lock file
  terraform init -upgrade

Step 4: Run plan in dev first
  cd environments/dev/payment-service
  terraform plan

Step 5: Read the plan output carefully
  Any resource showing changes = provider changed the resource schema
  Most provider minor bumps: no resource changes
  Some minor bumps (5.x → 5.y): a resource may add required fields or change defaults

Step 6: Apply in dev → verify → staging → verify → prod → verify
  Never upgrade a provider version directly in production without testing in lower envs first

Step 7: Commit the updated .terraform.lock.hcl along with versions.tf
  git add versions.tf .terraform.lock.hcl
  git commit -m "chore: upgrade AWS provider to ~> 5.60"
```

---

## Part 4 — Variables, Locals, and Outputs

**The key principle:** Use variables for values that differ between environments or callers. Use locals for derived values computed from variables. Use outputs for values that other modules or stacks need to reference.

### Variables: Types and Validation

```hcl
# variables.tf — best practices

# 1. Always declare a type
variable "environment" {
  type        = string
  description = "Deployment environment"
}

# 2. Use object types for complex inputs (not separate variables for related values)
variable "rds_config" {
  type = object({
    instance_class      = string
    allocated_storage   = number
    multi_az            = bool
    deletion_protection = bool
  })
  description = "RDS instance configuration"
  default = {
    instance_class      = "db.t3.medium"
    allocated_storage   = 100
    multi_az            = false
    deletion_protection = true
  }
}

# 3. Validate inputs to catch errors before apply
variable "retention_days" {
  type        = number
  description = "CloudWatch log retention in days"
  validation {
    condition     = contains([1, 3, 5, 7, 14, 30, 60, 90, 120, 150, 180, 365, 400, 545, 731, 1827, 3653], var.retention_days)
    error_message = "retention_days must be a valid CloudWatch retention period."
  }
}

# 4. Mark sensitive variables (prevents values from appearing in plan output)
variable "db_password" {
  type        = string
  description = "RDS master password"
  sensitive   = true   # value is redacted in terraform plan/apply output and state
}
```

### Locals: Computed and Derived Values

```hcl
# locals.tf — computed values derived from variables

locals {
  # Environment-specific name prefix for all resources
  name_prefix = "${var.project}-${var.environment}"

  # Derived tag map applied to every resource
  common_tags = {
    Project     = var.project
    Environment = var.environment
    ManagedBy   = "terraform"
    Owner       = var.team
    CostCenter  = var.cost_center
  }

  # Conditional logic: prod gets multi-AZ, others don't
  multi_az = var.environment == "prod" ? true : false

  # Derived from a map — useful for environment-specific sizing
  rds_instance_class = {
    dev     = "db.t3.small"
    staging = "db.t3.medium"
    prod    = "db.r6g.large"
  }[var.environment]
}

# Use locals in resources:
resource "aws_db_instance" "main" {
  identifier = "${local.name_prefix}-rds"
  multi_az   = local.multi_az
  tags       = local.common_tags
}
```

### terraform.tfvars per Environment

```hcl
# environments/prod/payment-service/terraform.tfvars
# Values that change per environment; committed to Git (no secrets)

project     = "company"
environment = "prod"
team        = "payments"
cost_center = "CC-1234"

rds_config = {
  instance_class      = "db.r6g.large"
  allocated_storage   = 500
  multi_az            = true
  deletion_protection = true
}

# environments/dev/payment-service/terraform.tfvars
project     = "company"
environment = "dev"
team        = "payments"
cost_center = "CC-1234"

rds_config = {
  instance_class      = "db.t3.small"
  allocated_storage   = 20
  multi_az            = false
  deletion_protection = false  # allow easy cleanup in dev
}
```

---

## Part 5 — Tagging Strategy: Every Resource

**Every AWS resource managed by Terraform must have consistent tags.** Tags are how you trace cost, enforce compliance, and find orphaned resources.

```hcl
# Apply common_tags to every resource via merge()
resource "aws_instance" "app" {
  ami           = data.aws_ami.amazon_linux.id
  instance_type = "m5.large"

  tags = merge(local.common_tags, {
    Name = "${local.name_prefix}-app-server"
    Role = "application"
  })
  # merge() applies common tags FIRST, then resource-specific tags
  # Resource-specific tags override common tags if key collides
}

# For resources that support tag propagation:
resource "aws_autoscaling_group" "app" {
  # ...
  tag {
    key                 = "Name"
    value               = "${local.name_prefix}-asg"
    propagate_at_launch = true   # copies tags to EC2 instances created by the ASG
  }

  dynamic "tag" {
    for_each = local.common_tags
    content {
      key                 = tag.key
      value               = tag.value
      propagate_at_launch = true
    }
  }
}

# Required tag set (enforce via aws_config or SCP):
# environment   = dev | staging | prod
# team          = payments | orders | platform | sre
# managed-by    = terraform
# cost-center   = CC-XXXX
# project       = company-name
```

---

## Part 6 — CI/CD Pipeline: The Only Apply Path

**The #1 Terraform best practice:** No one runs `terraform apply` manually from their laptop in staging or production. The CI/CD pipeline is the only apply path.

### GitHub Actions Workflow

```yaml
# .github/workflows/terraform.yml
name: Terraform CI/CD

on:
  pull_request:
    branches: [main]
    paths:
      - 'environments/**'
      - 'modules/**'
  push:
    branches: [main]
    paths:
      - 'environments/**'
      - 'modules/**'

env:
  TF_VERSION: "1.8.0"
  AWS_REGION: "ap-northeast-1"

jobs:
  # ── Plan on PR ──
  plan:
    if: github.event_name == 'pull_request'
    runs-on: ubuntu-latest
    permissions:
      id-token: write      # OIDC for AWS auth (no long-lived AWS keys)
      contents: read
      pull-requests: write # to post plan as PR comment

    steps:
      - uses: actions/checkout@v4

      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: ${{ env.TF_VERSION }}

      - name: Configure AWS credentials (OIDC)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789:role/github-actions-terraform-plan
          aws-region: ${{ env.AWS_REGION }}

      - name: Terraform Init
        run: terraform init
        working-directory: environments/prod/payment-service

      - name: Terraform Format Check
        run: terraform fmt -check -recursive

      - name: Terraform Validate
        run: terraform validate
        working-directory: environments/prod/payment-service

      - name: tflint
        uses: terraform-linters/setup-tflint@v4
        # Catches common mistakes: deprecated resource types, unused variables, etc.

      - name: Terraform Plan
        id: plan
        run: terraform plan -no-color -out=tfplan
        working-directory: environments/prod/payment-service

      - name: Post plan as PR comment
        uses: actions/github-script@v7
        with:
          script: |
            const output = `#### Terraform Plan 📋
            \`\`\`
            ${{ steps.plan.outputs.stdout }}
            \`\`\``;
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: output
            });

  # ── Apply on merge to main (dev/staging auto; prod requires approval) ──
  apply:
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: production   # requires a GitHub environment approval gate for prod
    permissions:
      id-token: write
      contents: read

    steps:
      - uses: actions/checkout@v4

      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: ${{ env.TF_VERSION }}

      - name: Configure AWS credentials (OIDC — apply role has more permissions)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789:role/github-actions-terraform-apply
          aws-region: ${{ env.AWS_REGION }}

      - name: Terraform Init
        run: terraform init
        working-directory: environments/prod/payment-service

      - name: Terraform Apply
        run: terraform apply -auto-approve
        working-directory: environments/prod/payment-service
```

### IAM Roles for CI/CD (OIDC — No Long-Lived Keys)

```hcl
# iam.tf — GitHub Actions OIDC role (no static AWS access keys needed)

resource "aws_iam_openid_connect_provider" "github_actions" {
  url             = "https://token.actions.githubusercontent.com"
  client_id_list  = ["sts.amazonaws.com"]
  thumbprint_list = ["6938fd4d98bab03faadb97b34396831e3780aea1"]
}

resource "aws_iam_role" "github_actions_plan" {
  name = "github-actions-terraform-plan"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Federated = aws_iam_openid_connect_provider.github_actions.arn
      }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringLike = {
          "token.actions.githubusercontent.com:sub" = "repo:company/infrastructure:*"
        }
        StringEquals = {
          "token.actions.githubusercontent.com:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })
}

# Plan role: read-only to AWS resources + read Terraform state
resource "aws_iam_role_policy_attachment" "plan_readonly" {
  role       = aws_iam_role.github_actions_plan.name
  policy_arn = "arn:aws:iam::aws:policy/ReadOnlyAccess"
}

# Apply role: same as plan + write permissions for the specific resources Terraform manages
# (Use a custom policy listing exactly which services Terraform touches — not AdministratorAccess)
```

---

## Part 7 — Sensitive Data: Secrets Management

**Never store secret values in .tf files or .tfvars files committed to Git.**

```hcl
# Pattern A: Reference from AWS Secrets Manager (best for production)
data "aws_secretsmanager_secret_version" "db_password" {
  secret_id = "prod/payment-service/db-password"
  # The actual password value is never in Git — only the secret ARN reference
}

resource "aws_db_instance" "main" {
  password = data.aws_secretsmanager_secret_version.db_password.secret_string
  # OR: jsondecode(data.aws_secretsmanager_secret_version.db_password.secret_string)["password"]
}

# Pattern B: AWS SSM Parameter Store
data "aws_ssm_parameter" "db_password" {
  name            = "/prod/payment-service/db-password"
  with_decryption = true   # decrypts SecureString parameters using KMS
}

resource "aws_db_instance" "main" {
  password = data.aws_ssm_parameter.db_password.value
}

# Pattern C: Random password generated by Terraform (stored in state, encrypted)
resource "random_password" "db_password" {
  length           = 32
  special          = true
  override_special = "!#$%&*()-_=+[]{}<>:?"
}

resource "aws_secretsmanager_secret_version" "db_password" {
  secret_id     = aws_secretsmanager_secret.db.id
  secret_string = random_password.db_password.result
  # Password is generated once, stored in Secrets Manager and Terraform state
  # State is encrypted at rest via KMS (backend.tf s3 with encrypt=true)
}

# NEVER:
#   variable "db_password" { default = "SuperSecret123!" }  ← in Git
#   db_password = "SuperSecret123!" in terraform.tfvars      ← in Git
```

---

## Part 8 — Resource Lifecycle: Prevent Accidental Destruction

```hcl
# lifecycle blocks protect critical resources from accidental deletion

resource "aws_db_instance" "production" {
  # ...

  lifecycle {
    # Block: prevents terraform destroy from deleting this resource
    prevent_destroy = true
    # An error is raised if any plan includes destroying this resource
    # Use for: production databases, S3 buckets with data, KMS keys

    # Ignore changes to these fields (prevent re-creation on external changes)
    ignore_changes = [
      password,       # rotated externally by Secrets Manager; Terraform should not reset it
      snapshot_identifier,  # set on first create; ignore on subsequent plans
    ]

    # Replace the resource before destroying the old one (zero-downtime)
    create_before_destroy = true
    # Required for resources that must always exist (e.g. security groups with dependencies)
  }
}

resource "aws_s3_bucket" "data" {
  bucket = "company-payment-data"
  lifecycle {
    prevent_destroy = true
  }
}

# For destructive changes that prevent_destroy would block:
# Step 1: remove prevent_destroy from the code temporarily
# Step 2: plan and review the destroy
# Step 3: apply
# Step 4: restore prevent_destroy for the replacement resource
# This forces an intentional, reviewable step before any destruction
```

---

## Part 9 — Import: Bringing Manual Resources Under Terraform

**When someone creates a resource manually in the AWS console, it is untracked. Terraform does not know it exists. Import brings it under Terraform management.**

```bash
# Step 1: write the resource configuration in your .tf file first
# (terraform import requires the resource block to already exist)

# Step 2: find the resource's AWS identifier
# For EC2 instance: the instance ID (i-0123456789abcdef)
# For S3 bucket: the bucket name
# For RDS: the DB identifier

# Step 3: import
terraform import aws_instance.web_server i-0123456789abcdef
terraform import aws_s3_bucket.data company-payment-data
terraform import aws_db_instance.main prod-payments-rds

# Step 4: run terraform plan to check if the code matches the imported state
terraform plan
# If plan shows changes: your .tf config doesn't match the real resource
# Adjust your .tf code until the plan shows "No changes" or only desired changes

# Terraform 1.5+ import block (preferred — declarative; no CLI command needed)
import {
  to = aws_instance.web_server
  id = "i-0123456789abcdef"
}

# Terraform 1.6+ generate config from import (write the .tf for you):
terraform plan -generate-config-out=imported_resources.tf
# Generates .tf code for the imported resource — use as a starting point, then clean up
```

---

## Part 10 — Drift Detection and Compliance

**Drift = the real infrastructure no longer matches the Terraform state.** Causes: manual console changes, AWS automatic updates, broken applies.

```bash
# Run terraform plan to detect drift (compares state to real AWS)
# In CI: schedule this as a daily job; alert if plan is non-empty

# Scheduled drift detection (GitHub Actions cron)
# Add to workflow:
#   schedule:
#     - cron: '0 9 * * 1-5'   # 9am UTC weekdays

terraform plan -detailed-exitcode
# Exit code 0: no changes (no drift)
# Exit code 1: error
# Exit code 2: changes detected (DRIFT) — alert the team

# Find resources in AWS not managed by Terraform
# (requires AWS Config or cloud-custodian):
# Check AWS Config rule: "required-tags" with managed-by=terraform
# Any resource without the managed-by:terraform tag = potential untracked resource

# Resolve drift: three options
# Option A: update the .tf code to match what was manually created (codify the change)
# Option B: sync back by running terraform apply (reverts to what Terraform says)
# Option C: if the resource should not be tracked: terraform state rm (remove from state)
```

---

## Common Mistakes and Correct Approaches

| Mistake | What Goes Wrong | Correct Approach |
|---|---|---|
| Storing state locally or in Git | State file contains plaintext secrets; two engineers corrupt state simultaneously | Always use S3 + DynamoDB backend; never commit .tfstate to Git |
| No version pinning on providers | A provider release changes a resource schema; plan breaks on Monday morning | Pin every provider with `~> X.Y` in required_providers; commit .terraform.lock.hcl |
| Running terraform apply from a laptop in production | No audit trail; no plan review; engineer makes a mistake under pressure | CI/CD pipeline is the only apply path for staging/prod; humans only run plan locally |
| One state file for all environments | A bad prod apply can affect staging resources; state grows huge; plans are slow | One state file per environment per service; small blast radius per state |
| Hardcoding resource IDs (VPC ID, subnet IDs) | IDs become stale when infra is recreated; tedious to update across all files | Use `data "terraform_remote_state"` to reference outputs from other stacks |
| Secrets in .tf files or tfvars | Committed to Git; visible in plan output; IAM role compromise leaks everything | Use `data "aws_secretsmanager_secret_version"` or SSM; never put secrets in code |
| `prevent_destroy = false` on production databases | A `terraform destroy` or refactor accidentally deletes 2 years of production data | Set `prevent_destroy = true` on every stateful production resource; remove intentionally |
| Not reviewing the plan output before apply | A resource rename causes create+destroy; downtime occurs | Every plan must be reviewed by a human; CI posts plan to PR; blocking destroy requires approval |
| Using `terraform workspace` for environment isolation | Workspaces share the same codebase; a prod workspace mistake is one `terraform workspace select` away | Use separate directories per environment (`environments/dev/`, `environments/prod/`); separate state keys |
| No tagging strategy | Cannot attribute cost; cannot find orphaned resources; compliance fails | Enforce `managed-by=terraform` and `environment` tags on every resource via locals.common_tags |
