# SRE Troubleshooting — Part 8: Post-Mortem

> **Core rule:** A post-mortem is not a blame session. It is a systems analysis. The question is never "who made the mistake?" — it is "what in the system allowed this failure to happen and persist?" People make mistakes. Good systems have guardrails that catch mistakes before they become incidents.

---

## Decision Tree — "Do I need a post-mortem for this incident?"

```
"Should we write a post-mortem?"
│
├─ Was this a SEV1?
│   └─ YES → post-mortem is REQUIRED; no exceptions
│
├─ Was this a SEV2?
│   └─ YES → post-mortem is REQUIRED
│
├─ Was this a SEV3?
│   ├─ Is it a recurring issue (happened before)?
│   │   └─ YES → post-mortem required (recurrence = systemic gap)
│   └─ Is it new and unlikely to recur?
│       └─ NO post-mortem → just fix it and add a monitoring alert
│
├─ Was this a SEV4?
│   └─ No post-mortem → Jira ticket to fix it; no formal analysis needed
│
└─ "Do we have time?" is NOT a valid reason to skip a post-mortem
    → SEV1/SEV2 post-mortems prevent future SEV1/SEV2 incidents
    → Skipping = accepting the same incident will happen again
```

---

## When to Write It

```
DRAFT:   within 48 hours of resolution
REVIEW:  within 1 week (team reviews; action items assigned)
CLOSE:   when all action items have owners and due dates (not when completed)

WHY 48 HOURS:
  Memory fades quickly after an incident.
  The timeline, feelings, and "what we were thinking" are clearest immediately after.
  A post-mortem written 2 weeks later is mostly reconstructed from Slack + git; it misses
  the human factors (why did we not check X? what assumption did we make?).
```

---

## The Full Post-Mortem Template

```markdown
# Post-Mortem: payment-service SEV2 — 2026-07-25

## Summary
Brief: 1–3 sentence plain-language summary of what happened and what was done.

On 2026-07-25, payment-service experienced a 40-minute SEV2 degradation
(error rate peaked at 2.3%) due to a missing database index introduced in v2.3.2.
The incident was mitigated by rolling back to v2.3.1 within 11 minutes of alert.
The permanent fix (adding the index + deploying v2.3.3) resolved the incident at 15:12 UTC.

---

## Impact

| Metric          | Value                           |
|---|---|
| Duration        | 40 minutes (14:32 – 15:12 UTC) |
| Error rate peak | 2.3% (150 errors/min at peak)  |
| Users affected  | ~800 failed payment submissions |
| Revenue impact  | ~$12,000 in failed transactions  |
| SLO impact      | Consumed 18 minutes of monthly error budget (41.4% of 43.2 min/month) |

---

## Timeline

All times UTC.

| Time  | Event |
|---|---|
| 14:21 | payment-service v2.3.2 deployed via GitHub Actions (automated deploy on merge) |
| 14:30 | DB connection count begins rising (visible in RDS CloudWatch, noticed in hindsight) |
| 14:32 | Alert fires: PaymentService 5xx rate > 1% |
| 14:33 | On-call (ts-shuge.kui) acknowledges PagerDuty, opens #incidents |
| 14:34 | Grafana review: error rate 2.3%, rising. Deploy at 14:21 identified as likely cause. |
| 14:35 | Rollback initiated to v2.3.1 |
| 14:38 | Rollback complete. Error rate begins dropping. |
| 14:42 | Error rate: 2.3% → 0.9% → 0.2% |
| 14:45 | Error rate at baseline (0.04%). Status page updated to "Monitoring". |
| 14:50 | Root cause hypothesis: missing DB index on payments.created_at |
| 14:55 | EXPLAIN ANALYZE confirms: v2.3.2 uses Seq Scan (full table scan) on 50M-row table |
| 15:00 | Fix PR created: add index + query review (#1234) |
| 15:05 | Fix reviewed, merged. DB migration (CREATE INDEX CONCURRENTLY) started. |
| 15:08 | Index creation complete. v2.3.3 deployed. |
| 15:12 | 10 minutes at baseline. Incident declared RESOLVED. |

---

## Root Cause

v2.3.2 introduced a new API endpoint: `GET /api/v2/payments?start_date=<date>`.

The implementation performed:
```sql
SELECT * FROM payments WHERE created_at > $1 ORDER BY created_at
```

The `payments.created_at` column had no index. On a table with 50 million rows, this
query performs a full sequential scan taking 15–30 seconds per query.

Under normal load (100 req/min to this endpoint), query duration caused DB connections
to be held for 15–30 seconds each. After ~3 minutes at Monday morning peak traffic
(300 req/min), the DB connection pool was exhausted. All subsequent requests returned
errors because no connections were available.

**Why the full table scan was not caught before production:**
- No load test existed for the new endpoint
- The staging database has only 10,000 rows; the query ran in < 1ms
- No DB query EXPLAIN ANALYZE review was part of the code review checklist
- No DB connection pool saturation alert existed to detect the early warning sign (14:30)

---

## Contributing Factors

| Factor | Description |
|---|---|
| No load testing | New endpoint tested functionally only; no performance test at production-scale data volume |
| Staging DB mismatch | Staging has 10K rows; production has 50M rows — query performance not comparable |
| No query review checklist | Code review did not include review of SQL EXPLAIN plan for new queries |
| No early-warning alert | DB connections reached 80% at 14:30 with no alert; first signal was the 5xx alert at 14:32 |
| Automated deploy on merge | No human gate before production deploy; a performance regression deployed immediately |

---

## What Went Well

| Item | Details |
|---|---|
| Alert was meaningful | Alert fired within 2 minutes of users being impacted |
| Rollback was fast | 11 minutes from alert to rollback complete |
| IC was clear from the start | @ts-shuge.kui named IC immediately; no confusion about ownership |
| Communication was timely | Status page updated within 15 minutes; team updates every 10-15 min |
| Root cause found quickly | Hypothesis (DB index) formed and confirmed within 20 minutes of stabilisation |
| Permanent fix was safe | Used CREATE INDEX CONCURRENTLY (no table lock); no additional downtime |

---

## What Did Not Go Well

| Item | Details |
|---|---|
| No early-warning detection | Connection pool was at 80% for 2 minutes before errors started; no alert caught this |
| Deploy reached production without load test | Performance regression not caught in staging |
| No DB index review in checklist | Engineers don't routinely check EXPLAIN plans during code review |
| DB missing from staging data scale | Staging data scale is 0.02% of production; makes performance testing impossible |

---

## Action Items

| Action | Type | Owner | Due | Status |
|---|---|---|---|---|
| Add DB connection pool saturation alert (>80% for 2 min → warning page) | Monitoring | @ts-shuge.kui | 2026-07-28 | OPEN |
| Add EXPLAIN plan review to code review checklist for any new SQL query | Process | @team-lead | 2026-08-01 | OPEN |
| Add load test for /api/v2/payments with 50M-row dataset | Testing | @dev-alice | 2026-08-08 | OPEN |
| Investigate options for production-scale staging DB (RDS snapshot sync) | Infrastructure | @infra-team | 2026-08-15 | OPEN |
| Add readiness probe check for /api/v2/payments endpoint | Operations | @dev-bob | 2026-07-28 | OPEN |

---

## Lessons Learned

1. **Staging data scale matters**: A query that takes 1ms on 10K rows can take 30s on 50M rows.
   Tests that don't use production-scale data cannot catch performance regressions.

2. **Early-warning alerts are more valuable than failure alerts**: The DB connection alert
   would have fired 2 minutes before the 5xx alert, giving us a chance to act before user impact.

3. **Automated deploys require automated gates**: When any merge triggers a production deploy,
   every code review must also be a production readiness review. Performance tests must be part
   of CI, not optional.
```

---

## The Blameless Post-Mortem: How to Write It

### The Frame that Prevents Blame

```
WRONG FRAMING (blame-based):
  "Alice wrote the query without an index."
  "Bob approved the PR without noticing the performance issue."
  "The deploy shouldn't have gone to prod without testing."
  
  Result: Alice and Bob are defensive; they hide mistakes next time;
          the systemic gaps (no checklist, no load test, no alert) are not addressed.

CORRECT FRAMING (systems-based):
  "The code review process did not include a SQL EXPLAIN plan review."
  "The CI pipeline did not include a performance test at production data scale."
  "The monitoring system did not have an early-warning alert for connection pool saturation."
  
  Result: the system's gaps are clear; action items address the system;
          Alice and Bob feel safe to share what they were thinking (valuable information).
```

### The Five Whys Applied

```
SYMPTOM: 5xx errors in production

WHY 1: Why did errors occur?
  → DB connection pool exhausted; queries couldn't get a connection

WHY 2: Why was the connection pool exhausted?
  → Each query took 15-30 seconds (full table scan); connections held for that duration

WHY 3: Why did the query take 15-30 seconds?
  → Missing index on payments.created_at; full sequential scan of 50M rows

WHY 4: Why was the index missing?
  → Code review did not include a SQL query performance review step

WHY 5: Why was there no SQL query review step?
  → The code review checklist was written before the service had large tables;
    performance at scale was not a consideration when the checklist was created

ROOT CAUSE (systemic):
  The code review process was not designed to catch database performance regressions
  at production data scale.

ACTION (addresses the system, not the person):
  Add SQL EXPLAIN plan review to the code review checklist for all new queries.
  Add a load test step to CI that runs against a production-scale dataset.
```

---

## Post-Mortem Review Meeting

```
PURPOSE: review the draft; ensure action items are complete; capture anything missed

AGENDA (45 minutes):
  1. Read the timeline together (10 min)
     → Is anything missing? Is the sequence of events accurate?
  
  2. Root cause discussion (10 min)
     → Does everyone agree on the root cause?
     → Are contributing factors all captured?
  
  3. Action items review (15 min)
     → Is each action item specific enough to be executed?
     → Does each action item have an owner AND a due date?
     → Are the action items tracked in Jira (not just in the doc)?
  
  4. Lessons learned (10 min)
     → What should we share with other teams?
     → Is this a pattern that other services might also have?

WHAT MAKES A GOOD ACTION ITEM:
  VAGUE: "Improve testing"
  → Not actionable; no owner; no measure of completion
  
  SPECIFIC: "Add a load test for /api/v2/payments using a 50M-row dataset
             that verifies p99 latency < 200ms at 300 req/min. Owned by @dev-alice. Due 2026-08-08."
  → Specific; measurable; owned; time-bound

TRACKING:
  Action items must be in Jira (not just in the post-mortem doc)
  Post-mortem is not "complete" until action items are tracked
  Action items are reviewed in the weekly SRE review until closed
```

---

## Common Part 8 Mistakes

| Mistake | What Goes Wrong | Correct Approach |
|---|---|---|
| Writing the post-mortem 2 weeks later | Timeline is reconstructed; human factors forgotten; "why did we do X?" has no answer | Write the draft within 48 hours while memory is fresh |
| Naming individuals in the root cause | People get defensive; hidden knowledge surfaces at the next similar incident | Frame root cause as system failures: "the process did not include X" not "Alice didn't do X" |
| Action items without owners or due dates | Action items never get done; same incident recurs 3 months later | Every action item: specific action + named owner + due date + Jira ticket |
| Only addressing the symptom (missing index) | The system gap (no performance test, no checklist) is not fixed | Use the Five Whys to find the systemic gap; action items fix the system |
| Skipping post-mortem review meeting | Draft has errors; action items are vague; lessons not shared with other teams | Schedule 45-minute review within 1 week; include the whole team |
