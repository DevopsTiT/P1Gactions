# SRE Troubleshooting — Part 3: Stabilise — Stop the Bleeding

> **Core rule:** Stabilise before you diagnose. A rollback that takes 5 minutes restores service. A root-cause investigation in a burning building takes 45 minutes and the fire keeps burning. Fix the building first, then investigate why it caught fire.

---

## Decision Tree — "How do I stop the incident right now?"

```
"Service is degraded — what is the fastest path to restoration?"
│
├─ Was there a deployment in the last 30 minutes?
│   └─ YES → ROLLBACK immediately (Option A)
│             Rollback is almost always faster than diagnosing + fixing
│
├─ Is CPU/memory at or near limit? (throttling or OOM?)
│   └─ YES → SCALE OUT immediately (Option B)
│             Add more pods; buy time to diagnose
│
├─ Is one specific endpoint or feature causing all errors?
│   └─ YES → REDIRECT TRAFFIC / DISABLE FEATURE (Option C)
│             Kill the bad feature; restore the rest of the service
│
├─ Is all traffic going to unhealthy pods?
│   └─ YES → RESTART PODS / CORDON + DRAIN (Option D)
│             Force replacement of unhealthy pods
│
└─ None of the above apply → still stabilising:
    → Scale out (buys time)
    → Move to diagnosis (Part 4)
```

---

## Option A: Rollback the Deployment

The most common and fastest stabilisation action. Use when a deploy happened within the last 30 minutes.

### Step 1: Confirm a deploy is the likely cause

```bash
# Check deployment history:
kubectl rollout history deployment/payment-service -n payment
# Output:
# REVISION  CHANGE-CAUSE
# 1         Initial deploy
# 2         v2.3.1 — fix pagination
# 3         v2.3.2 — add new payment provider   ← latest

# Check WHEN revision 3 was deployed:
kubectl rollout history deployment/payment-service -n payment --revision=3
# Look for: "Image:" line to see the image tag
# Cross-reference with the alert start time:
#   Alert started: 14:32 UTC
#   Revision 3 deployed: 14:21 UTC → 11 minutes before alert → VERY LIKELY CAUSE
```

### Step 2: Execute the rollback

```bash
# Rollback to previous revision (revision 2):
kubectl rollout undo deployment/payment-service -n payment

# OR rollback to a specific revision (e.g. revision 1):
kubectl rollout undo deployment/payment-service -n payment --to-revision=1

# Watch the rollback progress:
kubectl rollout status deployment/payment-service -n payment
# Output:
#   Waiting for deployment "payment-service" rollout to finish: 2 out of 3 new replicas have been updated...
#   Waiting for deployment "payment-service" rollout to finish: 2 old replicas are pending termination...
#   deployment "payment-service" successfully rolled out

# If the rollback itself hangs (pods won't start):
kubectl get pods -n payment -w
# Watch for: Pending → ContainerCreating → Running
# If stuck at Pending: check describe pod for scheduling issues
```

### Step 3: Verify the rollback worked

```bash
# Check all pods are running with the OLD revision:
kubectl get pods -n payment
# All should be: Running, READY = 1/1
# Age should be < 3 min (just restarted)

# Confirm the old image tag:
kubectl get pods -n payment -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.spec.containers[0].image}{"\n"}{end}'
# Should show: image:v2.3.1 (the previous version), NOT v2.3.2

# Watch the error rate in Grafana:
# After rollback: error rate should drop within 60-120 seconds
# If it doesn't drop after 3 minutes:
#   → The rollback completed but the error persists → the deploy was NOT the cause
#   → Move to Option B or diagnose directly (Part 4)

# Confirm in incident channel:
# "✅ Rolled back payment-service to v2.3.1 at 14:38 UTC.
#    Error rate dropping: 2.3% → 1.1% → 0.4%.
#    Watching for full stabilisation."
```

### What if rollback doesn't fix it?

```bash
# Error rate still elevated after rollback?
# The deploy was NOT the cause (or the cause existed before the deploy)
# Options:
#   1. Check if the config/secret changed (not just the image)
#   2. Check if the DB had a schema migration that can't be rolled back
#   3. Check if a downstream dependency changed

# Check for recent ConfigMap changes:
kubectl get configmap payment-config -n payment -o yaml | grep -A 5 "last-applied"
kubectl get events -n payment --sort-by='.metadata.creationTimestamp' \
  | grep -i "configmap\|secret\|updated" | tail -10

# Check for K8s events (config changes show here):
kubectl get events -n payment --sort-by='.metadata.creationTimestamp' | tail -20
```

---

## Option B: Scale Out (Capacity Problem)

Use when pods are at resource limits (CPU throttling, memory pressure) or when traffic spiked.

```bash
# Check current state:
kubectl get hpa -n payment
# NAME              REFERENCE              TARGETS         MINPODS   MAXPODS   REPLICAS
# payment-hpa       Deployment/payment     78%/70% CPU     3         10        3
# → CPU at 78% (above 70% target), but only 3 replicas (HPA hasn't caught up yet)

kubectl get deployment payment-service -n payment
# READY   UP-TO-DATE   AVAILABLE   AGE
# 3/3     3            3           30d
# → 3 replicas; fine under normal load but not enough during a spike

kubectl top pods -n payment
# NAME                            CPU(cores)   MEMORY(bytes)
# payment-service-abc-xkp2        980m         480Mi  ← 98% of 1 CPU limit; throttled
# payment-service-abc-9mnt        990m         475Mi  ← 99% of 1 CPU limit; throttled
# payment-service-abc-7q8f        970m         460Mi  ← 97% of 1 CPU limit; throttled

# Manual scale (immediate; bypasses HPA temporarily):
kubectl scale deployment payment-service -n payment --replicas=10

# Watch pods come up:
kubectl get pods -n payment -w
# New pods: Pending → ContainerCreating → Running (should take 30-90 sec)

# Verify load distributes:
kubectl top pods -n payment
# All pods should now be at ~30% CPU (traffic spread across 10 pods)

# Monitor error rate in Grafana:
# Should see improvement as new pods come online and take traffic
```

### When to use scale-out vs rollback

```
ROLLBACK:
  → Recent deploy (< 30 min)
  → Error rate started exactly when deploy completed
  → Same errors on all pods regardless of load
  → Fast (< 5 min to restore)

SCALE OUT:
  → No recent deploy
  → Traffic spiked (RPS doubled or more)
  → CPU/memory near limits (top pods shows throttling)
  → Error rate correlates with traffic, not with a specific deploy time
  → Slower than rollback (pods take 1-2 min to start)
  → Use as FIRST ACTION even before diagnosis when under heavy load
```

---

## Option C: Redirect Traffic / Disable Feature

Use when errors are isolated to one feature or endpoint.

### Disable a feature via ConfigMap

```bash
# Check what's in the config:
kubectl get configmap payment-config -n payment -o yaml

# Edit to disable the problematic feature:
kubectl edit configmap payment-config -n payment
# Find and change:
#   enable_apple_pay: "true"  →  enable_apple_pay: "false"
# Save and exit

# IMPORTANT: ConfigMap change doesn't restart pods automatically.
# If your app reads the config at startup (not live reload):
kubectl rollout restart deployment/payment-service -n payment
# This restarts pods to pick up the new ConfigMap value

# Verify the feature is disabled:
kubectl logs -n payment -l app=payment-service --since=1m | grep "apple_pay"
# Should see: "apple_pay feature disabled" or no apple_pay errors
```

### Canary rollback (Argo Rollouts)

```bash
# If using Argo Rollouts for canary deploys:
kubectl argo rollouts get rollout payment-service -n payment
# Shows: canary 30% traffic, stable 70%

# Abort the canary (shifts 100% back to stable):
kubectl argo rollouts abort payment-service -n payment
# Canary pods are terminated; all traffic goes to stable version

# Verify:
kubectl argo rollouts get rollout payment-service -n payment
# Should show: 100% traffic to stable
```

### ALB weighted routing (blue/green)

```bash
# For blue/green deployments via AWS ALB:
# Currently: blue (current) 70%, green (new) 30%
# Shift all traffic back to blue:

RULE_ARN="arn:aws:elasticloadbalancing:ap-northeast-1:123456789012:listener-rule/..."
BLUE_TG_ARN="arn:aws:elasticloadbalancing:ap-northeast-1:123456789012:targetgroup/blue/..."
GREEN_TG_ARN="arn:aws:elasticloadbalancing:ap-northeast-1:123456789012:targetgroup/green/..."

aws elbv2 modify-rule \
  --rule-arn ${RULE_ARN} \
  --actions "[{\"Type\":\"forward\",\"ForwardConfig\":{\"TargetGroups\":[
    {\"TargetGroupArn\":\"${BLUE_TG_ARN}\",\"Weight\":100},
    {\"TargetGroupArn\":\"${GREEN_TG_ARN}\",\"Weight\":0}
  ]}}]"

# Verify:
aws elbv2 describe-rules --rule-arns ${RULE_ARN} \
  --query 'Rules[0].Actions[0].ForwardConfig.TargetGroups[*].{TG:TargetGroupArn,Weight:Weight}' \
  --output table
```

---

## Option D: Restart Unhealthy Pods

Use when pods are in a bad state (not CrashLoopBackOff, but stuck/unhealthy).

```bash
# Identify unhealthy pods:
kubectl get pods -n payment
# payment-service-abc-7q8f   1/1  Running  0  4h  ← Running but possibly stuck

# Check if pods have memory leaks or are unresponsive:
kubectl top pods -n payment
kubectl exec -it payment-service-abc-7q8f -n payment -- \
  curl -s localhost:8080/health
# Expected: {"status":"ok"}
# Got: timeout → pod is running but not responding → needs restart

# Restart a specific pod (kubectl delete forces K8s to create a new one):
kubectl delete pod payment-service-abc-7q8f -n payment
# K8s immediately creates a replacement pod

# Restart ALL pods in the deployment (rolling restart — no downtime):
kubectl rollout restart deployment/payment-service -n payment

# Restart pods on a specific unhealthy node:
kubectl drain <node-name> --ignore-daemonsets --delete-emptydir-data
# Evicts all pods from the node → they reschedule elsewhere
# Note: make sure cluster has capacity on other nodes first

# If a node is completely unhealthy:
kubectl cordon <node-name>   # prevents new pods from scheduling here
kubectl drain <node-name> --ignore-daemonsets --delete-emptydir-data
# Then fix or replace the node
```

---

## Verify Stabilisation: The 10-Minute Watch

After ANY stabilisation action, watch the metrics for at least 10 minutes before declaring success.

```bash
# What to monitor:
# 1. Error rate graph: should drop to < 0.1% within 2 minutes of action
# 2. P99 latency: should return to baseline within 3 minutes
# 3. Pod readiness: all pods should be READY = 1/1
# 4. No new alerts firing

# Checkpoint at 2 minutes:
# Error rate still dropping? → good; keep watching
# Error rate stopped dropping at 2%? → stabilisation incomplete; re-evaluate

# Checkpoint at 5 minutes:
# Error rate at baseline (<0.1%)? → likely stabilised
# Still at 1-2%? → stabilisation partially successful; may be a different problem

# Checkpoint at 10 minutes:
# Stable at baseline for 10 consecutive minutes? → DECLARE STABILISED
# → Post to incident channel:
#    "✅ Service stabilised. Error rate < 0.05% for past 10 minutes.
#     Root cause investigation continues. No immediate user impact."

kubectl get pods -n payment
# All: Running + READY = 1/1 (confirm no restarts happening)

# After declaring stabilised:
# → Move to Part 4 (Diagnose) to find the ROOT CAUSE
# → The stabilisation was temporary; the root cause still needs to be understood and fixed
```

---

## Common Part 3 Mistakes

| Mistake | What Goes Wrong | Correct Approach |
|---|---|---|
| Diagnosing instead of stabilising | Service stays broken for 30+ min while you investigate; users suffering | Rollback/scale first; diagnose AFTER service is stable |
| Not watching metrics after rollback | Rollback completes but error rate stays high; team thinks service is fixed | Watch Grafana for 10 minutes after ANY stabilisation action |
| Scaling out when the problem is app-level | Adding pods doesn't fix a bug; wastes resources; delays diagnosis | Only scale if CPU/memory is the bottleneck; check `kubectl top` first |
| Disabling features without announcing it | Stakeholders confused why Apple Pay is suddenly down; support team gets calls | Always post to incident channel before AND after any traffic change |
| Rolling back without checking if schema migration ran | Rolled-back code doesn't understand the new DB schema; new kind of failure | Check if the deploy included a DB migration; if yes, rolling back may not be safe |
