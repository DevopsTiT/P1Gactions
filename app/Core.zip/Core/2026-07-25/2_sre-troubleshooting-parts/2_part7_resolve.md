# SRE Troubleshooting — Part 7: Resolve — Deploy the Permanent Fix

> **Core rule:** Stabilisation (Part 3) restores service but does not fix the problem. Resolution means the root cause is addressed, a permanent fix is deployed, and you have defined and verified criteria that confirm the fix works. Until all three are done, the incident is not resolved.

---

## Decision Tree — "Is the incident resolved yet?"

```
"Can I declare this incident resolved?"
│
├─ Is the service stable for at least 10 minutes?
│   └─ NO → wait; premature resolution is a common mistake
│
├─ Has the ROOT CAUSE been identified?
│   └─ NO → the incident is not resolved; only stabilised
│             Declare "STABILISED" not "RESOLVED"; continue diagnosis
│
├─ Has a PERMANENT fix been deployed to production?
│   ├─ NO → only a temporary mitigation (rollback, feature flag) is in place
│   │        That's fine — declare stabilised; track the permanent fix in a ticket
│   │        Do NOT leave the temporary fix in place indefinitely
│   └─ YES → continue
│
├─ Have verification criteria been met?
│   └─ Must check ALL of:
│       ☐ Error rate < 0.1% for 10+ consecutive minutes
│       ☐ P99 latency back to baseline
│       ☐ No new alerts firing
│       ☐ Downstream dependencies healthy
│       ☐ Deploy of the permanent fix is complete and stable
│
└─ Are action items created for all contributing factors?
    └─ Each contributing factor → a Jira ticket with owner + due date
       If any contributing factor is untracked → risk of recurrence
```

---

## Step 1: Understand the Difference — Mitigation vs Resolution

```
MITIGATION (temporary fix that restores service):
  → Rollback to previous version
  → Scale out to handle traffic
  → Disable a feature flag
  → Redirect traffic around the broken component
  
  Impact: service is restored; users can proceed
  Problem: the ROOT CAUSE still exists in your codebase; it will return
  Status: "STABILISED" — not "RESOLVED"

RESOLUTION (permanent fix that removes the root cause):
  → Add the missing DB index
  → Fix the memory leak in code
  → Increase the connection pool size + add monitoring
  → Fix the bug in the new endpoint
  
  Impact: the failure condition no longer exists
  Problem: requires careful deployment (don't introduce new bugs while fixing)
  Status: "RESOLVED" only after permanent fix is deployed and verified
```

---

## Step 2: Write the Fix

```
ROOT CAUSE EXAMPLE:
  v2.3.2 introduced a new endpoint: GET /api/v2/payments?start_date=...
  This endpoint queries: SELECT * FROM payments WHERE created_at > $1 ORDER BY created_at
  The payments table has 50 million rows; created_at has no index.
  Under load: full table scan takes 15-30 seconds → connection held → pool exhaustion

FIX:
  Add an index on payments.created_at (allows the query to use an index scan instead)

THE FIX IN CODE:
  File: db/migrations/003_add_payment_created_at_index.sql
  Content:
    -- Use CONCURRENTLY to avoid table lock during creation
    -- Note: CONCURRENTLY cannot be run inside a transaction; run separately
    CREATE INDEX CONCURRENTLY payments_created_at_idx ON payments(created_at);
    
    -- Verify the index was created:
    SELECT indexname, indexdef FROM pg_indexes WHERE tablename = 'payments';

THE FIX IN THE DEPLOYMENT:
  File: apps/payment-service/deployment.yaml
  Change: image: payment-service:v2.3.3 (includes the migration runner)

TEST THE FIX IN STAGING:
  1. Deploy v2.3.3 to staging
  2. Run a load test against the /api/v2/payments endpoint (simulate Monday traffic)
  3. Verify: DB connection count stays below 50% during the load test
  4. Verify: Query uses index: EXPLAIN ANALYZE SELECT * FROM payments WHERE created_at > ...
             Shows: "Index Scan using payments_created_at_idx" (not "Seq Scan")
  5. Verify: Error rate 0% during 5-minute load test at 2× normal traffic
```

---

## Step 3: PR Review Checklist for a Fix

```
BEFORE MERGING THE FIX PR:
  □ Is the fix the minimum change needed? (no extra refactoring during an incident fix)
  □ Does the PR description link to the incident? ("Fixes incident #INC-4892")
  □ Was the fix tested in staging? (and the test shows the failure no longer reproduces)
  □ Does the fix introduce any new risk? (e.g. DB migration that could fail mid-deploy)
  □ Is the deployment plan safe? (can it be rolled back if needed?)
  □ Are there DB schema migrations? If yes:
    □ Is the migration backward-compatible with the previous version?
    □ Can the previous code (v2.3.1) run against the new DB schema (with the index)?
    □ Can you roll forward or backward safely?
  □ Are there tests that cover this fix? (prevent regression)
```

---

## Step 4: Production Deploy — The Fix

```bash
# BEFORE deploying: announce in #incidents
# "[15:05 UTC] Deploying permanent fix v2.3.3 to production.
#  Fix: adds index payments_created_at_idx.
#  Expected: error rate to remain at baseline; DB connections to stay < 50% under load."

# For DB migration (run BEFORE deploying the new code if forward-compatible):
kubectl exec -it <db-migration-pod> -n payment -- \
  psql -h payment-db.payment.svc.cluster.local -U app -c \
  "CREATE INDEX CONCURRENTLY payments_created_at_idx ON payments(created_at);"
# CONCURRENTLY = no table lock; takes longer but won't block existing queries
# Watch progress:
kubectl exec -it <db-migration-pod> -n payment -- \
  psql -h payment-db.payment.svc.cluster.local -U app -c \
  "SELECT phase, blocks_done, blocks_total, tuples_done, tuples_total
   FROM pg_stat_progress_create_index
   WHERE relid = 'payments'::regclass;"

# Deploy the new image (v2.3.3):
kubectl set image deployment/payment-service \
  payment-service=123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service:v2.3.3 \
  -n payment

# Watch the rollout:
kubectl rollout status deployment/payment-service -n payment

# OR use ArgoCD if it's the deployment system:
# Update the image tag in Git → push → ArgoCD syncs → monitor

# WATCH METRICS DURING DEPLOY:
# 1. Error rate: should stay at baseline (<0.1%) during rolling update
# 2. DB connection count: should stay low (index scan vs seq scan)
# 3. Pod readiness: new pods should become Ready within 60s
```

---

## Step 5: Verification Criteria — Must Pass All

Define these BEFORE deploying, not after. Writing them after is post-hoc rationalisation.

```bash
# VERIFICATION CRITERION 1: Error rate < 0.1% for 10+ consecutive minutes
# Check in Grafana: payment-service error rate graph
# Or via Prometheus query:
# sum(rate(http_requests_total{namespace="payment", status=~"5.."}[2m]))
# / sum(rate(http_requests_total{namespace="payment"}[2m])) * 100
# → Result should be < 0.1 for the last 10 minutes

# VERIFICATION CRITERION 2: P99 latency at baseline (< 500ms)
# Check in Grafana: latency panel
# histogram_quantile(0.99, sum(rate(http_request_duration_seconds_bucket{namespace="payment"}[5m])) by (le))
# → Result should be < 0.5 seconds

# VERIFICATION CRITERION 3: DB connection count well below max
kubectl exec -it <pod-name> -n payment -- \
  psql -h payment-db.payment.svc.cluster.local -U app -c \
  "SELECT count(*), state FROM pg_stat_activity GROUP BY state;"
# active should be < 20; total should be < 50% of max_connections

# VERIFICATION CRITERION 4: Query is using the index (not a full table scan)
kubectl exec -it <pod-name> -n payment -- \
  psql -h payment-db.payment.svc.cluster.local -U app -c \
  "EXPLAIN ANALYZE SELECT * FROM payments WHERE created_at > now() - interval '1 day' LIMIT 100;"
# Should show: "Index Scan using payments_created_at_idx"
# NOT: "Seq Scan on payments" (that's the slow path)

# VERIFICATION CRITERION 5: No new alerts firing
kubectl get prometheusrule -n monitoring -o yaml | grep "payment"
# Check Grafana alerting tab: no active alerts for payment-service

# VERIFICATION CRITERION 6: Downstream services also healthy
kubectl get pods -n orders -l app=orders-service
kubectl top pods -n orders
# orders-service (which calls payment) should be error-free too
```

---

## Step 6: Declare Resolution

Only after ALL verification criteria are met for 10+ consecutive minutes.

```bash
# Post RESOLVED in #incidents:
# "✅ RESOLVED — payment-service SEV2
# 
# Timeline:
#   14:32 UTC — Alert fired (2.3% error rate)
#   14:38 UTC — Rollback to v2.3.1 (service stabilised)
#   15:00 UTC — Root cause confirmed: missing index on payments.created_at
#   15:05 UTC — Index created CONCURRENTLY; v2.3.3 deployed
#   15:12 UTC — All verification criteria met for 10 min
# 
# Current metrics:
#   Error rate: 0.04% (baseline)
#   P99 latency: 120ms (baseline)
#   DB connections: 23/500 (4.6%)
# 
# Incident duration: 40 minutes
# Post-mortem draft: by 2026-07-27
# 
# Action items (tracking in Jira):
#   PAY-1234: Add load test for /api/v2/payments before merge
#   PAY-1235: Add DB connection pool saturation alert
#   PAY-1236: Add DB index review to code review checklist"

# Update status page to "Resolved"
# Resolve PagerDuty incident
# Thank the team in Slack
```

---

## Common Part 7 Mistakes

| Mistake | What Goes Wrong | Correct Approach |
|---|---|---|
| Declaring resolved after rollback (before permanent fix) | Root cause still in codebase; same incident recurs in days or weeks | Rollback = STABILISED; permanent fix deployed + verified = RESOLVED |
| Skipping staging | Permanent fix introduces a new bug; second incident | Always deploy fix to staging first; run a load test; verify the failure no longer reproduces |
| Not writing verification criteria before deploying | After deploy, declare "looks good" without checking anything rigorously | Write specific, measurable criteria before deploying; verify each one by one |
| Running DB migrations inside a transaction | `CREATE INDEX CONCURRENTLY` fails inside a transaction; table locks without CONCURRENTLY | Run `CREATE INDEX CONCURRENTLY` outside a transaction block |
| Closing the incident before 10 min of stable metrics | Metrics look good at minute 3; error rate spikes again at minute 7; team re-opens | 10-minute minimum observation period after permanent fix before declaring resolved |
