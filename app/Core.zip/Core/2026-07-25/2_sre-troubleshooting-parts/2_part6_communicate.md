# SRE Troubleshooting — Part 6: Communicate During an Incident

> **Core rule:** Silent incidents are worse than noisy ones. If you are the Incident Commander and you stop posting updates, everyone assumes either nothing is happening or you are overwhelmed. Post updates on a fixed cadence whether or not you have new information. "Still investigating, no update yet" is a valid update.

---

## Decision Tree — "What do I communicate and when?"

```
"What communication action is needed right now?"
│
├─ First 2 minutes after alert fires:
│   └─ Post in #incidents: open the incident, assign IC, initial impact statement
│
├─ Every time you change something (rollback, scale, config):
│   └─ Post in #incidents BEFORE the action: "Rolling back to v2.3.1 now"
│       Post AFTER the action: "Rollback complete. Watching metrics."
│
├─ Every N minutes (by severity) even if no new info:
│   ├─ SEV1: every 10 minutes
│   ├─ SEV2: every 20 minutes
│   └─ SEV3: every 30 minutes
│
├─ External users are affected (site degraded):
│   └─ Update status page BEFORE posting in Slack
│       External users see the status page; internal team sees Slack
│
├─ You don't know the root cause after 30 minutes:
│   └─ Escalate: page the service owner + engineering manager
│
└─ Service is restored:
    └─ Post RESOLVED in #incidents + update status page + close PagerDuty incident
```

---

## Step 1: Opening Message (Post Within 90 Seconds)

This is the most important message. It establishes ownership, scope, and sets the cadence.

```
TEMPLATE:
────────────────────────────────────────────────────────────────────────
🔴 INCIDENT OPEN
Service:    payment-service (prod-tokyo)
Impact:     HTTP 5xx rate ~2.3%, rising. Payment submission failing.
            Checkout flow partially broken. ~150 errors/min.
Started:    ~14:32 UTC (alert fired 14:32, error visible since ~14:30)
IC:         @ts-shuge.kui
Status:     Investigating. Checking for recent deploys.
Next update: 14:45 UTC
────────────────────────────────────────────────────────────────────────

WHAT TO INCLUDE:
  Service name + environment (prod-tokyo, not just "payment")
  Impact statement (what is broken, how many errors/users)
  When it started (alert time AND observed start time if different)
  Who is the IC (Incident Commander) — one person, clearly named
  When the next update will come — this sets expectations

WHAT TO AVOID:
  Do NOT include: "I think it might be..."  (too uncertain; causes panic)
  Do NOT include: root cause theories (you don't know yet; you'll look wrong)
  Do NOT skip naming the IC (everyone thinks someone else is handling it)
```

---

## Step 2: Action Messages (One Per Action Taken)

Every significant action gets two messages: one BEFORE (what you're about to do) and one AFTER (what happened).

```
BEFORE ACTION:
────────────────────────────────────────────────────────────────────────
[14:35 UTC] INCIDENT UPDATE — payment-service
Action:  Rolling back to v2.3.1 (deploy at 14:21 preceded alert by 11 min)
Reason:  v2.3.2 deploy is the likely cause; rollback is the fastest stabilisation
ETA:     ~5 minutes
────────────────────────────────────────────────────────────────────────

AFTER ACTION:
────────────────────────────────────────────────────────────────────────
[14:38 UTC] INCIDENT UPDATE — payment-service
Action:   Rollback to v2.3.1 complete
Metrics:  Error rate: 2.3% → 1.1% → 0.4% and dropping ✅
Status:   Stabilising. Continuing to watch. Full RCA in progress.
Next update: 14:50 UTC
────────────────────────────────────────────────────────────────────────

WHY TWO MESSAGES:
  BEFORE: team knows what is happening in case you get interrupted
  AFTER:  team knows the outcome; they don't have to ask "did the rollback work?"
```

---

## Step 3: Regular Updates (Fixed Cadence)

Even if nothing has changed, post on schedule. Silence is misinterpreted as lack of progress.

```
UPDATE WHEN NOTHING NEW HAS HAPPENED:
────────────────────────────────────────────────────────────────────────
[14:50 UTC] INCIDENT UPDATE — payment-service
Status:  Error rate at baseline (0.04%) for 12 minutes. Service stable. ✅
Action:  Continuing root cause analysis. DB connection count was 95% at peak.
         Investigating whether v2.3.2 introduced a slow query.
Blocker: None — actively diagnosing.
Next update: 15:05 UTC (or sooner if findings)
────────────────────────────────────────────────────────────────────────

CADENCE RULES:
  SEV1: every 10 min (even if "still investigating")
  SEV2: every 20 min
  SEV3: every 30 min

  WHAT TO PUT IF NOTHING HAS CHANGED:
  → Current state of the key metric (error rate, latency)
  → What you are doing right now
  → What you have ruled out
  → What you still suspect
  → Next update time
```

---

## Step 4: Status Page Updates

The status page is for external users and customers. Update it before posting in Slack.

```
STATUS PAGE UPDATE SEQUENCE:
  1. Incident created → status page: "Investigating" (within 5 min of SEV1, 15 min of SEV2)
  2. Root cause identified → status page: "Identified"
  3. Fix deployed → status page: "Monitoring"
  4. Verified stable → status page: "Resolved"

STATUS DESCRIPTIONS (keep these brief and user-facing):
────────────────────────────────────────────────────────────────────────
Investigating:
  "We are investigating reports of errors with payment processing.
   Some users may experience failed payment submissions.
   We will provide an update within 30 minutes."

Identified:
  "We have identified the cause of the payment processing errors.
   A fix has been rolled back. We are monitoring to confirm full resolution."

Monitoring:
  "The payment processing issue has been addressed.
   Error rates are returning to normal. We are monitoring closely."

Resolved:
  "Payment processing is fully operational. The issue lasted from 14:32 UTC
   to 15:12 UTC. We apologise for the inconvenience. A full post-mortem will be
   published within 48 hours."
────────────────────────────────────────────────────────────────────────

WHAT TO AVOID ON STATUS PAGE:
  ❌ Technical details (no "DB connection pool exhausted")
  ❌ Blame (no "caused by a deploy")
  ❌ Promises you can't keep (no "will be fixed by 15:00")
  ✅ What the user experience is (failed payments, slow checkout)
  ✅ What you are doing about it
  ✅ When you will next update
```

---

## Step 5: Escalation

When to escalate and how.

```
ESCALATION TRIGGERS:
  → Root cause not identified after 30 minutes of active investigation
  → Any data loss confirmed or suspected
  → Cloud provider infrastructure issue (AWS service disruption)
  → Customer/account management is being contacted by key customers
  → On-call engineer is alone and stuck (no progress in 20 min)

ESCALATION MESSAGE (page/Slack to team lead or EM):
────────────────────────────────────────────────────────────────────────
@team-lead — ESCALATION REQUEST
Incident: payment-service SEV2 (30 minutes, ongoing)
Current: Error rate was 2.3%; rolled back; service stable.
         Root cause: not yet confirmed. DB connection pool was near capacity.
         Investigating whether v2.3.2 introduced a slow query.
Need:    SQL query expertise to analyse the DB slow query log.
         Can you join #incidents?
────────────────────────────────────────────────────────────────────────

ESCALATION IS NOT FAILURE:
  Escalating is the correct action when you are stuck.
  Waiting 60 minutes to escalate is the mistake.
  The team lead / service owner is ON CALL for exactly this reason.
```

---

## Step 6: Resolution Message

Declare resolution only after 10+ minutes of stable metrics.

```
RESOLUTION MESSAGE:
────────────────────────────────────────────────────────────────────────
✅ RESOLVED — payment-service SEV2

Timeline:
  14:32 UTC — Alert fired; error rate 2.3%
  14:38 UTC — Rollback to v2.3.1 complete
  14:45 UTC — Error rate at baseline
  15:00 UTC — Root cause confirmed: missing DB index on payments.created_at
  15:05 UTC — Fix PR merged (#1234); deploying to production
  15:12 UTC — Production deploy complete; error rate <0.05% for 10 min

Root cause:
  v2.3.2 introduced a new endpoint that performed a full table scan on
  payments.created_at (no index). Under load, this exhausted the DB
  connection pool, causing 5xx errors across the service.

Fix:
  Rolled back to v2.3.1 (immediate stabilisation)
  Added index: CREATE INDEX CONCURRENTLY payments_created_at_idx ON payments(created_at)
  Deployed v2.3.3 with the fix.

Incident duration: 40 minutes (14:32 – 15:12 UTC)
Post-mortem: draft by 2026-07-27; review by 2026-08-01
────────────────────────────────────────────────────────────────────────

AFTER POSTING RESOLUTION:
  1. Update status page to "Resolved"
  2. Resolve the PagerDuty incident
  3. Add a note to the PagerDuty incident linking to the post-mortem
  4. Update the Jira ticket to RESOLVED
  5. Send a DM to any stakeholders who were watching (account mgmt, eng manager)
```

---

## Incident Communication Channels: Which Goes Where

```
CHANNEL         AUDIENCE            CONTENT
──────────────────────────────────────────────────────────────────────
#incidents      Engineers + SRE     Technical updates, actions, metrics
Status page     External users      User-facing impact + status
PagerDuty       On-call team        Alert metadata + escalation
Jira ticket     Engineering         Root cause + action items
Email           Management          SEV1 only; high-level business impact summary
Account Mgmt    Key customers       SEV1 only; after you have confirmed impact

ORDER:
  1. Status page (users see this first)
  2. #incidents (team coordination)
  3. PagerDuty (pages the right people)
  4. Everything else (once service is restored or being stabilised)
```

---

## Common Part 6 Mistakes

| Mistake | What Goes Wrong | Correct Approach |
|---|---|---|
| Posting in Slack but not updating status page | External users call support; support has no info; escalates unnecessarily | Update status page FIRST; then Slack |
| Not naming an IC in the first message | Multiple engineers start working independently; duplicate actions; "I thought you were checking the DB" | Name the IC in the first message; one person owns the incident |
| Going silent for 20+ minutes during investigation | Team thinks incident is over or IC is overwhelmed; secondary investigation starts in parallel | Post "Still investigating [what you're checking]. No new info. Next update in Xmin." |
| Declaring "resolved" immediately after rollback | Service recovers but a second wave of errors hits 5 min later; "resolved" message looks wrong | Watch for 10 min; declare resolved only after 10 consecutive minutes at baseline |
| Posting root cause theories in early updates | "I think it might be the DB" — if wrong, you've sent 10 engineers to look at the DB | Only state confirmed facts; use "investigating [area]" not "I think it's [area]" |
