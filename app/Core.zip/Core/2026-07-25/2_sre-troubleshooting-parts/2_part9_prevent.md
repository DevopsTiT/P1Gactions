# SRE Troubleshooting — Part 9: Prevent — Harden After Every Incident

> **Core rule:** Every incident is a free lesson about a gap in your system. The post-mortem identifies what the gap is; Part 9 closes it. The goal is to make the same incident physically impossible, or at minimum detectable and auto-mitigated before users are impacted. If you don't act on the post-mortem action items, the incident was not free — it just cost user trust and revenue for nothing.

---

## Decision Tree — "How do I prevent this specific incident from recurring?"

```
"Root cause identified — how do I prevent recurrence?"
│
├─ Did we lack an alert that would have caught it earlier?
│   └─ Add a new Prometheus alert rule + connect to PagerDuty/Slack
│       → The alert should fire BEFORE users are affected (warning before critical)
│
├─ Did a bad deploy reach production without being caught?
│   └─ Add a CI/CD gate:
│       → Load test in CI (catches performance regressions)
│       → checkov/tfsec (catches IaC issues)
│       → Automated smoke test (catches basic functionality regressions)
│       → Staged rollout (canary → catch blast radius before 100% of traffic)
│
├─ Did a manual process fail or get skipped?
│   └─ Automate it:
│       → Auto-remediation (Config rule + SSM automation)
│       → Pre-merge checklist enforced by a bot (not a document)
│       → AFT customization hook (enforced baseline on new accounts)
│
├─ Did the system not recover gracefully when the dependency failed?
│   └─ Add resilience patterns:
│       → Circuit breaker (stop sending requests to a failing dependency)
│       → Retry with exponential backoff (handle transient failures)
│       → Fallback response (return cached data or degraded response instead of error)
│       → Timeout (fail fast instead of hanging)
│
└─ Did a chaos experiment catch this?
    └─ NO → add a chaos experiment that validates the fix
             → Ensure the system actually handles the failure mode it claims to handle
```

---

## Prevention Layer 1 — Add the Alert That Would Have Caught It Earlier

### The DB Connection Pool Alert (from the incident example)

```yaml
# prometheus/rules/payment-alerts.yaml
groups:
  - name: payment.db.rules
    interval: 30s
    rules:

      # Early warning: pool > 70% (before it exhausts)
      - alert: PaymentDBConnectionPoolHigh
        expr: |
          payment_db_pool_connections_active
          /
          payment_db_pool_connections_max
          > 0.70
        for: 2m
        labels:
          severity: warning
          team: payment
          service: payment-service
        annotations:
          summary: "Payment DB connection pool above 70%"
          description: "Pool is {{ $value | humanizePercentage }} utilised. Risk of exhaustion under load."
          runbook: "https://wiki.internal/runbooks/db-connection-pool"
          dashboard: "https://grafana.internal/d/payment-db"

      # Critical: pool > 90% (about to fail)
      - alert: PaymentDBConnectionPoolCritical
        expr: |
          payment_db_pool_connections_active
          /
          payment_db_pool_connections_max
          > 0.90
        for: 1m
        labels:
          severity: critical
          team: payment
          service: payment-service
        annotations:
          summary: "Payment DB connection pool near exhaustion (>90%)"
          description: "Pool is {{ $value | humanizePercentage }} utilised. Failures imminent."
          runbook: "https://wiki.internal/runbooks/db-connection-pool"
```

### Alert Design Rules

```
The "Early Warning" pattern:
  Two thresholds: WARNING at 70–80% (page Slack); CRITICAL at 90%+ (page PagerDuty)
  
  Why two levels:
    Warning at 70% → fires during business hours → team can act before users are impacted
    Critical at 90% → fires immediately → on-call pages → emergency action required

  Always include in annotations:
    summary:     one-line human description (shown in PagerDuty notification)
    description: current value + threshold (helps on-call understand severity immediately)
    runbook:     link to the runbook (on-call knows exactly what to do)
    dashboard:   link to the relevant Grafana panel (saves 2 minutes of navigation)

Alerting gap to close:
  "The alert fired WHEN we were already failing" → threshold too late
  Move the threshold to BEFORE failure:
    Connection pool exhaustion → add pool utilisation alert at 70%
    OOMKill → add memory utilisation alert at 85% of limit
    Disk full → add disk utilisation alert at 80%
    CPU throttling → add CPU utilisation alert at 80% of limit
```

---

## Prevention Layer 2 — Add a CI/CD Gate

### Load Test in CI (catches performance regressions)

```yaml
# .github/workflows/performance-test.yaml
name: Performance Test
on:
  pull_request:
    paths: ['src/**', 'db/migrations/**']

jobs:
  load-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Deploy to staging
        run: |
          kubectl set image deployment/payment-service \
            payment-service=:${{ github.sha }} -n payment-staging

      - name: Wait for rollout
        run: kubectl rollout status deployment/payment-service -n payment-staging --timeout=120s

      - name: Run load test (k6)
        run: |
          k6 run \
            --vus 50 \
            --duration 60s \
            --threshold 'http_req_failed<0.01' \
            --threshold 'http_req_duration{p(99)}<500' \
            tests/load/payment-api.js

      - name: Check DB connection pool (did the test exhaust connections?)
        run: |
          POOL_USAGE=$(kubectl exec -n payment-staging deployment/payment-service -- \
            curl -s localhost:9090/metrics | grep payment_db_pool_connections_active | awk '{print $2}')
          MAX=$(kubectl exec -n payment-staging deployment/payment-service -- \
            curl -s localhost:9090/metrics | grep payment_db_pool_connections_max | awk '{print $2}')
          RATIO=$(echo "scale=2; ${POOL_USAGE}/${MAX}" | bc)
          echo "DB pool usage during load test: ${RATIO}"
          if (( $(echo "${RATIO} > 0.8" | bc -l) )); then
            echo "ERROR: DB connection pool exceeded 80% during load test"
            exit 1
          fi
```

### Code Review Checklist Bot (enforces the process)

```yaml
# .github/pull_request_template.md
## Pre-merge Checklist

### For changes that include new SQL queries:
- [ ] EXPLAIN ANALYZE run on production-scale data (or estimated via EXPLAIN)
- [ ] New query uses an index (not a sequential scan on a large table)
- [ ] Query is paginated (no unbounded SELECT *)
- [ ] Connection pool implications considered (long-running query? lock contention?)

### For changes that include new API endpoints:
- [ ] Load test exists for this endpoint
- [ ] Readiness probe covers this endpoint
- [ ] Circuit breaker/timeout set for any downstream calls

### For all changes:
- [ ] Deployed to staging and smoke-tested
- [ ] Relevant runbook updated if operational procedure changes
- [ ] Alert added if new failure mode introduced
```

---

## Prevention Layer 3 — Add Resilience Patterns

### Circuit Breaker (stop sending to a failing dependency)

```go
// Using go-breaker or sony/gobreaker in Go:
import "github.com/sony/gobreaker"

var cb *gobreaker.CircuitBreaker

func init() {
    cb = gobreaker.NewCircuitBreaker(gobreaker.Settings{
        Name:        "payment-db",
        MaxRequests: 3,          // half-open state: 3 requests to test recovery
        Interval:    10 * time.Second,
        Timeout:     30 * time.Second,    // after tripping, wait 30s before half-open
        ReadyToTrip: func(counts gobreaker.Counts) bool {
            // Trip the breaker if failure rate > 50% over last 10 requests
            failureRatio := float64(counts.TotalFailures) / float64(counts.Requests)
            return counts.Requests >= 10 && failureRatio >= 0.5
        },
        OnStateChange: func(name string, from gobreaker.State, to gobreaker.State) {
            log.Printf("Circuit breaker %s: %s → %s", name, from, to)
        },
    })
}

func queryPayments(ctx context.Context) ([]Payment, error) {
    result, err := cb.Execute(func() (interface{}, error) {
        return db.QueryContext(ctx, "SELECT * FROM payments ...")
    })
    if err == gobreaker.ErrOpenState {
        // Circuit is open — return cached/degraded response instead of error
        return getCachedPayments(), nil
    }
    return result.([]Payment), err
}
```

### Retry with Exponential Backoff

```python
# Python example with tenacity:
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
import psycopg2

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=1, max=10),
    retry=retry_if_exception_type(psycopg2.OperationalError)
)
def query_payments(start_date):
    with get_db_connection() as conn:
        return conn.execute(
            "SELECT * FROM payments WHERE created_at > %s",
            (start_date,)
        ).fetchall()

# Retry only on transient errors (connection errors, timeouts)
# DO NOT retry on business logic errors (wrong data, auth failure)
```

### Timeout Configuration

```yaml
# In Kubernetes deployment:
# Set HTTP timeout on outbound calls to downstream services
# (prevents connection exhaustion when downstream is slow)

apiVersion: apps/v1
kind: Deployment
spec:
  template:
    spec:
      containers:
        - name: payment-service
          env:
            # DB connection timeout (how long to wait for a connection)
            - name: DB_CONNECT_TIMEOUT_SECONDS
              value: "5"
            # DB query timeout (how long a query can run before being cancelled)
            - name: DB_QUERY_TIMEOUT_SECONDS
              value: "10"
            # HTTP client timeout for external API calls
            - name: EXTERNAL_API_TIMEOUT_SECONDS
              value: "5"
            # Connection pool settings
            - name: DB_POOL_MAX_CONNECTIONS
              value: "20"        # don't allow more connections than this
            - name: DB_POOL_MIN_IDLE
              value: "5"         # keep at least 5 idle connections ready
            - name: DB_POOL_MAX_IDLE_TIME_SECONDS
              value: "60"        # return connections to pool after 60s idle
```

---

## Prevention Layer 4 — Add a Chaos Experiment

Verify that the fix actually makes the system more resilient. Don't just assume it does.

```bash
# Using AWS FIS (Fault Injection Simulator) to simulate DB connection exhaustion:

# Create an FIS experiment template to simulate DB latency injection:
cat > /tmp/fis-db-latency.json << 'EOF'
{
  "description": "Simulate DB slow queries to verify circuit breaker behavior",
  "targets": {
    "rdsInstance": {
      "resourceType": "aws:rds:db",
      "resourceTags": {
        "Name": "payment-db-staging"
      },
      "selectionMode": "ALL"
    }
  },
  "actions": {
    "injectLatency": {
      "actionId": "aws:rds:failover-db-cluster",
      "targets": {
        "Clusters": "rdsInstance"
      }
    }
  },
  "stopConditions": [{
    "source": "aws:cloudwatch:alarm",
    "value": "arn:aws:cloudwatch:ap-northeast-1:123456789:alarm:payment-error-rate-critical"
  }],
  "roleArn": "arn:aws:iam::123456789:role/fis-experiment-role"
}
EOF

# Run the experiment in STAGING (never start with production):
aws fis create-experiment-template --cli-input-json file:///tmp/fis-db-latency.json

# EXPECTED OUTCOME AFTER FIX:
#   DB connections spike to 90% → connection pool alert fires ✅
#   Circuit breaker opens after 50% failure rate ✅
#   App returns cached/degraded response instead of 5xx ✅
#   Error rate: < 5% (vs 100% before the fix) ✅
#   When DB recovers: circuit breaker enters half-open → tests → returns to closed ✅

# If the experiment shows the system STILL fails the same way:
#   → The fix didn't actually work as intended
#   → Revisit the resilience implementation before going back to production
```

---

## Prevention Layer 5 — Update the Runbook

The runbook is the on-call engineer's guide for the next time this alert fires.

```markdown
## Runbook: DB Connection Pool Saturation

**Alert:** `PaymentDBConnectionPoolHigh` (warning > 70%) / `PaymentDBConnectionPoolCritical` (critical > 90%)

**Last updated:** 2026-07-25 (after incident INC-4892)

---

### Step 1: Confirm the alert is real (2 minutes)

Check in Grafana: payment-service → DB metrics panel
Is the connection count still rising? If falling, watch for 5 minutes; may auto-recover.

```bash
kubectl exec -it $(kubectl get pods -n payment -l app=payment-service -o jsonpath='{.items[0].metadata.name}') \
  -n payment -- psql -h payment-db.payment.svc.cluster.local -U app -c \
  "SELECT count(*), state FROM pg_stat_activity GROUP BY state ORDER BY count DESC;"
```

### Step 2: Find the cause (5 minutes)

**Scenario A: Idle connections piling up (connection leak)**
```bash
psql -c "SELECT count(*) FROM pg_stat_activity WHERE state='idle' AND query_start < now() - interval '1 minute';"
# > 50 idle connections = leak
# Fix: kill them (Step 3A)
```

**Scenario B: Long-running active queries holding connections**
```bash
psql -c "SELECT pid, now()-query_start AS duration, query FROM pg_stat_activity WHERE state='active' ORDER BY duration DESC LIMIT 5;"
# Duration > 5 seconds = slow query
# Check for missing index: EXPLAIN ANALYZE <the slow query>
```

**Scenario C: Idle-in-transaction (transaction not committed)**
```bash
psql -c "SELECT pid, state, now()-state_change AS duration FROM pg_stat_activity WHERE state='idle in transaction' ORDER BY duration DESC;"
# Duration > 30s = app code not committing/rolling back
```

### Step 3: Take Action

**3A: Kill idle connections**
```bash
psql -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE state='idle' AND query_start < now() - interval '5 minutes';"
```

**3B: Kill idle-in-transaction connections**
```bash
psql -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE state='idle in transaction' AND state_change < now() - interval '1 minute';"
```

**3C: Identify and kill the slow query**
```bash
psql -c "SELECT pg_cancel_backend(<pid>);"   # graceful cancel
# or if that doesn't work:
psql -c "SELECT pg_terminate_backend(<pid>);" # force kill
```

### Step 4: If not resolved in 10 minutes, escalate

Page the payments team lead: @payments-lead in Slack / PagerDuty escalation.

### Step 5: Permanent fix options

- Fix connection leak in application code (add connection.close() / use context manager)
- Reduce pool max size if oversized
- Add DB-level timeout: `SET idle_in_transaction_session_timeout = '30s'`
- Deploy PgBouncer for connection pooling between app and RDS
```

---

## Common Part 9 Mistakes

| Mistake | What Goes Wrong | Correct Approach |
|---|---|---|
| Adding an alert but not testing it | Alert rule has a typo; never fires when the condition occurs | Test every new alert by temporarily forcing the condition in staging |
| Writing a runbook but not linking it to the alert | On-call engineer doesn't know the runbook exists | Add `runbook:` annotation to every PrometheusRule alert; link is in PagerDuty notification |
| Adding a circuit breaker without testing the fallback | Circuit opens; fallback returns empty data; user sees blank page instead of error | Test the fallback path explicitly: force the circuit open, verify user experience |
| Treating the load test as a one-time check | Load test passes today; data grows 10× over a year; same query becomes slow again | Run load tests with production-scale data; run them again after major data growth milestones |
| Not sharing the lessons with other teams | Same root cause (missing index, no circuit breaker) hits a different service next month | Post the post-mortem in a shared channel; run a 30-minute "lessons learned" session cross-team |
