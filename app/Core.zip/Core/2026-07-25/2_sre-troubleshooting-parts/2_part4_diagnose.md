# SRE Troubleshooting — Part 4: Diagnose — Trace from Symptom to Root Cause

> **Core rule:** Diagnose outside-in. Start at the edge (DNS/network), work inward to the load balancer, then to the pod, then to the application code, then to downstream dependencies. The first layer where you find an anomaly is where the problem lives.

---

## Decision Tree — "Which layer is the problem in?"

```
"Service is returning errors — where in the stack is the failure?"
│
├─ Can you reach the service endpoint at all?
│   ├─ curl returns: (6) Could not resolve host → Layer 1: DNS failure
│   ├─ curl returns: (7) Connection refused → Layer 2: ALB or firewall issue
│   └─ curl returns: HTTP response (200/5xx) → DNS and network OK; go deeper
│
├─ What HTTP status code is the ALB returning?
│   ├─ 502 Bad Gateway → ALB can't reach backend pods (wrong port? pods down?)
│   ├─ 503 Service Unavailable → no healthy targets in the target group
│   ├─ 504 Gateway Timeout → backend pods responding too slowly
│   └─ 5xx from the app itself → app-level error; look at pod logs
│
├─ Are pods Running and Ready?
│   ├─ CrashLoopBackOff → pod crash; check logs --previous + describe events
│   ├─ Pending → can't schedule; check node capacity/taints/affinity
│   ├─ Running but READY=0/1 → readiness probe failing; check probe endpoint
│   └─ Running and READY=1/1 → pod is fine; error is in the app logic or downstream
│
└─ Are downstream dependencies healthy?
    ├─ DB connections at/near max → connection pool exhaustion
    ├─ DB CPU > 80% sustained → slow queries; check slow query log
    ├─ Redis cache miss rate high → cache eviction or failover in progress
    └─ External API timeout → third-party incident; check their status page
```

---

## Layer 1: Network and DNS

Always check DNS first. A misconfigured DNS entry can make every other layer look healthy while the service is completely unreachable.

```bash
# Test from outside the cluster (user's perspective):
curl -v --max-time 10 https://payment.company.com/health
# Expected: HTTP 200 {"status":"ok"}
# Got: curl: (6) Could not resolve host → DNS failure
# Got: curl: (28) Operation timed out → network unreachable or firewall
# Got: HTTP 200 → DNS and external access are fine

# DNS lookup:
dig payment.company.com
# Should return: CNAME → ALB DNS name → ALB IP
nslookup payment.company.com 8.8.8.8  # test against public DNS
nslookup payment.company.com           # test against default DNS (in /etc/resolv.conf)

# If DNS fails:
cat /etc/resolv.conf                   # what DNS server is being used?
dig @8.8.8.8 payment.company.com      # bypass local DNS; test against Google
# If Google DNS works but local doesn't → local DNS server issue

# From INSIDE the cluster (pod-to-pod DNS via CoreDNS):
kubectl exec -it <any-running-pod> -n payment -- \
  nslookup payment-service.payment.svc.cluster.local
# Expected: returns ClusterIP of the Kubernetes Service
# "NXDOMAIN" → Service doesn't exist, or wrong namespace, or wrong name

# CoreDNS health:
kubectl get pods -n kube-system -l k8s-app=kube-dns
# All should be Running + READY
# If CoreDNS pods are crashing → ALL service discovery is broken
```

---

## Layer 2: Load Balancer (ALB)

The ALB is the entry point. 502/503/504 codes tell you exactly what's happening between the ALB and the backend pods.

```bash
# Check ALB target group health:
TG_ARN="arn:aws:elasticloadbalancing:ap-northeast-1:123456789012:targetgroup/payment/abc123"
aws elbv2 describe-target-health \
  --target-group-arn ${TG_ARN} \
  --query 'TargetHealthDescriptions[*].{IP:Target.Id,Port:Target.Port,State:TargetHealth.State,Reason:TargetHealth.Reason}' \
  --output table

# Interpretation:
#   State=healthy → ALB successfully health-checked this pod
#   State=unhealthy, Reason=Target.FailedHealthChecks → ALB health check returning non-200
#     → Check: is the /health endpoint working on the pod itself?
#   State=draining → pod is being deregistered (deployment rollout or scale-down)
#   State=unused → pod registered but health check hasn't completed yet (just started)

# Test the ALB health check endpoint from a pod directly:
POD=$(kubectl get pods -n payment -l app=payment-service -o jsonpath='{.items[0].metadata.name}')
kubectl exec -it ${POD} -n payment -- curl -v http://localhost:8080/health
# Expected: HTTP 200
# Got: HTTP 500 → /health endpoint is broken in this version → ALB marks pods unhealthy
# Got: Connection refused → app isn't listening on port 8080 → wrong port config

# Check ALB access logs for error codes (if logging enabled):
# S3 path: s3://your-alb-logs/<prefix>/AWSLogs/<account-id>/elasticloadbalancing/...
aws s3 ls s3://your-alb-logs/ --recursive | tail -5
aws s3 cp s3://your-alb-logs/<latest-log-file> /tmp/alb.log
grep " 502 \| 503 \| 504 " /tmp/alb.log | tail -20
# 502 = ALB connected to backend but backend rejected (wrong port, pod not ready)
# 504 = ALB connected but backend timed out (slow response > ALB timeout setting)
```

---

## Layer 3: Kubernetes Service and Pods

```bash
# Check Service endpoints (are pods registered?):
kubectl get endpoints payment-service -n payment
# Expected: 10.0.16.5:8080,10.0.48.3:8080,10.0.80.7:8080
# Got: <none> → NO healthy pods match the Service selector
#   → Check: Service selector vs Pod labels:
kubectl get svc payment-service -n payment -o jsonpath='{.spec.selector}'
# Returns: {"app":"payment-service"}
kubectl get pods -n payment --show-labels | grep payment-service
# Do any pods have "app=payment-service" label? If not → label mismatch

# Full pod status:
kubectl get pods -n payment -o wide
# Columns:
#   NAME          = pod name (includes ReplicaSet hash)
#   READY         = container count that passed readiness / total containers
#   STATUS        = Running/CrashLoopBackOff/Pending/Terminating/OOMKilled
#   RESTARTS      = how many times this pod has restarted
#   NODE          = which node it's scheduled on (useful for node-level issues)

# Describe a specific problem pod (gold mine of information):
kubectl describe pod <pod-name> -n payment
# KEY SECTIONS:
#   Conditions:
#     Ready: True/False
#     ContainersReady: True/False
#   Containers:
#     State: Running/Waiting/Terminated
#     Exit Code: 0=normal / 1=error / 137=OOMKill / 139=segfault
#     Reason: OOMKilled / Error / Completed
#     Restart Count: how many restarts
#     Limits: cpu/memory limits
#     Requests: cpu/memory requests
#   Events: (most useful section)
#     Warning BackOff    = CrashLoopBackOff confirmed
#     Warning OOMKilled  = memory limit exceeded
#     Warning Failed     = image pull failed / readiness failed
#     Warning Unhealthy  = liveness/readiness probe failing

# Check resource usage:
kubectl top pods -n payment
# If CPU near limit → throttling → slow responses → timeouts
# If memory near limit → OOMKill imminent

kubectl top nodes
# If node CPU/memory near capacity → pods can't get resources
```

---

## Layer 4: Application Logs

The logs tell you what the application itself saw. This is where you find the specific error.

```bash
# Stream recent logs (last 5 minutes):
kubectl logs -n payment -l app=payment-service --since=5m
# Use -l (label selector) to get logs from ALL pods simultaneously

# Follow live (tail -f equivalent):
kubectl logs -n payment -l app=payment-service -f --max-log-requests=10

# Get logs from the crashed previous container (for CrashLoopBackOff):
kubectl logs -n payment <pod-name> --previous
# This shows the logs from the container BEFORE the most recent restart
# Essential for CrashLoopBackOff — current run is too short to show the error

# Filter for errors only:
kubectl logs -n payment -l app=payment-service --since=5m \
  | grep -iE "error|exception|fatal|panic|failed|timeout"

# Count error types (find the most frequent error):
kubectl logs -n payment -l app=payment-service --since=10m \
  | grep -i "ERROR" \
  | sed 's/.*ERROR: //' \
  | sort | uniq -c | sort -rn | head -10
# Output shows frequency of each unique error message

# Common log patterns and what they mean:
#   "connection refused :5432"          → cannot reach PostgreSQL
#   "dial tcp: i/o timeout"             → cannot reach any TCP endpoint (DB, Redis, API)
#   "context deadline exceeded"          → request to downstream took longer than timeout
#   "no such host"                       → DNS resolution failure to downstream service
#   "connection pool exhausted"          → DB connection pool is full
#   "too many open files"                → file descriptor limit hit
#   "OOM" / "out of memory"             → application-level memory error (before OOMKill)
#   "certificate has expired"            → TLS cert expired on this service or a dependency
#   "SQLSTATE 57014: canceling statement" → PostgreSQL query timeout (statement_timeout)
#   "redis: connection refused"          → Redis is down or unreachable
```

---

## Layer 5: Downstream Dependencies

If the app logs show connection errors to a downstream service (DB, Redis, external API), diagnose that layer next.

### Database (PostgreSQL / RDS)

```bash
# Test connectivity from a pod:
kubectl exec -it <pod-name> -n payment -- \
  bash -c "nc -zv payment-db.payment.svc.cluster.local 5432 && echo TCP_OK"
# TCP_OK → network is fine; issue is at DB level
# Connection refused → DB pod is down or port is wrong
# Timeout → network policy blocking, or DB is overloaded

# Check DB connection count (from a pod with psql):
kubectl exec -it <pod-name> -n payment -- \
  psql -h payment-db.payment.svc.cluster.local -U app -c \
  "SELECT count(*), state FROM pg_stat_activity GROUP BY state ORDER BY count DESC;"
# Expected: idle: 5-10, active: 1-3
# HIGH idle: connection leak (connections not returned to pool)
# HIGH active: concurrent queries; DB overloaded; slow queries holding connections

# Check active queries (find slow queries):
kubectl exec -it <pod-name> -n payment -- \
  psql -h payment-db.payment.svc.cluster.local -U app -c \
  "SELECT pid, now()-query_start AS duration, state, query
   FROM pg_stat_activity
   WHERE state='active'
   ORDER BY duration DESC
   LIMIT 10;"
# duration > 5s = slow query (likely missing index or full table scan)

# AWS RDS metrics via CloudWatch:
aws cloudwatch get-metric-statistics \
  --namespace AWS/RDS \
  --metric-name DatabaseConnections \
  --dimensions Name=DBInstanceIdentifier,Value=payment-db-prod \
  --start-time $(date -u -v-30M +%Y-%m-%dT%H:%M:%S 2>/dev/null || date -u --date='-30 minutes' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 60 \
  --statistics Average \
  --output table

# Key RDS metrics and thresholds:
# DatabaseConnections   > 80% of max_connections = CRITICAL (pool exhaustion imminent)
# CPUUtilization        > 80% sustained = slow queries consuming CPU
# FreeableMemory        < 512MB = memory pressure; query plans may degrade
# ReadLatency           > 20ms average = IOPS issue (disk saturation or wrong instance class)
# WriteLatency          > 20ms average = same
# DiskQueueDepth        > 1 = IO bottleneck
# ReplicaLag            > 30s = replica is behind primary (check if reads hit stale replica)
```

### Redis / ElastiCache

```bash
# Test connectivity:
kubectl exec -it <pod-name> -n payment -- \
  redis-cli -h payment-cache.payment.svc.cluster.local ping
# Expected: PONG
# Connection refused → Redis is down
# Timeout → network issue or Redis overloaded

# Check cache metrics:
kubectl exec -it <pod-name> -n payment -- \
  redis-cli -h payment-cache.payment.svc.cluster.local info stats \
  | grep -E "keyspace_hits|keyspace_misses|evicted_keys"
# keyspace_hits:   100000
# keyspace_misses:  5000    ← miss rate = 5000/(100000+5000) = ~4.8% (normal)
# evicted_keys:     1000    ← keys being evicted = cache is full; maxmemory reached

# High evicted_keys = cache is evicting data under memory pressure
# → all evicted keys become misses → DB gets all those queries → DB overloaded → cascade

# Check Redis memory:
kubectl exec -it <pod-name> -n payment -- \
  redis-cli -h payment-cache.payment.svc.cluster.local info memory \
  | grep -E "used_memory_human|maxmemory_human|mem_fragmentation_ratio"
```

### External API

```bash
# Test the external API from inside the cluster:
kubectl exec -it <pod-name> -n payment -- \
  curl -v --max-time 10 https://api.payment-provider.com/health

# Check if there is a provider incident:
# → Search the provider's status page: status.payment-provider.com
# → Check AWS Service Health if it's an AWS service

# Check if it's a DNS issue vs connectivity issue:
kubectl exec -it <pod-name> -n payment -- \
  nslookup api.payment-provider.com
# If NXDOMAIN → DNS failure; check /etc/resolv.conf in the pod
# If returns IP → DNS OK; the IP is unreachable → network/firewall issue
```

---

## Building the Root Cause Hypothesis

After gathering data from all layers, form a specific hypothesis:

```
EVIDENCE COLLECTED:
  Layer 1 (DNS):       OK — payment.company.com resolves correctly
  Layer 2 (ALB):       OK — 2/3 targets healthy; 1 target unhealthy
  Layer 3 (K8s):       1 pod in CrashLoopBackOff; other 2 pods Running+Ready
  Layer 4 (App logs):  ERROR: "connection to DB refused" — appears on the crashing pod
  Layer 5 (DB):        DB pod is running; but connection count at 95% of max

HYPOTHESIS:
  The DB connection pool is near exhaustion.
  The crashing pod's health check fails because it can't get a DB connection to verify health.
  The ALB marks it unhealthy → stops sending traffic → that pod goes into CrashLoopBackOff.
  The other 2 pods are OK because they happened to get DB connections before the pool filled.

ROOT CAUSE:
  The new feature in v2.3.2 introduced a query that holds DB connections open for 15+ seconds
  (missing index → full table scan → slow query → connection held).
  Under normal load: 3 connections × 15s hold = 45 connection-seconds per minute → fine.
  Under Monday morning traffic spike: connections exhausted within 2 minutes.

FIX:
  Short-term: rolled back to v2.3.1 (connection leak removed)
  Long-term: add index on payments.created_at; add DB connection pool monitoring alert
```

---

## Common Part 4 Mistakes

| Mistake | What Goes Wrong | Correct Approach |
|---|---|---|
| Starting diagnosis at Layer 4 (logs) instead of Layer 1 | Spend 20 min reading logs on pods that are healthy; miss a DNS or ALB issue | Always check network/DNS first; work inward |
| Not checking endpoints object | All pods Running+Ready but no traffic → Service selector doesn't match pod labels | Always check `kubectl get endpoints` when traffic isn't reaching pods |
| Reading only the most recent log lines | Miss the root cause (it appeared 5 min ago before the crash loop started) | Use `--previous` for crashed pods; use `--since=10m` for context |
| Making multiple changes and not waiting | Changed 3 things simultaneously; metrics improved; you don't know which one worked | One change at a time; wait for metrics to respond before the next change |
| Checking DB metrics in isolation | DB CPU at 80% looks bad; but it's because the app is sending 100× normal queries | Always correlate DB metrics with app-side metrics (query rate, error type) |
