# SRE Troubleshooting — Part 10: The SRE Troubleshooting Mindset

> **Core rule:** Troubleshooting is a skill that improves with deliberate practice. The best SREs are not the ones who know all the answers — they are the ones who ask the right questions, change only one variable at a time, and know when to escalate rather than continue guessing.

---

## The Five Questions — Ask at Every Stage

These five questions apply at any point in an incident. If you are stuck, work through them in order.

```
1. WHAT CHANGED?
   → Before any diagnosis, check what changed in the last 30 minutes
   → Deploys, config changes, infrastructure changes, traffic spikes, cloud provider events
   → Most incidents have a "change trigger." Find it first.
   → If nothing changed: this is a capacity/growth problem or an intermittent issue

2. WHAT IS THE BLAST RADIUS?
   → How many users/requests/services are affected?
   → Is it growing or stable?
   → A growing blast radius requires immediate stabilisation (Part 3)
   → A stable blast radius gives you time to diagnose

3. WHERE DOES THE SIGNAL START?
   → Trace from the edge inward: internet → CDN → ALB → service → pod → downstream
   → The first layer where you see an anomaly is where the problem lives
   → Don't start in the middle — start at the edge and work inward

4. WHAT IS THE FASTEST PATH TO RESTORE SERVICE?
   → Rollback is almost always faster than debugging + fixing
   → Don't diagnose a burning building — roll back first, understand second
   → "Can I restore service in under 5 minutes?" If yes: do it now
   → "Will diagnosing take more than 5 minutes?" If yes: stabilise first

5. HOW DO I KNOW WHEN IT'S RESOLVED?
   → Define your verification criteria BEFORE taking action
   → "Error rate < 0.1% for 10 consecutive minutes" is a criterion
   → "It looks better" is not a criterion
   → Never declare resolved based on subjective assessment alone
```

---

## The OODA Loop — Your Mental Model for Diagnosis

Every diagnostic action follows this loop. One loop = one hypothesis test.

```
OBSERVE → ORIENT → DECIDE → ACT → (back to OBSERVE)

OBSERVE:
  Gather data without forming conclusions yet.
  → kubectl get pods; kubectl logs; Grafana error rate; DB connections
  → Look at all the data; don't stop at the first thing that looks suspicious

ORIENT:
  Form a specific, testable hypothesis.
  → "I think the DB is slow because the connection pool is exhausted"
  → "I think the pod is OOMKilled because memory usage is near the limit"
  → The hypothesis must be falsifiable: you can be proved wrong

DECIDE:
  Choose ONE action that tests the hypothesis.
  → "I will check pg_stat_activity to see if connections are at max"
  → "I will check kubectl describe pod to see if exit code is 137"
  → ONE action — not three simultaneous changes

ACT:
  Execute the action.

OBSERVE again:
  Did the result match your hypothesis?
  → If YES: hypothesis confirmed → take the corrective action
  → If NO: discard the hypothesis → form a new one (back to ORIENT)
  → If PARTIAL: the hypothesis was partially right → refine it

KEY RULE: ONE CHANGE AT A TIME.
  If you change three things simultaneously and the problem resolves,
  you don't know which one fixed it, which ones had no effect,
  and which ones may have introduced new risk.
```

---

## The Diagnostic Loop in Practice

```
INCIDENT: payment-service error rate 2.3%

LOOP 1:
  Observe: error rate 2.3%, started at 14:32, growing slightly
  Orient:  Hypothesis: a recent deploy caused the errors
  Decide:  Check: was there a deploy in the last 30 minutes?
  Act:     kubectl rollout history deployment/payment-service -n payment
  Observe: YES — v2.3.2 deployed at 14:21, 11 min before alert
  → Hypothesis CONFIRMED → rollback

LOOP 2:
  Observe: rolled back; error rate: 2.3% → 1.1% → 0.4% → 0.04% ✅
  Orient:  Service is stable. Need to find root cause for permanent fix.
           Hypothesis: the new endpoint /api/v2/payments caused DB slowdown
  Decide:  Run EXPLAIN ANALYZE on the new query
  Act:     psql -c "EXPLAIN ANALYZE SELECT * FROM payments WHERE created_at > ..."
  Observe: "Seq Scan on payments (cost=0.00..850000.00 rows=50000000)"
           → full table scan confirmed; 50M rows; no index
  → Hypothesis CONFIRMED → add index

LOOP 3:
  Observe: CREATE INDEX CONCURRENTLY started; v2.3.3 deployed
  Orient:  Hypothesis: adding the index will reduce query time below 100ms
  Decide:  Re-run EXPLAIN ANALYZE after index is created
  Act:     psql -c "EXPLAIN ANALYZE SELECT * FROM payments WHERE created_at > ..."
  Observe: "Index Scan using payments_created_at_idx (cost=0.56..9.42 rows=1000)"
           ← 100,000× faster; uses index
  → Hypothesis CONFIRMED → incident resolved
```

---

## Things That Waste Time During Incidents

```
❌ Trying to fix the bug instead of rolling back:
   "Let me just add the index and redeploy" → takes 20 minutes
   Rollback → takes 5 minutes → 15 minutes less user impact
   Principle: stabilise first; fix second

❌ Debugging without checking for recent changes:
   Spend 30 minutes checking DB, network, logs
   Someone finally mentions: "oh, we deployed 20 minutes ago"
   30 minutes wasted. Always check changes FIRST.

❌ Making multiple changes simultaneously:
   "I'll rollback AND scale up AND change the config at the same time"
   Problem resolves → which change fixed it? → don't know → can't write the post-mortem
   → Can't reproduce the fix reliably
   One change at a time.

❌ Not posting updates → parallel investigations:
   Engineer A is investigating the DB; Engineer B starts investigating the same DB
   without knowing Engineer A is doing it. Double work, conflicting findings.
   Post in #incidents: "I'm checking the DB." Others know to look elsewhere.

❌ Giving up after one failed approach without re-evaluating:
   "DB looks fine, must be something else" → checks network → checks pods →
   comes back to DB 40 minutes later and finds the actual DB issue.
   When a hypothesis is wrong: explicitly discard it, form a new one, record both.

❌ Fixing symptoms without understanding root cause:
   kubectl delete pod <crashing-pod>
   → pod comes back; crashes again immediately
   → deleted it again → still crashing
   Deleting a pod doesn't fix what's causing it to crash.
   Read the logs; find the cause.

❌ Declaring resolved too soon (before 10-minute stable period):
   "Error rate is back to 0% — I'll declare it resolved"
   3 minutes later: errors return (intermittent issue)
   → Reopened incident; looks bad; you lost the timeline continuity
   10-minute minimum stable period before declaring resolved.
```

---

## Building a Personal Troubleshooting Checklist

After every incident, add what you learned to your personal checklist. Over time, this becomes your incident playbook.

```
PERSONAL CHECKLIST — Running Template

FIRST 2 MINUTES:
  □ Read the alert: WHAT, WHERE, WHEN, HOW BAD, TREND
  □ Check Grafana: still elevated? growing?
  □ Post in #incidents: IC named, impact stated, next update time
  □ Check recent changes (deploys, config, infrastructure, cloud provider health)

TRIAGE (< 5 min):
  □ Is this real (not a flapping probe)?
  □ What % of requests are failing?
  □ Growing or stable?
  □ One service or cascading?
  □ Classify severity: SEV1/2/3/4

STABILISE (if needed):
  □ Recent deploy? → rollback immediately
  □ CPU/memory saturated? → scale out
  □ One feature? → disable via config flag
  □ Watch 10 min after action before declaring stable

DIAGNOSE (outside-in):
  □ Layer 1: DNS resolves? curl returns what HTTP code?
  □ Layer 2: ALB target health? 502/503/504 breakdown?
  □ Layer 3: kubectl get pods — any non-Running status?
  □ Layer 3: kubectl describe pod — events at bottom
  □ Layer 4: kubectl logs --since=5m | grep ERROR
  □ Layer 4: kubectl logs <pod> --previous (for CrashLoopBackOff)
  □ Layer 5: nc -zv <db-host> <port>; pg_stat_activity; redis ping

COMMUNICATE:
  □ SEV1: update every 10 min
  □ SEV2: update every 20 min
  □ Status page updated before each Slack update
  □ Post BEFORE and AFTER each action taken

RESOLVE:
  □ Root cause identified
  □ Permanent fix deployed and tested in staging first
  □ Verification criteria defined AND met (error rate < 0.1% for 10 min)
  □ Resolution posted in #incidents
  □ Status page set to Resolved
  □ PagerDuty incident resolved

POST-MORTEM:
  □ Draft within 48 hours
  □ Timeline reconstructed from Slack + git
  □ Five Whys applied to root cause
  □ Action items: specific + owner + due date + Jira ticket
  □ Review meeting scheduled

PREVENT:
  □ Alert added for early warning
  □ CI/CD gate added for this failure class
  □ Runbook written or updated
  □ Chaos experiment added (validates the fix works)
```

---

## Escalation Is a Skill, Not a Failure

```
WHEN TO ESCALATE:
  → Root cause not identified after 30 minutes of active investigation
  → You're the only one looking at it and you're stuck
  → Data loss is suspected or confirmed
  → Cloud provider involvement suspected
  → The scope is larger than you originally assessed (cascade starting)

HOW TO ESCALATE:
  1. Post what you KNOW (confirmed facts, not theories)
  2. Post what you have TRIED and RULED OUT
  3. Post what you NEED (a specific expert skill, more resources)
  4. Post the escalation concisely: "I've been investigating X for 30 min.
     I've ruled out Y and Z. I need help with [specific thing].
     Can @[person] join?"

WHY PEOPLE DELAY ESCALATION:
  → "I should be able to figure this out myself" → pride
  → "I don't want to bother them at 3am" → consideration
  → "I almost have it, 10 more minutes" → optimism bias

ALL THREE ARE MISTAKES.
  The on-call engineer who escalated after 5 minutes of being stuck
  costs the expert 15 minutes.
  The on-call engineer who waited 60 minutes costs users 50 minutes more.
  Escalation is a tool; use it.
```

---

## Common Part 10 Mistakes

| Mistake | What Goes Wrong | Correct Approach |
|---|---|---|
| Skipping the OODA loop — acting on the first hypothesis | Fix the wrong thing; incident continues; morale drops | Form a hypothesis, test it, confirm or discard; THEN act on the fix |
| Making multiple changes simultaneously | Don't know what worked; can't write the post-mortem; can't reproduce the fix | One change at a time; wait for metrics to respond; log every action |
| Treating troubleshooting as a solo activity | Get stuck alone; no fresh perspective; escalation delayed too long | Post every finding in #incidents; others can spot patterns you missed |
| Not maintaining a personal checklist | Same mistakes repeated incident after incident | After every incident: note what question you should have asked first; add it to your checklist |
| Treating escalation as admitting defeat | Delay escalation; incident drags on; users impacted longer | Escalation is a professional tool; use it before 30 minutes of being stuck |
