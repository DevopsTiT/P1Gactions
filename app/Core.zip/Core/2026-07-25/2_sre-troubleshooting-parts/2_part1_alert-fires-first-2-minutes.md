# SRE Troubleshooting — Part 1: Alert Fires — The First 2 Minutes

> **Core rule:** The first 2 minutes after an alert fires are the most important. Do three things in parallel: understand the signal, open the incident channel, and check if service is still degrading or recovering. Do NOT start fixing anything until you know what you are dealing with.

---

## Decision Tree — "Alert just fired — what do I do first?"

```
"PagerDuty woke me up at 3am — what do I do right now?"
│
├─ Step 1: Read the alert title and body (30 seconds)
│   → What service? What metric? Since when? How bad?
│   → Is this the first time this alert fired, or is it flapping?
│
├─ Step 2: Check if it is still actively failing (30 seconds)
│   → Open Grafana → is the error rate still elevated RIGHT NOW?
│   → If already recovering: watch for 5 more minutes before declaring false alarm
│
├─ Step 3: Open the incident (30 seconds)
│   → Post in #incidents Slack channel
│   → Assign yourself as Incident Commander
│   → Note the exact time you started
│
├─ Step 4: Classify severity (30 seconds)
│   ├─ SEV1: full outage / data loss risk / payment processing down → page immediately
│   ├─ SEV2: major feature broken / >10% error rate               → investigate now
│   ├─ SEV3: partial degradation / <5% error rate                 → investigate this hour
│   └─ SEV4: edge case / minor / no revenue impact                → ticket; fix in hours
│
└─ Step 5: Decide — stabilise or diagnose?
    ├─ If deploy was < 30 min ago → rollback FIRST (Part 3), diagnose second
    └─ If no recent deploy → start diagnosis (Part 4)
```

---

## Step 1: Read the Alert — Extract the 5 Ws

Every alert fires with a title and a body. Read both fully before doing anything else.

```
EXAMPLE ALERT (PagerDuty notification):
─────────────────────────────────────────────────────────────────
ALERT:   PaymentService 5xx rate > 1% for 5 minutes
SERVICE: payment-service (namespace: payment, cluster: prod-tokyo)
METRIC:  http_requests_total{status=~"5.."} / http_requests_total = 0.023
STARTED: 2026-07-25 14:32:17 UTC
RUNBOOK: https://wiki.internal/runbooks/payment-5xx
─────────────────────────────────────────────────────────────────

EXTRACT THE 5 Ws:
  WHAT:   HTTP 5xx error rate above threshold
  WHERE:  payment-service, namespace=payment, prod-tokyo cluster
  WHEN:   started at 14:32 UTC (8 minutes ago as of reading this)
  HOW BAD: 2.3% error rate — roughly 2-3× the alert threshold of 1%
  TREND:  still elevated (the for:5m means it has been elevated for at least 5 minutes)

QUESTIONS TO ANSWER IN THE NEXT 2 MINUTES:
  Is it still 2.3% or has it grown? (open Grafana)
  Is it ALL endpoints or one specific path? (check labels)
  Was there a deploy recently? (check ArgoCD/CI)
  Is there a cloud provider incident? (check AWS Health Dashboard)
```

---

## Step 2: Open the Dashboard — Understand the Timeline

The dashboard answers: when did it start, how fast is it growing, and what else changed at the same time?

```bash
# Open Grafana → payment-service overview dashboard
# URL pattern: https://grafana.internal/d/payment-overview

# What to look at in the first 60 seconds:
```

### Error Rate Graph

```
Look for the shape:
  Sudden vertical spike   → instantaneous failure (bad deploy, config change, network event)
  Gradual rise            → capacity problem or slow leak (connection pool, memory)
  Oscillating on/off      → flapping health check, partial node failure
  Spike then recovery     → transient issue (GC pause, brief overload, pod restart)

TIMELINE MATTERS:
  Spike at 14:21 → deploy was at 14:19 → rollback first
  Spike at 14:21 → no deploy; latency also spiked at 14:20 → investigate DB
  Spike at 14:21 → traffic also spiked 2× at 14:20 → capacity problem
```

### The Four Panels to Check Immediately

```
Panel 1: Error Rate (%)
  → Is it > 1%? > 5%? > 50%? (determines severity)
  → Is it growing, stable, or recovering?

Panel 2: Request Rate (RPS)
  → Did traffic double? (capacity problem)
  → Did traffic drop to zero? (DNS failure, all pods down)
  → Is traffic normal? → then it's an app or dependency problem

Panel 3: P99 Latency
  → If latency spiked BEFORE errors: timeouts are causing errors
  → If latency is normal but errors are high: fast failures (auth error, bad config)
  → If both spiked at same time: external dependency went down

Panel 4: Deployment events (blue markers at bottom of chart)
  → Is there a deploy marker within 30 minutes of the error spike?
  → If YES → the deploy is almost certainly the cause → rollback now
```

---

## Step 3: Open the Incident Channel

This is not optional, even if you think you'll fix it in 5 minutes. Incidents that "look small" can cascade. The channel creates a timestamped record.

```
FIRST MESSAGE (post within 90 seconds of alert):
──────────────────────────────────────────────────────────────────────
🔴 INCIDENT OPEN — PaymentService 5xx Degradation
Started:    ~14:32 UTC
IC:         @ts-shuge.kui (that's me — I'm coordinating)
Impact:     Payment 5xx rate ~2.3% and rising. Checkout may be affected.
Status:     Investigating. Checking for recent deploys.
Next update: 14:45 UTC
──────────────────────────────────────────────────────────────────────

WHY THIS MATTERS:
  → Tells the team something is happening (they stop wondering why metrics look odd)
  → Assigns clear ownership (no "I thought you were handling it")
  → Creates a timeline (the timestamp on this message is the incident start)
  → Tells management and support who to contact

ROLES TO ASSIGN:
  IC (Incident Commander):  you — coordinates all actions; owns the timeline
  CW (Comms Writer):        one other person — posts status page updates + stakeholder pings
  SME (Subject Expert):     the service owner team — called in if you can't identify root cause
  Scribe:                   (optional) — takes notes in a doc so nothing is lost
```

---

## Step 4: Classify Severity

Severity determines how you respond: who you page, how often you update, whether you need a post-mortem.

```
SEV1 — Critical (page everyone, immediately)
  → Full service outage: payment processing 100% down
  → Data loss in progress or imminent
  → Security breach
  → SLO burn rate so fast the month's budget will be exhausted today
  → Action: page team lead + engineering manager NOW; update status page within 5 min

SEV2 — High (investigate now, page the team)
  → Major feature broken: error rate > 10%
  → SLO at risk of being breached this week
  → Specific user segment completely blocked
  → Action: focus entirely on this; update stakeholders every 20 min

SEV3 — Medium (investigate within the hour)
  → Partial degradation: error rate 1-5%; workaround exists
  → Single non-critical endpoint affected
  → Performance degradation (slow but not failing)
  → Action: work through shift; update at regular check-ins

SEV4 — Low (ticket; fix in hours)
  → Single user or edge case
  → No revenue or SLO impact
  → Cosmetic / minor UX issue
  → Action: create Jira ticket; no immediate page needed
```

---

## Step 5: Check for Recent Changes

The single most time-saving question in any incident: **what changed recently?**

```bash
# Check recent deployments (ArgoCD):
# ArgoCD UI → Applications → payment-service → HISTORY tab
# Look for any deploy in the last 30 minutes

# Check from CLI (if ArgoCD CLI is available):
argocd app history payment-service --namespace argocd | head -5

# Check Git history for the service:
git log --oneline --since="1 hour ago" -- apps/payment-service/

# Check Kubernetes deployment history:
kubectl rollout history deployment/payment-service -n payment
# Look for: any revision change in the last 30 min (check timestamp)

# Check for config/secret changes:
kubectl get events -n payment --sort-by='.metadata.creationTimestamp' | tail -20
# Look for: "Updated" or "Patched" events on ConfigMaps, Secrets, Deployments

# Check AWS Health Dashboard:
aws health describe-events \
  --filter '{"eventStatusCodes": ["open","upcoming"]}' \
  --query 'events[*].[service,region,eventTypeCode,statusCode]' \
  --output table

# Check AWS Service Health for Tokyo region (ap-northeast-1):
# https://health.aws.amazon.com/health/status
```

---

## Step 6: Record Everything from the Start

Your incident timeline is built from the messages you send in Slack + the notes you take. Be obsessive about timestamps.

```
INCIDENT LOG TEMPLATE (keep a running note):

14:32  Alert fired: PaymentService 5xx > 1%
14:33  Grafana: error rate 2.3%, rising. Traffic normal. Latency elevated.
14:34  ArgoCD: payment-service v2.3.2 deployed at 14:21 (11 min before alert)
14:35  Decision: rolling back to v2.3.1
14:38  Rollback complete. Watching metrics.
14:41  Error rate dropping: 2.3% → 1.1% → 0.4% → 0.1%
14:45  Error rate at baseline (0.04%). Service stable.
14:46  INCIDENT CHANNEL: "Error rate at baseline. Continuing RCA investigation."

This log becomes the TIMELINE section of the post-mortem.
Save it — it takes 30 seconds to keep notes but 2 hours to reconstruct after the fact.
```

---

## Real Example: Reading an Alert Correctly

```
ALERT RECEIVED:
  Title: "PaymentService p99 latency > 2s"
  Body:  histogram_quantile(0.99) = 4.2s, threshold = 2s
  Duration: for 3 minutes

WRONG interpretation: "Latency is high, let me check the DB"
  → Jumps straight to DB without checking the big picture

CORRECT interpretation:
  1. Read the alert: p99 latency 4.2s (2× the threshold of 2s)
  2. Open Grafana: WHEN did it start?
     → Latency spiked at 14:18 UTC
  3. What else changed at 14:18?
     → Traffic spiked 3× at 14:17 (viral social media post)
     → DB connections spiked to 95% of max at 14:18
     → Error rate spiked at 14:20 (2 min after latency)
  4. Root cause before even running a command:
     Traffic spike → DB connections exhausted → queries slow → timeouts → errors
  5. Action: scale out app pods (reduce per-pod DB load) + scale DB read replica

The alert title ("p99 latency") was the symptom, not the cause.
Reading the timeline in Grafana revealed the cause.
```

---

## Common Part 1 Mistakes

| Mistake | What Goes Wrong | Correct Approach |
|---|---|---|
| Starting diagnosis before opening the incident channel | 20 minutes of silent investigation; team thinks nobody is working on it | Post in #incidents FIRST, before any kubectl command |
| Accepting the alert title as the root cause | "Latency alert" → debug latency → miss that DB connections are 100% → wrong fix | Alert title = symptom; root cause requires investigation |
| Not checking for recent changes | Spend 45 min on DB investigation; the cause was a deploy 10 min before the alert | Always check ArgoCD/deploy history FIRST — it's the most common cause |
| Skipping severity classification | No escalation when needed; wrong update cadence; team under/over-responds | Classify within the first 2 minutes; adjust as you learn more |
| Closing the alert without watching for 10 min | Service looks recovered; on-call goes back to sleep; issue recurs | Always watch the dashboard for 10 minutes after apparent recovery |
