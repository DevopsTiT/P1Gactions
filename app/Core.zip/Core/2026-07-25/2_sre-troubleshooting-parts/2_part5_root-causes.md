# SRE Troubleshooting — Part 5: Common Root Causes and Their Fingerprints

> **Core rule:** Every root cause has a fingerprint — a specific pattern of symptoms in logs, metrics, and kubectl output that uniquely identifies it. Learn the fingerprints and you can diagnose in minutes instead of hours.

---

## Decision Tree — "What root cause matches this fingerprint?"

```
"I see these symptoms — which root cause is it?"
│
├─ kubectl get pods shows STATUS = OOMKilled or CrashLoopBackOff
│   AND kubectl describe shows Exit Code: 137
│   → Root Cause: OOMKill (Part 5.1)
│
├─ kubectl get pods shows STATUS = CrashLoopBackOff
│   AND kubectl logs --previous shows app error at startup
│   → Root Cause: CrashLoopBackOff / bad startup (Part 5.2)
│
├─ kubectl get pods shows STATUS = Pending
│   AND kubectl describe shows "0/N nodes available"
│   → Root Cause: Pod scheduling failure (Part 5.3)
│
├─ kubectl get pods shows READY = 0/1 (Running but not Ready)
│   AND kubectl describe shows "Readiness probe failed"
│   → Root Cause: Readiness probe failing (Part 5.4)
│
├─ App logs show "connection pool exhausted" or "too many clients"
│   AND DB connections near max_connections
│   → Root Cause: DB connection pool exhaustion (Part 5.5)
│
├─ App logs show "no space left on device"
│   AND df -h on the node shows 100% full
│   → Root Cause: Disk full (Part 5.6)
│
└─ App logs show "certificate has expired" or TLS handshake error
    → Root Cause: Expired TLS certificate (Part 5.7)
```

---

## Root Cause 5.1 — OOMKill (Out of Memory Kill)

### Fingerprints

```
kubectl get pods -n payment:
  NAME                         READY   STATUS      RESTARTS   AGE
  payment-service-abc-7q8f     0/1     OOMKilled    3          45m
  OR
  payment-service-abc-7q8f     0/1     CrashLoopBackOff  3    45m

kubectl describe pod payment-service-abc-7q8f -n payment:
  Containers:
    payment-service:
      State:          Waiting
        Reason:       CrashLoopBackOff
      Last State:     Terminated
        Reason:       OOMKilled        ← the key fingerprint
        Exit Code:    137              ← 128 + 9 (SIGKILL) = 137
        Finished:     45 seconds ago
      Limits:
        memory: 512Mi                  ← the limit that was exceeded
        
  Events:
    Warning  OOMKilling  45s  kubelet  Memory cgroup out of memory: Kill process 1234 (java)
```

### Diagnosis Steps

```bash
# Step 1: Confirm OOMKill
kubectl describe pod <pod-name> -n payment | grep -A 5 "Last State"
# Look for: Reason: OOMKilled, Exit Code: 137

# Step 2: What was the pod doing when it was killed?
kubectl logs <pod-name> -n payment --previous | tail -50
# Look for: high memory activity, large cache loads, bulk data processing

# Step 3: What was the memory usage trend?
kubectl top pods -n payment
# If all pods are near their limit → memory limit is too low for the workload

# Step 4: Check if this is a memory leak (grows over time) vs spike:
# In Grafana: container_memory_working_set_bytes for this pod over the last 24h
# Gradual upward trend → memory leak
# Sudden spike → bulk operation / large request / cache stampede

# Step 5: Check the JVM heap if this is a Java service:
kubectl exec -it <another-pod-in-same-deployment> -n payment -- \
  bash -c "jcmd 1 VM.native_memory summary" 2>/dev/null
# OR check JVM flags:
kubectl exec -it <pod> -n payment -- cat /proc/1/cmdline | tr '\0' '\n' | grep -E "Xmx|Xms"
# -Xmx512m → JVM heap max is 512MB; container limit is also 512Mi → no room for off-heap
```

### Fix

```bash
# Immediate (incident): increase the memory limit
kubectl edit deployment payment-service -n payment
# Find:
#   resources:
#     limits:
#       memory: 512Mi    ← increase this
# Change to:
#   resources:
#     limits:
#       memory: 1Gi      ← 2× the original (start conservative)
# Save → pods restart with new limit

# Verify:
kubectl describe pod <new-pod-name> -n payment | grep memory
# Should show: memory: 1Gi

# Long-term fixes:
# Memory leak: profile the application; find which object is accumulating
# Bulk operation: paginate the operation; don't load all data at once
# JVM: set -Xmx to 70% of container limit (leave room for off-heap, JVM overhead)
```

---

## Root Cause 5.2 — CrashLoopBackOff (Bad Startup)

### Fingerprints

```
kubectl get pods -n payment:
  NAME                         READY   STATUS             RESTARTS   AGE
  payment-service-abc-7q8f     0/1     CrashLoopBackOff   7          15m

kubectl describe pod -n payment:
  Events:
    Warning  BackOff  1m  kubelet  Back-off restarting failed container
    
  Exit Code: 1 (or 255, or other non-zero, non-137 value)
  → This is an application error, not an OOMKill
```

### Diagnosis Steps

```bash
# Step 1: Read the crash logs (CRITICAL: use --previous)
kubectl logs <pod-name> -n payment --previous
# The previous container crashed. Its stdout/stderr is preserved temporarily.
# Without --previous, you see logs from the new (just-started, quickly crashed) run.

# Common crash messages and their causes:
#   "Error: config file not found at /etc/app/config.yaml"
#     → ConfigMap not mounted correctly, or wrong path in config
#     → Fix: check volumeMount path in deployment spec

#   "panic: runtime error: invalid memory address"
#     → Go panic; check the full stack trace in the logs
#     → Usually a nil pointer dereference; fix in code

#   "Error: dial tcp payment-db:5432: connection refused"
#     → App tries to connect to DB at startup; DB not available
#     → Fix: add initContainer to wait for DB, or make startup retry more resilient

#   "Error: PAYMENT_API_KEY environment variable not set"
#     → Required env var missing; Secret not mounted
#     → Fix: check secretRef in deployment spec

#   "bind: address already in use :8080"
#     → Another process is using port 8080
#     → Fix: check if host networking is enabled; check if another container uses same port

# Step 2: Check for missing env vars or secrets
kubectl get pod <pod-name> -n payment -o yaml | grep -A 30 "env:"
# Verify: are all required environment variables present?
# Check referenced Secrets exist:
kubectl get secret payment-secrets -n payment
# If "not found" → the Secret was deleted or never created

# Step 3: Check for missing ConfigMaps
kubectl get configmap payment-config -n payment
# If not found → ConfigMap was deleted

# Step 4: Check exit code for clues
kubectl describe pod <pod-name> -n payment | grep "Exit Code"
# 0   = container exited normally (should not crash; check why it exits)
# 1   = application error (generic)
# 2   = shell built-in error or script usage error
# 137 = OOMKill (covered in 5.1)
# 139 = Segmentation fault (memory corruption; fix in code)
# 143 = SIGTERM received; app exited gracefully (investigate why SIGTERM was sent)
# 255 = generic "application exited with non-zero status"
```

### Fix

```bash
# For missing Secret/ConfigMap: create the missing resource
# Example: create missing Secret
kubectl create secret generic payment-secrets \
  --from-literal=PAYMENT_API_KEY=sk_live_xxxxx \
  -n payment

# For wrong file path in ConfigMap mount:
kubectl edit deployment payment-service -n payment
# Check: volumeMounts[].mountPath matches what the app expects
# Example: if app expects /etc/app/config.yaml but mount is at /etc/config/app.yaml

# For DB connection at startup: add an initContainer to wait for DB
# Add to deployment spec:
#   initContainers:
#   - name: wait-for-db
#     image: busybox:1.35
#     command: ['sh', '-c', 'until nc -z payment-db 5432; do echo waiting; sleep 2; done']
```

---

## Root Cause 5.3 — Pending Pods (Scheduling Failure)

### Fingerprints

```
kubectl get pods -n payment:
  NAME                         READY   STATUS    RESTARTS   AGE
  payment-service-abc-7q8f     0/1     Pending   0          10m
  ← The pod never gets scheduled; stays Pending indefinitely

kubectl describe pod -n payment:
  Events:
    Warning  FailedScheduling  10m  default-scheduler  0/6 nodes are available:
      3 Insufficient cpu, 3 node(s) had taint {key: NoSchedule, effect: NoSchedule}
      that the pod did not tolerate.
```

### Diagnosis Steps

```bash
# Read the FailedScheduling event carefully — it tells you EXACTLY why:
kubectl describe pod <pod-name> -n payment | grep -A 5 "FailedScheduling"

# Common FailedScheduling messages:

# "0/N nodes are available: N Insufficient cpu"
# → No node has enough CPU to satisfy the pod's resource request
kubectl describe nodes | grep -A 5 "Allocated resources"
# Shows per-node: cpu requests vs capacity
# Fix: reduce CPU request in pod spec, OR add more nodes

# "0/N nodes are available: N node(s) had taint ... NoSchedule"
# → All nodes have a taint and the pod doesn't have a matching toleration
kubectl describe nodes | grep Taints
# Fix: add toleration to pod spec, OR remove taint from node

# "0/N nodes are available: N node(s) didn't match Pod's node affinity"
# → nodeAffinity rules don't match any node's labels
kubectl get nodes --show-labels
# Compare to pod's spec.affinity.nodeAffinity.requiredDuringScheduling
# Fix: update nodeAffinity to match existing node labels, OR add label to nodes

# "exceeded quota"
# → Namespace ResourceQuota is exhausted
kubectl describe resourcequota -n payment
# Shows: used vs hard limits for cpu, memory, pod count
# Fix: increase quota (kubectl edit resourcequota -n payment) OR reduce requests

# Check overall cluster capacity:
kubectl describe nodes | grep -E "Name:|Allocatable:|cpu:|memory:" | head -40
kubectl top nodes
# Is ANY node under-utilized? Pending pods should schedule there.
# All nodes near 100%? Need to add nodes to the cluster.
```

### Fix

```bash
# For insufficient capacity: add nodes
# EKS: update the node group desired count
aws eks update-nodegroup-config \
  --cluster-name prod-tokyo \
  --nodegroup-name general \
  --scaling-config desiredSize=10,minSize=3,maxSize=20

# For taint issues: add the correct toleration to the pod spec
kubectl edit deployment payment-service -n payment
# Add under spec.template.spec:
#   tolerations:
#   - key: "dedicated"
#     operator: "Equal"
#     value: "payment"
#     effect: "NoSchedule"

# For quota exhaustion: check what's using the quota
kubectl get all -n payment | wc -l   # how many resources exist?
kubectl top pods -n payment           # any pods using excessive resources?
# Then either increase quota or clean up unused resources
```

---

## Root Cause 5.4 — Readiness Probe Failing

### Fingerprints

```
kubectl get pods -n payment:
  NAME                         READY   STATUS    RESTARTS   AGE
  payment-service-abc-7q8f     0/1     Running   0          5m
  ← Running but NOT READY (0/1)
  
kubectl describe pod -n payment:
  Events:
    Warning  Unhealthy  1m  kubelet  Readiness probe failed:
      HTTP probe failed with statuscode: 500
      GET http://10.0.16.5:8080/ready: dial tcp: connection refused
```

### Diagnosis Steps

```bash
# The pod is running but the readiness probe is failing.
# This means: the pod is alive but is being excluded from the Service endpoints.
# Traffic will NOT be sent to this pod until the probe passes.

# Step 1: Test the readiness endpoint manually from inside the pod:
kubectl exec -it <pod-name> -n payment -- curl -v http://localhost:8080/ready
# If HTTP 500: the /ready endpoint has an error; check app logs
# If connection refused: app hasn't started yet OR wrong port in probe config

# Step 2: Check what the readiness probe is configured to check:
kubectl get pod <pod-name> -n payment -o yaml | grep -A 15 readinessProbe
# Example:
#   readinessProbe:
#     httpGet:
#       path: /ready
#       port: 8080
#     initialDelaySeconds: 10
#     periodSeconds: 5
#     failureThreshold: 3
#     successThreshold: 1

# Step 3: If the /ready endpoint is returning 500, why?
kubectl logs <pod-name> -n payment | grep -i "ready\|health\|probe"
# Common: /ready checks DB connectivity; if DB is unavailable, /ready returns 500
# → This is sometimes intentional: pod correctly reports it's not ready
# → Fix: restore DB connectivity; pod will become Ready automatically

# Step 4: Compare current endpoints to expected:
kubectl get endpoints payment-service -n payment
# Should show all pod IPs; failing pod's IP should NOT be there (correct behavior)
```

### Fix

```bash
# If /ready returns 500 because of a downstream failure:
# → Fix the downstream (DB, Redis); the probe will pass automatically once it recovers

# If /ready endpoint itself has a bug:
# → Fix the code; deploy a patched version

# If the probe is too strict (failing during normal startup):
# → Increase initialDelaySeconds to give the app more time to start
kubectl edit deployment payment-service -n payment
# Change:
#   readinessProbe:
#     initialDelaySeconds: 10  → increase to 30 or 60 for slow-starting apps
#     failureThreshold: 3      → increase to allow more failures before marking unready

# If the probe port is wrong:
# → Update port in readinessProbe.httpGet.port to match the actual port the app uses
```

---

## Root Cause 5.5 — DB Connection Pool Exhaustion

### Fingerprints

```
App logs:
  "connection pool exhausted: could not obtain connection from pool"
  "too many clients already" (PostgreSQL native error)
  "pq: sorry, too many clients already"

RDS CloudWatch:
  DatabaseConnections: 495 (max_connections=500; at 99%)
  CPUUtilization: 85% (high because of connection handling overhead)
```

### Diagnosis Steps

```bash
# Check active connections by state:
kubectl exec -it <pod-name> -n payment -- \
  psql -h payment-db.payment.svc.cluster.local -U app -c \
  "SELECT state, count(*) FROM pg_stat_activity GROUP BY state ORDER BY count DESC;"
#   state   | count
#   idle    |  450    ← 450 connections idle (wasted; pool too large or leaking)
#   active  |   40    ← 40 queries running
#   idle in transaction | 10  ← 10 connections in transactions but not executing

# "idle in transaction" is a leak signal:
# A connection opened a transaction but never committed/rolled back.
# It holds its connection indefinitely.

# Find long-idle-in-transaction connections:
kubectl exec -it <pod-name> -n payment -- \
  psql -h payment-db.payment.svc.cluster.local -U app -c \
  "SELECT pid, now()-state_change AS idle_duration, query, client_addr
   FROM pg_stat_activity
   WHERE state = 'idle in transaction'
   ORDER BY idle_duration DESC;"

# Find which queries are slow (holding connections):
kubectl exec -it <pod-name> -n payment -- \
  psql -h payment-db.payment.svc.cluster.local -U app -c \
  "SELECT pid, now()-query_start AS duration, query, state
   FROM pg_stat_activity
   WHERE state='active'
   ORDER BY duration DESC
   LIMIT 5;"
```

### Fix

```bash
# Immediate: kill idle connections that have been idle > 5 minutes
kubectl exec -it <pod-name> -n payment -- \
  psql -h payment-db.payment.svc.cluster.local -U app -c \
  "SELECT pg_terminate_backend(pid)
   FROM pg_stat_activity
   WHERE state='idle'
   AND query_start < now() - interval '5 minutes';"

# Kill idle-in-transaction connections:
kubectl exec -it <pod-name> -n payment -- \
  psql -h payment-db.payment.svc.cluster.local -U app -c \
  "SELECT pg_terminate_backend(pid)
   FROM pg_stat_activity
   WHERE state='idle in transaction'
   AND state_change < now() - interval '1 minute';"

# Set a DB-level timeout to prevent future idle-in-transaction pile-up:
# (requires DB admin access; sets a 30-second max for idle-in-transaction)
ALTER SYSTEM SET idle_in_transaction_session_timeout = '30s';
SELECT pg_reload_conf();

# Long-term:
# Reduce pool max size in application config (e.g., HikariCP maxPoolSize)
# Add idle connection timeout in the pool (return idle connections to pool after 60s)
# Deploy PgBouncer as a connection pooler between app and RDS
```

---

## Root Cause 5.6 — Disk Full

### Fingerprints

```
App logs:
  "no space left on device"
  "write /var/log/app.log: no space left on device"
  
kubectl describe pod:
  "Error: failed to create containerd task: failed to create shim: OCI runtime create failed:
   container_linux.go:380: starting container process caused: process_linux.go:545:
   writing file to bundle caused: write ...: no space left on device"
```

### Diagnosis Steps

```bash
# Check disk usage on the node the failing pod is on:
kubectl get pod <pod-name> -n payment -o jsonpath='{.spec.nodeName}'
# Returns: ip-10-0-1-45.ap-northeast-1.compute.internal

# Debug the node:
kubectl debug node/ip-10-0-1-45.ap-northeast-1.compute.internal \
  -it --image=ubuntu -- df -h /
# OR ssh to the node (if direct access is available):
# df -h
# Filesystem       Size  Used Avail Use% Mounted on
# /dev/nvme0n1p1    20G   20G     0  100% /   ← 100% FULL

# Find what is using the space:
kubectl debug node/<node-name> -it --image=ubuntu -- \
  bash -c "du -sh /var/log/* 2>/dev/null | sort -rh | head -20"

kubectl debug node/<node-name> -it --image=ubuntu -- \
  bash -c "du -sh /var/lib/docker/* 2>/dev/null | sort -rh | head -10"
# Large /var/lib/docker/overlay2 = dangling Docker image layers
```

### Fix

```bash
# Emergency: remove dangling Docker images on the node:
kubectl debug node/<node-name> -it --image=ubuntu -- \
  chroot /host docker image prune -f
# OR:
kubectl debug node/<node-name> -it --image=ubuntu -- \
  chroot /host docker system prune -f --volumes

# Remove old container logs:
kubectl debug node/<node-name> -it --image=ubuntu -- \
  bash -c "find /var/log/containers -name '*.log' -mtime +7 -delete"

# Clear systemd journal:
kubectl debug node/<node-name> -it --image=ubuntu -- \
  chroot /host journalctl --vacuum-size=500M

# Long-term prevention:
# Configure logrotate for application logs
# Set container log max-size in container runtime config
# Set up an alert: disk > 80% on nodes
# Add a larger EBS volume or expand the existing one (requires instance restart on AWS)
```

---

## Root Cause 5.7 — Expired TLS Certificate

### Fingerprints

```
App logs:
  "x509: certificate has expired or is not yet valid"
  "tls: failed to verify certificate: x509: certificate has expired"
  "Get https://api.payment-provider.com/: x509: certificate has expired"

curl output:
  curl: (60) SSL certificate problem: certificate has expired
```

### Diagnosis Steps

```bash
# Check the certificate expiry date:
# External endpoint:
echo | openssl s_client -connect payment.company.com:443 2>/dev/null \
  | openssl x509 -noout -dates
# notBefore=Jul 25 00:00:00 2025 GMT
# notAfter=Jul 25 23:59:59 2026 GMT   ← expiry date

# ACM certificates (AWS):
aws acm list-certificates \
  --query 'CertificateSummaryList[*].[DomainName,Status,NotAfter]' \
  --output table

# Check a specific ACM cert:
aws acm describe-certificate \
  --certificate-arn arn:aws:acm:ap-northeast-1:123456789012:certificate/abc-123 \
  --query 'Certificate.[DomainName,Status,NotAfter,RenewalSummary.RenewalStatus]' \
  --output table

# Check cert in a Kubernetes Secret (for manually managed certs):
kubectl get secret tls-secret -n payment -o jsonpath='{.data.tls\.crt}' \
  | base64 -d | openssl x509 -noout -dates
```

### Fix

```bash
# For ACM certificates: ACM auto-renews; check why renewal failed
aws acm describe-certificate \
  --certificate-arn <arn> \
  --query 'Certificate.RenewalSummary'
# Common reason: DNS validation CNAME was deleted from Route53
# Fix: re-add the CNAME validation record in Route53; ACM will retry renewal

# For manually managed certs (in K8s Secrets):
# Generate a new cert (Let's Encrypt example):
certbot certonly --dns-route53 -d payment.company.com
# OR via cert-manager (if installed in cluster):
kubectl get certificate -n payment
kubectl describe certificate payment-tls -n payment
# If cert-manager can't renew: check its logs and ACME challenge logs

# Update the K8s Secret with the new cert:
kubectl create secret tls payment-tls-secret \
  --cert=/path/to/fullchain.pem \
  --key=/path/to/privkey.pem \
  -n payment \
  --dry-run=client -o yaml | kubectl apply -f -
# The pod reads the Secret at startup; restart the pods to pick up the new cert
kubectl rollout restart deployment/payment-service -n payment
```

---

## Common Part 5 Mistakes

| Mistake | What Goes Wrong | Correct Approach |
|---|---|---|
| Reading current logs for CrashLoopBackOff (not using --previous) | Current run is 1 second old; logs show only startup message; crash reason invisible | Always use `kubectl logs --previous` for any pod that is crashing |
| Killing idle DB connections without finding why they're idle | Connections pile up again within minutes | Find and fix the leak (missing connection.close(), idle-in-transaction timeout) |
| Increasing memory limit without profiling the leak | Memory usage grows again over hours | Use `--previous` logs + memory profiler to find the leaking object |
| Adding disk space without fixing the log rotation | Disk fills up again within days | Fix the root cause: configure logrotate, set log level to WARN, add disk monitoring |
| Fixing CrashLoopBackOff by repeatedly deleting the pod | Pod comes back with the same crash; you've just reset the restart backoff timer | Read the crash logs; fix the root cause (missing config, bad image, etc.) |
