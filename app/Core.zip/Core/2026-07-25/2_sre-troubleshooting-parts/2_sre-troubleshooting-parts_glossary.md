# SRE Troubleshooting — All 10 Parts Glossary

**SRE (Site Reliability Engineer)**
An engineer who applies software engineering practices to operations problems. Owns reliability, availability, and latency of production systems. Responds to incidents, writes post-mortems, and builds automation to prevent future failures.

**Incident**
An unplanned event that causes service degradation or outage. Has a lifecycle: alert → triage → stabilise → diagnose → resolve → post-mortem. Every incident gets a severity (SEV1-4) that determines urgency and required communication.

**SEV1 / SEV2 / SEV3 / SEV4**
Incident severity levels. SEV1 = full outage/data loss risk (page immediately, update every 10 min, post-mortem required). SEV2 = major degradation (page team, update every 20 min). SEV3 = partial degradation (Slack notification, update hourly). SEV4 = minor issue (ticket only).

**IC (Incident Commander)**
The single person who owns coordination of an incident. Named explicitly in the first #incidents message. Makes decisions, assigns tasks, owns communication cadence, and declares resolution. One IC per incident — no exceptions.

**Blast Radius**
The scope of an incident: how many users, services, or requests are affected. Used to determine severity. A growing blast radius requires immediate stabilisation; a contained blast radius allows more time for careful diagnosis.

**Stabilisation**
The act of restoring service without necessarily fixing the root cause. A rollback is a stabilisation — it restores service but the bug still exists in the codebase. Stabilisation is always done BEFORE diagnosis. "Stop the bleeding first."

**Rollback**
Reverting to a previous version of an application to restore service after a bad deploy. In Kubernetes: `kubectl rollout undo deployment/<name>`. In ArgoCD: click ROLLBACK in the HISTORY tab. Much faster than finding and fixing the bug during an active incident.

**Root Cause**
The underlying reason why an incident occurred — the systemic gap that allowed the failure. "Missing database index" is a root cause. "Someone didn't add an index" is a symptom. Post-mortems use Five Whys to find the systemic root cause, not the proximate cause.

**OODA Loop**
A decision-making framework: Observe → Orient → Decide → Act → (repeat). Used in troubleshooting to structure hypothesis testing. One loop = test one hypothesis. Key rule: one change at a time so you know what worked.

**Hypothesis**
A specific, testable explanation for a problem. "The DB is slow because the connection pool is exhausted" is a hypothesis. "Something is wrong with the database" is not. Good hypotheses are falsifiable — you can be proved wrong.

**Five Whys**
A root cause analysis technique: ask "why?" five times to get from symptom to systemic cause. "5xx errors → connection pool exhausted → queries slow → missing index → no index review in code review checklist → checklist was written before large tables existed." Each "why" goes deeper.

**Post-Mortem**
A blameless written analysis of an incident. Contains: summary, impact, timeline, root cause, contributing factors, what went well, action items. Required for SEV1/SEV2. The goal is to fix the SYSTEM, not blame a person.

**Blameless Post-Mortem**
A post-mortem where the focus is on system failures, not individual mistakes. "The code review process did not include SQL performance review" vs "Alice wrote a slow query." Blameless culture makes incidents safer to report and produces more useful learnings.

**Contributing Factor**
A condition that made an incident worse or harder to prevent, but was not the primary root cause. Example: "staging database has only 10K rows" was a contributing factor to missing the performance regression before production.

**Action Item**
A specific task from a post-mortem with an owner and due date. Must be tracked in Jira (not just the post-mortem doc). "Improve testing" is not an action item. "Add load test for /api/v2/payments with 50M-row dataset. Owner: @alice. Due: 2026-08-08." is an action item.

**kubectl rollout history**
A command showing all past Deployment revisions with their change history. Used during incidents to identify when a deploy happened and what it changed. Combines with `--revision=N` to inspect a specific version.

**kubectl rollout status**
A command that watches a Deployment rollout and reports progress until complete or fails. Used to monitor a rollback or deploy in progress. Exits with code 0 on success, non-zero on failure.

**kubectl describe pod**
The richest single command for pod diagnosis. Shows: resource limits, current/last state, exit code, restart count, volume mounts, and most importantly the EVENTS section at the bottom (scheduling failures, probe failures, OOMKill, image pull errors).

**kubectl logs --previous**
Retrieves logs from the last terminated container instance (before the most recent restart). Essential for CrashLoopBackOff — the current run is too short to contain the crash reason. Always use this first for any pod that is crashing.

**CrashLoopBackOff**
A Kubernetes pod state where the container repeatedly crashes and Kubernetes restarts it with increasing delays (backoff). The pod is not Running. Caused by: application error, missing config/secrets, OOMKill, port conflict, or failed startup dependency.

**Exit Code 137**
The process exit code indicating the process was killed by signal 9 (SIGKILL) — typically by the Linux OOM killer because it exceeded its memory limit. Visible in `kubectl describe pod` under "Exit Code: 137." Fix: increase memory limit or fix memory leak.

**Exit Code 139**
Segmentation fault — the process accessed memory it shouldn't have. Signal 11 (SIGSEGV); 128+11=139. Requires code-level investigation (check core dump, rebuild with debug symbols).

**OOMKill (Out of Memory Kill)**
When the Linux kernel kills a process because it exceeded its memory limit. In Kubernetes, pods have memory limits; when exceeded, the kernel kills the container and Kubernetes restarts it. Shows as "OOMKilled" in pod status and Exit Code 137.

**Readiness Probe**
A Kubernetes health check that determines if a pod is ready to receive traffic. Failed pods are removed from the Service endpoints list (traffic stops going to them). Different from Liveness Probe (which determines if a pod should be restarted). A pod can be Running but not Ready (READY=0/1).

**kubectl get endpoints**
Shows which pod IPs are registered as healthy backends for a Kubernetes Service. If empty, no pods match the Service's label selector — traffic goes nowhere. Check this when traffic isn't reaching pods even though they appear Running.

**Service Selector**
A label query on a Kubernetes Service that determines which pods it routes traffic to. If `app=payment-service` is the selector, only pods with that label receive traffic. A mismatch between selector and pod labels = empty endpoints.

**HPA (Horizontal Pod Autoscaler)**
A Kubernetes controller that automatically adjusts the number of pod replicas based on CPU/memory metrics. Can scale up when traffic spikes. Has a lag (checks metrics every 30s by default) — manual scaling bypasses this lag during incidents.

**PodDisruptionBudget (PDB)**
A Kubernetes policy that limits how many pods can be unavailable at once. Prevents all pods from being taken down simultaneously during a rollout or node drain. Important for zero-downtime deploys.

**Connection Pool Exhaustion**
When all database connections in an application's connection pool are in use. New requests must wait for a connection, causing timeouts and 5xx errors. Caused by: slow queries holding connections, connection leaks, or pool too small for the workload.

**pg_stat_activity**
A PostgreSQL system view showing all current database connections and their states (idle, active, idle in transaction). Used during connection pool exhaustion diagnosis to find connection leaks and slow queries. Query with `SELECT state, count(*) FROM pg_stat_activity GROUP BY state`.

**EXPLAIN ANALYZE**
A PostgreSQL command that shows the query execution plan including actual row counts and timing. `EXPLAIN ANALYZE SELECT ...` reveals if a query uses an index scan (fast) or a sequential scan (full table scan, slow). Essential for diagnosing slow queries.

**Sequential Scan (Seq Scan)**
A PostgreSQL query plan step that reads every row in a table to find matches. Extremely slow on large tables (millions of rows). Fixed by adding an appropriate index. Visible in EXPLAIN ANALYZE output.

**Index Scan**
A PostgreSQL query plan step that uses a B-tree index to find rows directly without reading the whole table. Typical for queries on columns with high selectivity. Visible in EXPLAIN ANALYZE; indicates the query is using the index correctly.

**CREATE INDEX CONCURRENTLY**
A PostgreSQL command that builds an index without acquiring a full table lock. Takes longer than a regular CREATE INDEX but doesn't block reads/writes during creation. Always use this in production to avoid downtime.

**Circuit Breaker**
A resilience pattern that stops sending requests to a failing dependency once the failure rate exceeds a threshold. Returns a fallback response instead of waiting for the dependency to time out. Prevents cascading failures from one slow service overwhelming another.

**Exponential Backoff**
A retry pattern that increases the delay between retries exponentially (1s, 2s, 4s, 8s...) instead of retrying immediately. Prevents thundering herd problems where all retries hit the recovering service simultaneously.

**Fallback Response**
A degraded response returned when a dependency is unavailable. Examples: cached data, empty list with a message, or a simplified version of the response. Better than a 5xx error from the user's perspective.

**Chaos Engineering**
The practice of deliberately injecting failures (network latency, pod crashes, DB failover) into a system to verify it handles them gracefully. AWS FIS (Fault Injection Simulator) is the managed service for this. Run in staging first, then production during business hours.

**AWS FIS (Fault Injection Simulator)**
An AWS service for running controlled chaos experiments. Can: stop EC2 instances, inject network latency, trigger RDS failovers, drain EKS nodes. Has stop conditions (abort if error rate exceeds threshold) to prevent experiments from causing real incidents.

**PgBouncer**
A lightweight PostgreSQL connection pooler that sits between an application and the database. Maintains a small pool of real DB connections and multiplexes thousands of application connections through them. Dramatically reduces DB connection count without changing application code.

**Canary Deploy**
A deployment strategy that routes a small percentage of traffic (e.g. 5%) to the new version and the rest to the old version. If the canary shows errors, abort before full rollout. Argo Rollouts manages this in Kubernetes.

**Blue/Green Deploy**
A deployment strategy that maintains two identical environments (blue=current, green=new). Switch traffic from blue to green when ready. Rollback = switch back to blue instantly. Requires 2× infrastructure cost but enables zero-downtime deploys with instant rollback.

**Status Page**
A public-facing page (e.g. statuspage.io) showing the current operational status of a service. Updated during incidents with: Investigating, Identified, Monitoring, Resolved. External users check this first; update it before posting in internal Slack.

**Verification Criteria**
Specific, measurable conditions that must ALL be met before declaring an incident resolved. Example: error rate < 0.1% for 10 consecutive minutes + P99 < 500ms + no new alerts. Written BEFORE deploying the fix, not after.

**Toil**
Repetitive, manual operational work that could be automated. Examples: manually rotating secrets, manually resizing instances, manually clearing log files. SRE principle: reduce toil by automating everything that recurs. High toil = low reliability (humans make mistakes on repetitive tasks).

**SLO (Service Level Objective)**
A target for a service metric over a time window. Example: 99.9% of payment requests succeed within 500ms over any 30-day period. Breaching an SLO triggers reliability work. The post-mortem records how much error budget was consumed.

**Error Budget**
The allowed amount of unreliability within an SLO period. 99.9% availability SLO over 30 days = 43.2 minutes of downtime budget. Every incident consumes some of this budget. When the budget is exhausted, new features stop and reliability work takes priority.
