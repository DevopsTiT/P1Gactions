# SRE Troubleshooting — Part 2: Triage — Is This Real? How Bad?

> **Core rule:** Triage answers three questions before you touch anything: Is the signal real (not a flapping probe)? What is the blast radius (how many users/services)? Is it growing or recovering? The answers determine whether you rollback immediately, investigate, or go back to sleep.

---

## Decision Tree — "Is this alert worth acting on right now?"

```
"Alert is firing — is this a real incident?"
│
├─ Check: is the metric STILL elevated right now?
│   ├─ YES, still high → real incident; proceed with triage
│   └─ NO, already recovered → possible flapping; watch for 5 more minutes
│       └─ If it fires again within 30 min → investigate the flapping itself
│
├─ Is this a known noisy alert?
│   ├─ YES (alert was tuned incorrectly; fires on harmless spikes)
│   │   → Archive the alert; file a ticket to tune the threshold
│   └─ NO → proceed with triage
│
├─ What percentage of requests are failing?
│   ├─ > 50% → SEV1: full outage; stabilise immediately (Part 3)
│   ├─ 10–50% → SEV2: major degradation; rollback immediately if deploy < 30min ago
│   ├─ 1–10%  → SEV2/SEV3: investigate; check if specific endpoints or all
│   └─ < 1%   → SEV3/SEV4: investigate during business hours if not growing
│
├─ Is the error rate growing, stable, or recovering?
│   ├─ Growing rapidly → treat as SEV1 regardless of current %; it will get worse
│   ├─ Stable → you have time; diagnose methodically
│   └─ Recovering → watch for 10 min; may resolve itself (transient spike)
│
└─ Is it isolated to one service or cascading to dependents?
    ├─ One service → contained blast radius; investigate that service
    └─ Cascading  → identify the root service first; all others are symptoms
```

---

## Step 1: Confirm the Signal Is Real

Not every alert is a real incident. Check before escalating.

```bash
# Is the metric still elevated? (check real-time, not just the alert)
# Open Grafana → is the error rate graph still above the threshold LINE RIGHT NOW?

# Check live error rate from Prometheus (via port-forward or direct):
# (run this in a browser or via promtool)
# Query:
sum(rate(http_requests_total{namespace="payment", status=~"5.."}[2m]))
/
sum(rate(http_requests_total{namespace="payment"}[2m])) * 100
# Expected baseline: < 0.1%
# Incident threshold: > 1%

# Quick check from kubectl — is anything obviously wrong?
kubectl get pods -n payment
# All Running + READY = 1/1 → not a pod crash; app-level error
# Any CrashLoopBackOff → pod crash; definitely real

# How many errors in the last 2 minutes vs 10 minutes ago?
kubectl logs -n payment -l app=payment-service --since=2m \
  | grep -c "HTTP 5[0-9][0-9]\|ERROR\|exception" 2>/dev/null

# Compare to baseline (last hour):
kubectl logs -n payment -l app=payment-service --since=60m \
  | grep -c "HTTP 5[0-9][0-9]\|ERROR\|exception" 2>/dev/null
# If NOW rate >> baseline rate → real incident
```

### Flapping Alert vs Real Incident

```
FLAPPING (not a real incident):
  Pattern: alert fires, then clears, then fires again within minutes
  Cause: threshold set too tight; brief spikes in normal operation
  Example: p99 latency alert fires during GC pauses every 10 minutes
  Action: archive the PagerDuty incident; file a ticket to tune the alert

REAL INCIDENT:
  Pattern: metric is continuously above threshold for > 5 minutes
  Cause: genuine degradation
  Action: triage fully; may need to stabilise

HOW TO TELL THEM APART:
  Check the Grafana graph over the last 2 hours:
  → Regular spikes every X minutes → flapping alert
  → One sustained spike that started and hasn't recovered → real incident
  → Alert fired once, cleared, you're looking at the graph now and it's fine
    → watch for 10 minutes; if clean, acknowledge and investigate the cause
```

---

## Step 2: Measure the Blast Radius

Blast radius = how many users/requests/services are affected. This determines severity and urgency.

```bash
# Error rate as % of total requests (last 5 min):
sum(rate(http_requests_total{namespace="payment", status=~"5.."}[5m]))
/
sum(rate(http_requests_total{namespace="payment"}[5m])) * 100

# Absolute errors per second:
sum(rate(http_requests_total{namespace="payment", status=~"5.."}[5m]))
# 2.5 errors/sec at 250 req/sec = 1% error rate = 150 errors per minute
# 2.5 errors/sec at 50 req/sec = 5% error rate = 150 errors per minute
# Same absolute count, very different relative impact

# Which specific ENDPOINTS are erroring?
sum by (path, status) (rate(http_requests_total{namespace="payment", status=~"5.."}[5m]))
# Output example:
#   path="/api/v1/payments" status="500"  → 2.3 errors/sec
#   path="/api/v1/payments/refund" status="503" → 0.1 errors/sec
#   path="/api/v1/health" status="200"    → 0 errors (health is fine)
# → Errors are isolated to /api/v1/payments, not the whole service

# Are downstream services also affected?
kubectl get pods -n orders -l app=orders-service
kubectl get pods -n catalog -l app=catalog-service
# If orders-service also has errors → payment is a dependency; cascade starting
```

### Blast Radius Classification

```
CONTAINED (one service, one endpoint):
  → payment-service /v1/payments endpoint only
  → 2.3% error rate, 250 req/sec
  → Impact: payment submission failing; refunds/history unaffected
  → Severity: SEV2 (major feature broken)

PARTIAL CASCADE (one service affecting its direct consumers):
  → payment-service down → checkout-service gets 503 from payment calls
  → checkout-service error rate at 30% (because ~30% of checkouts hit payment)
  → catalog-service unaffected (doesn't call payment)
  → Severity: SEV1 (checkout = revenue-critical path)

FULL CASCADE (multiple services):
  → Database cluster down → all services that use the DB fail
  → 5+ services affected simultaneously
  → Severity: SEV1 (possible infrastructure incident)
  → Root cause is in the shared layer (DB, cache, network), not one service
```

---

## Step 3: Measure Growth Rate

An error rate of 2% that is growing to 10% is more urgent than a stable 5% error rate.

```bash
# Compare error rate at different time windows:
# Current (last 2 min):
sum(rate(http_requests_total{namespace="payment", status=~"5.."}[2m]))
/ sum(rate(http_requests_total{namespace="payment"}[2m])) * 100

# 5 min ago:
sum(rate(http_requests_total{namespace="payment", status=~"5.."}[2m] offset 5m))
/ sum(rate(http_requests_total{namespace="payment"}[2m] offset 5m)) * 100

# 10 min ago:
sum(rate(http_requests_total{namespace="payment", status=~"5.."}[2m] offset 10m))
/ sum(rate(http_requests_total{namespace="payment"}[2m] offset 10m)) * 100

# Interpretation:
# 10min ago: 0.1% → 5min ago: 1.2% → now: 3.4% → GROWING RAPIDLY → SEV1 treatment
# 10min ago: 5.2% → 5min ago: 4.8% → now: 4.6% → STABLE/RECOVERING → SEV2
# 10min ago: 0.1% → 5min ago: 0.1% → now: 8.0% → SUDDEN SPIKE → deploy-related
```

---

## Step 4: Severity Classification — Full Reference

```
SEVERITY MATRIX:
──────────────────────────────────────────────────────────────────────
                │ Growing     │ Stable      │ Recovering
────────────────┼─────────────┼─────────────┼─────────────
> 50% error     │ SEV1 ★★★   │ SEV1 ★★★   │ SEV1 → SEV2
10–50% error    │ SEV1 ★★★   │ SEV2 ★★    │ SEV2 → SEV3
1–10% error     │ SEV2 ★★    │ SEV2 ★★    │ SEV3
< 1% error      │ SEV2 ★★    │ SEV3 ★     │ SEV4
──────────────────────────────────────────────────────────────────────
★★★ = page immediately; update every 10 min; post-mortem required
★★  = investigate now; update every 20 min; post-mortem likely
★   = investigate this shift; update at next check-in
```

### Severity Actions

```
SEV1 — Full outage or critical degradation:
  □ Post in #incidents immediately
  □ Page team lead + engineering manager
  □ Update status page within 5 minutes: "Investigating"
  □ Update every 10 minutes
  □ Post-mortem required within 48 hours

SEV2 — Major degradation:
  □ Post in #incidents immediately
  □ Page service owner team (not manager unless unresolved > 30 min)
  □ Update status page within 15 minutes
  □ Update every 20 minutes
  □ Post-mortem likely required

SEV3 — Partial degradation:
  □ Post in #incidents
  □ Notify service team via Slack (no page needed)
  □ Update status page only if users are reporting
  □ Update at shift end
  □ Post-mortem optional (only if recurring)

SEV4 — Minor issue:
  □ Create Jira ticket
  □ No incident channel post needed
  □ No status page update
  □ No post-mortem
```

---

## Step 5: Triage Output — Decide What Happens Next

After completing triage, you should have answers to:

```
1. Is this real?
   → YES — error rate 2.3%, confirmed in Grafana, still rising

2. How bad?
   → SEV2 — 2.3% error rate on payment submission endpoint
             ~150 failed payments per minute at current traffic
             checkout-service is starting to see 5xx from payment calls

3. Growing, stable, or recovering?
   → Growing: 0.1% → 1.2% → 2.3% over 15 minutes

4. What changed recently?
   → payment-service v2.3.2 deployed at 14:21 (12 minutes before alert fired)

5. Decision:
   → Deploy < 30 min ago + growing error rate = ROLLBACK IMMEDIATELY
   → Move to Part 3 (Stabilise)

ANNOUNCE THE DECISION:
  Post in #incidents:
  "📊 TRIAGE COMPLETE — SEV2. Error rate 2.3%, growing.
   Deploy at 14:21 is the likely cause. Rolling back to v2.3.1 now.
   @payments-team please stand by."
```

---

## Common Part 2 Mistakes

| Mistake | What Goes Wrong | Correct Approach |
|---|---|---|
| Treating a flapping alert as a real incident | 30 min of investigation; no incident; on-call frustrated | Check if metric is still elevated; look for the flapping pattern in the 2h graph |
| Only checking % error rate, not absolute count | "0.1%" sounds fine but is 500 errors/sec on a high-traffic service | Always check both % and absolute errors/sec |
| Not checking if error rate is growing | SEV3 treatment for a growing problem that becomes SEV1 in 10 minutes | Track the trend: now vs 5 min ago vs 10 min ago |
| Checking blast radius too narrowly | Fix payment-service but miss that checkout-service is also failing | Always check direct consumers of the affected service |
| Escalating to SEV1 immediately based on alert title alone | Unnecessary pages; cry-wolf effect; on-call team stops trusting alerts | Confirm with data before escalating; use the severity matrix |
