# GA Questions
---

## Product Context (from the image)

| Product | Who It Serves | What It Does | How Money Is Made |
|---------|--------------|-------------|------------------|
| **RENOSY** | Individual investors | Buy / sell / manage investment condominiums online | Brokerage commission, rental management fees, attach products |
| **ITANDI BB** | Real estate agencies / property managers | Digital applications, e-contracts, agency workflows (SaaS) | Monthly subscription |
| **RENOSY Platform** | Developers / RE companies | White-label digital sales stack | License fees |

---

Business:

1. "RENOSY serves individual investors; revenue is brokerage commission, rental management fees, and attach products. — is the deal flow seasonal or event-driven, and how does the platform handle peak load?"
1. "The ~10-year transaction dataset is described as GA's primary competitive advantage — how is that data currently flowing into production models, and what does the pipeline look like end-to-end?"
1. What is the most significant advantange GA has over the competors and How Data team contributed to help maintain such advantage?
1. "What is the biggest problem the business is relying on Data team to solve in the next 12 months?"
1. "When a data pipeline fails today, how quickly does the business notice, and who is responsible for detecting and fixing it — data engineering, SRE, or shared?"
1. "What is the SLA commitment to ITANDI BB agencies, and what happens contractually if it is breached — is there a compensation clause?"

Team:

1. "Can you tell me how the team is structured — who owns what?"
2. "How does the SRE/platform team interact with the other team members  day to day?"
3. Is there someone on this team who joined in the last 1–2 years and is now a core contributor — what did they do to get there?

Tech Stack:

1. "How does a deployment work end-to-end today — from a PR merge to production?"
2. "What is the biggest infrastructure pain point that the team has not been able to fix yet, and why?"
3. "What is the part of the tech stack Data team is most proud of, and what is the part  most want to improve?"
4. "Is there a problem in the system that has been unsolved for a long time is in SRE position?"

Other:

1. "Can you walk me through the last significant incident — how it was detected, handled, and followed up?"

2. What does success look like for this role at 3 months, 6 months, and 12 months?

3. Can you tell me about someone on the team who grew significantly in the last year — what did that look like?

4. "What is the single most valuable thing someone in this role could do in the first 90 days that would have a real impact?"

5. "What mistakes do new people on this team most commonly make, and how can I avoid them?"







## 
