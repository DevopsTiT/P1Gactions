# GA Questions 

---

## E2E Flow Summary

```
1. WHAT YOU KNOW GOING IN (from the images)
   Three products: RENOSY (investors), ITANDI BB (agencies SaaS), RENOSY Platform (white-label)
   Three revenue models: brokerage+fees, monthly subscription, license fees
   Three moat pillars: ~10yr closed-deal data, ITANDI agency network, RENOSY brand
   Flywheel: brand → deals → data → AI → better product → stronger brand

2. WHAT YOU DON'T KNOW (gaps a question must close)
   Which product is the primary revenue driver RIGHT NOW?
   How mature is the data/AI layer in practice?
   How does infra/SRE relate to each revenue stream's reliability?
   How much does the platform team's work protect vs. enable the flywheel?
   Where is GA in the "second founding" growth arc — early, mid, or maturing?

3. QUESTION STRATEGY
   Per-product questions → understand relative priority and investment
   Failure-impact questions → surface what Tier-1 really means to the team
   Flywheel questions → understand if data/AI is aspirational or operational
   Platform-role questions → understand your leverage and political capital

4. AFTER ASKING
   Listen for: is the manager's answer product-specific or generic?
   Generic answer = they don't think in product-reliability terms (a risk)
   Product-specific answer = they know what breaks the business (a good sign
```



## Part 1 — RENOSY: The Brokerage + Investor Product

**What you know:** RENOSY serves individual investors; revenue is brokerage commission, rental management fees, and attach products. If the contract/payment path fails, it is a legal and trust failure — not just a UX problem.

**What you don't know:** Is RENOSY the primary revenue driver? How automated is the contract/payment path? What does "attach products" mean in practice and does it have separate infra?

---

### Questions to ask

1.**"RENOSY serves individual investors; revenue is brokerage commission, rental management fees, and attach products. — is the deal flow seasonal or event-driven, and how does the platform handle peak load?"**







**"RENOSY's revenue includes brokerage commissions, rental management fees, and attach products — which of those is the largest contributor right now, and does each have separate infra or pipelines?"**
> *Why:* Brokerage is transaction-based (spiky, high-stakes per event). Rental management is recurring (steady). Attach products may have separate systems. Understanding the split tells you where reliability failures hurt most.

**"The RENOSY contract and payment path has legal and trust consequences if it fails — how is that path currently instrumented and what is the recovery time if it goes down?"**
> *Why:* This is Tier-1 by definition from the business model. The answer tells you if the team already treats it that way, or if it is aspirational. A vague answer is a red flag.

**"How many RENOSY deals close per month, and is that volume growing, flat, or contracting?"**
> *Why:* Deal volume is the input to the data flywheel. If it is flat or shrinking, the data moat is not compounding. Also tells you about traffic patterns for infra sizing.

**"RENOSY sells to individual investors — is the deal flow seasonal or event-driven, and how does the platform handle peak load?"**

> *Why:* Real estate has seasonal patterns (fiscal year-end in Japan = March). Seasonal peaks without autoscaling or load testing are reliability risks.

---

## Part 2 — ITANDI BB: The Agency SaaS Product

**What you know:** ITANDI BB serves agencies and property managers; revenue is monthly subscription. Downtime = agencies cannot run daily operations = SLA breach = churn risk. Network effect: more agencies → more value.

**What you don't know:** What is the actual SLA commitment? How many agencies are on it? Is the subscription count growing? What is the churn rate if SLA is breached?

---

### Questions to ask

**"What is the SLA commitment to ITANDI BB agencies, and what happens contractually if it is breached — is there a compensation clause?"**
> *Why:* "SLA" is often stated without knowing the actual number or consequence. If the answer is vague, the team is not tracking against a real commitment. If there is a compensation clause, a breach costs money directly.

**"How many agencies are currently on ITANDI BB, and is the subscription count growing at a rate that is meaningful to the business?"**
> *Why:* Network effect compounds as agency count grows. If growth has stalled, the moat pillar is weaker than it looks. Also, more agencies = more load = infra must scale accordingly.

**"Agencies run daily operations on ITANDI — which specific workflows are most latency-sensitive, and do those have separate SLOs from the rest of the product?"**
> *Why:* "Digital applications" and "e-contracts" are probably the most critical. If the team has not separated these from less critical parts of the product, the monitoring is not granular enough.

**"What is the biggest reason agencies have churned from ITANDI BB — was reliability ever a factor?"**
> *Why:* If churn has been reliability-related, that is direct evidence that the SLA is already being missed. If the manager doesn't know the churn reason, that is a different red flag.

---

## Part 3 — RENOSY Platform: The White-Label Product

**What you know:** Serves developers and RE companies; revenue is license fees. White-label means customers expose GA's platform under their own brand.

**What you don't know:** How mature is this product? Is it growing? Do white-label customers have separate infra or share RENOSY's? What are the SLA implications of a white-label customer's users experiencing an outage?

---

### Questions to ask

**"RENOSY Platform is white-label — does it share infrastructure with RENOSY proper, or is it isolated? And do white-label customers have their own SLA contracts?"**
> *Why:* Shared infra means an outage in RENOSY can cascade to white-label customers and vice versa. White-label SLAs add contractual obligations beyond the direct product. The answer shapes blast-radius thinking.

**"Is RENOSY Platform a growing revenue line or is it still in early traction? How does the team prioritize it relative to RENOSY and ITANDI?"**
> *Why:* If it is small and early, it may not have mature infra. If it is growing fast, it could be the next underprepared Tier-1. Knowing the roadmap priority tells you how much attention to pay to it.

---

## Part 4 — The Data Flywheel and AI Layer

**What you know:** GA's competitive moat depends on ~10 years of closed-deal transaction data feeding AI valuation and "next best sales action." If data pipelines go down, the AI layer degrades. Better data/AI → better pricing, matching, sales assist → stronger brand and SaaS retention.

**What you don't know:** Is the AI layer actually in production, or is it aspirational? Who owns the data pipelines — data engineering, SRE, or both? How does data quality get monitored?

---

### Questions to ask

**"The ~10-year transaction dataset is described as GA's primary competitive advantage — how is that data currently flowing into production models, and what does the pipeline look like end-to-end?"**
> *Why:* This is the most important strategic question in this category. A strong answer names: ingestion source, warehouse (Snowflake), feature engineering, model training cadence, and serving layer. A vague answer means the flywheel is more aspirational than operational.

**"When a data pipeline fails today, how quickly does the business notice, and who is responsible for detecting and fixing it — data engineering, SRE, or shared?"**
> *Why:* Data pipeline reliability is often a blind spot between data eng and SRE. If the answer is "it depends" or "whoever notices first," there is no clear ownership. That is future SRE scope.

**"The AI layer includes valuation support and next-best-sales-action — are these models currently in production, and what is the consequence to the sales team if they are unavailable for a day?"**
> *Why:* Tests whether the AI layer is live or in development. Also reveals how the business actually depends on it: if sales can work without it for a day, it is important but not Tier-1. If they cannot, it needs SLOs.

**"How does GA ensure the quality of the transaction data that feeds the models — is there data validation, freshness monitoring, or schema change alerting in place?"**
> *Why:* Data quality failures are silent: the pipeline runs but the output is wrong. Asking about validation, freshness, and schema monitoring tells you how mature the data observability layer is.

---

## Part 5 — Competitive Moat and Platform's Role

**What you know:** Three moat pillars — data, ITANDI network, RENOSY brand — reinforce each other. The flywheel: brand → deals → data → AI → stronger brand. Platform/SRE keeps this running, safe, and cost-controlled.

**What you don't know:** Does the engineering leadership see the platform team as moat-fuel or cost centre? Is the SRE team given roadmap time to work on flywheel infrastructure, or is it purely reactive?

---

### Questions to ask

**"GA's moat depends on the data flywheel compounding over time — does the platform team have dedicated roadmap capacity to invest in data reliability and pipeline infrastructure, or is that mostly reactive work?"**
> *Why:* If the platform team is purely reactive (fixing things when they break), the flywheel infrastructure is not being proactively hardened. This is the single most important signal for long-term job satisfaction in this role.

**"How does senior leadership view the SRE / platform team — as infrastructure cost to be minimized, or as the layer that protects GA's competitive advantage?"**
> *Why:* This is the political capital question stated directly. The answer predicts your budget, headcount, and ability to push back on unsafe shortcuts.

**"If the ITANDI agency network is a moat pillar because of switching cost and network effect — what would it take for an agency to leave, and has the platform team ever had a conversation about what reliability level is required to prevent that?"**
> *Why:* Forces the manager to connect platform reliability to competitive strategy. A manager who can answer this is thinking at the right level.

---

## Common Mistakes and Correct Approaches

| Mistake | What Goes Wrong | Correct Approach |
|---------|-----------------|-----------------|
| Asking "which product is most important?" generically | Gets a diplomatic non-answer | Ask "which product's infrastructure failure would hurt revenue first?" — forces prioritization |
| Assuming the AI/data layer is operational because the JD mentions it | Join to find data pipelines are in a spreadsheet or prototype | Ask for the end-to-end pipeline description; listen for specific tools and monitoring |
| Not asking about ITANDI SLA specifics | Assume it is fine; find out after joining that there is a compensation clause you are now responsible for | Ask the exact SLA number and contractual consequence of a breach |
| Treating all three products as equally important | Dilute your focus; get paged for the wrong things | Ask directly: "If you had to rank the three products by reliability criticality, how would you order them?" |
| Not asking about white-label blast radius | RENOSY Platform shares infra; an outage hits both products and both customer bases | Ask whether white-label is isolated or shared infra |
| Skipping the political capital question | Join a team treated as a cost centre; FinOps work gets ignored; reliability roadmap never approved | Ask directly how leadership views the platform team's role |
