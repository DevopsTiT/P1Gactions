# GA Summary 

---

## 1. Who GA is (company summary)

| Topic | Explanation |
|-------|-------------|
| Company | **GA technologies** — Tokyo proptech company |
| Identity | **Technology × real estate** (not a traditional agency that “also uses IT”) |
| Mission | Digitize Japan’s real estate market, which still depends heavily on paper, fax, and in-person steps |
| Why that matters | Traditional deals often take **2–3 months**; digital flow aims for **weeks** |
| Scale (order of) | Large revenue, ~1,000 people, large engineering org; growth / “second founding” stage |

| Product | Who it serves | What it does | How money is made |
|---------|---------------|--------------|-------------------|
| **RENOSY** | Individual investors | Buy / sell / manage investment condominiums online | Brokerage commission, rental management fees, attach products |
| **ITANDI BB** | Real estate agencies / property managers | Digital applications, e-contracts, agency workflows (SaaS) | Monthly subscription |
| **RENOSY Platform** | Developers / RE companies | White-label digital sales stack | License fees |

| If this system fails… | Business meaning |
|-----------------------|------------------|
| RENOSY contract / payment path | Deal blocked; **legal and trust** problem, not only UX |
| Investor / owner personal data | **PIPA / compliance** risk |
| ITANDI down | Agencies cannot run daily operations (**SLA / churn**) |
| Sales ML / data pipelines down | “Next best sales action” and valuation support degrade |

```txt
Paper-heavy Japan RE
  → RENOSY (investors) + ITANDI (agencies)
    → deal & ops data accumulate
      → AI valuation + data-driven sales
        → needs a safe, reliable, cost-aware cloud platform
```

---

## 2. Why join GA (motivation — explained fully)

### 2d. Short spoken script (~45 seconds)

| Line | Text |
|------|------|
| 1 | GA digitizes Japan’s paper-heavy real estate market. |
| 2 | RENOSY serves individual investors; ITANDI serves agencies as B2B SaaS. |
| 3 | That makes reliability a **product and legal** concern—not only an ops metric. |
| 4 | I want to build and harden AWS, EKS, GitOps, and observability in that growth window. |
| 5 | I work with PR-driven infrastructure, shared dashboards, and blameless incident response. |

---

## 3. GA advantage (competitive moat)

### 3a. Three pillars

| Pillar | What it is | Why competitors cannot copy quickly |
|--------|------------|-------------------------------------|
| **~10 years of transaction data** | Real closed deals: prices, yields, time-to-close, outcomes, buyer patterns | Public listing scrapes miss closed-deal truth and labeled history |
| **ITANDI agency network** | Many agencies already run daily work on the SaaS | Switching cost + **network effect** (more agencies → more value) |
| **RENOSY brand** | Strong digital brand among individual investment-condo buyers | Trust and inbound demand take years to build |

### 3b. How the advantages reinforce each other

| From | To | Effect |
|------|-----|--------|
| RENOSY brand | More investor deals | More labeled transaction data |
| More deals / ITANDI usage | Richer data + stickier workflows | Harder for a new app to displace |
| Better data / AI | Better pricing, matching, sales assist | Stronger brand and SaaS retention |

```txt
Brand → more deals → more data → smarter AI/product
  → stickier ITANDI + stronger RENOSY → more deals again
```

### 3c. Data team and SRE (why this matters to you)

| Role | Value to the company |
|------|----------------------|
| **Data team** | Turns messy RE and ops events into trusted warehouse tables and ML features—“moat fuel,” not only charts |
| **SRE / platform** | Keeps pipelines up, PII-safe, auditable in Git, and cost-controlled **without** cutting Tier-1 user/legal paths |

---

## 4. What I can do to help the team

### 4a. Role you are targeting

| Item | Detail |
|------|--------|
| Title (JD) | Senior Cloud Infrastructure Engineer (SRE) |
| Mission | Infrastructure under **data-driven sales / ML** so models and workflows run **safe, reliable, and cost-effective** |
| Working style | Observe current state → write roadmap → own implementation through production (not design-and-hand-off) |

| Domain you own | Concrete help |
|----------------|---------------|
| **Security risk** | AWS Security Maturity roadmap; Security Hub / GuardDuty / Config → Slack triage; fix via Terraform |
| **Dev / verify / monitor** | Terraform for AWS (+ Snowflake); ArgoCD GitOps; prod→staging **masking**; Prometheus / Grafana / Loki; E2E and leading-indicator alerts |
| **Cost / FinOps** | Resource tiers; Spot for batch/training; on-demand / Savings Plans for serving; Cost Explorer visibility |

### 4b. First 90 days (how you help in practice)

| Days | Focus | What the team gets |
|------|-------|--------------------|
| **0–30** | Master current state | Inventory of AWS/EKS/Terraform/GitOps/security/cost; honest scorecard; P0 risks; draft Tier-1 SLIs with product/ML |
| **31–60** | Foundations | Critical path in Terraform; security findings to Slack; Tier-1 app on GitOps; masking design; simple JP rollback / SEV card |
| **61–90** | Raise the bar | Shared RED dashboards and burn/symptom pages; Spot vs on-demand split; light DR sketch; before/after score deltas |

| Harden order (why this sequence) | Explanation |
|----------------------------------|-------------|
| 1 IaC (Terraform) | Fixes stay reviewable and durable |
| 2 GitOps | Safe deploy and fast rollback |
| 3 Observability | You cannot improve what you cannot see |
| 4 Security triage | Detection must reach humans |
| 5 FinOps | Save money only after Tier-1 SLOs are protected |

### 4c. Who benefits day to day

| Teammate | How you help them |
|----------|-------------------|
| ML / data scientists | Faster, safer envs: deploy path, secrets, warehouse sizing, clear Spot vs serving policy |
| Product | Shared Grafana; error-budget based ship/freeze; SLOs on legal/user paths |
| On-call | Fewer noisy pages; clearer symptom alerts; runbooks; blameless postmortems |
| Security | Findings that are triaged, not buried in email |
| Eng lead / finance | Tagged cost, weekly movers, no surprise bills |

### 4d. Experience you bring (proof shape)

| Capability | How it helps GA |
|------------|-----------------|
| AWS + EKS + Terraform | Build and operate the estate they need under products/ML |
| GitOps (ArgoCD) + CI/CD | Auditable deploys and rollback for compliance-sensitive flows |
| Prometheus / Grafana / PagerDuty + logs/traces | Shorter MTTD/MTTR; shared truth with ML |
| Production incident ownership | Legal-grade calm under pressure |
| Cost and security hygiene | Maturity and FinOps domains in the JD |
| English + willingness for JP ops | Docs/design in EN; day-to-day JP readiness |

---

## 5. One-page interview card

| Question | Answer spine |
|----------|--------------|
| What is GA? | Proptech digitizing Japan RE; RENOSY for investors; ITANDI for agencies; data/AI underneath |
| Why join? | Reliability is product/legal; growth-stage platform work matches SRE craft and culture |
| What is their advantage? | Transaction data + agency network + RENOSY brand (flywheel) |
| What will you do? | Assess → harden IaC, GitOps, observability, security triage, FinOps under sales ML; own production with the team |

```txt
Market → products → reliability stakes
  → platform you will own
    → 90 days: see clearly, then make Tier-1 boring and safe
```

