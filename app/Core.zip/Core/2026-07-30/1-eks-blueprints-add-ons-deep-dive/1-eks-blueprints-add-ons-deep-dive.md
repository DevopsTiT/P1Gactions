# 2026-07-30 · Seq 1 · EKS Blueprints Add-ons Deep Dive

# EKS Blueprints Add-ons — Step-by-Step Deep Dive
## Local path: `GithubProjects/Terraform/eks-blueprints-add-ons-main`

> **Core idea:** This repo is **not** Terraform. It is the **Git desired-state for Kubernetes add-ons** that Argo CD syncs. Terraform (EKS Blueprints / GitOps Bridge) creates IAM roles, cluster, and Argo CD metadata; **this repo** holds Helm values + Application / ApplicationSet defs that install AWS LB Controller, Karpenter, Fluent Bit, Prometheus, etc.

---

## 0. What this repo is (and is not)

| Is | Is not |
|----|--------|
| GitOps config for **cluster add-ons** | VPC / EKS control-plane Terraform |
| Argo CD **App-of-Apps** (legacy) + **ApplicationSets** (newer) | Your payment-service app code |
| Helm umbrella + per-addon charts / value layers | A single install script for AWS |
| Designed to work with **EKS Blueprints** | Required to be used only with Blueprints |

**Your copy date stamp (~Nov 2023)** contains **two generations** in one tree:

| Generation | Folders | Pattern |
|------------|---------|---------|
| **Classic (README)** | `chart/` + `add-ons/` | Root Helm chart → child Argo `Application`s → wrapper charts |
| **GitOps Bridge era** | `argocd/` | ApplicationSets + cluster Secret labels/annotations + value layering |

Read both; modern Blueprints tutorials emphasize the **`argocd/`** layout.

---

## 1. Repo map (walk the tree)

```
eks-blueprints-add-ons-main/
├── README.md                 ← classic usage (chart + Application)
├── chart/                    ← ROOT App-of-Apps Helm chart
│   ├── Chart.yaml
│   ├── values.yaml           ← enable: true/false per addon + globals
│   └── templates/*.yaml      ← one Argo Application per addon
├── add-ons/                  ← ~48 wrapper Helm charts (dependencies → upstream)
│   ├── aws-load-balancer-controller/
│   ├── karpenter/
│   ├── metrics-server/
│   └── ...
├── argocd/                   ← newer multi-cluster GitOps Bridge layout
│   ├── bootstrap/control-plane/
│   │   ├── clusters/         ← clusters ApplicationSet
│   │   ├── addons/aws|oss/   ← per-addon ApplicationSets
│   │   └── exclude/          ← bootstrap ApplicationSet
│   ├── charts/addons/        ← default Helm values per addon
│   ├── environments/{dev,staging,prod}/addons/  ← env overlays
│   └── clusters/my-cluster/  ← per-cluster overlays
└── scripts/                  ← helper scripts (if present)
```

---

## 2. Big-picture data flow (step by step)

### Step A — Terraform / Blueprints (outside this repo)

```
1. terraform apply
   → VPC + EKS + OIDC
   → IRSA roles for LB controller, Karpenter, ExternalDNS, …
   → (often) install Argo CD once
   → Write Argo CD cluster Secret with annotations/labels:
        aws_cluster_name, aws_load_balancer_controller_iam_role_arn,
        enable_aws_load_balancer_controller=true,
        addons_repo_url, addons_repo_revision, environment=dev, …
```

This repo does **not** create those IAM roles. It **consumes** the ARNs via annotations (new pattern) or Helm values you inject (classic pattern).

### Step B — Argo CD points at this Git repo

```
2. Root Application OR bootstrap ApplicationSet
   → watches this repo
   → generates child Applications for each enabled addon
```

### Step C — Each child Application installs a Helm chart

```
3. Child app renders Helm (upstream chart + values)
   → creates Deployments/CRDs in kube-system / monitoring / …
   → IRSA annotation on ServiceAccount → pods assume AWS role
```

### Step D — Day-2 change

```
4. PR changes values.yaml (enable addon / bump chart version / env overlay)
   → Argo syncs → addon upgrades
   → No terraform apply needed for pure Helm value changes
```

---

## 3. Classic pattern deep dive (`chart/` + `add-ons/`) — step by step

### Step 1 — Understand the root chart

`chart/` is an **umbrella**: it does not install LB controller pods directly. Its templates create **Argo CD Application CRs**.

`chart/values.yaml` globals:

| Key | Purpose |
|-----|---------|
| `repoUrl` | This Git repo URL |
| `targetRevision` | Branch/tag (often `HEAD`) |
| `clusterName` / `region` / `account` | Passed into child Helm values |
| `destinationServer` | Target cluster API |
| `argoNamespace` / `argoProject` | Where Applications live |

Per-addon blocks look like:

```yaml
awsLoadBalancerController:
  enable: false          # flip to true to deploy
  createNamespace: true
  serviceAccountName:    # IRSA SA name (created by TF usually)
  ignoreDifferences: …   # webhook caBundle, TLS secret noise
```

**Point:** Default is **everything off**. You opt in with `enable: true`.

### Step 2 — Enable addons via the parent Application

README’s bootstrap Application:

```yaml
source:
  path: chart
  helm:
    values: |
      cluster-autoscaler:
        enable: true
      metrics-server:
        enable: true
```

When Argo syncs `path: chart`, Helm renders only templates whose `enable` is true.

### Step 3 — How one template becomes one Application

Example: `chart/templates/aws-load-balancer-controller.yaml`

| Piece | Meaning |
|-------|---------|
| `{{- if .Values.awsLoadBalancerController.enable }}` | Gate |
| `kind: Application` | Child Argo app |
| `source.path: add-ons/aws-load-balancer-controller` | Wrapper chart in this repo |
| `helm.values` | Injects `clusterName`, `region`, SA name, extras |
| `destination.namespace: kube-system` | Where controller runs |
| `syncPolicy.automated.prune` | GitOps delete |
| `ignoreDifferences` | Don’t fight cert-manager/webhook mutations |

### Step 4 — What lives in `add-ons/<name>/`

Each folder is a **thin Helm wrapper**:

| File | Role |
|------|------|
| `Chart.yaml` | Declares **dependency** on upstream chart (e.g. `aws-load-balancer-controller` 1.4.7 from `eks-charts`) |
| `values.yaml` | Defaults (often `serviceAccount.create: false` because TF/IRSA owns SA) |

Example dependency:

```yaml
dependencies:
- name: aws-load-balancer-controller
  version: 1.4.7
  repository: https://aws.github.io/eks-charts
```

**Point:** This repo pins chart versions and opinionated values; upstream owns the real templates.

### Step 5 — Classic sync cascade

```
kubectl apply Application(add-ons) pointing at chart/
  → Argo renders chart Helm
  → Creates Application/aws-load-balancer-controller (if enable)
  → That app renders add-ons/aws-load-balancer-controller
  → Pulls upstream chart dependency
  → Applies controller into kube-system
```

### Step 6 — Classic inventory (~48 add-ons)

Group them by SRE concern:

| Category | Examples in `add-ons/` |
|----------|-------------------------|
| **AWS networking / LB** | aws-load-balancer-controller, external-dns, appmesh, traefik, ingress-nginx |
| **Autoscaling** | cluster-autoscaler, karpenter, keda, vpa |
| **Observability** | kube-prometheus-stack, grafana, prometheus, promtail, aws-for-fluent-bit, aws-cloudwatch-metrics, aws-otel-collector, opentelemetry-collector, datadog-operator, kubecost |
| **Security / policy** | cert-manager, external-secrets, gatekeeper, kyverno, vault |
| **Storage** | aws-efs-csi-driver, smb-csi-driver, ondat, velero |
| **Delivery** | argo-rollouts, argo-workflows |
| **Mesh / CNI extras** | calico, cilium, tetrate-istio |
| **Data / batch** | spark-operator, strimzi-kafka-operator, yunikorn |
| **Misc** | metrics-server, reloader, chaos-mesh, kubernetes-dashboard, nvidia-device-plugin, agones, consul |

---

## 4. Modern pattern deep dive (`argocd/`) — step by step

This matches **GitOps Bridge** used by current EKS Blueprints Argo tutorials.

### Step 1 — Cluster Secret is the contract

Terraform registers the cluster in Argo with **labels** and **annotations**. ApplicationSets select on labels like:

| Label / annotation | Role |
|--------------------|------|
| `enable_aws_load_balancer_controller: "true"` | Turns that ApplicationSet on for this cluster |
| `environment: staging\|prod\|dev` | Picks env value overlay + chart version overrides |
| `aws_cluster_name` | Helm `clusterName` |
| `aws_load_balancer_controller_iam_role_arn` | IRSA annotation on SA |
| `aws_load_balancer_controller_service_account` | SA name |
| `aws_load_balancer_controller_namespace` | Destination ns |
| `addons_repo_url` / `revision` / `basepath` | Where to read **this** repo’s values |

**Point:** Enabling an addon is often a **Terraform label flip**, not editing 50 Application YAMLs.

### Step 2 — Bootstrap ApplicationSet

`argocd/bootstrap/control-plane/exclude/bootstrap.yaml`:

- Generator: all registered clusters (except special `in-cluster` hub name)
- Source path: `addons_repo_basepath + addons_repo_path` (points at ApplicationSet YAMLs)
- Syncs the **catalog of ApplicationSets** into the hub

So first Argo syncs “bootstrap,” which creates many `addons-*-appset` objects.

### Step 3 — Clusters ApplicationSet

`clusters-appset.yaml` syncs per-cluster Git path `clusters/{{name}}` (non-addon cluster resources), recurse, exclude `addons/*`.

### Step 4 — Per-addon ApplicationSet (LB controller example)

File: `addons-aws-load-balancer-controller-appset.yaml`

**Generator merge logic:**

1. Base: clusters with `enable_aws_load_balancer_controller=true` → chart version / repo  
2. Override staging label → maybe same or different version  
3. Override prod label → pin prod chart version  

**Template multi-source Helm:**

| Source | Purpose |
|--------|---------|
| Ref `$values` from this Git repo | Value files only |
| Upstream chart (`eks-charts`) | Real controller chart |

**Value file layers (order matters — later overrides earlier):**

```
1. charts/addons/aws-load-balancer-controller/values.yaml     ← defaults
2. environments/{{environment}}/addons/.../values.yaml        ← env
3. clusters/{{name}}/addons/.../values.yaml                   ← cluster-specific
+ inline values: clusterName, SA name, role-arn from annotations
```

**Sync options:** `CreateNamespace`, `ServerSideApply` (big CRDs), `ignoreDifferences` for TLS secret + webhook `caBundle`.

### Step 5 — Karpenter ApplicationSet (same pattern, AWS-specific)

Same merge generator with `enable_karpenter=true`, OCI chart from `public.ecr.aws`, injects:

- `settings.aws.clusterName`
- `defaultInstanceProfile`
- `interruptionQueueName` (SQS from TF)
- IRSA role ARN on SA

**Point:** Anything that needs AWS resources (SQS, instance profile) must be created in Terraform first; this repo only **wires** names/ARNs into Helm.

### Step 6 — Environment overlays

```
argocd/environments/dev/addons/<addon>/values.yaml
argocd/environments/staging/...
argocd/environments/prod/...
```

Your tree has many **dev** overlays filled; staging/prod often `.keep` placeholders — you fill them as you mature promotion.

### Step 7 — Per-cluster overlays

```
argocd/clusters/my-cluster/addons/<addon>/values.yaml
```

Use for one-off: different replica counts, feature flags, or zone settings on a single cluster.

---

## 5. Side-by-side: classic vs modern

| Concern | Classic `chart/` | Modern `argocd/` |
|---------|------------------|------------------|
| Enable addon | `enable: true` in parent Helm values | Cluster Secret **label** `enable_*=true` |
| Child unit | `Application` per addon | `ApplicationSet` → Applications per cluster |
| Multi-cluster | Manual destinationServer | Generators over all clusters |
| Values | Embedded in Application helm.values | Layered files: charts → env → cluster |
| IRSA | Pass SA name in values | Annotation `eks.amazonaws.com/role-arn` from TF metadata |
| Upstream chart | Via wrapper `add-ons/*/Chart.yaml` dependency | Direct `sources[].chart` + `$values` ref |
| Best when | Single cluster, simple bootstrap | Hub Argo, many clusters, Blueprints Bridge |

---

## 6. Step-by-step: how YOU should use this repo locally

### Path A — Learn classic App-of-Apps (fastest mental model)

1. Install Argo CD on a sandbox EKS.  
2. Create IRSA + SA for metrics-server / LB controller (or use Blueprints).  
3. Apply parent Application with `path: chart` and:

   ```yaml
   metrics-server:
     enable: true
   ```

4. Watch Argo UI: parent Synced → child `metrics-server` Synced.  
5. Open `chart/templates/metrics-server.yaml` + `add-ons/metrics-server/` and trace values.  
6. Flip another `enable: true`, sync, observe cascade.

### Path B — Align with current Blueprints GitOps Bridge

1. Follow Blueprints `patterns/gitops/getting-started-argocd`.  
2. Fork **this** repo (or point TF vars at aws-samples).  
3. Confirm cluster Secret annotations after `terraform apply`.  
4. Set labels `enable_metrics_server=true` etc.  
5. Open matching `argocd/bootstrap/.../*-appset.yaml`.  
6. Change `environments/dev/addons/.../values.yaml`, PR, watch sync.  
7. Promote by copying values to staging/prod overlays + label `environment`.

### Path C — Map to your payment platform

| Need | Addon(s) in this repo |
|------|------------------------|
| ALB Ingress | aws-load-balancer-controller |
| Node scale | karpenter **or** cluster-autoscaler |
| Logs | aws-for-fluent-bit |
| Metrics | kube-prometheus-stack / metrics-server |
| Secrets | external-secrets |
| Certs | cert-manager |
| Canary | argo-rollouts (pairs with your project 22) |
| Backup | velero |

Terraform still owns: VPC, EKS, IRSA roles, S3 for Velero, SQS for Karpenter interruption.

---

## 7. Deep points SRE must not miss

1. **TF vs Git ownership**  
   - TF: IAM, SQS, instance profiles, maybe first Argo install.  
   - Git (this repo): Helm desired state, enable flags, chart versions.

2. **`serviceAccount.create: false` is intentional**  
   Blueprints/TF create SA + IRSA; Helm must not create a conflicting SA without the role annotation.

3. **`ignoreDifferences` on webhooks**  
   Controllers inject `caBundle`; without ignore, Argo forever OutOfSync.

4. **`ServerSideApply=true`**  
   Large CRDs (Prometheus, Crossplane) need SSA to avoid annotation size limits.

5. **`preserveResourcesOnDeletion` on ApplicationSets**  
   Deleting an ApplicationSet does not wipe cluster addons by accident — safer for platform teams.

6. **Pin chart versions in ApplicationSet**  
   staging/prod generators can pin different `addonChartVersion` — treat like change management.

7. **Don’t enable everything**  
   48 addons = huge blast radius. Start: metrics-server + LB controller + fluent-bit + external-secrets.

8. **Repo age**  
   Your zip is ~2023; before prod use, compare with current [aws-samples/eks-blueprints-add-ons](https://github.com/aws-samples/eks-blueprints-add-ons) for chart version bumps.

---

## 8. End-to-end checklist (one addon: AWS LB Controller)

| Step | Action | Where |
|------|--------|-------|
| 1 | Create IRSA role for LB controller | Terraform / Blueprints |
| 2 | Create SA annotated with role-arn | TF or manifest |
| 3a Classic | `awsLoadBalancerController.enable: true` + SA name | Parent Application values |
| 3b Modern | Label `enable_aws_load_balancer_controller=true` + annotations | Cluster Secret |
| 4 | Argo creates Application / ApplicationSet child | Argo UI |
| 5 | Helm installs controller | `kube-system` |
| 6 | Deploy Ingress → ALB appears | AWS console |
| 7 | Change PDB / replicas via values overlay | Git PR |
| 8 | Argo syncs; ignoreDifferences keeps webhooks calm | Argo |

---

## 9. Mental model (one paragraph)

**eks-blueprints-add-ons** is a **catalog + wiring kit** for platform software on EKS. The classic half uses a Helm root chart to spawn Argo Applications that each wrap an upstream Helm chart. The modern half uses ApplicationSets that discover clusters, gate on `enable_*` labels, pull IRSA ARNs from annotations, and layer Helm values from `charts/` → `environments/` → `clusters/`. Either way, Git stays the source of truth for *what* runs on the cluster after Terraform has prepared *AWS identity and infrastructure*.

---

## Related files

| Path | Role |
|------|------|
| This deep dive | `Daily Files/2026-07-30/1-eks-blueprints-add-ons-deep-dive/` |
| Local repo | `/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main` |
| Blueprints | `aws-ia/terraform-aws-eks-blueprints` GitOps pattern |
| Your Argo practices | warp `21_argocd-best-practices-deep-dive` |

## Commands

See [`1.sh`](1.sh).
