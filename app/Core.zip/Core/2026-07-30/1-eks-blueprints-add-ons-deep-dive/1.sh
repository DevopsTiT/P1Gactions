ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main"
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/add-ons"
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/chart/templates" | wc -l
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/argocd/bootstrap/control-plane/addons/aws"
find "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/argocd" -name '*load-balancer*' 
