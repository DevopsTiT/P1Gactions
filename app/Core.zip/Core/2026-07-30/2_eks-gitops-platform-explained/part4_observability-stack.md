# Part 4 — Observability Stack: Prometheus, Thanos, Loki, Tempo, Alerts

> **What it creates:** The three pillars of observability: Metrics (Prometheus + Thanos), Logs (Fluent Bit + Loki), and Traces (OTel Collector + Tempo) — all visible in Grafana. Plus AlertManager routing critical alerts to Slack.

---

## The Observability Architecture

```
Application pod
  │
  ├─ Emits metrics on /metrics endpoint (Prometheus format)
  │   └─ Prometheus scrapes via ServiceMonitor CRD
  │       └─ Thanos sidecar ships to S3 (long-term retention)
  │           └─ Grafana queries via Thanos Querier
  │
  ├─ Writes structured JSON logs to stdout
  │   └─ Fluent Bit DaemonSet reads from /var/log/containers/
  │       └─ Pushes to Loki (S3-backed)
  │           └─ Grafana queries Loki datasource
  │
  └─ Sends OTLP traces to OTel Collector (via env var OTEL_EXPORTER_OTLP_ENDPOINT)
      └─ OTel Agent (DaemonSet) on the same node
          └─ OTel Gateway (Deployment) aggregates
              └─ Pushes to Tempo (S3-backed)
                  └─ Grafana queries Tempo datasource
                      └─ Trace-log correlation via trace_id in log entries
```

---

## File: `gitops/monitoring/prometheus/prometheus.yaml`

```yaml
source:
  chart: kube-prometheus-stack
  targetRevision: 72.9.0
  helm:
    values: |
      prometheus:
        prometheusSpec:
          nodeSelector:
            app: core
          serviceMonitorSelectorNilUsesHelmValues: false
          podMonitorSelectorNilUsesHelmValues: false
          retention: 4h         # SHORT retention — Thanos ships to S3 for long-term

          thanos:
            objectStorageConfig:
              existingSecret:
                name: thanos-objstore-config
                key: objstore.yml

      alertmanager:
        alertmanagerSpec:
          nodeSelector:
            app: core

      grafana:
        serviceAccount:
          annotations:
            eks.amazonaws.com/role-arn: …
        adminPassword: …

      nodeExporter:
        enabled: true          # collects node-level metrics (CPU, disk, network)

      kubeStateMetrics:
        enabled: true          # collects Kubernetes object metrics
```

**Why `retention: 4h`:**
- Prometheus stores metrics in memory and local disk. Long retention = large disk, large memory.
- Thanos takes over for storage beyond 4 hours — it ships blocks to S3 every 2 hours.
- This design: Prometheus = short-term buffer, S3/Thanos = long-term queryable storage.

**`serviceMonitorSelectorNilUsesHelmValues: false`:**
- By default, Prometheus only scrapes services in the same namespace as itself.
- Setting this to `false` means: scrape `ServiceMonitor` objects in ANY namespace.
- Without this, the `ServiceMonitor` in `simple-time-service` namespace would be ignored.

**`kube-prometheus-stack` includes:**
- Prometheus Operator (manages Prometheus config via CRDs)
- Prometheus (metrics storage + query)
- AlertManager (alert routing)
- Grafana (dashboards)
- Node Exporter DaemonSet (host metrics)
- kube-state-metrics (pod/deployment/node object metrics)

---

## File: `gitops/monitoring/thanos/thanos.yaml`

```yaml
source:
  chart: thanos
  targetRevision: 16.0.7
  helm:
    values: |
      query:
        enabled: true          # Thanos Query: federates multiple Prometheus instances
        nodeSelector:
          app: core

      storeGateway:
        enabled: true          # reads S3 blocks and makes them queryable
        nodeSelector:
          app: core

      compactor:
        enabled: true          # compacts + downsamples old blocks in S3
        nodeSelector:
          app: core
```

**Thanos components:**
- **Sidecar** (runs alongside Prometheus): ships 2-hour TSDB blocks from Prometheus to S3. Exposes gRPC endpoint for Thanos Query.
- **Store Gateway**: reads old S3 blocks and exposes them as queryable time series to Thanos Query.
- **Query**: federated query layer — aggregates results from Sidecar (fresh data) + Store Gateway (old data).
- **Compactor**: runs periodically to merge small blocks into larger ones and creates 5m/1h downsamples for faster long-range queries.

**Why Thanos instead of just increasing Prometheus retention:**
- Prometheus memory grows linearly with retention period and series count.
- At 90 days × millions of series: would need hundreds of GB of memory.
- Thanos stores compressed blocks in S3 (~$0.023/GB/month) and queries them on demand.

---

## File: `gitops/monitoring/thanos/thanos-objstore-secret.yaml`

```yaml
# ExternalSecret → AWS Secrets Manager
# Retrieves the S3 bucket config and creates Kubernetes Secret
resources:
  - apiVersion: external-secrets.io/v1beta1
    kind: ExternalSecret
    spec:
      secretStoreRef:
        name: aws-secrets-manager
        kind: ClusterSecretStore
      target:
        name: thanos-objstore-config
      data:
        - secretKey: objstore.yml
          remoteRef:
            key: /cluster-name/thanos/objstore-config
```

**The objstore.yml format:**
```yaml
type: S3
config:
  bucket: cluster-name-thanos-123456789
  region: ap-northeast-1
  endpoint: s3.amazonaws.com
```
This YAML lives as a value in AWS Secrets Manager, pulled by ESO into a Kubernetes Secret, referenced by the Thanos sidecar.

---

## File: `gitops/logs/fluent-bit/fluent-bit.yaml`

```yaml
source:
  chart: fluent-bit
  helm:
    values: |
      daemonSetVolumes:
        - name: varlog
          hostPath:
            path: /var/log        # mount host's /var/log into Fluent Bit pods
      config:
        inputs: |
          [INPUT]
              Name              tail
              Path              /var/log/containers/*.log
              Parser            cri
              Refresh_Interval  5

        outputs: |
          [OUTPUT]
              Name              loki
              Match             *
              Host              loki-gateway.logging.svc.cluster.local
              Port              80
              Labels            job=fluentbit, node=${NODE_NAME}, namespace=${NAMESPACE}
```

**Why DaemonSet (one pod per node):**
- Logs are written to files on the node's filesystem at `/var/log/containers/`.
- Each node needs its own Fluent Bit instance to read its own logs.
- A single central log collector would need to mount every node's filesystem — impossible.

**`Parser: cri`:**
- Kubernetes containers using the CRI runtime (containerd, cri-o) write logs in a specific format with a timestamp prefix.
- The `cri` parser strips this prefix and parses the actual log content.

---

## File: `gitops/logs/loki/loki.yaml`

```yaml
source:
  chart: loki
  targetRevision: 6.30.1
  helm:
    values: |
      deploymentMode: SingleBinary   # demo mode: one pod handles everything
      loki:
        storage:
          type: s3
          bucketNames:
            chunks: {{ .values.lokiBucketName }}   # log data
            ruler: {{ .values.lokiBucketName }}    # alerting rules
        schemaConfig:
          configs:
            - from: "2024-01-01"
              store: tsdb
              object_store: s3
              schema: v13

      singleBinary:
        replicas: 1              # demo trade-off: single replica, not HA
        nodeSelector:
          app: core
```

**`SingleBinary` vs microservices mode:**
- `SingleBinary`: one pod runs all Loki components (ingestor, querier, distributor). Simple, not HA.
- `microservices` / `SimpleScalable`: each component runs separately with its own replicas. Production choice.
- For this demo, SingleBinary is sufficient — the design note in `docs/design-decisions.md` documents this explicitly.

**S3 backend:**
- Loki stores log chunks in S3. Only the index is kept in memory/local disk.
- This makes Loki lightweight despite potentially huge log volumes.

---

## File: `gitops/tracing/otel-collector/otel-collector-agent.yaml`

```yaml
resources:
  - apiVersion: opentelemetry.io/v1alpha1
    kind: OpenTelemetryCollector
    metadata:
      name: otel-agent
      namespace: tracing
    spec:
      mode: DaemonSet         # one agent per node
      config: |
        receivers:
          otlp:
            protocols:
              grpc:
                endpoint: 0.0.0.0:4317   # pods send traces here
              http:
                endpoint: 0.0.0.0:4318

        processors:
          batch:
            timeout: 10s

        exporters:
          otlp:
            endpoint: otel-gateway.tracing.svc.cluster.local:4317
            tls:
              insecure: true

        service:
          pipelines:
            traces:
              receivers: [otlp]
              processors: [batch]
              exporters: [otlp]
```

**Two-tier OTel architecture:**

```
Pod                           Node (DaemonSet)              Gateway (Deployment)         Tempo
│ OTEL_EXPORTER_OTLP_ENDPOINT │                              │                            │
│ = http://$(NODE_IP):4317    │                              │                            │
│─────── traces (OTLP) ──────→│  otel-agent                 │                            │
                               │  (receives, batches)        │                            │
                               │──── forwards to gateway ──→│  otel-gateway              │
                                                              │  (fan-in from all agents) │
                                                              │──── writes to Tempo ─────→│
```

**Why two tiers:**
- The DaemonSet agent receives traces from pods on its own node (via `NODE_IP`). This avoids network overhead of pods sending traces across nodes.
- The Gateway aggregates traces from all agents and applies tail-based sampling (if enabled). It's the single writer to Tempo.
- This pattern scales horizontally: add more pods → more agent bandwidth, same gateway.

**How pods know the agent address:**
- The Deployment template in `charts/simple-time-service/templates/deployment.yaml`:
  ```yaml
  env:
    - name: NODE_IP
      valueFrom:
        fieldRef:
          fieldPath: status.hostIP     # ← injects the node's IP at pod start
    - name: OTEL_EXPORTER_OTLP_ENDPOINT
      value: "http://$(NODE_IP):4317"   # ← agent on the same node
  ```

---

## File: `gitops/alerts/simple-time-service-alerts.yaml`

```yaml
resources:
  - apiVersion: monitoring.coreos.com/v1
    kind: PrometheusRule
    metadata:
      labels:
        release: prometheus   # must match Prometheus's ruleSelector
        notify: slack          # AlertmanagerConfig uses this label to route
    spec:
      groups:
        - name: simple-time-service
          rules:
            - alert: SimpleTimeServiceDown
              expr: min(up{job=~".*simple-time-service.*"}) == 0
              for: 1m           # must be down for 1 min before firing
              labels:
                severity: critical
              annotations:
                summary: "SimpleTimeService scrape target is down"

            - alert: SimpleTimeServiceHPAAtMaxReplicas
              expr: kube_horizontalpodautoscaler_status_current_replicas{…} == max_replicas
              for: 5m
              labels:
                severity: warning

            - alert: SimpleTimeServiceHighLatency
              expr: histogram_quantile(0.99, …) > 0.5
              for: 5m           # P99 > 500ms for 5 min → page
```

**`release: prometheus` label:**
- Prometheus Operator uses a label selector to find `PrometheusRule` objects.
- Without this label, Prometheus doesn't know to load these rules.

**`notify: slack` label:**
- The `AlertmanagerConfig` (see below) matches on this label.
- Alerts with `notify: slack` are routed to Slack. Alerts without it use the default route (no notification).

---

## File: `gitops/alerts/alertmanager-slack.yaml`

```yaml
resources:
  - apiVersion: monitoring.coreos.com/v1alpha1
    kind: AlertmanagerConfig
    metadata:
      name: slack
      namespace: monitoring
    spec:
      route:
        receiver: slack
        groupBy: [alertname, namespace]
        groupWait: 30s
        groupInterval: 5m
        repeatInterval: 4h
        matchers:
          - name: notify
            matchType: =
            value: slack           # only routes alerts with notify=slack label
      receivers:
        - name: slack
          slackConfigs:
            - apiURL:
                name: slack-webhook-url   # Kubernetes Secret (from ESO + Secrets Manager)
                key: url
```

**Alert grouping:**
- `groupBy: [alertname, namespace]`: Multiple alerts with the same name in the same namespace are grouped into one Slack message.
- `groupWait: 30s`: Wait 30 seconds after the first alert fires before sending — collects related alerts into one notification.
- `repeatInterval: 4h`: If an alert stays open, re-notify every 4 hours (not every minute).

**The secret reference:**
- `apiURL.name: slack-webhook-url` — references a Kubernetes Secret named `slack-webhook-url` in the `monitoring` namespace.
- This secret was created by ESO from AWS Secrets Manager → the webhook URL is never in the Git repo.

---

## File: `gitops/monitoring/grafana/simple-time-service-dashboard.yaml`

```yaml
# ExternalSecret syncs a JSON dashboard definition into a Kubernetes ConfigMap.
# Grafana sidecar watches for ConfigMaps with label grafana_dashboard: "1"
# and automatically loads them as dashboards.
resources:
  - apiVersion: v1
    kind: ConfigMap
    metadata:
      name: simple-time-service-dashboard
      namespace: monitoring
      labels:
        grafana_dashboard: "1"   # Grafana sidecar picks this up automatically
    data:
      dashboard.json: |
        { … full Grafana dashboard JSON … }
```

**Why a ConfigMap for dashboards:**
- Grafana reads dashboard JSON from ConfigMaps at startup and watches for changes.
- This means dashboard changes go through Git PRs, not manual Grafana UI edits.
- If the ConfigMap is deleted: the dashboard disappears. If the Git repo is the source: ArgoCD recreates it.

---

## Commands

```bash
# Check Prometheus targets
kubectl port-forward -n monitoring svc/prometheus-operated 9090:9090
# Open http://localhost:9090/targets

# Query a metric
kubectl exec -n monitoring -it prometheus-prometheus-0 -- \
  promtool query instant http://localhost:9090 \
  'histogram_quantile(0.99, sum(rate(http_request_duration_seconds_bucket{job="simple-time-service"}[5m])) by (le))'

# Check Thanos query
kubectl port-forward -n monitoring svc/thanos-query 9091:9090
# Open http://localhost:9091

# Check Loki logs
kubectl port-forward -n logging svc/loki-gateway 3100:80
curl http://localhost:3100/loki/api/v1/query_range \
  --data-urlencode 'query={namespace="simple-time-service"}' \
  --data-urlencode 'since=1h'

# Check OTel Collector agent logs
kubectl logs -n tracing -l app.kubernetes.io/name=otel-agent --tail=30

# Check Alertmanager config
kubectl port-forward -n monitoring svc/alertmanager-operated 9093:9093
# Open http://localhost:9093/#/status

# Test a PrometheusRule loaded correctly
kubectl port-forward -n monitoring svc/prometheus-operated 9090:9090
# http://localhost:9090/rules → should show simple-time-service group

# Check Grafana
kubectl port-forward -n monitoring svc/prometheus-grafana 3000:80
# Username: admin / Password: from Secrets Manager
```
