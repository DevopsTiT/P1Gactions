# Part 6 — GitHub Actions CI: Every Workflow and Governance File

> **What it creates:** The automated quality gates that run on every pull request — preventing broken Terraform, bad Helm charts, wrong PR titles, and unapproved changes to critical files from ever reaching the main branch.

---

## The CI Pipeline Map

```
Pull Request opened
    │
    ├─── .github/workflows/pr-title-check.yaml     → validate PR title format
    ├─── .github/workflows/codeowners-check.yaml   → validate CODEOWNERS syntax
    ├─── .github/workflows/actions-check.yaml      → validate GitHub Actions YAML syntax
    ├─── .github/workflows/terraform-ci.yaml       → fmt, validate, tflint, checkov
    ├─── .github/workflows/gitops-ci.yaml          → helm lint + kubeconform
    └─── .github/workflows/app-image.yaml          → build + push Docker image (main only)
```

---

## File: `.github/CODEOWNERS` — Who Must Review What

```
# Format: <path-pattern> <@owner(s)>

*                           @platform-team     # everything needs platform review by default
terraform/                  @platform-team @security-team
.github/                    @platform-team
gitops/security/            @security-team
gitops/argocd/projects/     @platform-team @security-team
```

**What CODEOWNERS does:**
- When a PR modifies a file matching a pattern, GitHub automatically adds the specified owners as required reviewers.
- The PR CANNOT be merged until those owners approve it.
- This is a GitHub-enforced policy — not just a convention.

**Why `gitops/argocd/projects/` needs security-team review:**
- AppProjects define security boundaries (which repos can deploy where, which cluster-scoped resources are allowed).
- A change here could escalate privileges: a workload project gaining cluster-admin access.
- Requiring security-team review is a compensating control.

**Why `terraform/` needs both platform + security teams:**
- Terraform changes create real AWS resources with real IAM permissions.
- A careless change could create an overly permissive IAM role or remove encryption from an S3 bucket.

---

## File: `.github/branch-protection.md` — Documented Branch Rules

```markdown
Required status checks (all must pass before merge):
  ✓ pr-title-check
  ✓ helm-lint / helm-kubeconform
  ✓ terraform-validate / tflint / checkov
  ✓ codeowners-check

Required approvals: 1 (from CODEOWNERS for changed paths)
No direct pushes to main
No force pushes
Linear history required (no merge commits)
```

**Why document branch protection in a file:**
- Branch protection is configured in GitHub UI (not in Git). If someone accidentally changes it, there's no Git history.
- This file serves as the authoritative documentation of what the settings SHOULD be.
- Teams can verify the GitHub settings match this document during audits.

---

## File: `.github/workflows/pr-title-check.yaml`

```yaml
on:
  pull_request:
    types: [opened, edited, synchronize]

jobs:
  check-title:
    runs-on: ubuntu-latest
    steps:
      - name: Check PR title format
        run: |
          TITLE="${{ github.event.pull_request.title }}"
          # Must match: feat|fix|chore|docs|refactor|test|ci: description
          if ! echo "$TITLE" | grep -qE '^(feat|fix|chore|docs|refactor|test|ci|perf|build)(\(.+\))?: .{3,}$'; then
            echo "PR title does not follow Conventional Commits format"
            echo "Expected: feat(scope): description"
            echo "Got:      $TITLE"
            exit 1
          fi
```

**Why enforce PR title format:**
- PR titles become the first line of merge commits on `main`.
- With a consistent format, `git log --oneline` is readable and the history can be parsed automatically.
- Tools like `semantic-release` use the title to determine version bumps (feat → minor, fix → patch).

---

## File: `.github/workflows/terraform-ci.yaml`

```yaml
on:
  pull_request:
    paths: ['terraform/**', '.github/workflows/terraform-ci.yaml']

jobs:
  validate:
    steps:
      - name: terraform fmt
        run: terraform fmt -check -recursive
        # Fails if any .tf file has non-standard formatting

      - name: terraform init (root)
        run: terraform init -backend=false
        # -backend=false: skips S3 state backend (no AWS credentials needed in CI)

      - name: terraform validate (root)
        run: terraform validate
        # Checks syntax + references without calling AWS API

      - name: terraform validate (app-bootstrap)
        run: terraform validate
        working-directory: terraform/app-bootstrap

      - name: TFLint init + lint
        run: |
          tflint --init
          tflint --recursive
        # Checks for AWS-specific best practices (e.g., deprecated resource types)

  security:
    steps:
      - name: Checkov
        uses: bridgecrewio/checkov-action@v12
        with:
          directory: terraform/
          config_file: terraform/.checkov.yaml
          # Checks for security misconfigurations:
          # - S3 buckets with public access
          # - Resources without encryption
          # - IAM policies with wildcard actions
          # - Security groups open to 0.0.0.0/0
```

**`.checkov.yaml` content (suppressions):**
```yaml
skip-check:
  - CKV_AWS_130   # VPC endpoint for S3 - not needed for demo
  - CKV2_AWS_12   # Default VPC - not used but exists
```

**Why `terraform init -backend=false`:**
- The CI runner doesn't have AWS credentials to read the S3 backend.
- `-backend=false` tells Terraform: "just download providers, don't connect to the backend."
- This is sufficient for `fmt` and `validate` — no state access needed.

**Why both TFLint and Checkov:**
- **TFLint**: Terraform-specific linting — checks for deprecated API versions, invalid variable types, required attributes.
- **Checkov**: Security-specific scanning — checks for security misconfigurations, CIS compliance violations.
- They catch different things: TFLint catches "this EC2 resource is deprecated", Checkov catches "this EC2 instance has a public IP."

---

## File: `.github/workflows/gitops-ci.yaml`

```yaml
on:
  pull_request:
    paths: ['gitops/**', 'k8s/**', 'charts/**', '.github/workflows/gitops-ci.yaml']

jobs:
  helm:
    steps:
      - name: helm lint
        run: |
          helm lint charts/simple-time-service charts/namespaces charts/raw

      - name: helm template | kubeconform
        run: |
          {
            helm template charts/simple-time-service
            helm template charts/namespaces
          } | kubeconform -summary -strict -kubernetes-version 1.34.0 -
        # Validates rendered YAML against Kubernetes 1.34 schema

  yamllint:
    steps:
      - name: yamllint
        run: yamllint -c .yamllint.yaml gitops/ charts/ k8s/
        # Checks YAML syntax: indentation, trailing spaces, duplicate keys

      - name: Post results as PR comment
        if: failure() && github.event_name == 'pull_request'
        uses: actions/github-script@v7
        with:
          script: |
            # Posts formatted report of lint/validate failures to the PR
```

**`.yamllint.yaml` configuration:**
```yaml
extends: default
rules:
  line-length: disable          # don't enforce line length (ArgoCD values are long)
  truthy:
    allowed-values: ['true', 'false']   # require lowercase true/false
  comments:
    require-starting-space: true
```

**`kubeconform` vs `kubectl --dry-run`:**
- `kubectl --dry-run=server` requires a live cluster with credentials.
- `kubeconform` validates against a bundled schema — no cluster needed.
- This means CI can validate Kubernetes YAML correctness without any AWS credentials.

**`-strict` flag in kubeconform:**
- Rejects unknown fields. If you typo `readinessProbes:` (plural, wrong) instead of `readinessProbe:`, kubeconform catches it.
- Without strict mode: unknown fields are silently ignored, the YAML "validates" but the probe never works in the cluster.

---

## File: `.github/workflows/app-image.yaml` — Docker Build and Push

```yaml
on:
  push:
    branches: [main]
    paths: ['app/**', '.github/workflows/app-image.yaml']
  pull_request:
    paths: ['app/**']

jobs:
  build:
    steps:
      - name: Build image (PR — no push)
        if: github.event_name == 'pull_request'
        run: docker build -t simple-time-service:${{ github.sha }} app/

      - name: Build and push (main branch)
        if: github.ref == 'refs/heads/main'
        uses: docker/build-push-action@v6
        with:
          context: app/
          push: true
          tags: |
            docker.io/nabeemdev/simple-time-service:latest
            docker.io/nabeemdev/simple-time-service:${{ github.sha }}
          cache-from: type=gha
          cache-to: type=gha,mode=max
```

**Why build on PRs but only push on main:**
- Building on PRs validates the Dockerfile doesn't have syntax errors and all dependencies install.
- Pushing only from `main` ensures only reviewed, merged code becomes a published image.
- If you push from PRs: every branch creates images, filling the registry with noise.

**Two tags (`latest` and `$github.sha`):**
- `latest`: easy reference for the current production version. Used in the ApplicationSet's `helm.values`.
- `${{ github.sha }}`: the exact commit that produced this image. Critical for reproducibility — if `latest` breaks, you can reference the previous SHA.

**`cache-from: type=gha` / `cache-to: type=gha`:**
- Docker layer caching in GitHub Actions cache.
- Without it: every build re-downloads the Python base image and re-installs all packages (~2 minutes).
- With it: only changed layers are rebuilt. A small app code change takes ~20 seconds.

---

## File: `.yamllint.yaml` — YAML Style Enforcement

```yaml
extends: default
rules:
  line-length:
    max: 150          # allow long lines in Helm values
    level: warning    # warn but don't fail
  truthy:
    allowed-values: ['true', 'false', 'yes', 'no']
  braces:
    min-spaces-inside: 0
    max-spaces-inside: 1
  brackets:
    min-spaces-inside: 0
    max-spaces-inside: 1
  comments:
    require-starting-space: true
    min-spaces-from-content: 2
```

**Why a separate yamllint config:**
- The default yamllint config is very strict (80-char line length) — incompatible with Helm values embedded in ApplicationSets.
- This config is tuned for the project: long lines warned not failed, specific ArgoCD patterns allowed.

---

## File: `.github/CI.md` — CI Documentation

```markdown
## How CI Works

### Pull Request checks
All PRs run these checks. All must pass before merge:
1. **pr-title-check**: Conventional Commits format
2. **terraform-ci**: fmt, validate, tflint, checkov
3. **gitops-ci**: helm lint, kubeconform, yamllint
4. **codeowners-check**: CODEOWNERS syntax validation
5. **actions-check**: GitHub Actions YAML validation

### Merge to main
After merge, these jobs run:
- **app-image**: Builds and pushes Docker image to Docker Hub
```

**Why document CI in the repo:**
- New contributors can understand what checks are running without navigating GitHub Actions UI.
- When a CI job fails, engineers know WHERE to look and WHAT it checks.

---

## Commands

```bash
# Run Terraform CI checks locally
cd terraform
terraform fmt -check -recursive
terraform init -backend=false
terraform validate
tflint --init && tflint --recursive

# Run checkov locally
pip install checkov
checkov -d terraform/ --config-file terraform/.checkov.yaml

# Run GitOps CI checks locally
helm lint charts/simple-time-service charts/namespaces charts/raw
helm template charts/simple-time-service | kubeconform -strict -kubernetes-version 1.34.0 -
yamllint -c .yamllint.yaml gitops/ charts/ k8s/

# Build Docker image locally
docker build -t simple-time-service:local app/
docker run -p 8080:8080 simple-time-service:local

# View GitHub Actions run status
gh run list --limit 10
gh run view <run-id> --log-failed

# Re-run failed jobs
gh run rerun <run-id> --failed-only
```
