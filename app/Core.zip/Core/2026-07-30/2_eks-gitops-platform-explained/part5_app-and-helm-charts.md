# Part 5 — Application & Helm Charts: SimpleTimeService End-to-End

> **What it creates:** The complete lifecycle of the sample application — from Python source code to running pod, from Dockerfile to Helm chart, from `values.yaml` to an ALB-routed HTTPS endpoint, from metrics endpoint to Grafana dashboard.

---

## File: `app/src/app.py` — The Python Microservice

```python
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from prometheus_fastapi_instrumentator import Instrumentator
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
# … OTLP exporters, tracing setup

app = FastAPI(title="simple-time-service")

# Automatically expose /metrics endpoint with HTTP request metrics
Instrumentator().instrument(app).expose(app, include_in_schema=False)

# Structured JSON logger with trace_id + span_id injection
class JSONFormatter(logging.Formatter):
    def format(self, record):
        span = trace.get_current_span()
        ctx = span.get_span_context()
        log_record = {
            "timestamp": …,
            "level": record.levelname,
            "message": record.getMessage(),
        }
        if ctx.is_valid:
            log_record["trace_id"] = format(ctx.trace_id, "032x")
            log_record["span_id"]  = format(ctx.span_id, "016x")
        return json.dumps(log_record)

@app.get("/")
async def root(request: Request):
    logger.info("Handling root request")
    return JSONResponse({
        "time": datetime.now(timezone.utc).isoformat(),
        "ip": request.client.host,
    })

@app.get("/health")
async def health():
    return {"status": "ok"}   # used by ALB health checks + liveness/readiness probes
```

**Why `Instrumentator().instrument(app).expose(app)`:**
- This single line automatically adds Prometheus metrics for EVERY HTTP endpoint:
  - `http_requests_total{method, handler, status}`
  - `http_request_duration_seconds_bucket{…}` (histogram — used for P99 latency)
  - `http_request_size_bytes`, `http_response_size_bytes`
- No manual metric code needed — the library instruments FastAPI at the middleware level.

**Why `trace_id` and `span_id` in logs:**
- When an error occurs, the log entry contains the trace ID.
- In Grafana: click the trace ID in the log entry → jumps to the matching trace in Tempo.
- This is trace-log correlation — one of the key features of the observability stack.

**`OTEL_EXPORTER_OTLP_ENDPOINT` environment variable:**
- The application reads this at startup to find the OTel Collector agent.
- It's set in the Deployment template: `http://$(NODE_IP):4317`
- The application doesn't need to know the agent's address at build time — it's injected at runtime.

---

## File: `app/Dockerfile` — The Container Image

```dockerfile
FROM python:3.12-slim          # minimal base image — no compiler, no package manager

ENV PYTHONDONTWRITEBYTECODE=1  # don't write .pyc files (saves disk, avoids read-only filesystem issues)
    PYTHONUNBUFFERED=1         # print to stdout immediately (important for log shipping)
    PIP_NO_CACHE_DIR=1         # don't cache pip downloads (smaller image layer)

WORKDIR /app

# Create non-root user BEFORE installing packages
RUN groupadd --system --gid 10001 appgroup && \
    useradd --system --uid 10001 --gid appgroup appuser

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt && \
    rm -rf /root/.cache /tmp/* /var/tmp/*   # clean up after install

COPY src/ ./src/
RUN chown -R appuser:appgroup /app && chmod -R 755 /app

USER 10001:10001    # switch to non-root before EXPOSE and CMD

EXPOSE 8080
CMD ["uvicorn", "src.app:app", "--host", "0.0.0.0", "--port", "8080", "--no-access-log"]
```

**Security practices in this Dockerfile:**
- `python:3.12-slim` not `python:3.12` — the full image has compilers and tools that increase attack surface.
- Non-root user (UID 10001) — if the container is compromised, the attacker doesn't have root on the container OS.
- `chown -R appuser` before `USER` — files owned by root cannot be written by the app user (defense in depth).
- `rm -rf /root/.cache` — removes pip's download cache from the final image layer.

**`--no-access-log` on uvicorn:**
- FastAPI generates access log entries for EVERY request, including the `/metrics` scrape (every 15 seconds).
- With `--no-access-log`: the access log noise is eliminated. Application logs only contain meaningful events.

---

## File: `charts/simple-time-service/values.yaml` — The Configuration Contract

```yaml
fullnameOverride: simple-time-service

replicaCount: 2
image:
  repository: docker.io/nabeemdev/simple-time-service
  tag: v1
  pullPolicy: IfNotPresent

service:
  type: ClusterIP
  port: 80
  targetPort: 8080

resources:
  requests:
    cpu: 100m
    memory: 128Mi
  limits:
    cpu: 250m
    memory: 256Mi

livenessProbe:
  path: /health
  initialDelaySeconds: 5
  periodSeconds: 10

readinessProbe:
  path: /health
  initialDelaySeconds: 5
  periodSeconds: 5

hpa:
  enabled: true
  minReplicas: 2
  maxReplicas: 10
  targetCPUUtilizationPercentage: 70

pdb:
  enabled: true
  minAvailable: 1   # at least 1 replica during disruptions

serviceAccount:
  create: true

networkPolicy:
  enabled: true

serviceMonitor:
  enabled: true      # triggers Prometheus scraping
  interval: 15s

tracing:
  enabled: true
  serviceName: simple-time-service
  agentPort: 4317    # OTel agent gRPC port on the node

podSecurityContext:
  runAsNonRoot: true
  runAsUser: 10001
  fsGroup: 10001
  seccompProfile:
    type: RuntimeDefault

containerSecurityContext:
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: [ALL]
```

**`readOnlyRootFilesystem: true`:**
- The container cannot write to its own filesystem. If malware is injected, it cannot persist itself.
- Kyverno's `require-read-only-root-filesystem` policy (in Audit mode) checks for this.

**`seccompProfile: RuntimeDefault`:**
- Enables the default seccomp profile from the container runtime.
- This blocks ~300 rare system calls that are almost never needed by applications but are common in exploit chains.
- Reduces the attack surface significantly with zero application code changes.

**`capabilities: drop: [ALL]`:**
- Drops all Linux capabilities from the container process.
- Normal Python/FastAPI applications don't need any capabilities.
- Attacker in the container: cannot bind port <1024, cannot use raw sockets, cannot set UIDs, etc.

---

## File: `charts/simple-time-service/templates/deployment.yaml`

```yaml
spec:
  {{- if not .Values.hpa.enabled }}
  replicas: {{ .Values.replicaCount }}   # only set replicas if HPA is disabled
  {{- end }}
```

**Why `{{- if not .Values.hpa.enabled }}`:**
- When HPA is enabled, ArgoCD or Kubernetes reconciliation would fight with HPA over the replica count.
- HPA sets replicas to X based on CPU. Then ArgoCD syncs the Deployment and resets replicas to `values.replicaCount`.
- Solution: if HPA is enabled, DON'T set `replicas` in the Deployment spec — let HPA own it.
- ArgoCD uses `ignoreDifferences` in workloads-project (or sync option) to also ignore the `spec.replicas` field.

```yaml
containers:
  - name: simple-time-service
    {{- if .Values.tracing.enabled }}
    env:
      {{- if not .Values.tracing.endpoint }}
      - name: NODE_IP
        valueFrom:
          fieldRef:
            fieldPath: status.hostIP   # pod gets its own node's IP at runtime
      {{- end }}
      - name: OTEL_EXPORTER_OTLP_ENDPOINT
        value: "http://$(NODE_IP):{{ .Values.tracing.agentPort }}"
    {{- end }}
```

**Downward API (`fieldRef: status.hostIP`):**
- The pod gets its node's IP as an environment variable at startup.
- This is used to construct the OTel agent endpoint: `http://10.0.1.23:4317`
- The DaemonSet agent listens on `0.0.0.0:4317` on the node, so any pod on that node can reach it.

---

## File: `charts/simple-time-service/templates/networkpolicy.yaml`

```yaml
{{- if .Values.networkPolicy.enabled }}
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: simple-time-service
  namespace: {{ .Release.Namespace }}
spec:
  podSelector:
    matchLabels:
      {{- include "simple-time-service.selectorLabels" . | nindent 6 }}
  policyTypes: [Ingress, Egress]

  ingress:
    - from:
        - namespaceSelector:
            matchLabels:
              kubernetes.io/metadata.name: kube-system   # allow ingress controller
      ports:
        - port: 8080
    - from:
        - namespaceSelector:
            matchLabels:
              kubernetes.io/metadata.name: monitoring    # allow Prometheus scraping
      ports:
        - port: 8080

  egress:
    - to: []      # allow all egress (simplification for demo)
      ports:
        - port: 443     # HTTPS to external APIs
        - port: 4317    # OTel agent (gRPC)
        - port: 53      # DNS
{{- end }}
```

**Why NetworkPolicy:**
- Without NetworkPolicy: any pod can reach any other pod on any port.
- If the app is compromised: attacker can reach the Prometheus server, the Kubernetes API, internal services.
- With NetworkPolicy: only allowed traffic sources can reach port 8080 on the app.
- The monitoring namespace can scrape `/metrics`. The kube-system namespace (ALB controller, CoreDNS) can reach it. Nothing else can.

---

## File: `charts/simple-time-service/templates/servicemonitor.yaml`

```yaml
{{- if .Values.serviceMonitor.enabled }}
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: {{ include "simple-time-service.fullname" . }}
  labels:
    release: prometheus    # ← Prometheus picks this up via ruleSelector
spec:
  selector:
    matchLabels:
      {{- include "simple-time-service.selectorLabels" . | nindent 6 }}
  endpoints:
    - port: http
      path: /metrics
      interval: {{ .Values.serviceMonitor.interval }}
{{- end }}
```

**How this connects to Prometheus:**
1. The Prometheus Operator watches for `ServiceMonitor` CRDs cluster-wide (because of `serviceMonitorSelectorNilUsesHelmValues: false`).
2. It finds this `ServiceMonitor` in the `simple-time-service` namespace.
3. It configures Prometheus to scrape the service on `/metrics` every 15s.
4. The metrics become queryable: `http_requests_total{job="simple-time-service"}`.

Without `ServiceMonitor`, the app runs but Prometheus knows nothing about it — no metrics, no alerts.

---

## File: `gitops/app/simple-time-service/simple-time-service.yaml` — The Workload ApplicationSet

```yaml
annotations:
  argocd.argoproj.io/sync-wave: "8"   # after platform components are ready

spec:
  generators:
    - clusters:
        values:
          domainName: '{{index .metadata.annotations "domain-name"}}'
  template:
    spec:
      project: workloads          # cannot create cluster-scoped resources
      source:
        path: charts/simple-time-service
        helm:
          values: |
            image:
              repository: docker.io/nabeemdev/simple-time-service
              tag: latest

            ingress:
              enabled: true
              className: alb
              annotations:
                alb.ingress.kubernetes.io/scheme: internet-facing
                alb.ingress.kubernetes.io/target-type: ip
                alb.ingress.kubernetes.io/listen-ports: '[{"HTTP":80},{"HTTPS":443}]'
                alb.ingress.kubernetes.io/ssl-redirect: "443"
                alb.ingress.kubernetes.io/healthcheck-path: /health

              hosts:
                - host: simple-time-service.platform.{{ .values.domainName }}

            tracing:
              enabled: true
              serviceName: simple-time-service
```

**ALB Ingress annotations explained:**
- `scheme: internet-facing` → ALB is created in public subnets with a public IP.
- `target-type: ip` → ALB routes directly to pod IPs (not node IPs). Required for Fargate; better for EKS with VPC CNI.
- `listen-ports: HTTP:80,HTTPS:443` → ALB listens on both ports.
- `ssl-redirect: 443` → HTTP requests are 301-redirected to HTTPS.
- `healthcheck-path: /health` → ALB pings this endpoint; unhealthy pods are removed from the target group.

**`domainName` from cluster annotations:**
The ApplicationSet generator reads `domain-name` annotation from the ArgoCD cluster secret. This is set when registering the cluster: `argocd cluster add --annotation domain-name=example.com`. This makes the ApplicationSet environment-specific without hardcoding domain names.

---

## File: `charts/raw/` — The Pass-Through Chart

```yaml
# charts/raw/templates/resources.yaml
{{- range .Values.resources }}
---
{{ toYaml . }}
{{- end }}
```

```yaml
# charts/raw/values.yaml
resources: []   # list of arbitrary Kubernetes YAML objects
```

**What this does:**
- The `raw` chart takes a list of arbitrary Kubernetes YAML objects in `values.resources[]` and renders them verbatim.
- Used in ApplicationSets where the resource to deploy doesn't have a Helm chart (CRDs, `ClusterSecretStore`, `PrometheusRule`, `AlertmanagerConfig`, `Schedule`).
- Without `raw`: you'd need a separate Git folder full of YAML files. With `raw`: the YAML is inline in the ApplicationSet's `helm.values`.

**Example usage (from `kyverno-policies.yaml`):**
```yaml
source:
  path: charts/raw
  helm:
    values: |
      resources:
        - apiVersion: kyverno.io/v1
          kind: ClusterPolicy
          metadata:
            name: require-resource-limits
          spec: …
```

---

## Commands

```bash
# Run app locally
cd app
pip install -r requirements.txt
uvicorn src.app:app --port 8080

# Test endpoints
curl http://localhost:8080/
curl http://localhost:8080/health
curl http://localhost:8080/metrics  # Prometheus format metrics

# Build image locally
docker build -t simple-time-service:local app/
docker run -p 8080:8080 simple-time-service:local

# Render Helm chart to YAML (inspect what ArgoCD will apply)
helm template charts/simple-time-service \
  --set image.tag=latest \
  --set ingress.enabled=true

# Lint the chart
helm lint charts/simple-time-service

# Validate rendered YAML against Kubernetes schema
helm template charts/simple-time-service | \
  kubeconform -strict -kubernetes-version 1.34.0 -

# Check the ApplicationSet is creating Applications
kubectl get applicationsets -n argocd
kubectl get applications -n argocd | grep simple-time-service

# Port-forward to app (bypasses ALB for local debugging)
kubectl port-forward -n simple-time-service svc/simple-time-service 8080:80
curl http://localhost:8080/

# Check HPA status
kubectl get hpa -n simple-time-service
kubectl describe hpa -n simple-time-service simple-time-service
```
