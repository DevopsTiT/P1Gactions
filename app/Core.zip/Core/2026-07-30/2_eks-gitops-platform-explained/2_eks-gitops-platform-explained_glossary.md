# EKS GitOps Platform — Glossary

**ArgoCD**
A GitOps continuous delivery tool for Kubernetes. It watches a Git repository and automatically applies Kubernetes manifest changes to the cluster whenever the repository is updated. "Source of truth" = Git, not the cluster.

**App of Apps pattern**
An ArgoCD design where one "root" Application watches a folder of other Application/ApplicationSet YAMLs. The root app discovers and manages every other app. Adding a new YAML to the folder = ArgoCD creates and manages that new application.

**ApplicationSet**
An ArgoCD object that generates multiple Application objects from a template and a generator (e.g., one per cluster). Instead of writing 10 identical Applications for 10 clusters, you write one ApplicationSet.

**Sync wave (`argocd.argoproj.io/sync-wave`)**
A number annotation on ArgoCD resources that controls deployment order. Lower waves run first. Wave -1 runs before wave 0 which runs before wave 1. Used to ensure namespaces exist before other resources are created in them.

**AppProject (ArgoCD)**
A security boundary in ArgoCD. Defines which Git repos, Helm repos, target namespaces, and Kubernetes resource types an Application is allowed to deploy. Prevents a workload app from creating cluster-admin resources.

**prune (ArgoCD sync policy)**
When `prune: true`, ArgoCD deletes Kubernetes resources that exist in the cluster but no longer exist in Git. Without it, deleted YAML files leave orphaned resources running forever.

**selfHeal (ArgoCD sync policy)**
When `selfHeal: true`, ArgoCD reverts manual `kubectl` changes back to the Git state within ~3 minutes. Git is the source of truth — human edits are undone automatically.

**Karpenter**
An open-source Kubernetes node autoscaler. Unlike Cluster Autoscaler (which scales fixed EC2 ASGs), Karpenter directly calls the EC2 API to provision the exact right instance type for pending pods in ~30 seconds.

**NodePool (Karpenter)**
A Karpenter custom resource that defines constraints for nodes Karpenter can provision: which instance types, Spot vs On-Demand, disk size, AMI, labels, and taints. Multiple NodePools allow different types of nodes for different workloads.

**EC2NodeClass (Karpenter)**
A Karpenter custom resource that defines the EC2-specific configuration for nodes: which AMI, which subnets, which security groups, which instance profile. Referenced by NodePool objects.

**Spot interruption queue**
An SQS queue that receives AWS EventBridge events when a Spot EC2 instance is about to be terminated (2-minute warning). Karpenter reads this queue and drains the node gracefully before AWS reclaims it.

**IRSA (IAM Roles for Service Accounts)**
A mechanism that lets Kubernetes pods assume AWS IAM roles without node-level credentials. The pod's ServiceAccount has an annotation pointing to an IAM role ARN. AWS issues temporary credentials via the cluster's OIDC provider.

**OIDC provider (AWS)**
An AWS IAM Identity Provider created for the EKS cluster. It issues JSON Web Tokens (JWTs) that pods use to prove their identity to AWS when requesting IRSA credentials.

**Pod Identity (EKS)**
An alternative to IRSA for newer EKS versions. An agent DaemonSet on each node intercepts AWS SDK calls and provides credentials. Simpler configuration than OIDC/IRSA. Used by Karpenter in this platform.

**External Secrets Operator (ESO)**
A Kubernetes operator that syncs secrets from external stores (AWS Secrets Manager, Vault, GCP Secret Manager) into Kubernetes Secrets. The Kubernetes Secret is created and kept up-to-date automatically.

**ClusterSecretStore**
An ESO cluster-wide resource that defines connection details to a secret backend (e.g., AWS Secrets Manager). Namespaced `ExternalSecret` objects reference it. One store configuration works for all namespaces.

**ExternalSecret**
An ESO resource that says: "create a Kubernetes Secret named X from this external secret path Y". ESO polls the external store and keeps the Kubernetes Secret updated.

**Reloader (Stakater)**
A Kubernetes controller that watches Secrets and ConfigMaps. When they change, it triggers a rolling restart of Deployments that reference them. Eliminates the need for manual restarts after secret rotation.

**Kyverno**
A Kubernetes policy engine. Runs as an admission webhook — every `kubectl apply` passes through it. Can Audit (report violations) or Enforce (block non-compliant resources). Policies are written as YAML, not Rego.

**Admission webhook**
A Kubernetes API extension point. Before creating/updating a resource, Kubernetes sends it to a webhook server for validation or mutation. Kyverno uses this to check policies. If the webhook is down: resources can't be created.

**ClusterPolicy (Kyverno)**
A cluster-scoped Kyverno policy that applies to all namespaces. Examples: require resource limits, disallow root containers, require liveness probes. Namespaced `Policy` objects apply to one namespace only.

**PolicyReport (Kyverno)**
A Kubernetes resource created by Kyverno in Audit mode that lists all policy violations for resources in a namespace. Read with `kubectl get policyreport -A`.

**EBS CSI Driver**
A Kubernetes storage driver that provisions AWS EBS (Elastic Block Store) volumes when a PersistentVolumeClaim is created. Required for any stateful workload that needs durable block storage.

**StorageClass**
A Kubernetes object that defines a "class" of storage. `gp3` StorageClass means: create a gp3 EBS volume. The `isDefaultClass: true` setting means any PVC without an explicit StorageClass gets gp3.

**`WaitForFirstConsumer` (volume binding mode)**
A StorageClass setting that delays EBS volume creation until a pod is scheduled. This ensures the volume is created in the same Availability Zone as the pod — avoiding cross-AZ mount failures.

**AWS Load Balancer Controller**
A Kubernetes controller that provisions AWS Application Load Balancers (ALBs) from Kubernetes Ingress objects. Reads annotations like `alb.ingress.kubernetes.io/scheme: internet-facing` to configure the ALB.

**ExternalDNS**
A Kubernetes controller that automatically creates Route53 DNS records matching hostnames in Ingress and Service objects. When an Ingress is created with `host: myapp.example.com`, ExternalDNS creates an A record.

**Prometheus Operator**
A Kubernetes operator that manages Prometheus configuration via CRDs (`ServiceMonitor`, `PodMonitor`, `PrometheusRule`, `AlertmanagerConfig`). Instead of editing Prometheus config files, you apply YAML objects.

**ServiceMonitor**
A Prometheus Operator CRD that tells Prometheus which Kubernetes Services to scrape and on which path/port/interval. When `ServiceMonitor` is created, Prometheus automatically starts scraping that service.

**PrometheusRule**
A Prometheus Operator CRD that defines alerting rules and recording rules. Prometheus loads these rules automatically when they exist in the cluster with the matching label selector.

**AlertmanagerConfig**
A Prometheus Operator CRD that configures AlertManager routing — which alerts go where (Slack, PagerDuty, email). Scoped to a namespace; AlertManager merges all configs cluster-wide.

**Thanos**
An open-source extension to Prometheus for long-term storage. The Thanos sidecar runs alongside Prometheus, ships 2-hour blocks to S3, and exposes a gRPC endpoint. Thanos Query aggregates data from all Prometheus instances and S3.

**Loki**
A log aggregation system by Grafana Labs. Stores logs in S3 with a small index. Queried using LogQL (similar to PromQL). Designed to be lightweight — doesn't index log content, only metadata labels.

**Fluent Bit**
A lightweight log processor/forwarder running as a DaemonSet. Reads container log files from the node's filesystem, parses them, and forwards to Loki, CloudWatch, Elasticsearch, etc.

**OpenTelemetry (OTel)**
An open-source observability framework. Provides APIs, SDKs, and the OTel Collector for collecting metrics, logs, and traces in a vendor-neutral format. The `OTEL_EXPORTER_OTLP_ENDPOINT` env var tells applications where to send telemetry.

**OTel Collector**
A component that receives telemetry data (traces, metrics, logs), processes it, and exports it to backends. In this platform: Agent (DaemonSet) receives from pods on the same node; Gateway (Deployment) aggregates and writes to Tempo.

**Tempo**
A distributed tracing backend by Grafana Labs. Stores traces in S3 (one file per trace). Queried from Grafana. Designed for high-volume trace ingestion at low cost.

**OTLP (OpenTelemetry Protocol)**
The standard protocol for sending telemetry data to an OTel Collector. Uses gRPC (port 4317) or HTTP (port 4318). Language SDKs emit OTLP; the Collector receives OTLP.

**Trace-log correlation**
The ability to click a trace ID in a log entry and jump to the matching distributed trace. Made possible by the app injecting `trace_id` and `span_id` into every log entry when OpenTelemetry is active.

**Velero**
A Kubernetes cluster backup tool. Backs up Kubernetes objects (Deployments, ConfigMaps, Secrets) to S3 and can snapshot EBS volumes. Restores individual namespaces or the entire cluster from backup.

**Helm**
The Kubernetes package manager. A "chart" is a collection of YAML templates that render to Kubernetes resources when deployed with specific values. Used in this platform for every third-party tool installation.

**Helm values**
Configuration inputs for a Helm chart. The chart provides a `values.yaml` with defaults; you override specific values at deploy time. In this platform, values are embedded inline in the ArgoCD ApplicationSet's `helm.values` block.

**`charts/raw/`**
A minimal Helm pass-through chart. Takes a list of arbitrary Kubernetes YAML in `values.resources[]` and renders them verbatim. Used to deploy raw Kubernetes objects (CRDs, `ClusterPolicy`, `Schedule`) via ArgoCD without needing a dedicated Helm chart.

**kubeconform**
A tool that validates Kubernetes YAML manifests against the Kubernetes JSON Schema. Faster than `kubectl --dry-run` because it doesn't need a live cluster. Used in CI to catch schema errors in Helm charts.

**TFLint**
A Terraform linter that checks for provider-specific best practices and deprecated APIs. More opinionated than `terraform validate`. Example: warns when an ECS task definition uses a deprecated field.

**Checkov**
A static analysis tool for infrastructure-as-code (Terraform, CloudFormation, Kubernetes, Helm). Checks for security misconfigurations against CIS benchmarks and other security standards.

**CODEOWNERS**
A GitHub file (`.github/CODEOWNERS`) that maps file paths to required reviewers. When a PR changes a file matching a pattern, GitHub automatically adds the owner as a required reviewer.

**Conventional Commits**
A Git commit message convention: `type(scope): description`. Types include `feat` (new feature), `fix` (bug fix), `chore` (maintenance), `docs` (documentation). Enables automated changelog generation and semantic versioning.

**Seccomp profile (RuntimeDefault)**
A Linux kernel security mechanism that restricts which system calls a process can make. `RuntimeDefault` enables the container runtime's default seccomp profile, blocking ~300 rarely-needed but dangerous syscalls.

**Linux capabilities**
Granular permissions that can be granted to or dropped from a Linux process. `capabilities: drop: [ALL]` removes every capability (bind port <1024, raw sockets, set UIDs, etc.) from the container process.

**NetworkPolicy**
A Kubernetes object that defines allowed ingress and egress traffic for pods. Without NetworkPolicy: all pods can reach all other pods. With it: explicit rules control which namespaces/pods can communicate.

**Downward API**
A Kubernetes mechanism for injecting cluster metadata into pods as environment variables or files. `fieldRef: status.hostIP` injects the node's IP address — used to find the OTel DaemonSet agent running on the same node.

**HPA (Horizontal Pod Autoscaler)**
A Kubernetes controller that automatically adjusts pod replica count based on metrics (CPU, memory, custom). When CPU exceeds the target percentage, HPA adds replicas. When it drops, HPA removes them.

**PDB (PodDisruptionBudget)**
A Kubernetes policy that limits how many pods can be unavailable at once during voluntary disruptions (node upgrades, drains). `minAvailable: 1` ensures at least 1 replica is always running.

**`WaitForFirstConsumer` (EBS binding)**
Delays PersistentVolume creation until a pod that uses the PVC is scheduled. This ensures the EBS volume is created in the same AZ as the pod, preventing cross-AZ mount errors.

**Server-Side Apply (SSA)**
A Kubernetes API mode where the server owns field management and merges changes declaratively. Reduces conflicts when multiple controllers manage the same object. `syncOptions: ServerSideApply=true` enables it in ArgoCD.
