# eks-gitops-platform/ — Complete File-by-File Deep Dive

> This guide walks through every file in the eks-gitops-platform repository.
> Every Terraform, Helm, YAML, Python, and workflow file is explained: WHY it exists, WHAT every field does, and HOW it connects to everything else.
> Separate part files exist for each major section — see the folder structure below.

---

## How to Read This Guide

```
This repository has five major sections:

  terraform/        → Provisions AWS infrastructure (VPC, EKS, IAM roles, S3, Secrets Manager)
  gitops/           → ArgoCD-managed Kubernetes configurations (the GitOps control plane)
  charts/           → Helm chart definitions (namespaces, raw resources, app chart)
  app/              → The sample Python microservice (SimpleTimeService)
  .github/          → GitHub Actions CI pipelines + governance files
```

---

## The Master Flow: From git push to running pod

```
STEP 1: Developer writes Terraform in terraform/
        → terraform apply creates: VPC, EKS cluster, IRSA roles, S3 buckets, Secrets Manager secrets
        ↓
STEP 2: terraform/scripts/bootstrap.sh runs manually (one-time)
        → helm install argocd in the cluster
        → kubectl apply gitops/bootstrap/root-app.yaml
        ↓
STEP 3: root-app.yaml (App of Apps) tells ArgoCD:
        "Watch the entire gitops/ folder recursively"
        → ArgoCD discovers every ApplicationSet YAML in gitops/
        ↓
STEP 4: ArgoCD processes sync-waves (ordered by argocd.argoproj.io/sync-wave annotation):
        Wave -1:  namespaces/namespaces.yaml       → creates every namespace
        Wave  1:  networking/aws-load-balancer-controller.yaml
        Wave  2:  secrets/external-secrets/external-secret-operator.yaml
        Wave  3:  auto-scaling/karpenter/karpenter.yaml
        Wave  3:  security/kyverno/kyverno.yaml
        Wave  4:  secrets/external-secrets/cluster-secret-store.yaml
        Wave  5:  security/kyverno/kyverno-policies.yaml
        Wave  6:  monitoring/prometheus/prometheus.yaml
        Wave  7:  logs/loki/loki.yaml + tracing/tempo/tempo.yaml
        Wave  8:  gitops/app/simple-time-service/simple-time-service.yaml
        Wave  9:  alerts/alertmanager-slack.yaml
        Wave 10:  alerts/simple-time-service-alerts.yaml
        ↓
STEP 5: When a developer pushes app code:
        .github/workflows/app-image.yaml builds + pushes Docker image to Docker Hub
        ↓
STEP 6: Developer updates chart tag or ArgoCD auto-deploys latest
        → ArgoCD syncs simple-time-service application
        → charts/simple-time-service/ renders the Deployment, Service, HPA, PDB, Ingress
        → AWS Load Balancer Controller creates an ALB from the Ingress annotation
        → ExternalDNS creates a Route53 DNS record from the Ingress hostname annotation
```

---

## Part Files Index

```
2_eks-gitops-platform-explained/
  ├─ part1_terraform-infrastructure.md    → all terraform/ files explained
  ├─ part2_argocd-gitops-bootstrap.md     → gitops/bootstrap/ + gitops/argocd/ + App of Apps pattern
  ├─ part3_platform-components.md         → networking, autoscaling, secrets, storage, security
  ├─ part4_observability-stack.md         → prometheus, thanos, loki, tempo, alerts
  ├─ part5_app-and-helm-charts.md         → app/, charts/, gitops/app/
  ├─ part6_github-actions-ci.md           → .github/workflows/ + CODEOWNERS + branch-protection
  └─ 2_eks-gitops-platform-explained_glossary.md
```

---

## Repository Structure at a Glance

```
eks-gitops-platform-main/
│
├─ terraform/                   ← AWS infrastructure (VPC, EKS, IAM IRSA roles, S3, Secrets)
│   ├─ main.tf                  → calls vpc + eks modules
│   ├─ karpenter.tf             → Karpenter controller + node IAM role
│   ├─ *-irsa.tf                → one file per component that needs an AWS IAM role
│   ├─ loki.tf / thanos.tf / tempo.tf / velero.tf / secrets-manager.tf
│   ├─ modules/vpc/             → custom VPC module
│   ├─ modules/eks/             → custom EKS module (v1.34, managed node groups)
│   └─ app-bootstrap/           → separate root for ECR + app IAM
│
├─ gitops/                      ← ArgoCD-managed platform config (YAML only, no Helm rendering here)
│   ├─ bootstrap/root-app.yaml  → the App of Apps entry point
│   ├─ argocd/                  → ArgoCD self-management + AppProjects
│   ├─ namespaces/              → ApplicationSet that creates all namespaces
│   ├─ networking/              → ALB controller + ExternalDNS
│   ├─ auto-scaling/            → Karpenter + Cluster Autoscaler + metrics-server
│   ├─ secrets/                 → External Secrets Operator + ClusterSecretStore + Reloader
│   ├─ storage/                 → EBS CSI driver
│   ├─ security/                → Kyverno + policies + policy-reporter
│   ├─ monitoring/              → Prometheus + Thanos + Grafana
│   ├─ logs/                    → Fluent Bit + Loki
│   ├─ tracing/                 → OpenTelemetry Collector + Tempo
│   ├─ backup/                  → Velero + daily schedule
│   ├─ alerts/                  → AlertmanagerConfig + PrometheusRules
│   └─ app/                     → ApplicationSet for SimpleTimeService workload
│
├─ charts/                      ← Helm chart source code
│   ├─ namespaces/              → chart that creates Namespace + ResourceQuota per entry
│   ├─ raw/                     → pass-through chart (renders raw YAML as Helm)
│   └─ simple-time-service/     → full production-grade chart for the sample app
│
├─ app/                         ← Python microservice source
│   ├─ src/app.py               → FastAPI + Prometheus + OpenTelemetry
│   ├─ Dockerfile               → multi-stage, non-root, slim
│   └─ requirements.txt
│
├─ docs/                        ← Architecture docs, runbooks, design decisions
│   └─ runbooks/                → 13 specific runbooks (Karpenter, Loki, Velero, etc.)
│
├─ scripts/                     ← k6 + Python load test scripts
└─ .github/                     ← CI workflows + CODEOWNERS + branch-protection docs
```
