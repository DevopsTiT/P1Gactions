# Part 3 — Platform Components: Networking, Autoscaling, Secrets, Security

> **What it creates:** The operational infrastructure that every workload depends on — ingress routing (ALB), node provisioning (Karpenter), secret injection (ESO), automatic pod restarts on secret changes (Reloader), policy enforcement (Kyverno), and EBS volumes (EBS CSI).

---

## File: `gitops/networking/ingress-controller/aws-load-balancer-controller.yaml`

```yaml
source:
  repoURL: https://aws.github.io/eks-charts
  chart: aws-load-balancer-controller
  targetRevision: 1.13.3
  helm:
    values: |
      clusterName: {{ .values.clusterName }}
      serviceAccount:
        annotations:
          eks.amazonaws.com/role-arn: arn:aws:iam::{{ .values.accountId }}:role/{{ .values.clusterName }}-aws-lb-controller-irsa
      nodeSelector:
        app: core
      tolerations:
        - key: app, value: core, effect: NoSchedule
```

**What the AWS Load Balancer Controller does:**
- Watches Kubernetes `Ingress` objects with `annotations: kubernetes.io/ingress.class: alb`.
- Calls the AWS API to create/update/delete Application Load Balancers in AWS.
- The ALB is created in the public subnets (tagged `kubernetes.io/role/elb = 1`).

**Without this controller:**
- `Ingress` objects sit in `Pending` state — Kubernetes doesn't know how to create an ALB.
- Services type `LoadBalancer` would use the default AWS cloud controller (which creates CLBs, not ALBs).

**The IRSA annotation:**
- The ServiceAccount `aws-load-balancer-controller` has annotation `eks.amazonaws.com/role-arn` pointing to the IAM role created in `terraform/aws-load-balancer-controller-irsa.tf`.
- This IAM role has permissions to: create/describe/delete ALBs, target groups, listener rules, security groups.

**`nodeSelector: app: core` + tolerations:**
- This controller MUST run on core nodes (not Karpenter nodes).
- If it ran on a Karpenter node and that node was being replaced, the controller would be briefly unavailable during the replacement — potentially causing ALB health check failures.

---

## File: `gitops/networking/external-dns/external-dns.yaml`

```yaml
source:
  chart: external-dns
  helm:
    values: |
      provider: aws
      aws:
        region: {{ .values.region }}
      domainFilters:
        - {{ .values.domainName }}    # only manages records under this domain
      txtOwnerId: {{ .values.clusterName }}
      serviceAccount:
        annotations:
          eks.amazonaws.com/role-arn: arn:aws:iam::…:role/…-external-dns-irsa
```

**What ExternalDNS does:**
- Watches `Ingress` and `Service` objects for hostname annotations.
- Creates/updates/deletes Route53 DNS records matching those hostnames.

**Example:** When `simple-time-service.yaml` creates an Ingress with `host: simple-time-service.platform.example.com`, ExternalDNS automatically creates an A record in Route53 pointing to the ALB's DNS name.

**`txtOwnerId`:**
- ExternalDNS writes a TXT record alongside each A record with the cluster name as the owner ID.
- This prevents two clusters from fighting over the same DNS record — each cluster only manages records it owns.

**`domainFilters`:**
- ExternalDNS ONLY creates records under `example.com`. It won't accidentally modify records for `other-company.com` even if an Ingress annotation specifies a wrong domain.

---

## File: `gitops/auto-scaling/karpenter/karpenter.yaml`

```yaml
source:
  repoURL: public.ecr.aws/karpenter
  chart: karpenter
  targetRevision: 1.4.0
  helm:
    values: |
      settings:
        clusterName: {{ .values.clusterName }}
        interruptionQueue: {{ .values.clusterName }}-karpenter-interruption
      serviceAccount:
        annotations:
          eks.amazonaws.com/role-arn: …
```

**What Karpenter does vs Cluster Autoscaler:**

```
Cluster Autoscaler (legacy):
  Scales existing EC2 Auto Scaling Groups (ASGs).
  Can only add/remove nodes that match the ASG's fixed instance type.
  Scale-out: ~3-5 minutes (ASG creates an EC2 instance, waits for boot, joins cluster).

Karpenter (modern):
  Calls EC2 API directly without going through an ASG.
  Picks the cheapest/right-sized instance type for the pending pod's requirements.
  Scale-out: ~30-60 seconds (direct EC2 API is faster than ASG).
  Can use Spot instances where appropriate (specified in NodePool).
```

**`interruptionQueue`:**
- The SQS queue name created in `terraform/karpenter.tf` for Spot interruption events.
- When AWS sends a 2-minute Spot termination notice, Karpenter reads it from this queue and starts draining the node immediately.

---

## File: `gitops/auto-scaling/karpenter/karpenter-nodepools.yaml`

```yaml
resources:
  - apiVersion: karpenter.sh/v1
    kind: NodePool
    metadata:
      name: workloads
    spec:
      template:
        spec:
          nodeClassRef:
            name: workloads
          requirements:
            - key: "karpenter.sh/capacity-type"
              operator: In
              values: ["spot", "on-demand"]   # prefer Spot for cost
            - key: "node.kubernetes.io/instance-type"
              operator: In
              values: ["t3a.medium", "c6a.large"]   # small-medium instances
          taints: []    # no taint — app pods can schedule here without tolerations

  - apiVersion: karpenter.k8s.aws/v1
    kind: EC2NodeClass
    metadata:
      name: workloads
    spec:
      amiSelectorTerms:
        - alias: al2023@latest    # Amazon Linux 2023, always latest EKS-optimised AMI
      subnetSelectorTerms:
        - tags:
            karpenter.sh/discovery: {{ .values.clusterName }}   # finds subnets with this tag
      securityGroupSelectorTerms:
        - tags:
            karpenter.sh/discovery: {{ .values.clusterName }}
      instanceProfile: {{ .values.clusterName }}-karpenter-node  # IAM role for launched nodes
```

**How Karpenter chooses a node:**
1. Pod is `Pending` — no existing node can fit it.
2. Karpenter evaluates the pod's `resources.requests` + `nodeSelector` + `tolerations`.
3. Karpenter runs a bin-packing algorithm: which instance type from the list fits this pod at lowest cost?
4. Karpenter calls EC2 API with the winning instance type.
5. Node joins cluster, pod schedules.

**`amiSelectorTerms: alias: al2023@latest`:**
- Automatically uses the latest AWS-released EKS-optimised Amazon Linux 2023 AMI.
- No manual AMI ID updates needed — new nodes always start fully patched.

---

## File: `gitops/secrets/external-secrets/external-secret-operator.yaml`

```yaml
source:
  repoURL: https://charts.external-secrets.io
  chart: external-secrets
  targetRevision: 0.14.4
  helm:
    values: |
      serviceAccount:
        annotations:
          eks.amazonaws.com/role-arn: …-external-secrets-irsa
      nodeSelector:
        app: core
```

**What External Secrets Operator (ESO) does:**
- Defines a `ClusterSecretStore` that points to AWS Secrets Manager.
- Kubernetes resources define `ExternalSecret` objects that say: "create a Kubernetes Secret from this AWS Secrets Manager secret."
- ESO polls AWS Secrets Manager and syncs the values into Kubernetes Secrets.
- Developers never touch AWS — they just use a Kubernetes Secret.

---

## File: `gitops/secrets/external-secrets/cluster-secret-store.yaml`

```yaml
resources:
  - apiVersion: external-secrets.io/v1beta1
    kind: ClusterSecretStore
    metadata:
      name: aws-secrets-manager
    spec:
      provider:
        aws:
          service: SecretsManager
          region: "{{ .values.region }}"
          auth:
            jwt:
              serviceAccountRef:
                name: external-secrets
                namespace: external-secrets
```

**What ClusterSecretStore does:**
- A single cluster-wide store configuration. All `ExternalSecret` resources in any namespace can reference it.
- The `jwt` auth means ESO uses its own ServiceAccount token (IRSA) to authenticate to AWS — no static credentials.
- Without this, each namespace would need its own `SecretStore` — much more config.

**How ArgoCD admin password flows via ESO:**
```
Terraform creates: /cluster-name/argocd/admin-password in Secrets Manager
Human sets:        the actual password value via AWS Console
gitops/argocd/argocd-admin-secret.yaml defines:
  ExternalSecret → references ClusterSecretStore → references /cluster-name/argocd/admin-password
ESO syncs:         creates Kubernetes Secret "argocd-secret" with the password
ArgoCD reads:      the Kubernetes Secret at startup
```

---

## File: `gitops/secrets/reloader/reloader.yaml`

```yaml
source:
  repoURL: https://stakater.github.io/stakater-charts
  chart: reloader
  targetRevision: 1.4.5
  helm:
    values: |
      reloader:
        nodeSelector:
          app: core
```

**What Reloader does:**
- Watches Kubernetes `Secrets` and `ConfigMaps` for changes.
- When a referenced Secret changes, Reloader automatically triggers a rolling restart of the Deployment.
- Without Reloader: you update a secret → pods keep using the old value until manually restarted.

**Integration with ArgoCD:**
```yaml
# argocd.yaml includes:
deploymentAnnotations:
  reloader.stakater.com/auto: "true"
```
This tells Reloader: "if any Secret or ConfigMap referenced by this Deployment changes, restart the pods."

**Why this matters for ESO + Reloader together:**
1. ESO rotates a secret value in AWS Secrets Manager (or someone updates it).
2. ESO syncs the new value into the Kubernetes Secret.
3. Reloader detects the Secret changed.
4. Reloader restarts the relevant Deployment.
5. The pod picks up the new secret value at startup.

All of this happens **automatically** — no manual restart needed.

---

## File: `gitops/security/kyverno/kyverno.yaml`

```yaml
source:
  chart: kyverno
  targetRevision: 3.2.7
  helm:
    values: |
      global:
        nodeSelector:
          app: core
      admissionController:
        replicas: 1   # demo: single replica (production: 3 for HA)
```

**What Kyverno does:**
- A policy engine for Kubernetes. Runs as a Kubernetes admission webhook.
- Two modes: `Audit` (generates a report but doesn't block) and `Enforce` (blocks non-compliant resources).
- Every `kubectl apply` or Helm install passes through Kyverno before resources are created.

**Why sync-wave 3 (before wave 5 for policies):**
- Kyverno installs CRDs like `ClusterPolicy`, `PolicyReport`, etc.
- The actual policies (wave 5) use these CRDs.
- If policies were applied before Kyverno's CRDs exist, Kubernetes rejects them.

---

## File: `gitops/security/kyverno/kyverno-policies.yaml`

```yaml
resources:
  # Policy 1: require-resource-limits (Audit mode)
  # Every container must declare CPU + memory limits
  - apiVersion: kyverno.io/v1
    kind: ClusterPolicy
    metadata:
      name: require-resource-limits
    spec:
      validationFailureAction: Audit   # reports violations but doesn't block
      rules:
        - name: validate-resource-limits
          match: { resources: { kinds: [Pod] } }
          validate:
            message: "Resource limits are required for all containers."
            pattern:
              spec:
                containers:
                  - (name): "?*"
                    resources:
                      limits:
                        cpu: "?*"
                        memory: "?*"

  # Policy 2: disallow-privilege-escalation (Audit mode)
  # Policy 3: require-non-root-user (Audit mode)
  # Policy 4: disallow-latest-image-tag (Audit mode)
  # Policy 5: require-pod-probes (Audit mode)
```

**Why ALL policies are `Audit` not `Enforce`:**
- In a demo/learning environment, blocking deployments makes experimentation impossible.
- In production, start with Audit → observe violations → fix them → switch to Enforce.
- This is the recommended migration path for Kyverno policy adoption.

**What these policies catch:**
- `require-resource-limits`: Pod without CPU/memory limits → scheduler can't pack nodes efficiently.
- `disallow-privilege-escalation`: Container that could become root via setuid — security risk.
- `require-non-root-user`: Container running as UID 0 (root) — container escape is catastrophic.
- `disallow-latest-image-tag`: `image: myapp:latest` is not reproducible — any new deploy pulls different code.
- `require-pod-probes`: No liveness/readiness probe → ALB health checks may be inaccurate.

---

## File: `gitops/storage/ebs-csi-driver/ebs-csi-driver.yaml`

```yaml
source:
  chart: aws-ebs-csi-driver
  helm:
    values: |
      controller:
        serviceAccount:
          annotations:
            eks.amazonaws.com/role-arn: …-ebs-csi-driver-irsa
      storageClasses:
        - name: gp3
          isDefaultClass: true
          volumeBindingMode: WaitForFirstConsumer
          parameters:
            type: gp3
            encrypted: "true"
```

**What EBS CSI Driver does:**
- When a Kubernetes `PersistentVolumeClaim` with `storageClassName: gp3` is created, this driver calls the AWS API to create an EBS volume.
- The volume is attached to the node where the pod is scheduled.

**`WaitForFirstConsumer`:**
- The EBS volume is not created until a pod actually needs it.
- This matters for multi-AZ clusters: the volume is created in the same AZ as the pod, avoiding cross-AZ attachment errors.

**`encrypted: "true"`:**
- All EBS volumes are encrypted with the AWS KMS default key.
- Non-encrypted volumes would fail Kyverno policy (if enforce mode were on).

---

## Commands

```bash
# Check all platform components are synced
argocd app list | grep -E "platform|bootstrap|security|namespaces"

# Verify Karpenter is watching subnets correctly
kubectl describe nodepools workloads

# Test External Secrets sync
kubectl get externalsecrets -A
kubectl describe externalsecret -n argocd argocd-admin-password

# Check Kyverno policy violations
kubectl get policyreport -A
kubectl describe clusterpolicyreport

# Verify EBS CSI is the default storage class
kubectl get storageclass
# Expected: gp3 (default)

# Check Reloader is watching the right deployments
kubectl logs -n reloader -l app=reloader --tail=20

# Test Karpenter node provisioning (scale a deployment to trigger it)
kubectl scale deployment -n simple-time-service simple-time-service --replicas=10
kubectl get nodes -w  # watch for new nodes to appear
```
