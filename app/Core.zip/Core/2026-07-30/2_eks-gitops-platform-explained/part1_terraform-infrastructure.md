# Part 1 — Terraform Infrastructure: Every File Explained

> **What it creates:** The entire AWS foundation — VPC, EKS cluster, IAM roles for every component, S3 buckets for observability data, and Secrets Manager secrets. Without this layer, there is no cluster to run ArgoCD on.

---

## Decision Tree — "Which Terraform file do I touch?"

```
"I need to change something in AWS — which file?"
│
├─ VPC subnets / CIDR / AZs?
│   → terraform/modules/vpc/main.tf + variables.tf
│
├─ EKS version / node group size / addons?
│   → terraform/modules/eks/main.tf
│
├─ Add/change a component's AWS permissions?
│   → terraform/<component>-irsa.tf  (one file per component)
│
├─ Karpenter node pools / interruption queue?
│   → terraform/karpenter.tf
│
├─ S3 bucket for Thanos / Loki / Velero / Tempo?
│   → terraform/thanos.tf / loki.tf / velero.tf / tempo.tf
│
├─ Secrets stored in AWS Secrets Manager?
│   → terraform/secrets-manager.tf
│
└─ Variables / provider / backend?
    → terraform/variables.tf + providers.tf + backend.tf + versions.tf
```

---

## File: `terraform/versions.tf` — Provider Pins

```hcl
terraform {
  required_version = "~> 1.14.0"
  required_providers {
    aws  = { source = "hashicorp/aws",  version = "~> 6.0" }
    http = { source = "hashicorp/http",  version = "~> 3.5" }
    time = { source = "hashicorp/time",  version = "~> 0.12" }
  }
}
```

**Why pin versions:**
- `~> 1.14.0` = any patch release of 1.14 (1.14.1, 1.14.2) but NOT 1.15.
- Without pinning: `terraform init` on a new laptop downloads the latest (might be 2.0 with breaking changes).
- The `.terraform.lock.hcl` file records the exact provider hash — both files together make the build reproducible.

**Why `http` and `time` providers:**
- `http` provider fetches the Karpenter CloudFormation JSON policy from a URL at apply time.
- `time` provider creates a `time_sleep` resource used to wait for the EKS cluster to be fully ready before creating access entries.

---

## File: `terraform/backend.tf` — Remote State

```hcl
terraform {
  backend "s3" {
    bucket         = "…"
    key            = "terraform.tfstate"
    region         = "…"
    dynamodb_table = "…"
    encrypt        = true
  }
}
```

**What this does:**
- State file stored in S3 (not on someone's laptop) — every engineer and the CI pipeline share the same state.
- DynamoDB table provides the state lock — only one `terraform apply` can run at a time; the second waits.
- `encrypt = true` — state file is encrypted at rest with S3's SSE (contains IAM role ARNs and other sensitive values).

**app-bootstrap/backend.tf:**
- The `app-bootstrap/` directory is a *separate Terraform root*. It has its own backend, state file, and providers.
- This is intentional: app-bootstrap resources (ECR repo, app IAM role) change on a completely different cadence than the cluster infrastructure.

---

## File: `terraform/main.tf` — Wires VPC and EKS Modules Together

```hcl
module "vpc" {
  source = "./modules/vpc"
  vpc_name   = var.vpc_name
  vpc_cidr   = var.vpc_cidr
  azs        = var.azs
  …
  enable_karpenter_discovery_tags = var.enable_karpenter_discovery_tags
  cluster_name = var.enable_karpenter_discovery_tags ? var.cluster_name : null
}

module "eks" {
  source = "./modules/eks"
  cluster_name  = var.cluster_name
  vpc_id        = module.vpc.vpc_id           ← output from vpc module
  private_subnets = module.vpc.private_subnets ← output from vpc module
  …
}
```

**Why a module pattern:**
- The `vpc` and `eks` modules are reusable — point `source` at a different path and get a different environment.
- Outputs from `module.vpc` feed directly into `module.eks` — Terraform builds the dependency graph: VPC is always created first.

**`enable_karpenter_discovery_tags`:**
- When `true`, subnets and security groups get tagged: `"karpenter.sh/discovery" = cluster_name`.
- Karpenter reads these tags to know which subnets to launch nodes in — without this tag, Karpenter cannot find subnets.

---

## File: `terraform/modules/vpc/main.tf` — The Network Foundation

```hcl
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"

  name = var.vpc_name
  cidr = var.vpc_cidr
  azs  = var.azs

  private_subnets = var.private_subnets
  public_subnets  = var.public_subnets

  enable_nat_gateway     = true
  single_nat_gateway     = true     ← demo trade-off: saves cost, single AZ NAT failure = no outbound

  private_subnet_tags = merge(
    { "kubernetes.io/role/internal-elb" = "1" },
    var.enable_karpenter_discovery_tags ? { "karpenter.sh/discovery" = var.cluster_name } : {}
  )
  public_subnet_tags = { "kubernetes.io/role/elb" = "1" }
}
```

**Why two subnet types:**
- **Public subnets**: ALB nodes, NAT Gateways. These have internet routes via an Internet Gateway.
- **Private subnets**: EKS worker nodes, pods. These have no direct internet — outbound goes via NAT Gateway.
- `kubernetes.io/role/elb = 1` — the AWS Load Balancer Controller reads this tag to know where to create internet-facing ALBs.
- `kubernetes.io/role/internal-elb = 1` — for internal ALBs (not used here but follows the best practice).

**`single_nat_gateway = true` — Documented trade-off:**
- Production should have one NAT Gateway per AZ. A single one saves ~$32/month per AZ but creates a single point of failure for outbound internet access.
- If the NAT GW's AZ goes down, ALL private subnet pods lose outbound internet. This is acceptable in a demo but not production.

---

## File: `terraform/modules/eks/main.tf` — The Kubernetes Control Plane

```hcl
module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 21.0"

  enable_irsa        = true
  name               = var.cluster_name
  kubernetes_version = "1.34"
  endpoint_public_access = true

  enable_cluster_creator_admin_permissions = true

  addons = {
    coredns              = { most_recent = true, configuration_values = … }
    kube-proxy           = { most_recent = true }
    vpc-cni              = { before_compute = true, most_recent = true }
    eks-pod-identity-agent = { most_recent = true }
  }

  eks_managed_node_groups = {
    default = {
      instance_types = [var.instance_type]
      ami_type       = "AL2023_x86_64_STANDARD"
      capacity_type  = "ON_DEMAND"
      labels = { app = "core" }
      taints = {
        core = { key = "app", value = "core", effect = "NO_SCHEDULE" }
      }
    }
  }
}
```

**`enable_irsa = true`:**
- Creates an OIDC Identity Provider for the cluster.
- This is what allows IAM Roles for Service Accounts (IRSA) — pods can assume AWS IAM roles without node-level credentials.

**The `core` node group taint:**
- Nodes get label `app=core` AND taint `app=core:NoSchedule`.
- Result: ONLY pods with `tolerations: [{key: app, value: core, effect: NoSchedule}]` schedule here.
- Platform components (ArgoCD, Kyverno, Prometheus) tolerate this taint. Application workloads do NOT — they go to Karpenter nodes.
- This gives platform components dedicated, stable nodes. App pods cannot starve platform pods.

**`vpc-cni` with `before_compute = true`:**
- AWS VPC CNI assigns pod IPs from the VPC CIDR. It must be installed BEFORE nodes join the cluster.
- If nodes start before VPC CNI is ready, pods get wrong networking.

**`eks-pod-identity-agent`:**
- Alternative to IRSA for newer workloads. The agent runs as a DaemonSet and provides AWS credentials to pods via the local agent (no OIDC token exchange needed).
- Karpenter uses Pod Identity (set in `karpenter.tf`).

**`cloudwatch_log_group_retention_in_days = 90`:**
- Stores EKS control plane audit logs in CloudWatch for 90 days. Important for security investigations and compliance.

---

## IRSA Files — One Per Component

```
terraform/aws-load-balancer-controller-irsa.tf
terraform/cluster-autoscaler-irsa.tf
terraform/ebs-csi-driver-irsa.tf
terraform/external-dns-irsa.tf
terraform/external-secrets-irsa.tf
```

**Pattern (same in every file):**

```hcl
module "aws_load_balancer_controller_irsa" {
  source = "terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks"

  role_name = "${var.cluster_name}-aws-lb-controller-irsa"

  attach_load_balancer_controller_policy = true   ← AWS-managed policy for this specific component

  oidc_providers = {
    main = {
      provider_arn               = module.eks.oidc_provider_arn   ← the cluster's OIDC issuer
      namespace_service_accounts = ["kube-system:aws-load-balancer-controller"]
      # ↑ ONLY the SA "aws-load-balancer-controller" in "kube-system" namespace can assume this role
    }
  }
}
```

**Why this matters:**
- Each component gets a SEPARATE IAM role with EXACTLY the permissions it needs.
- Without IRSA, the EC2 node's instance profile would need all permissions merged — catastrophic if any pod is compromised.
- `namespace_service_accounts` is the trust boundary: only a pod running with ServiceAccount `aws-load-balancer-controller` in namespace `kube-system` can get an AWS token for this role.

---

## File: `terraform/karpenter.tf` — Node Provisioner IAM

```hcl
module "karpenter" {
  source  = "terraform-aws-modules/eks/aws//modules/karpenter"
  version = "~> 21.0"

  cluster_name = module.eks.cluster_name

  create_pod_identity_association = true   ← uses Pod Identity, not OIDC/IRSA
  create_node_iam_role            = true   ← nodes launched by Karpenter need an IAM role
  create_instance_profile         = true   ← EC2 instance profile for Karpenter-launched nodes
  enable_spot_termination         = true   ← SQS queue for EC2 Spot interruption events
  queue_name = "${var.cluster_name}-karpenter-interruption"
}
```

**`enable_spot_termination = true`:**
- AWS publishes a 2-minute warning before reclaiming a Spot instance.
- This creates an SQS queue that receives AWS EventBridge notifications for Spot interruptions.
- Karpenter consumes this queue and preemptively drains the node — pods are rescheduled gracefully instead of dying mid-request.

**`create_node_iam_role`:**
- Karpenter-launched nodes need an IAM role (for VPC CNI, EBS CSI, ECR pulls, etc.).
- This role is different from the Karpenter controller's role — it's the role nodes themselves assume.

---

## Files: `terraform/thanos.tf`, `loki.tf`, `tempo.tf`, `velero.tf`

These files all follow the same pattern: create an S3 bucket + an IRSA role for the component to access that bucket.

```hcl
# thanos.tf (simplified)
resource "aws_s3_bucket" "thanos" {
  bucket = "${var.cluster_name}-thanos-${data.aws_caller_identity.current.account_id}"
}

resource "aws_s3_bucket_versioning" "thanos" { … }
resource "aws_s3_bucket_server_side_encryption_configuration" "thanos" { … }

module "thanos_irsa" {
  source = "terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks"
  …
  # Policy: s3:GetObject, PutObject, DeleteObject, ListBucket on the thanos bucket
}
```

**Why separate buckets:**
- Thanos (long-term Prometheus metrics), Loki (logs), Tempo (traces), Velero (backups) each have different data lifetimes, access patterns, and retention requirements.
- Separate S3 buckets allow: different lifecycle rules, different IAM policies, independent cost tracking.

---

## File: `terraform/secrets-manager.tf` — Pre-Provisioned Secrets

```hcl
resource "aws_secretsmanager_secret" "argocd_admin_password" {
  name        = "${var.cluster_name}/argocd/admin-password"
  description = "ArgoCD admin password"
}

resource "aws_secretsmanager_secret" "grafana_admin_password" {
  name = "${var.cluster_name}/grafana/admin-password"
}

resource "aws_secretsmanager_secret" "slack_webhook_url" {
  name = "${var.cluster_name}/alertmanager/slack-webhook-url"
}
```

**Why pre-create the secret resources:**
- External Secrets Operator (ESO) will reference these ARNs from Kubernetes.
- The actual values are set manually after `terraform apply` (they contain sensitive credentials that should never be in code).
- The Terraform resource creates the secret *shell* — the human fills in the value via AWS Console or CLI.

---

## File: `terraform/app-bootstrap/main.tf` — App IAM

```hcl
resource "aws_ecr_repository" "simple_time_service" {
  name                 = "simple-time-service"
  image_tag_mutability = "MUTABLE"
}

module "github_actions_irsa" {
  # Creates: OIDC provider for GitHub Actions
  # Role trust: only "repo:Beem0807/eks-gitops-platform:ref:refs/heads/main" can assume
  # Policy: ecr:GetAuthorizationToken, ecr:PutImage (for building + pushing images)
}
```

**Why a separate Terraform root:**
- The ECR repo and GitHub Actions OIDC role are app-level concerns — they don't change when cluster infrastructure changes.
- Separating them means a cluster rebuild doesn't risk touching the ECR repo that production images live in.

---

## File: `terraform/scripts/bootstrap.sh` — One-Time Cluster Bootstrap

```bash
#!/bin/bash
# 1. Configure kubectl for the new cluster
aws eks update-kubeconfig --name $CLUSTER_NAME --region $AWS_REGION

# 2. Install ArgoCD via Helm
helm repo add argo https://argoproj.github.io/argo-helm
helm upgrade --install argocd argo/argo-cd \
  --namespace argocd --create-namespace \
  --version 9.4.17

# 3. Apply the App of Apps entry point
kubectl apply -f gitops/bootstrap/root-app.yaml

# From this point: ArgoCD takes over and manages everything via GitOps
```

**This is the ONE manual step after `terraform apply`.**
After this script runs, every future change goes through git → ArgoCD. The bootstrap script itself is idempotent: running it twice just updates ArgoCD to the same version.

---

## Key Outputs (`terraform/outputs.tf`)

```
cluster_name          → used in kubeconfig and ArgoCD cluster registration
cluster_endpoint      → Kubernetes API server URL
oidc_provider_arn     → referenced by all IRSA modules
karpenter_role_arn    → used in gitops/auto-scaling/karpenter/karpenter.yaml
thanos_bucket_name    → used in gitops/monitoring/thanos/thanos.yaml
loki_bucket_name      → used in gitops/logs/loki/loki.yaml
```

**Commands:**
```bash
# Apply infrastructure
cd terraform
terraform init
terraform plan -var-file=terraform.tfvars
terraform apply -var-file=terraform.tfvars

# Bootstrap after apply
chmod +x scripts/bootstrap.sh
./scripts/bootstrap.sh

# Verify outputs
terraform output cluster_name
terraform output thanos_bucket_name

# Check cluster is healthy
aws eks get-token --cluster-name $(terraform output -raw cluster_name) | jq .
kubectl get nodes
```
