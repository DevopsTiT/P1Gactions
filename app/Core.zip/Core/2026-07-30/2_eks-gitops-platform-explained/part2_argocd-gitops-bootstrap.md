# Part 2 — ArgoCD GitOps Bootstrap: App of Apps Pattern

> **What it creates:** The self-managing GitOps control plane. After bootstrap, ArgoCD reads this Git repo and reconciles the entire cluster state — every add, change, or delete to a YAML file in `gitops/` becomes a cluster change. No manual `kubectl apply` needed for anything after the first bootstrap.

---

## Decision Tree — "Where does a new platform component go?"

```
"I want to add a new platform tool to the cluster — where do I add it?"
│
├─ It needs an AWS IAM role (IRSA)?
│   → Add terraform/<tool>-irsa.tf + module in main.tf
│
├─ It needs a Kubernetes namespace?
│   → Add entry to gitops/namespaces/namespaces.yaml (namespaces list)
│
├─ It's a Helm chart deployed via ArgoCD?
│   → Create gitops/<category>/<tool>/<tool>.yaml (an ApplicationSet)
│   → Add the Helm repo URL to gitops/argocd/projects/<project>.yaml (sourceRepos)
│   → Set the correct sync-wave (later waves depend on earlier ones)
│
└─ It needs raw Kubernetes resources (CRDs, ConfigMaps)?
    → Use charts/raw/ as the Helm chart + embed YAML in the ApplicationSet's helm.values
```

---

## File: `gitops/bootstrap/root-app.yaml` — The Entry Point

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: root-app
  namespace: argocd
spec:
  project: bootstrap         # most restricted AppProject — only the argocd namespace
  source:
    repoURL: https://github.com/Beem0807/eks-gitops-platform.git
    targetRevision: main     # tracks the main branch
    path: gitops             # watches the ENTIRE gitops/ directory
    directory:
      recurse: true          # ← KEY: discovers every YAML file recursively
  destination:
    server: https://kubernetes.default.svc
    namespace: argocd
  syncPolicy:
    automated:
      prune: true            # delete resources removed from git
      selfHeal: true         # revert manual kubectl changes
    syncOptions:
      - CreateNamespace=true
      - ServerSideApply=true
```

**How "App of Apps" works:**

```
root-app watches gitops/ recursively
  → Finds gitops/argocd/argocd.yaml (an Application)
  → Finds gitops/namespaces/namespaces.yaml (an ApplicationSet)
  → Finds gitops/networking/ingress-controller/aws-load-balancer-controller.yaml (an ApplicationSet)
  → … finds every ApplicationSet/Application YAML in gitops/

ArgoCD creates all these objects in the argocd namespace.
Each ApplicationSet then creates Application objects per matched cluster.
Each Application syncs its Helm chart to the cluster.

One root-app → N ApplicationSets → N×M Applications → running workloads
```

**Why `selfHeal: true`:**
- If an engineer runs `kubectl edit deployment argocd-server` manually, ArgoCD detects the drift and reverts it within 3 minutes.
- This is critical for a GitOps platform: the Git repo is THE source of truth, not human memory.

**Why `prune: true`:**
- If you delete `gitops/networking/external-dns/external-dns.yaml` from Git, ArgoCD removes ExternalDNS from the cluster.
- Without `prune`, deleted files leave orphaned resources running forever.

---

## File: `gitops/argocd/argocd.yaml` — ArgoCD Self-Management

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: argocd-self
  namespace: argocd
spec:
  project: platform
  source:
    repoURL: https://argoproj.github.io/argo-helm
    chart: argo-cd
    targetRevision: 9.4.17       # pinned Helm chart version
    helm:
      values: |
        configs:
          params:
            server.insecure: true    # TLS terminated at ALB, not at ArgoCD server
        server:
          service:
            type: ClusterIP          # ALB Ingress in front, not NodePort
          deploymentAnnotations:
            reloader.stakater.com/auto: "true"   # Reloader watches ArgoCD secrets
        global:
          nodeSelector:
            app: core                # must run on core nodes (dedicated platform nodes)
          tolerations:
            - key: app, operator: Equal, value: core, effect: NoSchedule

  ignoreDifferences:
    - kind: Secret
      name: argocd-secret
      jsonPointers:
        - /data/admin.password       # ArgoCD modifies this at runtime (bcrypt hash)
        - /data/admin.passwordMtime  # timestamp — always drifts
```

**Why ArgoCD manages itself:**
- Meta-pattern: ArgoCD is self-managing. The bootstrap script installs a basic ArgoCD. Then `argocd.yaml` manages ArgoCD itself going forward.
- Benefit: ArgoCD upgrades happen via a Git PR, not a manual `helm upgrade`. Every upgrade is reviewed, auditable, and reversible.

**`ignoreDifferences` for the admin secret:**
- ArgoCD hashes the admin password and stores the bcrypt hash + timestamp in `argocd-secret`.
- Without `ignoreDifferences`, ArgoCD would see this field "drifted" from Helm and try to reset it every sync cycle — logging the user out.
- This tells ArgoCD: "the password hash and its timestamp are expected to be different from what Helm rendered — leave them alone."

**`server.insecure: true`:**
- The ArgoCD server itself serves plain HTTP. TLS is terminated at the AWS ALB (in `gitops/argocd/argocd-ingress.yaml`).
- This is the standard ALB → internal HTTP pattern. The ALB handles HTTPS; internal communication is HTTP on the private network.

---

## Files: ArgoCD AppProjects — The Security Boundaries

```
gitops/argocd/projects/
  ├─ bootstrap-project.yaml    → most restrictive: only argocd namespace, only this repo
  ├─ platform-project.yaml     → cluster infra: can deploy to kube-system + platform namespaces
  ├─ namespaces-project.yaml   → only namespace creation
  ├─ observability-project.yaml → monitoring namespace + CRDs
  ├─ security-project.yaml     → security namespace + cluster-scoped resources (CRDs, webhooks)
  └─ workloads-project.yaml    → app namespaces only, no cluster-scoped resources
```

**What AppProjects do:**

```yaml
# bootstrap-project.yaml — minimal blast radius
spec:
  sourceRepos:
    - https://github.com/Beem0807/eks-gitops-platform.git
    # Only this one repo. Cannot pull charts from anywhere else.
  destinations:
    - server: https://kubernetes.default.svc
      namespace: argocd              # ONLY the argocd namespace
  clusterResourceWhitelist: []       # ZERO cluster-scoped resources allowed
```

```yaml
# platform-project.yaml — trusted platform components
spec:
  sourceRepos:
    - https://argoproj.github.io/argo-helm
    - https://aws.github.io/eks-charts
    - https://kyverno.github.io/kyverno
    - … (all Helm repos for platform tools)
  destinations:
    - { namespace: argocd }
    - { namespace: kube-system }
    - { namespace: karpenter }
    - { namespace: external-secrets }
    - … (all platform namespaces)
  clusterResourceWhitelist:
    - group: "*", kind: "*"          # CAN create cluster-scoped resources (CRDs, ClusterRoles)
```

```yaml
# workloads-project.yaml — app teams
spec:
  destinations:
    - { namespace: simple-time-service }
    - { namespace: staging }
  clusterResourceWhitelist: []       # App teams CANNOT create cluster-scoped resources
```

**Why AppProjects matter for security:**
- Without AppProjects: any ArgoCD Application can deploy anything to any namespace.
- With AppProjects: a compromised application repo cannot deploy to `kube-system`. A workload ApplicationSet cannot create ClusterRoles. The blast radius of any single compromise is limited by the project.

---

## File: `gitops/namespaces/namespaces.yaml` — All Namespaces via ApplicationSet

```yaml
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: cluster-namespaces
  annotations:
    argocd.argoproj.io/sync-wave: "-1"   # ← runs FIRST before anything else
spec:
  generators:
    - clusters:
        selector:
          matchLabels:
            argocd.argoproj.io/secret-type: cluster
  template:
    spec:
      source:
        path: charts/namespaces        # uses the namespaces Helm chart
        helm:
          values: |
            namespaces:
              - name: karpenter
              - name: external-secrets
              - name: external-dns
              - name: reloader
              - name: velero
              - name: monitoring
              - name: logging
              - name: simple-time-service
              - name: security
              - name: tracing
```

**Why sync-wave "-1" (runs before everything):**
- Every other component (Karpenter, Prometheus, Loki, etc.) deploys INTO a specific namespace.
- If the namespace doesn't exist when the Helm chart runs, the chart fails with "namespace not found."
- Wave -1 guarantees namespaces exist before any other wave runs.

**Why `argocd` namespace is NOT in this list:**
- The `argocd` namespace is created by `helm install argocd --create-namespace` in `bootstrap.sh`.
- ArgoCD must exist before this ApplicationSet can run — it would be circular to manage the argocd namespace via ArgoCD.

**The `clusters` generator:**
- Queries ArgoCD's registered clusters. For each cluster with label `argocd.argoproj.io/secret-type: cluster`, creates one Application.
- In a multi-cluster setup, this creates namespaces on ALL clusters from one YAML file.

---

## File: `charts/namespaces/` — The Namespace Helm Chart

```yaml
# charts/namespaces/templates/namespace.yaml
{{- range .Values.namespaces }}
apiVersion: v1
kind: Namespace
metadata:
  name: {{ .name }}
  labels:
    {{- toYaml $.Values.global.labels | nindent 4 }}
  annotations:
    {{- toYaml $.Values.global.annotations | nindent 4 }}
{{- end }}
```

```yaml
# charts/namespaces/templates/resourcequota.yaml
{{- range .Values.namespaces }}
{{- if or ($.Values.global.resourceQuota) (.resourceQuota) }}
apiVersion: v1
kind: ResourceQuota
metadata:
  name: resource-quota
  namespace: {{ .name }}
spec:
  hard:
    {{- toYaml (merge (.resourceQuota | default dict) $.Values.global.resourceQuota) | nindent 4 }}
{{- end }}
{{- end }}
```

**What this chart does:**
- Iterates over `values.namespaces[]` and creates one `Namespace` per entry.
- Optionally creates a `ResourceQuota` per namespace (limits total CPU/memory in a namespace).
- The global labels and annotations are applied to every namespace — useful for network policy or billing labels.

**Why a Helm chart for namespaces instead of raw YAML:**
- Helm's `range` loop means adding a new namespace = one line in `namespaces.yaml`.
- If you had raw YAML, each namespace would be a separate file or a 10-line block — easy to forget a label.

---

## Sync Waves — The Deployment Order

```
Wave -1:  namespaces         (must exist before everything)
Wave  1:  aws-lb-controller  (ALB Ingress for ArgoCD UI and apps)
Wave  2:  external-secrets   (ESO installs CRDs — other components need ESO CRDs)
Wave  3:  karpenter          (node pools), kyverno (webhooks), velero (backup)
Wave  4:  cluster-secret-store (uses ESO CRDs — must come after wave 2)
Wave  5:  kyverno-policies   (uses Kyverno CRDs — must come after wave 3)
Wave  6:  prometheus         (monitoring stack)
Wave  7:  loki, tempo, fluent-bit (depends on prometheus CRDs for ServiceMonitor)
Wave  8:  simple-time-service (workload — after platform is ready)
Wave  9:  alertmanager-slack  (AlertmanagerConfig — after Prometheus is running)
Wave 10:  service alerts      (PrometheusRules — after Alertmanager is configured)
```

**Why the order matters:**
- Kubernetes CRDs (Custom Resource Definitions) must exist before any Custom Resources of that type can be created.
- Example: `ClusterSecretStore` is an ESO CRD. If you try to create a `ClusterSecretStore` (wave 4) before ESO is installed (wave 2), Kubernetes returns "no kind ClusterSecretStore registered" and the resource fails.
- Sync waves solve this: ArgoCD waits for all resources in wave N to be healthy before starting wave N+1.

---

## Commands

```bash
# Bootstrap (one-time after terraform apply)
./terraform/scripts/bootstrap.sh

# Check root-app status
argocd app get root-app

# List all applications ArgoCD is managing
argocd app list

# Force sync a specific app
argocd app sync cluster-namespaces

# Check sync waves and health
kubectl get applications -n argocd -o custom-columns='NAME:.metadata.name,HEALTH:.status.health.status,SYNC:.status.sync.status,WAVE:.metadata.annotations.argocd\.argoproj\.io/sync-wave'

# Watch sync progress
kubectl get applications -n argocd -w

# See ArgoCD server logs (useful when an app won't sync)
kubectl logs -n argocd -l app.kubernetes.io/name=argocd-server --tail=50
```
