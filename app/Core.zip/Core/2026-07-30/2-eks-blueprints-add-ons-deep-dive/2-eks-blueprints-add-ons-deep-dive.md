# 2026-07-30 · Seq 2 · EKS Blueprints Add-ons Deep Dive

## Decision tree

```
need EKS platform addons via GitOps?
 │
 ├─ only learning App-of-Apps?
 │    → use chart/ + add-ons/ (classic README path)
 │    → parent Application path=chart → enable: true → child Application → wrapper Helm
 │
 ├─ multi-cluster / current Blueprints GitOps Bridge?
 │    → use argocd/ ApplicationSets
 │    → TF writes cluster Secret labels+annotations
 │    → enable_* label gates ApplicationSet
 │    → values: charts → environments → clusters
 │
 ├─ addon pods CrashLoop / IRSA AccessDenied?
 │    → check SA exists + eks.amazonaws.com/role-arn
 │    → TF created role + trust OIDC? (this repo does NOT create IAM)
 │    → serviceAccount.create must be false if TF owns SA
 │
 ├─ Argo forever OutOfSync on webhook/TLS?
 │    → ignoreDifferences caBundle + Secret/data (already in templates)
 │    → RespectIgnoreDifferences / ServerSideApply
 │
 ├─ which folder is "source of truth" in THIS zip (~Nov 2023)?
 │    → BOTH eras coexist — README docs classic; argocd/ is Bridge era
 │    → pick ONE pattern per cluster; don't mix enable paths blindly
 │
 └─ promote staging → prod?
      classic → bump parent values / targetRevision
      modern → environment label + environments/{staging,prod}/ overlays + pin addonChartVersion
```

```
want add ALB controller?
  IRSA+SA ready? → no → Terraform/Blueprints first
  pattern classic? → awsLoadBalancerController.enable=true + SA name in parent helm values
  pattern modern? → label enable_aws_load_balancer_controller=true + ARN annotations on cluster Secret
  sync → Ingress Class alb → AWS ALB appears
```

## Short takeaway

| Key point | Detail |
|-----------|--------|
| What this repo is | GitOps desired state for **Kubernetes add-ons**, not EKS/VPC Terraform |
| Local path | `/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main` |
| Two eras in one tree | Classic: `chart/` + `add-ons/` · Modern: `argocd/` ApplicationSets |
| Enable classic | Parent App helm values `*.enable: true` (defaults all false) |
| Enable modern | Cluster Secret label `enable_<addon>=true` + IRSA annotations |
| TF vs Git | TF = IAM/OIDC/SQS/instance profile · Git = Helm charts/values/sync |
| Scale | ~48 classic wrappers · ~20 AWS + ~16 OSS ApplicationSets in `argocd/` |

## Summary

`eks-blueprints-add-ons` is the add-on catalog that pairs with EKS Blueprints / GitOps Bridge: Argo CD syncs this Git repo to install LB controller, Karpenter, Fluent Bit, Prometheus stack, etc. Your local copy contains both the classic App-of-Apps Helm root and the newer label-gated ApplicationSet layout—walk them as two complete pipelines below.

## Main content

### 1. What the repo is (and is not)

| Is | Is not |
|----|--------|
| Argo CD GitOps config for cluster add-ons | VPC / EKS control-plane Terraform |
| App-of-Apps (classic) + ApplicationSets (Bridge) | Your application / payment-service code |
| Helm wrappers + value layers + sync policies | A one-click AWS installer |
| Companion to [terraform-aws-eks-blueprints](https://github.com/aws-ia/terraform-aws-eks-blueprints) | Mandatory only if you use Blueprints |

README states the purpose plainly: bootstrap EKS with many Kubernetes add-ons via Argo CD App of Apps.

### 2. Repo map

```
eks-blueprints-add-ons-main/
├── README.md                 ← documents classic chart/ + add-ons/
├── chart/                    ← ROOT App-of-Apps Helm chart
│   ├── values.yaml           ← globals + per-addon enable (default false)
│   └── templates/*.yaml      ← ~47 Argo Application templates
├── add-ons/                  ← ~48 thin wrapper charts (Chart.yaml deps → upstream)
├── argocd/                   ← GitOps Bridge layout
│   ├── bootstrap/control-plane/
│   │   ├── clusters/         ← clusters ApplicationSet
│   │   ├── addons/aws/       ← AWS + AWS-OSS ApplicationSets
│   │   ├── addons/oss/       ← OSS ApplicationSets
│   │   └── exclude/          ← bootstrap ApplicationSet
│   ├── charts/addons/        ← default Helm values per addon
│   ├── environments/{dev,staging,prod}/addons/
│   └── clusters/<name>/      ← per-cluster overlays (+ non-addon cluster path)
└── scripts/                  ← helpers (if present)
```

### 3. Ownership split (memorize this)

| Layer | Owner | Examples |
|-------|--------|----------|
| AWS identity & infra | Terraform / Blueprints | OIDC, IRSA roles, Karpenter SQS + instance profile, Velero S3 |
| Cluster registration | Terraform → Argo cluster Secret | labels `enable_*`, `environment`; annotations `*_iam_role_arn`, `addons_repo_url` |
| Addon desired state | **This Git repo** | Chart versions, Helm values, Application / ApplicationSet YAML |
| Workload apps | Separate Git (App of Apps / AppSets) | payment-service Helm — not here |

```
Terraform apply
  → EKS + IRSA + (optional) Argo install + cluster Secret metadata
Git (this repo)
  → Argo syncs addons using that metadata
Day-2 Helm-only change
  → PR on this repo → Argo sync (no TF)
Day-2 IAM / SQS / new IRSA
  → Terraform first → then Git enable / values
```

---

### 4. Classic pattern — step by step (`chart/` + `add-ons/`)

#### Step 4.1 — Install Argo CD

On a sandbox or via Blueprints. Destination for the **parent** Application is usually the hub cluster’s `argocd` namespace.

#### Step 4.2 — Create the parent Application

From README (simplified):

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: add-ons
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/aws-samples/eks-blueprints-add-ons.git  # or your fork
    targetRevision: HEAD
    path: chart
    helm:
      values: |
        clusterName: my-eks
        region: ap-northeast-1
        metrics-server:
          enable: true
        cluster-autoscaler:
          enable: true
  destination:
    server: https://kubernetes.default.svc
    namespace: argocd
```

`kubectl apply -n argocd -f application.yaml`

#### Step 4.3 — Root chart globals (`chart/values.yaml`)

| Key | Role |
|-----|------|
| `repoUrl` | Git URL children use to fetch `add-ons/...` |
| `targetRevision` | Branch/tag (often `HEAD`) |
| `clusterName` / `region` / `account` | Injected into child Helm values |
| `destinationServer` | Target cluster API |
| `argoNamespace` / `argoProject` | Where child Applications are created |

Every addon block defaults to `enable: false`. Opt-in only what you need.

#### Step 4.4 — How one template becomes one child Application

Example: `chart/templates/aws-load-balancer-controller.yaml`

| Piece | Meaning |
|-------|---------|
| `if .Values.awsLoadBalancerController.enable` | Gate — no enable → no Application CR |
| `kind: Application` | Child Argo app |
| `source.path: add-ons/aws-load-balancer-controller` | Wrapper chart in **this** repo |
| `helm.values` | `clusterName`, `region`, SA name, `create: false`, plus nested values via `toYaml` |
| `destination.namespace: kube-system` | Where controller runs |
| `syncPolicy.automated.prune: true` | Git delete → prune resources |
| `ignoreDifferences` | Secret `/data` + webhook `caBundle` (controller mutates them) |
| `RespectIgnoreDifferences` | Sync option so ignore actually applies |
| `resources-finalizer.argocd.argoproj.io` | Cascade delete of managed resources when App deleted |

#### Step 4.5 — Wrapper chart under `add-ons/<name>/`

| File | Role |
|------|------|
| `Chart.yaml` | Declares **dependency** on upstream chart + pins version |
| `values.yaml` | Opinionated defaults (often `serviceAccount.create: false`) |

ALB example:

```yaml
# add-ons/aws-load-balancer-controller/Chart.yaml
dependencies:
- name: aws-load-balancer-controller
  version: 1.4.7
  repository: https://aws.github.io/eks-charts
```

```yaml
# add-ons/aws-load-balancer-controller/values.yaml
aws-load-balancer-controller:
  serviceAccount:
    create: false   # TF/IRSA owns the SA
```

Argo renders the wrapper → Helm pulls the dependency → installs upstream templates.

#### Step 4.6 — Classic sync cascade (pic)

```
kubectl apply Application(add-ons)  path=chart
        │
        ▼
Argo Helm-renders chart/templates/*
        │  (only enable:true)
        ▼
Application/aws-load-balancer-controller
        │  path=add-ons/aws-load-balancer-controller
        ▼
Wrapper Chart.yaml dependency → eks-charts upstream
        │
        ▼
Pods/CRDs in kube-system  (+ IRSA SA already present)
```

#### Step 4.7 — Classic addon catalog (~48)

| Category | Folders under `add-ons/` |
|----------|--------------------------|
| AWS net / LB | aws-load-balancer-controller, external-dns, appmesh-controller, traefik, ingress-nginx |
| Autoscaling | cluster-autoscaler, karpenter, keda, vpa |
| Observability | kube-prometheus-stack, grafana, prometheus, prometheus-node-exporter, kube-state-metrics, promtail, aws-for-fluent-bit, aws-cloudwatch-metrics, aws-otel-collector, opentelemetry-collector, datadog-operator, kubecost, thanos |
| Security / policy | cert-manager, cert-manager-csi-driver, external-secrets, gatekeeper, kyverno, vault |
| Storage / DR | aws-efs-csi-driver, smb-csi-driver, ondat, velero |
| Delivery | argo-rollouts, argo-workflows |
| Mesh / CNI | calico, cilium, tetrate-istio |
| Data / batch | spark-operator, strimzi-kafka-operator, yunikorn |
| Misc | metrics-server, reloader, chaos-mesh, kubernetes-dashboard, nvidia-device-plugin, agones, consul |

**SRE tip:** do not enable the whole catalog. Starter set: metrics-server + aws-load-balancer-controller + aws-for-fluent-bit + external-secrets (+ karpenter or cluster-autoscaler).

#### Step 4.8 — Classic Karpenter values to wire from TF

From `chart/values.yaml` Karpenter block you must fill when enabling:

| Value | Comes from Terraform |
|-------|----------------------|
| `serviceAccountName` | IRSA SA |
| `controllerClusterEndpoint` | EKS API endpoint |
| `awsDefaultInstanceProfile` | Node instance profile |
| `interruptionQueueName` | SQS queue for Spot interruption |

---

### 5. Modern pattern — step by step (`argocd/`)

Matches GitOps Bridge / current Blueprints Argo tutorials.

#### Step 5.1 — Cluster Secret is the contract

Terraform registers each spoke cluster in Argo with **labels** and **annotations**. ApplicationSets select on labels; Helm inline values pull annotations.

| Metadata | Role |
|----------|------|
| `enable_aws_load_balancer_controller: "true"` | Include cluster in that ApplicationSet |
| `enable_karpenter: "true"` | Same for Karpenter |
| `environment: dev\|staging\|prod` | Value overlay path + optional version pin |
| `aws_cluster_name` | Helm `clusterName` |
| `aws_load_balancer_controller_iam_role_arn` | SA annotation IRSA |
| `aws_load_balancer_controller_service_account` | SA name |
| `aws_load_balancer_controller_namespace` | Destination namespace |
| `karpenter_*` annotations | Instance profile, SQS, SA, role, namespace |
| `addons_repo_url` / `addons_repo_revision` / `addons_repo_basepath` | Where to read **this** repo’s value files |

Enabling an addon is often a **Terraform label flip**, not editing dozens of Application YAMLs.

#### Step 5.2 — Bootstrap ApplicationSet

`argocd/bootstrap/control-plane/exclude/bootstrap.yaml`:

- Generator: all clusters except special hub name `in-cluster` (Akuity label exclusion)
- Source path: `addons_repo_basepath + addons_repo_path`
- `directory.recurse: true`, `exclude: exclude/*`
- Destination: `argocd` on each cluster name
- Effect: syncs the **catalog of ApplicationSet YAMLs** onto the hub

```
bootstrap AppSet
  → applies addons-*-appset.yaml files into argocd ns
  → those AppSets then generate per-cluster Applications
```

#### Step 5.3 — Clusters ApplicationSet

`clusters-appset.yaml`:

- Per cluster → Application `cluster-{{name}}`
- Path: `clusters/{{name}}` (recurse)
- **Exclude** `addons/*` (addon values live under overlays consumed by multi-source Helm, not as raw directory sync)
- Soft retry / automated allowEmpty for empty cluster folders

Use this path for cluster-scoped non-addon manifests (quotas, namespaces, network policies, etc.).

#### Step 5.4 — Per-addon ApplicationSet (ALB controller)

File: `addons-aws-load-balancer-controller-appset.yaml`

**Merge generator:**

1. Base: clusters with `enable_aws_load_balancer_controller=true` → chart name/version/repo  
2. Staging label → override `addonChartVersion` (pin)  
3. Prod label → override `addonChartVersion` (pin)

**Multi-source Application:**

| Source | Purpose |
|--------|---------|
| Git ref `$values` | Only for valueFiles from this repo |
| Upstream Helm chart | Real controller from `eks-charts` |

**Value file order** (later wins; `ignoreMissingValueFiles: true`):

```
1. charts/addons/aws-load-balancer-controller/values.yaml
2. environments/{{environment}}/addons/aws-load-balancer-controller/values.yaml
3. clusters/{{name}}/addons/aws-load-balancer-controller/values.yaml
+ inline values: clusterName, SA name, role-arn from annotations
```

**Sync / drift guards:**

- `CreateNamespace=true`
- `ServerSideApply=true` (large CRDs)
- `preserveResourcesOnDeletion: true` on ApplicationSet (deleting AppSet ≠ wipe addons)
- `ignoreDifferences` on TLS Secret + webhook caBundles

#### Step 5.5 — Karpenter ApplicationSet (AWS-specific wiring)

Same merge/`enable_karpenter` pattern; chart from OCI `public.ecr.aws`.

Inline Helm injects:

```
settings.aws.clusterName
settings.aws.defaultInstanceProfile
settings.aws.interruptionQueueName
serviceAccount.name + role-arn annotation
destination.namespace from annotation
```

Prerequisite: Terraform must already have created instance profile + SQS; this repo only wires names/ARNs.

#### Step 5.6 — AWS vs OSS ApplicationSet folders

| Folder | Examples |
|--------|----------|
| `addons/aws/` | load-balancer-controller, fluentbit, EBS/EFS/FSx CSI, cloudwatch-metrics, NTH, gateway-api; plus `aws-oss-*` (karpenter, external-dns/secrets, cert-manager, velero, cluster-autoscaler, crossplane providers, argocd hub/ingress) |
| `addons/oss/` | metrics-server, kube-prometheus-stack, argo-rollouts/workflows/events/cd, ingress-nginx, kyverno, gatekeeper, vpa, crossplane, gpu-operator, secrets-store-csi-driver |

#### Step 5.7 — Environment & cluster overlays

```
argocd/environments/dev/addons/<addon>/values.yaml      ← filled for many addons in this zip
argocd/environments/staging/addons/...                  ← often sparse / .keep
argocd/environments/prod/addons/...
argocd/clusters/my-cluster/addons/<addon>/values.yaml   ← one-off per cluster
```

Promotion flow:

```
dev values proven
  → copy/adjust to staging overlay + label environment=staging
  → pin addonChartVersion in staging generator
  → same for prod
```

#### Step 5.8 — Modern sync cascade (pic)

```
TF: cluster Secret labels+annotations
        │
        ▼
bootstrap AppSet → installs addon ApplicationSets
        │
        ▼
AppSet (e.g. addons-aws-load-balancer-controller)
  generator match enable_*=true
        │
        ▼
Application addon-<cluster>-aws-load-balancer-controller
  multi-source: $values + upstream chart
        │
        ▼
Helm merge: charts → env → cluster → inline IRSA
        │
        ▼
Controller running on spoke cluster
```

---

### 6. Classic vs modern side-by-side

| Concern | Classic `chart/` | Modern `argocd/` |
|---------|------------------|------------------|
| Enable | `enable: true` in parent Helm values | Cluster Secret label `enable_*=true` |
| Child unit | One `Application` per addon | `ApplicationSet` → one App per matching cluster |
| Multi-cluster | Manual `destinationServer` | Cluster generators |
| Values | Mostly embedded in Application `helm.values` | Layered files + inline annotations |
| Upstream chart | Via wrapper `add-ons/*/Chart.yaml` dependency | Direct `sources[].chart` (+ `$values` ref) |
| IRSA | Pass SA name; TF created SA | Annotation `eks.amazonaws.com/role-arn` from TF metadata |
| Best fit | Single cluster, README bootstrap | Hub Argo, many clusters, Blueprints Bridge |

---

### 7. End-to-end checklist — AWS LB Controller

| Step | Action | Where |
|------|--------|-------|
| 1 | Create IRSA role + trust to OIDC | Terraform |
| 2 | Create SA annotated with role-arn | Terraform / manifest |
| 3a Classic | `awsLoadBalancerController.enable: true` + SA name | Parent Application values |
| 3b Modern | Label `enable_aws_load_balancer_controller=true` + ARN annotations | Cluster Secret |
| 4 | Argo creates child Application | Argo UI / CLI |
| 5 | Helm installs controller | `kube-system` (classic) or annotation ns |
| 6 | Deploy Ingress → ALB | AWS console |
| 7 | Tune PDB/replicas via values | Git PR |
| 8 | IgnoreDifferences keep webhooks calm | Already in templates |

---

### 8. Map to payment-platform EKS (ap-northeast-1)

| Need | Addon in this repo |
|------|--------------------|
| ALB Ingress | aws-load-balancer-controller |
| Node scale | karpenter **or** cluster-autoscaler |
| Logs | aws-for-fluent-bit |
| Metrics | kube-prometheus-stack / metrics-server |
| Secrets | external-secrets |
| Certs | cert-manager |
| Canary / progressive delivery | argo-rollouts |
| Backup | velero |

Still Terraform-owned: VPC, EKS, IRSA, Aurora/Redis (app data plane), S3 for Velero, SQS for Karpenter.

---

### 9. SRE pitfalls (deep points)

1. **TF vs Git** — IAM/SQS never “appear” from this repo; missing ARN → CrashLoop / AccessDenied.  
2. **`serviceAccount.create: false`** — intentional when Blueprints owns SA; if true without role annotation, broken IRSA.  
3. **Webhook OutOfSync** — always keep `ignoreDifferences` on caBundle + TLS secret data.  
4. **`ServerSideApply`** — required for large CRDs (Prometheus, Crossplane).  
5. **`preserveResourcesOnDeletion`** — AppSet delete should not surprise-wipe production addons.  
6. **Pin versions per env** — staging/prod generators exist to freeze `addonChartVersion`.  
7. **Don’t enable everything** — blast radius and upgrade toil explode.  
8. **Repo age** — local zip ~2023; classic ALB wrapper pins 1.4.7 while AppSet uses 1.6.0 — reconcile with upstream before prod.  
9. **Two eras** — pick classic **or** Bridge for a given cluster; dual-enabling the same addon twice causes ownership fights.  
10. **Hub vs spoke** — bootstrap/ApplicationSets usually live on hub; destination `name: '{{name}}'` is the spoke.

---

### 10. How to study this local tree (ordered exercises)

1. Read `README.md` + skim `chart/values.yaml` enable flags.  
2. Open one template: `chart/templates/aws-load-balancer-controller.yaml` + matching `add-ons/...`.  
3. Trace classic cascade on paper with metrics-server only.  
4. List `argocd/bootstrap/.../addons/aws` and `oss`.  
5. Read ALB + Karpenter ApplicationSets end-to-end.  
6. Diff empty vs filled `environments/dev` overlay for one addon.  
7. Write the list of annotations your TF would need for ALB + Karpenter.  
8. Decide starter enable set for a payment EKS sandbox.

## Data flow map

```
[GitHub: eks-blueprints-add-ons]
        │
        ├─ classic ──► path: chart ──► Helm templates ──► Application CRs
        │                                                      │
        │                                                      ▼
        │                                              path: add-ons/<name>
        │                                                      │
        │                                                      ▼
        │                                              upstream Helm chart
        │                                                      │
        └─ modern ──► bootstrap AppSet ──► addon AppSets ──► multi-source Apps
                              ▲                    │
                              │                    ├─ $values: charts→env→cluster
                              │                    └─ upstream chart + inline IRSA
                              │
[Terraform / Blueprints] ─────┴── EKS + IRSA + cluster Secret (labels/annotations)
                              │
                              ▼
                    [Argo CD hub] ──sync──► [EKS spoke workloads: controllers/CRDs]
                              │
                              ▼
                    [AWS APIs via IRSA: ELBv2, EC2, SQS, CloudWatch, …]
```

## Related files

| File | Role |
|------|------|
| [`2-eks-blueprints-add-ons-deep-dive.md`](2-eks-blueprints-add-ons-deep-dive.md) | This deep dive |
| [`2.sh`](2.sh) | Inspect commands |
| Local repo | `/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main` |
| Upstream | https://github.com/aws-samples/eks-blueprints-add-ons |
| Blueprints | https://github.com/aws-ia/terraform-aws-eks-blueprints |
| Prior same-day notes | `Daily Files/2026-07-30/1-gitops-bridge-deep-dive/`, `1-eks-blueprints-deep-dive/` |

## Commands

Inline one-liners are also in [`2.sh`](2.sh):

```bash
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main"
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/add-ons"
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/chart/templates" | wc -l
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/argocd/bootstrap/control-plane/addons/aws"
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/argocd/bootstrap/control-plane/addons/oss"
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/argocd/environments/dev/addons"
```
