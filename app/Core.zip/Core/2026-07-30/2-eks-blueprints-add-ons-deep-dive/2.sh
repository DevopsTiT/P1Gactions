ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main"
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/add-ons"
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/chart/templates" | wc -l
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/argocd/bootstrap/control-plane/addons/aws"
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/argocd/bootstrap/control-plane/addons/oss"
ls "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/argocd/environments/dev/addons"
find "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/argocd" -name '*load-balancer*'
head -40 "/Users/k/Codes/GithubProjects/Terraform/eks-blueprints-add-ons-main/argocd/bootstrap/control-plane/exclude/bootstrap.yaml"
