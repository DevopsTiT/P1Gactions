# 2026-07-30 · Seq 1 · GitOps Bridge Deep Dive

```
want GitOps on EKS but addons need IAM/VPC metadata from Terraform?
  install Helm with Terraform helm provider forever? → state drift fights Argo
  hand-copy ARNs into Git? → brittle
  GitOps Bridge → Terraform creates cloud + IRSA metadata
                 → stores metadata on ArgoCD cluster Secret (annotations/labels)
                 → ArgoCD ApplicationSets read metadata → Helm values for addons
                 → workloads from Git separately
```

| Key point | Detail |
|---|---|
| Repo | `/Users/k/Codes/GithubProjects/Terraform/gitops-bridge-main` |
| Pattern | Bridge IaC outputs into GitOps without Terraform owning Helm state |
| Stable path | Terraform + ArgoCD (getting-started example) |
| Companion Git | `gitops-bridge-argocd-control-plane-template` (addon AppSets / charts wiring) |

## Summary

GitOps Bridge is a **community pattern + examples**: Terraform (or other IaC) builds the EKS cluster and cloud identities, then **passes metadata** (IAM role ARNs, VPC ID, repo URLs, enable flags) into ArgoCD’s cluster Secret. ArgoCD installs addons/workloads from Git using that metadata. Terraform does **not** keep Helm releases for those addons in state (`create_kubernetes_resources = false` on blueprints addons).

---

## Step 0 — Problem the project solves

| Pain | Why it hurts | Bridge answer |
|---|---|---|
| Addons need cloud metadata | ALB controller needs IAM role ARN, VPC ID, region | IaC creates IRSA/roles and exports metadata |
| Terraform Helm provider owns state | `kubectl`/Argo changes fight Terraform | Terraform stops after bootstrap + metadata |
| Hardcoding ARNs in Git | Env-specific, secret sprawl, merge pain | Dynamic annotations on cluster Secret |
| Cluster create vs day-2 | Different tools, need one ops model | Any cluster create tool → same GitOps engine |

**One sentence:** IaC owns **cloud facts**; GitOps owns **cluster desired state**; the bridge is how facts become Helm/AppSet inputs.

---

## Step 1 — Big architecture (data flow)

```
Developer / Platform
  │
  ▼
Terraform apply
  ├── VPC
  ├── EKS (+ core EKS addons: vpc-cni, coredns, kube-proxy, ebs-csi)
  ├── IAM / IRSA for addon SAs (via eks-blueprints-addons, create_k8s=false)
  └── gitops-bridge helm module
        ├── Install ArgoCD (bootstrap only)
        └── Create/update ArgoCD cluster Secret
              annotations = metadata (ARNs, repo URLs, vpc, region…)
              labels      = enable_* flags + cluster selectors
  │
  ▼
kubectl apply bootstrap/addons.yaml   (ApplicationSet)
  │  clusters generator reads Secret
  │  templates use {{metadata.annotations.*}}
  ▼
Addon Git repo (control-plane template)
  └── ApplicationSets / Helm for enabled addons
        values from annotations (role ARN, SA name, …)
  │
  ▼
kubectl apply bootstrap/workloads.yaml
  └── Workload Git path (e.g. game-2048)
```

---

## Step 2 — Repository layout (what lives where)

| Path | Role |
|---|---|
| `README.md` | Pattern intro, why bridge, IaC×GitOps matrix |
| `argocd/` | ArgoCD-focused content (main usable path) |
| `argocd/iac/terraform/examples/eks/*` | Concrete EKS examples (start here) |
| `argocd/iac/pulumi|eksctl|cdk|…` | Other IaC sketches / status |
| `getting-started/` | Canonical tutorial |
| Companion repo (external) | Addon bootstrap Git: `gitops-bridge-argocd-control-plane-template` |

| Example folder | What it teaches |
|---|---|
| `getting-started` | Full bridge: ALB + metrics-server + sample app |
| `karpenter` | Node provisioning via GitOps + IAM metadata |
| `external-secrets` | Secrets from AWS via ESO |
| `aws-secrets-manager` | Secrets Manager pattern |
| `crossplane` | Cloud resources from inside cluster |
| `private-git` | Private repo credentials / access |
| `private-ecr` | Charts/images from private ECR |
| `argocd-ingress` | Expose Argo UI |
| `multi-cluster/hub-spoke` | Hub Argo manages spoke clusters |
| `multi-cluster/hub-spoke-shared` | Shared hub pattern variant |
| `multi-cluster/distributed` | Per-cluster Argo |

---

## Step 3 — Getting Started: prerequisites

| Tool | Why |
|---|---|
| `git` | Forks + clone |
| `terraform` | Apply VPC/EKS/bridge |
| `kubectl` | Bootstrap AppSets, verify |
| `argocd` CLI | Optional UI/login helpers |
| AWS creds | Account that can create EKS/IAM/VPC |

| Git forks (recommended) | Variable |
|---|---|
| Addon control plane template | `TF_VAR_gitops_addons_org` / `_repo` |
| This repo (workloads path) | `TF_VAR_gitops_workload_org` / `_repo` |

---

## Step 4 — Terraform locals: three critical maps

### 4a. `addons` (become **labels** on cluster Secret)

| Source | Examples |
|---|---|
| `local.aws_addons` | `enable_aws_load_balancer_controller`, `enable_karpenter`, … |
| `local.oss_addons` | `enable_argocd`, `enable_metrics_server`, … |
| Merged extras | `kubernetes_version`, `aws_cluster_name` |

**Purpose:** ApplicationSets / cluster generators select which addons install (`enable_*=true`).

### 4b. `addons_metadata` (become **annotations**)

| Merge piece | Contents |
|---|---|
| `module.eks_blueprints_addons.gitops_metadata` | IAM role ARNs, SA names, namespaces for enabled addons |
| AWS context | `aws_cluster_name`, `aws_region`, `aws_account_id`, `aws_vpc_id` |
| Addons Git coords | `addons_repo_url`, `basepath`, `path`, `revision` |
| Workload Git coords | `workload_repo_url`, `basepath`, `path`, `revision` |

**Purpose:** Helm values and AppSet `repoURL`/`path` templates without hardcoding per env in every chart.

### 4c. Why blueprints with `create_kubernetes_resources = false`

| Setting | Effect |
|---|---|
| `enable_aws_load_balancer_controller = true` (blueprints) | Still creates **IAM role / IRSA** in AWS |
| `create_kubernetes_resources = false` | Does **not** Helm-install the controller via Terraform |
| GitOps Bridge | Argo installs the Helm chart later, injecting role ARN from metadata |

This is the core split: **AWS identity in Terraform**, **chart in Argo**.

---

## Step 5 — Terraform modules (apply order of ideas)

| Module / resource | What it creates | Bridge relevance |
|---|---|---|
| `module.vpc` | VPC, public/private subnets, NAT, LB subnet tags | `aws_vpc_id`; subnet tags for ALB |
| `module.eks` | EKS control plane, managed node group, OIDC | Cluster for Argo + workloads |
| `cluster_addons` in EKS | vpc-cni (prefix delegation), coredns, kube-proxy, ebs-csi | Day-0 networking/storage before GitOps addons |
| `module.ebs_csi_driver_irsa` | IRSA for ebs-csi SA | CSI can mount volumes |
| `module.eks_blueprints_addons` | Cloud IAM/metadata for toggled addons | Feeds `gitops_metadata` |
| `module.gitops_bridge_bootstrap` | Helm: ArgoCD + cluster Secret wiring | **The bridge implementation** |

Provider note: `helm` and `kubernetes` providers auth via `aws eks get-token` to the new cluster.

---

## Step 6 — What `gitops_bridge_bootstrap` does

Source in getting-started: `gitops-bridge-dev/gitops-bridge/helm`

| Input | Meaning |
|---|---|
| `cluster.metadata` | Annotation map (ARNs, repo URLs, …) |
| `cluster.addons` | Label map (`enable_*`, version, name) |
| `apps` (optional, hub examples) | Raw Application/ApplicationSet YAML applied at bootstrap |
| `argocd.namespace` | Usually `argocd` |

| Output in cluster | Meaning |
|---|---|
| ArgoCD install | Enough to sync from Git |
| Secret `label: argocd.argoproj.io/secret-type=cluster` | Argo’s view of this cluster + bridge metadata |

Verify:

```
kubectl get secret -n argocd -l argocd.argoproj.io/secret-type=cluster \
  -o json | jq '.items[0].metadata.annotations'

kubectl get secret -n argocd -l argocd.argoproj.io/secret-type=cluster \
  -o json | jq '.items[0].metadata.labels'
```

---

## Step 7 — Bootstrap ApplicationSets (manual apply in getting-started)

### 7a. `bootstrap/addons.yaml` → `ApplicationSet/cluster-addons`

| Field | Value / meaning |
|---|---|
| Generator | `clusters: {}` — every registered cluster Secret |
| `repoURL` | `{{metadata.annotations.addons_repo_url}}` |
| `path` | `basepath + path` → control-plane addons tree |
| `targetRevision` | `addons_repo_revision` |
| Destination | `name: {{name}}` (cluster), ns `argocd` |
| Sync | `automated: {}` |
| `preserveResourcesOnDeletion` | `true` — safer teardown of AppSet |

**Deep point:** One AppSet definition works for many clusters because **each cluster Secret carries its own annotations**.

### 7b. `bootstrap/workloads.yaml` → `ApplicationSet/workloads`

| Field | Value / meaning |
|---|---|
| Source | workload repo annotations |
| Path | e.g. `…/getting-started/k8s` (game-2048) |
| `CreateNamespace=true` | App ns created on sync |
| Finalizer | Demo cascade delete behavior |

Hub examples often pass these YAMLs into the bridge module as `apps = { addons = file(...), workloads = file(...) }` so Terraform applies them too.

---

## Step 8 — How an addon actually gets the IAM role (deep)

```
1. var.addons.enable_aws_load_balancer_controller = true
2. eks-blueprints-addons creates IRSA role for ALB controller
3. gitops_metadata includes e.g.
     aws_load_balancer_controller_iam_role_arn
     aws_load_balancer_controller_service_account
     aws_load_balancer_controller_namespace
4. Bridge writes those as Secret annotations
5. Control-plane template ApplicationSet selects clusters with
     label enable_aws_load_balancer_controller=true
6. Helm chart values reference annotation keys for serviceAccount.annotations.eks.amazonaws.com/role-arn
7. Controller pods assume role → manage ALBs/TargetGroups
```

| Without bridge | With bridge |
|---|---|
| Copy ARN into values.yaml per env | Annotation per cluster Secret |
| Terraform helm release drift | Argo owns chart lifecycle |

---

## Step 9 — End-to-end operator runbook (getting-started)

| Step | Action | Success signal |
|---|---|---|
| 1 | Fork addon + workload repos; set `TF_VAR_gitops_*` | Vars point at your forks |
| 2 | `terraform init && terraform apply` | EKS up; Argo ns exists |
| 3 | `terraform output -raw configure_kubectl` | `kubectl get nodes` works |
| 4 | Inspect cluster Secret annotations/labels | ARNs + `enable_*=true` present |
| 5 | `kubectl apply -f bootstrap/addons.yaml` | AppSet `cluster-addons` exists |
| 6 | `watch kubectl get applications -n argocd` | Addons Healthy |
| 7 | Check Deployments (ALB controller, metrics-server) | Pods Ready |
| 8 | `kubectl apply -f bootstrap/workloads.yaml` | `workloads` App Healthy |
| 9 | Ingress game-2048 reconciles; curl hostname | HTTP 200 |
| 10 | `./destroy.sh` (ordered) | Clean teardown |

---

## Step 10 — Destroy order (why it matters)

From `destroy.sh` pattern:

| Order | Why |
|---|---|
| Delete workload AppSets/apps first | Remove Ingress/ALBs before VPC delete |
| Delete addon AppSets | Controllers stop creating cloud resources |
| Delete Argo server Service (if LB) | Drop LB ENIs |
| `terraform destroy` bridge module | Remove Helm/bootstrap |
| Destroy addons IAM / EKS / VPC | No dangling ENIs/security groups |

**SRE lesson:** GitOps-created AWS resources must be gone before Terraform deletes networking.

---

## Step 11 — Multi-cluster deep points (hub-spoke)

| Concept | Detail |
|---|---|
| Hub cluster | Runs ArgoCD; registers spoke cluster Secrets |
| Spoke | Workload clusters; may not run Argo UI |
| Hub IAM | Role allowing `sts:AssumeRole` into spoke deployer roles |
| Bridge still applies | Each spoke Secret gets its own metadata annotations |
| `apps` in Terraform | Often bootstrap hub AppSets automatically |

| Pattern | When |
|---|---|
| Distributed | Each cluster has its own Argo |
| Hub-spoke | Central GitOps control plane |
| Hub-spoke-shared | Shared platform hub variant |

---

## Step 12 — Design principles (interview-ready)

| Principle | Explanation |
|---|---|
| Separation of duties | Terraform = cloud + bootstrap; Argo = desired K8s state |
| Metadata as contract | Annotations/labels are the API between IaC and GitOps |
| Enable flags as selectors | Progressive addon enablement per cluster |
| Externalize Helm | Avoid Terraform state ownership of charts |
| Git as source for apps | Workloads and addon definitions versioned |
| Engine agnostic intent | Same bridge idea for Flux later (status: in progress) |

---

## Step 13 — What Terraform still installs on the cluster

| Still Terraform / EKS API | Why OK |
|---|---|
| EKS managed addons (CNI, CoreDNS, kube-proxy, EBS CSI) | Cluster won’t boot usefully without them |
| ArgoCD via bridge Helm module | Chicken-egg: need GitOps engine first |
| Cluster Secret | Bridge payload |

| Must NOT stay in Terraform long-term | Day-2 Helm for ALB, metrics-server, app charts |

---

## Step 14 — Common failure modes

| Symptom | Likely cause | Fix direction |
|---|---|---|
| Addon App Degraded / IRSA errors | Annotation missing role ARN / SA name mismatch | Check blueprints enable + metadata keys |
| AppSet created but no apps | Labels `enable_*=false` or generator filter | Fix addon map / Secret labels |
| Wrong Git path | Fork/vars not set | Fix `addons_repo_*` / `workload_repo_*` |
| ALB never appears | Controller not healthy / subnet tags | Check controller logs + public/private subnet tags |
| Destroy hung on ENI/SG | Ingress/LB left behind | Delete apps/Ingress before TF destroy |
| Terraform wants to change Helm | Someone used helm provider for same chart | Keep `create_kubernetes_resources=false` |

---

## Step 15 — Map to your SRE daily spine

| SRE domain | Where it shows in GitOps Bridge |
|---|---|
| AWS | VPC, IAM/IRSA, ALB, EKS |
| EKS ops | Nodes, CNI, workloads, Ingress |
| Terraform | Cluster + identities + metadata only |
| GitOps/CI | Argo AppSets, addon/workload repos |

---

## Data flow map (pic)

```
Terraform
  VPC + EKS + IRSA + gitops_metadata
       │
       ▼
ArgoCD cluster Secret
  annotations (facts) + labels (enable flags)
       │
       ▼
ApplicationSet (clusters generator)
       │
       ├── control-plane Git → addon Helms (use annotations)
       └── workload Git → apps (game-2048, …)
       │
       ▼
AWS APIs (ALB, etc.) via IRSA
```

## Related files

| File | Role |
|---|---|
| `argocd/iac/terraform/examples/eks/getting-started/main.tf` | Canonical implementation |
| `…/bootstrap/addons.yaml` | Addon AppSet |
| `…/bootstrap/workloads.yaml` | Workload AppSet |
| Root `README.md` | Pattern definition |

## Commands

See `1.sh` for inspect/bootstrap one-liners (run after apply in the example dir).
