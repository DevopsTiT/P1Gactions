kubectl get secret -n argocd -l argocd.argoproj.io/secret-type=cluster -o json | jq '.items[0].metadata.annotations'
kubectl get secret -n argocd -l argocd.argoproj.io/secret-type=cluster -o json | jq '.items[0].metadata.labels'
kubectl apply -f bootstrap/addons.yaml
kubectl get applications -n argocd
kubectl apply -f bootstrap/workloads.yaml
kubectl get -n game-2048 deployments,service,ingress
curl -I $(kubectl get -n game-2048 ingress game-2048 -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
