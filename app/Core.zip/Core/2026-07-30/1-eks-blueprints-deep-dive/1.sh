# EKS Blueprints — review before running. Replace REGION/CLUSTER_NAME/PATTERN as needed.
cd /Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-blueprints-main/patterns/karpenter
terraform init
terraform apply -target="module.vpc" -auto-approve
terraform apply -target="module.eks" -auto-approve
terraform apply -auto-approve
terraform output -raw configure_kubectl
aws eks --region us-west-2 update-kubeconfig --name ex-karpenter --alias ex-karpenter
kubectl get nodes
kubectl get pods -A
kubectl apply --server-side -f /Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-blueprints-main/patterns/karpenter/karpenter.yaml
kubectl apply --server-side -f /Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-blueprints-main/patterns/karpenter/example.yaml
kubectl scale deployment inflate --replicas=3
kubectl get nodes -w
kubectl delete -f /Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-blueprints-main/patterns/karpenter/example.yaml
terraform destroy -target=helm_release.karpenter --auto-approve
terraform destroy -target="module.eks_blueprints_addons" -auto-approve
terraform destroy -target="module.eks" -auto-approve
terraform destroy -auto-approve
aws logs describe-log-groups --log-group-name-prefix "/aws/eks/"
kubectl get namespaces
kubectl api-resources --verbs=list --namespaced -o name
terraform refresh
cd /Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-blueprints-main/patterns/gitops/getting-started-argocd
kubectl get secret -n argocd -l argocd.argoproj.io/secret-type=cluster -o json
cd /Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-blueprints-main/patterns/fully-private-cluster
cd /Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-blueprints-main/patterns/blue-green-upgrade
