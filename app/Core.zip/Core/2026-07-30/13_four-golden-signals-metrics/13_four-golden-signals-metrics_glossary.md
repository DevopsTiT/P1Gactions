# Four Golden Signals Metrics — Glossary

**Four Golden Signals**
The four metrics that together describe a service's complete health from a user perspective, defined by Google SRE. Traffic, Errors, Latency, and Saturation. If all four are healthy, users are not experiencing problems. If any one is unhealthy, investigate immediately.

**Traffic Signal**
How many requests per second/minute a service receives. The denominator for error rate. Most importantly: when traffic drops to zero, error rate is also zero — the service looks "healthy" to error-only monitors. A traffic drop alert is the ONLY way to detect silent outages.

**Errors Signal**
The percentage of requests that result in HTTP 5xx responses or application-level errors. Directly measures user-facing failures. The most intuitive signal — users notice errors immediately.

**Latency Signal**
How long requests take to complete, measured at the 99th percentile (P99). P99 means 99% of requests are faster than this value. 1% of users (potentially thousands per hour) experience the P99 latency. Average latency hides this tail.

**Saturation Signal**
How "full" a resource is: CPU %, memory %, thread pool %, connection pool %. Saturation is the LEADING indicator — it shows resource pressure BEFORE errors and latency spikes appear. Detecting saturation early gives time to scale before users are impacted.

**Silent Outage**
A service failure where error rate is 0% because no requests are reaching the service. Caused by: DNS failure, ALB misconfiguration, deployment failure (pods never start), network routing issues. Only detectable by monitoring traffic volume, not error rate.

**`builtin:service.requestCount.server`**
Dynatrace's built-in metric counting total server-side requests per minute. The traffic signal. Used with alert direction BELOW to detect traffic drops.

**`builtin:service.errors.server.rate`**
Dynatrace's built-in metric for HTTP 5xx error rate as a decimal (0.005 = 0.5%). The error signal. Used with alert direction ABOVE to detect error spikes.

**`builtin:service.response.time`**
Dynatrace's built-in metric for server-side response time in microseconds. With `aggregation = "PERCENTILE"` and `percentile = 99`, gives P99 latency. The latency signal. Multiply millisecond thresholds by 1000 (DT internal unit is microseconds).

**`builtin:process.cpu.usage`**
Dynatrace's built-in metric for process-level CPU utilisation as a percentage (0–100). More accurate than Kubernetes pod CPU metrics which are subject to cgroup throttling. The saturation signal.

**`alert_condition = "BELOW"`**
The metric event alert direction for traffic drop. Fires when the metric goes BELOW the threshold. All other signals use "ABOVE". Traffic drop is unique in that you want to alert when there is too LITTLE of something (too few requests).

**`alert_on_no_data = true`**
When true, fires the alert even when Dynatrace receives no data points at all (service completely unreachable). Critical for traffic drop alerts — if the service is down, DT receives no metrics and `alert_on_no_data = true` ensures the alert still fires.

**`ERROR_EVENT`**
A Dynatrace metric event type that maps to the ERROR severity level in Alerting Profiles. Routes to the critical alerting profile → PagerDuty. Used for traffic drop (silent outage = critical) and error rate alerts.

**`PERFORMANCE_EVENT`**
A Dynatrace metric event type mapping to PERFORMANCE/SLOWDOWN severity. Routes to the warning alerting profile → Slack. Used for latency alerts.

**`RESOURCE_CONTENTION_EVENT`**
A Dynatrace metric event type mapping to RESOURCE_CONTENTION severity. Routes to the warning alerting profile with a 15-minute delay → Slack. Used for CPU saturation alerts. Saturation is a warning — the service is still running, just approaching limits.

**`dt.entity.process_group_instance`**
The Dynatrace entity dimension key for process-level metrics (CPU, memory, thread count). Must be used as `event_entity_dimension_key` for CPU saturation alerts. Using `dt.entity.service` for a CPU metric would mismatch the entity type and break Management Zone routing.

**`dt.entity.service`**
The Dynatrace entity dimension key for service-level metrics (error rate, latency, request count). Must be used as `event_entity_dimension_key` for traffic, error, and latency alerts.

**P99 (99th percentile)**
The latency value that 99% of requests are FASTER than. If P99 is 500ms, 1% of users experience > 500ms. For a service handling 10,000 req/min, that is 100 slow requests per minute — real user impact.

**`violating_samples`**
The number of consecutive 1-minute evaluation periods that must exceed the threshold before a Dynatrace Problem is created. `3` = three consecutive minutes above threshold. Prevents a brief 1-minute spike (rolling deployment, batch job) from creating an alert.

**`dealerting_samples`**
Consecutive evaluation periods BELOW the threshold required before the Problem closes. Set higher than `violating_samples` to prevent flapping. CPU saturation uses 10 (recovery is slow); error rate uses 5.

**`percentile = 99`**
Tells Dynatrace to compute the 99th percentile of the response time distribution, not the average. Required for the latency signal — average latency hides the long tail that users actually experience.

**`resolution = "1m"`**
The evaluation granularity for the metric query. 1-minute resolution means Dynatrace checks the threshold every minute. Combined with `violating_samples = 3`, an alert fires after 3 minutes of threshold breach.

**HPA (HorizontalPodAutoscaler)**
Kubernetes resource that automatically scales pod count based on CPU or custom metrics. Typically configured to scale up at 70% CPU utilisation. Setting the saturation alert at 80% CPU means: HPA is already scaling when the alert fires. The alert catches cases where HPA hasn't responded quickly enough.

**`traffic_min_rps`**
A custom threshold field (not built-in to Dynatrace) defined in the project's `variables.tf` `services` map. Specifies the minimum expected request rate per minute. Set based on your service's observed baseline traffic at the quietest time of day.

**`cpu_saturation_pct`**
A custom threshold field in the `services` map specifying the CPU percentage at which a saturation alert fires. Typically 10 percentage points above the HPA scale-up trigger (if HPA triggers at 70%, set this to 80%).
