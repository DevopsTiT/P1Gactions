# Four Golden Signals — Adding Traffic and Saturation to metric-events.tf

---

## Current State vs Target

The existing `metric-events.tf` only measures **2 of the 4 golden signals**:

| Signal | Current | Target |
|---|---|---|
| **Traffic** (request rate) | ❌ Missing | ✅ Add |
| **Errors** (error rate) | ✅ `error_rate` resource | ✅ Keep |
| **Latency** (P99 response time) | ✅ `latency_p99` resource | ✅ Keep |
| **Saturation** (CPU / thread pool) | ❌ Missing | ✅ Add |

Without Traffic: a silent outage (0 errors, but 0 traffic) looks healthy.
Without Saturation: CPU maxing out 5 minutes before the service degrades is invisible.

---

## Required variables.tf Changes

Two new threshold fields must be added to the `services` object type and each service entry.

**Add to `variable "services"` object type:**
```hcl
traffic_min_rps      = number   # req/min below which traffic-drop alert fires
cpu_saturation_pct   = number   # CPU % above which saturation alert fires
```

**Update each service entry (example):**
```hcl
"payment-service" = {
  team             = "payments"
  slo_target       = 99.9
  error_rate_alert = 0.5
  latency_p99_ms   = 500
  health_check_url = "https://payment.company.com/health/ready"
  traffic_min_rps  = 10    # alert if req/min drops below 10 (silent outage)
  cpu_saturation_pct = 80  # alert if process CPU exceeds 80%
}
```

See artifact file `variables-addition.tf` for the exact diff to apply.

---

## Apply Steps

```bash
# Step 1: Apply the updated variables and metric-events
cd terraform/dynatrace/

# Step 2: Preview — should show 2 new resources per service
terraform plan
# Expected for payment-service:
#   + dynatrace_metric_events.traffic_drop["payment-service"]
#   + dynatrace_metric_events.cpu_saturation["payment-service"]
#   Plan: 2 to add, 0 to change, 0 to destroy.

# Step 3: Apply
terraform apply

# Step 4: Verify in Dynatrace UI
# Settings → Anomaly Detection → Custom Events for Alerting
# Should see 4 events per service: error_rate, latency_p99, traffic_drop, cpu_saturation

# Step 5: Verify in DT API
DT_TENANT="abc12345"
DT_TOKEN="dt0c01.YOUR_TOKEN"
curl -s "https://${DT_TENANT}.live.dynatrace.com/api/config/v1/anomalyDetection/metricEvents" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  jq '[.values[] | {name: .name}]'
# Expected: 4 events for payment-service
```

---

## What Each New Metric Measures

### Signal 1 (added): Traffic Drop — `builtin:service.requestCount.server`

Fires when requests per minute drop BELOW a threshold. Silent outages look like this:
- Error rate: 0% (no requests = no errors → looks healthy!)
- Traffic: 0 req/min (dropped from baseline)

This is the only metric that catches: DNS failure, deployment that never started, ALB misconfiguration that routes 0 traffic to pods.

Alert direction: **BELOW** (not ABOVE) — unique among the four signals.

### Signal 4 (added): CPU Saturation — `builtin:process.cpu.usage`

Fires when process-level CPU exceeds a threshold BEFORE the service degrades. CPU at 90% means:
- Threads are competing for CPU time
- Response times will spike in the next 2-5 minutes
- HPA may not have scaled yet

**Process-level (not pod-level):** `builtin:process.cpu.usage` measures the actual process CPU consumption — more accurate than Kubernetes pod-level metrics which are throttled by cgroup limits.

**`event_entity_dimension_key = "dt.entity.process_group_instance"`** — saturation uses the process entity, not the service entity. This is correct because CPU is a process-level metric. The Management Zone rule matches both service and process entities for the team tag.

---

## The Four Signals Together

After applying both new resources, every service has:

```
payment-service alerts:
  1. error_rate         → fires when HTTP 5xx rate > 0.5% for 3 consecutive minutes
  2. latency_p99        → fires when P99 latency > 500ms for 3 consecutive minutes
  3. traffic_drop       → fires when req/min < 10 for 3 consecutive minutes (silent outage)
  4. cpu_saturation     → fires when process CPU > 80% for 5 consecutive minutes
```

All four wire to the same alerting profiles and notifications:
- AVAILABILITY / ERROR events → PagerDuty (critical profile)
- SLOWDOWN / RESOURCE_CONTENTION events → Slack (warning profile)

Traffic drop fires as `ERROR_EVENT` → PagerDuty (silent outage = P1).
CPU saturation fires as `RESOURCE_CONTENTION_EVENT` → Slack (saturation = warning, not immediate outage).
