##############################################################################
# ADD TO: terraform/dynatrace/variables.tf
#
# Changes required:
# 1. Add two new fields to the services object type
# 2. Add the values for each existing service entry
##############################################################################

# ── CHANGE 1: Add fields to the object type declaration ──────────────────────
# In the variable "services" type = map(object({...})) block, add:

# traffic_min_rps    = number   # req/min below which traffic-drop alert fires
# cpu_saturation_pct = number   # CPU % above which saturation alert fires

# ── CHANGE 2: Updated services default with new fields ───────────────────────
# Replace the existing default block with this:

variable "services" {
  type = map(object({
    team               = string
    slo_target         = number
    error_rate_alert   = number
    latency_p99_ms     = number
    health_check_url   = string
    traffic_min_rps    = number   # NEW: minimum expected req/min
    cpu_saturation_pct = number   # NEW: CPU % threshold for saturation alert
  }))

  default = {
    "payment-service" = {
      team               = "payments"
      slo_target         = 99.9
      error_rate_alert   = 0.5
      latency_p99_ms     = 500
      health_check_url   = "https://payment.company.com/health/ready"
      traffic_min_rps    = 10    # payment-service always has traffic; < 10 = silent outage
      cpu_saturation_pct = 80    # alert at 80% — leaves 20% headroom before throttling
    }
  }
}

##############################################################################
# THRESHOLD GUIDANCE per service type:
#
# traffic_min_rps — set to your minimum expected traffic at quietest time of day
#   High-traffic service (payments):   10-50 req/min
#   Medium-traffic service (orders):    5-10 req/min
#   Low-traffic service (notification): 1-5  req/min (async, low baseline)
#   Cron/batch service:                 0    (skip traffic alert for these)
#
# cpu_saturation_pct — set based on your HPA trigger point
#   Standard:  80% (HPA triggers at 70% CPU → saturation fires at 80% → already scaling)
#   Memory-intensive Java services: 70% (GC pressure starts earlier)
#   Batch/worker services: 90% (expected to run hot)
##############################################################################
