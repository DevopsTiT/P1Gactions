##############################################################################
# Dynatrace Custom Metric Events — Four Golden Signals
#
# SIGNAL 1: TRAFFIC  → traffic_drop    (req/min drops below threshold)
# SIGNAL 2: ERRORS   → error_rate      (HTTP 5xx rate exceeds threshold)
# SIGNAL 3: LATENCY  → latency_p99     (p99 response time exceeds threshold)
# SIGNAL 4: SATURATION → cpu_saturation (process CPU exceeds threshold)
#
# All thresholds come from var.services — one entry per microservice.
# For each service: 4 metric events created automatically via for_each.
##############################################################################

# ─────────────────────────────────────────────────────────────────────────────
# SIGNAL 1: TRAFFIC — requests per minute
# WHY: error rate = 0% when traffic = 0 (no requests = no errors = looks healthy).
# A silent outage (DNS failure, ALB misconfiguration, deploy failure) is ONLY
# caught by a traffic drop alert. All other signals look green while traffic is 0.
# Alert direction: BELOW (unique — all other signals alert ABOVE threshold).
# ─────────────────────────────────────────────────────────────────────────────
resource "dynatrace_metric_events" "traffic_drop" {
  for_each = var.services

  enabled                    = true
  event_entity_dimension_key = "dt.entity.service"
  event_type                 = "ERROR_EVENT"
  # ERROR_EVENT → routes to the CRITICAL alerting profile (PagerDuty)
  # Traffic drop = silent outage = P1 severity
  summary     = "[${upper(var.environment)}] ${each.key}: Traffic drop (<${each.value.traffic_min_rps} req/min)"
  description = "Request rate for ${each.key} dropped below ${each.value.traffic_min_rps} req/min. Possible silent outage. Owner: team:${each.value.team}"

  metadata {
    configuration_versions = [4]
    dynatrace_version      = "1.0"
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "BELOW"   # ← BELOW threshold, not ABOVE
    alert_on_no_data   = true      # ← fire even when DT receives NO data (service unreachable)
    dealerting_samples = 5         # 5 consecutive minutes above threshold before closing
    samples            = 3
    threshold          = each.value.traffic_min_rps
    violating_samples  = 3         # 3 consecutive minutes below threshold before firing
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:service.requestCount.server"
    # builtin:service.requestCount.server = total server-side requests per minute
    # This is the denominator for error rate and the traffic signal.
    resolution = "1m"
    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = each.key
        key      = "service.name"
      }
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment
        key      = "environment"
      }
    }
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# SIGNAL 2: ERRORS — HTTP 5xx error rate %
# WHY: The most direct signal of user-visible failures.
# 5xx responses = the service is failing to process requests.
# ─────────────────────────────────────────────────────────────────────────────
resource "dynatrace_metric_events" "error_rate" {
  for_each = var.services

  enabled                    = true
  event_entity_dimension_key = "dt.entity.service"
  event_type                 = "ERROR_EVENT"
  summary                    = "[${upper(var.environment)}] ${each.key}: High error rate (>${each.value.error_rate_alert}%)"
  description                = "Error rate exceeded ${each.value.error_rate_alert}% for ${each.key}. Owner: team:${each.value.team}"

  metadata {
    configuration_versions = [4]
    dynatrace_version      = "1.0"
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    dealerting_samples = 5
    samples            = 5
    threshold          = each.value.error_rate_alert   # e.g., 0.5 = 0.5%
    violating_samples  = 3
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:service.errors.server.rate"
    # Returns a decimal: 0.005 = 0.5% error rate
    resolution = "1m"
    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = each.key
        key      = "service.name"
      }
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment
        key      = "environment"
      }
    }
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# SIGNAL 3: LATENCY — P99 response time
# WHY: P99 reveals the long tail — 1% of users experiencing slow requests.
# Average latency hides outliers; P99 exposes them.
# Dynatrace stores response time in MICROSECONDS (µs).
# var.latency_p99_ms is in ms → multiply by 1000 for the threshold.
# ─────────────────────────────────────────────────────────────────────────────
resource "dynatrace_metric_events" "latency_p99" {
  for_each = var.services

  enabled                    = true
  event_entity_dimension_key = "dt.entity.service"
  event_type                 = "PERFORMANCE_EVENT"
  # PERFORMANCE_EVENT → routes to SLOWDOWN severity → Warning alerting profile (Slack)
  summary     = "[${upper(var.environment)}] ${each.key}: p99 latency breach (>${each.value.latency_p99_ms}ms)"
  description = "p99 latency exceeded ${each.value.latency_p99_ms}ms for ${each.key}. Owner: team:${each.value.team}"

  metadata {
    configuration_versions = [4]
    dynatrace_version      = "1.0"
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    dealerting_samples = 5
    samples            = 5
    threshold          = each.value.latency_p99_ms * 1000  # 500ms → 500,000 µs
    violating_samples  = 3
  }

  query_definition {
    type        = "METRIC_KEY"
    metric_key  = "builtin:service.response.time"
    aggregation = "PERCENTILE"
    percentile  = 99   # P99: 99% of requests are faster than this
    resolution  = "1m"
    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = each.key
        key      = "service.name"
      }
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment
        key      = "environment"
      }
    }
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# SIGNAL 4: SATURATION — process CPU utilisation %
# WHY: Saturation is the LEADING indicator — predicts future degradation.
# CPU at 90% means latency spikes are coming in the next 2-5 minutes.
# HPA may not have triggered yet. This fires before user impact is visible.
#
# IMPORTANT: Uses dt.entity.process_group_instance (not dt.entity.service).
# CPU is a process-level metric — must match the entity dimension key.
# The Management Zone rule matches both service AND process entities for the
# team tag, so this alert still routes to the correct team's alerting profile.
# ─────────────────────────────────────────────────────────────────────────────
resource "dynatrace_metric_events" "cpu_saturation" {
  for_each = var.services

  enabled                    = true
  event_entity_dimension_key = "dt.entity.process_group_instance"
  # ↑ MUST be process_group_instance for CPU metrics — not dt.entity.service
  event_type = "RESOURCE_CONTENTION_EVENT"
  # RESOURCE_CONTENTION_EVENT → routes to RESOURCE_CONTENTION severity
  # → Warning alerting profile (Slack, 15-min delay) — saturation is a warning, not immediate outage
  summary     = "[${upper(var.environment)}] ${each.key}: CPU saturation (>${each.value.cpu_saturation_pct}%)"
  description = "Process CPU for ${each.key} exceeded ${each.value.cpu_saturation_pct}% for 5 consecutive minutes. Scale-out may be required. Owner: team:${each.value.team}"

  metadata {
    configuration_versions = [4]
    dynatrace_version      = "1.0"
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    dealerting_samples = 10   # longer de-alerting for saturation (CPU pressure resolves slowly)
    samples            = 5    # 5 consecutive minutes above threshold
    threshold          = each.value.cpu_saturation_pct   # e.g., 80 = 80%
    violating_samples  = 5    # more samples than error/latency — filter transient CPU spikes
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:process.cpu.usage"
    # builtin:process.cpu.usage = process-level CPU as a percentage (0-100)
    # More accurate than Kubernetes pod CPU (which is throttled by cgroup limits).
    resolution = "1m"
    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = each.key
        key      = "process.name"
        # process.name matches the process group name in Dynatrace
        # (usually same as the service name when discovered by OneAgent)
      }
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment
        key      = "environment"
      }
    }
  }
}
