# EKS GitOps File Deep Dives Index

Deep-dive markdown for **62 source files** under `app/`, `charts/`, `docs/`, `k8s/`, `scripts/`, `.github/`, and repo root — excluding `terraform/` and `gitops/` (handled by other agents).

**Output base:** `/Users/k/Learnings/AIProject/CursorFiles/Daily Files/2026-07-30/2-eks-gitops-file-deep-dives/`

**Source repo:** `/Users/k/Codes/GithubProjects/Terraform/eks-gitops-platform-main/`

Each deep-dive uses: What this file is → Why it exists → What is inside → How it connects → Beginner notes → Related source.

## Summary

| Area | Files |
|------|-------|
| root/ | 4 |
| app/ | 5 |
| charts/ | 22 |
| docs/ | 17 |
| k8s/ | 2 |
| scripts/ | 3 |
| github/ | 9 |
| **Total** | **62** |

## root/

| Source (repo path) | Deep dive |
|--------------------|-----------|
| `README.md` | [README.md](root/README.md) |
| `.gitignore` | [.gitignore.md](root/.gitignore.md) |
| `.yamllint.yaml` | [.yamllint.yaml.md](root/.yamllint.yaml.md) |
| `compose.yaml` | [compose.yaml.md](root/compose.yaml.md) |

## app/

| Source (repo path) | Deep dive |
|--------------------|-----------|
| `app/Dockerfile` | [Dockerfile.md](app/Dockerfile.md) |
| `app/.dockerignore` | [.dockerignore.md](app/.dockerignore.md) |
| `app/README.md` | [README.md](app/README.md) |
| `app/requirements.txt` | [requirements.txt.md](app/requirements.txt.md) |
| `app/src/app.py` | [src--app.py.md](app/src--app.py.md) |

## charts/

| Source (repo path) | Deep dive |
|--------------------|-----------|
| `charts/namespaces/Chart.yaml` | [namespaces--Chart.yaml.md](charts/namespaces--Chart.yaml.md) |
| `charts/namespaces/README.md` | [namespaces--README.md](charts/namespaces--README.md) |
| `charts/namespaces/values.yaml` | [namespaces--values.yaml.md](charts/namespaces--values.yaml.md) |
| `charts/namespaces/templates/namespace.yaml` | [namespaces--templates--namespace.yaml.md](charts/namespaces--templates--namespace.yaml.md) |
| `charts/namespaces/templates/resourcequota.yaml` | [namespaces--templates--resourcequota.yaml.md](charts/namespaces--templates--resourcequota.yaml.md) |
| `charts/raw/Chart.yaml` | [raw--Chart.yaml.md](charts/raw--Chart.yaml.md) |
| `charts/raw/README.md` | [raw--README.md](charts/raw--README.md) |
| `charts/raw/values.yaml` | [raw--values.yaml.md](charts/raw--values.yaml.md) |
| `charts/raw/templates/resources.yaml` | [raw--templates--resources.yaml.md](charts/raw--templates--resources.yaml.md) |
| `charts/simple-time-service/Chart.yaml` | [simple-time-service--Chart.yaml.md](charts/simple-time-service--Chart.yaml.md) |
| `charts/simple-time-service/README.md` | [simple-time-service--README.md](charts/simple-time-service--README.md) |
| `charts/simple-time-service/values.yaml` | [simple-time-service--values.yaml.md](charts/simple-time-service--values.yaml.md) |
| `charts/simple-time-service/templates/_helpers.tpl` | [simple-time-service--templates--_helpers.tpl.md](charts/simple-time-service--templates--_helpers.tpl.md) |
| `charts/simple-time-service/templates/deployment.yaml` | [simple-time-service--templates--deployment.yaml.md](charts/simple-time-service--templates--deployment.yaml.md) |
| `charts/simple-time-service/templates/service.yaml` | [simple-time-service--templates--service.yaml.md](charts/simple-time-service--templates--service.yaml.md) |
| `charts/simple-time-service/templates/serviceaccount.yaml` | [simple-time-service--templates--serviceaccount.yaml.md](charts/simple-time-service--templates--serviceaccount.yaml.md) |
| `charts/simple-time-service/templates/ingress.yaml` | [simple-time-service--templates--ingress.yaml.md](charts/simple-time-service--templates--ingress.yaml.md) |
| `charts/simple-time-service/templates/hpa.yaml` | [simple-time-service--templates--hpa.yaml.md](charts/simple-time-service--templates--hpa.yaml.md) |
| `charts/simple-time-service/templates/pdb.yaml` | [simple-time-service--templates--pdb.yaml.md](charts/simple-time-service--templates--pdb.yaml.md) |
| `charts/simple-time-service/templates/networkpolicy.yaml` | [simple-time-service--templates--networkpolicy.yaml.md](charts/simple-time-service--templates--networkpolicy.yaml.md) |
| `charts/simple-time-service/templates/servicemonitor.yaml` | [simple-time-service--templates--servicemonitor.yaml.md](charts/simple-time-service--templates--servicemonitor.yaml.md) |
| `charts/simple-time-service/templates/NOTES.txt` | [simple-time-service--templates--NOTES.txt.md](charts/simple-time-service--templates--NOTES.txt.md) |

## docs/

| Source (repo path) | Deep dive |
|--------------------|-----------|
| `docs/cost.md` | [cost.md](docs/cost.md) |
| `docs/design-decisions.md` | [design-decisions.md](docs/design-decisions.md) |
| `docs/security.md` | [security.md](docs/security.md) |
| `docs/runbooks/README.md` | [runbooks--README.md](docs/runbooks--README.md) |
| `docs/runbooks/alb-503.md` | [runbooks--alb-503.md](docs/runbooks--alb-503.md) |
| `docs/runbooks/alertmanager-not-firing.md` | [runbooks--alertmanager-not-firing.md](docs/runbooks--alertmanager-not-firing.md) |
| `docs/runbooks/argocd-outofsync.md` | [runbooks--argocd-outofsync.md](docs/runbooks--argocd-outofsync.md) |
| `docs/runbooks/ebs-pvc-not-mounting.md` | [runbooks--ebs-pvc-not-mounting.md](docs/runbooks--ebs-pvc-not-mounting.md) |
| `docs/runbooks/external-secrets-not-syncing.md` | [runbooks--external-secrets-not-syncing.md](docs/runbooks--external-secrets-not-syncing.md) |
| `docs/runbooks/externaldns-not-creating-record.md` | [runbooks--externaldns-not-creating-record.md](docs/runbooks--externaldns-not-creating-record.md) |
| `docs/runbooks/hpa-not-scaling.md` | [runbooks--hpa-not-scaling.md](docs/runbooks--hpa-not-scaling.md) |
| `docs/runbooks/karpenter-node-not-provisioning.md` | [runbooks--karpenter-node-not-provisioning.md](docs/runbooks--karpenter-node-not-provisioning.md) |
| `docs/runbooks/kyverno-policy-violation.md` | [runbooks--kyverno-policy-violation.md](docs/runbooks--kyverno-policy-violation.md) |
| `docs/runbooks/loki-no-logs.md` | [runbooks--loki-no-logs.md](docs/runbooks--loki-no-logs.md) |
| `docs/runbooks/prometheus-target-down.md` | [runbooks--prometheus-target-down.md](docs/runbooks--prometheus-target-down.md) |
| `docs/runbooks/thanos-no-metrics.md` | [runbooks--thanos-no-metrics.md](docs/runbooks--thanos-no-metrics.md) |
| `docs/runbooks/velero-restore.md` | [runbooks--velero-restore.md](docs/runbooks--velero-restore.md) |

## k8s/

| Source (repo path) | Deep dive |
|--------------------|-----------|
| `k8s/README.md` | [README.md](k8s/README.md) |
| `k8s/microservice.yaml` | [microservice.yaml.md](k8s/microservice.yaml.md) |

## scripts/

| Source (repo path) | Deep dive |
|--------------------|-----------|
| `scripts/README.md` | [README.md](scripts/README.md) |
| `scripts/load_test.py` | [load_test.py.md](scripts/load_test.py.md) |
| `scripts/k6-staged.js` | [k6-staged.js.md](scripts/k6-staged.js.md) |

## github/

| Source (repo path) | Deep dive |
|--------------------|-----------|
| `.github/CI.md` | [CI.md](github/CI.md) |
| `.github/CODEOWNERS` | [CODEOWNERS.md](github/CODEOWNERS.md) |
| `.github/branch-protection.md` | [branch-protection.md](github/branch-protection.md) |
| `.github/workflows/app-image.yaml` | [workflows--app-image.yaml.md](github/workflows--app-image.yaml.md) |
| `.github/workflows/terraform-ci.yaml` | [workflows--terraform-ci.yaml.md](github/workflows--terraform-ci.yaml.md) |
| `.github/workflows/gitops-ci.yaml` | [workflows--gitops-ci.yaml.md](github/workflows--gitops-ci.yaml.md) |
| `.github/workflows/actions-check.yaml` | [workflows--actions-check.yaml.md](github/workflows--actions-check.yaml.md) |
| `.github/workflows/codeowners-check.yaml` | [workflows--codeowners-check.yaml.md](github/workflows--codeowners-check.yaml.md) |
| `.github/workflows/pr-title-check.yaml` | [workflows--pr-title-check.yaml.md](github/workflows--pr-title-check.yaml.md) |
