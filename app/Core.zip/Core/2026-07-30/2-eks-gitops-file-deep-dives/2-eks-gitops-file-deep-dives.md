# EKS GitOps Every File Deep Dives

```
need every file explained?
  start → this index
  terraform files? → terraform/_index.md
  gitops files? → gitops/_index.md
  app/charts/docs/ci? → _index-app-charts-docs-ci.md
  one file? → open matching *.md (path with / → --)
```

## Short takeaway

| Key point | Detail |
|-----------|--------|
| Location | `Daily Files/2026-07-30/2-eks-gitops-file-deep-dives/` |
| Count | **156** per-file deep-dive markdown files |
| Format | Each MD: What → Why → Inside → Connects → Beginner notes → Source path |
| Source repo | `/Users/k/Codes/GithubProjects/Terraform/eks-gitops-platform-main` |

## Summary

Every meaningful source file in the EKS GitOps platform repo has its own deep-dive markdown. Use the three indexes below, then open the matching file.

## Main content

### How to find a file’s deep dive

| Source path example | Deep-dive MD |
|---------------------|--------------|
| `terraform/main.tf` | `terraform/main.tf.md` |
| `terraform/modules/eks/main.tf` | `terraform/modules--eks--main.tf.md` |
| `gitops/bootstrap/root-app.yaml` | `gitops/bootstrap--root-app.yaml.md` |
| `app/src/app.py` | `app/src--app.py.md` |
| `.github/workflows/terraform-ci.yaml` | `github/workflows--terraform-ci.yaml.md` |

Rule: under each area folder, `/` in the relative path becomes `--`.

### Indexes (start here)

| Index | Covers |
|-------|--------|
| [terraform/_index.md](terraform/_index.md) | All Terraform root, modules, app-bootstrap, scripts, lint (~38) |
| [gitops/_index.md](gitops/_index.md) | All ArgoCD apps, ApplicationSets, READMEs (~56) |
| [_index-app-charts-docs-ci.md](_index-app-charts-docs-ci.md) | Root, app, charts, docs/runbooks, k8s, scripts, `.github` (~62) |

### Folder layout

```
2-eks-gitops-file-deep-dives/
├── 2-eks-gitops-file-deep-dives.md   ← this master index
├── 2.sh
├── terraform/     + _index.md
├── gitops/        + _index.md
├── app/
├── charts/
├── docs/
├── github/
├── k8s/
├── root/
├── scripts/
└── _index-app-charts-docs-ci.md
```

### What each deep-dive MD contains

| Section | Purpose |
|---------|---------|
| What this file is | Plain-English one-liner |
| Why it exists | Reasons table |
| What is inside | Block-by-block / field-by-field deep dive |
| How it connects | Upstream/downstream links |
| Beginner notes | Pitfalls |
| Related source | Absolute path to the real file |

### Skipped on purpose

| Skipped | Why |
|---------|-----|
| `*.png` | Screenshots, not code |
| `.terraform.lock.hcl` | Provider lock noise |
| `README.md.gotmpl` | Helm-docs template only |

## Data flow map

```
eks-gitops-platform-main/<any-file>
        │
        ▼
2-eks-gitops-file-deep-dives/<area>/<path--with--dashes>.md
        │
        ├── terraform/*  ← AWS foundation explain
        ├── gitops/*     ← ArgoCD desired-state explain
        └── app|charts|docs|github|…  ← app + CI + runbooks
```

## Related files

| File | Role |
|------|------|
| `2-eks-gitops-file-deep-dives.md` | Master index |
| `2.sh` | List/find helpers |
| `../1-eks-gitops-platform-deep-dive/` | Platform-level (not per-file) overview |

## Commands

See [2.sh](2.sh).
