find "/Users/k/Learnings/AIProject/CursorFiles/Daily Files/2026-07-30/2-eks-gitops-file-deep-dives" -name '*.md' ! -name '_*' | wc -l
ls "/Users/k/Learnings/AIProject/CursorFiles/Daily Files/2026-07-30/2-eks-gitops-file-deep-dives/terraform/_index.md"
ls "/Users/k/Learnings/AIProject/CursorFiles/Daily Files/2026-07-30/2-eks-gitops-file-deep-dives/gitops/_index.md"
ls "/Users/k/Learnings/AIProject/CursorFiles/Daily Files/2026-07-30/2-eks-gitops-file-deep-dives/_index-app-charts-docs-ci.md"
# Find one file's deep dive by name:
# find "/Users/k/Learnings/AIProject/CursorFiles/Daily Files/2026-07-30/2-eks-gitops-file-deep-dives" -iname '*root-app*'
# find "/Users/k/Learnings/AIProject/CursorFiles/Daily Files/2026-07-30/2-eks-gitops-file-deep-dives" -iname '*main.tf*'
