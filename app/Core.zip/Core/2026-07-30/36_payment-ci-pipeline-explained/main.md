# payment-service CI/CD Pipeline — Line by Line

> This file is the `.github/workflows/payment-service-ci.yaml` — every job, every field, every decision explained for an SRE beginner.

---

## Decision Tree — What Runs When

```
                  Code pushed to repo
                         │
             ┌───────────┴───────────┐
        PR opened                 Merged to main
        (pull_request)             (push to main)
             │                         │
     paths filter?               paths filter?
     services/payment-service/**  services/payment-service/**
     charts/payment-service/**    charts/payment-service/**
             │                         │
     ┌───────┴──────────┐              │
 No change in    Changed?          Changed?
 those paths     │                    │
     │           ▼                    ▼
 Workflow    Job 1 only:        ALL 8 jobs run:
 skipped     Unit tests          test → build-dev → smoke-dev →
             (no image           promote-staging → test-staging →
              built, no          MANUAL APPROVAL →
              deploy)            promote-prod → verify-prod
```

---

## E2E Flow Summary

```
1. git push to main (paths: services/payment-service/**)
         │
2. Job: test
   └── Gradle unit tests + JaCoCo 70% coverage gate
         │ passes
3. Job: build-and-deploy-dev
   ├── Docker build (amd64 + arm64) → push to DEV ECR (123456789010)
   ├── Trivy scan (CRITICAL + HIGH CVEs → exit 1)
   ├── sed updates gitops/dev/app/payment-service/payment-service.yaml (tag field)
   ├── git commit "[skip ci]" + git push
   └── kubectl rollout status ... --timeout=8m
         │ ArgoCD picks up the tag change → rolls out new pod
4. Job: smoke-test-dev
   ├── curl /actuator/health/liveness
   ├── curl /actuator/health/readiness
   └── POST /api/v1/payments → assert status='created'
         │ passes
5. Job: promote-to-staging
   ├── docker pull DEV ECR image (same SHA bytes)
   ├── docker push to STAGING ECR (123456789011) — SAME image, no rebuild
   ├── sed updates gitops/staging/.../payment-service.yaml
   └── kubectl rollout status ... --timeout=10m
         │ ArgoCD staging cluster deploys
6. Job: test-staging
   └── k6 load test: 50 VUs, 3 min, p99 < 800ms
         │ passes
7. Job: promote-to-production
   ├── ⏸  PAUSES — GitHub sends approval request to reviewers
   ├── Reviewer approves in GitHub UI
   ├── docker pull STAGING ECR → docker push PRODUCTION ECR (123456789012)
   ├── sed updates gitops/production/.../payment-service.yaml
   └── kubectl rollout status ... --timeout=12m
         │ ArgoCD production cluster deploys (3 replicas, rolling)
8. Job: verify-production
   ├── sleep 60 (JVM warmup)
   ├── curl /actuator/health/liveness
   ├── curl /actuator/health/readiness
   └── FAIL → auto-rollback: git revert to previous tag → ArgoCD rolls back
```

---

## Part 1 — `on:` Trigger Block

```yaml
on:
  push:
    branches: [main]
    paths: ['services/payment-service/**', 'charts/payment-service/**']
  pull_request:
    branches: [main]
    paths: ['services/payment-service/**', 'charts/payment-service/**']
```

**`push` vs `pull_request`:**
```
push:    fires when a PR is MERGED into main (the code is now live in main)
pull_request: fires when a PR is OPENED or UPDATED against main

On a pull_request: only Job 1 (test) runs.
  All other jobs have: if: github.event_name == 'push'
  → they are skipped on a PR.
  WHY: on an open PR, you want tests to verify the code is correct.
  But you do NOT want a deploy to dev for every commit pushed to a feature branch.

On a push (merge): ALL jobs run — full promotion chain starts.
```

**`paths:` filter:**
```
paths: ['services/payment-service/**', 'charts/payment-service/**']

This workflow ONLY triggers when files in those directories change.
If you change:
  services/order-service/app/src/.java → this pipeline does NOT trigger
  terraform/environments/dev/main.tf   → does NOT trigger
  services/payment-service/app/src/.java → TRIGGERS

WHY THIS MATTERS (3-service repo):
  Without paths: every commit to the repo triggers all 3 service pipelines.
  = 3 × 8 jobs = 24 concurrent jobs for a README edit.
  With paths: only the relevant service's 8 jobs run.
  Clear audit trail: "this run was triggered by payment-service change."
```

---

## Part 2 — `env:` Global Variables

```yaml
env:
  AWS_REGION:     ap-northeast-1
  IMAGE_TAG:      ${{ github.sha }}
  JAVA_VERSION:   '21'
  SERVICE:        payment-service
  ECR_DEV:        123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  ECR_STAGING:    123456789011.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  ECR_PRODUCTION: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
```

**`IMAGE_TAG: ${{ github.sha }}`:**
```
The full 40-character Git commit SHA of the exact commit that triggered this run.
Example: a1b2c3d4e5f6789012345678901234567890abcd

Why use the SHA as the image tag (not :latest, not :1.2.3)?
  IMMUTABLE: sha "a1b2c3" always refers to exactly one build, forever.
  TRACEABLE: "what code is running in production?" → read the tag → git show a1b2c3
             → see exact files, author, commit message.
  SAFE: :latest is mutable — pushing a new image overwrites it.
        ArgoCD cannot detect a change to :latest (tag didn't change, just the bytes).
        SHA tag changes every commit → ArgoCD always detects it.
```

**Three separate ECR registries (one per AWS account):**
```
123456789010 = dev AWS account   → DEV ECR
123456789011 = staging AWS account → STAGING ECR
123456789012 = production AWS account → PRODUCTION ECR

WHY SEPARATE ACCOUNTS:
  Security boundary: dev credentials cannot reach production ECR.
  Promotion audit: image must be explicitly copied between accounts.
  "Accidentally deployed dev code to production" is impossible by IAM design.
  Each account's ECR has its own access policy — cross-account pull requires explicit permission.
```

---

## Part 3 — Job 1: `test` (Unit Tests + Coverage)

```yaml
test:
  runs-on: ubuntu-latest
  steps:
    - uses: actions/checkout@v4
    - uses: actions/setup-java@v4
      with: { java-version: '21', distribution: 'temurin', cache: 'gradle' }
    - uses: actions/cache@v4
      with:
        path: services/payment-service/app/.gradle
        key: ${{ runner.os }}-gradle-payment-${{ hashFiles('services/payment-service/app/build.gradle') }}
    - name: Run tests + coverage
      working-directory: services/payment-service/app
      run: ./gradlew test jacocoTestReport jacocoTestCoverageVerification --no-daemon
    - uses: mikepenz/action-junit-report@v4
      if: always()
      with:
        report_paths: 'services/payment-service/app/build/test-results/test/*.xml'
        check_name: 'payment-service JUnit'
```

**`actions/setup-java@v4` with `cache: 'gradle'`:**
```
Downloads Java 21 (Temurin distribution) onto the CI runner.
cache: 'gradle' → caches ~/.gradle/caches (downloaded JAR dependencies from Maven Central).

Without cache: every CI run downloads ~200MB of JARs (Spring Boot, Hibernate, JUnit...) from internet.
With cache: first run downloads; subsequent runs restore from cache in ~15 seconds.
Cache key: automatically keyed by build.gradle file hash.
If build.gradle changes (new dependency added) → cache key changes → fresh download.
```

**`actions/cache@v4` (separate, per-service):**
```
key: gradle-payment-${{ hashFiles('services/payment-service/app/build.gradle') }}

This caches the Gradle wrapper and compiled classes under services/payment-service/app/.gradle.
The key includes "payment" — so order-service and notification-service have SEPARATE cache entries.
Changing order-service build.gradle does NOT invalidate payment-service's compile cache.

Two cache steps (setup-java cache: 'gradle' + explicit actions/cache):
  setup-java cache: 'gradle' → caches ~/.gradle/caches (downloaded JARs, global)
  actions/cache → caches this specific service's .gradle folder (compiled classes)
  Together: near-instant rebuilds when only application code changes.
```

**`working-directory: services/payment-service/app`:**
```
The repo contains 3 services: services/order-service/, services/payment-service/, services/notification-service/.
Each has its own build.gradle and gradlew inside its app/ folder.
Without working-directory: Gradle runs from repo root → "build.gradle not found" error.
With working-directory: Gradle runs from the correct service directory.
```

**`./gradlew test jacocoTestReport jacocoTestCoverageVerification --no-daemon`:**
```
test: runs all JUnit tests
jacocoTestReport: generates HTML + XML coverage report at build/reports/jacoco/
jacocoTestCoverageVerification: FAILS the build (exit code 1) if line coverage < 70%

--no-daemon:
  Gradle daemon = background process that stays alive to speed up repeated builds.
  CI runners are disposable containers that die after one job.
  Daemon starts, builds once, container stops → daemon provides zero benefit.
  --no-daemon: don't start the daemon → saves ~200MB RAM per job.

The 70% gate:
  If tests cover less than 70% of payment service code → Gradle exits 1.
  GitHub Actions: step failed → job failed → ALL subsequent jobs have needs: test.
  A failed test job means: no image built, no dev deploy, no staging, no production.
  The gate is enforced by the job dependency graph, not by a script check.
```

**`mikepenz/action-junit-report@v4` with `if: always()`:**
```
Reads build/test-results/test/*.xml (JUnit XML format).
Adds inline annotations to the PR diff:
  "PaymentControllerTest.createPayment_missingAmount → FAILED at line 45"
Developers see test failures directly in the PR, not buried in CI log output.

if: always():
  This step runs even if the previous step (tests) failed.
  Without: if tests fail, this step is skipped → no annotations → developer must dig into logs.
  With if: always(): annotations appear on the PR even for failed test runs.
```

---

## Part 4 — Job 2: `build-and-deploy-dev`

```yaml
build-and-deploy-dev:
  needs: test
  if: github.event_name == 'push'
  environment: dev
  permissions: { id-token: write, contents: write }
```

**`needs: test`:**
```
This job only starts AFTER the test job completes AND passes.
Test fails → this job is skipped → no image built → nothing deployed.
The dependency chain enforces: untested code cannot be deployed.
```

**`if: github.event_name == 'push'`:**
```
Skips this job on pull_request events.
On PR open/update: only Job 1 (tests) runs. No image, no deploy.
Prevents dev environment from being deployed on every feature branch commit.
On merge to main (push event): this job runs → full deploy chain starts.
```

**`environment: dev`:**
```
References a GitHub Environment named "dev" (created in repo settings).
Provides:
  - Deployment history in GitHub UI (who deployed what, when)
  - Environment-specific secrets (DEV_DB_PASSWORD, etc.)
  - Optional protection rules (approval gates — currently none for dev, fast iteration)
```

**`permissions: { id-token: write, contents: write }`:**
```
id-token: write → allows this job to request an OIDC token from GitHub.
  OIDC token is exchanged with AWS for temporary credentials (no long-lived keys stored).
  Used by: aws-actions/configure-aws-credentials to assume the ECR push role.

contents: write → allows git push back to the repository.
  Used by: the "Update dev gitops tag" step that commits the new image tag.
  Without: git push fails with "403 Permission denied".
```

**Docker build:**
```yaml
- uses: docker/build-push-action@v5
  with:
    context: services/payment-service/app/
    push: true
    platforms: linux/amd64,linux/arm64
    tags: ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }},${{ env.ECR_DEV }}:latest-dev
    cache-from: type=gha
    cache-to: type=gha,mode=max
```

```
context: services/payment-service/app/:
  Docker build context = only this service's directory.
  payment-service Dockerfile cannot accidentally COPY files from order-service/.
  Keeps images small: only payment-service source is included.

platforms: linux/amd64,linux/arm64:
  Builds a multi-platform manifest (one image tag, two architecture layers).
  linux/amd64: Intel/AMD nodes (standard x86)
  linux/arm64: AWS Graviton nodes (m6g, m7g) — better price/performance
  Karpenter provisions Graviton nodes → pods pull the arm64 layer automatically.
  One CI build covers both architectures. No separate pipelines.

Two tags:
  :${{ env.IMAGE_TAG }} (e.g., :a1b2c3d4...)  → IMMUTABLE, used by ArgoCD
  :latest-dev                                   → MUTABLE shorthand for engineers
  ArgoCD always uses the SHA tag (changes every commit → ArgoCD detects the change).
  latest-dev: useful for: docker pull .../payment-service:latest-dev when debugging locally.

cache-from: type=gha / cache-to: type=gha,mode=max:
  Docker layer cache stored in GitHub Actions Cache.
  Java Dockerfile layers (from bottom = most stable):
    1. FROM eclipse-temurin:21-jre (~180MB) — changes rarely (new JRE releases)
    2. COPY build.gradle (changes when dependencies change)
    3. RUN ./gradlew dependencies (downloads JARs — cached if build.gradle unchanged)
    4. COPY src/ (changes every commit — only ~1-2MB)
  
  With cache: layers 1-3 restore from cache → only layer 4 rebuilds.
  Without cache: full 180MB JRE download + Gradle dependency resolution every build = 5-8 min.
  With cache: ~45 seconds total.
```

**Trivy scan:**
```yaml
- uses: aquasecurity/trivy-action@master
  with:
    image-ref: ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
    severity: 'CRITICAL,HIGH'
    exit-code: '1'
```

```
Trivy scans the ALREADY PUSHED image in ECR.
Checks all OS packages (Ubuntu base) and JAR dependencies against the CVE database.

severity: 'CRITICAL,HIGH':
  CRITICAL: known exploits, RCE (Remote Code Execution), severe data exposure.
  HIGH: significant risk but no known active exploit (or harder to exploit).
  LOW/MEDIUM: informational, not a gate.
  Java projects use CRITICAL + HIGH (not just CRITICAL like Python).
  WHY: Java pulls more transitive dependencies (Spring Boot alone includes ~80 JARs).
  More dependencies = larger attack surface → stricter gate.

exit-code: '1':
  If any CRITICAL or HIGH CVE found → Trivy exits with code 1 → step fails → job fails.
  The image is already in ECR (pushed before this step) but the gitops tag is NOT updated yet.
  Vulnerable image: sits in ECR, never deployed. ArgoCD still points to the old SHA.
  Fix: update the vulnerable dependency → re-run CI → Trivy passes → gitops updated → deployed.
```

**GitOps tag update:**
```yaml
- name: Update dev gitops tag
  run: |
    sed -i "s|tag: \".*\"|tag: \"${{ env.IMAGE_TAG }}\"|" \
      gitops/dev/app/payment-service/payment-service.yaml
    git config user.email "github-actions[bot]@users.noreply.github.com"
    git config user.name  "github-actions[bot]"
    git add gitops/dev/app/payment-service/payment-service.yaml
    git diff --staged --quiet || git commit -m "chore(deploy-dev): payment-service=${{ env.IMAGE_TAG }} [skip ci]"
    git push
```

```
sed -i "s|tag: \".*\"|tag: \"$IMAGE_TAG\"|":
  In-place replace the tag field in the ArgoCD Application YAML.
  BEFORE: tag: "old-sha-abc1234"
  AFTER:  tag: "new-sha-xyz5678"
  ArgoCD watches this file. When the tag changes → ArgoCD detects drift → triggers sync.
  Kubernetes rolling update starts: new pod (new image) → readiness probe passes → old pod removed.

git config user.email/name:
  This git commit needs an author identity.
  github-actions[bot] is the conventional identity for automated commits.
  Shows up in git log as "github-actions[bot]" — clearly automated, not a human.

git diff --staged --quiet || git commit:
  If the tag DID NOT change (same SHA re-run, or no paths-matching files changed):
    git diff --staged is empty → quiet exits 0 → || short-circuits → no commit.
  If the tag changed:
    git diff has content → quiet exits 1 → || runs the commit command.
  Prevents empty "chore: no change" commits cluttering gitops history.

[skip ci] in commit message:
  This git push to main triggers the workflow again (the workflow watches main).
  WITHOUT [skip ci]: push → CI starts → builds → updates gitops → push → CI starts → ...
  INFINITE LOOP. The repo would accumulate commits and CI jobs forever.
  WITH [skip ci]: GitHub Actions sees this flag → skips the workflow for this commit.
  The loop is broken. One deploy → one gitops commit → done.
```

**Wait for rollout:**
```yaml
- name: Wait for dev rollout
  run: |
    sleep 30
    aws eks update-kubeconfig --name company-dev --alias dev
    kubectl rollout status deployment/payment-service -n payment-ns --context dev --timeout=8m
```

```
sleep 30:
  ArgoCD polls git for changes every ~3 minutes (or immediately via webhook if configured).
  The 30-second sleep gives ArgoCD time to detect the new tag and START the rollout.
  Without sleep: kubectl rollout status runs immediately → no rollout in progress yet →
    exits 0 (nothing to wait for) → next job (smoke tests) starts against OLD pod.
  With sleep: ArgoCD has started the rollout → kubectl watches actual new pod creation.

aws eks update-kubeconfig --name company-dev --alias dev:
  Downloads the kubeconfig (authentication info) for the dev EKS cluster.
  --alias dev: names this context "dev" in kubeconfig → used by --context dev below.
  CI runner has no kubeconfig by default — this step creates it using OIDC AWS credentials.

kubectl rollout status --timeout=8m:
  Watches the Deployment until: all new pods are running AND passing readinessProbe.
  If a pod fails to start: after 8 minutes, exits 1 → job fails → smoke tests don't run.
  
  WHY 8 MINUTES for Java dev:
    JVM cold start (first deploy, empty code cache): 2-4 minutes
    Spring Boot context loading + Hibernate validation: 1-3 minutes
    Possible: Docker image pull (if not cached on node): 1-2 minutes
    Total worst case: ~7 minutes → 8m gives margin.
    Python equivalent: 1-2 minutes. Java is 4× slower to start.
```

---

## Part 5 — Job 3: `smoke-test-dev`

```yaml
smoke-test-dev:
  needs: build-and-deploy-dev
  steps:
    - name: Actuator health checks
      run: |
        curl -sf https://payment.dev.company.com/actuator/health/liveness
        curl -sf https://payment.dev.company.com/actuator/health/readiness
        curl -sf -X POST -H 'Content-Type: application/json' \
          -d '{"amount":100,"currency":"JPY","userId":"smoke-test"}' \
          https://payment.dev.company.com/api/v1/payments | \
          python3 -c "import json,sys; d=json.load(sys.stdin); assert d['status']=='created'"
        echo "✅ payment-service smoke tests passed"
```

**`curl -sf`:**
```
-s: silent mode (no progress bar, no stats — clean output)
-f: fail silently (exits 1 on HTTP 4xx/5xx instead of returning the error body)
Combined: if the endpoint returns 404, 500, etc. → curl exits 1 → step fails → job fails.
```

**Three checks in order:**
```
1. /actuator/health/liveness
   Spring Actuator endpoint. Returns: {"status": "UP"} if the JVM and Spring context are alive.
   If DOWN: the JVM is deadlocked or Spring crashed during startup.
   BASIC: does the Java process exist and respond?

2. /actuator/health/readiness
   Returns {"status": "UP"} only if ALL readiness indicators pass.
   Spring Boot default indicators: DB connection (SELECT 1 on HikariCP pool).
   If DOWN: PostgreSQL is unreachable from this pod.
   DEPENDENCY: can the service reach its database?

3. POST /api/v1/payments with a smoke payload
   Submits a real (test) payment through the full application stack:
     HTTP → Controller → Service → Repository → PostgreSQL → back
   python3 assert d['status'] == 'created': verifies the BUSINESS LOGIC works, not just the process.
   If the DB schema is wrong, a bug was introduced, or a config is incorrect → this fails.
   BUSINESS LOGIC: does the actual feature work?

WHY THREE CHECKS IN THIS ORDER:
  Liveness first: no point testing readiness if the JVM is dead.
  Readiness second: no point testing business logic if the DB is unreachable.
  Business logic last: validates the full stack end-to-end.
  Each check confirms a prerequisite for the next one.
```

---

## Part 6 — Job 4: `promote-to-staging`

```yaml
promote-to-staging:
  needs: smoke-test-dev
  environment: staging
  permissions: { id-token: write, contents: write }
  steps:
    - uses: aws-actions/configure-aws-credentials@v4
      with:
        role-to-assume: arn:aws:iam::123456789010:role/github-actions-ecr-read
    - uses: aws-actions/amazon-ecr-login@v2
      with: { registries: "123456789010" }
    - uses: aws-actions/configure-aws-credentials@v4
      with:
        role-to-assume: arn:aws:iam::123456789011:role/github-actions-ecr-push
    - uses: aws-actions/amazon-ecr-login@v2
      with: { registries: "123456789011" }
    - name: Promote image dev → staging
      run: |
        docker pull ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
        docker tag  ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }} ${{ env.ECR_STAGING }}:${{ env.IMAGE_TAG }}
        docker push ${{ env.ECR_STAGING }}:${{ env.IMAGE_TAG }}
```

**Two `configure-aws-credentials` steps:**
```
Step 1: assume dev account (123456789010) ECR-read role
  → authenticate to dev ECR → docker pull the image.

Step 2: assume staging account (123456789011) ECR-push role
  → authenticate to staging ECR → docker push the image.

The second configure-aws-credentials OVERWRITES the first set of credentials.
After step 2: only staging credentials are active.
This is intentional: pull from dev (step 1), switch credentials, push to staging (step 2).

Two amazon-ecr-login@v2 steps (with { registries: "account-id" }):
  docker login must happen separately for each ECR registry domain.
  123456789010.dkr.ecr.ap-northeast-1.amazonaws.com and
  123456789011.dkr.ecr.ap-northeast-1.amazonaws.com are DIFFERENT domains.
  Each login stores a separate auth token in Docker's credential store.
  After both logins: Docker can pull from account 010 AND push to account 011.
```

**Why copy instead of rebuild:**
```
docker pull (DEV ECR) → docker tag → docker push (STAGING ECR)

The image bytes are IDENTICAL. docker tag only changes the name, not the content.
Image digest (SHA256 of all layers): abc123... in dev ECR = abc123... in staging ECR.

WHY NOT REBUILD:
  Rebuilding: Gradle compiles again, Docker builds again → NEW image.
  New image = different binary = different sha256 digest.
  The dev smoke tests ran against Image A. Rebuild produces Image B.
  Even same source: build timestamps, transitive dependency versions can differ.
  YOU TESTED IMAGE A. YOU SHOULD DEPLOY IMAGE A.

  Copying: pull same bytes → tag with new name → push.
  What you tested in dev is EXACTLY what runs in staging and production.
  The test certificate travels with the artifact.
```

**`git pull origin main` before gitops update:**
```yaml
- name: Update staging gitops tag
  run: |
    git pull origin main
    sed -i ...
    git push
```

```
Problem: two jobs (build-and-deploy-dev and promote-to-staging) both push to the same git repo.
If build-and-deploy-dev committed gitops/dev/... while promote-to-staging checked out an older commit:
  git push would fail with "non-fast-forward" (your local is behind remote).

git pull origin main:
  Fetches the latest commits from remote (including the dev gitops commit).
  Rebases local changes on top → now local is at the same point as remote.
  Subsequent git push succeeds cleanly.
```

---

## Part 7 — Job 5: `test-staging` (k6 Load Test)

```yaml
test-staging:
  needs: promote-to-staging
  steps:
    - name: Install k6
      run: |
        sudo apt-get install -y gnupg
        curl -s https://dl.k6.io/key.gpg | sudo gpg --dearmor -o /usr/share/keyrings/k6-archive-keyring.gpg
        echo "deb [signed-by=...] https://dl.k6.io/deb stable main" | sudo tee ...
        sudo apt-get update && sudo apt-get install k6 -y
    - name: Load test
      run: |
        k6 run --vus 50 --duration 3m \
          --env BASE_URL=https://payment.staging.company.com \
          services/payment-service/tests/load/load-test.js
```

**k6 installation from official repository:**
```
ubuntu-latest CI runners do NOT have k6 pre-installed.
Must install via k6's official apt repository.

GPG key step:
  curl -s https://dl.k6.io/key.gpg | sudo gpg --dearmor → downloads k6's signing key.
  --dearmor: converts from ASCII armor format to binary format apt expects.
  Stored in /usr/share/keyrings/k6-archive-keyring.gpg.

signed-by=/usr/share/keyrings/k6-archive-keyring.gpg:
  apt verifies each downloaded package was signed by k6's private key.
  Prevents supply chain attack: even if someone hijacks dl.k6.io CDN,
  they cannot serve a malicious k6 binary without k6's private signing key.
  The GPG signature is the trust anchor.
```

**`--vus 50 --duration 3m`:**
```
--vus 50: 50 virtual users — 50 concurrent HTTP connections to payment.staging.company.com.
--duration 3m: run for exactly 3 minutes, then stop.

For payment-service:
  Each VU sends: POST /api/v1/payments (submit payment) → GET /api/v1/payments/{id} (check status).
  50 simultaneous payments = reasonable concurrent payment load.

3 minutes is enough to:
  - Warm up the JVM JIT (first 30s slower → next 2m30s is steady-state performance)
  - Collect enough p99 data points to be statistically meaningful
  - Trigger HPA scaling if pods are under CPU pressure
  - Not so long that CI is delayed by a 10-minute load test

Thresholds in load-test.js (not shown but implied):
  http_req_duration{p(99)} < 800ms  ← staging threshold (NOT 300ms production SLO)
  http_req_failed < 1%

WHY 800ms (not 300ms):
  300ms = production SLO (steady state, warmed JVM, production Graviton nodes).
  Staging JVM: first 30s of JIT warmup → latency 3-5× higher → p99 easily 600-700ms.
  If threshold = 300ms: EVERY staging CI run fails during warmup on a healthy service.
  Engineers would either: always fail CI (annoying) or raise threshold to 800ms anyway.
  800ms acknowledges JIT warmup reality while still catching actual capacity regressions.
```

---

## Part 8 — Job 6: `promote-to-production` (Manual Approval Gate)

```yaml
promote-to-production:
  needs: test-staging
  environment: production   # ← THIS LINE creates the approval gate
  permissions: { id-token: write, contents: write }
```

**How the manual approval works:**
```
GitHub Environment "production" must be configured in:
  Repo Settings → Environments → production → Required reviewers → add SRE lead, EM

When this job reaches environment: production:
  1. Workflow PAUSES here. Zero code runs.
  2. GitHub sends email + (optionally) Slack notification to all required reviewers.
  3. Reviewers see in GitHub UI:
     - Which workflow run is waiting
     - Which commit SHA (IMAGE_TAG) is being deployed
     - That staging load test passed (previous job succeeded — green checkmark)
  4. Reviewer clicks "Approve and deploy" → job resumes from the pause point.
     Reviewer clicks "Reject" → workflow stops. No production deploy. Job marked as rejected.

WHY MANUAL APPROVAL (not automated):
  Automated tests validate: does the code work correctly?
  Manual approval validates: should we deploy NOW?
  Tests cannot answer:
    - Is this a safe deploy window? (Friday 5pm = bad)
    - Is there an active incident in production? (deploying during incident = dangerous)
    - Did we just get a customer complaint about this feature?
    - Does the business want this released this week?
  Human judgment is the final gate for code that processes real money.
```

**`--timeout=12m` for production rollout:**
```
Production: 3 replicas, rolling update (maxUnavailable=0, maxSurge=1).
Rolling update sequence:
  Pod 4 created → waits until ready (JVM start: 1-4 min) →
  Pod 1 removed (preStop sleep 15s + graceful drain: 15s) →
  Pod 5 created → ready → Pod 2 removed →
  Pod 6 created → ready → Pod 3 removed.

3 replicas × ~4 min per pod = ~12 minutes total.
--timeout=12m gives exactly enough margin.
If a pod gets stuck (OOM kill loop, DB connection timeout): 12 min expires → kubectl exits 1 → CI fails → engineer investigates.
Without timeout: if a pod gets stuck, the CI job waits forever (until GitHub's 6-hour job timeout).
```

---

## Part 9 — Job 7: `verify-production` + Auto-Rollback

```yaml
verify-production:
  needs: promote-to-production
  environment: production
  permissions: { id-token: write, contents: write }
  steps:
    - name: Production smoke tests
      id: smoke
      run: |
        sleep 60
        curl -sf https://payment.company.com/actuator/health/liveness
        curl -sf https://payment.company.com/actuator/health/readiness
        echo "✅ payment-service production verified"
    - name: Auto-rollback on failure
      if: failure() && steps.smoke.outcome == 'failure'
      run: |
        git pull origin main
        PREV_TAG=$(git log --oneline -- gitops/production/app/payment-service/payment-service.yaml | \
                   awk 'NR==2{print $1}' | \
                   xargs git show | grep 'tag:' | head -1 | awk -F'"' '{print $2}')
        [ -n "$PREV_TAG" ] && \
          sed -i "s|tag: \".*\"|tag: \"$PREV_TAG\"|" \
            gitops/production/app/payment-service/payment-service.yaml && \
          git add ... && \
          git commit -m "chore(rollback-prod): payment-service=$PREV_TAG [skip ci]" && \
          git push
        exit 1
```

**`sleep 60` (production JIT warmup):**
```
Production: 3 replicas. Rolling update creates 1 new pod at a time.
The LAST pod created finished its rolling update most recently → may still be in JIT warmup.
JIT warmup: first 30-60 seconds after JVM starts → slower response times.
Running smoke tests against a pod in JIT warmup: latency assertions fail on a healthy service.

sleep 60: gives all production pods at least 1 minute of running time after rollout completes.
After 60s: JIT has compiled the hot paths → responses are at steady-state latency.
Production uses 60s (vs 30s for dev/staging) because:
  production pods are on Graviton (different JIT profile)
  production handles 3× more concurrent requests → more JIT compilation needed
```

**`id: smoke` (step ID):**
```
Assigns the name "smoke" to this step.
Used by the rollback step: steps.smoke.outcome == 'failure'
Allows precise conditional: "rollback ONLY IF the smoke test step specifically failed"
(not if some other earlier step failed, which would not indicate a bad deploy)
```

**`if: failure() && steps.smoke.outcome == 'failure'`:**
```
failure(): returns true if ANY previous step in this job failed.
steps.smoke.outcome == 'failure': specifically the smoke test step failed.

Combined: "run this step IF the job is in a failure state AND it was the smoke test that failed."

WHY BOTH CONDITIONS:
  failure() alone: rollback step runs if setup-java or checkout fails → wrong (not a deploy issue).
  steps.smoke.outcome alone: doesn't protect against other failure modes.
  Together: rollback only triggers for the specific case of "production smoke tests failed".
```

**Auto-rollback logic:**
```bash
PREV_TAG=$(git log --oneline -- gitops/production/app/payment-service/payment-service.yaml | \
           awk 'NR==2{print $1}' | \
           xargs git show | grep 'tag:' | head -1 | awk -F'"' '{print $2}')
```

```
git log --oneline -- <file>:
  Shows commit history for ONE specific file (the production ArgoCD Application yaml).
  --oneline: one line per commit, format: "abc1234 chore(deploy-prod): payment-service=..."

awk 'NR==2{print $1}':
  NR==1 = current (bad) commit SHA: the one we just deployed.
  NR==2 = PREVIOUS (good) commit SHA: the last known-working deploy.
  Prints just the commit SHA of the previous commit.

xargs git show:
  git show <SHA>: prints the full content of the file at that commit.
  xargs: passes the SHA from the previous awk as the argument to git show.

grep 'tag:' | head -1 | awk -F'"' '{print $2}':
  From the file content: find the line containing "tag:"
  Extract the value between the quotes: "old-sha-abc1234" → old-sha-abc1234
  This is the IMAGE_TAG that was running BEFORE this bad deploy.

Then:
  sed replaces the current (bad) tag with the previous (good) tag in the yaml file.
  git commit + git push → ArgoCD detects the change → rolls back to the old image.
  
  exit 1 at the end:
    Explicitly fails the job even after rollback.
    CI run shows as FAILED → engineers get notified → investigate why smoke tests failed.
    Without exit 1: rollback completes → job shows as "passed" → engineers don't know there was a problem.
```

**Why Git rollback (not `kubectl rollout undo`):**
```
kubectl rollout undo: reverts the Deployment in Kubernetes directly.
  Problem: ArgoCD immediately detects "drift" (Git says tag=new, cluster runs tag=old).
  ArgoCD re-applies the Git state → deploys the bad image again.
  Net result: rollback immediately reversed by ArgoCD. Deploy war.

Git revert + push: updates Git to the old tag.
  ArgoCD detects the git change → applies it → rolls back to old image.
  Git and cluster are now in sync (both say old tag).
  Durable: the rollback survives ArgoCD syncs, pod restarts, operator restarts.
  Auditable: git log shows the rollback commit with timestamp and reason.
  Git is the SINGLE SOURCE OF TRUTH in GitOps. All changes go through Git.
```
