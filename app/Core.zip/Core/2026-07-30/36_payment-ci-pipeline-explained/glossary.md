# Glossary — payment-service CI/CD Pipeline

Every term, flag, tool, and concept mentioned in main.md. One entry per term.

---

**GitHub Actions**
A CI/CD system built into GitHub that runs automated jobs when code is pushed or PRs are opened. Why it matters: this entire pipeline (tests, builds, deploys) runs on GitHub Actions.

**Workflow (`.github/workflows/*.yaml`)**
A YAML file that defines when and how GitHub Actions jobs run. Why it matters: `payment-service-ci.yaml` is the workflow — it describes all 8 jobs and their order.

**Job**
One unit of work in a GitHub Actions workflow. Each job runs on a fresh virtual machine. Why it matters: the 8 jobs (test, build-dev, smoke-dev, promote-staging, test-staging, promote-prod, verify-prod) are connected by `needs:` — they run in sequence.

**`needs:`**
A field in a GitHub Actions job that lists which jobs must complete successfully before this job starts. Why it matters: `needs: test` means the build job only runs if tests pass — enforces the quality gate at the pipeline level.

**`on: push` / `on: pull_request`**
Trigger events for a workflow. `push` fires when code is merged to a branch. `pull_request` fires when a PR is opened/updated. Why it matters: different jobs run on each event — tests only on PR, full deploy on merge.

**`paths:` filter**
Limits workflow triggering to only when files in specified directories change. Why it matters: in a 3-service repo, each service has its own `paths:` filter so changing order-service does NOT trigger payment-service CI.

**`github.event_name`**
A GitHub Actions variable holding the event that triggered the workflow (`push` or `pull_request`). Why it matters: `if: github.event_name == 'push'` skips build/deploy jobs on PR events — only tests run on open PRs.

**GitHub Environment**
A named deployment target (dev, staging, production) in GitHub repo settings that can have secrets, deployment history, and required reviewers. Why it matters: `environment: production` creates the manual approval gate — the job pauses until a reviewer approves.

**Required reviewers (GitHub Environment)**
People designated in GitHub Environment settings who must approve before a job continues. Why it matters: prevents production deploys without human sign-off — the production job pauses until an approver clicks "Approve and deploy".

**OIDC (OpenID Connect)**
A protocol that lets GitHub Actions get short-lived AWS credentials without storing access keys as secrets. Why it matters: `id-token: write` permission + `configure-aws-credentials` action uses OIDC — no long-lived credentials in the repo.

**`permissions: { id-token: write, contents: write }`**
Job-level permissions in GitHub Actions. `id-token: write` allows OIDC token requests. `contents: write` allows pushing commits back to the repo. Why it matters: without `contents: write`, the gitops tag update git push fails with 403.

**`aws-actions/configure-aws-credentials@v4`**
A GitHub Action that assumes an AWS IAM role using OIDC and sets AWS credentials as environment variables for subsequent steps. Why it matters: used twice in promote jobs — once to read from source ECR, once to push to destination ECR.

**`aws-actions/amazon-ecr-login@v2`**
A GitHub Action that authenticates Docker to an AWS ECR registry. Why it matters: without this, `docker pull` and `docker push` to ECR return "no basic auth credentials" error.

**ECR (Elastic Container Registry)**
AWS's managed Docker image registry. Why it matters: this project has 3 separate ECR registries (one per AWS account) — images must be explicitly promoted between them, creating an audit trail.

**`github.sha`**
The 40-character Git commit SHA that triggered the workflow run (e.g., `a1b2c3d4...`). Why it matters: used as the Docker image tag — immutable, unique per commit, fully traceable to the exact source code.

**Immutable image tag**
An image tag (like a Git SHA) that always refers to the same image bytes forever. Why it matters: `:latest` is mutable — the bytes change when you push a new image. A SHA tag never changes → ArgoCD detects changes (tag changes) and prevents accidental deploys of old-but-identically-named images.

**Temurin**
A distribution of OpenJDK (open-source Java) maintained by the Eclipse Foundation. Why it matters: `distribution: 'temurin'` in `actions/setup-java` downloads this specific Java 21 build for the CI runner.

**`cache: 'gradle'` (in setup-java)**
A built-in cache option in `actions/setup-java` that caches `~/.gradle/caches` (downloaded JAR dependencies from Maven Central). Why it matters: saves 3-4 minutes per CI run — downloaded JARs are restored from cache instead of re-downloaded.

**`actions/cache@v4`**
A GitHub Action that saves and restores a directory between workflow runs using a cache key. Why it matters: used to cache the per-service `.gradle` build folder so compiled classes survive between runs.

**Cache key (`hashFiles`)**
A cache key that includes a hash of specified files. When those files change, the key changes and the old cache is invalidated. Why it matters: `hashFiles('build.gradle')` means if you add a new dependency, the cache is invalidated and dependencies are re-downloaded fresh.

**`working-directory:`**
A GitHub Actions step option that changes the working directory before running a command. Why it matters: in a multi-service repo, `working-directory: services/payment-service/app` ensures Gradle runs in the correct service folder.

**Gradle**
A build tool for Java that compiles code, runs tests, and packages JARs. Why it matters: `./gradlew test jacocoTestReport jacocoTestCoverageVerification` runs the full test + coverage pipeline.

**`./gradlew` (Gradle wrapper)**
A script checked into the repo that downloads and runs the correct Gradle version automatically. Why it matters: CI doesn't need Gradle pre-installed — the wrapper handles downloading the right version.

**`--no-daemon`**
A Gradle flag that prevents starting the background Gradle daemon. Why it matters: on CI (ephemeral containers), the daemon starts, builds once, then the container dies — no benefit, wastes ~200MB RAM.

**JaCoCo**
A Java code coverage library that measures what percentage of code is executed by tests. Why it matters: `jacocoTestCoverageVerification` fails the build if coverage is below 70%, enforcing a minimum test quality gate.

**`jacocoTestCoverageVerification`**
The Gradle task that checks if JaCoCo-measured coverage meets the configured minimum threshold. Why it matters: exits with code 1 if coverage < 70% → CI job fails → no deploy possible.

**`mikepenz/action-junit-report@v4`**
A GitHub Action that reads JUnit XML test result files and adds inline annotations to the PR. Why it matters: shows "TestName FAILED at line 45" directly on the PR diff — engineers don't need to dig through CI logs.

**`if: always()`**
A GitHub Actions condition that makes a step run regardless of whether previous steps passed or failed. Why it matters: the JUnit report step uses `if: always()` so test failure annotations still appear even when the test run failed.

**`docker/setup-buildx-action@v3`**
A GitHub Action that sets up Docker Buildx — the multi-platform build driver. Why it matters: required for `platforms: linux/amd64,linux/arm64` builds; standard `docker build` cannot build for multiple architectures.

**`docker/build-push-action@v5`**
A GitHub Action that builds a Docker image and pushes it to a registry in one step. Why it matters: handles multi-platform builds, layer caching, and pushing to ECR.

**`platforms: linux/amd64,linux/arm64`**
Builds a Docker multi-platform manifest — one image tag that includes layers for both Intel (amd64) and ARM (arm64) architectures. Why it matters: EKS Graviton nodes (m6g, m7g) run arm64; without this, pods on Graviton nodes fail to pull the image.

**Docker manifest**
A metadata file that points to multiple platform-specific image layers under a single tag. Why it matters: `docker pull` on an arm64 Graviton node automatically selects the arm64 layer from the manifest.

**`cache-from: type=gha` / `cache-to: type=gha,mode=max`**
Docker layer cache stored in GitHub Actions Cache. Why it matters: Java Docker images have a large base layer (~180MB JRE). With GHA cache, only the changed application code layer (~2MB) rebuilds per commit. Without: 5-8 min builds. With: ~45 seconds.

**Docker layer**
One immutable filesystem change unit in a Docker image. Each Dockerfile instruction (`FROM`, `COPY`, `RUN`) creates a layer. Why it matters: if a layer hasn't changed, it's reused from cache — only changed layers rebuild.

**Trivy**
An open-source vulnerability scanner for container images and filesystems. Why it matters: scans the built image against the CVE database; `exit-code: '1'` blocks the deploy if CRITICAL or HIGH vulnerabilities are found.

**CVE (Common Vulnerabilities and Exposures)**
A numbered entry in a public database describing a known security vulnerability in software. Why it matters: Trivy checks all OS packages and JAR dependencies against this database — a known exploitable CVE in a production payment service is unacceptable.

**`exit-code: '1'` (Trivy)**
Makes Trivy exit with code 1 (failure) when vulnerabilities are found, which fails the CI step. Why it matters: the image is already pushed to ECR but the gitops tag is NOT updated — vulnerable image sits in ECR, never deployed.

**`sed -i "s|old|new|"`**
An in-place stream editor command that finds and replaces text inside a file. Why it matters: `sed -i "s|tag: \".*\"|tag: \"$SHA\"|"` updates the image tag in the ArgoCD Application YAML — this is how CI tells ArgoCD which image to deploy.

**`git diff --staged --quiet || git commit`**
`git diff --staged --quiet` exits 0 if there are no staged changes, exits 1 if there are. `||` runs the right side only if the left side exits 1. Why it matters: prevents empty commits to gitops history on re-runs where the tag didn't actually change.

**`[skip ci]`**
A string in a Git commit message that tells GitHub Actions to NOT trigger workflows for that commit. Why it matters: without it, the CI gitops commit triggers another CI run → infinite loop of builds and commits.

**`kubectl rollout status`**
A kubectl command that watches a Deployment until all pods are updated and passing readiness probes, then exits 0. Exits 1 if the timeout is exceeded. Why it matters: CI waits here until the new pods are actually healthy before running smoke tests.

**`--timeout=8m` / `--timeout=12m`**
Maximum time kubectl waits for the rollout to complete. Why it matters: Java Spring Boot cold start can take 4-8 min in dev, up to 12 min for a 3-replica rolling update in production. Without a timeout, a stuck pod hangs CI indefinitely.

**`sleep 30` / `sleep 60`**
Pauses CI execution for N seconds. Why it matters: ArgoCD needs time to detect the gitops change and start the rollout; JVM JIT needs 30-60 seconds to warm up. Running kubectl or smoke tests too early gives false results.

**JIT (Just-In-Time compilation)**
The JVM automatically compiles frequently-run code into native machine code while the program runs. Why it matters: for the first 30-60 seconds after JVM startup, code runs in interpreted mode (5-20× slower). Load tests and smoke tests run AFTER this warmup to avoid false failures.

**`aws eks update-kubeconfig`**
An AWS CLI command that downloads the kubeconfig (authentication configuration) for an EKS cluster. Why it matters: CI runners have no cluster access by default — this command creates the kubeconfig needed for kubectl commands.

**`--alias dev` / `--alias staging` / `--alias prod`**
Names the kubeconfig context for the downloaded cluster. Why it matters: with multiple EKS clusters, `--context dev` ensures kubectl commands target the correct cluster.

**`/actuator/health/liveness`**
A Spring Boot Actuator HTTP endpoint that returns `{"status": "UP"}` if the JVM and Spring ApplicationContext are running. Why it matters: Kubernetes liveness probe + CI smoke tests use this to verify the process is alive.

**`/actuator/health/readiness`**
A Spring Boot Actuator HTTP endpoint that returns `{"status": "UP"}` only if all readiness checks pass (e.g., database connection is healthy). Why it matters: readiness probe + CI smoke tests use this to verify the service can serve traffic safely.

**Spring Boot Actuator**
A Spring Boot module that automatically exposes health, metrics, and info HTTP endpoints. Why it matters: provides `/actuator/health/liveness` and `/actuator/health/readiness` — the correct paths for Spring Boot probes (NOT `/health/live` which is for other frameworks).

**`curl -sf`**
`-s` = silent (no progress/stats output). `-f` = fail on HTTP errors (exits 1 on 4xx/5xx). Why it matters: without `-f`, curl exits 0 even on a 500 response — the smoke test would pass even if the service is broken.

**python3 JSON assert**
`python3 -c "import json,sys; d=json.load(sys.stdin); assert d['status']=='created'"` — parses curl output as JSON and checks a field value. Why it matters: verifies business logic (payment was created correctly), not just that the endpoint responds.

**k6**
An open-source load testing tool written in Go. Runs virtual users that execute JavaScript test scripts. Why it matters: staging CI runs a k6 load test to verify the service handles concurrent load before production promotion.

**VU (Virtual User)**
A concurrent user simulation in k6. Each VU runs the test script in a loop for the test duration. Why it matters: 50 VUs = 50 simultaneous HTTP connections — tests concurrent payment processing.

**`--duration 3m`**
k6 flag that stops the load test after 3 minutes. Why it matters: 3 minutes is enough to cover JIT warmup (first 30s) plus 2.5 minutes of steady-state performance data.

**p99 latency threshold**
The load test assertion that 99% of requests must complete in under N milliseconds. Why it matters: staging threshold is 800ms (accommodates JIT warmup); production SLO is 300ms. Separate thresholds prevent false failures in staging.

**GPG key (for k6 apt)**
A cryptographic signing key that verifies apt package authenticity. Why it matters: `--dearmor` converts the key format; `signed-by=` in the apt source means apt verifies k6 package signatures — prevents tampered packages.

**Supply chain attack**
An attack where malicious code is injected into a legitimate package or distribution channel. Why it matters: GPG signing protects against this for k6 installation; Trivy scanning protects against known CVEs in dependencies.

**`promote-to-staging` (image copy)**
Pulling an image from dev ECR and pushing it to staging ECR with the same SHA tag, no rebuild. Why it matters: staging tests the EXACT same bytes that passed dev smoke tests — not a rebuild with potentially different artifacts.

**`promote-to-production` (image copy)**
Same copy from staging ECR to production ECR. Why it matters: what passed staging load test is exactly what goes to production — no rebuild, no new binaries, same SHA256 digest.

**Rolling update**
Kubernetes replaces pods one at a time: create new pod → wait for readiness → remove old pod. Why it matters: zero-downtime deploys; at no point is the service fully unavailable.

**`maxUnavailable: 0, maxSurge: 1`**
Rolling update strategy settings. `maxUnavailable: 0` = never remove an old pod until a new one is ready. `maxSurge: 1` = create 1 extra pod above the desired count during the update. Why it matters: guarantees the service always has at least `replicaCount` pods handling traffic during a deploy.

**Auto-rollback**
CI automatically reverts a bad deploy by reading the previous Git commit's image tag and pushing a revert commit to the gitops repo. Why it matters: if production smoke tests fail, rollback starts within seconds without requiring a human to wake up and intervene.

**`git log --oneline -- <file>`**
Shows commit history for a single specific file, one line per commit. Why it matters: rollback reads the PREVIOUS commit of the production ArgoCD Application yaml to extract the last-known-good image tag.

**`awk 'NR==2{print $1}'`**
`NR` = row number. `NR==2` = second row (the previous commit). `{print $1}` = print the first field (the commit SHA). Why it matters: extracts the commit SHA of the previous (good) deploy from git log output.

**`xargs git show`**
Passes the SHA from the previous awk command as an argument to `git show`, which prints the file content at that commit. Why it matters: used to read the gitops YAML at the previous commit to extract the old image tag.

**`exit 1` (end of rollback step)**
Explicitly fails the CI job even after rollback completes successfully. Why it matters: without this, a successful rollback would mark the job as passed — engineers would not be notified that production smoke tests failed and a rollback occurred.

**`steps.smoke.outcome == 'failure'`**
References the outcome of a specific named step (`id: smoke`). Why it matters: ensures rollback only triggers when the smoke test step specifically fails — not when an unrelated step (like checkout) fails.

**`if: failure() && steps.smoke.outcome == 'failure'`**
Combined condition: `failure()` = the job is in a failed state. `steps.smoke.outcome == 'failure'` = the smoke tests specifically failed. Why it matters: prevents rollback from triggering on infrastructure failures (checkout failure, kubeconfig failure) which are not caused by bad code.

**GitOps**
The practice of storing all deployment configuration in Git and using automated tools to apply changes from Git to the cluster. Why it matters: Git is the single source of truth — rollbacks are git commits, deploys are git commits, all changes are auditable.

**ArgoCD**
A GitOps tool that watches a Git repository and synchronizes a Kubernetes cluster to match what is in Git. Why it matters: CI never calls kubectl apply directly — it updates Git files, and ArgoCD applies the changes.

**`git pull origin main` (before gitops update)**
Fetches the latest commits from the remote before making local changes. Why it matters: multiple CI jobs push to the same repo; without pulling first, the local checkout is behind the remote and `git push` fails with a non-fast-forward error.

**Non-fast-forward error**
A git error when the remote has commits that your local copy doesn't have, so a simple push is rejected. Why it matters: if two CI jobs commit gitops changes, the second one must `git pull` first or its push will be rejected.

**`[skip ci]` (in gitops commits)**
Prevents the CI workflow from re-triggering on the automated gitops commit. Why it matters: without it, every CI deploy would trigger another full pipeline run — infinite loop.

**Deployment history (GitHub Environments)**
A log of all deployments to a GitHub Environment including who triggered them, when, and which commit was deployed. Why it matters: "who deployed what to production and when?" — answered without digging through git log.

**`environment: production` (on verify-production job)**
Both the promote and verify jobs reference the production environment. Why it matters: both jobs appear in the production deployment history, and both have access to production environment secrets.

**Single source of truth**
A principle where one system (Git in GitOps) is authoritative for a piece of information. Why it matters: if Git says tag=old-sha, the cluster should always run old-sha. Rollback via git commit keeps Git and the cluster in agreement — unlike `kubectl rollout undo` which would be immediately reversed by ArgoCD.
