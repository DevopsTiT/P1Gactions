# Dynatrace Terraform Pipeline — Glossary

**GitHub Actions workflow**
An automated process defined in a YAML file under `.github/workflows/`. It runs in response to events (a push, a PR, a schedule) on ephemeral virtual machines called runners. Each run is isolated and starts fresh with no pre-existing files.

**Trigger (`on:`)**
The section of a GitHub Actions workflow that defines which events start the workflow. This pipeline uses `pull_request` (fires when a PR is opened or updated) and `push` (fires when code is merged to main). Path filters restrict which file changes activate the trigger.

**Path filter (`paths:`)**
A trigger restriction that only runs the workflow when specific files change. `paths: ['terraform/dynatrace/**']` means the workflow only runs when any file under `terraform/dynatrace/` is modified. Prevents the pipeline from running on unrelated changes.

**Job**
A unit of work inside a GitHub Actions workflow. Each job runs on its own fresh Ubuntu virtual machine. Jobs run in parallel by default unless `needs:` declares a dependency. This pipeline has two jobs: `plan` (on PR) and `apply` (on merge).

**`if: github.event_name == 'pull_request'`**
A job condition that only runs the job for specific events. The plan job uses this so it runs only on PRs. The apply job uses `if: github.event_name == 'push'` to only run after a merge. Without these conditions, both jobs would run on every trigger.

**OIDC (OpenID Connect)**
A protocol that lets GitHub Actions prove its identity to AWS without storing any access keys. GitHub generates a short-lived signed JWT (JSON Web Token) per workflow run. AWS verifies the JWT signature and issues temporary 1-hour credentials. The JWT expires; stolen credentials are useless quickly.

**JWT (JSON Web Token)**
A signed token that contains claims about who is making a request: which repository, which workflow, which branch, which event. AWS reads these claims and checks them against the IAM role's trust policy before granting access.

**`id-token: write` permission**
A GitHub Actions permission that allows a job to request a signed OIDC JWT from GitHub's token service. Without this permission, the `configure-aws-credentials` step cannot obtain a JWT and OIDC authentication fails entirely.

**`pull-requests: write` permission**
A GitHub Actions permission that allows a job to post comments on pull requests. Without this, the "Post Plan to PR" step gets a 403 Forbidden error from the GitHub API.

**IAM role (`role-to-assume`)**
An AWS identity with a defined set of permissions that can be assumed via OIDC. The plan role (`github-actions-dynatrace-plan`) has read-only access to Secrets Manager. The apply role (`github-actions-dynatrace-apply`) has the same plus write access to Dynatrace via the API token. Separate roles limit blast radius.

**Least privilege**
A security principle: grant only the exact permissions needed, nothing more. The plan IAM role can only read the DT token from Secrets Manager — it cannot create EC2 instances, modify S3 buckets, or access any other service. Even if the plan job is compromised, the damage is limited.

**`actions/checkout@v4`**
A GitHub Action that downloads the repository code onto the runner's filesystem. Without it, the runner has no code to work with. Pinning to `@v4` (a major version tag) prevents accidental breakage from minor version updates.

**`hashicorp/setup-terraform@v3`**
A GitHub Action that downloads the specified Terraform binary and adds it to the system PATH. GitHub-hosted runners don't pre-install Terraform, so this step is required before any `terraform` commands can run.

**`terraform init`**
The first Terraform command you always run. Downloads provider plugins (the Dynatrace provider in this case), connects to the remote state backend (S3), and validates the backend configuration. Without init, all other terraform commands fail.

**`terraform plan`**
A read-only preview command. Compares the desired state in `.tf` files against the current live state (from S3 state file + real Dynatrace API). Shows exactly what would change if you ran apply. Makes no changes to anything. Safe to run at any time.

**`terraform apply -auto-approve`**
Applies the changes shown by the plan — actually calls the Dynatrace API to create/update/delete resources. `-auto-approve` skips the interactive "yes/no" prompt (required in CI since there's no terminal). Safe here because a human reviewed and merged the PR first.

**Terraform state file**
A JSON file (stored in S3) that records every resource Terraform manages: the resource type, its configuration, and its real ID in the target system. On the next plan or apply, Terraform compares the `.tf` code against this state to compute the diff.

**S3 backend (Terraform)**
Remote storage for the Terraform state file. Using S3 instead of a local file means: all engineers and all CI/CD pipelines share the same state. Without a remote backend, each person's laptop would have a different view of what exists in Dynatrace.

**`-no-color` flag**
Disables ANSI terminal color codes in Terraform output. Terminal color codes (like `\033[0;32m` for green) look like garbage characters in plain text files or PR comments. `-no-color` produces clean text suitable for posting in a GitHub comment.

**`2>&1`**
A shell redirect that merges stderr (standard error, file descriptor 2) into stdout (standard output, file descriptor 1). Terraform writes some output to stderr. Without this merge, error messages would not be captured in `plan.txt` — important for debugging failures.

**`tee plan.txt`**
The `tee` command reads from stdin and writes to BOTH stdout and a file simultaneously. `terraform plan ... | tee plan.txt` means: the output appears in the Actions log AND is saved to `plan.txt` for use in the PR comment step.

**`actions/github-script@v7`**
A GitHub Action that runs JavaScript inline in the workflow with the GitHub API client pre-authenticated. Used here to post the plan output as a PR comment via `github.rest.issues.createComment()`.

**`plan.substring(0, 65000)`**
JavaScript's substring method, cutting the plan output to a maximum of 65,000 characters. GitHub PR comments have a character limit. Large plans (many services) can exceed it. Truncating prevents the API call from failing.

**`github.rest.issues.createComment()`**
The GitHub API call that creates a comment on a PR. GitHub's API treats PR comments as "issue comments" (PRs are a type of issue). The PR number comes from `context.issue.number`, which is automatically available in PR events.

**Drift**
When the live state of a system differs from what the code says it should be. Example: an engineer manually edits an alert threshold in the Dynatrace UI. The `.tf` file still has the old threshold. This is "drift" — code and reality have diverged.

**`terraform plan -refresh-only`**
A Terraform flag that updates the state file to match current reality without proposing any code changes. Useful for drift detection: if the output shows changes, someone modified Dynatrace outside of Terraform.

**`-auto-approve` flag**
Skips the interactive confirmation prompt that `terraform apply` normally shows before making changes ("Do you want to perform these actions? yes/no"). Required in CI environments where there is no terminal for human input.

**`plan` job vs `apply` job (separation)**
The plan job runs on PRs with a read-only IAM role — it can only show what would change. The apply job runs only after merge with a write IAM role. This separation means: no code path in a PR can modify production Dynatrace, even if the CI is exploited.

**`github.event_name`**
A GitHub Actions context variable that contains the name of the event that triggered the workflow. `pull_request` when a PR is opened/updated; `push` when code is merged. Used in job conditions to route which job runs for which event.

**`context.issue.number`**
In GitHub Actions, the PR number is available as the "issue number" because GitHub's API models PRs as a special type of issue. Used in `createComment()` to post the plan to the correct PR.

**Management Zone (Dynatrace)**
A grouping of Dynatrace entities (services, hosts, pods) by tag. Created per team to give each team a scoped view of their own services. Each new service in `variables.tf` adds a rule to its team's management zone.

**Custom Metric Event (Dynatrace)**
A Dynatrace alert definition that fires when a specific metric exceeds a threshold. This pipeline creates two per service: one for error rate and one for P99 latency.

**SLO (Service Level Objective)**
A Dynatrace resource that tracks a reliability target (e.g., 99.9% of requests succeed over 30 days) and calculates the remaining error budget. Created per service by this pipeline.

**HTTP Synthetic Monitor (Dynatrace)**
An automated test that Dynatrace runs from multiple global locations every 1-5 minutes. It makes real HTTP requests to the service's health endpoint and alerts if the request fails or is too slow. Created per service by this pipeline.
