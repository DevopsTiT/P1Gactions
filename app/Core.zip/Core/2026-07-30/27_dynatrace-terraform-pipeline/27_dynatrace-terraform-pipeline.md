# GitHub Actions: Dynatrace Terraform Pipeline — Complete Deep Dive

> This guide explains every line of the Dynatrace Terraform CI/CD workflow.
> It covers: why the pipeline is separate from the infra pipeline, how OIDC authentication works without stored keys, what each job does step by step, and how the "add a new service in one PR" workflow functions end to end.

---

## How to Read This Guide

```
This pipeline has two jobs and several surrounding decisions:

  Trigger design        → why path filters, why two separate triggers
  OIDC authentication   → how GitHub Actions gets AWS credentials without keys
  Plan job              → what runs on every PR (safe, read-only preview)
  Apply job             → what runs on every merge to main (applies to Dynatrace)
  The PR comment        → what the plan output posted to the PR looks like
  The "add a service"   → end-to-end walkthrough of the intended workflow
```

---

## The Master Flow: From PR to Dynatrace Config Change

```
Developer adds a new service to terraform/dynatrace/variables.tf
        │
        ▼
git push → opens Pull Request
        │
        ▼
Trigger: pull_request on branch main, path terraform/dynatrace/**
        │
        ▼
Job: plan
  → OIDC: GitHub gets 1-hour AWS temp credentials (read-only role)
  → terraform init: downloads Dynatrace provider from registry
  → terraform plan: compares .tf code vs live Dynatrace API
  → Posts plan output as a PR comment showing exactly what will change
        │
        ▼
Reviewer reads PR comment: "+1 Management Zone, +2 Metric Events, +1 SLO, +1 Synthetic"
Reviewer approves and merges PR
        │
        ▼
Trigger: push to main, path terraform/dynatrace/**
        │
        ▼
Job: apply
  → OIDC: GitHub gets 1-hour AWS temp credentials (write role)
  → terraform init: same provider download
  → terraform apply -auto-approve: calls Dynatrace API to create resources
        │
        ▼
New service is fully monitored in Dynatrace within ~2 minutes of merge
```

---

## SECTION 1: The Trigger Block — Why Two Conditions

```yaml
on:
  push:
    branches: [main]
    paths: ['terraform/dynatrace/**']
  pull_request:
    branches: [main]
    paths: ['terraform/dynatrace/**']
```

**Why `paths: ['terraform/dynatrace/**']`:**

```
Without path filter:
  Every commit to main triggers this pipeline, even if a developer
  only changed a README.md in the app/ folder.
  Result: Dynatrace terraform runs on every unrelated change → noisy,
          wastes GitHub Actions minutes, confuses reviewers.

With path filter:
  Pipeline only triggers when files under terraform/dynatrace/ change.
  A README change → this pipeline does NOT run.
  An edit to terraform/dynatrace/variables.tf → this pipeline runs.
```

**Why `pull_request` AND `push` as separate triggers:**

```
pull_request trigger:
  Fires when a PR is opened or a new commit is pushed to a PR branch.
  Used for: the PLAN job (safe read-only preview).
  Does NOT apply changes. Just shows what WOULD change.
  Safe to run from forks (limited GitHub token).

push to main trigger:
  Fires when code is merged to the main branch.
  Used for: the APPLY job (actually modifies Dynatrace).
  Only runs after a human reviewed and merged the PR.

WHY NOT combine into one job:
  If you ran apply on every PR, every developer branch would apply
  changes to production Dynatrace before review. Chaotic.
  If you only ran on push to main, PRs would have no preview of changes.
  Two separate triggers = review before apply. Safe GitOps pattern.
```

**Why separate from the infra pipeline:**

```
The comment at the top says: "Separate from infra pipeline — lower risk."

Infrastructure changes (EKS nodes, VPCs, RDS):
  → Destructive operations possible (delete a subnet → outage)
  → Changes take 10-30 minutes
  → Require a production environment gate (human approval after merge)
  → High risk: wrong plan = cluster down

Dynatrace config changes (alerts, dashboards, SLOs):
  → Non-destructive: deleting an alert never takes down a service
  → Changes take <60 seconds
  → Can auto-apply after PR merge (no additional gate needed)
  → Low risk: wrong plan = monitoring gap, not an outage

Result: Dynatrace pipeline can be simpler — no environment gate,
        auto-approve on apply, independent release cadence.
```

---

## SECTION 2: The `env` Block — Shared Variables

```yaml
env:
  TF_VERSION: "1.8.0"
  AWS_REGION: ap-northeast-1
  WORKING_DIR: terraform/dynatrace
```

**Why environment variables instead of hardcoded values:**

```
TF_VERSION: "1.8.0"
  → Both plan and apply jobs use the exact same Terraform version.
  → If you hardcoded it in each job and forgot to update one,
    plan would use 1.8.0 and apply would use 1.9.0 → behavioural mismatch.
  → Change it in one place → both jobs update.

AWS_REGION: ap-northeast-1
  → Dynatrace tokens live in Secrets Manager in this region.
  → Used in: configure-aws-credentials (which region's STS endpoint to call)
             and in Terraform itself (which region to read secrets from).
  → Single source of truth: change the region once → both steps update.

WORKING_DIR: terraform/dynatrace
  → Every step that runs terraform commands uses this path.
  → Without it: every step has `working-directory: terraform/dynatrace`
    hardcoded → change the folder structure and update 6 places.
  → With env var: change in one place.
  → Referenced as: working-directory: ${{ env.WORKING_DIR }}
```

---

## SECTION 3: The `plan` Job — Safe Preview on Every PR

### Job-level conditions

```yaml
plan:
  name: Dynatrace Plan
  if: github.event_name == 'pull_request'
  runs-on: ubuntu-latest
  permissions:
    id-token: write
    contents: read
    pull-requests: write
```

**`if: github.event_name == 'pull_request'`:**

```
The workflow file has TWO triggers (push and pull_request).
Without this condition: the plan job would also run on push to main.
With this condition: plan ONLY runs on PRs. Apply ONLY runs on push.

Think of it as: the workflow file is the container,
the jobs inside use conditions to claim their specific trigger.
```

**`permissions` block:**

```
id-token: write
  → REQUIRED for OIDC authentication.
  → Allows this job to request a signed JWT from GitHub's OIDC provider.
  → Without this: the configure-aws-credentials step fails with
    "Unable to get OIDC token" error.

contents: read
  → Allows the job to checkout the repository code.
  → Without this: actions/checkout@v4 would be denied access.

pull-requests: write
  → Allows the job to post comments to the PR.
  → Without this: the "Post Plan to PR" step fails with
    "Resource not accessible by integration" error.
  → The plan comment requires this permission to create issue comments
    (GitHub API treats PR comments as issue comments).
```

---

### Step 1: `actions/checkout@v4`

```yaml
- uses: actions/checkout@v4
```

```
Downloads the repository code onto the GitHub Actions runner (a fresh Ubuntu VM).
The runner starts empty — no code, no files.
Without checkout: the working directory is empty → terraform init fails.

Why @v4 (pinned version not @latest):
  Pinning prevents supply chain attacks where the action is updated
  with malicious code. @v4 is the current major version which is
  safe to use; @main would run whatever was last committed.
```

---

### Step 2: `hashicorp/setup-terraform@v3`

```yaml
- uses: hashicorp/setup-terraform@v3
  with:
    terraform_version: ${{ env.TF_VERSION }}
```

```
Downloads the specified Terraform binary and adds it to $PATH.
GitHub-hosted runners come with some tools pre-installed, but
Terraform is NOT one of them (too many versions to pre-install all).

terraform_version: "1.8.0"
  → Exact version match: plan and apply use identical binary.
  → If left unspecified: the action downloads "latest" which may change
    between the plan run and the apply run → potential behaviour difference.

After this step: `terraform` command is available in all subsequent steps.
```

---

### Step 3: Configure AWS credentials (OIDC)

```yaml
- name: Configure AWS credentials
  uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789012:role/github-actions-dynatrace-plan
    aws-region: ${{ env.AWS_REGION }}
```

**How OIDC works (no stored keys):**

```
OLD WAY (static credentials — dangerous):
  Store AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY as GitHub Secrets.
  Problems:
    - Keys never expire → if leaked: attacker has permanent access
    - Keys must be manually rotated → easy to forget
    - Keys exist in GitHub's secret storage → more exposure surface

NEW WAY (OIDC — this pipeline):
  1. GitHub generates a signed JWT (JSON Web Token) for this specific
     workflow run. The JWT contains:
       "repo": "company/platform"
       "workflow": "Terraform Dynatrace"
       "ref": "refs/pull/42/merge"
       "event": "pull_request"
  
  2. configure-aws-credentials@v4 sends this JWT to AWS STS:
     "I have this JWT. Please exchange it for temporary AWS credentials
      if my trust policy allows it."
  
  3. AWS STS validates the JWT signature (GitHub's public key is registered
     in the AWS account as an OIDC provider).
  
  4. AWS checks the IAM role's trust policy:
     {
       "Principal": { "Federated": "token.actions.githubusercontent.com" },
       "Condition": {
         "StringLike": {
           "token.actions.githubusercontent.com:sub": "repo:company/platform:*"
         }
       }
     }
     → Does the JWT come from the right repo? Yes → grant access.
  
  5. AWS issues temporary credentials: access key + secret + session token.
     These credentials expire in 1 hour. Even if leaked: useless quickly.
  
  6. The action sets AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY,
     AWS_SESSION_TOKEN as environment variables for the remaining steps.

The plan role (github-actions-dynatrace-plan):
  → Has ONLY: secretsmanager:GetSecretValue on the DT token secret
  → Cannot modify any AWS resources
  → Cannot access EC2, EKS, S3, or any other service
  → Perfect least-privilege: plan reads the DT API token, nothing else
```

---

### Step 4: Terraform Init

```yaml
- name: Terraform Init
  working-directory: ${{ env.WORKING_DIR }}
  run: terraform init -no-color
```

```
terraform init does THREE things:

1. Downloads the Dynatrace Terraform provider plugin
   (~/.terraform/providers/registry.terraform.io/dynatrace-oss/dynatrace/...)
   The provider is a compiled Go binary that knows how to call the Dynatrace API.
   Without init: "terraform plan" fails with "provider not installed" error.

2. Connects to the S3 backend (Terraform remote state)
   The backend.tf in terraform/dynatrace/ specifies:
     bucket = "company-tfstate"
     key    = "dynatrace/prod/terraform.tfstate"
   Init downloads the state file from S3 so plan can compare .tf vs current.
   Without state: plan would try to create EVERYTHING (ignoring what already exists).

3. Validates the backend configuration
   Confirms the S3 bucket exists and is accessible with the current AWS credentials.

-no-color:
  Terminal color codes (ANSI escape sequences like \033[0;32m) look garbled
  when captured to a text file or displayed in a PR comment.
  -no-color produces clean, readable text for the PR comment.
```

---

### Step 5: Terraform Plan

```yaml
- name: Terraform Plan
  id: plan
  working-directory: ${{ env.WORKING_DIR }}
  run: terraform plan -no-color 2>&1 | tee plan.txt
```

```
terraform plan:
  1. Reads all .tf files in terraform/dynatrace/
  2. Downloads the current state from S3
  3. Calls the Dynatrace API (using credentials from the DT provider,
     which reads the API token from AWS Secrets Manager via the IRSA role)
  4. Compares: desired state (.tf files) vs current state (live Dynatrace)
  5. Outputs: what would change if you ran terraform apply

Output symbols:
  + resource    → will be CREATED (new)
  ~ resource    → will be UPDATED in-place (exists, some fields changing)
  - resource    → will be DESTROYED (dangerous — review carefully)
  -/+ resource  → will be DESTROYED then RECREATED (more disruptive than ~)

2>&1 | tee plan.txt:
  2>&1     → redirect stderr (error output) to stdout (merge streams)
             Without this: error messages go to stderr and are NOT captured in plan.txt
  | tee    → pipe to the tee command
  plan.txt → tee writes to BOTH the terminal (visible in Actions log) AND plan.txt
             Without tee: the output would go to terminal but not to the file

id: plan:
  → Names this step "plan" so other steps can reference its outcome
  → Used to check: steps.plan.outcome == 'success' or 'failure'
  → Not strictly needed here but good practice for referencing step results
```

---

### Step 6: Count Resources

```yaml
- name: Count resources to be created
  run: |
    ADDS=$(grep "^  + " terraform/dynatrace/plan.txt | wc -l)
    CHANGES=$(grep "^  ~ " terraform/dynatrace/plan.txt | wc -l)
    DESTROYS=$(grep "^  - " terraform/dynatrace/plan.txt | wc -l)
    echo "Plan summary: +${ADDS} changes ~${CHANGES} destroys -${DESTROYS}"
```

```
This step parses plan.txt and counts operations by type.

grep "^  + " plan.txt:
  → Finds lines starting with "  + " (two spaces then plus)
  → These are resource creation lines in the plan output
  → wc -l counts the number of matching lines = number of resources to create

grep "^  ~ " plan.txt:
  → Finds lines starting with "  ~ " (two spaces then tilde)
  → These are in-place update lines

grep "^  - " plan.txt:
  → Finds lines starting with "  - " (two spaces then minus)
  → These are DESTROY lines — reviewers should pay attention to these

echo "Plan summary: +5 changes ~2 destroys -0":
  → Prints to the Actions log (visible in the workflow run output)
  → Gives reviewers a quick summary without reading the full plan

Why this is useful:
  A reviewer can glance at the Actions log and see "destroys -0"
  before even reading the PR comment. Zero destroys = safe to approve quickly.
  Destroys > 0 = read the plan carefully before approving.
```

---

### Step 7: Post Plan to PR

```yaml
- name: Post Plan to PR
  uses: actions/github-script@v7
  with:
    script: |
      const fs = require('fs');
      const plan = fs.readFileSync('${{ env.WORKING_DIR }}/plan.txt', 'utf8');
      const body = [
        '## Dynatrace Configuration Plan',
        '',
        '**What this creates per new service:**',
        '- 1 Management Zone rule',
        '- 2 Custom Metric Events (error rate + p99 latency)',
        '- 1 SLO with burn rate alerts',
        '- 1 HTTP Synthetic Monitor',
        '',
        '```',
        plan.substring(0, 65000),
        '```',
      ].join('\n');
      github.rest.issues.createComment({
        issue_number: context.issue.number,
        owner: context.repo.owner,
        repo: context.repo.repo,
        body
      });
```

**What this does:**

```
actions/github-script@v7:
  → Runs JavaScript inline with the GitHub API client pre-configured.
  → The `github` object is already authenticated with the GITHUB_TOKEN
    (which has pull-requests:write permission from the job's permissions block).

fs.readFileSync('terraform/dynatrace/plan.txt', 'utf8'):
  → Reads the plan output file written by `tee` in the previous step.

plan.substring(0, 65000):
  → GitHub PR comments have a maximum character limit of ~65,536.
  → Large plans (many services) can exceed this.
  → Truncating prevents the comment from failing.
  → If truncated: the comment still shows the summary header with key info.

github.rest.issues.createComment({...}):
  → Creates a comment on the pull request.
  → GitHub API treats PR comments as issue comments (same endpoint).
  → context.issue.number: the PR number (automatically available in PR events).
  → context.repo.owner / context.repo.repo: org and repo name.

The comment body includes:
  1. A header explaining what each new service gets
     → Reviewers who haven't seen this before understand the scope
  2. The full plan output in a code block
     → The exact resources that will change are visible
  3. Limited to 65,000 characters to stay within GitHub's limit

WHY post the plan to the PR (not just to the Actions log):
  PR review is the decision point. The reviewer is reading the PR diff.
  If the plan is only in the Actions log, the reviewer must:
    1. Notice the CI check passed
    2. Click into the workflow run
    3. Find the plan step
    4. Read the output
  
  With the PR comment: the plan is INLINE in the review interface.
  Reviewer sees what will change without leaving the PR page.
  Lower friction → better reviews → fewer misconfigurations reaching prod.
```

---

## SECTION 4: The `apply` Job — Applies on Merge to Main

```yaml
apply:
  name: Dynatrace Apply
  if: github.event_name == 'push'
  runs-on: ubuntu-latest
  permissions:
    id-token: write
    contents: read
```

**Key differences from the plan job:**

```
1. Trigger condition: if: github.event_name == 'push'
   → Only runs when code is pushed to main (i.e., a PR was merged)
   → Plan job uses: if: github.event_name == 'pull_request'

2. Different IAM role: github-actions-dynatrace-apply
   vs plan's: github-actions-dynatrace-plan
   → Apply role has: secretsmanager:GetSecretValue (to get DT token)
                     PLUS: the Dynatrace provider can WRITE to Dynatrace API
   → Why separate roles: plan role cannot apply changes even if compromised.
     A PR from a fork, an injection attack, or a bug in the plan job
     cannot modify production Dynatrace config.

3. No pull-requests:write permission
   → Apply job doesn't post PR comments (no active PR at merge time)
   → Minimum permissions for the job

4. No -out flag (uses plan from state directly)
   → Plan is re-run internally as part of apply
   → This re-run ensures no drift between the plan (minutes ago)
     and the apply (now)

5. -auto-approve flag
   → Skips the interactive "yes/no" prompt
   → Required in CI (no terminal input possible)
   → Safe here because:
     a) Human already reviewed and approved the plan in the PR
     b) Human merged the PR (second human decision)
     c) Apply role has minimal permissions (worst case: wrong DT config, not infra outage)
```

---

### The Apply Step

```yaml
- name: Terraform Apply
  working-directory: ${{ env.WORKING_DIR }}
  run: terraform apply -auto-approve -no-color
```

```
terraform apply:
  1. Re-runs terraform plan internally (refreshes against live Dynatrace)
  2. If plan matches expectations: applies each change via Dynatrace API
  3. Writes updated state to S3 (records what was created + their IDs)

What Dynatrace API calls get made (for a new service):
  POST /api/v2/settings/objects (management zone rule)
  POST /api/v2/settings/objects (metric event: error rate)
  POST /api/v2/settings/objects (metric event: p99 latency)
  POST /api/v2/slo/v2           (SLO definition)
  POST /api/v1/synthetic/monitors (HTTP monitor)

Each call returns an object ID (e.g., "vu9U3hXa3q0AAAABABABC1JQ==")
Terraform stores these IDs in the state file so future plans can:
  - Find and update existing resources (not create duplicates)
  - Delete resources if removed from .tf files
  - Show "no changes" when the live config matches the code

-no-color:
  Same as in the plan step — clean output in the Actions log.

After apply succeeds:
  The new service is monitored in Dynatrace within seconds.
  The management zone, alerts, SLO, and synthetic monitor are all live.
  The state file in S3 is updated.
  The next terraform plan will show "No changes."
```

---

## SECTION 5: The Complete "Add a New Service" Workflow

```
1. Developer edits terraform/dynatrace/variables.tf:
   services = {
     …existing services…
     "payment-service" = {         ← ADD THIS
       team                 = "payments"
       slo_target           = 99.9
       error_rate_threshold = 1.0
       latency_p99_ms       = 500
       health_check_url     = "https://payment.company.com/health"
     }
   }

2. git add terraform/dynatrace/variables.tf
   git commit -m "feat(monitoring): add payment-service to Dynatrace"
   git push origin feat/add-payment-monitoring

3. Open Pull Request to main

4. Trigger: pull_request event on path terraform/dynatrace/**

5. Plan job runs:
   → Posts PR comment with plan output:
   
   ## Dynatrace Configuration Plan
   
   **What this creates per new service:**
   - 1 Management Zone rule
   - 2 Custom Metric Events (error rate + p99 latency)
   - 1 SLO with burn rate alerts
   - 1 HTTP Synthetic Monitor
   
   ```
   Terraform will perform the following actions:
   
     # dynatrace_management_zone_v2.team["payment"] will be created
     + resource "dynatrace_management_zone_v2" "team" {
         + name = "Payments Team — Production"
       }
   
     # dynatrace_metric_events.error_rate["payment-service"] will be created
     + resource "dynatrace_metric_events" "error_rate" {
         + summary   = "payment-service — High Error Rate"
         + threshold = 0.01
       }
   
     # dynatrace_slo_v2.availability["payment-service"] will be created
     + resource "dynatrace_slo_v2" "availability" {
         + name   = "payment-service — Availability"
         + target = 99.9
       }
   
     # dynatrace_synthetic_monitor.health_check["payment-service"] will be created
     + resource "dynatrace_synthetic_monitor" "health_check" {
         + url = "https://payment.company.com/health"
       }
   
   Plan: 4 to add, 0 to change, 0 to destroy.
   ```

6. Reviewer reads the PR comment:
   → "4 to add, 0 to destroy" → safe change
   → Resources match what's expected for a new service
   → Approves and merges

7. Trigger: push to main event

8. Apply job runs:
   → terraform apply creates all 4 resources in Dynatrace
   → State file in S3 updated with new resource IDs
   → Job completes in ~30 seconds

9. payment-service is now fully monitored:
   → Management zone shows payments team resources
   → Alerts will fire if error rate > 1%
   → SLO tracks 99.9% availability
   → Synthetic monitor checks /health every minute from 3 locations
```

---

## Missing Pieces (Production Hardening)

```
What this pipeline LACKS that production should have:

1. No plan output artifact saved:
   → If the apply job's re-plan differs from the PR plan,
     there's no easy way to see the difference.
   → Fix: save plan as artifact: actions/upload-artifact@v4 with plan.txt

2. No Slack/Teams notification on apply:
   → Engineers don't know when the apply completes or fails.
   → Fix: add a step after apply that curls the Slack webhook.

3. No failure alerting:
   → If apply fails, only the person watching the pipeline knows.
   → Fix: add: if: failure() step with Slack notification.

4. No drift detection:
   → If someone changes Dynatrace config in the UI, this pipeline won't catch it.
   → Fix: add a scheduled workflow (daily) that runs terraform plan -refresh-only
     and alerts if output ≠ "No changes."

5. No apply environment gate:
   → Because Dynatrace config is low-risk, this is acceptable.
   → For higher-risk changes: add environment: production to the apply job
     (requires human to click Approve in GitHub before apply runs).
```

---

## Commands — Verify and Debug the Pipeline

```bash
# Run plan locally before opening a PR (same as CI)
cd terraform/dynatrace
terraform init
terraform plan -no-color 2>&1 | tee /tmp/dt-plan.txt
grep "^  [+-~]" /tmp/dt-plan.txt  # just the resource lines

# Count resources (same as CI step)
ADDS=$(grep "^  + " /tmp/dt-plan.txt | wc -l)
echo "+${ADDS} resources to create"

# Check if the pipeline ran
gh run list --workflow="Terraform Dynatrace" --limit 5

# See the plan output from the last run
gh run view $(gh run list --workflow="Terraform Dynatrace" --limit 1 --json databaseId --jq '.[0].databaseId')

# Re-run a failed apply
gh run rerun $(gh run list --workflow="Terraform Dynatrace" --limit 1 --json databaseId --jq '.[0].databaseId')

# Verify Dynatrace resources were created after apply
terraform show | grep -E "dynatrace_metric_events|dynatrace_slo_v2|dynatrace_synthetic_monitor"

# Check state file is up to date
terraform state list
```
