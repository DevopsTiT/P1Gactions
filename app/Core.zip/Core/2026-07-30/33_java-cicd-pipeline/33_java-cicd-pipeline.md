# Java App CI/CD Pipeline — Dev → Staging → Production: Complete Deep Dive

> This guide explains every line of the Java CI/CD workflow — why each step exists, what it does, and how Java-specific behaviour (JVM startup, Gradle caching, JaCoCo, Spring Actuator) makes this different from a Python pipeline.

---

## How to Read This Guide

```
This pipeline has 7 jobs that run in sequence:

  Job 1: test                  → unit tests + coverage check (JUnit + JaCoCo)
  Job 2: build-and-deploy-dev  → build Docker image → push to Dev ECR → deploy to dev cluster
  Job 3: smoke-test-dev        → hit Spring Actuator endpoints → verify dev is healthy
  Job 4: promote-to-staging    → copy image dev → staging ECR → deploy to staging
  Job 5: test-staging          → staging health checks + k6 load test
  Job 6: promote-to-production → MANUAL APPROVAL → copy image staging → prod ECR → deploy
  Job 7: verify-production     → smoke test prod → auto-rollback if failed
```

---

## The Master Flow: From git push to Production

```
Developer pushes to main
        │
        ▼
Trigger: push to main, paths: app/** or charts/**
        │
        ▼
Job 1: UNIT TESTS
  → JDK 21 (Temurin) set up
  → Gradle cache restored (saves ~2 min on every run)
  → ./gradlew test jacocoTestReport jacocoTestCoverageVerification
  → JUnit XML reports posted as GitHub annotations
  → Coverage must be ≥70% (JaCoCo) — fails if lower
        │
        ▼ (test passed)
Job 2: BUILD → DEV
  → AWS OIDC auth to dev account (123456789010)
  → Docker buildx: builds linux/amd64 + linux/arm64
  → Pushes to Dev ECR
  → Trivy scans for CRITICAL/HIGH CVEs
  → Updates gitops/dev/app/... YAML with new tag
  → Waits 8 minutes for JVM startup on dev cluster
        │
        ▼ (deploy to dev succeeded)
Job 3: SMOKE TEST DEV
  → Actuator /liveness → checks JVM is alive
  → Actuator /readiness → checks DB is connected
  → POST /api/v1/payments → creates a payment
  → Invalid request → verifies 400 validation
        │
        ▼ (smoke tests pass)
Job 4: PROMOTE TO STAGING (automatic)
  → Pull image from Dev ECR → push to Staging ECR
  → Updates gitops/staging/... YAML
  → Waits 10 minutes for JVM startup on staging
        │
        ▼ (staging deployment succeeded)
Job 5: STAGING TESTS
  → Actuator health checks
  → k6 load test: 50 virtual users × 3 minutes
  → Thresholds account for JVM JIT warmup (~30s)
        │
        ▼ (load test passed)
Job 6: PROMOTE TO PRODUCTION ← PAUSES FOR HUMAN APPROVAL
  → environment: production gate
  → Reviewer approves in GitHub UI
  → Pull image from Staging → push to Production ECR
  → Updates gitops/production/... YAML
  → Waits 12 minutes for JVM startup
        │
        ▼ (production deployment succeeded)
Job 7: VERIFY PRODUCTION
  → Waits 60s for JVM JIT warmup
  → Actuator health checks
  → API smoke test
  → If any test fails: reads previous git commit → auto-rollback
```

---

## SECTION 1: Triggers and Environment Variables

```yaml
on:
  push:
    branches: [main]
    paths: ['app/**', 'charts/**']
  pull_request:
    branches: [main]
    paths: ['app/**', 'charts/**']
```

**Why two triggers:**
- `pull_request` → runs Job 1 (tests only) on every PR. Safe: no Docker builds, no deploys.
- `push` to main → runs the full pipeline after a PR is merged.
- PR reviewers see test results BEFORE they approve the merge.

**Why path filters:**
- Without `paths`: every README edit triggers a full 30-minute Java build.
- With `paths`: only triggers when `app/` or `charts/` actually change.

```yaml
env:
  JAVA_VERSION:   '21'
  ECR_DEV:        123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  ECR_STAGING:    123456789011.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  ECR_PRODUCTION: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  IMAGE_TAG:      ${{ github.sha }}
```

**Three separate ECR registries (three AWS accounts):**
```
Dev account     (123456789010) → ECR_DEV
Staging account (123456789011) → ECR_STAGING
Production account (123456789012) → ECR_PRODUCTION
```
- Each environment is an isolated AWS account. An IAM mistake in dev cannot affect prod.
- `IMAGE_TAG = github.sha`: immutable commit SHA. Every image is uniquely traceable to exactly one commit.

---

## SECTION 2: Job 1 — Unit Tests + Coverage (Java/Gradle Specific)

### `actions/setup-java@v4` — Why Temurin

```yaml
- uses: actions/setup-java@v4
  with:
    java-version: '21'
    distribution: 'temurin'   # Adoptium OpenJDK
    cache: 'gradle'
```

**`distribution: 'temurin'`:**
- Temurin = Eclipse Adoptium's OpenJDK build. Free, long-term support, same as what the Dockerfile uses.
- Critical: CI must use THE SAME JDK distribution as the Docker image.
- If CI uses Corretto (Amazon JDK) but Docker uses Temurin: byte code differences, potential subtle bugs that pass CI but fail in production.

**`cache: 'gradle'`:**
- Caches `~/.gradle/caches` and `~/.gradle/wrapper` between runs.
- Without cache: every run re-downloads ALL Gradle dependencies (~200MB for Spring Boot).
- With cache: second run hits the cache → ~2 minutes saved per run.
- Cache key is based on `build.gradle` hash. If you add a dependency: cache miss → fresh download.

### Gradle Build Cache (second cache layer)

```yaml
- name: Cache Gradle build outputs
  uses: actions/cache@v4
  with:
    path: |
      app/.gradle
      app/build
    key: ${{ runner.os }}-gradle-${{ hashFiles('app/build.gradle', 'app/settings.gradle') }}-${{ hashFiles('app/src/**/*.java') }}
    restore-keys: |
      ${{ runner.os }}-gradle-${{ hashFiles('app/build.gradle') }}-
      ${{ runner.os }}-gradle-
```

**Two levels of Gradle caching:**
- Level 1 (`cache: 'gradle'` in setup-java): caches downloaded JARs from Maven Central.
- Level 2 (this step): caches COMPILED CLASS FILES and test results.

**The key formula: `OS + build.gradle hash + all .java files hash`:**
```
If ONLY a non-Java file changes (README): .java hash unchanged → FULL CACHE HIT
  → Gradle detects "nothing changed" → tests are SKIPPED (from cache)
  → Build completes in 5 seconds instead of 3 minutes

If ANY .java file changes: .java hash changes → cache miss
  → Gradle recompiles changed files (incremental) → tests re-run

If build.gradle changes: both hashes change → full cache miss
  → Dependencies re-downloaded + full recompile
```

**`restore-keys` fallback:**
- If exact key misses: try the partial key `OS + build.gradle hash`.
- This reuses the downloaded dependencies cache even when source files changed.
- Saves ~2 minutes of Maven Central downloads even on a source change.

### The Test + Coverage Command

```yaml
- name: Run tests and coverage check
  working-directory: app
  run: |
    ./gradlew test jacocoTestReport jacocoTestCoverageVerification \
      --no-daemon \
      --continue
```

**Three Gradle tasks in one command:**

```
./gradlew test
  → Compiles production code + test code
  → Runs all @Test methods (JUnit 5)
  → Generates test results in build/test-results/test/*.xml (JUnit XML format)
  → Fails if any test fails (unless --continue)

jacocoTestReport
  → Reads class files + test execution data from JaCoCo agent
  → Generates HTML report: build/reports/jacoco/test/html/index.html
  → Generates XML report: build/reports/jacoco/test/jacocoTestReport.xml

jacocoTestCoverageVerification
  → Reads the coverage data
  → Checks: is line coverage ≥ 70%? branch coverage ≥ 70%?
  → Configured in build.gradle:
    jacocoTestCoverageVerification {
        violationRules {
            rule { limit { counter = 'LINE'; minimum = 0.70 } }
        }
    }
  → FAILS THE BUILD if coverage < 70%
  → This gate CANNOT be bypassed without editing build.gradle
```

**`--no-daemon`:**
- Normally Gradle starts a background daemon process for faster repeated builds.
- In CI: each job starts fresh → the daemon doesn't help → just wastes ~100MB RAM.
- `--no-daemon` skips the daemon → less memory → faster on GitHub Actions.

**`--continue`:**
- Without: first test failure stops the build immediately.
- With: Gradle runs ALL tests even if some fail → you see ALL failures at once.
- Developers can fix all issues in one PR cycle instead of one-at-a-time.

### Publishing Test Results

```yaml
- uses: mikepenz/action-junit-report@v4
  if: always()
  with:
    report_paths: 'app/build/test-results/test/*.xml'
    check_name: 'JUnit Test Results'
```

**Why `if: always()`:**
- Without this: if tests fail, the job fails, and remaining steps are skipped.
- With `if: always()`: the report step runs REGARDLESS of whether tests passed or failed.
- This means: failed tests → report is published → developer sees WHICH tests failed as GitHub annotations inline in the code view.

**What the report looks like:**
- GitHub shows annotations on the specific file and line of each failing test.
- Instead of reading XML files, developers see: `PaymentServiceTest.java line 42: Expected 'CREATED' but was 'FAILED'`.

---

## SECTION 3: Job 2 — Build Docker Image + Deploy to Dev

### Why JDK is needed in the build job

```yaml
- uses: actions/setup-java@v4
  with:
    java-version: '21'
    distribution: 'temurin'
    cache: 'gradle'
```

**This job does a Docker build, not a Gradle build. Why JDK?**

The `./gradlew` wrapper script (which runs inside Docker) needs to:
1. Validate the Gradle wrapper (verify checksum) — requires `java` on PATH.
2. The `docker build` itself downloads Maven dependencies INSIDE the container.
3. Gradle build cache is reused from Job 1 via the Docker layer cache.

Without JDK: `./gradlew: not found` error during build validation.

### OIDC Authentication (no stored credentials)

```yaml
- name: Configure AWS credentials (dev)
  uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789010:role/github-actions-ecr-push
    aws-region: ap-northeast-1
    role-session-name: ci-java-dev-${{ github.run_id }}
```

**How OIDC works here:**
1. GitHub generates a signed JWT for this run: `{"repo": "company/payment", "run_id": "12345", "event": "push"}`
2. AWS STS receives the JWT → validates signature → checks trust policy → issues 1-hour temp credentials.
3. These credentials have permission ONLY to push to ECR in account 123456789010.
4. After 1 hour: expired, useless even if leaked.

**`role-session-name: ci-java-dev-${{ github.run_id }}`:**
- CloudTrail logs show: "ECR push by ci-java-dev-9876543" instead of just "github-actions-ecr-push".
- Makes it easy to trace WHICH pipeline run pushed a specific image.

### Docker Build (Multi-Architecture)

```yaml
- uses: docker/build-push-action@v5
  with:
    context: app/
    push: true
    platforms: linux/amd64,linux/arm64
    tags: |
      ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
      ${{ env.ECR_DEV }}:latest-dev
    cache-from: type=gha
    cache-to: type=gha,mode=max
    build-args: |
      BUILD_DATE=${{ github.event.head_commit.timestamp }}
      VCS_REF=${{ github.sha }}
```

**`platforms: linux/amd64,linux/arm64`:**
- Builds ONE image manifest that supports BOTH x86_64 (standard EC2) AND ARM64 (Graviton).
- Kubernetes pulls the right variant automatically based on node architecture.
- ARM instances (Graviton) are 20% cheaper. Multi-arch image = can run on cheaper nodes without code changes.
- Java note: ARM64 Java builds take ~2× longer than amd64 (cross-compilation via QEMU emulation).

**Docker layer cache for Java:**
```
Dockerfile for Java app typically layers:
  Layer 1: FROM eclipse-temurin:21-jre-alpine   (JRE — changes rarely)
  Layer 2: COPY build.gradle settings.gradle .   (dependencies spec)
  Layer 3: RUN ./gradlew dependencies            (downloads JARs — cached if build.gradle unchanged)
  Layer 4: COPY src/ .                           (application code — changes every commit)
  Layer 5: RUN ./gradlew bootJar                 (compile — changes every commit)

cache-from: type=gha → restores cached layers 1-3
cache-to: type=gha,mode=max → saves all layers
Result: layers 1-3 hit cache (saves ~3 min), only layers 4-5 rebuild
```

**`BUILD_DATE` and `VCS_REF` build args:**
- Baked into the image as metadata (OCI labels or env vars in the JARfile manifest).
- `VCS_REF = github.sha`: running `docker inspect image | grep VCS_REF` tells you the exact commit.
- Useful for incident debugging: "which commit is running in prod right now?"

### Trivy Security Scan

```yaml
- uses: aquasecurity/trivy-action@master
  with:
    image-ref: ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
    severity: 'CRITICAL,HIGH'
    exit-code: '1'
```

**Java-specific CVE scanning:**
Trivy checks THREE layers for Java images:

```
1. OS packages (Alpine APK):
   apk list → finds packages with known CVEs
   e.g., libssl, zlib, musl

2. JDK/JRE itself:
   eclipse-temurin:21 → checks if this JRE version has known CVEs
   JDK CVEs are rare but impactful (JVM escape, crypto weakness)

3. Maven/Gradle dependencies (JAR files):
   Scans MANIFEST.MF and pom.xml inside JAR files
   Spring Boot embeds ALL dependencies as JARs inside the fat JAR
   Trivy reads each embedded JAR → checks CVE databases
   e.g., log4j vulnerability was found this way (log4shell)
   If any embedded library has a CRITICAL CVE: build fails
```

**`exit-code: '1'`:** Pipeline FAILS if any CRITICAL or HIGH CVE is found. Developer must update the vulnerable dependency before the image can be pushed.

### GitOps Deploy (update the YAML)

```yaml
- name: Deploy to dev (update gitops)
  run: |
    sed -i "s|tag: \".*\"|tag: \"${{ env.IMAGE_TAG }}\"|" \
      gitops/dev/app/payment-service/payment-service.yaml
    git config user.email "github-actions[bot]@users.noreply.github.com"
    git config user.name  "github-actions[bot]"
    git add gitops/dev/app/payment-service/payment-service.yaml
    git diff --staged --quiet || \
      git commit -m "chore(deploy-dev): update payment-service to ${{ env.IMAGE_TAG }} [skip ci]"
    git push
```

**What this does:**
- `sed -i`: inline-replaces the `tag: "old-sha"` with `tag: "new-sha"` in the GitOps YAML.
- ArgoCD watches this repo. When the YAML changes: ArgoCD detects the diff → triggers a `kubectl set image` equivalent.
- `git diff --staged --quiet ||`: only commits if the file actually changed. Prevents empty commits if the SHA happens to be the same.

**`[skip ci]` in commit message:**
- Prevents THIS commit (a gitops tag update) from triggering ANOTHER pipeline run.
- Without `[skip ci]`: updating the tag → new push event → another full pipeline → infinite loop.

### Java-Specific Deployment Wait

```yaml
- name: Wait for dev deployment (Java — allow 8 min)
  run: |
    sleep 30  # ArgoCD detection delay
    kubectl rollout status deployment/payment-service \
      -n payment-ns --context dev --timeout=8m
```

**Why 8 minutes for Java vs ~2 minutes for Python:**
```
Python Flask/FastAPI startup: ~2-5 seconds
  → Web server starts
  → App module imports
  → Ready

Java Spring Boot startup: 30-120 seconds
  → JVM starts (~2s)
  → Spring ApplicationContext loads (~5-10s)
  → All @Component, @Service, @Repository beans created (~10-30s)
  → Database connection pool established (~5-10s)
  → Embedded Tomcat/Netty server starts (~2s)
  → Application ready

startupProbe failureThreshold=60 (mentioned in header):
  → Probe checks /actuator/health/liveness every 10 seconds
  → 60 failures × 10s = 600s = 10 minute maximum startup window
  → After 10 min: Kubernetes kills and restarts the pod (crash)
  → The 8m kubectl timeout should be less than this (fail fast in CI before k8s kills it)
```

---

## SECTION 4: Job 3 — Smoke Tests Dev (Spring Actuator)

### Why Spring Actuator instead of plain /health

```yaml
- name: Health check — liveness
  run: |
    RESPONSE=$(curl -sf https://payment.dev.company.com/actuator/health/liveness)
    echo "$RESPONSE" | python3 -c "import json,sys; d=json.load(sys.stdin); assert d['status']=='UP', f'Liveness not UP: {d}'"
```

**Two separate Actuator endpoints:**

```
/actuator/health/liveness:
  → Is the JVM running? Is the application process alive?
  → Returns UP if the JVM is running and not in an irrecoverable error state
  → Does NOT check external dependencies (DB, cache)
  → Maps to Kubernetes livenessProbe
  → If this fails: Kubernetes restarts the pod

/actuator/health/readiness:
  → Is the application ready to receive traffic?
  → Checks: DB connected, cache available, dependencies healthy
  → Returns UP only when ALL dependencies are healthy
  → Maps to Kubernetes readinessProbe
  → If this fails: Kubernetes removes the pod from the Service endpoints (no traffic)
  → Does NOT restart the pod (it's alive, just not ready)

Why check both:
  Liveness UP + Readiness DOWN = JVM running but DB not connected yet
  → Don't send traffic yet (still starting up)
  
  Liveness UP + Readiness UP = fully healthy
  → Route traffic
  
  Liveness DOWN = JVM crashed
  → Kubernetes restarts
```

**Why `python3 -c "import json,sys; ... assert d['status']=='UP'"` not just `grep`:**
- `curl -sf` returns the raw JSON: `{"status":"UP","components":{"db":{"status":"UP"}}}`
- `grep UP` would pass even if the JSON was `{"status":"MAINTENANCE"}` (contains "UP" in the URL path).
- Python JSON parsing ensures we check the ACTUAL `status` field value, not just string presence.

---

## SECTION 5: Job 4 — Promote Image Dev → Staging

### Cross-Account Image Promotion

```yaml
# Two separate AWS credential configurations
- name: Configure AWS (dev — pull source)
  uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789010:role/github-actions-ecr-read
    ...
- name: Login to Dev ECR
  uses: aws-actions/amazon-ecr-login@v2
  with: { registries: "123456789010" }

- name: Configure AWS (staging — push destination)
  uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789011:role/github-actions-ecr-push
    ...
- name: Promote image dev → staging
  run: |
    docker pull ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
    docker tag  ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }} \
                ${{ env.ECR_STAGING }}:${{ env.IMAGE_TAG }}
    docker push ${{ env.ECR_STAGING }}:${{ env.IMAGE_TAG }}
```

**Why promote (copy) instead of rebuild:**

```
WITHOUT promotion (rebuild in each environment):
  Dev:     build from main SHA abc123 → image A
  Staging: rebuild from main SHA abc123 → image B
  Prod:    rebuild from main SHA abc123 → image C

  Images A, B, C are built from the same source code BUT:
  → Different build timestamps
  → Different Docker layer cache states
  → Different Maven Central snapshot versions (if using SNAPSHOT dependencies)
  → Potentially different test results (flaky dependency)
  → NOT guaranteed to be byte-for-byte identical

WITH promotion (copy exact image):
  Dev:     build from main SHA abc123 → image A
  Staging: copy image A → image A (same bytes, same SHA256 digest)
  Prod:    copy image A → image A (same bytes, same SHA256 digest)

  Guaranteed: what was tested in dev is EXACTLY what runs in production.
  The same 8-hour stability test in staging applies to the EXACT binary going to prod.
```

---

## SECTION 6: Job 5 — Staging Load Test (JVM-Aware)

```yaml
- name: Load test (50 VUs, 3 min) — JVM warm-up aware
  run: |
    k6 run \
      --vus 50 \
      --duration 3m \
      --env BASE_URL=https://payment.staging.company.com \
      app/tests/load/payment-load-test.js
```

**Java JIT compilation warmup — why staging thresholds are different:**

```
JVM execution phases:
  0-30 seconds: INTERPRETED mode
    → JVM interprets bytecode line-by-line
    → Slow: ~10-100× slower than native
    → Latency: P99 might be 2000ms (10× higher than steady state)

  30-120 seconds: JIT COMPILATION
    → JVM identifies "hot paths" (frequently executed code)
    → Compiles them to native machine code (JIT = Just In Time)
    → P99 gradually improves from 2000ms → 500ms → 200ms

  120+ seconds: STEADY STATE
    → All hot paths compiled
    → Near-native performance
    → P99: ~200ms (normal target)

k6 thresholds should account for this:
  p99 < 1000ms    (during first 30s warmup: could be 2000ms)
  p99_steady < 500ms  (after 30s: should be under 500ms)

Alternative: GraalVM Native Image
  → Compiles Java to a native binary at BUILD TIME (not runtime)
  → No JVM warmup → startup in <1 second (like Python/Go)
  → Trade-off: very slow build time (10-30 min), harder debugging
  → The comment "skip 60s wait if using GraalVM native image" in Job 7 refers to this
```

---

## SECTION 7: Job 6 — Production (Manual Approval Gate)

```yaml
promote-to-production:
  environment: production   # ← PAUSES HERE
```

**What happens when the pipeline hits `environment: production`:**
1. Job PAUSES. All steps stop before executing.
2. GitHub sends notification to the configured "Required reviewers" (defined in repo Settings → Environments → production).
3. Reviewer sees in GitHub UI: "Workflow waiting for approval — SHA abc123 — tested in staging"
4. Reviewer clicks "Approve and deploy" OR "Reject".
5. If approved: job continues from the paused point.
6. If rejected: job is cancelled, no deploy happens.

**Why the reviewer has enough information at this point:**
- Job 1 (tests) passed → coverage ≥ 70%, all unit tests green.
- Job 2 (build) passed → no CRITICAL CVEs in the image.
- Job 3 (smoke dev) passed → basic API functionality confirmed.
- Job 5 (load staging) passed → performance under 50 VUs confirmed.
- The reviewer sees: commit message + PR link + all previous job results.

---

## SECTION 8: Job 7 — Verify Production + Auto-Rollback

```yaml
- name: Production smoke tests (Actuator)
  id: smoke
  run: |
    sleep 60  # JVM JIT compilation period
    curl -sf https://payment.company.com/actuator/health/liveness
    curl -sf https://payment.company.com/actuator/health/readiness
    curl -sf https://payment.company.com/api/v1/payments/smoke-test-id
```

**Why `sleep 60` in production but `sleep 30` in dev:**
- Production handles real traffic. During the 60s JVM warmup period, real user requests are hitting the pod.
- The pod IS responding (otherwise readiness probe fails and Kubernetes removes it), but latency is elevated.
- The `sleep 60` gives JIT compilation time to complete before the smoke test runs.
- Without it: smoke test might catch the pod during high latency warmup and trigger a false-positive rollback.

### Auto-Rollback Logic

```yaml
- name: Auto-rollback on failure
  if: failure() && steps.smoke.outcome == 'failure'
  run: |
    git pull origin main
    PREV_TAG=$(git log --oneline -- gitops/production/app/payment-service/payment-service.yaml | \
               awk 'NR==2{print $1}' | \
               xargs git show | grep 'tag:' | head -1 | tr -d ' ' | cut -d'"' -f2)
    if [ -n "$PREV_TAG" ]; then
      sed -i "s|tag: \".*\"|tag: \"$PREV_TAG\"|" \
        gitops/production/app/payment-service/payment-service.yaml
      git commit -m "chore(rollback-prod): revert to $PREV_TAG [skip ci]"
      git push
    fi
    exit 1
```

**How the rollback logic works:**

```
Step 1: git pull origin main
  → Gets latest repo state (in case another commit happened during this pipeline)

Step 2: git log --oneline -- gitops/production/.../payment-service.yaml
  → Shows commit history for that specific file
  → Example output:
    abc1234 chore(deploy-prod): update payment-service to abc1234
    def5678 chore(deploy-prod): update payment-service to def5678
    ghi9012 chore(deploy-prod): update payment-service to ghi9012

Step 3: awk 'NR==2{print $1}'
  → NR=1 is the current (bad) commit. NR=2 is the PREVIOUS (good) commit.
  → Extracts the commit hash: "def5678"

Step 4: xargs git show | grep 'tag:' | head -1
  → Shows the content of that commit
  → Finds the tag value: tag: "def5678"
  → Extracts: "def5678" (the previous image SHA)

Step 5: sed -i replaces current tag with PREV_TAG
  → Git commit → git push
  → ArgoCD detects the change → rolls back to previous image
  → Kubernetes replaces pods with the previous Docker image

Step 6: exit 1
  → Forces the job to FAIL even after successful rollback
  → This triggers notifications: "Production verification FAILED, rollback executed"
  → Without exit 1: the pipeline would show "passed" (rollback succeeded), hiding the incident
```

**`if: failure() && steps.smoke.outcome == 'failure'`:**
- `failure()`: runs if any previous step in this job failed.
- `steps.smoke.outcome == 'failure'`: only if specifically the smoke test step failed (not other unrelated failures).
- Prevents rollback if, say, a git authentication failure (unrelated to the deployment) caused job failure.

---

## Java vs Python Pipeline Differences Summary

```
AREA                    PYTHON PIPELINE           JAVA PIPELINE
────────────────────    ─────────────────────     ─────────────────────────────────────────
Build tool              pip install                ./gradlew build
Dependency cache key    requirements.txt hash      build.gradle hash + src/**/*.java hash
Test runner             pytest                     JUnit 5 via Gradle
Coverage tool           coverage.py               JaCoCo (bytecode instrumentation)
Test report format      pytest-junit XML           JUnit XML (same format, different tool)
Coverage minimum        configurable               70% line+branch (jacocoTestCoverageVerification)
Startup time            2-5 seconds               30-120 seconds (JVM + Spring context)
k8s startupProbe        failureThreshold: 10       failureThreshold: 60 (10× longer)
Deployment timeout      3 min                      8-12 min (depends on JVM complexity)
Health endpoint         /health (custom)           /actuator/health/liveness + /readiness
Production warmup       not needed                 sleep 60 (JIT compilation)
CVE scan extras         Python packages (pip)      JRE + Maven JARs + embedded Spring JARs
Multi-arch build        optional                   recommended (Graviton ARM64 savings)
```

---

## Commands — Verify and Debug the Pipeline

```bash
# Run tests locally (same as CI)
cd app
./gradlew test jacocoTestReport jacocoTestCoverageVerification --no-daemon

# See coverage report
open build/reports/jacoco/test/html/index.html

# Build Docker image locally
docker buildx build --platform linux/amd64,linux/arm64 -t payment-service:test app/

# Scan the image for CVEs locally
trivy image payment-service:test --severity CRITICAL,HIGH

# Check pipeline status
gh run list --workflow="Java App CI/CD" --limit 5

# Watch a running pipeline
gh run watch

# Check deployment status on dev
kubectl rollout status deployment/payment-service -n payment-ns --context dev

# Manual rollback (if auto-rollback failed)
PREV_TAG=$(git log --oneline -- gitops/production/app/payment-service/payment-service.yaml | \
           awk 'NR==2{print $1}' | xargs git show | grep 'tag:' | head -1 | \
           tr -d ' ' | cut -d'"' -f2)
sed -i "s|tag: \".*\"|tag: \"${PREV_TAG}\"|" \
  gitops/production/app/payment-service/payment-service.yaml
git commit -am "chore(rollback-prod): manual revert to ${PREV_TAG}"
git push
```
