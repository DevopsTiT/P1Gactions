# Java CI/CD Pipeline — Glossary

**GitHub Actions workflow**
An automated process defined in a YAML file. Runs on virtual machines (runners) in response to events like a git push or pull request. Each run is isolated — starts fresh with no prior state.

**Job**
A unit of work inside a GitHub Actions workflow. Each job runs on its own fresh Ubuntu virtual machine. Jobs can depend on other jobs via `needs:`. This pipeline has 7 jobs in sequence.

**`needs:`**
A GitHub Actions field that declares one job must wait for another to complete successfully. `needs: test` means: don't start this job until `test` passes. Creates the sequential dev → staging → prod pipeline.

**Gradle**
A build automation tool for Java (and other JVM languages). Compiles code, runs tests, builds JAR files, and manages dependencies. Equivalent to `npm` for Node.js or `pip` for Python but with much more power and a longer startup time.

**`./gradlew`**
The Gradle Wrapper — a shell script in the project that downloads and runs a specific version of Gradle. Ensures everyone (local dev, CI) uses the EXACT same Gradle version. No need to install Gradle separately.

**`--no-daemon` (Gradle)**
Disables the Gradle background daemon process. The daemon normally speeds up repeated local builds. In CI where each job starts fresh, the daemon has no benefit but uses extra memory.

**JUnit 5**
The standard Java testing framework. Tests are methods annotated with `@Test`. Generates XML reports in `build/test-results/test/*.xml`. GitHub Actions can read these XML files and show test failures as inline code annotations.

**JaCoCo**
Java Code Coverage — a tool that instruments compiled bytecode to track which lines and branches are executed during tests. Reports coverage as a percentage. This pipeline requires ≥70% line coverage or the build fails.

**`jacocoTestCoverageVerification`**
A Gradle task that FAILS the build if coverage drops below the configured minimum. Unlike just generating a report, this task enforces the coverage requirement as a hard gate.

**`--continue` (Gradle)**
Tells Gradle to keep running remaining tasks even if one fails. Useful for tests: without it, the first test failure stops everything. With it, all tests run and all failures are reported at once.

**JDK (Java Development Kit)**
The full Java toolkit: compiler (`javac`), runtime (JVM), and development tools. Required to compile and run Java code. JRE (Java Runtime Environment) is the subset needed to run already-compiled code.

**Temurin (Eclipse Adoptium)**
A free, open-source, long-term-support (LTS) build of OpenJDK maintained by the Eclipse Foundation. The same distribution used in the Docker image — CI must use the same JDK to avoid subtle differences.

**`distribution: 'temurin'`**
The specific OpenJDK distribution for `actions/setup-java`. Other options: Corretto (Amazon), Zulu (Azul), Microsoft. Using the same distribution in CI and the Docker image ensures byte-code consistency.

**JVM (Java Virtual Machine)**
The runtime that executes compiled Java bytecode. Unlike Python or Node.js, the JVM takes 2-30+ seconds to start because it must: load classes, allocate memory, initialise the garbage collector, and optionally JIT-compile hot code paths.

**JIT compilation (Just-In-Time)**
The JVM's optimisation process. During the first ~30-120 seconds of execution, the JVM identifies frequently-executed code paths and compiles them to native machine code. After warmup: near-native performance. During warmup: higher latency.

**GraalVM Native Image**
A Java build tool that compiles Java to a native binary at build time (instead of JIT at runtime). Result: ~1 second startup instead of 30-120 seconds. Trade-off: 10-30 minute build time, harder to debug.

**Spring Boot**
The dominant Java web framework. Provides embedded web servers (Tomcat, Netty), database connections, security, and hundreds of other features auto-configured via `@SpringBootApplication`. The main reason Java startup is slow — Spring loads all these components.

**Spring ApplicationContext**
The Spring Boot container that creates and wires together all `@Component`, `@Service`, `@Repository`, and `@Controller` beans. Loading the context is the slowest part of Spring Boot startup: 5-30 seconds depending on complexity.

**Spring Boot Actuator**
An optional Spring Boot module that exposes operational endpoints: `/actuator/health`, `/actuator/metrics`, `/actuator/info`. Used in this pipeline for Kubernetes liveness and readiness probes instead of a custom `/health` endpoint.

**`/actuator/health/liveness`**
Spring Actuator endpoint that answers: "Is the JVM alive and not in an irrecoverable state?" Returns `{"status":"UP"}`. Maps to the Kubernetes livenessProbe. If this fails: Kubernetes restarts the pod.

**`/actuator/health/readiness`**
Spring Actuator endpoint that answers: "Is the application ready to accept traffic?" Checks database connectivity, external dependencies. Maps to Kubernetes readinessProbe. If this fails: Kubernetes removes the pod from load balancer rotation but does NOT restart it.

**`startupProbe failureThreshold: 60`**
A Kubernetes setting that gives a pod 600 seconds (60 probes × 10 seconds each) to become ready before Kubernetes kills it. Java needs this because Spring Boot can take 60-120+ seconds to start. Python needs only 10-20 seconds.

**ECR (Elastic Container Registry)**
AWS's Docker image registry. Stores container images securely. Each AWS account has its own ECR. This pipeline uses three separate ECRs: one per environment (dev/staging/production) in three different AWS accounts.

**Image promotion**
Copying a Docker image from one registry to another without rebuilding. `docker pull dev → docker tag → docker push staging`. The SHA256 digest is preserved — the EXACT same binary runs in staging as in dev.

**Why not rebuild**
Rebuilding from the same source code does not guarantee an identical image. Different build timestamps, different cached dependency versions, and different build environments can produce slightly different images. Promotion guarantees byte-for-byte identity.

**OIDC (OpenID Connect) authentication**
A protocol where GitHub generates a short-lived signed JWT per workflow run. AWS STS validates the JWT and issues 1-hour temporary credentials. No static access keys stored anywhere. Keys expire automatically.

**`role-session-name`**
A human-readable label attached to the assumed IAM role session. Shows up in AWS CloudTrail logs: "ECR push by ci-java-dev-12345". Makes it easy to trace which pipeline run performed which AWS action.

**Trivy**
An open-source security scanner for container images and filesystems. For Java: scans OS packages, the JRE itself, AND every JAR file embedded inside the Spring Boot fat JAR. Catches the log4j (log4shell) class of vulnerabilities.

**Fat JAR (uber JAR)**
A Java deployment artifact that contains the application code PLUS all its dependencies (hundreds of JARs) bundled together. Spring Boot's `bootJar` task creates this. Trivy scans inside the fat JAR to check each embedded dependency for CVEs.

**`sed -i`**
A Linux command that edits a file in-place, replacing text matching a pattern. Used in the GitOps deploy step to update the image tag in the YAML file: `sed -i "s|tag: \".*\"|tag: \"new-sha\"|" file.yaml`.

**`[skip ci]`**
A special string in a git commit message that tells GitHub Actions not to trigger a new workflow run for that commit. Used when the pipeline itself updates files (gitops YAML tag updates) to prevent an infinite trigger loop.

**`kubectl rollout status`**
A command that watches a Kubernetes Deployment and waits until the rolling update is complete. Returns success when all pods are running the new image. Returns failure if pods fail to start within the timeout.

**`--timeout=8m` (kubectl rollout)**
The maximum time kubectl waits for a rollout to complete. If the JVM hasn't started within 8 minutes, the pipeline fails. This should be less than the pod's `startupProbe` timeout (10 min) so the pipeline fails before Kubernetes kills the pod.

**k6**
An open-source load testing tool. Runs JavaScript test scripts that simulate virtual users (VUs) making HTTP requests. Reports latency percentiles (P50, P95, P99) and error rates. Used here to confirm the staging deployment handles 50 concurrent users.

**VU (Virtual User)**
A simulated user in a k6 load test. Each VU continuously loops through the test script (make request → wait → make request). `--vus 50` means 50 concurrent requests are sent throughout the test duration.

**`environment: production` (GitHub Actions)**
A job setting that pauses the workflow and requires manual approval from designated reviewers. Configured in GitHub repo Settings → Environments. The job won't run until a reviewer clicks "Approve and deploy" in the GitHub UI.

**Auto-rollback**
When the production smoke test fails, the pipeline reads the previous git commit's image tag from git history and updates the gitops YAML to point back to it. ArgoCD detects the change and rolls Kubernetes back to the previous pod version.

**`git log --oneline -- file.yaml`**
Shows the commit history for a specific file. `NR==1` is the current commit (the bad one). `NR==2` is the previous commit (the known-good one). Used to find the previous image tag for rollback.

**`steps.smoke.outcome == 'failure'`**
A condition that checks if the specific step named `smoke` failed. Used to ensure rollback only triggers if the SMOKE TEST failed, not if an unrelated step (like git config) failed.

**Multi-architecture Docker image**
A single Docker image tag that contains separate variants for different CPU architectures (amd64 for Intel/AMD, arm64 for ARM/Graviton). Kubernetes automatically pulls the right variant based on the node's CPU. Enables running on cheaper ARM instances without code changes.

**`git pull origin main` (before rollback)**
Fetches the latest state of the main branch before making any changes. Required because another commit might have been pushed between when this pipeline started and when the rollback happens. Without `git pull`: merge conflicts on `git push`.

**JUnit XML report**
A standardised XML file format for test results. Every test runner (JUnit, pytest, Jest) can output this format. GitHub Actions reads these files and shows test results as annotations on the code — red markers on the failing test file and line number.

**Gradle dependency cache**
Stores downloaded Maven/Gradle dependency JARs locally (in `~/.gradle/caches`). On subsequent runs: dependencies are read from disk instead of downloaded from Maven Central (~200MB). Saves 2-5 minutes per CI run.

**Gradle build cache**
Stores compiled class files and test results. If neither source files nor `build.gradle` change: test execution is SKIPPED entirely (Gradle returns cached results). Much faster than re-running passing tests every commit.

**`hashFiles('app/src/**/*.java')`**
A GitHub Actions function that computes a SHA256 hash of all matching files. Used as the Gradle build cache key. If ANY Java file changes: hash changes → cache miss → recompile. If no Java files change: hash unchanged → cache hit → skip compilation.
