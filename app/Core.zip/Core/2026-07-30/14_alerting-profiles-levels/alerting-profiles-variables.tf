# Variables needed by the 4-tier alerting profiles

variable "environment" {
  description = "Deployment environment (prod / staging / dev)"
  type        = string
  # Controls which tiers are active:
  # prod    → critical + high + warning + info
  # staging → high + warning + info (no PagerDuty critical)
  # dev     → warning + info only
}

variable "pagerduty_account" {
  description = "PagerDuty account subdomain (e.g. 'yourcompany' for yourcompany.pagerduty.com)"
  type        = string
}

variable "pagerduty_service_keys" {
  description = "Map of team name → PagerDuty service integration key"
  type        = map(string)
  sensitive   = true
  # Example:
  # {
  #   payment   = "abc123..."
  #   orders    = "def456..."
  #   inventory = "ghi789..."
  #   platform  = "jkl012..."
  # }
  # Store in AWS Secrets Manager, not in tfvars files.
}

variable "slack_webhook_url" {
  description = "Slack incoming webhook URL for Dynatrace notifications"
  type        = string
  sensitive   = true
}
