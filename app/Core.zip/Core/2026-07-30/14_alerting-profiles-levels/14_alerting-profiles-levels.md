# More Levels of Alerting — Dynatrace Alerting Profiles Deep Dive

> **Context:** The image shows `alerting-profiles.tf` with 2 tiers (Critical → PagerDuty, Warning → Slack).
> This guide expands to **4 tiers** matching real production alerting architecture, explains every setting, and shows the complete Terraform + notification integration.

---

## Why 2 Tiers Is Not Enough

```
CURRENT (2 tiers):
  Critical → PagerDuty  (AVAILABILITY + ERROR)
  Warning  → Slack      (SLOWDOWN + RESOURCE_CONTENTION)

PROBLEM:
  Critical = ALWAYS wakes someone up at 3am.
  But not all errors are equal:
    → payment-service error rate 1%? Wake up immediately.
    → staging environment slowdown? Send to Slack, nobody cares at night.
    → info-level diagnostic? Log it, never alert.
    
  Warning → Slack for ALL teams = Slack noise.
  When everything is an alert, nothing is an alert.
  
  Missing: incident escalation (page team lead if not acked in 15 min)
  Missing: environment separation (prod alerts ≠ staging alerts)
  Missing: business-hours-only alerts (some things can wait until morning)
```

---

## The 4-Tier Alerting Architecture

```
TIER 1 — CRITICAL (SEV1)
  Severity:   AVAILABILITY (service down)
  Delay:      0 minutes (immediate)
  Channel:    PagerDuty → on-call phone call
  Who:        On-call engineer, escalates to team lead at 15 min
  Example:    payment-service is completely unreachable
              EKS node NotReady
              RDS instance unavailable

TIER 2 — HIGH (SEV2)
  Severity:   ERROR (elevated error rate)
  Delay:      2 minutes (filter out transient spikes)
  Channel:    PagerDuty → push notification (not a call)
  Who:        On-call engineer
  Example:    payment-service error rate > 5% for 2 min
              Database connection pool exhausted
              Memory pressure causing OOM kills

TIER 3 — WARNING (SEV3)
  Severity:   SLOWDOWN (latency degradation)
  Delay:      5 minutes (confirm it's sustained, not a spike)
  Channel:    Slack #alerts-<team>
  Who:        Team sees it next morning or during business hours
  Example:    P99 latency increased from 200ms to 800ms
              Slow database queries detected
              Cache hit rate dropped

TIER 4 — INFO
  Severity:   RESOURCE_CONTENTION (CPU/memory pressure)
              CUSTOM_ALERT (business metric thresholds)
  Delay:      15 minutes
  Channel:    Slack #monitoring (lower priority, aggregated)
  Who:        Engineering manager + team lead, weekly review
  Example:    CPU usage trending up across all nodes
              Disk usage at 70% (not yet critical)
              Error budget at 50% consumed mid-month
```

---

## The Expanded alerting-profiles.tf (4 Tiers)

See the separate file: `alerting-profiles-4tier.tf`

---

## Key Variable Explanations

### severity_level — All 5 Dynatrace Values

```hcl
severity_level = "AVAILABILITY"
# Triggered by: service/process/host going DOWN
# Examples: pod crash, node failure, RDS unreachable, health check failing
# Delay: ALWAYS 0 — you want to know immediately if something is down

severity_level = "ERROR"
# Triggered by: elevated HTTP error rates, exception spikes, failed transactions
# Examples: 5xx errors from your service, database errors, payment failures
# Delay: 2 minutes — filters out brief transient spikes from deployments

severity_level = "SLOWDOWN"
# Triggered by: response time degradation, throughput drop
# Examples: P99 latency doubled, requests per second dropped 50%
# Delay: 5 minutes — slowdowns need time to confirm (not a 1-second blip)

severity_level = "RESOURCE_CONTENTION"
# Triggered by: CPU, memory, disk, network resource pressure
# Examples: node CPU > 80%, JVM heap pressure, disk filling up
# Delay: 15 minutes — resource pressure is a trend, not an event

severity_level = "CUSTOM_ALERT"
# Triggered by: your own metric threshold rules
# Examples: error budget at 80%, order volume dropped 30%
# Delay: configurable per use case
```

### delay_in_minutes — Why It Matters

```
delay_in_minutes = 0:
  Alert fires the INSTANT the problem is detected.
  Use for: AVAILABILITY (service is down — every second matters)
  Risk of too-short delay: woken up for a 30-second blip during deployment

delay_in_minutes = 2:
  Dynatrace waits 2 minutes before sending the alert.
  Use for: ERROR (transient spike during deploy might resolve itself)
  If the problem resolves within 2 min: no alert sent (no false positive)

delay_in_minutes = 5:
  5-minute sustained problem before alerting.
  Use for: SLOWDOWN (performance issues fluctuate — need sustained evidence)

delay_in_minutes = 15:
  15-minute sustained problem before alerting.
  Use for: RESOURCE_CONTENTION (trending issues, not emergencies)
  By 15 minutes: the problem is clearly real, not a spike
```

### include_mode and tag_filter

```hcl
# Option 1: Alert on ALL problems in this management zone
tag_filter {
  include_mode = "INCLUDE_ALL"  # no tag filtering
}

# Option 2: Alert ONLY on problems where entity has specific tags
tag_filter {
  include_mode = "INCLUDE_ANY_MATCHING"
  tag_filter {
    context = "CONTEXTLESS"
    key     = "criticality"
    value   = "high"
    # Only alert if the affected entity has tag: criticality=high
  }
}

# Option 3: Alert on everything EXCEPT specific tags
tag_filter {
  include_mode = "INCLUDE_ALL"
  # Then use management zone scoping to exclude non-prod
}
```

---

## Notification Integrations

### PagerDuty Integration

```hcl
resource "dynatrace_pagerduty_notification" "critical" {
  for_each = local.teams
  
  name    = "${each.value}-${var.environment}-critical-pagerduty"
  active  = true
  profile = dynatrace_alerting.critical[each.key].id
  
  account     = "your-pagerduty-subdomain"
  service_api_key = var.pagerduty_integration_key
  # Each team should have their own PagerDuty service key.
  # payment-team key → payment team on-call
  # platform-team key → platform team on-call
  
  # Behaviour:
  # Alert opens → PagerDuty creates an incident → notifies on-call
  # Alert resolves → PagerDuty auto-resolves the incident
}
```

### Slack Integration

```hcl
resource "dynatrace_slack_notification" "warning" {
  for_each = local.teams
  
  name    = "${each.value}-${var.environment}-warning-slack"
  active  = true
  profile = dynatrace_alerting.warning[each.key].id
  
  url     = var.slack_webhook_url         # team-specific webhook
  channel = "#alerts-${each.value}"       # payment → #alerts-payment
  message = "🟡 {State} - {ProblemTitle} - {ImpactedEntities}"
  
  # Message variables:
  # {State}           = OPEN / RESOLVED / MERGED
  # {ProblemTitle}    = human-readable problem description
  # {ProblemURL}      = direct link to Dynatrace problem page
  # {ImpactedEntities} = which services/hosts are affected
}
```

### Email for Info Tier

```hcl
resource "dynatrace_email_notification" "info" {
  for_each = local.teams
  
  name    = "${each.value}-${var.environment}-info-email"
  active  = true
  profile = dynatrace_alerting.info[each.key].id
  
  subject = "[INFO] {ProblemTitle} in {ManagementZone}"
  to      = ["engineering-leads@company.com"]
  body    = <<-EOT
    Problem: {ProblemTitle}
    Severity: {ProblemSeverity}
    Start: {ProblemStartTime}
    Impacted: {ImpactedEntities}
    Link: {ProblemURL}
  EOT
}
```

---

## Environment-Specific Alerting

```hcl
# Production: all 4 tiers active
# Staging: only WARNING and INFO (no PagerDuty pages for staging)
# Dev: INFO only (engineers check manually)

locals {
  # Per-environment active tiers
  active_critical = var.environment == "prod"
  active_high     = var.environment == "prod" || var.environment == "staging"
  active_warning  = true  # all environments
  active_info     = true  # all environments
}

resource "dynatrace_alerting" "critical" {
  for_each = var.environment == "prod" ? local.teams : {}
  # Critical tier only exists in production
  # In staging: no PagerDuty pages, no 3am wake-ups
  ...
}
```

---

## Escalation Policy (PagerDuty side)

```
What Terraform alone cannot do: escalation within PagerDuty.
Configure this in PagerDuty UI (or PagerDuty Terraform provider):

  Payment Team Service Escalation Policy:
    Level 1 (0 min): On-call engineer — mobile push notification
    Level 2 (15 min, if not acked): Team lead — phone call
    Level 3 (30 min, if not acked): Engineering Manager — SMS + call
    
  For CRITICAL (AVAILABILITY):
    Level 1: Phone call immediately (not just push notification)
    Level 2 (15 min): Team lead phone call
    Level 3 (30 min): VP Engineering

  For HIGH (ERROR):
    Level 1: Push notification (not a call)
    Level 2 (30 min): Phone call if still open

This is why you separate AVAILABILITY and ERROR into different profiles:
Different profiles → different PagerDuty services → different escalation.
```

---

## Verification Commands

```bash
# Check alerting profiles exist in Dynatrace
terraform output alerting_profile_critical_ids
terraform output alerting_profile_high_ids
terraform output alerting_profile_warning_ids
terraform output alerting_profile_info_ids

# Verify via Dynatrace API
DT_URL="https://<your-tenant>.live.dynatrace.com"
DT_TOKEN="<your-api-token>"

curl -s "$DT_URL/api/v1/alertingProfiles" \
  -H "Authorization: Api-Token $DT_TOKEN" | \
  python3 -c "
import json, sys
profiles = json.load(sys.stdin)
for p in profiles.get('values', []):
    print(f\"{p['id']}: {p['displayName']}\")
" | grep -E "critical|high|warning|info"

# Test: manually trigger a test problem in Dynatrace
# Settings → Alerting → Alerting Profiles → click profile → Send test notification
# Verify PagerDuty receives it for critical
# Verify Slack receives it for warning
```
