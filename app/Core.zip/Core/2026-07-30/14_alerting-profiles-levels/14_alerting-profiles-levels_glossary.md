# Glossary — Alerting Profiles Levels

Every term used in the alerting profiles guide, explained for an SRE beginner.

---

**Alerting Profile (Dynatrace)**
A set of rules that controls which Dynatrace problems trigger notifications, and with what delay. Like a filter: "only send me AVAILABILITY problems with a 0-minute delay." One profile is linked to one notification channel.

**dynatrace_alerting (Terraform resource)**
The Terraform resource that creates a Dynatrace Alerting Profile. Each resource = one profile. You create one per tier per team using `for_each = local.teams`.

**severity_level**
The category of problem Dynatrace detected. Five possible values: AVAILABILITY (service down), ERROR (high error rate), SLOWDOWN (latency degradation), RESOURCE_CONTENTION (CPU/memory/disk pressure), CUSTOM_ALERT (your own metric thresholds).

**AVAILABILITY**
A Dynatrace severity indicating a service, host, or process is completely unreachable. The most critical severity. Examples: pod crash, node failure, health check failing, RDS instance down. Always uses delay_in_minutes = 0.

**ERROR**
A Dynatrace severity indicating an elevated error rate. Not "service is down" but "service is returning errors to users." Examples: HTTP 5xx rate spike, database connection errors, failed payment transactions.

**SLOWDOWN**
A Dynatrace severity indicating performance degradation. The service is still up but responding slowly. Examples: P99 latency doubled, throughput dropped 50%, database queries taking 10x longer.

**RESOURCE_CONTENTION**
A Dynatrace severity indicating resource pressure that could lead to future problems. Examples: CPU usage at 80%, JVM heap pressure, disk filling up, network saturation. Usually a TREND, not an emergency.

**CUSTOM_ALERT**
A Dynatrace severity for alerts you define yourself using Metric Events. Examples: error budget consumption exceeding 50%, order volume dropping 30% vs last week. Triggered by your own thresholds on custom metrics.

**delay_in_minutes**
How long Dynatrace waits after detecting a problem before sending the alert. Crucial for reducing false positives. A 2-minute delay means: if the problem resolves itself within 2 minutes (e.g., a brief deployment spike), no alert is sent.

**False Positive**
An alert that fires for a problem that wasn't real or that resolved itself immediately. Too many false positives cause "alert fatigue" — engineers start ignoring alerts because most of them aren't real. Tuning delay_in_minutes reduces false positives.

**Alert Fatigue**
When engineers receive so many alerts that they stop taking them seriously. The most dangerous state for an on-call team: the real SEV1 incident gets missed because it's buried in a flood of low-priority alerts. Prevented by: separate tiers, appropriate delays, and team-scoped channels.

**management_zone**
A Dynatrace scope that groups entities (services, hosts, pods) belonging to one team. Each alerting profile is scoped to a management zone. Payment team's profile only sees payment team's problems.

**for_each (Terraform)**
A Terraform meta-argument that creates one resource per item in a map or set. `for_each = local.teams` creates one alerting profile per team. Avoids copy-pasting the same resource block for each team.

**include_mode = "INCLUDE_ALL"**
Tells the alerting profile to match ALL problems of that severity level, without filtering by entity tag. The broadest setting — any entity in the management zone that has a problem will trigger the rule.

**include_mode = "INCLUDE_ANY_MATCHING"**
Tells the alerting profile to only match problems where the affected entity has specific Dynatrace tags. Useful for targeting only "business-critical" services within a management zone.

**tag_filter**
An optional filter inside an alerting rule that restricts alerts to entities with specific Dynatrace tags. Example: only alert on entities tagged `criticality=high`.

**PagerDuty**
An on-call incident management platform. Receives alerts (from Dynatrace, CloudWatch, etc.) and routes them to the right on-call engineer via phone call, SMS, or push notification. Has escalation policies: if engineer doesn't acknowledge in 15 minutes, escalate to team lead.

**dynatrace_pagerduty_notification (Terraform resource)**
Creates a Dynatrace notification integration that sends problems to PagerDuty. Links an alerting profile (which problems) to a PagerDuty service key (where to send them).

**PagerDuty Service Key**
A unique token that identifies one "service" in PagerDuty. Each team has their own service key → their own on-call schedule. The payment team's key pages the payment team; the platform key pages SREs.

**Escalation Policy (PagerDuty)**
A rule in PagerDuty that defines what happens if an alert is not acknowledged within a set time. Example: notify on-call engineer → if no ack in 15 min → notify team lead → if no ack in 30 min → notify engineering manager.

**dynatrace_slack_notification (Terraform resource)**
Creates a Dynatrace notification integration that sends problems to a Slack channel. Links an alerting profile to a Slack webhook URL and channel name.

**Slack Webhook URL**
A special HTTPS URL provided by Slack that accepts POST requests and posts messages to a channel. Dynatrace POSTs a JSON payload to this URL when a problem fires. Stored as a secret — never hardcode it in Terraform files.

**#alerts-<team>**
A per-team Slack channel that receives WARNING-level alerts for that team only. Payment team sees only payment alerts. Prevents cross-team alert noise. Engineers review this channel during business hours.

**#monitoring**
A shared Slack channel for INFO-level alerts from all teams. Low-priority, reviewed weekly by engineering managers. Used for trending resource pressure and business metric thresholds.

**SEV1 / SEV2 / SEV3**
Incident severity levels. SEV1: complete outage, wake up immediately. SEV2: major degradation, respond quickly. SEV3: minor issue, handle during business hours. Maps to: CRITICAL → SEV1, HIGH → SEV2, WARNING → SEV3 in this alerting design.

**Tier (alerting)**
A level in the alerting hierarchy. Each tier has a different severity threshold, delay, notification channel, and urgency. 4-tier design: Critical (page immediately), High (page with delay), Warning (Slack), Info (weekly review).

**contains() (Terraform function)**
A built-in Terraform function that checks if a value is in a list. `contains(["prod", "staging"], var.environment)` returns true if the environment is either prod or staging. Used to activate certain alert tiers only in specific environments.

**toset([]) (Terraform)**
Converts an empty list to an empty set. When used with `for_each = toset([])`, no resources are created. Used to conditionally disable alerting tiers in non-production environments.

**sensitive = true (Terraform variable)**
Marks a variable as containing sensitive data (API keys, passwords). Terraform will not display the value in logs, plan output, or state file UI. Prevents secrets from being accidentally logged in CI/CD pipelines.

**Metric Event (Dynatrace)**
A Dynatrace rule that fires a CUSTOM_ALERT when a metric crosses a threshold. Example: "fire an alert when payment_error_rate > 1% for 5 minutes." Defined in metric-events.tf, referenced by CUSTOM_ALERT severity in alerting profiles.
