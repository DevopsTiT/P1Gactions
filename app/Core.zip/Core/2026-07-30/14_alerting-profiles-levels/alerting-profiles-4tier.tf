##############################################################################
# Dynatrace Alerting Profiles — 4 Tiers per Team
#
# TIER 1 CRITICAL:  AVAILABILITY (0 min delay)          → PagerDuty (call)
# TIER 2 HIGH:      ERROR (2 min delay)                 → PagerDuty (push)
# TIER 3 WARNING:   SLOWDOWN (5 min delay)              → Slack #alerts-<team>
# TIER 4 INFO:      RESOURCE_CONTENTION (15 min delay)  → Slack #monitoring
#                   CUSTOM_ALERT (15 min delay)
#
# Per-environment:
#   prod    → all 4 tiers active
#   staging → high + warning + info (no PagerDuty critical)
#   dev     → warning + info only
##############################################################################

locals {
  teams = toset(["payment", "orders", "inventory", "platform"])
}

# ─── TIER 1: CRITICAL — AVAILABILITY ─────────────────────────────────────────
# Fires immediately when a service, host, or process becomes UNAVAILABLE.
# Every second counts — no delay.
# Routes to PagerDuty for immediate phone/push alert to on-call.

resource "dynatrace_alerting" "critical" {
  for_each = var.environment == "prod" ? local.teams : toset([])
  # Only created in production. Staging and dev do NOT page people at 3am.

  name            = "${each.value}-${var.environment}-critical"
  management_zone = dynatrace_management_zone_v2.team[each.value].id

  rules {
    rule {
      include_mode     = "INCLUDE_ALL"
      severity_level   = "AVAILABILITY"
      delay_in_minutes = 0
      # 0 delay: alert fires THE INSTANT Dynatrace confirms service is down.
      # No grace period — if it's down, we need to know NOW.
      tag_filter { include_mode = "INCLUDE_ALL" }
    }
  }
}

# ─── TIER 2: HIGH — ERROR RATE ────────────────────────────────────────────────
# Fires when elevated error rates are sustained for 2 minutes.
# 2-minute delay filters out transient spikes during deployments.
# Routes to PagerDuty — push notification (not a phone call for ERROR).

resource "dynatrace_alerting" "high" {
  for_each = contains(["prod", "staging"], var.environment) ? local.teams : toset([])
  # Active in prod and staging (staging errors should be known, just not paged).

  name            = "${each.value}-${var.environment}-high"
  management_zone = dynatrace_management_zone_v2.team[each.value].id

  rules {
    rule {
      include_mode     = "INCLUDE_ALL"
      severity_level   = "ERROR"
      delay_in_minutes = 2
      # 2-minute delay: if a deploy causes a brief error spike and then self-heals,
      # no alert is sent. Reduces false positives by ~60% around deployments.
      tag_filter { include_mode = "INCLUDE_ALL" }
    }
  }
}

# ─── TIER 3: WARNING — PERFORMANCE DEGRADATION ───────────────────────────────
# Fires when latency or throughput is degraded for 5 minutes.
# 5-minute delay confirms sustained degradation vs temporary fluctuation.
# Routes to Slack only — team reviews during business hours.

resource "dynatrace_alerting" "warning" {
  for_each        = local.teams
  name            = "${each.value}-${var.environment}-warning"
  management_zone = dynatrace_management_zone_v2.team[each.value].id

  rules {
    rule {
      include_mode     = "INCLUDE_ALL"
      severity_level   = "SLOWDOWN"
      delay_in_minutes = 5
      # 5 minutes: confirms it's a real performance problem, not a 30-second spike.
      # A spike that lasts < 5 min = no alert. Good for latency that fluctuates.
      tag_filter { include_mode = "INCLUDE_ALL" }
    }
  }
}

# ─── TIER 4: INFO — RESOURCE PRESSURE ────────────────────────────────────────
# Fires when resource utilisation trends are concerning but not yet critical.
# 15-minute delay: only sustained trends trigger this (not spikes).
# Routes to Slack #monitoring — weekly review, not immediate action required.

resource "dynatrace_alerting" "info" {
  for_each        = local.teams
  name            = "${each.value}-${var.environment}-info"
  management_zone = dynatrace_management_zone_v2.team[each.value].id

  rules {
    rule {
      include_mode     = "INCLUDE_ALL"
      severity_level   = "RESOURCE_CONTENTION"
      delay_in_minutes = 15
      # 15 minutes: CPU pressure, memory pressure, disk trending up.
      # These are TRENDS, not emergencies. No 3am alerts.
      # Engineer reviews in morning and plans capacity action.
      tag_filter { include_mode = "INCLUDE_ALL" }
    }
    rule {
      include_mode     = "INCLUDE_ALL"
      severity_level   = "CUSTOM_ALERT"
      delay_in_minutes = 15
      # CUSTOM_ALERT: fires on your own metric events (defined in metric-events.tf).
      # Examples: error budget > 50% consumed, order volume drop > 30%.
      # Business metrics you want tracked but not paged for immediately.
      tag_filter { include_mode = "INCLUDE_ALL" }
    }
  }
}

##############################################################################
# NOTIFICATIONS — Wire alerting profiles to channels
##############################################################################

# ─── TIER 1 + 2: PagerDuty ────────────────────────────────────────────────────

resource "dynatrace_pagerduty_notification" "critical" {
  for_each = var.environment == "prod" ? local.teams : toset([])

  name    = "${each.value}-${var.environment}-critical-pagerduty"
  active  = true
  profile = dynatrace_alerting.critical[each.key].id

  account         = var.pagerduty_account
  service_api_key = var.pagerduty_service_keys[each.value]
  # Each team has their own PagerDuty service → their own on-call schedule.
  # payment-service-key → payment team on-call
  # platform-service-key → platform/SRE team on-call
}

resource "dynatrace_pagerduty_notification" "high" {
  for_each = var.environment == "prod" ? local.teams : toset([])

  name    = "${each.value}-${var.environment}-high-pagerduty"
  active  = true
  profile = dynatrace_alerting.high[each.key].id

  account         = var.pagerduty_account
  service_api_key = var.pagerduty_service_keys[each.value]
  # Same PagerDuty service — different escalation policy in PagerDuty:
  # Critical: immediate phone call
  # High (ERROR): push notification, escalate to call after 30 min if unacked
}

# ─── TIER 3: Slack per-team channel ──────────────────────────────────────────

resource "dynatrace_slack_notification" "warning" {
  for_each = local.teams

  name    = "${each.value}-${var.environment}-warning-slack"
  active  = true
  profile = dynatrace_alerting.warning[each.key].id

  url     = var.slack_webhook_url
  channel = "#alerts-${each.value}"
  # Each team gets their own Slack channel:
  # payment → #alerts-payment
  # orders  → #alerts-orders
  # Avoids alert noise leaking between teams.

  message = "{State} | {ProblemSeverity} | {ProblemTitle} | {ProblemURL}"
}

# ─── TIER 4: Slack shared monitoring channel ─────────────────────────────────

resource "dynatrace_slack_notification" "info" {
  for_each = local.teams

  name    = "${each.value}-${var.environment}-info-slack"
  active  = true
  profile = dynatrace_alerting.info[each.key].id

  url     = var.slack_webhook_url
  channel = "#monitoring"
  # ALL teams share one #monitoring channel for info-level alerts.
  # Reason: info is low-priority. A shared channel is easier to scan weekly.
  # Engineering managers and team leads review #monitoring on Monday mornings.

  message = "[INFO] {State} | {ManagementZone} | {ProblemTitle} | {ProblemURL}"
}

##############################################################################
# OUTPUTS — consumed by notification resources and other modules
##############################################################################

output "alerting_profile_critical_ids" {
  description = "Map of team → critical alerting profile ID"
  value       = { for team, p in dynatrace_alerting.critical : team => p.id }
}

output "alerting_profile_high_ids" {
  description = "Map of team → high alerting profile ID"
  value       = { for team, p in dynatrace_alerting.high : team => p.id }
}

output "alerting_profile_warning_ids" {
  description = "Map of team → warning alerting profile ID"
  value       = { for team, p in dynatrace_alerting.warning : team => p.id }
}

output "alerting_profile_info_ids" {
  description = "Map of team → info alerting profile ID"
  value       = { for team, p in dynatrace_alerting.info : team => p.id }
}
