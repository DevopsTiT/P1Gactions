# EKS Dynatrace GitOps Project — Every File Deep Dive

> One explanation md per folder group. Each file's purpose, every design decision, and what breaks if it is wrong.

## File → Explanation Map

| Folder | Explanation File |
|---|---|
| `app/` | `app/app-files.md` |
| `charts/payment-service/` | `charts/payment-service-chart.md` |
| `charts/namespaces/` | `charts/namespaces-chart.md` |
| `gitops/` (all yaml) | `gitops/gitops-files.md` |
| `terraform/` (infra) | `terraform/terraform-infra-files.md` |
| `terraform/dynatrace/` | `terraform/terraform-dynatrace-files.md` |
| `.github/workflows/` | `github-actions/workflows.md` |
