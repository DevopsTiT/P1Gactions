# All Files Deep Dive — Glossary

**Structured JSON logging**
Writing log lines as JSON objects (`{"level":"error","event":"payment_failed","payment_id":"123"}`) instead of plain text. Dynatrace OneAgent and CloudWatch Logs Insights can query JSON fields directly — impossible with unstructured text logs.

**Liveness probe (`/health/live`)**
A Kubernetes health check that determines if a container is alive. If it fails, Kubernetes restarts the container. Should only check if the process itself is functioning — NOT external dependencies. Failing liveness for a DB issue causes unnecessary restarts.

**Readiness probe (`/health/ready`)**
A Kubernetes health check that determines if a pod should receive traffic. If it fails, the pod is removed from the Service endpoint list — no new requests. Does NOT restart the container. Correct for checking DB connectivity.

**Startup probe**
Disables liveness and readiness probes during application startup. Prevents premature restarts of slow-starting apps. After the startup probe passes, normal probes take over.

**Multi-stage Docker build**
A Dockerfile technique with two stages: a "builder" stage that installs dependencies using build tools, and a "runtime" stage that copies only the compiled output. Final image is smaller (no gcc, pip, build tools) and has a smaller attack surface.

**`readOnlyRootFilesystem: true`**
A Kubernetes security context setting making the container's filesystem immutable. The process cannot write to disk (except mounted volumes). Prevents attackers from writing malicious binaries if the application is compromised.

**`drop: ["ALL"]` capabilities**
Drops all Linux capabilities from the container process. The process cannot bind to privileged ports, modify network rules, access raw sockets, or perform other privileged operations. Combined with `runAsNonRoot` and `readOnlyRootFilesystem`, provides strong container security.

**`topologySpreadConstraints`**
A Kubernetes scheduling rule distributing pods across Availability Zones or nodes. `maxSkew: 1` means no zone has more than 1 extra pod vs others. Prevents all pods from landing in one AZ.

**Pod anti-affinity (`requiredDuringScheduling`)**
A Kubernetes rule preventing two pods with the same label from being scheduled on the same node. If the node fails, at most one pod is lost. Provides node-level redundancy in addition to AZ-level redundancy.

**`preStop: sleep 10`**
A Kubernetes lifecycle hook that runs before SIGTERM is sent. The 10-second sleep gives the ALB time to stop routing new requests to this pod before it begins shutting down. Without it: ALB sends requests to a pod that is in the process of stopping → connection errors.

**`terminationGracePeriodSeconds`**
How long Kubernetes waits after SIGTERM before sending SIGKILL. Set to 60 seconds to allow in-flight requests to complete before the process is forcibly killed.

**HPA (HorizontalPodAutoscaler)**
Automatically adjusts replica count based on metrics. `stabilizationWindowSeconds: 300` prevents thrashing — waits 5 minutes before scaling down to ensure the traffic reduction is sustained.

**PDB (PodDisruptionBudget)**
Limits how many pods can be simultaneously unavailable during voluntary disruptions (node drain, rolling upgrade). `minAvailable: 2` means at least 2 pods must remain running at all times.

**`alb.ingress.kubernetes.io/target-type: ip`**
An ALB annotation routing traffic directly to pod IP addresses, bypassing node IP and kube-proxy. Lower latency, simpler debugging, no NodePort firewall rules needed.

**`ingressClassName: alb`**
Tells Kubernetes which Ingress controller should handle this Ingress resource. The AWS Load Balancer Controller watches for Ingresses with this class and provisions real ALBs.

**ClusterIP (Service type)**
A Kubernetes Service that is only reachable from within the cluster. External traffic reaches pods through the ALB (not through the Service IP). The Service IP is used for pod-to-pod communication.

**`for_each = local.teams`**
Creates one Terraform resource per unique team name extracted from the services map. Three services with `team: payments` create one Management Zone, one alerting profile pair — not three.

**`violating_samples` (DT metric events)**
Number of consecutive evaluation periods a metric must exceed the threshold before an alert fires. 3 samples = 3 consecutive minutes above threshold. Filters single-minute spikes from rolling deployments.

**`dealerting_samples` (DT metric events)**
Number of consecutive periods BELOW threshold before an alert closes. Must be higher than `violating_samples` to prevent flapping. 5 samples = 5 consecutive clean minutes before closing.

**Burn rate (SLO)**
How fast the error budget is being consumed. Burn rate 14.4 means the budget (e.g., 0.1% of allowed failures) will be exhausted in 2 days. Burn rate alerts fire before the SLO actually breaches, giving time to respond.

**`-1M` evaluation window (SLO)**
Rolling 30-day evaluation window. Always evaluates the most recent 30 days — an incident on day 29 stays in the SLO for 30 more days. Prevents gaming by "waiting for the month to reset."

**`prevent_destroy = true` (Terraform lifecycle)**
Prevents `terraform destroy` (or accidental rename/recreate) from deleting the resource. Applied to Management Zones (deletion breaks alerting) and SLOs (deletion loses compliance history).

**OIDC (GitHub Actions to AWS)**
A trust protocol letting GitHub Actions get temporary AWS credentials without storing long-lived access keys. GitHub issues a JWT per job; AWS STS validates and returns 1-hour credentials. The IAM role trust policy restricts to specific repo and branch.

**`id-token: write` permission**
Required GitHub Actions job permission for OIDC. Without it, the job cannot request an OIDC token from GitHub's provider and the AWS credentials step fails.

**`[skip ci]` commit message**
A convention preventing a CI pipeline from re-triggering after a bot commit. When `app-ci.yaml` commits the image tag update to the gitops repo, `[skip ci]` prevents that commit from triggering another `app-ci.yaml` run — avoiding an infinite loop.

**ECR (Elastic Container Registry)**
AWS's managed Docker image registry. `image_tag_mutability = "IMMUTABLE"` ensures the same tag always refers to the same image — nobody can push a different image with an existing tag.

**Trivy**
An open-source container image vulnerability scanner. Checks OS packages and language dependencies (pip, npm) against CVE databases. `exit-code: 1` with `severity: CRITICAL` blocks deployment when critical vulnerabilities are found.

**`environment: production` (GitHub Actions)**
A GitHub feature that pauses a workflow job until designated reviewers click "Approve." Used on the `apply` job so Terraform infrastructure changes require explicit human approval before execution.

**PR comment with plan output**
Posting `terraform plan` output as a GitHub PR comment. Reviewers see exactly what changes will be made to AWS infrastructure before approving the merge. No need to clone and run locally.

**`actions/github-script`**
A GitHub Actions action that runs JavaScript directly in the workflow without checking out code. Used here to create PR comments with the Terraform plan output.

**`fromJSON()` / `toYaml .Values.serviceAccount.annotations`**
Helm template functions. `toYaml` serializes a map to YAML format and `nindent` adds proper indentation. Used to render the IRSA annotation from values without hardcoding the key name in the template.

**`{{ include "payment-service.labels" . }}`**
A Helm template partial (defined in `_helpers.tpl`) that generates a standard set of labels for all resources. Used instead of repeating `app: payment-service, team: payments, ...` in every template file.

**`docker/build-push-action`**
A GitHub Actions action for Docker BuildKit-powered builds. Supports multi-platform builds (`linux/amd64,linux/arm64`) and layer caching via GitHub Actions cache (`cache-from: type=gha`). Substantially reduces build times for repeated CI runs.
