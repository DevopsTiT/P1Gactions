##############################################################################
# MISSING FILE: terraform/modules/vpc/variables.tf
#
# WHY CRITICAL: terraform/main.tf calls module "vpc" and passes these variables.
# Without this file, `terraform validate` fails immediately:
#   "Error: Module does not declare variable X"
##############################################################################

variable "name" {
  type        = string
  description = "Name prefix for all VPC resources (e.g. company-prod)"
}

variable "environment" {
  type        = string
  description = "Environment name applied as a tag"
}

variable "vpc_cidr" {
  type        = string
  description = "CIDR block for the VPC. Must not overlap with other VPCs in the org."
  default     = "10.0.0.0/16"
}

variable "azs" {
  type        = list(string)
  description = "List of availability zones to spread subnets across. Use 3 for HA."
  default     = ["ap-northeast-1a", "ap-northeast-1c", "ap-northeast-1d"]
}

variable "cluster_name" {
  type        = string
  description = "EKS cluster name. Used for subnet discovery tags (ALB + Karpenter)."
}

variable "tags" {
  type        = map(string)
  description = "Common tags applied to all VPC resources"
  default     = {}
}
