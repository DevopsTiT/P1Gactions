##############################################################################
# MISSING FILE: terraform/app-bootstrap/main.tf
#
# PURPOSE: Standalone quickstart deployment — create ECR repo + application
# IAM role without the full GitOps stack. Useful for:
#   - Testing the infrastructure quickly
#   - Deploying payment-service directly (without ArgoCD)
#   - CI/CD bootstrap (create the ECR repo that app-ci.yaml pushes to)
#
# This is a SEPARATE Terraform root with its own backend.tf (different state).
# It does NOT include VPC/EKS — it assumes the cluster already exists.
# Run AFTER the main terraform/ workspace has been applied.
##############################################################################

terraform {
  required_version = ">= 1.6.0, < 2.0.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.50"
    }
  }
  backend "s3" {
    bucket         = "company-terraform-state-prod"
    key            = "app-bootstrap/terraform.tfstate"
    region         = "ap-northeast-1"
    encrypt        = true
    dynamodb_table = "terraform-state-lock"
  }
}

provider "aws" {
  region = var.aws_region
  default_tags {
    tags = {
      managed-by  = "terraform"
      project     = "eks-platform"
      environment = var.environment
    }
  }
}

data "aws_caller_identity" "current" {}

# ── ECR Repository ────────────────────────────────────────────────────────────
# The container registry where GitHub Actions pushes payment-service images.
# This must exist BEFORE app-ci.yaml can push any images.
resource "aws_ecr_repository" "payment_service" {
  name                 = "${var.app_name}"
  image_tag_mutability = "IMMUTABLE"
  # IMMUTABLE: prevents overwriting an existing tag (e.g., :abc1234)
  # Ensures deployed images are always exactly what was tested in CI

  image_scanning_configuration {
    scan_on_push = true
    # Scans each pushed image for CVEs automatically
    # View results: AWS Console → ECR → Repositories → Scan results
  }

  tags = {
    service = var.app_name
    team    = "payments"
  }
}

# Lifecycle policy: keep last 30 production images, delete older ones
resource "aws_ecr_lifecycle_policy" "payment_service" {
  repository = aws_ecr_repository.payment_service.name
  policy = jsonencode({
    rules = [{
      rulePriority = 1
      description  = "Keep last 30 images"
      selection = {
        tagStatus   = "any"
        countType   = "imageCountMoreThan"
        countNumber = 30
      }
      action = { type = "expire" }
    }]
  })
}

# ── IRSA Role for Payment Service ─────────────────────────────────────────────
# The payment-service pod uses this role to access AWS resources (DynamoDB, SQS, etc.)
# Reads the EKS OIDC provider from remote state — this workspace is downstream of main/
data "terraform_remote_state" "main" {
  backend = "s3"
  config = {
    bucket = "company-terraform-state-prod"
    key    = "eks-platform/terraform.tfstate"
    region = var.aws_region
  }
}

data "aws_iam_openid_connect_provider" "eks" {
  url = data.terraform_remote_state.main.outputs.cluster_oidc_issuer_url
}

resource "aws_iam_role" "payment_service" {
  name        = "${var.cluster_name}-payment-service"
  description = "IRSA role for payment-service pod in payment-ns namespace"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Federated = data.aws_iam_openid_connect_provider.eks.arn
      }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "${replace(data.aws_iam_openid_connect_provider.eks.url, "https://", "")}:sub" = "system:serviceaccount:payment-ns:payment-service"
          "${replace(data.aws_iam_openid_connect_provider.eks.url, "https://", "")}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })
}

# Add permissions the payment service actually needs (extend as required)
resource "aws_iam_role_policy" "payment_service" {
  name = "payment-service-policy"
  role = aws_iam_role.payment_service.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "SecretsManagerRead"
        Effect = "Allow"
        Action = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"]
        Resource = "arn:aws:secretsmanager:${var.aws_region}:${data.aws_caller_identity.current.account_id}:secret:${var.environment}/payment-service/*"
      }
    ]
  })
}
