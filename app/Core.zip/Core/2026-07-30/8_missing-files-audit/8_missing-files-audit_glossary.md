# Missing Files Audit — Glossary

**Alerting Profile (Dynatrace)**
A Dynatrace rule set that decides which Problems trigger notifications, with what delay, and scoped to which Management Zone. Without an Alerting Profile, Problems are created but nobody is notified — the monitoring exists silently.

**Notification Integration (Dynatrace)**
A Dynatrace configuration connecting an Alerting Profile to a delivery channel: PagerDuty, Slack, OpsGenie, email, webhook. The Alerting Profile says "which problems"; the Notification says "where to send them."

**`dynatrace_alerting` (Terraform resource)**
Creates a Dynatrace Alerting Profile. Specifies severity levels (AVAILABILITY, ERROR, SLOWDOWN, RESOURCE_CONTENTION), delay in minutes before firing, and the Management Zone scope.

**`dynatrace_pagerduty_notification` (Terraform resource)**
Wires an Alerting Profile to a PagerDuty service via the Events API v2 integration key. When the profile matches a Problem, Dynatrace calls PagerDuty and creates an incident.

**`dynatrace_slack_notification` (Terraform resource)**
Wires an Alerting Profile to a Slack channel via an incoming webhook URL. Posts a formatted message when the profile matches a Problem, and another message when the Problem resolves.

**`{State}`, `{ProblemTitle}`, `{ProblemURL}` (DT placeholders)**
Dynamic values in Slack/notification message templates. `{State}` is OPEN or RESOLVED. `{ProblemTitle}` is the human-readable Problem description. `{ProblemURL}` is a direct link to the Problem in the DT UI.

**pytest**
Python's standard test framework. The GitHub Actions `app-ci.yaml` runs `pytest app/tests/` on every PR. If no test files exist, pytest exits 0 (success) by default but may also fail depending on configuration. Tests ensure code correctness before Docker images are built.

**`app.test_client()` (Flask)**
Creates an in-memory HTTP client for testing Flask routes without starting a real server. Allows calling endpoints like `client.get('/health')` and asserting on the response.

**ECR (Elastic Container Registry)**
AWS's managed Docker image registry. The `app-bootstrap` workspace creates the ECR repository that GitHub Actions pushes images to. The EKS nodes pull images from this registry.

**`image_tag_mutability = "IMMUTABLE"`**
An ECR setting that prevents overwriting an existing image tag. Ensures `payment-service:abc1234` always refers to the exact same image that was tested — nobody can push a different image with the same tag later.

**`scan_on_push = true` (ECR)**
Automatically scans each pushed image for known CVEs (Common Vulnerabilities and Exposures). Results appear in the ECR console. Does not block pushes but provides visibility into image security posture.

**ECR Lifecycle Policy**
An ECR rule that automatically deletes old images to control storage costs. "Keep last 30 images" means images beyond the 30 most recent are deleted — reducing storage costs while keeping enough history for rollback.

**`terraform_remote_state` (data source)**
Reads outputs from another Terraform workspace's state file stored in S3. The `app-bootstrap` workspace uses this to read the EKS OIDC provider URL from the main workspace — avoids duplicating the EKS module call.

**`Chart.yaml` (Helm)**
The mandatory descriptor file for every Helm chart. Defines: chart name, version, description, and type. Without `Chart.yaml`, Helm (and ArgoCD using Helm mode) cannot recognise the directory as a chart.

**Module `variables.tf`**
Declares the input variables a Terraform module accepts. Without it, the calling `main.tf` cannot pass any arguments to the module — every `module.vpc.vpc_id` type reference fails with "unsupported attribute."

**Module `outputs.tf`**
Declares the values a Terraform module exposes to its callers. Without it, `module.vpc.vpc_id` and `module.eks.cluster_endpoint` fail with "this object has no attribute." Required for chaining modules together.

**`cluster_oidc_issuer_url` (EKS output)**
The OIDC provider URL that the EKS cluster uses. Every IRSA trust policy references this URL to scope which pods can assume which IAM role. Without this output, none of the `irsa-*.tf` files work.

**`node_security_group_id` (EKS output)**
The security group attached to EKS worker nodes. Karpenter's EC2NodeClass uses the tag `karpenter.sh/discovery` on this security group to find where to provision new nodes. Without this output, Karpenter cannot discover the correct security group.

**`delay_in_minutes` (Alerting Profile)**
How long a Problem must be open before a notification fires. `0` for AVAILABILITY (immediate). `2` for ERROR (filters transient spikes). `5` for SLOWDOWN (latency spikes during deploys are common). `15` for RESOURCE_CONTENTION (rarely immediately critical).

**`for_each = local.teams`**
A Terraform meta-argument creating one resource per unique team. If the services map has `payments` and `platform` teams, this creates two alerting profiles — one per team — without duplicating code.

**`for_each = var.pagerduty_integration_keys`**
Creates one PagerDuty notification per entry in the PagerDuty keys map. Each team has their own routing key routing incidents to their on-call schedule. Sensitive variable — passed via `TF_VAR_` environment variable, never in `.tfvars`.
