##############################################################################
# MISSING FILE: terraform/modules/eks/outputs.tf
#
# WHY CRITICAL — every file that references module.eks.* needs this:
#   terraform/main.tf:        cluster_endpoint, cluster_ca_certificate (K8s provider)
#   terraform/karpenter.tf:   cluster_oidc_issuer_url (IRSA trust policy)
#   terraform/irsa-lbc.tf:    cluster_oidc_issuer_url
#   terraform/irsa-eso.tf:    cluster_oidc_issuer_url
#   terraform/irsa-externaldns.tf: cluster_oidc_issuer_url
#   terraform/outputs.tf:     cluster_name, cluster_endpoint, cluster_oidc_issuer_url
#
#   Without this file, terraform plan fails with:
#   "Error: Unsupported attribute: module.eks.cluster_endpoint"
##############################################################################

output "cluster_name" {
  value       = aws_eks_cluster.main.name
  description = "EKS cluster name — used for kubectl config and CI/CD"
}

output "cluster_endpoint" {
  value       = aws_eks_cluster.main.endpoint
  description = "EKS API server endpoint — used by Kubernetes and Helm providers in main.tf"
}

output "cluster_ca_certificate" {
  value       = aws_eks_cluster.main.certificate_authority[0].data
  description = "Base64-encoded cluster CA certificate — used by K8s provider for TLS"
  sensitive   = true
}

output "cluster_oidc_issuer_url" {
  value       = aws_eks_cluster.main.identity[0].oidc[0].issuer
  description = "OIDC provider URL — used in every IRSA trust policy condition"
  # Format: https://oidc.eks.REGION.amazonaws.com/id/CLUSTER_ID
  # Strip "https://" prefix when using in IAM condition variable keys
}

output "node_security_group_id" {
  value       = aws_eks_cluster.main.vpc_config[0].cluster_security_group_id
  description = "Security group attached to EKS nodes — referenced by Karpenter EC2NodeClass for discovery"
}
