##############################################################################
# MISSING FILE: terraform/modules/eks/variables.tf
#
# WHY CRITICAL:
#   terraform/main.tf calls module "eks" with these parameters.
#   Without this file, every `module.eks.*` reference in main.tf and IRSA files fails.
##############################################################################

variable "cluster_name" {
  type        = string
  description = "EKS cluster name — used as prefix for all related resources"
}

variable "cluster_version" {
  type        = string
  description = "Kubernetes version for the EKS cluster"
  default     = "1.30"
}

variable "vpc_id" {
  type        = string
  description = "VPC ID from VPC module output (module.vpc.vpc_id)"
}

variable "subnet_ids" {
  type        = list(string)
  description = "Private subnet IDs for EKS nodes (module.vpc.private_subnet_ids)"
}

variable "node_instance_types" {
  type        = list(string)
  description = "EC2 instance types for the system node group"
  default     = ["m7g.xlarge"]
}

variable "node_min_size" {
  type    = number
  default = 3
}

variable "node_max_size" {
  type    = number
  default = 10
}

variable "node_desired_size" {
  type    = number
  default = 3
}

variable "tags" {
  type    = map(string)
  default = {}
}
