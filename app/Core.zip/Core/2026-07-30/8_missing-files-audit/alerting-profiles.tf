##############################################################################
# MISSING FILE: terraform/dynatrace/alerting-profiles.tf
#
# Creates TWO alerting profiles per team:
#   1. <team>-critical → no delay, routes AVAILABILITY + ERROR problems
#   2. <team>-warning  → 5-10 min delay, routes SLOWDOWN + RESOURCE_CONTENTION
#
# WHY TWO PROFILES PER TEAM:
#   Critical: wakes on-call engineer immediately (AVAILABILITY outage = money loss)
#   Warning:  Slack notification only, for trends that need attention but not immediate response
#
# DEPENDENCY:
#   management-zones.tf must run first — alerting profiles reference zone IDs.
#   Both are in the same Terraform workspace so order is handled by dependency graph.
##############################################################################

# One CRITICAL alerting profile per unique team
resource "dynatrace_alerting" "critical" {
  for_each = local.teams

  name = "${each.value}-${var.environment}-critical"

  # Scope to this team's Management Zone only
  # This means only Problems from entities IN the team's zone trigger this profile.
  # Without management_zone: every team would receive every alert in the tenant.
  management_zone = dynatrace_management_zone_v2.team[each.value].id

  rules {
    # AVAILABILITY: service/host completely down → notify IMMEDIATELY (delay = 0)
    rule {
      include_mode     = "INCLUDE_ALL"
      severity_level   = "AVAILABILITY"
      delay_in_minutes = 0
      tag_filter {
        include_mode = "INCLUDE_ALL"
      }
    }

    # ERROR: elevated error rate → notify after 2 minutes (filters transient spikes)
    rule {
      include_mode     = "INCLUDE_ALL"
      severity_level   = "ERROR"
      delay_in_minutes = 2
      tag_filter {
        include_mode = "INCLUDE_ALL"
      }
    }
  }
}

# One WARNING alerting profile per unique team
resource "dynatrace_alerting" "warning" {
  for_each = local.teams

  name            = "${each.value}-${var.environment}-warning"
  management_zone = dynatrace_management_zone_v2.team[each.value].id

  rules {
    # SLOWDOWN: elevated latency → notify after 5 min (latency spikes are common during deploys)
    rule {
      include_mode     = "INCLUDE_ALL"
      severity_level   = "SLOWDOWN"
      delay_in_minutes = 5
      tag_filter {
        include_mode = "INCLUDE_ALL"
      }
    }

    # RESOURCE_CONTENTION: CPU/memory pressure → notify after 15 min
    # (resource pressure rarely causes immediate user impact; give it time to self-resolve)
    rule {
      include_mode     = "INCLUDE_ALL"
      severity_level   = "RESOURCE_CONTENTION"
      delay_in_minutes = 15
      tag_filter {
        include_mode = "INCLUDE_ALL"
      }
    }
  }
}

# Outputs: profile IDs needed by notifications.tf and metric-events.tf
output "alerting_profile_critical_ids" {
  value       = { for team, profile in dynatrace_alerting.critical : team => profile.id }
  description = "Map of team → critical alerting profile ID (for PagerDuty notifications)"
}

output "alerting_profile_warning_ids" {
  value       = { for team, profile in dynatrace_alerting.warning : team => profile.id }
  description = "Map of team → warning alerting profile ID (for Slack notifications)"
}
