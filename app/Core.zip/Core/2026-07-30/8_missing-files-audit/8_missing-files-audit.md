# Missing Files Audit — 4_eks-dynatrace-gitops-project

> Cross-checking every file listed in `4_eks-dynatrace-gitops-project.md` against what actually exists on disk.

---

## Audit Result

| File (from MD spec) | Status | Gap Type |
|---|---|---|
| `terraform/dynatrace/alerting-profiles.tf` | ❌ MISSING | Dynatrace alerting profiles |
| `terraform/dynatrace/notifications.tf` | ❌ MISSING | PagerDuty + Slack webhooks |
| `app/tests/test_main.py` | ❌ MISSING | Unit tests for Python app |
| `charts/namespaces/Chart.yaml` | ❌ MISSING (dir exists empty) | Helm chart for namespaces |
| `terraform/app-bootstrap/main.tf` | ❌ MISSING | Standalone quickstart |
| `terraform/app-bootstrap/variables.tf` | ❌ MISSING | |
| `terraform/app-bootstrap/outputs.tf` | ❌ MISSING | |
| `terraform/modules/vpc/variables.tf` | ❌ MISSING | VPC module inputs |
| `terraform/modules/vpc/outputs.tf` | ❌ MISSING | VPC module outputs |
| `terraform/modules/eks/variables.tf` | ❌ MISSING | EKS module inputs |
| `terraform/modules/eks/outputs.tf` | ❌ MISSING | EKS module outputs |
| `terraform/variables-addition.tf` | ⚠️ EXTRA (added by us in task 7) | Not in original MD |

---

## Files Created in This Task

All missing files are created as artifacts in this folder and explained in the sections below.

| Artifact File | Destination (copy to) |
|---|---|
| `alerting-profiles.tf` | `terraform/dynatrace/alerting-profiles.tf` |
| `notifications.tf` | `terraform/dynatrace/notifications.tf` |
| `test_main.py` | `app/tests/test_main.py` |
| `namespaces-Chart.yaml` | `charts/namespaces/Chart.yaml` |
| `namespaces-values.yaml` | `charts/namespaces/values.yaml` (bonus) |
| `app-bootstrap-main.tf` | `terraform/app-bootstrap/main.tf` |
| `app-bootstrap-variables.tf` | `terraform/app-bootstrap/variables.tf` |
| `app-bootstrap-outputs.tf` | `terraform/app-bootstrap/outputs.tf` |
| `modules-vpc-variables.tf` | `terraform/modules/vpc/variables.tf` |
| `modules-vpc-outputs.tf` | `terraform/modules/vpc/outputs.tf` |
| `modules-eks-variables.tf` | `terraform/modules/eks/variables.tf` |
| `modules-eks-outputs.tf` | `terraform/modules/eks/outputs.tf` |

---

## Why Each File Is Important

### `alerting-profiles.tf` + `notifications.tf`

These are the LAST MILE of the alert pipeline:

```
Metric Event fires (metric-events.tf)
    → creates a DT Problem
    → alerting-profiles.tf: which team's profile matches? what delay?
    → notifications.tf: which PagerDuty/Slack webhook to call?
```

Without these files, Problems are created in Dynatrace but NOBODY is notified. The entire monitoring setup exists but silently — alerts never reach engineers.

### `test_main.py`

The `app-ci.yaml` GitHub Actions workflow explicitly runs `pytest` on PR:
```yaml
- run: pytest app/tests/
```
Without `test_main.py`, every PR fails immediately on the test step. The CI pipeline is broken from day one.

### `charts/namespaces/Chart.yaml`

The `gitops/namespaces/namespaces.yaml` ArgoCD Application points at `charts/namespaces/` as its Helm chart source. If `Chart.yaml` doesn't exist, ArgoCD cannot parse it as a Helm chart and the namespaces Application fails to sync. No namespaces = no other pods can start (wave -1 failure cascades to every other wave).

### `terraform/app-bootstrap/`

Listed in the MD as "separate root: ECR repo + app IAM." This is the quickstart deployment path — deploy the payment-service without the full GitOps stack. Without these files, `cd terraform/app-bootstrap && terraform apply` (as shown in multiple docs) fails immediately.

### `terraform/modules/vpc/variables.tf` + `outputs.tf`

The VPC `main.tf` exists but its module is unusable without `variables.tf` (what inputs does the caller pass?) and `outputs.tf` (what does the VPC expose for EKS to consume?). The root `main.tf` calls `module.vpc.vpc_id` and `module.vpc.private_subnet_ids` — these come from `outputs.tf`. Without it: `module.vpc.vpc_id` errors with "unsupported attribute."

### `terraform/modules/eks/variables.tf` + `outputs.tf`

Same problem as VPC. The root `main.tf` calls `module.eks.cluster_endpoint`, `module.eks.cluster_oidc_issuer_url`, `module.eks.cluster_name` etc. These all come from `outputs.tf`. Without it: every IRSA file and the Kubernetes provider block fail with "unsupported attribute."
