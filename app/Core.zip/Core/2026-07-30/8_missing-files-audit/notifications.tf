##############################################################################
# MISSING FILE: terraform/dynatrace/notifications.tf
#
# Creates notification integrations for each team:
#   - PagerDuty: wired to the critical alerting profile
#   - Slack:     wired to the warning alerting profile
#
# WHY THIS FILE IS CRITICAL:
#   alerting-profiles.tf defines WHICH problems get notified.
#   notifications.tf defines WHERE those notifications go.
#   Without notifications.tf, problems are created in Dynatrace but
#   no engineer is ever paged — silent monitoring.
#
# PREREQUISITE: alerting-profiles.tf must be applied first.
#
# SENSITIVE VALUES:
#   pagerduty_integration_keys and slack_webhook_urls come from var.
#   These are marked sensitive=true in variables.tf.
#   Pass them via: TF_VAR_pagerduty_integration_keys='{"payments":"key..."}'
#   OR: read from AWS Secrets Manager in a data source (recommended for prod).
##############################################################################

# PagerDuty notification: one per team, wired to the CRITICAL alerting profile
resource "dynatrace_pagerduty_notification" "critical" {
  for_each = var.pagerduty_integration_keys   # map of team → PD integration key

  name             = "${each.key}-${var.environment}-pagerduty"
  active           = true
  alerting_profile = dynatrace_alerting.critical[each.key].id
  # alerting_profile: this notification only fires when the CRITICAL profile matches
  # → AVAILABILITY or ERROR problems in this team's Management Zone

  # PagerDuty Events API v2 integration key
  # Each team has their own routing key → incidents route to the correct on-call schedule
  account     = "${each.key}-oncall"
  service_api_key = each.value   # the PD integration key for this team
}

# Slack notification: one per team, wired to the WARNING alerting profile
resource "dynatrace_slack_notification" "warning" {
  for_each = var.slack_webhook_urls   # map of team → Slack webhook URL

  name             = "${each.key}-${var.environment}-slack"
  active           = true
  alerting_profile = dynatrace_alerting.warning[each.key].id
  # alerting_profile: fires for SLOWDOWN + RESOURCE_CONTENTION in this team's zone

  url     = each.value   # Slack incoming webhook URL for this team's channel
  channel = "#${each.key}-alerts"
  message = "[${upper(var.environment)}] {State} {ProblemTitle} — {ProblemURL}"
  # Placeholders:
  #   {State}        → OPEN or RESOLVED
  #   {ProblemTitle} → e.g., "High error rate on payment-service"
  #   {ProblemURL}   → direct link to the DT Problem view
}
