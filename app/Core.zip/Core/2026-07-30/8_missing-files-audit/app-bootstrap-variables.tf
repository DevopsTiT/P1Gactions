# MISSING FILE: terraform/app-bootstrap/variables.tf

variable "aws_region" {
  type    = string
  default = "ap-northeast-1"
}

variable "environment" {
  type    = string
  default = "production"
}

variable "cluster_name" {
  type        = string
  description = "EKS cluster name (must match the main workspace's cluster_name)"
  default     = "company-prod"
}

variable "app_name" {
  type        = string
  description = "Application name used for ECR repository and IAM role naming"
  default     = "payment-service"
}
