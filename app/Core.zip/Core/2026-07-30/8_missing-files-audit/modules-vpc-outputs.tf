##############################################################################
# MISSING FILE: terraform/modules/vpc/outputs.tf
#
# WHY CRITICAL:
#   terraform/main.tf references:
#     module.vpc.vpc_id              → used by EKS module + security groups
#     module.vpc.private_subnet_ids  → EKS nodes live here
#   terraform/karpenter.tf references these indirectly through security group discovery.
#
#   Without outputs.tf, `terraform plan` fails:
#     "Error: Unsupported attribute: This object has no attribute named 'vpc_id'"
##############################################################################

output "vpc_id" {
  value       = aws_vpc.main.id
  description = "VPC ID — referenced by EKS module, security groups, and VPC endpoints"
}

output "private_subnet_ids" {
  value       = aws_subnet.private[*].id
  description = "Private subnet IDs — EKS nodes + pods live here. Referenced by EKS module and Karpenter EC2NodeClass."
}

output "public_subnet_ids" {
  value       = aws_subnet.public[*].id
  description = "Public subnet IDs — ALBs and NAT Gateways live here"
}

output "vpc_cidr" {
  value       = aws_vpc.main.cidr_block
  description = "VPC CIDR block — used for security group ingress rules"
}

output "nat_gateway_ids" {
  value       = aws_nat_gateway.main[*].id
  description = "NAT Gateway IDs — one per AZ"
}
