# MISSING FILE: terraform/app-bootstrap/outputs.tf

output "ecr_repository_url" {
  value       = aws_ecr_repository.payment_service.repository_url
  description = "ECR URL for Docker push. Use in GitHub Actions: docker push <this_value>:<tag>"
}

output "payment_service_role_arn" {
  value       = aws_iam_role.payment_service.arn
  description = "IRSA role ARN. Set this in charts/payment-service/values.yaml serviceAccount.annotations"
}
