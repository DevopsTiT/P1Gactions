# MISSING FILE: app/tests/test_main.py
#
# WHY THIS FILE IS NEEDED:
#   The GitHub Actions workflow app-ci.yaml runs pytest on every PR.
#   Without this file, pytest finds no tests and the step fails or is empty.
#   Having tests proves the app logic works before Docker image is built.
#
# WHAT TO TEST:
#   - Health check endpoint returns 200
#   - Main endpoint returns correct JSON structure
#   - Error handling (invalid input)
#   - Edge cases specific to the payment service

import pytest
import json
from unittest.mock import patch, MagicMock

# Import the Flask app
# The app is in app/main.py; tests run from the repo root
# pytest is configured (or should be) to add app/ to sys.path
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from main import app


@pytest.fixture
def client():
    """Create a test client for the Flask app."""
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client


class TestHealthCheck:
    """Tests for the /health endpoint."""

    def test_health_returns_200(self, client):
        """Health endpoint must return 200 — used by Kubernetes readiness probe."""
        response = client.get('/health')
        assert response.status_code == 200

    def test_health_returns_json(self, client):
        """Health endpoint must return JSON — ALB health check validates body."""
        response = client.get('/health')
        data = json.loads(response.data)
        assert 'status' in data

    def test_health_status_ok(self, client):
        """Health status must be 'ok' — Dynatrace synthetic monitor validates this."""
        response = client.get('/health')
        data = json.loads(response.data)
        assert data['status'] == 'ok'


class TestMainEndpoint:
    """Tests for the main payment service endpoint."""

    def test_root_returns_200(self, client):
        """Root endpoint accessible."""
        response = client.get('/')
        assert response.status_code == 200

    def test_response_has_required_fields(self, client):
        """Response must contain required fields for downstream services."""
        response = client.get('/')
        data = json.loads(response.data)
        # Adjust these assertions to match your actual app's response structure
        assert data is not None

    def test_headers_present(self, client):
        """Content-Type header must be application/json."""
        response = client.get('/')
        assert 'application/json' in response.content_type


class TestErrorHandling:
    """Tests for error scenarios."""

    def test_404_returns_json(self, client):
        """404 responses should be JSON, not HTML (for API clients)."""
        response = client.get('/nonexistent-endpoint')
        assert response.status_code == 404

    def test_method_not_allowed(self, client):
        """DELETE on health endpoint should return 405."""
        response = client.delete('/health')
        assert response.status_code == 405
