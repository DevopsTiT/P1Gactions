# Microservice Metrics Check — Glossary

**Four Golden Signals**
The four metrics that together fully describe a service's health: Latency (how long requests take), Traffic (how many requests per second), Errors (fraction that fail), and Saturation (how close to capacity). Originated from Google's SRE book. If all four are healthy, the service is fit.

**Fit (service health)**
A service is "fit" when all its Four Golden Signals are within acceptable bounds — low errors, good latency, normal traffic, and not resource-saturated. The opposite of fit is "degraded" or "down."

**Error rate**
The percentage of HTTP requests that return a 5xx status code (server errors). A healthy service has < 0.1% error rate. Above 1% means users are experiencing failures. Calculated as: (5xx requests / total requests) × 100.

**Latency**
How long it takes for a service to respond to a request. Measured as percentiles: P50 (median), P95, P99 (99th percentile). P99 of 500ms means 99% of requests complete in under 500ms. The remaining 1% took longer.

**P99 (99th percentile)**
The response time below which 99% of all requests fall. The most important latency metric for SLOs because it captures the worst-case experience for users. Averages hide slow outliers; P99 reveals them.

**Traffic (request rate)**
The number of requests per second hitting a service. Used as context for other signals: a 5% error rate at 10 req/s = 0.5 errors/second (minor). A 5% error rate at 10,000 req/s = 500 errors/second (major incident).

**Saturation**
How close a resource (CPU, memory, DB connections) is to its limit. A leading indicator — high saturation PREDICTS future latency and error increases before users feel them. CPU at 85% will cause slowness soon; at 95% it's already causing slowness.

**SLO (Service Level Objective)**
A reliability target: "99.9% of requests succeed over 30 days." When the SLO is being met, the service is fit. When the SLO is breached, the service is not fit and reliability work takes priority.

**Error budget**
The allowed failure derived from the SLO. 99.9% SLO = 0.1% allowed failure = 43.2 minutes of allowed downtime per month. When the budget is nearly exhausted, deploying risky changes is paused.

**PromQL**
Prometheus Query Language. Used to write queries against metrics stored in Prometheus. Similar to SQL but for time-series data. Functions like `rate()`, `sum by ()`, and `histogram_quantile()` are the building blocks of all metrics queries.

**`rate(metric[5m])`**
A PromQL function that calculates the per-second average rate of a counter metric over the last 5 minutes. Counters only go up; `rate()` gives you the speed of change (how fast requests are arriving).

**`histogram_quantile(0.99, ...)`**
A PromQL function that calculates the 99th percentile value from a histogram metric. Used for P99 latency. The `_bucket` suffix on metrics like `http_request_duration_seconds_bucket` contains the histogram data.

**`kubectl get pods`**
A command to list running pods in a Kubernetes namespace. The STATUS column shows if pods are Running, Pending, or CrashLoopBackOff. RESTARTS column shows how many times the container has crashed and restarted.

**`kubectl top pods`**
A command that shows live CPU and memory usage for pods. Requires metrics-server to be installed. Useful for comparing actual usage against resource limits to check saturation.

**`kubectl get endpoints`**
A command that shows which pod IPs are registered behind a Kubernetes Service. If endpoints shows `<none>`, no pods are ready to receive traffic — the service is effectively down.

**`kubectl describe hpa`**
Shows the HPA's current status including current vs target replicas, current CPU%, and any warning events (like "unable to fetch metrics" or "failed to get scale"). Essential for diagnosing autoscaling problems.

**HPA (Horizontal Pod Autoscaler)**
A Kubernetes controller that automatically adjusts the number of pod replicas based on CPU/memory usage. If REPLICAS = MAXPODS, the HPA is at its ceiling and cannot scale further — the service is saturated.

**`kubectl get events`**
Shows Kubernetes cluster events sorted by time. Useful for seeing recent warnings like OOMKilled (ran out of memory), FailedScheduling (no node available), or BackOff (container restart delays). Often the first place to look during an incident.

**CrashLoopBackOff**
A Kubernetes pod status meaning the container keeps crashing and restarting. Kubernetes adds exponential delays between restarts (backoff). Caused by: app crash, OOMKill, failed health probe, missing config. High restart count is the telltale sign.

**OOMKilled**
"Out Of Memory Killed" — the Linux kernel killed the container process because it exceeded its memory limit. Shows as exit code 137. A pod with OOMKilled in its status needs either a higher memory limit or a memory leak fixed.

**Readiness probe**
A Kubernetes health check that determines if a pod is ready to receive traffic. If the readiness probe fails, the pod is removed from the Service's endpoints list — no traffic is sent to it. A failing readiness probe is why endpoints might show `<none>`.

**Liveness probe**
A Kubernetes health check that determines if a pod is alive. If the liveness probe fails N consecutive times, Kubernetes kills and restarts the container. Used to recover from hung processes.

**Resource limits (CPU/memory)**
The maximum CPU and memory a container can use. If CPU exceeds the limit, the container is throttled (slowed down). If memory exceeds the limit, the container is OOMKilled. Saturation check compares actual usage against these limits.

**DB connection pool**
A pre-established set of database connections that the application reuses. If all connections are in use (pool saturation = 100%), new database requests queue or fail. Pool saturation above 80% means requests will soon queue and latency will spike.

**ServiceMonitor (Prometheus Operator)**
A Kubernetes custom resource that tells Prometheus which services to scrape for metrics. If a service doesn't have a ServiceMonitor, Prometheus knows nothing about it — no metrics means no alerts, no latency data, no error rate.

**`kubectl top`**
A kubectl subcommand for showing real-time CPU and memory usage. `kubectl top pods` shows pod-level usage. `kubectl top nodes` shows node-level usage. Requires `metrics-server` to be running in the cluster.

**Dynatrace Problems API**
A Dynatrace API endpoint that returns open problems (incidents). A problem is opened when an alert threshold is exceeded. Zero open problems for a service = Dynatrace considers it healthy.

**`builtin:service.errors.total.rate`**
A Dynatrace built-in metric that measures the HTTP error rate for a service. Automatically collected by OneAgent without any instrumentation code.

**`builtin:service.response.time:percentile(99)`**
A Dynatrace built-in metric that returns the P99 response time for a service in microseconds. Divide by 1000 to get milliseconds.

**Traffic drop (> 50%)**
When traffic suddenly drops to less than half of normal, it usually means: the service is unreachable (DNS, ALB, deployment broke routing), an upstream service stopped calling it, or a feature flag disabled it. It's not always bad — could be intentional (night, weekend).

**Long tail latency**
When P50 (average) looks normal but P99 is very high, a small percentage of requests are extremely slow. Common causes: slow database queries for edge-case data, connection pool timeouts for occasional spikes, external API calls timing out.

**`kubectl run --rm -it debug`**
Creates a temporary debug pod inside the cluster that is automatically deleted when you exit. Used to test connectivity, DNS resolution, and service responses from inside the cluster — simulating what other pods experience.
