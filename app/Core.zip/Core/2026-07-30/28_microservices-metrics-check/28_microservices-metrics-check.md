# How to Check if Microservice Metrics Are Fit (Healthy)

> **What "fit" means:** A microservice is "fit" when its Four Golden Signals are within acceptable bounds — low error rate, acceptable latency, normal traffic, and resources not saturated. This guide covers every layer: from Prometheus/Dynatrace queries to kubectl commands to what numbers to look for.

---

## Decision Tree — "Is this microservice fit?"

```
Start here: is the service responding at all?
│
├─ GET /health returns 200?
│   NO  → Service is DOWN. Stop. Investigate pod crashes, not metrics.
│   YES → Continue.
│
├─ Error rate check: is error rate < 1%?
│   > 5%  → CRITICAL. Users impacted now. Investigate immediately.
│   1-5%  → DEGRADED. Elevated errors. Investigate.
│   < 1%  → ✓ Pass.
│
├─ Latency check: is P99 within SLO target?
│   > 2×  → DEGRADED. Users noticing slowness.
│   > SLO → BREACH. SLO is being consumed.
│   ≤ SLO → ✓ Pass.
│
├─ Traffic check: is traffic normal vs baseline?
│   Drop > 50% → Possible upstream failure or deployment issue.
│   Spike > 2×  → Load test? DDoS? Legitimate traffic surge?
│   Within ±20% → ✓ Pass.
│
├─ Saturation check: is CPU/memory/DB pool below limits?
│   > 80% sustained → Approaching limit. Scale before it fails.
│   > 90% sustained → CRITICAL. Will fail soon. Scale now.
│   < 80%           → ✓ Pass.
│
└─ All four ✓ → Service is FIT.
```

---

## The Four Golden Signals — Quick Reference

```
SIGNAL          WHAT TO MEASURE                  HEALTHY RANGE         ALERT THRESHOLD
──────────────  ───────────────────────────────  ────────────────────  ──────────────────────
Latency         P50, P95, P99 response time      P99 < SLO target      P99 > SLO for 5 min
Errors          HTTP 5xx rate (% of requests)    < 0.1%                > 1% for 3 min
Traffic         Requests per second              Within ±20% of base   Drop > 50% for 5 min
Saturation      CPU, memory, DB pool, queue      < 80% of limit        > 80% sustained 5 min
```

---

## SECTION 1: Check Using kubectl (Any Kubernetes Cluster)

### 1a. Is the pod running and healthy?

```bash
SERVICE="payment-service"
NAMESPACE="payment"

# Are pods Running? Any CrashLoopBackOff or Pending?
kubectl get pods -n $NAMESPACE -l app=$SERVICE
# EXPECTED: all pods STATUS=Running, READY=1/1 (or N/N)
# BAD: CrashLoopBackOff, Pending, OOMKilled, Error

# Detailed pod health (recent events at the bottom)
kubectl describe pod -n $NAMESPACE -l app=$SERVICE | tail -30

# Restart count — high restarts = recurring crash
kubectl get pods -n $NAMESPACE -l app=$SERVICE \
  -o custom-columns='NAME:.metadata.name,RESTARTS:.status.containerStatuses[0].restartCount,STATUS:.status.phase'
# BAD: RESTARTS > 3 in last hour = CrashLoopBackOff pattern

# Live resource usage: is the pod actually processing requests?
kubectl top pods -n $NAMESPACE -l app=$SERVICE
# Shows: CPU cores used, memory used
# COMPARE to: kubectl describe pod → resources.limits and resources.requests
```

### 1b. Is the service reachable inside the cluster?

```bash
# Does the service endpoint exist and have pod IPs registered?
kubectl get endpoints -n $NAMESPACE $SERVICE
# EXPECTED: ENDPOINTS column shows IP:port entries
# BAD: <none> = no healthy pods, selector mismatch, or pods not ready

# Test HTTP from inside the cluster (run a debug pod)
kubectl run -it --rm debug \
  --image=curlimages/curl:latest \
  --restart=Never \
  -n $NAMESPACE \
  -- curl -s http://$SERVICE/health
# EXPECTED: {"status":"ok"} or similar 200 response
# BAD: connection refused, timeout, 5xx response
```

### 1c. HPA status — is autoscaling working?

```bash
kubectl get hpa -n $NAMESPACE
# Columns: MINPODS, MAXPODS, REPLICAS, CPU, MEMORY
# BAD: REPLICAS = MAXPODS (at ceiling — HPA can't scale further)
# BAD: CPU shows <unknown> (metrics-server not working)
# BAD: TARGETS shows 0% despite traffic (metrics pipeline broken)

kubectl describe hpa -n $NAMESPACE $SERVICE
# Look for: "Warning FailedGetScale" or "Unable to fetch metrics"
```

---

## SECTION 2: Check Using Prometheus Queries (PromQL)

Run these in the Prometheus UI or Grafana. Replace `payment-service` with your service name.

### 2a. Error Rate

```promql
# HTTP 5xx error rate as percentage of total requests (last 5 minutes)
sum(rate(http_requests_total{job="payment-service", status=~"5.."}[5m]))
/
sum(rate(http_requests_total{job="payment-service"}[5m]))
* 100

# HEALTHY: result < 1
# DEGRADED: result 1–5
# CRITICAL: result > 5

# Error count per endpoint (find the worst endpoint)
sum by (handler) (
  rate(http_requests_total{job="payment-service", status=~"5.."}[5m])
) * 300
# (multiply by 300 = errors per 5 minutes per endpoint)
```

### 2b. Latency (Response Time Percentiles)

```promql
# P50 latency (median — half of users faster than this)
histogram_quantile(0.50,
  sum by (le) (
    rate(http_request_duration_seconds_bucket{job="payment-service"}[5m])
  )
) * 1000
# Unit: milliseconds

# P95 latency (95% of users faster than this)
histogram_quantile(0.95,
  sum by (le) (
    rate(http_request_duration_seconds_bucket{job="payment-service"}[5m])
  )
) * 1000

# P99 latency (99% of users faster than this) — most critical for SLO
histogram_quantile(0.99,
  sum by (le) (
    rate(http_request_duration_seconds_bucket{job="payment-service"}[5m])
  )
) * 1000

# HEALTHY: P99 < your SLO target (e.g., < 500ms)
# DEGRADED: P99 1-2× above SLO target
# CRITICAL: P99 > 2× SLO target

# Latency broken down by endpoint (find the slow endpoint)
histogram_quantile(0.99,
  sum by (le, handler) (
    rate(http_request_duration_seconds_bucket{job="payment-service"}[5m])
  )
) * 1000
```

### 2c. Traffic (Request Rate)

```promql
# Total requests per second right now
sum(rate(http_requests_total{job="payment-service"}[1m]))

# Compare to yesterday same time (baseline comparison)
sum(rate(http_requests_total{job="payment-service"}[5m]))
/
sum(rate(http_requests_total{job="payment-service"}[5m] offset 1d))
# Result: 1.0 = same as yesterday, 0.5 = 50% drop, 2.0 = double

# HEALTHY: within 0.8–1.2× yesterday's value
# INVESTIGATE: < 0.5× (traffic drop) or > 2× (traffic spike)

# Traffic broken down per HTTP status code
sum by (status) (rate(http_requests_total{job="payment-service"}[5m]))
```

### 2d. Saturation

```promql
# CPU usage as % of limit (pod level)
sum by (pod) (
  rate(container_cpu_usage_seconds_total{namespace="payment", container="payment-service"}[5m])
)
/
sum by (pod) (
  kube_pod_container_resource_limits{namespace="payment", container="payment-service", resource="cpu"}
)
* 100
# HEALTHY: < 70%
# WARNING: 70-85%
# CRITICAL: > 85%

# Memory usage as % of limit
sum by (pod) (
  container_memory_working_set_bytes{namespace="payment", container="payment-service"}
)
/
sum by (pod) (
  kube_pod_container_resource_limits{namespace="payment", container="payment-service", resource="memory"}
)
* 100
# HEALTHY: < 75%
# WARNING: 75-85%
# CRITICAL: > 85% → OOMKill likely soon

# DB connection pool saturation (custom metric, if your app exposes it)
ext:payment.db.pool.utilisation
# HEALTHY: < 0.7 (70%)
# WARNING: 0.7–0.85
# CRITICAL: > 0.85 → connection exhaustion imminent
```

### 2e. SLO Remaining Budget

```promql
# Availability SLO: % of successful requests over 30 days
(
  1 - (
    sum(increase(http_requests_total{job="payment-service", status=~"5.."}[30d]))
    /
    sum(increase(http_requests_total{job="payment-service"}[30d]))
  )
) * 100
# COMPARE TO SLO target (e.g., 99.9%)
# If result < SLO target: SLO is currently BREACHED

# Error budget remaining (how many more minutes you can afford to be down)
# For 99.9% SLO over 30 days: total budget = 43.2 minutes
(
  sum(increase(http_requests_total{job="payment-service"}[30d]))
  * (1 - 0.999)  # = 0.1% = budget fraction
  -
  sum(increase(http_requests_total{job="payment-service", status=~"5.."}[30d]))
)
/
sum(rate(http_requests_total{job="payment-service"}[5m]))
/ 60  # convert seconds to minutes
# Result: minutes of error budget remaining at current traffic volume
# < 0 = budget exhausted
```

---

## SECTION 3: Check Using Dynatrace (if using DT)

### 3a. Service-level health — quick check

```bash
DT_URL="https://abc12345.live.dynatrace.com"
DT_TOKEN="dt0c01.YOUR_TOKEN"

# Get open problems for a specific service
curl -s "${DT_URL}/api/v2/problems?problemSelector=impactedEntities(type(SERVICE),entityName(payment-service))&status=open" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  | jq '{total: .totalCount, problems: [.problems[] | {title, severity, startTime}]}'
# HEALTHY: totalCount = 0
# BAD:     any open problems

# Get current error rate for the service (last 5 minutes)
curl -s "${DT_URL}/api/v2/metrics/query?metricSelector=builtin:service.errors.total.rate:filter(tag(application:payment-service))&from=now-5m" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  | jq '.resolution.result[0].data[0].values[-1]'
# Result: decimal (0.02 = 2% error rate)

# Get P99 latency (microseconds — divide by 1000 for ms)
curl -s "${DT_URL}/api/v2/metrics/query?metricSelector=builtin:service.response.time:percentile(99):filter(tag(application:payment-service))&from=now-5m" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  | jq '.resolution.result[0].data[0].values[-1]'
# Result: microseconds. Divide by 1000 for milliseconds.

# Check SLO status
curl -s "${DT_URL}/api/v2/slo?nameFilter=payment-service" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  | jq '.slo[] | {name, status, errorBudget}'
# HEALTHY: status = "SUCCESS", errorBudget > 0
# BAD: status = "FAILURE" = SLO breached
```

---

## SECTION 4: The "Fit Check" Runbook — Run Before Any Deploy

```
Before deploying to production, verify the service is fit:

Step 1: Pod health (30 seconds)
  kubectl get pods -n $NAMESPACE -l app=$SERVICE
  → All Running, RESTARTS < 3
  
Step 2: Endpoint health (10 seconds)
  kubectl get endpoints -n $NAMESPACE $SERVICE
  → Has at least min_replicas pod IPs registered
  
Step 3: Error rate (check last 15 minutes)
  Prometheus: sum(rate(http_requests_total{job="$SERVICE", status=~"5.."}[5m])) / sum(rate(http_requests_total{job="$SERVICE"}[5m])) * 100
  → < 1%
  
Step 4: P99 latency (check last 15 minutes)
  Prometheus: histogram_quantile(0.99, sum by (le) (rate(http_request_duration_seconds_bucket{job="$SERVICE"}[5m]))) * 1000
  → Below SLO target (e.g., < 500ms)
  
Step 5: Saturation (check last 15 minutes)
  kubectl top pods -n $NAMESPACE -l app=$SERVICE
  → CPU < 70% of limit, Memory < 75% of limit
  
Step 6: HPA status (is there headroom to scale?)
  kubectl get hpa -n $NAMESPACE
  → REPLICAS < MAXPODS (not at ceiling)
  
Step 7: SLO budget (is there budget to absorb a risky deploy?)
  Dynatrace or Prometheus SLO query
  → Budget remaining > 20% = proceed
  → Budget remaining < 20% = consider postponing risky deploy

ALL PASS → Service is fit, safe to deploy.
ANY FAIL → Fix the existing issue before deploying.
```

---

## SECTION 5: Common "Not Fit" Patterns and Their Meaning

```
PATTERN                            WHAT IT MEANS                  WHERE TO LOOK
──────────────────────────────────  ─────────────────────────────  ───────────────────────
Error rate spike at exact deploy   New version introduced bug     ArgoCD deployment event + pod logs
P99 spike without error rate spike Service is slow, not failing   DB connection pool, slow queries
Traffic drop to near zero          Service unreachable or down    ALB target group health, DNS
Memory climbing linearly           Memory leak                    Memory trend over 24h
CPU at 100% continuously           Needs more replicas or CPUs    HPA ceiling, Compute Optimizer
Restarts every 10–15 minutes       App crashing on memory limit   kubectl describe pod → OOMKilled
Endpoints showing 0 pods           All pods NotReady              Readiness probe failing
P50 normal but P99 very high       Long tail problem              Slowest endpoint breakdown
```

---

## SECTION 6: Quick One-Liner Health Check Script

```bash
#!/usr/bin/env bash
# Run this to get a quick "fit" summary for any service
SERVICE=${1:-"payment-service"}
NAMESPACE=${2:-"payment"}

echo "=== MICROSERVICE FIT CHECK: $SERVICE ==="
echo ""

echo "--- Pod Status ---"
kubectl get pods -n $NAMESPACE -l app=$SERVICE \
  -o custom-columns='NAME:.metadata.name,STATUS:.status.phase,READY:.status.containerStatuses[0].ready,RESTARTS:.status.containerStatuses[0].restartCount'

echo ""
echo "--- Resource Usage ---"
kubectl top pods -n $NAMESPACE -l app=$SERVICE 2>/dev/null || echo "(metrics-server not available)"

echo ""
echo "--- HPA Status ---"
kubectl get hpa -n $NAMESPACE 2>/dev/null | grep -E "NAME|$SERVICE" || echo "(no HPA found)"

echo ""
echo "--- Endpoints ---"
kubectl get endpoints -n $NAMESPACE $SERVICE

echo ""
echo "--- Recent Events ---"
kubectl get events -n $NAMESPACE --sort-by='.lastTimestamp' | grep -i "$SERVICE\|warning" | tail -5

echo ""
echo "=== CHECK COMPLETE ==="
echo "Next: check error rate + latency + SLO in Prometheus/Dynatrace"
```
