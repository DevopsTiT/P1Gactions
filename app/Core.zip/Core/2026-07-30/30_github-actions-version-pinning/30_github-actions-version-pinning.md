# GitHub Actions `@v4` Version Pinning — Deep Dive

---

## The Single Line That Hides a Lot of Complexity

```yaml
- uses: actions/checkout@v4
```

That `@v4` is a Git reference. It looks simple. Behind it is a versioning system, a security model, and a set of trade-offs you need to understand.

---

## What `@v4` Actually Means

When you write `actions/checkout@v4`, GitHub does this:

```
1. Go to github.com/actions/checkout repository
2. Find the Git tag named "v4"
3. Check out that tag's commit SHA
4. Run that code on the runner
```

**The critical point:** `v4` is a **mutable tag**. The repository owner (the `actions` org in this case) can move the `v4` tag to a different commit at any time.

```
Today:     v4 tag → commit abc123 (safe, working code)
Tomorrow:  v4 tag → commit def456 (bug fix added, or breaking change, or compromised)
```

Your workflow says `@v4` but it might be running different code tomorrow than today.

---

## The Four Ways to Pin an Action

```yaml
# Option 1: Major version tag — MOST COMMON
- uses: actions/checkout@v4
# Resolves to: latest v4.x.y (tag is mutable)
# Risk: minor or patch updates could introduce breaking changes
# Benefit: automatically gets bug fixes and security patches

# Option 2: Minor version tag — UNCOMMON
- uses: actions/checkout@v4.1.7
# Resolves to: exactly v4.1.7 (still a mutable tag — can be moved)
# Risk: smaller attack surface than @v4, but tag can still be moved
# Benefit: more stable than @v4

# Option 3: Full commit SHA — MOST SECURE
- uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683
# Resolves to: exactly this commit, always, forever (immutable)
# Risk: none — this exact code runs regardless of what tags point to
# Benefit: guaranteed reproducibility; protects against tag manipulation attacks
# Drawback: you must manually update the SHA to get security patches

# Option 4: Branch name — WORST OPTION
- uses: actions/checkout@main
# Resolves to: whatever is on main right now
# Risk: every run could execute completely different code
# Benefit: none
# Do not use this in production
```

---

## Why `@v4` (Not `@v4.1.7`, Not SHA)

### The Practical Reality

Action maintainers (GitHub, Docker, AWS) maintain **rolling major version tags**. When they release v4.1.8, they:

1. Create a `v4.1.8` tag at the new commit
2. Move the `v4` tag to point to the same commit

This means `@v4` **always resolves to the latest v4.x.y release**. The maintainers promise:
- v4.x.y → NO breaking changes within the v4 major version
- v5.0.0 → breaking changes (they use a new major version number)

```
v4.0.0 → v4 tag
v4.1.0 → v4 tag moves here
v4.1.7 → v4 tag moves here
v4.2.0 → v4 tag moves here  ← @v4 always points here
v5.0.0 → v5 tag (NOT v4 — breaking change)
```

### The Semantic Versioning Promise

For well-maintained actions like `actions/checkout`, `aws-actions/configure-aws-credentials`, `docker/build-push-action`:

```
MAJOR (v4 → v5): Breaking changes — you must update your workflow deliberately
MINOR (v4.1 → v4.2): New features, backward compatible
PATCH (v4.1.7 → v4.1.8): Bug fixes and security patches
```

Using `@v4` means: "give me all bug fixes and security patches automatically, but don't break my workflow."

---

## How GitHub Resolves the Reference

```
actions/checkout@v4

Step 1: GitHub looks up the `actions/checkout` repository
Step 2: Searches for a ref named "v4"
   → Is it a tag? Yes → use the commit the tag points to
   → Is it a branch? No
   → Is it a SHA? No (too short to be SHA)
Step 3: Fetches the ACTIONS metadata from that commit
Step 4: Downloads the JavaScript bundle (most actions are compiled JS)
Step 5: Runs the action in the sandboxed runner environment
```

You can verify what SHA `@v4` currently resolves to:

```bash
# Check what commit v4 currently points to for any action
gh api repos/actions/checkout/git/ref/tags/v4 \
  --jq '.object.sha'

# For actions that use annotated tags (which point to tag objects, not commits):
gh api repos/actions/checkout/git/ref/tags/v4 \
  --jq '.object.url' | \
  xargs -I{} gh api {} --jq '.object.sha'

# You can also check the full list of v4.x.y releases
gh api repos/actions/checkout/releases \
  --jq '[.[] | select(.tag_name | startswith("v4")) | {tag: .tag_name, published: .published_at}]' | \
  head -20
```

---

## The Security Consideration: SHA Pinning

For security-critical workflows (especially those with `id-token: write` or `contents: write`), some teams pin to exact SHAs:

```yaml
# Instead of:
- uses: actions/checkout@v4

# Use the full commit SHA:
- uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683  # v4.2.2
```

**Why this matters:** If an attacker compromises the `actions/checkout` repository and moves the `v4` tag to malicious code:
- `@v4` workflows: run the malicious code on next execution
- `@SHA` workflows: still run the original safe code (immutable)

**The trade-off:**
- SHA pinning = maximum security, but you must manually update to get bug fixes
- `@v4` = automatic security patches, but trusts the maintainer never moves the tag maliciously

For most teams, `@v4` is acceptable for well-known, trusted actions (GitHub's own, major cloud providers). SHA pinning is used for highly sensitive pipelines.

---

## The `.github/workflows` Lock File Pattern (Dependabot)

GitHub's Dependabot can automatically open PRs to update action versions:

```yaml
# .github/dependabot.yml
version: 2
updates:
  - package-ecosystem: "github-actions"
    directory: "/"
    schedule:
      interval: "weekly"
    # This automatically opens PRs like:
    # "Bump actions/checkout from 4.1.7 to 4.2.2"
```

With Dependabot:
1. You pin to `@v4` (or even `@v4.1.7`)
2. Dependabot opens a PR when v4.1.8 is released
3. You review the PR (changelog, no breaking changes)
4. You merge → workflow uses v4.1.8

This gives you the security of explicit version control with the convenience of automatic update notifications.

---

## In the `app-ci.yaml` File — Every Action Explained

```yaml
- uses: actions/checkout@v4
# Why @v4: GitHub-maintained, high-trust, semantic versioning guaranteed.
# v4 introduced sparse checkout and improved performance over v3.
# Breaking change from v3 → v4: different default fetch-depth behaviour.

- uses: actions/setup-python@v5
# Why @v5: supports Python 3.12, improved caching, faster setup.
# v5 introduced better pip cache integration.

- uses: aws-actions/configure-aws-credentials@v4
# Why @v4: OIDC support was stable in v4. v3 had OIDC but with bugs.
# AWS publishes this action; high-trust source.

- uses: aws-actions/amazon-ecr-login@v2
# Why @v2: current major version for ECR login with IAM credential support.

- uses: docker/setup-buildx-action@v3
# Why @v3: supports BuildKit 0.12+ features needed for multi-arch builds.

- uses: docker/build-push-action@v5
# Why @v5: supports gha cache type, improved provenance attestation.
# v4 → v5 had breaking changes in the cache input format.

- uses: aquasecurity/trivy-action@master
# ⚠️ THIS IS DANGEROUS — @master is a branch name, not a version tag
# Every run could execute different code as main is updated
# Safer alternative: aquasecurity/trivy-action@0.28.0 (pinned version)
# The project should fix this to use a version tag or SHA.
```

**The `@master` issue in Trivy:**
```yaml
# Current (risky):
- uses: aquasecurity/trivy-action@master

# Better (version tag):
- uses: aquasecurity/trivy-action@0.28.0

# Best (SHA pinned):
- uses: aquasecurity/trivy-action@18b2cbea2fb42571d30b7f889ae66c87bd4e4041  # v0.28.0
```

---

## What Happens When You Run a Workflow — the Resolution Timeline

```
1. Developer pushes to main
        │
2. GitHub sees workflow trigger matches
        │
3. GitHub reads .github/workflows/app-ci.yaml
        │
4. For each "uses: action@ref":
        ├── actions/checkout@v4
        │       → fetch current SHA of tag v4
        │       → today: abc123 (this could change tomorrow)
        │       → download and run the JS bundle at that SHA
        │
        ├── aws-actions/configure-aws-credentials@v4
        │       → fetch current SHA of tag v4
        │       → download and run
        │
        └── aquasecurity/trivy-action@master
                → fetch current SHA of branch master
                → THIS IS RESOLVED FRESH EVERY RUN
                → dangerous: could be different code each time
        │
5. Execute each step in sequence
```

---

## Summary: When to Use Each Pinning Style

| Use case | Recommended pinning | Reason |
|---|---|---|
| Standard CI pipeline | `@v4` | Automatic security patches from trusted maintainers |
| Security-critical pipeline (OIDC, secrets) | `@SHA` | Protects against compromised action repository |
| Internal/private actions | `@v1.2.3` explicit | You control the versioning, be explicit |
| Development/testing | `@main` | Acceptable for local experimentation only |
| Production (NEVER) | `@main` or `@latest` | Branch names are mutable, unpredictable |

**The one rule:** Never use `@main`, `@master`, or `@latest` in production workflows. Always use a version tag or SHA.
