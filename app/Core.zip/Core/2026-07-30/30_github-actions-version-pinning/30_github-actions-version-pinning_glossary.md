# GitHub Actions Version Pinning — Glossary

**`uses` (GitHub Actions)**
A step field that references an external action to run. Format: `owner/repo@ref`. The action's code is downloaded from GitHub and executed in the runner. Examples: `actions/checkout@v4`, `docker/build-push-action@v5`.

**Git ref**
A pointer to a specific commit in a Git repository. Can be a branch name (like `main`), a tag (like `v4`), or a full commit SHA (like `abc123...`). The `@` in `actions/checkout@v4` is followed by a Git ref.

**Git tag**
A named pointer to a specific commit. Unlike branches, tags are typically not moved. However, **mutable tags** (like `v4`) CAN be moved by the repository owner to point to a newer commit. Immutable refers to the tag being locked — not all tags are immutable.

**Mutable tag**
A Git tag that the repository owner can move to point to a different commit. The `v4` major version tag is mutable — when `v4.2.0` is released, the `v4` tag is moved to the new commit. Your workflow runs new code without changing your YAML.

**Immutable commit SHA**
A 40-character hexadecimal string (like `11bd71901bbe5b1630ceea73d27597364c9af683`) uniquely identifying a specific commit. Cannot be changed — that commit's code is fixed forever. SHA pinning guarantees your workflow runs identical code on every execution.

**SHA pinning**
Using a full commit SHA instead of a version tag in `uses`. Example: `actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683`. Protects against an attacker moving a version tag to malicious code. Requires manual updates to get security patches.

**Semantic Versioning (SemVer)**
A versioning scheme: `MAJOR.MINOR.PATCH`. MAJOR version bump = breaking changes (users must update deliberately). MINOR = new backward-compatible features. PATCH = bug fixes and security patches. Actions use this: `v4` promises no breaking changes within v4.x.

**Rolling major version tag**
The convention where maintainers keep a tag like `v4` pointing to the latest `v4.x.y` release. When `v4.1.8` is released, the `v4` tag moves to that commit. Users pinned to `@v4` automatically run the latest bug fixes without changing their YAML.

**`@v4` vs `@v4.1.7` vs `@SHA`**
Three levels of pinning precision. `@v4` = automatic minor/patch updates (less control). `@v4.1.7` = specific version, no automatic updates (still a mutable tag). `@SHA` = exact immutable commit (maximum control, maximum maintenance burden).

**`@main` / `@master` (branch name)**
Using a branch name as the `@ref`. The most dangerous option — the branch advances with every new commit, so your workflow runs different code on every execution with no visibility or control. Never use in production.

**Supply chain attack**
A security attack where malicious code is introduced via a dependency (in this case, an action). If an attacker compromises the `docker/build-push-action` repository and moves the `@v5` tag to malicious code, workflows using `@v5` would execute the attacker's code with full access to secrets and tokens.

**Dependabot**
GitHub's automated dependency update service. Configured via `.github/dependabot.yml`. Opens pull requests when newer versions of actions are available. Enables a workflow like: pin to `@v4`, Dependabot notifies when v4.1.8 is released, you review and merge.

**`id-token: write` (permission)**
A GitHub Actions job permission that allows requesting an OIDC token. With this permission enabled, a compromised action could steal the OIDC token and assume AWS IAM roles. This is why SHA pinning matters most for jobs that use OIDC.

**Action (GitHub Actions)**
A reusable unit of work in a GitHub Actions workflow. Published to GitHub Marketplace or any public repository. When `uses: actions/checkout@v4` is in your workflow, GitHub downloads that action's code and runs it in your runner.

**Runner**
The virtual machine that executes a GitHub Actions job. `ubuntu-latest` = Ubuntu Linux. The runner is ephemeral — it is created for a job and destroyed after. Actions run in a sandboxed environment on the runner.

**JavaScript bundle**
Most GitHub Actions are compiled into a single `.js` file that runs directly in Node.js on the runner. When you reference `actions/checkout@v4`, GitHub downloads and executes this compiled JS. This is why checking the `dist/` folder in an action's repository shows the actual executable code.

**Annotated tag vs lightweight tag**
Two types of Git tags. Lightweight tags directly point to a commit. Annotated tags point to a tag object, which points to a commit (one extra indirection). Many GitHub Actions use annotated tags. The resolution is: `v4` → tag object → commit SHA.

**`.github/dependabot.yml`**
Configuration file for GitHub's Dependabot. For `package-ecosystem: "github-actions"`, Dependabot scans workflow files and opens PRs when actions have newer versions. Enables automatic notification of updates without automatic application.

**`@master` in Trivy action (the bug)**
The `aquasecurity/trivy-action@master` reference in the project's `app-ci.yaml` is a risky choice. `master` is a branch name — every run might execute different code as Trivy's main branch advances. The safe alternative is pinning to a release tag like `@0.28.0` or a SHA.

**`gh api` (GitHub CLI)**
A command-line tool for interacting with the GitHub API. `gh api repos/actions/checkout/git/ref/tags/v4` resolves what commit SHA the `v4` tag currently points to — useful for verifying which version your workflow is actually running.
