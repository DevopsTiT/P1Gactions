# Dev → Staging → Production Promotion: Complete Guide

> **Goal:** Take the entire `16_eks-dynatrace-gitops-revised` project and add a proper dev → staging → production pipeline. Test everything in dev first, promote to staging, then production. Every file is changed.

---

## The Architecture: Three Environments, One Codebase

```
Git Repository Structure (AFTER this change):
  ├── app/                          ← same code for all envs (image tag changes)
  ├── charts/                       ← same Helm templates for all envs (values differ)
  │
  ├── gitops/
  │   ├── dev/                      ← NEW: ArgoCD apps for dev environment
  │   ├── staging/                  ← NEW: ArgoCD apps for staging environment
  │   ├── production/               ← MOVED: existing gitops/ → production/
  │   └── bootstrap/                ← root-app now points to env-specific folders
  │
  ├── terraform/
  │   ├── environments/
  │   │   ├── dev/                  ← NEW: dev AWS infra (tfvars)
  │   │   ├── staging/              ← NEW: staging AWS infra (tfvars)
  │   │   └── production/           ← NEW: production AWS infra (tfvars)
  │   ├── modules/                  ← SAME: reused by all envs
  │   └── dynatrace/                ← SAME: but called 3 times with different vars
  │
  └── .github/workflows/
      ├── app-ci.yaml               ← REVISED: promotes dev→staging→prod
      ├── terraform-infra.yaml      ← REVISED: per-environment apply
      └── terraform-dynatrace.yaml  ← REVISED: per-environment DT config

THREE AWS ACCOUNTS:
  dev account:         123456789010  (one EKS cluster: company-dev)
  staging account:     123456789011  (one EKS cluster: company-staging)
  production account:  123456789012  (one EKS cluster: company-prod)

WHY SEPARATE ACCOUNTS:
  An IAM mistake in dev cannot affect production.
  A Terraform error in dev cannot touch production state.
  Cost reports are clean per environment.
  SCPs can be applied differently per account (dev = more permissive).
```

---

## Promotion Flow: Step by Step

```
STEP 1: Developer merges PR to main
          │
          ▼
STEP 2: app-ci.yaml: tests pass → build image → push to DEV ECR
          │
          ▼
STEP 3: Update gitops/dev/app/ image tag
          ArgoCD (dev cluster) deploys to dev EKS
          │
          ▼
STEP 4: Integration tests run against dev (automated smoke tests)
          │  SUCCESS ──────────────────────────────────────────┐
          │  FAILURE: stops here, Slack alert, no promotion    │
          ▼                                                     │
STEP 5: Promote image to staging                              │
          Update gitops/staging/app/ image tag  ←─────────────┘
          ArgoCD (staging cluster) deploys
          │
          ▼
STEP 6: Staging tests pass (automated + manual QA)
          │  SUCCESS (with manual approval gate) ──────────────┐
          │  FAILURE: stops here                               │
          ▼                                                     │
STEP 7: Promote image to production ←──────────────────────────┘
          Update gitops/production/app/ image tag
          ArgoCD (production cluster) deploys (rolling update)
          │
          ▼
STEP 8: Production smoke tests pass
          Dynatrace monitors for error rate spike (auto-rollback trigger)
```

---

## File Changes Summary

### What changes vs the original project

```
CHANGED FILES:
  .github/workflows/app-ci.yaml              ← 3-stage promotion pipeline
  .github/workflows/terraform-infra.yaml     ← per-environment matrix
  .github/workflows/terraform-dynatrace.yaml ← per-environment DT config

NEW FILES:
  terraform/environments/dev/terraform.tfvars
  terraform/environments/staging/terraform.tfvars
  terraform/environments/production/terraform.tfvars
  terraform/environments/dev/backend.tf
  terraform/environments/staging/backend.tf
  terraform/environments/production/backend.tf

  gitops/dev/bootstrap/root-app-dev.yaml
  gitops/dev/namespaces/namespaces.yaml
  gitops/dev/app/payment-service/payment-service.yaml
  gitops/dev/networking/aws-load-balancer-controller.yaml
  gitops/dev/networking/external-dns.yaml
  gitops/dev/secrets/external-secrets/external-secret-operator.yaml
  gitops/dev/secrets/external-secrets/cluster-secret-store.yaml
  gitops/dev/monitoring/dynatrace/dynatrace-operator.yaml
  gitops/dev/auto-scaling/karpenter/karpenter.yaml

  gitops/staging/ (same structure as dev, different values)
  gitops/production/ (same structure, moved from gitops/)
  
  charts/payment-service/values-dev.yaml
  charts/payment-service/values-staging.yaml
  (existing values.yaml becomes values-production.yaml)

UNCHANGED:
  app/                  ← same code runs in all environments
  charts/templates/     ← same Helm templates, different values
  terraform/modules/    ← same modules, called with different vars
  terraform/dynatrace/  ← same DT resources, different thresholds
```

---

## Verification Commands Per Stage

```bash
# ── DEV VERIFICATION ─────────────────────────────────────────────────────
# After ArgoCD deploys to dev:

# 1. Check all pods healthy
kubectl get pods -A --context company-dev | grep -v Running | grep -v Completed

# 2. Hit the dev health endpoint
curl -s https://payment.dev.company.com/health/ready | python3 -m json.tool
# Expected: {"status": "ready"}

# 3. Run smoke test
pytest app/tests/integration/ \
  --base-url=https://payment.dev.company.com \
  -v --tb=short
# Must pass 100% before staging promotion

# 4. Check Dynatrace dev: no new problems in last 10 minutes
DT_URL="https://dev-tenant.live.dynatrace.com"
curl -s "$DT_URL/api/v2/problems?problemSelector=status%3AOPEN&from=now-10m" \
  -H "Authorization: Api-Token $DT_DEV_TOKEN" | \
  python3 -c "import json,sys; d=json.load(sys.stdin); print(f'Open problems: {d[\"totalCount\"]}')"

# ── STAGING VERIFICATION ──────────────────────────────────────────────────
# After promotion to staging:

# 1. Health check
curl -s https://payment.staging.company.com/health/ready

# 2. Load test (k6)
k6 run --vus 50 --duration 5m tests/load/payment-load-test.js \
  --env BASE_URL=https://payment.staging.company.com
# Check: p99 latency < 500ms, error rate < 0.1%

# 3. Dynatrace staging: SLO compliance after load test
curl -s "$DT_STAGING_URL/api/v2/slo?from=now-30m" \
  -H "Authorization: Api-Token $DT_STAGING_TOKEN" | \
  python3 -c "
import json,sys
data = json.load(sys.stdin)
for slo in data.get('slo', []):
    status = '✅' if slo['status'] == 'SUCCESS' else '❌'
    print(f\"{status} {slo['name']}: {slo['evaluatedPercentage']:.3f}%\")
"

# ── PRODUCTION VERIFICATION ───────────────────────────────────────────────
# After production deployment:

# 1. Rolling update completion
kubectl rollout status deployment/payment-service \
  -n payment-ns --context company-prod --timeout=10m

# 2. Production health + version check
curl -s https://payment.company.com/health/ready
# Confirm image tag matches deployed SHA

# 3. Watch error rate for 5 minutes post-deploy
watch -n 30 'curl -s "https://prod-tenant.live.dynatrace.com/api/v2/metrics/query?metricSelector=builtin:service.errors.server.rate:filter(eq(service.name,payment-service))&from=now-5m" \
  -H "Authorization: Api-Token $DT_PROD_TOKEN" | python3 -m json.tool'
```

---

## Environment Configuration Differences

```
                    DEV             STAGING         PRODUCTION
─────────────────────────────────────────────────────────────────
AWS Account         123456789010    123456789011    123456789012
Cluster Name        company-dev     company-staging company-prod
Node Instance       t3.medium       m7g.large       m7g.xlarge
Min Nodes           1               2               3
Replicas            1               2               3
HPA Max             5               10              20
PDB Min             0               1               2
Memory Limit        256Mi           512Mi           1Gi
Karpenter           disabled        enabled         enabled
Endpoint Access     public          public          private (VPN)
DT Alert Tiers      warning+info    high+warning    all 4 tiers
PagerDuty           NO              NO              YES
SLO Target          99.0%           99.5%           99.9%
Latency Alert       2000ms          1000ms          300ms
Error Rate Alert    5.0%            1.0%            0.1%
```
