# Glossary — Dev → Staging → Production Promotion

Every term in the promotion guide, explained for an SRE beginner.

---

**Environment promotion**
Moving a tested artifact (Docker image, Terraform config) from a lower environment (dev) to a higher one (staging → production). The same image that passed dev tests is promoted — not rebuilt. Guarantees what you test is what you deploy.

**GitHub Environment (with approval gate)**
A GitHub Actions feature. When a job uses `environment: production`, GitHub pauses the workflow and sends a notification to configured reviewers. The workflow only continues after a human clicks "Approve." Used as the manual gate before production deployments.

**Image promotion (ECR to ECR)**
Copying a Docker image from one account's ECR to another account's ECR using `docker pull` → `docker tag` → `docker push`. The image digest (SHA256 hash) is identical — no rebuild. Proves the exact tested bits are deployed.

**Multi-account strategy (dev/staging/prod)**
Using separate AWS accounts for each environment. An IAM mistake in dev cannot affect production. Cost reports are clean per environment. SCPs can be different per account. Industry standard for enterprise AWS organisations.

**terraform.tfvars**
A file containing variable values for a specific Terraform workspace run. `terraform apply -var-file=dev.tfvars` uses dev settings. `-var-file=production.tfvars` uses production settings. Same Terraform code, different values per environment.

**backend.tf (partial)**
When used with `-backend-config=`, specifies only the S3 bucket and key (not the full backend block). Allows the same `terraform/` code to use different state buckets for dev, staging, and production.

**matrix strategy (GitHub Actions)**
Runs the same job multiple times in parallel with different input values. `matrix: environment: [dev, staging, production]` creates 3 jobs: one per environment. All plans run simultaneously — faster CI feedback.

**fail-fast: false**
In a matrix strategy, controls whether all matrix jobs stop if one fails. `fail-fast: false` means: even if the dev plan fails, the staging and production plans still run. You see all environment diffs at once.

**needs: (GitHub Actions)**
Declares a dependency between jobs. `needs: apply-dev` means: this job waits until `apply-dev` completes successfully before starting. Creates sequential deployment: dev → staging → prod.

**smoke test**
A minimal set of automated tests that verify the most critical paths work after deployment. Not exhaustive — just enough to confirm the service is alive and handling basic requests. Runs after every deployment before promotion.

**integration test**
Tests that verify the service works correctly with its real dependencies (database, other services). Run against the deployed environment, not mocked. More thorough than smoke tests.

**load test (k6)**
A test that simulates many concurrent users hitting the service. k6 is an open-source load testing tool. Parameters: VUs (virtual users = concurrent connections), duration. Results: p99 latency, error rate, throughput. Run in staging to validate capacity.

**VUs (Virtual Users)**
The number of concurrent simulated users in a load test. 50 VUs = 50 simultaneous HTTP connections. More VUs = more load on the service.

**auto-rollback**
Automatic reversion to the previous version if post-deployment tests fail. The CI pipeline reads the previous image tag from git history, updates the gitops file, and commits — triggering ArgoCD to roll back without human intervention.

**single_nat_gateway = true**
A Terraform VPC module option that creates only ONE NAT Gateway for the entire VPC (shared by all AZs). Cheaper than per-AZ NAT but a single point of failure. Acceptable in dev (cost saving). Unacceptable in production (AZ failure kills all outbound internet).

**pullPolicy: Always vs IfNotPresent**
Kubernetes image pull policy. `Always`: pulls the image from ECR on every pod start (ensures latest). `IfNotPresent`: only pulls if the image is not already on the node (cached). Dev uses `Always` for fast iteration with `:latest-dev` tags. Production uses `IfNotPresent` with pinned SHA tags.

**podAntiAffinity: preferred vs required**
`required` (production): hard rule — scheduler REFUSES to put two pods on the same node. `preferred` (staging): soft rule — scheduler tries to spread but will co-locate if no other option. Staging uses preferred because it has fewer nodes and can't always satisfy a hard rule.

**topologySpread: enabled: false (dev)**
Disabling topology spread constraints in dev because dev has only 1 replica and 1 node. A topologySpread constraint with 1 replica is meaningless, and constraints on a single node would cause pods to stay Pending (can't spread if there's nowhere to spread to).

**LOG_LEVEL: DEBUG vs INFO**
The verbosity of application logs. `DEBUG` prints every function call, variable state, database query — very detailed. `INFO` prints only significant events. Dev uses DEBUG for troubleshooting. Production uses INFO (DEBUG logs are expensive at scale and fill up storage).

**environment-specific resource limits**
Dev: smaller limits (256Mi) = cheaper on t3.medium. Staging: medium limits (512Mi) = handles load test. Production: full limits (1Gi) = handles real user traffic. Sized by testing in each environment.

**[skip ci] tag**
A commit message suffix that tells GitHub Actions not to trigger CI for that commit. Used when the pipeline commits the updated image tag back to Git — prevents an infinite CI loop (commit → trigger CI → commit → trigger CI...).

**valuesFiles (Helm)**
A Helm feature that merges multiple values files. `values.yaml` contains defaults; `values-dev.yaml` contains dev overrides; only the overriding fields need to be in the env-specific file. ArgoCD supports this via `helm.valueFiles`.

**PagerDuty: disabled in dev/staging**
Dev and staging environments should NOT page on-call engineers. Problems there are expected (testing, iteration). The `pagerduty_integration_keys = {}` empty map in dev/staging tfvars means no PagerDuty notifications are created. Only production creates them.

**SLO target: 99.0% dev, 99.5% staging, 99.9% production**
The availability target increases as you get closer to real users. Dev: 99.0% (failures expected during development). Staging: 99.5% (should handle load tests). Production: 99.9% (real users, real money, maximum reliability required).

**txtOwnerId per environment**
Each ExternalDNS instance needs a unique owner ID. `company-dev`, `company-staging`, `company-prod`. Without this: the staging ExternalDNS might delete production DNS records (they might share the same Route53 zone for different subdomains).

**account_id per environment**
Each environment runs in a completely separate AWS account. Dev: `123456789010`. Staging: `123456789011`. Production: `123456789012`. Separate accounts = separate IAM, separate billing, separate blast radius. A security issue in dev cannot reach production.

**GitHub Environment (dev/staging/production)**
Configured in: Repo Settings → Environments. Each environment can have: required reviewers (approval gates), protection rules (only certain branches can deploy), deployment history, and environment-specific secrets. Production environment requires explicit approval by SRE lead.

**Deployment pipeline pause (waiting for approval)**
When a GitHub Actions job uses `environment: production` and the environment has required reviewers, the entire workflow pauses. An email/Slack notification goes to the approvers. They see the job context (which image, which tests passed) and click Approve or Reject. The workflow only continues on approval.

**ECR per account**
Each AWS account has its own Elastic Container Registry. Dev ECR: holds dev images. Staging ECR: holds images promoted from dev. Production ECR: holds images promoted from staging. IMMUTABLE tag policy on all: once pushed, cannot be overwritten.

**k6 load test thresholds**
k6 can be configured to fail (exit code 1) if thresholds are exceeded. Common thresholds: `p99 < 1000ms` (99% of requests under 1 second), `rate[error_rate] < 0.01` (error rate under 1%). If the load test exceeds these: CI job fails, staging promotion blocked.
