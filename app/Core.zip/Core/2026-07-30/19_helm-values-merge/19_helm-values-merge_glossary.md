# Helm Values Merge — Glossary

**`values.yaml` (chart defaults)**
The default configuration file that lives inside the Helm chart folder. Contains safe, minimal settings — most optional features disabled. Anyone can install the chart without extra config and get a working result. Think of it as the "factory settings."

**`helm.values` (ArgoCD override)**
The inline values block inside an ArgoCD ApplicationSet or Application. Overrides specific keys from `values.yaml` for a particular environment (production, staging, etc.). Only sets the fields that differ from defaults — everything else inherits from `values.yaml`.

**Helm values merge**
Helm always loads `values.yaml` first, then applies overrides on top. Overrides WIN on any key they set; defaults FILL IN every key not in the override. It is a deep merge — overriding `image.tag` does not wipe out `image.repository` or `image.pullPolicy`.

**Deep merge**
When merging two YAML objects, a deep merge updates only the specific keys that exist in the override, preserving all other keys from the original. Opposite of "replace", which would wipe out the entire block.

**ArgoCD ApplicationSet**
An ArgoCD object that generates multiple Application objects from a template and a generator (one per cluster). The `spec.template.spec.source.helm.values` block is the production override for every generated Application.

**Helm chart**
A package of Kubernetes YAML templates that render to real resources when given values. The `charts/simple-time-service/` folder is a Helm chart. `values.yaml` is its configuration contract.

**`helm template`**
A local command that renders a Helm chart to plain YAML without deploying it. Useful for inspecting what ArgoCD will actually apply to the cluster: `helm template charts/simple-time-service --values values.yaml --set key=value`.

**`nodeSelector`**
A Kubernetes field on a pod spec that constrains which nodes the pod can schedule on. `nodeSelector: app: workload` means: only schedule on nodes with the label `app=workload`. The production override adds this so app pods run on Karpenter workload nodes, not on the core platform nodes.

**taint (Kubernetes)**
A property on a Kubernetes node that repels pods. `app=workload:NoSchedule` means: NO pod can schedule on this node unless it has a matching toleration. Core nodes have `app=core:NoSchedule` and workload nodes have `app=workload:NoSchedule`.

**toleration (Kubernetes)**
A property on a pod that allows it to schedule on a tainted node. The production override adds `tolerations: [{key: app, value: workload, effect: NoSchedule}]` so the app pod CAN land on workload nodes.

**Core nodes (managed node group)**
The fixed EC2 instances in the EKS cluster that run platform components (ArgoCD, Prometheus, Kyverno). Have taint `app=core:NoSchedule`. Application pods do not tolerate this taint and cannot schedule here.

**Workload nodes (Karpenter)**
Nodes provisioned on-demand by Karpenter for application workloads. Labelled `app=workload` with matching taint. Karpenter creates and destroys these nodes based on pod demand. App pods must declare `nodeSelector: app: workload` to land here.

**`ingress.enabled: false` (default)**
The chart default disables Ingress creation. Without this safeguard, installing the chart on a cluster without an ALB controller would create a broken Ingress that stays Pending forever.

**`serviceMonitor.enabled: false` (default)**
The chart default disables Prometheus ServiceMonitor creation. If enabled on a cluster without Prometheus Operator, the apply fails because the `ServiceMonitor` CRD doesn't exist.

**`hpa.enabled: false` (default)**
The chart default disables HPA creation. If enabled on a cluster without `metrics-server`, the HPA exists but never scales because it can't get CPU metrics.

**`image.tag: v1` vs `image.tag: latest`**
`values.yaml` defaults to `v1` (a stable, pinned build). The ArgoCD override sets `latest` (always the newest pushed image). This means production always runs the freshest build, while a local `helm install` without overrides gets a known-stable version.

**`helm get values`**
A command to see the values currently applied to a deployed Helm release. `--all` shows the full merged result including defaults. Useful for verifying what ArgoCD actually deployed.
