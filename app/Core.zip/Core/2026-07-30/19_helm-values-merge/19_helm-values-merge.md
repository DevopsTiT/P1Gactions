# Why Payment-Service Has Two Sets of Values — and Which One Wins

> **Short answer:** There are always two sets of Helm values in this pattern. The chart's `values.yaml` is the **default baseline** (safe, minimal, disabled features). The ArgoCD ApplicationSet's inline `helm.values` is the **production override** (real image tag, real Ingress, real monitoring enabled). Helm merges them: the override wins on any key it sets; the default fills in everything else.

---

## The Two Files and Their Roles

```
charts/simple-time-service/
  └─ values.yaml                              ← FILE 1: chart defaults (safe baseline)

gitops/app/simple-time-service/
  └─ simple-time-service.yaml (ApplicationSet)
       └─ spec.template.spec.source.helm.values  ← FILE 2: ArgoCD production override
```

---

## What Each File Contains (Side by Side)

```
KEY                          values.yaml (default)        ArgoCD helm.values (override)
──────────────────────────── ─────────────────────────── ─────────────────────────────────
image.tag                    v1                           latest              ← OVERRIDDEN
ingress.enabled              false                        true                ← OVERRIDDEN
ingress.className            ""                           alb                 ← OVERRIDDEN
ingress.annotations          {}                           (ALB annotations)   ← OVERRIDDEN
ingress.hosts                []                           simple-time-service.platform.<domain> ← OVERRIDDEN
tracing.enabled              false                        true                ← OVERRIDDEN
serviceMonitor.enabled       false                        true                ← OVERRIDDEN
hpa.enabled                  false                        true                ← OVERRIDDEN
networkPolicy.enabled        false                        false               (same)
nodeSelector                 {}                           app: workload       ← OVERRIDDEN
tolerations                  []                           (workload taint)    ← OVERRIDDEN

── Everything NOT listed in the override uses the default ──
replicaCount                 2                            (not set → uses 2)
resources.requests.cpu       100m                         (not set → uses 100m)
resources.limits.memory      256Mi                        (not set → uses 256Mi)
podSecurityContext           (full definition)            (not set → uses full definition)
pdb.minAvailable             1                            (not set → uses 1)
```

---

## How Helm Merges the Two (The Rule)

```
Helm merge rule:
  Override values WIN on any key they set.
  Default values FILL IN any key not set in the override.

It is a DEEP MERGE, not a replace:
  Default:   image: { repository: "...", tag: "v1",   pullPolicy: "IfNotPresent" }
  Override:  image: {                    tag: "latest"                            }
  Result:    image: { repository: "...", tag: "latest", pullPolicy: "IfNotPresent" }

  Only `tag` was overridden. `repository` and `pullPolicy` are preserved from defaults.
  The override did NOT need to repeat fields it doesn't change.
```

---

## Why This Two-File Design Exists

```
PURPOSE OF values.yaml (chart defaults):
  → Safe, minimal, everything DISABLED by default
  → Someone can run: helm install simple-time-service charts/simple-time-service
    and get a working, safe deployment without any extra config
  → Good for: local development, testing, learning the chart
  → ingress.enabled = false means: no internet exposure by default
  → hpa.enabled = false means: no HPA created (needs metrics-server)
  → serviceMonitor.enabled = false means: no Prometheus scraping (needs Prometheus Operator)
  
  WHY DISABLE BY DEFAULT:
    If someone installs the chart on a cluster without Prometheus,
    and serviceMonitor.enabled = true, the deployment fails because
    the ServiceMonitor CRD doesn't exist.
    Defaults protect against "missing dependencies" errors.

PURPOSE OF ArgoCD helm.values (production override):
  → Turns on EXACTLY what production needs
  → Sets the real domain name (injected from cluster annotations)
  → Uses `latest` image tag (always deploying the freshest build)
  → Pins to `nodeSelector: app: workload` (Karpenter workload nodes, not core nodes)
  → Enables tracing, monitoring, HPA — because production cluster HAS these dependencies
```

---

## Which One ArgoCD Actually Applies

```
ArgoCD runs this internally when syncing:

  helm template charts/simple-time-service \
    --values charts/simple-time-service/values.yaml \      ← always loaded first
    --set-string "image.tag=latest" \                      ← override values applied on top
    --set "ingress.enabled=true" \
    --set "tracing.enabled=true" \
    … (all keys from the ApplicationSet helm.values block)

The RESULT of this merge is what gets applied to the cluster.
ArgoCD never applies values.yaml alone.
ArgoCD never applies the override alone.
It always merges both.
```

---

## Concrete Example: What the Merged Deployment Looks Like

```yaml
# What values.yaml alone would produce:
spec:
  containers:
    - image: docker.io/nabeemdev/simple-time-service:v1    # default tag
  # No ingress created (disabled)
  # No HPA created (disabled)
  # No ServiceMonitor created (disabled)
  nodeSelector: {}   # no node constraint

# What ArgoCD applies after merging with the override:
spec:
  containers:
    - image: docker.io/nabeemdev/simple-time-service:latest  # ← overridden tag
      env:
        - name: OTEL_EXPORTER_OTLP_ENDPOINT  # ← added because tracing.enabled=true
  nodeSelector:
    app: workload    # ← overridden (runs on Karpenter workload nodes)
  tolerations:
    - key: app, value: workload  # ← overridden

# Plus these extra resources ArgoCD creates (because enabled=true):
---
kind: Ingress        # created because ingress.enabled=true
  annotations:
    alb.ingress.kubernetes.io/scheme: internet-facing
    host: simple-time-service.platform.example.com

---
kind: HorizontalPodAutoscaler  # created because hpa.enabled=true

---
kind: ServiceMonitor            # created because serviceMonitor.enabled=true
```

---

## The `nodeSelector: app: workload` Explains the Taint System

```
Core nodes (managed node group):
  label:  app=core
  taint:  app=core:NoSchedule
  → Only platform components (ArgoCD, Prometheus, etc.) tolerate this taint
  → Application pods DO NOT tolerate it → cannot schedule here

Workload nodes (Karpenter):
  label:  app=workload  (set by Karpenter NodePool)
  taint:  app=workload:NoSchedule (set by Karpenter NodePool)
  → Application pods declare: nodeSelector: app=workload AND tolerations for the workload taint
  → This forces app pods onto Karpenter-provisioned nodes
  → Platform pods do NOT tolerate workload taint → cannot mix

The override adds nodeSelector + tolerations so the pod:
  a) Is scheduled ONLY on workload nodes (not on core nodes)
  b) Can actually schedule there (tolerates the workload taint)
```

---

## Summary

```
DO NOT EDIT values.yaml for production config.
DO EDIT values.yaml when you want to change the DEFAULT for everyone who uses the chart.

DO EDIT the helm.values in simple-time-service.yaml for production config.
DO NOT put every value in the override — only what differs from the default.

values.yaml  =  chart defaults  =  the "what a basic install looks like"
helm.values  =  env overrides   =  the "what THIS cluster's production install needs"
```

---

## Commands — Verify the Merge in Practice

```bash
# See what ArgoCD actually has as the merged values (live on cluster)
argocd app get simple-time-service-in-cluster \
  --show-params

# Render the merged chart locally (what ArgoCD would apply)
helm template charts/simple-time-service \
  --values charts/simple-time-service/values.yaml \
  --set image.tag=latest \
  --set ingress.enabled=true \
  --set "ingress.className=alb" \
  --set tracing.enabled=true \
  --set serviceMonitor.enabled=true \
  --set hpa.enabled=true \
  --set "nodeSelector.app=workload"

# Check what ArgoCD is actually syncing for the app
argocd app diff simple-time-service-in-cluster

# See current values live in the cluster (merged result)
helm get values simple-time-service -n simple-time-service

# See ALL values including defaults (the full merged picture)
helm get values simple-time-service -n simple-time-service --all
```
