# Glossary — Project File Explainer

Every term used in the file-by-file explanation, defined for an SRE beginner.

---

**GitHub Actions**
A CI/CD automation system built into GitHub. Runs automated workflows (build, test, deploy) when code is pushed, a PR is opened, or on a schedule. Defined as YAML files in `.github/workflows/`.

**CI/CD (Continuous Integration / Continuous Deployment)**
CI: automatically run tests on every code change. CD: automatically deploy passing changes to production. Together: code merged to main → tested → deployed without manual steps.

**OIDC Authentication (GitHub to AWS)**
A way for GitHub Actions to prove its identity to AWS without storing long-lived access keys. GitHub generates a short-lived JWT token; AWS verifies it is signed by GitHub's OIDC provider. The pipeline never has AWS_SECRET_ACCESS_KEY stored anywhere.

**ECR (Elastic Container Registry)**
AWS's private Docker image registry. Like Docker Hub but inside your AWS account. EKS pulls container images from ECR when starting pods.

**Multi-arch Docker image (linux/amd64 + linux/arm64)**
A single Docker image tag that works on both Intel/AMD CPUs and ARM CPUs (Graviton). When an EKS Graviton node pulls the image, it gets the ARM version automatically. Enables the 20% cost saving from Graviton without any code changes.

**Trivy**
An open-source vulnerability scanner for container images. Scans the image for known CVEs (security vulnerabilities) in operating system packages and Python/Node/Go dependencies. A CRITICAL CVE finding stops the pipeline — the image is not deployed.

**Multi-stage Dockerfile**
A Dockerfile pattern with multiple FROM statements. Stage 1 (builder) installs build tools and compiles dependencies. Stage 2 (runtime) copies only the compiled output — no build tools included. Results in a smaller, more secure final image.

**Virtual environment (Python venv)**
An isolated Python environment with its own copy of pip and installed packages. Prevents package version conflicts between projects. In the Dockerfile, `/opt/venv` is copied from builder to runtime stage, carrying all installed packages.

**FastAPI**
A modern Python web framework for building APIs. Used to create the payment-service HTTP endpoints. FastAPI is fast, has automatic input validation, and generates API documentation automatically.

**Uvicorn**
An ASGI web server for Python. Runs the FastAPI application and handles HTTP connections. Called in `CMD ["python", "main.py"]` which starts uvicorn.

**Liveness Probe**
A Kubernetes health check that asks "is this container still alive?" If it fails repeatedly: Kubernetes restarts (kills and re-creates) the container. Hits `/health/live`. Simple — just checks if the process is running.

**Readiness Probe**
A Kubernetes health check that asks "is this container ready to serve traffic?" If it fails: Kubernetes removes the pod from the Service's endpoints — traffic stops routing to it (no restart, just isolation). Hits `/health/ready`. Checks dependencies (DB).

**Startup Probe**
A Kubernetes health check that runs only during container startup. Gives slow-starting apps (JVM, heavy initialisation) time to start before the liveness probe begins. `failureThreshold: 30 × periodSeconds: 10 = 300s max startup time`.

**preStop hook**
A Kubernetes lifecycle hook that runs before a container receives SIGTERM. The `sleep 10` in preStop gives in-flight HTTP requests 10 seconds to complete after the pod is removed from the load balancer but before the process is killed.

**terminationGracePeriodSeconds**
How long Kubernetes waits for a container to shut down gracefully after sending SIGTERM before force-killing it. Set to 60 seconds — long enough for in-flight requests to finish and connections to drain.

**Helm**
A package manager for Kubernetes. A "chart" is a folder of template files that renders into actual Kubernetes YAML using values from `values.yaml`. Like a parameterised Kubernetes deployment. ArgoCD uses Helm charts to deploy applications.

**Helm Chart**
A packaged collection of Kubernetes resource templates. `Chart.yaml` = metadata. `values.yaml` = default configuration. `templates/` = parameterised YAML files. One chart can render different YAML for prod vs staging by changing values.

**values.yaml**
The default configuration file for a Helm chart. Sets things like replica count, resource limits, image tag. The ArgoCD Application YAML can override individual values without modifying the chart itself.

**Kubernetes Deployment**
A resource that manages a set of identical pods. Handles: rolling updates, replica count, self-healing (restart failed pods). The `deployment.yaml` in the Helm chart defines how the payment-service pods run.

**RollingUpdate strategy**
A Kubernetes deployment strategy that replaces old pods with new ones one at a time. `maxUnavailable: 0` = never have fewer ready pods than desired. `maxSurge: 1` = create one extra pod before removing an old one. Zero-downtime deployments.

**topologySpreadConstraints**
A Kubernetes feature that forces pods to be spread across topology zones (Availability Zones). `maxSkew: 1` means: no zone can have more than 1 more pod than any other zone. Ensures AZ-level resilience.

**podAntiAffinity**
A Kubernetes scheduling rule that prevents two pods with matching labels from running on the same node. `requiredDuringScheduling` = hard rule, scheduler won't violate it. Ensures node failure only kills one pod.

**HPA (HorizontalPodAutoscaler)**
A Kubernetes resource that automatically adjusts the number of pod replicas based on CPU or memory utilisation. Scale up when load increases, scale down when load decreases. `minReplicas: 3` ensures always at least 1 pod per AZ.

**PDB (PodDisruptionBudget)**
A Kubernetes resource that limits how many pods can be disrupted simultaneously during planned maintenance (node upgrades, Karpenter consolidation). `minAvailable: 2` = at least 2 pods must always be running. Prevents maintenance causing an outage.

**Kubernetes Ingress**
A resource that defines HTTP routing rules: "requests for payment.company.com → payment-service Service." The AWS Load Balancer Controller reads this and creates an ALB in AWS.

**ALB (Application Load Balancer)**
AWS's layer-7 HTTP load balancer. Routes HTTPS traffic from the internet to Kubernetes pods. Created automatically by the AWS Load Balancer Controller when it sees an Ingress resource.

**ServiceAccount (Kubernetes)**
An identity assigned to a pod. Used by IRSA: the ServiceAccount is annotated with an IAM role ARN, and Kubernetes injects a JWT token that the AWS SDK uses to get credentials. One ServiceAccount per service = least-privilege isolation.

**ExternalSecret**
A custom Kubernetes resource (from the External Secrets Operator project) that automatically syncs a secret from AWS Secrets Manager into a Kubernetes Secret. The value lives in Secrets Manager; Git only stores the reference (which secret key to read).

**External Secrets Operator (ESO)**
The controller that processes ExternalSecret resources. Runs in the cluster, watches for ExternalSecret objects, reads the referenced value from Secrets Manager, and creates/updates the Kubernetes Secret. Without ESO running, ExternalSecret CRDs are just YAML.

**ClusterSecretStore**
An ESO resource that defines how to connect to a secret backend (AWS Secrets Manager, Vault, etc.). Cluster-scoped: shared by all namespaces. Contains: which AWS region, which IRSA ServiceAccount to use for authentication.

**GitOps**
A practice where Git is the single source of truth for what should run in production. Any change to the Git repo triggers an automatic reconciliation in the cluster. `selfHeal: true` in ArgoCD means: manual kubectl changes are reverted back to Git state.

**ArgoCD**
A GitOps continuous delivery tool for Kubernetes. Watches a Git repository. When it detects a change, it computes the diff between Git and the live cluster and applies the changes. Runs inside the EKS cluster.

**ArgoCD Application**
A custom resource that tells ArgoCD: "watch this Git repo at this path and deploy it to this namespace." Each YAML file in `gitops/` is an ArgoCD Application (or contains one).

**App of Apps pattern**
An ArgoCD pattern where one "root" Application watches a folder that contains other Application YAMLs. The root finds and manages all child Applications recursively. One `kubectl apply` bootstraps the entire platform.

**sync-wave**
An ArgoCD annotation that controls deployment ordering. Lower numbers deploy first. `"0"` (namespaces) → `"2"` (operators) → `"4"` (stores/configs) → `"8"` (applications). Ensures dependencies exist before the things that need them.

**prune: true**
An ArgoCD sync policy setting. If a resource exists in the cluster but NOT in Git, ArgoCD deletes it. "Git is truth — if it's not in Git, it shouldn't exist." Prevents orphaned resources accumulating over time.

**selfHeal: true**
An ArgoCD sync policy setting. If someone uses `kubectl` to manually change a resource, ArgoCD reverts it back to what Git says within ~3 minutes. Enforces GitOps discipline.

**Kyverno**
A Kubernetes-native policy engine. Defines rules like "all pods must have resource limits" or "all pods must have a team label." Enforces them at admission time — a pod that violates a policy is rejected before it can be created.

**ClusterPolicy (Kyverno)**
A Kyverno resource that defines a policy rule applied cluster-wide. `validationFailureAction: Enforce` = reject the resource if the rule fails. Used here to require: resource limits on all pods, team+app labels on all pods.

**Terraform Module**
A reusable package of Terraform resources with defined inputs and outputs. The `modules/vpc/` folder is called with `module "vpc" { source = "./modules/vpc" }`. Encapsulates complexity, enables reuse.

**Terraform State**
A JSON file recording what resources Terraform has created. Stored in S3 (backend.tf). When you run `terraform plan`, Terraform compares state vs actual AWS vs your .tf files. If three match: no changes. If they differ: changes needed.

**DynamoDB Lock (Terraform)**
A DynamoDB table entry that Terraform writes before applying changes. Prevents two people from running `terraform apply` simultaneously (which would corrupt the state file). Released automatically after apply completes.

**OIDC Provider (IAM)**
An AWS IAM resource that tells AWS: "trust JWT tokens signed by this OIDC issuer (EKS cluster)." Required for IRSA. The Terraform EKS module creates this automatically.

**IRSA (IAM Roles for Service Accounts)**
The mechanism that gives individual Kubernetes pods specific AWS permissions without static credentials. The IAM role trust policy names the specific ServiceAccount that can assume it. Credentials are temporary and automatically rotated.

**Karpenter**
A Kubernetes node autoscaler. Instead of managing fixed Auto Scaling Groups, Karpenter provisions exactly the right EC2 instance for each batch of pending pods. Faster (30-90 seconds vs 3-5 minutes) and more cost-efficient than Cluster Autoscaler.

**SQS (Simple Queue Service)**
AWS's managed message queue. Karpenter uses an SQS queue to receive Spot interruption warnings from EventBridge. When AWS reclaims a Spot instance, Karpenter gets 2 minutes of warning via SQS to drain and replace the node.

**EventBridge**
AWS's event routing service. Routes events from AWS services (e.g., "EC2 Spot instance will be interrupted") to targets (e.g., SQS queue). Karpenter uses EventBridge rules to receive Spot and instance lifecycle events.

**Dynatrace Management Zone**
A filter in Dynatrace that groups entities (services, hosts, pods) by team. All alerts, dashboards, and SLOs in a management zone only show that team's resources. Created per team via Terraform `for_each`.

**Dynatrace OneAgent**
A monitoring agent deployed as a Kubernetes DaemonSet (one pod per node). Automatically discovers all services, measures response times, error rates, CPU, memory — without any application code changes.

**Dynatrace Problem**
Dynatrace's incident abstraction. When metric events fire, Dynatrace creates a Problem that groups related alerts. The Problem routes to alerting profiles which trigger notifications (PagerDuty/Slack). When all metric events resolve: Problem closes automatically.

**SLO (Service Level Objective)**
A target for reliability. "99.9% of requests succeed over 30 days." Dynatrace tracks this against an SLI (Service Level Indicator — the actual metric). The difference between 100% and the SLO target = the error budget.

**Error Budget**
The allowed amount of downtime or errors within the SLO window. For a 99.9% SLO: 0.1% of requests can fail = ~43 minutes of downtime per month. Burn rate alerts fire when the budget is being consumed too quickly.

**Burn Rate**
How fast the error budget is being consumed relative to the SLO window. 14.4× burn rate = the monthly budget will be exhausted in 2 days at the current rate. The signal to page on-call immediately.

**HTTP Synthetic Monitor**
A Dynatrace feature that periodically sends real HTTP requests to your health endpoint from external locations (Tokyo, Singapore). Detects outages from an external perspective — catches DNS failures and network issues that OneAgent (inside the cluster) cannot see.
