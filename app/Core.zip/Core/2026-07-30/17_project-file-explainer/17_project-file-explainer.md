# Every File in 16_eks-dynatrace-gitops-revised — Explained

> **How to read this:** Each section = one file or folder. For each file: what it IS, what it DOES, and why it EXISTS (what breaks without it).

---

## Project Map (Who Uses What)

```
Developer pushes code
        │
        ▼
.github/workflows/app-ci.yaml          ← builds Docker image, runs tests
        │ (on merge to main)
        ▼
app/Dockerfile + app/main.py           ← the actual application being built
        │ (pushes image to ECR, commits new tag to Git)
        ▼
gitops/app/payment-service/            ← ArgoCD reads the new tag from here
        │
        ▼
charts/payment-service/                ← Helm chart ArgoCD renders into K8s YAML
        │
        ▼
EKS cluster                            ← pods running the app

Platform engineer changes infrastructure
        │
        ▼
.github/workflows/terraform-infra.yaml ← runs terraform plan/apply for AWS infra
terraform/ (root)                       ← creates VPC, EKS, IAM roles
        │
        ▼
.github/workflows/terraform-dynatrace.yaml ← separate pipeline for monitoring config
terraform/dynatrace/                       ← creates Dynatrace alerts, SLOs, zones
        │
        ▼
Dynatrace tenant                           ← monitoring for the EKS cluster
```

---

## ROOT LEVEL

### `4_eks-dynatrace-gitops-project.md`
The main documentation file for the entire project — explains the architecture, how all the pieces connect, and the deployment flow. Not used by any tool — it's human-readable context for anyone new to the repo.

### `4_eks-dynatrace-gitops-project_glossary.md`
A glossary of every term used in the project docs. Same purpose — documentation only. Useful when a new engineer joins and sees "IRSA" or "GitOps" for the first time.

---

## `.github/workflows/` — CI/CD Pipelines

These three files are the automation engine of the project. Nothing deploys without them.

---

### `.github/workflows/app-ci.yaml`
**What it is:** The application CI/CD pipeline — the full journey from code push to production deployment.

**What it does, step by step:**
```
TRIGGER: any push or PR to main that changes app/ or charts/

Step 1 — Test job:
  - Installs Python 3.12 + requirements.txt
  - Runs pytest on app/tests/
  - If tests FAIL: pipeline stops. No image is built.

Step 2 — Build-push job (only runs after test passes):
  - Authenticates to AWS via OIDC (no stored AWS keys in GitHub)
  - Logs in to ECR
  - Builds a multi-arch Docker image (linux/amd64 + linux/arm64)
    → linux/arm64 = runs on Graviton EKS nodes (20% cheaper)
  - Pushes image to ECR with tag = git SHA (e.g., "abc1234")
  - Runs Trivy to scan for CRITICAL vulnerabilities
    → If found: pipeline fails, image not deployed
  - Updates gitops/app/payment-service/payment-service.yaml
    with the new image tag and commits it
  - ArgoCD detects the gitops commit and deploys the new image
```

**Why it exists:**
Without this file, every deployment is manual — engineer must build, push, and update YAML by hand. That means: inconsistent process, potential for forgetting the vulnerability scan, human error on the image tag.

---

### `.github/workflows/terraform-infra.yaml`
**What it is:** The AWS infrastructure Terraform pipeline — manages VPC, EKS cluster, IAM roles.

**What it does:**
```
TRIGGER: any push/PR to main that changes terraform/ (excluding terraform/dynatrace/)

On PR:
  - terraform init + terraform plan
  - Posts the plan output as a comment on the PR
  - Engineers review: what AWS resources will change?
  - High-risk changes (EKS version upgrade, VPC changes) require human approval

On merge to main:
  - terraform apply -auto-approve
  - Updates real AWS infrastructure
```

**Why it exists:**
Without this, infrastructure changes require someone to run `terraform apply` from their laptop. Problems: different engineers use different Terraform versions, credentials vary, no audit trail of who applied what.

---

### `.github/workflows/terraform-dynatrace.yaml`
**What it is:** A SEPARATE Terraform pipeline just for Dynatrace monitoring configuration.

**Why separate from terraform-infra.yaml:**
```
Dynatrace config changes frequently — adding a new service, adjusting a threshold.
Infrastructure changes rarely — EKS upgrades, VPC modifications.

Separate pipelines mean:
  Adding a new service to monitoring: fast, low-risk PR that only touches DT config.
  EKS upgrade: heavyweight PR that only touches infra Terraform.
  They don't block each other.
  Different IAM roles with different permissions:
    dynatrace-plan role: reads Secrets Manager (DT tokens). No EC2/EKS access.
    infra-apply role: full AWS admin. More dangerous.
```

**What it does:**
```
On PR:  terraform plan → posts plan to PR as a comment
On merge: terraform apply → updates Dynatrace configuration in real time
```

---

## `app/` — The Application Code

### `app/main.py`
**What it is:** The example payment microservice — a FastAPI Python application.

**What it does:**
```
Exposes 4 HTTP endpoints:
  GET  /health/live     → Kubernetes LIVENESS probe
                          Returns 200 if process is alive
                          Returns non-200 only if process is deadlocked/broken
                          
  GET  /health/ready    → Kubernetes READINESS probe
                          Returns 200 if ready to serve traffic
                          Returns 503 if DB_HOST env var is missing
                          K8s removes pod from load balancer if this returns 503
                          
  GET  /api/v1/payments/{id}  → fetch a payment
  POST /api/v1/payments       → create a payment
```

**Why the two health endpoints are different:**
```
/health/live:   Is the process running? (liveness)
  If this fails repeatedly: Kubernetes RESTARTS the container.
  Should be simple — just return 200 if the process is alive.
  
/health/ready:  Is the process ready for traffic? (readiness)
  If this fails: Kubernetes STOPS sending traffic to this pod (no restart).
  Checks dependencies (DB connection).
  During startup or DB outage: pods go "not ready" → ALB routes to healthy pods.
  
  WHY BOTH MATTER:
  Startup: DB is connecting → pod is alive (/live = 200) but not ready (/ready = 503)
           → ALB doesn't send traffic yet → no errors during cold start
  DB outage: all pods alive but not ready → ALB returns 502 (no backends)
             rather than 500 (unhealthy backends)
```

**Structured JSON logging:**
Every log line is JSON (`{"timestamp": "...", "level": "info", "event": "payment_fetch", ...}`). Dynatrace, Fluent Bit, and CloudWatch Logs Insights can all parse JSON natively — no log parsing rules needed.

---

### `app/Dockerfile`
**What it is:** The build recipe for the payment-service container image.

**What it does:**
```
TWO-STAGE BUILD:

Stage 1 (builder):
  FROM python:3.12-slim-bookworm
  Installs all Python packages into /opt/venv
  → installs pip, requirements.txt
  → creates a virtual environment

Stage 2 (runtime):
  FROM python:3.12-slim-bookworm (clean base — no build tools)
  Copies ONLY /opt/venv from Stage 1
  Copies main.py
  Sets up non-root user (UID 1000)
  Exposes port 8080
  CMD: python main.py
```

**Why two stages:**
```
Builder has: pip, gcc, build headers → needed to compile some packages
Runtime needs: ONLY the compiled packages + main.py

Without multi-stage: final image = 800MB (includes all build tools)
With multi-stage:    final image = 120MB (only runtime dependencies)

Smaller image = faster pulls from ECR to EKS node = faster pod startup
Also: no gcc/pip in runtime = smaller attack surface if container is compromised
```

**Why non-root user:**
If the container is compromised (e.g., via app vulnerability), the attacker has UID 1000 — no ability to install packages, modify system files, or access other users' files.

---

### `app/requirements.txt`
Lists Python dependencies: `fastapi`, `uvicorn`. Pinned to specific versions for reproducibility — same versions on every build.

### `app/tests/test_main.py`
Unit tests for main.py. Run by `pytest` in the CI pipeline. If tests fail, the Docker image is never built.

---

## `charts/` — Helm Charts

Helm is a package manager for Kubernetes. A "chart" is a folder of templates that renders into actual Kubernetes YAML using values from `values.yaml`. ArgoCD uses these charts to deploy.

---

### `charts/payment-service/Chart.yaml`
Metadata file: chart name, version, description. Helm requires this to treat the folder as a chart.

### `charts/payment-service/values.yaml`
The default configuration for the payment-service chart: image tag, replica count, resource limits, HPA settings. The ArgoCD Application YAML in `gitops/app/` can override these values.

### `charts/payment-service/templates/deployment.yaml`
**What it is:** The Kubernetes Deployment — defines how pods run.

**Key features explained:**
```
RollingUpdate strategy (maxUnavailable: 0, maxSurge: 1):
  Never take a pod down before a new one is Ready.
  Zero-downtime deployments: new pod starts → passes readiness → old pod terminates.
  
topologySpreadConstraints (maxSkew: 1, zone):
  Spreads pods across 3 AZs.
  With 3 replicas: 1 pod per AZ.
  If AZ-a fails: 2 of 3 pods still alive in AZ-b and AZ-c.
  
podAntiAffinity (requiredDuringScheduling, hostname):
  No two pods on the same node.
  If a node fails: only 1 pod is lost, not all pods.
  Combined with zone spread: maximum resilience.
  
startupProbe (failureThreshold: 30, period: 10s = 300s max):
  Gives slow-starting apps 5 minutes to start before liveness kicks in.
  Without this: slow Java app startup → liveness fails → endless restart loop.
  
livenessProbe → /health/live:
  Kills and restarts the container if it becomes stuck/deadlocked.
  
readinessProbe → /health/ready:
  Removes pod from load balancer if DB is unreachable.
  No traffic to broken pods.
  
preStop sleep 10:
  Before Kubernetes terminates the pod:
  1. K8s removes pod from Service endpoints (ALB stops routing here)
  2. In-flight requests are still processing
  3. preStop sleeps 10 seconds to let them finish
  4. Then the container receives SIGTERM
  Without this: in-flight requests get connection reset mid-processing.
  
readOnlyRootFilesystem: true:
  Container cannot write to its own filesystem.
  Prevents: malicious code writing backdoors, log injection to disk.
  App writes logs to stdout only (correct pattern).
```

---

### `charts/payment-service/templates/hpa.yaml`
**What it is:** HorizontalPodAutoscaler — automatically scales pod count based on load.

```
Watches: CPU utilisation + memory utilisation
Scale UP trigger:  CPU > 70% across all pods → add up to 3 pods per minute
Scale DOWN trigger: CPU < 70% for 5 minutes → remove 1 pod per minute

minReplicas: 3  → always at least 1 pod per AZ (AZ resilience)
maxReplicas: 20 → cost ceiling

Why scale-down is slow (300s window, 1 pod/min):
  Fast scale-down causes oscillation: traffic spike → scale up → traffic drops → scale down → spike again.
  Slow scale-down: keeps capacity available for the next spike.
  Trade-off: slightly higher cost vs. stability.
```

---

### `charts/payment-service/templates/pdb.yaml`
**What it is:** PodDisruptionBudget — minimum pod guarantee during planned disruptions.

```
minAvailable: 2  →  at least 2 pods must be running at all times

WHEN THIS MATTERS:
  Node upgrade: Kubernetes drains nodes one at a time.
  Without PDB: Kubernetes can drain all 3 pods simultaneously → service down.
  With PDB:    Kubernetes must wait for a new pod to start before evicting the next.
  
  Karpenter node consolidation (replace 3 small nodes with 1 large one):
  Without PDB: all pods evicted at once → downtime.
  With PDB:    Karpenter respects the budget → rolling replacement.
```

---

### `charts/payment-service/templates/service.yaml`
Kubernetes Service: creates a stable DNS name (`payment-service.payment-ns.svc.cluster.local`) that load-balances across all healthy pods. The ALB routes to this Service. Other pods call this Service name — not individual pod IPs.

### `charts/payment-service/templates/serviceaccount.yaml`
Kubernetes ServiceAccount with the IRSA annotation (`eks.amazonaws.com/role-arn`). This is the link between the pod and its AWS IAM permissions. Without this, the pod uses the node's IAM role (too broad).

### `charts/payment-service/templates/ingress.yaml`
Kubernetes Ingress with AWS Load Balancer Controller annotations. When ArgoCD applies this, the ALB controller creates an ALB in AWS that routes `payment.company.com` HTTPS traffic to the payment-service pods.

### `charts/payment-service/templates/external-secret.yaml`
**What it is:** An ExternalSecret custom resource — automatically syncs secrets from AWS Secrets Manager into a Kubernetes Secret.

```
Flow:
  ExternalSecret reads: production/payment-service/db-credentials (Secrets Manager)
  Creates: Kubernetes Secret named "payment-service-db-credentials"
  Refreshes: every 1 hour (re-reads from Secrets Manager)
  
The Deployment mounts this Secret as envFrom:
  DB_HOST, DB_PORT, DB_NAME, DB_USERNAME, DB_PASSWORD
  → injected as environment variables into the container

WHY NOT STORE SECRETS IN GIT:
  GitOps = everything in Git. But secrets must NOT be in Git.
  ExternalSecret is the bridge: Git stores the reference (which secret), 
  not the value. The value stays in Secrets Manager.
```

---

### `charts/namespaces/`
A simple Helm chart that creates Kubernetes Namespaces (payment-ns, orders-ns, etc.). Deployed by ArgoCD in sync-wave 1 — before any application. Applications cannot be deployed to a namespace that doesn't exist yet.

---

## `gitops/` — ArgoCD GitOps Manifests

Every file here is either an ArgoCD Application (deploys something) or a raw Kubernetes manifest.

---

### `gitops/bootstrap/root-app.yaml`
**THE most important file. Apply this once manually — everything else is automated.**

```
It creates ONE ArgoCD Application that watches the entire gitops/ folder.
ArgoCD recursively finds every other Application YAML and manages them.
This is the "App of Apps" pattern.

After running: kubectl apply -f gitops/bootstrap/root-app.yaml
→ ArgoCD discovers: namespaces, networking, secrets, monitoring, payment-service
→ All of them deploy in the right order (sync-waves)
→ Any future change to gitops/ is deployed automatically

prune: true    → if you delete a YAML from gitops/, ArgoCD deletes the resource
selfHeal: true → if someone manually changes a resource with kubectl, 
                  ArgoCD reverts it back to what's in Git within 3 minutes
```

---

### `gitops/app/payment-service/payment-service.yaml`
ArgoCD Application for the payment-service microservice. Points to `charts/payment-service/`. GitHub Actions automatically updates the `image.tag` field in this file on every merge to main. ArgoCD detects the change and deploys the new image.

---

### `gitops/namespaces/namespaces.yaml`
ArgoCD Application (sync-wave 1) that installs the namespaces Helm chart. Creates: `payment-ns`, `karpenter`, `external-secrets`, `dynatrace`, `kyverno` namespaces. Must run before everything else.

### `gitops/networking/aws-load-balancer-controller.yaml`
ArgoCD Application (sync-wave 2) that installs the AWS Load Balancer Controller Helm chart. Without this, Kubernetes Ingress resources do nothing — there's no controller to create ALBs.

### `gitops/networking/external-dns.yaml`
ArgoCD Application that installs ExternalDNS. Watches for Ingress resources and automatically creates Route 53 DNS records. Without this, `payment.company.com` doesn't exist in DNS — you'd need to create it manually in Route 53 every time.

### `gitops/secrets/external-secrets/external-secret-operator.yaml`
ArgoCD Application (sync-wave 2) that installs External Secrets Operator (ESO). ESO is the controller that processes ExternalSecret resources. Without ESO running, ExternalSecret CRDs are just YAML — nothing reads them.

### `gitops/secrets/external-secrets/cluster-secret-store.yaml`
ArgoCD Application (sync-wave 4) that creates the ClusterSecretStore resource. This tells ESO: "connect to AWS Secrets Manager in ap-northeast-1 using the IRSA role." Must run after ESO (wave 4 > wave 2).

### `gitops/monitoring/dynatrace/dynatrace-operator.yaml`
ArgoCD Application that installs the Dynatrace Operator Helm chart and creates the DynaKube custom resource. The operator deploys OneAgent DaemonSet (one pod per node) for full-stack monitoring.

### `gitops/argocd/argocd-project.yaml`
Defines ArgoCD Projects (`platform`, `payments`). A Project limits which repos and namespaces an Application can deploy to. Prevents a payments Application from accidentally deploying to the platform namespace.

### `gitops/auto-scaling/karpenter/karpenter.yaml`
ArgoCD Application that installs Karpenter (the node autoscaler) via Helm. Also contains the NodePool and EC2NodeClass custom resources that define what kind of nodes Karpenter is allowed to provision.

### `gitops/security/kyverno/kyverno.yaml`
**Two things in one file:**
1. ArgoCD Application (wave 3) that installs Kyverno policy engine
2. Two ClusterPolicy resources (wave 5) that enforce:
   - `require-resource-limits`: all pods must declare CPU/memory requests and limits
   - `require-pod-labels`: all pods must have `team` and `app` labels (for Dynatrace tagging)

---

## `terraform/` — AWS Infrastructure

---

### `terraform/versions.tf`
Declares the minimum Terraform version and all required providers (AWS, Kubernetes, Helm) with pinned versions. Without this, different engineers might use different provider versions and get different results.

### `terraform/backend.tf`
Tells Terraform where to store the state file: S3 bucket with DynamoDB locking. Multiple engineers can run Terraform safely — DynamoDB lock prevents two people from applying at the same time.

### `terraform/variables.tf` + `terraform/variables-addition.tf`
All input variables for the root module: `cluster_name`, `environment`, `vpc_cidr`, instance types, etc. Using variables instead of hardcoded values means the same Terraform works for both `prod` and `staging` by changing one variable.

### `terraform/main.tf`
The root orchestration file. Calls two modules:
- `module "vpc"` → creates the VPC, subnets, NAT gateways
- `module "eks"` → creates the EKS cluster
Also configures the Kubernetes and Helm providers using the EKS cluster's endpoint and certificate.

### `terraform/outputs.tf`
Exports values that other Terraform modules or CI/CD pipelines need: cluster name, endpoint, OIDC URL, VPC ID. These are referenced by the IRSA files and the Dynatrace Terraform module.

### `terraform/secrets-manager.tf`
Creates the AWS Secrets Manager secrets used by the application: `production/payment-service/db-credentials`. The values are not in Terraform — they're populated manually or by another process. Terraform just creates the secret shell and IAM policies.

---

### `terraform/irsa-lbc.tf`
**What it is:** IAM Role for Service Accounts — AWS Load Balancer Controller.

Creates an IAM role with OIDC trust policy that allows only the `aws-load-balancer-controller` ServiceAccount in `kube-system` to assume it. Attaches a policy with permissions to create/modify/delete ALBs. Without this role, the ALB controller cannot call AWS APIs — Ingress resources never create ALBs.

### `terraform/irsa-eso.tf`
IRSA for External Secrets Operator. Allows the `external-secrets-sa` ServiceAccount to call `secretsmanager:GetSecretValue`. Without this, ESO cannot read secrets from Secrets Manager.

### `terraform/irsa-externaldns.tf`
IRSA for ExternalDNS. Allows the `external-dns` ServiceAccount to call Route 53 APIs to create DNS records. Without this, ExternalDNS cannot update DNS — `payment.company.com` is never registered.

### `terraform/karpenter.tf`
Creates all AWS-side resources Karpenter needs:
- IAM role for the Karpenter controller pod (to call `ec2:RunInstances`, etc.)
- IAM role + instance profile for nodes Karpenter provisions
- SQS queue to receive Spot interruption warnings
- EventBridge rule to route Spot warnings → SQS

---

### `terraform/modules/vpc/`
A reusable Terraform module that creates:
- VPC with specified CIDR
- Public subnets (1 per AZ) — for NAT gateways and internet-facing ALBs
- Private subnets (1 per AZ) — for EKS nodes and pods
- Internet Gateway (for public subnets)
- NAT Gateways (1 per AZ — HA: each AZ has its own NAT)
- Route tables wiring it all together
- Required tags for EKS ALB discovery (`kubernetes.io/role/elb`, etc.)

### `terraform/modules/eks/`
A reusable Terraform module that creates:
- EKS control plane (the managed Kubernetes API server)
- System managed node group (3 × t3.medium, for CoreDNS/kube-proxy)
- OIDC provider (required for IRSA)
- EKS managed add-ons: vpc-cni, coredns, kube-proxy, aws-ebs-csi-driver
- CloudWatch log group for control plane logs
- IAM roles for the cluster and node groups
- Security groups

### `terraform/app-bootstrap/`
A separate Terraform module (separate state file) that bootstraps application-level AWS resources: ECR repository for the Docker image, IAM role for GitHub Actions to push to ECR. Run once before the first CI build.

---

## `terraform/dynatrace/` — Dynatrace Monitoring Configuration

All files here create Dynatrace resources. Applied by the `terraform-dynatrace.yaml` GitHub Actions pipeline. Completely independent from the EKS infrastructure — can be changed and deployed without touching the cluster.

---

### `terraform/dynatrace/main.tf`
Provider configuration: reads the Dynatrace API token and tenant URL from AWS Secrets Manager (never hardcoded). Configures S3 backend for Dynatrace state (separate from infra state).

### `terraform/dynatrace/variables.tf`
The **single source of truth** for all monitoring thresholds. Adding one entry to the `services` map automatically creates: 1 management zone, 8 metric events, 2 SLOs, 1 synthetic monitor, 4 notification integrations. No other files need to be edited.

### `terraform/dynatrace/management-zones.tf`
Creates one Dynatrace Management Zone per team. A zone scopes all monitoring to that team's entities (services, hosts, processes, Kubernetes workloads). Each team's alerting profile is scoped to their zone — payment alerts only go to the payment team.

### `terraform/dynatrace/metric-events.tf`
Creates 8 custom metric event rules per service (4 golden signals + memory + JVM heap + pod restarts + network errors). When a metric crosses its threshold for the required number of consecutive minutes, Dynatrace creates a Problem which flows to the alerting profile → notification channel.

### `terraform/dynatrace/alerting-profiles.tf`
Creates 4 alerting profiles per team (Critical/High/Warning/Info). Each profile filters problems by severity and delay before triggering a notification. Critical profiles only exist in production — no 3am pages for staging.

### `terraform/dynatrace/notifications.tf`
Wires alerting profiles to notification channels: Critical/High → PagerDuty, Warning → Slack `#alerts-<team>`, Info → Slack `#monitoring`.

### `terraform/dynatrace/slos.tf`
Creates 2 SLOs per service (availability + latency). Each SLO has burn rate alerts: fast burn (14.4×) → pages immediately, slow burn (3×) → Slack warning. This is the error budget tracking — you can see how much of the monthly reliability budget has been spent.

### `terraform/dynatrace/synthetics.tf`
Creates 1 HTTP synthetic health check per service, running from Tokyo and Singapore every 5 minutes. Checks: HTTP 2xx status, response body contains `"status":"ok"`, response time under 2× the P99 target. Detects outages from an external perspective (vs OneAgent which monitors from inside).
