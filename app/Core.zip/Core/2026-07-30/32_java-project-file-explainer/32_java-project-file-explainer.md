# 23_java-eks-gitops-project — Every File Deep Dive

> One md per file. Each explains: what the file is, every line that matters, and what breaks if it is wrong.

## File → Explanation Map

| File | Explanation |
|---|---|
| `app/PaymentApplication.java` | `app/PaymentApplication.md` |
| `app/controller/PaymentController.java` | `app/PaymentController.md` |
| `app/health/ReadinessIndicator.java` | `app/ReadinessIndicator.md` |
| `app/model/CreatePaymentRequest.java` | `app/CreatePaymentRequest.md` |
| `app/model/Payment.java` | `app/Payment.md` |
| `app/resources/application.yaml` | `app/application-yaml.md` |
| `app/test/PaymentControllerTest.java` | `app/PaymentControllerTest.md` |
| `app/build.gradle` | `app/build-gradle.md` |
| `app/settings.gradle` | `app/settings-gradle.md` |
| `app/Dockerfile` | `app/Dockerfile.md` |
| `charts/payment-service/values.yaml` | `charts/values-yaml.md` |
| `charts/payment-service/values-dev.yaml` | `charts/values-dev-yaml.md` |
| `charts/payment-service/values-staging.yaml` | `charts/values-staging-yaml.md` |
| `gitops/dev/bootstrap/root-app-dev.yaml` | `gitops/root-app-dev.md` |
| `gitops/dev/namespaces/namespaces.yaml` | `gitops/namespaces.md` |
| `gitops/dev/app/payment-service.yaml` | `gitops/payment-service-dev.md` |
| `gitops/staging/app/payment-service.yaml` | `gitops/payment-service-staging.md` |
| `gitops/production/app/payment-service.yaml` | `gitops/payment-service-production.md` |
| `terraform/environments/*/terraform.tfvars` | `terraform/env-tfvars.md` |
| `terraform/dynatrace/*.tfvars` | `terraform/dynatrace-tfvars.md` |
| `.github/workflows/app-ci.yaml` | `github-actions/app-ci.md` |
