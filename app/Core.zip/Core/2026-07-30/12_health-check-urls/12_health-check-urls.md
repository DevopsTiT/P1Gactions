# health_check_url — Default Values per Service

---

## Current State in the Project

The project currently defines **only one service** in `terraform/dynatrace/variables.tf`:

```hcl
# terraform/dynatrace/variables.tf
variable "services" {
  default = {
    "payment-service" = {
      team             = "payments"
      slo_target       = 99.9
      error_rate_alert = 0.5
      latency_p99_ms   = 500
      health_check_url = "https://payment.company.com/health"
    }
  }
}
```

| Service | `health_check_url` | Why This URL |
|---|---|---|
| `payment-service` | `https://payment.company.com/health` | placeholder — matches the `ingress.host` in `charts/payment-service/values.yaml` |

---

## Why `/health` Not `/health/ready` or `/health/live`

The app (`app/main.py`) exposes **two** health endpoints:

```python
@app.get("/health/live")   # liveness: is the process alive?
@app.get("/health/ready")  # readiness: is it ready for traffic?
```

**There is no `/health` endpoint defined in `main.py`.**

The `health_check_url = "https://payment.company.com/health"` used by the Dynatrace synthetic monitor will return **404** with the current `main.py`. This is a bug in the project.

**What each health URL is used for:**

| URL | Used By | Returns |
|---|---|---|
| `https://payment.company.com/health` | Dynatrace synthetic monitor | 404 ← BUG |
| `/health/live` | Kubernetes `livenessProbe` | 200 (process alive) |
| `/health/ready` | Kubernetes `readinessProbe` | 200 / 503 |
| `/health/ready` | ALB health check (`alb.ingress.kubernetes.io/healthcheck-path`) | 200 / 503 |

---

## Three Ways to Fix the Mismatch

### Fix A — Change `health_check_url` to `/health/ready` (recommended)

The readiness endpoint already exists and checks real dependencies (DB connectivity). Use it for the external synthetic check too.

```hcl
# terraform/dynatrace/variables.tf
"payment-service" = {
  ...
  health_check_url = "https://payment.company.com/health/ready"
}
```

**Why `ready` not `live`:** The readiness probe checks whether the service can actually serve traffic (DB connected). If the DB is down, `/health/ready` returns 503 — the synthetic monitor fires an alert. `/health/live` would still return 200 even when the DB is down.

```bash
# Apply the change
cd terraform/dynatrace/
terraform plan    # shows: ~ dynatrace_http_monitor.health_check["payment-service"] will be updated
terraform apply   # synthetic URL updated
```

### Fix B — Add a `/health` route to `main.py`

```python
# In app/main.py
@app.get("/health")
def health():
    """Combined health endpoint — used by Dynatrace synthetic monitor."""
    db_host = os.getenv("DB_HOST", "")
    if not db_host:
        raise HTTPException(status_code=503, detail="Database not configured")
    return {"status": "ok", "timestamp": datetime.now(timezone.utc).isoformat()}
```

Then `health_check_url = "https://payment.company.com/health"` matches.

### Fix C — Use `/health/live` (simplest, but less thorough)

```hcl
health_check_url = "https://payment.company.com/health/live"
```
Always returns 200 if the process is running. Catches: DNS failure, TLS expiry, complete service outage. Does NOT catch: DB down (service running but can't serve requests).

---

## What the Health Check URL Is Actually Used For

The `health_check_url` in `variables.tf` is used by **one resource only**:

```hcl
# terraform/dynatrace/synthetics.tf
resource "dynatrace_http_monitor" "health_check" {
  for_each = var.services
  script {
    request {
      url = each.value.health_check_url   # ← this field
      validation {
        rule { type = "httpStatusesList"; value = "2xx" }
      }
    }
  }
}
```

The Dynatrace synthetic monitor sends an HTTP GET to this URL from Tokyo and Singapore every 5 minutes. It verifies:
1. DNS resolves correctly
2. TLS certificate is valid
3. ALB routes to a healthy pod
4. The pod responds with a 2xx status

This catches failures that internal Kubernetes health checks cannot see (DNS failure, expired certificate, CloudFront/CDN issues).

---

## If You Had Multiple Services

If you added all five services from earlier discussions, their `health_check_url` values would be:

| Service key | Recommended `health_check_url` |
|---|---|
| `payment-service` | `https://payment.company.com/health/ready` |
| `orders-service` | `https://orders.company.com/health/ready` |
| `inventory-service` | `https://inventory.company.com/health/ready` |
| `notification-service` | `https://notification.company.com/health/ready` |
| `user-service` | `https://user.company.com/health/ready` |

Each URL is: `https://` + the Ingress `host` value from `values.yaml` + `/health/ready`.

The Ingress host is set in `gitops/app/<service>/application.yaml` under `helm.values.ingress.host`, which maps to the Route53 record that ExternalDNS creates when the Ingress is applied.

---

## Verify the Synthetic Monitor After Fix

```bash
# Check the synthetic monitor is hitting the right URL
DT_TENANT="abc12345"
DT_TOKEN="dt0c01.YOUR_TOKEN"

curl -s "https://${DT_TENANT}.live.dynatrace.com/api/v1/synthetic/monitors" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  jq '.monitors[] | {name: .name, url: .script.requests[0].url}'
# Expected: "url": "https://payment.company.com/health/ready"

# Test the URL manually
curl -I https://payment.company.com/health/ready
# Expected: HTTP/2 200

# Check last synthetic execution result
MONITOR_ID=$(curl -s "https://${DT_TENANT}.live.dynatrace.com/api/v1/synthetic/monitors" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  jq -r '.monitors[0].entityId')

curl -s "https://${DT_TENANT}.live.dynatrace.com/api/v1/synthetic/monitors/${MONITOR_ID}/results?resultType=LAST&maxResults=1" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  jq '.executions[0] | {status: .status, httpStatus: .responseStatusCode, responseTime: .responseTime}'
# status: "SUCCESS" = synthetic check passing
# status: "FAILED"  = something is wrong (DNS, TLS, 404, etc.)
```
