# Health Check URL — Glossary

**`health_check_url`**
A field in the Dynatrace `services` variable map specifying the public HTTPS URL the Dynatrace synthetic monitor checks every 5 minutes. Must be an endpoint the application actually exposes — if the endpoint doesn't exist, the synthetic returns 404 and fires a false alert.

**Dynatrace Synthetic Monitor**
An automated HTTP test run from multiple global locations (Tokyo, Singapore) on a schedule. Tests the service from outside the cluster — catches DNS failures, expired TLS certificates, and CDN issues that internal Kubernetes health checks cannot see.

**`/health/live` (Liveness endpoint)**
An application endpoint that returns 200 if the process is running and not deadlocked. Used by the Kubernetes `livenessProbe`. Should NOT check external dependencies — if it fails, Kubernetes restarts the container.

**`/health/ready` (Readiness endpoint)**
An application endpoint that returns 200 when the service is ready to receive traffic (DB connected, dependencies available). Returns 503 when not ready. Used by both the Kubernetes `readinessProbe` and the ALB health check.

**`/health` (Combined endpoint)**
A single health endpoint combining liveness and readiness checks. Not defined in this project's `main.py` — the default `health_check_url = "https://payment.company.com/health"` results in a 404. Either add this endpoint to the app or update `health_check_url` to point to `/health/ready`.

**ALB Health Check (`alb.ingress.kubernetes.io/healthcheck-path`)**
An AWS ALB annotation specifying which HTTP path the ALB uses to verify pod health. Set to `/health/ready` in the Ingress template. If a pod's readiness endpoint returns non-2xx, the ALB stops routing traffic to that pod.

**DNS Resolution**
The process of converting a domain name (`payment.company.com`) to an IP address or hostname. The Dynatrace synthetic monitor performs DNS resolution as part of its check — a DNS failure (incorrect Route53 record, ExternalDNS bug) is caught by the synthetic but invisible to internal Kubernetes probes.

**TLS Certificate Validation**
The synthetic monitor's `accept_any_certificate = false` setting causes the check to fail if the HTTPS certificate is invalid or expired. An expired ACM certificate breaks HTTPS for all users — the synthetic catches it before users report it.

**503 Service Unavailable**
HTTP status code returned when a service cannot handle the request (DB down, dependency unavailable). The readiness probe returning 503 causes the pod to be removed from the ALB target group without restarting it.

**2xx Status Validation**
The synthetic monitor validates that the response HTTP status code is in the 200–299 range. A 404 (URL doesn't exist), 500 (server error), or 503 (service unavailable) all fail this validation and create a Dynatrace Problem.

**ExternalDNS**
The Kubernetes controller that creates Route53 DNS records when an Ingress is applied. The `health_check_url` domain (`payment.company.com`) is the Route53 record ExternalDNS creates pointing to the ALB. Without ExternalDNS running, the domain doesn't resolve and the synthetic always fails.

**Ingress `host` value**
The hostname in the Kubernetes Ingress spec (`host: payment.company.com`). This is what ExternalDNS reads to create the DNS record. The `health_check_url` in Dynatrace should match this host plus the health endpoint path.
