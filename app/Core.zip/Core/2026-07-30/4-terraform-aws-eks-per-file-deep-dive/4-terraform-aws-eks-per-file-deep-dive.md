# 2026-07-30 · Seq 4 · Terraform AWS EKS Per-File Deep Dive

## Decision tree

```
need to understand terraform-aws-eks file-by-file?
 │
 ├─ root module wiring? → main.tf / node_groups.tf / variables.tf / outputs.tf / versions.tf
 ├─ managed nodes? → modules/eks-managed-node-group/* + templates + _user_data
 ├─ self-managed / Fargate / hybrid / Karpenter / capability? → matching modules/*
 ├─ upgrade / compute / network / user-data theory? → docs/*
 ├─ copy-paste patterns? → examples/*
 └─ CI golden / unit fixtures? → tests/*
```

```
which file open first?
  new to module → README.md → main.tf → node_groups.tf → outputs.tf
  auth issues → main.tf (access entries) + docs/faq.md + UPGRADE-21
  nodes NeverReady → docs/user_data.md + modules/_user_data + templates/*
  Karpenter AWS deps → modules/karpenter/{main,policy,outputs}.tf
```

## Short takeaway

| Key point | Detail |
|-----------|--------|
| Per-file docs | **144** markdown files under `files/` |
| Repo | `/Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-master` |
| Naming | `files/<path-with-__-and-->.md` mirrors repo path |
| Each md structure | Decision tree → takeaway → summary → inventory → connections → data flow |
| Companion overview | Seq 3 `3-terraform-aws-eks-deep-dive` (architecture) |

## Summary

Every meaningful source/docs/example/test file in the local `terraform-aws-eks` tree has its own deep-dive markdown: what the file is for, what resources/variables it declares, and how it connects in the Terraform graph. Use this index to jump; open the linked `files/*.md` for the file-level detail.

## Main content

### Root module

| File | Lines | Deep dive | Role |
|------|------:|-----------|------|
| `README.md` | 627 | [md](files/README-md.md) | Human documentation for this directory (usage, inputs overview, links). |
| `main.tf` | 954 | [md](files/main-tf.md) | Root orchestration: EKS cluster, access entries, KMS, SGs, OIDC/IRSA, cluster IAM, EKS … |
| `mkdocs.yml` | 65 | [md](files/mkdocs-yml.md) | MkDocs site config for publishing module docs. |
| `node_groups.tf` | 547 | [md](files/node_groups-tf.md) | Dataplane: time_sleep gate, IPv6 CNI policy, node SG, Fargate/MNG/SMNG child modules. |
| `outputs.tf` | 281 | [md](files/outputs-tf.md) | Root outputs: endpoint, OIDC, SGs, addon/node group maps for kubeconfig and downstream … |
| `variables.tf` | 1526 | [md](files/variables-tf.md) | All root module inputs (typed objects in v21): cluster, networking, IAM, addons, comput… |
| `versions.tf` | 24 | [md](files/versions-tf.md) | Terraform and provider version constraints + AWS provider user_agent metadata. |

### Repo tooling

| File | Lines | Deep dive | Role |
|------|------:|-----------|------|
| `.pre-commit-config.yaml` | 32 | [md](files/-pre-commit-config-yaml.md) | Pre-commit hooks (fmt, docs, tflint, etc.) for contributors. |
| `.releaserc.json` | 45 | [md](files/-releaserc-json.md) | Semantic-release configuration for module versioning. |
| `mkdocs.yml` | 65 | [md](files/mkdocs-yml.md) | MkDocs site config for publishing module docs. |

### docs/

| File | Lines | Deep dive | Role |
|------|------:|-----------|------|
| `docs/README.md` | 14 | [md](files/docs__README-md.md) | Official module documentation page: README.md. |
| `docs/UPGRADE-17.0.md` | 65 | [md](files/docs__UPGRADE-17-0-md.md) | Breaking-change upgrade guide for consumers moving to the version in the filename (UPGR… |
| `docs/UPGRADE-18.0.md` | 764 | [md](files/docs__UPGRADE-18-0-md.md) | Breaking-change upgrade guide for consumers moving to the version in the filename (UPGR… |
| `docs/UPGRADE-19.0.md` | 470 | [md](files/docs__UPGRADE-19-0-md.md) | Breaking-change upgrade guide for consumers moving to the version in the filename (UPGR… |
| `docs/UPGRADE-20.0.md` | 254 | [md](files/docs__UPGRADE-20-0-md.md) | Breaking-change upgrade guide for consumers moving to the version in the filename (UPGR… |
| `docs/UPGRADE-21.0.md` | 330 | [md](files/docs__UPGRADE-21-0-md.md) | Breaking-change upgrade guide for consumers moving to the version in the filename (UPGR… |
| `docs/compute_resources.md` | 153 | [md](files/docs__compute_resources-md.md) | Official module documentation page: compute_resources.md. |
| `docs/faq.md` | 315 | [md](files/docs__faq-md.md) | Official module documentation page: faq.md. |
| `docs/index.md` | 3 | [md](files/docs__index-md.md) | Official module documentation page: index.md. |
| `docs/local.md` | 20 | [md](files/docs__local-md.md) | Official module documentation page: local.md. |
| `docs/network_connectivity.md` | 67 | [md](files/docs__network_connectivity-md.md) | Official module documentation page: network_connectivity.md. |
| `docs/user_data.md` | 95 | [md](files/docs__user_data-md.md) | Official module documentation page: user_data.md. |

### templates/

| File | Lines | Deep dive | Role |
|------|------:|-----------|------|
| `templates/al2023_user_data.tpl` | 11 | [md](files/templates__al2023_user_data-tpl.md) | User-data template fragment consumed by modules/_user_data (al2023_user_data.tpl). |
| `templates/al2_user_data.tpl` | 12 | [md](files/templates__al2_user_data-tpl.md) | User-data template fragment consumed by modules/_user_data (al2_user_data.tpl). |
| `templates/bottlerocket_user_data.tpl` | 8 | [md](files/templates__bottlerocket_user_data-tpl.md) | User-data template fragment consumed by modules/_user_data (bottlerocket_user_data.tpl). |
| `templates/windows_user_data.tpl` | 13 | [md](files/templates__windows_user_data-tpl.md) | User-data template fragment consumed by modules/_user_data (windows_user_data.tpl). |

### modules/_user_data

| File | Lines | Deep dive | Role |
|------|------:|-----------|------|
| `modules/_user_data/README.md` | 61 | [md](files/modules___user_data__README-md.md) | Human documentation for this directory (usage, inputs overview, links). |
| `modules/_user_data/main.tf` | 138 | [md](files/modules___user_data__main-tf.md) | Renders bootstrap user data for AL2/AL2023/Bottlerocket/Windows from templates. |
| `modules/_user_data/outputs.tf` | 4 | [md](files/modules___user_data__outputs-tf.md) | Output values for modules/_user_data. |
| `modules/_user_data/variables.tf` | 121 | [md](files/modules___user_data__variables-tf.md) | Input variables for modules/_user_data. |
| `modules/_user_data/versions.tf` | 14 | [md](files/modules___user_data__versions-tf.md) | Provider/Terraform version constraints for this module or example. |

### modules/capability

| File | Lines | Deep dive | Role |
|------|------:|-----------|------|
| `modules/capability/README.md` | 172 | [md](files/modules__capability__README-md.md) | Human documentation for this directory (usage, inputs overview, links). |
| `modules/capability/main.tf` | 222 | [md](files/modules__capability__main-tf.md) | EKS capability resources (managed capability API wiring). |
| `modules/capability/outputs.tf` | 37 | [md](files/modules__capability__outputs-tf.md) | Output values for modules/capability. |
| `modules/capability/variables.tf` | 215 | [md](files/modules__capability__variables-tf.md) | Input variables for modules/capability. |
| `modules/capability/versions.tf` | 20 | [md](files/modules__capability__versions-tf.md) | Provider/Terraform version constraints for this module or example. |

### modules/eks-managed-node-group

| File | Lines | Deep dive | Role |
|------|------:|-----------|------|
| `modules/eks-managed-node-group/README.md` | 226 | [md](files/modules__eks-managed-node-group__README-md.md) | Human documentation for this directory (usage, inputs overview, links). |
| `modules/eks-managed-node-group/main.tf` | 843 | [md](files/modules__eks-managed-node-group__main-tf.md) | Creates one EKS managed node group: IAM, launch template, user data, aws_eks_node_group… |
| `modules/eks-managed-node-group/migrations.tf` | 20 | [md](files/modules__eks-managed-node-group__migrations-tf.md) | moved/state migration blocks for non-breaking refactors across module versions. |
| `modules/eks-managed-node-group/outputs.tf` | 95 | [md](files/modules__eks-managed-node-group__outputs-tf.md) | Output values for modules/eks-managed-node-group. |
| `modules/eks-managed-node-group/variables.tf` | 799 | [md](files/modules__eks-managed-node-group__variables-tf.md) | Input variables for modules/eks-managed-node-group. |
| `modules/eks-managed-node-group/versions.tf` | 16 | [md](files/modules__eks-managed-node-group__versions-tf.md) | Provider/Terraform version constraints for this module or example. |

### modules/self-managed-node-group

| File | Lines | Deep dive | Role |
|------|------:|-----------|------|
| `modules/self-managed-node-group/README.md` | 232 | [md](files/modules__self-managed-node-group__README-md.md) | Human documentation for this directory (usage, inputs overview, links). |
| `modules/self-managed-node-group/main.tf` | 1116 | [md](files/modules__self-managed-node-group__main-tf.md) | Creates one self-managed node group: IAM, launch template, ASG, access entry, optional … |
| `modules/self-managed-node-group/migrations.tf` | 20 | [md](files/modules__self-managed-node-group__migrations-tf.md) | moved/state migration blocks for non-breaking refactors across module versions. |
| `modules/self-managed-node-group/outputs.tf` | 157 | [md](files/modules__self-managed-node-group__outputs-tf.md) | Output values for modules/self-managed-node-group. |
| `modules/self-managed-node-group/variables.tf` | 1038 | [md](files/modules__self-managed-node-group__variables-tf.md) | Input variables for modules/self-managed-node-group. |
| `modules/self-managed-node-group/versions.tf` | 16 | [md](files/modules__self-managed-node-group__versions-tf.md) | Provider/Terraform version constraints for this module or example. |

### modules/fargate-profile

| File | Lines | Deep dive | Role |
|------|------:|-----------|------|
| `modules/fargate-profile/README.md` | 102 | [md](files/modules__fargate-profile__README-md.md) | Human documentation for this directory (usage, inputs overview, links). |
| `modules/fargate-profile/main.tf` | 190 | [md](files/modules__fargate-profile__main-tf.md) | Creates one EKS Fargate profile + IAM role for pod execution. |
| `modules/fargate-profile/migrations.tf` | 15 | [md](files/modules__fargate-profile__migrations-tf.md) | moved/state migration blocks for non-breaking refactors across module versions. |
| `modules/fargate-profile/outputs.tf` | 42 | [md](files/modules__fargate-profile__outputs-tf.md) | Output values for modules/fargate-profile. |
| `modules/fargate-profile/variables.tf` | 186 | [md](files/modules__fargate-profile__variables-tf.md) | Input variables for modules/fargate-profile. |
| `modules/fargate-profile/versions.tf` | 16 | [md](files/modules__fargate-profile__versions-tf.md) | Provider/Terraform version constraints for this module or example. |

### modules/hybrid-node-role

| File | Lines | Deep dive | Role |
|------|------:|-----------|------|
| `modules/hybrid-node-role/README.md` | 163 | [md](files/modules__hybrid-node-role__README-md.md) | Human documentation for this directory (usage, inputs overview, links). |
| `modules/hybrid-node-role/main.tf` | 396 | [md](files/modules__hybrid-node-role__main-tf.md) | IAM role (SSM / IAM Roles Anywhere) for EKS Hybrid Nodes. |
| `modules/hybrid-node-role/outputs.tf` | 37 | [md](files/modules__hybrid-node-role__outputs-tf.md) | Output values for modules/hybrid-node-role. |
| `modules/hybrid-node-role/variables.tf` | 284 | [md](files/modules__hybrid-node-role__variables-tf.md) | Input variables for modules/hybrid-node-role. |
| `modules/hybrid-node-role/versions.tf` | 16 | [md](files/modules__hybrid-node-role__versions-tf.md) | Provider/Terraform version constraints for this module or example. |

### modules/karpenter

| File | Lines | Deep dive | Role |
|------|------:|-----------|------|
| `modules/karpenter/README.md` | 209 | [md](files/modules__karpenter__README-md.md) | Human documentation for this directory (usage, inputs overview, links). |
| `modules/karpenter/main.tf` | 435 | [md](files/modules__karpenter__main-tf.md) | Karpenter AWS-side resources: controller IAM, Pod Identity, SQS/EventBridge, node role,… |
| `modules/karpenter/migrations.tf` | 77 | [md](files/modules__karpenter__migrations-tf.md) | moved/state migration blocks for non-breaking refactors across module versions. |
| `modules/karpenter/outputs.tf` | 112 | [md](files/modules__karpenter__outputs-tf.md) | Output values for modules/karpenter. |
| `modules/karpenter/policy.tf` | 419 | [md](files/modules__karpenter__policy-tf.md) | IAM policy documents for Karpenter controller permissions. |
| `modules/karpenter/variables.tf` | 355 | [md](files/modules__karpenter__variables-tf.md) | Input variables for modules/karpenter. |
| `modules/karpenter/versions.tf` | 16 | [md](files/modules__karpenter__versions-tf.md) | Provider/Terraform version constraints for this module or example. |

### examples/

| File | Lines | Deep dive | Role |
|------|------:|-----------|------|
| `examples/README.md` | 8 | [md](files/examples__README-md.md) | Example configuration file demonstrating module usage (examples/README.md). |
| `examples/eks-auto-mode/README.md` | 97 | [md](files/examples__eks-auto-mode__README-md.md) | Example configuration file demonstrating module usage (examples/eks-auto-mode/README.md). |
| `examples/eks-auto-mode/deployment.yaml` | 21 | [md](files/examples__eks-auto-mode__deployment-yaml.md) | Example configuration file demonstrating module usage (examples/eks-auto-mode/deploymen… |
| `examples/eks-auto-mode/main.tf` | 107 | [md](files/examples__eks-auto-mode__main-tf.md) | Example configuration file demonstrating module usage (examples/eks-auto-mode/main.tf). |
| `examples/eks-auto-mode/outputs.tf` | 245 | [md](files/examples__eks-auto-mode__outputs-tf.md) | Output values for examples/eks-auto-mode. |
| `examples/eks-auto-mode/variables.tf` | 0 | [md](files/examples__eks-auto-mode__variables-tf.md) | Input variables for examples/eks-auto-mode. |
| `examples/eks-auto-mode/versions.tf` | 10 | [md](files/examples__eks-auto-mode__versions-tf.md) | Provider/Terraform version constraints for this module or example. |
| `examples/eks-capabilities/README.md` | 74 | [md](files/examples__eks-capabilities__README-md.md) | Example configuration file demonstrating module usage (examples/eks-capabilities/README… |
| `examples/eks-capabilities/main.tf` | 163 | [md](files/examples__eks-capabilities__main-tf.md) | Example configuration file demonstrating module usage (examples/eks-capabilities/main.t… |
| `examples/eks-capabilities/outputs.tf` | 104 | [md](files/examples__eks-capabilities__outputs-tf.md) | Output values for examples/eks-capabilities. |
| `examples/eks-capabilities/variables.tf` | 0 | [md](files/examples__eks-capabilities__variables-tf.md) | Input variables for examples/eks-capabilities. |
| `examples/eks-capabilities/versions.tf` | 10 | [md](files/examples__eks-capabilities__versions-tf.md) | Provider/Terraform version constraints for this module or example. |
| `examples/eks-hybrid-nodes/README.md` | 85 | [md](files/examples__eks-hybrid-nodes__README-md.md) | Example configuration file demonstrating module usage (examples/eks-hybrid-nodes/README… |
| `examples/eks-hybrid-nodes/ami/amazon-eks-ubuntu.pkr.hcl` | 320 | [md](files/examples__eks-hybrid-nodes__ami__amazon-eks-ubuntu-pkr-hcl.md) | Example configuration file demonstrating module usage (examples/eks-hybrid-nodes/ami/am… |
| `examples/eks-hybrid-nodes/ami/plugins.pkr.hcl` | 8 | [md](files/examples__eks-hybrid-nodes__ami__plugins-pkr-hcl.md) | Example configuration file demonstrating module usage (examples/eks-hybrid-nodes/ami/pl… |
| `examples/eks-hybrid-nodes/ami/variables.pkr.hcl` | 723 | [md](files/examples__eks-hybrid-nodes__ami__variables-pkr-hcl.md) | Example configuration file demonstrating module usage (examples/eks-hybrid-nodes/ami/va… |
| `examples/eks-hybrid-nodes/main.tf` | 148 | [md](files/examples__eks-hybrid-nodes__main-tf.md) | Example configuration file demonstrating module usage (examples/eks-hybrid-nodes/main.t… |
| `examples/eks-hybrid-nodes/outputs.tf` | 0 | [md](files/examples__eks-hybrid-nodes__outputs-tf.md) | Output values for examples/eks-hybrid-nodes. |
| `examples/eks-hybrid-nodes/remote.tf` | 314 | [md](files/examples__eks-hybrid-nodes__remote-tf.md) | Example configuration file demonstrating module usage (examples/eks-hybrid-nodes/remote… |
| `examples/eks-hybrid-nodes/variables.tf` | 0 | [md](files/examples__eks-hybrid-nodes__variables-tf.md) | Input variables for examples/eks-hybrid-nodes. |
| `examples/eks-hybrid-nodes/versions.tf` | 26 | [md](files/examples__eks-hybrid-nodes__versions-tf.md) | Provider/Terraform version constraints for this module or example. |
| `examples/eks-managed-node-group/README.md` | 59 | [md](files/examples__eks-managed-node-group__README-md.md) | Example configuration file demonstrating module usage (examples/eks-managed-node-group/… |
| `examples/eks-managed-node-group/eks-al2023.tf` | 55 | [md](files/examples__eks-managed-node-group__eks-al2023-tf.md) | Example configuration file demonstrating module usage (examples/eks-managed-node-group/… |
| `examples/eks-managed-node-group/eks-bottlerocket.tf` | 56 | [md](files/examples__eks-managed-node-group__eks-bottlerocket-tf.md) | Example configuration file demonstrating module usage (examples/eks-managed-node-group/… |
| `examples/eks-managed-node-group/main.tf` | 55 | [md](files/examples__eks-managed-node-group__main-tf.md) | Creates one EKS managed node group: IAM, launch template, user data, aws_eks_node_group… |
| `examples/eks-managed-node-group/outputs.tf` | 0 | [md](files/examples__eks-managed-node-group__outputs-tf.md) | Output values for examples/eks-managed-node-group. |
| `examples/eks-managed-node-group/variables.tf` | 0 | [md](files/examples__eks-managed-node-group__variables-tf.md) | Input variables for examples/eks-managed-node-group. |
| `examples/eks-managed-node-group/versions.tf` | 10 | [md](files/examples__eks-managed-node-group__versions-tf.md) | Provider/Terraform version constraints for this module or example. |
| `examples/karpenter/README.md` | 131 | [md](files/examples__karpenter__README-md.md) | Example configuration file demonstrating module usage (examples/karpenter/README.md). |
| `examples/karpenter/inflate.yaml` | 21 | [md](files/examples__karpenter__inflate-yaml.md) | Example configuration file demonstrating module usage (examples/karpenter/inflate.yaml). |
| `examples/karpenter/karpenter.yaml` | 47 | [md](files/examples__karpenter__karpenter-yaml.md) | Example configuration file demonstrating module usage (examples/karpenter/karpenter.yam… |
| `examples/karpenter/main.tf` | 195 | [md](files/examples__karpenter__main-tf.md) | Karpenter AWS-side resources: controller IAM, Pod Identity, SQS/EventBridge, node role,… |
| `examples/karpenter/outputs.tf` | 0 | [md](files/examples__karpenter__outputs-tf.md) | Output values for examples/karpenter. |
| `examples/karpenter/variables.tf` | 0 | [md](files/examples__karpenter__variables-tf.md) | Input variables for examples/karpenter. |
| `examples/karpenter/versions.tf` | 14 | [md](files/examples__karpenter__versions-tf.md) | Provider/Terraform version constraints for this module or example. |
| `examples/self-managed-node-group/README.md` | 57 | [md](files/examples__self-managed-node-group__README-md.md) | Example configuration file demonstrating module usage (examples/self-managed-node-group… |
| `examples/self-managed-node-group/eks-al2023.tf` | 54 | [md](files/examples__self-managed-node-group__eks-al2023-tf.md) | Example configuration file demonstrating module usage (examples/self-managed-node-group… |
| `examples/self-managed-node-group/eks-bottlerocket.tf` | 56 | [md](files/examples__self-managed-node-group__eks-bottlerocket-tf.md) | Example configuration file demonstrating module usage (examples/self-managed-node-group… |
| `examples/self-managed-node-group/main.tf` | 55 | [md](files/examples__self-managed-node-group__main-tf.md) | Creates one self-managed node group: IAM, launch template, ASG, access entry, optional … |
| `examples/self-managed-node-group/outputs.tf` | 0 | [md](files/examples__self-managed-node-group__outputs-tf.md) | Output values for examples/self-managed-node-group. |
| `examples/self-managed-node-group/variables.tf` | 0 | [md](files/examples__self-managed-node-group__variables-tf.md) | Input variables for examples/self-managed-node-group. |
| `examples/self-managed-node-group/versions.tf` | 10 | [md](files/examples__self-managed-node-group__versions-tf.md) | Provider/Terraform version constraints for this module or example. |

### tests/

| File | Lines | Deep dive | Role |
|------|------:|-----------|------|
| `tests/eks-fargate-profile/README.md` | 91 | [md](files/tests__eks-fargate-profile__README-md.md) | Terratest / validation fixture for module behavior (tests/eks-fargate-profile/README.md). |
| `tests/eks-fargate-profile/main.tf` | 165 | [md](files/tests__eks-fargate-profile__main-tf.md) | Creates one EKS Fargate profile + IAM role for pod execution. |
| `tests/eks-fargate-profile/outputs.tf` | 245 | [md](files/tests__eks-fargate-profile__outputs-tf.md) | Output values for tests/eks-fargate-profile. |
| `tests/eks-fargate-profile/variables.tf` | 0 | [md](files/tests__eks-fargate-profile__variables-tf.md) | Input variables for tests/eks-fargate-profile. |
| `tests/eks-fargate-profile/versions.tf` | 10 | [md](files/tests__eks-fargate-profile__versions-tf.md) | Provider/Terraform version constraints for this module or example. |
| `tests/eks-hybrid-nodes/README.md` | 65 | [md](files/tests__eks-hybrid-nodes__README-md.md) | Terratest / validation fixture for module behavior (tests/eks-hybrid-nodes/README.md). |
| `tests/eks-hybrid-nodes/main.tf` | 84 | [md](files/tests__eks-hybrid-nodes__main-tf.md) | Terratest / validation fixture for module behavior (tests/eks-hybrid-nodes/main.tf). |
| `tests/eks-hybrid-nodes/outputs.tf` | 71 | [md](files/tests__eks-hybrid-nodes__outputs-tf.md) | Output values for tests/eks-hybrid-nodes. |
| `tests/eks-hybrid-nodes/variables.tf` | 0 | [md](files/tests__eks-hybrid-nodes__variables-tf.md) | Input variables for tests/eks-hybrid-nodes. |
| `tests/eks-hybrid-nodes/versions.tf` | 14 | [md](files/tests__eks-hybrid-nodes__versions-tf.md) | Provider/Terraform version constraints for this module or example. |
| `tests/eks-managed-node-group/README.md` | 101 | [md](files/tests__eks-managed-node-group__README-md.md) | Terratest / validation fixture for module behavior (tests/eks-managed-node-group/README… |
| `tests/eks-managed-node-group/main.tf` | 643 | [md](files/tests__eks-managed-node-group__main-tf.md) | Creates one EKS managed node group: IAM, launch template, user data, aws_eks_node_group… |
| `tests/eks-managed-node-group/outputs.tf` | 245 | [md](files/tests__eks-managed-node-group__outputs-tf.md) | Output values for tests/eks-managed-node-group. |
| `tests/eks-managed-node-group/variables.tf` | 0 | [md](files/tests__eks-managed-node-group__variables-tf.md) | Input variables for tests/eks-managed-node-group. |
| `tests/eks-managed-node-group/versions.tf` | 10 | [md](files/tests__eks-managed-node-group__versions-tf.md) | Provider/Terraform version constraints for this module or example. |
| `tests/self-managed-node-group/README.md` | 97 | [md](files/tests__self-managed-node-group__README-md.md) | Terratest / validation fixture for module behavior (tests/self-managed-node-group/READM… |
| `tests/self-managed-node-group/main.tf` | 501 | [md](files/tests__self-managed-node-group__main-tf.md) | Creates one self-managed node group: IAM, launch template, ASG, access entry, optional … |
| `tests/self-managed-node-group/outputs.tf` | 245 | [md](files/tests__self-managed-node-group__outputs-tf.md) | Output values for tests/self-managed-node-group. |
| `tests/self-managed-node-group/variables.tf` | 0 | [md](files/tests__self-managed-node-group__variables-tf.md) | Input variables for tests/self-managed-node-group. |
| `tests/self-managed-node-group/versions.tf` | 10 | [md](files/tests__self-managed-node-group__versions-tf.md) | Provider/Terraform version constraints for this module or example. |
| `tests/user-data/README.md` | 107 | [md](files/tests__user-data__README-md.md) | Terratest / validation fixture for module behavior (tests/user-data/README.md). |
| `tests/user-data/main.tf` | 672 | [md](files/tests__user-data__main-tf.md) | Terratest / validation fixture for module behavior (tests/user-data/main.tf). |
| `tests/user-data/outputs.tf` | 189 | [md](files/tests__user-data__outputs-tf.md) | Output values for tests/user-data. |
| `tests/user-data/rendered/al2/eks-mng-custom-ami-ipv6.sh` | 8 | [md](files/tests__user-data__rendered__al2__eks-mng-custom-ami-ipv6-sh.md) | Terratest / validation fixture for module behavior (tests/user-data/rendered/al2/eks-mn… |
| `tests/user-data/rendered/al2/eks-mng-custom-ami.sh` | 8 | [md](files/tests__user-data__rendered__al2__eks-mng-custom-ami-sh.md) | Terratest / validation fixture for module behavior (tests/user-data/rendered/al2/eks-mn… |
| `tests/user-data/rendered/al2/eks-mng-custom-template.sh` | 12 | [md](files/tests__user-data__rendered__al2__eks-mng-custom-template-sh.md) | Terratest / validation fixture for module behavior (tests/user-data/rendered/al2/eks-mn… |
| `tests/user-data/rendered/al2/eks-mng-no-op.sh` | 0 | [md](files/tests__user-data__rendered__al2__eks-mng-no-op-sh.md) | Terratest / validation fixture for module behavior (tests/user-data/rendered/al2/eks-mn… |
| `tests/user-data/rendered/al2/self-mng-bootstrap-ipv6.sh` | 9 | [md](files/tests__user-data__rendered__al2__self-mng-bootstrap-ipv6-sh.md) | Terratest / validation fixture for module behavior (tests/user-data/rendered/al2/self-m… |
| `tests/user-data/rendered/al2/self-mng-bootstrap.sh` | 9 | [md](files/tests__user-data__rendered__al2__self-mng-bootstrap-sh.md) | Terratest / validation fixture for module behavior (tests/user-data/rendered/al2/self-m… |
| `tests/user-data/rendered/al2/self-mng-custom-template.sh` | 12 | [md](files/tests__user-data__rendered__al2__self-mng-custom-template-sh.md) | Terratest / validation fixture for module behavior (tests/user-data/rendered/al2/self-m… |
| `tests/user-data/rendered/al2/self-mng-no-op.sh` | 0 | [md](files/tests__user-data__rendered__al2__self-mng-no-op-sh.md) | Terratest / validation fixture for module behavior (tests/user-data/rendered/al2/self-m… |
| `tests/user-data/templates/al2023_custom.tpl` | 15 | [md](files/tests__user-data__templates__al2023_custom-tpl.md) | User-data template fragment consumed by modules/_user_data (al2023_custom.tpl). |
| `tests/user-data/templates/bottlerocket_custom.tpl` | 7 | [md](files/tests__user-data__templates__bottlerocket_custom-tpl.md) | User-data template fragment consumed by modules/_user_data (bottlerocket_custom.tpl). |
| `tests/user-data/templates/linux_custom.tpl` | 11 | [md](files/tests__user-data__templates__linux_custom-tpl.md) | User-data template fragment consumed by modules/_user_data (linux_custom.tpl). |
| `tests/user-data/templates/windows_custom.tpl` | 10 | [md](files/tests__user-data__templates__windows_custom-tpl.md) | User-data template fragment consumed by modules/_user_data (windows_custom.tpl). |
| `tests/user-data/variables.tf` | 0 | [md](files/tests__user-data__variables-tf.md) | Input variables for tests/user-data. |
| `tests/user-data/versions.tf` | 10 | [md](files/tests__user-data__versions-tf.md) | Provider/Terraform version constraints for this module or example. |

### How to read a per-file doc

| Section in each `files/*.md` | Meaning |
|------------------------------|---------|
| Decision tree | When to open this file / what question it answers |
| Short takeaway | Path, line count, one-line role |
| Resource / variable / output inventory | Exact Terraform symbols (for `.tf`) |
| Section walkthrough | Extra depth for `main.tf` / `node_groups.tf` |
| How it connects | Upstream/downstream in the module graph |

### Priority reading order (if time-boxed)

| Order | File | Why |
|------:|------|-----|
| 1 | `README.md` | Usage patterns (Auto Mode, MNG, access entries) |
| 2 | `versions.tf` | TF/provider floors |
| 3 | `main.tf` | Control plane + IAM + OIDC + addons + access |
| 4 | `node_groups.tf` | Compute attachment |
| 5 | `variables.tf` / `outputs.tf` | Contract with callers |
| 6 | `modules/eks-managed-node-group/main.tf` | How nodes actually appear |
| 7 | `modules/karpenter/main.tf` + `policy.tf` | Autoscaler AWS deps |
| 8 | `docs/UPGRADE-21.0.md` | Breaking changes |
| 9 | `docs/user_data.md` + `templates/*` | Bootstrap failures |
| 10 | One `examples/*/main.tf` | End-to-end wiring with VPC |

## Data flow map

```
Caller module
  → variables.tf
  → main.tf (cluster, access, OIDC, addons)
  → node_groups.tf → modules/{mng|smng|fargate}
       → modules/_user_data → templates/*.tpl
  → outputs.tf
Optional: modules/karpenter, hybrid-node-role, capability
Docs/examples/tests explain and validate the above
```

## Related files

| Path | Role |
|------|------|
| This index | `4-terraform-aws-eks-per-file-deep-dive.md` |
| `files/*.md` | One deep dive per repo file (144) |
| `_file_index.tsv` | Machine-readable catalog |
| `4.sh` | List/count helpers |
| Seq 3 overview | `../3-terraform-aws-eks-deep-dive/` |

## Commands

See [`4.sh`](4.sh).
