ls "/Users/k/Learnings/AIProject/CursorFiles/Daily Files/2026-07-30/4-terraform-aws-eks-per-file-deep-dive/files" | wc -l
wc -l "/Users/k/Learnings/AIProject/CursorFiles/Daily Files/2026-07-30/4-terraform-aws-eks-per-file-deep-dive/_file_index.tsv"
head -20 "/Users/k/Learnings/AIProject/CursorFiles/Daily Files/2026-07-30/4-terraform-aws-eks-per-file-deep-dive/_file_index.tsv"
ls "/Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-master"/*.tf
find "/Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-master/modules" -name '*.tf' | sort
