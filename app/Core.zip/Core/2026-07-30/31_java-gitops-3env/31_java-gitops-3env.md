# Java EKS GitOps — Dev → Staging → Production (3 Environments)

> Full 3-environment promotion pipeline for a Java Spring Boot payment microservice. One EKS cluster per environment. Separate AWS accounts. Separate ECR registries. Manual approval gate before production.

---

## Environment Architecture

```
AWS Account: company-dev (123456789010)
  EKS: company-dev
  ECR: 123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  Domain: payment.dev.company.com
  Replicas: 1
  Resources: small (t3.medium nodes)

AWS Account: company-staging (123456789011)
  EKS: company-staging
  ECR: 123456789011.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  Domain: payment.staging.company.com
  Replicas: 2
  Resources: medium (m6g.large nodes)

AWS Account: company-prod (123456789012)
  EKS: company-prod
  ECR: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  Domain: payment.company.com
  Replicas: 3 (HPA: up to 20)
  Resources: full HA (m7g.xlarge nodes, 3 AZs)
```

---

## Promotion Flow

```
git push to main
    │
    ▼ Job 1: test (unit + JaCoCo coverage)
    │
    ▼ Job 2: build → push to DEV ECR → update gitops/dev → ArgoCD deploys
    │
    ▼ Job 3: smoke test dev (Actuator endpoints + API)
    │
    ▼ Job 4: promote dev→staging ECR → update gitops/staging → ArgoCD deploys
    │
    ▼ Job 5: staging tests (Actuator + k6 load test 50VUs)
    │
    ▼ Job 6: MANUAL APPROVAL (GitHub Environment gate: production)
    │         reviewer checks: staging passed? error budget? deploy window?
    │
    ▼ Job 7: promote staging→production ECR → update gitops/production → ArgoCD deploys
    │
    ▼ Job 8: verify production (smoke test + auto-rollback on failure)
```

---

## File Tree

```
31_java-gitops-3env/
│
├── .github/workflows/
│   └── app-ci.yaml               ← 8-job pipeline (build→dev→staging→prod)
│
├── charts/payment-service/
│   ├── Chart.yaml
│   ├── values.yaml               ← production defaults
│   ├── values-dev.yaml           ← dev: 1 replica, DEBUG logs, 20min startup timeout
│   ├── values-staging.yaml       ← staging: 2 replicas, load-test ready
│   └── templates/                ← Helm templates (shared by all envs)
│
├── gitops/
│   ├── dev/
│   │   ├── bootstrap/root-app-dev.yaml
│   │   ├── namespaces/namespaces.yaml
│   │   ├── networking/... (ALB, ExternalDNS)
│   │   ├── secrets/... (ESO, ClusterSecretStore)
│   │   ├── auto-scaling/karpenter/
│   │   ├── monitoring/dynatrace/
│   │   ├── security/kyverno/
│   │   └── app/payment-service/payment-service.yaml
│   ├── staging/
│   │   ├── bootstrap/root-app-staging.yaml
│   │   ├── namespaces/namespaces.yaml
│   │   └── app/payment-service/payment-service.yaml
│   └── production/
│       ├── bootstrap/root-app-production.yaml
│       ├── namespaces/namespaces.yaml
│       └── app/payment-service/payment-service.yaml
│
└── terraform/
    ├── environments/
    │   ├── dev/terraform.tfvars
    │   ├── staging/terraform.tfvars
    │   └── production/terraform.tfvars
    └── dynatrace/
        ├── dev.tfvars
        ├── staging.tfvars
        └── production.tfvars
```

---

## Bootstrap Commands (one-time per environment)

```bash
# ── DEV ──────────────────────────────────────────────────────────────────────
aws eks update-kubeconfig --name company-dev --region ap-northeast-1
kubectl create namespace argocd
kubectl apply -n argocd \
  -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
kubectl wait --for=condition=available --timeout=300s \
  deployment/argocd-server -n argocd
kubectl apply -f gitops/dev/bootstrap/root-app-dev.yaml
echo "Dev ArgoCD bootstrapped. Wait 5 minutes for all components to sync."

# ── STAGING ───────────────────────────────────────────────────────────────────
aws eks update-kubeconfig --name company-staging --region ap-northeast-1
kubectl create namespace argocd
kubectl apply -n argocd \
  -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
kubectl apply -f gitops/staging/bootstrap/root-app-staging.yaml

# ── PRODUCTION ────────────────────────────────────────────────────────────────
aws eks update-kubeconfig --name company-prod --region ap-northeast-1
kubectl create namespace argocd
kubectl apply -n argocd \
  -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
kubectl apply -f gitops/production/bootstrap/root-app-production.yaml
```

---

## Environment-specific Differences at a Glance

| Setting | Dev | Staging | Production |
|---|---|---|---|
| Replicas | 1 | 2 | 3 (HPA → 20) |
| CPU request | 100m | 200m | 500m |
| Memory limit | 512Mi | 768Mi | 1.5Gi |
| JVM Xmx | 256m | 512m | 1024m |
| Startup timeout | 20 min | 15 min | 12 min |
| PDB | disabled | minAvailable=1 | minAvailable=2 |
| Log level | DEBUG | INFO | WARN |
| SHOW_SQL | true | false | false |
| Spring profile | dev | staging | prod (default) |
| Auto-deploy | Yes | Yes | After manual approval |
