# Java GitOps 3-Environment — Glossary

**Environment promotion**
Moving a Docker image through a sequence of environments (dev → staging → production), with automated and manual validation gates between each step. Each environment must pass before the next receives the image.

**Multi-account AWS architecture**
Separate AWS accounts for each environment (dev: 123456789010, staging: 123456789011, prod: 123456789012). Hard isolation — dev credentials cannot touch prod resources, even if accidentally configured wrong.

**ECR per account**
Each AWS account has its own Elastic Container Registry. The image is copied between registries during promotion (not just retagged). This means prod ECR only ever holds images that passed dev AND staging validation.

**Image promotion (not rebuild)**
The same Docker image built once is promoted through environments. Staging tests the exact bytes that production will run. No "it works in staging but prod builds differently" surprises. The SHA tag is immutable.

**GitHub Environment gate**
A GitHub feature that pauses a workflow job until named reviewers click "Approve". Used before production deployment. The reviewer can check: did staging tests pass? Is the error budget healthy? Is it a safe deploy window?

**`environment: production` (workflow job)**
The YAML key that creates the approval pause. GitHub checks Settings → Environments → production → Required reviewers. The job does not run until an approved reviewer clicks the button.

**ArgoCD sync timeout (`Timeout=900`)**
A syncOption telling ArgoCD to wait up to 900 seconds (15 minutes) for a deployment to become healthy before marking it as failed. Java JVM startup is 30–120 seconds; without this timeout, ArgoCD marks the deployment as degraded during normal startup.

**`ignoreDifferences: /spec/replicas`**
An ArgoCD Application setting preventing ArgoCD from fighting the HPA. HPA changes `spec.replicas` at runtime (from 3 to 8 under load). ArgoCD would see this as "diverged from Git" and reset it to 3 on next sync. This setting tells ArgoCD to ignore that field.

**`valueFiles` (Helm in ArgoCD)**
A list of values files applied in order. Later files override earlier ones. `valueFiles: [values.yaml, values-dev.yaml]` = start with production defaults, override with dev-specific settings. Only the overrides are in values-dev.yaml.

**`values-dev.yaml`**
Dev-specific Helm overrides: smaller JVM heap (256m), DEBUG logging, 20-minute startup timeout, no PDB, 1 replica, pullPolicy=Always. These override the production defaults in values.yaml.

**`values-staging.yaml`**
Staging-specific overrides: 2 replicas, INFO logging, PDB minAvailable=1, larger heap than dev (512m), k6 load-test ready HPA (max=8). Production-equivalent configuration at half scale.

**Spring Boot Actuator**
A Spring Boot module that exposes operational HTTP endpoints. `/actuator/health/liveness` = is the JVM alive? `/actuator/health/readiness` = is the service ready for traffic (DB connected)? These replace the simple `/health` endpoint of Python services.

**`/actuator/health/liveness`**
The Kubernetes liveness probe endpoint for Spring Boot. Returns `{"status":"UP"}` if the JVM is running. Returns non-200 only if the JVM is truly broken (OutOfMemoryError, deadlock). Does NOT check DB.

**`/actuator/health/readiness`**
The Kubernetes readiness probe endpoint. Returns UP when all dependencies (DB, downstream services) are available. Returns OUT_OF_SERVICE (503) when any dependency is unavailable. Used by both Kubernetes and the ALB health check.

**JVM startup time**
Java applications take 30–120 seconds to start (load classes, compile JIT, establish DB connection pool, start Spring context). This is why startup probes have `failureThreshold: 60` (10 minutes) vs Python's `failureThreshold: 30`.

**JIT (Just-In-Time) compilation**
The JVM compiles hot code paths to native machine code at runtime. First 30 seconds: interpreted mode (slow). After JIT: near-native speed. k6 load test thresholds on staging use `p(99) < 800ms` (not 300ms) to account for the JIT warmup period.

**JaCoCo**
Java Code Coverage library. Measures what percentage of lines are executed by tests. `jacocoTestCoverageVerification` fails the build if coverage drops below the configured minimum (70% in this project).

**`-XX:+UseContainerSupport`**
JVM flag that makes the JVM detect its running inside a container and read memory limits from cgroups (not from host RAM). Without this: JVM thinks it has 64GB RAM (the node), sets heap to 16GB, and immediately OOM kills.

**`-XX:MaxRAMPercentage=75.0`**
JVM flag setting heap to 75% of the container memory limit. With container limit 1536Mi: heap = 1536 × 0.75 = 1152MB. The remaining 25% is for: JVM non-heap (metaspace, code cache), Java thread stacks, off-heap allocations.

**`-XX:+UseG1GC`**
Selects the G1 (Garbage First) garbage collector. Designed for large heaps (≥4GB) but also works well on medium heaps (512MB+). Gives more predictable GC pause times vs the default parallel GC. Good for latency-sensitive services.

**`-XX:MaxGCPauseMillis=200`**
Hints to G1GC to try to keep GC pauses under 200ms. Not a hard guarantee — G1GC uses this to tune region sizes. Too low (50ms) causes more frequent but shorter pauses. 200ms is a reasonable starting point.

**JVM heap utilisation alert (75%)**
When JVM heap exceeds 75% of Xmx, G1GC starts running major collections more frequently. P99 latency starts climbing. Alert at 75% (not 90%) to give time to investigate before users notice. Production: 70% threshold.

**k6 load test**
An open-source load testing tool. `k6 run --vus 50 --duration 3m` runs 50 virtual users for 3 minutes. Used in staging to validate the service handles production-like traffic before promotion. Thresholds check P99 latency and error rate.

**`docker pull + tag + push`**
The image promotion mechanism. Dev image is pulled from DEV ECR, retagged, and pushed to STAGING ECR. This copies the exact same image bytes — no rebuild. The SHA tag ensures it's the same image that was tested in dev.

**`git pull origin main` before commit**
The gitops update step pulls latest main before making the image tag commit. Without this: concurrent pipeline runs could push conflicting commits, causing `git push` to fail on a non-fast-forward error.

**Auto-rollback**
When production smoke tests fail, the pipeline reads the previous image tag from git history and updates the gitops file to revert to it. ArgoCD detects the git change and rolls the deployment back. Fully automatic — no manual intervention needed.

**`PREV_TAG=$(git log --oneline -- file | awk 'NR==2{...}')`**
Shell command reading the second-most-recent git commit that touched the production gitops file, then extracting the image tag from that commit. This is how auto-rollback finds the previous version.

**Separate OIDC roles per account**
Each AWS account (dev, staging, prod) has its own `github-actions-ecr-push` IAM role. The dev role can only push to dev ECR. The prod role can only push to prod ECR. Prevents a compromised dev pipeline from pushing to prod ECR.

**`registries` parameter (amazon-ecr-login)**
Specifies which AWS account's ECR to log into. When promoting images (pulling from dev ECR, pushing to staging ECR), you need to authenticate twice — once per account. `registries: "123456789010"` logs into account 123456789010's ECR only.

**Dynatrace `jvm_heap_pct` per environment**
Dev: 80% (small heap hits limit faster). Staging: 78% (medium heap). Production: 70% (large heap, early warning for GC pressure). Different thresholds reflect different heap sizes and criticality levels.

**`traffic_min_rps = 0` in dev**
Disabling the traffic drop alert for dev. Dev clusters have natural quiet periods (nobody testing at 3am, developer's workstation off). Setting traffic_min_rps=0 skips the traffic drop alert for that environment.
