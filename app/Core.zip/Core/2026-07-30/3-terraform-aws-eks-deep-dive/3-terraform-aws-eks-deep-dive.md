# 2026-07-30 · Seq 3 · Terraform AWS EKS Deep Dive

## Decision tree

```
need Amazon EKS via Terraform?
 │
 ├─ which compute model?
 │    ├─ EKS Auto Mode → compute_config.enabled=true (+ node_pools or custom)
 │    ├─ Managed node groups → eks_managed_node_groups = { ... }
 │    ├─ Self-managed ASG → self_managed_node_groups = { ... }
 │    ├─ Fargate → fargate_profiles = { selectors... }
 │    └─ Hybrid nodes → remote_network_config + modules/hybrid-node-role
 │
 ├─ kubectl / CI can’t auth after create?
 │    → enable_cluster_creator_admin_permissions = true
 │    → or add access_entries for CI role / humans
 │    → v21: aws-auth submodule REMOVED — use Access Entries (API)
 │
 ├─ pods need AWS API (ALB, Secrets, S3)?
 │    → enable_irsa = true (OIDC provider)  AND/OR
 │    → eks-pod-identity-agent addon + Pod Identity associations
 │    → Karpenter submodule: Pod Identity default (IRSA path removed in v21)
 │
 ├─ CNI/CoreDNS fail before nodes Ready?
 │    → addons with before_compute=true (vpc-cni, pod-identity-agent)
 │    → dataplane_wait_duration / time_sleep between cluster and nodes
 │
 ├─ Auto Mode won’t turn off?
 │    → MUST apply compute_config = { enabled = false } first
 │    → only then remove the block (README caution)
 │
 ├─ this module vs Blueprints / add-ons repo?
 │    → THIS = cluster + IAM + OIDC + node groups + EKS addons API
 │    → Blueprints/add-ons = higher-level patterns + Argo GitOps charts
 │    → VPC usually separate (terraform-aws-modules/vpc)
 │
 └─ upgrade pain?
      → read docs/UPGRADE-21.0.md before bumping ~> 21.0
      → TF >= 1.5.7, AWS provider >= 6.52 (this zip)
```

```
create order (what Terraform actually does)
  IAM cluster role → (optional KMS) → aws_eks_cluster
       → CW log group / cluster SG / OIDC
       → access entries
       → addons before_compute
       → time_sleep(dataplane_wait)
       → MNG / SMNG / Fargate
       → remaining addons (after compute)
```

## Short takeaway

| Key point | Detail |
|-----------|--------|
| What it is | Official **terraform-aws-modules/eks** (~v21) — creates EKS control plane + compute + IAM/OIDC/access |
| Local path | `/Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-master` |
| Not included | VPC (use VPC module), Argo/GitOps add-ons (separate repos) |
| Entry point | Root `module "eks"` → `main.tf` + `node_groups.tf` + child `modules/*` |
| Auth model (v21) | **Access Entries** (`access_entries`); `aws-auth` submodule gone |
| IRSA | `enable_irsa` → `aws_iam_openid_connect_provider` → output `oidc_provider_arn` |
| Compute maps | `eks_managed_node_groups`, `self_managed_node_groups`, `fargate_profiles`, Auto Mode `compute_config` |
| Submodules | `eks-managed-node-group`, `self-managed-node-group`, `fargate-profile`, `karpenter`, `capability`, `hybrid-node-role`, `_user_data` |

## Summary

This tree is the community-standard Terraform module for Amazon EKS. Call the root module with VPC/subnet IDs and a compute choice; it creates the control plane, security groups, optional KMS, OIDC for IRSA, Access Entries, EKS Add-ons (split before/after compute), and node/Fargate/Auto Mode resources. Use the Karpenter submodule for controller IAM + SQS + node instance profile; wire Helm/GitOps separately (e.g. eks-blueprints-add-ons).

## Main content

### 1. What this repo is (and is not)

| Is | Is not |
|----|--------|
| Terraform module to create **EKS cluster + compute + IAM plumbing** | Full platform (no Argo, no app Helm) |
| Source you publish as `terraform-aws-modules/eks/aws` | A VPC module (examples pull VPC separately) |
| Submodules for MNG, SMNG, Fargate, Karpenter IAM, Hybrid role | Your payment-service application code |
| Docs + examples + upgrade guides | Blueprints “pattern” wrappers |

**Registry usage:**

```hcl
module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 21.0"
  # ...
}
```

Local study path = unzipped `master` of that module.

### 2. Repo map

```
terraform-aws-eks-master/
├── main.tf              ← cluster, access entries, KMS, SG, OIDC, IAM, addons, Auto Mode IAM
├── node_groups.tf       ← time_sleep, node SG, fargate/MNG/SMNG module for_each
├── variables.tf         ← large typed object vars (v21 style)
├── outputs.tf           ← endpoint, OIDC, SGs, node group maps, …
├── versions.tf          ← TF >= 1.5.7; aws >= 6.52; tls; time
├── modules/
│   ├── eks-managed-node-group/
│   ├── self-managed-node-group/
│   ├── fargate-profile/
│   ├── karpenter/       ← IAM + SQS + events + instance profile + Pod Identity
│   ├── hybrid-node-role/
│   ├── capability/
│   └── _user_data/      ← AL2023 / Bottlerocket / AL2 bootstrap fragments
├── examples/            ← auto-mode, MNG, SMNG, karpenter, hybrid, capabilities
├── tests/
├── docs/                ← compute, user_data, network, FAQ, UPGRADE-17…21
└── templates/
```

### 3. Requirements (this zip)

| Tool | Constraint |
|------|------------|
| Terraform | `>= 1.5.7` |
| hashicorp/aws | `>= 6.52` |
| hashicorp/tls | `>= 4.0` |
| hashicorp/time | `>= 0.9` |

`local.create = var.create && var.putin_khuylo` — module refuses to create if that bool is false (project stance variable; default `true`).

---

### 4. End-to-end create path (step by step)

#### Step 4.1 — Prerequisites outside this module

```
1. AWS account + credentials
2. VPC with private (+ usually public) subnets across ≥2 AZs
3. Tag subnets for LB discovery:
     public:  kubernetes.io/role/elb = 1
     private: kubernetes.io/role/internal-elb = 1
4. Decide K8s version (examples use 1.33)
5. Decide compute model (Auto / MNG / SMNG / Fargate / Hybrid)
```

Examples use `terraform-aws-modules/vpc/aws` ~> 6.0 — **not** bundled here.

#### Step 4.2 — Minimal module call shape

```hcl
module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 21.0"

  name               = "payment-eks"
  kubernetes_version = "1.33"

  vpc_id     = module.vpc.vpc_id
  subnet_ids = module.vpc.private_subnets

  endpoint_public_access                   = true   # tighten for prod
  enable_cluster_creator_admin_permissions = true

  # compute: pick one pattern from sections below
}
```

#### Step 4.3 — Cluster IAM role

`main.tf` creates (if `create_iam_role`):

- Assume role: `eks.amazonaws.com` (+ `ec2` on Outposts)
- Policies depend on mode:
  - **Standard:** `AmazonEKSClusterPolicy`
  - **Auto Mode:** + Compute / BlockStorage / LoadBalancing / Networking policies
  - **Outposts:** local outpost cluster policy

#### Step 4.4 — `aws_eks_cluster`

Key fields wired by the module:

| Setting | Variable / behavior |
|---------|---------------------|
| Name / version | `name`, `kubernetes_version` |
| Auth | `authentication_mode` (Access Entries era) |
| Creator admin bootstrap API flag | **Hardcoded false** — use Access Entry instead |
| Self-managed addons bootstrap | **Hardcoded false** — use `addons` map |
| VPC | `subnet_ids`, optional `control_plane_subnet_ids`, endpoint public/private, CIDRs |
| Encryption | `encryption_config` + optional `module.kms` |
| Auto Mode | `compute_config` (+ storage/ELB toggles tied to same block) |
| Provisioned CP | `control_plane_scaling_config.tier` |
| Hybrid | `remote_network_config` |
| Logs | `enabled_log_types` + optional CW log group |
| Deletion protection | `deletion_protection` |

#### Step 4.5 — Cluster security group

Creates cluster SG (+ rules) unless you pass `security_group_id`. Additional rules via `security_group_additional_rules`. Primary SG from EKS can be tagged (`create_primary_security_group_tags`).

#### Step 4.6 — Access Entries (replace aws-auth)

```
enable_cluster_creator_admin_permissions
  → injects access entry for current STS issuer ARN
  → AmazonEKSClusterAdminPolicy, scope=cluster

access_entries = {
  ci = {
    principal_arn = "arn:aws:iam::ACCOUNT:role/github-actions"
    policy_associations = {
      admin = {
        policy_arn = "arn:aws:eks::aws:cluster-access-policy/AmazonEKSClusterAdminPolicy"
        access_scope = { type = "cluster" }
      }
    }
  }
}
```

Resources: `aws_eks_access_entry` + `aws_eks_access_policy_association`.

**v21:** `aws-auth` ConfigMap submodule **removed**. Managed node / Fargate roles get entries from AWS when using API auth modes; SMNG + Karpenter node roles get entries created by this project.

#### Step 4.7 — Encryption / KMS

- Default EKS encrypts secrets at rest; custom CMK via `create_kms_key` + `encryption_config`
- To use AWS-managed path: `encryption_config = null` (v21 semantics — empty `{}` no longer means “disable”)
- Not available on Outposts local clusters

#### Step 4.8 — IRSA (OIDC provider)

```
enable_irsa = true (default path for classic IRSA)
  → tls_certificate from cluster OIDC issuer
  → aws_iam_openid_connect_provider
  → outputs: oidc_provider_arn, cluster_oidc_issuer_url
```

Downstream: create IAM roles trusting `oidc-eks...` with SA subject conditions (often via `terraform-aws-iam` IRSA module or Blueprints). **This root module does not create per-addon IRSA roles** except Auto Mode / shared node role pieces.

Also distinct: `identity_providers` → `aws_eks_identity_provider_config` (OIDC IdP for **users**, not IRSA).

#### Step 4.9 — EKS Add-ons (two waves)

```
addons = {
  vpc-cni = { before_compute = true }
  eks-pod-identity-agent = { before_compute = true }
  coredns = {}
  kube-proxy = {}
}
```

| Wave | Resource | Depends on |
|------|----------|------------|
| `before_compute = true` | `aws_eks_addon.before_compute` | Cluster (runs **before** nodes) |
| default | `aws_eks_addon.this` | Fargate + MNG + SMNG modules |

Supports: version / `most_recent`, `configuration_values`, `service_account_role_arn` (IRSA for addon), Pod Identity associations, conflict resolve, timeouts, preserve.

v21 defaults called out in upgrade guide: `most_recent=true`, `resolve_conflicts_on_create=NONE`.

#### Step 4.10 — Dataplane wait

`time_sleep.this` with `dataplane_wait_duration` gates node groups / Fargate so before-compute addons can settle. Triggers include name, endpoint, version, CA, service CIDR — also used as stable references into child modules.

#### Step 4.11 — Node security group

Shared node SG with EKS-recommended rules (API→443/10250, CoreDNS, ephemeral, etc.). Toggle recommended set with `node_security_group_enable_recommended_rules`. Extra rules: `node_security_group_additional_rules`.

#### Step 4.12 — Compute modules (`node_groups.tf`)

| Map variable | Child module |
|--------------|--------------|
| `fargate_profiles` | `./modules/fargate-profile` |
| `eks_managed_node_groups` | `./modules/eks-managed-node-group` |
| `self_managed_node_groups` | `./modules/self-managed-node-group` |

Each `for_each` key = logical name; values are rich typed objects (AMI, sizing, taints, LT, IAM, etc.).

---

### 5. Compute models — deep dive

#### 5.1 EKS Auto Mode

```hcl
compute_config = {
  enabled    = true
  node_pools = ["general-purpose"]  # or omit for custom pools only
}
# OR create_auto_mode_iam_resources = true with enabled compute
```

- Module attaches Auto Mode IAM policies to cluster role
- Creates `aws_iam_role.eks_auto` for node role when node_pools set
- Disabling: **must** apply `enabled = false` before removing the block

**When:** least node ops; AWS owns more of data plane.

#### 5.2 EKS Managed Node Groups

```hcl
eks_managed_node_groups = {
  general = {
    ami_type       = "AL2023_x86_64_STANDARD"  # v21 default
    instance_types = ["m5.xlarge"]
    min_size = 2
    max_size = 10
    desired_size = 2
  }
}
```

Child module highlights:

- Custom launch template **by default** (tags, user data); set `use_custom_launch_template = false` for AWS default LT
- Bottlerocket via `ami_type = BOTTLEROCKET_*` + TOML `bootstrap_extra_args`
- Custom AMI → must handle bootstrap (`enable_bootstrap_user_data`, `cloudinit_pre_nodeadm` for AL2023 NodeConfig)
- `_user_data` submodule builds MIME / nodeadm / Bottlerocket fragments
- v21: IMDS hop limit **1**, monitoring default off, `use_latest_ami_release_version` true, ASG schedules removed

**When:** standard production default for many teams.

#### 5.3 Self-managed node groups

ASG + LT you own more fully (custom AMI pipelines, special networking). Same user-data story; module can create Access Entry for node role. More ops burden than MNG.

#### 5.4 Fargate profiles

```hcl
fargate_profiles = {
  default = {
    selectors = [{ namespace = "kube-system" }]
  }
}
```

No EC2 nodes for selected pods; still need CoreDNS strategy (often Fargate profile for kube-system or MNG for DNS). IAM role per profile created by submodule.

#### 5.5 Hybrid nodes

- `remote_network_config` CIDRs for remote nodes/pods
- `modules/hybrid-node-role` for node IAM (SSM or IAM Roles Anywhere)
- SG rules to allow remote CIDR traffic
- See `examples/eks-hybrid-nodes`

#### 5.6 Choosing compute (SRE view)

| Workload | Prefer |
|----------|--------|
| General microservices | MNG AL2023 or Auto Mode |
| Burst / diverse instance needs | Karpenter (+ small MNG for system) |
| Strong isolation / no node patching | Fargate |
| On-prem / edge joined to EKS | Hybrid |
| GPU / EFA / placement groups | MNG/SMNG with explicit `subnet_ids` (v21: no auto-pick) |

---

### 6. Karpenter submodule (step by step)

**Not** installed by root `module.eks` automatically — call separately:

```hcl
module "karpenter" {
  source  = "terraform-aws-modules/eks/aws//modules/karpenter"
  version = "~> 21.0"

  cluster_name = module.eks.cluster_name
  # ...
}
```

What it creates (from `modules/karpenter`):

| Piece | Purpose |
|-------|---------|
| Controller IAM role + policy | EC2/SQS/IAM permissions for Karpenter |
| `aws_eks_pod_identity_association` | Default identity path in v21 (IRSA removed) |
| SQS queue + policy | Spot interruption / rebalance events |
| EventBridge rules → SQS | EC2 state change, Spot interruption, etc. |
| Node IAM role + instance profile | EC2 nodes Karpenter launches |
| Access entry for node role | Cluster join auth |

Outputs to wire into Helm/GitOps: `iam_role_arn`, `queue_name`, `instance_profile_name`, `node_iam_role_arn`, namespace/SA names.

**Helm chart itself** still comes from GitOps (eks-blueprints-add-ons ApplicationSet) or Helm provider — this submodule is **AWS side only**.

---

### 7. Networking & endpoints (checklist)

| Concern | Knob |
|---------|------|
| Private-only API | `endpoint_private_access=true`, `endpoint_public_access=false` + VPN/bastion/SG |
| Public API lockdown | `endpoint_public_access_cidrs` |
| Control plane in dedicated subnets | `control_plane_subnet_ids` vs worker `subnet_ids` |
| IPv6 | `ip_family`, `create_cni_ipv6_iam_policy` |
| Pod SG | attach `AmazonEKSVPCResourceController` via `iam_role_additional_policies` (v21 removed dedicated toggle) |
| Egress mode | `control_plane_egress_mode` |

See `docs/network_connectivity.md`.

---

### 8. Outputs you will actually use

| Output | Typical consumer |
|--------|------------------|
| `cluster_name` / `cluster_endpoint` / `cluster_certificate_authority_data` | kubeconfig, providers |
| `oidc_provider_arn` / `cluster_oidc_issuer_url` | IRSA role trust |
| `cluster_security_group_id` / `node_security_group_id` | Extra SG rules, RDS allowlists |
| `eks_managed_node_groups` | ASG names, node role ARNs |
| `cluster_addons` | Addon status map |
| Karpenter module outputs | Helm values / GitOps annotations |

---

### 9. How this fits your platform stack

```
terraform-aws-modules/vpc
        │
        ▼
terraform-aws-eks  (THIS REPO)
  → cluster + OIDC + MNG/Auto + EKS addons (vpc-cni, …)
        │
        ├─► modules/karpenter  → IAM/SQS/profile
        │
        ▼
eks-blueprints / GitOps Bridge (optional)
  → Argo cluster Secret annotations (role ARNs, enable_* labels)
        │
        ▼
eks-blueprints-add-ons (Git)
  → ApplicationSets install LB controller, Fluent Bit, Prometheus, …
        │
        ▼
App GitOps (payment-service Helm)
```

**Ownership split:**

| This module | Not this module |
|-------------|-----------------|
| EKS API, node IAM, OIDC, Access Entries, EKS Addons API | ALB controller Helm, Argo apps |
| Karpenter AWS deps | Karpenter Helm values / NodePool CRs |
| Cluster logging to CW | App logs → Loki/Fluent Bit config |

---

### 10. Step-by-step lab (recommended study order)

1. Read README Usage: Auto Mode + Managed Node Group samples.  
2. Trace `main.tf`: cluster → access → KMS → SG → OIDC → IAM → addons.  
3. Trace `node_groups.tf`: sleep → node SG → `module.eks_managed_node_group`.  
4. Open `examples/eks-managed-node-group` (VPC + module wiring).  
5. Open `examples/karpenter` + `modules/karpenter/main.tf`.  
6. Skim `docs/UPGRADE-21.0.md` breaking list.  
7. Skim `docs/user_data.md` + `modules/_user_data`.  
8. Map outputs → what Blueprints/add-ons need for IRSA annotations.

---

### 11. SRE pitfalls

1. **No kubectl after apply** — forgot creator admin Access Entry / CI role entry.  
2. **Stuck CNI** — vpc-cni not `before_compute`; or private nodes without egress to ECR/API.  
3. **IRSA 403** — OIDC provider missing (`enable_irsa`), wrong issuer/thumbprint, SA annotation typo.  
4. **Karpenter v21** — expect Pod Identity, not IRSA, in the submodule.  
5. **Auto Mode disable** — must set `enabled=false` in a dedicated apply.  
6. **IMDS hop 1** — pods that scraped node IMDS break; use IRSA/Pod Identity instead.  
7. **Custom AMI without bootstrap** — nodes Never Ready.  
8. **EFA / placement** — you must pass correct `subnet_ids` yourself (v21).  
9. **Encryption var change** — `encryption_config = null` vs old `{}`.  
10. **Don’t treat this as Blueprints** — patterns/GitOps live elsewhere; this is the cluster foundation.

---

### 12. Examples directory quick index

| Example | Focus |
|---------|--------|
| `eks-auto-mode` | Auto Mode compute |
| `eks-managed-node-group` | AL2023 / Bottlerocket MNGs + VPC |
| `self-managed-node-group` | ASG-based nodes |
| `karpenter` | Cluster + Karpenter AWS submodule |
| `eks-hybrid-nodes` | Remote networks + hybrid role |
| `eks-capabilities` | Capability submodule usage |

## Data flow map

```
[Operator / CI]
   terraform apply
        │
        ▼
[Root module: terraform-aws-eks]
   ├─ IAM role (eks.amazonaws.com)
   ├─ (optional) KMS CMK
   ├─ aws_eks_cluster ──► EKS control plane (API / etcd)
   ├─ Cluster SG + Node SG
   ├─ CW log group (API/audit/authenticator/…)
   ├─ OIDC provider ──► IRSA trust for addon/app roles
   ├─ Access Entries ──► IAM principals → K8s RBAC via EKS policies
   ├─ addons before_compute (vpc-cni, pod-identity-agent, …)
   ├─ time_sleep
   ├─ MNG / SMNG / Fargate ──► worker capacity
   └─ addons after_compute (coredns, …)
        │
        ├─► [modules/karpenter] IAM + SQS + instance profile + Pod Identity
        │
        ▼
[kubectl / Argo / Helm]
   use endpoint + CA + IAM auth
        │
        ▼
[Workloads] ──IRSA/Pod Identity──► [AWS APIs: ELB, SQS, Secrets, …]
```

## Related files

| File | Role |
|------|------|
| [`3-terraform-aws-eks-deep-dive.md`](3-terraform-aws-eks-deep-dive.md) | This deep dive |
| [`3.sh`](3.sh) | Inspect commands |
| Local module | `/Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-master` |
| Upstream | https://github.com/terraform-aws-modules/terraform-aws-eks |
| Companion add-ons dive | `Daily Files/2026-07-30/2-eks-blueprints-add-ons-deep-dive/` |
| Upgrade | `docs/UPGRADE-21.0.md` in local tree |

## Commands

See [`3.sh`](3.sh).

```bash
ls "/Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-master"
ls "/Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-master/modules"
ls "/Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-master/examples"
rg -n "^resource |^module " "/Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-master/main.tf"
rg -n "^module " "/Users/k/Codes/GithubProjects/Terraform/terraform-aws-eks-master/node_groups.tf"
```
