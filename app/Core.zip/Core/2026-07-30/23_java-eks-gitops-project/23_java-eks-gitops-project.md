# Java EKS GitOps Project — Complete Deep Dive

> **What this is:** The same dev → staging → production pipeline as the Python project, rebuilt for a Java (Spring Boot) payment microservice. Same AWS infrastructure, same ArgoCD GitOps, same Dynatrace monitoring — but Java-specific: JVM tuning, Gradle build, JVM heap monitoring, G1GC, Spring Boot Actuator health endpoints.

---

## Java vs Python: What Changes

```
JAVA-SPECIFIC CHANGES:
  app/                   ← Spring Boot (Java 21) instead of FastAPI (Python)
  app/Dockerfile         ← Multi-stage Gradle build, JVM flags, G1GC
  app/build.gradle       ← Gradle build file (replaces requirements.txt)
  app/src/               ← src/main/java + src/test/java structure

  charts/payment-service/values.yaml
    memory limits: 512Mi → 1Gi (JVM needs headroom for heap + metaspace)
    startupProbe failureThreshold: 30 → 60 (JVM takes longer to start)
    JVM_OPTS: -Xms256m -Xmx512m -XX:+UseG1GC env var added

  terraform/dynatrace/variables.tf
    is_jvm_service = true for ALL services (they're Java)
    jvm_heap_pct = 75 (alert at 75% heap, before GC thrashing)

  .github/workflows/app-ci.yaml
    maven/gradle cache instead of pip cache
    JUnit XML reports instead of pytest XML

SAME AS PYTHON VERSION:
  3-environment promotion (dev → staging → production)
  terraform/ infrastructure (VPC, EKS, IAM, Karpenter)
  gitops/ ArgoCD Applications
  Dynatrace metric events, SLOs, synthetics
  All promotion gates and approval flows
```

---

## Project File Map

```
23_java-eks-gitops-project/
  ├── app/
  │   ├── src/main/java/com/company/payment/
  │   │   ├── PaymentApplication.java        ← Spring Boot entry point
  │   │   ├── controller/PaymentController.java  ← REST endpoints
  │   │   ├── health/ReadinessIndicator.java  ← custom readiness check
  │   │   └── model/Payment.java             ← domain model
  │   ├── src/main/resources/
  │   │   └── application.yaml              ← Spring Boot config
  │   ├── src/test/java/com/company/payment/
  │   │   └── PaymentControllerTest.java    ← JUnit 5 tests
  │   ├── build.gradle                      ← dependencies + build config
  │   ├── settings.gradle                   ← project name
  │   └── Dockerfile                        ← multi-stage Gradle → JRE
  │
  ├── charts/payment-service/
  │   ├── Chart.yaml
  │   ├── values.yaml                       ← production defaults
  │   ├── values-dev.yaml                   ← dev overrides
  │   ├── values-staging.yaml               ← staging overrides
  │   └── templates/                        ← (same as Python version)
  │       ├── deployment.yaml
  │       ├── service.yaml
  │       ├── ingress.yaml
  │       ├── hpa.yaml
  │       ├── pdb.yaml
  │       ├── serviceaccount.yaml
  │       └── external-secret.yaml
  │
  ├── gitops/
  │   ├── dev/bootstrap/root-app-dev.yaml
  │   ├── dev/app/payment-service/payment-service.yaml
  │   ├── staging/bootstrap/root-app-staging.yaml
  │   ├── staging/app/payment-service/payment-service.yaml
  │   └── production/bootstrap/ + app/
  │
  ├── terraform/
  │   ├── environments/{dev,staging,production}/terraform.tfvars
  │   ├── dynatrace/{dev,staging,production}.tfvars
  │   └── modules/{vpc,eks}/     (unchanged from Python version)
  │
  └── .github/workflows/
      ├── app-ci.yaml             ← Gradle build + Java-specific tests
      ├── terraform-infra.yaml    ← identical to Python version
      └── terraform-dynatrace.yaml ← identical to Python version
```

---

## Java vs Python: Memory Sizing

```
PYTHON (FastAPI + uvicorn):
  Base RSS: ~50MB
  Per request overhead: minimal
  memory request: 128Mi (dev) / 256Mi (staging) / 512Mi (prod)
  memory limit:   256Mi (dev) / 512Mi (staging) / 1Gi   (prod)

JAVA (Spring Boot + JVM):
  Base RSS: ~200MB (JVM startup, class loading, metaspace)
  JVM heap (-Xmx): explicit upper bound
  JVM non-heap: metaspace (~100MB), code cache (~50MB), JVM overhead
  
  FORMULA: container_memory_limit = Xmx + 250MB (non-heap overhead)
    dev:     Xmx=256m  → limit = 256 + 250 = ~512Mi
    staging: Xmx=512m  → limit = 512 + 250 = ~768Mi → use 1Gi
    prod:    Xmx=768m  → limit = 768 + 250 = ~1018Mi → use 1.5Gi
  
  NEVER set Xmx = container_limit
  A 1Gi container with -Xmx1g will OOM kill because non-heap is ignored.
  Rule: Xmx = container_limit × 0.75 (leave 25% for non-heap)
```

---

## Verification Commands (Java-specific)

```bash
# Check JVM heap usage in running pod
kubectl exec -n payment-ns deploy/payment-service -- \
  java -jar /proc/$(pgrep java)/fd/... 2>/dev/null || \
  kubectl exec -n payment-ns deploy/payment-service -- \
    curl -s http://localhost:8080/actuator/metrics/jvm.memory.used | \
    python3 -m json.tool
# Look for: jvm.memory.used{area=heap} vs jvm.memory.max{area=heap}

# Check GC activity
kubectl exec -n payment-ns deploy/payment-service -- \
  curl -s http://localhost:8080/actuator/metrics/jvm.gc.pause | \
  python3 -m json.tool
# If gc.pause.count is high AND duration > 100ms: GC pressure

# Spring Boot health endpoints
curl -s https://payment.company.com/actuator/health/liveness  | python3 -m json.tool
curl -s https://payment.company.com/actuator/health/readiness | python3 -m json.tool
# Both should show: {"status": "UP"}

# Thread pool status
curl -s http://localhost:8080/actuator/metrics/executor.active | python3 -m json.tool
# High active thread count + slow responses = thread pool saturation

# Check container startup time (important for JVM — slow is normal)
kubectl get events -n payment-ns | grep "Started container"
```
