# Glossary — Java EKS GitOps Project

Every Java-specific and general term in this project, explained for an SRE beginner.

---

**Spring Boot**
A Java framework that auto-configures a production-ready application. Includes: embedded Tomcat web server, dependency injection, JPA database access, Actuator health endpoints. You write business logic; Spring wires everything together.

**Spring Boot Actuator**
A Spring Boot module that exposes operational endpoints: `/actuator/health`, `/actuator/metrics`, `/actuator/prometheus`. Used by Kubernetes probes (`/actuator/health/liveness`, `/actuator/health/readiness`) and Dynatrace metrics collection.

**JVM (Java Virtual Machine)**
The runtime that executes Java bytecode. Manages: memory (heap + non-heap), threads, garbage collection, JIT compilation. Every Java app runs on a JVM — it's the layer between your code and the OS.

**JVM Heap**
The area of JVM memory where Java objects live. Set by `-Xmx` (maximum) and `-Xms` (initial). The garbage collector reclaims unused objects from the heap. At 75%+ usage: GC pressure begins. At 90%+: GC thrashing, severe latency spikes.

**-Xmx (JVM flag)**
Sets the maximum heap size. Example: `-Xmx768m` = max 768MB heap. CRITICAL: never set Xmx equal to the container memory limit — non-heap (metaspace, code cache) also needs memory. Rule: `Xmx = container_limit × 0.75`.

**-XX:MaxRAMPercentage=75.0**
A modern JVM flag (Java 10+) that automatically sets `Xmx` to 75% of the container's memory limit. Works correctly in Docker/Kubernetes. Replaces the need to manually calculate `-Xmx` values per environment. Used in the Dockerfile ENTRYPOINT.

**-XX:+UseContainerSupport**
JVM flag that makes the JVM read container CPU and memory limits (from cgroups) instead of host machine resources. Without this: the JVM on a 1Gi container thinks it has 64GB of RAM (the node's RAM) and creates a massive heap → immediate OOM kill.

**G1GC (Garbage First Garbage Collector)**
The JVM garbage collector used via `-XX:+UseG1GC`. Designed for low-latency applications. Divides heap into equal-sized regions and collects the most garbage-dense regions first. Good balance of throughput vs pause time for web services.

**GC (Garbage Collection)**
The JVM's automatic memory management process. Periodically scans the heap, finds objects no longer referenced, frees their memory. During a GC pause: application threads are stopped ("stop-the-world"). High GC frequency = high latency.

**GC Thrashing**
When the JVM spends more time running garbage collection than executing application code. Symptom: p99 latency spikes to seconds, throughput drops to near zero. Cause: heap is almost full, GC can't reclaim enough to keep up. Fix: increase Xmx or fix memory leak.

**Metaspace**
JVM memory area that stores class metadata (bytecode, method info). Not part of the heap. Grows as more classes are loaded. Spring Boot loads hundreds of classes on startup (~100MB). Cannot be set to 0 — always add ~150MB overhead beyond Xmx.

**JIT (Just-In-Time compilation)**
The JVM compiles hot bytecode paths to native machine code at runtime. First few requests are interpreted (slow). After warmup (~30 seconds): JIT-compiled code runs at near-native speed. This is why Java load test results improve after the first 30 seconds.

**JVM warmup**
The period (typically 30-120 seconds) after JVM startup while JIT compilation is running. Request latency is higher during warmup than in steady state. Load test thresholds in staging are set to 1000ms (not 300ms) to account for warmup.

**Gradle**
A build tool for Java projects. Reads `build.gradle` to determine: dependencies, compilation settings, test configuration. Equivalent to `pip install` + `pytest` in Python. `./gradlew bootJar` compiles and packages the app. `./gradlew test` runs JUnit tests.

**Gradle wrapper (gradlew)**
A script (`./gradlew`) that downloads and runs the correct Gradle version automatically. Ensures all developers and CI use the same Gradle version. Committed to the repo. Never requires "install Gradle" — just run `./gradlew`.

**JUnit 5**
Java's standard testing framework. Tests are annotated with `@Test`. Results are written as XML to `build/test-results/test/*.xml`. GitHub Actions can parse and display these as inline PR annotations.

**@WebMvcTest**
A Spring Boot test annotation that loads only the web layer (controllers + filters) for testing. No real database or services — fast unit tests. Uses `MockMvc` to simulate HTTP requests without starting a real server.

**MockMvc**
Spring's test utility for simulating HTTP requests in unit tests. `mockMvc.perform(get("/api/v1/payments/123"))` sends a fake GET request and lets you assert the response status, headers, and JSON body. No real HTTP server needed.

**JaCoCo**
Java Code Coverage library. Measures what percentage of your code is executed by tests. Configured in `build.gradle` with a minimum threshold (70%). If coverage drops below 70%, the Gradle `check` task fails and CI stops.

**Bean Validation (@Valid, @NotNull, @Min)**
Java EE/Jakarta standard for declaring data validation constraints as annotations. Spring Boot automatically validates request bodies annotated with `@Validated`. Invalid inputs return HTTP 400 without any manual null-checking code.

**Java record**
A Java 16+ feature for immutable value objects. `public record Payment(String id, String status, long amount)` auto-generates: constructor, getters, equals, hashCode, toString. Used for domain models and request/response DTOs.

**HikariCP**
A high-performance JDBC connection pool. Manages a pool of database connections so threads don't create/destroy connections on every request (expensive). Built into Spring Boot. Key settings: `maximum-pool-size` (max concurrent DB connections), `connection-timeout` (how long to wait for an available connection).

**JDBC**
Java Database Connectivity. The standard Java API for connecting to relational databases. HikariCP pools JDBC connections. Spring JPA uses JDBC internally to execute SQL queries.

**Spring JPA (Hibernate)**
Spring's database access layer. Maps Java classes (`@Entity`) to database tables. Generates SQL automatically. `ddl-auto: validate` checks that the database schema matches your entity classes on startup — fails fast if they're out of sync.

**server.shutdown: graceful**
Spring Boot configuration that enables graceful shutdown. When SIGTERM arrives: Spring stops accepting new requests, waits for in-flight requests to complete, then shuts down. Without this: SIGTERM kills the JVM immediately, dropping all in-flight requests.

**OpenTelemetry (OTLP)**
A vendor-neutral observability standard for distributed tracing. Spring Boot sends trace spans via OTLP protocol to Dynatrace ActiveGate. Traces show the full request path: HTTP → controller → service → database → external API.

**Micrometer**
A Java metrics facade library. Translates JVM and Spring metrics (heap usage, request count, GC pause time) into Prometheus format at `/actuator/prometheus`. Dynatrace scrapes these or reads them via OneAgent.

**eclipse-temurin**
The official Adoptium OpenJDK distribution (formerly AdoptOpenJDK). Used in the Dockerfile as `eclipse-temurin:21-jdk-alpine` (build) and `eclipse-temurin:21-jre-alpine` (runtime). Well-maintained, security-patched, widely used in production.

**Alpine Linux**
A minimal Linux distribution (~5MB). Used as the Docker base OS. Significantly smaller than Debian/Ubuntu. The `eclipse-temurin:21-jre-alpine` image is ~180MB vs ~350MB for the Debian-based JRE image. Reduces ECR storage and image pull time.

**Spring Boot layer JAR (layertools)**
Spring Boot 2.3+ feature that splits the fat JAR into layers for Docker caching. Dependencies layer (40MB, changes rarely) is cached. Application layer (1MB, changes every commit) rebuilds quickly. Reduces CI build times significantly.

**Fat JAR**
A single JAR file containing the application code AND all its dependencies. Spring Boot produces this with `./gradlew bootJar`. Equivalent to a self-contained executable — just run `java -jar app.jar`. The layer extraction in the Dockerfile splits this for caching.

**JarLauncher (Spring Boot)**
The class used to start a layer-exploded Spring Boot application: `org.springframework.boot.loader.launch.JarLauncher`. Used in the Dockerfile ENTRYPOINT instead of running the fat JAR directly. Required when using layertools extraction.

**-Djava.security.egd=file:/dev/./urandom**
A JVM system property that tells the JVM to use `/dev/urandom` (non-blocking) instead of `/dev/random` (blocking) for random number generation. Without this: Tomcat startup can block for minutes waiting for entropy in containers.

**HealthIndicator (Spring Boot)**
An interface for implementing custom health checks. The `ReadinessIndicator` class implements `health()` to check DB connectivity. Spring Actuator aggregates all HealthIndicators at `/actuator/health/readiness`.

**cache: 'gradle' (GitHub Actions)**
Caches the Gradle dependency cache (`~/.gradle/caches`) between CI runs. Without cache: every CI run downloads all dependencies from Maven Central (~200MB). With cache: only new or changed dependencies are downloaded (~seconds vs minutes).

**actions/setup-java**
GitHub Actions action that installs a specific JDK version. `distribution: 'temurin'` uses Adoptium JDK (same as Dockerfile). `cache: 'gradle'` enables Gradle dependency caching. Must match the Java version in `build.gradle` (`JavaLanguageVersion.of(21)`).

**JUnit XML report (GitHub Actions)**
Test result files written to `build/test-results/test/*.xml`. The `mikepenz/action-junit-report` action parses these and adds inline annotations to the PR (e.g., "Test X failed at line Y"). Makes it easy to see which tests failed without reading raw CI logs.

**Timeout=900 (ArgoCD sync option)**
Tells ArgoCD to wait up to 900 seconds (15 minutes) for resources to become healthy after applying. Java Spring Boot needs this because startup takes 30-120 seconds. Without it: ArgoCD times out after the default (shorter) period and marks the sync as failed.

**valueFiles (Helm)**
A list of values files to merge together. ArgoCD loads `values.yaml` first (defaults), then `values-dev.yaml` (overrides). Later files override earlier files. Allows sharing a single chart template across environments with per-environment customisation.

**Testcontainers**
A Java library that starts real Docker containers during tests. `testImplementation 'org.testcontainers:postgresql'` starts a real PostgreSQL container for integration tests. Tests run against the real database, not a mock — catches SQL-specific bugs that mocks miss.

**jacocoTestCoverageVerification**
A Gradle task that fails the build if code coverage is below the configured threshold. Set to 70% line coverage minimum. CI runs this automatically via `check.dependsOn jacocoTestCoverageVerification`. Prevents coverage from degrading silently over time.

**Tomcat (embedded)**
The HTTP server embedded in Spring Boot. Handles TCP connections, HTTP parsing, and servlet dispatch. Configured via `server.tomcat.connection-timeout`. Part of the `spring-boot-starter-web` dependency — no separate installation needed.

**m7g.2xlarge (Graviton)**
AWS EC2 instance: 8 vCPU, 32GB RAM, ARM64 (Graviton3). Used for production Java nodes. Java on Graviton works fully (JVM is ARM64-native). 32GB RAM allows multiple large JVM heaps per node. ~20% cheaper than equivalent Intel instance (m7i.2xlarge).
