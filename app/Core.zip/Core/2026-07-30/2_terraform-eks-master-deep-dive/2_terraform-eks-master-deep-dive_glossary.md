# terraform-aws-eks Master Deep Dive — Glossary

**terraform-aws-modules/terraform-aws-eks**
The official community Terraform module for creating AWS EKS clusters. Maintained by the Terraform AWS Modules community. Used by thousands of companies worldwide. Available at registry.terraform.io. Why it matters: encapsulates years of EKS best practices so you don't have to invent them from scratch.

**Terraform Module**
A reusable package of Terraform resources that accepts input variables and returns outputs. Calling `module "eks" { source = "..." }` is like calling a function. Why it matters: avoids writing hundreds of lines of EKS resource configuration from scratch.

**`versions.tf`**
The file that declares which Terraform CLI version and which provider versions are required. Any version outside these constraints causes an error before anything runs. Why it matters: ensures everyone (developers, CI, production) uses compatible tools.

**Provider (Terraform)**
A plugin that knows how to interact with a specific API (AWS, Kubernetes, Helm). The `aws` provider translates Terraform resource blocks into AWS API calls. Why it matters: without providers, Terraform has no way to talk to AWS.

**`provider_meta`**
A Terraform block that adds metadata to all API calls made by a provider. In this module: adds the module's GitHub URL to the User-Agent header of every AWS API call. Why it matters: helps AWS Support identify which module version caused a problem.

**`putin_khuylo`**
A boolean variable (default: true) that must be true for any resources to be created. Added in 2022 as a module-wide safety switch expressing solidarity with Ukraine. Also functions as a dry-run toggle. Why it matters: `var.create` AND `var.putin_khuylo` must both be true; it's a two-factor safety gate.

**EKS Control Plane**
The Kubernetes brain — the API server, etcd, scheduler, and controller-manager. In EKS, AWS manages these. Your nodes connect to this. Why it matters: everything kubectl does hits the control plane; it must be accessible and healthy for the cluster to work.

**`aws_eks_cluster` resource**
The Terraform resource that creates the EKS control plane. The core of this module. Accepts: cluster name, Kubernetes version, IAM role, VPC config, encryption config, logging config. Why it matters: this IS the cluster.

**`count = local.create ? 1 : 0`**
A Terraform pattern for conditional resource creation. If `local.create` is true: creates 1 resource. If false: creates 0. Why it matters: the standard way to make any Terraform resource optional.

**`dynamic` block**
A Terraform feature that generates zero or more nested blocks based on a list or map. `dynamic "encryption_config" { for_each = ... }` creates the block only if encryption is configured. Why it matters: makes optional nested configurations clean — no need for dummy empty blocks.

**`lifecycle { ignore_changes }` block**
Tells Terraform to NOT track changes to specific attributes after creation. Used for fields that AWS modifies automatically or that can't be changed after creation. Why it matters: prevents constant "plan shows changes" noise for fields that aren't really changing.

**`lifecycle { create_before_destroy }`**
Tells Terraform to create the replacement resource BEFORE destroying the old one. Used on security groups and launch templates. Why it matters: without it, Terraform would delete the old resource first, breaking dependencies and causing downtime.

**`for_each` (Terraform)**
Creates one resource instance per item in a map or set. Used throughout this module to create multiple node groups, security group rules, etc. from a single resource block. Why it matters: the fundamental pattern for managing multiple similar resources without code duplication.

**OIDC Provider (IAM)**
An AWS IAM identity provider that trusts tokens issued by the EKS cluster's OpenID Connect endpoint. Required for IRSA (pod IAM roles). Why it matters: the link that allows Kubernetes ServiceAccounts to authenticate to AWS IAM.

**IRSA (IAM Roles for Service Accounts)**
An EKS feature where each Kubernetes ServiceAccount can be associated with its own IAM role. Pods running under that ServiceAccount get temporary AWS credentials with only that role's permissions. Why it matters: the correct way to give pods AWS access — no static credentials, no overly-broad node permissions.

**TLS Certificate Thumbprint**
The SHA1 fingerprint of the TLS certificate of the EKS OIDC endpoint. Required when registering the OIDC provider in IAM. Why it matters: proves to IAM that OIDC tokens are coming from a trusted source.

**KMS Key for etcd Encryption**
A customer-managed KMS key used to encrypt all Kubernetes Secrets stored in etcd. Why it matters: by default, Kubernetes Secrets are stored in plaintext in etcd; this adds encryption at rest, required for compliance.

**Access Entry**
The modern EKS authentication mechanism (replaces aws-auth ConfigMap). Maps an IAM principal (role/user) to Kubernetes permissions. Why it matters: auditable in CloudTrail, manageable via API/Terraform, no need to edit YAML in kube-system.

**Access Policy**
A pre-defined EKS policy document (like `AmazonEKSClusterAdminPolicy`) that grants specific Kubernetes permissions. Applied to an Access Entry. Why it matters: standardised permissions without writing custom RBAC — cluster-admin, admin, view, etc.

**`aws-auth` ConfigMap**
The legacy method for granting IAM identities Kubernetes access. A YAML file in the kube-system namespace mapping IAM ARNs to Kubernetes groups. Why it matters: still used in older clusters; the module supports it for backward compatibility but recommends Access Entries for new clusters.

**Cluster Security Group**
The AWS security group attached to the EKS API server's ENIs. Controls: which traffic can reach the API server. The main rule: nodes → API server on port 443. Why it matters: improperly configured = nodes can't communicate with the control plane.

**Node Security Group**
The AWS security group attached to all worker EC2 instances. Controls: what traffic can reach nodes. Main rules: control plane → kubelet (port 10250), node-to-node all traffic (for pod communication). Why it matters: the firewall around your worker nodes.

**`source_cluster_security_group = true`**
A security group rule attribute that sets the SOURCE of the rule to the cluster's primary security group (instead of a CIDR). Why it matters: more secure than CIDR-based rules — only resources WITH the cluster SG can trigger this rule.

**Managed Node Group (`aws_eks_node_group`)**
An EC2 node group where AWS manages the Auto Scaling Group, AMI updates, and graceful node draining. Preferred for most workloads. Why it matters: reduces operational burden — AWS handles patching and rolling updates.

**Self-Managed Node Group (ASG)**
An EC2 node group where you control the Auto Scaling Group directly. Gives full control over AMI, launch template, and bootstrap process. Why it matters: needed when you require custom OS configuration, specific AMI versions, or non-standard hardware.

**Fargate Profile**
Serverless EKS compute. Pods run on AWS-managed infrastructure with no EC2 instances to manage. Selected by namespace and label selectors. Why it matters: eliminates node management entirely for suitable workloads.

**`time_sleep` resource**
A Terraform resource from the `time` provider that introduces a delay. Used here to wait 30 seconds after cluster creation before creating node groups. Why it matters: gives EKS add-ons time to initialise before nodes try to join.

**`time_sleep` triggers**
A map of values that, when changed, reset the timer. If the cluster version changes: wait 30 seconds before updating nodes. Why it matters: ensures the delay fires at the right moment (any cluster change), not just on initial creation.

**IPv6 CNI Policy**
A custom IAM policy granting the VPC CNI plugin permissions to assign IPv6 addresses to pods. Not available as an AWS-managed policy. Why it matters: required for EKS clusters using IPv6 networking — without it, pods can't get IPv6 addresses.

**Karpenter**
A node autoscaler that dynamically provisions the right EC2 instance for each pending pod. Faster than Cluster Autoscaler. Supports Spot diversification. Why it matters: scale-out in under 60 seconds instead of 3-5 minutes; better cost optimisation.

**Spot Interruption Queue (SQS)**
An SQS queue that receives 2-minute warnings before AWS reclaims a Spot instance. Karpenter monitors this queue and gracefully drains the node before termination. Why it matters: without this, pods on interrupted Spot nodes get hard-killed; with it, pods are gracefully rescheduled.

**Warm Pool (ASG)**
Pre-launched EC2 instances sitting in a "Warmed" state, ready to join the ASG on demand. Scale-out goes from minutes to seconds. Why it matters: eliminates the EC2 instance boot delay during traffic spikes.

**User Data (EC2)**
A script that runs when an EC2 instance first boots. For EKS nodes: configures and starts kubelet, pointing it at the cluster. Why it matters: without user data, an EC2 instance has no idea it should be a Kubernetes node.

**`/etc/eks/bootstrap.sh`**
The bootstrap script pre-installed in EKS-optimised Amazon Linux 2 AMIs. Configures kubelet and connects the node to the cluster. Why it matters: the mechanism by which AL2 nodes join EKS.

**`nodeadm`**
The new YAML-based node configuration tool used in Amazon Linux 2023. Replaces the bash bootstrap script. Why it matters: more structured, validated, and idempotent than bash scripts; the future of EKS node bootstrap.

**Bottlerocket**
AWS's purpose-built container operating system. Minimal attack surface, no SSH, atomic updates with rollback. Why it matters: significantly more secure than general-purpose Linux for container workloads.

**TOML**
A configuration file format (Tom's Obvious Minimal Language). Used by Bottlerocket for all configuration. Simpler than YAML for configuration; strongly typed. Why it matters: Bottlerocket user data is TOML, not bash.

**Prefix Delegation (VPC CNI)**
A VPC CNI mode where each ENI gets a /28 IP prefix (16 addresses) instead of individual IPs. Dramatically increases pods-per-node. Why it matters: without it, a single node may support only 58 pods; with it, the same node can support 234+ pods.

**Block Device Mapping**
The EBS volume configuration for an EC2 instance's root disk. In this module: configured via the launch template. Why it matters: the default 20GB root volume fills up quickly with container images; production nodes typically need 100GB+.

**`gp3` EBS volume**
The latest generation AWS general-purpose SSD. Provides 3000 IOPS and 125 MB/s throughput at base price (no extra charge unlike gp2). Why it matters: better performance than gp2 at the same or lower cost.

**`pre-commit`**
A framework that runs checks automatically before every `git commit`. Configured in `.pre-commit-config.yaml`. Why it matters: catches formatting errors, validation failures, and security issues before code reaches CI.

**`semantic-release`**
A tool that automatically creates versioned GitHub releases based on commit message conventions. Configured in `.releaserc.json`. Why it matters: automates version bumping and changelog generation.

**Breaking Change (in semantic versioning)**
A change marked with `!` in the commit message or `BREAKING CHANGE:` in the body. Triggers a major version bump (21.0.0 → 22.0.0). Why it matters: users who pin to `~> 21.0` are protected from accidentally pulling in breaking changes.

**EKS Auto Mode**
An EKS feature where AWS manages node provisioning, scaling, AMI updates, and patching entirely. You just deploy pods. Why it matters: eliminates all node management operational overhead.

**Hybrid Nodes**
On-premise servers (physical or VM) that join an AWS EKS cluster as worker nodes. The cluster runs in AWS but some nodes run in your data centre. Why it matters: enables gradual cloud migration or keeping sensitive workloads on-premise while using EKS for orchestration.

**`coalescelist()`**
A Terraform function that returns the first non-empty list from its arguments. Used to provide fallback values: `coalescelist(var.control_plane_subnet_ids, var.subnet_ids)`. Why it matters: allows optional configuration — if the specific setting isn't provided, fall back to the general one.

**`coalesce()`**
A Terraform function that returns the first non-null, non-empty string value from its arguments. Used to provide defaults: `coalesce(var.custom_name, "${var.cluster_name}-node")`. Why it matters: clean way to handle optional string values with sensible defaults.
