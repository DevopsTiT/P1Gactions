# terraform-aws-eks Master — Deep Dive Index

> This is the official `terraform-aws-modules/terraform-aws-eks` community module — the most widely used Terraform module for creating AWS EKS clusters. Every file is explained in a separate deep-dive document.

---

## Project Map

```
terraform-aws-eks-master/
│
├── ROOT FILES (the module interface)
│   ├── versions.tf        ← Terraform + provider version requirements
│   ├── main.tf            ← EKS cluster, IAM, security groups, OIDC, KMS (954 lines)
│   ├── node_groups.tf     ← node group orchestration + time_sleep + CNI policy (547 lines)
│   ├── variables.tf       ← ALL input variables (1526 lines)
│   └── outputs.tf         ← ALL output values (281 lines)
│
├── modules/               ← sub-modules called by main.tf
│   ├── eks-managed-node-group/   ← managed node groups (AWS-controlled ASG)
│   ├── self-managed-node-group/  ← self-managed node groups (you control ASG)
│   ├── fargate-profile/          ← serverless pod compute
│   ├── karpenter/                ← Karpenter autoscaler IAM + SQS
│   ├── capability/               ← EKS capability enablement
│   ├── hybrid-node-role/         ← hybrid (on-prem) node IAM roles
│   └── _user_data/               ← bootstrap script generator (private, prefixed _)
│
├── templates/             ← EC2 user data templates for each OS
│   ├── al2_user_data.tpl          ← Amazon Linux 2 bootstrap
│   ├── al2023_user_data.tpl       ← Amazon Linux 2023 (nodeadm)
│   ├── bottlerocket_user_data.tpl ← Bottlerocket TOML config
│   └── windows_user_data.tpl      ← Windows PowerShell bootstrap
│
├── examples/              ← complete working examples you can deploy
│   ├── eks-auto-mode/             ← EKS Auto Mode (fully managed nodes)
│   ├── eks-managed-node-group/    ← standard EKS managed node groups
│   ├── self-managed-node-group/   ← ASG-based node groups
│   ├── karpenter/                 ← Karpenter node autoscaling
│   ├── eks-capabilities/          ← enabling EKS capabilities
│   └── eks-hybrid-nodes/          ← on-premise hybrid nodes
│
└── tests/                 ← integration tests (not for production use)
    ├── eks-managed-node-group/
    ├── self-managed-node-group/
    ├── fargate-profile/
    ├── eks-hybrid-nodes/
    └── user-data/                 ← unit tests for user_data rendering
```

---

## Part Index

| Part | File | Content |
|---|---|---|
| Part 1 | `part1_root-files/` | versions.tf, .gitignore, .pre-commit-config.yaml |
| Part 2 | `part2_main-tf/` | Deep dive of main.tf — cluster, IAM, SGs, OIDC, KMS, access entries |
| Part 3 | `part3_node-groups-tf/` | node_groups.tf — CNI, time_sleep, node SG, how sub-modules are called |
| Part 4 | `part4_variables-outputs/` | variables.tf + outputs.tf — what you pass in and what you get back |
| Part 5 | `part5_modules/` | All sub-modules: eks-managed-node-group, self-managed, fargate, karpenter |
| Part 6 | `part6_examples/` | All 6 examples explained — when to use each |
| Part 7 | `part7_templates/` | User data templates for AL2, AL2023, Bottlerocket, Windows |

---

## The Mental Model: What This Module Creates

```
When you call this module, it creates (at minimum):

1. aws_eks_cluster              ← the EKS control plane (API server, etcd)
2. aws_iam_role (cluster)       ← IAM role for the EKS service
3. aws_cloudwatch_log_group     ← control plane logs
4. aws_security_group (cluster) ← SG for the cluster API server
5. aws_security_group (node)    ← SG for worker nodes
6. aws_iam_openid_connect_provider ← enables IRSA (pod IAM roles)
7. module.kms (optional)        ← KMS key for etcd secret encryption
8. time_sleep                   ← waits N seconds for addons to be ready

Then (based on what you pass in variables.tf):
  → eks_managed_node_groups    → calls modules/eks-managed-node-group
  → self_managed_node_groups   → calls modules/self-managed-node-group
  → fargate_profiles            → calls modules/fargate-profile
  → karpenter (if configured)   → calls modules/karpenter
```
