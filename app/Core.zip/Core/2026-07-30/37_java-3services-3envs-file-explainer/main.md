# Every File in 34_java-3services-3envs-gitops — Explained

> **How to read this:** Each section = one file or folder. For each file: what it IS, what it DOES, and why it EXISTS (what breaks without it).

---

## Project Map (Who Uses What)

```
Developer pushes code to main
          │
          ▼
.github/workflows/<service>-ci.yaml     ← builds, tests, promotes across 3 envs
          │
          ▼ Step 1: Unit tests (Gradle + JaCoCo)
          │ Step 2: Build Docker image → push to DEV ECR
          │ Step 3: Trivy scan (CRITICAL/HIGH → fail)
          │ Step 4: Update gitops/dev/app/<service>/  ← ArgoCD sees the new tag
          │ Step 5: Smoke test dev (curl health + API)
          │ Step 6: Promote image → STAGING ECR, update gitops/staging/
          │ Step 7: k6 load test on staging (50 VUs, 3 min)
          │ Step 8: MANUAL APPROVAL gate (GitHub environment protection)
          │ Step 9: Promote image → PRODUCTION ECR, update gitops/production/
          │ Step 10: Smoke test prod + auto-rollback if it fails
          ▼
gitops/<env>/app/<service>/<service>.yaml    ← ArgoCD Application YAML with image tag
          │
          ▼
charts/<service>/                            ← Helm chart ArgoCD renders into K8s YAML
          │    values.yaml          (prod defaults)
          │    values-dev.yaml      (dev overrides)
          │    values-staging.yaml  (staging overrides)
          ▼
EKS cluster (dev / staging / production)    ← 3 separate clusters, same chart

Platform engineer manages infrastructure
          │
          ▼
terraform/environments/<env>/               ← per-environment EKS + VPC + ECR
          │    main.tf     calls vpc + eks + ecr modules
          │    terraform.tfvars  sets sizes, CIDRs for that env
          ▼
.github/workflows/terraform-infra.yaml      ← plan on PR, apply on merge
```

---

## ROOT LEVEL

### `34_java-3services-3envs-gitops.md`
Main documentation for the project — architecture, service descriptions, deployment flow. Not used by any tool. Human context for anyone new to the repo.

### `34_java-3services-3envs-gitops_glossary.md`
Glossary of all terms in the docs. Same purpose — documentation only.

---

## `.github/workflows/` — CI/CD Pipelines

These files are the automation engine. Nothing deploys without them.

---

### `.github/workflows/payment-service-ci.yaml`
**What it is:** The full Deploy pipeline for payment-service — from code commit to production, across all 3 environments.

**What it does, step by step:**
```
TRIGGER: push/PR to main that changes services/payment-service/** or charts/payment-service/**

Job 1 — test:
  - Setup Java 21 (Temurin distribution) with Gradle cache
  - Run: ./gradlew test jacocoTestReport jacocoTestCoverageVerification
  - JaCoCo enforces ≥70% line coverage — build fails below that threshold
  - Publishes JUnit XML reports to GitHub PR as check annotations

Job 2 — build-and-deploy-dev (needs: test, only on push):
  - Auth to AWS via OIDC (no stored AWS secrets in GitHub Secrets)
  - Login to DEV ECR (account 123456789010)
  - Build multi-arch image: linux/amd64 + linux/arm64 (for Graviton nodes)
  - Push to ECR_DEV:${{ github.sha }}  AND  ECR_DEV:latest-dev
  - Trivy scan: CRITICAL or HIGH CVEs → pipeline fails, no deploy
  - sed update: gitops/dev/app/payment-service/payment-service.yaml  image.tag = SHA
  - git commit + push  [skip ci]  (the [skip ci] stops an infinite loop)
  - kubectl rollout status --timeout=8m  (waits for ArgoCD to finish the rollout)

Job 3 — smoke-test-dev (needs: build-and-deploy-dev):
  - curl GET /actuator/health/liveness  → 200 required
  - curl GET /actuator/health/readiness → 200 required
  - curl POST /api/v1/payments          → assert response.status == "created"

Job 4 — promote-to-staging (needs: smoke-test-dev):
  - Cross-account image copy: pull from DEV ECR → re-tag → push to STAGING ECR
    (each env is a SEPARATE AWS account with its own ECR)
  - Update gitops/staging/app/payment-service/payment-service.yaml
  - kubectl rollout status --timeout=10m on staging cluster

Job 5 — test-staging (needs: promote-to-staging):
  - Installs k6 load testing tool
  - Runs: k6 --vus 50 --duration 3m against staging URL
  - k6 script checks error rate, P95 latency thresholds

Job 6 — promote-to-production (needs: test-staging, environment: production):
  - GitHub environment "production" has REQUIRED REVIEWERS configured
  - Pipeline pauses here — a human must click Approve in GitHub UI
  - After approval: copy image STAGING → PRODUCTION ECR
  - Update gitops/production/app/payment-service/payment-service.yaml
  - kubectl rollout status --timeout=12m

Job 7 — verify-production (needs: promote-to-production):
  - sleep 60s (let pods fully start)
  - curl liveness + readiness against payment.company.com
  - If this job FAILS: auto-rollback script runs:
      - git log finds the PREVIOUS tag from the gitops file history
      - Updates gitops/production/ back to the previous tag
      - Pushes → ArgoCD auto-deploys the old version
```

**Why it exists:**
Without this file, every promote-to-production is manual — engineer must build, push, test, update 3 YAML files, and coordinate across 3 accounts. The pipeline enforces the SAME exact process every time: tests must pass, coverage must hit 70%, no CVEs, smoke tests pass, load test passes, human approves.

---

### `.github/workflows/order-service-ci.yaml`
**What it is:** Identical pipeline structure to payment-service-ci.yaml, but for the order-service.

**Key differences:**
```
ECR accounts:    same 3-account pattern (dev/staging/prod have separate ECR repos)
URLs tested:     order.dev.company.com, order.staging.company.com, order.company.com
gitops paths:    gitops/*/app/order-service/order-service.yaml
smoke test API:  POST /api/v1/orders  (not /api/v1/payments)
```

---

### `.github/workflows/notification-service-ci.yaml`
**What it is:** Same pipeline structure for notification-service.

**Key difference — the smoke test API call:**
```
POST /api/v1/notifications  with { "userId", "channel": "EMAIL", "subject", "body" }
→ asserts response.status == "queued"
(notifications are async — "queued" is the correct initial response, not "sent")
```

---

### `.github/workflows/terraform-infra.yaml`
**What it is:** Infrastructure Terraform pipeline — manages VPC, EKS clusters, ECR repos for all 3 environments.

**What it does:**
```
TRIGGER: push/PR to main that changes terraform/ (not terraform/dynatrace/)

On PR:   terraform init + plan → posts plan output as PR comment
On merge: terraform apply -auto-approve → creates/modifies real AWS resources

Why it uses separate state per env:
  terraform/environments/dev/        → S3 key: eks/dev/terraform.tfstate
  terraform/environments/staging/    → S3 key: eks/staging/terraform.tfstate
  terraform/environments/production/ → S3 key: eks/production/terraform.tfstate

Separate state = dev apply can't accidentally modify prod resources.
```

---

### `.github/workflows/terraform-dynatrace.yaml`
**What it is:** Monitoring config pipeline. Separate from infra because monitoring changes (new service threshold) are far more frequent and lower risk than infrastructure changes (EKS upgrade, VPC change).

---

## `services/` — The Java Application Code

Three independent Spring Boot 3 microservices. Each follows the exact same structure — only the domain logic differs.

---

### `services/payment-service/app/src/main/java/com/company/PaymentApplication.java`
The Spring Boot application entry point. Just `@SpringBootApplication` + `main()`. Required for Spring to boot the application context.

---

### `services/payment-service/app/src/main/java/com/company/PaymentController.java`
**What it is:** The REST API for payment-service.

**Endpoints:**
```
GET  /api/v1/payments/{id}
  → Returns: Payment(id, status="completed", amount=5000.0, currency="JPY", createdAt)
  → Logs: {"event":"payment_get","payment_id":"<id>"}

POST /api/v1/payments
  → Body: { amount: (positive number), currency: (string), userId: (string) }
  → Validates: @NotNull @Positive on amount, @NotNull on currency and userId
  → If validation fails: Spring returns 400 automatically (no manual try/catch needed)
  → Returns: { id: "pay_<12 random hex chars>", status: "created" }
  → Logs: {"event":"payment_created","payment_id":"...","amount":...,"currency":"...","user_id":"..."}
```

**Why JSON logging:**
Every log line is a raw JSON string — not a human sentence. Dynatrace and CloudWatch Logs Insights can query it directly without parsing rules. Example query: `filter event = "payment_created" | stats count() by currency`.

---

### `services/order-service/app/src/main/java/com/company/OrderController.java`
**What it is:** REST API for order-service.

**Endpoints:**
```
GET    /api/v1/orders/{id}         → Returns Order with items list
POST   /api/v1/orders              → Body: { userId, items: [{productId, quantity}] }
                                    → Returns: { id: "ord_<12 hex>", status: "pending" }
PATCH  /api/v1/orders/{id}/status  → Body: { status: "shipped" }
                                    → Updates the order status (e.g., pending → shipped → delivered)
```

**Why order-service has PATCH but payment-service doesn't:**
Orders change state over time (pending → confirmed → shipped → delivered). Payments are immutable once created — you never edit a payment, you only create refunds as new payment records.

---

### `services/notification-service/app/src/main/java/com/company/NotificationController.java`
**What it is:** REST API for notification-service.

**Endpoints:**
```
GET  /api/v1/notifications/{id}   → Returns Notification record
POST /api/v1/notifications        → Body: { userId, channel: EMAIL|SMS|PUSH, subject, body }
                                   → Returns: { id: "notif_<12 hex>", status: "queued" }
```

**Why "queued" not "sent":**
Real notification delivery (email, SMS, push) is async — it goes through SQS/SNS. The comment in the code says: `// In production: publish to SQS/SNS for async delivery`. The API returns immediately with "queued" so the caller doesn't wait for actual delivery. The smoke test asserts `status == "queued"` — that's the correct contract.

---

### `services/payment-service/app/src/main/resources/application.yaml`
**What it is:** Spring Boot configuration for the payment-service.

**Key sections explained:**
```
datasource:
  url: jdbc:postgresql://${DB_HOST}:${DB_PORT:5432}/${DB_NAME:payments}
  → DB_HOST, DB_PORT, DB_NAME, DB_USERNAME, DB_PASSWORD
    come from the Kubernetes Secret (payment-service-db-credentials)
    which is synced from AWS Secrets Manager by ExternalSecret
  hikari.maximum-pool-size: 10
    → Max 10 concurrent DB connections per pod
    → With 3 pods in prod: max 30 connections to the DB

server.shutdown: graceful
spring.lifecycle.timeout-per-shutdown-phase: 30s
  → When K8s sends SIGTERM: Spring stops accepting new requests,
    waits up to 30s for in-flight requests to finish, then shuts down.
  → Combined with preStop sleep 15s in Deployment: ALB stops routing
    BEFORE Spring starts its graceful shutdown. No dropped requests.

management.endpoint.health.probes.enabled: true
  → Enables /actuator/health/liveness and /actuator/health/readiness
    as SEPARATE endpoints (not combined into one /health)
  → K8s reads these two URLs separately for liveness/readiness probes

management.tracing.sampling.probability: 1.0
  → Trace 100% of requests (appropriate for lower-traffic services)
  → Sends traces to Dynatrace via OpenTelemetry (OTLP protocol)
  → In very high-traffic scenarios, reduce to 0.1 to sample 10%

logging.pattern.console:
  → Every log line emitted as JSON: {"timestamp":"...","level":"...","service":"payment-service","message":"..."}
  → The service field lets you filter by service in Dynatrace log viewer
```

---

### `services/payment-service/app/build.gradle`
**What it is:** The Gradle build file — defines dependencies and build tasks.

**Key dependencies:**
```
spring-boot-starter-web        → REST endpoints (Spring MVC + embedded Tomcat)
spring-boot-starter-actuator   → /actuator/health/liveness, /readiness, /metrics
spring-boot-starter-data-jpa   → PostgreSQL ORM (Hibernate)
spring-boot-starter-validation → @NotNull @Positive @NotBlank annotations
postgresql                     → JDBC driver for PostgreSQL
micrometer-registry-prometheus → Exposes /actuator/prometheus for Prometheus scraping
micrometer-tracing-bridge-otel → Connects Micrometer tracing to OpenTelemetry
opentelemetry-exporter-otlp    → Sends traces to Dynatrace via OTLP protocol
testcontainers:postgresql      → Spins up a real PostgreSQL in Docker during tests
                                 (no mocking — tests hit an actual DB)
rest-assured                   → HTTP client for integration test assertions
```

**Build task chain (what runs during CI):**
```
./gradlew test jacocoTestReport jacocoTestCoverageVerification
  1. test:                    Run all tests with JUnit 5
  2. jacocoTestReport:        Generate coverage XML report
  3. jacocoTestCoverageVerification:
       if LINE coverage < 70% → BUILD FAILS
       CI never builds the Docker image if coverage is insufficient
```

---

### `services/payment-service/app/Dockerfile`
**What it is:** THREE-stage Docker build (not two — this is Java-specific).

**Why 3 stages for Spring Boot:**
```
Stage 1 — builder (eclipse-temurin:21-jdk-alpine):
  - Full JDK with Gradle
  - Runs: ./gradlew bootJar → produces app.jar
  - app.jar = fat jar: all dependencies + app classes bundled in one file

Stage 2 — extractor (eclipse-temurin:21-jdk-alpine):
  - java -Djarmode=layertools -jar app.jar extract
  - This SPLITS the fat jar into 4 ordered layers:
      dependencies/          ← 3rd-party libs (change rarely)
      spring-boot-loader/    ← Spring Boot bootstrap code (never changes)
      snapshot-dependencies/ ← SNAPSHOT libs (change occasionally)
      application/           ← YOUR code (changes every commit)
  - WHY: Docker caches each layer separately.
    If only your code changed → Docker reuses the dependencies/ layer from cache.
    Without layer splitting: every build re-uploads all deps (~200MB) even if unchanged.
    With layers: only application/ (~2MB) is uploaded on most builds.

Stage 3 — runtime (eclipse-temurin:21-jre-alpine):
  - JRE only (no JDK compiler, no javac) → smaller image, smaller attack surface
  - Creates non-root user appuser (UID 1000)
  - Copies the 4 layers from extractor — in cache-friendly order (least-changing first)
  - ENTRYPOINT java flags:
      -XX:+UseContainerSupport       → JVM reads cgroup limits (not host RAM)
      -XX:MaxRAMPercentage=75.0      → Use 75% of container memory limit for heap
                                       With 1Gi limit: heap = ~768MB
      -XX:+UseG1GC                   → G1 garbage collector (good for low-latency)
      -XX:+HeapDumpOnOutOfMemoryError → Write heap dump to /tmp/heapdump.hprof on OOM
      -Djava.security.egd=file:/dev/./urandom → Faster random number generation in containers
```

---

### `services/payment-service/app/settings.gradle`
Single line: `rootProject.name = 'payment-service'`. Gradle requires this to name the project. The name shows up in test reports and build logs.

### `services/payment-service/app/src/test/java/com/company/PaymentControllerTest.java`
Integration tests using Testcontainers (real PostgreSQL) + RestAssured (HTTP assertions). Run by Gradle during CI. Must achieve ≥70% line coverage or the pipeline fails.

---

## `charts/` — Helm Charts

One chart per service. Each chart has `values.yaml` (production defaults) plus `values-dev.yaml` and `values-staging.yaml` (environment overrides).

---

### `charts/payment-service/values.yaml` (production defaults)
```
replicaCount: 3           → 1 pod per AZ in production (3 AZs)
image.tag: "PLACEHOLDER"  → CI overwrites this via gitops ArgoCD Application inline values
resources.requests:  cpu: 250m, memory: 768Mi
resources.limits:    cpu: 1000m, memory: 1Gi
hpa.minReplicas: 3, maxReplicas: 20  → scale range for production
pdb.minAvailable: 2       → at least 2 pods must survive any disruption
startupProbe.failureThreshold: 60, periodSeconds: 10 → 600s (10 min) for JVM startup
env.SPRING_PROFILES_ACTIVE: production
env.LOG_LEVEL: INFO       → quieter logs in production
env.OTEL_EXPORTER_OTLP_ENDPOINT → Dynatrace ActiveGate for traces
terminationGracePeriodSeconds: 60
```

### `charts/payment-service/values-dev.yaml` (dev overrides)
```
replicaCount: 1       → 1 pod is enough in dev (no need for HA)
resources.requests:   cpu: 100m, memory: 512Mi  → cheaper nodes
hpa.minReplicas: 1, maxReplicas: 3
pdb.enabled: false    → no PDB in dev: node drains can proceed without restriction
LOG_LEVEL: DEBUG      → verbose logs for developers investigating issues
certArn: ""           → dev may not have a TLS certificate
```

### `charts/payment-service/values-staging.yaml` (staging overrides)
```
replicaCount: 2       → 2 pods: enough for load test, some HA
resources: between dev and production sizes
hpa.minReplicas: 2, maxReplicas: 10
pdb.minAvailable: 1   → PDB enabled but only requires 1 surviving pod
SPRING_PROFILES_ACTIVE: staging
```

**Why 3 values files instead of 3 separate charts:**
One chart, different values = the SAME Helm template is guaranteed identical across all environments. If you had 3 separate charts, a developer might add a feature to the production chart but forget staging — environments silently diverge.

---

### `charts/payment-service/templates/deployment.yaml`
**What it is:** Kubernetes Deployment — how pods are run.

**Key features:**
```
strategy.rollingUpdate: { maxUnavailable: 0, maxSurge: 1 }
  → Never take a pod down before the replacement is Ready.
  → Zero-downtime deployments: new pod starts → passes readiness probe → old pod terminates.

securityContext (pod-level):
  runAsNonRoot: true   → Kubernetes rejects the pod if image runs as root
  runAsUser: 1000      → matches the appuser created in Dockerfile
  fsGroup: 1000        → files in mounted volumes owned by appuser

securityContext (container-level):
  allowPrivilegeEscalation: false  → sudo is impossible inside the container
  readOnlyRootFilesystem: true     → the container filesystem is read-only
  capabilities.drop: [ALL]         → removes ALL Linux capabilities (no raw sockets, etc.)

volumeMounts: /tmp → emptyDir (Memory, 200Mi)
  → Dockerfile writes heap dumps to /tmp on OOM.
  → readOnlyRootFilesystem: true requires any writable path to be an explicit volume.
  → medium: Memory = RAM-backed (fast), sizeLimit: 200Mi = prevents memory abuse.

lifecycle.preStop: sleep 15
  → Sequence when K8s terminates a pod:
    1. K8s removes pod from Service endpoints (ALB stops routing here)
    2. preStop runs: sleep 15s (in-flight requests finish)
    3. Spring graceful shutdown starts: waits up to 30s for open connections
    4. Container terminates
  → Without preStop: ALB might still route to the pod for a few seconds
    after SIGTERM → connection resets on active requests.

env from values.yaml: ENVIRONMENT, LOG_LEVEL, SPRING_PROFILES_ACTIVE, OTEL_*
envFromSecret: payment-service-db-credentials
  → DB_HOST, DB_PORT, DB_NAME, DB_USERNAME, DB_PASSWORD
  → injected as env vars; app reads them via ${DB_HOST} in application.yaml
```

---

### `charts/payment-service/templates/hpa.yaml`
HorizontalPodAutoscaler. Scales pods based on CPU utilization.
```
minReplicas: 3 (dev: 1, staging: 2)
maxReplicas: 20 (dev: 3, staging: 10)
targetCPUUtilizationPercentage: 70
→ If average CPU across all pods > 70%: add pods (up to 3/min)
→ If CPU < 70% for 5 minutes: remove pods (1/min — slow scale-down avoids oscillation)
```

---

### `charts/payment-service/templates/pdb.yaml`
PodDisruptionBudget.
```
minAvailable: 2 (production), minAvailable: 1 (staging), disabled (dev)

WHEN IT MATTERS:
  kubectl drain <node>  (node upgrade):
    Without PDB: all 3 pods on that node evicted simultaneously → downtime
    With PDB:    Kubernetes waits for replacement pods to start before evicting each pod

  Karpenter node consolidation (replacing 3 m5.large with 1 m5.xlarge):
    Without PDB: Karpenter evicts all pods from old nodes at once → downtime
    With PDB:    Karpenter drains one node, waits for pods to reschedule → zero downtime
```

---

### `charts/payment-service/templates/service.yaml`
Kubernetes Service (ClusterIP). Creates stable DNS: `payment-service.payment-ns.svc.cluster.local`. The ALB Ingress and other pods use this DNS name. Individual pod IPs change on every restart — the Service IP is stable.

### `charts/payment-service/templates/serviceaccount.yaml`
Kubernetes ServiceAccount with IRSA annotation: `eks.amazonaws.com/role-arn: arn:aws:iam::<account>:role/company-<env>-payment-service`. This links the pod to its AWS IAM role (for Secrets Manager, etc.) without storing any AWS credentials in the pod.

### `charts/payment-service/templates/ingress.yaml`
Kubernetes Ingress with AWS Load Balancer Controller annotations. When ArgoCD applies this, the ALB controller creates an ALB that routes `payment.<env>.company.com` HTTPS traffic to the payment-service pods.

---

## `gitops/` — ArgoCD GitOps Manifests

Three subfolders — one per environment. Each has identical structure.

```
gitops/
  dev/
    bootstrap/root-app-dev.yaml         ← Apply once manually → automates the rest
    namespaces/namespaces.yaml          ← Creates payment-ns, order-ns, notification-ns
    app/payment-service/payment-service.yaml
    app/order-service/order-service.yaml
    app/notification-service/notification-service.yaml
  staging/  (same structure)
  production/  (same structure)
```

---

### `gitops/dev/bootstrap/root-app-dev.yaml`
**THE most important file. Apply once manually — everything else is automated.**

```yaml
spec:
  source:
    path: gitops/dev          ← watches THIS entire folder
  syncPolicy:
    automated:
      prune: true             ← delete K8s resources if you delete the YAML from Git
      selfHeal: true          ← revert manual kubectl changes within ~3 minutes
```

**How it works:**
```
kubectl apply -f gitops/dev/bootstrap/root-app-dev.yaml
  → Creates ONE ArgoCD Application in the dev cluster
  → ArgoCD scans gitops/dev/ recursively
  → Finds: namespaces.yaml, payment-service.yaml, order-service.yaml, notification-service.yaml
  → Deploys all of them
  → Any future git push to gitops/dev/ is deployed automatically

selfHeal means: if someone runs kubectl edit deployment payment-service
→ ArgoCD reverts it within 3 minutes to what's in Git
→ Git is always the source of truth — manual changes don't stick
```

---

### `gitops/dev/namespaces/namespaces.yaml`
Creates 3 Kubernetes Namespaces with labels:
```yaml
payment-ns:       team: payments,      environment: dev, pod-security.kubernetes.io/enforce: restricted
order-ns:         team: orders,        environment: dev, pod-security.kubernetes.io/enforce: restricted
notification-ns:  team: notifications, environment: dev, pod-security.kubernetes.io/enforce: restricted
```

**Why `pod-security.kubernetes.io/enforce: restricted`:**
The `restricted` Pod Security Standard is the strictest built-in policy. It blocks pods that run as root, use host networking, mount sensitive host paths, or request extra Linux capabilities. This is why the Deployment has `runAsNonRoot: true` and `capabilities.drop: [ALL]` — the namespace enforces it.

**Why namespaces are separate YAML (not inside the ArgoCD Application):**
ArgoCD deploys applications INTO namespaces. The namespace must exist BEFORE the application is deployed. ArgoCD sync-waves control this order — namespaces deploy in wave 1, applications in wave 8.

---

### `gitops/dev/app/payment-service/payment-service.yaml`
**What it is:** The ArgoCD Application for payment-service in the dev environment.

```yaml
metadata:
  name: payment-service-dev
  annotations:
    argocd.argoproj.io/sync-wave: "8"    ← deploys after namespaces (wave 1)
spec:
  project: payment-team                   ← limits what this app can deploy to
  source:
    path: charts/payment-service
    helm:
      valueFiles:
        - values.yaml                     ← production defaults (base layer)
        - values-dev.yaml                 ← dev overrides (smaller resources, 1 replica)
      values: |
        image:
          tag: "PLACEHOLDER"              ← CI overwrites this line via git commit
        serviceAccount.annotations:
          eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-payment-service
        ingress.host: payment.dev.company.com
  destination:
    namespace: payment-ns
```

**How CI updates the tag:**
```bash
sed -i "s|tag: \".*\"|tag: \"${{ env.IMAGE_TAG }}\"|" \
  gitops/dev/app/payment-service/payment-service.yaml
git commit -m "chore(deploy-dev): payment-service=abc1234 [skip ci]"
git push
```
ArgoCD detects the commit → re-renders the Helm chart with the new tag → rolling-updates the pods.

**Why `[skip ci]` in the commit message:**
CI triggers on pushes to main. If the CI pipeline itself commits to main (to update the image tag), that would trigger CI again → infinite loop. `[skip ci]` tells GitHub Actions to NOT trigger workflows for this specific commit.

---

## `terraform/` — AWS Infrastructure

---

### `terraform/environments/dev/main.tf`
```
Declares:
  backend "s3":  bucket=company-tfstate-123456789010, key=eks/dev/terraform.tfstate
  module "vpc":  calls ../../modules/vpc with dev-specific CIDR 10.10.0.0/16
  module "eks":  calls ../../modules/eks with services list (creates IRSA roles for each)
  module "ecr":  calls ../../modules/ecr for 3 repos (payment-, order-, notification-service)
```

### `terraform/environments/dev/terraform.tfvars`
```
cluster_name:  company-dev
vpc_cidr:      10.10.0.0/16   ← dev VPC
node_groups:
  workers:
    instance_types: [m5.large]   ← smaller + cheaper nodes in dev
    min_size: 2, max_size: 6, desired_size: 2
    disk_size: 50GB
```

### `terraform/environments/staging/terraform.tfvars`
```
cluster_name:  company-staging
vpc_cidr:      10.20.0.0/16   ← staging VPC (non-overlapping CIDR)
node_groups:
  workers:
    instance_types: [m5.large, m5a.large]  ← Graviton option for cost savings
    min_size: 2, max_size: 15, desired_size: 4
    disk_size: 75GB
```

### `terraform/environments/production/terraform.tfvars`
```
cluster_name:  company-prod
vpc_cidr:      10.30.0.0/16   ← production VPC (non-overlapping with dev/staging)
node_groups:
  workers:
    instance_types: [m5.xlarge, m5a.xlarge]   ← larger nodes for production load
    min_size: 3, max_size: 30, desired_size: 6
    disk_size: 100GB
```

**Why 3 separate VPCs with non-overlapping CIDRs:**
In a real setup, you'd use VPC Peering or AWS Transit Gateway to let clusters communicate. For peering to work, CIDRs must not overlap:
- dev:        10.10.0.0/16
- staging:    10.20.0.0/16
- production: 10.30.0.0/16

---

## E2E Flow: Code Push → Production (The Complete Picture)

```
1. Developer pushes code to main (changes services/payment-service/)
2. GitHub Actions triggers payment-service-ci.yaml
3. [test job] Gradle runs tests + JaCoCo coverage check (≥70% required)
4. [build-dev job] Java app compiled → Spring Boot fat jar → Docker image built (3-stage)
5. Image pushed to DEV ECR (account 123456789010):payment-service:abc1234
6. Trivy scans the image → CRITICAL/HIGH CVEs → fail here, never reaches DEV
7. CI commits:  gitops/dev/app/payment-service/payment-service.yaml  tag: "abc1234"
8. ArgoCD (dev cluster) detects the git commit within 3 minutes
9. ArgoCD renders Helm chart with values.yaml + values-dev.yaml + inline values
10. ArgoCD applies Kubernetes resources: Deployment, Service, Ingress, HPA, PDB, ServiceAccount
11. RollingUpdate: new pod starts → passes startupProbe → passes readinessProbe
    → old pod terminated (maxUnavailable: 0 = zero downtime)
12. kubectl rollout status confirms all pods updated
13. [smoke-test-dev] CI curls the endpoints: health + POST /api/v1/payments
14. [promote-to-staging] Image pulled from DEV ECR → re-tagged → pushed to STAGING ECR
15. CI commits:  gitops/staging/app/payment-service/payment-service.yaml  tag: "abc1234"
16. ArgoCD (staging cluster) deploys with values.yaml + values-staging.yaml
17. [test-staging] k6 load test: 50 virtual users, 3 minutes, checks P95 latency + error rate
18. [promote-to-production] PAUSES — GitHub environment requires human approval
19. Senior engineer reviews test results → clicks Approve in GitHub UI
20. Image pushed to PRODUCTION ECR (account 123456789012)
21. CI commits:  gitops/production/app/payment-service/payment-service.yaml  tag: "abc1234"
22. ArgoCD (prod cluster) deploys with values.yaml (prod defaults)
23. [verify-production] CI waits 60s → curls payment.company.com liveness + readiness
24a. Success → pipeline complete, image tag abc1234 running in all 3 environments
24b. Failure → auto-rollback: git log finds previous tag → sed reverts → commit → push
     → ArgoCD redeploys the previous working version within minutes
```

---

## Common Mistakes: What Breaks Without Each File

| File | What breaks without it |
|---|---|
| `values-dev.yaml` | Dev deploys with 3 replicas + prod-size resources → dev cluster runs out of capacity |
| `values-staging.yaml` | Staging uses prod settings: 20 max replicas, prod ECR repo, production Spring profile |
| `root-app-dev.yaml` (bootstrap) | ArgoCD knows nothing about this project — no services deploy automatically |
| `namespaces/namespaces.yaml` | Applications fail: namespace `payment-ns` does not exist |
| `lifecycle.preStop: sleep 15` | In-flight requests get connection reset mid-processing during pod shutdown |
| `pdb.yaml` (production) | Node upgrades evict all 3 pods simultaneously → full service outage |
| `[skip ci]` in commit message | CI loop: CI pushes tag update → CI triggers again → infinite pipeline |
| `jacocoTestCoverageVerification` | Low-coverage code ships to production with untested paths |
| JVM `-XX:+UseContainerSupport` | JVM reads host RAM (e.g., 64GB) → sets heap to 48GB → pod OOMKilled immediately |
| Trivy scan step | CVE-containing image deploys to dev/staging/prod before anyone notices |
| 3-stage Dockerfile (layer extraction) | Every build re-uploads all 200MB of dependencies even if only app code changed |
