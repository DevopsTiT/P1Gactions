# Glossary — 34_java-3services-3envs-gitops

Every term, tool, and concept used in the project. One term per entry.

---

**ArgoCD**
A Kubernetes tool that watches a Git repo and automatically applies YAML to the cluster whenever Git changes. It is the deployment engine — GitHub Actions pushes a new image tag to Git, ArgoCD detects the change and updates the running pods. Without ArgoCD, someone would have to run `kubectl apply` manually every time.

**ArgoCD Application**
A YAML resource (kind: Application) that tells ArgoCD: "watch this Git path and deploy it to this namespace." There is one Application per service per environment (e.g., payment-service-dev, payment-service-staging, payment-service-production).

**ArgoCD App of Apps**
A pattern where one ArgoCD Application watches a folder that contains OTHER Application YAMLs. The root-app-dev.yaml is this "parent" — it discovers all the child Applications in `gitops/dev/` and manages them. You only need to manually apply the root app once; everything else is automated.

**selfHeal (ArgoCD)**
A setting that tells ArgoCD: if someone manually changes a Kubernetes resource with `kubectl`, revert it back to what's in Git within ~3 minutes. Git is always the source of truth.

**prune (ArgoCD)**
A setting that tells ArgoCD: if a YAML file is deleted from Git, delete the corresponding Kubernetes resource too. Without this, deleted YAMLs leave orphaned resources in the cluster.

**sync-wave (ArgoCD)**
A number annotation that controls deploy ORDER. Wave 1 runs before wave 8. Namespaces are wave 1 (must exist before anything else). Applications are wave 8.

**GitHub Actions**
The CI/CD system built into GitHub. It runs automated jobs (build, test, deploy) based on triggers (code push, pull request). Each job runs in a fresh virtual machine.

**GitHub environment (production)**
A named environment in GitHub that can require HUMAN APPROVAL before a job runs. The `promote-to-production` job is gated on the "production" environment — the pipeline pauses until a reviewer clicks Approve.

**OIDC (for AWS)**
OpenID Connect. A way for GitHub Actions to authenticate to AWS WITHOUT storing AWS access keys in GitHub Secrets. GitHub gets a temporary token from AWS, uses it to assume an IAM role, and the token expires after the job. No long-lived credentials to leak.

**ECR (Elastic Container Registry)**
AWS's Docker image registry. Each environment (dev/staging/production) has its own separate ECR repo in its own AWS account. This isolates images — a dev image cannot accidentally run in production.

**Multi-arch image (linux/amd64 + linux/arm64)**
One Docker image that contains code compiled for both Intel/AMD CPUs and ARM CPUs. EKS can use ARM-based Graviton nodes (cheaper). Building multi-arch means the same image works on both node types.

**Trivy**
A security scanner that checks Docker images for known vulnerabilities (CVEs). If CRITICAL or HIGH severity CVEs are found, the pipeline fails — the image never reaches any environment.

**`[skip ci]`**
A special string in a git commit message that tells GitHub Actions to NOT trigger CI for that commit. Used when CI itself commits to Git (to update the image tag in gitops/) — prevents an infinite loop where CI triggers CI triggers CI.

**Spring Boot**
A Java framework that makes it easy to build REST API services. It includes: embedded web server (Tomcat), health check endpoints (/actuator/health), metrics (/actuator/prometheus), database ORM (JPA/Hibernate), and automatic configuration.

**Spring Boot Actuator**
A Spring Boot add-on that automatically exposes management endpoints:
- `/actuator/health/liveness` — is the JVM alive?
- `/actuator/health/readiness` — is the app ready for traffic?
- `/actuator/prometheus` — Prometheus-format metrics
Kubernetes probes use the health endpoints. Dynatrace scrapes the prometheus endpoint.

**Spring profiles (`SPRING_PROFILES_ACTIVE`)**
A way to activate different configuration blocks per environment. The env var `SPRING_PROFILES_ACTIVE=dev` makes Spring use dev-specific settings (more verbose logging, relaxed security). `production` activates stricter settings.

**Gradle**
Java's build tool (alternative to Maven). `build.gradle` defines dependencies and build tasks. `./gradlew` is the Gradle wrapper — it downloads the correct Gradle version automatically. You never need Gradle installed on the CI machine.

**JaCoCo**
A Java code coverage tool. It measures what percentage of code lines are exercised by tests. This project requires ≥70% line coverage — if tests cover less than 70% of the code, the Gradle build fails and the Docker image is never built.

**Testcontainers**
A Java testing library that spins up real Docker containers (PostgreSQL, Redis, etc.) during tests. This project's tests use a real PostgreSQL container — not a mock. Real DB tests catch SQL bugs that mocked tests miss.

**RestAssured**
A Java HTTP client library for API integration tests. Lets you write: `given().body(req).when().post("/payments").then().statusCode(200)`.

**Helm**
A package manager for Kubernetes. A "chart" is a folder of YAML templates + a `values.yaml`. Helm renders the templates into actual Kubernetes YAML by substituting values. ArgoCD uses Helm to deploy services.

**Helm values merging**
When ArgoCD renders a Helm chart, it loads values files in order: `values.yaml` (base/prod defaults) then `values-dev.yaml` (overrides). The last file wins for any overlapping key. This is how the same chart deploys with different replica counts per environment.

**`values.yaml`**
The base Helm values file — contains production-grade defaults. Every environment uses this as the starting point. Dev and staging only need to override what's different.

**`values-dev.yaml` / `values-staging.yaml`**
Environment-specific Helm overrides. Only contain the keys that differ from production: replica count, resource sizes, HPA range, PDB toggle, log level, ECR repository.

**Kubernetes Deployment**
A Kubernetes resource that manages running pods. It handles: how many replicas to run, what container image to use, how to roll out updates (RollingUpdate), where to place pods (anti-affinity), and when to restart pods (probes).

**RollingUpdate (`maxUnavailable: 0, maxSurge: 1`)**
The update strategy. `maxUnavailable: 0` means: never terminate an old pod until a replacement is fully Ready. `maxSurge: 1` means: you can have 1 extra pod temporarily during the update. Result: zero-downtime deployments — there is always `N` healthy pods serving traffic.

**startupProbe**
A Kubernetes probe that runs ONLY during pod startup. If it keeps failing past the threshold, K8s kills the pod and restarts it. `failureThreshold: 60, periodSeconds: 10` = 600 seconds (10 minutes) for the JVM to boot before being killed. Java apps take longer to start than Python/Go — this prevents false "stuck in restart loop" kills during cold start.

**readinessProbe**
A Kubernetes probe that runs continuously. If it fails, K8s removes the pod from the Service's load balancer — no traffic is routed to it. The pod is NOT restarted. When the probe passes again, traffic resumes. Checks: `/actuator/health/readiness`. If the DB is down, readiness returns 503 → no traffic goes to pods that can't serve requests.

**livenessProbe**
A Kubernetes probe that runs continuously. If it fails repeatedly, K8s KILLS and restarts the container. Checks: `/actuator/health/liveness`. Only kills truly stuck/deadlocked processes — configured with a higher threshold than readiness so transient hiccups don't cause restarts.

**preStop lifecycle hook**
A command that runs INSIDE the container BEFORE K8s sends the termination signal (SIGTERM). This project uses `sleep 15`. Purpose: give the load balancer (ALB) time to stop routing traffic to the pod before the app starts shutting down. Without it, some requests arrive at the pod after it starts shutting down → connection resets.

**Graceful shutdown (Spring Boot)**
When Spring Boot receives SIGTERM, it stops accepting new HTTP requests but waits for in-flight requests to finish (up to 30 seconds). Combined with preStop sleep, this means: no requests are lost during pod shutdown.

**HPA (HorizontalPodAutoscaler)**
Kubernetes resource that automatically changes the number of pods based on metrics (CPU, memory). If CPU > 70%: add pods. If CPU < 70% for 5 minutes: remove pods. Slow scale-down (300s window) prevents oscillation — you don't want to scale down and immediately need to scale back up.

**PDB (PodDisruptionBudget)**
Kubernetes resource that limits how many pods can be voluntarily disrupted at once. `minAvailable: 2` means: always keep at least 2 pods running. During node upgrades or Karpenter consolidation, Kubernetes respects the PDB — it won't evict a pod if doing so would violate the budget.

**IRSA (IAM Roles for Service Accounts)**
A way for Kubernetes pods to get AWS permissions without storing AWS credentials. The ServiceAccount is annotated with an IAM role ARN. When the pod starts, the AWS SDK automatically gets temporary credentials for that role. Each service has its own role with minimal permissions.

**Pod Security Standard (restricted)**
A Kubernetes built-in policy level. When a namespace has `pod-security.kubernetes.io/enforce: restricted`, Kubernetes rejects any pod that: runs as root, uses host network/PID, mounts host paths, or requests extra Linux capabilities. The Deployment's security settings exist to satisfy this policy.

**`readOnlyRootFilesystem: true`**
Container security setting. The container's own filesystem is read-only — nothing can be written to it. Prevents: malware writing backdoors, log injection to disk, modifying app files at runtime. The `/tmp` volume mount is an explicit exception so the JVM can write heap dumps.

**emptyDir (Memory)**
A Kubernetes volume backed by RAM instead of disk. Faster than disk. `sizeLimit: 200Mi` prevents the container from using unlimited memory through this volume. Used here for `/tmp` — gives the JVM a writable /tmp without using the read-only container filesystem.

**`capabilities.drop: [ALL]`**
Removes ALL Linux capabilities from the container process. Capabilities are special permissions like: open raw network sockets (CAP_NET_RAW), modify kernel parameters (CAP_SYS_ADMIN), etc. Most apps don't need any — dropping all is the safest default.

**OTLP (OpenTelemetry Protocol)**
The standard protocol for sending distributed traces and metrics from applications to observability backends (Dynatrace, Jaeger, etc.). The Java app sends traces to `http://dynatrace-activegate.dynatrace.svc:4318` via OTLP. This is how Dynatrace gets distributed traces showing the full call chain across services.

**Distributed traces**
A way to track a single user request as it flows through multiple services. If a payment creates an order which sends a notification, traces show all 3 service calls linked as one transaction — with timing for each step.

**Prometheus metrics**
A standard format for exposing application metrics (request count, latency histograms, JVM heap size, etc.) at `/actuator/prometheus`. Dynatrace or Prometheus can scrape this endpoint to collect time-series data for dashboards and alerts.

**`-XX:+UseContainerSupport`**
JVM flag. Without it, the JVM reads the host machine's total RAM (e.g., 64GB on an m5.xlarge) and sets heap to 75% of that — which is far more than the container's 1Gi memory limit → pod is immediately OOMKilled by Kubernetes. With this flag, the JVM reads the cgroup memory limit (the container's actual limit) instead.

**`-XX:MaxRAMPercentage=75.0`**
JVM flag. Sets heap to 75% of the container's RAM limit. With `limits.memory: 1Gi` → heap = ~768MB. The remaining 25% is for JVM overhead: non-heap memory (metaspace, code cache), thread stacks, OS buffers.

**`-XX:+UseG1GC`**
JVM flag. Selects G1 (Garbage First) garbage collector — designed for low-latency applications. Runs GC incrementally, avoiding long stop-the-world pauses. Good choice for REST APIs where consistent latency matters.

**Spring Boot layer jar extraction**
A technique to split a Spring Boot fat jar into 4 layers (dependencies, spring-boot-loader, snapshot-dependencies, application). Docker caches each layer independently. Since your application code changes every commit but dependencies change rarely, only the `application/` layer (~2MB) needs to be rebuilt and pushed — not the full 200MB dependencies layer.

**JRE vs JDK**
JDK = Java Development Kit (compiler + runtime). JRE = Java Runtime Environment (runtime only, no compiler). The production Docker image uses JRE — smaller, no javac, no debugging tools. Smaller attack surface: a compromised container can't compile or run arbitrary Java code.

**Temurin**
The production-ready, open-source JDK distribution from Adoptium (Eclipse Foundation). Used in both CI (via `actions/setup-java`) and Docker (`eclipse-temurin:21-jdk-alpine`). Alpine variant = minimal Linux base → smaller image.

**k6**
A load testing tool. Runs a JavaScript test script that sends HTTP requests with a specified number of virtual users (VUs) for a duration. The staging load test: 50 VUs for 3 minutes checks that the service holds up under concurrent load before production promotion.

**PLACEHOLDER (image tag)**
The literal string `"PLACEHOLDER"` written in the ArgoCD Application YAML as the initial image tag. It's not a real image — it signals "CI has not deployed yet." CI replaces this with the actual git SHA on first deploy. The first ArgoCD sync with `PLACEHOLDER` will fail (no such image), but that's expected — it only matters once CI has deployed a real image.

**`[skip ci]`**
Text in a git commit message that tells GitHub Actions: do NOT trigger workflow runs for this commit. Used by the pipeline when it commits updated image tags to prevent an infinite CI loop.

**Karpenter**
An EKS node autoscaler. When pods can't be scheduled (not enough nodes), Karpenter provisions a new EC2 instance in ~45 seconds. When nodes are underutilized, Karpenter consolidates pods onto fewer nodes and terminates the empty ones (saving cost). Respects PDB when evicting pods during consolidation.

**Namespace**
A Kubernetes logical boundary — like a folder for Kubernetes resources. `payment-ns`, `order-ns`, `notification-ns` keep each service's resources separate. Namespace-level security policies (Pod Security Standard, network policies) apply to all pods in the namespace.

**ClusterIP Service**
A Kubernetes Service type that creates a stable virtual IP inside the cluster. Other pods use the DNS name (`payment-service.payment-ns.svc.cluster.local`) to reach the service. The IP doesn't change even when pods restart. Only accessible from within the cluster — not from the internet.

**Ingress**
A Kubernetes resource that defines HTTP routing rules (which hostname → which Service). The AWS Load Balancer Controller reads Ingress resources and creates ALBs in AWS. Without an Ingress, the service is only reachable inside the cluster.

**ALB (Application Load Balancer)**
AWS's HTTP/HTTPS load balancer. Created automatically by the AWS Load Balancer Controller when an Ingress resource is applied. Routes `payment.company.com` HTTPS traffic to Kubernetes pods. Handles TLS termination using the ACM certificate in the Ingress annotations.

**ACM (AWS Certificate Manager)**
AWS service that manages TLS/SSL certificates. The `certArn` in values.yaml points to a certificate in ACM. The ALB uses this certificate to serve HTTPS. Dev has `certArn: ""` (no TLS certificate for dev).

**Secrets Manager (AWS)**
AWS service that stores secrets (database passwords, API keys) encrypted at rest. The ExternalSecret operator reads from Secrets Manager and creates a Kubernetes Secret. The app reads the secret as environment variables — no credentials ever appear in Git or Docker images.

**terraform.tfvars**
A file that provides concrete values for Terraform variables. Different per environment: `terraform/environments/dev/terraform.tfvars` has small nodes and a dev CIDR; `terraform/environments/production/terraform.tfvars` has large nodes and more replicas. Same Terraform modules, different inputs.

**Terraform state**
A JSON file that records what infrastructure Terraform manages. Stored in S3 (one file per environment). DynamoDB is used for locking — prevents two people from running `terraform apply` at the same time, which could corrupt state or create conflicting resources.

**VPC CIDR**
The IP address range for a Virtual Private Cloud. Dev uses `10.10.0.0/16`, staging uses `10.20.0.0/16`, production uses `10.30.0.0/16`. Non-overlapping ranges allow VPC peering between environments (dev can reach prod DB over private network) without routing conflicts.

**Private subnets**
Subnets with no direct internet access. EKS nodes and pods live here — they can make outbound connections via NAT Gateway but are not directly reachable from the internet. Reduces attack surface.

**Public subnets**
Subnets with direct internet access (via Internet Gateway). NAT Gateways and internet-facing ALBs live here. Not where your app pods run.

**ECR module (Terraform)**
Creates the Docker image repositories for all 3 services in a given AWS account. The CI pipeline pushes images to ECR. Each environment account has its own ECR — an image that passed dev testing must be explicitly promoted (re-tagged + re-pushed) to staging and production ECR.

**Cross-account image promotion**
When promoting from dev → staging, CI must:
1. Assume the DEV account IAM role to read from DEV ECR
2. Assume the STAGING account IAM role to push to STAGING ECR
3. `docker pull` from DEV ECR, `docker tag`, `docker push` to STAGING ECR

This is why the promote jobs have two sets of `configure-aws-credentials` steps — they switch IAM roles between the two ECR operations.

**Auto-rollback**
The `verify-production` job runs smoke tests after production deploy. If the smoke test fails, a rollback script runs:
1. `git log` finds the previous commit that changed the gitops/production file
2. Extracts the old image tag from that commit
3. `sed` reverts the tag in the YAML file
4. Commits and pushes → ArgoCD redeploys the old version

The rollback takes effect within ~3 minutes (ArgoCD sync interval).
