# EKS Dynatrace GitOps Project — Every File Explained

> Source project: `4_eks-dynatrace-gitops-project`
> One explanation file per file or logical group. Each explains: what the file does, why every block exists, and what breaks if it is wrong.

---

## File Map → Explanation Files

```
gitops/bootstrap/root-app.yaml            → gitops/root-app.md
gitops/argocd/argocd-project.yaml         → gitops/argocd-project.md
gitops/namespaces/namespaces.yaml         → gitops/namespaces.md
gitops/networking/aws-load-balancer-controller.yaml → gitops/networking.md
gitops/secrets/external-secrets/*.yaml   → gitops/external-secrets.md
gitops/security/kyverno/kyverno.yaml     → gitops/kyverno.md
gitops/auto-scaling/karpenter/karpenter.yaml → gitops/karpenter-yaml.md
gitops/monitoring/dynatrace/dynatrace-operator.yaml → gitops/dynatrace-operator.md
gitops/app/payment-service/payment-service.yaml → gitops/payment-service-yaml.md

terraform/versions.tf                    → terraform-infra/versions.md
terraform/backend.tf                     → terraform-infra/backend.md
terraform/variables.tf                   → terraform-infra/variables.md
terraform/main.tf                        → terraform-infra/main.md
terraform/karpenter.tf                   → terraform-infra/karpenter.md
terraform/irsa-eso.tf                    → terraform-infra/irsa-eso.md
terraform/irsa-lbc.tf                    → terraform-infra/irsa-lbc.md
terraform/secrets-manager.tf             → terraform-infra/secrets-manager.md
terraform/outputs.tf                     → terraform-infra/outputs.md

terraform/dynatrace/main.tf              → terraform-dynatrace/dt-main.md
terraform/dynatrace/variables.tf         → terraform-dynatrace/dt-variables.md
terraform/dynatrace/management-zones.tf  → terraform-dynatrace/dt-management-zones.md
terraform/dynatrace/metric-events.tf     → terraform-dynatrace/dt-metric-events.md
terraform/dynatrace/slos.tf              → terraform-dynatrace/dt-slos.md
terraform/dynatrace/synthetics.tf        → terraform-dynatrace/dt-synthetics.md
```

---

## Sync Wave Order (ArgoCD deployment sequence)

```
Wave -1: namespaces.yaml         → create all namespaces first
Wave  1: aws-load-balancer-controller.yaml
Wave  2: external-secret-operator.yaml
Wave  3: karpenter.yaml, dynatrace-operator.yaml, kyverno.yaml
Wave  4: cluster-secret-store.yaml    (ESO must be running first)
Wave  5: kyverno-policies.yaml        (Kyverno must be running first)
Wave  8: payment-service.yaml         (everything else must be ready)
```
