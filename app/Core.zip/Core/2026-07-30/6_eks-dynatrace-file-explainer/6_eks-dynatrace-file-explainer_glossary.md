# EKS Dynatrace File Explainer — Glossary

**ArgoCD Application**
A Kubernetes custom resource that tells ArgoCD which Git repository and path to watch, which cluster and namespace to deploy to, and how to sync (automated or manual). The core unit of GitOps management.

**ArgoCD AppProject**
An RBAC boundary in ArgoCD. Defines which Git repos, destination namespaces, and Kubernetes resource types a group of Applications is allowed to use. Prevents a developer App from deploying to the wrong namespace or creating cluster-level resources.

**`finalizers: resources-finalizer.argocd.argoproj.io`**
A Kubernetes finalizer on ArgoCD Applications that causes cascade deletion — when the Application is deleted, ArgoCD also deletes all Kubernetes resources it manages. Without it, deleting an Application leaves all its resources running as orphans.

**App-of-Apps Pattern**
An ArgoCD pattern where a root Application watches a directory of other Application/ApplicationSet YAMLs. Apply one YAML once; ArgoCD discovers and manages everything else automatically.

**`recurse: true`**
An ArgoCD Application source setting that makes ArgoCD scan all subdirectories (not just the root directory) for Kubernetes resource YAMLs. Required for the App-of-Apps root to discover nested applications.

**`selfHeal: true`**
ArgoCD sync policy setting. Automatically reverts manual `kubectl` changes to match the Git state. Enforces "Git is the only source of truth."

**`prune: true`**
ArgoCD sync policy setting. Deletes Kubernetes resources when their YAML is removed from Git. Without it, deleted files leave orphaned resources running forever.

**Sync Wave (`argocd.argoproj.io/sync-wave`)**
An annotation on ArgoCD resources that controls deployment order. Lower numbers deploy first. ArgoCD waits for each wave to be healthy before starting the next. Essential for ordering dependencies (namespaces before pods, CRDs before CRD instances).

**`ServerSideApply=true` (syncOptions)**
Uses Kubernetes Server-Side Apply instead of client-side apply. Better conflict resolution when multiple controllers modify the same resource fields.

**IRSA (IAM Roles for Service Accounts)**
A Kubernetes-native mechanism for giving pods AWS credentials without access keys. An IAM role's trust policy uses an OIDC condition to allow only a specific Kubernetes ServiceAccount to assume it. The pod gets temporary credentials automatically.

**OIDC Trust Policy**
The IAM role trust policy condition that enables IRSA. Uses the EKS cluster's OIDC issuer URL and a `StringEquals` condition on `system:serviceaccount:NAMESPACE:SA_NAME` to restrict which pod can assume the role.

**`eks.amazonaws.com/role-arn` annotation**
The Kubernetes ServiceAccount annotation that links the ServiceAccount to an IAM role ARN. When a pod uses this ServiceAccount, the AWS SDK automatically exchanges the projected JWT token for temporary IAM credentials.

**DynaKube**
A Dynatrace custom resource that configures what the Dynatrace Operator deploys. Specifies: monitoring mode (classicFullStack), log collection settings, ActiveGate configuration, and token secret references.

**classicFullStack (Dynatrace)**
A DynaKube mode that deploys OneAgent as a DaemonSet — one pod per node. Provides full application performance monitoring (APM) with automatic code instrumentation via shared library injection.

**ActiveGate**
A Dynatrace component that aggregates data from OneAgents, handles routing to the DT SaaS tenant, and provides capabilities like log analytics and Kubernetes API monitoring.

**`logMonitoring: enabled: true`**
A DynaKube setting that enables OneAgent to read container log files directly from `/var/log/containers/*.log` on each node. Eliminates the need for Fluent Bit or a separate log shipper.

**ExternalSecret**
An External Secrets Operator custom resource that fetches a value from an external store (AWS Secrets Manager) and creates a Kubernetes Secret. The ExternalSecret YAML is safe to commit to Git — it contains only the path reference, not the actual secret value.

**ClusterSecretStore**
An ESO custom resource defining how ESO authenticates with the secrets backend. Cluster-scoped — all namespaces can reference it. Contains the IRSA ServiceAccount reference that ESO uses to authenticate with AWS.

**`refreshInterval: 1h`**
An ExternalSecret setting controlling how often ESO re-fetches from Secrets Manager. After Secrets Manager rotates a secret, ESO syncs the new value within 1 hour (or sooner if you trigger a manual refresh).

**Karpenter NodePool**
A Karpenter custom resource defining what types of EC2 instances Karpenter can provision: instance families, architectures (arm64/x86_64), capacity types (Spot/on-demand), and size restrictions.

**EC2NodeClass**
A Karpenter custom resource defining EC2-level launch configuration: AMI family, IAM role for nodes, subnet selector tags, security group selector tags, and root volume settings.

**`karpenter.sh/discovery: cluster-name`**
A tag applied to VPC subnets and security groups by Terraform. Karpenter uses this tag to discover where to provision new nodes. Without this tag, Karpenter cannot find valid subnets and fails to provision.

**Spot Interruption Queue (SQS)**
An SQS queue that receives Spot instance termination warnings from AWS EventBridge. Karpenter polls this queue and proactively drains pods from Spot instances before they are terminated, enabling graceful workload migration.

**`consolidationPolicy: WhenUnderutilized`**
A Karpenter disruption policy that terminates underutilised nodes by moving their pods to other nodes. Reduces idle EC2 costs by removing nodes that are no longer needed after a traffic decrease.

**Kyverno ClusterPolicy**
A Kyverno custom resource defining admission validation rules. Applied cluster-wide (or namespace-scoped via `match.resources.namespaces`). `validationFailureAction: Enforce` blocks violating pod specs at creation time.

**`validationFailureAction: Enforce`**
A Kyverno policy setting that BLOCKS pod creation if the policy is violated (rather than just logging). Use `Audit` first to build a violation inventory, then switch to `Enforce` once violations are resolved.

**`?*` pattern (Kyverno)**
A Kyverno pattern operator meaning "must exist and must not be empty." `cpu: "?*"` validates that the `cpu` field exists and has a non-empty value. Used to enforce resource requests without specifying exact values.

**Management Zone (Dynatrace)**
A Dynatrace filter scoping what a team sees — services, hosts, dashboards, alerts. Defined by entity tag rules. The payments Management Zone shows only entities tagged `team:payments` and `environment:production`.

**`for_each = var.services`**
A Terraform meta-argument creating one resource instance per entry in the `services` map. Adding a new service to the map creates all 5 Dynatrace resources automatically. Removing a service destroys only that service's resources.

**`local.teams` (Terraform)**
A computed set of unique team names extracted from the services map: `toset([for svc in values(var.services) : svc.team])`. Used to create one Management Zone per unique team, not per service.

**Burn Rate (SLO)**
How fast the error budget is being consumed. Burn rate 1.0 = sustainable (budget lasts 30 days). Burn rate 14.4 = budget exhausted in 2 days. Fast burn triggers immediate paging; slow burn triggers warnings.

**`dealerting_samples`**
The number of consecutive metric evaluation periods BELOW the threshold before a Dynatrace Problem closes. Set higher than `violating_samples` to prevent flapping (rapid open/close cycles when the metric oscillates at the threshold).

**`violating_samples`**
The number of consecutive evaluation periods ABOVE the threshold before a Dynatrace Problem is created. Set to 3 (minutes) to filter out single-minute spikes from rolling deployments.

**`builtin:service.errors.server.rate`**
Dynatrace built-in metric for HTTP 5xx error rate as a decimal (0.005 = 0.5%). Used in error rate metric events with `threshold = 0.5`.

**`builtin:service.response.time`**
Dynatrace built-in metric for response time in microseconds. Used in latency metric events with `aggregation = "PERCENTILE"` and `percentile = 99` for P99 latency alerts.

**`evaluation_window = "-1M"`**
A rolling 30-day SLO evaluation window. Always evaluates the most recent 30 days — an incident stays in the SLO calculation for 30 days after it occurs, preventing "waiting for the month to reset."

**`accept_any_certificate = false` (synthetic)**
A synthetic monitor setting that fails the check if the endpoint's SSL certificate is invalid or expired. Catches TLS issues that internal monitoring cannot see.

**`response_time_limit`**
The synthetic monitor's request timeout. Set to 3× the SLO latency target — generous enough to avoid false positives while catching catastrophic slowdowns.

**`recovery_window_in_days = 30` (Secrets Manager)**
Prevents immediate permanent deletion of a secret. A deleted secret enters a 30-day recovery window before permanent removal. Prevents accidental data loss from a mistaken `aws secretsmanager delete-secret` command.
