# Glossary — Terraform Infrastructure Pipeline Deep Dive

Every term in the pipeline explanation, defined for an SRE beginner.

---

**GitHub Actions**
CI/CD automation built into GitHub. Runs automated workflows when code is pushed, a PR is opened, or on a schedule. Defined as YAML files in `.github/workflows/`. Each workflow has jobs, each job has steps.

**workflow trigger (on:)**
The event that causes a GitHub Actions workflow to run. `push` fires when code is pushed to a branch. `pull_request` fires when a PR is opened or updated. `paths:` filters so the workflow only runs when specific files change.

**paths filter**
A GitHub Actions trigger setting that makes the workflow only run when files matching the pattern changed. `paths: ['terraform/**']` = only run when files under terraform/ change. Prevents unnecessary CI runs.

**`!` path exclusion**
A `!` prefix in a paths list means "exclude". `'!terraform/dynatrace/**'` = do NOT run this workflow when only Dynatrace files changed. The `!` path takes precedence over other patterns.

**environment variable (env:)**
A value defined once at the workflow level and referenced in all steps as `${{ env.VARIABLE_NAME }}`. Prevents repetition and makes updates easier — change it once, all steps use the new value.

**TF_VERSION**
The pinned Terraform version string. Passed to `hashicorp/setup-terraform` to download exactly that version. Prevents unexpected behaviour from Terraform upgrades breaking your CI.

**`if: github.event_name == 'pull_request'`**
A job condition that makes the job run ONLY for pull request events. The counterpart job uses `'push'`. This makes the two jobs mutually exclusive — plan runs on PR, apply runs on merge.

**permissions (GitHub Actions)**
The minimum GitHub API permissions the job needs. `id-token: write` = can request OIDC tokens. `contents: read` = can read the repo. `pull-requests: write` = can post PR comments. Only grant what's needed (principle of least privilege).

**id-token: write**
A GitHub Actions permission that allows the workflow to request an OIDC JWT token from GitHub. Required for keyless AWS authentication. Without this: `aws-actions/configure-aws-credentials` fails with "credentials could not be loaded."

**pull-requests: write**
A GitHub Actions permission that allows the workflow to create comments on PRs. Required for the step that posts the Terraform plan as a PR comment. Without it: the GitHub API call returns 403 Forbidden.

**OIDC (OpenID Connect)**
A protocol for federated identity. GitHub Actions generates a signed JWT. AWS verifies it using a registered OIDC provider. STS issues temporary credentials. No long-lived AWS secrets stored in GitHub.

**JWT (JSON Web Token)**
A signed, base64-encoded JSON object containing claims (sub, aud, iss). GitHub generates one per workflow run. AWS STS verifies the signature and the claims before issuing credentials.

**`sts:AssumeRoleWithWebIdentity`**
The AWS STS API call that exchanges a JWT (from OIDC) for temporary IAM credentials. The JWT proves identity; the role trust policy controls who is allowed to assume the role.

**IAM trust policy**
The policy on an IAM role that says who can assume it. For GitHub Actions: it trusts JWTs from `token.actions.githubusercontent.com` where the `sub` claim matches the specific repo and branch. Other repos/branches cannot assume the role.

**Plan role (read-only)**
The IAM role used during `terraform plan`. Has only read permissions (`Describe*`). Cannot create, modify, or delete resources. Limits the blast radius if a malicious PR runs the plan step.

**Apply role (read-write)**
The IAM role used during `terraform apply`. Has full permissions to create/modify/delete AWS resources. Only assumed after a PR is merged to main — after human review and approval.

**Blast radius**
The extent of damage a mistake or attack can cause. A read-only role has a small blast radius (can read but not destroy). An admin role has a large blast radius. Separate plan/apply roles minimise blast radius on PRs.

**`actions/checkout@v4`**
A GitHub Actions action that downloads the repository code to the runner filesystem. Without it: the runner directory is empty. All subsequent steps that read files would fail.

**`hashicorp/setup-terraform@v3`**
A GitHub Actions action that installs a specific version of the `terraform` binary. Without it: the `terraform` command is not found on the ubuntu-latest runner.

**`terraform init`**
The first Terraform command to run. Downloads providers, initialises the state backend (S3), and resolves modules. Must run before plan or apply. Terraform runners are ephemeral — init runs every time.

**state backend**
Where Terraform stores its state file. In this project: S3 bucket with DynamoDB locking. The state records all resources Terraform has created. Required to: detect drift, know what exists, plan changes.

**DynamoDB lock**
A record in a DynamoDB table that Terraform writes before apply. Prevents two simultaneous applies from corrupting the state file. Released automatically after apply completes.

**provider**
A Terraform plugin that knows how to talk to a specific API. `hashicorp/aws` communicates with the AWS API. Providers are downloaded during `terraform init` and stored in `.terraform/`.

**.terraform.lock.hcl**
A file committed to the repo that pins the exact provider version checksums. Ensures all machines (CI, laptops) use the exact same provider binary. The equivalent of a Python `requirements.txt` for Terraform providers.

**`-no-color`**
A flag that removes ANSI colour escape codes from Terraform output. CI logs and PR comments don't render colours — without this flag, output contains unreadable control characters like `[32m`.

**`terraform fmt`**
Reformats `.tf` files to match Terraform's canonical style (2-space indentation, aligned = signs). `fmt -check` returns exit code 1 if any file needs reformatting. Used in CI to enforce consistent code style.

**`terraform fmt -check`**
Runs format checking without modifying files. Returns 0 if all files are correctly formatted, 1 if any need reformatting. CI fails on exit code 1, blocking PRs with poorly-formatted Terraform code.

**`-recursive`**
A flag for `terraform fmt` that checks all subdirectories, not just the current directory. Required to check module files in `terraform/modules/vpc/`, `terraform/modules/eks/`, etc.

**`terraform validate`**
Checks the configuration for syntax errors and type errors WITHOUT calling any AWS APIs. Instant feedback (< 5 seconds). Catches missing required arguments, invalid resource types, undefined variables.

**`terraform plan`**
Computes the difference between desired state (`.tf` files) and actual state (AWS + tfstate). Outputs a human-readable diff: `+` create, `~` update, `-` destroy. Does not make any changes to AWS.

**`-out=tfplan`**
Saves the plan to a binary file. The plan file records exactly what will be applied. Passing it to `terraform apply tfplan` guarantees the same operations as the reviewed plan. Not used between separate jobs without artifact transfer.

**`2>&1`**
A shell redirect that merges stderr into stdout. Terraform writes most output to stderr. Without `2>&1`, piping Terraform output only captures stdout — the rest is lost. With `2>&1`: all output is captured.

**`tee plan.txt`**
A Unix command that reads from stdin and writes to both a file and stdout simultaneously. Allows real-time output display AND file creation in one command.

**Safety check (grep for destructive changes)**
A shell script in the plan step that searches `plan.txt` for lines indicating destruction of stateful resources (RDS, S3, EKS). If found: exits with code 1, blocking the CI run. Prevents accidental data loss.

**Stateful resource**
An AWS resource that holds data. Deleting it = permanent data loss. Examples: RDS (database data), S3 bucket (objects), EKS cluster (all running workloads). Contrast with stateless resources (security groups, IAM roles) that can be safely recreated.

**`grep -E "^  - resource"`**
A regex grep that finds lines starting with exactly `  - resource` (2 spaces + dash). In Terraform plan output, this pattern indicates a resource marked for destruction.

**`actions/github-script@v7`**
A GitHub Actions action that runs JavaScript code with access to the GitHub API (`github.rest.*`). Used here to post the Terraform plan as a PR comment.

**`context.issue.number`**
In GitHub Actions, a pull request is treated as an "issue" for comment purposes. `context.issue.number` is the PR number, used to identify which PR to post the comment on.

**`plan.substring(0, 65000)`**
JavaScript string truncation to 65,000 characters. GitHub PR comments have a size limit. Large Terraform plans (many resources) can exceed this limit. Truncating prevents the GitHub API call from returning a 422 error.

**`environment: production`**
A reference to a GitHub Environment. Provides: deployment history, environment secrets, optional approval gates. Without required reviewers configured: no extra manual gate. With reviewers: workflow pauses for human approval.

**GitHub Environment**
A named deployment target in GitHub (Settings → Environments). Can have: required approvers, wait timers, environment-specific secrets. Provides an audit trail of all deployments to that environment.

**`-auto-approve`**
A Terraform apply flag that skips the interactive "Enter 'yes' to confirm" prompt. Required in CI (non-interactive environment). Safe because the PR was already reviewed before merge.

**idempotency (Terraform)**
The property that running `terraform apply` multiple times produces the same result as running it once. Already-created resources are not recreated. Failed applies can be safely re-run after fixing the error.

**partial apply**
When `terraform apply` fails midway — some resources created, others not. Terraform's state file records what was successfully created. Next apply creates only the remaining resources. No duplicate creation.

**`terraform plan -refresh-only`**
A read-only mode that checks if the actual AWS state drifted from the Terraform state file. Returns "No changes" if everything matches. If it shows changes: AWS was modified outside Terraform (drift detected).

**`gh run list`**
A GitHub CLI command that lists recent workflow runs. Shows: run ID, status (success/failure), trigger (push/PR), timestamp. Useful for checking the result of recent apply runs.

**`gh run view`**
A GitHub CLI command that shows the details and logs of a specific workflow run. `--log` shows all step output. Useful for debugging failed plan or apply steps.

**`terraform import`**
Brings an existing AWS resource under Terraform management by adding it to the state file. Used for: recovering from partial applies, adopting manually-created resources, fixing state corruption. Does not modify the resource.

**Atlantis**
An open-source tool that runs Terraform plan/apply as part of a PR workflow. Explicitly links plan output to apply: the `atlantis apply` PR comment runs the exact plan that was reviewed. Solves the plan-apply separation problem.

**Terraform Cloud**
HashiCorp's managed service for Terraform state and runs. Provides: plan-apply consistency (apply uses the reviewed plan), state management, team collaboration, cost estimation. An alternative to self-hosted S3 backend + GitHub Actions.
