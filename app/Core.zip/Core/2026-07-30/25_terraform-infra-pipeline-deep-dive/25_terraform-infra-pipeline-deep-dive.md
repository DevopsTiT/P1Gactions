# Terraform Infrastructure Pipeline — Complete Deep Dive

> **What this file is:** `.github/workflows/terraform-infra.yaml` — the GitHub Actions pipeline that safely applies Terraform changes to AWS infrastructure. Every line explained.

---

## The Big Picture: What This Pipeline Does

```
WHEN A PR IS OPENED (touching terraform/ files):
  ┌─────────────────────────────────────────────────────────┐
  │  1. Format check    → is the HCL code properly indented? │
  │  2. Validate        → is the syntax correct?             │
  │  3. Plan            → what will actually change in AWS?  │
  │  4. Safety check    → does this destroy RDS/S3/EKS?     │
  │  5. Post to PR      → comment showing the plan output   │
  └─────────────────────────────────────────────────────────┘
         Reviewer reads the plan and approves/rejects the PR.

WHEN PR IS MERGED TO MAIN:
  ┌────────────────────────────────────────────────────────┐
  │  1. Init            → connect to state backend (S3)    │
  │  2. Apply           → actually create/change AWS infra │
  └────────────────────────────────────────────────────────┘
         Real AWS resources are created or modified.

WITHOUT THIS PIPELINE:
  Engineer runs terraform apply on their laptop.
  No code review of what will change.
  Different Terraform versions → different results.
  No record of who applied what or when.
  A typo destroys the production RDS instance.
```

---

## Line-by-Line Explanation

### `name:` and `on:`

```yaml
name: Terraform Infrastructure

on:
  push:
    branches: [main]
    paths: ['terraform/**', '!terraform/dynatrace/**']
  pull_request:
    branches: [main]
    paths: ['terraform/**', '!terraform/dynatrace/**']
```

**`name: Terraform Infrastructure`**
```
The display name shown in the GitHub Actions UI.
When you open a PR, you see this name in the "Checks" section.
Engineers click on it to see what ran.
No functional effect — purely for human readability.
```

**`on: push + pull_request`**
```
Two separate triggers:

push (branches: [main]):
  Fires when a commit lands on main.
  This is "after the PR is merged."
  Triggers: the APPLY job.

pull_request (branches: [main]):
  Fires when a PR is opened, updated, or synchronized against main.
  This is "before merging."
  Triggers: the PLAN job.

WHY TWO TRIGGERS:
  Plan on PR = "show me what will change BEFORE we merge."
  Apply on push = "now actually apply the change after it's approved."
  If only push: you'd apply blindly without review.
  If only pull_request: you'd see the plan but never apply.
```

**`paths: ['terraform/**', '!terraform/dynatrace/**']`**
```
paths: ['terraform/**']:
  Only run when files under terraform/ change.
  A change to app/ or gitops/ does NOT trigger this pipeline.
  Why: prevents rebuilding infra when only app code changed.

'!terraform/dynatrace/**' (the ! = EXCLUDE):
  Changes inside terraform/dynatrace/ do NOT trigger this pipeline.
  The Dynatrace Terraform has its own separate pipeline (terraform-dynatrace.yaml).
  
  Why separate pipelines:
  Dynatrace config changes frequently (add a new service, tune a threshold).
  Infrastructure changes rarely (EKS upgrade, VPC change).
  If combined: a DT threshold change triggers an EKS plan → engineers see noise.
  Separate: each pipeline is focused, clear, fast.
```

---

### `env:` — Global Environment Variables

```yaml
env:
  TF_VERSION: "1.8.0"
  AWS_REGION: ap-northeast-1
  WORKING_DIR: terraform
```

**`TF_VERSION: "1.8.0"`**
```
Pins the exact Terraform version used by this pipeline.

WITHOUT version pinning:
  hashicorp/setup-terraform@v3 installs "latest".
  Today: 1.8.0. Next week: 1.9.0 released.
  1.9.0 has a behaviour change in how for_each handles null values.
  Your plan output changes unexpectedly.
  Engineers: "why does the plan show changes? nobody touched the code."

WITH version pinning:
  Always 1.8.0. The plan output is predictable.
  To upgrade Terraform: change "1.8.0" to "1.9.0", open a PR,
  review the plan with the new version, merge. Controlled, intentional upgrade.

Also ensures: the version used in CI matches what's in
  terraform/versions.tf: required_version = ">= 1.6.0, < 2.0.0"
```

**`AWS_REGION: ap-northeast-1`**
```
Used in AWS CLI calls throughout the pipeline.
Defined once here → referenced as ${{ env.AWS_REGION }} everywhere.

If you need to change the region:
  Change it ONCE in env: → all steps use the new value.
  Without env var: you'd update the region in every single step → easy to miss one.
```

**`WORKING_DIR: terraform`**
```
All terraform commands run from this directory (working-directory: ${{ env.WORKING_DIR }}).
Keeps the GitHub Actions runner's starting directory (repo root) separate from
the directory where terraform files live.

Without working-directory:
  terraform init → "No Terraform files found" → fails.
  Every step would need: cd terraform && terraform init.
  With WORKING_DIR env var: one definition, clean step definitions.
```

---

### `jobs: plan:` — The PR Plan Job

```yaml
jobs:
  plan:
    name: Terraform Plan
    if: github.event_name == 'pull_request'
    runs-on: ubuntu-latest
    permissions:
      id-token: write
      contents: read
      pull-requests: write
```

**`if: github.event_name == 'pull_request'`**
```
This job ONLY runs when triggered by a pull_request event.
When the pipeline is triggered by a push (merge to main): this job is SKIPPED.

Why needed:
  Both 'plan' and 'apply' jobs are defined in the same file.
  Without 'if' guards: BOTH jobs would run on EVERY trigger.
  On a PR: you'd plan AND apply simultaneously. Apply before review = dangerous.
  With 'if' guards:
    PR opened  → plan job runs, apply job is skipped.
    PR merged  → plan job is skipped, apply job runs.
```

**`permissions:`**
```yaml
permissions:
  id-token: write        # required for OIDC AWS authentication
  contents: read         # read the repo code
  pull-requests: write   # post a comment on the PR
```
```
id-token: write:
  GitHub Actions can request an OIDC JWT token.
  This JWT is sent to AWS STS in exchange for temporary credentials.
  Without this: aws-actions/configure-aws-credentials fails.
  "Error: Credentials could not be loaded"

contents: read:
  The runner can checkout the repository code.
  Required for: actions/checkout@v4

pull-requests: write:
  The runner can post comments on the PR.
  Required for: actions/github-script (posting the plan output).
  Without this: the plan is computed but never posted.
  Engineers have no way to see what will change.
```

---

### Step: `actions/checkout@v4`

```yaml
- uses: actions/checkout@v4
```
```
Downloads the repository code to the runner's filesystem.
Without this: the runner has an empty directory. No Terraform files to run.

@v4: pinned to major version 4. GitHub resolves to the latest v4.x.y.
Best practice: for security, pin to a specific SHA:
  uses: actions/checkout@11bd71901bbe5b1630ceea73d27597364c9af683
But major version pinning is common and acceptable in most organisations.
```

---

### Step: `hashicorp/setup-terraform@v3`

```yaml
- uses: hashicorp/setup-terraform@v3
  with:
    terraform_version: ${{ env.TF_VERSION }}
```
```
Downloads and installs the pinned Terraform binary.
Adds it to PATH so `terraform` commands work in subsequent steps.

terraform_version: 1.8.0 → downloads exactly 1.8.0 from releases.hashicorp.com.
The action caches the binary: if the same version is used in the next run,
it's restored from cache instead of re-downloaded (saves ~30 seconds per run).

Without this step:
  Ubuntu runners have NO Terraform installed by default.
  terraform init → command not found.
```

---

### Step: Configure AWS Credentials (OIDC)

```yaml
- name: Configure AWS credentials
  uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789012:role/github-actions-terraform-plan
    aws-region: ${{ env.AWS_REGION }}
```

**How OIDC authentication works here:**
```
Without OIDC (old way):
  Store AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY in GitHub Secrets.
  Long-lived keys: if exposed → immediate and permanent AWS access.
  Must rotate regularly. If rotation forgotten → keys are years old.
  GitHub breach: all stored secrets exposed.

With OIDC (current way):
  Step 1: GitHub Actions generates a short-lived JWT containing:
    { "sub": "repo:company/infra:ref:refs/heads/main",
      "aud": "sts.amazonaws.com",
      "iss": "https://token.actions.githubusercontent.com" }

  Step 2: aws-actions sends this JWT to AWS STS:
    sts:AssumeRoleWithWebIdentity(WebIdentityToken=<jwt>, RoleArn=<role>)

  Step 3: AWS validates:
    a. JWT was signed by GitHub (via OIDC provider registered in IAM)
    b. The "sub" claim matches the trust policy on github-actions-terraform-plan
    c. The "aud" claim = "sts.amazonaws.com"

  Step 4: STS returns temporary credentials (valid 1 hour):
    AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_SESSION_TOKEN
    These are set as environment variables for subsequent steps.

CREDENTIAL EXPIRY: 1 hour.
If a PR plan takes > 1 hour: credentials expire mid-step.
Mitigation: plans should complete in < 15 minutes.
```

**Two different roles: plan vs apply:**
```
Plan role: github-actions-terraform-plan
  Permissions: read-only AWS access
    ec2:Describe*, rds:Describe*, eks:Describe*
    s3:GetObject (to read terraform state)
    NO: ec2:CreateVpc, rds:CreateDBInstance, eks:CreateCluster

  WHY READ-ONLY FOR PLAN:
  terraform plan calls AWS APIs to read current state and compare with config.
  If the plan role could modify resources: a malicious PR could abuse plan to
  create EC2 instances just by opening a PR. Minimise blast radius.

Apply role: github-actions-terraform-apply
  Permissions: full infrastructure management
    ec2:*, rds:*, eks:*, iam:PassRole, s3:*
    Can create, modify, delete resources.

  WHY SEPARATE ROLES:
  Plan happens on every PR (including PRs from forks or junior engineers).
  Apply only happens when merging to main (after code review + approval).
  If plan and apply used the same role: plan role would need apply permissions.
  A compromised plan step could destroy infrastructure.
```

---

### Step: `terraform init`

```yaml
- name: Terraform Init
  working-directory: ${{ env.WORKING_DIR }}
  run: terraform init -no-color
```

**What `terraform init` does:**
```
Three operations in one command:

1. Backend initialisation:
   Reads backend.tf:
     backend "s3" { bucket = "company-tfstate", key = "eks-platform/..." }
   Downloads state file from S3.
   Acquires DynamoDB lock (plan doesn't modify state, but init verifies access).
   Sets up the workspace for this run.

2. Provider installation:
   Reads versions.tf required_providers.
   Downloads: hashicorp/aws v5.50.x, hashicorp/kubernetes, hashicorp/helm, etc.
   Verifies checksums from .terraform.lock.hcl (provider lock file).
   Stores in .terraform/ directory (NOT committed to git).

3. Module resolution:
   Finds all module references in *.tf files.
   Downloads external modules from Terraform Registry.
   Copies local modules (./modules/vpc, ./modules/eks) into .terraform/modules/.

-no-color:
   Removes ANSI colour codes from output.
   CI logs don't render colours — raw ANSI codes appear as garbage: [32m+ resource[0m.
   With -no-color: plain text that's readable in CI logs and PR comments.

Without terraform init:
   terraform plan → "Error: Required plugins are not installed."
   Every run must init first. Providers and modules are not cached between jobs.
   (GitHub Actions runners are ephemeral — a fresh VM every job.)
```

---

### Step: `terraform fmt -check`

```yaml
- name: Terraform Format Check
  working-directory: ${{ env.WORKING_DIR }}
  run: terraform fmt -check -recursive -no-color
```

**What `terraform fmt` does:**
```
Terraform has an opinionated code style:
  - 2-space indentation
  - Aligned = signs in blocks
  - Specific quote styles

terraform fmt (without -check): REWRITES the files to match the style.
terraform fmt -check: checks IF files match the style, returns exit code 1 if not.

-check:
  Does NOT modify files. Returns:
    exit 0: all files are correctly formatted
    exit 1: at least one file needs reformatting
  CI uses the exit code to pass/fail the step.

-recursive:
  Checks ALL .tf files under the working directory, including subdirectories.
  Without -recursive: only checks .tf files in the current directory.
  The VPC and EKS modules (terraform/modules/) are also checked.

WHY FORMAT CHECK IN CI:
  Without it: PR has inconsistent indentation → hard to read the diff.
  Line 1: "  resource" (2 spaces), Line 2: "    resource" (4 spaces).
  git diff looks noisy even for small logic changes.

  With format check:
  PR with badly formatted code → CI fails immediately → engineer runs:
    terraform fmt -recursive  (to auto-fix)
  All code in the repo has consistent formatting.
  PR diffs only show real logic changes, not formatting noise.

Engineers avoid this step by: running terraform fmt before committing.
Many teams set up a pre-commit hook:
  echo "terraform fmt -check -recursive" > .git/hooks/pre-commit
  chmod +x .git/hooks/pre-commit
```

---

### Step: `terraform validate`

```yaml
- name: Terraform Validate
  working-directory: ${{ env.WORKING_DIR }}
  run: terraform validate -no-color
```

**What `terraform validate` does:**
```
Checks that the Terraform configuration is syntactically and logically correct
WITHOUT making any API calls to AWS.

Catches:
  - HCL syntax errors: missing braces, invalid attribute names
  - Invalid resource arguments: aws_eks_cluster with unknown attribute
  - Type errors: passing a string where a number is expected
  - Undefined variable references: var.cluster_name used but not declared
  - Module input errors: required module variable not provided

Does NOT catch:
  - AWS resource limit errors (your account has 5 VPCs limit, plan would create a 6th)
  - IAM permission errors (the role lacks permission to create this resource)
  - Resource already exists conflicts
  - Network connectivity issues

WHY VALIDATE BEFORE PLAN:
  terraform plan also validates internally, so validate feels redundant.
  But validate is: instant (no API calls), lightweight, catches obvious errors fast.
  If validate fails: plan is skipped → saves 2-3 minutes of API calls.

  For CI feedback speed:
  validate fails in 5 seconds.
  plan fails in 3 minutes (API calls needed before the error is caught).
  Fast feedback loop = engineers fix the issue sooner.

Real example of what validate catches:
  resource "aws_eks_cluster" "main" {
    cluster_name = var.cluster_name   # WRONG: should be 'name', not 'cluster_name'
  }
  validate: "An argument named 'cluster_name' is not expected here."
  Caught immediately. No API calls wasted.
```

---

### Step: `terraform plan` + Safety Check

```yaml
- name: Terraform Plan
  id: plan
  working-directory: ${{ env.WORKING_DIR }}
  run: |
    terraform plan -no-color -out=tfplan 2>&1 | tee plan.txt
    # Safety check: block if plan destroys stateful resources
    if grep -E "^  - resource" plan.txt | grep -E "aws_rds|aws_s3_bucket|aws_eks_cluster"; then
      echo "BLOCKED: plan destroys stateful resources. Requires manual review."
      exit 1
    fi
```

**`terraform plan -no-color -out=tfplan 2>&1 | tee plan.txt`**
```
terraform plan:
  Compares: desired state (*.tf files) vs actual state (S3 tfstate) vs real AWS.
  Outputs: + to add, ~ to change, - to destroy.
  Shows exactly what AWS API calls will be made on apply.

-out=tfplan:
  Saves the plan to a binary file (tfplan).
  This plan file can be passed directly to terraform apply.
  Guarantees: what was reviewed in the plan is EXACTLY what gets applied.
  Without -out:
    Plan shows: "will create 3 resources"
    Apply runs independently, re-computes the plan.
    If someone merged another PR between plan and apply:
    the apply plan might be different from what was reviewed.
  With -out=tfplan:
    Apply uses tfplan. No recomputation. Exactly what was reviewed.
  NOTE: in this pipeline, the plan file is NOT passed to apply.
  The -out file is only for the plan job. Apply reruns the plan.
  (See discussion at the end about plan/apply separation.)

2>&1:
  Redirects stderr (error output) to stdout.
  Terraform writes most output to stderr, not stdout.
  Without 2>&1: the pipe only captures stdout → plan.txt is empty.
  With 2>&1: both streams combined → plan.txt has everything.

| tee plan.txt:
  tee reads from stdin and writes to: a file (plan.txt) AND stdout simultaneously.
  The runner sees the plan output in real time during the step.
  plan.txt is created for the next step to read.
  Without tee: you'd redirect to a file and lose real-time output.
  Or you'd have real-time output but no file to read later.
```

**The Safety Check:**
```bash
if grep -E "^  - resource" plan.txt | grep -E "aws_rds|aws_s3_bucket|aws_eks_cluster"; then
  echo "BLOCKED: plan destroys stateful resources. Requires manual review."
  exit 1
fi
```
```
WHY THIS SAFETY CHECK EXISTS:
  A common Terraform accident:
  Engineer refactors module structure.
  Terraform sees: old resource at path A → new resource at path B.
  Terraform plans: destroy resource at A, create resource at B.
  For stateless resources (security groups): destroy + recreate = fine.
  For stateful resources (RDS, S3, EKS): DESTROY = DATA LOSS.

  RDS deletion: all database data is GONE.
  S3 bucket deletion: all objects are GONE (if force_destroy = true).
  EKS cluster deletion: all running pods, configs, PVCs are GONE.

  The safety check catches: "this plan will DESTROY an RDS instance"
  and blocks the pipeline immediately. Requires a human to review.

HOW THE CHECK WORKS:
  grep -E "^  - resource":
    Finds lines in plan.txt that START with "  - resource"
    (2 spaces + dash = Terraform's destroy notation)
    Example matching line: "  - resource "aws_db_instance" "main" {"

  | grep -E "aws_rds|aws_s3_bucket|aws_eks_cluster":
    Further filters to only lines containing these resource types.
    Only destruction of these specific resources triggers the block.
    A security group deletion (aws_security_group) would NOT trigger this.

  exit 1:
    The plan step fails → CI fails → PR cannot be merged.
    An engineer must investigate WHY the resource is being destroyed.
    If intentional (decommissioning old RDS): they must manually:
      terraform state rm aws_db_instance.old
      Or set deletion_protection=false and add lifecycle.prevent_destroy=false

LIMITATION OF THIS CHECK:
  It only looks at plan.txt text output.
  Terraform's plan output format is human-readable, not machine-parseable.
  The regex might miss some cases or trigger false positives.
  Better approach for teams: use terraform plan -json and parse the JSON output.
```

---

### Step: Post Plan to PR

```yaml
- name: Post Plan to PR
  uses: actions/github-script@v7
  with:
    script: |
      const fs = require('fs');
      const plan = fs.readFileSync('${{ env.WORKING_DIR }}/plan.txt', 'utf8');
      const body = [
        '## Terraform Infrastructure Plan',
        '```',
        plan.substring(0, 65000),
        '```',
      ].join('\n');
      github.rest.issues.createComment({
        issue_number: context.issue.number,
        owner: context.repo.owner,
        repo: context.repo.repo,
        body
      });
```

**What this step does:**
```
Reads plan.txt (created in the previous step).
Posts it as a comment on the PR using the GitHub API.

WHY POST THE PLAN TO THE PR:
  Without this: engineer opens the PR → wants to see what changes.
  They must: click "Checks" → click the plan job → scroll through raw CI logs.
  3-4 clicks, hard to read.

  With this: PR shows a comment:
    ## Terraform Infrastructure Plan
    ```
    + aws_eks_node_group.application: instance_types = ["m7g.xlarge"]
    ~ aws_eks_cluster.main: version = "1.29" → "1.30"
    Plan: 2 to change, 0 to add, 0 to destroy.
    ```
  Reviewer sees: "Oh, this upgrades EKS from 1.29 to 1.30" → approves or requests changes.
  Plan review IS the infrastructure code review.

plan.substring(0, 65000):
  GitHub PR comments have a maximum size.
  Large plans (many resources) can exceed the limit.
  Truncating at 65,000 characters prevents the API call from failing.
  Most plans fit within 65,000 characters.
  For very large plans: engineers check the CI logs directly.

context.issue.number:
  In GitHub Actions, a pull_request is treated as an "issue" for commenting purposes.
  context.issue.number = the PR number.
  Used by the GitHub API to identify which PR to comment on.
```

---

### `jobs: apply:` — The Main Branch Apply Job

```yaml
apply:
  name: Terraform Apply
  if: github.event_name == 'push'
  runs-on: ubuntu-latest
  environment: production
  permissions:
    id-token: write
    contents: read
```

**`if: github.event_name == 'push'`**
```
Only runs when triggered by a push to main (i.e., a PR was merged).
NOT on pull_request events (those trigger plan only).

This is the mirror of 'plan': if: github.event_name == 'pull_request'.
The two jobs are mutually exclusive on every trigger.
```

**`environment: production`**
```
References a GitHub Environment named "production".
GitHub Environments can have:
  - Required reviewers (human approval gate before job runs)
  - Wait timer (delay before running)
  - Environment secrets (separate from repo secrets)
  - Deployment protection rules

For this pipeline:
  environment: production without required reviewers = no extra approval.
  The PR merge itself was the approval gate.
  The environment provides: deployment history (who applied when),
  environment-specific secrets (separate prod AWS keys), audit trail.

To add a manual approval gate (e.g., for major infra changes):
  Repo Settings → Environments → production → Required reviewers → add SRE leads.
  The apply job pauses and emails approvers before proceeding.
```

**`permissions: (apply job has no pull-requests: write)`**
```
apply:
  id-token: write   ← OIDC auth to AWS (same as plan)
  contents: read    ← checkout repo
  NO pull-requests: write

The apply job doesn't post PR comments (there's no PR at this point — it's merged).
Only the MINIMUM permissions needed. Least privilege principle applied to CI.
```

---

### Apply: `terraform apply -auto-approve`

```yaml
- name: Terraform Apply
  working-directory: ${{ env.WORKING_DIR }}
  run: terraform apply -auto-approve -no-color
```

**`-auto-approve`**
```
Without -auto-approve:
  terraform apply displays the plan and asks:
  "Do you want to perform these actions? Enter 'yes' to confirm."
  A GitHub Actions runner CANNOT type "yes" — it's non-interactive.
  The step hangs until the 6-hour job timeout kills it.

With -auto-approve:
  Skips the confirmation prompt. Applies immediately.
  SAFE BECAUSE: the PR was already reviewed. The plan was posted as a comment.
  A human approved the PR before it was merged.
  -auto-approve is the automated equivalent of a human typing "yes" after review.

WHY NOT PASS -out=tfplan FROM THE PLAN JOB:
  The plan job and apply job are separate jobs in separate runners.
  Files created in one job don't automatically transfer to another.
  To pass the plan file: use actions/upload-artifact + actions/download-artifact.
  
  Most pipelines don't do this because:
    Plan runs on PR (could be hours/days before merge).
    Stale plan: if another PR merged between plan and apply,
    the plan file is outdated → apply uses wrong plan.
    
  Safer: apply reruns the plan immediately before applying.
  Cost: 2-3 minutes extra. Benefit: always applies the current state.
  
  For guaranteed plan-apply consistency: use Atlantis or Terraform Cloud
  which explicitly link plan and apply in one atomic operation.
```

---

## What Happens When the Apply Fails

```
Scenario: terraform apply starts, creates 3 resources, then fails on resource 4.

Result:
  Resources 1-3: CREATED in AWS.
  Resource 4: NOT created.
  Terraform state: partially updated (records resources 1-3).

Next run (after fixing the code):
  Terraform reads state: resources 1-3 already exist.
  Plan: only create resource 4 (the one that failed).
  No duplicate creation.

This is Terraform's idempotency guarantee:
  Apply can always be re-run safely.
  Already-created resources are not recreated.

EXCEPTION: if you're in a partial apply with a destroyed resource:
  resource A deleted (gone from AWS).
  resource B creation failed.
  State: A marked as deleted, B not in state.
  Next run: plan shows B to create. A is still gone (no re-creation attempt).
  
  Manual recovery: terraform import to re-add A to state if it still exists.
```

---

## Full Flow Summary

```
Developer opens PR (changes terraform/modules/eks/main.tf):
  ↓
GitHub triggers: pull_request event
  ↓
plan job runs:
  checkout → setup terraform 1.8.0 → assume plan role (read-only) →
  terraform init (connect to S3 state, download providers) →
  terraform fmt -check (format OK?) →
  terraform validate (syntax OK?) →
  terraform plan (what changes? saved to plan.txt) →
  safety check (no RDS/S3/EKS destroyed?) →
  post plan to PR (comment shows the diff)
  ↓
PR shows comment: "~ aws_eks_cluster.main: version 1.29 → 1.30"
  ↓
Reviewer approves → Engineer merges PR
  ↓
GitHub triggers: push event
  ↓
apply job runs:
  checkout → setup terraform 1.8.0 → assume apply role (read-write) →
  terraform init (same S3 state, fresh runner so re-download providers) →
  terraform apply -auto-approve (runs plan again + applies to AWS)
  ↓
EKS control plane upgraded to 1.30.
State file in S3 updated to reflect new version.
GitHub Environment "production" shows new deployment in history.
```

---

## Verification Commands (Run after apply)

```bash
# Verify state is consistent with AWS after apply
cd terraform/
terraform plan -refresh-only
# Expected: "No changes. Your infrastructure matches the configuration."
# If changes shown: drift detected — AWS was modified outside Terraform

# Check the state file was updated
aws s3 ls s3://company-terraform-state-prod/eks-platform/ \
  --human-readable
# Should show a recent Last Modified timestamp

# Verify DynamoDB lock was released (no leftover lock)
aws dynamodb get-item \
  --table-name terraform-state-lock \
  --key '{"LockID":{"S":"company-terraform-state-prod/eks-platform/terraform.tfstate"}}' \
  --output json
# Expected: returns empty (no lock entry) = lock was properly released

# See what Terraform applied (GitHub deployment history)
gh run list --workflow=terraform-infra.yaml --limit 5
# Shows recent workflow runs: success/failure, who triggered, when

# View the plan output from a specific run
gh run view <run-id> --log | grep -A 50 "Terraform Plan"
```
