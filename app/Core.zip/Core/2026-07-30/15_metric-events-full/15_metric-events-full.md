# Full Metric Events — 8 Signals Deep Dive

> **Context:** Expanding the `metric-events.tf` from 4 Golden Signals to **8 real production signals**, including memory, JVM heap, disk, network error rate, and pod restarts.
> Each signal maps to a Dynatrace metric key, event type, and alerting tier.

---

## Signal Map: What Each Metric Catches

```
GOLDEN SIGNALS (Google SRE Book):
  Signal 1  TRAFFIC       builtin:service.requestCount.server      → detect silent outage
  Signal 2  ERRORS        builtin:service.errors.server.rate       → user-visible failures
  Signal 3  LATENCY       builtin:service.response.time (p99)      → slow request tail
  Signal 4  SATURATION    builtin:process.cpu.usage                → CPU pressure (leading indicator)

ADDITIONAL REAL-WORLD SIGNALS:
  Signal 5  MEMORY        builtin:process.memory.usage             → OOM kill prevention
  Signal 6  JVM HEAP      builtin:process.mem.commit (JVM only)    → GC pressure, heap exhaustion
  Signal 7  POD RESTARTS  builtin:cloud.kubernetes.workload.restarts → crash-looping pods
  Signal 8  NETWORK ERROR builtin:host.net.errorRate.total         → packet drops, NIC issues

WHY NOT JUST USE AVAILABILITY CHECK:
  Availability check = "is /health returning 200?"
  These 8 signals = "IS the service actually healthy BEFORE it starts failing?"
  
  Signals 4/5/6 fire BEFORE the service starts erroring.
  Signals 7/8 fire for infrastructure-layer problems the service can't self-report.
  Signal 1 (traffic drop) catches outages that look healthy from inside the cluster.
```

---

## Signal to Event Type to Alerting Tier Mapping

```
Signal        metric_key                              event_type                  → Alerting Tier
─────────────────────────────────────────────────────────────────────────────────────────────────
Traffic drop  service.requestCount.server             ERROR_EVENT                 → Critical (PagerDuty)
Error rate    service.errors.server.rate              ERROR_EVENT                 → High (PagerDuty push)
Latency p99   service.response.time p99               PERFORMANCE_EVENT           → Warning (Slack)
CPU           process.cpu.usage                       RESOURCE_CONTENTION_EVENT   → Info (Slack #monitoring)
Memory        process.memory.usage                    RESOURCE_CONTENTION_EVENT   → Info (Slack #monitoring)
JVM Heap      process.mem.commit                      RESOURCE_CONTENTION_EVENT   → Info (Slack #monitoring)
Pod Restarts  cloud.kubernetes.workload.restarts       ERROR_EVENT                 → High (PagerDuty push)
Network Error host.net.errorRate.total                ERROR_EVENT                 → High (PagerDuty push)
```

---

## Updated services variable (variables.tf) — add new fields

The `variables.tf` services map needs new threshold fields:

See: `variables-expanded.tf`

---

## The 8-Signal metric-events.tf

See: `metric-events-8signal.tf`

---

## Threshold Tuning Guide

```
HOW TO SET THRESHOLDS (not guessing):

Step 1 — Baseline (first 2 weeks, no alerts):
  Deploy Dynatrace, let it observe. Do NOT set alerts yet.
  Look at each metric in the Dynatrace UI: what is "normal" for each service?

Step 2 — Set initial thresholds at 3× the normal:
  Normal CPU: 30% → alert at 80%
  Normal p99 latency: 150ms → alert at 500ms
  Normal error rate: 0.01% → alert at 0.5%

Step 3 — Tune based on false positives (over 30 days):
  Too many alerts? Increase threshold or increase violating_samples.
  Missing real incidents? Decrease threshold or decrease violating_samples.

TEAM-SPECIFIC THRESHOLDS (examples):
  payment-service: strict — handles money, lower thresholds
    error_rate_alert   = 0.1  (0.1% — any error is serious)
    latency_p99_ms     = 300  (300ms — payments must be fast)
    cpu_saturation_pct = 70   (70% — aggressively scale out)
    
  analytics-service: relaxed — batch workload, high tolerance
    error_rate_alert   = 5.0  (5% — data pipelines have retries)
    latency_p99_ms     = 5000 (5s — batch queries are slow by design)
    cpu_saturation_pct = 90   (90% — expected to spike during batch)
```

---

## Verification Commands

```bash
# List all metric events via Dynatrace API
DT_URL="https://<your-tenant>.live.dynatrace.com"
DT_TOKEN="<your-api-token>"

curl -s "$DT_URL/api/v2/settings/objects" \
  -H "Authorization: Api-Token $DT_TOKEN" \
  -G --data-urlencode "schemaIds=builtin:anomaly-detection.metric-events" \
  --data-urlencode "fields=value" | \
  python3 -c "
import json, sys
data = json.load(sys.stdin)
for item in data.get('items', []):
    v = item.get('value', {})
    print(f\"{v.get('summary','?')} | enabled={v.get('enabled')} | type={v.get('modelProperties',{}).get('type','?')}\")
"

# Verify a metric key exists and returns data
curl -s "$DT_URL/api/v2/metrics/query" \
  -H "Authorization: Api-Token $DT_TOKEN" \
  -G \
  --data-urlencode "metricSelector=builtin:process.memory.usage:filter(eq(process.name,payment-service)):max" \
  --data-urlencode "from=now-5m" \
  --data-urlencode "resolution=1m" | \
  python3 -c "import json,sys; d=json.load(sys.stdin); print(json.dumps(d.get('result',[{}])[0].get('data',[{}])[0], indent=2))"

# Check terraform output IDs
cd terraform/dynatrace/
terraform output | grep metric_event

# After apply: confirm events in DT
# Settings → Anomaly Detection → Custom Metric Events
# Should see 8 entries per service (for 4 services = 32 entries)
```
