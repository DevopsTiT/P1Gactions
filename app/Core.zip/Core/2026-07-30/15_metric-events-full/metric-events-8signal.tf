##############################################################################
# Dynatrace Custom Metric Events — 8 Production Signals
#
# GOLDEN SIGNALS (Google SRE):
#   Signal 1: TRAFFIC      → traffic_drop        (req/min drops below threshold)
#   Signal 2: ERRORS       → error_rate          (HTTP 5xx rate exceeds threshold)
#   Signal 3: LATENCY      → latency_p99         (p99 response time exceeds threshold)
#   Signal 4: SATURATION   → cpu_saturation      (process CPU exceeds threshold)
#
# ADDITIONAL REAL-WORLD SIGNALS:
#   Signal 5: MEMORY       → memory_usage        (process RSS memory % of limit)
#   Signal 6: JVM HEAP     → jvm_heap            (heap used % of max — JVM only)
#   Signal 7: POD RESTARTS → pod_restarts        (crash loop detection)
#   Signal 8: NETWORK ERROR→ network_error_rate  (packet errors/drops)
#
# Event type → alerting tier mapping:
#   ERROR_EVENT              → Critical (AVAILABILITY) or High (ERROR) → PagerDuty
#   PERFORMANCE_EVENT        → Warning (SLOWDOWN) → Slack
#   RESOURCE_CONTENTION_EVENT→ Info (RESOURCE_CONTENTION) → Slack #monitoring
##############################################################################

locals {
  # Only services with traffic_min_rps > 0 get traffic drop alerts
  # Analytics-style services with batch quiet periods are excluded
  services_with_traffic_alert = {
    for name, svc in var.services : name => svc
    if svc.traffic_min_rps > 0
  }

  # Only JVM services get heap monitoring
  jvm_services = {
    for name, svc in var.services : name => svc
    if svc.is_jvm_service
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# SIGNAL 1: TRAFFIC — requests per minute (BELOW threshold)
#
# WHY THIS IS THE MOST IMPORTANT SIGNAL:
#   Error rate = 0% when traffic = 0 (no requests = no errors = looks healthy).
#   A silent outage caused by DNS failure, ALB misconfiguration, or a deploy
#   failure is ONLY caught by a traffic drop alert.
#   Every other signal looks completely green while traffic is zero.
#
# alert_on_no_data = true: fires even when Dynatrace receives ZERO data points.
# This catches the case where the service is so broken it can't send metrics.
#
# alert_condition = "BELOW": unique — all other signals fire ABOVE threshold.
# ─────────────────────────────────────────────────────────────────────────────
resource "dynatrace_metric_events" "traffic_drop" {
  for_each = local.services_with_traffic_alert

  enabled                    = true
  event_entity_dimension_key = "dt.entity.service"
  event_type                 = "ERROR_EVENT"
  # ERROR_EVENT → routes via the ERROR severity level → High tier (PagerDuty push).
  # Traffic drop is treated as an error because it indicates a silent outage.

  summary     = "[${upper(var.environment)}] ${each.key}: Traffic drop (<${each.value.traffic_min_rps} req/min)"
  description = "Request rate for ${each.key} dropped below ${each.value.traffic_min_rps} req/min for 3 consecutive minutes. Possible silent outage — check ALB, DNS, and recent deployments. Owner: team:${each.value.team}"

  metadata {
    configuration_versions = [4]
    dynatrace_version      = "1.0"
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "BELOW"    # ← only signal that fires BELOW threshold
    alert_on_no_data   = true       # ← CRITICAL: fires when DT gets no data at all
    dealerting_samples = 5          # traffic must recover for 5 consecutive minutes before closing
    samples            = 5
    threshold          = each.value.traffic_min_rps
    violating_samples  = 3          # 3 consecutive minutes below → real problem, not a blip
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:service.requestCount.server"
    # Total server-side requests per minute. Includes all HTTP methods and status codes.
    resolution = "1m"
    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = each.key
        key      = "service.name"
      }
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment
        key      = "environment"
      }
    }
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# SIGNAL 2: ERRORS — HTTP 5xx error rate %
#
# WHY P99 IS NOT ENOUGH: error rate and latency are independent signals.
# A service can have 0ms latency and 100% error rate (fast failures).
# A service can have 0% error rate and 10s latency (slow but succeeding).
# You need BOTH signals. Neither replaces the other.
#
# Threshold format: decimal, NOT percentage.
#   0.5 = 0.5%  |  1.0 = 1%  |  5.0 = 5%
# ─────────────────────────────────────────────────────────────────────────────
resource "dynatrace_metric_events" "error_rate" {
  for_each = var.services

  enabled                    = true
  event_entity_dimension_key = "dt.entity.service"
  event_type                 = "ERROR_EVENT"

  summary     = "[${upper(var.environment)}] ${each.key}: High error rate (>${each.value.error_rate_alert}%)"
  description = "HTTP 5xx error rate for ${each.key} exceeded ${each.value.error_rate_alert}% for 3 consecutive minutes. Owner: team:${each.value.team}"

  metadata {
    configuration_versions = [4]
    dynatrace_version      = "1.0"
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false    # no data = service probably down (traffic alert handles this)
    dealerting_samples = 5
    samples            = 5
    threshold          = each.value.error_rate_alert   # e.g. 0.5 = 0.5%
    violating_samples  = 3
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:service.errors.server.rate"
    # Returns decimal: 0.005 = 0.5% error rate.
    # Counts: 5xx responses, thrown exceptions, request timeouts.
    resolution = "1m"
    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = each.key
        key      = "service.name"
      }
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment
        key      = "environment"
      }
    }
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# SIGNAL 3: LATENCY — P99 response time
#
# WHY P99, NOT AVERAGE:
#   Average latency can be 50ms while 1% of users experience 5000ms.
#   With 1,000 requests/minute: P99 = 10 users per minute getting a terrible experience.
#   That 1% compounds: a user retrying slow requests doubles your load.
#   P99 = the SLI that maps most directly to user experience.
#
# UNIT: Dynatrace stores response time in MICROSECONDS (μs).
#   var.latency_p99_ms is in ms → multiply by 1000 for the threshold.
#   500ms → threshold = 500,000 (not 500).
# ─────────────────────────────────────────────────────────────────────────────
resource "dynatrace_metric_events" "latency_p99" {
  for_each = var.services

  enabled                    = true
  event_entity_dimension_key = "dt.entity.service"
  event_type                 = "PERFORMANCE_EVENT"
  # PERFORMANCE_EVENT → SLOWDOWN severity → Warning tier (Slack, 5-min delay).
  # Latency degradation = SEV3 — investigate during business hours unless severe.

  summary     = "[${upper(var.environment)}] ${each.key}: P99 latency breach (>${each.value.latency_p99_ms}ms)"
  description = "P99 response time for ${each.key} exceeded ${each.value.latency_p99_ms}ms for 5 consecutive minutes. Check DB query times, downstream dependencies, and recent deployments. Owner: team:${each.value.team}"

  metadata {
    configuration_versions = [4]
    dynatrace_version      = "1.0"
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    dealerting_samples = 5
    samples            = 5
    threshold          = each.value.latency_p99_ms * 1000  # ms → μs conversion
    violating_samples  = 5   # more samples: latency fluctuates more than error rate
  }

  query_definition {
    type        = "METRIC_KEY"
    metric_key  = "builtin:service.response.time"
    aggregation = "PERCENTILE"
    percentile  = 99   # P99: 99% of requests complete faster than this value
    resolution  = "1m"
    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = each.key
        key      = "service.name"
      }
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment
        key      = "environment"
      }
    }
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# SIGNAL 4: CPU SATURATION — process CPU utilisation
#
# WHY THIS IS A LEADING INDICATOR:
#   CPU at 90%: the kernel is scheduling every process fairly.
#   But "fair" scheduling = everything gets slower.
#   Request queues build up. P99 latency starts climbing.
#   The latency alert fires 3-5 minutes AFTER CPU alert.
#   Catching CPU first = more time to scale before users are impacted.
#
# entity_dimension_key: MUST be dt.entity.process_group_instance for CPU metrics.
# CPU is measured at the process level, not the service level.
# ─────────────────────────────────────────────────────────────────────────────
resource "dynatrace_metric_events" "cpu_saturation" {
  for_each = var.services

  enabled                    = true
  event_entity_dimension_key = "dt.entity.process_group_instance"
  # process_group_instance = a specific running process (PID group) on a host.
  # NOT dt.entity.service — service is a logical concept, CPU is physical.
  event_type = "RESOURCE_CONTENTION_EVENT"
  # RESOURCE_CONTENTION_EVENT → Info tier (Slack #monitoring, 15-min delay).

  summary     = "[${upper(var.environment)}] ${each.key}: CPU saturation (>${each.value.cpu_saturation_pct}%)"
  description = "Process CPU for ${each.key} exceeded ${each.value.cpu_saturation_pct}% for 5 consecutive minutes. Check HPA scaling, Karpenter node provisioning, and recent traffic changes. Owner: team:${each.value.team}"

  metadata {
    configuration_versions = [4]
    dynatrace_version      = "1.0"
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    dealerting_samples = 10   # CPU recovers slowly after scaling — give it time
    samples            = 5
    threshold          = each.value.cpu_saturation_pct   # 80 = 80%
    violating_samples  = 5    # 5 consecutive minutes: filter transient spikes (e.g., JVM startup)
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:process.cpu.usage"
    # Process CPU as % (0–100). More accurate than Kubernetes CPU throttling metrics.
    # Kubernetes "CPU throttled" is different — throttling can occur even at low usage.
    resolution = "1m"
    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = each.key
        key      = "process.name"
      }
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment
        key      = "environment"
      }
    }
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# SIGNAL 5: MEMORY — process RSS memory as % of container limit
#
# WHY NOT JUST WATCH FOR OOM KILLS:
#   OOM kill = the process is already dead. You're watching the corpse.
#   Memory at 85% = "in 10 minutes this process will be killed".
#   Alert at 80% = time to investigate leak, increase limit, or roll restart.
#
# METRIC: builtin:process.memory.usage
#   Returns RSS (Resident Set Size) in bytes.
#   You compare to the container memory limit to get a percentage.
#   Threshold approach: set absolute byte threshold based on container limit.
#   Example: 512Mi limit → alert at 410Mi (80%) → threshold = 430,000,000 bytes.
#
# ALTERNATIVE: use builtin:kubernetes.container.memoryLimitUtilization
#   Returns % directly (0–100) without needing to calculate bytes.
#   Used here for simplicity.
# ─────────────────────────────────────────────────────────────────────────────
resource "dynatrace_metric_events" "memory_usage" {
  for_each = var.services

  enabled                    = true
  event_entity_dimension_key = "dt.entity.cloud_application_instance"
  # cloud_application_instance = a Kubernetes pod (one instance of a workload).
  # More granular than process_group_instance for containerised workloads.
  event_type = "RESOURCE_CONTENTION_EVENT"

  summary     = "[${upper(var.environment)}] ${each.key}: High memory usage (>${each.value.memory_usage_pct}% of limit)"
  description = "Memory usage for ${each.key} pods exceeded ${each.value.memory_usage_pct}% of container memory limit. OOM kill risk. Check for memory leaks, increase memory limit, or restart pods. Owner: team:${each.value.team}"

  metadata {
    configuration_versions = [4]
    dynatrace_version      = "1.0"
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    dealerting_samples = 10
    samples            = 5
    threshold          = each.value.memory_usage_pct  # e.g. 80 = 80% of container limit
    violating_samples  = 5
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:kubernetes.container.memoryLimitUtilization"
    # Returns: percentage of container memory limit in use (0–100).
    # Much simpler than calculating from raw bytes. DT divides RSS by limit for you.
    resolution = "1m"
    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = each.key
        key      = "k8s.workload.name"
        # Matches on the Kubernetes Deployment/StatefulSet name.
      }
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment
        key      = "environment"
      }
    }
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# SIGNAL 6: JVM HEAP — heap utilisation % (Java services only)
#
# WHY JVM HEAP IS A SEPARATE SIGNAL FROM MEMORY:
#   process.memory.usage = total RSS (includes JVM off-heap, native memory, code cache).
#   JVM heap = ONLY the object allocation area. Where most leaks happen.
#   A JVM process can be at 50% RSS but 95% heap utilisation.
#   Heap at 95% → GC runs 100% of the time → throughput drops to near zero → OOM.
#
# JVM HEAP PHASES:
#   < 50%: healthy, minor GC keeps up
#   50–75%: GC more frequent but manageable
#   75%: alert threshold — GC is starting to impact latency
#   90%: critical — major GC pauses, latency spikes visible to users
#   95%+: near-OOM, JVM may be unresponsive
#
# Only created for services where is_jvm_service = true.
# ─────────────────────────────────────────────────────────────────────────────
resource "dynatrace_metric_events" "jvm_heap" {
  for_each = local.jvm_services   # only JVM services — defined in locals above

  enabled                    = true
  event_entity_dimension_key = "dt.entity.process_group_instance"
  event_type                 = "RESOURCE_CONTENTION_EVENT"

  summary     = "[${upper(var.environment)}] ${each.key}: JVM heap pressure (>${each.value.jvm_heap_pct}% of max heap)"
  description = "JVM heap utilisation for ${each.key} exceeded ${each.value.jvm_heap_pct}% of -Xmx for 5 consecutive minutes. GC pressure likely. Check for memory leaks, increase -Xmx, or scale out. Owner: team:${each.value.team}"

  metadata {
    configuration_versions = [4]
    dynatrace_version      = "1.0"
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    dealerting_samples = 10   # heap recovers after full GC — wait before de-alerting
    samples            = 5
    threshold          = each.value.jvm_heap_pct   # e.g. 75 = 75% of max heap
    violating_samples  = 5
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:process.memory.jvm.heapUtilization"
    # JVM-specific metric. Returns: heap used / heap max × 100 (percentage).
    # DT only populates this metric for processes detected as JVM by OneAgent.
    # For non-JVM processes: metric returns no data (safe — alert_on_no_data = false).
    resolution = "1m"
    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = each.key
        key      = "process.name"
      }
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment
        key      = "environment"
      }
    }
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# SIGNAL 7: POD RESTARTS — crash loop detection
#
# WHY THIS CATCHES WHAT OTHER SIGNALS MISS:
#   A pod in CrashLoopBackOff is restarting every 30 seconds.
#   Between restarts: the pod is "starting up" and HEALTHY from Dynatrace's view.
#   Error rate = 0 (pod not receiving traffic during restart).
#   Latency = 0 (no requests).
#   CPU/memory = 0 (process is dead).
#   Traffic = 0 (Kubernetes routes traffic away during restart).
#   ALL FOUR GOLDEN SIGNALS LOOK PERFECT while the pod is crash-looping.
#
#   Pod restarts signal catches this. 2+ restarts in 5 minutes = crash loop.
#
# entity_dimension_key: dt.entity.cloud_application
#   cloud_application = the Kubernetes Deployment/StatefulSet (not individual pod).
#   Summing restarts across all pods: one alert for the workload, not per-pod noise.
# ─────────────────────────────────────────────────────────────────────────────
resource "dynatrace_metric_events" "pod_restarts" {
  for_each = var.services

  enabled                    = true
  event_entity_dimension_key = "dt.entity.cloud_application"
  event_type                 = "ERROR_EVENT"
  # ERROR_EVENT → High tier (PagerDuty push, 2-min delay).
  # Crash-looping pod = production problem requiring immediate investigation.

  summary     = "[${upper(var.environment)}] ${each.key}: Pod restarts detected (>${each.value.pod_restart_threshold} in 5 min)"
  description = "${each.key} pods restarted more than ${each.value.pod_restart_threshold} times in 5 minutes. Possible CrashLoopBackOff. Run: kubectl describe pod -l app=${each.key} to see crash reason. Owner: team:${each.value.team}"

  metadata {
    configuration_versions = [4]
    dynatrace_version      = "1.0"
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    dealerting_samples = 3   # pod restarts stop quickly once fixed
    samples            = 1   # fire on the FIRST sample above threshold
    threshold          = each.value.pod_restart_threshold   # e.g. 2 = 2 restarts
    violating_samples  = 1   # 1 violation is enough — crash loop is obvious
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:cloud.kubernetes.workload.restarts"
    # Number of container restarts in the observation period (1 minute resolution).
    # Summed across all pods in the workload.
    resolution = "1m"
    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = each.key
        key      = "k8s.workload.name"
        # Matches the Kubernetes Deployment or StatefulSet name.
      }
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment
        key      = "environment"
      }
    }
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# SIGNAL 8: NETWORK ERROR RATE — packet errors and drops
#
# WHY THIS CATCHES INFRASTRUCTURE-LAYER PROBLEMS:
#   Application-level signals (errors, latency) only fire when a request
#   makes it TO the application. Network errors happen BEFORE the request arrives.
#
#   Use cases:
#   - NIC failure on a node (all traffic to that node starts dropping)
#   - CNI misconfiguration after an EKS upgrade
#   - Security group rule unintentionally blocking traffic
#   - Subnet routing table change causing packet drops
#
# entity_dimension_key: dt.entity.host (not service, not process)
#   Network errors are measured at the host/node level by OneAgent.
#   The host entity is the EC2 node running the pod.
# ─────────────────────────────────────────────────────────────────────────────
resource "dynatrace_metric_events" "network_error_rate" {
  for_each = var.services

  enabled                    = true
  event_entity_dimension_key = "dt.entity.host"
  # Host = the EC2 node. This alert fires per node, not per service.
  # OneAgent on the node sends network metrics to Dynatrace.
  event_type = "ERROR_EVENT"

  summary     = "[${upper(var.environment)}] ${each.key} host: Network error rate (>${each.value.network_error_rate_pct}%)"
  description = "Network packet error/drop rate on host running ${each.key} exceeded ${each.value.network_error_rate_pct}%. Check NIC health, security groups, and CNI configuration. Owner: team:${each.value.team}"

  metadata {
    configuration_versions = [4]
    dynatrace_version      = "1.0"
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    dealerting_samples = 5
    samples            = 3
    threshold          = each.value.network_error_rate_pct   # e.g. 1.0 = 1% packet error rate
    violating_samples  = 3
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:host.net.errorRate.total"
    # Total network error rate across all interfaces on the host.
    # Includes: transmit errors, receive errors, packet drops.
    # Normal is < 0.01%. Anything above 0.5% warrants investigation.
    resolution = "1m"
    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment
        key      = "environment"
      }
      # Note: network errors are per host, not per service.
      # The management zone scoping ensures only hosts in this
      # team's management zone trigger this team's alerting profile.
      # A more precise filter would use dt.entity.host tags set by
      # Dynatrace auto-tagging rules based on the node group label.
    }
  }
}

##############################################################################
# OUTPUTS — expose all event IDs for reference and testing
##############################################################################

output "metric_event_ids" {
  description = "All metric event IDs organised by signal type"
  value = {
    traffic_drop        = { for k, v in dynatrace_metric_events.traffic_drop : k => v.id }
    error_rate          = { for k, v in dynatrace_metric_events.error_rate : k => v.id }
    latency_p99         = { for k, v in dynatrace_metric_events.latency_p99 : k => v.id }
    cpu_saturation      = { for k, v in dynatrace_metric_events.cpu_saturation : k => v.id }
    memory_usage        = { for k, v in dynatrace_metric_events.memory_usage : k => v.id }
    jvm_heap            = { for k, v in dynatrace_metric_events.jvm_heap : k => v.id }
    pod_restarts        = { for k, v in dynatrace_metric_events.pod_restarts : k => v.id }
    network_error_rate  = { for k, v in dynatrace_metric_events.network_error_rate : k => v.id }
  }
}
