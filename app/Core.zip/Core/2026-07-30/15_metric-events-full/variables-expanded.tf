##############################################################################
# Expanded variables.tf — adds memory, JVM heap, pod restart, network thresholds
# Drop-in replacement for the existing variables.tf services map.
##############################################################################

variable "environment" {
  type    = string
  default = "production"
}

variable "dynatrace_api_url" {
  type      = string
  sensitive = true
}

variable "synthetic_locations" {
  type = list(string)
  default = [
    "GEOLOCATION-6F55B7E4B5E7A52F", # Tokyo
    "GEOLOCATION-D15FBAABA11A2D7D", # Singapore
  ]
}

variable "pagerduty_integration_keys" {
  type      = map(string)
  sensitive = true
  default   = {}
}

variable "slack_webhook_urls" {
  type      = map(string)
  sensitive = true
  default   = {}
}

##############################################################################
# SERVICES MAP — single source of truth for all metric event thresholds
# Each entry creates: 8 metric events (4 golden signals + memory + JVM + restarts + network)
##############################################################################
variable "services" {
  type = map(object({
    team             = string
    slo_target       = number
    health_check_url = string

    # ── Signal 1: Traffic ────────────────────────────────────────────
    traffic_min_rps = number
    # Minimum expected requests per minute.
    # Below this for 3 consecutive minutes = silent outage alert.
    # How to find: look at Dynatrace traffic graph at quietest time (e.g., 3am).
    # Set threshold to 50% of that quiet-time baseline.

    # ── Signal 2: Errors ─────────────────────────────────────────────
    error_rate_alert = number
    # HTTP 5xx error rate as a decimal. 0.5 = 0.5%, 1.0 = 1%.
    # Payment services: 0.1 (strict). Analytics: 2.0 (relaxed).

    # ── Signal 3: Latency ────────────────────────────────────────────
    latency_p99_ms = number
    # P99 response time in milliseconds.
    # Set at 2-3× your normal P99 baseline.
    # Payment: 300ms. API gateway: 500ms. Batch service: 5000ms.

    # ── Signal 4: CPU Saturation ─────────────────────────────────────
    cpu_saturation_pct = number
    # Process CPU utilisation as a percentage (0-100).
    # 80% is a good starting point for most services.
    # JVM services: 70% (GC kicks in aggressively above this).

    # ── Signal 5: Memory ─────────────────────────────────────────────
    memory_usage_pct = number
    # Process RSS memory as % of container memory limit.
    # 80% = alert. At 90%+ the OOM killer terminates the process.
    # Set lower for services with large working sets or leaks.

    # ── Signal 6: JVM Heap ───────────────────────────────────────────
    jvm_heap_pct     = number
    is_jvm_service   = bool
    # Heap used as % of max heap (-Xmx).
    # 75% = alert (GC pressure begins). 90% = GC thrashing, latency spikes.
    # Only meaningful for Java/JVM services. Set is_jvm_service = false for Go/Python/Node.

    # ── Signal 7: Pod Restarts ───────────────────────────────────────
    pod_restart_threshold = number
    # Number of pod restarts in 5 minutes before alerting.
    # 2 = alert immediately (crash loop = 2 restarts in rapid succession).
    # Lower for stateful services (database sidecar), higher for batch workers.

    # ── Signal 8: Network Error Rate ────────────────────────────────
    network_error_rate_pct = number
    # Percentage of outbound network packets that are errors/drops.
    # 1.0 = 1% packet error rate. Normal is < 0.01%.
    # Any value above 0.5% is unusual and warrants investigation.
  }))

  default = {
    "payment-service" = {
      team             = "payments"
      slo_target       = 99.9
      health_check_url = "https://payment.company.com/health"

      # Strict thresholds — handles money
      traffic_min_rps        = 10    # expect at least 10 req/min even at 3am
      error_rate_alert       = 0.1   # 0.1% — any error is serious for payments
      latency_p99_ms         = 300   # 300ms SLO
      cpu_saturation_pct     = 70    # alert early — payment needs headroom
      memory_usage_pct       = 75    # strict — payment service has history of leaks
      jvm_heap_pct           = 70    # JVM service
      is_jvm_service         = true
      pod_restart_threshold  = 2     # any restart = alert immediately
      network_error_rate_pct = 0.5
    }

    "order-service" = {
      team             = "orders"
      slo_target       = 99.5
      health_check_url = "https://orders.company.com/health"

      traffic_min_rps        = 5
      error_rate_alert       = 0.5
      latency_p99_ms         = 500
      cpu_saturation_pct     = 80
      memory_usage_pct       = 80
      jvm_heap_pct           = 75
      is_jvm_service         = true
      pod_restart_threshold  = 2
      network_error_rate_pct = 1.0
    }

    "inventory-service" = {
      team             = "inventory"
      slo_target       = 99.0
      health_check_url = "https://inventory.company.com/health"

      # Go service — no JVM heap monitoring
      traffic_min_rps        = 2
      error_rate_alert       = 1.0
      latency_p99_ms         = 1000
      cpu_saturation_pct     = 85
      memory_usage_pct       = 80
      jvm_heap_pct           = 0     # not used (is_jvm_service = false)
      is_jvm_service         = false
      pod_restart_threshold  = 3
      network_error_rate_pct = 1.0
    }

    "analytics-service" = {
      team             = "platform"
      slo_target       = 98.0
      health_check_url = "https://analytics.company.com/health"

      # Batch/analytics service — relaxed thresholds
      traffic_min_rps        = 0     # 0 = disable traffic drop alert (batch has natural quiet periods)
      error_rate_alert       = 5.0   # 5% — batch pipelines have retries, errors expected
      latency_p99_ms         = 10000 # 10s — batch queries are slow by design
      cpu_saturation_pct     = 92    # 92% — expected to spike during batch jobs
      memory_usage_pct       = 85
      jvm_heap_pct           = 80    # Python/Spark service
      is_jvm_service         = false
      pod_restart_threshold  = 5     # batch workers restart more frequently
      network_error_rate_pct = 2.0
    }
  }
}
