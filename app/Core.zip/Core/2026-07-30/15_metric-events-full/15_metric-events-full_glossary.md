# Glossary — 8-Signal Metric Events

Every term used in the metric events deep dive, explained for an SRE beginner.

---

**Four Golden Signals**
Google SRE Book's framework for what to monitor in any production system. Traffic (how much), Errors (how many fail), Latency (how slow), Saturation (how full). If all four are healthy: the system is healthy. If any one degrades: there is or will be a user-visible problem.

**dynatrace_metric_events (Terraform resource)**
Creates a Dynatrace Custom Metric Event — a rule that says "when metric X crosses threshold Y for Z consecutive minutes, create a problem event." Each resource = one alert rule. Created via `for_each` to make one per service.

**builtin: metrics (Dynatrace)**
Dynatrace's built-in metric keys. Prefix `builtin:` means Dynatrace collects and names this metric automatically via OneAgent — no custom code needed. Examples: `builtin:service.requestCount.server`, `builtin:process.cpu.usage`.

**metric_key**
The identifier for a specific metric in Dynatrace. Like a database column name. `builtin:service.errors.server.rate` means: the error rate metric, for services, measured server-side, as a rate (%).

**event_type**
Determines how Dynatrace classifies the problem and which severity level it maps to in alerting profiles. Three types used here: `ERROR_EVENT` (maps to ERROR/AVAILABILITY severity), `PERFORMANCE_EVENT` (maps to SLOWDOWN), `RESOURCE_CONTENTION_EVENT` (maps to RESOURCE_CONTENTION).

**STATIC_THRESHOLD**
The model type for metric events that fire when a metric crosses a fixed number (e.g., CPU > 80%). The alternative is `BASELINE` (anomaly detection — fires when metrics deviate from learned normal). Static threshold = you choose the number; baseline = Dynatrace learns the number.

**alert_condition = "BELOW"**
Fires when the metric value drops BELOW the threshold. Used only for traffic drop (you want to know when traffic falls). All other signals use `"ABOVE"` (fire when the metric exceeds a threshold).

**alert_on_no_data = true**
Fires the alert even when Dynatrace receives no data at all for the metric. Critical for traffic drop: if the service is completely unreachable, Dynatrace gets zero data points — you still want to be alerted.

**violating_samples**
How many consecutive 1-minute data points must exceed the threshold before the alert fires. `violating_samples = 3` means: 3 minutes in a row above threshold. Prevents false positives from brief transient spikes.

**dealerting_samples**
How many consecutive 1-minute data points must be BELOW threshold before the alert closes (resolves). `dealerting_samples = 5` means: must be healthy for 5 consecutive minutes before the problem is considered resolved. Prevents flapping alerts.

**samples**
The total evaluation window in minutes. The system looks at `samples` minutes of data and requires `violating_samples` of them to be above threshold. `samples = 5, violating_samples = 3` means: "3 out of 5 recent minutes above threshold."

**event_entity_dimension_key**
Tells Dynatrace which type of entity the metric is associated with. Different metrics live on different entity types: service metrics use `dt.entity.service`, CPU uses `dt.entity.process_group_instance`, memory uses `dt.entity.cloud_application_instance`, network uses `dt.entity.host`. Using the wrong entity type = alert never fires.

**dt.entity.service**
A Dynatrace entity representing a logical microservice (as discovered and named by OneAgent). Service-level metrics: request count, error rate, response time. Think of it as the application's identity in Dynatrace.

**dt.entity.process_group_instance**
A Dynatrace entity representing a specific running process on a specific host. Process-level metrics: CPU usage, memory RSS, JVM heap. More granular than a service — one service may have 10 process instances across 10 pods.

**dt.entity.cloud_application_instance**
A Dynatrace entity representing a single Kubernetes pod. Container memory utilisation metrics live here. More precise than the host entity for container workloads.

**dt.entity.cloud_application**
A Dynatrace entity representing a Kubernetes Deployment or StatefulSet (the workload, not individual pods). Pod restart metrics are measured at this level — you see total restarts across all replicas of the workload.

**dt.entity.host**
A Dynatrace entity representing a physical or virtual machine (EC2 node). Host-level metrics: network error rate, disk I/O, total CPU, total memory. Network errors are measured here because they're per-NIC, not per-service.

**RSS (Resident Set Size)**
The actual RAM currently in use by a process. Different from "virtual memory" (which includes memory that hasn't been used yet). Kubernetes memory limits are measured against RSS. OOM killer looks at RSS.

**OOM Kill (Out of Memory Kill)**
When the Linux kernel forcibly terminates a process because it exceeded its memory limit (or the node ran out of RAM). The process is killed instantly — no graceful shutdown. In Kubernetes: the container restarts immediately, which shows up as a pod restart event.

**Container Memory Limit**
The maximum RAM a container is allowed to use, set in the Kubernetes pod spec (`resources.limits.memory`). If the container exceeds this: OOM killed. `builtin:kubernetes.container.memoryLimitUtilization` shows current usage as a % of this limit.

**JVM (Java Virtual Machine)**
The runtime environment for Java applications. Manages memory through a garbage collector (GC) rather than manual allocation. Has its own memory model: heap (objects), off-heap (JVM internals), code cache (compiled bytecode).

**JVM Heap**
The area of JVM memory where Java objects are allocated. The garbage collector reclaims unused objects from the heap. Set by `-Xmx` (maximum heap size). If the heap fills up faster than GC can reclaim: `OutOfMemoryError`, then process crash.

**-Xmx (JVM flag)**
Sets the maximum heap size for a JVM process. Example: `-Xmx512m` = max 512MB heap. `builtin:process.memory.jvm.heapUtilization` measures heap used as % of this value.

**GC Pressure (Garbage Collection pressure)**
When the JVM spends an increasing percentage of CPU time running garbage collection instead of application code. At 75% heap: GC runs frequently but application threads still progress. At 90%+: GC may be running continuously (GC thrashing), effectively pausing all application threads.

**GC Thrashing**
Extreme GC pressure where the JVM spends more time collecting garbage than running application code. Application appears frozen or extremely slow. P99 latency spikes to seconds or minutes. Precursor to OOM kill.

**CrashLoopBackOff**
A Kubernetes state where a pod keeps crashing and Kubernetes keeps restarting it. Kubernetes adds increasing delay between restarts (1s, 2s, 4s, 8s... up to 5 minutes). The pod shows as `CrashLoopBackOff` in `kubectl get pods`. Common causes: application startup error, missing config, OOM kill.

**builtin:cloud.kubernetes.workload.restarts**
A Dynatrace metric counting the number of container restarts for a Kubernetes workload (Deployment/StatefulSet). Increments each time a container is restarted. A value > 2 in 5 minutes indicates a crash loop.

**NIC (Network Interface Card)**
The hardware (or virtual hardware) that connects a server to the network. In AWS: each EC2 instance has one or more ENIs (Elastic Network Interfaces) which act as virtual NICs. Network error rate measures errors on these interfaces.

**Packet Drop**
When a network packet is discarded rather than delivered. Caused by: buffer overflow (too much traffic), NIC errors, security group rules (blocked silently), or routing issues. Packet drops cause TCP retransmissions, which appear as latency to the application.

**builtin:host.net.errorRate.total**
A Dynatrace metric measuring the percentage of network packets that are errors or drops across all network interfaces on a host. Normal: < 0.01%. Concerning: > 0.5%. Critical: > 1%.

**CNI (Container Network Interface)**
The plugin that manages networking for Kubernetes pods. In EKS: the vpc-cni plugin assigns real VPC IP addresses to pods. CNI misconfigurations after upgrades can cause packet routing failures that appear as network errors.

**Aggregation = PERCENTILE**
A way to summarise a set of metric values. For response time: instead of averaging all 1000 requests in a minute, percentile picks the value at a specific rank. P99 = the value that 99% of requests are faster than. P50 = median (half are faster, half are slower).

**P99 (99th Percentile)**
The response time value that 99% of requests complete within. If P99 = 500ms: 990 out of 1000 requests took less than 500ms; 10 requests took more. Those 10 slow requests represent your worst-performing users.

**Long Tail**
The small percentage of requests that are much slower than the average. Average latency hides the long tail: average could be 50ms while P99 is 5000ms. The long tail is where user complaints come from.

**Resolution = "1m"**
The granularity of metric data used for evaluation. `1m` = evaluate using 1-minute data points. Dynatrace stores metrics at 1-minute resolution by default (and finer for some metrics). `violating_samples = 3` with `resolution = 1m` means: 3 consecutive minutes.

**Microseconds (μs)**
One millionth of a second. Dynatrace stores response time in microseconds. 500ms = 500,000μs. When setting latency thresholds in Terraform: multiply milliseconds by 1,000 to get the correct unit for the `threshold` field.

**entity_filter**
A Terraform block inside `query_definition` that scopes the metric to specific entities. Without a filter: the metric event applies to ALL services in the tenant. With a filter on `service.name = "payment-service"`: only alerts for that specific service.

**k8s.workload.name**
A Dynatrace dimension/label that holds the Kubernetes Deployment or StatefulSet name. Used as an entity filter for metrics that live on `cloud_application` or `cloud_application_instance` entities. Equivalent to the `app` label in Kubernetes.

**for_each with locals**
A Terraform pattern where you pre-filter a map before passing it to `for_each`. `local.jvm_services` = services where `is_jvm_service = true`. This prevents creating JVM heap alerts for Go/Python/Node services where the metric doesn't exist.

**alert_on_no_data = false**
Do NOT fire an alert when Dynatrace receives no data for this metric. Safe default for most signals — if the service is completely down, the traffic drop alert (with `alert_on_no_data = true`) handles it. Using `false` for other signals prevents duplicate "service is down" alerts.

**Leading Indicator**
A metric that warns you BEFORE the problem causes user impact. CPU saturation and memory usage are leading indicators — they spike before error rate and latency do. Catching a leading indicator gives you time to scale before users are affected.

**Lagging Indicator**
A metric that tells you about a problem AFTER it has already caused user impact. Error rate and latency are lagging indicators — they only rise after the service is already degraded. Important to monitor, but not enough on their own.
