# app-ci.yaml Deep Dive — Glossary

**GitHub Actions**
An automation platform built into GitHub that runs workflows defined in YAML files. Triggers on events (push, PR, schedule). Each workflow runs in an isolated virtual machine (runner). Free for public repos; minutes-based billing for private repos.

**Workflow**
A YAML file in `.github/workflows/` that defines an automated process. Composed of jobs. Triggered by events (`push`, `pull_request`, `schedule`, etc.).

**Job**
A unit of work in a GitHub Actions workflow. Runs on a separate virtual machine. Jobs run in parallel by default. `needs:` creates sequential dependencies.

**Step**
A single command or action within a job. Steps in a job run sequentially on the same machine. If a step fails, subsequent steps are skipped.

**Runner**
The virtual machine that executes a job. `ubuntu-latest` = Ubuntu Linux VM. Each job gets a fresh VM — nothing persists between jobs or runs by default.

**`on: push / pull_request`**
Event triggers for the workflow. `push: branches: [main]` fires when code is merged. `pull_request: branches: [main]` fires when a PR is opened or updated.

**`paths` filter**
Limits the trigger to only fire when specific files change. `paths: ['app/**']` means the workflow only runs when files under `app/` are changed. Prevents unnecessary CI runs for unrelated changes.

**`${{ github.sha }}`**
A GitHub Actions expression returning the full 40-character git commit SHA of the event that triggered the workflow. Used as the Docker image tag to create an immutable, traceable identifier.

**Immutable image tag**
A Docker image tag that never changes once set. The git commit SHA is immutable — `payment-service:a1b2c3d4` always refers to the same exact code. Contrast with `:latest` which changes every push.

**`${{ github.event_name }}`**
GitHub Actions expression returning the event type that triggered the workflow: `push` (merge to branch) or `pull_request` (PR opened/updated). Used to conditionally run steps only on merge.

**`${{ github.run_id }}`**
A unique number assigned to each workflow run. Used in `role-session-name` to make AWS CloudTrail records traceable to specific CI runs.

**OIDC (OpenID Connect)**
An authentication protocol allowing GitHub Actions to prove its identity to AWS without storing credentials. GitHub issues a short-lived signed JWT; AWS validates the signature and issues 1-hour temporary credentials.

**JWT (JSON Web Token)**
A signed, time-limited token that carries claims about the bearer (which repo, branch, workflow). GitHub's OIDC provider issues one per job. AWS uses it to verify the caller's identity.

**STS (Security Token Service)**
AWS's service for issuing temporary credentials. When GitHub presents a valid OIDC JWT, STS validates it and returns short-lived access keys (valid 1 hour). These are used for ECR push.

**`role-to-assume`**
The IAM role ARN that the workflow will assume via STS. The role's trust policy must explicitly allow GitHub's OIDC provider to assume it, restricted to specific repos and branches.

**Trust policy (IAM)**
An IAM role configuration defining WHO can assume the role. For OIDC, it specifies the GitHub OIDC provider as the trusted identity source and conditions like the specific repository and branch.

**`id-token: write` permission**
A required GitHub Actions job permission that allows the job to request an OIDC token from GitHub's identity provider. Without it, the AWS credential step fails immediately.

**`contents: write` permission**
A required GitHub Actions job permission that allows the job to push commits back to the repository (needed for the gitops image tag update step).

**ECR (Elastic Container Registry)**
AWS's managed Docker image registry. Private registry for storing container images. The CI pipeline pushes images here; EKS nodes pull images from here.

**`ecr:GetAuthorizationToken`**
AWS API call that returns a temporary Docker login token for ECR. The `amazon-ecr-login` action calls this automatically using the OIDC credentials.

**Docker Buildx**
An extended Docker build tool (part of BuildKit) that enables multi-architecture builds and advanced caching. Required for `platforms: linux/amd64,linux/arm64` and `cache-from: type=gha`.

**Multi-architecture image (`linux/amd64,linux/arm64`)**
A Docker image containing variants for multiple CPU architectures in a single manifest. Kubernetes automatically selects the correct architecture variant when starting a container. Required for Graviton (ARM64) nodes.

**Graviton**
AWS's ARM-based EC2 processor series (m7g, c7g, r7g instances). 20-30% cheaper than equivalent Intel/AMD instances. Requires `arm64` Docker images.

**`exec format error`**
The error that occurs when you try to run an x86 (amd64) Docker image on an ARM64 (Graviton) node. Fix: build multi-arch images with `platforms: linux/amd64,linux/arm64`.

**Layer caching (Docker)**
Docker's optimisation that reuses unchanged image layers between builds. If `requirements.txt` doesn't change, the `pip install` layer is reused from cache — 60-second step becomes 5-second step.

**`cache-from: type=gha`**
Uses GitHub Actions' built-in cache as a Docker layer cache. Persists Docker build layers between workflow runs. Combined with `cache-to: type=gha,mode=max`, subsequent builds that haven't changed dependencies are significantly faster.

**`build-args`**
Values passed to Docker `ARG` instructions during the build. `BUILD_DATE` and `VCS_REF` are baked into the image as labels via `LABEL` instructions. Useful for traceability — `docker inspect` shows when and from which commit the image was built.

**Trivy**
An open-source container image vulnerability scanner from Aqua Security. Checks OS packages and application dependencies against CVE databases. `exit-code: '1'` makes the pipeline fail when vulnerabilities of the specified severity are found.

**CVE (Common Vulnerability and Exposure)**
A publicly known security vulnerability with a unique identifier (e.g., CVE-2024-12345). Trivy checks images against databases of known CVEs. CRITICAL CVEs have the highest risk score and most potential for exploitation.

**`exit-code: '1'`**
Trivy configuration that makes the GitHub Actions step fail (exit non-zero) when vulnerabilities are found. Without this setting, Trivy reports findings but the pipeline continues — dangerous.

**`sed -i`**
A Unix command that edits a file in-place (`-i` = in-place). `sed -i "s|old|new|"` replaces `old` with `new` throughout the file. Used here to update the Docker image tag in the ArgoCD Application YAML.

**`git diff --staged --quiet`**
Git command that checks if there are staged changes. Returns exit 0 if no changes, exit 1 if changes exist. Used as a guard before `git commit` to prevent the "nothing to commit" error.

**`||` (logical OR in shell)**
Shell operator: if the left command fails (non-zero exit), run the right command. `git diff --staged --quiet || git commit` means: "if there are staged changes, commit them."

**`[skip ci]`**
A commit message convention recognised by GitHub Actions (and most CI systems). When a commit message contains `[skip ci]`, GitHub Actions does not trigger workflows for that commit. Prevents the infinite loop where CI pushes a commit → CI triggers again → CI pushes again.

**ArgoCD polling**
ArgoCD periodically checks the configured Git repository for changes (default: every 3 minutes). When it detects a change to `payment-service.yaml` (the image tag update), it calculates the diff and applies the Helm chart changes to the cluster.

**Rolling update (Kubernetes)**
A deployment strategy that replaces pods one at a time. New pods start, pass the readiness probe, then old pods are terminated. Zero downtime — at no point are fewer than `replicas` pods serving traffic (with `maxUnavailable: 0`).

**`github.event.head_commit.timestamp`**
GitHub Actions expression returning the ISO 8601 timestamp of the commit that triggered the push event. Passed as `BUILD_DATE` build argument — baked into the image label for traceability.

**`github-actions[bot]@users.noreply.github.com`**
The standard email identity for automated GitHub bot commits. Using this identity makes it clear in git history that the commit was made by automation, not a human.

**`git push` after OIDC checkout**
When the repository is checked out with `token: ${{ secrets.GITHUB_TOKEN }}`, git is configured with the correct credentials to push back to the repo. Without specifying `token`, the default checkout cannot push.
