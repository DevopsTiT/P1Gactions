# app-ci.yaml — Complete Line-by-Line Deep Dive

> This file is the application CI/CD pipeline. It runs automatically on every PR and every merge to main. It is the bridge between "developer writes code" and "code runs in production."

---

## The Big Picture: What This File Does

```
On every PR:
  Code → tests → docker build (build only, DO NOT push)
  Purpose: catch broken code before it merges

On every merge to main:
  Code → tests → docker build → ECR push → Trivy scan → gitops update → ArgoCD deploys
  Purpose: safely deliver working code to production
```

---

## Block 1: File Header (Comments)

```yaml
##############################################################################
# On PR:    run tests + docker build (no push)
# On merge: docker build → push to ECR → update image tag → ArgoCD deploys
# OIDC Authentication: no AWS_ACCESS_KEY_ID stored in GitHub Secrets
```

These comments document the two distinct behaviours depending on the event type. The critical note: **no stored AWS keys**. The AWS credentials are obtained at runtime via OIDC — a modern, keyless authentication mechanism.

---

## Block 2: Workflow Name

```yaml
name: App CI/CD
```

This is what appears in the GitHub Actions UI (the "Actions" tab of your repository). When a PR fails, reviewers see "App CI/CD" in the check status. Keep the name short and meaningful.

---

## Block 3: Trigger (`on`)

```yaml
on:
  push:
    branches: [main]
    paths: ['app/**', 'charts/**']
  pull_request:
    branches: [main]
    paths: ['app/**', 'charts/**']
```

**Two triggers:**
- `push: branches: [main]` — fires when a commit is pushed directly to main (after a PR is merged)
- `pull_request: branches: [main]` — fires when a PR is opened or updated targeting main

**`paths` filter — why this matters:**
Without `paths`, this workflow fires on EVERY push to main, even if only a README was changed. With `paths`, it only fires when `app/**` or `charts/**` files change.

```
Developer edits README.md → NO workflow trigger (paths don't match)
Developer edits app/main.py → WORKFLOW TRIGGERS
Developer edits terraform/main.tf → NO trigger (handled by terraform-infra.yaml)
```

This prevents unnecessary CI minutes and avoids false "all tests passed" signals on non-application changes.

---

## Block 4: Environment Variables (`env`)

```yaml
env:
  AWS_REGION: ap-northeast-1
  ECR_REGISTRY: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com
  ECR_REPOSITORY: payment-service
  IMAGE_TAG: ${{ github.sha }}
```

These are set at the workflow level — available to ALL jobs.

**`IMAGE_TAG: ${{ github.sha }}`** — the most important line.

`github.sha` is the full 40-character git commit SHA (e.g., `a1b2c3d4e5f6...`). Every Docker image is tagged with this SHA:
```
123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service:a1b2c3d4e5f6...
```

**Why commit SHA, not `:latest` or semantic version:**

| Tag | Problem |
|---|---|
| `:latest` | Mutable — two different images can have the same tag. `docker pull :latest` today != tomorrow. You can't tell which code is running. |
| `v1.2.3` | Requires manual version bumping. Easy to forget. Two pushes could get the same version number. |
| `github.sha` | Immutable. One commit SHA = one exact piece of code. Always. Forever. Rollback = change the SHA. Audit = check the SHA. |

---

## Block 5: Job 1 — `test`

```yaml
jobs:
  test:
    name: Test
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'
          cache: 'pip'

      - name: Install dependencies
        run: pip install -r app/requirements.txt

      - name: Run tests
        run: pytest app/tests/ -v --tb=short
```

**Why tests are a separate job (not part of `build-push`):**

If tests fail, the `build-push` job never starts (`needs: test` dependency). No image is built. No image is pushed. No deployment happens.

If everything was one job: a test failure after 10 minutes of Docker build time means wasted CI minutes.

**`cache: 'pip'`:**
Caches pip's download cache between runs. If `requirements.txt` hasn't changed, pip packages are restored from cache in ~5 seconds instead of downloading for ~60 seconds.

**`pytest app/tests/ -v --tb=short`:**
- `-v` — verbose: shows each test's pass/fail individually
- `--tb=short` — short traceback on failure: shows the failing assertion without full stack trace noise

---

## Block 6: Job 2 — `build-push` Setup

```yaml
  build-push:
    name: Build and Push
    runs-on: ubuntu-latest
    needs: test
    permissions:
      id-token: write
      contents: write
```

**`needs: test`:**
This job ONLY runs after the `test` job succeeds. If tests fail, `build-push` is skipped. This creates a dependency chain:

```
test job ──(success)──► build-push job
test job ──(failure)──► build-push job CANCELLED
```

**`permissions`** — two specific permissions required:

`id-token: write` — enables this job to request an OIDC token from GitHub's identity provider. Without this, the AWS credential step fails with:

```
Error: No id-token permission is set on the workflow.
Please add permissions: id-token: write to the workflow or job.
```

`contents: write` — enables the job to push commits back to the repository (the gitops image tag update step at the end). Without this, `git push` fails with a 403 permission denied error.

---

## Block 7: `actions/checkout@v4`

```yaml
      - uses: actions/checkout@v4
        with:
          token: ${{ secrets.GITHUB_TOKEN }}
```

Checks out the repository code onto the runner. The `token: ${{ secrets.GITHUB_TOKEN }}` is automatically provided by GitHub — no manual setup needed.

**Why specify `token` here:**
The default checkout creates a "detached HEAD" state that doesn't allow `git push`. By explicitly passing `GITHUB_TOKEN`, the checkout configures git credentials so the later `git push` (for the image tag update) works correctly.

---

## Block 8: OIDC Authentication — The Key Security Mechanism

```yaml
      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/github-actions-ecr-push
          aws-region: ${{ env.AWS_REGION }}
          role-session-name: github-actions-${{ github.run_id }}
```

**What OIDC is and why it matters:**

Traditional approach (wrong):
```yaml
env:
  AWS_ACCESS_KEY_ID: ${{ secrets.AWS_ACCESS_KEY_ID }}      # stored permanently in GitHub
  AWS_SECRET_ACCESS_KEY: ${{ secrets.AWS_SECRET_ACCESS_KEY }} # never expires
```
If GitHub is breached, or if a repo admin leaks the secret, the attacker has permanent AWS access.

**OIDC approach (correct):**
```
1. GitHub Actions job starts
2. GitHub's OIDC provider issues a signed JWT (JSON Web Token)
   JWT contains: which repo, which branch, which workflow, which actor
3. `configure-aws-credentials` presents the JWT to AWS STS
4. AWS STS validates the JWT signature using GitHub's public key
5. AWS STS checks the IAM role's trust policy:
   "Does this token claim to be from repo:company/app-repo on branch:main?"
6. If trust policy matches: STS returns temporary credentials (1-hour validity)
7. Credentials are used for ECR push
8. After 1 hour: credentials expire automatically
```

**No credentials are stored anywhere.** If GitHub is breached: the attacker gets a JWT that's valid for this one job run only, not permanent AWS access.

**`role-session-name: github-actions-${{ github.run_id }}`:**
In CloudTrail (AWS audit logs), you can see exactly which GitHub Actions run made each API call. `github.run_id` is a unique number per workflow run. Without this: all runs show as `github-actions` in audit logs — impossible to trace which specific run created/deleted something.

---

## Block 9: ECR Login

```yaml
      - name: Login to Amazon ECR
        uses: aws-actions/amazon-ecr-login@v2
```

Uses the credentials obtained in Block 8 to authenticate Docker with ECR. After this, Docker commands can push to ECR. This action:
1. Calls `ecr:GetAuthorizationToken` using the OIDC credentials
2. Runs `docker login` with the returned base64 token
3. The token is valid for 12 hours

---

## Block 10: Docker Buildx Setup

```yaml
      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3
```

Installs Docker BuildKit's extended builder. Required for:
- **Multi-architecture builds** (`linux/amd64,linux/arm64`)
- **Layer caching via GitHub Actions cache** (`cache-from: type=gha`)
- **Optimised layer ordering and parallel build stages**

Without Buildx: `platforms: linux/amd64,linux/arm64` would fail.

---

## Block 11: Build and Push — The Core Step

```yaml
      - name: Build and push Docker image
        uses: docker/build-push-action@v5
        with:
          context: app/
          push: ${{ github.event_name == 'push' }}
          platforms: linux/amd64,linux/arm64
          tags: |
            ${{ env.ECR_REGISTRY }}/${{ env.ECR_REPOSITORY }}:${{ env.IMAGE_TAG }}
            ${{ env.ECR_REGISTRY }}/${{ env.ECR_REPOSITORY }}:latest
          cache-from: type=gha
          cache-to: type=gha,mode=max
          build-args: |
            BUILD_DATE=${{ github.event.head_commit.timestamp }}
            VCS_REF=${{ github.sha }}
```

### `context: app/`
Docker's build context — the directory sent to the Docker daemon. Only `app/` is included. If `context: .` (root), the entire repository is sent — much slower and the Dockerfile might pick up files from `terraform/` that don't belong in the image.

### `push: ${{ github.event_name == 'push' }}`
This is a Go template expression evaluated at runtime:
- PR event (`pull_request`): evaluates to `false` → image is built but NOT pushed to ECR
- Merge to main (`push`): evaluates to `true` → image is pushed to ECR

This is the key: the same steps run for both PR and merge. On PRs we validate the build works. On merge we actually publish.

### `platforms: linux/amd64,linux/arm64`
Builds the image for BOTH x86 (Intel/AMD) and ARM64 (Graviton). The Karpenter NodePool uses ARM64 (m7g, c7g — Graviton3) for cost savings. Without `arm64` in the image manifest, pods cannot schedule on Graviton nodes:
```
Error: exec /app/python: exec format error  ← wrong architecture
```

### `tags:`
Two tags are applied:
1. `payment-service:a1b2c3d4...` — immutable, tied to exact commit
2. `payment-service:latest` — mutable, always points to most recent build

The `:latest` tag is useful for development (`docker pull payment-service:latest` gives the current version). Production deployments use the SHA tag.

### `cache-from: type=gha` / `cache-to: type=gha,mode=max`
Uses GitHub Actions' built-in cache as a Docker layer cache.

How it works:
- First build: all layers are fresh, stored in GHA cache
- Second build (if requirements.txt unchanged): `pip install` layer is CACHED — skipped completely
- Result: build time drops from ~3 minutes to ~30 seconds for unchanged dependencies

`mode=max` stores ALL intermediate layers, not just the final image. Maximises cache hits.

### `build-args:`
```
BUILD_DATE=2026-07-30T10:15:00Z
VCS_REF=a1b2c3d4e5f6...
```
These become `ARG` values in the Dockerfile:
```dockerfile
ARG BUILD_DATE
ARG VCS_REF
LABEL build_date="$BUILD_DATE" vcs_ref="$VCS_REF"
```
Baked into the image as labels. `docker inspect` on any production image shows when it was built and which commit:
```bash
docker inspect payment-service:a1b2c3d4 | jq '.[0].Config.Labels'
# {"build_date": "2026-07-30T10:15:00Z", "vcs_ref": "a1b2c3d4..."}
```

---

## Block 12: Trivy Vulnerability Scan

```yaml
      - name: Run Trivy vulnerability scanner
        if: github.event_name == 'push'
        uses: aquasecurity/trivy-action@master
        with:
          image-ref: ${{ env.ECR_REGISTRY }}/${{ env.ECR_REPOSITORY }}:${{ env.IMAGE_TAG }}
          severity: 'CRITICAL'
          exit-code: '1'
```

**`if: github.event_name == 'push'`:**
Only runs on merge to main (not on PRs). Why: Trivy scans the IMAGE IN ECR — on PRs, no image was pushed to ECR, so there's nothing to scan.

**`image-ref`:** Points to the image just pushed. Trivy pulls it from ECR and scans its layers.

**`severity: 'CRITICAL'`:**
Only fail the build for CRITICAL CVEs. HIGH/MEDIUM CVEs are reported but don't block deployment. Why: HIGH/MEDIUM vulnerabilities often have no fix available yet. Blocking on them creates constant noise with no actionable path.

**`exit-code: '1'`:**
The most important setting. Without this, Trivy reports findings but returns exit code 0 — the step passes even with CRITICAL vulnerabilities. `exit-code: '1'` makes the step fail when CRITICAL CVEs are found.

**The deployment gate:**
The image is already in ECR when Trivy runs. But the image tag UPDATE (Block 13) runs AFTER Trivy. A CRITICAL CVE:
```
Build → Push to ECR → Trivy finds CRITICAL → Step exits 1 → Job fails → Image tag NOT updated → ArgoCD never deploys
```
The vulnerable image exists in ECR but is never deployed.

---

## Block 13: Update Image Tag in GitOps — The Deployment Trigger

```yaml
      - name: Update image tag in gitops
        if: github.event_name == 'push'
        run: |
          sed -i "s|tag: \".*\"|tag: \"${{ env.IMAGE_TAG }}\"|" \
            gitops/app/payment-service/payment-service.yaml

          git config user.email "github-actions[bot]@users.noreply.github.com"
          git config user.name "github-actions[bot]"
          git add gitops/app/payment-service/payment-service.yaml
          git diff --staged --quiet || \
            git commit -m "chore(deploy): update payment-service image to ${{ env.IMAGE_TAG }} [skip ci]"
          git push
```

This step is the bridge between the Docker build world and the GitOps world.

**What it does step by step:**

1. **`sed -i "s|tag: \".*\"|tag: \"...\"|"`**
   Opens `payment-service.yaml` and replaces whatever is in `tag: "..."` with the new SHA.
   Before: `tag: "old-sha-abc123"`
   After: `tag: "new-sha-def456"`

2. **`git config user.email/name`**
   Sets git author identity for the commit. The email `github-actions[bot]@...` is the standard identity for bot commits in GitHub.

3. **`git add`**
   Stages the modified file.

4. **`git diff --staged --quiet || git commit`**
   - `git diff --staged --quiet`: checks if there are staged changes
   - Returns exit 0 (no changes) or exit 1 (changes exist)
   - `||` means: if the left command FAILS (exit 1 = changes exist), run the right command
   - So: only commit if there are actual changes
   - Why this guard: if the SHA didn't change (rerun of same commit), `git commit` would fail with "nothing to commit" — the guard prevents that error

5. **`git commit -m "... [skip ci]"`**
   The `[skip ci]` tag tells GitHub Actions: do NOT trigger a new CI run for this commit. Without it:
   ```
   Push to main → CI runs → CI pushes commit → CI runs again → CI pushes commit → infinite loop
   ```

6. **`git push`**
   Pushes the updated file to the repository's main branch.

**What happens next (automatic):**
ArgoCD polls the gitops repository every 3 minutes (or immediately via webhook). It detects the image tag change in `payment-service.yaml`, calculates the diff, and applies the Helm chart with the new image tag. Kubernetes performs a rolling update.

---

## Block 14: Notify Deployment

```yaml
      - name: Notify deployment
        if: github.event_name == 'push'
        run: |
          echo "Image pushed: ${{ env.ECR_REGISTRY }}/${{ env.ECR_REPOSITORY }}:${{ env.IMAGE_TAG }}"
          echo "ArgoCD will detect the gitops change and deploy automatically"
```

Simple echo statements that appear in the GitHub Actions logs. In a production setup, this step would send a Slack message, create a PagerDuty event timeline entry, or update a deployment tracking system.

---

## Complete Flow Visualisation

```
Developer merges PR to main
         │
         ▼
GitHub Actions triggers (push to main, app/** changed)
         │
         ├─── Job: test ──────────────────────────────────────────────────────
         │      pytest app/tests/ -v                                          │
         │      Pass? ─(yes)─► continue                                       │
         │      Fail? ─(no)──► STOP — no image built or pushed               │
         │                                                                     │
         └─── Job: build-push (after test passes) ──────────────────────────-┘
                │
                ├── OIDC: get 1-hour AWS credentials (no stored keys)
                │
                ├── ECR login (using OIDC credentials)
                │
                ├── Docker Buildx: build linux/amd64 + linux/arm64
                │       Context: app/
                │       Tag: payment-service:a1b2c3d4
                │       Tag: payment-service:latest
                │       GHA layer cache speeds up unchanged layers
                │
                ├── Push to ECR (because: push event, not PR)
                │
                ├── Trivy scan (CRITICAL CVEs → fail here, never deploy)
                │
                ├── sed: update tag: "a1b2c3d4" in payment-service.yaml
                │
                └── git commit [skip ci] + git push
                           │
                           ▼
              ArgoCD detects gitops change (3-min poll)
                           │
                           ▼
              kubectl apply: rolling update
                           │
                           ▼
              New pods start → readiness probe passes → old pods terminate
                           │
                           ▼
              Dynatrace OneAgent auto-discovers new version (5 min)
```

---

## Common Problems and Fixes

| Problem | Error message | Fix |
|---|---|---|
| Missing `id-token: write` | `Error: No id-token permission` | Add `permissions: id-token: write` to the job |
| Missing `contents: write` | `remote: Permission to repo.git denied` | Add `permissions: contents: write` to the job |
| Trivy not blocking bad image | Build passes despite CVEs | Check `exit-code: '1'` is set |
| Infinite CI loop | CI runs trigger each other | Ensure `[skip ci]` is in the gitops commit message |
| Wrong architecture on Graviton | `exec format error` on pods | Ensure `platforms: linux/amd64,linux/arm64` is set |
| Image tag not changing | ArgoCD never redeploys | Verify `sed` pattern matches the YAML key exactly |
| `git commit` fails on no-change rerun | `nothing to commit, working tree clean` | The `git diff --staged --quiet \|\|` guard prevents this |
