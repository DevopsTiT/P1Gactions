# EKS GitOps Platform Deep Dive

```
what is eks-gitops-platform-main?
  toy demo? → no — full reference platform (learn + harden before prod)
  step 1 → Terraform: VPC + EKS + IRSA + S3 + secrets
  step 2 → bootstrap ArgoCD + AppProjects + root-app
  step 3 → GitOps sync waves install platform stack
  step 4 → SimpleTimeService app (metrics/logs/traces)
  fail? → use docs/runbooks/* ; tear down with cleanup.sh to save $
```

## Short takeaway

| Key point | Detail |
|-----------|--------|
| Path | `/Users/k/Codes/GithubProjects/Terraform/eks-gitops-platform-main` |
| What it is | End-to-end **EKS + Terraform + ArgoCD GitOps** reference platform |
| Sample app | **SimpleTimeService** — Python FastAPI: timestamp + IP JSON |
| Split of duties | Terraform = AWS foundation; ArgoCD = everything in-cluster from `gitops/` |
| Honest scope | Working demo with documented shortcuts — not drop-in bank-grade prod |

## Summary

This repo shows how a real-ish platform is built: provision AWS with Terraform, then let ArgoCD (App of Apps) install networking, secrets, observability, autoscaling, backup, policy, and the demo app from Git. Learn it layer by layer in the order below.

## Main content — step-by-step deep dive

### Step 0 — Mental model (whole system)

```
You / CI
  → Terraform apply
       → VPC, EKS, IRSA roles, S3 (metrics/logs/traces/backups), Secrets Manager
  → bootstrap.sh
       → Helm install ArgoCD once
       → apply AppProjects + root-app
  → root-app watches gitops/ (recurse)
       → ApplicationSets create child apps by sync wave
  → Platform + SimpleTimeService running on EKS
```

| Layer | Owns | Folder |
|-------|------|--------|
| Infra | Cloud foundation | `terraform/` |
| Desired K8s state | Controllers + apps | `gitops/` |
| Helm charts | Reusable K8s packages | `charts/` |
| App source | Container image | `app/` |
| Raw K8s (optional) | Non-Helm quick path | `k8s/` |
| Docs / runbooks | Why + how to fix | `docs/` |
| CI | Lint/plan/image | `.github/` |

---

### Step 1 — Repo map (every top folder)

| Path | What it is |
|------|------------|
| `README.md` | Master overview, quick start, validation checklist |
| `terraform/` | VPC, EKS, Karpenter IAM, IRSA, buckets, Secrets Manager |
| `terraform/app-bootstrap/` | **Fast path**: infra + app Helm in one apply (no ArgoCD) |
| `terraform/scripts/` | `bootstrap.sh`, `upgrade.sh`, `cleanup.sh` |
| `gitops/` | All ArgoCD Applications / ApplicationSets |
| `charts/` | `simple-time-service`, `namespaces`, `raw` |
| `app/` | FastAPI source + Dockerfile |
| `k8s/microservice.yaml` | Plain manifest alternative to Helm |
| `docs/` | Design, security, cost, 13 runbooks, screenshots |
| `scripts/` | Load test (`load_test.py`, `k6-staged.js`) |
| `.github/workflows/` | Terraform CI, GitOps CI, app image, PR checks |
| `compose.yaml` | Local Docker Compose helper |

---

### Step 2 — Two ways to run (pick one path)

| Path | When to use | How |
|------|-------------|-----|
| **Bootstrap (fast)** | Learn app on EKS quickly | `cd terraform/app-bootstrap && terraform apply` → NLB URL |
| **GitOps (full platform)** | Learn real platform pattern | `bash terraform/scripts/bootstrap.sh` → ArgoCD owns the rest |

**Before GitOps path:** ACM cert for `*.platform.<your-domain>` must be **ISSUED** (ALB HTTPS). Region in docs examples: **ap-south-1**.

---

### Step 3 — Terraform deep dive (`terraform/`)

#### 3.1 Entry wiring

| File | Role |
|------|------|
| `main.tf` | Calls `modules/vpc` then `modules/eks` |
| `providers.tf` / `versions.tf` | AWS provider + Terraform version pins |
| `backend.tf` | Remote S3 state (`use_lockfile = true`) |
| `variables.tf` / `terraform.tfvars` | Cluster name, CIDRs, sizes, domain knobs |
| `outputs.tf` | Values bootstrap/ArgoCD need later |

#### 3.2 What Terraform creates

| Resource | Detail (from project docs) |
|----------|----------------------------|
| VPC | `10.0.0.0/24`, 2 AZs, public + private subnets, 1 NAT |
| EKS | K8s ~1.34, public API (tighten CIDRs for real prod) |
| Core nodes | Managed node group, label/taint `app=core` |
| Add-ons | coredns, kube-proxy, vpc-cni, pod-identity-agent |
| Karpenter AWS side | Controller IAM, node role, instance profile, SQS interruption |
| IRSA / Pod Identity | Roles for LBC, ExternalDNS, ESO, EBS CSI, CA, Thanos, Loki, Velero, Tempo, … |
| S3 buckets | Thanos metrics, Loki logs, Tempo traces, Velero backups |
| Secrets Manager | `argocd-admin`, `grafana-admin`, `alertmanager-webhook` |

Companion `.tf` files (one concern each): `karpenter.tf`, `*-irsa.tf`, `loki.tf`, `thanos.tf`, `tempo.tf`, `velero.tf`, `secrets-manager.tf`, …

#### 3.3 Modules

| Module | Job |
|--------|-----|
| `modules/vpc` | Network + Karpenter discovery tags on subnets |
| `modules/eks` | Cluster + node group + add-ons + tags for autoscaler |

#### 3.4 Scripts

| Script | Does |
|--------|------|
| `bootstrap.sh` | TF apply → install ArgoCD Helm → apply projects → apply root-app |
| `upgrade.sh` | TF apply only; refresh ArgoCD cluster secret; force ExternalSecret re-sync |
| `cleanup.sh` | Tear down to stop burn (~$310–330/mo idle if left up) |

**SRE rule:** Terraform stops at cloud + IAM + buckets. Controllers live in GitOps.

---

### Step 4 — ArgoCD bootstrap and App of Apps

#### 4.1 Root application

File: `gitops/bootstrap/root-app.yaml`

| Field | Value / meaning |
|-------|-----------------|
| `path: gitops` + `recurse: true` | Discovers all Application / ApplicationSet YAMLs under `gitops/` |
| `project: bootstrap` | Tiny AppProject — avoids circular dependency with `platform` |
| Destination | In-cluster EKS API (`kubernetes.default.svc`) |
| Sync | automated + prune + selfHeal + ServerSideApply |

#### 4.2 AppProjects (least privilege)

| Project | Allowed to touch |
|---------|------------------|
| `bootstrap` | root-app only (`argocd` NS) |
| `namespaces` | Create Namespaces (+ quotas) |
| `platform` | Infra tools NS + cluster RBAC/CRDs |
| `observability` | monitoring / logging / tracing |
| `security` | Kyverno + Policy Reporter |
| `workloads` | `simple-time-service` only |

#### 4.3 Why App-of-Apps (not ApplicationSet-only root)

Design decision #1: root `Application` is a stable anchor you `kubectl apply` once. ApplicationSets underneath do templating. An ApplicationSet-only root needs generators healthy first → chicken-and-egg.

---

### Step 5 — Sync waves (install order)

ArgoCD waits for each wave to be healthy before the next.

| Wave | Components |
|------|------------|
| -1 | Namespaces + ResourceQuotas |
| 0 | Prometheus Operator CRDs |
| 1 | ESO, EBS CSI, Reloader, Cluster Autoscaler |
| 2 | AWS Load Balancer Controller, ExternalDNS |
| 3 | Karpenter, Velero, Kyverno |
| 4 | ClusterSecretStore, Karpenter NodePools |
| 5 | ExternalSecrets, Velero schedule, Kyverno policies |
| 6 | ArgoCD Ingress, Loki, Tempo, OTel gateway, Policy Reporter |
| 7 | Prometheus stack, OTel agent |
| 8 | SimpleTimeService, Fluent Bit, Grafana datasources/dashboard |
| 9 | Prometheus Adapter, AlertmanagerConfig |
| 10 | PrometheusRules, Thanos |

**Why waves matter:** CRDs before operators; LBC before Ingresses; secrets before apps that need passwords; Prometheus before rules/Thanos that depend on it.

---

### Step 6 — Platform capabilities (by GitOps folder)

#### 6.1 Networking (`gitops/networking/`)

| Component | Job |
|-----------|-----|
| AWS Load Balancer Controller | Creates ALB from Ingress |
| ExternalDNS | Writes Route53 records from annotations |

Public HTTPS hosts (typical): ArgoCD, Grafana, SimpleTimeService. Prometheus/Alertmanager: **port-forward only**.

#### 6.2 Storage (`gitops/storage/`)

| Component | Job |
|-----------|-----|
| EBS CSI Driver | Dynamic EBS volumes |
| Default StorageClass | `gp3` for Prometheus/Thanos PVCs |

#### 6.3 Secrets (`gitops/secrets/`)

| Component | Job |
|-----------|-----|
| External Secrets Operator | AWS Secrets Manager → K8s Secrets |
| ClusterSecretStore | Cluster-wide store definition |
| Reloader | Restart pods when Secret/ConfigMap changes |

#### 6.4 Autoscaling (`gitops/auto-scaling/`)

| Component | Job |
|-----------|-----|
| Cluster Autoscaler | Scales **core** managed node group |
| Karpenter | Provisions **workload** nodes (`t3a.medium` / `c6a.large`) |
| metrics-server | CPU/mem metrics for HPA |
| HPA on app | 2–10 replicas @ ~70% CPU (enabled in GitOps values) |

Design decision #2: **both** CA + Karpenter — CA for core ASG; Karpenter for flexible app nodes (separate labels/taints).

#### 6.5 Monitoring (`gitops/monitoring/` + `alerts/`)

| Piece | Job |
|-------|-----|
| Prometheus CRDs then kube-prometheus-stack | Metrics + Grafana + Alertmanager |
| Thanos | Long-term metrics in S3 |
| Prometheus Adapter | Custom metrics API → richer HPA |
| PrometheusRules + Slack | Alerts for SimpleTimeService |
| Dashboard ConfigMap | App dashboard in Grafana |

Design #3: self-managed Prometheus+Thanos (not AMP) for portability + S3 cost model in this demo.

#### 6.6 Logs (`gitops/logs/`)

| Piece | Job |
|-------|-----|
| Fluent Bit DaemonSet | Ship container logs |
| Loki (SingleBinary) | Store/query logs (S3 backend) |
| Grafana Loki datasource | Explore logs in UI |

Design #4: SingleBinary OK for demo; production → SimpleScalable/Distributed.

#### 6.7 Tracing (`gitops/tracing/`)

| Piece | Job |
|-------|-----|
| OTel agent (DaemonSet) | Receive spans from local pods |
| OTel gateway (Deployment) | Batch → Tempo |
| Tempo (S3) | Trace storage |
| Grafana Tempo datasource | Trace ↔ log correlation via `trace_id` |

App emits OTLP + JSON logs with `trace_id` / `span_id`.

#### 6.8 Backup (`gitops/backup/`)

| Piece | Job |
|-------|-----|
| Velero | Backup K8s resources + EBS snapshots to S3 |
| Schedule | Daily ~02:00 UTC, 30-day retention (as documented) |

#### 6.9 Security (`gitops/security/`)

| Piece | Job |
|-------|-----|
| Kyverno | Admission policies |
| Policies (Audit mode) | Limits, no privileged, no `:latest`, non-root |
| Policy Reporter | UI for PolicyReports |

Design #5: **Audit first**, Enforce later after cleanup.

---

### Step 7 — Sample application

| Name mapping | Same thing |
|--------------|------------|
| SimpleTimeService | Product name |
| `app/` | Source |
| `charts/simple-time-service` | Helm chart |
| `gitops/app/.../simple-time-service.yaml` | ArgoCD deploy |
| `k8s/microservice.yaml` | Raw YAML option |

**What the app does:** FastAPI service returning JSON with timestamp + client IP; Prometheus metrics; OpenTelemetry traces; structured JSON logs.

Chart extras (when enabled): Deployment, Service, Ingress, HPA, PDB, ServiceMonitor, NetworkPolicy, ServiceAccount.

Nodes: app scheduled on **workload** Karpenter nodes (`app=workload`), not core system nodes.

---

### Step 8 — Charts helpers

| Chart | Purpose |
|-------|---------|
| `charts/namespaces` | Create NS + ResourceQuota from values list |
| `charts/simple-time-service` | Full app chart |
| `charts/raw` | Deploy arbitrary YAML via ApplicationSet (policies, etc.) |

---

### Step 9 — CI / governance (`.github/`)

| Workflow / doc | Role |
|----------------|------|
| `terraform-ci.yaml` | TF fmt/validate/plan style checks |
| `gitops-ci.yaml` | Manifest/YAML checks |
| `app-image.yaml` | Build/push app image |
| `pr-title-check`, `codeowners-check`, `actions-check` | PR hygiene |
| `CI.md`, `branch-protection.md`, `CODEOWNERS` | How merges are gated |

Also: Checkov / TFLint / yamllint / Trivy themes in the security story.

---

### Step 10 — Docs and runbooks (on-call gold)

| Doc | Use when |
|-----|----------|
| `docs/design-decisions.md` | Why CA+Karpenter, why Thanos, why Audit Kyverno, … |
| `docs/security.md` | Controls inventory + harden roadmap |
| `docs/cost.md` | ~$310–330/mo idle; teardown tips |
| `docs/runbooks/*.md` | ArgoCD OutOfSync, ALB 503, Loki empty, Karpenter stuck, Velero restore, … |

---

### Step 11 — Validation order (after bootstrap)

| # | Check |
|---|--------|
| 1 | Nodes Ready |
| 2 | `root-app` Synced/Healthy |
| 3 | curl service HTTPS JSON |
| 4 | Prometheus target UP |
| 5 | Grafana dashboard has data |
| 6 | HPA moves under `scripts/load_test.py` |
| 7 | Slack test alert |
| 8–9 | Loki labels + logs with trace ids |
| 9a–9b | OTel pods + Tempo traces |
| 10–14 | Thanos, PVs, Velero, Kyverno, Policy Reporter |

---

### Step 12 — How this maps to your learning path

| You already studied | Appears here as |
|---------------------|-----------------|
| Terraform 15-min video | `terraform/` init/plan/apply + remote state |
| ArgoCD beginner course | root-app, sync, prune, selfHeal, AppProjects |
| Dynatrace TF separate | Here observability is Prometheus/Loki/Tempo — same *idea* (sibling concern to EKS TF) |
| AXA first week | This repo is a **practice platform** for platform engineering JD skills |

**Do not** `terraform apply` this against a company prod account without explicit approval — cost and blast radius are real.

## Data flow map

```
GitHub repo (desired state)
  ├─ terraform/ ──apply──► AWS VPC + EKS + IRSA + S3 + Secrets Manager
  └─ gitops/ ←── ArgoCD root-app recurse ──► child ApplicationSets
                                              │
                    ┌─────────────────────────┼─────────────────────────┐
                    ▼                         ▼                         ▼
              platform tools            observability              workloads
           (LBC, ESO, Karpenter…)   (Prom/Grafana/Loki/Tempo)   (SimpleTimeService)
                    │                         ▲                         │
                    └──────── IRSA / S3 / SM ─┴──── metrics/logs/traces ┘

User → ALB → Ingress → Service → Pods (workload nodes)
On-call → Grafana / runbooks / ArgoCD UI
```

## Related files

| File | Role |
|------|------|
| `1-eks-gitops-platform-deep-dive.md` | This deep dive |
| `1.sh` | Optional explore commands for you |
| Source | `/Users/k/Codes/GithubProjects/Terraform/eks-gitops-platform-main` |

## Commands

See [1.sh](1.sh). Prefer read-only exploration first; apply only in an account you own and can afford.
