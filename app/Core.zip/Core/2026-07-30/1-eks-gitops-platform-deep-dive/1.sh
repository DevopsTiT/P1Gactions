ls "/Users/k/Codes/GithubProjects/Terraform/eks-gitops-platform-main"
ls "/Users/k/Codes/GithubProjects/Terraform/eks-gitops-platform-main/terraform"
ls "/Users/k/Codes/GithubProjects/Terraform/eks-gitops-platform-main/gitops"
# Read-only explore:
# sed -n '1,80p' "/Users/k/Codes/GithubProjects/Terraform/eks-gitops-platform-main/README.md"
# Only in YOUR sandbox AWS account after ACM + tfvars are ready:
# export TF_VAR_alertmanager_slack_webhook_url="https://hooks.slack.com/..."
# bash "/Users/k/Codes/GithubProjects/Terraform/eks-gitops-platform-main/terraform/scripts/bootstrap.sh"
# kubectl get applications -n argocd
# kubectl get nodes -o wide
# Tear down when done to stop cost:
# bash "/Users/k/Codes/GithubProjects/Terraform/eks-gitops-platform-main/terraform/scripts/cleanup.sh"
