# Glossary — Java Project File Explainer

Every term in the file explanations, defined for an SRE beginner.

---

**Spring Boot**
A Java framework that creates a production-ready application with minimal configuration. Auto-wires: web server (Tomcat), database access (JPA), health endpoints (Actuator), metrics. You write business logic; Spring wires everything together automatically.

**@SpringBootApplication**
A single annotation that combines @Configuration + @EnableAutoConfiguration + @ComponentScan. Put on the main class. It tells Spring: "scan the classpath, auto-configure everything you find, and wire all the beans."

**SpringApplication.run()**
The line that starts everything. Initialises the Spring container, wires dependencies, starts Tomcat on port 8080, registers Actuator endpoints. Returns when the app is fully ready to serve requests.

**@RestController**
A Spring annotation that marks a class as a REST API controller. All return values are automatically serialised to JSON and written to the HTTP response body. Equivalent to @Controller + @ResponseBody combined.

**@RequestMapping**
Maps a URL path prefix to a controller class. All methods inside the class inherit the prefix. `@RequestMapping("/api/v1/payments")` means every method in that class handles paths starting with /api/v1/payments.

**@GetMapping / @PostMapping**
Shortcuts for @RequestMapping with a specific HTTP method. `@GetMapping("/{id}")` handles `GET /api/v1/payments/{id}`. `@PostMapping` handles `POST /api/v1/payments`. Cleaner than writing `@RequestMapping(method = RequestMethod.GET)`.

**@Validated**
Applied to a controller method parameter. Triggers Bean Validation constraints on the annotated object before the method runs. If validation fails: Spring returns HTTP 400 automatically. The method is never called.

**@RequestBody**
Tells Spring to read the HTTP request body (JSON) and deserialise it into the annotated Java object. Jackson handles the JSON parsing. If the JSON is malformed: Spring returns HTTP 400.

**Bean Validation (@NotNull, @NotBlank, @Min, @Size)**
Jakarta EE standard annotations for declaring data constraints. @NotNull: field cannot be null. @NotBlank: string cannot be null, empty, or whitespace. @Min(1): number must be >= 1. @Size(min=3,max=3): string length must be exactly 3. Applied to model classes; enforced by @Validated.

**Java record**
A Java 16+ shorthand for immutable value objects. `public record Payment(String id, long amount)` auto-generates: constructor, getters, equals(), hashCode(), toString(). Immutable by design — no setters. Jackson serialises records to JSON automatically.

**HealthIndicator (Spring Actuator)**
An interface you implement to add custom health checks to the Actuator `/health` endpoint. The `ReadinessIndicator` class runs `SELECT 1` against the database. Returns Health.up() or Health.down(). Spring aggregates all HealthIndicators into a single health response.

**Spring Actuator**
A Spring Boot module that exposes operational endpoints. Key endpoints: `/actuator/health/liveness` (is the JVM alive?), `/actuator/health/readiness` (is the app ready for traffic?), `/actuator/metrics` (JVM heap, GC, request counts), `/actuator/prometheus` (Prometheus-format metrics). Used by Kubernetes probes and Dynatrace.

**Liveness vs Readiness (Spring Actuator)**
`/actuator/health/liveness`: Is the Spring ApplicationContext running? Returns UP unless the JVM is deadlocked. Kubernetes: restart if this fails. `/actuator/health/readiness`: Is the app ready for traffic? Checks dependencies like the database. Kubernetes: stop sending traffic if this fails (no restart).

**Micrometer**
A Java metrics facade library. Collects: JVM heap usage, GC pause times, HTTP request latency, thread pool usage. Exports them in Prometheus format at `/actuator/prometheus`. Dynatrace scrapes this endpoint or reads metrics via OneAgent.

**OpenTelemetry (OTLP)**
A vendor-neutral standard for distributed tracing and metrics. Spring Boot sends trace spans (request paths across services) via OTLP protocol to Dynatrace ActiveGate. Shows: `HTTP GET /api/v1/payments/123 → Hibernate SELECT → DB 5ms`.

**Distributed trace**
A record of a request's journey through multiple services. `GET /api/v1/payments/123` → payment-service → database. Each step has a span (start time, duration, status). Dynatrace correlates all spans into a trace using a trace ID propagated in HTTP headers.

**HikariCP**
A high-performance JDBC connection pool. Maintains a fixed number of open database connections. Threads borrow a connection, use it, return it. Prevents: creating/closing a new DB connection on every request (expensive). The most widely used connection pool in Java.

**maximum-pool-size**
Maximum number of simultaneous database connections HikariCP maintains. Each pod uses up to this many. Total DB connections = pods × pool-size. Must be calibrated against the database's connection limit (e.g., RDS has a max_connections setting).

**connection-timeout (HikariCP)**
How long to wait for an available connection from the pool when all connections are busy. After this timeout: throw exception → request fails. Prevents: threads waiting forever, thread pool exhaustion, cascading failures.

**max-lifetime (HikariCP)**
How long a database connection lives before HikariCP closes and recreates it. RDS has server-side connection timeouts (~30 min). max-lifetime keeps the pool fresh. Without it: "stale connection" errors when RDS closes connections the pool still holds.

**server.shutdown: graceful**
Spring Boot configuration for graceful shutdown. When SIGTERM arrives: stop accepting new requests, wait for in-flight requests to finish, then exit. Without this: SIGTERM kills the JVM immediately, dropping all active requests with connection reset errors.

**Gradle**
A build tool for Java (and other languages). Reads `build.gradle` to determine dependencies and tasks. `./gradlew bootJar` compiles and packages. `./gradlew test` runs tests. Replaces Maven as the modern Java build tool. More flexible and faster with build caching.

**Gradle wrapper (gradlew)**
A shell script in the repo that downloads and runs the exact Gradle version specified in `gradle/wrapper/gradle-wrapper.properties`. Never requires "install Gradle first." `./gradlew test` always uses the pinned version. Identical builds on all machines and in CI.

**--no-daemon (Gradle)**
Tells Gradle not to start a persistent background daemon process. CI containers are ephemeral — a daemon would start, run one build, then be discarded. No benefit, ~200MB wasted memory. Always use `--no-daemon` in CI.

**--continue (Gradle)**
Tells Gradle to continue running all tasks even after one fails. Without it: first test failure → Gradle stops → PR shows only 1 failure. With --continue: all failures visible → engineer fixes all in one go.

**JaCoCo**
Java Code Coverage library. Instruments the bytecode during test execution, measures which lines were executed. Produces: XML/HTML reports. The `jacocoTestCoverageVerification` task fails the build if coverage falls below the configured minimum (70%).

**Line coverage**
The percentage of code lines executed at least once during test runs. 70% line coverage = 70 out of every 100 lines were touched by a test. High coverage catches regressions when code is modified. Low coverage means untested paths can break silently.

**@WebMvcTest**
A Spring Boot test slice annotation. Loads only the web layer (controllers, filters, Jackson). Does NOT load: database, full Spring context, services. Tests start in 1-2 seconds instead of 30+ seconds. Use for controller unit tests with MockMvc.

**MockMvc**
Spring's test utility for simulating HTTP requests without a real server. `mockMvc.perform(get("/api/v1/payments/123"))` executes the request in memory and returns a result you can assert against. Fast, no network overhead.

**JUnit 5**
The current Java testing framework standard. Tests are annotated with `@Test`. JUnit discovers and runs them. Results written to XML files (`build/test-results/test/*.xml`). GitHub Actions can parse these files and display results as PR annotations.

**eclipse-temurin**
The official Adoptium OpenJDK distribution. Community-maintained, security-patched, widely used. Available as both JDK (compiler + runtime) and JRE (runtime only) variants. Used in the Dockerfile: JDK for building, JRE for running. Same binaries as most production Java deployments.

**alpine**
A minimal Linux distribution (~5MB). Used as the base OS for Docker images. Much smaller than Debian/Ubuntu. `eclipse-temurin:21-jre-alpine` = 180MB vs `eclipse-temurin:21-jre` (Debian) = 350MB. Smaller image = faster ECR pull = faster pod startup.

**Fat JAR**
A single JAR file containing the application bytecode AND all its dependency JARs inside. Spring Boot produces this with `bootJar`. Self-contained executable: `java -jar app.jar`. No separate classpath configuration needed. Downside: ~50MB single Docker layer.

**Spring Boot layer JAR (layertools)**
A Spring Boot 2.3+ feature that splits the fat JAR into 4 separate layers for Docker layer caching. `java -Djarmode=layertools -jar app.jar extract` outputs: dependencies/, spring-boot-loader/, snapshot-dependencies/, application/. Code changes only rebuild the application/ layer (1-2MB instead of 50MB).

**-XX:+UseContainerSupport**
JVM flag that reads container memory limits from cgroups instead of host memory. Without it: JVM on a 1Gi container thinks it has 64GB (the node's RAM) → sets 16GB heap → immediate OOM kill. With it: JVM reads 1Gi limit → sets proportional heap. Critical for any JVM in Kubernetes.

**-XX:MaxRAMPercentage=75.0**
JVM flag that sets the maximum heap to 75% of the container's memory limit. Replaces the need to manually calculate `-Xmx` per environment. 1Gi container → Xmx = 768MB. Leaves 25% for non-heap (metaspace, code cache, thread stacks).

**-XX:+UseG1GC**
Enables the G1 (Garbage First) garbage collector. Designed for low-latency, heap sizes 4GB+. Divides heap into equal regions, collects the densest ones first. Best choice for web services where p99 latency matters. Alternative: ZGC (Java 15+, even lower pauses).

**-XX:+HeapDumpOnOutOfMemoryError**
JVM flag that writes a heap dump (.hprof file) when the JVM runs out of memory before crashing. The dump contains a snapshot of all objects in memory at the time of the OOM. Used by engineers with tools like Eclipse MAT to identify memory leaks. Without this: OOM = crash with no diagnostic information.

**-Djava.security.egd=file:/dev/./urandom**
A JVM system property directing the JVM to use `/dev/urandom` (non-blocking) for random number generation. `/dev/random` blocks until the OS accumulates enough entropy. In containers: entropy is scarce → Tomcat startup blocks 2-5 minutes waiting for randomness. `/dev/urandom` never blocks.

**JarLauncher**
`org.springframework.boot.loader.launch.JarLauncher` — the class that starts a layer-exploded Spring Boot application. When using layertools extraction, the application is no longer a fat JAR. JarLauncher assembles the classpath from the extracted layers and starts the application.

**JIT (Just-In-Time compilation)**
The JVM compiles hot bytecode paths to native machine code at runtime. First requests are interpreted (slow, 2-10x production speed). After ~30-60 seconds: hot paths are JIT-compiled → near-native performance. This is why Java load test thresholds are set to 1000ms (not 300ms) — to account for the warmup period.

**Metaspace**
JVM memory area that holds class metadata: bytecode definitions, method information, constant pool. Outside the heap. Spring Boot loads ~500+ classes on startup → ~100-120MB metaspace. Cannot be set to zero — always budget ~150MB beyond Xmx for non-heap.

**GC pressure**
The condition where the garbage collector runs frequently and takes significant time. Symptom: p99 latency spikes, throughput drops. Cause: heap usage consistently above 75-80%. Fix: increase Xmx (more memory), reduce object allocation rate (code optimisation), or add more replicas (distribute load).

**jvm_heap_pct**
Dynatrace variable in the services map. The percentage of JVM maximum heap (-Xmx) that triggers a Resource Contention alert. Set to 75% in production (before GC thrashing), 80% in staging (load test tolerance), 88% in dev (t3.medium always near limit).

**is_jvm_service**
Boolean variable in the Dynatrace services map. Controls whether `dynatrace_metric_events.jvm_heap` is created for this service. `true` for Java/Scala/Kotlin services. `false` for Go/Python/Node services (they have no JVM heap). Prevents creating alerts for metrics that don't exist on non-JVM services.

**OTEL_SERVICE_NAME**
Environment variable that sets the service name in OpenTelemetry traces. Each environment uses a distinct name: `payment-service-dev`, `payment-service-staging`, `payment-service`. Without distinct names: dev traces appear in the production service in Dynatrace → corrupts metrics and SLOs.

**Timeout=900 (ArgoCD sync option)**
Tells ArgoCD to wait up to 900 seconds (15 minutes) for deployed resources to become Healthy. For Java: "Healthy" means readiness probe returns 200, which requires the JVM to finish starting. Without this: ArgoCD times out before Spring Boot finishes starting → false deployment failure.

**valueFiles (Helm)**
A list of values files merged left-to-right. `[values.yaml, values-dev.yaml]`: dev file overrides specific fields from the base file. Fields in values-dev.yaml replace the same fields in values.yaml. Fields NOT in values-dev.yaml keep the values.yaml defaults. Avoids duplicating the entire chart configuration per environment.

**t3.medium (dev node)**
AWS EC2 instance: 2 vCPU, 4GB RAM, Intel. The cheapest EKS-compatible node. Suitable for Java dev (JVM fits in 4GB alongside system pods). CPU throttles under heavy JIT compilation → startup is slow (5-15 minutes). Acceptable for dev. Never use for staging or production.

**m7g.xlarge (staging node)**
AWS Graviton3 instance: 4 vCPU, 16GB RAM, ARM64. Java needs more RAM per node than Python (800MB vs 200MB per pod). 16GB handles 8 Java pods during load test HPA scale-out. ~20% cheaper than m7i.xlarge (Intel equivalent).

**m7g.2xlarge (production node)**
AWS Graviton3 instance: 8 vCPU, 32GB RAM, ARM64. Production Java nodes: 30GB available after system overhead → comfortable for up to 20 Java pods (HPA max). Graviton3 has native ARM64 JVM support — no emulation, near-native performance.
