# Every File in 23_java-eks-gitops-project — Explained

> **How to read this:** Each section = one file or folder. For each file: what it IS, what it DOES, and why it EXISTS (what breaks without it).

---

## Project Map (Who Uses What)

```
Developer pushes Java code
        │
        ▼
.github/workflows/app-ci.yaml          ← Gradle build, JUnit tests, JaCoCo coverage
        │ (on merge to main)
        ▼
app/Dockerfile                          ← 3-stage build: JDK compile → layer extract → JRE run
app/src/main/java/...                   ← Spring Boot application code
        │ (pushes image to ECR, commits new tag to gitops)
        ▼
gitops/dev/app/payment-service/         ← ArgoCD dev: reads new tag here first
        │ (smoke tests pass → promote)
        ▼
gitops/staging/app/payment-service/     ← ArgoCD staging: load test before prod
        │ (staging tests + manual approval)
        ▼
gitops/production/app/payment-service/  ← ArgoCD production: final deploy
        │
        ▼
charts/payment-service/                 ← Helm chart rendered into K8s YAML per env
        │
        ▼
EKS cluster (dev / staging / production) ← Spring Boot pods running the app

Platform engineer changes infra
        │
        ▼
terraform/environments/                  ← per-env VPC, EKS, node sizes
terraform/dynatrace/                     ← per-env DT thresholds (JVM heap alerts, SLOs)
        │
        ▼
Dynatrace tenant                         ← JVM monitoring: heap, GC, traces, SLOs
```

---

## `app/` — The Java Spring Boot Application

---

### `app/settings.gradle`
**What it is:** The Gradle project name declaration — one line.

```groovy
rootProject.name = 'payment-service'
```
```
Gradle uses this name to:
  - Name the output JAR: payment-service-0.0.1-SNAPSHOT.jar
  - Display the project name in build logs
  - Identify the root project in multi-module builds

Without this file: Gradle uses the directory name as the project name.
Inconsistent directory names → inconsistent JAR names → CI scripts break.
One line. Always present.
```

---

### `app/build.gradle`
**What it is:** The Java build configuration — dependencies, plugins, test settings.

**What each section does:**
```groovy
plugins {
    id 'org.springframework.boot' version '3.3.1'
    // Adds: bootJar task (creates the executable fat JAR)
    //       bootRun task (runs the app locally)
    //       spring-boot BOM (manages all Spring dependency versions)

    id 'io.spring.dependency-management' version '1.1.5'
    // Works with spring-boot plugin to lock transitive dependency versions.
    // You write: implementation 'org.springframework.boot:spring-boot-starter-web'
    // No version needed — spring-boot BOM provides the correct version.

    id 'java'           // compiles .java → .class
    id 'jacoco'         // code coverage measurement
}
```

```groovy
java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(21)
    }
}
```
```
Why 21 (not 17 or 11):
  Java 21 is the current LTS (Long-Term Support) release.
  Includes: virtual threads (Loom) — massively more efficient for I/O-heavy apps.
  Spring Boot 3.x requires at least Java 17. 21 is recommended.

toolchain (not sourceCompatibility):
  toolchain downloads and uses EXACTLY Java 21 regardless of what's on the machine.
  sourceCompatibility just sets the compile target — doesn't guarantee JDK version.
  Without toolchain: developer on Java 11 compiles Java 17 features → cryptic errors.
  With toolchain: Gradle downloads Java 21 if needed → everyone uses the same JDK.
```

**Key dependencies explained:**
```groovy
implementation 'org.springframework.boot:spring-boot-starter-web'
```
```
Brings in: Spring MVC (REST routing), Tomcat (HTTP server), Jackson (JSON).
This one line replaces ~20 individual dependency declarations.
The 'starter' prefix = curated dependency bundle.
```

```groovy
implementation 'org.springframework.boot:spring-boot-starter-actuator'
```
```
Adds: /actuator/health, /actuator/metrics, /actuator/prometheus endpoints.
Used by: Kubernetes probes (liveness/readiness), Dynatrace metric collection.
WHY CRITICAL: without Actuator, you have no health endpoints.
Kubernetes has no way to know if the Spring app is ready to serve traffic.
```

```groovy
implementation 'io.micrometer:micrometer-registry-prometheus'
implementation 'io.micrometer:micrometer-tracing-bridge-otel'
implementation 'io.opentelemetry:opentelemetry-exporter-otlp'
```
```
micrometer-registry-prometheus:
  Exposes JVM metrics in Prometheus format at /actuator/prometheus.
  Dynatrace scrapes this: heap_used, gc_pause, http_requests, thread_count.

micrometer-tracing-bridge-otel + opentelemetry-exporter-otlp:
  Distributed tracing: every HTTP request gets a trace ID.
  When payment-service calls order-service calls the DB:
  Dynatrace shows the full call chain as one trace.
  Engineers see EXACTLY where time was spent (controller? service? DB query?).
  Sent to Dynatrace ActiveGate via OTLP protocol (in-cluster, no internet).
```

```groovy
testImplementation 'org.testcontainers:postgresql:1.19.8'
```
```
Testcontainers: starts a REAL PostgreSQL Docker container during tests.
The test JVM connects to it, runs real SQL, checks real results.

WHY NOT MOCK THE DB:
  A mock returns what you tell it to return. It cannot catch:
    - Missing index causing slow query → production timeout
    - SQL type mismatch (Java int → DB varchar) → runtime exception
    - Constraint violation your code didn't handle

  Testcontainers: same database engine as production.
  If the test passes → the SQL works on real PostgreSQL.
  Cost: tests take ~30s longer (container startup). Worth it.
```

**JaCoCo coverage gate:**
```groovy
tasks.named('jacocoTestCoverageVerification') {
    violationRules {
        rule {
            limit { counter = 'LINE'; value = 'COVEREDRATIO'; minimum = 0.70 }
        }
    }
}
check.dependsOn jacocoTestCoverageVerification
```
```
70% minimum line coverage. If coverage drops below 70%:
  ./gradlew check FAILS → CI fails → PR cannot be merged.

WHY ENFORCE COVERAGE:
  Without enforcement: coverage drops to 10% over 2 years as new code is added.
  Engineers test the happy path but not error handling.
  A database connection failure crashes the app because nobody tested that path.

With 70% minimum:
  Every new feature must have tests covering at least 70% of its lines.
  Catches the most common untested paths.
  Not 100% — that creates test-writing overhead without proportional safety gain.
```

---

### `app/Dockerfile`
**What it is:** The 3-stage build recipe that converts Java source into a Docker image.

**Stage 1 — Build (JDK + Gradle):**
```dockerfile
FROM eclipse-temurin:21-jdk-alpine AS builder
COPY gradlew .
COPY gradle/ gradle/
COPY build.gradle settings.gradle ./
RUN ./gradlew dependencies --no-daemon --quiet || true
COPY src/ src/
RUN ./gradlew bootJar --no-daemon -x test
```
```
Why copy Gradle files BEFORE source code:
  Docker builds layer by layer. Each COPY creates a new layer.
  If source code changes but build.gradle doesn't:
  Docker reuses the cached "download dependencies" layer.
  Dependencies don't re-download on every code change.

  Without this ordering:
  COPY . .  ← copies everything at once
  Any code change → entire layer invalidated → re-download all dependencies
  Every PR build: 5 minutes downloading Maven Central jars.

  With this ordering:
  src/ changes → only the last COPY layer is invalidated.
  Dependencies layer cached → build starts immediately.
  Typical savings: 3-4 minutes per CI build.

-x test: skip tests in Docker build.
  CI already ran tests with full JUnit reporting and JaCoCo coverage.
  Running them again in Docker: doubles time, no benefit.
  The JAR is tested. The Docker layer is just packaging.
```

**Stage 2 — Layer extraction:**
```dockerfile
FROM eclipse-temurin:21-jdk-alpine AS extractor
RUN java -Djarmode=layertools -jar app.jar extract
```
```
Spring Boot fat JAR = 50MB single file.
One code change = 50MB Docker layer pushed to ECR every time.

Layer extraction splits into 4 layers:
  1. dependencies      40MB  — external JARs (only changes on dependency update)
  2. spring-boot-loader 1MB  — Spring's classloader (never changes)
  3. snapshot-dependencies 0-5MB — SNAPSHOT versions (infrequent changes)
  4. application       1-2MB — YOUR code (changes every commit)

After extraction:
  Code change → only layer 4 (1-2MB) is pushed to ECR.
  Dependency change → layers 1+2+3+4 pushed, but this is rare.
  Developer pulling the latest image: only downloads the changed layers.
  CI build times reduce from 5 min (push 50MB) to < 30s (push 1-2MB).
```

**Stage 3 — Runtime (JRE only):**
```dockerfile
FROM eclipse-temurin:21-jre-alpine AS runtime
RUN addgroup -S appgroup && adduser -S -G appgroup -u 1000 appuser
COPY --from=extractor ... ./
USER appuser
```
```
eclipse-temurin:21-jre-alpine (not JDK):
  JRE: runs compiled Java → ~180MB
  JDK: compiles + runs → ~350MB
  No compiler in the runtime image: cannot compile/modify code if compromised.
  Attack surface reduced by ~170MB of tooling.

UID 1000 non-root:
  Same as Python version. No root = no system-level access if container escapes.
  Combined with readOnlyRootFilesystem in K8s securityContext:
  Attacker can only write to /tmp (explicitly mounted as emptyDir).
```

**JVM ENTRYPOINT flags explained:**
```dockerfile
ENTRYPOINT ["java",
    "-XX:+UseContainerSupport",
    "-XX:MaxRAMPercentage=75.0",
    "-XX:+UseG1GC",
    "-XX:+HeapDumpOnOutOfMemoryError",
    "-XX:HeapDumpPath=/tmp/heapdump.hprof",
    "-Djava.security.egd=file:/dev/./urandom",
    "org.springframework.boot.loader.launch.JarLauncher"]
```
```
-XX:+UseContainerSupport (THE MOST IMPORTANT FLAG):
  Before Java 11: JVM reads HOST memory, not container limits.
  A 1Gi container on a 64GB node: JVM thinks it has 64GB.
  Default heap = 25% of "available" = 16GB → OOM kill within seconds.
  With +UseContainerSupport: JVM reads the cgroup memory limit (1Gi).
  Sets heap proportionally to 1Gi, not 64GB.

-XX:MaxRAMPercentage=75.0:
  Set heap = 75% of container memory limit.
  1Gi limit → Xmx = 768MB → 256MB left for non-heap.
  Non-heap includes: metaspace (~100MB), code cache (~50MB), thread stacks.
  Rule: always leave 25% for non-heap. Never set Xmx = container limit.

-XX:+UseG1GC:
  G1 = Garbage-First garbage collector.
  Designed for: low pause times (<200ms) on heaps up to several GB.
  Alternative: ZGC (even lower pauses, Java 15+, more memory overhead).
  G1GC is the correct choice for web services where p99 latency matters.

-XX:+HeapDumpOnOutOfMemoryError + HeapDumpPath=/tmp/heapdump.hprof:
  When OOM kill occurs: write the heap snapshot to /tmp before dying.
  Engineers copy the heap dump and analyse what was consuming memory.
  Without this: OOM = mystery. With this: "payment objects consuming 600MB — memory leak in PaymentCache".
  /tmp because the container has readOnlyRootFilesystem=true.

-Djava.security.egd=file:/dev/./urandom:
  Java uses /dev/random for cryptographic randomness.
  /dev/random BLOCKS when entropy pool is empty (common in containers).
  Tomcat startup: generates session keys → reads /dev/random → blocks 2-5 minutes.
  With /dev/urandom: non-blocking. Startup time: normal.
  The /dev/./ path tricks older JVMs into accepting /dev/urandom as the path.
```

---

### `app/src/main/java/com/company/payment/PaymentApplication.java`
**What it is:** The Spring Boot application entry point — 8 lines.

```java
@SpringBootApplication
public class PaymentApplication {
    public static void main(String[] args) {
        SpringApplication.run(PaymentApplication.class, args);
    }
}
```
```
@SpringBootApplication = 3 annotations in one:
  @Configuration:  this class can define @Bean methods
  @EnableAutoConfiguration: scan classpath, auto-configure detected libraries
  @ComponentScan: find all @Controller, @Service, @Repository in this package

SpringApplication.run():
  Starts the Spring container (ApplicationContext).
  Wires all dependencies (dependency injection).
  Starts Tomcat on port 8080.
  Registers Actuator endpoints.

Everything else in the app is discovered and wired automatically.
This file just says "start Spring Boot from here."
```

---

### `app/src/main/java/com/company/payment/controller/PaymentController.java`
**What it is:** The REST API controller — defines all HTTP endpoints.

**Why `@RestController` (not `@Controller`):**
```java
@RestController   // = @Controller + @ResponseBody
@RequestMapping("/api/v1/payments")
public class PaymentController {
```
```
@Controller: renders HTML views (Thymeleaf, JSP)
@RestController: serialises return values directly to JSON response body
Payment API returns JSON → @RestController is correct.

@RequestMapping("/api/v1/payments"):
  All methods in this class are prefixed with /api/v1/payments.
  GET /api/v1/payments/{id} → getPayment()
  POST /api/v1/payments → createPayment()
```

**Bean Validation on POST:**
```java
@PostMapping
public ResponseEntity<Map<String, String>> createPayment(
        @Validated @RequestBody CreatePaymentRequest request)
```
```
@Validated: triggers Bean Validation on the request body BEFORE the method runs.
@RequestBody: parse the JSON request body into a CreatePaymentRequest object.

What happens with invalid input:
  POST {"amount": -100, "currency": "JPY", "userId": "u1"}
  @Min(1) on amount fails → Spring returns HTTP 400 automatically.
  createPayment() method is NEVER called.
  No null checks in controller code. Validation is declarative.

WHY THIS MATTERS:
  Without validation: controller must check every field manually.
  Forgetting one check: negative amount charges, empty userId, 6-char currency code.
  With @Validated: constraints are in the model class (CreatePaymentRequest).
  Adding a new field: add the constraint once → all callers are protected.
```

**Structured logging pattern:**
```java
log.info("{\"event\":\"payment_fetch\",\"payment_id\":\"{}\"}", paymentId);
```
```
JSON log format: every log line is a parseable JSON object.
  event field: what happened (machine-readable, not "Fetching payment abc123")
  payment_id field: the specific entity involved

Dynatrace log ingestion:
  Reads /var/log/containers/*.log from each node via OneAgent.
  JSON fields are extracted automatically into searchable attributes.
  Filter: event="payment_fetch" AND payment_id="pay_123" → exact request trail.

Without structured logs:
  Log: "Fetching payment pay_123 for user user_456"
  To find all payment fetches: regex on free text → fragile, slow.
  To correlate with an error: manual log reading.
```

---

### `app/src/main/java/com/company/payment/model/Payment.java`
**What it is:** The payment domain model — an immutable value object using Java 21 record syntax.

```java
public record Payment(String id, String status, long amount, String currency, String timestamp) {}
```
```
Java record (Java 16+):
  Automatically generates: constructor, getters, equals(), hashCode(), toString().
  Immutable: no setters. Once created, values cannot change.
  One line replaces ~40 lines of a traditional POJO class.

Jackson serialises records to JSON automatically:
  new Payment("pay_1", "completed", 5000, "JPY", "2026-07-30T09:00:00Z")
  → {"id":"pay_1","status":"completed","amount":5000,"currency":"JPY","timestamp":"..."}

WHY IMMUTABLE:
  Response objects should not be mutated after creation.
  Immutability prevents accidental modification during serialisation.
  Thread-safe by default — no synchronisation needed.
```

---

### `app/src/main/java/com/company/payment/model/CreatePaymentRequest.java`
**What it is:** The validated request body model for POST /api/v1/payments.

```java
public record CreatePaymentRequest(
    @NotNull @Min(1) Long amount,
    @NotBlank @Size(min=3, max=3) String currency,
    @NotBlank String userId
) {}
```
```
WHY CONSTRAINTS ON THE MODEL (not in controller):
  If constraints are in the controller: multiple controllers calling this model
  each need their own validation code. Duplication.
  
  With constraints on the record:
  Any controller that accepts CreatePaymentRequest gets validation automatically.
  New endpoint added: annotate with @Validated → same rules enforced.

@NotNull vs @NotBlank:
  @NotNull: value cannot be null (works for Long, Boolean, any type)
  @NotBlank: value cannot be null, empty string, or whitespace-only (Strings only)
  amount uses @NotNull (it's a Long)
  currency and userId use @NotBlank (they're Strings)

@Size(min=3, max=3) on currency:
  Enforces ISO 4217 currency code format (JPY, USD, EUR = 3 chars).
  "DOLLAR" (6 chars) → 400 Bad Request.
  Without this: "DOLLAR" stored in DB, breaks payment processing systems expecting 3 chars.
```

---

### `app/src/main/java/com/company/payment/health/ReadinessIndicator.java`
**What it is:** Custom Spring Boot Actuator health indicator that checks database connectivity.

```java
@Component("readinessIndicator")
public class ReadinessIndicator implements HealthIndicator {
    @Override
    public Health health() {
        try {
            jdbcTemplate.queryForObject("SELECT 1", Integer.class);
            return Health.up()
                .withDetail("database", "connected")
                .withDetail("status", "ok")
                .build();
        } catch (Exception e) {
            return Health.down()
                .withDetail("database", "unreachable")
                .build();
        }
    }
}
```
```
WHY THIS EXISTS:
  Without it: /actuator/health/readiness only checks if the JVM is running.
  A running JVM with a broken DB connection = Kubernetes sends traffic here anyway.
  Every request: DB connection fails → 500 error to the user.

  With ReadinessIndicator:
  DB unreachable → health() returns DOWN → Actuator returns HTTP 503.
  Kubernetes readinessProbe sees 503 → removes pod from Service endpoints.
  Traffic routes only to pods with working DB connections.

"SELECT 1":
  The lightest possible DB query. No table access. Returns immediately.
  Just proves the TCP connection to PostgreSQL is alive and accepting queries.
  Runs on every readiness check (every 5 seconds in production).

withDetail("status", "ok"):
  This specific value is checked by the Dynatrace synthetic monitor.
  Synthetic validation rule: response body contains "\"status\":\"ok\"".
  If the DB is down: response body contains "unreachable" → synthetic FAILS → alert.
  External monitoring catches the DB failure even if internal metrics look normal.
```

---

### `app/src/main/resources/application.yaml`
**What it is:** All Spring Boot configuration — database, logging, server, Actuator, tracing.

**HikariCP connection pool:**
```yaml
spring.datasource.hikari:
  minimum-idle:      2
  maximum-pool-size: 10
  connection-timeout: 3000
  max-lifetime:      1800000
```
```
maximum-pool-size = 10:
  Max 10 simultaneous DB connections from this pod.
  3 pods × 10 connections = 30 total connections to RDS.
  RDS has a connection limit (e.g., db.r6g.large = 1000 max connections).
  Without this limit: 100 pods × unbounded connections → RDS max connections exceeded.

connection-timeout = 3000ms:
  If all 10 connections are in use and a request needs one:
  Wait up to 3 seconds for a free connection.
  After 3s: throw exception → request fails with 500.
  Without timeout: request waits forever → thread stuck → thread pool exhaustion.

max-lifetime = 1800000ms (30 min):
  TCP connections to RDS have a server-side timeout (~30 min).
  HikariCP proactively closes connections before they expire.
  Prevents "stale connection" errors where the DB closed the connection but the pool still holds it.
```

**Structured JSON logging pattern:**
```yaml
logging:
  pattern:
    console: '{"timestamp":"%d{...}","level":"%level","service":"payment-service","message":"%msg"}%n'
```
```
Every log line is JSON. Dynatrace OneAgent reads this format from container log files.
log.info("payment fetched") → {"timestamp":"2026-07-30T09:00Z","level":"INFO","service":"payment-service","message":"payment fetched"}
Searchable in Dynatrace Grail without any log parsing configuration.
```

**Graceful shutdown:**
```yaml
server:
  shutdown: graceful
spring:
  lifecycle:
    timeout-per-shutdown-phase: 30s
```
```
When Kubernetes sends SIGTERM to the pod:
  WITHOUT graceful shutdown:
    JVM exits immediately.
    50 in-flight HTTP requests: TCP connection reset → 500 errors for users.
  
  WITH graceful shutdown (server.shutdown: graceful):
    Tomcat stops accepting new connections.
    Waits up to 30s for in-flight requests to complete.
    Then shuts down cleanly.

  Combined with the Helm chart preStop: sleep 10:
    preStop: give ALB 10s to drain connections → no new requests arrive.
    graceful shutdown: existing requests have 30s to finish.
    Total: zero dropped requests during normal pod termination.
```

**OpenTelemetry tracing:**
```yaml
management:
  tracing:
    sampling:
      probability: 1.0
    exporter:
      otlp:
        endpoint: http://dynatrace-activegate.dynatrace.svc:4318
```
```
probability: 1.0 = trace every request (100% sampling).
  Production: consider 0.1 (10%) for high-traffic services — reduces telemetry cost.
  Dev/staging: 1.0 for full observability.

http://dynatrace-activegate.dynatrace.svc:4318:
  In-cluster DNS: dynatrace-activegate pod in the dynatrace namespace.
  Port 4318: OTLP/HTTP endpoint.
  No internet required: traces stay on the AWS backbone.
  Latency to send a trace: ~1ms (in-cluster). Not blocking the request thread.
```

---

### `app/src/test/java/com/company/payment/PaymentControllerTest.java`
**What it is:** Unit tests for the REST controller using Spring's MockMvc.

```java
@WebMvcTest(PaymentController.class)
class PaymentControllerTest {
    @Autowired
    private MockMvc mockMvc;
```
```
@WebMvcTest(PaymentController.class):
  Loads ONLY: PaymentController + Spring MVC configuration.
  Does NOT load: database, services, security (unless configured).
  Result: tests start in <2 seconds (vs 30s for full Spring context).

MockMvc:
  Simulates HTTP requests without a real network connection.
  mockMvc.perform(get("/api/v1/payments/123"))
  → Spring processes the request in memory
  → Returns a MockMvcResult you can assert against.
  No server port, no TCP, no network stack needed.
```

**What each test validates:**
```java
void getPayment_returns200() — basic 200 status
void getPayment_returnsPaymentJson() — response has id, status, currency fields
void createPayment_validRequest_returns200() — valid POST body → 200
void createPayment_missingAmount_returns400() — @NotNull works
void createPayment_negativeAmount_returns400() — @Min(1) works
void createPayment_invalidCurrency_returns400() — @Size(3,3) works
void actuatorLiveness_returns200() — /actuator/health/liveness is accessible
```
```
WHY TEST VALIDATION (400 responses):
  If @NotNull annotation is removed by accident:
  createPayment_missingAmount_returns400 FAILS.
  CI blocks the PR. Regression caught before production.

  Without these tests: validation is removed → production accepts null amounts.
  Payment records created with null amounts → downstream processing crashes.
  Post-mortems for bugs like this typically say "no test coverage for validation".

WHY TEST THE ACTUATOR ENDPOINT:
  The liveness probe depends on /actuator/health/liveness returning 200.
  If Actuator is accidentally disabled or misconfigured:
  This test fails → CI blocks → deployment blocked.
  Without this test: misconfigured Actuator → pods restart in a loop → incident.
```

---

## `.github/workflows/app-ci.yaml` — Java CI/CD Pipeline

**What it is:** 7-job pipeline: unit tests → build → dev → staging → production with Java-specific optimisations.

**Java-specific step: Gradle cache:**
```yaml
- uses: actions/setup-java@v4
  with:
    java-version: '21'
    distribution: 'temurin'
    cache: 'gradle'
```
```
cache: 'gradle':
  Caches ~/.gradle/caches between CI runs.
  Without cache: CI downloads ALL dependencies from Maven Central on every run.
  ~200MB of JARs × 20 CI runs/day = 4GB of redundant downloads per day.
  With cache: only NEW or CHANGED dependencies downloaded.
  First run: 4 minutes. Subsequent runs: 15 seconds.

distribution: 'temurin':
  Same JDK distribution as the Dockerfile (eclipse-temurin).
  Guarantees: code compiled in CI uses the same JDK as the runtime container.
  Different JDK distributions can have subtle differences in standard library behaviour.
```

**Java-specific test step:**
```yaml
- name: Run tests and coverage check
  working-directory: app
  run: |
    ./gradlew test jacocoTestReport jacocoTestCoverageVerification \
      --no-daemon \
      --continue
```
```
Three tasks chained:
  test: runs all JUnit tests, writes XML results to build/test-results/
  jacocoTestReport: reads test execution data, produces coverage report
  jacocoTestCoverageVerification: checks coverage >= 70% (FAILS if not)

--no-daemon:
  Don't start a long-running Gradle daemon process.
  CI containers are ephemeral — daemon would start, run one build, then die.
  No benefit, 200MB wasted memory.

--continue:
  Even if one test fails, continue running ALL tests.
  Without --continue: first failing test → Gradle stops immediately.
  You see: "1 test failed" → fix → push → 2 more tests fail.
  With --continue: see ALL failures at once → fix all in one commit.
```

**Java-specific JUnit test reporting:**
```yaml
- uses: mikepenz/action-junit-report@v4
  if: always()
  with:
    report_paths: 'app/build/test-results/test/*.xml'
    check_name: 'JUnit Test Results'
```
```
Parses JUnit XML files and creates inline PR annotations.
Reviewer sees: "PaymentControllerTest.createPayment_missingAmount_returns400 FAILED"
directly on the PR diff, not buried in CI log output.

if: always():
  Run even if the test step failed.
  If tests fail: you still want the report to show WHICH tests failed.
  Without if: always() → report step skipped on failure → reviewer has no context.
```

**Longer deployment timeouts (Java vs Python):**
```yaml
kubectl rollout status ... --timeout=8m   # dev:  8 min (JVM startup slow)
kubectl rollout status ... --timeout=10m  # staging
kubectl rollout status ... --timeout=12m  # production
```
```
Python startup: 2-5 seconds.
Java (Spring Boot) startup:
  - JVM initialisation: 2-5s
  - Spring context loading: 5-15s
  - Hibernate entity scanning + connection pool init: 5-15s
  - Total cold start: 30-120 seconds (longer with t3.medium in dev)

If timeout is too short: `kubectl rollout status` exits with non-zero → CI fails.
The deployment actually succeeded but CI reports failure → false alarm.
Python project: 5 min timeout is fine. Java project: 8-12 min needed.

Production smoke test also has extra sleep 60:
  JVM JIT compilation runs for ~60s after startup.
  During warmup: p99 latency is 2-3x higher than steady state.
  Testing during warmup: tests fail on latency even though app is healthy.
  sleep 60 → JIT completes → smoke tests see real steady-state performance.
```

---

## `charts/payment-service/` — Helm Chart

---

### `charts/payment-service/values.yaml` (production defaults)

**Memory sizing (different from Python):**
```yaml
resources:
  requests: { cpu: 250m, memory: 768Mi }
  limits:   { cpu: 1000m, memory: 1Gi }
```
```
JVM memory formula: container_limit = Xmx / 0.75
  1Gi container × 0.75 = 768MB heap (Xmx)
  Remaining 256MB → JVM non-heap:
    metaspace (~120MB): class definitions, method bytecode
    code cache (~80MB): JIT-compiled native code
    thread stacks (~50MB): 200 threads × 256KB stack
    JVM overhead (~10MB): GC metadata, etc.

requests.memory = 768Mi (not 512Mi like Python):
  JVM base RSS before any requests = ~250MB.
  Even idle, the JVM uses more memory than Python.
  Setting requests too low: pod gets scheduled on a memory-tight node.
  Memory pressure triggers JVM GC more frequently → latency spikes.
```

**Startup probe (much longer than Python):**
```yaml
startupProbe:
  httpGet:
    path: /actuator/health/liveness
    port: 8080
  failureThreshold: 60
  periodSeconds:    10
```
```
failureThreshold: 60 × periodSeconds: 10 = 600 seconds = 10 MINUTES max startup.
Compare to Python: failureThreshold: 30 × 10 = 5 minutes.

WHY JAVA NEEDS MORE:
  Development environment (t3.medium, first cold start):
  1. JVM initialisation: 5s
  2. Spring loads 500+ auto-configuration classes: 15s
  3. Hibernate validates schema, creates connection pool: 20s
  4. RDS connection (cold start across VPC): 5s
  5. Application-specific startup logic: varies
  Total worst case: 3-5 minutes. On a slow node: up to 8 minutes.

  failureThreshold too low → Kubernetes kills pod during legitimate startup.
  Pod restarts → starts over → loops forever.
  "CrashLoopBackOff" with message "Liveness probe failed" = startup probe too tight.

Actuator path (/actuator/health/liveness not /health/live):
  Python uses FastAPI custom endpoints.
  Spring Boot uses Actuator endpoints.
  Must use the correct path for the framework being deployed.
```

**Graceful shutdown in Helm values:**
```yaml
terminationGracePeriodSeconds: 60
```
```
Coordinates with application.yaml server.shutdown: graceful (30s).

Sequence:
  1. K8s removes pod from Service endpoints (ALB stops routing here)
  2. preStop: sleep 10 (10s for in-flight requests to drain from ALB)
  3. K8s sends SIGTERM → Spring starts graceful shutdown
  4. Spring: stops Tomcat accepting new requests, drains existing ones (30s)
  5. terminationGracePeriodSeconds: 60 → K8s waits up to 60s for JVM to exit
  6. JVM exits cleanly

If step 4 takes > 60s: K8s sends SIGKILL (force kill).
60s is generous — Spring drains requests in <30s normally.
The extra 30s is buffer for unusually slow requests.
```

---

### `charts/payment-service/values-dev.yaml`

**Why dev settings are extremely generous:**
```yaml
startupProbe:
  failureThreshold: 120   # 120 × 10s = 20 minutes max startup
  periodSeconds: 10
```
```
Dev environment: t3.medium node (2 vCPU, 4GB RAM).
Spring Boot + PostgreSQL + ECR image pull cold start on t3.medium:
  Image pull: 2-3 minutes (arm64 JRE image from ECR first time)
  JVM start: 2-5 minutes on t3.medium (CPU throttling under load)
  Spring context: 5-10 minutes with slow CPU
  Total: up to 15-18 minutes on a completely cold dev node.

With failureThreshold: 120: 20 minutes max → covers even the slowest cold start.
Dev engineer frustration: pod killed during startup → CrashLoopBackOff → "it's broken".
With generous probe: pod eventually starts → dev can work.
```

```yaml
env:
  - name: LOG_LEVEL
    value: "DEBUG"
  - name: SHOW_SQL
    value: "true"
```
```
LOG_LEVEL: DEBUG:
  Spring logs everything: every bean created, every HTTP request processed,
  every method called. Extremely verbose.
  Dev: engineers need this detail to debug issues.
  Production: would produce gigabytes of logs per hour. Never use DEBUG in prod.

SHOW_SQL: true:
  Hibernate logs every SQL query executed.
  Example: "select payment0_.id from payments payment0_ where payment0_.id=?"
  Dev: engineers verify their JPA queries are correct. Catches N+1 queries.
  Production: one request can execute 20+ queries → 20 log lines per request.
  At 1000 req/min: 20,000 SQL log lines/min → CloudWatch costs, log noise.
```

---

### `charts/payment-service/values-staging.yaml`

```yaml
env:
  - name: OTEL_SERVICE_NAME
    value: "payment-service-staging"
```
```
Each environment has a distinct OTEL_SERVICE_NAME.
In Dynatrace: services are identified by name.
If dev and staging both use "payment-service": traces from both appear in one service.
With distinct names: separate services → separate dashboards → no cross-env noise.
"payment-service-dev" traces never pollute "payment-service" (production) analysis.
```

---

## `gitops/` — ArgoCD Applications per Environment

---

### `gitops/dev/bootstrap/root-app-dev.yaml`

```yaml
spec:
  source:
    path: gitops/dev
```
```
The dev ArgoCD instance watches ONLY gitops/dev/.
It cannot see or deploy gitops/staging/ or gitops/production/.
Changes to staging gitops: dev ArgoCD does not react. Isolation enforced.

Applied once manually to bootstrap:
  kubectl apply -f gitops/dev/bootstrap/root-app-dev.yaml --context company-dev
After that: dev ArgoCD manages itself and everything under gitops/dev/.
```

---

### `gitops/dev/app/payment-service/payment-service.yaml`

**The key Java-specific setting:**
```yaml
syncOptions:
  - Timeout=900   # 15 minutes
```
```
ArgoCD waits for resources to become Healthy before marking sync successful.
For Java: "Healthy" means readiness probe passes.
readiness probe passes when: /actuator/health/readiness returns 200.
/actuator/health/readiness returns 200 when: DB is connected AND JVM started.

From ArgoCD's perspective:
  Apply Deployment → Kubernetes creates pod → pod is Pending → Running → not-Ready → Ready.
  Java pod: not-Ready for up to 10 minutes (JVM + Spring startup).

Timeout=900: ArgoCD waits 15 minutes for the pod to become Ready.
Without Timeout=900: ArgoCD default timeout is lower → sync fails → false deployment failure.
```

**valueFiles merging:**
```yaml
helm:
  valueFiles:
    - values.yaml       # production defaults (base)
    - values-dev.yaml   # dev overrides (applied on top)
```
```
Helm merges these files from left to right.
values.yaml:      replicaCount: 3, memory: 1Gi, startupProbe.failureThreshold: 60
values-dev.yaml:  replicaCount: 1, memory: 512Mi, startupProbe.failureThreshold: 120

Result: dev chart has replicaCount=1, memory=512Mi, failureThreshold=120.
Only overridden fields are in values-dev.yaml — everything else inherits from values.yaml.
Adding a new production value: it automatically applies to all envs unless overridden.
```

---

## `terraform/environments/` — Infrastructure Per Environment

---

### `terraform/environments/dev/terraform.tfvars`

```hcl
node_instance_types = ["t3.medium"]   # cheapest viable EKS node
node_min_size       = 1
single_nat_gateway  = true
```
```
t3.medium (2 vCPU, 4GB RAM):
  Cheapest node that can run:
    System nodes: CoreDNS (~100MB), kube-proxy (~50MB), DT OneAgent (~512MB)
    Java pod: Spring Boot (~512MB heap + 256MB non-heap = ~768MB RSS)
  Total: ~1.5GB → tight on 4GB, but viable for dev.

  Java on t3.medium is slow (CPU throttling when compiling JIT). Expected in dev.

single_nat_gateway = true:
  One NAT GW = $45/month saved.
  If dev AZ-a fails: dev loses internet access. Acceptable — no SLA for dev.
  Production: never acceptable (use one_nat_gateway_per_az = true).
```

---

### `terraform/environments/staging/terraform.tfvars`

```hcl
node_instance_types = ["m7g.xlarge"]   # 4 vCPU, 16GB — Java needs more RAM
```
```
Python staging: m7g.large (2 vCPU, 8GB) was sufficient.
Java staging: m7g.xlarge (4 vCPU, 16GB) needed.

Why Java needs more RAM per node:
  Python pod: ~200MB RSS
  Java pod: ~800MB RSS (JVM heap + non-heap)
  System components: ~600MB (CoreDNS, kube-proxy, DT OneAgent)
  
  m7g.large (8GB):
    Available for pods: 8GB - 600MB system - OS overhead = ~7GB
    2 Java pods (800MB each) = 1.6GB used. Fine.
    Load test (50 VUs) scales HPA: 8 pods = 6.4GB → EXCEEDS available memory.
    OOM kills during load test → test fails.
  
  m7g.xlarge (16GB):
    Available: ~15GB
    8 Java pods × 800MB = 6.4GB used. Comfortable.
    Load test completes without OOM.
```

---

### `terraform/environments/production/terraform.tfvars`

```hcl
node_instance_types = ["m7g.2xlarge"]   # 8 vCPU, 32GB
```
```
Production Java nodes need more memory headroom:
  Per-node capacity: ~30GB available after system overhead.
  20 Java pods max (HPA maxReplicas) × 1Gi = 20GB.
  2 nodes each with 20 pods: 20GB per node → safe on 30GB.
  Headroom for: JVM GC overhead, metrics, temporary objects.

m7g.2xlarge is Graviton3 (ARM64):
  Java on ARM64: JVM has native ARM64 support.
  No emulation. Near-native performance.
  ~20% cheaper than equivalent Intel (m7i.2xlarge).
  Multi-arch Docker image supports both linux/arm64 and linux/amd64.
  Karpenter provisions m7g.2xlarge → pulls arm64 image layer automatically.
```

---

## `terraform/dynatrace/` — Monitoring Thresholds Per Environment

---

### `terraform/dynatrace/dev.tfvars`

```hcl
latency_p99_ms    = 10000  # 10 seconds
jvm_heap_pct      = 88
is_jvm_service    = true
```
```
latency_p99_ms = 10000 (10 seconds in dev):
  JVM cold start on t3.medium: first requests during JIT warmup take 2-8 seconds.
  If threshold is 300ms (production): alert fires constantly during dev testing.
  Dev engineers ignore alerts → alert fatigue → they miss real problems.
  10s threshold: only alerts on genuinely broken behaviour (not JIT warmup).

jvm_heap_pct = 88:
  t3.medium has 4GB total. System uses 600MB. JVM gets ~768MB.
  Spring Boot + Hibernate preloads much of this. Idle heap usage: 60-70%.
  Under any load: heap usage goes to 80-90%.
  88% threshold: only fires if heap is truly near-OOM, not during normal dev load.

is_jvm_service = true:
  Enables dynatrace_metric_events.jvm_heap for this service.
  This is the Terraform filter:
    jvm_services = { for name, svc in var.services : name => svc if svc.is_jvm_service }
  With is_jvm_service = true: JVM heap monitoring created.
  If set to false: no JVM heap alert, no GC monitoring. Silent heap exhaustion.
```

---

### `terraform/dynatrace/staging.tfvars`

```hcl
latency_p99_ms = 1000   # 1 second (accounts for JIT warmup in load test)
jvm_heap_pct   = 80
```
```
latency_p99_ms = 1000ms (not 300ms like production):
  k6 load test (50 VUs, 3 minutes) starts while JVM is still warming up.
  First 30-60 seconds of load test: JIT compiling hot paths → 2-4x higher latency.
  If threshold is 300ms: alert fires during warmup → false alarm → blocks staging promotion.
  1000ms: covers warmup period, still catches genuine degradation (> 1s = real problem).

jvm_heap_pct = 80:
  Staging under load test: JVM heap usage goes higher than dev (real load, multiple VUs).
  75% threshold (same as production) would fire during normal load test execution.
  80% gives breathing room for the load test while still alerting on true heap pressure.
```

---

### `terraform/dynatrace/production.tfvars`

```hcl
latency_p99_ms    = 300   # 300ms — strict (real users pay real money)
jvm_heap_pct      = 75    # alert before GC thrashing starts
is_jvm_service    = true
pagerduty_integration_keys = { "payments" = "..." }
```
```
jvm_heap_pct = 75 in production (not 80):
  At 75% heap: GC starts running more frequently.
  Impact: p99 latency increases 20-50ms due to GC pauses.
  Alert at 75%: 15-minute warning before real user impact (at 85-90%).
  Engineers can scale out (add replicas) before users are affected.

  LEADING INDICATOR CHAIN:
  jvm_heap alert at 75% → engineer adds replicas → heap drops.
  No alert until 90%: GC thrashing begins → latency spikes → error rate rises.
  With 75% alert: catch and fix BEFORE the latency and error rate signals fire.

pagerduty only in production:
  Dev/staging DT tfvars have pagerduty_integration_keys = {}
  Production: PagerDuty keys provided → critical and high alerts page on-call.
  An OOM kill in dev: Slack notification at best.
  An OOM kill in production: PagerDuty call at 3am. Immediate response.
```
