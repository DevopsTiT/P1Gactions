# Glossary — Java GitOps 3-Environment File Explainer

Every term used across all file explanations, defined for an SRE beginner.

---

**GitHub Actions `on.paths`**
A trigger filter that makes a workflow only run when specific files change. `paths: ['app/**']` = only run when files under `app/` are changed. Prevents unnecessary CI runs when unrelated files (like terraform or docs) are edited.

**`if: github.event_name == 'push'`**
A job condition in GitHub Actions. `push` = code was merged to main (PR closed). `pull_request` = PR was opened or updated. Using this condition makes jobs mutually exclusive: plan/test on PR, apply/deploy on merge.

**`needs:` (GitHub Actions)**
A job dependency declaration. `needs: test` means: wait for the `test` job to succeed before starting this job. Creates a sequential chain: tests must pass before build, build before smoke tests, smoke tests before staging promotion.

**`environment:` (GitHub Actions)**
References a GitHub Environment (Settings → Environments). Provides: deployment history, environment-specific secrets, and optional approval gates (required reviewers). `environment: production` with required reviewers pauses the workflow until a human approves.

**`contents: write` permission**
Grants the GitHub Actions workflow permission to commit and push to the repository. Required for the gitops image tag update step (writing `tag: "new-sha"` to a YAML file and pushing).

**Image promotion (ECR to ECR)**
Copying a Docker image from one AWS account's ECR to another using `docker pull` → `docker tag` → `docker push`. The image digest (SHA256) is identical — same bytes, different registry. Guarantees: what passed dev tests is exactly what runs in production.

**`[skip ci]` commit message tag**
A convention recognised by GitHub Actions. Any commit message containing `[skip ci]` causes GitHub to skip triggering CI workflows for that commit. Used in the gitops tag update commit to prevent an infinite CI loop.

**Docker manifest (multi-arch)**
A single Docker image tag that references multiple architecture-specific images (linux/amd64, linux/arm64). When a Graviton (ARM) node pulls the image, Docker automatically selects the arm64 variant. Built with `platforms: linux/amd64,linux/arm64`.

**Trivy**
An open-source vulnerability scanner for container images. Checks OS packages and JAR dependencies against CVE databases. `exit-code: '1'` makes the CI step fail if CRITICAL or HIGH vulnerabilities are found, blocking deployment.

**`sleep 30/60` (JVM warmup wait)**
A deliberate pause in the CI pipeline before running smoke tests or load tests. JVM JIT (Just-In-Time) compilation runs for 30-60 seconds after startup — during this time, request latency is 2-10× higher than steady state. Waiting allows JIT to complete so tests measure real performance.

**JIT (Just-In-Time compilation)**
The JVM's process of compiling hot bytecode paths to native machine code at runtime. First requests are interpreted (slow). After ~30-60 seconds of warm-up: JIT-compiled code runs at near-native speed. Why staging thresholds are relaxed vs production.

**Auto-rollback**
An automated reversion to the previous deployment when post-deployment tests fail. The CI pipeline finds the previous image tag from git history, updates the gitops file, and commits — triggering ArgoCD to roll back without human intervention.

**`git log --oneline` for rollback**
Shell command to get the git commit history of a specific file. `NR==2` (second line) = the commit before the current deploy. `xargs git show` shows the file content at that commit. Used to extract the previous image tag for rollback.

**Helm `valueFiles` merge**
When ArgoCD/Helm applies multiple values files, they are merged left-to-right. Later files override fields from earlier files. `[values.yaml, values-dev.yaml]`: `values.yaml` provides all defaults; `values-dev.yaml` overrides only the fields that differ in dev. Fields absent from `values-dev.yaml` inherit from `values.yaml`.

**`ScheduleAnyway` vs `DoNotSchedule`**
Kubernetes topology spread constraint behaviour when a node placement would violate `maxSkew`. `DoNotSchedule` (hard): scheduler refuses the placement — pod stays Pending. `ScheduleAnyway` (soft): scheduler places the pod anyway and tries its best. Hard in production (real HA); soft in dev (may have only 1 node).

**`whenUnsatisfiable`**
A field in Kubernetes `topologySpreadConstraints` that controls what happens when a pod cannot be spread according to the constraint. `DoNotSchedule` = never violate the constraint (production). `ScheduleAnyway` = violate if necessary (dev/staging with fewer nodes).

**`Timeout=900` (ArgoCD sync option)**
Tells ArgoCD to wait up to 900 seconds (15 minutes) for resources to become Healthy before declaring the sync failed. Java Spring Boot pods take 30-120+ seconds to start, much longer than ArgoCD's default. Without this, ArgoCD reports sync failure during legitimate JVM startup.

**`ignoreDifferences` (ArgoCD)**
Tells ArgoCD to ignore differences between the desired state (Git) and the actual state (cluster) for specific fields. Used for `/spec/replicas`: HPA changes this field dynamically; ArgoCD must not fight it by reverting to the Helm value every 3 minutes.

**HPA (HorizontalPodAutoscaler)**
A Kubernetes resource that automatically adjusts the number of pod replicas based on metrics (CPU, memory, custom). `minReplicas` → `maxReplicas` range. HPA changes `spec.replicas` directly — ArgoCD must ignore this field to avoid conflict.

**`argoproj.io/sync-wave` annotation**
Controls the order in which ArgoCD deploys resources during a sync. Lower numbers deploy first. `-1` (namespaces) → `1` (operators) → `8` (applications). Resources in the same wave deploy in parallel; the next wave only starts after the current wave is healthy.

**`directory.recurse: true` (ArgoCD source)**
Tells ArgoCD to recursively scan all subdirectories of the source path for Kubernetes manifests and ArgoCD Applications. Without `recurse: true`: only the top-level files are considered. Required for the App of Apps pattern where the root-app manages an entire folder tree.

**`prune: true` (ArgoCD)**
If a Kubernetes resource exists in the cluster but its corresponding file was deleted from Git, ArgoCD deletes the resource. Enforces "Git = desired state." Without prune: deleted files leave orphaned resources in the cluster.

**`selfHeal: true` (ArgoCD)**
If someone manually changes a resource with `kubectl`, ArgoCD reverts it back to the Git state within ~3 minutes. Enforces GitOps discipline: changes must go through Git. Good habit to enforce in dev so engineers learn the GitOps workflow.

**AppProject (ArgoCD)**
Defines what an ArgoCD Application is allowed to deploy: which source repos, which destination namespaces, which resource types. `project: payments` restricts the payment-service Application to deploy only to `payment-ns`. Prevents cross-namespace accidents.

**`finalizers: resources-finalizer.argocd.argoproj.io`**
When an ArgoCD Application with this finalizer is deleted, ArgoCD cascades the deletion to all resources it manages. Ensures clean teardown. Remove this finalizer before deleting an Application if you want to keep the deployed resources.

**k6**
An open-source load testing tool. Runs HTTP load tests with configurable VUs (virtual users = concurrent connections) and duration. Thresholds defined in the test script cause k6 to exit with code 1 if breached (CI failure). Commonly used to validate staging before production.

**VU (Virtual User)**
In k6 load testing: one simulated concurrent user. Each VU runs continuously for the test duration, executing requests. `--vus 50` = 50 simultaneous HTTP connections hitting the service.

**p99 (99th percentile) threshold**
A k6 threshold: `p(99) < 800` means "99% of requests must complete in under 800ms." If even 1% of requests exceed 800ms: threshold is breached → k6 exits with code 1 → CI fails. Staging threshold (800ms) is relaxed vs production SLO (300ms) to account for JIT warmup.

**`-agentlib:jdwp`**
Java Debug Wire Protocol. A JVM flag that opens a debug port (5005) for remote debugging. Allows attaching IntelliJ or VSCode to a running JVM and setting breakpoints. Used in dev only. Never in staging or production (security risk, performance overhead).

**`suspend=n` (JDWP)**
A JDWP option meaning "do NOT suspend the JVM while waiting for a debugger to connect." Without `suspend=n`: JVM starts, waits for debugger before running any code → startupProbe never passes → pod restart loop.

**`pullPolicy: Always`**
Kubernetes image pull policy. Always pull the image from ECR on every pod start. Used in dev where the `:latest-dev` tag may be reused but points to a different image. Production uses `IfNotPresent` with SHA tags (immutable tags make Always unnecessary and wasteful).

**`pullPolicy: IfNotPresent`**
Kubernetes only pulls the image if it's not already cached on the node. With immutable SHA tags (production), the cached image is always correct. Avoids redundant ECR pulls on every pod start, reducing startup time.

**`-Xms` / `-Xmx`**
JVM flags setting initial and maximum heap size. `-Xms128m`: JVM allocates 128MB heap at startup. `-Xmx256m`: JVM never uses more than 256MB heap. Setting `Xms` close to `Xmx` reduces GC overhead from heap resizing. In production, `MaxRAMPercentage` replaces these with container-aware sizing.

**`-XX:MaxGCPauseMillis=200`**
G1GC tuning flag. Tells G1GC to target maximum GC pauses of 200ms. G1GC adjusts collection frequency and region size to achieve this. Cannot guarantee the target but guides the GC tuning algorithm. Important for payment APIs with p99 latency SLOs.

**`-XX:+UseContainerSupport`**
JVM flag (enabled by default in Java 11+) that makes the JVM read container cgroup memory limits instead of host memory. Critical for Kubernetes. Without it: JVM thinks it has the node's full RAM → allocates huge heap → OOM kill.

**`-XX:MaxRAMPercentage=75.0`**
JVM flag that automatically sets maximum heap to 75% of the container memory limit. With a 1Gi container: Xmx = 768MB. The remaining 25% is reserved for JVM non-heap (metaspace, code cache, thread stacks). Replaces manually calculated `-Xmx` values.

**HikariCP minimum-idle**
The minimum number of idle database connections HikariCP keeps open. `minimum-idle: 2` means even when no requests are active, 2 connections are always open and ready. Eliminates connection setup latency for the first requests after a quiet period.

**HikariCP maximum-pool-size**
The maximum number of simultaneous database connections. `maximum-pool-size: 10` means at most 10 concurrent DB queries from this pod. Prevents one pod from exhausting the database's connection limit. Total connections = pods × pool_size.

**`server.shutdown: graceful` (Spring Boot)**
Configures Tomcat to finish processing in-flight HTTP requests before shutting down when SIGTERM arrives. Without this: SIGTERM kills the JVM immediately, dropping all active requests with TCP reset errors.

**`topology.kubernetes.io/zone`**
A label automatically applied by Kubernetes to each node indicating its availability zone (e.g., `ap-northeast-1a`). Used as `topologyKey` in spread constraints to distribute pods across AZs.

**`maxSkew: 1`**
In topology spread constraints: the maximum allowed difference in pod count between any two topology domains (AZs). `maxSkew: 1` means: no AZ can have more than 1 extra pod compared to the least-loaded AZ. Ensures balanced distribution.

**PodDisruptionBudget (PDB)**
A Kubernetes policy limiting how many pods can be disrupted simultaneously. `minAvailable: 2` means: at least 2 pods must remain running during voluntary disruptions (node drain, rolling update). Prevents maintenance from causing an outage.

**`LOG_LEVEL: WARN`**
An environment variable passed to Spring Boot to set logging verbosity. `WARN` = only warnings and errors. `INFO` = include informational events. `DEBUG` = include everything (very verbose). Production uses WARN to reduce log volume (cost) and noise.

**`OTEL_SERVICE_NAME`**
OpenTelemetry environment variable that sets the service name in distributed traces. Each environment uses a different value (`payment-service-dev`, `payment-service-staging`, `payment-service`). Without distinct names, dev traces contaminate production metrics in Dynatrace.

**`jvm_heap_pct` (Dynatrace tfvars)**
The JVM heap utilisation percentage that triggers a Resource Contention alert in Dynatrace. Production: 70% (early warning before GC pressure affects latency). Staging: 78% (accounts for load test heap growth). Dev: 80% (t3.medium heap fills faster on tiny Xmx=256m).

**`is_jvm_service` (Dynatrace tfvars)**
Boolean that controls whether JVM heap monitoring (`dynatrace_metric_events.jvm_heap`) is created for a service. `true` for Java/Spring Boot. `false` for Go/Python/Node (the metric `builtin:process.memory.jvm.heapUtilization` doesn't exist on non-JVM runtimes).

**`traffic_min_rps = 0` (dev)**
Setting the traffic drop alert threshold to 0 disables the alert. Dev has no real users — long quiet periods are expected. If threshold > 0: the alert fires constantly → alert fatigue → engineers ignore it → they miss real problems when they do occur.

**`pod_restart_threshold = 2`**
The number of pod restarts in 5 minutes that triggers a Dynatrace alert. Production: 2 (any CrashLoopBackOff is immediately investigated). Dev: 5 (dev pods restart frequently during development). Staging: 3.

**VPC CIDR per environment**
Each environment uses a different `/16` IP range: dev=10.10.0.0/16, staging=10.11.0.0/16, production=10.12.0.0/16. Non-overlapping CIDRs enable VPC peering if cross-environment communication is ever needed. Overlapping CIDRs make peering impossible.

**Spot instance diversification**
Using multiple EC2 instance types (t3.medium AND t3a.medium) to spread Spot capacity requests across multiple pools. If one type's Spot capacity is exhausted, the other is still available. More instance types = fewer "insufficient capacity" errors during scale-out.

**`m6g` vs `m7g` (Graviton generations)**
m6g = 6th-generation Graviton2. m7g = 7th-generation Graviton3 (latest). m7g has ~25% better compute performance. Staging uses m6g (good enough, slightly cheaper). Production uses m7g (best performance for real user traffic). Both are ARM64 — same architecture as m7g.
