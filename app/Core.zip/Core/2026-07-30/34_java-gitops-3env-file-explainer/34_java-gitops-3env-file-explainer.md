# Every File in 31_java-gitops-3env — Explained

> **How to read this:** Each section = one file. For each file: what it IS, what it DOES, and why it EXISTS (what breaks without it).

---

## Project Map (Who Uses What)

```
Developer merges Java code to main
          │
          ▼
.github/workflows/app-ci.yaml     ← 7-job pipeline: test → build → dev → staging → prod
          │
          ├─ Job 1: JUnit tests + JaCoCo 70% coverage gate
          │         (fails = stops everything)
          │
          ├─ Job 2: Gradle build → Docker 3-stage → push DEV ECR → gitops/dev/ updated
          │         ArgoCD dev cluster detects git change → deploys Java pod
          │
          ├─ Job 3: Smoke test dev (/actuator/health + API) → if pass →
          │
          ├─ Job 4: Copy image DEV ECR → STAGING ECR → gitops/staging/ updated
          │         ArgoCD staging cluster deploys → k6 load test (50 VUs)
          │
          ├─ Job 5: k6 load test (p99 < 800ms, error < 1%) → if pass →
          │
          ├─ Job 6: MANUAL APPROVAL → copy STAGING ECR → PROD ECR
          │         gitops/production/ updated → ArgoCD production deploys
          │
          └─ Job 7: Production smoke test → FAIL → AUTO-ROLLBACK via git revert

charts/payment-service/           ← Helm templates, 3 values files (one per env)
          │
          ▼
gitops/{dev,staging,production}/  ← ArgoCD reads image tags from here
  bootstrap/root-app-*.yaml       ← Apply once: bootstraps entire environment
  namespaces/namespaces.yaml      ← Wave -1: namespaces first
  app/payment-service/            ← Wave 8: payment-service last

terraform/environments/*/         ← Per-env AWS infra (node types, VPC, cluster)
terraform/dynatrace/              ← Per-env DT thresholds (JVM heap, SLO, alerts)
```

---

## `.github/workflows/app-ci.yaml` — The 7-Job Promotion Pipeline

**What it is:** A single GitHub Actions workflow file that drives the entire dev → staging → production promotion. Every job is a stage in the pipeline.

---

### `on:` triggers

```yaml
on:
  push:
    branches: [main]
    paths: ['app/**', 'charts/**']
  pull_request:
    branches: [main]
    paths: ['app/**', 'charts/**']
```
```
paths: ['app/**', 'charts/**']:
  Only runs when Java source code or Helm templates change.
  A change to terraform/ or gitops/ does NOT trigger this pipeline.
  WHY: Terraform changes are infrastructure. App changes are code.
  Separate concerns → separate pipelines → separate risk.

push to main = PR was merged → run the full promotion chain.
pull_request = PR opened → run only Job 1 (unit tests).
  Note: Jobs 2-7 all have: if: github.event_name == 'push'
  So on a PR: only tests run. No image built, no deploy.
```

---

### `env:` — Global Variables

```yaml
env:
  AWS_REGION:     ap-northeast-1
  IMAGE_TAG:      ${{ github.sha }}
  JAVA_VERSION:   '21'
  ECR_DEV:        123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  ECR_STAGING:    123456789011.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  ECR_PRODUCTION: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
```
```
IMAGE_TAG = ${{ github.sha }}:
  The full git commit SHA (e.g., "a1b2c3d4e5f6...").
  Every image has a unique, immutable, traceable tag.
  "Which code is running in production?" → tag "a1b2c3" → git show a1b2c3 → exact code.
  NEVER use :latest in production — it's mutable and untraceable.

Three separate ECR registries (one per AWS account):
  Each account has its own ECR repository.
  An image in DEV ECR cannot be accidentally deployed to production.
  Promotion = explicit copy: docker pull DEV → docker tag → docker push STAGING.
  The image digest (SHA256) is identical after copying — no rebuild.
  What you test in dev is EXACTLY what runs in production.
```

---

### Job 1: Unit Tests + JaCoCo Coverage

```yaml
test:
  steps:
    - uses: actions/setup-java@v4
      with: { java-version: '21', distribution: 'temurin', cache: 'gradle' }

    - name: Cache Gradle build
      uses: actions/cache@v4
      with:
        key: ${{ runner.os }}-gradle-${{ hashFiles('app/build.gradle') }}-${{ hashFiles('app/src/**/*.java') }}

    - name: Test + coverage
      run: ./gradlew test jacocoTestReport jacocoTestCoverageVerification --no-daemon

    - uses: mikepenz/action-junit-report@v4
      if: always()
      with: { report_paths: 'app/build/test-results/test/*.xml' }
```
```
cache: 'gradle' in actions/setup-java:
  Caches ~/.gradle/caches (downloaded dependency JARs).
  Without: every CI run downloads ~200MB from Maven Central → 3-4 min.
  With cache: only new/changed deps downloaded → 15-30 seconds.

hashFiles('app/build.gradle')-${{ hashFiles('app/src/**/*.java') }}:
  The cache key includes hashes of BOTH:
    build.gradle: if dependencies change → new cache key → re-download.
    src/**/*.java: if source changes → new key → re-compile from scratch.
  Guarantees: compiled classes never come from a stale cache.

--no-daemon:
  Don't start the Gradle background daemon.
  CI containers are ephemeral — daemon starts, builds once, then the container dies.
  No benefit from keeping a daemon alive. Saves ~200MB memory.

jacocoTestCoverageVerification:
  Checks: is line coverage ≥ 70%?
  If NO: Gradle exits with code 1 → CI job fails → PR cannot be merged.
  Engineers cannot ship untested code. The gate is automatic.

mikepenz/action-junit-report@v4 (if: always()):
  Parses build/test-results/test/*.xml → adds inline PR annotations.
  "PaymentControllerTest.createPayment_missingAmount_returns400 FAILED at line 45"
  Visible directly on the PR diff — no digging in CI logs.
  if: always() = runs even if tests fail → you still get the report.
```

---

### Job 2: Build + Deploy Dev

```yaml
build-deploy-dev:
  needs: test
  if: github.event_name == 'push'
  environment: dev
  permissions:
    id-token: write    # OIDC to AWS
    contents: write    # commit image tag back to gitops
```
```
needs: test:
  Only starts AFTER Job 1 passes.
  If tests fail → this job never runs → image never built → nothing deployed.
  The test gate is enforced at the job dependency level, not by the script.

if: github.event_name == 'push':
  Only runs on merge to main. NOT on PR open/update.
  On a PR: only Job 1 (tests) runs. No image builds, no deploys.
  Prevents dev environment from being deployed on every draft PR push.

environment: dev:
  References GitHub Environment named "dev".
  Provides: deployment history, audit trail of who deployed when.
  Can add protection rules later (e.g., required reviewer before dev deploy).
  Currently: no approval gate for dev. Fast iteration.

contents: write:
  Required because this job commits back to the repo (image tag update).
  Without: git push fails with "Permission denied (403)".
```

**Build step:**
```yaml
- name: Build + push Dev ECR
  uses: docker/build-push-action@v5
  with:
    platforms: linux/amd64,linux/arm64
    cache-from: type=gha
    cache-to: type=gha,mode=max
```
```
platforms: linux/amd64,linux/arm64:
  Builds two images in one step, stored as a Docker manifest.
  linux/arm64 = Graviton EKS nodes. linux/amd64 = Intel nodes.
  Karpenter provisions arm64 Graviton nodes → pulls arm64 layer automatically.
  No code change needed. The manifest handles architecture selection.

cache-from/cache-to: type=gha:
  Uses GitHub Actions cache for Docker layer caching.
  Without: every build downloads the eclipse-temurin JRE (~180MB) from Docker Hub.
  With: JRE layer is cached → only changed Spring Boot layers rebuild.
  Java Dockerfile layer order: JRE (stable) → dependencies (changes on build.gradle update) → code (changes every commit).
  Correctly ordered → only the code layer (1-2MB) rebuilds per commit.
```

**Trivy scan:**
```yaml
- name: Trivy scan (CRITICAL + HIGH)
  uses: aquasecurity/trivy-action@0.28.0
  with:
    severity: 'CRITICAL,HIGH'
    exit-code: '1'
```
```
CRITICAL + HIGH (not just CRITICAL like Python version):
  Java JARs carry more transitive dependencies than Python packages.
  HIGH vulnerabilities in Java's ecosystem are more exploitable.
  Stricter gate: either fix the dependency or accept the risk deliberately.

exit-code: '1':
  If any CRITICAL or HIGH CVE found → image is pushed to ECR but NOT deployed.
  The gitops update step only runs if ALL previous steps passed.
  A vulnerable image sits in ECR but never reaches Kubernetes.
```

**GitOps update:**
```yaml
- name: Update dev gitops image tag
  run: |
    sed -i "s|tag: \".*\"|tag: \"${{ env.IMAGE_TAG }}\"|" \
      gitops/dev/app/payment-service/payment-service.yaml
    git commit -m "chore(deploy-dev): ${{ env.IMAGE_TAG }} [skip ci]"
    git push
```
```
sed replaces the tag field IN-PLACE. From:
  tag: "old-sha"
To:
  tag: "new-sha-abc1234"

ArgoCD watches this file. When it changes:
  ArgoCD computes diff: desired tag "new-sha" ≠ running tag "old-sha".
  ArgoCD applies: Kubernetes updates the Deployment image.
  Rolling update starts: new pod created → passes readinessProbe → old pod terminated.

[skip ci] in the commit message:
  This git push triggers the workflow again (it watches main).
  Without [skip ci]: infinite loop (push → CI → push → CI → ...).
  With [skip ci]: GitHub Actions skips the workflow for this commit.
```

**Wait for Java rollout:**
```yaml
- name: Wait for dev rollout (Java — 8 min)
  run: |
    sleep 30
    kubectl rollout status deployment/payment-service \
      -n payment-ns --context dev --timeout=8m
```
```
sleep 30:
  ArgoCD detects gitops changes every ~3 minutes (polling).
  Or immediately via webhook if configured.
  The 30s sleep gives ArgoCD time to detect the new tag and start the rollout.
  Without sleep: kubectl rollout status starts before the rollout begins → exits immediately.

--timeout=8m:
  Java Spring Boot startup on t3.medium (dev):
    JVM init: 2-5s
    Spring context loading: 10-20s
    Hibernate schema validation + HikariCP pool init: 10-20s
    startupProbe passing: another 10s
  Total: 1-3 minutes on a warm node, 3-8 minutes on a cold node (first deploy).

  Python equivalent: 1-2 minutes. Java needs 4x more time.
  8 min gives margin for slow cold starts without being impractically long.
```

---

### Job 3: Smoke Tests — Dev

```yaml
smoke-test-dev:
  needs: build-deploy-dev

  - name: Wait for JVM warmup
    run: sleep 30   # allow JIT compilation before smoke tests

  - name: Actuator liveness
    run: |
      R=$(curl -sf https://payment.dev.company.com/actuator/health/liveness)
      python3 -c "import json,sys; d=json.loads('$R'); assert d['status']=='UP'"

  - name: Actuator readiness (DB check)
    run: |
      R=$(curl -sf https://payment.dev.company.com/actuator/health/readiness)
      python3 -c "import json,sys; d=json.loads('$R'); assert d['status']=='UP'"
```
```
sleep 30 before smoke tests (JVM warmup):
  JVM JIT compilation runs for ~30-60 seconds after the JVM starts.
  During JIT compilation: first requests are interpreted → 5-20× slower than steady state.
  Running smoke tests during warmup: latency assertions fail on a healthy service.
  sleep 30 → JIT completes → tests see real performance.

DIFFERENT PROBE PATHS vs Python:
  Python:  /health/live, /health/ready  (custom FastAPI endpoints)
  Java:    /actuator/health/liveness, /actuator/health/readiness  (Spring Actuator)
  Must use the correct path for the framework.

Actuator liveness check:
  Returns {"status": "UP"} if the Spring ApplicationContext is running.
  If DOWN: the JVM is deadlocked or the Spring container crashed.
  Expected: always UP if the pod passed startupProbe.

Actuator readiness check (includes DB):
  Returns {"status": "UP"} if the DB connection works (ReadinessIndicator runs SELECT 1).
  If DOWN: PostgreSQL is unreachable from this pod.
  This check gates staging promotion: if the DB is broken, staging is not promoted.

python3 assert:
  Parses the JSON response and checks status == "UP".
  If "status": "DOWN": AssertionError → step fails → smoke test job fails → staging NOT promoted.
```

---

### Job 4: Promote Dev → Staging

```yaml
promote-staging:
  needs: smoke-test-dev
  environment: staging

  - name: Auth dev ECR (pull source)
    uses: aws-actions/configure-aws-credentials@v4
    with:
      role-to-assume: arn:aws:iam::123456789010:role/github-actions-ecr-read

  - name: Auth staging ECR (push destination)
    uses: aws-actions/configure-aws-credentials@v4
    with:
      role-to-assume: arn:aws:iam::123456789011:role/github-actions-ecr-push

  - name: Copy image dev → staging
    run: |
      docker pull ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
      docker tag  ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }} \
                  ${{ env.ECR_STAGING }}:${{ env.IMAGE_TAG }}
      docker push ${{ env.ECR_STAGING }}:${{ env.IMAGE_TAG }}
```
```
Two configure-aws-credentials steps in sequence:
  Step 1: assume dev account's ECR-read role → login → docker pull the image.
  Step 2: assume staging account's ECR-push role → login → docker push to staging.
  Each step OVERWRITES the AWS credentials in the environment.
  The second configure-aws-credentials replaces the first.

WHY COPY instead of rebuild:
  Rebuilding: Gradle compiles again, Docker builds again, new image created.
  New image = different binary = different sha256 digest = untested code.
  The dev smoke tests ran against Image A. A rebuild produces Image B.
  Even with the same source code: timestamp differences, dependency versions.

  Copying: docker pull (same bytes) → docker tag (new name, same bytes) → docker push.
  Image digest is IDENTICAL. What dev tested is EXACTLY what staging runs.
  Immutable promotion: the test certificate travels with the artifact.
```

---

### Job 5: Load Test — Staging

```yaml
test-staging:
  needs: promote-staging

  - name: Install k6
    run: |
      sudo gpg --no-default-keyring ...
      sudo apt-get install k6 -y

  - name: Load test (50 VUs, 3 min) — JIT warmup-aware
    run: |
      k6 run --vus 50 --duration 3m \
        --env BASE_URL=https://payment.staging.company.com \
        app/tests/load/payment-load-test.js
```
```
k6 install from official repository:
  ubuntu-latest runners don't have k6 pre-installed.
  Must install via k6's apt repository.
  The GPG key verifies the package signature — prevents supply chain attacks.

--vus 50 --duration 3m:
  50 virtual users running for 3 minutes.
  50 VUs = 50 concurrent HTTP connections.
  For a payment API: simulates 50 users submitting payments simultaneously.
  Real production traffic: much higher. But 50 VUs validates basic capacity.

JIT warmup in load test:
  First 30s: JVM still compiling hot paths → latency is 2-3× higher.
  Staging k6 thresholds in payment-load-test.js:
    p(99) < 800ms  (staging, JIT warmup — NOT 300ms production SLO)
    error_rate < 1%
  If threshold = 300ms (production): test ALWAYS fails in staging due to warmup.
  Relaxed threshold: validates real capacity after warmup, not false JVM warmup failures.

sleep 30 before load test:
  Same JIT warmup wait as smoke tests.
  30s after readiness → JIT has compiled the most common code paths.
  Load test starts in steady-state performance mode.
```

---

### Job 6: Promote Staging → Production (MANUAL APPROVAL)

```yaml
promote-production:
  needs: test-staging
  environment: production   # ← PAUSES HERE

  - name: Copy image staging → production
  - name: Update production gitops
  - name: Wait for production rollout (Java — 12 min, 3 replicas)
    run: kubectl rollout status ... --timeout=12m
```
```
environment: production with required reviewers:
  Configure in: GitHub → Repo Settings → Environments → production → Required reviewers.
  Add: SRE lead, engineering manager.
  When the job reaches this point: GitHub sends email/Slack to approvers.
  Workflow PAUSES — no code runs until an approver clicks Approve.

  What approvers see in the approval modal:
    - Which workflow run
    - Which SHA is being deployed
    - That staging tests passed (previous jobs succeeded)
    - Link to the staging load test results

  They approve → workflow resumes → copy + gitops update happens.
  They reject → workflow stops → no production deploy.

--timeout=12m for production rollout:
  Production: 3 replicas rolling update.
  Rolling update strategy: maxUnavailable=0, maxSurge=1.
  Sequence: 
    Create pod 4 (wait for it to start: up to 4 min for Java) → 
    Remove pod 1 (takes 15s: preStop sleep + graceful drain) →
    Create pod 5 → Remove pod 2 → Create pod 6 → Remove pod 3.
  3 replicas × ~4 min each = ~12 minutes total.
  timeout=12m gives just enough margin without hanging too long on a failure.
```

---

### Job 7: Verify Production + Auto-Rollback

```yaml
verify-production:
  needs: promote-production
  environment: production

  - name: JVM warmup wait
    run: sleep 60

  - name: Production smoke tests
    id: smoke
    run: |
      curl -sf https://payment.company.com/actuator/health/liveness
      curl -sf https://payment.company.com/actuator/health/readiness
      curl -sf https://payment.company.com/api/v1/payments/smoke-test-id
      echo "✅ Production smoke tests passed"

  - name: Auto-rollback on failure
    if: failure() && steps.smoke.outcome == 'failure'
    run: |
      PREV_TAG=$(git log --oneline -- gitops/production/.../payment-service.yaml | \
        awk 'NR==2{print $1}' | xargs git show | grep 'tag:' | ...)
      sed -i "s|tag: \".*\"|tag: \"$PREV_TAG\"|" ...
      git commit -m "chore(rollback-prod): revert to $PREV_TAG [skip ci]"
      git push
```
```
sleep 60 (production JIT warmup):
  Longer than dev/staging (30s).
  Production has 3 replicas. During rolling update: new pods start one by one.
  The newest pod just finished its rolling update → may still be in JIT warmup.
  Smoke tests against the newest pod during warmup: false latency failure.
  sleep 60: all pods have been running for at least 1 minute → JIT complete.

Three checks in production smoke:
  1. /actuator/health/liveness: JVM is alive
  2. /actuator/health/readiness: DB connected
  3. /api/v1/payments/smoke-test-id: actual API responds correctly
  Ordered: basic → dependency check → business logic.
  If any fails: production is broken, rollback immediately.

Auto-rollback logic:
  git log --oneline on the payment-service.yaml file.
  NR==1 = current commit (the one we just deployed).
  NR==2 = previous commit (the last known-good version).
  xargs git show → reads the file at that commit → grep for tag: → extract the SHA.
  
  Then: sed updates the file to the PREVIOUS tag → git commit → git push.
  ArgoCD detects the git change → rolls back the Deployment to the previous image.
  Kubernetes performs a rolling update BACK to the old image.
  No kubectl rollout undo needed — Git is the source of truth.
```

---

## `charts/payment-service/` — Helm Chart (3 Values Files)

---

### `charts/payment-service/values.yaml` — Production Defaults

**What it is:** The base configuration file. Used directly for production. Dev and staging override specific fields.

**Memory sizing:**
```yaml
resources:
  requests:
    cpu: 500m
    memory: 1Gi
  limits:
    cpu: 2000m
    memory: 1536Mi

env:
  - name: JVM_OPTS
    value: >-
      -Xms512m -Xmx1024m
      -XX:+UseContainerSupport
      -XX:MaxRAMPercentage=75.0
```
```
JVM memory formula:
  container_limit = Xmx + non-heap overhead
  non-heap includes: metaspace (~120MB), code cache (~80MB), thread stacks (~50MB)
  = ~250MB non-heap minimum for a Spring Boot app.

  limits.memory = 1536Mi:
    Xmx = 1024m = 1GB heap.
    1024MB + 250MB non-heap + headroom = ~1400MB → 1536Mi limit is safe.

  requests.memory = 1Gi:
    JVM at idle: ~600MB RSS (JVM base + Spring loaded classes).
    Kubernetes scheduler: needs at least 1Gi free on the node.
    Without sufficient request: pod scheduled on a full node → OOM kill on startup.

-XX:+UseContainerSupport (CRITICAL):
  Without: JVM on a 1.5Gi container sees the NODE's memory (32GB on m7g.xlarge).
  JVM default heap = 25% of available RAM = 8GB → OOM kill immediately.
  With: JVM reads the cgroup limit (1536Mi) → MaxRAMPercentage=75 → Xmx=1152MB → fits.

-XX:MaxGCPauseMillis=200:
  Tells G1GC: target max GC pause of 200ms.
  G1GC adjusts heap region sizes and collection frequency to try to stay under 200ms.
  Cannot guarantee it, but guides the GC tuning.
  Without: default is 200ms anyway, but being explicit self-documents the intent.
```

**Startup probe (Java-specific, 10 min):**
```yaml
startupProbe:
  httpGet:
    path: /actuator/health/liveness
  failureThreshold: 60
  periodSeconds: 10
```
```
failureThreshold: 60 × periodSeconds: 10 = 600 seconds = 10 minutes max startup.
Python equivalent: 30 × 10 = 5 minutes.

WHY JAVA NEEDS 10 MIN:
  JVM initialisation: 2-5s
  Spring auto-configuration scans classpath (500+ classes): 10-20s
  JPA entity scanning + Hibernate schema validation: 10-15s
  HikariCP: establishes minimum-idle connections to RDS: 5-10s
  Total on production Graviton node: 30-120s.
  Cold start on first node drain (caches empty): up to 5-8 minutes.

  If failureThreshold is too low:
  Pod reaches the limit during legitimate startup → Kubernetes kills and restarts.
  New pod starts → fails startup probe again → CrashLoopBackOff.
  Symptom: pods never become Ready, always restarting.
  Fix: increase failureThreshold.

/actuator/health/liveness (not /health/live):
  Python FastAPI uses custom endpoints /health/live, /health/ready.
  Spring Boot Actuator uses /actuator/health/liveness, /actuator/health/readiness.
  These are different paths. Using the wrong path → probe hits 404 → endless restart.
```

**Graceful shutdown:**
```yaml
lifecycle:
  preStop:
    exec:
      command: ["/bin/sh", "-c", "sleep 15"]
terminationGracePeriodSeconds: 60
```
```
ALB deregistration timing problem:
  Kubernetes removes a pod from Service endpoints (ALB stops routing here).
  But the ALB's connection draining takes 10-15 seconds.
  During those 15s: ALB still sends in-flight requests to the pod.
  Without preStop sleep: pod starts shutting down → Spring closes Tomcat → requests get 503.
  With preStop sleep 15s: pod waits for ALB to drain → then shuts down cleanly.

terminationGracePeriodSeconds: 60:
  Total time Kubernetes waits after SIGTERM before force-killing (SIGKILL).
  15s preStop + 45s for Spring to:
    1. Stop accepting new requests (Tomcat stops)
    2. Finish in-flight requests (up to 30s for slow payments)
    3. Close DB connections cleanly
    4. JVM shutdown hooks run
  60s total is generous. Most shutdowns complete in 20-30s.
```

**Topology spread (HARD in production):**
```yaml
topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: topology.kubernetes.io/zone
    whenUnsatisfiable: DoNotSchedule   # HARD
```
```
DoNotSchedule (hard) in production:
  Kubernetes scheduler REFUSES to place a pod that would violate maxSkew=1.
  With 3 replicas across 3 AZs: each AZ must have exactly 1 pod.
  If AZ-a has 2 pods and AZ-b has 0: maxSkew = 2 > 1 → scheduler refuses.
  Forces: 1 pod per AZ at all times.

WHY HARD IN PRODUCTION:
  AZ outage is the most common AWS incident.
  If 2 pods are in AZ-a and AZ-a goes down: 66% of capacity lost.
  With hard spread: AZ-a outage loses exactly 1/3 of capacity (1 pod).
  2/3 remain in AZ-b and AZ-c → service stays alive.

COMPARE with staging/dev (ScheduleAnyway — soft):
  Dev/staging may not have 3 AZs available or 3 nodes.
  ScheduleAnyway: scheduler tries to spread but co-locates if no choice.
  Result: dev can work even on a single-node cluster.
```

**LOG_LEVEL: WARN (production):**
```yaml
env:
  - name: LOG_LEVEL
    value: "WARN"
```
```
WARN = only log warnings and errors. No INFO or DEBUG.

WHY WARN IN PRODUCTION:
  Payment service at 1000 req/min with INFO logging:
    1000 requests × ~5 log lines each = 5000 lines/min.
    5000 lines × ~200 bytes = 1MB/min = 1.4GB/day of logs.
    CloudWatch Logs: ~$0.50/GB = $700/month just for INFO logs.

  With WARN: only actual problems are logged.
  Real errors appear clearly without noise.
  Engineers can temporarily switch to INFO for debugging via env var change.
```

---

### `charts/payment-service/values-dev.yaml` — Dev Overrides

**What it is:** Fields that override values.yaml for the dev environment only. Smaller, more permissive, more verbose.

```yaml
replicaCount: 1
image:
  pullPolicy: Always
resources:
  requests: { cpu: 100m, memory: 384Mi }
  limits:   { cpu: 500m,  memory: 512Mi }
```
```
replicaCount: 1:
  Single pod in dev. No HA needed.
  Dev is for testing new code, not serving real users.
  1 pod = faster restarts, less resource consumption on t3.medium.

pullPolicy: Always:
  Kubernetes always pulls the image from ECR on every pod start.
  In dev: engineers might push multiple commits quickly.
  The :latest-dev tag is reused → without Always, Kubernetes uses the cached old image.
  With Always: every restart gets the freshest image.
  Production: IfNotPresent → uses cached image (immutable SHA tag guarantees correctness).

memory.limits: 512Mi:
  Dev JVM heap: Xms128m Xmx256m + ~250MB non-heap = ~506MB → 512Mi limit is tight but OK.
  t3.medium has 4GB RAM total.
  System pods (CoreDNS, kube-proxy, DT OneAgent) use ~600MB.
  Payment-service at 512Mi + system = 1.1GB → fits on 4GB node with room for Karpenter.
```

```yaml
env:
  - name: JVM_OPTS
    value: >-
      -Xms128m -Xmx256m
      -XX:+UseContainerSupport
      -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005
```
```
-Xms128m -Xmx256m (tiny heap for dev):
  Dev: no real traffic. Minimal heap is fine.
  -Xms128m: JVM starts with 128MB heap (lower startup memory).
  -Xmx256m: JVM can grow to max 256MB heap.
  
  WHY NOT USE MaxRAMPercentage for dev:
  t3.medium: 4GB RAM. 75% of 512Mi container = 384MB heap.
  384MB > 256MB (which is what we want for a tiny dev JVM).
  Explicit Xmx overrides MaxRAMPercentage. Use explicit values in dev for predictability.

-agentlib:jdwp (Java Debug Wire Protocol):
  Enables remote debugging on port 5005.
  Usage:
    kubectl port-forward -n payment-ns pod/<name> 5005:5005
    In IntelliJ: Run → Debug → Remote JVM Debug → port 5005.
  Engineers can: set breakpoints, inspect variables, evaluate expressions.
  suspend=n: JVM does NOT wait for debugger to connect before starting.
  Without suspend=n: pod starts → waits for debugger → never passes startupProbe → killed.
  ONLY in dev. Never in staging or production (major security risk, also slow).
```

```yaml
startupProbe:
  failureThreshold: 120   # 20 minutes max startup
  periodSeconds: 10
pdb:
  enabled: false
topologySpreadConstraints:
  - whenUnsatisfiable: ScheduleAnyway   # SOFT
```
```
failureThreshold: 120 (20 min):
  Dev worst case: Docker layer cache expired after long weekend.
  Full image pull (180MB JRE + 50MB app) from ECR: 2-3 minutes.
  Gradle compiled inside Docker (build cache expired): 3-5 minutes.
  Spring context cold start on t3.medium: 3-5 minutes.
  Total: up to 15 minutes from pod scheduled to /actuator/health/liveness → 200.
  120 × 10s = 20 minutes covers this with margin.

pdb: enabled: false:
  A PodDisruptionBudget with minAvailable=1 on a single-pod deployment
  prevents Kubernetes from EVER draining the node containing that pod.
  Node drain is required for: EKS node upgrades, Spot interruptions, Karpenter consolidation.
  With PDB + 1 replica: node can never be drained → upgrade blocked forever.
  Dev with 1 replica → no PDB. Let the pod be evicted freely.

ScheduleAnyway (soft spread):
  Dev cluster: 1-2 nodes, maybe only 1 AZ.
  Hard spread (DoNotSchedule) requires 3 nodes in 3 AZs to place 3 pods.
  With 1 replica and 1 node: hard spread is impossible → pod stays Pending forever.
  ScheduleAnyway: spreads if possible, co-locates if not. Dev works on any node count.
```

---

### `charts/payment-service/values-staging.yaml` — Staging Overrides

**What it is:** Between dev and production. Must handle the k6 load test. Still smaller than production.

```yaml
replicaCount: 2
resources:
  requests: { cpu: 200m, memory: 512Mi }
  limits:   { cpu: 800m,  memory: 768Mi }
env:
  - name: LOG_LEVEL
    value: "INFO"
  - name: JVM_OPTS
    value: "-Xms256m -Xmx512m ..."
```
```
replicaCount: 2:
  2 replicas = 1 per AZ (staging usually has 2 AZs active).
  Enough for the k6 load test (50 VUs ÷ 2 pods = 25 VUs per pod).
  Basic HA: if 1 pod fails during load test → 1 remaining handles traffic.

LOG_LEVEL: INFO (not WARN like production, not DEBUG like dev):
  Staging: more visibility for pre-production debugging.
  INFO shows: service starting, request counts, DB connection events.
  Helps: "why did the load test fail?" → check logs for DB connection errors.
  WARN would miss these informational events.
  DEBUG would be too noisy (50 VUs × 5 debug lines/req = 250 lines/second).

-Xmx512m (staging, vs 1024m production):
  Staging needs less heap: 2 replicas vs 3, fewer users.
  512m heap + 250m non-heap = ~760MB → 768Mi limit.
  During load test: heap usage may spike to 400MB → still under 512m max.
  This is what the staging DT threshold jvm_heap_pct=78 monitors.
```

```yaml
hpa:
  minReplicas: 2
  maxReplicas: 8    # k6 50 VUs may trigger scale-out

pdb:
  enabled: true
  minAvailable: 1
```
```
maxReplicas: 8:
  k6 sends 50 VUs. If each pod handles 10 req/s: 50 VUs = 5 req/s per pod.
  HPA at 70% CPU: under load test, pods scale out.
  maxReplicas: 8 gives 4× headroom (2 → 8 pods under load).
  Production: maxReplicas 20 (real traffic can be 10× higher than staging).

pdb minAvailable: 1:
  2 replicas → at most 1 can be disrupted.
  During k6 load test + a node drain: 1 pod stays alive.
  Traffic continues (at half capacity) while the other pod is replaced.
  Without PDB: both pods could be evicted simultaneously → 100% downtime during load test.
```

---

## `gitops/` — ArgoCD Applications Per Environment

---

### `gitops/dev/bootstrap/root-app-dev.yaml`

**What it is:** The single file applied once to bootstrap the dev ArgoCD instance.

```yaml
spec:
  source:
    path: gitops/dev
    directory:
      recurse: true
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```
```
path: gitops/dev + recurse: true:
  ArgoCD watches the ENTIRE gitops/dev/ folder tree recursively.
  Every YAML file in gitops/dev/ that contains an ArgoCD Application is discovered and managed.
  Add a new component: create gitops/dev/some-new-thing/app.yaml → ArgoCD finds it automatically.
  No manual registration needed.

prune: true:
  Delete resources from the cluster that are no longer in gitops/dev/.
  Remove a file from gitops/dev/ → the component it manages is deleted from the cluster.
  Prevents orphaned resources accumulating in dev (common without GitOps discipline).

selfHeal: true:
  If an engineer runs kubectl edit on something in dev → ArgoCD reverts it within 3 minutes.
  Forces: all changes go through Git. Manual kubectl is temporary.
  WHY IN DEV: trains engineers on GitOps workflow before they are doing it in production.
  Good habits form in dev, natural in production.
```

---

### `gitops/dev/namespaces/namespaces.yaml`

**What it is:** ArgoCD Application (sync-wave -1) that creates all Kubernetes Namespaces for dev.

```yaml
annotations:
  argocd.argoproj.io/sync-wave: "-1"
helm:
  values: |
    environment: dev
    namespaces:
      - name: payment-ns
        team: payments
        environment: dev
```
```
sync-wave: "-1":
  Negative wave number = deploys BEFORE wave 0, 1, 2, etc.
  Namespaces must exist before any pods can be scheduled into them.
  If payment-ns doesn't exist: payment-service Deployment → "namespace not found" → fails.
  Wave -1 guarantees namespaces exist before ANYTHING else tries to deploy.

team: payments + environment: dev labels:
  Dynatrace OneAgent reads Kubernetes labels from pod metadata.
  Pods inherit namespace labels via Kyverno policies.
  Auto-tagging rule in DT: "if pod has label team=payments → tag entity with team:payments".
  management zone rule: "include entities where tag team:payments AND environment:dev".
  Without these labels: payment-service entities are unscoped → wrong management zone → wrong alerts.
```

---

### `gitops/dev/app/payment-service/payment-service.yaml`

**What it is:** ArgoCD Application for payment-service in the dev cluster.

```yaml
spec:
  project: payments   # locked to payment-ns only

  source:
    helm:
      valueFiles:
        - values.yaml        # base (production defaults)
        - values-dev.yaml    # dev overrides

      values: |
        image:
          repository: 123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
          tag: "PLACEHOLDER"
        serviceAccount:
          annotations:
            eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-payment-service

  syncPolicy:
    syncOptions:
      - Timeout=900          # 15 min: Java startup is slow
  ignoreDifferences:
    - group: apps
      kind: Deployment
      jsonPointers:
        - /spec/replicas     # HPA manages this; don't fight it
```
```
project: payments:
  ArgoCD AppProject "payments" restricts this Application to deploy ONLY to payment-ns.
  The payment team cannot accidentally deploy to kube-system or dynatrace namespace.
  Blast radius control at the GitOps layer.

valueFiles: [values.yaml, values-dev.yaml]:
  Helm merges these from left to right.
  values.yaml: base production settings (replicaCount: 3, memory: 1Gi, ...)
  values-dev.yaml: overrides specific fields (replicaCount: 1, memory: 512Mi, ...)
  Only overridden fields appear in values-dev.yaml.
  Fields NOT in values-dev.yaml: inherited unchanged from values.yaml.
  New production feature added to values.yaml: automatically available in dev without editing values-dev.yaml.

tag: "PLACEHOLDER":
  CI replaces this with the actual SHA on every deploy.
  In the repo: "PLACEHOLDER" is a safe sentinel showing "no real image yet".
  After first CI run: "PLACEHOLDER" → "a1b2c3d4...".
  ArgoCD sees the tag changed → triggers a sync → rolling update.

eks.amazonaws.com/role-arn: (DEV account IAM role):
  Each environment's payment-service pod uses a DIFFERENT IAM role.
  Dev role: can read dev Secrets Manager, dev S3 only.
  Production role: can read prod Secrets Manager, prod S3 only.
  Cross-environment access is impossible by IAM design.
  A misconfigured dev pod cannot read production database credentials.

Timeout=900 (ArgoCD):
  ArgoCD default health check timeout is lower.
  Java pod with startupProbe failureThreshold=120 (20 min) in dev.
  Without Timeout=900: ArgoCD declares the sync "Degraded" before the pod even finishes starting.
  With Timeout=900: ArgoCD waits 15 minutes for all resources to become Healthy.

ignoreDifferences on /spec/replicas:
  HPA automatically adjusts spec.replicas based on CPU usage.
  ArgoCD sees: desired spec.replicas=1 (from Helm) vs actual spec.replicas=2 (from HPA).
  Without ignoreDifferences: ArgoCD immediately scales back to 1, fighting the HPA.
  With ignoreDifferences: ArgoCD ignores the replicas field → HPA wins.
  Critical: without this, HPA-driven scaling is immediately reversed.
```

---

### `gitops/staging/app/payment-service/payment-service.yaml`

**What it is:** Same structure as dev, different AWS account, staging-specific values.

```yaml
valueFiles:
  - values.yaml
  - values-staging.yaml
values: |
  image:
    repository: 123456789011.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  ingress:
    certArn: arn:aws:acm:ap-northeast-1:123456789011:certificate/staging-xxx
```
```
Staging ECR (123456789011):
  The same image SHA, now in the staging AWS account's ECR.
  Staging ArgoCD cannot pull from dev ECR (cross-account without explicit permission).
  ECR account isolation forces the image to be explicitly copied before staging can use it.
  Accidental "deploy dev image to staging" is impossible — wrong account.

Real ACM certificate in staging:
  Staging uses a real HTTPS certificate (not empty certArn like dev).
  Load test must run against HTTPS (as production would).
  An HTTP-only staging would not test TLS overhead, cipher negotiation, certificate validation.
  If TLS terminates correctly in staging: it will in production.
```

---

### `gitops/production/app/payment-service/payment-service.yaml`

**What it is:** Production config. Uses only values.yaml (no override). Strictest settings.

```yaml
source:
  helm:
    valueFiles:
      - values.yaml   # production IS the base — no override needed
syncOptions:
  - Timeout=900
ignoreDifferences:
  - jsonPointers: [/spec/replicas]
```
```
values.yaml only (no override file):
  Production config lives in values.yaml.
  Dev/staging override values.yaml with their simpler settings.
  Production uses values.yaml as-is — it IS the production config.
  This design means: values.yaml reflects production reality.
  Any change to values.yaml is a production change → requires PR review.

Timeout=900 (production too):
  3 replicas rolling update on production Graviton nodes.
  Each pod: JVM startup 30-120s + readinessProbe cycles.
  Total rolling update: 3 pods × 2 minutes each = ~6 minutes.
  With network latency, probe intervals, slow DB connections: 10-15 minutes total.
  Timeout=900 (15 min) covers this without risking false timeouts.
```

---

## `terraform/environments/` — AWS Infrastructure Per Account

---

### `terraform/environments/dev/terraform.tfvars`

```hcl
node_instance_types = ["t3.medium", "t3a.medium"]
node_min_size       = 2
vpc_cidr            = "10.10.0.0/16"
```
```
t3.medium AND t3a.medium (two instance types):
  Both are 2 vCPU, 4GB RAM — one Intel (t3), one AMD (t3a).
  Two types → two Spot instance pools → if t3.medium Spot is unavailable, use t3a.medium.
  Karpenter manages diversification automatically.

node_min_size = 2:
  2 system nodes minimum.
  One system node handles: CoreDNS, kube-proxy, DT OneAgent, ESO, Karpenter.
  Second node provides redundancy (if one node is replaced/upgraded: system components survive).
  
vpc_cidr = "10.10.0.0/16":
  Different /16 block from staging (10.11.0.0/16) and production (10.12.0.0/16).
  VPC peering (cross-env connectivity) requires non-overlapping CIDRs.
  With overlapping: peering is impossible → environments cannot communicate if needed.
  Non-overlapping from the start: peering can be added later without VPC recreation.
```

---

### `terraform/environments/staging/terraform.tfvars`

```hcl
node_instance_types = ["m6g.large", "m6g.xlarge"]
node_min_size       = 3
vpc_cidr            = "10.11.0.0/16"
```
```
m6g.large AND m6g.xlarge (Graviton, different sizes):
  m6g.large: 2 vCPU, 8GB — handles normal staging traffic.
  m6g.xlarge: 4 vCPU, 16GB — for the k6 load test when HPA scales pods.
  Two sizes: Karpenter picks the cheapest that fits. 8 pods during load test → xlarge.
  m6g (6th gen Graviton) in staging vs m7g (7th gen) in production:
  Slight performance difference is acceptable for pre-production testing.
  Using the same FAMILY (Graviton) validates arm64 compatibility in staging.

node_min_size = 3:
  3 nodes = 1 per AZ.
  Realistic HA testing: staging simulates production topology.
  2-node staging wouldn't reveal AZ-boundary issues.
  3 AZs: if load test causes OOM on node in AZ-a → AZ-b and AZ-c still serve traffic.
  Validates: the system survives real AZ-level disruptions.
```

---

### `terraform/environments/production/terraform.tfvars`

```hcl
node_instance_types = ["m7g.xlarge", "m7g.2xlarge"]
node_min_size       = 3
node_max_size       = 15
vpc_cidr            = "10.12.0.0/16"
```
```
m7g.xlarge AND m7g.2xlarge (Graviton3):
  m7g = latest Graviton3. Best price/performance of any Graviton generation.
  xlarge: 4 vCPU, 16GB — handles most system + application loads.
  2xlarge: 8 vCPU, 32GB — for Karpenter to provision when a workload needs more.
  Karpenter chooses the smallest that fits → optimises cost automatically.

node_max_size = 15:
  System node group: max 15 nodes.
  Application workload nodes: managed by Karpenter (separate, not in this count).
  15 system nodes × m7g.xlarge = 240 vCPU / 480GB RAM ceiling for system components.
  Protects against: a misconfigured workload requesting thousands of system nodes.
```

---

## `terraform/dynatrace/` — Monitoring Thresholds Per Environment

---

### `terraform/dynatrace/dev.tfvars`

```hcl
latency_p99_ms    = 2000
jvm_heap_pct      = 80
traffic_min_rps   = 0
is_jvm_service    = true
```
```
latency_p99_ms = 2000 (2 seconds):
  Dev JVM on t3.medium: JIT not warmed up → first requests 2-10× slower than production.
  If threshold = 300ms (production): alert fires constantly during dev testing → alert fatigue.
  Engineers ignore alerts → they miss real problems.
  2000ms: only fires on genuinely broken behaviour, not normal dev slowness.

jvm_heap_pct = 80:
  Dev heap is tiny: Xmx=256MB.
  Spring Boot + Hibernate preloads: ~180MB at idle.
  180/256 = 70% heap used at idle. Any request → 80% quickly.
  If threshold = 75% (production): alert fires constantly at idle.
  80%: only fires when actually close to OOM.

traffic_min_rps = 0 (traffic drop alert DISABLED):
  Dev has no real users. Traffic is zero most of the time.
  Enabling this at any threshold: constant "silent outage" alerts when nobody is testing.
  0 = disable the alert entirely.
  Production: 10 req/min minimum (payment service always has users).

is_jvm_service = true:
  Activates JVM heap monitoring (dynatrace_metric_events.jvm_heap resource created).
  For non-Java services: this would be set false → no heap metric event created.
  Dynatrace metric key builtin:process.memory.jvm.heapUtilization only exists for JVM processes.
  Creating heap alerts for a Go service: metric returns null → alert never fires (wasted config).
```

---

### `terraform/dynatrace/staging.tfvars`

```hcl
latency_p99_ms  = 800
jvm_heap_pct    = 78
traffic_min_rps = 2
```
```
latency_p99_ms = 800 (staging, 2× production):
  k6 load test: first 30s = JIT warmup period → latency up to 3× higher.
  If threshold = 300ms: alert fires during warmup → blocks staging CI.
  After 30s: JIT done → latency drops to ~200-250ms steady state.
  800ms: accommodates warmup without firing false alerts.

traffic_min_rps = 2:
  Staging has the k6 load test. Traffic should be > 0 at all times during test.
  2 req/min = minimum viable traffic signal.
  If traffic drops to 0 during a load test run: something broke → alert correctly.
  Validates: the traffic drop signal works in staging before production relies on it.

jvm_heap_pct = 78:
  Staging heap: Xmx=512MB.
  Under k6 load: heap usage rises to 350-400MB = 68-78% of 512MB.
  Alert at 78%: fires only when approaching real GC pressure, not normal load.
  GC thrashing starts around 85-90% → 78% gives engineers time to act.
```

---

### `terraform/dynatrace/production.tfvars`

```hcl
latency_p99_ms    = 300
jvm_heap_pct      = 70
traffic_min_rps   = 10
error_rate_alert  = 0.1
pod_restart_threshold = 2
```
```
jvm_heap_pct = 70 (strictest, earlier warning):
  Production heap: Xmx=1024MB.
  Normal load: heap 30-50%. G1GC keeps this low on modern JVM.
  Sustained high load: heap climbs to 60-70%.
  At 70%: G1GC starts more frequent minor GCs → p99 latency increases 20-50ms.
  Alert at 70%: catch this BEFORE users notice latency degradation.
  Scale out (add replicas) → heap per pod drops → GC relaxes.
  Leading indicator: act on this before error_rate or latency alerts fire.

traffic_min_rps = 10:
  Payment service: real users 24/7. Even at 3am in Tokyo: ~10 req/min.
  If traffic drops below 10: something is wrong with routing/DNS/ALB.
  The most important signal: catches silent outages that all other signals miss
  (error rate = 0% when traffic = 0).

error_rate_alert = 0.1 (0.1%):
  Very strict. 1 failed payment per 1000 = alert.
  Payments handle real money. A 0.1% error rate = failed transactions.
  Every failed payment = a customer complaint or lost revenue.
  Lower threshold = faster detection = less money lost.

pod_restart_threshold = 2:
  Any pod in CrashLoopBackOff in production = immediate investigation.
  2 restarts in 5 minutes = crash loop.
  Production pods should NEVER restart in normal operation.
  Even 1 restart is suspicious (OOM kill, configuration error, DB timeout).
  2 = catches crash loops without alerting on single transient restarts.
```
