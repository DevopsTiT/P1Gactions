# Per-File Deep Dive — Glossary

**FastAPI**
A Python web framework for building HTTP APIs. Uses type hints for automatic request validation and OpenAPI documentation. Dynatrace OneAgent supports auto-instrumentation — HTTP request traces are captured without any code changes.

**Uvicorn**
An ASGI server that runs FastAPI applications. `[standard]` extra installs C-based components for higher throughput. The production command: `python main.py` which calls `uvicorn.run(app, ...)`.

**Liveness probe (`/health/live`)**
Kubernetes health check answering "is the process alive?" Returns 200 if the process is running. Should NOT check external dependencies. If it returns non-200, the container is restarted.

**Readiness probe (`/health/ready`)**
Kubernetes health check answering "is the pod ready for traffic?" Returns 200 when all dependencies are available. If it returns non-200, the pod is removed from the Service endpoint list but NOT restarted.

**Startup probe**
Kubernetes probe that disables liveness/readiness probes during application startup. Prevents premature restarts of slow-starting apps. Once startup succeeds, normal probes take over.

**Multi-stage Docker build**
A Dockerfile technique with a "builder" stage (with build tools) and a "runtime" stage (without build tools). Final image is 40-60% smaller and has fewer attack vectors.

**Non-root container user**
Running the container process as UID 1000 (not root). If a container escape vulnerability is exploited, the attacker gets limited permissions on the host rather than root access.

**Multi-architecture Docker image**
A single image manifest that contains variants for multiple CPU architectures (amd64 and arm64). Kubernetes automatically selects the correct variant per node. Required for Graviton (arm64) nodes.

**OIDC (GitHub Actions)**
OpenID Connect authentication. GitHub Actions gets temporary AWS credentials by exchanging a GitHub-issued JWT for an AWS STS token. No stored access keys. The IAM role trust policy restricts to specific repo/branch.

**`id-token: write` permission**
Required GitHub Actions job permission for OIDC. Without it, the `aws-actions/configure-aws-credentials` step cannot request a GitHub OIDC token.

**`[skip ci]`**
A Git commit message convention. When CI commits a file update, including `[skip ci]` prevents the commit from triggering another CI run, avoiding an infinite loop.

**Trivy**
Open-source container image vulnerability scanner. Checks OS packages and application dependencies against CVE databases. `exit-code: 1` fails the pipeline on CRITICAL findings.

**ArgoCD sync wave**
An integer annotation (`argocd.argoproj.io/sync-wave`) controlling deployment order. Lower numbers deploy first. Wave N does not start until all wave N-1 resources are healthy.

**`prune: true` (ArgoCD)**
Deletes Kubernetes resources when their YAML is removed from Git. Without prune: deleted manifests leave orphaned resources running forever.

**`selfHeal: true` (ArgoCD)**
Reverts manual `kubectl` changes back to Git state. Enforces "Git is the only way to change the cluster."

**`recurse: true` (ArgoCD)**
Makes ArgoCD scan all subdirectories of the source path for Kubernetes YAML files. Required for App-of-Apps root to discover nested applications.

**AppProject (ArgoCD)**
An RBAC boundary restricting which source repos, destination namespaces, and resource types Applications can use. `payments` project locks to `payment-ns` only; `platform` project is cluster-wide.

**`clusterResourceWhitelist`**
An AppProject setting listing allowed cluster-scoped resource types. Empty (`[]`) means the project cannot create ClusterRoles, CRDs, or any cluster-level resource.

**`prevent_destroy = true`**
A Terraform lifecycle setting blocking resource deletion via `terraform destroy`. Applied to DT Management Zones (deletion breaks alerting) and SLOs (deletion loses compliance history).

**`violating_samples`**
Number of consecutive metric evaluations exceeding a threshold before a Dynatrace Problem is created. `3` = 3 consecutive minutes above threshold. Filters single-minute deployment spikes.

**`dealerting_samples`**
Number of consecutive evaluations below threshold before the Dynatrace Problem closes. Must be higher than `violating_samples` to prevent flapping (rapid open/close cycles).

**`event_entity_dimension_key`**
A DT Terraform field attaching a Problem to a specific entity type (`dt.entity.service`). Without it, Problems are entity-less and cannot be matched by Management Zone rules — alerts never fire.

**Burn rate (DT SLO)**
How fast the error budget is consumed. Burn rate 14.4 = budget exhausted in 2 days. Alerts fire before the SLO actually breaches, giving time to respond.

**`-1M` rolling window (DT SLO)**
Rolling 30-day SLO evaluation. Always evaluates the most recent 30 days — incidents stay in scope for 30 days after they occur, preventing month-reset gaming.

**Spot interruption queue (SQS)**
An SQS queue receiving Spot instance termination warnings from EventBridge. Karpenter polls this queue and drains nodes proactively before the 2-minute hard termination window.

**`iam:PassRole` scoping**
Restricting `iam:PassRole` to a specific role ARN prevents privilege escalation. Without scoping, a service with PassRole could assign an admin role to new EC2 instances.

**DynaKube**
A Dynatrace custom resource configuring what the Operator deploys: OneAgent DaemonSet mode, log monitoring settings, ActiveGate capabilities and replica count.

**`logMonitoring: enabled: true`**
A DynaKube setting making OneAgent collect container logs directly from `/var/log/containers/`. Eliminates the need for Fluent Bit + Loki as separate log infrastructure.

**`installCRD: true` (DT Helm)**
Ensures the `DynaKube` CRD is registered when the Helm chart installs. Without it, the DynaKube resource in the same file fails with "no matches for kind DynaKube."

**`karpenter.sh/discovery` tag**
An AWS tag applied to private subnets and node security groups by Terraform. Karpenter reads this tag to discover which subnets and security groups to use when provisioning new EC2 nodes.

**`consolidateAfter: 30s` (Karpenter)**
How long a node must be underutilised before Karpenter moves its pods elsewhere and terminates it. 30 seconds = aggressive cost optimisation.

**Spot + on-demand fallback**
Karpenter tries Spot instances first (60-80% cheaper). If no Spot capacity is available in any AZ, it falls back to on-demand. Without on-demand fallback, pending pods stay unscheduled during Spot scarcity.

**`domainFilters` (ExternalDNS)**
Restricts ExternalDNS to only manage DNS records within specified domains. Without it, ExternalDNS attempts to modify ALL Route53 zones in the account.

**`txtOwnerId` (ExternalDNS)**
A unique identifier ExternalDNS stamps on its DNS records via TXT records. Only modifies records with matching ownership. Essential for multi-cluster setups to prevent DNS conflicts.

**`policy: sync` (ExternalDNS)**
Creates AND deletes Route53 records to match Ingress state. The alternative `upsert-only` only creates/updates — orphaned records accumulate when Ingresses are deleted.
