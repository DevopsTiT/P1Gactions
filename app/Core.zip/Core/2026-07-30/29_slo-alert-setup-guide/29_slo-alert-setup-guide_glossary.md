# SLO + Alert Setup Guide — Glossary

**SLO (Service Level Objective)**
A precise, measurable reliability target for a service. Example: "99.9% of payment requests succeed over 30 days." Converts vague questions like "is the service healthy?" into a single number everyone can reason about.

**SLA (Service Level Agreement)**
A contractual commitment to customers with financial penalties for breach. The SLO is the internal target — always stricter than the SLA to give a safety buffer. If SLA = 99.9%, set SLO = 99.95%.

**SLI (Service Level Indicator)**
The specific metric used to measure an SLO. For availability: `(successful_requests / total_requests) × 100`. For latency: `(requests_under_threshold / total_requests) × 100`. The SLI is the input; the SLO is the target on that input.

**Error Budget**
The allowed amount of unreliability within an SLO. For 99.9% SLO over 30 days: error budget = 0.1% × 43,200 minutes = 43.2 minutes of allowed downtime. Every minute of degraded service consumes budget.

**Error Budget Policy**
Written team agreement on how to use error budget. Example: ">50% remaining = freely deploy. 10-50% remaining = cautious deploys. <10% = no feature work, only reliability work. 0% = stop everything, fix now."

**Burn Rate**
How fast error budget is being consumed. Burn rate 1.0 = sustainable (budget lasts exactly 30 days). Burn rate 14.4 = budget gone in 2 days. Burn rate 3.0 = budget gone in 10 days.

**`fast_burn_threshold = 14.4`**
A Dynatrace SLO setting: alert when the last 1 hour of data shows 14.4× the sustainable error rate. At this rate, the 30-day error budget would be exhausted in 2 days. Routes to CRITICAL tier (PagerDuty call).

**`slow_burn_threshold = 3.0`**
A Dynatrace SLO setting: alert when 6 hours of data shows 3× the sustainable error rate. Budget would be exhausted in 10 days. Routes to WARNING tier (Slack notification).

**`evaluation_window = "-1M"` (rolling)**
SLO evaluation covering the most recent 30 days from right now. An incident from 25 days ago is still in scope. Contrast with calendar month, which resets on the 1st — rolling windows create genuine accountability.

**`evaluation_type = "AGGREGATE"`**
Calculates one single percentage across the entire evaluation window. Versus timeseries (which shows the value at each point). For SLOs, aggregate is correct — you want one number: "were we 99.9% reliable last month?"

**`target_success`**
The SLO target percentage in Dynatrace. When the SLI drops below this, SLO status = FAILURE and a problem is created.

**`target_warning`**
A slightly stricter threshold — when SLI drops below this but is still above `target_success`, SLO status = WARNING. Gives early warning before formal breach. Typically set 0.1% stricter than target.

**AVAILABILITY (Dynatrace Problem severity)**
The highest severity level in Dynatrace. Created when a service is completely or severely unreachable. Triggers TIER 1 alerts (immediate PagerDuty call). Fires at burn rate 14.4× or complete outage detection.

**ERROR (Dynatrace Problem severity)**
Second highest severity. Created when error rate exceeds threshold. Triggers TIER 2 alerts (PagerDuty push). Has a 2-minute delay to filter transient spikes during rolling deployments.

**SLOWDOWN (Dynatrace Problem severity)**
Third severity level. Created when latency exceeds threshold. Triggers TIER 3 alerts (Slack). Has a 5-minute delay to confirm it's sustained degradation, not a brief spike.

**RESOURCE_CONTENTION (Dynatrace Problem severity)**
Lowest alerting tier. Created when CPU/memory exceeds threshold. Triggers TIER 4 alerts (Slack #monitoring). Has a 15-minute delay — resource pressure often self-resolves via HPA.

**Alerting Profile**
A Dynatrace rule set that defines which Problem severities should trigger notifications, with what delay, and scoped to which Management Zone. The `delay_in_minutes` field filters transient problems.

**`delay_in_minutes`**
How long a Dynatrace Problem must exist before a notification fires. 0 = immediate (for outages). 2 minutes = filter deploy spikes (for error rate). 5 minutes = confirm sustained latency. 15 minutes = confirm resource pressure.

**Management Zone**
A Dynatrace filter scoping which entities (services, hosts) a team sees. Alerting profiles are scoped to Management Zones — ensuring each team only receives alerts for their own services.

**PagerDuty routing key**
A unique identifier for a PagerDuty service that routes incoming incidents to the correct on-call schedule. Different routing keys route to different teams' on-call rotations.

**PagerDuty phone call**
The most intrusive notification method. PagerDuty calls the on-call engineer's phone. Used for TIER 1 (AVAILABILITY) alerts that require immediate human response regardless of time of day.

**PagerDuty push notification**
A mobile app push notification from PagerDuty. Less intrusive than a phone call but still creates an actionable incident. Used for TIER 2 (ERROR) alerts.

**`#alerts-<team>` Slack channel**
A team-specific Slack channel for TIER 3 (WARNING) alerts. Example: `#alerts-payments` for the payments team. Engineers check this during business hours — not a 3am wake-up.

**`#monitoring` Slack channel**
A shared channel for TIER 4 (INFO/RESOURCE_CONTENTION) alerts across all teams. Low signal channel — check weekly, not in real time.

**Incident timeline**
The chronological sequence of events during an incident. Critical for post-mortems. Start recording timestamps from the moment you're paged: "10:14 acknowledged alert, 10:17 identified cause, 10:22 deployed fix, 10:28 confirmed recovery."

**Post-mortem**
A blameless, structured analysis of what caused an incident, how it was resolved, and what changes will prevent recurrence. Must have concrete action items with owners and due dates. Required for every SLO-breaching incident.

**`argocd app rollback`**
The fastest way to revert a bad deployment. Takes 2–3 minutes. Reverts to the previously deployed revision without needing to open a PR or wait for CI. Use immediately if error rate spike correlates with a recent deployment.

**`kubectl top pods`**
Shows current CPU and memory usage per pod. Used during TIER 3 and TIER 4 alert investigations to identify which pods are consuming the most resources.

**`kubectl get events --sort-by='.lastTimestamp'`**
Lists Kubernetes events (pod creation failures, OOM kills, scheduling failures) sorted by recency. Often the fastest way to understand why pods are misbehaving during an incident.

**`dynatrace_slo_v2`**
The Terraform resource for creating a Dynatrace SLO. The `v2` version supports burn rate visualisation and alerting via `error_budget_burn_rate` blocks.

**`metric_expression`**
The formula Dynatrace evaluates to compute SLO compliance. Availability: `100 × (requests - errors) / requests`. Latency: `100 × (requests_under_threshold) / total_requests`.

**`for_each = var.services`**
Terraform meta-argument creating one SLO per entry in the services map. Adding a new service to `variables.tf` automatically creates all its SLOs, metric events, and alerting wiring.

**Sustainable error rate**
The maximum error rate that keeps burn rate at exactly 1.0 (budget lasts exactly 30 days). For 99.9% SLO: sustainable error rate = 0.1% per minute, or about 1 error per 1000 requests. Burn rate alerts compare actual rate to this sustainable rate.
