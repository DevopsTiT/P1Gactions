# SLO + Alert Setup for Microservices — Complete Guide

> How to define SLOs, set burn rate alerts, configure the 4-tier notification system, and respond when alerts fire. Based on the Dynatrace Terraform implementation in this project.

---

## Part 1 — What Is an SLO and Why Every Microservice Needs One

### The Problem Without SLOs

Without SLOs:
- "Is the service healthy?" is answered by gut feeling
- Incidents are declared by whoever complains loudest
- There is no data to decide: "should we delay this risky deploy?"
- Engineers debate severity instead of fixing things

### With SLOs:

```
SLO = a precise, measurable reliability target

Example: payment-service has a 99.9% availability SLO over 30 days.
→ This means: only 43.2 minutes of downtime allowed per month.
→ Error budget remaining = 70% → safe to do risky deploys.
→ Error budget remaining = 5%  → freeze non-critical deploys.
→ Error budget = 0%            → stop ALL features, fix reliability.
```

Every question about risk becomes numerical, not political.

---

## Part 2 — The Two Standard SLOs for Every Microservice

### SLO Type 1: Availability SLO

**Question it answers:** "What % of requests succeeded over the last 30 days?"

```
Availability = (successful requests / total requests) × 100

Successful request = any request that is NOT a 5xx HTTP error
```

**Standard targets by service type:**

| Service Type | Availability SLO | Error Budget (30 days) |
|---|---|---|
| Payment / financial | 99.95% | 21.6 minutes |
| User-facing API (auth, checkout) | 99.9% | 43.2 minutes |
| Internal service | 99.5% | 3.6 hours |
| Analytics / batch | 99.0% | 7.2 hours |
| Dev / staging | 99.0% | 7.2 hours |

**In this project (from variables.tf):**
```hcl
"payment-service"   → slo_target = 99.9
"order-service"     → slo_target = 99.5
"inventory-service" → slo_target = 99.0
"analytics-service" → slo_target = 98.0
```

### SLO Type 2: Latency SLO

**Question it answers:** "What % of requests completed within the target time?"

```
Latency SLO = (requests under threshold / total requests) × 100

Example: 95% of payment requests complete in under 300ms
```

This is NOT the same as "P99 < 300ms." It asks: what fraction of all requests are within budget?

---

## Part 3 — SLO Terraform Implementation

### How to add a new service's SLOs

**Step 1: Add the service to `variables.tf`**

```hcl
# terraform/dynatrace/variables.tf
"checkout-service" = {
  team             = "payments"
  slo_target       = 99.9
  health_check_url = "https://checkout.company.com/health/ready"
  latency_p99_ms   = 400          # SLO latency threshold
  error_rate_alert = 0.2
  traffic_min_rps  = 8
  # ... other fields
}
```

**Step 2: Run terraform plan — see what will be created**

```bash
cd terraform/dynatrace/
terraform plan
# Expected output:
#   + dynatrace_slo_v2.availability["checkout-service"]
#   + dynatrace_slo_v2.latency["checkout-service"]
#   Plan: 2 to add, 0 to change, 0 to destroy.
```

**Step 3: Apply**

```bash
terraform apply
```

**Verify in Dynatrace UI:**
```bash
# Check via API
DT_TENANT="abc12345"
DT_TOKEN="dt0c01.YOUR_TOKEN"

curl -s "https://${DT_TENANT}.live.dynatrace.com/api/v2/slo" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  jq '.slo[] | {name: .name, status: .status, target: .target, current: .evaluatedPercentage}'
```

### Understanding the SLO Terraform resource

```hcl
resource "dynatrace_slo_v2" "availability" {
  for_each = var.services              # one SLO per service in the map

  name          = "${each.key} Availability [production]"
  target_success = 99.9               # the SLO target
  target_warning = 99.8               # warn 0.1% before breach

  evaluation_window = "-1M"           # rolling 30-day window (NOT calendar month)
  evaluation_type   = "AGGREGATE"     # one aggregate % for the whole window

  metric_expression = <<-EOT
    100*(requests - errors) / requests
  EOT

  error_budget_burn_rate {
    burn_rate_visualization_enabled = true
    fast_burn_threshold = 14.4        # budget gone in 2 days → page immediately
    slow_burn_threshold = 3.0         # budget gone in 10 days → Slack warning
  }
}
```

**Why rolling window (`-1M`) not calendar month:**
Calendar month resets on the 1st. A major incident on the 30th is "forgotten" on the 1st. Rolling window keeps the incident in the SLO calculation for 30 more days — forcing genuine improvement.

---

## Part 4 — Error Budget and Burn Rate: The Alert Mechanism

### What Is Error Budget?

```
Error Budget = (1 - SLO target) × evaluation window
            = (1 - 0.999) × 43,200 minutes
            = 43.2 minutes allowed downtime per 30 days
```

Every minute of degraded service consumes budget. When budget hits 0%, the SLO is breached.

### What Is Burn Rate?

```
Burn Rate = (current error rate) / (acceptable error rate)
          = (how fast you're consuming budget) / (sustainable rate)

Burn Rate = 1.0  → sustainable (budget lasts exactly 30 days)
Burn Rate = 14.4 → budget exhausted in 2 days → PAGE NOW
Burn Rate = 3.0  → budget exhausted in 10 days → SLACK WARNING
```

**Why alert on burn rate, not just "SLO breached":**

If you only alert when the SLO is 0% remaining, you discover the breach AFTER it happened — too late to prevent it.

Burn rate alerts fire 48 hours BEFORE the breach at burn rate 14.4. You have time to act.

### The Two Burn Rate Alerts

```
fast_burn_threshold = 14.4
  → fires when the last hour of data shows 14.4× consumption rate
  → at this rate: 30-day budget gone in 2 days
  → SEVERITY: CRITICAL → PagerDuty
  → ACTION: investigate and fix within hours

slow_burn_threshold = 3.0
  → fires when 6 hours of data shows 3× consumption rate
  → at this rate: 30-day budget gone in 10 days
  → SEVERITY: WARNING → Slack
  → ACTION: investigate this week, not necessarily tonight
```

**How to calculate your fast_burn_threshold:**
```
fast_burn_threshold = total_window / alert_window
                    = 30 days / 2 days
                    = 15 (approximately 14.4 with 5% safety margin)
```

---

## Part 5 — The 4-Tier Alert System

### Tier Architecture

```
TIER 1: CRITICAL   (AVAILABILITY problems)
  ├── Who gets paged:  On-call engineer via PagerDuty phone call
  ├── Delay:          0 minutes (fire immediately)
  ├── Environments:   PRODUCTION ONLY
  └── Response:       Drop everything, wake up, fix now

TIER 2: HIGH       (ERROR problems — high error rate, traffic drop, pod crash)
  ├── Who gets paged:  On-call engineer via PagerDuty push notification
  ├── Delay:          2 minutes (filter 1-minute deployment spikes)
  ├── Environments:   Production + Staging
  └── Response:       Investigate within 15 minutes

TIER 3: WARNING    (SLOWDOWN — latency degradation)
  ├── Who is notified: Team's Slack channel #alerts-<team>
  ├── Delay:          5 minutes (confirm sustained, not transient)
  ├── Environments:   All environments
  └── Response:       Investigate during business hours (unless P99 is severe)

TIER 4: INFO       (RESOURCE_CONTENTION — CPU/memory pressure)
  ├── Who is notified: Shared #monitoring Slack channel
  ├── Delay:          15 minutes (resource pressure self-resolves often)
  ├── Environments:   All environments
  └── Response:       Check next morning, plan capacity work
```

### How It Connects to the SLO

```
SLO burn rate fires: fast_burn (14.4×) → creates AVAILABILITY Problem
                                        → TIER 1 alert fires
                                        → PagerDuty phone call

SLO burn rate fires: slow_burn (3.0×)  → creates WARNING Problem
                                        → TIER 3 alert fires
                                        → Slack #alerts-payments

SLO status = FAILURE (breached)         → creates AVAILABILITY Problem
                                        → TIER 1 fires
                                        → This is the worst case — avoid this
```

---

## Part 6 — The Complete Alert → Action Playbook

### When TIER 1 (PagerDuty call) fires — AVAILABILITY down

```bash
# Step 1: Acknowledge the alert in PagerDuty (stops escalation clock)

# Step 2: Check what is down
kubectl get pods -n payments | grep -v Running
kubectl get events -n payments --sort-by='.lastTimestamp' | tail -10

# Step 3: Check ALB target health
aws elbv2 describe-target-health \
  --target-group-arn <YOUR_TG_ARN> \
  --query 'TargetHealthDescriptions[*].{IP:Target.Id, State:TargetHealth.State}' \
  --output table

# Step 4: Check when this started vs recent deployments
argocd app history payment-service | head -5
# Did the SLO breach start after a deploy? Roll back.

# Step 5: Roll back if deploy-related
argocd app rollback payment-service
# Verify rollback
kubectl rollout status deployment/payment-service -n payments

# Step 6: Update status page / notify stakeholders
# "We are investigating elevated error rates on payment-service. ETA: 15 minutes."

# Step 7: Post incident in Slack with timeline
# "Incident resolved. Error rate returned to normal. Post-mortem in 48 hours."
```

### When TIER 2 (PagerDuty push) fires — HIGH error rate

```bash
# Check error rate trend (is it going up or stabilising?)
DT_TENANT="abc12345"
DT_TOKEN="dt0c01.YOUR_TOKEN"

curl -s -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "metricSelector": "builtin:service.errors.server.rate:filter(eq(service.name,\"payment-service\")):splitBy():avg",
    "resolution": "1m",
    "from": "now-30m"
  }' | jq '.result[0].data[0].values'

# Check Dynatrace problem details for root cause
curl -s "https://${DT_TENANT}.live.dynatrace.com/api/v2/problems?problemSelector=status(OPEN)" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  jq '.problems[] | {title: .title, severity: .severityLevel, rootCause: .rootCauseEntity}'

# Check for recent dependency issues (DB, downstream service)
kubectl logs -n payments deployment/payment-service --tail=100 | grep -i "error\|exception\|timeout"

# Is the DB responding?
kubectl exec -n payments deployment/payment-service -- \
  python -c "import os; print(os.environ.get('DB_HOST', 'NO DB HOST SET'))"
```

### When TIER 3 (Slack warning) fires — HIGH latency

```bash
# Check P99 latency trend
curl -s -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "metricSelector": "builtin:service.response.time:percentile(99):filter(eq(service.name,\"payment-service\")):splitBy():avg",
    "resolution": "1m",
    "from": "now-1h"
  }' | jq '.result[0].data[0].values | map(. / 1000 | . * 100 | round / 100)'
# Divide by 1000 to convert µs → ms

# Check Dynatrace service flow for slow calls
# DT UI: Applications → payment-service → Service Flow → sort by response time
# Look for: slow DB queries, slow downstream service calls

# Check if it's CPU-related (might be scheduled CPU throttling)
kubectl top pods -n payments
kubectl describe pod -n payments $(kubectl get pods -n payments -l app=payment-service -o name | head -1)

# Check if HPA is scaling (traffic spike causing latency)
kubectl get hpa -n payments
kubectl get events -n payments | grep -i "HorizontalPodAutoscaler"
```

### When TIER 4 (Slack info) fires — Resource pressure

```bash
# CPU saturation — check if HPA responded
kubectl get hpa -n payments
kubectl top pods -n payments --sort-by=cpu

# Memory pressure — check for leak trend
kubectl top pods -n payments --sort-by=memory
# Compare to last hour: is memory steadily climbing?

# Check if Karpenter provisioned new nodes
kubectl get nodes --sort-by='.metadata.creationTimestamp' | tail -5
kubectl logs -n karpenter deployment/karpenter --tail=20 | grep -i "provisioned\|launched"

# Check node CPU pressure (Karpenter should add nodes automatically)
kubectl describe node $(kubectl get nodes -o name | head -1) | grep -A 10 "Allocated resources"
```

---

## Part 7 — SLO Health Dashboard (Daily Check)

Run this every morning at the start of your shift:

```bash
DT_TENANT="abc12345"
DT_TOKEN="dt0c01.YOUR_TOKEN"

echo "=== SLO HEALTH DASHBOARD ==="
echo "$(date '+%Y-%m-%d %H:%M')"
echo ""

curl -s "https://${DT_TENANT}.live.dynatrace.com/api/v2/slo" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  jq -r '
    .slo[] | 
    [
      .name,
      .status,
      (.evaluatedPercentage | . * 100 | round / 100 | tostring) + "%",
      "budget: " + (.errorBudget | . * 100 | round / 100 | tostring) + "%"
    ] | @tsv' | \
  while IFS=$'\t' read NAME STATUS CURRENT BUDGET; do
    if [ "$STATUS" = "FAILURE" ]; then
      echo "  🚨 $NAME → $STATUS ($CURRENT, $BUDGET)"
    elif [ "$STATUS" = "WARNING" ]; then
      echo "  ⚠️  $NAME → $STATUS ($CURRENT, $BUDGET)"
    else
      echo "  ✅ $NAME → $STATUS ($CURRENT, $BUDGET)"
    fi
  done

echo ""
echo "=== OPEN PROBLEMS ==="
curl -s "https://${DT_TENANT}.live.dynatrace.com/api/v2/problems?problemSelector=status(OPEN)" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  jq -r '.problems[] | "  [\(.severityLevel)] \(.title)"' | head -10
```

---

## Part 8 — Adding SLOs to a Brand New Microservice (Step-by-Step)

```bash
# === STEP 1: Observe first (run new service for 7 days with no SLO) ===
# Watch Dynatrace → Services → your-service-name
# Note: normal P99 latency, normal error rate, normal traffic

# === STEP 2: Find your baseline numbers ===
DT_TENANT="abc12345"
DT_TOKEN="dt0c01.YOUR_TOKEN"
NEW_SERVICE="checkout-service"

# Error rate baseline (last 7 days)
curl -s -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{
    \"metricSelector\": \"builtin:service.errors.server.rate:filter(eq(service.name,\\\"${NEW_SERVICE}\\\"))\",
    \"resolution\": \"1h\",
    \"from\": \"now-7d\"
  }" | jq '
    .result[0].data[0].values | map(select(. != null)) |
    {
      avg_error_rate_pct: (add / length * 100 | . * 100 | round / 100),
      peak_error_rate_pct: (max * 100 | . * 100 | round / 100)
    }'

# Latency P99 baseline
curl -s -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{
    \"metricSelector\": \"builtin:service.response.time:percentile(99):filter(eq(service.name,\\\"${NEW_SERVICE}\\\"))\",
    \"resolution\": \"1h\",
    \"from\": \"now-7d\"
  }" | jq '
    .result[0].data[0].values | map(select(. != null)) | map(. / 1000) |
    {
      avg_p99_ms: (add / length | . * 100 | round / 100),
      peak_p99_ms: (max | . * 100 | round / 100),
      suggested_slo_threshold_ms: (max * 2 | . * 100 | round / 100)
    }'

# === STEP 3: Decide SLO targets ===
# Use the decision tables from threshold-calibration-guide (folder 21)
# For checkout-service (user-facing, revenue-critical):
#   slo_target = 99.9
#   latency_p99_ms = (your observed peak × 2)

# === STEP 4: Add to variables.tf ===
cat >> terraform/dynatrace/variables.tf << 'EOF'
# (Add inside the services default = { ... } block)
"checkout-service" = {
  team             = "payments"
  slo_target       = 99.9
  health_check_url = "https://checkout.company.com/health/ready"
  latency_p99_ms   = 400
  error_rate_alert = 0.2
  traffic_min_rps  = 15
  cpu_saturation_pct     = 75
  memory_usage_pct       = 80
  jvm_heap_pct           = 75
  is_jvm_service         = true
  pod_restart_threshold  = 2
  network_error_rate_pct = 0.5
}
EOF

# === STEP 5: Apply ===
cd terraform/dynatrace/
terraform plan  # review: 2 SLOs + 8 metric events = 10 new resources
terraform apply

# === STEP 6: Verify ===
curl -s "https://${DT_TENANT}.live.dynatrace.com/api/v2/slo" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  jq '.slo[] | select(.name | contains("checkout-service")) | {name, status, target}'

# === STEP 7: Test the alert chain ===
# Inject a test problem to verify PagerDuty/Slack fires
ENTITY_ID=$(curl -s "https://${DT_TENANT}.live.dynatrace.com/api/v2/entities?entitySelector=type(SERVICE),entityName(\"checkout-service\")" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | jq -r '.entities[0].entityId')

curl -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v1/events" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{
    \"eventType\": \"CUSTOM_ALERT\",
    \"title\": \"TEST: Verify alert chain for checkout-service\",
    \"timeoutMinutes\": 1,
    \"attachRules\": {\"entityIds\": [\"${ENTITY_ID}\"]}
  }"

# Expected: Slack notification in #alerts-payments within 2 minutes
# Check: did the right channel get the message?
```

---

## Summary: The Full Stack in One View

```
var.services (variables.tf)
    │
    │ slo_target = 99.9, latency_p99_ms = 300
    │
    ├──► slos.tf
    │       availability SLO (99.9% target, 30-day rolling)
    │       latency SLO (99.4% target, 30-day rolling)
    │       fast_burn = 14.4 → AVAILABILITY Problem → TIER 1 → PagerDuty call
    │       slow_burn = 3.0  → WARNING Problem     → TIER 3 → Slack warning
    │
    ├──► metric-events.tf (8 signals)
    │       traffic drop → TIER 2 (PagerDuty push)
    │       error rate   → TIER 2 (PagerDuty push)
    │       p99 latency  → TIER 3 (Slack #alerts-team)
    │       cpu          → TIER 4 (Slack #monitoring)
    │       memory       → TIER 4 (Slack #monitoring)
    │       jvm heap     → TIER 4 (Slack #monitoring)
    │       pod restarts → TIER 2 (PagerDuty push)
    │       net errors   → TIER 2 (PagerDuty push)
    │
    ├──► alerting-profiles.tf
    │       TIER 1: AVAILABILITY → 0 min delay → PagerDuty phone (prod only)
    │       TIER 2: ERROR        → 2 min delay → PagerDuty push (prod+staging)
    │       TIER 3: SLOWDOWN     → 5 min delay → Slack #alerts-<team>
    │       TIER 4: RESOURCE     → 15 min delay → Slack #monitoring
    │
    └──► notifications.tf
            wires each profile to the correct channel/service
```
