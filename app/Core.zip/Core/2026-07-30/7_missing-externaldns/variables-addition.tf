##############################################################################
# ADD TO: terraform/variables.tf
#
# ExternalDNS needs the Route53 hosted zone ID to scope its IAM policy.
# Add this variable to the existing variables.tf.
##############################################################################

variable "route53_zone_id" {
  type        = string
  description = "Route53 hosted zone ID for ExternalDNS to manage DNS records. Get via: aws route53 list-hosted-zones"
  # Example: "Z1234567890ABCDEFGHIJ"
  # Do NOT use the full ARN here — just the zone ID portion.
  # The IAM policy in irsa-externaldns.tf constructs the full ARN.

  validation {
    condition     = can(regex("^Z[A-Z0-9]{8,32}$", var.route53_zone_id))
    error_message = "route53_zone_id must be a valid Route53 hosted zone ID (starts with Z, uppercase letters and numbers)"
  }
}

variable "domain_name" {
  type        = string
  description = "Root domain name managed by Route53 (e.g. company.com). Used as the ExternalDNS domainFilter."
  # domainFilter tells ExternalDNS to ONLY manage records in this domain.
  # Without it, ExternalDNS would attempt to manage ALL records in all zones.
}
