# Why `irsa-externaldns.tf` Is Missing — And How to Add It

---

## The Gap

The project overview (`4_eks-dynatrace-gitops-project.md`) lists `irsa-externaldns.tf` in the file tree as a required component:

```
terraform/
  ├── irsa-lbc.tf          ← ✅ EXISTS  — ALB controller IAM role
  ├── irsa-eso.tf          ← ✅ EXISTS  — External Secrets Operator IAM role
  ├── irsa-externaldns.tf  ← ❌ MISSING — ExternalDNS IAM role
```

There is also no `gitops/networking/external-dns.yaml` — the ArgoCD Application to deploy ExternalDNS into the cluster is absent too.

Without both files, ExternalDNS is never deployed and DNS records are never automatically created for your Ingress resources. When the payment-service Ingress creates an ALB, the `payment.company.com` DNS name never points to that ALB. Users cannot reach the service.

---

## Why It Is Missing (The Likely Reason)

The project was scaffolded with `irsa-externaldns.tf` in the design spec but the author did not implement it before publishing. This is a common "known gap" in reference projects — the architecture is correct but one component was left as an exercise.

---

## What ExternalDNS Does

ExternalDNS is a Kubernetes controller that watches `Service` and `Ingress` objects and automatically creates/updates/deletes DNS records in Route53 (or other DNS providers).

```
Developer creates Ingress:
  host: payment.company.com
  → ALB Controller creates ALB: k8s-paymentns-abc123.ap-northeast-1.elb.amazonaws.com
  → ExternalDNS sees the Ingress
  → ExternalDNS calls Route53 API: CREATE A record payment.company.com → ALB alias
  → DNS propagates in ~30 seconds

Developer deletes Ingress:
  → ALB Controller deletes ALB
  → ExternalDNS calls Route53 API: DELETE A record payment.company.com
  → No orphaned DNS records
```

Without ExternalDNS: DNS records must be created manually in the Route53 console every time an Ingress is created. If an ALB is recreated (new IP/hostname), the DNS record is not updated.

---

## Fix: Create the Two Missing Files

### File 1: `terraform/irsa-externaldns.tf`

This creates the IAM role that ExternalDNS uses to call Route53.

```bash
# Verify your Route53 hosted zone exists before creating the IAM role
aws route53 list-hosted-zones \
  --query 'HostedZones[*].{Name:Name, ID:Id}' \
  --output table

# Get your hosted zone ID (needed in the Terraform file)
ZONE_ID=$(aws route53 list-hosted-zones \
  --query 'HostedZones[?Name==`company.com.`].Id' \
  --output text | cut -d/ -f3)
echo "Hosted Zone ID: $ZONE_ID"
```

See: `irsa-externaldns.tf` (artifact file in this folder)

### File 2: `gitops/networking/external-dns.yaml`

This deploys ExternalDNS into the cluster via ArgoCD.

See: `external-dns.yaml` (artifact file in this folder)

---

## Apply Order

```bash
# Step 1: Apply the Terraform IRSA role first
cd terraform/
terraform plan -target=aws_iam_role.externaldns -target=aws_iam_role_policy.externaldns
terraform apply -target=aws_iam_role.externaldns -target=aws_iam_role_policy.externaldns

# Get the role ARN (needed in the Helm values)
terraform output externaldns_role_arn

# Step 2: Update external-dns.yaml with the real role ARN from Step 1
# Replace the placeholder ARN in external-dns.yaml

# Step 3: Commit external-dns.yaml to gitops repo
git add gitops/networking/external-dns.yaml
git commit -m "feat(networking): add ExternalDNS for Route53 DNS automation"
git push

# ArgoCD auto-syncs → ExternalDNS pod starts in kube-system
# Verify pod running:
kubectl get pods -n kube-system -l app.kubernetes.io/name=external-dns

# Step 4: Test — create a test Ingress and verify DNS record is created
kubectl get ingress -n payment-ns
# Wait ~30 seconds after Ingress is created
aws route53 list-resource-record-sets \
  --hosted-zone-id $ZONE_ID \
  --query 'ResourceRecordSets[?Name==`payment.company.com.`]' \
  --output table
```

---

## Verifying ExternalDNS Is Working

```bash
# Check ExternalDNS logs — should show "Desired change: CREATE payment.company.com"
kubectl logs -n kube-system -l app.kubernetes.io/name=external-dns --tail=50 | \
  grep -E "CREATE|UPDATE|DELETE|error|Warning"

# Check if Route53 records match Ingress hostnames
kubectl get ingress -A -o jsonpath='{range .items[*]}{.metadata.name}: {.spec.rules[*].host}{"\n"}{end}'

# Verify DNS resolves correctly
dig payment.company.com +short
# Should return the ALB hostname or IP

# Check ExternalDNS TXT ownership records (how ED tracks what it manages)
aws route53 list-resource-record-sets \
  --hosted-zone-id $ZONE_ID \
  --query 'ResourceRecordSets[?Type==`TXT`].{Name:Name, Value:ResourceRecords[0].Value}' \
  --output table
```

---

## The `txtOwnerId` Setting

```yaml
# In external-dns.yaml Helm values:
txtOwnerId: "company-prod"
```

This is a critical setting. ExternalDNS creates a TXT record alongside each DNS record as "proof of ownership." The TXT record looks like:

```
heritage=external-dns,owner=company-prod,resource=ingress/payment-ns/payment-service
```

If you deploy a second cluster (staging) without a different `txtOwnerId`, it would see the production DNS records and try to "reconcile" them — potentially deleting production records it thinks belong to it. Each cluster must have a unique `txtOwnerId`.

---

## Why `policy: sync` Not `upsert-only`

```yaml
# In external-dns.yaml:
policy: sync    # creates AND deletes records

# Alternative:
policy: upsert-only   # only creates/updates, never deletes
```

`upsert-only` leaves orphaned DNS records when you delete an Ingress. Over months of deploying and removing services, your Route53 hosted zone fills with records pointing to deleted ALBs. `sync` keeps DNS clean — records are deleted when the Ingress that owns them is deleted.

The risk of `sync`: if ExternalDNS has a bug or misconfiguration, it could delete valid records. Mitigations:
- Set `txtOwnerId` correctly (ED only deletes records it created)
- Review ExternalDNS logs after changes
- Use Route53 change tracking via CloudTrail
