##############################################################################
# MISSING FILE: terraform/irsa-externaldns.tf
#
# WHY THIS FILE IS NEEDED:
#   ExternalDNS calls the Route53 API to create/update/delete DNS records
#   when Kubernetes Ingress resources are created or deleted.
#   Without this IAM role, ExternalDNS cannot call Route53 and all DNS
#   record management must be done manually.
#
# WHAT THIS FILE CREATES:
#   1. IAM role with OIDC trust — only the ExternalDNS K8s ServiceAccount
#      in kube-system can assume it
#   2. IAM policy — least privilege: only ChangeResourceRecordSets on your
#      specific hosted zone(s), and ListHostedZones globally
#
# HOW IT CONNECTS:
#   Terraform creates role ARN →
#   gitops/networking/external-dns.yaml references ARN as IRSA annotation →
#   ExternalDNS pod assumes role via IRSA →
#   ExternalDNS calls route53:ChangeResourceRecordSets
##############################################################################

# ── OIDC Trust Policy ─────────────────────────────────────────────────────────
# Allows only the ExternalDNS ServiceAccount in kube-system to assume this role.
# Scoped to: namespace=kube-system, serviceaccount=external-dns
data "aws_iam_policy_document" "externaldns_trust" {
  statement {
    effect = "Allow"

    principals {
      type        = "Federated"
      identifiers = [data.aws_iam_openid_connect_provider.eks.arn]
      # data.aws_iam_openid_connect_provider.eks is defined in main.tf
    }

    actions = ["sts:AssumeRoleWithWebIdentity"]

    condition {
      test     = "StringEquals"
      variable = "${replace(module.eks.cluster_oidc_issuer_url, "https://", "")}:sub"
      values   = ["system:serviceaccount:kube-system:external-dns"]
      # "system:serviceaccount:NAMESPACE:SERVICE_ACCOUNT_NAME"
      # Namespace: kube-system (where ExternalDNS runs)
      # ServiceAccount: external-dns (created by the Helm chart)
    }

    condition {
      test     = "StringEquals"
      variable = "${replace(module.eks.cluster_oidc_issuer_url, "https://", "")}:aud"
      values   = ["sts.amazonaws.com"]
    }
  }
}

# ── IAM Role ──────────────────────────────────────────────────────────────────
resource "aws_iam_role" "externaldns" {
  name               = "${local.cluster_name}-external-dns"
  assume_role_policy = data.aws_iam_policy_document.externaldns_trust.json
  description        = "IRSA role for ExternalDNS to manage Route53 records"
  tags               = local.common_tags
}

# ── IAM Policy: Least Privilege Route53 Permissions ─────────────────────────
# WHY NOT wildcard Resource:
#   ChangeResourceRecordSets on "*" would allow ExternalDNS to modify
#   ANY hosted zone in the account — including zones belonging to other teams.
#   Restricting to the specific hosted zone ID limits blast radius.
#
# You can allow multiple zones by adding more ARNs to the Resource list,
# or use a data source to look up zone IDs dynamically.
resource "aws_iam_role_policy" "externaldns" {
  name = "externaldns-route53-policy"
  role = aws_iam_role.externaldns.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "ChangeRecordsInSpecificZone"
        Effect = "Allow"
        Action = ["route53:ChangeResourceRecordSets"]
        # IMPORTANT: Replace with your actual hosted zone ID(s)
        # Format: arn:aws:route53:::hostedzone/ZONEID
        # Get your zone ID: aws route53 list-hosted-zones
        Resource = [
          "arn:aws:route53:::hostedzone/${var.route53_zone_id}"
        ]
      },
      {
        Sid    = "ListAllZones"
        Effect = "Allow"
        Action = [
          "route53:ListHostedZones",
          "route53:ListResourceRecordSets",
          "route53:ListTagsForResource",
        ]
        # ListHostedZones requires * resource — cannot be scoped to a specific zone
        Resource = ["*"]
      }
    ]
  })
}

# ── Output: ARN for Helm chart values ─────────────────────────────────────────
output "externaldns_role_arn" {
  value       = aws_iam_role.externaldns.arn
  description = "IAM role ARN to use in external-dns.yaml Helm values as IRSA annotation"
}
