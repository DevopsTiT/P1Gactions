# Missing ExternalDNS — Glossary

**ExternalDNS**
A Kubernetes controller that automatically creates, updates, and deletes DNS records in Route53 (or other DNS providers) when Kubernetes Ingress or Service objects are created. Eliminates manual DNS management — developers create an Ingress and the correct DNS record appears automatically within 30–60 seconds.

**Route53**
AWS's managed DNS service. Hosts domain name records (A, CNAME, ALIAS, TXT) and resolves domain names to IP addresses or load balancer hostnames. ExternalDNS calls the Route53 API to manage records on behalf of Kubernetes.

**Hosted Zone**
A Route53 container for DNS records for a specific domain (e.g., `company.com`). Has a unique zone ID (e.g., `Z1234567890ABCDEFGHIJ`). ExternalDNS's IAM policy scopes to specific hosted zone IDs to prevent modifying unintended zones.

**A Record (DNS)**
A DNS record mapping a domain name to an IPv4 address. ExternalDNS creates A records or ALIAS records (for AWS ALBs) pointing your domain to the ALB's hostname or IP.

**ALIAS Record**
An AWS Route53-specific record type that maps a domain to an AWS resource hostname (like an ALB). Unlike a CNAME, an ALIAS can be used at the zone apex (e.g., `company.com` not just `sub.company.com`). ExternalDNS uses ALIAS records for ALB-backed Ingresses.

**TXT Record (ExternalDNS ownership)**
A DNS TXT record ExternalDNS creates alongside each A/ALIAS record to mark ownership. Format: `heritage=external-dns,owner=company-prod,resource=ingress/namespace/name`. ExternalDNS only modifies records where the TXT record's owner matches its own `txtOwnerId` setting.

**`txtOwnerId`**
A unique identifier ExternalDNS embeds in its TXT ownership records. Each cluster must have a unique `txtOwnerId`. If two clusters share a Route53 zone with the same `txtOwnerId`, they will fight over records — one cluster deletes what the other creates.

**`policy: sync`**
ExternalDNS policy that creates, updates, AND deletes Route53 records to match the current Ingress state. When an Ingress is deleted, the DNS record is deleted too. Keeps Route53 clean but requires correct `txtOwnerId` to prevent cross-cluster record deletion.

**`policy: upsert-only`**
ExternalDNS policy that only creates and updates records, never deletes them. Safer but leads to orphaned DNS records pointing to deleted ALBs over time.

**`domainFilter`**
A list of domains ExternalDNS is allowed to manage. ExternalDNS ignores Ingresses with hostnames outside the filter. Without it, ExternalDNS attempts to manage DNS records across all Route53 zones in the account, including zones belonging to other teams.

**IRSA (IAM Roles for Service Accounts)**
The mechanism giving ExternalDNS's Kubernetes pod AWS credentials to call Route53 without hardcoded access keys. The pod's projected JWT is exchanged for temporary IAM credentials via AWS STS.

**`route53:ChangeResourceRecordSets`**
The IAM action that allows creating, updating, and deleting Route53 DNS records. ExternalDNS needs this permission on the specific hosted zone(s) it manages. This is the core permission for DNS automation.

**`route53:ListHostedZones`**
An IAM action required by ExternalDNS to discover which hosted zones exist. Must be scoped to `Resource: "*"` because there is no way to limit this action to specific zones in IAM policy syntax.

**`domainFilter` + `zoneType`**
Two ExternalDNS settings that narrow which zones it operates on. `domainFilter: company.com` limits to records in the company.com zone. `zoneType: public` limits to public (internet-facing) hosted zones. Together they prevent ExternalDNS from accidentally managing records in internal or unrelated zones.

**Sync Wave 1 (for ExternalDNS)**
ExternalDNS is deployed at ArgoCD sync wave 1, the same as the ALB Controller. Both must be running before application Ingresses are created (wave 8). They can deploy in parallel with each other. No dependency between ALB Controller and ExternalDNS.

**Orphaned DNS Record**
A Route53 record that points to a deleted or non-existent resource. Caused by `policy: upsert-only` or manual DNS management when Ingresses are deleted. `policy: sync` with correct `txtOwnerId` prevents orphaned records.

**`interval: 1m`**
How often ExternalDNS polls Kubernetes for changes and reconciles Route53. After a new Ingress is created, the DNS record appears within 1 minute (plus Route53 propagation time of ~30 seconds). Total expected delay: under 2 minutes from Ingress creation to DNS resolution.

**ALB ALIAS Record**
When ExternalDNS creates a record for an ALB-backed Ingress, it creates an ALIAS record pointing to the ALB's hostname (e.g., `k8s-paymentns-abc.ap-northeast-1.elb.amazonaws.com`) rather than an IP address. ALIAS records update automatically if the ALB's IP changes (e.g., during ALB scaling).

**`sources: [ingress, service]`**
Tells ExternalDNS which Kubernetes resources to watch. `ingress` sources watch `spec.rules[].host`. `service` sources watch the `external-dns.alpha.kubernetes.io/hostname` annotation on Services. Using both covers all DNS management patterns.
