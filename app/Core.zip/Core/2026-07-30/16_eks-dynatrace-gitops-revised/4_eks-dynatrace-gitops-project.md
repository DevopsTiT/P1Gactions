# Complete Project: EKS + Dynatrace + GitHub Actions + ArgoCD

> **What this project builds:** A production-grade Kubernetes platform on AWS EKS where every infrastructure change flows through Terraform (IaC), every application deployment flows through ArgoCD (GitOps), every container build flows through GitHub Actions (CI), and every service is automatically monitored by Dynatrace (observability) — with zero manual cloud console clicks after initial bootstrap.

---

## Architecture Overview

```
┌────────────────────────────────────────────────────────────────────┐
│  Developer Workflow                                                 │
│                                                                    │
│  git push → GitHub Actions → Docker image → ArgoCD → EKS pod      │
│  terraform apply → AWS EKS + VPC + IAM                            │
│                   ↓                                                │
│              Dynatrace OneAgent (auto-discovers everything)        │
└────────────────────────────────────────────────────────────────────┘

AWS Infrastructure (Terraform):
  VPC (3 AZs, public/private subnets, NAT GWs, VPC Endpoints)
  EKS Cluster (v1.30, managed node groups + Karpenter)
  IAM IRSA roles (ESO, LBC, ExternalDNS, Karpenter, payment-service)
  Secrets Manager (DT tokens, app credentials)
  ECR repository (Docker images — app-bootstrap workspace)
  Dynatrace Terraform provider (Management Zones, Alerting Profiles,
                                Notifications, Metric Events, SLOs, Synthetics)

GitOps Control Plane (ArgoCD — App of Apps):
  Wave -1: Namespaces         (all namespaces created first)
  Wave  1: AWS LBC + ExternalDNS  (ALB + DNS management)
  Wave  2: External Secrets Operator
  Wave  3: Karpenter + Dynatrace Operator + Kyverno
  Wave  4: ClusterSecretStore
  Wave  5: Kyverno Policies
  Wave  8: payment-service application

CI Pipeline (GitHub Actions):
  On PR:    lint + test + docker build (no push)
  On merge: docker build → push to ECR → update image tag in gitops
  On infra: terraform plan (PR) / terraform apply (merge)
  On DT:    dynatrace terraform plan/apply
```

---

## Complete File Tree

```
4_eks-dynatrace-gitops-project/
│
├── .github/workflows/
│   ├── app-ci.yaml                ← build + test + push Docker image to ECR
│   ├── terraform-infra.yaml       ← plan/apply AWS infrastructure
│   └── terraform-dynatrace.yaml   ← plan/apply Dynatrace config
│
├── app/                           ← Python microservice (payment-service)
│   ├── main.py                    ← Flask app: /health + main endpoints
│   ├── requirements.txt           ← Flask, gunicorn, opentelemetry
│   ├── Dockerfile                 ← multi-stage build, non-root user
│   └── tests/
│       └── test_main.py           ← pytest: health check + endpoint tests
│
├── charts/
│   ├── namespaces/                ← Helm chart: creates K8s Namespaces
│   │   ├── Chart.yaml
│   │   ├── values.yaml            ← list of namespaces + labels
│   │   └── templates/
│   │       └── namespace.yaml     ← iterates values.namespaces list
│   └── payment-service/           ← Helm chart: full app deployment
│       ├── Chart.yaml
│       ├── values.yaml            ← image.tag updated by GitHub Actions CI
│       └── templates/
│           ├── deployment.yaml    ← 3 replicas, probes, topology spread
│           ├── service.yaml       ← ClusterIP
│           ├── ingress.yaml       ← ALB annotations → AWS LBC creates ALB
│           ├── hpa.yaml           ← scale 3→20 at 70% CPU
│           ├── pdb.yaml           ← minAvailable=2
│           ├── serviceaccount.yaml← IRSA annotation for AWS access
│           └── external-secret.yaml ← DB credentials from Secrets Manager
│
├── gitops/                        ← ArgoCD-managed Kubernetes config
│   ├── bootstrap/
│   │   └── root-app.yaml          ← THE App of Apps (apply once manually)
│   ├── argocd/
│   │   └── argocd-project.yaml    ← AppProject: platform + payments
│   ├── namespaces/
│   │   └── namespaces.yaml        ← wave -1: creates all namespaces first
│   ├── networking/
│   │   ├── aws-load-balancer-controller.yaml  ← wave 1: ALB management
│   │   └── external-dns.yaml                  ← wave 1: Route53 automation
│   ├── secrets/external-secrets/
│   │   ├── external-secret-operator.yaml  ← wave 2: ESO install
│   │   └── cluster-secret-store.yaml      ← wave 4: connects ESO → Secrets Manager
│   ├── auto-scaling/karpenter/
│   │   └── karpenter.yaml         ← wave 3: NodePool + EC2NodeClass
│   ├── monitoring/dynatrace/
│   │   └── dynatrace-operator.yaml← wave 3: Operator + ExternalSecret + DynaKube
│   ├── security/kyverno/
│   │   └── kyverno.yaml           ← wave 3/5: engine + policies
│   └── app/payment-service/
│       └── payment-service.yaml   ← wave 8: the application
│
└── terraform/
    ├── main.tf                    ← VPC + EKS modules, providers
    ├── variables.tf               ← all input variables
    ├── outputs.tf                 ← cluster endpoint, OIDC URL
    ├── versions.tf                ← provider version locks
    ├── backend.tf                 ← S3 state + DynamoDB lock
    ├── karpenter.tf               ← Karpenter IAM + SQS interruption queue
    ├── irsa-lbc.tf                ← ALB controller IAM role
    ├── irsa-externaldns.tf        ← ExternalDNS IAM role (Route53)
    ├── irsa-eso.tf                ← External Secrets Operator IAM role
    ├── secrets-manager.tf         ← DT token containers + payment-service DB
    ├── variables-addition.tf      ← route53_zone_id + domain_name
    ├── modules/
    │   ├── vpc/
    │   │   ├── main.tf            ← VPC, subnets, NAT GWs, VPC endpoints
    │   │   ├── variables.tf       ← vpc_cidr, azs, cluster_name, etc.
    │   │   └── outputs.tf         ← vpc_id, private_subnet_ids, public_subnet_ids
    │   └── eks/
    │       ├── main.tf            ← EKS cluster, node group, OIDC provider
    │       ├── variables.tf       ← cluster_name, version, instance types
    │       └── outputs.tf         ← cluster_endpoint, cluster_oidc_issuer_url
    ├── dynatrace/                 ← separate Terraform workspace
    │   ├── main.tf                ← DT provider reads token from Secrets Manager
    │   ├── variables.tf           ← services map: the single source of truth
    │   ├── management-zones.tf    ← one zone per team (for_each = local.teams)
    │   ├── alerting-profiles.tf   ← Critical + Warning per team
    │   ├── notifications.tf       ← PagerDuty (critical) + Slack (warning)
    │   ├── metric-events.tf       ← error rate + p99 latency alerts per service
    │   ├── slos.tf                ← availability SLOs with burn rate alerts
    │   └── synthetics.tf          ← HTTP health check per service
    └── app-bootstrap/             ← separate Terraform workspace (quickstart)
        ├── main.tf                ← ECR repo + payment-service IRSA role
        ├── variables.tf
        └── outputs.tf             ← ecr_repository_url, payment_service_role_arn
```

---

## Step 1: Bootstrap (Run in Order)

```bash
# ── 1a. Main infrastructure ──────────────────────────────────────────────────
cd terraform/
terraform init
terraform apply
# Creates: VPC, EKS cluster, all IRSA roles, Secrets Manager secrets

# ── 1b. App bootstrap (creates ECR + app IRSA) ──────────────────────────────
cd terraform/app-bootstrap/
terraform init
terraform apply
# Get the ECR URL for GitHub Actions:
terraform output ecr_repository_url

# ── 1c. Store secrets in Secrets Manager ────────────────────────────────────
aws secretsmanager put-secret-value \
  --secret-id production/dynatrace/api-token \
  --secret-string "dt0c01.YOUR_API_TOKEN"

aws secretsmanager put-secret-value \
  --secret-id production/dynatrace/paas-token \
  --secret-string "dt0c01.YOUR_PAAS_TOKEN"

aws secretsmanager put-secret-value \
  --secret-id production/dynatrace/tenant-url \
  --secret-string "https://abc12345.live.dynatrace.com/api"

# ── 1d. Bootstrap ArgoCD (apply root-app ONCE) ──────────────────────────────
aws eks update-kubeconfig --name company-prod --region ap-northeast-1
kubectl apply -f gitops/bootstrap/root-app.yaml
# ArgoCD discovers and deploys everything else automatically

# ── 1e. Dynatrace configuration ─────────────────────────────────────────────
cd terraform/dynatrace/
terraform init
terraform apply
# Creates: Management Zones, Alerting Profiles, Notifications, Alerts, SLOs, Synthetics
```

---

## Step 2: terraform/main.tf — Orchestrator

```
Calls two modules:
  module "vpc" → creates VPC, 3 public + 3 private subnets, NAT GWs, VPC endpoints
  module "eks" → creates EKS cluster, managed node group (system nodes), OIDC provider

Providers:
  AWS provider:        default_tags applies common tags to ALL resources
  Kubernetes provider: uses exec/aws eks get-token for authentication (no kubeconfig)
  Helm provider:       same exec-based auth

Data sources (shared across IRSA files):
  aws_caller_identity  → account_id for constructing ARNs without hardcoding
  aws_iam_openid_connect_provider → OIDC provider ARN for IRSA trust policies

WHY MODULES:
  The VPC and EKS modules are reusable — staging calls the same modules with different CIDRs.
  main.tf stays clean: it just orchestrates and passes outputs between modules.
```

---

## Step 3: IRSA Files — One IAM Role Per Component

```
PATTERN (identical in every irsa-*.tf):
  1. Trust policy: EKS OIDC provider can issue tokens
     Condition: ONLY system:serviceaccount:NAMESPACE:SA_NAME can assume this role
  2. aws_iam_role with that trust policy
  3. aws_iam_role_policy: minimum permissions only (resource-scoped, not *)

IRSA files:
  irsa-lbc.tf           → route create/modify/delete ALBs
  irsa-externaldns.tf   → route53:ChangeResourceRecordSets on specific hosted zone
  irsa-eso.tf           → secretsmanager:GetSecretValue on production/* secrets only

WHY IRSA NOT NODE INSTANCE PROFILE:
  Node profile: ALL pods on the node share the node's IAM role.
  IRSA: each pod gets its own scoped role.
  Compromised payment-service pod → attacker gets ONLY payment secrets.
  Not: all secrets for all services on the node.
```

---

## Step 4: terraform/dynatrace/ — Monitoring as Code

```
SINGLE SOURCE OF TRUTH: variables.tf services map
  Add one entry → PR → merge → apply creates:
    Management Zone rule entry
    Error rate + p99 latency metric events
    Availability SLO with burn rate alerts
    HTTP synthetic health check

services map entry format:
  "service-name" = {
    team             = "payments"      ← which Management Zone to add to
    slo_target       = 99.9            ← availability target %
    error_rate_alert = 0.5             ← alert threshold %
    latency_p99_ms   = 500             ← P99 alert threshold in ms
    health_check_url = "https://..."   ← synthetic monitor URL
  }

PROVIDER AUTHENTICATION:
  DT API token read from Secrets Manager at apply time.
  Never in .tf files, .tfvars, or CI environment variables.

SEPARATE STATE:
  terraform/dynatrace/backend.tf → key: "dynatrace/terraform.tfstate"
  Isolated from EKS infra state — DT threshold tuning never touches EKS resources.
```

---

## Step 5: gitops/ — ArgoCD App of Apps

```
THE ONLY MANUAL COMMAND:
  kubectl apply -f gitops/bootstrap/root-app.yaml

root-app watches gitops/ recursively → discovers ALL Application YAMLs
→ ArgoCD deploys and manages everything in dependency order via sync waves.

SYNC WAVE ORDER:
  Wave -1: namespaces.yaml           namespaces must exist before any pod
  Wave  1: aws-load-balancer-controller.yaml  ALB controller
           external-dns.yaml                  Route53 automation
  Wave  2: external-secret-operator.yaml      ESO Helm chart + CRDs
  Wave  3: karpenter.yaml                     Karpenter + NodePool + EC2NodeClass
           dynatrace-operator.yaml            Operator + ExternalSecret + DynaKube
           kyverno.yaml                       Kyverno engine
  Wave  4: cluster-secret-store.yaml          ESO → Secrets Manager connection
  Wave  5: kyverno-policies (inline)          Kyverno ClusterPolicy resources
  Wave  8: payment-service.yaml               The application (everything else ready)

WHAT ARGOCD ENFORCES:
  prune: true    → delete K8s resources when YAML is removed from Git
  selfHeal: true → revert manual kubectl changes back to Git state
  Git is the ONLY source of truth for cluster state.
```

---

## Step 6: charts/payment-service/ — Application Helm Chart

```
values.yaml controls everything; image.tag is the only value changed per deploy.

templates/deployment.yaml:
  replicas: 3 (one per AZ via topologySpreadConstraints)
  readinessProbe: /health (removes pod from LB before SIGTERM)
  livenessProbe:  /health (restarts if truly stuck)
  resources: requests + limits (required by Kyverno policy)
  labels: team + app (required by Kyverno + Dynatrace auto-tagging)

templates/ingress.yaml:
  ingressClassName: alb
  alb.ingress.kubernetes.io/scheme: internet-facing
  alb.ingress.kubernetes.io/target-type: ip  (direct to pod IP, no iptables hop)
  → AWS LBC creates real ALB from these annotations

templates/external-secret.yaml:
  Pulls DB credentials from Secrets Manager.
  ExternalSecret → creates K8s Secret → pod reads as env vars.
  Secret never in Git, never in image.
```

---

## Step 7: GitHub Actions Pipelines

```
app-ci.yaml (triggers on app/ changes):
  On PR:    pytest → docker build (no push, validates Dockerfile)
  On merge: pytest → docker build → ECR push (tag = git SHA)
            → sed update charts/payment-service/values.yaml image.tag
            → git commit [skip ci] → ArgoCD detects → rolling update

terraform-infra.yaml (triggers on terraform/ changes, excluding dynatrace/):
  On PR:    init → fmt check → validate → plan (posted as PR comment)
  On merge: init → apply → Slack notification

terraform-dynatrace.yaml (triggers on terraform/dynatrace/ changes):
  On PR:    init → validate → plan
  On merge: apply
  WHY SEPARATE: DT config changes are lower risk than infra changes.
                Uses different IAM role (only reads DT token from SM).

OIDC AUTHENTICATION (no stored AWS keys in GitHub Secrets):
  GitHub Actions → request JWT from GitHub's OIDC provider
  → present to AWS STS → assume role → get 1-hour credentials
  Role trust policy: only allows this org/repo on main branch.
```

---

## End-to-End Flows

```
FLOW 1: Deploy a code change
  Developer merges PR to main
  → app-ci.yaml builds + pushes image :abc1234
  → Updates charts/payment-service/values.yaml image.tag = abc1234
  → ArgoCD detects gitops change → rolling update
  → New pods start → readiness probe passes → old pods terminate
  → Dynatrace OneAgent auto-discovers new version within 5 minutes

FLOW 2: Alert fires (error rate spike)
  T+0:   Error rate exceeds 0.5% threshold (metric-events.tf)
  T+2min: DT Problem created → alerting-profiles.tf matches (ERROR, 2 min delay)
  T+2min: notifications.tf → PagerDuty creates incident → on-call paged
  T+5min: Engineer reverts image.tag → git push → ArgoCD rolls back
  T+7min: Error rate recovers → DT Problem closes → PD auto-resolves

FLOW 3: Add a new service to monitoring
  1. Add entry to terraform/dynatrace/variables.tf services map
  2. terraform plan → shows: 1 MZ rule + 2 alerts + 1 SLO + 1 synthetic
  3. Merge → terraform apply → DT config created
  4. Create gitops/app/new-service/new-service.yaml
  5. Merge → ArgoCD deploys → OneAgent discovers within 5 minutes
```

---

## Known Trade-offs and Production Gaps

| Gap | Fix for Production |
|---|---|
| `apiUrl: PLACEHOLDER` in dynatrace-operator.yaml | Use ExternalSecret (3rd key: apiUrl) or Kustomize overlay per cluster |
| Helm chart repoURL uses raw.githubusercontent.com | Use official repo: `https://raw.githubusercontent.com/Dynatrace/dynatrace-operator/main/config/helm/repos/stable` |
| `variables-addition.tf` not integrated into `variables.tf` | Merge into `variables.tf`, remove the separate file |
| Single `variables.tf` file for DT; PD keys/Slack webhooks empty in tfvars | Inject via `TF_VAR_pagerduty_integration_keys` env vars in CI |
| Kyverno in Audit mode | Change `validationFailureAction: Audit` → `Enforce` after testing |
| No NetworkPolicy defined | Add NetworkPolicy templates to charts/payment-service |
