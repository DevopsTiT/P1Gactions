# EKS + Dynatrace + GitOps Project — Glossary

Every term from the project explained for an SRE beginner.

---

**EKS (Elastic Kubernetes Service)**
AWS's managed Kubernetes service. AWS manages the control plane (the "brain": API server, etcd, scheduler); you manage the worker nodes where your containers actually run. You interact with it via `kubectl` commands or ArgoCD — never through manual AWS console clicks in production.

**Terraform**
Infrastructure as Code tool. You write `.tf` files describing what AWS resources you want (VPC, EKS, IAM roles, Secrets Manager). Terraform computes what needs to change and creates/updates/deletes resources to match. The state file tracks what it has created.

**ArgoCD**
A GitOps continuous delivery tool for Kubernetes. It watches a Git repository and makes the cluster match what Git says. When you commit a change to a YAML file, ArgoCD detects it and applies the change to the cluster automatically. "Git is the source of truth."

**GitOps**
An operational model where ALL cluster configuration lives in Git. Changes happen through pull requests. ArgoCD continuously reconciles the cluster state to match Git. Benefits: peer review, audit trail, instant rollback (revert the commit).

**App of Apps (ArgoCD)**
A pattern where one ArgoCD Application watches a folder of other ArgoCD Application manifests. The root-app is applied once manually; it then discovers and manages all child applications automatically. Enables full cluster recovery by applying one file.

**Sync Wave**
An ArgoCD annotation (`argocd.argoproj.io/sync-wave: "N"`) that controls deployment order. Wave -1 deploys before wave 0; wave 0 before wave 1; etc. Each wave waits for all resources in the previous wave to be Healthy before starting.

**IRSA (IAM Roles for Service Accounts)**
A mechanism that gives individual Kubernetes pods their own AWS IAM role. Each pod's ServiceAccount is annotated with an IAM role ARN. AWS validates the pod's identity via the OIDC provider and issues temporary credentials. Prevents all pods from sharing the node's broad permissions.

**OIDC Provider**
Open ID Connect Provider. Created by the EKS module; it's the bridge between Kubernetes ServiceAccounts and AWS IAM. When a pod needs AWS credentials, it presents its ServiceAccount token to the OIDC provider, which validates it and allows the pod to assume its IRSA role.

**Karpenter**
A Kubernetes node autoscaler by AWS. When pods are in "Pending" state (no node has capacity), Karpenter provisions a new EC2 instance in ~30 seconds — choosing the optimal instance type and size for the workload. Much faster than Cluster Autoscaler (~3 minutes).

**External Secrets Operator (ESO)**
A Kubernetes operator that reads secrets from external stores (AWS Secrets Manager, Vault) and creates Kubernetes Secrets from them. Your pods reference the K8s Secret; ESO keeps it in sync with the external store. Credentials never touch your Git repository.

**ExternalSecret**
A Kubernetes Custom Resource (created by ESO). It says "read this path from AWS Secrets Manager and create a K8s Secret named X with keys Y and Z." The actual secret values are fetched at runtime — only the path reference is stored in Git.

**ClusterSecretStore**
An ESO resource that configures HOW to connect to the external secret backend (which AWS region, which IAM role to use). Created once per cluster. All ExternalSecrets in any namespace reference this single store.

**DynaKube**
A Kubernetes Custom Resource defined by the Dynatrace Operator CRD. It configures what the Operator deploys: OneAgent DaemonSet (`classicFullStack`), log monitoring, ActiveGate. The Operator reads DynaKube and creates/manages the actual pods.

**Dynatrace OneAgent**
A software agent that Dynatrace installs on every EKS node as a DaemonSet. It automatically discovers all running services, captures metrics (CPU, response time, error rate), distributed traces, and container logs — with zero code changes to your applications.

**Dynatrace Operator**
A Kubernetes Operator that manages the lifecycle of Dynatrace components (OneAgent, ActiveGate) in your cluster. When nodes are added, it automatically installs OneAgent on them. It reads the DynaKube custom resource to determine the configuration.

**ActiveGate**
A Dynatrace component that acts as a gateway between OneAgent pods and the Dynatrace SaaS tenant. It routes monitoring data, processes log ingestion, and handles Kubernetes API monitoring. Deployed as a Kubernetes Deployment (2 replicas for HA).

**Log Monitoring (DynaKube)**
A Dynatrace OneAgent feature (`logMonitoring: enabled: true`) that reads container logs directly from `/var/log/containers/` on each node and ships them to Dynatrace Grail. Eliminates the need for a separate Fluent Bit DaemonSet.

**Dynatrace Grail**
Dynatrace's storage and query engine for logs, events, and metrics. When OneAgent ships container logs, they land in Grail and become searchable via the Logs & Events view. Queryable using DQL (Dynatrace Query Language).

**Management Zone (Dynatrace)**
A Dynatrace configuration that groups entities by tag. The `payments` Management Zone includes all services tagged `team:payments` and `environment:production`. Used to scope dashboards, alerting profiles, and UI filtering to what each team owns.

**Custom Metric Event (Dynatrace)**
A Dynatrace alert based on a fixed threshold on a specific metric. Example: "fire when payment-service error rate > 0.5% for 3 consecutive minutes." Different from Davis AI anomaly detection — this fires at the specific number regardless of historical baseline.

**SLO (Service Level Objective)**
A reliability target expressed as a percentage over a rolling window. "payment-service must be 99.9% available over 30 days." Dynatrace measures the actual availability, tracks the error budget, and fires burn rate alerts before the SLO is breached.

**Burn Rate Alert (Dynatrace SLO)**
An alert that fires when the SLO error budget is being consumed too fast. 14.4× burn rate = the monthly budget will be exhausted in 2 days → page immediately. 3× burn rate = exhausted in 10 days → Slack warning. Catches problems before the SLO is actually violated.

**Synthetic Monitor (Dynatrace)**
A Dynatrace feature that makes real HTTP requests to your service's health endpoint from global locations (Tokyo, Singapore) every 5 minutes. Detects downtime even when no real users are making requests. Works even if the entire cluster is down.

**Helm Chart**
A package of Kubernetes YAML templates with configurable values. The `charts/payment-service/` chart contains Deployment, Service, Ingress, HPA, PDB, ServiceAccount, and ExternalSecret templates. ArgoCD renders it with the values in the Application spec.

**values.yaml (Helm)**
The default configuration file for a Helm chart. Contains all tunable parameters (image tag, resource limits, replica count). The ArgoCD Application spec overrides specific values (like the image tag that GitHub Actions updates on every deploy).

**HPA (HorizontalPodAutoscaler)**
A Kubernetes resource that automatically scales the number of pod replicas based on CPU or memory utilisation. Min: 3 pods (one per AZ for HA). Max: 20 pods (cost ceiling). Target: 70% CPU — scale out before saturation.

**PDB (PodDisruptionBudget)**
A Kubernetes resource that limits how many pods can be simultaneously unavailable during voluntary disruptions (rolling updates, node drains). `minAvailable: 2` ensures at least 2 pods are always running, preventing zero-downtime deployments from having zero pods.

**Ingress (Kubernetes)**
A Kubernetes resource that defines routing rules for HTTP/HTTPS traffic into the cluster. The AWS Load Balancer Controller reads the Ingress annotations and creates an Application Load Balancer in AWS that routes traffic to the pods.

**AWS Load Balancer Controller**
A Kubernetes controller that watches Ingress objects and creates/manages AWS ALBs and NLBs. When you create a Kubernetes Ingress with ALB annotations, the controller calls the AWS API to provision the actual load balancer.

**Topology Spread Constraints**
A Kubernetes pod scheduling rule that distributes pods evenly across Availability Zones or nodes. `maxSkew: 1` means no AZ can have more than 1 extra pod compared to the least-populated AZ. Prevents all pods from landing in one AZ (single point of failure).

**Pod Anti-Affinity**
A Kubernetes scheduling rule that prevents two pods of the same service from running on the same node. If one node fails, the service still has pods on other nodes. Combined with topology spread: pods are spread across both AZs and nodes.

**Liveness Probe**
A Kubernetes health check that determines if a container is alive. Fails → Kubernetes restarts the container. Used for: detecting deadlocks, stuck processes. `GET /health/live` — returns 200 if the process is functioning.

**Readiness Probe**
A Kubernetes health check that determines if a container is ready to serve traffic. Fails → Kubernetes removes the pod from the Service endpoints (no traffic sent to it). Used for: waiting for startup, detecting when a dependency (DB) is unavailable.

**Startup Probe**
A Kubernetes health check that runs ONLY during startup. It prevents the liveness probe from killing a slow-starting container before it has time to initialise. `failureThreshold: 30` = allow 5 minutes for startup.

**ECR (Elastic Container Registry)**
AWS's private Docker image registry. GitHub Actions pushes built images here. EKS nodes pull images from here (via VPC endpoint — no NAT Gateway cost). IRSA roles give nodes permission to pull.

**OIDC Authentication (GitHub Actions)**
A mechanism that lets GitHub Actions assume an AWS IAM role without storing long-lived AWS credentials as GitHub Secrets. GitHub provides a signed JWT token; AWS validates it and issues temporary credentials (expires in 1 hour). More secure than static access keys.

**Multi-arch Docker Build**
Building a Docker image for multiple CPU architectures simultaneously (`linux/amd64` and `linux/arm64`). Required when EKS nodes use AWS Graviton (ARM-based) processors. Docker Buildx handles the cross-compilation; EKS pulls the correct architecture automatically.

**Commit SHA Tag (Docker)**
Using the Git commit SHA as the Docker image tag (e.g., `abc1234def`). This tag is immutable — it always refers to exactly that code commit. Enables: precise rollback (change tag to previous SHA), audit trail, no ambiguity about what version is running.

**`[skip ci]` commit message**
A convention in the commit message that tells GitHub Actions NOT to trigger a workflow for that commit. Used when GitHub Actions itself commits a file (like updating the image tag in gitops) to prevent an infinite loop of CI runs.

**Kyverno**
A Kubernetes-native policy engine. Policies are written as Kubernetes resources (not separate OPA Rego). In this project: enforces resource limits on all pods, requires team/app labels (needed for Dynatrace auto-tagging).

**Deduplication Key (PagerDuty)**
A string that uniquely identifies an ongoing incident. Dynatrace automatically uses its Problem ID as the dedup key when sending events to PagerDuty. Multiple events from the same Problem create/update ONE PagerDuty incident instead of many.

**Linting**
Automated code quality checks. `terraform fmt --check` verifies Terraform formatting. Runs in CI on PRs to catch issues before human review. A failing lint check blocks merge.

**Remote State (Terraform)**
Storing the `terraform.tfstate` file in S3 (not locally). Multiple engineers and CI/CD pipelines share the same state file. DynamoDB prevents two applies running simultaneously (state locking). Never commit tfstate to Git.

**`for_each` (Terraform)**
A Terraform meta-argument that creates one resource instance per item in a map or set. In `metric-events.tf`: `for_each = var.services` creates one error rate alert per service. Adding a service to the map automatically creates the alert — no duplicate code.
