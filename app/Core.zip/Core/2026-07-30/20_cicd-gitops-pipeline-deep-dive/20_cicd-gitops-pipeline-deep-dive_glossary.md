# CI/CD + GitOps + Infrastructure Pipeline — Glossary

**CI/CD (Continuous Integration / Continuous Delivery)**
CI = automatically build and test code on every commit. CD = automatically deploy tested code to environments. Together they turn "push code" into "code is running in production." Why it matters: eliminates manual steps that cause errors, delays, and "works on my machine" problems.

**GitOps**
An operational model where Git is the single source of truth for both application configuration and infrastructure state. Changes are made via Pull Requests; automated systems (ArgoCD, Terraform) apply them. Why it matters: every production change has an author, a code review, and an audit trail in Git history.

**GitHub Actions**
GitHub's built-in CI/CD platform. Workflow files in `.github/workflows/` define automated jobs that run on events (push, PR, schedule). Why it matters: no separate CI server to manage; pipelines live in the same repo as the code.

**`.github/workflows/app-ci.yaml`**
The workflow file that builds the Docker image, runs tests, pushes to ECR, and updates the GitOps manifest with the new image tag. Triggers on pushes to `main` that change `app/` files. Why it matters: the automation that bridges developer commits and deployments.

**`github.sha`**
The Git commit SHA (hash) of the commit that triggered the GitHub Actions run. Example: `abc1234def56789`. Used as the Docker image tag. Why it matters: immutable, traceable — you can always find the exact code that produced any running container.

**ECR (Elastic Container Registry)**
AWS's private Docker image registry. Stores the Docker images your application runs on. Why it matters: keeps images in your AWS account (no Docker Hub rate limits, no public exposure, integrated with IAM).

**`docker build`**
Builds a Docker container image from a `Dockerfile`. Takes the application code and packages it into a single immutable artifact. Why it matters: ensures the app always runs with exactly the dependencies defined in `requirements.txt`.

**`docker push`**
Uploads a built Docker image to a container registry (ECR). After this step, Kubernetes nodes can pull and run the image. Why it matters: makes the image available to all nodes in the EKS cluster.

**Image Tag**
A label attached to a Docker image version. In this pipeline: the Git commit SHA is used as the tag. `:latest` is dangerous (changes unpredictably); a SHA is immutable. Why it matters: knowing the image tag tells you exactly what code is running in production.

**GitOps Manifest**
A YAML file (like `values-prod.yaml`) stored in Git that declares the desired state of an application. ArgoCD reads these files to know what to deploy. Why it matters: the interface between CI (which writes the image tag) and CD (ArgoCD which reads it).

**`values-prod.yaml`**
A Helm values file containing production-specific configuration (image tag, replica count, resource limits). Updated by CI when a new image is built. ArgoCD reads it when rendering the Helm chart. Why it matters: the one file that connects the CI pipeline to ArgoCD deployments.

**ArgoCD**
A GitOps continuous delivery tool that runs inside Kubernetes. It watches Git for changes to application manifests and automatically applies them to the cluster. Why it matters: ensures the cluster always matches what Git says — no manual `kubectl apply` needed.

**ArgoCD Application (CRD)**
A Kubernetes Custom Resource (`kind: Application`) that tells ArgoCD: which Git repo to watch, which path inside it, and which cluster/namespace to deploy to. Why it matters: registers your application with ArgoCD so it can manage its lifecycle.

**Helm Chart**
A package of Kubernetes YAML templates with configurable values. ArgoCD renders a Helm chart by combining `templates/*.yaml` with values from `values-prod.yaml` to produce actual Kubernetes manifests. Why it matters: avoids duplicating Kubernetes YAML for each environment — one chart, different values per environment.

**`helm upgrade --install`**
The Helm command that creates or updates a release in Kubernetes. ArgoCD runs this internally when it syncs an application. Why it matters: Helm handles the complexity of creating, updating, and rolling back Kubernetes resources.

**`_helpers.tpl`**
A Helm template file that defines reusable template functions (like generating the app's full name from chart name + release name). Called by other templates with `{{ include "chart.name" . }}`. Why it matters: avoids duplicating naming logic across all template files.

**Rolling Update**
A Kubernetes deployment strategy that replaces old pods one at a time with new ones. `maxUnavailable: 0` ensures there are always healthy pods serving traffic. Why it matters: zero-downtime deployments — users never experience an outage during a deploy.

**Readiness Probe**
A Kubernetes health check on a specific HTTP endpoint. Only when it returns 200 does Kubernetes add the pod to the Service endpoints (start sending traffic). Why it matters: prevents traffic from reaching pods that aren't ready yet (still starting up, not connected to DB).

**Liveness Probe**
A Kubernetes health check that kills and restarts the container if it fails. Different from readiness: readiness removes from traffic, liveness restarts. Why it matters: automatically recovers from hung/deadlocked processes without human intervention.

**Startup Probe**
A Kubernetes health check that runs ONLY during container startup. Prevents the liveness probe from killing a container that's still initialising. Why it matters: JVM apps and large Python apps can take 30+ seconds to start — startup probe gives them time without being killed prematurely.

**`preStop` hook**
A lifecycle hook that runs before Kubernetes sends SIGTERM to a container. Used here: `sleep 15` — gives the load balancer 15 seconds to stop routing traffic to the pod before it starts shutting down. Why it matters: prevents "connection refused" errors during rolling updates.

**`terminationGracePeriodSeconds`**
How long Kubernetes waits after sending SIGTERM before force-killing (`SIGKILL`) the container. Default: 30 seconds. Here: 60 seconds. Why it matters: allows in-flight requests to complete before the process dies.

**OIDC (GitHub Actions → AWS)**
A token exchange mechanism. GitHub Actions generates a short-lived JWT for the job. AWS STS validates it and returns temporary credentials. No static access keys stored in GitHub. Why it matters: if GitHub is compromised, there are no long-lived AWS credentials to steal.

**IAM Role for GitHub Actions**
An AWS IAM role with a trust policy allowing GitHub Actions (via OIDC) to assume it. Two roles exist: plan role (read-only) and apply role (can create/modify resources). Why it matters: the plan role can't make real changes — a mistake in plan is safe; only apply (with human approval) changes infrastructure.

**`environment: production` (GitHub Actions)**
A GitHub Actions job setting that requires a named reviewer to approve the job before it runs. Used on the `terraform apply` job for AWS infrastructure. Why it matters: human gate preventing accidental infrastructure changes from auto-applying.

**Terraform Backend (S3)**
Remote storage for the Terraform state file in an S3 bucket with DynamoDB locking. State records every resource Terraform manages and its current values. Why it matters: shared state enables team collaboration; DynamoDB lock prevents two people applying simultaneously and corrupting state.

**`terraform plan`**
A read-only Terraform command that shows what WOULD change without making any changes. Output is posted as a PR comment so reviewers can see the impact. Why it matters: the preview step — engineers review the plan before approving a deploy.

**`terraform apply -auto-approve`**
Applies the Terraform configuration to real infrastructure without interactive confirmation. Safe in CI because a human reviewed the plan and approved the PR. Why it matters: automated apply removes the manual step while maintaining human review via the PR process.

**`terraform plan -refresh-only`**
Checks if the real infrastructure matches Terraform's state file WITHOUT computing changes from `.tf` files. Used for drift detection. Why it matters: detects if someone changed Dynatrace (or AWS) manually outside of Terraform.

**Drift Detection**
The daily scheduled check (`terraform plan -refresh-only`) that compares real Dynatrace configuration against Terraform's state. If they differ, someone changed Dynatrace via the UI. Why it matters: enforces GitOps discipline — only code changes should change configuration.

**`-detailed-exitcode`**
A `terraform plan` flag that returns exit code 2 when changes are detected (instead of the usual 0). Used in drift detection to programmatically check "were any changes found?" Why it matters: enables shell scripts to act differently based on whether drift was detected.

**Dynatrace Terraform Provider**
A Terraform plugin that knows how to create/update/delete Dynatrace configuration (management zones, alerts, SLOs, synthetic monitors) via the Dynatrace API. Why it matters: enables monitoring-as-code — Dynatrace config is versioned, reviewed, and reproducible.

**Management Zone (Dynatrace)**
A filter in Dynatrace that groups monitored entities (services, pods, hosts) by common attributes (Kubernetes namespace, tags, etc.). Used to scope dashboards and alerts. Why it matters: without it, alerts and dashboards show data from ALL services — you can't tell which team's service has the problem.

**SLO (Service Level Objective)**
A reliability target: "99.9% of payment requests must succeed over 30 days." Tracks error budget (how much failure is still within the target). Why it matters: makes "is the service reliable enough?" measurable — when budget runs out, freeze new features and fix reliability.

**Synthetic Monitor (Dynatrace)**
A scheduled HTTP request from Dynatrace's global infrastructure to your endpoint. Tests availability even when no real users are present. Why it matters: detects outages at 3am when traffic is zero — real users don't test your service, synthetic monitors do.

**`dynatrace_metric_events`**
A Terraform resource that creates a custom threshold alert in Dynatrace. When a metric (CPU, error rate, latency) exceeds the threshold for N consecutive measurements, it fires. Why it matters: the alerting rules that determine when PagerDuty pages on-call.

**`violating_samples` / `dealerting_samples`**
Alert tuning parameters. `violating_samples = 3` means the threshold must be exceeded for 3 consecutive measurements before alerting (prevents flapping). `dealerting_samples = 5` means it must be below threshold for 5 measurements before clearing. Why it matters: prevents false alarms from transient spikes while still catching sustained problems.

**Dynatrace OneAgent**
The Dynatrace monitoring agent that runs as a Kubernetes DaemonSet on every EKS node. Auto-discovers all services, collects metrics, traces requests. Why it matters: zero-configuration monitoring — deploying a new pod is automatically monitored with no code changes.

**Auto-Tagging (Dynatrace)**
Dynatrace rules that automatically apply tags to monitored entities based on their attributes. Example: tag all services in the `payments` namespace with `application:payment-service`. Why it matters: new services are automatically tagged without manual work; management zones and alert filters use these tags.

**`argocd app rollback`**
An ArgoCD command that redeploys the application using the manifest state from a previous sync (previous Git revision). Faster than reverting the code in Git. Why it matters: during an incident, rolling back takes seconds instead of waiting for a new CI build.

**IRSA (IAM Roles for Service Accounts)**
An EKS feature where Kubernetes pods get their own AWS IAM credentials based on their ServiceAccount. No static credentials needed; credentials rotate every 15 minutes. Why it matters: each microservice only has the AWS permissions it needs — a compromised pod can't access other services' resources.

**`imagePullPolicy: IfNotPresent`**
Tells Kubernetes to use the locally cached image if it already exists on the node, instead of always pulling from ECR. Why it matters: faster pod startup; reduces ECR API calls and data transfer costs.

**`path:` filter (GitHub Actions)**
A workflow trigger filter that only fires the workflow when specific file paths change. `paths: ['app/**']` means the app CI only runs when `app/` files are modified. Why it matters: prevents the Dynatrace pipeline from running when only app code changed (and vice versa) — reduces unnecessary CI runs.

**Secrets Manager (AWS)**
AWS's service for storing and rotating secrets (API tokens, passwords). The Dynatrace API token is stored here and fetched at Terraform runtime. Why it matters: secrets are never written into `.tf` files or Git — only the secret name/path is in code.

**DaemonSet**
A Kubernetes object that ensures a specific pod runs on EVERY node in the cluster. Used for: Dynatrace OneAgent (monitoring on all nodes), Fluent Bit (log collection from all nodes), Node Exporter (metrics from all nodes). Why it matters: infrastructure agents need to run everywhere — DaemonSet handles this automatically as nodes are added.
