# CI/CD + GitOps + Infrastructure Pipeline — Deep Dive

> This document explains every step of the two pipelines shown: the **application pipeline** (developer pushes code → app runs in EKS) and the **infrastructure pipeline** (platform engineer changes config → AWS infra + Dynatrace updated). Every arrow in the diagram is a real, concrete operation with files, commands, and logic.

---

## The Big Picture: Two Separate Pipelines, One Platform

```
WHO changes it        WHAT they change          HOW it gets deployed
─────────────────────────────────────────────────────────────────────
Developer             Application code          App CI Pipeline → GitOps → ArgoCD → EKS
Platform Engineer     AWS Infrastructure        Terraform Infra Pipeline → AWS APIs
Platform Engineer     Monitoring config         Terraform Dynatrace Pipeline → Dynatrace APIs
```

**Why two separate pipelines for infrastructure?**
- AWS infra (`terraform/`) changes are high-risk (wrong change = cluster down)
- Dynatrace config changes are low-risk (wrong alert threshold = noisy alerts, not an outage)
- Different risk levels → different approval gates, different rollback strategies

---

## PIPELINE 1: Application Delivery (Developer → EKS)

### Step 1: Developer Pushes Code

```
Developer:
  git add app/main.py
  git commit -m "feat: add retry logic to payment processor"
  git push origin feature/retry-logic

  → Opens a Pull Request on GitHub
  → PR triggers: lint, unit tests (from app-ci.yaml — the "check" phase)
  → PR is reviewed and approved by a colleague
  → PR is merged to main
  → MERGE triggers the full CI pipeline (the "build and deploy" phase)
```

---

### Step 2: `.github/workflows/app-ci.yaml` — Build, Test, Publish

```yaml
# .github/workflows/app-ci.yaml
name: Application CI/CD

on:
  push:
    branches: [main]
    paths: ['app/**']        # ← only triggers when app/ files change
  pull_request:
    paths: ['app/**']

jobs:
  build-and-push:
    runs-on: ubuntu-latest
    permissions:
      id-token: write       # OIDC for AWS credentials (no stored secrets)
      contents: write       # to commit the new image tag back to Git

    steps:
      # 1. Get the code
      - uses: actions/checkout@v4

      # 2. Get temporary AWS credentials via OIDC
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/github-actions-app-ci
          aws-region: ap-northeast-1

      # 3. Authenticate Docker to ECR
      - run: aws ecr get-login-password | docker login --username AWS --password-stdin 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com

      # 4. Run tests BEFORE building the image
      - name: Run unit tests
        run: |
          cd app
          pip install -r requirements.txt
          python -m pytest tests/ -v --tb=short

      # 5. Build the Docker image with a unique tag
      - name: Build Docker image
        run: |
          IMAGE_TAG="${{ github.sha }}"    # ← uses the Git commit SHA as the image tag
          # e.g. "abc1234def5678" — immutable, traceable, unique
          docker build -t 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service:$IMAGE_TAG app/

      # 6. Push to ECR
      - name: Push to ECR
        run: |
          IMAGE_TAG="${{ github.sha }}"
          docker push 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service:$IMAGE_TAG

      # 7. Update the GitOps manifest with the new image tag
      # This is the CRITICAL step that connects CI to CD (ArgoCD)
      - name: Update image tag in GitOps repo
        run: |
          IMAGE_TAG="${{ github.sha }}"
          # Modify the Helm values file to point to the new image
          sed -i "s|tag: .*|tag: \"$IMAGE_TAG\"|" \
            gitops/app/payment-service/values-prod.yaml

          git config user.name "github-actions[bot]"
          git config user.email "github-actions[bot]@users.noreply.github.com"
          git add gitops/app/payment-service/values-prod.yaml
          git commit -m "chore: update payment-service image to $IMAGE_TAG"
          git push
```

**Why use the Git commit SHA as the image tag?**
- Immutable: once pushed, `abc1234def56` always refers to this exact image build
- Traceable: you can always find the Git commit that produced any running image
- `:latest` is dangerous: if the image for `:latest` changes, pods restart with unknown code

---

### Step 3: `app/Dockerfile` + `app/main.py` — The Application

```dockerfile
# app/Dockerfile
FROM python:3.12-slim

# Security: run as non-root user
RUN addgroup --system app && adduser --system --ingroup app app

WORKDIR /app

# Install dependencies first (Docker layer caching — faster rebuilds)
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY main.py .

# Switch to non-root
USER app

# Port the app listens on (must match Helm chart's containerPort)
EXPOSE 8080

HEALTHCHECK --interval=30s --timeout=10s --start-period=60s --retries=3 \
  CMD curl -f http://localhost:8080/health || exit 1

CMD ["python", "main.py"]
```

```python
# app/main.py
from flask import Flask, jsonify
import time
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')

@app.route('/health')
def health():
    # This endpoint is what the Kubernetes liveness/readiness probes call
    # Must return 200 quickly (< 5 seconds) or the probe fails
    return jsonify({"status": "ok", "service": "payment-service"})

@app.route('/ready')
def ready():
    # Readiness probe: only return 200 when the app is fully initialised
    # (DB connected, cache warmed up, etc.)
    return jsonify({"ready": True})

@app.route('/v1/payments', methods=['POST'])
def create_payment():
    # Business logic here
    logging.info("Processing payment request")
    return jsonify({"payment_id": "pay_123", "status": "processing"}), 201

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
```

---

### Step 4: `gitops/app/payment-service/` — What ArgoCD Watches

This is where the **CI pipeline writes** and **ArgoCD reads**. The split between these two systems is the GitOps boundary.

```
gitops/
  app/
    payment-service/
      application.yaml        ← ArgoCD Application CRD (tells ArgoCD about this app)
      values-prod.yaml         ← Helm values for production (CI updates the image tag here)
      values-staging.yaml      ← Helm values for staging (different tag, different replicas)
```

```yaml
# gitops/app/payment-service/application.yaml
# This file is what makes ArgoCD aware of this application.
# ArgoCD reads this and starts watching the gitops/ path.
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: payment-service
  namespace: argocd
spec:
  project: payments-team

  source:
    repoURL: https://github.com/company/platform
    targetRevision: HEAD       # always watch the latest commit on main
    path: charts/payment-service   # where the Helm chart lives
    helm:
      valueFiles:
        - ../../gitops/app/payment-service/values-prod.yaml  # production values

  destination:
    server: https://kubernetes.default.svc
    namespace: payments

  syncPolicy:
    automated:
      prune: true        # delete resources removed from Git
      selfHeal: true     # revert manual kubectl changes
    syncOptions:
      - CreateNamespace=true
```

```yaml
# gitops/app/payment-service/values-prod.yaml
# CI pipeline WRITES to this file (updates the image tag)
# ArgoCD READS this file (uses the tag to deploy the right image)

replicaCount: 3

image:
  repository: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  tag: "abc1234def56"   # ← THIS LINE IS UPDATED BY CI PIPELINE automatically

resources:
  requests:
    cpu: "250m"
    memory: "256Mi"
  limits:
    cpu: "500m"
    memory: "512Mi"

autoscaling:
  enabled: true
  minReplicas: 3
  maxReplicas: 20
  targetCPUUtilizationPercentage: 70

ingress:
  enabled: true
  host: payment.company.com
```

**The GitOps contract:**
- CI writes ONLY the image tag in `values-prod.yaml`
- ArgoCD reads the Helm values and renders the full Kubernetes YAML
- ArgoCD applies it to EKS
- No CI/CD pipeline has `kubectl apply` access to production — ONLY ArgoCD does

---

### Step 5: `charts/payment-service/` — The Helm Chart

```
charts/payment-service/
  Chart.yaml          ← chart metadata (name, version, description)
  values.yaml         ← default values (overridden by values-prod.yaml)
  templates/
    deployment.yaml   ← Kubernetes Deployment template
    service.yaml      ← Kubernetes Service template
    hpa.yaml          ← HorizontalPodAutoscaler template
    ingress.yaml      ← Ingress (ALB) template
    serviceaccount.yaml ← ServiceAccount with IRSA annotation
    _helpers.tpl      ← reusable template helpers (name generation)
```

```yaml
# charts/payment-service/templates/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "payment-service.fullname" . }}
  namespace: {{ .Release.Namespace }}
  labels:
    {{- include "payment-service.labels" . | nindent 4 }}
spec:
  replicas: {{ .Values.replicaCount }}
  selector:
    matchLabels:
      {{- include "payment-service.selectorLabels" . | nindent 6 }}
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 0      # NEVER have 0 pods during update
      maxSurge: 1            # have 1 extra pod during update
  template:
    metadata:
      labels:
        {{- include "payment-service.selectorLabels" . | nindent 8 }}
        # Dynatrace auto-tagging will match on these labels
        app.kubernetes.io/version: {{ .Values.image.tag | quote }}
    spec:
      serviceAccountName: {{ include "payment-service.serviceAccountName" . }}

      # Security: run as non-root
      securityContext:
        runAsNonRoot: true
        runAsUser: 1000
        fsGroup: 1000

      containers:
        - name: payment-service
          image: "{{ .Values.image.repository }}:{{ .Values.image.tag }}"
          imagePullPolicy: IfNotPresent  # use cached image (faster restarts)
          ports:
            - name: http
              containerPort: 8080

          # Health probes (critical for zero-downtime rolling updates)
          startupProbe:
            httpGet: { path: /health, port: 8080 }
            failureThreshold: 30     # allow up to 5 minutes to start
            periodSeconds: 10

          readinessProbe:
            httpGet: { path: /ready, port: 8080 }
            initialDelaySeconds: 5
            periodSeconds: 10
            failureThreshold: 3      # remove from LB after 3 failures

          livenessProbe:
            httpGet: { path: /health, port: 8080 }
            initialDelaySeconds: 30
            periodSeconds: 15
            failureThreshold: 3      # restart after 3 failures

          resources:
            requests:
              cpu: {{ .Values.resources.requests.cpu }}
              memory: {{ .Values.resources.requests.memory }}
            limits:
              cpu: {{ .Values.resources.limits.cpu }}
              memory: {{ .Values.resources.limits.memory }}

          # Graceful shutdown: finish in-flight requests before dying
          lifecycle:
            preStop:
              exec:
                command: ["/bin/sh", "-c", "sleep 15"]

      terminationGracePeriodSeconds: 60
```

---

### Step 6: ArgoCD → EKS — How the Deploy Actually Happens

```
Time 0:   CI pushes new image tag to gitops/app/payment-service/values-prod.yaml
Time ~3m: ArgoCD polls Git (default: every 3 minutes)
           OR immediately if GitHub webhook is configured
Time 3m:  ArgoCD detects values-prod.yaml changed (OutOfSync)
Time 3m+: ArgoCD renders the Helm chart with new values
           → produces new deployment.yaml with image tag abc1234def56
           → applies it to EKS via kubectl apply
Time 4m:  Kubernetes starts rolling update:
           → new pod starts (with new image)
           → readiness probe passes → new pod added to Service endpoints
           → old pod removed from Service endpoints → graceful shutdown
           → repeat for each replica (3 total)
Time 6m:  All 3 replicas running new image
Time 6m:  ArgoCD marks application as Synced + Healthy
```

---

## PIPELINE 2: Infrastructure (Platform Engineer → AWS)

### Step 1: `.github/workflows/terraform-infra.yaml` — AWS Infrastructure

```yaml
# .github/workflows/terraform-infra.yaml
name: Terraform Infrastructure

on:
  push:
    branches: [main]
    paths: ['terraform/**', '!terraform/dynatrace/**']  # excludes dynatrace
  pull_request:
    paths: ['terraform/**', '!terraform/dynatrace/**']

jobs:
  plan:
    name: Terraform Plan
    runs-on: ubuntu-latest
    if: github.event_name == 'pull_request'
    permissions:
      id-token: write
      pull-requests: write

    steps:
      - uses: actions/checkout@v4

      - name: Configure AWS (OIDC — no stored keys)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/github-actions-terraform-plan
          aws-region: ap-northeast-1

      - run: terraform -chdir=terraform init -input=false
      - run: terraform -chdir=terraform plan -no-color -out=tfplan.binary 2>&1 | tee plan.txt

      - name: Post plan to PR comment
        uses: actions/github-script@v7
        with:
          script: |
            const plan = require('fs').readFileSync('plan.txt', 'utf8')
            github.rest.issues.createComment({
              ...context.repo,
              issue_number: context.issue.number,
              body: '## Terraform Plan\n```hcl\n' + plan.slice(0, 60000) + '\n```'
            })

  apply:
    name: Terraform Apply
    runs-on: ubuntu-latest
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
    environment: production   # ← requires human approval in GitHub UI

    steps:
      - uses: actions/checkout@v4

      - name: Configure AWS (apply role — different permissions than plan)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/github-actions-terraform-apply
          aws-region: ap-northeast-1

      - run: terraform -chdir=terraform init -input=false
      - run: terraform -chdir=terraform apply -auto-approve -input=false
```

---

### Step 2: `terraform/` — What the Root Module Creates

```
terraform/
  main.tf          ← orchestrates all modules
  versions.tf      ← Terraform + provider versions
  variables.tf     ← input variables
  outputs.tf       ← outputs (cluster endpoint, etc.)
  backend.tf       ← S3 state backend

  modules/
    vpc/            ← VPC, subnets, NAT gateways, route tables
    eks/            ← EKS cluster, node groups, OIDC provider
    iam/            ← IAM roles for IRSA, CI/CD, node groups
    ecr/            ← ECR repositories for Docker images
```

```hcl
# terraform/main.tf (simplified)
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  name    = "prod-vpc"
  cidr    = "10.0.0.0/16"
  azs     = ["ap-northeast-1a", "ap-northeast-1c", "ap-northeast-1d"]
  private_subnets = ["10.0.10.0/22", "10.0.14.0/22", "10.0.18.0/22"]
  public_subnets  = ["10.0.1.0/24",  "10.0.2.0/24",  "10.0.3.0/24"]
  enable_nat_gateway = true
  single_nat_gateway = false  # one per AZ for HA
}

module "eks" {
  source          = "terraform-aws-modules/eks/aws"
  name            = "prod-eks"
  kubernetes_version = "1.31"
  vpc_id          = module.vpc.vpc_id
  subnet_ids      = module.vpc.private_subnets

  eks_managed_node_groups = {
    workers = {
      instance_types = ["m5.xlarge"]
      min_size       = 3
      max_size       = 10
      desired_size   = 3
    }
  }

  enable_cluster_creator_admin_permissions = true
}

module "ecr" {
  source         = "./modules/ecr"
  repository_name = "payment-service"
  # Lifecycle policy: keep last 30 images, delete untagged after 7 days
}
```

---

## PIPELINE 3: Dynatrace Monitoring (`terraform/dynatrace/`)

### Why a Separate Pipeline?

```
terraform/ (AWS infra):     HIGH RISK
  Wrong change → EKS cluster down → all services down
  → Requires: human approval gate, careful review, maintenance window

terraform/dynatrace/ (monitoring): LOWER RISK
  Wrong alert threshold → noisy alerts or missed alerts
  → Can be fixed immediately with another commit
  → No approval gate needed for most changes
  → Runs more frequently (monitoring config changes often)
```

### Step 1: `.github/workflows/terraform-dynatrace.yaml`

```yaml
name: Dynatrace Terraform

on:
  push:
    branches: [main]
    paths: ['terraform/dynatrace/**']    # ONLY triggers for dynatrace changes
  pull_request:
    paths: ['terraform/dynatrace/**']
  schedule:
    - cron: '0 6 * * *'    # daily drift detection at 06:00 UTC

jobs:
  plan:
    if: github.event_name == 'pull_request'
    # ... same pattern as infra pipeline

  apply:
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
    # NO environment gate (lower risk than AWS infra)
    steps:
      - run: terraform -chdir=terraform/dynatrace apply -auto-approve

  drift:
    if: github.event_name == 'schedule'
    steps:
      - run: |
          # Checks if someone changed Dynatrace manually in the UI
          terraform -chdir=terraform/dynatrace plan -refresh-only -detailed-exitcode
          if [ $? -eq 2 ]; then
            echo "DRIFT DETECTED — someone changed Dynatrace outside of Terraform"
            # Creates a GitHub Issue and Slack alert
          fi
```

---

### Step 2: `terraform/dynatrace/` — Monitoring as Code

```
terraform/dynatrace/
  provider.tf          ← Dynatrace provider + credentials from Secrets Manager
  variables.tf         ← service names, thresholds, SLO targets
  management-zones.tf  ← logical groupings of monitored entities
  alerting-profiles.tf ← which problems page who
  metric-alerts.tf     ← custom threshold alerts (error rate, latency)
  slos.tf              ← Service Level Objectives
  synthetic-monitors.tf ← health checks from global locations
  notifications.tf     ← Slack webhooks, PagerDuty routing keys
  dashboards.tf        ← Four Golden Signals dashboard
  tagging.tf           ← auto-tagging rules
```

```hcl
# terraform/dynatrace/provider.tf
# Credentials from Secrets Manager (never hardcoded in .tf files)
data "aws_secretsmanager_secret_version" "dynatrace" {
  secret_id = "prod/dynatrace/api-token"
}

provider "dynatrace" {
  dt_env_url   = jsondecode(data.aws_secretsmanager_secret_version.dynatrace.secret_string).tenant_url
  dt_api_token = jsondecode(data.aws_secretsmanager_secret_version.dynatrace.secret_string).api_token
}
```

```hcl
# terraform/dynatrace/management-zones.tf
# Groups all EKS resources for payment-service into one view
resource "dynatrace_management_zone_v2" "payment_service" {
  name = "payment-service — production"

  rules {
    type    = "ME"
    enabled = true
    conditions {
      key { attribute = "KUBERNETES_NAMESPACE_NAME" }
      string_comparison {
        operator = "EQUALS"
        value    = "payments"
      }
    }
  }
}
```

```hcl
# terraform/dynatrace/slos.tf
# Defines the SLO contract: "99.9% of payment requests must succeed"
resource "dynatrace_slo_v2" "payment_availability" {
  name        = "payment-service — 99.9% Availability"
  enabled     = true
  type        = "AGGREGATE"
  target      = 99.9      # 99.9% success rate target
  warning     = 99.95     # warn at 99.95% (50% budget consumed)
  timeframe   = "-30d"    # measured over 30-day rolling window

  metric_numerator   = "builtin:service.errors.total.successCount"
  metric_denominator = "builtin:service.requestCount.total"
  filter             = "type(SERVICE),entityName(payment-service)"
}
```

```hcl
# terraform/dynatrace/metric-alerts.tf
# Alert on EKS pod CPU saturation (leading indicator before latency degrades)
resource "dynatrace_metric_events" "pod_cpu_critical" {
  enabled     = true
  summary     = "payment-service pods CPU > 85%"
  event_type  = "PERFORMANCE_EVENT"

  metric_selector = "builtin:container.cpu.usagePercent
    :filter(and(eq(k8s.namespace.name,payments)))
    :splitBy(dt.entity.container_group_instance):avg"

  model_properties {
    type               = "STATIC_THRESHOLD"
    threshold          = 85
    alert_condition    = "ABOVE"
    violating_samples  = 3
    samples            = 5
    dealerting_samples = 5
  }
}
```

```hcl
# terraform/dynatrace/synthetic-monitors.tf
# Tests payment-service from Tokyo, Singapore, Sydney every minute
resource "dynatrace_http_monitor" "payment_health" {
  name      = "payment-service — Health Check"
  enabled   = true
  frequency = 1  # every 1 minute

  locations = [
    data.dynatrace_synthetic_location.tokyo.id,
    data.dynatrace_synthetic_location.singapore.id,
    data.dynatrace_synthetic_location.sydney.id,
  ]

  script {
    request {
      url    = "https://payment.company.com/health"
      method = "GET"
      validation {
        rules {
          type          = "httpStatusesList"
          pass_if_found = true
          value         = "200"
        }
        rules {
          type          = "textContains"
          pass_if_found = true
          value         = "\"status\":\"ok\""
        }
      }
    }
  }

  anomaly_detection {
    outage_handling {
      global_outage = true
      global_outage_policy { consecutive_runs = 2 }
    }
  }
}
```

---

## How Everything Connects: The Full Data Flow

```
1. Developer pushes code to main
   ↓
2. app-ci.yaml triggers
   → Builds Docker image with tag = git SHA
   → Pushes to ECR
   → Updates gitops/app/payment-service/values-prod.yaml with new tag
   → Commits + pushes the values file change
   ↓
3. ArgoCD detects Git changed (3-min poll OR webhook)
   → Renders Helm chart with new image tag
   → Applies rendered YAML to EKS
   → Kubernetes does rolling update (old pods replaced one by one)
   → After all pods healthy: ArgoCD marks Synced + Healthy
   ↓
4. Dynatrace OneAgent (running in EKS as DaemonSet) detects new pods
   → Auto-discovers the new deployment
   → Applies auto-tagging rules (kubernetes-namespace → "payments")
   → New version tagged: app.kubernetes.io/version: abc1234def56
   → Synthetic monitors keep testing the health endpoint throughout
   ↓
5. If deployment breaks (high error rate, latency spike):
   → Dynatrace metric alert fires
   → SNS → Lambda → PagerDuty pages on-call
   → On-call runs: argocd app rollback payment-service
   → ArgoCD redeploys previous image version
   → Dynatrace synthetic confirms recovery

6. Platform engineer changes AWS infrastructure
   → terraform-infra.yaml triggers
   → Plan posted as PR comment (review required)
   → Human approves in GitHub environment gate
   → terraform apply runs
   → If EKS node group changes: new nodes join, old nodes drain gracefully

7. Platform engineer changes monitoring thresholds
   → terraform-dynatrace.yaml triggers
   → Plan posted as PR comment
   → Auto-applies on merge (no human gate — lower risk)
   → Daily cron checks: did anyone change Dynatrace manually?
```

---

## Security Architecture: No Credentials Stored Anywhere

```
GitHub Actions → AWS:
  OIDC (not stored access keys)
  GitHub job gets a JWT → AWS STS exchanges it for temp credentials
  Credentials expire when the job ends

Application → AWS (in EKS pods):
  IRSA (IAM Roles for Service Accounts)
  Each pod has its own IAM role with minimum permissions
  Credentials rotate every 15 minutes automatically

Dynatrace API token:
  Stored in AWS Secrets Manager
  Never in Git, never in environment variables
  Fetched at Terraform plan/apply time

Docker images:
  ECR (private registry in your AWS account)
  Node IAM role has ecr:GetAuthorizationToken
  No image pull secrets needed
```

---

## Common Mistakes and How This Design Avoids Them

| Mistake | How This Pipeline Prevents It |
|---|---|
| "Works on my machine" | Docker image built in CI, not on laptop |
| Secrets in Git | OIDC for AWS, Secrets Manager for Dynatrace token |
| Direct kubectl to prod | Only ArgoCD has kubectl access; CI writes Git only |
| All-or-nothing deploys | Rolling update strategy: never 0 pods available |
| Broken deploy stays broken | Dynatrace detects error spike → page → rollback |
| Manual Dynatrace changes drift | Daily drift detection with `terraform plan -refresh-only` |
| One failure breaks all infra | Separate pipelines: dynatrace failure can't block EKS change |
| Unknown what's deployed | Image tag = Git SHA → `git show abc1234` shows what's running |
