# eks-gitops-platform — Complete Deep Dive

> Source: https://github.com/Beem0807/eks-gitops-platform
> "A realistic EKS GitOps reference implementation — not a drop-in production platform, but a working end-to-end example of how one could be built."

---

## What This Project Is

This repo is a complete, opinionated AWS EKS platform built around three core pillars:

1. **Terraform** — provisions all AWS infrastructure (VPC, EKS cluster, IAM roles, S3 buckets)
2. **ArgoCD** — manages every Kubernetes resource via GitOps (App of Apps pattern)
3. **Full observability stack** — Prometheus + Thanos + Loki + Tempo + Grafana + OTel

It is designed for engineers who want to study a realistic platform, not a toy tutorial.

---

## Repository Layout

```
eks-gitops-platform/
├── .github/workflows/     ← CI pipelines (app image, terraform, gitops lint)
├── app/                   ← SimpleTimeService: Python Flask microservice
├── charts/                ← Custom Helm charts (namespaces, raw, simple-time-service)
├── gitops/                ← All ArgoCD Application/ApplicationSet YAMLs
│   ├── bootstrap/         ← root-app.yaml (the single bootstrap entry point)
│   ├── argocd/            ← ArgoCD self-management + AppProjects
│   ├── auto-scaling/      ← Karpenter, Cluster Autoscaler, metrics-server
│   ├── networking/        ← AWS Load Balancer Controller, ExternalDNS
│   ├── storage/           ← EBS CSI driver
│   ├── backup/            ← Velero + schedule
│   ├── secrets/           ← External Secrets Operator + Reloader
│   ├── monitoring/        ← Prometheus, Thanos, Grafana
│   ├── alerts/            ← AlertManager + Slack integration
│   ├── logs/              ← Loki + Fluent Bit
│   ├── tracing/           ← Tempo + OTel Collector (2-tier)
│   ├── security/          ← Kyverno policies
│   └── app/               ← SimpleTimeService application
├── scripts/               ← Load test scripts (k6, Python)
├── docs/                  ← Design decisions, security notes, cost analysis
└── terraform/             ← VPC + EKS + IRSA roles + S3 + Secrets Manager
    ├── modules/vpc/
    ├── modules/eks/
    └── app-bootstrap/     ← Standalone quickstart path (no GitOps)
```

---

## Two Deployment Paths

```
PATH A — App Bootstrap (fastest, no GitOps):
  cd terraform/app-bootstrap && terraform apply
  → Provisions EKS + deploys SimpleTimeService directly (no ArgoCD)
  → Use: quick demo, infra testing

PATH B — Full GitOps:
  export TF_VAR_alertmanager_slack_webhook_url="..."
  bash terraform/scripts/bootstrap.sh
  → Provisions EKS via Terraform
  → Applies root-app.yaml → ArgoCD takes over
  → Everything in gitops/ is synced automatically
  → Use: real platform study
```

---

## Part Index

| Part | File | Covers |
|---|---|---|
| 1 | `part1_architecture-overview/` | Full system architecture, data flow, cost |
| 2 | `part2_terraform-infra/` | VPC, EKS modules, IRSA, S3, variables |
| 3 | `part3_argocd-gitops/` | Root app, App-of-Apps, AppProjects, sync waves |
| 4 | `part4_networking/` | ALB Controller, ExternalDNS, VPC design |
| 5 | `part5_autoscaling/` | Karpenter, Cluster Autoscaler, HPA + Prometheus Adapter |
| 6 | `part6_observability/` | Prometheus, Thanos, Loki, Fluent Bit, Tempo, OTel, Grafana |
| 7 | `part7_security/` | Kyverno, External Secrets, Reloader, IRSA scoping |
| 8 | `part8_storage-backup/` | EBS CSI driver, gp3 StorageClass, Velero |
| 9 | `part9_app-and-cicd/` | SimpleTimeService, Helm chart, GitHub Actions CI |
| 10 | `part10_design-decisions/` | All 22 documented design choices + demo trade-offs |

---

## Cost at a Glance

| State | Monthly Cost |
|---|---|
| Idle running (on-demand, ap-south-1) | $310–330 |
| Under load | $400–500 |
| Cluster torn down (S3 + Route53 + SM) | < $10 |
