# eks-gitops-platform — Glossary

**App-of-Apps Pattern**
An ArgoCD pattern where a root Application manages a directory of other Application/ApplicationSet objects. Apply one YAML to bootstrap the entire platform — ArgoCD discovers and manages everything else automatically.

**ApplicationSet**
An ArgoCD CRD that generates multiple Application objects from a template and a generator (e.g., a list of clusters). Enables the same GitOps manifests to deploy across multiple clusters by reading per-cluster annotations from cluster secrets.

**AppProject (ArgoCD)**
A scoping boundary in ArgoCD that restricts which source repos, destination namespaces, and Kubernetes resource types an Application can use. Prevents workload deployments from creating cluster-level security resources.

**Cluster Secret (ArgoCD)**
A Kubernetes Secret in the `argocd` namespace that represents a registered cluster. Custom annotations on this secret (bucket names, ARNs, domain) become template variables in ApplicationSets — this is how Terraform outputs flow into GitOps manifests.

**Sync Wave (`argocd.argoproj.io/sync-wave`)**
An annotation on ArgoCD Application objects that controls deployment order. Lower-numbered waves deploy first and must be healthy before higher waves begin. Ensures namespaces exist before workloads, CRDs are registered before CRD instances.

**selfHeal (ArgoCD)**
When enabled on a sync policy, ArgoCD automatically reverts manual `kubectl` changes to match the Git state. Enforces Git as the single source of truth.

**prune (ArgoCD)**
When enabled, ArgoCD deletes Kubernetes resources that exist in the cluster but no longer exist in Git. Without prune, deleted manifests leave orphaned resources running forever.

**IRSA (IAM Roles for Service Accounts)**
A Kubernetes-native way to give pods AWS credentials without access keys. Each workload has its own IAM role. The pod gets a JWT token that the AWS SDK exchanges for temporary credentials via STS.

**EBS CSI Driver**
The Container Storage Interface driver for AWS EBS. Translates Kubernetes PersistentVolumeClaim requests into real EBS volume creation and attachment operations.

**gp3 StorageClass**
AWS EBS gp3 volume type. Delivers 3,000 IOPS and 125 MB/s throughput as a flat baseline (no burst credits). ~20% cheaper per GB than gp2. Recommended for production Kubernetes storage.

**Reclaim Policy: Retain**
A PersistentVolume setting that keeps the EBS volume when the PVC is deleted. The volume enters `Released` state and must be manually deleted. Prevents accidental data loss during Helm uninstalls or rollbacks.

**Karpenter**
A Kubernetes node autoscaler that provisions EC2 instances directly (not via ASG). Provisions in < 60 seconds, selects optimal instance types for pending pods, and consolidates underutilised nodes.

**Cluster Autoscaler**
The traditional EKS node autoscaler. Scales pre-defined managed node groups by calling the ASG API. Takes 2–5 minutes to provision. Less flexible than Karpenter but simpler to configure.

**NodePool (Karpenter)**
A Karpenter CRD that defines constraints for new nodes: instance types, capacity type (Spot/on-demand), zones, and disruption policy. Karpenter selects the best match from within these constraints.

**EC2NodeClass (Karpenter)**
A Karpenter CRD that defines EC2-specific configuration: AMI selector, subnet selector, security group selector. Tells Karpenter where to find the subnets tagged with `karpenter.sh/discovery`.

**HPA (HorizontalPodAutoscaler)**
Kubernetes resource that automatically adjusts pod replica count based on metrics. Can scale on CPU, memory, or custom metrics from Prometheus via the Prometheus Adapter.

**Prometheus Adapter**
A Kubernetes API extension that registers as the `custom.metrics.k8s.io` server, exposing Prometheus query results as Kubernetes custom metrics. Enables HPA to scale on application-level signals like request rate.

**kube-prometheus-stack**
A Helm umbrella chart from the Prometheus community that installs: Prometheus, Alertmanager, Grafana, kube-state-metrics, and node-exporter in one release.

**Thanos**
An extension to Prometheus that adds: long-term S3 storage, global query federation, high availability, and data compaction. Prometheus retains 7 days; Thanos retains indefinitely in S3.

**Thanos Sidecar**
A container running alongside Prometheus that uploads TSDB blocks to S3 every 2 hours. Part of the Thanos architecture for durable metric storage.

**Thanos Query**
The Thanos component that merges live Prometheus data with historical S3 data into a single Prometheus-compatible query endpoint. Grafana uses Thanos Query (not local Prometheus) as its default datasource.

**Loki**
A log aggregation system designed by Grafana Labs. Indexes log metadata (labels) but not log content — making it much cheaper than Elasticsearch at scale. Logs are stored in S3 and queried with LogQL.

**Fluent Bit**
A lightweight log forwarder running as a DaemonSet on every Kubernetes node. Collects container logs from the node's `/var/log/containers/` directory and forwards them to Loki. Uses ~450 KB memory (vs Fluentd's ~40 MB).

**Grafana Tempo**
A distributed tracing storage backend. Stores OpenTelemetry trace data in S3 and makes it queryable via Grafana. Supports trace-to-logs correlation (click a trace → jump to related Loki logs).

**OpenTelemetry (OTel)**
An open standard for metrics, logs, and traces. The OTel Collector receives telemetry from applications and routes it to backends (Prometheus, Loki, Tempo).

**OTel Collector — Two-Tier**
A DaemonSet agent per node collects traces from local pods. A central Gateway Deployment aggregates from all agents and forwards to Tempo. Prevents Tempo backpressure from propagating to every node agent.

**Kyverno**
A Kubernetes-native policy engine running as an admission controller. Validates and mutates pod specs at creation time. In this project: audit mode only — violations are logged but pods are not blocked.

**Audit Mode (Kyverno)**
`validationFailureAction: Audit` — Kyverno reports violations but does not block them. The inventory of violations is built before switching to Enforce mode.

**External Secrets Operator (ESO)**
A Kubernetes operator that syncs secrets from external stores (AWS Secrets Manager, Vault) into Kubernetes Secrets. Uses IRSA for authentication. Refreshes on a configurable interval.

**ExternalSecret**
An ESO CRD specifying: which secret to fetch from Secrets Manager, which Kubernetes Secret to create. The ExternalSecret YAML is safe to commit to Git (contains only the secret path, not the value).

**ClusterSecretStore**
An ESO CRD defining how ESO authenticates with the secrets backend. Cluster-scoped (all namespaces can use it). References the IRSA ServiceAccount for authentication.

**Reloader**
A Kubernetes operator (from Stakater) that watches for changes to Secrets and ConfigMaps. When ESO updates a Secret, Reloader triggers a rolling restart of annotated Deployments — completing the zero-touch rotation pipeline.

**Velero**
A Kubernetes backup and restore tool. Backs up: Kubernetes resource manifests (to S3) and EBS volume snapshots. Supports scheduled backups and restore to different namespaces.

**Alertmanager**
The Prometheus alerting routing component. Receives firing alerts from Prometheus, deduplicates and groups them, and routes to configured receivers (Slack, PagerDuty, email). In this project: routes to Slack via webhook.

**AlertmanagerConfig**
A Kubernetes CRD for defining Alertmanager routing rules and receivers. Allows per-namespace alert routing configuration. The webhook URL is fetched from Secrets Manager via ESO.

**ServiceMonitor**
A Prometheus Operator CRD that tells Prometheus which pods to scrape for metrics, and at what path and interval. The SimpleTimeService Helm chart includes a ServiceMonitor so Prometheus discovers it automatically.

**PodDisruptionBudget (PDB)**
A Kubernetes policy limiting how many pods of a Deployment can be simultaneously unavailable. `minAvailable: 1` ensures at least one SimpleTimeService pod is always running during rolling updates or node drains.

**AWS Load Balancer Controller**
A Kubernetes controller that watches Ingress objects and provisions real AWS ALBs. With `target-type: ip`, routes traffic directly to pod IPs without an extra iptables hop.

**ExternalDNS**
A Kubernetes controller that watches Services and Ingresses and creates/updates Route53 DNS records automatically. `sync` policy also deletes records when resources are removed.

**`group.name` annotation (ALB)**
An ALB Ingress annotation that causes multiple Ingresses to share one ALB. Without it, each Ingress creates its own ALB ($20+/month each). With it, Grafana and other tools share one ALB.

**Taint/Toleration**
Kubernetes mechanism for dedicating nodes. A node `taint` repels pods unless the pod has a matching `toleration`. Core nodes are tainted `app=core:NoSchedule` — only infrastructure pods with the toleration can schedule there.

**SimpleTimeService**
The sample Python Flask microservice in this project. Returns current UTC timestamp and caller IP. Intentionally minimal — its purpose is to exercise all platform features (Prometheus scraping, Loki logging, Tempo tracing, HPA, ALB, DNS).

**TSDB (Time Series Database)**
Prometheus's internal storage format. Stores metrics as compressed blocks on disk. Thanos uploads these blocks to S3 for long-term retention after they reach 2 hours of age.

**`recurse: true` (ArgoCD)**
An Application source setting that makes ArgoCD recursively scan all subdirectories for Kubernetes resource YAMLs. Used by the root-app to discover all ApplicationSets and Applications in the `gitops/` directory.
