# Part 6 — terraform/modules/ & app-bootstrap/ Deep Dive

---

## terraform/modules/vpc/main.tf

```hcl
locals {
  public_subnets   = [for i, az in var.azs : cidrsubnet(var.vpc_cidr, 8, i + 1)]    # /24
  private_subnets  = [for i, az in var.azs : cidrsubnet(var.vpc_cidr, 4, i + 16)]   # /20
  database_subnets = [for i, az in var.azs : cidrsubnet(var.vpc_cidr, 8, i + 100)]  # /24
}
```

**Why three subnet tiers and different sizes:**
```
For vpc_cidr = "10.0.0.0/16":

PUBLIC subnets (/24 = 256 IPs each):
  cidrsubnet("10.0.0.0/16", 8, 1) = 10.0.1.0/24  (AZ-a)
  cidrsubnet("10.0.0.0/16", 8, 2) = 10.0.2.0/24  (AZ-b)
  cidrsubnet("10.0.0.0/16", 8, 3) = 10.0.3.0/24  (AZ-c)
  WHO LIVES HERE: NAT Gateways, internet-facing ALBs.
  WHY SMALL (/24): Only a few resources. NAT GW uses 1 IP. ALB uses 8 IPs.
  DON'T PUT: application pods or nodes. Public IP = internet-reachable = security risk.

PRIVATE subnets (/20 = 4,096 IPs each):
  cidrsubnet("10.0.0.0/16", 4, 16) = 10.0.16.0/20 (AZ-a)
  cidrsubnet("10.0.0.0/16", 4, 17) = 10.0.32.0/20 (AZ-b)
  cidrsubnet("10.0.0.0/16", 4, 18) = 10.0.48.0/20 (AZ-c)
  WHO LIVES HERE: EKS nodes + ALL PODS.
  WHY LARGE (/20): EKS VPC CNI assigns 1 IP per pod.
    100 nodes × 58 pods/node = 5,800 pod IPs needed.
    /24 = only 251 usable IPs per AZ → runs out with ~4 nodes.
    /20 = 4,091 usable IPs per AZ → supports ~70 nodes.
  
DATABASE subnets (/24):
  cidrsubnet("10.0.0.0/16", 8, 100) = 10.0.100.0/24 (AZ-a)
  WHO LIVES HERE: RDS, ElastiCache.
  WHY SEPARATE: No route to internet. Security group: only app tier can connect.
  Even the most permissive application pods cannot reach DB directly 
  without explicitly being in the DB security group.
```

**NAT Gateway HA configuration:**
```hcl
enable_nat_gateway     = true
single_nat_gateway     = false    # DO NOT USE single_nat_gateway in production
one_nat_gateway_per_az = true
```
```
single_nat_gateway = true:
  One NAT GW in AZ-a. All private subnets (AZ-a, AZ-b, AZ-c) route through it.
  AZ-a fails → NAT GW gone → AZ-b and AZ-c pods cannot reach the internet.
  All outbound calls fail: ECR image pulls, Secrets Manager, DT telemetry, S3.
  Cost saving (~$45/month) at the cost of cross-AZ resilience.
  NEVER use in production.

one_nat_gateway_per_az = true:
  One NAT GW per AZ (3 total).
  AZ-a private route table → AZ-a NAT GW
  AZ-b private route table → AZ-b NAT GW
  AZ-c private route table → AZ-c NAT GW
  
  AZ-a fails → AZ-b and AZ-c pods still have their own NAT GWs.
  Only AZ-a traffic is affected.
  Cost: 3× NAT GW (~$135/month) = HA tax.
  Worth it for any production workload.
```

**Critical EKS subnet tags:**
```hcl
public_subnet_tags = {
  "kubernetes.io/role/elb" = "1"    # ← public ALB discovery
  "kubernetes.io/cluster/company-prod" = "shared"
}
private_subnet_tags = {
  "kubernetes.io/role/internal-elb" = "1"   # ← internal ALB discovery
  "karpenter.sh/discovery" = "company-prod"  # ← Karpenter finds these subnets
}
```
```
kubernetes.io/role/elb = "1":
  The AWS Load Balancer Controller looks for this tag to find subnets for internet-facing ALBs.
  Without this tag: the controller doesn't know which public subnets to use.
  Result: ALB creation FAILS with "no subnets available".
  
kubernetes.io/role/internal-elb = "1":
  Same but for internal (VPC-only) ALBs.
  Used for: service-to-service ALBs, internal API gateways.

karpenter.sh/discovery = "company-prod":
  Karpenter uses this tag to find which subnets to launch new nodes in.
  EC2NodeClass in karpenter.yaml uses subnetSelectorTerms with this tag.
  If missing: Karpenter cannot launch nodes → pending pods stay pending forever.
```

**VPC Endpoints (free tier):**
```hcl
resource "aws_vpc_endpoint" "s3" {
  vpc_endpoint_type = "Gateway"    # free! adds a route to the route table
  route_table_ids   = module.vpc.private_route_table_ids
}
resource "aws_vpc_endpoint" "dynamodb" {
  vpc_endpoint_type = "Gateway"    # free!
}
```
```
WITHOUT S3 Gateway Endpoint:
  EKS node pulls image from ECR:
  Node → private subnet → NAT Gateway ($0.045/GB) → internet → ECR
  Cost: significant for large images or many nodes.
  Security: image layers travel via the public internet.

WITH S3 Gateway Endpoint:
  ECR stores image layers in S3.
  Node → private subnet → S3 Gateway Endpoint (FREE, no NAT) → ECR/S3
  Cost: $0 for data transfer via gateway endpoint.
  Security: image data never leaves AWS network.
  
  Gateway endpoints for S3 and DynamoDB are FREE.
  They add a route to the route table (no ENI, no security group needed).
  There is NO reason not to enable them.
```

---

## terraform/modules/eks/main.tf

```hcl
cluster_endpoint_private_access = true
cluster_endpoint_public_access  = false
```
```
Private cluster (public_access = false):
  The Kubernetes API server is only reachable from within the VPC.
  kubectl from an engineer's laptop: must connect via VPN or bastion first.
  
  WHY PRIVATE FOR PRODUCTION:
  With public_access = true and CIDRS = ["0.0.0.0/0"]:
  Any computer on the internet can attempt to authenticate to the API server.
  A stolen kubeconfig (e.g., leaked in a GitHub commit) = instant cluster access.
  
  With private_access = true only:
  Even with a stolen kubeconfig: attacker cannot reach the API server.
  They would need VPN access AND the kubeconfig.
  Two separate security layers.
  
  OPERATIONAL IMPACT:
  CI/CD pipelines (GitHub Actions): must run from a VPC-connected runner.
  Terraform applies: must be inside VPC or via VPN.
  kubectl: requires VPN connection first.
  This is expected in enterprise environments.
```

```hcl
cluster_encryption_config = {
  resources = ["secrets"]
}
```
```
Encrypts Kubernetes Secrets stored in etcd (the cluster database).
  
Without this:
  kubectl get secret payment-service-db-credentials -o yaml
  Shows: base64-encoded values.
  base64 is NOT encryption → anyone with API access can decode secrets.
  
With KMS encryption:
  etcd stores: encrypted blob (AES-256 wrapped by KMS key).
  kubectl get secret: Kubernetes decrypts transparently (if you have RBAC permission).
  Direct etcd access: unreadable without the KMS key.
  
  CloudTrail audit:
  "Who decrypted secrets today?" → CloudTrail shows every KMS Decrypt call.
  KMS key logs: exactly which secrets were accessed, by which role, at what time.
```

```hcl
cluster_addons = {
  coredns = {
    most_recent = true
    configuration_values = jsonencode({ replicaCount = 3 })
  }
  vpc-cni = {
    most_recent    = true
    before_compute = true   # CRITICAL ordering
  }
  aws-ebs-csi-driver = { most_recent = true }
}
```
```
before_compute = true for vpc-cni:
  VPC CNI must be installed BEFORE the node group is created.
  The EKS module's terraform logic:
    1. Create EKS control plane
    2. Install vpc-cni addon (because before_compute = true)
    3. Create managed node group
  
  WITHOUT before_compute = true:
    1. Create EKS control plane
    2. Create managed node group → nodes try to join
    3. Nodes can't get pod IPs → vpc-cni not configured yet
    4. CoreDNS pods can't start → cluster DNS broken
    5. Install vpc-cni addon (too late)
  
  The ordering dependency is subtle but causes a cluster bootstrap failure.

aws-ebs-csi-driver:
  Without this addon: PersistentVolumeClaims fail.
  All StatefulSets (databases, Prometheus) cannot get storage.
  The EBS CSI driver converts:
    PVC (Kubernetes) → EBS volume (AWS) and attaches it to the correct node.
```

**System node group taint:**
```hcl
taints = {
  dedicated = {
    key    = "dedicated"
    value  = "system"
    effect = "NO_SCHEDULE"
  }
}
labels = { "node-type" = "system" }
```
```
TAINT: dedicated=system:NoSchedule
  Any pod WITHOUT matching toleration: CANNOT schedule on system nodes.
  
  Application pods (payment-service): no toleration → cannot use system nodes.
  kube-system pods (CoreDNS, kube-proxy): have the toleration (added in their Helm values).
  ALB Controller: has the toleration (in aws-load-balancer-controller.yaml).
  ExternalDNS: has the toleration.
  Karpenter: has the toleration.
  Dynatrace ActiveGate: has the toleration.
  
  RESULT: system nodes are RESERVED for platform components.
  Application workloads → Karpenter-provisioned nodes.
  System components → system nodes (never preempted by application pods).
  
  WHY THIS MATTERS:
  Without taint:
  Traffic spike → payment-service needs more pods → pods schedule on system nodes.
  CoreDNS pod is evicted (not enough CPU on the node).
  DNS is broken → ALL services fail → cascade incident.
  
  With taint:
  Traffic spike → payment-service pods → Karpenter adds new nodes.
  System nodes are untouched. CoreDNS runs safely forever.
```

---

## terraform/app-bootstrap/main.tf

**Why this is a SEPARATE Terraform workspace (different state file):**
```hcl
backend "s3" {
  key = "app-bootstrap/terraform.tfstate"   # separate from eks-platform/
}
```
```
Timeline of operations:
  Day 1: Run terraform/ (creates VPC, EKS, IAM roles, Secrets Manager)
  Day 1: Run terraform/app-bootstrap/ (creates ECR, payment-service IRSA role)
  Day 1: Engineer pushes first commit → app-ci.yaml runs → pushes image to ECR
  Day 1: Apply gitops → ArgoCD deploys payment-service

WHY NOT IN THE MAIN WORKSPACE:
  The IRSA role for payment-service needs the cluster's OIDC URL.
  The OIDC URL is an output of the main workspace.
  
  If both were in the same workspace: circular dependency.
  Create cluster (needs nothing) → wait for OIDC URL → create IRSA role (needs OIDC URL).
  Terraform handles sequential dependencies within a workspace but the timing is awkward.
  
  Two workspaces:
  Workspace 1 (terraform/): creates cluster → state has OIDC URL as output.
  Workspace 2 (app-bootstrap/): reads OIDC URL from workspace 1's state → creates IRSA role.
  Clean, explicit dependency. Different apply frequency.
  
  App-bootstrap applies: whenever a new service is onboarded (needs ECR + IRSA).
  Main workspace applies: whenever infrastructure changes (much less often).
```

**ECR lifecycle policy:**
```hcl
resource "aws_ecr_lifecycle_policy" "payment_service" {
  policy = jsonencode({
    rules = [{
      rulePriority = 1
      selection    = { countType = "imageCountMoreThan", countNumber = 30 }
      action       = { type = "expire" }
    }]
  })
}
```
```
Keeps the last 30 images per repository. Deletes older ones automatically.

WITHOUT lifecycle policy:
  Every push creates a new image.
  100 deploys/day × 365 days = 36,500 images.
  ECR storage: ~$0.10/GB/month.
  If each image is 500MB: 36,500 × 500MB = 18TB = $1,800/month just for ECR.
  
WITH lifecycle policy (keep last 30):
  30 images × 500MB = 15GB = $1.50/month.
  Old images are automatically cleaned up.
  You can still deploy any of the last 30 versions instantly.
  
image_tag_mutability = "IMMUTABLE":
  Once you push tag "abc1234", that image content is locked.
  Nobody can push a different image to the same tag.
  
  WHY: "latest" mutable tag is a security risk.
  Attacker compromises the ECR write role → overwrites "latest" with malicious image.
  Next pod restart → pulls the malicious "latest" → cluster compromised.
  
  With IMMUTABLE tags: the malicious image cannot overwrite "abc1234".
  The deployed SHA is frozen. To change what runs: change the tag in Git (audited).
```

**Payment service IRSA trust policy:**
```hcl
condition {
  test     = "StringEquals"
  variable = "...oidc_provider_url...:sub"
  values   = ["system:serviceaccount:payment-ns:payment-service"]
}
```
```
The IRSA trust policy is the security gate.

"system:serviceaccount:payment-ns:payment-service" means:
  Namespace: payment-ns
  ServiceAccount: payment-service

ONLY THIS EXACT combination can assume the role.

Attack scenario: a developer creates a malicious pod in the staging namespace:
  ServiceAccount: payment-service (copied from prod)
  Namespace: staging-ns
  
  IRSA trust policy condition fails:
  sub = "system:serviceaccount:staging-ns:payment-service"
  Required: "system:serviceaccount:payment-ns:payment-service"
  → MISMATCH → STS DENIES the AssumeRoleWithWebIdentity call.
  
  Malicious pod cannot access production Secrets Manager.
  Namespace isolation is enforced at the IAM layer, not just Kubernetes RBAC.
```
