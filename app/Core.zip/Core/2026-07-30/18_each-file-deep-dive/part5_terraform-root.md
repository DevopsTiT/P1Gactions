# Part 5 — terraform/ Root Files Deep Dive

> **What this folder is:** The Terraform code that creates all AWS infrastructure — VPC, EKS cluster, IAM roles for IRSA, and Secrets Manager secrets. The foundation everything else runs on.

---

## terraform/versions.tf

```hcl
terraform {
  required_version = ">= 1.6.0, < 2.0.0"
  required_providers {
    aws        = { version = "~> 5.50" }
    kubernetes  = { version = "~> 2.30" }
    helm        = { version = "~> 2.13" }
    dynatrace   = { version = "~> 1.55" }
    random      = { version = "~> 3.6" }
    time        = { version = "~> 0.11" }
  }
}
```
```
required_version = ">= 1.6.0, < 2.0.0":
  This workspace will NOT run on Terraform 0.12, 0.13, 1.0 (too old).
  This workspace will NOT run on Terraform 2.0 (future major version might break HCL).
  Prevents: "works on my machine (0.14) but fails in CI (1.5)"

~> 5.50 means: allow 5.50, 5.51, 5.52... but NOT 6.0.
  ~> is the "pessimistic constraint operator" = allow patch versions only.
  Provider major versions often have breaking changes.
  aws ~> 5.50 = we tested with 5.50.x; patch releases are fine; 6.x is unknown.

WHY PIN PROVIDERS:
  AWS provider 5.x added the "default_tags" behaviour change.
  Code that worked with 4.x broke on 5.x (tags applied differently).
  Without pinning: engineer A uses 5.49, engineer B uses 5.52.
  A runs terraform plan: no changes.
  B runs terraform plan: 50 resources to update (tag format changed in 5.51).
  With pinning: everyone uses 5.50.x. Explicit upgrade via PR + testing.

dynatrace = { version = "~> 1.55" }
  The Dynatrace Terraform provider.
  This workspace needs BOTH the aws provider (for Secrets Manager)
  AND the dynatrace provider (for DT API calls).
  They coexist in the same versions.tf.
```

---

## terraform/backend.tf

```hcl
terraform {
  backend "s3" {
    bucket         = "company-terraform-state-prod"
    key            = "eks-platform/terraform.tfstate"
    region         = "ap-northeast-1"
    encrypt        = true
    dynamodb_table = "terraform-state-lock"
  }
}
```
```
WHAT IS TERRAFORM STATE:
  Terraform needs to know: "what did I already create?"
  The state file records: every resource Terraform manages, their IDs, their current config.
  
  Without state: terraform plan would say "create everything" every time (can't detect drift).
  With state: terraform plan says "this is already created, this changed, this is new".

WHY S3 BACKEND (not local file):
  Local (default): state stored as terraform.tfstate in the repo directory.
    Problem 1: committed to Git → state contains sensitive values (DB passwords, ARNs, etc.)
    Problem 2: two engineers apply simultaneously → one overwrites the other's state.
    Problem 3: state on laptop → lost if laptop is lost.
  
  S3 backend:
    State file stored in S3 (not on anyone's laptop).
    encrypt: true → state file encrypted at rest (AES-256).
    Versioning on S3 → can roll back to any previous state version.

DynamoDB lock (dynamodb_table = "terraform-state-lock"):
  DynamoDB is used as a distributed lock.
  Before apply: Terraform writes a lock entry to DynamoDB.
  While lock is held: any other terraform apply reads the lock → BLOCKED.
  After apply completes: lock is released.
  
  WHAT THIS PREVENTS:
  Engineer A runs terraform apply (starts).
  Engineer B runs terraform apply (starts simultaneously).
  Without lock: both read state → both think "nothing created yet" → BOTH create VPC.
  Now: two VPCs. Terraform state is corrupted. Incident.
  
  With DynamoDB lock:
  Engineer A acquires lock → starts apply.
  Engineer B tries to acquire lock → BLOCKED with "state locked by <A's session>".
  Engineer B waits → A finishes → lock released → B acquires lock → safe apply.

key = "eks-platform/terraform.tfstate"
  The S3 "path" within the bucket.
  Each Terraform workspace has a different key:
    eks-platform/terraform.tfstate     (this workspace)
    app-bootstrap/terraform.tfstate    (terraform/app-bootstrap/)
    dynatrace/terraform.tfstate        (terraform/dynatrace/)
  
  Separate state files = separate blast radii.
  A broken app-bootstrap apply cannot corrupt the EKS state.
```

---

## terraform/variables.tf

```hcl
variable "environment" {
  type    = string
  default = "production"
  validation {
    condition     = contains(["production", "staging", "dev"], var.environment)
    error_message = "environment must be production, staging, or dev"
  }
}

variable "cluster_version" {
  type    = string
  default = "1.30"
}

variable "node_instance_types" {
  type    = list(string)
  default = ["m7g.xlarge"]   # Graviton
}
```
```
validation block:
  Terraform 0.13+ feature. Runs before any resources are created.
  If condition is false: terraform plan FAILS immediately with the error_message.
  
  Without validation:
  Engineer sets environment = "prod" (typo for "production").
  Terraform applies → creates resources tagged environment=prod.
  Cost reports show "prod" and "production" as separate environments.
  Management zones in DT don't match.
  
  With validation:
  terraform plan → "environment must be production, staging, or dev" (immediate error)
  No resources created. Typo caught before any damage.

default = "1.30" for cluster_version:
  Pin the EKS version explicitly.
  If not pinned: AWS might default to a new version you haven't tested.
  Kubernetes upgrades should be:
    1. Tested in staging first
    2. Committed as a PR (so the plan shows "1.29 → 1.30")
    3. Reviewed and approved before applying to prod

m7g.xlarge (Graviton):
  m7g = 7th generation Graviton.
  xlarge = 4 vCPU, 16GB RAM.
  System node group: runs kube-system only, so xlarge provides plenty of headroom.
  Graviton vs equivalent Intel (m7i.xlarge): ~20% cost saving, same performance.
```

---

## terraform/main.tf

```hcl
provider "aws" {
  region = var.aws_region
  default_tags {
    tags = merge(var.tags, { environment = var.environment })
  }
}

provider "kubernetes" {
  host                   = module.eks.cluster_endpoint
  cluster_ca_certificate = base64decode(module.eks.cluster_ca_certificate)
  exec {
    api_version = "client.authentication.k8s.io/v1beta1"
    command     = "aws"
    args        = ["eks", "get-token", "--cluster-name", module.eks.cluster_name]
  }
}
```
```
default_tags in AWS provider:
  EVERY AWS resource created by this workspace automatically gets:
    { managed-by = "terraform", project = "eks-platform", environment = "production" }
  
  Without this: you must add tags = merge(local.common_tags, {...}) to EVERY resource.
  With default_tags: tags are implicit. Easy to miss one resource without default_tags.
  
  CloudTrail benefit: every AWS API call carries these tags.
  Cost allocation: every resource is tagged environment=production.
  Without: "$50,000 untagged" in monthly cost report.
  With: every dollar is attributed to the project.

kubernetes provider exec block:
  Generates a temporary kubeconfig token on-the-fly.
  `aws eks get-token --cluster-name company-prod` returns a bearer token (valid 15 min).
  Terraform uses this token to authenticate to the Kubernetes API.
  
  WHY exec INSTEAD OF static credentials:
  Static: kubeconfig with username/password in plaintext in terraform state.
  exec: generates a fresh token on every Terraform run. No credentials stored.
  If Terraform state is leaked: no Kubernetes credentials exposed (tokens expired).

module "vpc" + module "eks":
  The root main.tf is intentionally SHORT (90 lines).
  Complexity lives inside ./modules/vpc and ./modules/eks.
  Root module's job: wire inputs from variables.tf → modules, modules → each other.
  
  module.vpc creates VPC → returns vpc_id, subnet_ids.
  module.eks receives vpc_id, subnet_ids → creates the cluster in that VPC.
  The output of one module feeds the input of the next.
```

---

## terraform/outputs.tf

```hcl
output "cluster_oidc_issuer_url" {
  value       = module.eks.cluster_oidc_issuer_url
  description = "OIDC provider URL — used when creating new IRSA roles"
}

output "private_subnet_ids" {
  value       = module.vpc.private_subnet_ids
  description = "Private subnet IDs — used for Karpenter node provisioning"
}
```
```
WHY OUTPUTS EXIST:
  Other Terraform workspaces (app-bootstrap, dynatrace) need these values.
  They read them via data "terraform_remote_state" from S3.
  
  app-bootstrap/main.tf:
    data "terraform_remote_state" "main" { key = "eks-platform/terraform.tfstate" }
    data.terraform_remote_state.main.outputs.cluster_oidc_issuer_url
    → used to create IRSA trust policies for new services
  
  CI/CD pipelines:
    terraform output -raw cluster_name
    → used in: aws eks update-kubeconfig --name <cluster_name>
    → used in: argocd cluster add <cluster_endpoint>
  
  sensitive = true on cluster_ca_certificate:
  The CA certificate is used to verify the API server's TLS certificate.
  Not a password, but still security-sensitive.
  With sensitive = true:
    terraform output cluster_ca_certificate → BLOCKED (prints "sensitive value")
    terraform output -raw cluster_ca_certificate → still works (explicit override)
    CI pipelines use -raw when they need the actual value.
    Prevents accidental printing in logs.
```

---

## terraform/secrets-manager.tf

```hcl
resource "aws_secretsmanager_secret" "payment_db" {
  name = "${var.environment}/payment-service/db-credentials"
  kms_key_id = "alias/aws/secretsmanager"
  recovery_window_in_days = 30
}
```
```
WHAT THIS CREATES: the secret CONTAINER, not the secret VALUE.
  After terraform apply: the secret exists in Secrets Manager with no value.
  
  To populate: aws secretsmanager put-secret-value \
    --secret-id production/payment-service/db-credentials \
    --secret-string '{"host":"db.company.com","username":"app","password":"..."}'
  
  WHY NOT PUT VALUES IN TERRAFORM:
  Option A: var.db_password → password in terraform.tfvars → in Git → EXPOSED.
  Option B: password in terraform.tfstate (even as sensitive) → S3 → still accessible.
  
  Correct pattern:
  Terraform creates the secret shell.
  DBA or secret rotation Lambda populates the value.
  ESO reads the value at pod startup.
  Terraform never sees the actual secret value.

recovery_window_in_days = 30:
  When you run terraform destroy or delete the secret:
  The secret is NOT immediately deleted.
  It enters a "pending deletion" state for 30 days.
  During this window: you can cancel the deletion and recover it.
  
  WHY:
  "terraform destroy" during a migration → secret is gone → app can't connect to DB.
  With 30-day window: you have a month to realise the mistake and cancel.
  For true immediate deletion: aws secretsmanager delete-secret --force-delete-without-recovery.

kms_key_id = "alias/aws/secretsmanager":
  Uses the AWS-managed KMS key for Secrets Manager.
  Every secret is encrypted at rest.
  For compliance requirements (PCI/HIPAA): replace with a customer-managed key.
  Customer-managed key = you control rotation, CloudTrail shows who decrypted what.
```

---

## terraform/irsa-eso.tf

```hcl
resource "aws_iam_role_policy" "eso" {
  policy = jsonencode({
    Statement = [{
      Action   = ["secretsmanager:GetSecretValue", "secretsmanager:DescribeSecret"]
      Resource = "arn:aws:secretsmanager:${var.aws_region}:${account_id}:secret:${var.environment}/*"
    }]
  })
}
```
```
Resource = "...secret:production/*"
  ESO can ONLY read secrets whose name starts with "production/".
  
  What ESO CAN read:
    production/dynatrace/api-token ✓
    production/payment-service/db-credentials ✓
  
  What ESO CANNOT read:
    staging/payment-service/db-credentials ✗
    management/terraform-state-access ✗
    /aws/reference/... ✗ (SSM cross-references)
  
  WHY SCOPE MATTERS:
  If the ESO pod is compromised (container escape, supply chain attack):
  Attacker can only read production/* secrets.
  Cannot pivot to: management account secrets, staging credentials, other environments.
  Least privilege = smallest possible blast radius on compromise.

The IRSA trust policy condition:
  "system:serviceaccount:external-secrets:external-secrets-sa"
  
  If an attacker creates a ServiceAccount named "external-secrets-sa"
  in the WRONG namespace (e.g., payment-ns):
  The trust policy checks: namespace=external-secrets AND sa=external-secrets-sa.
  Payment-ns SA cannot assume this role → denied.
  
  Both namespace AND service account name must match exactly.
```

---

## terraform/irsa-externaldns.tf

```hcl
Statement = [
  {
    Action   = ["route53:ChangeResourceRecordSets"]
    Resource = ["arn:aws:route53:::hostedzone/${var.route53_zone_id}"]
  },
  {
    Action   = ["route53:ListHostedZones", "route53:ListResourceRecordSets"]
    Resource = ["*"]   # List requires * (cannot scope to specific zone)
  }
]
```
```
WHY route53:ChangeResourceRecordSets is scoped to one zone:
  ExternalDNS creates/deletes DNS records for your services.
  If the permission was Resource = "*" (all zones):
  ExternalDNS could modify records in every Route53 zone in the account.
  A bug in ExternalDNS could delete records for:
    internal.company.com (internal services)
    legacy.company.com (critical old records)
    mail.company.com (email MX records — would break all email)
  
  With Resource scoped to one zone ID:
  ExternalDNS can ONLY modify records in company.com.
  Blast radius of a bug: company.com records only.
  Other zones are completely safe.

route53:ListHostedZones requires Resource = "*":
  This is an AWS API limitation, not a design choice.
  The ListHostedZones API cannot be scoped to a specific zone.
  It lists all zones. The domainFilters setting in ExternalDNS config
  ensures ExternalDNS only ACTS on company.com even though it can list all zones.
  Two layers of scoping: IAM (what it can modify) + config (what it chooses to modify).
```

---

## terraform/irsa-lbc.tf

The most complex IRSA role — ALB Controller needs 30+ permissions.

```hcl
# Simplified — the actual file has many more:
Statement = [
  {
    Action   = ["elasticloadbalancing:CreateLoadBalancer", "elasticloadbalancing:DeleteLoadBalancer", ...]
    Resource = "*"
  },
  {
    Action   = ["ec2:CreateSecurityGroup", "ec2:AuthorizeSecurityGroupIngress", ...]
    Resource = "*"
  }
]
```
```
WHY SO MANY PERMISSIONS:
  When you create a Kubernetes Ingress with alb.ingress.kubernetes.io/scheme: internet-facing:
  
  The ALB controller:
  1. Creates an ALB (elasticloadbalancing:CreateLoadBalancer)
  2. Creates a Target Group (elasticloadbalancing:CreateTargetGroup)
  3. Registers pod IPs as targets (elasticloadbalancing:RegisterTargets)
  4. Creates HTTPS listener with ACM cert (elasticloadbalancing:CreateListener)
  5. Creates routing rules (elasticloadbalancing:CreateRule)
  6. Creates a security group for the ALB (ec2:CreateSecurityGroup)
  7. Adds inbound rules to allow HTTPS (ec2:AuthorizeSecurityGroupIngress)
  8. Tags all created resources (ec2:CreateTags)
  
  When you delete the Ingress:
  ALB controller reverses all steps (DeleteLoadBalancer, DeleteTargetGroup, etc.)
  
  Each step is a separate AWS API call requiring a specific IAM permission.
  None of these can be consolidated into fewer permissions.
  This is why the ALB Controller IRSA policy is long.

WHY RESOURCE = "*" FOR MOST:
  ElasticLoadBalancing actions cannot be scoped to a specific ALB before creation.
  You don't know the ALB ARN until AFTER it's created.
  So the create permission must be Resource = "*".
  After creation: the modify/delete permissions ideally would scope to the specific ARN.
  But the ALB controller manages many ALBs dynamically — ARNs change constantly.
  The controller adds mandatory tags (owned/shared) to track which resources it manages.
  An ALB without the correct tag: controller doesn't touch it.
  So the IAM is broad but the controller's logic is narrow.
```

---

## terraform/karpenter.tf

```hcl
# EventBridge rule → SQS queue
resource "aws_cloudwatch_event_rule" "karpenter_spot_interruption" {
  event_pattern = jsonencode({
    source      = ["aws.ec2"]
    detail-type = ["EC2 Spot Instance Interruption Warning"]
  })
}
resource "aws_cloudwatch_event_target" "karpenter_spot_interruption" {
  rule = aws_cloudwatch_event_rule.karpenter_spot_interruption.name
  arn  = aws_sqs_queue.karpenter_interruption.arn
}
```
```
THE SPOT INTERRUPTION CHAIN (created by this file):

  AWS decides to reclaim Spot instance i-0abc123:
    ↓
  AWS publishes event to EventBridge:
    { "source": "aws.ec2", "detail-type": "EC2 Spot Instance Interruption Warning",
      "detail": { "instance-id": "i-0abc123", "instance-action": "terminate" } }
    ↓
  EventBridge rule matches → routes to SQS queue (karpenter-interruption)
    ↓
  Karpenter polls SQS every few seconds → receives the message
    ↓
  Karpenter: cordon i-0abc123 (no new pods)
  Karpenter: drain pods from i-0abc123 (move to other nodes)
  Karpenter: provision replacement node (different Spot pool/AZ if possible)
  Karpenter: all BEFORE the 2-minute interruption deadline
    ↓
  AWS terminates i-0abc123 (no pods running there anymore → zero disruption)

message_retention_seconds = 300 on SQS:
  Messages older than 5 minutes are automatically deleted.
  WHY NOT LONGER:
  Spot warnings are time-sensitive (2-minute window).
  An old warning about a node that was already terminated = stale/useless.
  5 minutes is enough for Karpenter to process and act on warnings.
  Longer retention = stale messages confuse Karpenter about nodes that no longer exist.
```
