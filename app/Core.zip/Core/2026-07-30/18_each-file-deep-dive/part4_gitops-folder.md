# Part 4 — gitops/ Folder Deep Dive

> **What this folder is:** Every ArgoCD Application definition and Kubernetes manifest. ArgoCD watches this folder and makes the cluster match it. This folder IS the cluster's desired state.

---

## The Sync Wave Order (Deployment Sequencing)

```
Wave -1: namespaces/namespaces.yaml          ← Namespaces FIRST (nothing can deploy without them)
Wave  1: networking/aws-load-balancer-controller.yaml  ← ALB controller
         networking/external-dns.yaml                  ← DNS automation (parallel with ALB)
Wave  2: secrets/external-secrets/external-secret-operator.yaml  ← ESO controller
Wave  3: monitoring/dynatrace/dynatrace-operator.yaml  ← DT operator + DynaKube
         auto-scaling/karpenter/karpenter.yaml         ← node autoscaler
         security/kyverno/kyverno.yaml                 ← policy engine
Wave  4: secrets/external-secrets/cluster-secret-store.yaml  ← ESO backend config
Wave  5: security/kyverno/ policies                   ← policy rules (after kyverno is running)
Wave  8: app/payment-service/payment-service.yaml     ← application LAST

WHY THIS ORDER:
  Wave -1 (Namespaces): pods can only run in existing namespaces.
    ArgoCD cannot create a Deployment in payment-ns before payment-ns exists.
    
  Wave 1 (ALB + ExternalDNS): infrastructure must be running before Ingress objects.
    If payment-service Ingress applies before ALB controller: Ingress sits Pending.
    
  Wave 2 (ESO operator): CRDs must exist before CRD instances.
    ExternalSecret CRD installed by the ESO Helm chart.
    ClusterSecretStore (wave 4) is an instance of that CRD.
    Instance before CRD = Kubernetes "unknown resource" error.
    
  Wave 3 (DT operator): same reason as ESO.
    DynaKube is a CRD instance. DynaKube CRD installed by the operator Helm chart.
    
  Wave 8 (Application): everything must be running first.
    Kyverno: must be ready to validate pods (otherwise pods blocked at admission)
    ESO: must be ready to create DB credential secrets
    ALB controller: must be ready to create the ALB from the Ingress
```

---

## gitops/bootstrap/root-app.yaml

**THE entry point. Apply once manually. Never touch again.**

```yaml
spec:
  source:
    path: gitops    # watch the ENTIRE gitops/ folder recursively

  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```
```
path: gitops
  ArgoCD scans ALL files under gitops/ recursively.
  Every file that contains an ArgoCD Application object is discovered and managed.
  Adding a new service: create gitops/app/new-service/new-service.yaml
  ArgoCD discovers it and deploys it. No manual steps.

prune: true
  "Git = desired state. If something is in the cluster but NOT in Git: delete it."
  
  Example: you deployed a test Application manually with kubectl.
  Without prune: that Application stays forever, consuming resources.
  With prune: ArgoCD sees "this Application is not in Git" → deletes it.
  
  This is the ENFORCEMENT part of GitOps.
  The cluster cannot accumulate manual changes over time.

selfHeal: true
  "If someone changes the running state with kubectl: revert it back to Git."
  
  Example: engineer runs:
    kubectl scale deployment payment-service --replicas=1  (trying to save cost)
  Without selfHeal: replicas stays at 1 forever.
  With selfHeal: ArgoCD detects mismatch after 3 minutes → sets replicas back to 3.
  
  WHY THIS IS GOOD:
  The cluster state is always what Git says it should be.
  You cannot accidentally change production by running kubectl.
  To change production: commit to Git → PR → review → merge.

finalizers:
  - resources-finalizer.argocd.argoproj.io
  
  When root-app is deleted: ArgoCD cascades deletion to ALL child Applications.
  All managed resources (Deployments, Services, etc.) are deleted too.
  This is intentional for full teardown.
  For partial teardown: remove this finalizer first.
```

---

## gitops/namespaces/namespaces.yaml

```yaml
metadata:
  annotations:
    argocd.argoproj.io/sync-wave: "-1"   # negative = before everything

# Namespace definitions:
- name: payment-ns
  labels:
    team: payments
    environment: production
```
```
Wave -1 (negative number):
  ArgoCD processes lower numbers first.
  -1 < 0 < 1 < 2 ... → namespaces deploy before waves 0, 1, 2, etc.
  This ensures all namespaces exist before ANY other Application runs.

Labels on namespaces:
  team: payments → used by Kyverno for admission scope
                   used by Dynatrace for auto-tagging
                   used by cost allocation (AWS Resource Groups)
  environment: production → used by management zone rules in DT
```

---

## gitops/argocd/argocd-project.yaml

```yaml
# Project: platform
destinations:
  - server: "https://kubernetes.default.svc"
    namespace: "*"   # platform can deploy to ANY namespace
clusterResourceWhitelist:
  - group: "*"
    kind: "*"        # can create CRDs, ClusterRoles, etc.

# Project: payments
destinations:
  - server: "https://kubernetes.default.svc"
    namespace: "payment-ns"   # payments team ONLY deploys here
clusterResourceWhitelist: []  # CANNOT create cluster-level resources
namespaceResourceWhitelist:   # only specific resource types
  - { group: "apps", kind: "Deployment" }
  - { group: "", kind: "Service" }
  - { group: "networking.k8s.io", kind: "Ingress" }
  - { group: "autoscaling", kind: "HorizontalPodAutoscaler" }
  - { group: "policy", kind: "PodDisruptionBudget" }
  - { group: "external-secrets.io", kind: "ExternalSecret" }
```
```
WHY PROJECTS MATTER (blast radius control):

  WITHOUT AppProject scoping:
  A developer on the payments team creates an Application that accidentally:
    - Deploys to kube-system → could overwrite CoreDNS
    - Creates a ClusterRole with admin permissions → privilege escalation
    - Deploys to the dynatrace namespace → breaks monitoring
  
  WITH AppProject scoping:
  payments project: can ONLY deploy to payment-ns.
  ArgoCD refuses: "destination not allowed" for any other namespace.
  payments project: cannot create Deployments in kube-system.
  
  platform project: can do everything → restricted to platform team members.
  
  namespaceResourceWhitelist for payments:
  The payments team can create: Deployment, Service, Ingress, HPA, PDB, ExternalSecret.
  The payments team CANNOT create: ServiceAccount (no cluster identity changes),
  ClusterRole (no privilege changes), NetworkPolicy, PodSecurityPolicy.
  Only the platform team can manage security policies.
```

---

## gitops/networking/aws-load-balancer-controller.yaml

```yaml
helm:
  values: |
    serviceAccount:
      annotations:
        eks.amazonaws.com/role-arn: arn:aws:iam::123456789012:role/company-prod-aws-load-balancer-controller
    tolerations:
      - key: "dedicated"
        operator: "Equal"
        value: "system"
        effect: "NoSchedule"
    affinity:
      nodeAffinity:
        requiredDuringSchedulingIgnoredDuringExecution:
          nodeSelectorTerms:
            - matchExpressions:
                - key: "node-type"
                  operator: In
                  values: ["system"]
```
```
tolerations + nodeAffinity = run on system nodes only.
WHY PLATFORM COMPONENTS MUST RUN ON SYSTEM NODES:

  Application nodes are scaled by Karpenter.
  Karpenter adds nodes when workloads need them.
  Karpenter removes nodes when workloads leave.
  
  If the ALB Controller runs on an application node:
  Karpenter scales down that node → ALB Controller pod is evicted.
  While ALB Controller is restarting: no one processes new Ingress objects.
  New deployments hang → payment-service Ingress never gets an ALB.
  
  System node taint: "dedicated=system:NoSchedule"
  Only pods with matching toleration can schedule here.
  ALB Controller has the toleration → schedules on system nodes.
  Application pods do NOT have the toleration → cannot schedule on system nodes.
  System nodes are reserved exclusively for platform components.
```

---

## gitops/networking/external-dns.yaml

```yaml
helm:
  values: |
    domainFilters:
      - company.com    # ONLY manage records in company.com zone
    
    policy: sync       # creates AND deletes records as Ingresses change
    
    txtOwnerId: "company-prod"  # identifies this cluster's DNS records
    
    sources:
      - ingress        # watches Kubernetes Ingress objects
      - service        # watches Services with hostname annotation
```
```
domainFilters: CRITICAL SAFETY SETTING
  Without this: ExternalDNS tries to manage records in EVERY Route53 zone.
  Example: company has zones for company.com, internal.company.com, legacy-company.com.
  Without filter: ExternalDNS might accidentally delete records in all zones.
  With filter: ONLY modifies records in company.com.

policy: sync vs upsert-only
  sync: creates records when Ingress is created; DELETES records when Ingress is deleted.
  upsert-only: creates/updates but NEVER deletes.
  sync is correct for GitOps — when you remove a service from Git, its DNS record goes too.
  upsert-only creates orphaned DNS records that point to deleted ALBs.

txtOwnerId: "company-prod"
  ExternalDNS creates a "TXT record" alongside each DNS A record.
  The TXT record contains the owner ID.
  Before modifying an A record: ExternalDNS checks "does this TXT record match my owner ID?"
  If another ExternalDNS instance (staging cluster) manages the same zone:
  staging's ExternalDNS sees the TXT owner = "company-prod" → doesn't touch it.
  Prevents multiple clusters from overwriting each other's DNS records.
```

---

## gitops/secrets/external-secrets/external-secret-operator.yaml

```yaml
serviceAccount:
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::123456789012:role/company-prod-external-secrets-operator
```
```
THE ESO IRSA CHAIN:
  This Helm chart creates ServiceAccount "external-secrets-sa" in namespace "external-secrets".
  The annotation links this SA to the IAM role from terraform/irsa-eso.tf.
  
  The IAM role trust policy says:
  "Only system:serviceaccount:external-secrets:external-secrets-sa can assume this role"
  
  When ESO pod starts → EKS injects OIDC token → ESO calls STS.AssumeRoleWithWebIdentity
  → gets temporary credentials → can call secretsmanager:GetSecretValue.
  
  SCOPE IN IAM POLICY (from irsa-eso.tf):
  Resource: arn:aws:secretsmanager:region:account:secret:production/*
  ESO can ONLY read secrets under the production/ prefix.
  It cannot read secrets belonging to staging, management, or other prefixes.
  Even if ESO pod is compromised: attacker can only read production secrets (not cross-account).
```

---

## gitops/monitoring/dynatrace/dynatrace-operator.yaml

This file has THREE resources bundled (because they're tightly coupled):

**1. ArgoCD Application** → installs the Dynatrace Operator Helm chart
**2. ExternalSecret** → pulls DT API tokens into a Kubernetes Secret named "dynakube"
**3. DynaKube** → tells the Operator what to deploy

```yaml
# DynaKube spec:
classicFullStack:
  enabled: true
  tolerations:
    - key: dedicated
      operator: Equal
      value: system
      effect: NoSchedule
```
```
classicFullStack = OneAgent DaemonSet.
One OneAgent pod per node. Monitors: processes, containers, network, disk, logs.
Auto-instruments: Java, Node.js, Python, .NET — no code changes needed.

Tolerations for system nodes:
  System nodes have taint "dedicated=system:NoSchedule".
  Without toleration: OneAgent DaemonSet SKIPS system nodes.
  System nodes run: CoreDNS, kube-proxy, Karpenter, ALB Controller.
  We WANT to monitor these — they're the most critical components.
  With toleration: OneAgent runs on EVERY node (system + application).
```

```yaml
logMonitoring:
  enabled: true
```
```
OneAgent reads /var/log/containers/*.log from the host filesystem.
Replaces Fluent Bit / Fluentd for log shipping.
Logs flow to: Dynatrace Grail (DT's log storage and query engine).

WHY ONEAGENT LOG MONITORING > FLUENT BIT:
  Fluent Bit: separate DaemonSet, separate config, separate IRSA role.
    Needs: parsing rules per log format, routing rules per service.
  OneAgent: already running on every node, reads container logs automatically.
    Correlates logs WITH traces (same OneAgent sees both).
    In DT: click on a slow trace → click "Show logs for this request" → immediate context.
    Fluent Bit just ships logs — it doesn't correlate them with traces.
```

```yaml
activeGate:
  capabilities:
    - routing
    - kubernetes-api-monitoring
    - log-analytics
  replicas: 2
  topologySpreadConstraints: ...
```
```
ActiveGate = an on-premises DT proxy/gateway.
  routing: OneAgent data from all nodes flows through ActiveGate to DT cloud.
    Without routing: each OneAgent connects directly to DT cloud (many connections).
    With routing: all OneAgents → 2 ActiveGate pods → DT cloud (consolidated).
    
  kubernetes-api-monitoring: queries the K8s API server for cluster-level metrics.
    Pod counts, Deployment status, Node conditions, Resource quotas.
    Creates the "Kubernetes" view in DT automatically.
    
  log-analytics: processes log data before sending to DT Grail.

replicas: 2 + topologySpreadConstraints:
  2 replicas across 2 different AZs.
  If AZ-a fails: ActiveGate in AZ-b still processes all monitoring data.
  No monitoring blind spot during AZ failure.
```

---

## gitops/auto-scaling/karpenter/karpenter.yaml

**Three resources in one file:**

### 1. ArgoCD Application (Karpenter Helm chart)

```yaml
settings:
  interruptionQueue: company-prod-karpenter-interruption
```
```
Links Karpenter to the SQS queue created by terraform/karpenter.tf.
Karpenter polls this queue every few seconds for:
  - Spot interruption warnings (2-min notice before instance reclaimed)
  - EC2 rebalance recommendations (proactive migration before interruption)
  - Instance health notifications
  
When a warning arrives:
  1. Karpenter cordons the node (no new pods scheduled)
  2. Drains pods to other nodes
  3. Provisions a replacement node from a different Spot pool
  4. All before AWS reclaims the instance
  → zero pod eviction without replacement
```

### 2. NodePool (what nodes Karpenter can provision)

```yaml
requirements:
  - key: kubernetes.io/arch
    operator: In
    values: ["arm64"]       # Graviton ONLY
  - key: karpenter.sh/capacity-type
    operator: In
    values: ["spot", "on-demand"]
  - key: karpenter.k8s.aws/instance-family
    operator: In
    values: ["m7g", "c7g", "r7g"]
  - key: karpenter.k8s.aws/instance-size
    operator: NotIn
    values: ["nano", "micro", "small"]

limits:
  cpu: 1000
  memory: 4000Gi

disruption:
  consolidationPolicy: WhenUnderutilized
  consolidateAfter: 30s
```
```
arm64 only (Graviton):
  20% cheaper than equivalent Intel/AMD instances.
  Works because Docker images are multi-arch (built in app-ci.yaml).
  Go, Python, Node.js all run on ARM without changes.

spot + on-demand:
  Karpenter prefers Spot (60-70% cheaper) when available.
  Falls back to On-Demand if no Spot capacity available.
  
  SPOT DIVERSIFICATION:
  m7g + c7g + r7g = 3 instance families × multiple sizes = many Spot pools.
  If m7g.large Spot capacity is exhausted in ap-northeast-1a:
  Karpenter tries c7g.large, then r7g.large, then m7g.xlarge.
  More pools = fewer times Spot capacity is unavailable.

limits.cpu: 1000
  Hard ceiling: Karpenter will NOT provision nodes that would exceed 1000 vCPU total.
  Cost control: prevents runaway autoscaling from a bug or traffic spike.
  At m7g.large (2 vCPU): max 500 nodes. Estimated max monthly cost is predictable.

consolidation: WhenUnderutilized, consolidateAfter: 30s
  If a node has pods using < X% of its capacity:
  Karpenter finds a smaller node that fits all those pods.
  Cordons old node → drains pods → starts smaller node → terminates large node.
  Happens automatically 30 seconds after underutilisation is detected.
  
  COST IMPACT:
  3× m7g.4xlarge nodes (50% used each) → 1× m7g.4xlarge + 2× m7g.2xlarge
  Same capacity, cheaper configuration. Happens continuously overnight.
```

### 3. EC2NodeClass (what hardware each node uses)

```yaml
spec:
  amiFamily: AL2023
  role: company-prod-karpenter-node
  subnetSelectorTerms:
    - tags:
        karpenter.sh/discovery: "company-prod"
  securityGroupSelectorTerms:
    - tags:
        karpenter.sh/discovery: "company-prod"
  blockDeviceMappings:
    - deviceName: /dev/xvda
      ebs:
        volumeSize: 50Gi
        volumeType: gp3
        encrypted: true
```
```
subnetSelectorTerms + securityGroupSelectorTerms:
  Karpenter uses AWS tags to discover which subnets and security groups to use.
  Tag karpenter.sh/discovery = "company-prod" is set in terraform/modules/vpc/main.tf.
  Karpenter automatically uses the correct VPC resources without hardcoded IDs.
  
  WHY TAGS NOT IDs:
  Tags are stable. Subnet IDs change if you recreate the VPC.
  With tags: recreate the VPC → new subnet IDs but same tags → Karpenter still works.

amiFamily: AL2023
  Amazon Linux 2023. AWS maintains the EKS-optimised AMI for AL2023.
  Karpenter looks up the latest AL2023 AMI compatible with the cluster version.
  Node upgrades: Karpenter automatically picks up new AMI versions.
  Security patches in AMI: applied automatically on next scale-out.

encrypted: true on root volume
  All data on Karpenter nodes is encrypted at rest.
  If an EBS volume is somehow detached and accessed: unreadable without KMS key.
  Compliance requirement for most regulated industries.
```

---

## gitops/security/kyverno/kyverno.yaml

**Three resources: operator, policies Application, and two ClusterPolicy objects.**

### Policy 1: require-resource-limits

```yaml
spec:
  validationFailureAction: Enforce
  rules:
    - name: check-container-resources
      match:
        resources: { kinds: ["Pod"], namespaces: ["payment-ns"] }
      validate:
        pattern:
          spec:
            containers:
              - resources:
                  requests: { memory: "?*", cpu: "?*" }
                  limits: { memory: "?*" }
```
```
validationFailureAction: Enforce
  BLOCK the resource from being created if it violates this policy.
  (Alternative: Audit = allow but log the violation.)
  
WHY BLOCK pod creation if no resource limits:
  Without limits: one misbehaving pod can consume ALL node CPU/memory.
  Result: other pods are evicted (OOM killer removes them from the node).
  A payment-service pod could starve order-service and inventory-service.
  
  With this policy:
  Developer writes a Deployment without resource limits.
  kubectl apply → Kyverno webhook → REJECTED.
  "Pods must have resource requests and limits set"
  Developer must add limits before the pod can be created.
  
  This is SHIFT LEFT security: catch the mistake at deploy time (CI),
  not at runtime when it causes an incident at 3am.

WHY ONLY payment-ns (not all namespaces):
  kube-system pods (CoreDNS, kube-proxy): managed by AWS/EKS team.
  They have their own resource settings. Kyverno should not block them.
  The policy targets only application namespaces.
```

### Policy 2: require-pod-labels

```yaml
validate:
  message: "Pods must have 'team' and 'app' labels for Dynatrace tagging"
  pattern:
    metadata:
      labels:
        team: "?*"   # must exist and be non-empty
        app: "?*"
```
```
WHY LABELS MATTER FOR DYNATRACE:

  OneAgent auto-tags entities based on Kubernetes labels.
  DT auto-tagging rule: "if pod has label team=X → tag entity with team:X"
  
  WITHOUT team label:
  → Pod has no team tag in DT
  → Management zone rule "match where tag team:payments exists" MISSES this pod
  → payment-service metrics appear under "unscoped" entities
  → Payment team cannot see their own metrics in DT
  → Alerting profile for payments team doesn't fire for this service
  
  This Kyverno policy ENFORCES the label at pod creation time.
  Every pod in payment-ns MUST have team + app labels.
  Guaranteed: Dynatrace always has proper tagging.
  No silent monitoring gaps from missing labels.
```
