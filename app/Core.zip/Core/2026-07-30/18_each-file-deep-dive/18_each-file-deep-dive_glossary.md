# Glossary — Each File Deep Dive

Every term used across all 7 parts, for SRE beginners.

---

**requirements.txt**
A file that lists Python packages and their pinned versions. `pip install -r requirements.txt` installs exactly these versions. Pinning prevents "works on my machine but not in CI" surprises.

**pytest**
Python's standard testing framework. Discovers files named `test_*.py`, runs functions named `test_*`, reports pass/fail. Exit code 0 = all pass. CI checks the exit code — non-zero stops the pipeline.

**FastAPI**
A Python web framework for building HTTP APIs. Provides: automatic JSON serialisation, request validation, and a built-in Swagger UI. Used to define the payment-service endpoints.

**Uvicorn**
An ASGI web server for Python. Listens on a TCP port, accepts HTTP connections, and passes them to FastAPI. Started with `uvicorn.run(app, host="0.0.0.0", port=8080)`.

**Structured logging (JSON logs)**
Writing every log line as a JSON object instead of plain text. Machines can parse JSON without regex. Enables: filtering by field, correlation across services, Dynatrace log intelligence. `{"timestamp":"...","level":"info","event":"payment_fetch"}`.

**Multi-stage Dockerfile**
A Dockerfile with multiple `FROM` statements. Stage 1 (builder) installs compile-time tools. Stage 2 (runtime) copies only the compiled output. Result: smaller, more secure final image (no build tools).

**Virtual environment (Python venv)**
An isolated Python installation at a specific directory path (`/opt/venv`). Packages installed here don't conflict with system Python. Easy to copy as a unit between Docker stages.

**OIDC (OpenID Connect) — GitHub to AWS**
A protocol allowing GitHub Actions to prove its identity to AWS without storing long-lived credentials. GitHub generates a signed JWT; AWS verifies it and returns temporary STS credentials. No `AWS_ACCESS_KEY_ID` stored in GitHub Secrets.

**STS (Security Token Service)**
AWS service that issues temporary IAM credentials. `sts:AssumeRoleWithWebIdentity` exchanges a GitHub OIDC JWT for temporary access keys (valid 1 hour). Used by both GitHub Actions and IRSA.

**role-session-name**
A label attached to the STS session when assuming an IAM role. Appears in CloudTrail logs. `github-actions-8134521` lets you trace any AWS action back to the specific GitHub Actions run that performed it.

**Multi-arch image (Docker manifest)**
A single Docker image tag that contains separate images for different CPU architectures (amd64 for Intel, arm64 for Graviton). Docker/containerd automatically pulls the correct one based on the host CPU. Built with `platforms: linux/amd64,linux/arm64`.

**Trivy**
An open-source container vulnerability scanner. Checks OS packages and library dependencies against known CVE databases. Configured with `exit-code: '1'` to fail CI on CRITICAL findings.

**CVE (Common Vulnerabilities and Exposures)**
A public database of known security vulnerabilities. Each has a severity: CRITICAL, HIGH, MEDIUM, LOW. Trivy checks your image layers against this database.

**Image tag immutability**
ECR setting that prevents overwriting an existing image tag. Once `abc1234` is pushed, it cannot be replaced by a different image with the same tag. Prevents supply chain attacks via tag overwriting.

**ECR lifecycle policy**
Automatic cleanup rules for ECR. "Delete images older than the last 30" prevents storage accumulation. Without it: thousands of old images accumulate, costing hundreds per month.

**GitOps (gitops update step)**
The CI pipeline commits the new image tag to the gitops repo. ArgoCD detects the commit and deploys the new version. Git is the deployment trigger — not a direct `kubectl set image` command.

**[skip ci] commit message**
A convention GitHub Actions recognises. Any commit message containing `[skip ci]` tells GitHub not to trigger CI workflows for that commit. Prevents the gitops tag update commit from triggering another CI run (infinite loop).

**Helm template range**
Helm's loop syntax: `{{- range .Values.items }} ... {{- end }}`. Iterates over a list and renders the template block once per item. Used to create multiple Namespace objects from a single values.yaml list.

**Rolling update (maxUnavailable: 0, maxSurge: 1)**
A Kubernetes deployment strategy that creates one new pod before removing any old pod. Guarantees: the desired replica count is always available. Zero-downtime deployments.

**Topology spread constraints**
Kubernetes feature that distributes pods across availability zones. `maxSkew: 1` means no zone can have more than 1 extra pod compared to any other zone. Ensures AZ failures only remove 1/3 of pods.

**Pod anti-affinity (requiredDuringScheduling)**
A Kubernetes hard rule: no two matching pods on the same node. `topologyKey: kubernetes.io/hostname` makes it node-level. `required` = scheduler refuses to violate it (unlike `preferred` which is a hint).

**Startup probe**
A Kubernetes health check active only during container startup. While it runs, liveness and readiness are paused. Prevents killing a legitimately slow-starting container (e.g., JVM taking 2 minutes to boot).

**preStop hook**
A command that runs in a container BEFORE it receives SIGTERM. `sleep 10` gives the ALB ~10 seconds to drain connections after the pod is removed from endpoints but before the app starts shutting down.

**terminationGracePeriodSeconds**
How long Kubernetes waits after sending SIGTERM before force-killing (SIGKILL) the container. 60 seconds = the app has a full minute to finish in-flight requests and close connections cleanly.

**readOnlyRootFilesystem**
A container security setting that makes the container's filesystem read-only. The app can still write to stdout (logs) but cannot write files to disk. Prevents attackers from writing backdoors to the container.

**capabilities.drop: ALL**
Removes all Linux kernel capabilities from a container. Default containers have NET_BIND_SERVICE, CHOWN, etc. Dropping all = minimal kernel privileges. Required for most security compliance frameworks.

**ALB target-type: ip**
Routes ALB traffic directly to pod IPs (not to node IPs via NodePort). Lower latency, better connection tracking. Requires EKS VPC CNI (pods have real VPC IPs, not NAT'd through nodes).

**ssl-redirect: "443"**
An ALB annotation that creates an HTTP → HTTPS redirect rule at the ALB level. All HTTP requests are automatically redirected to HTTPS. The application never sees plain HTTP requests.

**ExternalSecret refreshInterval**
How often the External Secrets Operator re-reads the secret value from Secrets Manager. `1h` = re-reads every hour. If the secret is rotated in Secrets Manager, pods pick up the new value on next refresh.

**ClusterSecretStore**
An ESO resource that defines HOW to connect to a secret backend (which AWS account, which region, which IRSA ServiceAccount to authenticate with). Cluster-scoped: shared by all namespaces.

**ArgoCD prune**
Deletes cluster resources that exist in the live cluster but NOT in the Git repository. Enforces "Git = desired state". Without prune: deleted YAML files leave orphaned Kubernetes resources.

**ArgoCD selfHeal**
Reverts manual `kubectl` changes back to what Git says. Detects drift every 3 minutes. Makes GitOps enforcement automatic — you cannot permanently change production with `kubectl`.

**AppProject (ArgoCD)**
Defines what an ArgoCD Application is ALLOWED to deploy: which source repos, which destination namespaces, which resource types. Scopes each team's Applications to their own namespace. Prevents cross-namespace accidents.

**Taint (Kubernetes node)**
A "do not schedule here unless you have permission" marker on a node. `dedicated=system:NoSchedule` = only pods with matching toleration can run on this node. Reserves system nodes for platform components.

**Toleration**
A pod configuration that allows it to be scheduled on tainted nodes. `key: dedicated, value: system, effect: NoSchedule` matches the system node taint. Required for: ALB Controller, ExternalDNS, Karpenter, Dynatrace ActiveGate.

**nodeAffinity (requiredDuringSchedulingIgnoredDuringExecution)**
Hard scheduling rule that says "this pod MUST run on nodes matching these labels." Used to pin platform components to system nodes. `IgnoredDuringExecution` = if a node label changes, existing pods aren't evicted.

**Karpenter NodePool**
A CRD that defines the rules for what nodes Karpenter can provision: instance families, architectures (arm64), capacity types (spot/on-demand), size limits. The policy that governs node provisioning.

**EC2NodeClass**
A CRD that defines the hardware template for Karpenter-provisioned nodes: which AMI family, which subnets (via tags), which security groups, volume size, encryption. The "launch template" for new nodes.

**Karpenter consolidation**
Automatically replaces underutilised nodes with smaller ones (or terminates empty nodes). `consolidateAfter: 30s` = start consolidating 30 seconds after a node is detected as underutilised. Reduces costs continuously.

**txtOwnerId (ExternalDNS)**
A unique identifier this ExternalDNS instance adds to TXT records alongside DNS A records. Prevents multiple clusters (staging + prod) from overwriting each other's DNS records in a shared Route53 zone.

**domainFilter (ExternalDNS)**
Restricts ExternalDNS to only manage records in specified domains. Without it: ExternalDNS modifies records in ALL Route53 zones in the account (including email MX records, internal zones). A critical safety setting.

**DynaKube**
The Dynatrace Operator's primary CRD. Defines WHAT the operator deploys: OneAgent (which nodes, resources), ActiveGate (how many replicas, which capabilities), log monitoring. One DynaKube = one monitoring configuration.

**OneAgent (classicFullStack)**
A DaemonSet pod (one per node) that monitors everything on that node: processes, containers, network, disk, application traces. Auto-instruments Java/Python/Node.js without code changes.

**ActiveGate**
A Dynatrace gateway component that proxies monitoring data from OneAgent pods to the DT cloud. Also queries the Kubernetes API for cluster-level metrics. Deployed with `replicas: 2` for HA.

**Dynatrace management zone**
A filter that groups entities (services, hosts, processes, k8s workloads) by tag. Each team has their own zone. Alerting profiles are scoped to zones — only the team's entities trigger their alerts. Prevents cross-team alert noise.

**Burn rate (error budget)**
How fast the error budget is being consumed relative to the monthly allowance. Burn rate 14.4× = at this rate, the 30-day budget will be exhausted in 2 days. Triggers immediate paging. More precise than point-in-time error rate alerts.

**Synthetic monitor (Dynatrace)**
Periodic HTTP requests from Dynatrace's external monitoring nodes to your service. Tests the full path: DNS → internet → ALB → pod → response. OneAgent sees the inside; synthetics see what users see. Essential for catching external connectivity failures.

**P99 (latency)**
The 99th percentile response time. 99% of requests complete faster than this value. Exposes the slowest 1% of requests that average latency hides. If average is 50ms but P99 is 5000ms: 10 users/second have a terrible experience.

**Pessimistic constraint (~>)**
Terraform version constraint that allows patch updates but not minor or major version bumps. `~> 5.50` = allows 5.50.x but not 5.51 or 6.x. Prevents unexpected breaking changes from provider version upgrades.

**DynamoDB lock (Terraform)**
Before `terraform apply`, Terraform writes a lock entry to DynamoDB. Any concurrent apply attempt reads the lock and is blocked. Prevents two engineers from applying simultaneously and corrupting the state file.

**sensitive = true (Terraform output)**
Marks an output as containing sensitive data. `terraform output` prints `<sensitive>`. `terraform output -raw` still works (explicit). Prevents accidental logging of certificates or tokens in CI pipelines.

**default_tags (AWS provider)**
Automatically applies specified tags to every AWS resource created by the provider. Without it: every resource block needs `tags = merge(...)`. With it: tags are implicit — no risk of missing a resource.

**cidrsubnet (Terraform function)**
Calculates a subnet CIDR from a VPC CIDR. `cidrsubnet("10.0.0.0/16", 8, 1)` = `10.0.1.0/24`. The second argument (8) = how many additional bits to use. The third (1) = which subnet number. Used to calculate all subnet CIDRs from the VPC CIDR.

**Gateway VPC Endpoint (S3/DynamoDB)**
A free VPC network route that sends S3 and DynamoDB traffic through the AWS backbone instead of the internet via NAT Gateway. No data transfer cost. No security group needed. No NAT Gateway required.

**IRSA trust policy sub condition**
The OIDC claim that identifies which Kubernetes ServiceAccount can assume the IAM role. Format: `"system:serviceaccount:NAMESPACE:SERVICEACCOUNT"`. Both namespace AND name must match exactly — prevents cross-namespace privilege escalation.

**is_jvm_service (variable)**
A boolean in the services map that controls whether JVM-specific monitoring (heap utilisation metric event) is created. `false` for Go/Python/Node services prevents creating alerts for metrics that don't exist on those runtimes.

**jvm_heap_pct (variable)**
The percentage of JVM maximum heap (-Xmx) that triggers an alert. At 75%: GC pressure begins, latency starts climbing. At 90%: GC thrashing. Alert at 70-75% gives engineers time to act before user impact.

**alert_on_no_data**
Controls whether a metric event fires when no data is received. `true` for traffic drop (no data = possible outage). `false` for other signals (no data = service unreachable → traffic drop alert already fired). Prevents duplicate alerts.

**entity_dimension_key**
Tells Dynatrace which entity type the metric belongs to. Different metrics live on different entities: service metrics on `dt.entity.service`, CPU on `dt.entity.process_group_instance`, pod restarts on `dt.entity.cloud_application`. Using the wrong type = alert never routes to the management zone.
