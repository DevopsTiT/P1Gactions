# Part 7 — terraform/dynatrace/ Deep Dive

> **What this folder is:** Terraform that configures the entire Dynatrace tenant — management zones, alerting profiles, metric events, SLOs, synthetic monitors, and notifications. Changes here never touch AWS infrastructure.

---

## terraform/dynatrace/main.tf

```hcl
data "aws_secretsmanager_secret_version" "dt_api_token" {
  secret_id = "production/dynatrace/api-token"
}

provider "dynatrace" {
  dt_env_url   = data.aws_secretsmanager_secret_version.dt_tenant_url.secret_string
  dt_api_token = data.aws_secretsmanager_secret_version.dt_api_token.secret_string
}

locals {
  teams = toset([for svc in values(var.services) : svc.team])
}
```
```
SECRET-BASED PROVIDER CREDENTIALS:
  The DT API token is read from Secrets Manager AT APPLY TIME.
  It is NEVER stored in:
    - Git (would be committed permanently)
    - terraform.tfvars (could be committed accidentally)
    - GitHub Secrets (CI can see them but pipeline logs might expose them)
  
  Flow: CI pipeline assumes github-actions-dynatrace-apply IAM role
  → that role has secretsmanager:GetSecretValue on production/dynatrace/*
  → Terraform calls Secrets Manager → gets the token
  → provider "dynatrace" uses it to call DT API
  → token is never written to the state file (it's a data source, not a resource)

locals.teams:
  Derives the set of unique teams from the services map.
  
  For services = { "payment-service": { team = "payments" }, "order-service": { team = "orders" } }
  → teams = toset(["payments", "orders"])
  
  This one local drives ALL management zones and alerting profiles.
  Adding payment-service2 with team = "payments":
  → teams still = { "payments", "orders" } (toset deduplicates)
  → no new management zone created (payments zone already exists)
  → no new alerting profile created
  
  Adding a new team for the first time:
  → teams grows → new management zone, new alerting profiles auto-created.
  Single source of truth: the services map.
```

---

## terraform/dynatrace/variables.tf

**The Single Source of Truth:**
```hcl
variable "services" {
  type = map(object({
    team = string, slo_target = number, health_check_url = string
    traffic_min_rps = number, error_rate_alert = number
    latency_p99_ms = number, cpu_saturation_pct = number
    memory_usage_pct = number, jvm_heap_pct = number
    is_jvm_service = bool, pod_restart_threshold = number
    network_error_rate_pct = number
  }))
  default = {
    "payment-service" = {
      team = "payments", slo_target = 99.9, ...
      traffic_min_rps = 10, error_rate_alert = 0.1, latency_p99_ms = 300
      cpu_saturation_pct = 70, memory_usage_pct = 75
      jvm_heap_pct = 70, is_jvm_service = true
      pod_restart_threshold = 2, network_error_rate_pct = 0.5
    }
  }
}
```
```
ONE entry in this map creates:
  - 1 management zone rule (via management-zones.tf)
  - 8 metric events (traffic, errors, latency, CPU, memory, JVM heap, pod restarts, network)
  - 4 alerting profiles (critical/high/warning/info) → already exist per team (not per service)
  - 2 SLOs (availability + latency)
  - 1 synthetic monitor
  
  Total: ~11 Dynatrace resources per service. 4 services = 44 resources.
  Added with ONE line: add a map entry, commit, PR, merge.
  
  This is "configuration as code" for observability.
  New service onboarding checklist in most companies:
    1. Write the service code ✓
    2. Add Dynatrace monitoring → edit variables.tf → ONE ENTRY → all monitoring created
  
  Compare to WITHOUT this approach:
    1. Log into Dynatrace
    2. Navigate to Alerting → Create custom metric event × 8
    3. Navigate to SLOs → Create SLO × 2
    4. Navigate to Synthetics → Create monitor × 1
    5. Navigate to Management Zones → Add rule
    6. Navigate to Alerting Profiles → Update × 4
    Total: ~20 manual steps, 30-60 minutes, prone to inconsistency and mistakes.

is_jvm_service: controls whether JVM heap monitoring is created.
  Go services, Node.js services: is_jvm_service = false
  → local.jvm_services will exclude them
  → dynatrace_metric_events.jvm_heap not created for them
  → no "JVM heap utilization" metric event firing on non-JVM services (noise)
  
  Java services (payment-service uses JVM): is_jvm_service = true
  → JVM heap monitoring created
  → alert at 70% heap (GC pressure starting)
```

---

## terraform/dynatrace/management-zones.tf

```hcl
resource "dynatrace_management_zone_v2" "team" {
  for_each = local.teams

  rules {
    rule { type = "SERVICE"      ... attribute: SERVICE_TAGS includes team:<team> }
    rule { type = "HOST"         ... attribute: HOST_TAGS includes team:<team> }
    rule { type = "PROCESS_GROUP"... attribute: PROCESS_GROUP_TAGS includes team:<team> }
    rule { type = "KUBERNETES_CLUSTER" ... attribute: env tag }
  }
}
```
```
WHY FOUR RULE TYPES:

SERVICE entities (error rate, latency, traffic signals):
  The payment-service microservice appears in DT as a "SERVICE" entity.
  Tagged with: team:payments (via Kyverno-enforced pod labels).
  The management zone must include SERVICE entities with this tag
  for error rate / latency / traffic alerts to fire to the right team.

HOST entities (network error rate signal):
  EC2 nodes appear as "HOST" entities in DT.
  EKS nodes tagged with: team:platform (they're shared infrastructure).
  The network error rate signal fires on hosts.
  The management zone must include HOST entities for these alerts to route correctly.

PROCESS_GROUP entities (CPU saturation, JVM heap signals):
  Running processes appear as "PROCESS_GROUP_INSTANCE" entities.
  CPU and JVM heap metrics live here.
  Without this rule: the cpu_saturation alert fires but doesn't route to any management zone.
  Result: alert exists but goes to the "default" profile → wrong team notified or nobody.

KUBERNETES_CLUSTER entities (pod restart, memory signals):
  Kubernetes workloads appear as "KUBERNETES_CLUSTER" > "WORKLOAD" hierarchy.
  Pod restarts and container memory metrics live here.
  These CANNOT be tagged per-team (the cluster is shared).
  The rule adds the environment tag → scoped by environment only.
  For proper team scoping: use k8s.workload.name in the entity_filter instead.

WHAT HAPPENS WITHOUT THE CORRECT ENTITY TYPES:
  cpu_saturation fires → creates a Problem in DT.
  Problem has severity: RESOURCE_CONTENTION.
  Management zones are checked: "which management zone includes this entity?"
  If the process entity isn't in the payments management zone:
  The alerting profile for payments team is NOT triggered.
  Alert fires to nobody → silent CPU issue.
```

---

## terraform/dynatrace/alerting-profiles.tf

```hcl
# Tier 1 CRITICAL: only in prod
resource "dynatrace_alerting" "critical" {
  for_each = var.environment == "prod" ? local.teams : toset([])
  rules { rule { severity_level = "AVAILABILITY", delay_in_minutes = 0 } }
}

# Tier 2 HIGH: prod + staging
resource "dynatrace_alerting" "high" {
  for_each = contains(["prod", "staging"], var.environment) ? local.teams : toset([])
  rules { rule { severity_level = "ERROR", delay_in_minutes = 2 } }
}

# Tier 3 WARNING: all environments
resource "dynatrace_alerting" "warning" {
  for_each = local.teams
  rules { rule { severity_level = "SLOWDOWN", delay_in_minutes = 5 } }
}

# Tier 4 INFO: all environments
resource "dynatrace_alerting" "info" {
  for_each = local.teams
  rules {
    rule { severity_level = "RESOURCE_CONTENTION", delay_in_minutes = 15 }
    rule { severity_level = "CUSTOM_ALERT", delay_in_minutes = 15 }
  }
}
```
```
ENVIRONMENT GATING:
  critical: var.environment == "prod" ? local.teams : toset([])
  If environment = "staging": creates ZERO critical profiles (no PagerDuty for staging)
  If environment = "prod": creates one critical profile per team.
  
  WHY:
  Staging exists to test changes before production.
  A staging service going down should NOT wake up an on-call engineer at 3am.
  But staging errors should be VISIBLE in Slack (warning profile applies everywhere).
  
  Developers can fix staging issues during business hours.
  Only PRODUCTION alerts require immediate (night/weekend) response.

DELAY DESIGN RATIONALE:
  AVAILABILITY delay = 0:
  Service DOWN = every second matters.
  Dynatrace fires the moment it confirms downtime.
  No grace period — there is no "brief availability blip" to filter.
  ALBs fail fast; 10-second downtime is user-visible.
  
  ERROR delay = 2 minutes:
  During a rolling deployment: old pods removed, new pods starting.
  There's a ~30-60 second window where error rates spike.
  New pods might have transient startup errors before passing readiness.
  2-minute delay: if the deployment succeeds, errors drop before alert fires.
  If the deployment is broken: errors persist past 2 minutes → alert fires.
  Eliminates most deployment-triggered false positives.
  
  SLOWDOWN delay = 5 minutes:
  Latency fluctuates more than error rate.
  A JVM GC pause causes 1-2 seconds of elevated P99.
  A memory pressure event causes 30-second latency spikes.
  These are real but transient and self-resolve.
  5-minute delay: confirms it's a sustained degradation, not a brief spike.
  
  RESOURCE_CONTENTION delay = 15 minutes:
  CPU and memory trends develop over hours.
  A 10-minute CPU spike during a batch job is normal.
  15-minute threshold: confirms it's not a normal peak but a sustained trend.
  These alerts inform capacity planning, not immediate incident response.
```

---

## terraform/dynatrace/metric-events.tf

**The most complex file — 8 resources × 4 services = 32 metric event rules.**

```hcl
# Signal 1: traffic_drop
alert_condition    = "BELOW"
alert_on_no_data   = true       # UNIQUE to this signal
threshold          = each.value.traffic_min_rps
violating_samples  = 3
```
```
alert_on_no_data = true: THE CRITICAL SETTING FOR SILENT OUTAGES.

Normal operation: DT receives "30 requests/min" every minute → above threshold → no alert.

Silent outage (DNS failure, ALB misconfiguration):
  DT receives NOTHING for 3 minutes.
  With alert_on_no_data = false: "no data = no problem" → alert never fires.
  You discover the outage when a customer calls.
  
  With alert_on_no_data = true:
  DT sees: 0 data points → treats as "0 requests/min".
  0 req/min < 10 req/min threshold → BELOW condition triggered.
  Alert fires after violating_samples = 3 consecutive minutes.
  
  This is the only signal that can catch a total connectivity failure.
  All other signals need REQUEST DATA to fire. No requests = no data.

alert_condition = "BELOW":
  This is the ONLY signal that fires on "too low" values.
  All others fire on "too high" (CPU > 80%, error rate > 0.5%).
  Traffic drop is "healthy" when high, "problem" when low.
  Classic asymmetric monitoring.
```

```hcl
# Signal 3: latency_p99
metric_key  = "builtin:service.response.time"
aggregation = "PERCENTILE"
percentile  = 99
threshold   = each.value.latency_p99_ms * 1000   # ms → μs
```
```
threshold = each.value.latency_p99_ms * 1000:
  DT stores response time in MICROSECONDS (μs).
  500ms = 500,000 μs.
  If you set threshold = 500 (forgetting to multiply):
  Alert fires when P99 > 0.5ms → FIRES CONSTANTLY (every request).
  
  The × 1000 conversion is essential and easy to forget.
  This is why the variable is named latency_p99_ms (explicit unit) 
  and the conversion is commented in the code.

aggregation = "PERCENTILE", percentile = 99:
  DT receives response times for every request.
  It pre-aggregates into percentile buckets per minute.
  "PERCENTILE with 99" = the value that 99% of requests are below.
  
  Alternative (average): sum of all response times / count.
  1000 requests: 999 at 50ms, 1 at 50,000ms.
  Average = (999 × 50ms + 1 × 50,000ms) / 1000 = 99.95ms (looks fine!)
  P99 = 50,000ms (that 1 slowest request is above the 99th percentile)
  
  Average HIDES the outlier that represents 10 users/second having terrible experience.
  P99 EXPOSES it.
```

```hcl
# Signal 6: jvm_heap — only for JVM services
resource "dynatrace_metric_events" "jvm_heap" {
  for_each = local.jvm_services   # local from main.tf
```
```
local.jvm_services:
  Defined in main.tf as:
  jvm_services = { for name, svc in var.services : name => svc if svc.is_jvm_service }
  
  For our 4 services:
  payment-service: is_jvm_service = true  → included
  order-service:   is_jvm_service = true  → included
  inventory-service: is_jvm_service = false → EXCLUDED
  analytics-service: is_jvm_service = false → EXCLUDED
  
  jvm_heap metric event created: only for payment-service + order-service.
  
  WHY THIS MATTERS:
  builtin:process.memory.jvm.heapUtilization is a JVM-specific metric.
  DT OneAgent only collects it for Java processes.
  For Go (inventory-service) or Python (analytics-service): metric is empty.
  Creating a JVM heap event for a Go service:
  → alert_on_no_data = false → never fires (no data = no alert)
  → but it's cluttered, confusing, and wrong in DT's UI
  → drift from the actual service technology
  
  is_jvm_service = false + local filter = clean, correct monitoring.
```

---

## terraform/dynatrace/notifications.tf

```hcl
resource "dynatrace_pagerduty_notification" "critical" {
  for_each         = var.pagerduty_integration_keys
  alerting_profile = dynatrace_alerting.critical[each.key].id
  service_api_key  = each.value
}
```
```
for_each = var.pagerduty_integration_keys:
  This iterates over the MAP, not local.teams.
  
  var.pagerduty_integration_keys = { "payments" = "key1", "platform" = "key2" }
  
  WHY NOT for_each = local.teams:
  If all teams had PagerDuty: use local.teams.
  But what if the "inventory" team uses email instead of PagerDuty?
  
  pagerduty_integration_keys = { "payments" = "key1", "orders" = "key2" }
  (inventory omitted → no PagerDuty notification for inventory team)
  
  Teams in local.teams but NOT in pagerduty_integration_keys:
  → No critical PagerDuty notification created for them.
  Each team can have different notification channels.
  
  THE PROBLEM WITH for_each = local.teams:
  If "inventory" is in teams but not in pagerduty_integration_keys:
  → Terraform tries to create dynatrace_alerting.critical["inventory"]
  → but dynatrace_pagerduty_notification.critical["inventory"] fails 
     (no PagerDuty key provided)
  → terraform apply fails for ALL notifications
  
  The map-based for_each creates notifications ONLY for teams that have keys defined.

alerting_profile = dynatrace_alerting.critical[each.key].id:
  The notification is linked to the alerting profile for this team.
  "critical" notification for "payments" → linked to "payments-production-critical" profile.
  
  This is the wire between:
  Metric event fires → creates Problem → matches alerting profile → triggers notification → PagerDuty.
```

---

## terraform/dynatrace/slos.tf

```hcl
resource "dynatrace_slo_v2" "availability" {
  metric_expression = <<-EOT
    100*(builtin:service.requestCount.server
      :filter(eq(service.name,"${each.key}"))
      :splitBy():sum
      - builtin:service.errors.server.count
      :filter(eq(service.name,"${each.key}"))
      :splitBy():sum)
    / builtin:service.requestCount.server
      :filter(eq(service.name,"${each.key}"))
      :splitBy():sum
  EOT
  
  error_budget_burn_rate {
    fast_burn_threshold = 14.4
    slow_burn_threshold = 3.0
  }
}
```
```
THE SLI FORMULA:
  (total_requests - failed_requests) / total_requests × 100
  = successful_request_percentage
  
  Example: 10,000 requests, 50 errors.
  (10,000 - 50) / 10,000 × 100 = 99.5%
  
  If target_success = 99.9: SLO is BREACHED (99.5% < 99.9%).
  Error budget consumed = (99.9 - 99.5) / (100 - 99.9) × 100 = 400% of monthly budget.

BURN RATE EXPLAINED:
  Monthly error budget for 99.9% SLO = 0.1% × 30 days × 24h × 60min = 43.2 minutes.
  
  Burn rate 1.0 = consuming the budget at exactly the monthly allowance.
  
  fast_burn_threshold = 14.4:
  14.4× the normal rate = at this rate, the budget is exhausted in 30 days / 14.4 = 2 days.
  If it's been burning at 14.4× for the past hour: you'll be out of budget tomorrow.
  PAGE NOW.
  
  slow_burn_threshold = 3.0:
  3× the normal rate = budget exhausted in 10 days.
  Not an emergency but needs attention.
  Send to Slack: "error budget is burning 3× faster than normal."
  
  WHY NOT ALERT ON ERROR RATE ALONE:
  Error rate alert: fires when current rate > threshold (point-in-time).
  Burn rate alert: fires based on how fast the CUMULATIVE budget is consumed (window).
  
  Example: 1% error rate for 30 seconds → error rate alert fires.
  But 30 seconds of 1% errors out of 43 minutes of budget = 1/86 of the budget.
  Not worth waking someone up.
  
  Burn rate only fires when the consumption is significant relative to the total budget.
  More actionable, fewer false positives.

evaluation_window = "-1M" (rolling 30 days):
  The SLO always measures the LAST 30 days.
  An outage 28 days ago is STILL affecting the current SLO value.
  As time passes, old incidents roll off the window.
  Motivates teams to fix incidents quickly — the faster it's fixed, the smaller the impact.
```

---

## terraform/dynatrace/synthetics.tf

```hcl
resource "dynatrace_http_monitor" "health_check" {
  frequency = 5   # every 5 minutes
  locations = var.synthetic_locations   # Tokyo + Singapore
  
  validation {
    rule { type = "httpStatusesList", value = "2xx",         pass_if_found = true }
    rule { type = "patternConstraint", value = "\"status\":\"ok\"", pass_if_found = true }
  }
  
  response_time_limit = each.value.latency_p99_ms * 3
}
```
```
WHY SYNTHETIC MONITORS IN ADDITION TO ONEAGENT:
  OneAgent monitoring: measures from INSIDE the cluster.
  Can see: pod errors, pod latency, process CPU.
  CANNOT see: DNS resolution from the internet, ALB connectivity,
              TLS certificate validity, CDN issues.
  
  Synthetic monitor: HTTP request from DT's global monitoring nodes (Tokyo, Singapore).
  Simulates a REAL USER REQUEST from outside your cluster.
  
  Catches:
  ✓ ALB is unreachable (network path to ALB broken)
  ✓ DNS returns wrong IP (Route53 misconfiguration)
  ✓ TLS certificate expired (HTTPS fails)
  ✓ Health endpoint returns 500 (app error OneAgent might not surface as "outage")
  ✓ Response body changed ("status": "degraded" instead of "ok")
  
  OneAgent tells you: "pods are healthy, error rate is 0%"
  Synthetic tells you: "users cannot reach the service at all"
  Both signals are needed. OneAgent = internal view. Synthetic = external/user view.

TWO LOCATIONS (Tokyo + Singapore):
  One location failure could be a regional network issue (not your fault).
  global_outages = true: alert only when BOTH locations fail.
  local_outages = true: alert if ONE location fails 3 times in a row.
  
  Eliminates false alarms from:
  - DT monitoring node temporary issue
  - Regional BGP routing instability
  - Tokyo-specific internet issue (Singapore still reaches your service = your fault?)
  
  global outage (both locations fail) = YOUR SERVICE IS DOWN. Page immediately.
  local outage (only Tokyo fails) = investigate. Could be DT, could be network.

response_time_limit = latency_p99_ms * 3:
  If latency_p99_ms = 300ms: synthetic warns if response > 900ms.
  3× gives headroom for: synthetic overhead (DT agent → internet → ALB → pod → response → internet → DT agent)
  Synthetic latency is always higher than internal latency.
  Alert fires on ABNORMAL slow responses, not on expected overhead.
```
