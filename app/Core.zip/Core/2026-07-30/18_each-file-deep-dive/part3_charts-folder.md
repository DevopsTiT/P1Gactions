# Part 3 — charts/ Folder Deep Dive

> **What this folder is:** Helm charts that define how Kubernetes resources are created. ArgoCD reads these charts and renders them into actual Kubernetes YAML. Think of charts as parameterised templates — one chart, different values = different environments.

---

## charts/namespaces/ — Namespace Chart

**What it does:** Creates all Kubernetes Namespaces in one shot. Deployed first (sync-wave -1).

### charts/namespaces/Chart.yaml
```yaml
apiVersion: v2
name: namespaces
description: Creates all platform namespaces
version: 0.1.0
```
```
Helm requires this file to treat the directory as a chart.
version: tracks the chart itself (separate from app version).
No appVersion here — namespaces don't have a version.
```

### charts/namespaces/templates/namespace.yaml
```yaml
{{- range .Values.namespaces }}
apiVersion: v1
kind: Namespace
metadata:
  name: {{ .name }}
  labels:
    team: {{ .team }}
    environment: {{ $.Values.environment }}
{{- end }}
```
```
range = Helm's for-loop: iterate over the namespaces list in values.yaml.
For each item: renders one Namespace YAML block.
WHY A TEMPLATE INSTEAD OF STATIC YAML:
  6 namespaces → 6 Namespace YAML files → 6 ArgoCD sync targets.
  1 chart with range → 1 ArgoCD Application → renders all 6 at once.
  Adding a namespace: edit values.yaml (one line), commit, ArgoCD creates it.
```

### charts/namespaces/values.yaml
```yaml
environment: production
namespaces:
  - { name: argocd,            team: platform }
  - { name: karpenter,         team: platform }
  - { name: external-secrets,  team: platform }
  - { name: dynatrace,         team: platform }
  - { name: kyverno,           team: platform }
  - { name: payment-ns,        team: payments }
```
```
team label = CRITICAL for Dynatrace.
  Dynatrace management zone rules match on: tag "team:payments"
  If payment-ns namespace has label team=payments:
    All pods in payment-ns inherit this label.
    Dynatrace OneAgent reads the label via Kubernetes API.
    Entities are automatically tagged: team:payments.
    Management zone "payments-production" includes them automatically.
  
  Without team label: entities have no team tag → no management zone scope →
  payment team sees all platform alerts → alert noise.
```

---

## charts/payment-service/ — Application Chart

**What it creates:** All Kubernetes resources for the payment-service microservice.

### charts/payment-service/Chart.yaml
```
apiVersion: v2, name: payment-service, version: 0.1.0, appVersion: "0.0.1"
```
appVersion = the application semantic version. Different from the image SHA tag (which is the deployment-level identifier).

### charts/payment-service/values.yaml
The defaults for all template variables. Key sections:
```yaml
image:
  repository: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  tag: "abc1234"       # ← GitHub Actions overwrites this on every deploy
  pullPolicy: IfNotPresent

replicaCount: 3

serviceAccount:
  create: true
  name: payment-service
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::123456789012:role/company-prod-payment-service

ingress:
  enabled: true
  host: payment.company.com
  certArn: arn:aws:acm:...

resources:
  requests: { cpu: 250m, memory: 512Mi }
  limits:   { cpu: 1000m, memory: 1Gi }

hpa:
  minReplicas: 3
  maxReplicas: 20
  targetCPUUtilizationPercentage: 70

pdb:
  minAvailable: 2
```
```
WHY requests != limits:
  requests.cpu: 250m = "I need AT LEAST 250 millicores to function".
    Kubernetes scheduler places the pod on a node that has 250m free.
  limits.cpu: 1000m = "I can burst to 1 full core but no more".
    If the pod exceeds 1000m: it is CPU-throttled (slowed down, not killed).
  
  requests.memory: 512Mi = scheduling guarantee.
  limits.memory: 1Gi = hard cap. If pod exceeds 1Gi: OOM killed (restarted).
  
  requests < limits is normal ("burstable" QoS class).
  requests = limits = "guaranteed" QoS (harder to schedule but never throttled).
```

---

### templates/deployment.yaml — Deep Dive

**Rolling Update Strategy:**
```yaml
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxUnavailable: 0
    maxSurge: 1
```
```
DEPLOYMENT LIFECYCLE with maxUnavailable=0, maxSurge=1:
  Current state: 3 pods (v1, v1, v1)
  
  Step 1: Create new pod v2 (surge=1, now 4 pods running: v1 v1 v1 v2)
  Step 2: Wait for v2 to pass readiness probe (ready to serve traffic)
  Step 3: Terminate one v1 (back to 3 pods: v1 v1 v2)
  Step 4: Repeat until all 3 are v2 (v2 v2 v2)
  
  At NO POINT are there fewer than 3 healthy pods.
  Zero-downtime guaranteed.
  
  WHY NOT maxUnavailable=1, maxSurge=0:
  That would terminate one v1 BEFORE creating v2.
  Briefly: only 2 pods serving traffic with 3× the expected load.
  Payment service cannot afford a 33% capacity reduction during deploy.
```

**Topology Spread Constraints:**
```yaml
topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: topology.kubernetes.io/zone
    whenUnsatisfiable: DoNotSchedule
    labelSelector:
      matchLabels:
        app: payment-service
```
```
WHAT THIS GUARANTEES with 3 pods:
  AZ-a: 1 pod, AZ-b: 1 pod, AZ-c: 1 pod
  maxSkew=1: no AZ can have MORE THAN 1 extra pod vs another AZ.
  
  If AZ-a has 2 and AZ-b has 0: skew = 2. Exceeds maxSkew=1.
  Kubernetes scheduler REFUSES to place another pod in AZ-a.
  Forces pod to AZ-b or AZ-c.
  
  WHY CRITICAL FOR PAYMENT SERVICE:
  AWS AZ outage (happens ~2 times/year):
  WITHOUT zone spread: 2 of 3 pods might be in AZ-a → AZ-a fails → service down
  WITH zone spread: 1 pod per AZ → AZ-a fails → 2 pods in AZ-b + AZ-c still alive
  
  whenUnsatisfiable: DoNotSchedule
  If all AZs are full and can't satisfy maxSkew=1: pod stays Pending.
  Better than violating zone spread.
  Karpenter sees Pending pod → adds a node in the correct AZ.
```

**Pod Anti-Affinity:**
```yaml
affinity:
  podAntiAffinity:
    requiredDuringSchedulingIgnoredDuringExecution:
      - labelSelector:
          matchLabels:
            app: payment-service
        topologyKey: kubernetes.io/hostname
```
```
RULE: no two payment-service pods on the same physical node.
topologyKey: kubernetes.io/hostname = "this node" (not the AZ, the specific machine).

COMBINED WITH ZONE SPREAD:
  Zone spread ensures: 1 pod per AZ (inter-AZ protection)
  Anti-affinity ensures: 1 pod per NODE (intra-AZ protection)
  
  AZ-a has 2 nodes: Node-1 and Node-2.
  With 3 replicas and 3 AZs: each AZ gets 1 pod, each on a different node.
  If AZ-a Node-1 fails: only 1 pod lost. AZ-b and AZ-c pods are fine.
  
  required (hard rule) vs preferred (soft rule):
  required: scheduler REFUSES to place the pod if it violates anti-affinity.
  preferred: scheduler TRIES to avoid but will violate if no other option.
  PAYMENT SERVICE USES required: we never want two pods on the same node.
  A node failure should not take down more than 1/3 of capacity.
```

**Probes:**
```yaml
startupProbe:
  httpGet:  { path: /health/live, port: 8080 }
  failureThreshold: 30
  periodSeconds: 10

livenessProbe:
  httpGet:  { path: /health/live, port: 8080 }
  periodSeconds: 10
  failureThreshold: 3

readinessProbe:
  httpGet:  { path: /health/ready, port: 8080 }
  periodSeconds: 5
  failureThreshold: 3
```
```
WHY THREE SEPARATE PROBES:
  StartupProbe runs FIRST. While it's running: liveness and readiness are paused.
  failureThreshold: 30 × periodSeconds: 10 = 300 seconds max startup.
  After startupProbe passes once: it stops. Liveness takes over.
  
  WITHOUT startupProbe:
  Java app takes 2 minutes to start.
  livenessProbe starts checking after initialDelaySeconds.
  App fails liveness during startup → Kubernetes restarts it → never starts.
  Classic: "pod stuck in CrashLoopBackOff during cold start"
  
  WITH startupProbe:
  startupProbe gives up to 5 minutes. If still not healthy at 5 min: something is wrong.
  After it passes: livenessProbe + readinessProbe take over at normal intervals.

preStop + terminationGracePeriodSeconds:
  preStop: sleep 10 (10 seconds BEFORE the process gets SIGTERM)
  terminationGracePeriodSeconds: 60 (60 seconds AFTER SIGTERM before SIGKILL)
  
  SEQUENCE:
  1. Pod removed from Service endpoints (ALB stops routing here)
  2. preStop: sleep 10 → allows the ALB to fully drain (~10s for connections to close)
  3. SIGTERM sent to process → app starts graceful shutdown
  4. terminationGracePeriodSeconds: 60 → Kubernetes waits up to 60s for process to exit
  5. If still running at 60s: SIGKILL (force kill)
  
  WHY preStop sleep 10?
  ALB → ELB deregistration → pod removal is ASYNCHRONOUS.
  There's a ~5-10 second window where the pod is removed from K8s endpoints
  but ALB still sends requests to it.
  Sleep 10 bridges this gap → zero in-flight request interruptions.
```

**Security Context:**
```yaml
securityContext:
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```
```
readOnlyRootFilesystem: true
  Container CANNOT write to its own filesystem.
  If an attacker exploits the app: cannot write a backdoor script.
  Cannot modify /etc/passwd to add a root user.
  App only writes to stdout (logs) — which goes to the node's log files.
  
  PREREQUISITE: app must not need to write to disk.
  Logs → stdout (correct). Temp files → /tmp (separate writable mount if needed).

allowPrivilegeEscalation: false
  Process cannot gain more privileges than it started with.
  Prevents: running sudo, setuid binaries, exploiting kernel vulnerabilities.

capabilities.drop: ["ALL"]
  Drops ALL Linux capabilities.
  Default Docker containers have: NET_BIND_SERVICE, CHOWN, SETUID, SETGID, etc.
  Dropping all = container has NO special kernel privileges.
  Running on port 8080 (not 80): no NET_BIND_SERVICE needed.
```

---

### templates/ingress.yaml — ALB Creation

```yaml
annotations:
  alb.ingress.kubernetes.io/scheme: internet-facing
  alb.ingress.kubernetes.io/target-type: ip
  alb.ingress.kubernetes.io/healthcheck-path: /health/ready
```
```
scheme: internet-facing
  Creates a PUBLIC ALB (accessible from the internet).
  Alternative: internal → VPC-only access.
  Payment API needs to be called from the internet (mobile apps, external partners).

target-type: ip
  ALB routes directly to POD IPs (not node IPs via NodePort).
  WHY: NodePort requires an extra hop (node → pod).
  IP target: ALB → pod directly = lower latency + better connection tracking.
  REQUIRES: VPC CNI (pods have real VPC IPs). EKS with vpc-cni = this works.

healthcheck-path: /health/ready (not /health/live)
  ALB performs its own health checks.
  WHY /ready and not /live?
  ALB wants to know: "should I send traffic to this pod?"
  /ready = "I'm ready to serve" → correct signal for load balancer.
  /live = "I'm alive" → doesn't check dependencies → ALB could route to pods
  that are alive but can't connect to the database.

ssl-redirect: "443"
  Visitors hitting http://payment.company.com → automatically redirected to HTTPS.
  Enforced at ALB level: app never sees HTTP requests.
```

---

### templates/external-secret.yaml — Secret Injection

```yaml
spec:
  refreshInterval: 1h
  secretStoreRef:
    name: aws-secrets-manager
    kind: ClusterSecretStore
  target:
    name: payment-service-db-credentials
  data:
    - secretKey: DB_HOST
      remoteRef:
        key: production/payment-service/db-credentials
        property: host
```
```
FULL FLOW — from Secrets Manager to pod environment variable:

  AWS Secrets Manager:
    secret name: "production/payment-service/db-credentials"
    secret value: { "host": "db.company.com", "username": "appuser", "password": "abc123..." }

  ExternalSecret watches this secret every 1 hour.
  Reads the JSON, extracts individual properties.
  Creates Kubernetes Secret "payment-service-db-credentials":
    DB_HOST = "db.company.com"
    DB_USERNAME = "appuser"
    DB_PASSWORD = "abc123..."

  Deployment mounts this Secret as envFrom:
    envFrom:
      - secretRef:
          name: payment-service-db-credentials
  
  Pod container sees:
    $DB_HOST = "db.company.com"
    $DB_USERNAME = "appuser"
    $DB_PASSWORD = "abc123..."

WHY NOT STORE SECRETS IN GIT:
  If password is in Git → anyone with repo read access has the DB password.
  Once in Git history: it's there FOREVER (even after rotation).
  
  ExternalSecret pattern:
  Git contains: "read from production/payment-service/db-credentials" (safe)
  Secrets Manager contains: the actual password (protected by IAM)
  Only ESO's IRSA role can read from Secrets Manager → only the ESO pod sees the value.
```
