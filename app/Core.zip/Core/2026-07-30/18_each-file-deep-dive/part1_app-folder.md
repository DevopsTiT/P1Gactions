# Part 1 — app/ Folder Deep Dive

> **What this folder is:** The actual payment microservice — Python source code, Dockerfile, tests. Everything the CI pipeline needs to build and test the Docker image.

---

## app/requirements.txt

```
fastapi==0.111.0
uvicorn[standard]==0.30.1
pytest==8.2.2
httpx==0.27.0
```

**What it is:** The pinned list of every Python package the app needs.

**Why every version is pinned (==):**
```
WITHOUT pinning:
  fastapi  → installs "latest" at build time
  Monday build: fastapi 0.111.0 (works)
  Tuesday build: fastapi 0.112.0 is released (breaking change)
  Tuesday build: app crashes — but you don't know why
  You're debugging a problem that was introduced by a library, not your code.

WITH pinning (fastapi==0.111.0):
  Every build on every machine uses the exact same version.
  If it worked on Monday, it works on Tuesday.
  To upgrade: change the pin deliberately, run tests, commit.
  Upgrades are intentional, not accidental.
```

**What each package does:**
```
fastapi==0.111.0
  The web framework. Handles: HTTP routing, request parsing,
  response serialisation, automatic input validation.
  Example: @app.get("/health/live") creates a GET /health/live endpoint.

uvicorn[standard]==0.30.1
  The web server. Listens on the TCP socket, accepts HTTP connections,
  passes requests to FastAPI.
  [standard] includes: uvloop (fast event loop) + httptools (fast HTTP parser).
  Started in CMD: uvicorn.run(app, host="0.0.0.0", port=8080)

pytest==8.2.2
  The test runner. Discovers test files (test_*.py) and runs them.
  Returns exit code 0 if all pass, 1 if any fail.
  CI checks the exit code — non-zero = pipeline stops.

httpx==0.27.0
  An HTTP client for Python — used by pytest to make test requests to FastAPI.
  FastAPI's TestClient is built on httpx internally.
```

---

## app/tests/test_main.py

**What it is:** Automated tests that verify the app works before it's deployed.

**What each test does:**
```python
def test_health_returns_200(client):
    assert client.get('/health').status_code == 200
```
```
WHAT IT TESTS: /health endpoint returns HTTP 200 (not 404, not 500).
WHY IT EXISTS: If this fails, the app is completely broken.
  Kubernetes health probes hit /health/live — if that returns non-200,
  every pod restarts in a loop (CrashLoopBackOff).
  This test catches that BEFORE the image is pushed to ECR.
```

```python
def test_health_returns_ok(client):
    data = json.loads(client.get('/health').data)
    assert data.get('status') == 'ok'
```
```
WHAT IT TESTS: /health returns JSON with {"status": "ok"}.
WHY IT EXISTS: The Dynatrace synthetic monitor validates the response body
  contains "status":"ok". A 200 response that says {"status": "degraded"}
  would pass the status code test but fail the Dynatrace check.
  This test enforces the contract the monitoring layer depends on.
```

```python
def test_root_returns_200(client):
    assert client.get('/').status_code == 200
```
```
WHAT IT TESTS: Root path / returns 200.
WHY IT EXISTS: ALB health checks hit / by default. A broken root path
  means the ALB considers ALL pods unhealthy → no traffic served.
```

**How pytest finds and runs tests:**
```bash
# CI runs this:
pytest app/tests/ -v --tb=short

# pytest discovers: any file named test_*.py
# pytest runs: any function named test_*
# -v = verbose output (shows each test name)
# --tb=short = short traceback on failure (easier to read in CI logs)
```

---

## app/main.py

**What it is:** The FastAPI payment microservice — 123 lines that define all endpoints.

### The structured logging function

```python
def log(level: str, event: str, **kwargs):
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "level": level,
        "service": "payment-service",
        "event": event,
        **kwargs
    }
    print(json.dumps(entry))
```
```
WHY JSON LOGS (not: "[2026-07-30 09:00] INFO: payment fetched"):
  JSON = structured → machine-parseable without regex rules.
  
  Dynatrace OneAgent reads /var/log/containers/*.log from the node.
  It can extract fields from JSON automatically:
    level, service, event → searchable in Dynatrace Logs
    payment_id → can filter "show me all logs for payment_id=pay_1234"
  
  CloudWatch Logs Insights queries on JSON:
    fields event, payment_id | filter level = "error"
  
  Fluent Bit (if used instead of OneAgent log monitoring) can parse JSON
  without any custom parsers.
  
  **kwargs: any extra fields passed to log() are merged in.
    log("info", "payment_fetched", payment_id="123", duration_ms=52.3)
    → {"timestamp":..., "level":"info", "event":"payment_fetched",
       "payment_id":"123", "duration_ms":52.3}
```

### The health endpoints

```python
@app.get("/health/live")   # Liveness probe
def liveness():
    return {"status": "alive", ...}
```
```
WHAT IT CHECKS: Is the Python process running?
KUBERNETES USES IT: livenessProbe → if this fails 3 times → container RESTARTED.
CORRECT BEHAVIOUR: This must ALWAYS return 200 unless the process is stuck/deadlocked.
WRONG PATTERN: Checking the database here.
  If DB is down → liveness returns 500 → pod restarts → pod checks DB again → fails again
  → restart loop forever. The DB being down is NOT a reason to restart the app.
```

```python
@app.get("/health/ready")   # Readiness probe
def readiness():
    db_host = os.getenv("DB_HOST", "")
    if not db_host:
        raise HTTPException(status_code=503, detail="Database not configured")
    return {"status": "ready", ...}
```
```
WHAT IT CHECKS: Is the app ready to accept traffic? Is config present?
KUBERNETES USES IT: readinessProbe → if this fails → pod REMOVED from Service endpoints.
  Traffic is redirected to healthy pods. Pod is NOT restarted.
CORRECT BEHAVIOUR: Check dependencies. Return 503 if not ready.
WHY THIS IS DIFFERENT FROM LIVENESS:
  DB being down = don't send requests here = readiness fails (correct).
  DB being down = pod should restart? = NO! Restarting doesn't fix the DB.
  readiness = "don't send me traffic right now"
  liveness  = "I'm broken, restart me"
```

### Business logic pattern

```python
@app.get("/api/v1/payments/{payment_id}")
def get_payment(payment_id: str):
    start_time = time.time()
    log("info", "payment_fetch", payment_id=payment_id)   # log BEFORE the operation
    time.sleep(0.05)   # simulated 50ms DB query
    duration_ms = (time.time() - start_time) * 1000
    log("info", "payment_fetched", payment_id=payment_id, duration_ms=round(duration_ms, 1))
    return {...}
```
```
LOG BEFORE AND AFTER pattern:
  Log before: confirms the request was received (even if it crashes mid-operation)
  Log after with duration_ms: confirms the request completed + how long it took
  
  Without "before" log: if the DB call hangs, you only know a request started
                        when you see no "after" log — confusing gap.
  With both logs: you can calculate "gap" = duration_ms exactly for every request.
  
  duration_ms in every log line = poor man's performance tracing.
  Dynatrace auto-instruments this endpoint too — but the explicit log is a backup.
```

---

## app/Dockerfile

**What it is:** The build recipe that converts main.py into a Docker image.

### Stage 1: Builder

```dockerfile
FROM python:3.12-slim-bookworm AS builder
WORKDIR /app
COPY requirements.txt .
RUN python -m venv /opt/venv && \
    /opt/venv/bin/pip install --no-cache-dir -r requirements.txt
```
```
WHY python:3.12-slim-bookworm AND NOT python:3.12:
  python:3.12 = 1.2GB (includes: gcc, make, binutils, many dev packages)
  python:3.12-slim-bookworm = 130MB (minimal Debian — just what Python needs)
  
  The builder has all build tools available to compile packages.
  Only the compiled output is copied to the runtime stage.

WHY /opt/venv (virtual environment):
  All packages installed into /opt/venv instead of system Python.
  The ENTIRE /opt/venv directory is copied to Stage 2 as a single unit.
  Clean separation: builder has everything, runtime has only /opt/venv.

--no-cache-dir:
  pip doesn't save its download cache.
  Without this: Docker layer has downloaded packages + cache = larger layer.
  With this: Docker layer only has installed packages = smaller image.
```

### Stage 2: Runtime

```dockerfile
FROM python:3.12-slim-bookworm AS runtime
RUN groupadd -r appgroup && useradd -r -g appgroup -u 1000 appuser
COPY --from=builder /opt/venv /opt/venv
COPY main.py .
USER appuser
ENV PATH="/opt/venv/bin:$PATH"
```
```
FRESH base image (new FROM):
  Python:3.12-slim-bookworm again — starts completely clean.
  No build tools from Stage 1 are carried over.
  Only two things are copied: /opt/venv and main.py.

useradd -u 1000:
  Creates a non-root user with a predictable UID.
  Kubernetes securityContext.runAsUser: 1000 references this UID.
  Any file written by the app is owned by UID 1000.
  If container is compromised: attacker has user permissions, not root.
  Cannot: install packages, modify /etc, create setuid binaries.

COPY --from=builder:
  Takes /opt/venv from the "builder" stage (discarded after this step).
  The builder image is never pushed to ECR — only the runtime image is.
  All of pip, gcc, and build headers are gone from the final image.
```

### Health check and labels

```dockerfile
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
  CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8080/health/live')"
```
```
Docker-level health check (different from Kubernetes probes).
Used by: docker run, docker-compose, ECR image scan.
Kubernetes IGNORES this and uses its own liveness/readiness probes instead.
Still useful for: local development testing, docker-compose based testing.
```

```dockerfile
ARG BUILD_DATE
ARG VCS_REF
LABEL build_date="$BUILD_DATE" vcs_ref="$VCS_REF"
```
```
Build arguments injected by GitHub Actions:
  BUILD_DATE = ${{ github.event.head_commit.timestamp }}
  VCS_REF    = ${{ github.sha }}
  
These are baked into the image as labels.
Later: docker inspect <image> shows exactly when it was built and from which commit.
ECR: you can see the VCS_REF and trace any running image back to a specific PR.
Trivy: includes VCS_REF in vulnerability scan reports.
```
