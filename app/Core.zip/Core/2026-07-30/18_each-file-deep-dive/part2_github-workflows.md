# Part 2 — .github/workflows/ Deep Dive

> **What this folder is:** The 3 GitHub Actions workflows that automate everything — app deployment, infra changes, and Dynatrace config. Nothing reaches production without passing through one of these.

---

## app-ci.yaml — Application CI/CD Pipeline

**Triggers:**
```yaml
on:
  push:
    branches: [main]
    paths: ['app/**', 'charts/**']
  pull_request:
    branches: [main]
    paths: ['app/**', 'charts/**']
```
```
paths filter: only runs when app/ or charts/ files changed.
If you edit terraform/ or gitops/: this pipeline does NOT run.
WHY: prevents unnecessary image builds from non-app changes.
     avoids burning CI minutes when only a Dynatrace threshold was tweaked.

push to main: test → build → push → deploy
pull_request:  test → build only (no push, no deploy)
```

### Job 1: test

```yaml
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/setup-python@v5
        with: { python-version: '3.12', cache: 'pip' }
      - run: pip install -r app/requirements.txt
      - run: pytest app/tests/ -v --tb=short
```
```
cache: 'pip'  → caches downloaded pip packages between runs.
  First run:  pip downloads from internet (~30s).
  Later runs: restores from GitHub Actions cache (~3s).
  WHY: CI runs up to 50 times/day on an active repo.
  Without cache: 50 × 30s = 25 min of redundant downloads per day.

pytest exit code:
  0 = all tests passed → job succeeds → build-push job runs
  1 = any test failed → job fails → build-push job SKIPPED
  Broken code CANNOT reach ECR. The gate is automatic.
```

### Job 2: build-push

```yaml
needs: test
permissions:
  id-token: write   # required for OIDC
  contents: write   # required to commit image tag update
```
```
needs: test
  build-push only starts AFTER test passes.
  GitHub Actions default: all jobs run in parallel.
  needs: creates an explicit dependency ordering.

id-token: write
  Allows the workflow to request an OIDC JWT from GitHub.
  This JWT is sent to AWS STS to exchange for temporary credentials.
  Without id-token: write → AWS OIDC authentication fails.

contents: write
  Allows the workflow to commit back to the repo (updating the image tag).
  Without this → git push at the end fails with "insufficient permission".
```

### OIDC Authentication Deep Dive

```yaml
- name: Configure AWS credentials
  uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789012:role/github-actions-ecr-push
    aws-region: ap-northeast-1
    role-session-name: github-actions-${{ github.run_id }}
```
```
HOW OIDC WORKS HERE:
  Step 1: GitHub generates a JWT containing:
    {
      "sub": "repo:company/payment-service:ref:refs/heads/main",
      "aud": "sts.amazonaws.com",
      "iss": "https://token.actions.githubusercontent.com"
    }
  
  Step 2: aws-actions sends this JWT to AWS STS AssumeRoleWithWebIdentity
  
  Step 3: AWS verifies:
    a. JWT was signed by GitHub (via OIDC provider registered in IAM)
    b. "sub" matches the trust policy condition on github-actions-ecr-push role
    c. "aud" = "sts.amazonaws.com"
  
  Step 4: STS returns temporary credentials (access key + secret + session token)
    Valid for: 1 hour. Auto-refreshed by the action.
  
  Step 5: All subsequent AWS commands in this job use those credentials.
  
NO STORED SECRETS:
  No AWS_ACCESS_KEY_ID in GitHub repository secrets.
  No credentials that can be leaked, rotated, or expired.
  If GitHub is breached: attackers can't access AWS without also controlling
  the specific repo+branch specified in the IAM trust policy.

role-session-name: github-actions-${{ github.run_id }}
  The session name appears in CloudTrail logs:
  "who assumed this role?" → "github-actions-8134521"
  Can trace any AWS action back to a specific workflow run.
```

### Multi-arch Docker Build

```yaml
- name: Build and push Docker image
  uses: docker/build-push-action@v5
  with:
    platforms: linux/amd64,linux/arm64
    push: ${{ github.event_name == 'push' }}
    tags: |
      ${{ env.ECR_REGISTRY }}/${{ env.ECR_REPOSITORY }}:${{ env.IMAGE_TAG }}
      ${{ env.ECR_REGISTRY }}/${{ env.ECR_REPOSITORY }}:latest
```
```
platforms: linux/amd64,linux/arm64
  Builds TWO images in one step and stores them as a Docker manifest.
  One tag (e.g., "abc1234") → two images:
    linux/amd64 = Intel/AMD (used by x86 EKS nodes)
    linux/arm64 = ARM (used by Graviton EKS nodes)
  
  When an EKS Graviton node does docker pull payment-service:abc1234:
  Docker/containerd reads the manifest → picks linux/arm64 automatically.
  
  WITHOUT multi-arch:
  Graviton nodes pull the amd64 image → runs via QEMU emulation → 30-50% slower.
  Or: builds fail on Graviton because binary is wrong architecture.

push: ${{ github.event_name == 'push' }}
  Ternary: only push to ECR on merge to main, not on PRs.
  On PR: build runs (validates Dockerfile is not broken) but image is NOT pushed.
  On merge: image is pushed and the gitops update happens.

IMAGE_TAG = ${{ github.sha }}
  The full git commit SHA (e.g., "abc1234def5678...").
  Every image has a unique, traceable tag.
  "Which code version is running?" → tag "abc1234" → git show abc1234 → exact code.
  NEVER use :latest in production — it's mutable (can be overwritten).
  ALWAYS use the commit SHA — it's immutable.
```

### Trivy Vulnerability Scan

```yaml
- name: Run Trivy vulnerability scanner
  if: github.event_name == 'push'
  uses: aquasecurity/trivy-action@master
  with:
    image-ref: ${{ env.ECR_REGISTRY }}/${{ env.ECR_REPOSITORY }}:${{ env.IMAGE_TAG }}
    severity: 'CRITICAL'
    exit-code: '1'
```
```
exit-code: '1'
  If ANY CRITICAL vulnerability is found → pipeline FAILS.
  The image exists in ECR but the gitops update step doesn't run.
  ArgoCD never sees the new tag → old version stays deployed.
  
  WHAT TRIVY SCANS:
  OS packages (Debian packages in python:3.12-slim-bookworm):
    Known CVEs in bash, openssl, glibc, etc.
  Python packages (from requirements.txt / /opt/venv):
    Known CVEs in fastapi, uvicorn, httpx dependencies.
  
  WHY ONLY CRITICAL (not HIGH):
  HIGH vulnerabilities exist in almost every image (transient deps).
  Blocking on HIGH = pipeline never passes without constant patching.
  CRITICAL = actively exploitable, immediate risk. These MUST be fixed.
  
  WORKFLOW:
  Trivy finds CRITICAL → pipeline fails → engineer sees:
    "CVE-2024-XXXX in openssl 1.1.1 (installed by Debian)"
  Engineer updates: FROM python:3.12-slim-bookworm → python:3.12-slim-bookworm@sha256:NEWDIGEST
  Pipeline passes → deploy proceeds.
```

### GitOps Update (The Deployment Trigger)

```yaml
- name: Update image tag in gitops
  if: github.event_name == 'push'
  run: |
    sed -i "s|tag: \".*\"|tag: \"${{ env.IMAGE_TAG }}\"|" \
      gitops/app/payment-service/payment-service.yaml
    git config user.email "github-actions[bot]@users.noreply.github.com"
    git add gitops/app/payment-service/payment-service.yaml
    git diff --staged --quiet || \
      git commit -m "chore(deploy): update payment-service image to ${{ env.IMAGE_TAG }} [skip ci]"
    git push
```
```
HOW THIS TRIGGERS THE DEPLOYMENT:
  1. sed replaces:  tag: "oldsha"  →  tag: "abc1234"
  2. Git commits the change to gitops/app/payment-service/payment-service.yaml
  3. ArgoCD polls the repo every 3 minutes (or via webhook instantly)
  4. ArgoCD sees: desired image tag in Git ≠ running image tag in cluster
  5. ArgoCD applies the new Helm values → Kubernetes rolling update starts

[skip ci]  in the commit message:
  Without this: the git push triggers app-ci.yaml AGAIN (infinite loop).
  GitHub Actions: any commit message containing "[skip ci]" → skip the workflow.
  This is the standard pattern to prevent CI from triggering itself.

git diff --staged --quiet ||
  If the image tag is ALREADY "abc1234" (idempotent re-run):
  git diff shows no changes → exit 0 → the || skips the commit.
  Prevents empty commits that confuse reviewers ("why are there 20 deploy commits?").
```

---

## terraform-infra.yaml — Infrastructure Terraform Pipeline

```yaml
on:
  push:
    branches: [main]
    paths: ['terraform/**', '!terraform/dynatrace/**']
  pull_request:
    paths: ['terraform/**', '!terraform/dynatrace/**']
```
```
!terraform/dynatrace/**  (the ! means EXCLUDE):
  Changes to terraform/dynatrace/ do NOT trigger the infra pipeline.
  Only the dynatrace-specific pipeline handles those.
  Two separate IAM roles, separate state files, separate risk profiles.
```

### Plan job (on PR)

```yaml
- name: Terraform Plan
  run: terraform plan -no-color 2>&1 | tee plan.txt

- name: Post Plan to PR
  uses: actions/github-script@v7
  with:
    script: |
      const plan = fs.readFileSync('plan.txt', 'utf8');
      github.rest.issues.createComment({ body: '```\n' + plan + '\n```' });
```
```
What engineers see on the PR:
  +  aws_eks_node_group.application: instance_types = ["m7g.xlarge"] → ["m7g.2xlarge"]
  ~ terraform/modules/eks/main.tf: cluster_version = "1.29" → "1.30"
  Plan: 2 to change, 0 to add, 0 to destroy.

WHY PLAN ON PR:
  Infra changes are reviewed like code changes.
  A reviewer sees: "this will upgrade EKS from 1.29 to 1.30"
  They can ask: "did we test this in staging first?"
  They can block merge until staging confirms it works.
  
  WITHOUT plan-on-PR:
  Engineer merges code → apply runs → EKS upgrade starts in prod → surprise
  With plan-on-PR:
  Team knows what's changing BEFORE it changes.
```

### Apply job (on merge to main)

```yaml
- name: Terraform Apply
  run: terraform apply -auto-approve -no-color
```
```
-auto-approve: skips the interactive "yes" prompt.
  Required for automated CI — there's no human to type "yes".
  SAFE BECAUSE: the Plan was already reviewed on the PR.
  The apply is just executing what was already approved.
  
  If Terraform encounters a destroy of a critical resource:
  The plan would have shown "1 to destroy" → reviewer blocks the PR.
  The apply never runs unless the PR is approved.
```

---

## terraform-dynatrace.yaml — Dynatrace Terraform Pipeline

**Key difference from infra pipeline:** a completely different IAM role with minimal permissions.

```yaml
role-to-assume: arn:aws:iam::123456789012:role/github-actions-dynatrace-plan
```
```
dynatrace-plan role permissions:
  secretsmanager:GetSecretValue on production/dynatrace/* (read DT tokens)
  s3:GetObject on terraform state bucket (read state)
  NO: ec2, eks, iam, rds access
  
WHY SEPARATE ROLE:
  Dynatrace config changes 10× more often than infra changes.
  A junior engineer can add a new service to monitoring (variables.tf edit).
  They should NOT have the power to accidentally delete an EKS cluster.
  Separate role = separate blast radius.

What this pipeline creates per new service entry in variables.tf:
  - 8 dynatrace_metric_events resources
  - 4 dynatrace_alerting resources (one per tier)
  - 2 dynatrace_slo_v2 resources  
  - 1 dynatrace_http_monitor resource
  - 4 dynatrace notification resources
  Total: ~19 Dynatrace resources created from one services map entry.
```
