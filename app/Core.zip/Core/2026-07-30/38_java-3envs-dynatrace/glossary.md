# Glossary — Java 3 Environments + Dynatrace

Every term, tool, and concept from main.md. One entry per term.

---

**Dynatrace**
An observability platform that automatically monitors applications, infrastructure, and traces using AI. Why it matters: OneAgent instruments Java apps without code changes — this entire project's alerting, SLOs, and dashboards come from DT.

**OneAgent**
A Dynatrace agent deployed as a DaemonSet (one copy per EKS node) that automatically instruments every Java process on that node. Why it matters: OneAgent injects into the JVM at startup and captures HTTP metrics, DB queries, JVM heap, and traces — no annotation or SDK needed.

**DynaKube**
A Kubernetes custom resource that tells the Dynatrace Operator what to deploy (classicFullStack, logMonitoring, activeGate). Why it matters: `classicFullStack: enabled: true` is the single flag that activates full Java auto-instrumentation on every node.

**Dynatrace Operator**
A Kubernetes Operator (a program running in the cluster) that manages the DynaKube lifecycle — starts/stops OneAgent DaemonSets, manages ActiveGate, handles upgrades. Why it matters: installed via Helm chart in `gitops/<env>/monitoring/dynatrace/dynatrace-operator.yaml`.

**ActiveGate**
A Dynatrace component that runs in the cluster (not on every node) and acts as a gateway: routes metrics + traces from OneAgent to the DT SaaS tenant, and routes OpenTelemetry data from Java apps. Why it matters: without ActiveGate, DT cannot receive data from private EKS clusters.

**classicFullStack**
A DynaKube deployment mode where OneAgent runs on EVERY node via DaemonSet and hooks into ALL processes (JVMs, containers). Why it matters: the most complete monitoring mode — captures everything automatically including JVM heap, GC, HTTP requests, DB calls.

**logMonitoring**
A DynaKube setting that enables OneAgent to read container logs from `/var/log/containers/*.log` on each node and ingest them into Dynatrace Grail log analytics. Why it matters: replaces Fluent Bit — no separate log pipeline needed.

**Terraform module**
A reusable, parameterized block of Terraform resources called from multiple places with different inputs. Why it matters: `terraform/modules/dynatrace/main.tf` defines all DT resources once; `environments/dev/`, `environments/staging/`, `environments/production/` call it with different threshold values.

**Terraform module caller**
A `terraform/environments/<env>/main.tf` file that calls the module with environment-specific `services = { ... }` values. Why it matters: the module logic is identical across all 3 environments; only the threshold numbers differ.

**`services` variable (Terraform)**
A map of service configs passed into the Dynatrace module, containing all metric thresholds per service. Why it matters: single source of truth — changing a threshold means editing one value in one file, and the next `terraform apply` updates all DT metric events, SLOs, and synthetics.

**Management Zone (Dynatrace)**
A logical grouping in DT that scopes which entities each team sees and which alerts they receive. Why it matters: payment-service alerts only appear in the payments team's management zone — no cross-team noise.

**Auto-tagging (Dynatrace)**
A DT rule that automatically assigns tags (like `team:payments`, `environment:production`) to entities based on their Kubernetes labels. Why it matters: namespace labels `team=payments` → auto-tag → management zone rule matches → payment-service included in payments zone.

**Alerting profile**
A DT configuration that defines which problem types (AVAILABILITY, ERROR, SLOWDOWN, RESOURCE_CONTENTION) to alert on, with what delay, and scoped to which management zone. Why it matters: 4 tiers (critical/high/warning/info) with different delays prevent alert fatigue from transient issues.

**4-tier alerting (critical/high/warning/info)**
The alert architecture: CRITICAL (0 min delay, prod only) → AVAILABILITY → PagerDuty call; HIGH (2 min) → ERROR → PagerDuty push; WARNING (5 min) → SLOWDOWN → Slack; INFO (15 min) → RESOURCE_CONTENTION → Slack. Why it matters: engineers are only woken up for genuine production availability issues.

**Alert delay**
How many minutes DT waits after detecting a problem before sending a notification. Why it matters: a 2-minute delay on ERROR alerts filters out transient error spikes during rolling deploys that would otherwise cause false pages.

**Metric event (Dynatrace)**
A DT resource that watches a specific metric and fires a problem (of a specified type) when the metric crosses a threshold. Why it matters: this project creates 8 metric events per service covering all important observability signals.

**The 4 Golden Signals**
Google SRE's framework for what to monitor: (1) Traffic — request rate; (2) Errors — error rate; (3) Latency — response time; (4) Saturation — resource usage. Why it matters: this project implements all 4 plus 4 additional Java-specific signals (memory, JVM heap, pod restarts, network errors).

**Traffic drop signal**
A metric event that fires when requests per minute falls BELOW a minimum threshold. Why it matters: the MOST important signal — if DNS fails or ALB breaks, traffic = 0, and all other signals (error rate, latency) show green because there's nothing to measure. `alert_on_no_data = true` catches total metric silence.

**`alert_on_no_data = true`**
A Dynatrace metric event setting that fires the alert even when DT receives zero data points (not just when the metric crosses a threshold). Why it matters: if a service crashes so hard it stops sending any metrics, this flag still triggers the alert.

**`alert_condition = "BELOW"`**
The only metric event that fires when a value drops below a threshold (traffic drop). All other 7 signals fire when values go above their thresholds. Why it matters: unique to the traffic drop signal — not used for any other metric.

**SLO (Service Level Objective)**
A measurable reliability target: "99.9% of requests succeed" or "99.5% of requests respond within 300ms." Why it matters: DT SLOs track error budget and fire burn rate alerts before the SLO is breached.

**Error budget**
The amount of downtime/errors allowed before an SLO is breached. For a 99.9% monthly SLO: 43 minutes of downtime allowed per month. Why it matters: burn rate alerts fire when you're consuming error budget too fast, giving time to fix before the SLO window closes.

**Burn rate alert**
Fires when you're consuming error budget at a rate that will exhaust it before the SLO window ends. `fast_burn: 14.4×` = budget would be gone in 2 days if maintained. `slow_burn: 3×` = 10 days. Why it matters: proactive alerting — you fix before the SLO is actually breached.

**HTTP Synthetic monitor**
A Dynatrace monitor that sends real HTTP requests from global locations on a schedule and alerts if the response fails validation. Why it matters: checks the service from OUTSIDE the cluster (Tokyo + Singapore), catches DNS, ALB, and TLS issues that internal monitoring misses.

**Synthetic location**
A geographic location from which Dynatrace sends synthetic HTTP checks (e.g., `GEOLOCATION-6F55B7E4B5E7A52F` = Tokyo). Why it matters: checks from Tokyo AND Singapore distinguish regional outages from global ones.

**Global outage (synthetic)**
ALL synthetic locations fail simultaneously. Why it matters: indicates a real service outage (not a regional network issue) → more urgent alert.

**Local outage (synthetic)**
ONE synthetic location fails. Why it matters: may indicate a regional network/DNS issue, not a full service outage. `local_consecutive_outage_count_threshold: 3` requires 3 consecutive failures to avoid false alerts from transient network blips.

**Spring Boot Actuator**
A Spring Boot module that auto-exposes health endpoints: `/actuator/health/liveness`, `/actuator/health/readiness`. Why it matters: Kubernetes probes and DT synthetic monitors use these paths — NOT custom `/health` paths.

**`"status":"UP"` (Spring Actuator)**
The response body from `/actuator/health` when all health indicators pass. Why it matters: DT synthetic validates this pattern in the body — a 200 response with `{"status":"DOWN"}` still fails the synthetic check.

**OpenTelemetry (OTEL)**
An open standard for distributed tracing and metrics. Java Spring Boot supports it via the OpenTelemetry Java agent. Why it matters: `OTEL_EXPORTER_OTLP_ENDPOINT` sends traces to DT ActiveGate — enables cross-service distributed traces (order → payment → database) in DT.

**`OTEL_SERVICE_NAME`**
An environment variable that tells the OTEL agent which service name to report traces under. Why it matters: DT uses this to identify the service in distributed traces and link spans to the correct service entity.

**JVMTI (Java Virtual Machine Tool Interface)**
The Java API that allows external agents (like OneAgent) to hook into a running JVM. Why it matters: OneAgent uses JVMTI to auto-instrument Java code without byte-code modification in the application JAR.

**JVM heap utilization**
The percentage of the maximum heap (`-Xmx`) currently in use by Java objects. Why it matters: `builtin:process.memory.jvm.heapUtilization` is the DT metric that tracks this — alerting at 70% (production) catches GC pressure before it affects latency.

**G1GC (Garbage-First Garbage Collector)**
The default JVM garbage collector since Java 9. Runs in incremental pauses to keep max pause times bounded. Why it matters: at 70%+ heap utilization, G1GC starts running more frequent minor GCs → p99 latency increases. Alert at 70% catches this early.

**`-Xmx` / `-Xms`**
JVM flags for maximum and initial heap size. `Xmx=1024m` = max 1GB heap. Why it matters: determines the denominator for JVM heap threshold calculations (70% of 1GB = 700MB alert threshold).

**`-XX:+UseContainerSupport`**
JVM flag that makes the JVM read its memory limit from the container cgroup, not the host node's memory. Why it matters: without this, a JVM in a 1GB container sees the node's 32GB RAM and allocates 8GB heap → immediate OOM kill.

**PagerDuty**
An on-call alerting platform that routes notifications to the correct engineer via phone call, SMS, or push notification. Why it matters: TIER 1 CRITICAL alerts → PagerDuty phone call to wake the oncall engineer immediately.

**Slack notification (DT)**
A Dynatrace webhook that posts alert messages to a Slack channel. Why it matters: WARNING and INFO tier alerts go to Slack (not PagerDuty) — engineers review them during business hours, not at 3am.

**`dynatrace_pagerduty_notification`**
Terraform resource that creates a DT notification rule sending to PagerDuty. Why it matters: wired to the `critical` or `high` alerting profile → fires only for the right severity tier.

**`dynatrace_slack_notification`**
Terraform resource that creates a DT notification rule sending to a Slack webhook URL. Why it matters: separate resources for warning (per-team `#alerts-<team>` channel) and info (shared `#monitoring` channel).

**ArgoCD**
A GitOps tool that watches a Git repository and keeps a Kubernetes cluster synchronized with it. Why it matters: after one `kubectl apply` of the root-app, ArgoCD manages all 3 Java services and all infrastructure components automatically.

**Sync wave (`argocd.argoproj.io/sync-wave`)**
An ArgoCD annotation that controls deployment order. Lower numbers deploy first. Why it matters: namespaces (`-1`) → ESO (`2`) → DynaKube (`3`) → Java services (`8`). If DynaKube deployed before namespaces, the dynatrace namespace wouldn't exist → DynaKube fails.

**Root-app (App of Apps)**
A single ArgoCD Application pointing at the entire `gitops/<env>/` folder. Applied once manually; ArgoCD discovers and manages all child Applications recursively. Why it matters: after `kubectl apply -f root-app-dev.yaml`, you never need to manually apply any other YAML.

**`recurse: true` (ArgoCD)**
Tells ArgoCD to scan all subdirectories of the `path` for Application YAMLs. Why it matters: without this, only the top-level files are discovered — all the nested `app/payment-service/` etc. would be ignored.

**`prune: true` (ArgoCD)**
Deletes cluster resources when the corresponding YAML file is removed from Git. Why it matters: prevents ghost resources — if you remove notification-service from the repo, ArgoCD deletes it from the cluster.

**`selfHeal: true` (ArgoCD)**
Reverts manual `kubectl edit` changes within ~3 minutes. Why it matters: all changes must go through Git. Manual edits are overwritten by ArgoCD, enforcing GitOps discipline.

**`ignoreDifferences` (ArgoCD)**
Tells ArgoCD to ignore specific fields when comparing desired vs actual state. Why it matters: HPA changes `spec.replicas` dynamically. Without this setting, ArgoCD immediately reverts HPA scaling decisions — service can't scale under load.

**ExternalSecret (ESO)**
A Kubernetes custom resource that tells ESO to pull a value from AWS Secrets Manager and create a Kubernetes Secret with it. Why it matters: DynaKube API tokens are stored in Secrets Manager (not in Git), pulled into a K8s Secret named `dynakube` at deploy time.

**ClusterSecretStore**
An ESO resource that defines HOW to connect to a secret provider (AWS Secrets Manager in this case) for the whole cluster. Why it matters: once created, all ExternalSecrets in any namespace can reference it to pull secrets.

**IRSA (IAM Roles for Service Accounts)**
AWS feature that lets a Kubernetes ServiceAccount assume an IAM role using OIDC tokens, without static credentials. Why it matters: ESO's ServiceAccount has an IRSA annotation → can read Secrets Manager → no AWS access keys stored anywhere.

**ECR (Elastic Container Registry)**
AWS managed Docker image registry. Each AWS account has its own ECR. Why it matters: dev images in `123456789010.dkr.ecr...`, staging in `123456789011.dkr.ecr...`, production in `123456789012.dkr.ecr...` — images must be explicitly promoted, no accidental cross-env deploys.

**Helm chart (3 values files)**
A Helm chart with `values.yaml` (production defaults), `values-dev.yaml` (dev overrides), `values-staging.yaml` (staging overrides). Why it matters: avoids duplicating full YAML files per environment — only the fields that differ appear in the override files.

**Alert fatigue**
When too many alerts fire for non-critical or expected events, engineers learn to ignore all alerts — including real ones. Why it matters: the entire per-environment threshold strategy exists to prevent this.

**Distributed trace**
A record of a request as it flows through multiple services, showing timing for each hop. Why it matters: when an order fails because payment failed, a distributed trace shows the full chain `order → payment → DB` and exactly where time was spent.

**`terraform apply -auto-approve`**
Applies Terraform changes without an interactive confirmation prompt. Why it matters: used in CI pipelines where there's no interactive terminal. Manual approval is handled by the GitHub Environment gate, not the terraform command.

**`Timeout=900` (ArgoCD sync option)**
Tells ArgoCD to wait up to 900 seconds (15 min) for all resources to become healthy after a sync. Why it matters: Java Spring Boot cold starts take 1-10 minutes. Without this, ArgoCD marks the sync as "Degraded" before the JVM even finishes starting.

**`jdwp` (Java Debug Wire Protocol)**
Enables remote Java debugging on a port (default 5005). Why it matters: dev pods have `-agentlib:jdwp=...address=*:5005` → engineers can `kubectl port-forward` and attach IntelliJ debugger. `suspend=n` is critical — without it the pod waits for a debugger before starting.

**`ScheduleAnyway` vs `DoNotSchedule` (topology spread)**
`DoNotSchedule` = hard: pod stays Pending if spread constraints can't be met. `ScheduleAnyway` = soft: tries to spread, co-locates if no choice. Why it matters: production uses `DoNotSchedule` (guarantees 1 pod per AZ); dev uses `ScheduleAnyway` (works on 1-node dev clusters).

**Deployment history (GitHub Environment)**
A log in GitHub's UI showing every deployment, who triggered it, when, and which commit was used. Why it matters: "who deployed what to production and when?" answered without reading git log.
