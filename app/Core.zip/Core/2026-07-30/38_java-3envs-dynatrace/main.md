# Java 3 Environments + Dynatrace — Full Observability Project

> Expands the single-env Python reference (16_eks-dynatrace-gitops-revised) to **3 Java Spring Boot services × 3 AWS environments (dev/staging/production)** with a reusable Terraform Dynatrace module.
>
> Key idea: Dynatrace thresholds are **different per environment** — same module, different `services = { ... }` map per caller.

---

## Decision Tree — How Everything Connects

```
                    ┌─────────────────────────────────────────┐
                    │  Terraform module/dynatrace/main.tf      │
                    │  (one module, called 3 times)           │
                    └──────────┬──────────────────────────────┘
                               │ called by
          ┌────────────────────┼──────────────────────┐
          ▼                    ▼                       ▼
   environments/dev/    environments/staging/   environments/production/
   main.tf               main.tf                 main.tf
   (relaxed thresholds)  (medium thresholds)     (strict thresholds)
          │                    │                       │
          │ each creates in Dynatrace:                 │
          └────────────────────┴──────────────────────┘
             ↓ per service (payment / order / notification):
             - 1 Management Zone   (scopes alerts to the right team)
             - 4 Alerting Profiles (critical/high/warning/info)
             - 8 Metric Events     (8 signals: traffic/error/latency/cpu/memory/jvm/restart/network)
             - 2 SLOs              (availability + latency)
             - 1 HTTP Synthetic    (health check every 5 min from Tokyo + Singapore)
             - 4 Notifications     (PagerDuty critical+high, Slack warning+info)

Q: Where do Dynatrace thresholds come from?
   → terraform/environments/<env>/main.tf → services = { ... } map

Q: What is the same for all environments?
   → terraform/modules/dynatrace/main.tf (the module logic never changes)

Q: How does Dynatrace know which service is which?
   → Kubernetes namespace labels (team=, environment=)
   → OneAgent reads them → auto-tagging rules → management zones filter by tags

Q: What deploys the Java apps?
   → ArgoCD reads gitops/<env>/app/<service>/  → applies Helm chart from charts/<service>/

Q: How does the Java app send traces to Dynatrace?
   → OTEL_EXPORTER_OTLP_ENDPOINT env var → Dynatrace ActiveGate → DT tenant
```

---

## E2E Flow — Dev to Production

```
1. Terraform infra apply (once per environment):
   terraform/environments/<env>/main.tf
   → Creates EKS cluster, VPC, IRSA roles, Secrets Manager entries
   → Triggered by: terraform-infra.yaml CI on push to terraform/**

2. ArgoCD bootstrap (once per environment):
   kubectl apply -f gitops/<env>/bootstrap/root-app-<env>.yaml
   → ArgoCD discovers and manages ALL resources under gitops/<env>/ recursively

3. ArgoCD sync waves (automated, in order):
   wave -1: namespaces created (payment-ns, order-ns, notification-ns, dynatrace, external-secrets)
   wave  2: ESO + ClusterSecretStore (can now pull secrets from AWS Secrets Manager)
   wave  3: Dynatrace Operator + ExternalSecret (dynakube tokens) + DynaKube
            → OneAgent DaemonSet starts on every node
            → OpenTelemetry traces from Java apps now routed to DT tenant
   wave  8: 3 Java services deployed (payment, order, notification)
            → Each pod gets team=X + environment=Y labels → Dynatrace auto-tags them

4. Terraform Dynatrace apply (per environment, independently):
   terraform/environments/<env>/main.tf → module "dynatrace" { ... }
   → Creates: management zones, alerting profiles, metric events, SLOs, synthetics, notifications
   → Triggered by: terraform-dynatrace-<env>.yaml CI on push to terraform/environments/<env>/**

5. Developer pushes Java code:
   services/<service>/src/...
   → GitHub Actions: test → build → dev deploy → smoke test → staging promote → k6 → prod (manual approval)
   → Each step: image tag updated in gitops/<env>/app/<service>/ → ArgoCD detects → rolling update
   → Dynatrace OneAgent auto-instruments the new Java pods (no code change needed)

   NOTE: This repo ships Dockerfile placeholders only under services/ — not real Spring Boot src/.
   Step 5 is the CI happy-path story. Bring your own Java repo/image, or see services/README.md.
```

---

## File Tree

```
38_java-3envs-dynatrace/
│
├── .github/workflows/
│   ├── terraform-dynatrace-dev.yaml        ← DT Terraform CI for dev (plan on PR, apply on push)
│   ├── terraform-dynatrace-staging.yaml    ← same for staging
│   └── terraform-dynatrace-production.yaml ← same + manual approval gate
│
├── terraform/
│   ├── modules/
│   │   └── dynatrace/
│   │       ├── main.tf       ← THE MODULE: all DT resources (management zones, alerts, SLOs, synthetics)
│   │       └── variables.tf  ← all thresholds as variables (called with different values per env)
│   │
│   └── environments/
│       ├── dev/main.tf         ← calls module with RELAXED thresholds (no traffic alert, 2000ms latency)
│       ├── staging/main.tf     ← calls module with MEDIUM thresholds (800ms latency, k6-aware)
│       └── production/main.tf  ← calls module with STRICT thresholds (300ms latency, 0.1% errors)
│
├── gitops/
│   ├── dev/
│   │   ├── bootstrap/root-app-dev.yaml           ← apply once → ArgoCD manages gitops/dev/
│   │   ├── namespaces/namespaces.yaml             ← wave -1: 5 namespaces with team/env labels
│   │   ├── secrets/cluster-secret-store.yaml      ← wave 2: ESO + ClusterSecretStore
│   │   ├── monitoring/dynatrace/dynatrace-operator.yaml  ← wave 3: DT Operator + DynaKube
│   │   └── app/
│   │       ├── payment-service/payment-service.yaml
│   │       ├── order-service/order-service.yaml
│   │       └── notification-service/notification-service.yaml
│   │
│   ├── staging/ (same structure, staging account)
│   └── production/ (same structure, production account)
│
├── charts/
│   ├── payment-service/
│   │   ├── values.yaml          ← PRODUCTION defaults (replicaCount: 3, Xmx: 1024m, WARN logs)
│   │   ├── values-dev.yaml      ← DEV overrides (1 replica, Xmx: 256m, DEBUG, jdwp debug port)
│   │   └── values-staging.yaml  ← STAGING overrides (2 replicas, Xmx: 512m, INFO logs)
│   ├── order-service/           (same 3-file structure)
│   └── notification-service/    (same 3-file structure)
│
└── services/
    ├── payment-service/Dockerfile
    ├── order-service/Dockerfile
    └── notification-service/Dockerfile
```

---

## Part 1 — Terraform Dynatrace Module (The Core)

### Why a module?

Without a module — one set of DT Terraform files per environment:
```
terraform/dynatrace-dev/     ← 7 .tf files
terraform/dynatrace-staging/ ← 7 .tf files (copy of dev)
terraform/dynatrace-prod/    ← 7 .tf files (copy of staging)
```
Problem: A bug fix in metric-events.tf must be applied to 3 copies. They diverge.

With a module — one module, three callers:
```
terraform/modules/dynatrace/main.tf   ← ONE copy of the logic
terraform/environments/dev/main.tf    ← calls module with dev thresholds
terraform/environments/staging/main.tf  ← calls same module with staging thresholds
terraform/environments/prod/main.tf   ← calls same module with prod thresholds
```
Fix the module once → all 3 environments get the fix on their next `terraform apply`.

### The services map — single source of truth

All per-environment threshold values live in one Terraform variable called `services`:

```hcl
# In environments/production/main.tf
services = {
  "payment-service" = {
    traffic_min_rps        = 10     # 10 req/min expected even at 3am
    error_rate_alert       = 0.1    # 0.1%: any payment error is serious
    latency_p99_ms         = 300    # 300ms P99 SLO
    jvm_heap_pct           = 70     # G1GC pressure starts above this
    pod_restart_threshold  = 2      # any restart = alert
    ...
  }
}

# In environments/dev/main.tf — SAME module call, DIFFERENT values
services = {
  "payment-service" = {
    traffic_min_rps        = 0      # dev: no real traffic → disable
    error_rate_alert       = 10.0   # dev: 10% = only alert on catastrophic errors
    latency_p99_ms         = 2000   # dev: JIT not warmed on t3.medium
    jvm_heap_pct           = 85     # dev: small Xmx=256m fills fast
    pod_restart_threshold  = 5      # dev: pods restart during development
    ...
  }
}
```

### The 8 Metric Event signals

All 3 Java services use all 8 signals (all are JVM services, so the `is_jvm_service` conditional from the reference project is removed):

| Signal | Metric Key | Alert Type | Fires |
|--------|-----------|------------|-------|
| 1. Traffic | `builtin:service.requestCount.server` | ERROR_EVENT | BELOW threshold (silent outage) |
| 2. Error rate | `builtin:service.errors.server.rate` | ERROR_EVENT | ABOVE threshold |
| 3. Latency P99 | `builtin:service.response.time:percentile(99)` | PERFORMANCE_EVENT | ABOVE threshold |
| 4. CPU | `builtin:process.cpu.usage` | RESOURCE_CONTENTION_EVENT | ABOVE threshold |
| 5. Memory | `builtin:process.memory.usage` | RESOURCE_CONTENTION_EVENT | ABOVE threshold |
| 6. JVM Heap | `builtin:process.memory.jvm.heapUtilization` | RESOURCE_CONTENTION_EVENT | ABOVE threshold |
| 7. Pod restarts | `builtin:kubernetes.workload.pods.restarts` | ERROR_EVENT | ABOVE threshold |
| 8. Network errors | `builtin:host.net.errorRate` | RESOURCE_CONTENTION_EVENT | ABOVE threshold |

**Why traffic drop is the most important signal:**
```
Error rate = 0% when traffic = 0.
If DNS fails, ALB misconfigures, or a deploy breaks ingress:
  → no requests reach the service
  → no 5xx errors (there's nothing to fail)
  → latency looks fine (no requests to measure)
  → ALL other signals look green

Only the traffic drop signal catches this.
alert_on_no_data = true: fires even when DT receives ZERO data points.
This catches: service so broken it can't send ANY metrics at all.
```

### Alerting tiers (who gets woken up when)

```
TIER 1 CRITICAL  (AVAILABILITY, 0 min delay)  → PagerDuty phone call     → prod only
TIER 2 HIGH      (ERROR, 2 min delay)         → PagerDuty push notify    → prod + staging
TIER 3 WARNING   (SLOWDOWN, 5 min delay)      → Slack #alerts-<team>     → all envs
TIER 4 INFO      (RESOURCE_CONTENTION, 15min) → Slack #monitoring        → all envs

Why delays?
  0 min (critical): availability loss is never transient. Alert immediately.
  2 min (high): filters out brief error spikes during rolling deploys.
  5 min (warning): confirms sustained latency degradation, not a brief spike.
  15 min (info): CPU/heap trends need time to confirm they're real, not bursts.

Why prod only for CRITICAL:
  AVAILABILITY tier in DT = complete service down.
  Dev services are down regularly (no users, intentional). Waking oncall = noise.
  Production down = real money impact → phone call is correct.
```

---

## Part 2 — Per-Environment Threshold Rationale

### Why thresholds must differ

If you use production thresholds everywhere:

```
Dev latency alert: 300ms
Dev JVM on t3.medium, JIT not warmed:
  First request after cold start: 2000ms → alert fires
  Second request: 800ms → alert fires
  After 60s: steady state 150ms → alert clears

Result: alert fires and clears every time a dev engineer restarts a pod.
Engineers learn to IGNORE the alert → miss real problems.
Alert fatigue kills observability.
```

### Threshold comparison table

| Signal | Dev | Staging | Production | Reason for difference |
|--------|-----|---------|------------|----------------------|
| Traffic min | 0 (off) | 2 rps | 10 rps | Dev has no real users |
| Error rate | 10% | 1% | 0.1% | Stricter as env approaches users |
| Latency P99 | 2000ms | 800ms | 300ms | JIT warmup in dev/staging; prod is warmed |
| CPU | 90% | 85% | 70% | Prod needs CPU headroom for GC |
| Memory | 85% | 80% | 75% | Less tolerance near OOM in prod |
| JVM Heap | 85% | 78% | 70% | Xmx is smaller in dev/staging |
| Pod restarts | 5 | 3 | 2 | Dev pods restart more during development |
| SLO target | 90% | 95% | 99.9% | Only prod has user-facing SLA |

### Java-specific JVM heap threshold explanation

```
Dev:     Xmx=256m. Spring Boot idle fills ~180MB = 70% at idle.
         If threshold = 70%: alert fires before you write a single line of code.
         85%: only fires when heap is truly near exhaustion.

Staging: Xmx=512m. k6 load test fills heap to ~78%.
         78% threshold: fires if heap grows beyond normal load test peak.
         Signals: possible memory leak or config regression.

Prod:    Xmx=1024m. Normal load: 30-50% heap. Heavy load: up to 65%.
         70%: alert before GC starts affecting latency.
         G1GC starts showing longer pauses above 70% → act before users notice.
```

---

## Part 3 — Dynatrace OneAgent Integration (How DT Sees Java)

### How OneAgent instruments Java — no code change needed

```
DynaKube (gitops/<env>/monitoring/dynatrace/dynatrace-operator.yaml):
  classicFullStack:
    enabled: true

This deploys OneAgent as a DaemonSet on EVERY EKS node.
OneAgent on each node:
  1. Reads /var/lib/docker/containers/*.log → sends to DT log analytics
  2. Hooks into every JVM process on the node via JVMTI (Java agent injection)
  3. Auto-instruments: HTTP requests, DB queries, JVM heap, thread counts, GC
  4. Sends all metrics + traces to Dynatrace ActiveGate

Java developer writes:
  @RestController
  @GetMapping("/api/v1/payments")
  public Payment getPayment(...) { ... }

DT automatically captures:
  - HTTP request count, duration, error rate for /api/v1/payments
  - Database query time and count called by this method
  - JVM heap, GC pause time during this request
  - Thread pool utilization
  - Full distributed trace if the request came from another DT-instrumented service

Zero annotation. Zero SDK. Zero code change.
```

### How namespace labels connect to management zones

```
# gitops/<env>/namespaces/namespaces.yaml:
namespaces:
  - name: payment-ns
    labels: { team: payments, environment: production }

# OneAgent reads these labels from each pod's namespace
# DT auto-tagging rule (configured in DT UI or via API):
#   "if Kubernetes namespace label team=payments → tag entity team:payments"
#   "if Kubernetes namespace label environment=production → tag entity environment:production"

# Terraform management zone:
resource "dynatrace_management_zone_v2" "team" {
  rules { rule {
    attribute_conditions { attribute = "SERVICE_TAGS" tag_value = "team:${each.value}" }
    attribute_conditions { attribute = "SERVICE_TAGS" tag_value = "environment:${var.environment}" }
  }}
}

Flow: pod starts → OneAgent tags it with namespace labels → management zone includes it
→ alerting profiles scoped to this zone → notifications go to the right team
```

### OpenTelemetry for distributed traces (cross-service)

```yaml
# In values.yaml for all services:
env:
  - name: OTEL_EXPORTER_OTLP_ENDPOINT
    value: "http://dynatrace-activegate.dynatrace.svc:4318"
  - name: OTEL_SERVICE_NAME
    value: "payment-service"
```

```
When order-service calls payment-service:
  1. order-service OTEL SDK creates a trace span, injects trace ID into HTTP headers
  2. payment-service OTEL SDK reads trace ID from headers → creates child span
  3. Both spans sent to Dynatrace ActiveGate → stitched into one distributed trace in DT

Result in DT: one trace shows the full call chain:
  order-service [120ms]
    └── payment-service [80ms]
          └── PostgreSQL SELECT [30ms]

This works across all 3 services without any code change to the business logic.
```

### HTTP Synthetic monitors

```hcl
# terraform/modules/dynatrace/main.tf
resource "dynatrace_http_monitor" "health_check" {
  for_each  = var.services
  frequency = 5   # every 5 minutes
  locations = var.synthetic_locations  # [Tokyo, Singapore]

  script {
    request {
      url = each.value.health_check_url   # e.g., https://payment.company.com/actuator/health
      validation {
        rule { type = "httpStatusesList"; value = "2xx" }
        rule { type = "patternConstraint"; value = "\"status\":\"UP\"" }
      }
    }
  }
}
```

```
Every 5 minutes, DT sends a GET to /actuator/health from Tokyo AND Singapore.
Checks: HTTP status 2xx AND body contains "status":"UP" (Spring Actuator format).

Why validate the body, not just HTTP 200?
  A misconfigured Spring app can return 200 with body {"status":"DOWN"}.
  200 = HTTP layer is fine. "status":"UP" = application layer is healthy.
  Both are needed to confirm the service is truly healthy.

Why Tokyo + Singapore?
  If only Tokyo fails → local_outage alert (regional DNS/network issue).
  If both fail → global_outage alert (service is really down).
  Distinguishes regional blip from real outage → fewer false pages.
```

---

## Part 4 — CI/CD Pipelines

### Three separate Terraform DT pipelines (one per env)

```
terraform-dynatrace-dev.yaml:
  paths: ['terraform/environments/dev/**', 'terraform/modules/dynatrace/**']
  → triggers when EITHER dev config OR the shared module changes

terraform-dynatrace-staging.yaml: same pattern for staging
terraform-dynatrace-production.yaml: same + environment: production (manual approval)
```

**Why trigger on module changes too?**
```
If only paths: ['terraform/environments/dev/**']:
  You fix a bug in terraform/modules/dynatrace/main.tf.
  Only the prod CI triggers (if you changed prod config too), but dev and staging don't.
  Result: dev and staging run old buggy module logic until you touch their config files.

With both paths listed:
  Changing the module → all 3 env pipelines trigger → all 3 environments get the fix.
```

### Plan on PR, Apply on merge

```
on PR (pull_request event):
  terraform plan → output posted as PR comment
  Reviewer sees: "+ 3 metric events to add, ~ 1 SLO to change, - 0 to destroy"
  No changes applied until approved and merged.

on merge (push event):
  terraform apply -auto-approve
  Changes applied immediately after merge.
  production: environment: production gate → apply pauses for human approval.
```

---

## Part 5 — Bootstrap Commands

```bash
# ── ONE-TIME BOOTSTRAP (per environment) ──────────────────────────────────

# 1. Terraform infra (EKS + VPC + IRSA)
cd terraform/environments/dev
terraform init
terraform apply

# 2. Connect kubectl to the new cluster
aws eks update-kubeconfig --name company-dev --region ap-northeast-1

# 3. Install ArgoCD
kubectl create namespace argocd
kubectl apply -n argocd \
  -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
kubectl wait --for=condition=available deployment/argocd-server -n argocd --timeout=300s

# 4. Bootstrap root-app → ArgoCD manages everything else
kubectl apply -f gitops/dev/bootstrap/root-app-dev.yaml

# Wait ~5 minutes. ArgoCD syncs in wave order:
#   wave -1: namespaces
#   wave  2: ESO + ClusterSecretStore
#   wave  3: Dynatrace Operator + DynaKube → OneAgent starts
#   wave  8: 3 Java services

# 5. Terraform Dynatrace (creates DT observability config)
cd terraform/environments/dev
terraform apply
# Creates: management zones, alerting profiles, metric events, SLOs, synthetics

# Repeat steps 1-5 for staging (company-staging, 123456789011)
# and production (company-prod, 123456789012)
```

---

## Common Mistakes

| Mistake | Symptom | Fix |
|---------|---------|-----|
| Missing namespace labels (`team=`, `environment=`) | Dynatrace auto-tagging misses the pod → wrong management zone → alerts go to wrong team | Add `labels: { team: X, environment: Y }` to namespace definition |
| DT latency metric uses ms but DT API needs µs | SLO `metric_expression` threshold is 300 but should be 300,000 (microseconds) | Multiply `latency_p99_ms` by 1000 in SLO metric expression |
| `alert_on_no_data = false` on traffic drop | Silent outage where DT stops receiving metrics → alert never fires | Always set `alert_on_no_data = true` for traffic drop signal only |
| Same DT thresholds in dev and production | Alert fatigue in dev: JIT warmup triggers 2000ms latency alert constantly → engineers ignore all alerts | Use relaxed thresholds in dev (2000ms), medium in staging (800ms), strict in prod (300ms) |
| `pdb: enabled: true` with 1 dev replica | Node drain blocked → EKS upgrades hang indefinitely | Set `pdb: enabled: false` in values-dev.yaml |
| activeGate `replicas: 1` in production | ActiveGate dies → DT loses all metrics + traces from that cluster until restart | Set `replicas: 2` + topology spread in production DynaKube |
| `suspend=n` missing from jdwp | Dev pod waits for debugger → never passes startupProbe → CrashLoopBackOff | Always add `suspend=n` to jdwp agent string |
| Module change not reflected in staging | Bug fixed in module but staging CI path doesn't include module changes | Add `terraform/modules/dynatrace/**` to staging workflow `paths:` |
