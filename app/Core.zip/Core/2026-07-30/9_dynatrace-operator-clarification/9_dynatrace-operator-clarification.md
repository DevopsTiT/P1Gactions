# Dynatrace Operator YAML — File Status Clarification

---

## The File EXISTS — Not Missing

The image shows the **description text** from `4_eks-dynatrace-gitops-project.md` that explains what `dynatrace-operator.yaml` does. That description text is documentation, not an error indicator.

The actual file **exists on disk** and is complete:

```bash
# Verify the file exists and is non-empty
ls -lh /Users/ts-shuge.kui/warp/Files/2026-07-30/4_eks-dynatrace-gitops-project/gitops/monitoring/dynatrace/
# Output: dynatrace-operator.yaml  (117 lines)
```

---

## What The File Contains (3 Resources in 1 File)

```
gitops/monitoring/dynatrace/dynatrace-operator.yaml
│
├── Application (ArgoCD)          → installs Dynatrace Operator Helm chart
├── ExternalSecret                → pulls DT tokens from Secrets Manager
└── DynaKube (Custom Resource)    → configures what the Operator deploys
```

---

## The One Real Issue: `apiUrl` Placeholder

```yaml
spec:
  apiUrl: https://PLACEHOLDER.live.dynatrace.com/api
```

This placeholder must be replaced before the platform works. The DynaKube CR cannot connect to Dynatrace without a real tenant URL.

**Three ways to fix it:**

### Option A — Replace the placeholder in Git (simplest for single cluster)

```bash
# Get your tenant URL from Dynatrace UI: Settings → Environment → Tenant ID
DT_TENANT="abc12345"

# Update the file
sed -i "s|https://PLACEHOLDER.live.dynatrace.com/api|https://${DT_TENANT}.live.dynatrace.com/api|g" \
  gitops/monitoring/dynatrace/dynatrace-operator.yaml

# Commit and push — ArgoCD picks up the change
git add gitops/monitoring/dynatrace/dynatrace-operator.yaml
git commit -m "fix: set Dynatrace tenant URL in DynaKube"
git push
```

### Option B — Read from ExternalSecret (most secure, no hardcoded URL in Git)

```bash
# 1. Store the tenant URL in Secrets Manager (already created by secrets-manager.tf)
aws secretsmanager put-secret-value \
  --secret-id production/dynatrace/tenant-url \
  --secret-string "https://abc12345.live.dynatrace.com/api"

# 2. Add a third entry to the ExternalSecret in the same YAML:
```

```yaml
# In the ExternalSecret (dynakube-tokens), add:
  data:
    - secretKey: apiToken
      remoteRef:
        key: production/dynatrace/api-token
    - secretKey: dataIngestToken
      remoteRef:
        key: production/dynatrace/paas-token
    - secretKey: apiUrl          # ← ADD THIS
      remoteRef:
        key: production/dynatrace/tenant-url

# Then in DynaKube, reference the secret:
spec:
  apiUrl: ""         # leave empty; DynaKube reads from the secret below
  tokens: dynakube   # the Secret now contains apiUrl, apiToken, dataIngestToken
```

### Option C — Inject via Kustomize overlay per cluster (best for multi-cluster)

```bash
# Create a Kustomize overlay that patches the placeholder per environment:
# gitops/monitoring/dynatrace/overlays/production/kustomization.yaml
```

```yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization
resources:
  - ../../dynatrace-operator.yaml
patches:
  - patch: |-
      - op: replace
        path: /spec/apiUrl
        value: https://abc12345.live.dynatrace.com/api
    target:
      kind: DynaKube
      name: dynakube
```

---

## Verify DynaKube Is Working After Fix

```bash
# Check the Dynatrace Operator pod is running
kubectl get pods -n dynatrace

# Check DynaKube status (should show Phase: Running)
kubectl get dynakube dynakube -n dynatrace -o yaml | grep -A 10 "status:"

# Check OneAgent DaemonSet — should have one pod per node
kubectl get daemonset -n dynatrace
kubectl get pods -n dynatrace -l app.kubernetes.io/name=oneagent

# Check ActiveGate pods (should be 2 replicas in different AZs)
kubectl get pods -n dynatrace -l app.kubernetes.io/component=activegate

# Check Dynatrace Operator logs for errors
kubectl logs -n dynatrace deployment/dynatrace-operator --tail=50 | grep -iE "error|warn|connected"

# Verify the dynakube Secret was created by ESO
kubectl get secret dynakube -n dynatrace -o jsonpath='{.data}' | jq 'keys'
# Expected: ["apiToken", "dataIngestToken"]

# In Dynatrace UI (after ~5 minutes):
# Infrastructure → Kubernetes → cluster should appear
# Infrastructure → Hosts → EKS nodes should appear
# Applications → Services → payment-service should appear (once app deploys)
```

---

## Why Three Resources in One File (Not Three Files)

The Operator, ExternalSecret, and DynaKube are deployed atomically at sync wave 3. They depend on each other:

```
Operator must be running first (registers DynaKube CRD)
    → ExternalSecret creates the "dynakube" K8s Secret
    → DynaKube reads the Secret to authenticate with DT tenant
    → Operator reads DynaKube and deploys OneAgent DaemonSet
```

Splitting into separate files would require separate sync waves and more complexity. Since all three are in the same wave and belong conceptually together, one file is the cleaner choice for this project.

The trade-off: if you want to update ONLY the DynaKube configuration (e.g., adjust resource limits), the PR diff is noisier because it touches the same file that also contains the Operator and ExternalSecret. For a larger project with frequent DynaKube tuning, splitting is worth it.
