# Dynatrace Operator YAML Clarification — Glossary

**Dynatrace Operator**
A Kubernetes controller that manages the lifecycle of Dynatrace monitoring components. Reads `DynaKube` custom resources and deploys: OneAgent DaemonSet (one pod per node), ActiveGate (data router), and other components based on configuration.

**DynaKube**
A Kubernetes Custom Resource (CRD) that tells the Dynatrace Operator what to deploy and how to configure it. Specifies: monitoring mode (`classicFullStack`), log collection settings, ActiveGate capabilities, token secret references, and tolerations.

**`classicFullStack`**
A DynaKube monitoring mode that deploys OneAgent as a DaemonSet — one pod on every node. Provides full Application Performance Monitoring (APM): HTTP traces, database calls, exception stack traces, service discovery, all without code changes.

**OneAgent**
The Dynatrace monitoring agent that runs on each Kubernetes node as part of the DaemonSet. Instruments processes automatically, captures metrics and traces, and reads container logs (when `logMonitoring: enabled`).

**`logMonitoring: enabled: true`**
A DynaKube setting that makes OneAgent read `/var/log/containers/*.log` on each node and ship logs directly to Dynatrace Grail. Replaces the need for Fluent Bit + Loki as a separate log infrastructure.

**ActiveGate**
A Dynatrace component that aggregates data from OneAgents in the cluster and forwards it to the Dynatrace SaaS tenant. Also handles: Kubernetes API monitoring, log analytics processing, and routing. Runs as a Deployment (not DaemonSet) — two replicas spread across AZs.

**`capabilities` (ActiveGate)**
The list of functions the ActiveGate performs. `routing` = forward OneAgent data to DT SaaS. `kubernetes-api-monitoring` = read K8s API for cluster health metrics. `log-analytics` = process and forward log data to DT Grail.

**`repoURL` (ArgoCD Helm source)**
The URL ArgoCD fetches the Helm chart from. Must be a proper Helm repository with a valid `index.yaml`. A raw GitHub file URL (`raw.githubusercontent.com`) is NOT a Helm repository and may fail to resolve chart versions correctly.

**Official Dynatrace Helm Repository**
`https://raw.githubusercontent.com/Dynatrace/dynatrace-operator/main/config/helm/repos/stable` — the correct URL to use as `repoURL` for the Dynatrace Operator Helm chart. This serves a proper `index.yaml` that Helm and ArgoCD can parse.

**`targetRevision`**
The Helm chart version to deploy. Always pin to a specific version (e.g., `"1.3.2"`) in production. Leaving it unpinned means ArgoCD always deploys the latest version, which can introduce breaking changes unexpectedly.

**`installCRD: true`**
A Dynatrace Operator Helm value that installs the `DynaKube` CRD as part of the Helm release. Must be `true` because the DynaKube custom resource in the same file requires the CRD schema to exist before it can be applied.

**`apiUrl` (DynaKube)**
The URL of your Dynatrace tenant API. Format: `https://<tenant-id>.live.dynatrace.com/api`. The DynaKube CR uses this to register the cluster with Dynatrace. Must NOT be a placeholder in a production deployment.

**`tokens: dynakube`**
A DynaKube field referencing the Kubernetes Secret that holds the Dynatrace API credentials (`apiToken` and `dataIngestToken`). The Secret named `dynakube` is created by the ExternalSecret resource in the same file.

**ExternalSecret (in this context)**
The External Secrets Operator resource that reads `apiToken`, `dataIngestToken`, and optionally `apiUrl` from AWS Secrets Manager and creates the `dynakube` Kubernetes Secret. The DynaKube CR consumes this Secret for authentication.

**`public.ecr.aws/dynatrace/dynatrace-operator`**
The AWS ECR Public registry URL for the Dynatrace Operator image. Preferred over Docker Hub because ECR Public has no pull rate limits — important when many nodes start simultaneously and all try to pull the operator image.

**`topologySpreadConstraints` (ActiveGate)**
A Kubernetes scheduling rule spreading the 2 ActiveGate replicas across different Availability Zones. If one AZ fails, the remaining ActiveGate replica in the other AZ continues routing OneAgent data to Dynatrace — no monitoring blackout during an AZ failure.

**`kubernetesMonitoring: enabled: true`**
Enables the Kubernetes API integration. ActiveGate reads the K8s API to monitor: pod counts, node status, deployment health, namespace activity. Populates the Dynatrace Infrastructure → Kubernetes dashboards.

**`DT Grail`**
Dynatrace's unified data storage and analytics platform for logs, metrics, and traces. When `logMonitoring: enabled: true`, container logs are stored and searchable in DT Grail — accessible via DQL (Dynatrace Query Language) in the Logs & Events view.

**Kustomize Overlay**
A Kubernetes-native way to patch YAML files for different environments without duplicating the entire file. A `kustomization.yaml` with a `patches:` section can replace specific fields (like `apiUrl`) per environment — staging gets staging tenant URL, production gets production tenant URL.

**`refreshInterval: 1h` (ExternalSecret)**
How often the External Secrets Operator re-fetches the secret from Secrets Manager. After AWS Secrets Manager rotates the Dynatrace tokens, ESO will pick up the new values within 1 hour and update the `dynakube` Kubernetes Secret automatically.
