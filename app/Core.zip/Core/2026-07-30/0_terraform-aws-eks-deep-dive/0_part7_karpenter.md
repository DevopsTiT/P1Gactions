# Part 7 — Karpenter Submodule Deep Dive: terraform-aws-eks

> **What this part covers:** The `modules/karpenter` submodule — what it creates, how Karpenter scales nodes, the NodePool/EC2NodeClass CRDs, and how it replaces Cluster Autoscaler.

---

## What Karpenter Does vs Cluster Autoscaler

```
CLUSTER AUTOSCALER (older approach):
  Works with predefined Auto Scaling Groups.
  You create node groups (m5.large, m5.xlarge) in advance.
  When pods are Pending: CA scales up the existing ASG.
  
  PROBLEM:
  You must predict which instance types you'll need.
  You pay for capacity in the wrong shape if predictions are wrong.
  Slow: 3-5 minutes to add a node.
  Idle ASGs: you might have 3 different ASGs all at minimum size.

KARPENTER (modern approach):
  No predefined node groups.
  Watches for Pending pods and provisions EXACTLY the right instance.
  
  Example: pod requests 2 CPU, 4Gi memory.
  Karpenter finds the cheapest instance that fits: maybe c6g.large.
  Provisions it directly. Pod runs in 60-90 seconds.
  
  When node is unused for >30 seconds: Karpenter terminates it.
  Node consolidation: Karpenter can replace 3 small nodes with 1 large one.
  
  RESULT:
  Better bin-packing (fewer wasted resources)
  Faster scaling (directly calls ec2:RunInstances)
  Automatic Spot diversification across 20+ instance types
  Automatic node rotation for security patches (disruption budgets honored)
```

---

## What the Karpenter Submodule Creates

```hcl
module "karpenter" {
  source  = "terraform-aws-modules/eks/aws//modules/karpenter"
  version = "~> 20.0"

  cluster_name = module.eks.cluster_name

  # IRSA for Karpenter controller
  irsa_oidc_provider_arn          = module.eks.oidc_provider_arn
  irsa_namespace_service_accounts = ["kube-system:karpenter"]
  # Karpenter controller pod → IRSA role → can call ec2:RunInstances

  # Node IAM role: all nodes Karpenter creates get this role
  create_node_iam_role = true
  node_iam_role_name   = "karpenter-node-role"
  
  node_iam_role_additional_policies = {
    # Required for SSM Session Manager (kubectl exec, port-forward)
    AmazonSSMManagedInstanceCore = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
  }

  # EKS access entry for Karpenter nodes
  # Nodes provisioned by Karpenter need to authenticate to the cluster
  enable_v1_permissions = true  # use Karpenter v1 API permissions
}
```

**What the submodule creates:**
```
aws_iam_role.karpenter_controller          ← IRSA role for Karpenter pods
aws_iam_policy.karpenter_controller        ← ec2:RunInstances, ec2:TerminateInstances, etc.
aws_iam_role.karpenter_node                ← Instance profile for Karpenter-provisioned nodes
aws_iam_instance_profile.karpenter         ← Instance profile (attaches node role to EC2)
aws_eks_access_entry.karpenter_node        ← Lets Karpenter nodes join the cluster
aws_sqs_queue.karpenter                    ← Receives Spot interruption + EC2 events
aws_cloudwatch_event_rule.karpenter_*      ← Routes EC2 events to SQS
```

---

## Installing Karpenter via Helm (after submodule)

```hcl
resource "helm_release" "karpenter" {
  namespace        = "kube-system"
  name             = "karpenter"
  repository       = "oci://public.ecr.aws/karpenter"
  chart            = "karpenter"
  version          = "1.0.0"
  create_namespace = false
  wait             = true
  atomic           = true

  values = [yamlencode({
    serviceAccount = {
      annotations = {
        "eks.amazonaws.com/role-arn" = module.karpenter.iam_role_arn
        # The IRSA role — Karpenter controller gets AWS permissions via this
      }
    }
    settings = {
      clusterName       = module.eks.cluster_name
      clusterEndpoint   = module.eks.cluster_endpoint
      interruptionQueue = module.karpenter.queue_name  # SQS queue for Spot events
    }
    controller = {
      resources = {
        requests = { cpu = "1", memory = "1Gi" }
        limits   = { cpu = "1", memory = "1Gi" }
      }
    }
  })]
  
  depends_on = [module.eks.eks_managed_node_groups]
  # Karpenter must have nodes to schedule on before it starts
}
```

---

## NodePool — Karpenter's Scaling Rules

```yaml
# nodepool.yaml — what types of nodes Karpenter can provision
apiVersion: karpenter.sh/v1
kind: NodePool
metadata:
  name: default
spec:
  template:
    metadata:
      labels:
        karpenter.sh/nodepool: default
    spec:
      nodeClassRef:
        group: karpenter.k8s.aws
        kind: EC2NodeClass
        name: default
      
      # Which instance families are allowed
      requirements:
        - key: karpenter.sh/capacity-type
          operator: In
          values: ["spot", "on-demand"]
          
        - key: kubernetes.io/arch
          operator: In
          values: ["amd64", "arm64"]  # both Intel and Graviton
          
        - key: karpenter.k8s.aws/instance-family
          operator: In
          values: ["m5", "m6i", "m6a", "m7g", "m6g", "c5", "c6i", "r5", "r6i"]
          # More families = more Spot capacity pools = better availability
          
        - key: karpenter.k8s.aws/instance-size
          operator: NotIn
          values: ["nano", "micro", "small"]
          # Minimum size: small instances have too few pod slots
          
        - key: topology.kubernetes.io/zone
          operator: In
          values: ["ap-northeast-1a", "ap-northeast-1c", "ap-northeast-1d"]
  
  # Scale down: remove nodes unused for 30 seconds
  disruption:
    consolidationPolicy: WhenEmptyOrUnderutilized
    consolidateAfter: 30s
    
    # Never interrupt pods during peak hours (optional)
    budgets:
      - nodes: "20%"            # max 20% of nodes disrupted at once
      - schedule: "0 9 * * 1-5" # during 9am-5pm weekdays: more conservative
        nodes: "5%"
  
  # Cost ceiling: stop adding nodes if this limit would be exceeded
  limits:
    cpu: "1000"       # 1000 vCPUs max across all Karpenter nodes
    memory: "2000Gi"
```

---

## EC2NodeClass — Node Configuration

```yaml
# ec2nodeclass.yaml — hardware configuration for Karpenter nodes
apiVersion: karpenter.k8s.aws/v1
kind: EC2NodeClass
metadata:
  name: default
spec:
  # Which AMI to use — Karpenter finds the latest EKS-optimized AMI
  amiSelectorTerms:
    - alias: al2023@latest  # Amazon Linux 2023, always latest patched AMI
  
  # Subnets to launch nodes into (by tag)
  subnetSelectorTerms:
    - tags:
        karpenter.sh/discovery: prod-cluster  # tag set by terraform on subnets
  
  # Security groups for nodes
  securityGroupSelectorTerms:
    - tags:
        karpenter.sh/discovery: prod-cluster  # tag set by module on node SG
  
  # IAM instance profile for nodes
  instanceProfile: karpenter-node-role
  
  # IMDSv2 enforcement
  metadataOptions:
    httpEndpoint: enabled
    httpProtocolIPv6: disabled
    httpPutResponseHopLimit: 1    # blocks containers from IMDS
    httpTokens: required          # IMDSv2 mandatory
  
  # Root volume
  blockDeviceMappings:
    - deviceName: /dev/xvda
      ebs:
        volumeSize: 50Gi
        volumeType: gp3
        iops: 3000
        throughput: 125
        encrypted: true
        deleteOnTermination: true
  
  # Additional user data (runs during node bootstrap)
  userData: |
    #!/bin/bash
    # Custom node setup (log rotation, etc.)
```

---

## How the SQS Queue Handles Spot Interruptions

```
1. Spot interruption: AWS decides to reclaim your Spot instance
2. AWS sends a 2-minute warning event to:
   - EC2 instance metadata (traditional IMDS)
   - EventBridge (for Karpenter)
   
3. EventBridge rule (created by karpenter submodule) → routes event to SQS queue

4. Karpenter controller polls SQS queue every few seconds

5. Karpenter sees: "i-0abc123 will be terminated in 2 minutes"

6. Karpenter immediately:
   a. Cordons the node (no new pods scheduled)
   b. Drains the node (moves pods to other nodes)
   c. Provisions a replacement node in another AZ or with another type
   d. Waits for the old node to be terminated by AWS

RESULT: Zero-downtime Spot interruptions
  Old approach: IMDS + node-termination-handler DaemonSet
  Karpenter approach: SQS queue, handled natively

The SQS queue also handles:
  - EC2 rebalance recommendations (proactive — before actual interruption)
  - EC2 instance unhealthy events
  - Scheduled maintenance events
```

---

## Verification Commands

```bash
# Check Karpenter controller is running
kubectl get pods -n kube-system -l app.kubernetes.io/name=karpenter
# Expected: karpenter-xxxx  1/1  Running

# Check NodePool exists and is ready
kubectl get nodepools
# NAME      NODECLASS   NODES   READY   AGE
# default   default     5       True    1d

# Check nodes provisioned by Karpenter
kubectl get nodes -l karpenter.sh/nodepool=default
# Shows nodes Karpenter created (vs node group nodes)

# Check Karpenter logs (see why nodes are/aren't being provisioned)
kubectl logs -n kube-system -l app.kubernetes.io/name=karpenter --since=10m | \
  grep -E "provisioning|launching|terminating|consolidating"

# Simulate: create a pod that needs more nodes
kubectl run test-pending \
  --image=nginx \
  --requests='cpu=2,memory=4Gi' \
  --overrides='{"spec":{"nodeSelector":{"karpenter.sh/nodepool":"default"}}}'

# Watch Karpenter respond (should add a node in ~60 seconds)
watch kubectl get nodes

# Cleanup
kubectl delete pod test-pending
```
