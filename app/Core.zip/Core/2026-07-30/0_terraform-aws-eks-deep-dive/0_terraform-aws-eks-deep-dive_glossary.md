# Glossary — terraform-aws-eks Deep Dive

Every term used across all 8 parts, explained for an SRE beginner.

---

**terraform-aws-eks**
A community Terraform module that creates an EKS cluster with all its dependencies. Instead of writing 2,000 lines of Terraform, you write ~50 lines and call this module. Maintained at github.com/terraform-aws-modules/terraform-aws-eks.

**Module (Terraform)**
A reusable package of Terraform resources. Like a function in programming — you call it with inputs (variables), it creates resources, and returns outputs you can use elsewhere. The eks module is called with `module "eks" { source = "..." }`.

**Module Version Pinning**
`version = "~> 20.0"` means: use any version from 20.0 up to (but not including) 21.0. This prevents unexpected breaking changes from a new major version. Always pin module versions in production.

**EKS (Elastic Kubernetes Service)**
AWS's managed Kubernetes service. AWS runs the control plane (API server, etcd, scheduler) for you. You provide the worker nodes. You never SSH into the control plane — AWS owns it.

**EKS Control Plane**
The brain of Kubernetes: API server (receives kubectl commands), etcd (the database of cluster state), scheduler (decides which node a pod runs on), and controller manager (reconciles desired vs actual state). AWS manages this entirely in EKS.

**Worker Node**
An EC2 instance that runs your application pods. You see these in your AWS account. The control plane schedules pods onto worker nodes. If a node fails, the control plane reschedules pods onto healthy nodes.

**Managed Node Group**
An AWS-managed Auto Scaling Group of EC2 instances for EKS. AWS handles rolling node upgrades (drain, replace, verify). You define the instance type and scaling limits. The most common compute mode.

**Self-Managed Node Group**
You create and manage the EC2 Auto Scaling Group yourself. More control (custom AMIs, bootstrap scripts) but more responsibility. Use when you need deep OS customisation.

**Fargate Profile**
Runs Kubernetes pods on AWS-managed serverless infrastructure. No EC2 instances to manage — pods run directly on AWS hardware. Pay per pod CPU/memory, not per node. Best for batch jobs or teams with zero node-management appetite.

**EKS Auto Mode**
The newest EKS compute mode (2024). AWS manages everything: node provisioning, scaling, AMI updates, security patches. You define what workloads to run; AWS figures out the infrastructure. Least operational overhead.

**cluster_version**
The Kubernetes version for the EKS cluster (e.g., "1.30"). EKS supports only 4 minor versions at a time. You MUST upgrade before AWS forces you to. Changing this variable and applying triggers a rolling upgrade.

**endpoint_public_access**
Whether the Kubernetes API server is reachable over the internet. In production: set to `false`. Engineers use VPN to reach the private endpoint. Reduces the attack surface significantly.

**endpoint_private_access**
Whether the Kubernetes API server is reachable from inside the VPC. Always `true`. Without this, worker nodes cannot talk to the control plane.

**control_plane_subnet_ids**
The subnets where AWS places the Elastic Network Interfaces (ENIs) connecting your VPC to the EKS control plane. Use "intra" subnets (no NAT, no internet route) — the control plane ENIs don't need internet access.

**cluster_encryption_config**
Tells EKS to encrypt Kubernetes Secrets in etcd using a KMS key. Without this, Secrets are stored as base64 (which is NOT encryption). The module creates a KMS key automatically if `create_kms_key = true`.

**cluster_enabled_log_types**
Which Kubernetes control plane logs to send to CloudWatch. Should always include `api`, `audit`, `authenticator`, `controllerManager`, `scheduler` in production. `audit` is the most important for security investigations.

**authentication_mode**
How IAM identities are mapped to Kubernetes permissions. `API_AND_CONFIG_MAP` supports both the new Access Entries API and the legacy aws-auth ConfigMap. Recommended for new clusters: `API`.

**enable_cluster_creator_admin_permissions**
Automatically grants the Terraform caller cluster-admin rights via an Access Entry. Set to `true` — without it, Terraform can create the cluster but cannot install add-ons (gets "Unauthorized").

**Access Entries**
The modern way to give IAM users/roles access to a Kubernetes cluster. Replaces the aws-auth ConfigMap. More reliable, IAM-native, no YAML indentation bugs. Defined in the `access_entries` variable.

**aws-auth ConfigMap**
The legacy way to grant IAM identities Kubernetes permissions. A Kubernetes ConfigMap that maps IAM roles to Kubernetes groups. Fragile — a YAML formatting mistake can lock you out of the cluster. Being replaced by Access Entries.

**eks_managed_node_group_defaults**
A map of settings applied to ALL managed node groups. Individual node groups can override specific fields. Saves you from repeating the same IMDSv2, disk encryption, and update settings on every group.

**ami_type**
Which Amazon Machine Image (operating system) EKS uses for nodes. `AL2023_x86_64_STANDARD` = Amazon Linux 2023 for Intel CPUs. `AL2023_ARM_64_STANDARD` = Amazon Linux 2023 for Graviton (ARM) — 20% cheaper.

**capacity_type**
`ON_DEMAND` = reserved capacity, predictable pricing. `SPOT` = spare AWS capacity, 60-70% cheaper, can be reclaimed with 2-minute notice. Use Spot for application nodes, On-Demand for system nodes.

**Spot Instance**
An AWS EC2 instance using spare capacity at a discounted price. AWS can reclaim it with a 2-minute warning when they need the capacity back. Karpenter and PodDisruptionBudgets make Spot interruptions seamless.

**Spot Diversification**
Using many different instance types (m5.large, m6i.large, m6a.large, etc.) so Spot availability is spread across many capacity pools. If one type is unavailable, Karpenter picks another. More instance types = more resilient scaling.

**Launch Template**
An EC2 configuration template containing: AMI, instance type, security groups, volume settings, metadata options. The eks module creates one per node group. You customise it via `metadata_options` and `block_device_mappings`.

**IMDSv2 (Instance Metadata Service v2)**
A more secure way for EC2 instances to access their own metadata (including IAM credentials). Requires a PUT request for a token before any metadata can be read. `http_tokens = "required"` enforces this.

**http_put_response_hop_limit = 1**
An IMDSv2 setting that prevents containers inside pods from reaching the EC2 Instance Metadata Service. The PUT request from a container counts as 1 hop — the TTL drops to zero and the IMDS never responds. Critical for IRSA security.

**gp3 Volume**
The current generation AWS EBS volume type. Faster than gp2, 20% cheaper, and IOPS/throughput are configurable independently of size. Always use gp3 for EKS node root volumes.

**Taint (Kubernetes)**
A marking on a node that repels pods. `CriticalAddonsOnly=true:NoSchedule` means: "do not schedule pods here unless they have a matching toleration." Used to reserve system nodes for cluster-critical components.

**Toleration (Kubernetes)**
A pod configuration that allows it to be scheduled on tainted nodes. CoreDNS has a toleration for `CriticalAddonsOnly` so it can run on system nodes alongside other cluster-critical components.

**Node Label**
A key-value pair attached to a Kubernetes node. Pods use `nodeSelector` to request nodes with specific labels. `role: system` on nodes + `nodeSelector: {role: system}` in pod spec = pod runs only on system nodes.

**EKS Add-on**
An AWS-managed Kubernetes component. AWS validates version compatibility, applies security patches, and manages upgrades. Examples: vpc-cni, coredns, kube-proxy, aws-ebs-csi-driver.

**vpc-cni (VPC Container Networking Interface)**
The network plugin that gives each Kubernetes pod its own VPC IP address. Integrates pods directly with VPC networking, security groups, and routing. Required for all EKS clusters.

**Prefix Delegation (vpc-cni)**
A setting that makes vpc-cni assign /28 IP blocks (16 IPs) to each ENI slot instead of individual IPs. Massively increases the number of pods per node. `ENABLE_PREFIX_DELEGATION = "true"`.

**CoreDNS**
The DNS server for the Kubernetes cluster. Every pod resolves service names through CoreDNS. `payment-service.payments.svc.cluster.local` → CoreDNS returns the ClusterIP. If CoreDNS is down, no inter-service communication works.

**kube-proxy**
A component that runs on every node and manages iptables rules for Kubernetes Services. When a pod calls a ClusterIP, iptables rewrites the destination to a real pod IP. Without kube-proxy, Services don't work.

**aws-ebs-csi-driver**
The CSI (Container Storage Interface) driver that creates and mounts EBS volumes for Kubernetes PersistentVolumeClaims. Required if any workload uses persistent storage (databases, Prometheus, message queues).

**PersistentVolumeClaim (PVC)**
A Kubernetes request for storage. The EBS CSI driver fulfils PVCs by creating EBS volumes and attaching them to the correct node. Without the CSI driver, PVCs stay in Pending state forever.

**aws-efs-csi-driver**
The CSI driver for Amazon EFS (Elastic File System). Unlike EBS, EFS volumes can be mounted by multiple pods simultaneously (ReadWriteMany). Used for shared file storage across multiple pods.

**OIDC Provider (IAM)**
A trusted identity provider registered in AWS IAM. The EKS module creates one OIDC provider per cluster. This tells AWS: "Trust JWT tokens signed by this EKS cluster's issuer." Required for IRSA to work.

**OIDC Issuer URL**
The URL where the EKS cluster publishes its public keys for JWT verification. Looks like: `https://oidc.eks.ap-northeast-1.amazonaws.com/id/EXAMPLE123`. Unique per cluster.

**JWT (JSON Web Token)**
A signed token that proves identity. EKS mounts JWTs into pods at `/var/run/secrets/eks.amazonaws.com/serviceaccount/token`. The token is signed by the cluster's private key. AWS STS verifies the signature using the OIDC provider's public keys.

**IRSA (IAM Roles for Service Accounts)**
The mechanism that gives individual Kubernetes pods specific AWS IAM permissions without static credentials. A pod's ServiceAccount has an annotation with an IAM role ARN. EKS automatically injects OIDC tokens, which AWS STS exchanges for temporary IAM credentials.

**ServiceAccount (Kubernetes)**
A Kubernetes identity assigned to a pod. Used by IRSA: the ServiceAccount is annotated with an IAM role ARN, and EKS mounts an OIDC JWT token into pods using that ServiceAccount. One ServiceAccount per service = least-privilege isolation.

**terraform_remote_state**
A Terraform data source that reads outputs from another Terraform state file. Used to pass values between modules: the `eks` module reads `vpc_id` from the `networking` module's state file stored in S3.

**Karpenter**
An open-source Kubernetes node autoscaler by AWS. Instead of managing fixed Auto Scaling Groups, Karpenter dynamically provisions exactly the right EC2 instance for each workload. Faster, cheaper, and more flexible than Cluster Autoscaler.

**NodePool (Karpenter)**
A Karpenter CRD (Custom Resource Definition) that defines which instance types, architectures, and capacity types Karpenter is allowed to provision. Like a policy: "use these 10 instance families, both Spot and On-Demand, in these 3 AZs."

**EC2NodeClass (Karpenter)**
A Karpenter CRD that defines the hardware configuration for nodes Karpenter creates: which AMI, which subnets, which security groups, IMDSv2 settings, root volume size. The "template" for new nodes.

**CRD (Custom Resource Definition)**
A Kubernetes extension mechanism. Lets you define new resource types (like `NodePool`, `EC2NodeClass`) beyond the built-in ones (Deployment, Service, Pod). Karpenter installs its own CRDs into the cluster via Helm.

**Node Consolidation (Karpenter)**
Karpenter's ability to replace multiple underutilised small nodes with fewer larger nodes, or terminate empty nodes. Reduces costs by eliminating wasted capacity. Controlled by `consolidationPolicy` in the NodePool.

**SQS Queue (Karpenter)**
Karpenter uses an SQS queue to receive EC2 events: Spot interruption warnings, instance health notifications, scheduled maintenance. The karpenter submodule creates this queue and the EventBridge rules to route events into it.

**Helm**
A package manager for Kubernetes. Instead of writing raw YAML, you install pre-packaged applications called "charts." Karpenter, the AWS Load Balancer Controller, and Dynatrace are all deployed via Helm charts.

**helm_release (Terraform)**
A Terraform resource that deploys a Helm chart. Equivalent to running `helm install`. Keeps Helm charts under Terraform's lifecycle management — tracked in state, updatable via `terraform apply`.

**depends_on (Terraform)**
Tells Terraform to create resource A before resource B, even if there's no direct reference between them. Used for: Helm charts that need EKS nodes to exist before installing (pods need somewhere to schedule).

**tls Provider (Terraform)**
A Terraform provider that can read TLS certificates. The eks module uses it to automatically read the OIDC issuer certificate thumbprint, which is required when creating the IAM OIDC provider.

**time Provider (Terraform)**
A Terraform provider for time-based resources. Used internally by the eks module to add sleep/wait resources between cluster creation and node group creation, ensuring the control plane is fully ready.

**CloudWatch Log Group**
Where EKS control plane logs are stored in AWS. Each cluster gets a log group: `/aws/eks/<cluster-name>/cluster`. Set `cloudwatch_log_group_retention_in_days = 90` to control cost.

**Cluster Autoscaler**
The older Kubernetes node autoscaler. Works by scaling existing Auto Scaling Groups up/down. Slower and less flexible than Karpenter. Still used in some organisations but being replaced by Karpenter.

**Bin-packing**
Packing as many pods as possible onto as few nodes as possible to minimise wasted resources. Karpenter is better at bin-packing than Cluster Autoscaler because it can choose the optimal instance size dynamically.
