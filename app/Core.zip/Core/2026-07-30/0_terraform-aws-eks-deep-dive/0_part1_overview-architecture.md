# Part 1 — Overview & Architecture: terraform-aws-eks Deep Dive

> **Source:** https://github.com/terraform-aws-modules/terraform-aws-eks
> **What this module is:** The community standard for creating EKS clusters with Terraform. Used by thousands of companies. One module call can create a complete, production-ready EKS cluster with all its dependencies.

---

## What Problem This Module Solves

```
WITHOUT the module (raw Terraform):
  You write ~2,000 lines of Terraform across 30+ files.
  You handle: cluster IAM role, node IAM role, security groups,
  launch templates, OIDC provider, access entries, add-ons,
  Fargate profiles, node groups — all from scratch.
  Miss one security setting: your cluster is insecure.

WITH the module:
  ~50 lines of Terraform in your root module.
  The module handles all the plumbing internally.
  Battle-tested defaults: IMDSv2, encryption, access entries.
  Maintained by the community — security fixes land automatically.
```

---

## High-Level Module Structure

```
terraform-aws-eks/
  ├── main.tf                          ← EKS cluster + OIDC + access entries
  ├── variables.tf                     ← All input variables (~200 variables)
  ├── outputs.tf                       ← Cluster ID, endpoint, CA cert, OIDC ARN
  ├── locals.tf                        ← Computed values used internally
  ├── node_groups.tf                   ← Orchestrates all node group submodules
  ├── access_entries.tf                ← IAM → Kubernetes RBAC mapping
  ├── addons.tf                        ← EKS managed add-ons (vpc-cni, coredns, etc.)
  │
  └── modules/
      ├── eks-managed-node-group/      ← AWS manages the node lifecycle
      │     ├── main.tf
      │     ├── variables.tf
      │     └── outputs.tf
      ├── self-managed-node-group/     ← You manage the ASG + lifecycle
      │     ├── main.tf
      │     ├── variables.tf
      │     └── outputs.tf
      ├── fargate-profile/             ← Serverless pods (no nodes)
      │     ├── main.tf
      │     ├── variables.tf
      │     └── outputs.tf
      └── karpenter/                   ← Node autoscaling setup
            ├── main.tf
            ├── variables.tf
            └── outputs.tf
```

---

## The 5 Compute Modes Supported

```
1. EKS Auto Mode (newest, 2024)
   ├── AWS manages EVERYTHING: node provisioning, scaling, upgrades, AMI rotation
   ├── You don't manage node groups at all
   ├── Best for: teams that want zero node management overhead
   └── Terraform: enable_cluster_creator_admin_permissions = true
                  compute_config = { enabled = true }

2. EKS Managed Node Groups (most common)
   ├── You define the node group config; AWS handles the rolling upgrades
   ├── AWS provisions EC2 instances into an Auto Scaling Group
   ├── Best for: most production workloads — good balance of control vs effort
   └── Terraform: eks_managed_node_groups = { ... }

3. Self-Managed Node Groups
   ├── You create and manage the EC2 Auto Scaling Group yourself
   ├── Full control: custom AMIs, custom bootstrap scripts, any instance type
   ├── Best for: teams needing deep OS-level customisation
   └── Terraform: self_managed_node_groups = { ... }

4. Fargate Profiles
   ├── Pods run on AWS-managed serverless infrastructure (no nodes visible)
   ├── Pay per pod CPU/memory, not per node
   ├── Best for: batch jobs, variable workloads, teams that want zero node ops
   └── Terraform: fargate_profiles = { ... }

5. Hybrid Nodes (newest)
   ├── Connects on-premises servers or other clouds as EKS nodes
   ├── Best for: enterprises with on-prem data centres
   └── Terraform: cluster_compute_config (with hybrid settings)
```

---

## How the Root Module Coordinates Everything

```hcl
# Your call (root module) — simplified view
module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 20.0"

  cluster_name    = "prod-cluster"
  cluster_version = "1.30"

  vpc_id     = module.vpc.vpc_id
  subnet_ids = module.vpc.private_subnets

  eks_managed_node_groups = {
    system = { instance_types = ["m5.large"], min_size = 3 }
  }
}
```

Internally, the root module:
```
1. Creates aws_eks_cluster (control plane)
2. Creates aws_iam_role for the cluster
3. Creates aws_iam_openid_connect_provider (OIDC — needed for IRSA)
4. Calls modules/eks-managed-node-group for each entry in eks_managed_node_groups
5. Creates aws_eks_access_entry for each entry in access_entries
6. Creates aws_eks_addon for each entry in cluster_addons
```

---

## Requirements

```
Terraform:     >= 1.5.7
AWS Provider:  >= 6.52.0   (major change: v20.x uses new AWS provider v6)
time provider: >= 0.9
tls provider:  >= 4.0

Why tls provider?
  The module reads the OIDC issuer certificate thumbprint automatically.
  Without tls: you'd have to manually calculate the SHA1 thumbprint.

Why time provider?
  Used for sleep resources during cluster creation to wait for
  control plane to be fully ready before creating node groups.
```

---

## The Key Design Decisions in This Module

```
1. MERGE STRATEGY for node group defaults
   You can set defaults at the root level that apply to ALL node groups.
   Each node group can override individual settings.
   
   eks_managed_node_group_defaults = {
     ami_type = "AL2023_x86_64_STANDARD"
     disk_size = 50
   }
   eks_managed_node_groups = {
     critical = { instance_types = ["m5.large"] }         # inherits defaults
     gpu      = { ami_type = "AL2023_x86_64_NVIDIA_GPU" } # overrides ami_type
   }

2. PASS-THROUGH DESIGN
   Every variable from the submodule is also a variable in the root module.
   This means you can configure deeply nested settings from your root call.
   Tradeoff: ~200 variables in variables.tf — looks overwhelming at first.

3. ACCESS ENTRIES (replaces aws-auth ConfigMap)
   Modern versions use the EKS Access Entries API instead of the
   aws-auth ConfigMap. This is more reliable and IAM-native.
   authentication_mode = "API_AND_CONFIG_MAP" supports both.

4. CLUSTER CREATOR AUTO-ADMIN
   enable_cluster_creator_admin_permissions = true
   Automatically gives the Terraform caller admin rights to the cluster.
   Without this: Terraform can create the cluster but kubectl won't work
   immediately — you'd have to manually add your role to access entries.
```
