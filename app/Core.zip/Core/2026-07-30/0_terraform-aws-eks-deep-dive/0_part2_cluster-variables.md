# Part 2 — Cluster Variables Deep Dive: terraform-aws-eks

> **What this part covers:** Every key variable for the EKS control plane — cluster name, version, networking, encryption, logging, and access control. Understanding these is the foundation before touching node groups.

---

## The Minimum Required Variables

```hcl
module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 20.0"

  # REQUIRED — the module will error without these
  cluster_name    = "prod-cluster"   # must be unique in the account/region
  cluster_version = "1.30"           # Kubernetes version

  vpc_id     = "vpc-xxxxxxxx"
  subnet_ids = ["subnet-aaa", "subnet-bbb", "subnet-ccc"]  # private subnets for nodes
}
```

---

## Control Plane Variables

### cluster_name
```hcl
variable "cluster_name" {
  type = string
}
```
```
WHY IT MATTERS:
  Used as a prefix for ALL resources created by the module.
  aws_eks_cluster.this → name = "prod-cluster"
  aws_iam_role.cluster → name = "prod-cluster-cluster-role"
  aws_security_group.cluster → name = "prod-cluster-cluster"
  
  Naming convention: "<env>-<purpose>" e.g. prod-payments, staging-platform
  
  CANNOT BE CHANGED after creation without destroying/recreating the cluster.
  Choose carefully — this is permanent.
```

### cluster_version
```hcl
variable "cluster_version" {
  type    = string
  default = null  # uses whatever AWS defaults to — don't rely on this
}
```
```
WHY IT MATTERS:
  EKS supports 4 minor versions at a time.
  Example: if current is 1.30, supported range is 1.27–1.30.
  Versions past end of support: AWS FORCES an upgrade.
  
  Upgrade path: must go one minor version at a time.
  1.27 → 1.28 → 1.29 → 1.30 (cannot skip to 1.30 from 1.27).
  
  BEST PRACTICE: pin this explicitly in variables.tf.
  variable "kubernetes_version" { default = "1.30" }
  module "eks" { cluster_version = var.kubernetes_version }
  
  Changing this value and running terraform apply triggers the
  EKS control plane upgrade (takes ~10-15 minutes).
```

### cluster_endpoint_public_access + cluster_endpoint_private_access
```hcl
variable "cluster_endpoint_public_access" {
  type    = bool
  default = true    # ← the module default is PUBLIC ACCESS ON
}

variable "cluster_endpoint_private_access" {
  type    = bool
  default = true
}

variable "cluster_endpoint_public_access_cidrs" {
  type    = list(string)
  default = ["0.0.0.0/0"]  # ← open to everyone by default
}
```
```
WHY THIS IS IMPORTANT:
  DEFAULT IS PUBLIC. This is a security risk in production.

  PRODUCTION CONFIGURATION:
    cluster_endpoint_public_access       = false
    cluster_endpoint_private_access      = true
    → kubectl only works from inside the VPC (VPN or bastion required)
  
  DEVELOPMENT CONFIGURATION:
    cluster_endpoint_public_access       = true
    cluster_endpoint_private_access      = true
    cluster_endpoint_public_access_cidrs = ["203.0.113.0/24"]  # office IP only
    → kubectl works from the office network

  NEVER do this in production:
    cluster_endpoint_public_access       = true
    cluster_endpoint_public_access_cidrs = ["0.0.0.0/0"]
    → anyone on the internet can attempt to authenticate to your API server
```

---

## Networking Variables

### subnet_ids vs control_plane_subnet_ids
```hcl
variable "subnet_ids" {
  description = "Subnets for worker nodes"
  type        = list(string)
}

variable "control_plane_subnet_ids" {
  description = "Subnets for the EKS control plane ENIs"
  type        = list(string)
  default     = []   # if empty, uses subnet_ids
}
```
```
The control plane does NOT run in your subnets.
AWS manages the control plane infrastructure in AWS-owned accounts.

control_plane_subnet_ids controls where AWS places the ENIs (network interfaces)
that connect your VPC to the control plane. These ENIs are what your nodes and
kubectl use to talk to the API server.

BEST PRACTICE:
  Use PRIVATE subnets for both subnet_ids and control_plane_subnet_ids.
  If you want high availability: subnets in at least 3 AZs.
  
  module "eks" {
    subnet_ids              = module.vpc.private_subnets  # nodes
    control_plane_subnet_ids = module.vpc.intra_subnets   # control plane ENIs (no NAT)
  }
  
  "intra" subnets = no NAT gateway, no internet route at all.
  Control plane ENIs don't need internet access → cheaper, more secure.
```

### cluster_ip_family
```hcl
variable "cluster_ip_family" {
  type    = string
  default = "ipv4"
  # Options: "ipv4" or "ipv6"
}
```
```
ipv4: standard, supported everywhere
ipv6: newer — each pod gets a real IPv6 address, solves IP exhaustion

WHY ipv6 matters for large clusters:
  IPv4: each pod needs an IP from your VPC CIDR.
  Large cluster: 500 nodes × 58 pods = 29,000 pod IPs from your /16.
  With prefix delegation: more efficient but still limited.
  
  IPv6: pods get addresses from a separate IPv6 CIDR (infinite space).
  No IP exhaustion possible. Growing trend in large organisations.
  
  CANNOT CHANGE after cluster creation without full rebuild.
```

---

## Encryption Variables

### cluster_encryption_config
```hcl
variable "create_kms_key" {
  type    = bool
  default = true  # module creates a KMS key for you
}

variable "kms_key_description" {
  type    = string
  default = "EKS Secret Encryption Key"
}

variable "cluster_encryption_config" {
  type = any
  default = {
    resources = ["secrets"]
    # Encrypts Kubernetes Secrets (passwords, tokens, certs) in etcd.
  }
}
```
```
WHY SECRETS ENCRYPTION MATTERS:
  Kubernetes Secrets stored in etcd are base64-encoded by default.
  Base64 is NOT encryption — anyone who can read etcd can decode it.
  
  With KMS encryption:
    etcd stores: AES-256 encrypted blob
    To read it: must have access to the KMS key
    KMS key is in your account with CloudTrail audit logging
    
  The module creates a KMS key automatically (create_kms_key = true).
  BEST PRACTICE: use your own key for compliance requirements.
  
  module "eks" {
    create_kms_key          = false
    cluster_encryption_config = {
      provider_key_arn = aws_kms_key.eks.arn
      resources        = ["secrets"]
    }
  }
```

---

## Logging Variables

```hcl
variable "cluster_enabled_log_types" {
  type    = list(string)
  default = []   # ← DEFAULT IS NO LOGGING — important to override
}
```
```
PRODUCTION SETTING — always set this:
  cluster_enabled_log_types = [
    "api",               # API server requests — all kubectl commands
    "audit",             # who did what to which Kubernetes resource
    "authenticator",     # IAM authentication decisions
    "controllerManager", # controller loop events (pod scheduling decisions)
    "scheduler",         # scheduling decisions (why pod went to which node)
  ]

WHY EACH TYPE:
  api:               Required for debugging API errors, rate limits
  audit:             Required for security investigations ("who deleted that pod?")
  authenticator:     Required for diagnosing access denied errors
  controllerManager: Required for debugging stuck deployments, ReplicaSet issues
  scheduler:         Required for debugging pod placement failures (Pending pods)
  
  Cost: ~$0.50/GB ingested into CloudWatch. Enable all 5 — worth it.
  Logs go to: /aws/eks/<cluster-name>/cluster log group.

cluster_cloudwatch_log_group_retention_in_days = 90
  Default is 0 = never expire (expensive over time)
  Set to 90 days for most use cases.
```

---

## Access Control Variables (Modern: Access Entries)

```hcl
variable "authentication_mode" {
  type    = string
  default = "API_AND_CONFIG_MAP"
  # Options:
  # "CONFIG_MAP"      = legacy aws-auth ConfigMap only
  # "API"             = new Access Entries API only
  # "API_AND_CONFIG_MAP" = both (transition period)
}

variable "enable_cluster_creator_admin_permissions" {
  type    = bool
  default = false  # ← if false, Terraform CANNOT use kubectl after cluster creation
}

variable "access_entries" {
  type    = any
  default = {}
  # Map of IAM principals → Kubernetes RBAC policies
}
```
```
CRITICAL: enable_cluster_creator_admin_permissions = true

  Without this:
    Terraform creates the cluster.
    Terraform tries to install add-ons or access entries.
    Error: "Unauthorized" — Terraform's IAM role has no Kubernetes rights.
    
  With this:
    The IAM role/user that ran Terraform is automatically added as
    cluster-admin. kubectl works immediately.
    The CI/CD pipeline can apply add-ons and access entries.

ACCESS ENTRIES — replacing aws-auth ConfigMap:
  Old way (aws-auth ConfigMap):
    A Kubernetes ConfigMap you had to manage manually.
    Easy to break (wrong YAML indentation = locked out of cluster).
    Terraform race conditions during apply.
  
  New way (Access Entries):
    IAM-native API. Managed by AWS. No ConfigMap to break.
    
  module "eks" {
    access_entries = {
      # Give the SRE team cluster-admin
      sre_team = {
        principal_arn = "arn:aws:iam::123456789:role/sre-admin"
        policy_associations = {
          admin = {
            policy_arn = "arn:aws:eks::aws:cluster-access-policy/AmazonEKSClusterAdminPolicy"
            access_scope = { type = "cluster" }
          }
        }
      }
      # Give a specific app role read-only access to one namespace
      payment_readonly = {
        principal_arn = "arn:aws:iam::123456789:role/payment-readonly"
        policy_associations = {
          readonly = {
            policy_arn = "arn:aws:eks::aws:cluster-access-policy/AmazonEKSViewPolicy"
            access_scope = {
              type       = "namespace"
              namespaces = ["payments"]
            }
          }
        }
      }
    }
  }
```

---

## Tags Variable

```hcl
variable "tags" {
  type    = map(string)
  default = {}
}
```
```
Applied to ALL resources created by the module.
MINIMUM PRODUCTION TAGS:

module "eks" {
  tags = {
    Environment = "production"
    Team        = "platform"
    ManagedBy   = "terraform"
    CostCenter  = "platform-infra"
  }
}

The module also passes these tags to:
  - EC2 instances in node groups
  - EBS volumes
  - Security groups
  - IAM roles
  - CloudWatch log groups
```
