# Part 5 — OIDC Provider & IRSA Deep Dive: terraform-aws-eks

> **What this part covers:** How the module creates the OIDC provider, how IRSA works end-to-end, and the exact Terraform pattern to give pods AWS permissions.

---

## What the Module Creates for OIDC

```hcl
# Inside the module (main.tf) — what happens automatically:

data "tls_certificate" "this" {
  # Fetches the OIDC issuer certificate from the EKS cluster
  url = aws_eks_cluster.this[0].identity[0].oidc[0].issuer
}

resource "aws_iam_openid_connect_provider" "oidc_provider" {
  count = var.enable_irsa ? 1 : 0  # enabled by default

  # The URL of the OIDC issuer (unique per cluster)
  url = aws_eks_cluster.this[0].identity[0].oidc[0].issuer
  # Example: https://oidc.eks.ap-northeast-1.amazonaws.com/id/EXAMPLED539D4633E53DE1B71EXAMPLE

  client_id_list  = ["sts.amazonaws.com"]
  
  thumbprint_list = [data.tls_certificate.this.certificates[0].sha1_fingerprint]
  # The module reads the cert fingerprint automatically using the tls provider.
  # Without the tls provider: you'd have to calculate this SHA1 manually.
  
  tags = var.tags
}
```

---

## IRSA: How It Works End-to-End

```
SETUP (Terraform, done once per IAM role):
  1. EKS cluster is created
  2. Module creates OIDC provider in IAM
     → "Trust tokens signed by this EKS cluster"
  3. You create an IAM role with trust policy:
     → "Only tokens from this specific ServiceAccount can assume this role"

RUNTIME (happens every time a pod starts):
  1. Pod starts with serviceAccountName: payment-api
  2. EKS control plane mounts a JWT token into the pod at:
     /var/run/secrets/eks.amazonaws.com/serviceaccount/token
  3. The AWS SDK in the pod reads this token automatically
  4. SDK calls: sts:AssumeRoleWithWebIdentity
     → sends the JWT token to STS
  5. STS verifies:
     a. The token was signed by the cluster's OIDC issuer (trust)
     b. The sub claim matches: system:serviceaccount:payments:payment-api
     c. The aud claim = "sts.amazonaws.com"
  6. STS returns temporary credentials (valid 1 hour, auto-renewed)
  7. Pod can now call AWS APIs with those credentials

NO SECRETS:
  No AWS access keys stored anywhere.
  No Kubernetes Secrets with credentials.
  Credentials are automatic, temporary, and least-privilege per pod.
```

---

## The Module's OIDC Outputs

```hcl
# Use these in your IRSA role definitions:
output "oidc_provider" {
  # The OIDC provider URL without the https:// prefix
  # Example: oidc.eks.ap-northeast-1.amazonaws.com/id/EXAMPLE123
  value = try(replace(aws_iam_openid_connect_provider.oidc_provider[0].url, "https://", ""), null)
}

output "oidc_provider_arn" {
  # Full ARN of the OIDC provider
  # Example: arn:aws:iam::123456789:oidc-provider/oidc.eks.ap-northeast-1...
  value = try(aws_iam_openid_connect_provider.oidc_provider[0].arn, null)
}
```

---

## Creating an IRSA Role (Manual Pattern)

```hcl
# File: infra/irsa/payment-api.tf

resource "aws_iam_role" "payment_api" {
  name = "eks-irsa-payment-api"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = {
        Federated = module.eks.oidc_provider_arn  # from module output
      }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          # Only this specific ServiceAccount in this namespace can assume this role
          "${module.eks.oidc_provider}:sub" = "system:serviceaccount:payments:payment-api"
          "${module.eks.oidc_provider}:aud" = "sts.amazonaws.com"
        }
      }
    }]
  })
}

# Least-privilege policy: only what payment-api actually needs
resource "aws_iam_role_policy" "payment_api" {
  name = "payment-api-policy"
  role = aws_iam_role.payment_api.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["s3:GetObject", "s3:PutObject"]
        Resource = "arn:aws:s3:::payment-uploads-prod/*"
      },
      {
        Effect   = "Allow"
        Action   = ["secretsmanager:GetSecretValue"]
        Resource = "arn:aws:secretsmanager:ap-northeast-1:*:secret:prod/payment/*"
      }
    ]
  })
}
```

---

## Creating IRSA with the Companion Module

The easier way using `terraform-aws-modules/iam`:

```hcl
module "payment_api_irsa" {
  source    = "terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks"
  version   = "~> 5.0"

  role_name = "eks-irsa-payment-api"

  oidc_providers = {
    main = {
      provider_arn               = module.eks.oidc_provider_arn
      namespace_service_accounts = ["payments:payment-api"]
      # Format: "<namespace>:<serviceaccount-name>"
    }
  }
  
  # Pre-built policy attachments for common patterns:
  attach_s3_policy         = false  # use custom policy instead
  
  # Custom policy
  role_policy_arns = {
    payment = aws_iam_policy.payment_api.arn
  }
}

resource "aws_iam_policy" "payment_api" {
  name   = "payment-api-policy"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["s3:GetObject", "s3:PutObject"]
        Resource = "arn:aws:s3:::payment-uploads-prod/*"
      }
    ]
  })
}
```

---

## Kubernetes ServiceAccount — The Missing Link

You also need a Kubernetes ServiceAccount annotated with the IAM role ARN:

```yaml
# serviceaccount.yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: payment-api
  namespace: payments
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::123456789:role/eks-irsa-payment-api
    # This annotation is what tells the pod mutating webhook
    # to inject the OIDC token volume into the pod.
```

```hcl
# Or create it via Terraform (keeps everything in one place):
resource "kubernetes_service_account" "payment_api" {
  metadata {
    name      = "payment-api"
    namespace = "payments"
    annotations = {
      "eks.amazonaws.com/role-arn" = module.payment_api_irsa.iam_role_arn
    }
  }
}
```

---

## Verification Commands

```bash
# 1. Verify the OIDC provider was created
aws iam list-open-id-connect-providers \
  --query 'OpenIDConnectProviderList[*].Arn' \
  --output table

# 2. Verify the trust policy on an IRSA role
aws iam get-role --role-name eks-irsa-payment-api \
  --query 'Role.AssumeRolePolicyDocument' \
  --output json | python3 -m json.tool

# 3. Verify from inside the pod
kubectl exec -n payments deploy/payment-api -- \
  aws sts get-caller-identity
# Expected: Arn contains "eks-irsa-payment-api"

# 4. Test least-privilege: this should fail (no SQS permissions)
kubectl exec -n payments deploy/payment-api -- \
  aws sqs list-queues 2>&1
# Expected: AccessDenied

# 5. Test least-privilege: this should succeed
kubectl exec -n payments deploy/payment-api -- \
  aws s3 ls s3://payment-uploads-prod/ 2>&1
# Expected: success
```
