# Part 8 — Complete Production Example: terraform-aws-eks

> **What this part covers:** A complete, production-ready Terraform EKS configuration using the module — with all security settings, node groups, add-ons, IRSA, and Karpenter. Copy-paste ready.

---

## File Structure

```
infra/aws/eks/
  ├── main.tf           ← EKS module call
  ├── variables.tf      ← Input variables
  ├── outputs.tf        ← Outputs used by other modules
  ├── providers.tf      ← AWS, Kubernetes, Helm providers
  ├── irsa.tf           ← All IRSA roles
  ├── karpenter.tf      ← Karpenter submodule + Helm + NodePool
  ├── addons.tf         ← cluster_addons (separate file for clarity)
  └── backend.tf        ← S3 state backend
```

---

## backend.tf

```hcl
terraform {
  required_version = ">= 1.5.7"
  
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = ">= 2.20"
    }
    helm = {
      source  = "hashicorp/helm"
      version = ">= 2.9"
    }
    tls = {
      source  = "hashicorp/tls"
      version = ">= 4.0"
    }
    time = {
      source  = "hashicorp/time"
      version = ">= 0.9"
    }
  }
  
  backend "s3" {
    bucket         = "company-tfstate-management"
    key            = "eks/terraform.tfstate"
    region         = "ap-northeast-1"
    dynamodb_table = "terraform-state-lock"
    encrypt        = true
  }
}
```

---

## providers.tf

```hcl
provider "aws" {
  region = var.region
  
  default_tags {
    tags = {
      ManagedBy   = "terraform"
      Environment = var.environment
    }
  }
}

# Kubernetes and Helm providers MUST reference the cluster after it's created
# Use `depends_on` with the EKS module to avoid chicken-and-egg problems
provider "kubernetes" {
  host                   = module.eks.cluster_endpoint
  cluster_ca_certificate = base64decode(module.eks.cluster_certificate_authority_data)
  
  exec {
    api_version = "client.authentication.k8s.io/v1beta1"
    command     = "aws"
    args        = ["eks", "get-token", "--cluster-name", module.eks.cluster_name, "--region", var.region]
  }
}

provider "helm" {
  kubernetes {
    host                   = module.eks.cluster_endpoint
    cluster_ca_certificate = base64decode(module.eks.cluster_certificate_authority_data)
    
    exec {
      api_version = "client.authentication.k8s.io/v1beta1"
      command     = "aws"
      args        = ["eks", "get-token", "--cluster-name", module.eks.cluster_name, "--region", var.region]
    }
  }
}
```

---

## variables.tf

```hcl
variable "environment"         { default = "prod" }
variable "region"              { default = "ap-northeast-1" }
variable "cluster_name"        { default = "prod-cluster" }
variable "kubernetes_version"  { default = "1.30" }

variable "vpc_id"              {}
variable "private_subnet_ids"  { type = list(string) }
variable "intra_subnet_ids"    { type = list(string) }  # for control plane ENIs
```

---

## main.tf

```hcl
data "aws_caller_identity" "current" {}
data "aws_region" "current" {}

module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 20.0"

  # ─── CLUSTER ──────────────────────────────────────────────────────
  cluster_name    = var.cluster_name
  cluster_version = var.kubernetes_version

  # ─── NETWORKING ───────────────────────────────────────────────────
  vpc_id                   = var.vpc_id
  subnet_ids               = var.private_subnet_ids
  control_plane_subnet_ids = var.intra_subnet_ids

  # ─── ENDPOINT ACCESS ──────────────────────────────────────────────
  cluster_endpoint_public_access       = false  # private cluster
  cluster_endpoint_private_access      = true
  # cluster_endpoint_public_access     = true   # for dev environments
  # cluster_endpoint_public_access_cidrs = ["203.0.113.0/24"]  # office IP

  # ─── ENCRYPTION ───────────────────────────────────────────────────
  create_kms_key = true  # module creates KMS key for secret encryption
  cluster_encryption_config = {
    resources = ["secrets"]
  }
  kms_key_deletion_window_in_days = 7

  # ─── LOGGING ──────────────────────────────────────────────────────
  cluster_enabled_log_types = [
    "api", "audit", "authenticator", "controllerManager", "scheduler"
  ]
  cloudwatch_log_group_retention_in_days = 90

  # ─── ACCESS CONTROL ───────────────────────────────────────────────
  authentication_mode                          = "API_AND_CONFIG_MAP"
  enable_cluster_creator_admin_permissions     = true

  access_entries = {
    sre_admin = {
      principal_arn = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:role/sre-admin"
      policy_associations = {
        admin = {
          policy_arn   = "arn:aws:eks::aws:cluster-access-policy/AmazonEKSClusterAdminPolicy"
          access_scope = { type = "cluster" }
        }
      }
    }
  }

  # ─── NODE GROUP DEFAULTS ──────────────────────────────────────────
  eks_managed_node_group_defaults = {
    ami_type = "AL2023_x86_64_STANDARD"

    metadata_options = {
      http_endpoint               = "enabled"
      http_tokens                 = "required"
      http_put_response_hop_limit = 1
      instance_metadata_tags      = "enabled"
    }

    block_device_mappings = {
      xvda = {
        device_name = "/dev/xvda"
        ebs = {
          volume_size           = 50
          volume_type           = "gp3"
          iops                  = 3000
          throughput            = 125
          encrypted             = true
          delete_on_termination = true
        }
      }
    }

    update_config = {
      max_unavailable_percentage = 33
    }
  }

  # ─── NODE GROUPS ──────────────────────────────────────────────────
  eks_managed_node_groups = {
    # System: critical add-ons (CoreDNS, Karpenter, monitoring)
    system = {
      instance_types = ["t3.medium"]
      capacity_type  = "ON_DEMAND"
      min_size       = 3
      max_size       = 6
      desired_size   = 3

      labels = { role = "system" }
      taints = [{
        key    = "CriticalAddonsOnly"
        value  = "true"
        effect = "NO_SCHEDULE"
      }]
    }
  }
  # Application workloads → Karpenter (defined separately)

  # ─── CLUSTER ADD-ONS ─────────────────────────────────────────────
  cluster_addons = {
    vpc-cni = {
      most_recent              = true
      service_account_role_arn = module.vpc_cni_irsa.iam_role_arn
      configuration_values = jsonencode({
        env = {
          ENABLE_PREFIX_DELEGATION = "true"
          WARM_PREFIX_TARGET       = "1"
          ENABLE_NETWORK_POLICY    = "true"
        }
      })
      before_compute = true
    }
    coredns = {
      most_recent = true
      configuration_values = jsonencode({
        replicaCount = 3
        nodeSelector = { role = "system" }
        tolerations  = [{ key = "CriticalAddonsOnly", operator = "Exists", effect = "NoSchedule" }]
      })
    }
    kube-proxy           = { most_recent = true }
    aws-ebs-csi-driver   = {
      most_recent              = true
      service_account_role_arn = module.ebs_csi_irsa.iam_role_arn
    }
  }

  tags = {
    Environment = var.environment
    Team        = "platform"
    CostCenter  = "platform-infra"
  }
}
```

---

## irsa.tf

```hcl
# vpc-cni IRSA
module "vpc_cni_irsa" {
  source    = "terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks"
  role_name = "${var.cluster_name}-vpc-cni"
  attach_vpc_cni_policy = true
  vpc_cni_enable_ipv4   = true
  oidc_providers = {
    main = {
      provider_arn               = module.eks.oidc_provider_arn
      namespace_service_accounts = ["kube-system:aws-node"]
    }
  }
}

# EBS CSI IRSA
module "ebs_csi_irsa" {
  source    = "terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks"
  role_name = "${var.cluster_name}-ebs-csi"
  attach_ebs_csi_policy = true
  oidc_providers = {
    main = {
      provider_arn               = module.eks.oidc_provider_arn
      namespace_service_accounts = ["kube-system:ebs-csi-controller-sa"]
    }
  }
}
```

---

## karpenter.tf

```hcl
module "karpenter" {
  source  = "terraform-aws-modules/eks/aws//modules/karpenter"
  version = "~> 20.0"
  
  cluster_name           = module.eks.cluster_name
  irsa_oidc_provider_arn = module.eks.oidc_provider_arn
  
  enable_v1_permissions = true
  
  node_iam_role_additional_policies = {
    AmazonSSMManagedInstanceCore = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
  }
}

resource "helm_release" "karpenter" {
  namespace  = "kube-system"
  name       = "karpenter"
  repository = "oci://public.ecr.aws/karpenter"
  chart      = "karpenter"
  version    = "1.0.0"
  wait       = true
  atomic     = true

  values = [yamlencode({
    serviceAccount = {
      annotations = { "eks.amazonaws.com/role-arn" = module.karpenter.iam_role_arn }
    }
    settings = {
      clusterName       = module.eks.cluster_name
      clusterEndpoint   = module.eks.cluster_endpoint
      interruptionQueue = module.karpenter.queue_name
    }
    tolerations = [{ key = "CriticalAddonsOnly", operator = "Exists", effect = "NoSchedule" }]
    nodeSelector = { role = "system" }
  })]

  depends_on = [module.eks.eks_managed_node_groups]
}
```

---

## outputs.tf

```hcl
output "cluster_name"                      { value = module.eks.cluster_name }
output "cluster_endpoint"                  { value = module.eks.cluster_endpoint }
output "cluster_certificate_authority_data" { value = module.eks.cluster_certificate_authority_data }
output "oidc_provider_arn"                 { value = module.eks.oidc_provider_arn }
output "oidc_provider"                     { value = module.eks.oidc_provider }
output "node_security_group_id"            { value = module.eks.node_security_group_id }
output "cluster_security_group_id"         { value = module.eks.cluster_security_group_id }
output "karpenter_irsa_arn"                { value = module.karpenter.iam_role_arn }
output "karpenter_node_role_name"          { value = module.karpenter.node_iam_role_name }
```

---

## Apply Order

```bash
cd infra/aws/eks/

# 1. Init
terraform init

# 2. Plan — read carefully
terraform plan -out=eks.tfplan

# 3. Apply control plane first
terraform apply -target=module.eks eks.tfplan
# ~15 minutes for EKS control plane

# 4. Apply IRSA roles
terraform apply -target=module.vpc_cni_irsa -target=module.ebs_csi_irsa eks.tfplan

# 5. Apply Karpenter module (IAM, SQS, EventBridge)
terraform apply -target=module.karpenter eks.tfplan

# 6. Apply Karpenter Helm release
terraform apply -target=helm_release.karpenter eks.tfplan

# 7. Apply everything else
terraform apply eks.tfplan

# 8. Configure kubectl
aws eks update-kubeconfig --name prod-cluster --region ap-northeast-1

# 9. Verify
kubectl get nodes
kubectl get pods -A | grep -v Running | grep -v Completed
```
