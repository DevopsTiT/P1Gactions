# Part 3 — EKS Managed Node Groups Deep Dive: terraform-aws-eks

> **What this part covers:** How `eks_managed_node_groups` works, every key setting, the defaults inheritance system, and the Launch Template the module generates.

---

## What "Managed" Means

```
MANAGED NODE GROUP: AWS takes care of:
  ├── Creating the EC2 Auto Scaling Group
  ├── Rolling node upgrades (drain → launch new → drain old → terminate)
  ├── Node repair (replace unhealthy nodes automatically)
  └── AMI version tracking per Kubernetes version

YOU take care of:
  ├── Choosing instance types
  ├── Setting min/max/desired counts
  ├── Security settings (IMDSv2, volume encryption, etc.)
  └── Node labels and taints
```

---

## The Two-Level Configuration System

The module uses a defaults + per-group override pattern:

```hcl
module "eks" {
  # LEVEL 1: defaults applied to ALL managed node groups
  eks_managed_node_group_defaults = {
    ami_type       = "AL2023_x86_64_STANDARD"
    instance_types = ["m5.large"]
    disk_size      = 50

    # Security defaults applied everywhere
    metadata_options = {
      http_endpoint               = "enabled"
      http_tokens                 = "required"   # IMDSv2 mandatory
      http_put_response_hop_limit = 1            # blocks pods from reaching IMDS
      instance_metadata_tags      = "enabled"
    }
    
    # Volume encryption applied everywhere
    block_device_mappings = {
      xvda = {
        device_name = "/dev/xvda"
        ebs = {
          volume_size           = 50
          volume_type           = "gp3"
          iops                  = 3000
          throughput            = 125
          encrypted             = true
          delete_on_termination = true
        }
      }
    }
  }

  # LEVEL 2: per-group config (overrides defaults where specified)
  eks_managed_node_groups = {
    system = {
      # Inherits everything from defaults above
      instance_types = ["t3.medium"]  # overrides the default m5.large
      min_size       = 3
      max_size       = 5
      desired_size   = 3
    }

    application = {
      # Also inherits defaults
      instance_types = ["m5.large", "m5.xlarge", "m6i.large"]  # multiple for Spot
      capacity_type  = "SPOT"  # overrides default ON_DEMAND
      min_size       = 3
      max_size       = 50
      desired_size   = 3
    }
  }
}
```

---

## Key Variables per Node Group

### ami_type
```hcl
# Common values:
ami_type = "AL2023_x86_64_STANDARD"    # Amazon Linux 2023, x86
ami_type = "AL2023_ARM_64_STANDARD"    # Amazon Linux 2023, Graviton (ARM) — 20% cheaper
ami_type = "AL2023_x86_64_NVIDIA_GPU"  # GPU instances
ami_type = "BOTTLEROCKET_x86_64"       # Bottlerocket OS (container-focused)
ami_type = "WINDOWS_CORE_2022_x86_64"  # Windows nodes
```
```
WHY GRAVITON (ARM):
  Same Kubernetes workloads, ~20% lower cost, better performance/watt.
  Most application workloads run on ARM without any changes.
  Requirement: container images must be built for linux/arm64.
  If using multi-arch images (Docker manifest list): works transparently.
  
  node_group_arm = {
    ami_type       = "AL2023_ARM_64_STANDARD"
    instance_types = ["m7g.large", "m6g.large"]
    capacity_type  = "SPOT"
  }
```

### capacity_type
```hcl
capacity_type = "ON_DEMAND"   # default — predictable, always available
capacity_type = "SPOT"        # 60-70% cheaper, can be interrupted with 2-min notice
```
```
SPOT INTERRUPTION:
  AWS gives a 2-minute warning before reclaiming a Spot instance.
  The node gets a termination notice.
  EKS drains the node (moves pods to other nodes).
  If pods have PodDisruptionBudgets: rolling replacement is safe.
  
SPOT DIVERSIFICATION (critical for availability):
  Never use a single instance type with Spot.
  If that type is out of capacity: no nodes can be added.
  
  instance_types = [
    "m5.large", "m5.xlarge",     # Intel
    "m6i.large", "m6i.xlarge",   # Intel 3rd gen
    "m6a.large", "m6a.xlarge",   # AMD (cheaper)
  ]
  # If m5.large Spot is unavailable: uses m5.xlarge, etc.
  # More types = more Spot capacity pools = more resilient
```

### Scaling Configuration
```hcl
min_size     = 3    # NEVER go below this (AZ resilience)
max_size     = 50   # cost ceiling — you decide the max
desired_size = 3    # starting count — Karpenter/CA adjusts dynamically
```
```
WHY min_size = 3 (not 1 or 2):
  3 AZs → 1 node per AZ minimum.
  If one AZ fails: 2 remaining nodes handle the workload.
  If min_size = 1 and that one AZ fails: 0 nodes = full outage.

WHY desired_size matters less with autoscaling:
  If using Karpenter or Cluster Autoscaler:
    These tools change desired_size via AWS API directly.
    Terraform should ignore_changes for desired_size to avoid conflicts.
    
  lifecycle {
    ignore_changes = [scaling_config[0].desired_size]
  }
```

### Labels and Taints
```hcl
labels = {
  role        = "system"
  environment = "production"
}

taints = [
  {
    key    = "CriticalAddonsOnly"
    value  = "true"
    effect = "NO_SCHEDULE"
    # Prevents regular pods from scheduling here.
    # Only pods with matching tolerations can use these nodes.
    # Reserves system nodes for: CoreDNS, kube-proxy, monitoring agents.
  }
]
```
```
COMMON TAINT PATTERNS:
  System nodes:
    taint: CriticalAddonsOnly=true:NoSchedule
    → only CoreDNS, kube-proxy, Dynatrace OneAgent can schedule here
    
  GPU nodes:
    taint: nvidia.com/gpu=present:NoSchedule
    → only ML workloads with GPU toleration can schedule here
    
  Spot nodes:
    label:  spot=true
    taint:  spot=true:PreferNoSchedule (soft — prefer not to schedule here)
    → all pods can schedule here but prefer on-demand if available
    
NODE SELECTOR in pod spec to target node groups:
  nodeSelector:
    role: system        # schedule this pod on system nodes
    spot: "false"       # schedule this pod on on-demand only
```

---

## The Launch Template the Module Creates

For each node group, the module creates an `aws_launch_template`:

```hcl
# What the module generates internally (simplified):
resource "aws_launch_template" "this" {
  name_prefix = "${var.cluster_name}-${var.node_group_name}-"

  # IMDSv2 settings (from metadata_options variable)
  metadata_options {
    http_endpoint               = "enabled"
    http_tokens                 = "required"    # IMDSv2
    http_put_response_hop_limit = 1             # blocks containers
  }

  # Root volume (from block_device_mappings variable)
  block_device_mappings {
    device_name = "/dev/xvda"
    ebs {
      volume_type           = "gp3"
      volume_size           = 50
      encrypted             = true
      delete_on_termination = true
    }
  }

  # Network interface: disable public IPs on nodes
  network_interfaces {
    associate_public_ip_address = false
    security_groups             = [aws_security_group.node.id]
  }

  # Node tags for Karpenter discovery
  tag_specifications {
    resource_type = "instance"
    tags = merge(var.tags, {
      "kubernetes.io/cluster/${var.cluster_name}" = "owned"
    })
  }
}
```

---

## Complete Production Node Group Example

```hcl
module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 20.0"

  cluster_name    = "prod-cluster"
  cluster_version = "1.30"
  vpc_id          = module.vpc.vpc_id
  subnet_ids      = module.vpc.private_subnets

  enable_cluster_creator_admin_permissions = true

  cluster_enabled_log_types = ["api", "audit", "authenticator", "controllerManager", "scheduler"]

  # Defaults for ALL node groups
  eks_managed_node_group_defaults = {
    ami_type = "AL2023_x86_64_STANDARD"
    
    metadata_options = {
      http_endpoint               = "enabled"
      http_tokens                 = "required"
      http_put_response_hop_limit = 1
      instance_metadata_tags      = "enabled"
    }
    
    block_device_mappings = {
      xvda = {
        device_name = "/dev/xvda"
        ebs = {
          volume_size           = 50
          volume_type           = "gp3"
          iops                  = 3000
          throughput            = 125
          encrypted             = true
          delete_on_termination = true
        }
      }
    }
    
    update_config = {
      max_unavailable_percentage = 33  # max 1/3 of nodes down at once during upgrades
    }
  }

  eks_managed_node_groups = {
    # System nodes: on-demand, reserved for cluster-critical add-ons
    system = {
      instance_types = ["t3.medium"]
      capacity_type  = "ON_DEMAND"
      min_size       = 3
      max_size       = 6
      desired_size   = 3

      labels = { role = "system" }
      taints = [{
        key    = "CriticalAddonsOnly"
        value  = "true"
        effect = "NO_SCHEDULE"
      }]
    }

    # Application nodes: Spot Graviton for cost savings
    application = {
      ami_type       = "AL2023_ARM_64_STANDARD"
      instance_types = ["m7g.large", "m6g.large", "m7g.xlarge", "m6g.xlarge"]
      capacity_type  = "SPOT"
      min_size       = 3
      max_size       = 50
      desired_size   = 3

      labels = { role = "application" }

      lifecycle = {
        ignore_changes = ["scaling_config[0].desired_size"]  # Karpenter manages this
      }
    }
  }
}
```
