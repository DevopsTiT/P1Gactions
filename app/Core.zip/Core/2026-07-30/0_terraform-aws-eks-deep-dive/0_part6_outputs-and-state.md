# Part 6 — Outputs, State & Module Integration Deep Dive: terraform-aws-eks

> **What this part covers:** Every important output the module exposes, how downstream modules consume those outputs, and how the Terraform state is organized for a multi-module EKS project.

---

## All Key Module Outputs

```hcl
# After applying the module, these outputs are available:
# Reference as: module.eks.<output_name>

# ─── CLUSTER IDENTITY ───────────────────────────────────────────────
output "cluster_name"                  # "prod-cluster"
output "cluster_arn"                   # "arn:aws:eks:ap-northeast-1:123:cluster/prod-cluster"
output "cluster_id"                    # same as cluster_name for EKS

# ─── NETWORK ACCESS ─────────────────────────────────────────────────
output "cluster_endpoint"
# "https://EXAMPLED539D4633E53DE1B71.gr7.ap-northeast-1.eks.amazonaws.com"
# Used by: kubectl (in kubeconfig), Helm provider, kubernetes provider

output "cluster_certificate_authority_data"
# Base64-encoded CA certificate
# Used by: kubectl (to verify the API server's TLS cert)

# ─── OIDC (for IRSA) ────────────────────────────────────────────────
output "oidc_provider"
# "oidc.eks.ap-northeast-1.amazonaws.com/id/EXAMPLE123"
# Used in IRSA trust policy: StringEquals condition

output "oidc_provider_arn"
# "arn:aws:iam::123456789:oidc-provider/oidc.eks.ap-northeast-1..."
# Used in IRSA trust policy: Principal.Federated

# ─── IAM ROLES ──────────────────────────────────────────────────────
output "cluster_iam_role_name"          # IAM role for the control plane
output "cluster_iam_role_arn"
output "node_security_group_id"         # Security group applied to all nodes
output "cluster_security_group_id"      # Security group for the control plane ENIs

# ─── KUBECONFIG / CONNECTION ────────────────────────────────────────
output "cluster_version"               # "1.30"
output "cluster_platform_version"      # "eks.x" (AWS internal patch version)
output "cluster_status"                # "ACTIVE"

# ─── NODE GROUPS ────────────────────────────────────────────────────
output "eks_managed_node_groups"
# Map of all node group details:
# {
#   system = {
#     node_group_arn  = "arn:aws:eks:..."
#     node_group_id   = "prod-cluster:system"
#     node_group_resources = [{ autoscaling_groups = [...] }]
#     node_group_status    = "ACTIVE"
#     launch_template_id   = "lt-..."
#   }
# }

output "eks_managed_node_groups_autoscaling_group_names"
# ["prod-cluster-system-2024xxxx", "prod-cluster-application-2024xxxx"]
# Used by Karpenter and Cluster Autoscaler
```

---

## How Other Modules Consume These Outputs

### Kubernetes Provider Configuration

```hcl
# providers.tf — configure kubernetes and helm providers using module outputs
provider "kubernetes" {
  host                   = module.eks.cluster_endpoint
  cluster_ca_certificate = base64decode(module.eks.cluster_certificate_authority_data)
  
  exec {
    api_version = "client.authentication.k8s.io/v1beta1"
    command     = "aws"
    args        = ["eks", "get-token", "--cluster-name", module.eks.cluster_name]
    # Uses AWS CLI to get a bearer token — avoids storing static credentials.
    # Token expires after 15 minutes (automatically renewed).
  }
}

provider "helm" {
  kubernetes {
    host                   = module.eks.cluster_endpoint
    cluster_ca_certificate = base64decode(module.eks.cluster_certificate_authority_data)
    
    exec {
      api_version = "client.authentication.k8s.io/v1beta1"
      command     = "aws"
      args        = ["eks", "get-token", "--cluster-name", module.eks.cluster_name]
    }
  }
}
```

### Karpenter Setup

```hcl
module "karpenter" {
  source  = "terraform-aws-modules/eks/aws//modules/karpenter"
  version = "~> 20.0"

  cluster_name           = module.eks.cluster_name
  irsa_oidc_provider_arn = module.eks.oidc_provider_arn  # ← from module output
  
  # Karpenter needs to be able to create nodes:
  node_iam_role_additional_policies = {
    AmazonSSMManagedInstanceCore = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
  }
}
```

### IRSA Roles

```hcl
# All IRSA roles need the OIDC outputs:
resource "aws_iam_role" "service_role" {
  assume_role_policy = jsonencode({
    Statement = [{
      Principal = { Federated = module.eks.oidc_provider_arn }
      Condition = {
        StringEquals = {
          "${module.eks.oidc_provider}:sub" = "system:serviceaccount:my-ns:my-sa"
        }
      }
    }]
  })
}
```

---

## Multi-Module State Organization

```
A production EKS project uses multiple Terraform state files.
Each state file = one independent apply unit.

infra/
  ├── aws/
  │   ├── networking/          ← State: s3://tfstate/networking/terraform.tfstate
  │   │   └── outputs: vpc_id, subnet_ids, security_group_ids
  │   │
  │   ├── eks/                 ← State: s3://tfstate/eks/terraform.tfstate
  │   │   ├── READS networking state (data source)
  │   │   └── outputs: cluster_name, oidc_provider_arn, node_sg_id
  │   │
  │   ├── irsa/                ← State: s3://tfstate/irsa/terraform.tfstate
  │   │   ├── READS eks state (data source)
  │   │   └── outputs: role ARNs per service
  │   │
  │   └── addons/              ← State: s3://tfstate/addons/terraform.tfstate
  │       └── READS eks state + irsa state
  │
  └── k8s/
      ├── namespaces/          ← State: s3://tfstate/k8s/namespaces/terraform.tfstate
      └── serviceaccounts/     ← State: s3://tfstate/k8s/sa/terraform.tfstate
```

### How Modules Read Each Other's Outputs

```hcl
# eks/main.tf — reads networking outputs
data "terraform_remote_state" "networking" {
  backend = "s3"
  config = {
    bucket = "company-tfstate"
    key    = "networking/terraform.tfstate"
    region = "ap-northeast-1"
  }
}

module "eks" {
  vpc_id     = data.terraform_remote_state.networking.outputs.vpc_id
  subnet_ids = data.terraform_remote_state.networking.outputs.private_subnet_ids
}

# irsa/main.tf — reads eks outputs
data "terraform_remote_state" "eks" {
  backend = "s3"
  config = {
    bucket = "company-tfstate"
    key    = "eks/terraform.tfstate"
    region = "ap-northeast-1"
  }
}

resource "aws_iam_role" "payment_api" {
  assume_role_policy = jsonencode({
    Statement = [{
      Principal = {
        Federated = data.terraform_remote_state.eks.outputs.oidc_provider_arn
      }
    }]
  })
}
```

---

## Reading the State After Apply

```bash
# Navigate to eks module
cd infra/aws/eks/

# List all resources Terraform manages
terraform state list

# Get a specific output
terraform output cluster_endpoint
terraform output oidc_provider_arn

# Get all outputs as JSON (useful for scripts)
terraform output -json | python3 -m json.tool

# Check if a specific resource exists in state
terraform state show module.eks.aws_eks_cluster.this[0] | head -20

# Generate kubeconfig using the outputs
CLUSTER_NAME=$(terraform output -raw cluster_name)
aws eks update-kubeconfig --name $CLUSTER_NAME --region ap-northeast-1
kubectl get nodes
```

---

## The `depends_on` Pattern

Some resources must wait for the cluster to be fully ready:

```hcl
# Add-ons, node groups, and Helm charts must wait for the cluster
resource "helm_release" "dynatrace" {
  # ... chart config ...
  
  depends_on = [
    module.eks.eks_managed_node_groups,
    # Wait for node groups: pods need nodes to schedule on
    # Without this: Helm might install but pods stay Pending
  ]
}

module "eks" {
  # ...
  cluster_addons = {
    coredns = {
      # CoreDNS needs nodes to schedule on
      # The module handles the dependency automatically between
      # the cluster and the add-on resources internally
    }
  }
}
```
