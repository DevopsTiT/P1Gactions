# Part 4 — EKS Add-ons Deep Dive: terraform-aws-eks

> **What this part covers:** How the `cluster_addons` variable works, every critical add-on explained, version management, and configuration values you must set for production.

---

## What EKS Add-ons Are

```
Add-on = an AWS-managed Kubernetes component that runs in the cluster.
AWS handles: version compatibility, security patches, rolling updates.
You handle: which version, configuration overrides, IRSA role.

Without add-ons:
  You would deploy CoreDNS, vpc-cni, kube-proxy manually via Helm.
  You'd manage version compatibility yourself.
  A Kubernetes upgrade: manually check all component compatibility.

With managed add-ons:
  AWS validates: "Kubernetes 1.30 is compatible with vpc-cni v1.18.x"
  One command to upgrade: change addon_version in Terraform.
  AWS handles the rolling update.
```

---

## The cluster_addons Variable

```hcl
cluster_addons = {
  <addon-name> = {
    most_recent              = true/false
    addon_version            = "v1.18.1-eksbuild.1"   # pin a specific version
    resolve_conflicts_on_update = "OVERWRITE"
    service_account_role_arn = "<IRSA role ARN>"       # for add-ons that need AWS access
    configuration_values     = jsonencode({...})        # add-on-specific config
    preserve                 = true/false               # keep add-on if module is destroyed
  }
}
```

---

## Add-on 1: vpc-cni (VPC Container Networking Interface)

```hcl
cluster_addons = {
  vpc-cni = {
    most_recent = true
    
    # vpc-cni needs IAM permissions to assign IPs to pods
    service_account_role_arn = module.vpc_cni_irsa.iam_role_arn
    
    configuration_values = jsonencode({
      env = {
        # PREFIX DELEGATION: assigns /28 blocks instead of individual IPs
        # Dramatically increases pod density per node
        ENABLE_PREFIX_DELEGATION = "true"
        WARM_PREFIX_TARGET       = "1"
        # Without prefix delegation:
        #   m5.large: 3 ENIs × 10 secondary IPs = 30 pod IPs
        # With prefix delegation:
        #   m5.large: 3 ENIs × 10 /28 blocks = 3 × 10 × 16 = 480 pod IPs
        
        # NETWORK POLICY: enables Kubernetes NetworkPolicy enforcement
        ENABLE_NETWORK_POLICY = "true"
        # Without this: NetworkPolicy resources are ignored silently.
        # With this: traffic between pods is actually restricted per policy.
      }
    })
    
    before_compute = true
    # CRITICAL: install vpc-cni BEFORE node groups are created.
    # Nodes won't work without vpc-cni. Some module versions support this flag.
  }
}
```

**The vpc-cni IRSA role is required:**
```hcl
module "vpc_cni_irsa" {
  source    = "terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks"
  
  role_name = "vpc-cni-irsa"
  
  attach_vpc_cni_policy = true
  vpc_cni_enable_ipv4   = true
  
  oidc_providers = {
    main = {
      provider_arn               = module.eks.oidc_provider_arn
      namespace_service_accounts = ["kube-system:aws-node"]
    }
  }
}
```
```
WHY vpc-cni NEEDS IRSA:
  vpc-cni calls AWS APIs:
    - ec2:AssignPrivateIpAddresses (assign IPs to pods)
    - ec2:UnassignPrivateIpAddresses (release IPs when pods terminate)
    - ec2:DescribeNetworkInterfaces
    
  Without IRSA: vpc-cni uses the node instance profile.
  Every node would need ec2:AssignPrivateIpAddresses permission.
  With IRSA: only the vpc-cni ServiceAccount gets these permissions.
  Better isolation — application pods cannot call these APIs.
```

---

## Add-on 2: coredns (DNS for Pods)

```hcl
cluster_addons = {
  coredns = {
    most_recent = true
    
    configuration_values = jsonencode({
      replicaCount = 3  # default is 2 — increase for HA
      
      # Spread CoreDNS pods across AZs
      topologySpreadConstraints = [
        {
          maxSkew           = 1
          topologyKey       = "topology.kubernetes.io/zone"
          whenUnsatisfiable = "DoNotSchedule"
          labelSelector     = {
            matchLabels = { "k8s-app" = "kube-dns" }
          }
        }
      ]
      
      # Schedule on system nodes (not application nodes)
      nodeSelector = { role = "system" }
      
      tolerations = [{
        key      = "CriticalAddonsOnly"
        operator = "Exists"
        effect   = "NoSchedule"
      }]
    })
  }
}
```
```
WHY CoreDNS MATTERS:
  Every pod resolves service names via CoreDNS.
  payment-api → looks up "payments-db.payments.svc.cluster.local"
  CoreDNS returns the ClusterIP for that Service.
  
  If CoreDNS is down:
  → No pods can resolve service names
  → ALL inter-service communication breaks
  → Complete application outage
  
  WHY 3 replicas:
  Default 2: if one CoreDNS pod is on the failing node, the other
  is taking all DNS queries. It becomes a bottleneck.
  3 replicas across 3 AZs: one AZ failure = 2 CoreDNS pods remain.
  
  RESOURCE TUNING for large clusters:
  configuration_values = jsonencode({
    resources = {
      limits   = { cpu = "500m", memory = "256Mi" }
      requests = { cpu = "100m", memory = "70Mi" }
    }
  })
```

---

## Add-on 3: kube-proxy

```hcl
cluster_addons = {
  kube-proxy = {
    most_recent = true
    # Minimal configuration needed — defaults are usually fine
    # Runs on every node, manages iptables rules for Service routing
  }
}
```
```
WHY kube-proxy:
  Services in Kubernetes have a ClusterIP (virtual IP).
  kube-proxy creates iptables rules: ClusterIP → pod IP (real).
  When pod A calls Service B: iptables rewrites the destination IP.
  Without kube-proxy: ClusterIPs don't work = Services don't work.
  
  ALTERNATIVE: eBPF mode (Cilium, AWS VPC CNI network policy mode)
  Replaces kube-proxy with more efficient eBPF programs.
  Not covered by the managed add-on (requires Cilium Helm chart).
```

---

## Add-on 4: aws-ebs-csi-driver (Persistent Volumes)

```hcl
cluster_addons = {
  aws-ebs-csi-driver = {
    most_recent              = true
    service_account_role_arn = module.ebs_csi_irsa.iam_role_arn
  }
}

module "ebs_csi_irsa" {
  source    = "terraform-aws-modules/iam/aws//modules/iam-role-for-service-accounts-eks"
  role_name = "ebs-csi-driver"
  
  attach_ebs_csi_policy = true
  
  oidc_providers = {
    main = {
      provider_arn               = module.eks.oidc_provider_arn
      namespace_service_accounts = ["kube-system:ebs-csi-controller-sa"]
    }
  }
}
```
```
WHY THIS MATTERS:
  PersistentVolumeClaims that request block storage use the EBS CSI driver.
  Without it: StatefulSets (databases, message queues) cannot mount volumes.
  
  What it does:
    PVC created → CSI driver calls ec2:CreateVolume → EBS volume created
    Pod scheduled → CSI driver calls ec2:AttachVolume → EBS attached to node
    Pod deleted → CSI driver calls ec2:DetachVolume
    PVC deleted → CSI driver calls ec2:DeleteVolume
  
  MUST HAVE if you run:
    Prometheus (stores metrics on PV)
    Any stateful application
    Message queues (Kafka, RabbitMQ)
    Any database running in Kubernetes
```

---

## Add-on 5: aws-efs-csi-driver (Shared Persistent Volumes)

```hcl
cluster_addons = {
  aws-efs-csi-driver = {
    most_recent              = true
    service_account_role_arn = module.efs_csi_irsa.iam_role_arn
  }
}
```
```
DIFFERENCE vs EBS:
  EBS: one pod at a time can mount it (ReadWriteOnce).
  EFS: multiple pods across multiple nodes can mount simultaneously (ReadWriteMany).
  
  USE CASES for EFS:
    Shared configuration files across multiple replicas
    ML training: multiple worker pods read the same dataset
    Shared upload storage (user files)
    
  EFS is NFS-based: higher latency than EBS for random I/O.
  Not suitable for databases. Use EBS for databases.
```

---

## Add-on 6: aws-load-balancer-controller (ALB Ingress)

```hcl
# NOT a managed add-on — deployed via Helm
# But the module output makes this easy:

resource "helm_release" "aws_load_balancer_controller" {
  name       = "aws-load-balancer-controller"
  repository = "https://aws.github.io/eks-charts"
  chart      = "aws-load-balancer-controller"
  namespace  = "kube-system"

  set {
    name  = "clusterName"
    value = module.eks.cluster_name
  }
  set {
    name  = "serviceAccount.annotations.eks\\.amazonaws\\.com/role-arn"
    value = module.alb_controller_irsa.iam_role_arn
  }
}
```
```
WHY THIS IS NEEDED:
  Without it: you can create Services of type LoadBalancer.
  AWS creates a Classic/Network Load Balancer per service.
  Expensive if many services. Cannot do path-based routing.
  
  With aws-load-balancer-controller:
  You create an Ingress resource.
  The controller creates ONE ALB shared across all services.
  Path routing: /api → payment-service, /shop → frontend.
  WAF integration: attach AWS WAF to the ALB.
  
  INGRESS EXAMPLE (what the controller reads):
  apiVersion: networking.k8s.io/v1
  kind: Ingress
  metadata:
    annotations:
      kubernetes.io/ingress.class: alb
      alb.ingress.kubernetes.io/scheme: internet-facing
      alb.ingress.kubernetes.io/target-type: ip
  spec:
    rules:
    - http:
        paths:
        - path: /api
          backend:
            service:
              name: payment-service
              port: { number: 80 }
```

---

## Version Management Strategy

```hcl
# OPTION 1: most_recent = true (auto-upgrade)
coredns = { most_recent = true }
# PRO: always on latest compatible version
# CON: a new version might break your configuration
# USE FOR: non-critical add-ons in dev/staging

# OPTION 2: pin version (predictable)
coredns = { addon_version = "v1.11.1-eksbuild.9" }
# PRO: changes only when you decide to
# CON: you must manually check for security patches
# USE FOR: production clusters

# OPTION 3: pin with automated upgrade in CI
# Run this weekly in CI to check for updates:
# aws eks describe-addon-versions \
#   --kubernetes-version 1.30 \
#   --addon-name coredns \
#   --query 'addons[0].addonVersions[*].addonVersion'

# Check current add-on versions vs available
aws eks describe-addon \
  --cluster-name prod-cluster \
  --addon-name coredns \
  --query '{Current:addonVersion,Status:status,ConfigurationStatus:configurationStatus}'
```
