# Step 6: payment-service Application — Production-Grade Kubernetes App

> **What this step builds:** A complete production-ready application deployed via Helm and ArgoCD. Every Kubernetes best practice is applied: topology spread, PodDisruptionBudget, HPA, ExternalSecret for credentials, IRSA for AWS access, resource limits, probes.

---

## The Full Helm Chart Structure

```
charts/payment-service/
├── Chart.yaml             ← chart name, version, description
├── values.yaml            ← all tunable parameters (environment-specific overrides possible)
└── templates/
    ├── deployment.yaml     ← the pods (replicas, resources, probes, topology spread)
    ├── service.yaml        ← ClusterIP Service (internal discovery)
    ├── ingress.yaml        ← ALB via annotations (external access)
    ├── hpa.yaml            ← HorizontalPodAutoscaler (auto-scaling)
    ├── pdb.yaml            ← PodDisruptionBudget (availability during disruptions)
    ├── serviceaccount.yaml ← IRSA annotation (AWS credentials)
    └── external-secret.yaml ← pulls DB credentials from Secrets Manager
```

---

## File: `templates/deployment.yaml` — The Core

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ .Values.name }}
  namespace: {{ .Values.namespace }}
  labels:
    app: {{ .Values.name }}
    team: {{ .Values.team }}
    version: {{ .Values.image.tag }}
spec:
  replicas: {{ .Values.replicaCount }}   # from values.yaml: default 3
  selector:
    matchLabels:
      app: {{ .Values.name }}
  
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 1    # at most 1 pod unavailable during update
      maxSurge: 1          # at most 1 extra pod during update
  
  template:
    metadata:
      labels:
        app: {{ .Values.name }}
        team: {{ .Values.team }}
      annotations:
        # Forces Karpenter to re-provision if drift is detected
        kubectl.kubernetes.io/last-applied-configuration: ""
    spec:
      serviceAccountName: {{ .Values.name }}   # links to IRSA role

      # ONE POD PER AVAILABILITY ZONE
      # Without this: all 3 replicas might land in AZ-a
      # If AZ-a fails: service is completely down despite having 3 replicas
      # With this: 1 pod in AZ-a, 1 in AZ-b, 1 in AZ-c
      topologySpreadConstraints:
        - maxSkew: 1
          topologyKey: topology.kubernetes.io/zone
          whenUnsatisfiable: DoNotSchedule
          labelSelector:
            matchLabels:
              app: {{ .Values.name }}

      # No two pods on the same NODE
      # Without this: 2 pods on node-1, 1 on node-2
      # If node-1 is drained: 2 pods evict simultaneously
      affinity:
        podAntiAffinity:
          preferredDuringSchedulingIgnoredDuringExecution:
            - weight: 100
              podAffinityTerm:
                topologyKey: kubernetes.io/hostname
                labelSelector:
                  matchLabels:
                    app: {{ .Values.name }}

      containers:
        - name: {{ .Values.name }}
          image: "{{ .Values.image.repository }}:{{ .Values.image.tag }}"
          ports:
            - containerPort: 8080
          
          env:
            # DB credentials from the K8s Secret created by ExternalSecret
            - name: DB_HOST
              valueFrom:
                secretKeyRef:
                  name: payment-service-db
                  key: host
            - name: DB_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: payment-service-db
                  key: password
          
          resources:
            requests:
              cpu: "200m"        # HPA needs requests to calculate utilisation
              memory: "256Mi"    # scheduler uses this for bin-packing
            limits:
              cpu: "1000m"       # 1 CPU core max
              memory: "512Mi"    # OOMKill if exceeded (better than slow + degraded)
          
          # STARTUP PROBE: don't check health until app is ready to serve
          # Allows up to 60s for the app to start (30 failures × 2s interval)
          startupProbe:
            httpGet:
              path: /health
              port: 8080
            failureThreshold: 30
            periodSeconds: 2
          
          # LIVENESS PROBE: restart the pod if the app is deadlocked
          # Only checks: is the process still alive and responding?
          # Does NOT check: is the DB connection working? (that's readiness)
          livenessProbe:
            httpGet:
              path: /health
              port: 8080
            initialDelaySeconds: 0   # startup probe handles the delay
            periodSeconds: 10
            failureThreshold: 3
          
          # READINESS PROBE: removes pod from Service endpoints when not ready
          # The app should return 503 if it cannot serve requests
          # (DB down, dependency unavailable, etc.)
          readinessProbe:
            httpGet:
              path: /ready
              port: 8080
            initialDelaySeconds: 0
            periodSeconds: 5
            failureThreshold: 3
```

### Why three different probes matter

```
Common mistake: using /health for both liveness and readiness.

Scenario: Database goes down.

With /health for both:
  DB unavailable → readiness probe → still returns 200 (just checks process)
  → traffic continues to reach pod → 500 errors for every request
  → liveness probe → still passes → pod never restarted
  → no recovery until DB comes back

Correct approach:
  /ready: checks DB connection → returns 503 if DB is unreachable
  Readiness probe fails → pod removed from Service endpoints → no traffic
  Traffic routed to pods in other AZs (where DB is reachable)
  → service continues degraded (fewer pods) but not broken

  /health: only checks if the process itself is alive (memory, event loop)
  Liveness probe fails → pod restarted → restores to clean state
  → prevents deadlocked or memory-leaked pods from continuing to run
```

---

## File: `templates/external-secret.yaml` — DB Credentials from Secrets Manager

```yaml
# ExternalSecret: instructs ESO to pull credentials from Secrets Manager
# and create a Kubernetes Secret in the payment namespace.
# The application reads env vars from that K8s Secret.

apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: payment-service-db
  namespace: payment
spec:
  refreshInterval: 1h   # ESO re-reads from Secrets Manager every hour
                        # picks up rotated passwords automatically

  secretStoreRef:
    name: cluster-secret-store    # defined in wave 4
    kind: ClusterSecretStore

  target:
    name: payment-service-db      # creates a K8s Secret with this name
    creationPolicy: Owner         # ESO owns this secret; deletes it if ExternalSecret is deleted

  data:
    - secretKey: host             # key in the created K8s Secret
      remoteRef:
        key: production/payment-service/database   # Secrets Manager path
        property: host                              # JSON field in the secret
    
    - secretKey: password
      remoteRef:
        key: production/payment-service/database
        property: password
    
    - secretKey: username
      remoteRef:
        key: production/payment-service/database
        property: username
```

### The credentials chain: Secrets Manager → ESO → K8s Secret → Pod

```
AWS Secrets Manager:
  Secret name: production/payment-service/database
  Value: {"host":"payment.abc.ap-northeast-1.rds.amazonaws.com","username":"payment_app","password":"xK9$m..."}
  Encrypted with KMS. Access controlled by IAM.

ESO (External Secrets Operator):
  Reads the ClusterSecretStore (uses IRSA role to authenticate to AWS)
  Calls: aws secretsmanager get-secret-value --secret-id production/payment-service/database
  Creates K8s Secret: payment-service-db

K8s Secret: payment-service-db
  Data:
    host: cGF5bWVudC5hYmM...   (base64 encoded, not encrypted in etcd by default)
    password: eEs5JG0...
    username: cGF5bWVudF9hcHA=

Pod (payment-service):
  Mounts the secret as environment variables:
    DB_HOST=payment.abc.ap-northeast-1.rds.amazonaws.com
    DB_PASSWORD=xK9$m...
  Application reads these at startup.

Rotation:
  DBA rotates the password in Secrets Manager.
  ESO detects the change on next refresh (within 1 hour).
  ESO updates the K8s Secret.
  Application reads the new value on next startup (or hot-reload if supported).
  NO code change, NO redeployment needed.
```

---

## File: `templates/hpa.yaml` — Horizontal Pod Autoscaler

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {{ .Values.name }}
  namespace: {{ .Values.namespace }}
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: {{ .Values.name }}
  
  minReplicas: {{ .Values.hpa.minReplicas }}   # default: 3 (one per AZ)
  maxReplicas: {{ .Values.hpa.maxReplicas }}   # default: 20

  metrics:
    # Scale based on CPU utilisation
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70  # scale out when avg CPU > 70%
    
    # Scale based on memory (optional but useful for memory-heavy apps)
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: 80
  
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 60   # don't scale up for 60s after last scale event
      policies:
        - type: Pods
          value: 4
          periodSeconds: 60            # add max 4 pods per 60 seconds
    scaleDown:
      stabilizationWindowSeconds: 300  # wait 5 minutes before scaling down
      policies:
        - type: Pods
          value: 1
          periodSeconds: 60            # remove max 1 pod per 60 seconds
```

### Why HPA + topology spread + PDB work together

```
Without this trio:
  HPA scales to 10 pods.
  All 10 might land in AZ-a (no topology spread → random scheduling).
  AZ-a fails: all 10 pods gone → service down.
  
  Node drain for maintenance:
  Kubernetes starts evicting pods.
  All pods might be evicted simultaneously → service down.

With this trio:
  HPA at 10 pods → topology spread ensures ~3 per AZ (~3 in a, 3 in b, 4 in c)
  AZ-a fails → 7 pods survive → service degraded but running
  
  Node drain for maintenance:
  PDB says: minAvailable=2 (or 75%)
  → Kubernetes drain only evicts pods if ≥ 2 will remain
  → Rolling eviction: drain node-1 → wait → drain node-2 → wait
  → Service always has ≥ 2 pods serving traffic during maintenance
```

---

## File: `templates/pdb.yaml` — PodDisruptionBudget

```yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: {{ .Values.name }}
  namespace: {{ .Values.namespace }}
spec:
  minAvailable: {{ .Values.pdb.minAvailable }}  # default: 2
  selector:
    matchLabels:
      app: {{ .Values.name }}

# What this prevents:
# 1. kubectl drain (node maintenance): only drains if ≥ 2 pods will remain healthy
# 2. Cluster upgrade (rolling node replacement): same protection
# 3. Karpenter consolidation (bin-packing nodes): won't remove node if PDB violated
# 4. Accidental kubectl delete pods --all: blocked until replacement pods are ready
```

---

## File: `templates/ingress.yaml` — ALB via Annotations

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{ .Values.name }}
  namespace: {{ .Values.namespace }}
  annotations:
    # These annotations are read by the AWS Load Balancer Controller
    # which creates an actual ALB from this Ingress object.
    
    kubernetes.io/ingress.class: "alb"
    
    # internet-facing: public ALB | internal: private ALB within VPC
    alb.ingress.kubernetes.io/scheme: "internet-facing"
    
    # ip mode: routes directly to pod IPs (no NodePort overhead)
    # instance mode: routes to node IP + NodePort (older, less efficient)
    alb.ingress.kubernetes.io/target-type: "ip"
    
    # ACM certificate ARN for HTTPS termination
    alb.ingress.kubernetes.io/certificate-arn: "{{ .Values.ingress.certificateArn }}"
    
    # Force HTTPS (HTTP → 301 redirect)
    alb.ingress.kubernetes.io/listen-ports: '[{"HTTP":80},{"HTTPS":443}]'
    alb.ingress.kubernetes.io/ssl-redirect: '443'
    
    # ALB health check settings (used to determine target health)
    alb.ingress.kubernetes.io/healthcheck-path: "/health"
    alb.ingress.kubernetes.io/healthcheck-interval-seconds: "15"
    alb.ingress.kubernetes.io/healthy-threshold-count: "2"
    alb.ingress.kubernetes.io/unhealthy-threshold-count: "3"
    
    # WAF integration (optional but recommended for public services)
    alb.ingress.kubernetes.io/wafv2-acl-arn: "{{ .Values.ingress.wafAclArn }}"

spec:
  rules:
    - host: "{{ .Values.ingress.host }}"  # payment.company.com
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service:
                name: {{ .Values.name }}
                port:
                  number: 8080
```

---

## values.yaml — All Configurable Parameters

```yaml
# charts/payment-service/values.yaml

name: payment-service
namespace: payment
team: payments

image:
  repository: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  tag: "latest"            # overwritten by GitHub Actions with commit SHA

replicaCount: 3            # 1 per AZ minimum

resources:
  requests:
    cpu: "200m"
    memory: "256Mi"
  limits:
    cpu: "1000m"
    memory: "512Mi"

hpa:
  minReplicas: 3
  maxReplicas: 20
  targetCPUUtilizationPercentage: 70

pdb:
  minAvailable: 2

ingress:
  host: "payment.company.com"
  certificateArn: "arn:aws:acm:ap-northeast-1:123456789012:certificate/xxx"
  wafAclArn: ""            # optional WAF

irsa:
  roleArn: "arn:aws:iam::123456789012:role/payment-service-role"
```

---

## ArgoCD Application for payment-service

```yaml
# gitops/app/payment-service/payment-service.yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: payment-service
  namespace: argocd
  annotations:
    argocd.argoproj.io/sync-wave: "8"   # deploys LAST (after all platform components)
spec:
  project: payments    # AppProject restricts deployment to payment namespace only
  source:
    repoURL: https://github.com/company/eks-dynatrace-gitops-project
    targetRevision: main
    path: charts/payment-service
    helm:
      valueFiles:
        - values.yaml
  destination:
    server: https://kubernetes.default.svc
    namespace: payment
  syncPolicy:
    automated:
      selfHeal: true   # reverts any manual kubectl changes
      prune: true      # removes resources deleted from the chart
    syncOptions:
      - CreateNamespace=true
```

---

## Verification: Payment Service Running

```bash
# Check all pods are running and spread across AZs:
kubectl get pods -n payment -o wide
# Expected: 3 pods in different AZs (NODE column shows different nodes)

# Check the ALB was created by the ALB Controller:
kubectl get ingress -n payment
# Expected: ADDRESS column shows the ALB DNS name

# Test the service:
ALB_DNS=$(kubectl get ingress payment-service -n payment \
  -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
curl -f "https://${ALB_DNS}/health"
# Expected: HTTP 200 {"status": "ok"}

# Check HPA is scaling correctly:
kubectl get hpa -n payment
# Expected: TARGETS shows current CPU% / target CPU%

# Check PDB is configured:
kubectl get pdb -n payment
# Expected: ALLOWED DISRUPTIONS = replicas - minAvailable (usually = 1)

# Check external secret was synced:
kubectl get externalsecret -n payment
# Expected: STATUS=SecretSynced

# Check Dynatrace discovered the service:
DT_TENANT=$(aws secretsmanager get-secret-value \
  --secret-id production/dynatrace/tenant-url --query SecretString --output text)
DT_TOKEN=$(aws secretsmanager get-secret-value \
  --secret-id production/dynatrace/api-token --query SecretString --output text)

curl -s "${DT_TENANT}/api/v2/entities?entitySelector=type(SERVICE),tag(service:payment-service)" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  python3 -c "
import sys, json
d = json.load(sys.stdin)
total = d.get('totalCount', 0)
print(f'payment-service in Dynatrace: {total} entity(ies)')
"
# Expected: 1 (the service was auto-discovered by OneAgent)
```
