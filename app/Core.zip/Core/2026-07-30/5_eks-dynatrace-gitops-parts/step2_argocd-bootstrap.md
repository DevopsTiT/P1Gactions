# Step 2: ArgoCD Bootstrap — GitOps Control Plane

> **What this step builds:** The GitOps control plane. After this step, ALL future Kubernetes changes happen by pushing to Git — ArgoCD reconciles the cluster to match. This is the most important architectural decision in the project.

---

## What GitOps Actually Means

```
Traditional deployment:
  Developer → runs: kubectl apply -f deployment.yaml → Kubernetes updated
  
  Problems:
    Who ran that command? What exact manifest was used? What version was that?
    If the pod crashes, how do you restore exactly what was there?
    How do staging and production stay in sync?

GitOps:
  Git repo = the ONLY source of truth for what should run in Kubernetes.
  ArgoCD watches the repo and continuously reconciles the cluster.
  Developer → git push → ArgoCD detects change → applies to cluster
  
  Results:
    Every change is a Git commit: author, timestamp, diff are all recorded.
    Rollback = git revert → ArgoCD applies the reverted state.
    Disaster recovery = point ArgoCD at the repo → cluster rebuilt automatically.
    Staging + prod use the same manifests (different branches or overlay values).
```

---

## File: `gitops/bootstrap/root-app.yaml` — The One File You Apply Manually

### What it is

```yaml
# This is the ONLY kubectl command you ever run directly.
# After this: everything else is managed by ArgoCD.

apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: root-app
  namespace: argocd
  annotations:
    argocd.argoproj.io/sync-wave: "0"
spec:
  project: default
  source:
    repoURL: https://github.com/company/eks-dynatrace-gitops-project
    targetRevision: main
    path: gitops/           # ArgoCD watches the ENTIRE gitops/ directory
  destination:
    server: https://kubernetes.default.svc
    namespace: argocd
  syncPolicy:
    automated:
      selfHeal: true       # if anyone manually changes K8s resources, ArgoCD reverts them
      prune: true          # if a resource is removed from Git, ArgoCD deletes it from K8s
    syncOptions:
      - CreateNamespace=true
      - ApplyOutOfSyncOnly=true
```

```bash
# Bootstrap sequence (run ONCE after EKS + ArgoCD install):

# Step 1: Install ArgoCD into the cluster
kubectl create namespace argocd
kubectl apply -n argocd \
  -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# Step 2: Wait for ArgoCD to be ready
kubectl wait --for=condition=available deployment/argocd-server \
  -n argocd --timeout=300s

# Step 3: Apply the root app (THE ONLY MANUAL APPLY YOU'LL EVER DO)
kubectl apply -f gitops/bootstrap/root-app.yaml

# Step 4: Watch ArgoCD bootstrap the entire platform
argocd app list --grpc-web
# You'll see apps appearing as ArgoCD discovers them from the gitops/ repo
```

---

## The App of Apps Pattern

### Why it matters

```
Without App of Apps:
  30 Kubernetes applications on the platform.
  Each needs its own ArgoCD Application resource.
  ArgoCD gets reinstalled (disaster recovery or upgrade).
  You must manually re-create all 30 Application resources.
  Some are forgotten. Platform is partially broken.

With App of Apps:
  root-app watches gitops/ directory.
  gitops/ contains Application and ApplicationSet resources.
  ArgoCD discovers and creates all child Applications automatically.
  
  Disaster recovery:
    kubectl apply -f gitops/bootstrap/root-app.yaml
    → ArgoCD recreates all 30 applications automatically
    → Platform fully restored in ~15 minutes
    → Zero manual work per application
```

### The hierarchy

```
root-app  (watches: gitops/)
├── namespaces ApplicationSet      (gitops/namespaces/namespaces.yaml)
│   → creates all namespaces via Helm chart
│
├── networking ApplicationSet      (gitops/networking/)
│   ├── aws-load-balancer-controller Application
│   └── (future: nginx-ingress, etc.)
│
├── secrets ApplicationSet         (gitops/secrets/)
│   ├── external-secrets-operator Application
│   └── cluster-secret-store Application
│
├── monitoring ApplicationSet      (gitops/monitoring/)
│   └── dynatrace-operator Application
│
├── auto-scaling ApplicationSet    (gitops/auto-scaling/)
│   └── karpenter Application
│
├── security ApplicationSet        (gitops/security/)
│   └── kyverno Application
│
└── app ApplicationSet             (gitops/app/)
    └── payment-service Application
```

---

## Sync Waves — The Ordering System

### Why ordering matters

```
If everything deploys simultaneously (no ordering):

  ESO (External Secrets Operator) pod starts.
  ClusterSecretStore tries to create.
  → FAILS: the ESO CRD doesn't exist yet (pod hasn't finished installing)

  ExternalSecret for dynakube tries to create.
  → FAILS: ClusterSecretStore doesn't exist yet

  Dynatrace Operator tries to create DynaKube.
  → FAILS: the dynakube K8s Secret doesn't exist yet (ESO hasn't created it)

  payment-service tries to start.
  → FAILS: its database credentials Secret doesn't exist yet

  Result: CrashLoopBackOff cascade. Everything fails.
  You spend 30 minutes running kubectl describe to understand the order.

With sync waves:
  Wave -1 completes (namespaces) → Wave 1 starts (ALB Controller)
  Wave 1 completes → Wave 2 starts (ESO)
  Wave 2 completes → Wave 3 starts (Karpenter + Dynatrace Operator)
  etc.
  Each wave waits until the previous wave's resources are Healthy.
```

### Wave assignments and why

```
Wave -1: Namespaces
  WHY FIRST: Every pod needs a namespace to land in.
  If the namespace doesn't exist, ArgoCD cannot create the Application.
  All namespaces must exist before any Application deploys.

Wave 1: AWS Load Balancer Controller
  WHY SECOND: Ingress objects reference ALB annotations.
  If the ALB Controller isn't running, Ingress creates but ALB is never provisioned.
  Services that need external access will be unreachable.

Wave 2: External Secrets Operator (ESO)
  WHY THIRD: ESO must be installed before we can create ClusterSecretStore.
  ClusterSecretStore is an ESO CRD — it doesn't exist until ESO is installed.
  Without ESO, no Kubernetes Secrets can be synced from Secrets Manager.

Wave 3: Karpenter + Dynatrace Operator (parallel, same wave)
  Karpenter: must be ready before we scale past the system node group.
  Dynatrace Operator: needs namespaces and ESO to be working (for the dynakube secret).
  These two can deploy in parallel (no dependency between them).

Wave 4: ClusterSecretStore
  WHY AFTER ESO: ClusterSecretStore is an ESO CRD.
  This resource tells ESO: "connect to AWS Secrets Manager in this region."
  Must come AFTER ESO (wave 2) has installed the CRD.
  Must come BEFORE any ExternalSecret (wave 5+).

Wave 5: Kyverno security policies
  WHY AFTER PLATFORM: Kyverno enforces security policies.
  If Kyverno policies are applied before system pods are running,
  those pods might be blocked by the policies (chicken-and-egg).
  Apply policies AFTER platform is healthy.

Wave 8: payment-service application
  WHY LAST: The app needs EVERYTHING to be ready:
    Namespace (wave -1)
    ALB to route external traffic (wave 1)
    ESO + ClusterSecretStore to create its DB credentials Secret (waves 2, 4)
    Karpenter to provision nodes for the app pods (wave 3)
    Dynatrace to start monitoring immediately on first deploy (wave 3)
    Kyverno policies to be in place before the app pod runs (wave 5)
```

---

## File: `gitops/namespaces/namespaces.yaml` — ApplicationSet

### What ApplicationSets are

```
An ApplicationSet generates multiple ArgoCD Applications from a template.

Use case: you need one namespace per service.
Without ApplicationSet: write one Application resource per namespace.
With ApplicationSet: write one template + a list → generates all Applications.

namespaces.yaml (simplified):
  generators:
    - list:
        elements:
          - namespace: payment
          - namespace: orders
          - namespace: monitoring
          - namespace: dynatrace
          - namespace: karpenter
  template:
    name: "namespace-{{namespace}}"
    spec:
      source:
        path: charts/namespaces   ← simple Helm chart that creates a Namespace resource
        helm:
          parameters:
            - name: namespace
              value: "{{namespace}}"

Result: 5 ArgoCD Applications, each creating one namespace.
Add a service: add one line to the elements list → namespace auto-created.
```

---

## File: `gitops/argocd/argocd-project.yaml` — RBAC per Team

### What AppProjects do

```
By default: any ArgoCD user can deploy anything anywhere.
AppProject: restricts what a team's ArgoCD Applications can do.

Example: AppProject for "payments" team:
  sourceRepos:
    - 'https://github.com/company/eks-dynatrace-gitops-project'
    → Can only use our own repo (not some external repo)
  
  destinations:
    - namespace: payment
      server: https://kubernetes.default.svc
    → Can only deploy to the payment namespace
    → CANNOT deploy to kube-system or argocd namespaces
  
  clusterResourceWhitelist:
    - group: ''
      kind: Namespace
    → Can create namespaces, but no ClusterRoles or ClusterRoleBindings
  
Result:
  If a developer's ArgoCD credentials are compromised:
  → Attacker can only deploy to the payment namespace
  → Cannot touch platform components or other teams' namespaces
```

---

## Verification After Bootstrap

```bash
# Check all Applications are Synced and Healthy:
argocd app list --grpc-web
# Expected: every app shows Synced + Healthy

# Check sync wave progress (all waves completed):
argocd app get root-app --grpc-web
# Look for: Sync Status: Synced, Health Status: Healthy

# Verify all platform pods are running:
kubectl get pods -A | grep -v "Running\|Completed"
# Expected: empty output (all pods running or completed)

# Verify specific components:
kubectl get pods -n kube-system | grep aws-load-balancer
kubectl get pods -n external-secrets | grep external-secrets
kubectl get pods -n karpenter | grep karpenter
kubectl get pods -n dynatrace | grep oneagent
```
