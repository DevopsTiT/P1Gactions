# Step 5: GitHub Actions Pipelines — Automated CI/CD

> **What this step builds:** Three GitHub Actions workflows that close the automation loop: application CI (test + build + push + update tag), infrastructure Terraform (plan on PR, apply on merge), and Dynatrace Terraform (same pattern, separate pipeline).

---

## Why Three Separate Workflows

```
Single workflow for everything:
  One YAML, one trigger, everything runs together.
  
  Problems:
    → App code change triggers a terraform plan for infrastructure (unrelated, slow)
    → Terraform infrastructure change triggers Docker build (unrelated)
    → If Docker build is broken, you can't even plan infrastructure changes
    → One workflow file becomes 500 lines (unmaintainable)

Three separate workflows:
  app-ci.yaml           → triggered by: changes to app/** or charts/**
  terraform-infra.yaml  → triggered by: changes to terraform/** (not dynatrace/)
  terraform-dynatrace.yaml → triggered by: changes to terraform/dynatrace/**

  Benefits:
    → App engineers can merge and deploy without touching infra pipelines
    → SREs can update Dynatrace alerting thresholds without running Docker builds
    → Failures in one pipeline don't block others
    → Each workflow uses the minimum required AWS permissions
```

---

## File: `.github/workflows/app-ci.yaml`

### On Pull Request (validation only)

```yaml
on:
  pull_request:
    branches: [main]
    paths:
      - 'app/**'
      - 'charts/**'

jobs:
  test-and-build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'

      - name: Install dependencies
        run: |
          cd app/
          pip install -r requirements.txt
          pip install pytest

      - name: Run tests
        run: |
          cd app/
          pytest tests/ -v --tb=short
        # Tests must pass before any merge is allowed

      - name: Build Docker image (no push — just verify it builds)
        run: |
          docker build -t payment-service:pr-test ./app/
        # Catches: Dockerfile errors, missing dependencies, broken build scripts
        # Does NOT push — we don't want PR images polluting ECR
```

### On Merge to Main (build + push + update tag)

```yaml
on:
  push:
    branches: [main]
    paths:
      - 'app/**'

jobs:
  build-push-deploy:
    runs-on: ubuntu-latest
    permissions:
      id-token: write    # REQUIRED for OIDC (no stored AWS keys)
      contents: write    # needed to commit the image tag update

    steps:
      - uses: actions/checkout@v4
        with:
          token: ${{ secrets.GITHUB_TOKEN }}

      # OIDC authentication — no AWS_ACCESS_KEY_ID stored in GitHub Secrets
      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/github-actions-ecr-push
          aws-region: ap-northeast-1
          # GitHub OIDC token is exchanged for temporary AWS credentials
          # The IAM role's trust policy restricts this to:
          #   - github.com/company/eks-dynatrace-gitops-project
          #   - refs/heads/main branch only

      - name: Login to Amazon ECR
        id: ecr-login
        uses: aws-actions/amazon-ecr-login@v2

      - name: Build and push Docker image
        env:
          ECR_REGISTRY: ${{ steps.ecr-login.outputs.registry }}
          ECR_REPO: payment-service
          IMAGE_TAG: ${{ github.sha }}    # commit SHA = immutable, traceable tag
        run: |
          docker build -t "${ECR_REGISTRY}/${ECR_REPO}:${IMAGE_TAG}" ./app/
          docker push "${ECR_REGISTRY}/${ECR_REPO}:${IMAGE_TAG}"
          echo "IMAGE_TAG=${IMAGE_TAG}" >> $GITHUB_ENV
          echo "Pushed: ${ECR_REGISTRY}/${ECR_REPO}:${IMAGE_TAG}"

      # This is the GitOps update — commits to the gitops repo
      # ArgoCD detects the commit and triggers the rollout
      - name: Update image tag in Helm values
        run: |
          # Update charts/payment-service/values.yaml
          sed -i "s|tag:.*|tag: \"${IMAGE_TAG}\"|g" charts/payment-service/values.yaml
          
          git config user.email "github-actions@company.com"
          git config user.name "GitHub Actions"
          
          git add charts/payment-service/values.yaml
          git commit -m "chore(deploy): update payment-service image to ${IMAGE_TAG}
          
          Deployed by: ${{ github.actor }}
          Triggered by commit: ${{ github.sha }}
          Build URL: ${{ github.server_url }}/${{ github.repository }}/actions/runs/${{ github.run_id }}"
          
          git push origin main
          echo "GitOps updated — ArgoCD will detect this change and roll out"
```

### Why commit SHA tag (not `:latest`)

```
:latest tag:
  docker pull payment-service:latest
  → What code is actually in this image? Who pushed it? When?
  → Cannot answer any of these questions
  
  Production shows an error. "Which version is running?"
  → "It's latest"
  → "What IS latest right now?"
  → Nobody knows without checking ECR push time

Commit SHA tag: payment-service:abc1234ef5678
  → Exactly which commit is in this image
  → git show abc1234ef5678 shows the exact code
  → git log charts/payment-service/values.yaml shows deploy history
  → Rollback: change tag to the previous SHA → ArgoCD deploys the old version
  → Audit: "what was running at 14:00 yesterday?" → check git log at 14:00
```

---

## File: `.github/workflows/terraform-infra.yaml`

### On Pull Request (plan + review)

```yaml
on:
  pull_request:
    branches: [main]
    paths:
      - 'terraform/**'
      - '!terraform/dynatrace/**'  # dynatrace has its own workflow

jobs:
  terraform-plan:
    runs-on: ubuntu-latest
    permissions:
      id-token: write
      pull-requests: write    # to post plan as PR comment

    steps:
      - uses: actions/checkout@v4

      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: "1.8.0"  # pinned version

      - name: Configure AWS credentials (OIDC)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/github-actions-terraform
          aws-region: ap-northeast-1

      - name: Terraform Init
        working-directory: terraform/
        run: terraform init

      - name: Terraform Format Check
        working-directory: terraform/
        run: terraform fmt -check -recursive
        # Fails if any .tf file is not properly formatted
        # Run locally: terraform fmt -recursive to fix

      - name: Terraform Validate
        working-directory: terraform/
        run: terraform validate

      - name: Terraform Plan
        working-directory: terraform/
        run: |
          terraform plan -out=tfplan -no-color 2>&1 | tee plan.txt
          echo "PLAN_EXIT_CODE=${PIPESTATUS[0]}" >> $GITHUB_ENV

      - name: Check for dangerous changes
        working-directory: terraform/
        run: |
          # Block merge if plan would DESTROY any stateful resources
          # (RDS, EKS, VPC, EFS) without explicit approval
          DESTROYS=$(terraform show -json tfplan | \
            python3 -c "
import sys, json
plan = json.load(sys.stdin)
changes = plan.get('resource_changes', [])
destroys = [c for c in changes if 'delete' in c.get('change', {}).get('actions', [])]
dangerous = [d for d in destroys if any(
    t in d['type'] for t in ['aws_eks', 'aws_vpc', 'aws_db', 'aws_efs']
)]
if dangerous:
    print('DANGEROUS_DESTROYS=true')
    for d in dangerous:
        print(f'Would destroy: {d[\"address\"]}')
else:
    print('DANGEROUS_DESTROYS=false')
")
          echo "$DESTROYS"
          if echo "$DESTROYS" | grep -q "DANGEROUS_DESTROYS=true"; then
            echo "::error::Plan would destroy stateful resources. Requires explicit approval."
            exit 1
          fi

      - name: Post plan to PR
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs')
            const plan = fs.readFileSync('terraform/plan.txt', 'utf8')
            const maxLength = 65000
            const truncated = plan.length > maxLength ? plan.slice(-maxLength) : plan
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: `## Terraform Plan\n\`\`\`\n${truncated}\n\`\`\``
            })
```

### On Merge to Main (apply)

```yaml
  terraform-apply:
    runs-on: ubuntu-latest
    needs: []    # no dependency — this is a separate job
    if: github.ref == 'refs/heads/main' && github.event_name == 'push'

    environment: production    # requires human approval in GitHub Environments

    steps:
      # ... (same init steps as plan)

      - name: Terraform Apply
        working-directory: terraform/
        run: terraform apply -auto-approve

      - name: Notify Slack on success
        if: success()
        run: |
          curl -X POST "${{ secrets.SLACK_WEBHOOK }}" \
            -H "Content-Type: application/json" \
            -d '{"text":"✅ Terraform apply succeeded for PR ${{ github.event.pull_request.number }}"}'

      - name: Notify Slack on failure
        if: failure()
        run: |
          curl -X POST "${{ secrets.SLACK_WEBHOOK }}" \
            -H "Content-Type: application/json" \
            -d '{"text":"❌ Terraform apply FAILED for PR ${{ github.event.pull_request.number }}"}'
```

---

## File: `.github/workflows/terraform-dynatrace.yaml`

### Why separate from infra terraform

```
Separate workflow because:

1. Different trigger paths:
   infra:       terraform/** except terraform/dynatrace/**
   dynatrace:   terraform/dynatrace/**
   
   An app team updating alert thresholds should not trigger an EKS plan.

2. Different AWS permissions:
   infra role:  can create VPCs, EKS clusters, IAM roles → very powerful
   dynatrace role: can only read DT token from Secrets Manager → minimal
   
   If dynatrace workflow is compromised: attacker can only read DT token.
   Cannot touch EKS or IAM.

3. Different risk profile:
   Infrastructure changes can cause downtime (wrong VPC config = no connectivity)
   Dynatrace config changes cannot cause downtime (worst case: bad alert threshold)
   Infra: requires production environment approval gate (human clicks approve)
   Dynatrace: can auto-apply on merge (lower risk)

4. Independent cadence:
   Infra changes: rare (once per week or less)
   DT config changes: frequent (tuning thresholds, adding new services)
   Separating them prevents infra pipeline noise from DT updates.
```

```yaml
# terraform-dynatrace.yaml (simplified)
on:
  pull_request:
    paths: ['terraform/dynatrace/**']
  push:
    branches: [main]
    paths: ['terraform/dynatrace/**']

jobs:
  plan:
    if: github.event_name == 'pull_request'
    steps:
      # Uses a different AWS role (reads DT token from SM, nothing else)
      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/github-actions-dt-config

      - name: Read DT credentials from Secrets Manager
        run: |
          DT_URL=$(aws secretsmanager get-secret-value \
            --secret-id production/dynatrace/tenant-url --query SecretString --output text)
          DT_TOKEN=$(aws secretsmanager get-secret-value \
            --secret-id production/dynatrace/api-token --query SecretString --output text)
          echo "TF_VAR_dynatrace_env_url=${DT_URL}" >> $GITHUB_ENV
          echo "TF_VAR_dynatrace_api_token=${DT_TOKEN}" >> $GITHUB_ENV

      - name: Terraform Plan
        working-directory: terraform/dynatrace/
        run: terraform plan -no-color 2>&1 | tee plan.txt
      
      # Post plan as PR comment (same as infra workflow)

  apply:
    if: github.ref == 'refs/heads/main' && github.event_name == 'push'
    steps:
      # NO environment gate — DT config changes auto-apply on merge
      - name: Terraform Apply
        working-directory: terraform/dynatrace/
        run: terraform apply -auto-approve
```

---

## OIDC Authentication — No Stored AWS Credentials

```
Without OIDC (old approach):
  GitHub Actions → uses AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY stored in GitHub Secrets
  
  Problems:
    Keys have long TTL (months/years unless manually rotated)
    Keys are stored in GitHub — potential for Secret scanning exposure
    No audit trail: "this key was used by GitHub Actions" but which action? Which repo?
    Key compromise = permanent AWS access until manually revoked

With OIDC (correct approach):
  GitHub Actions → calls AWS STS AssumeRoleWithWebIdentity with OIDC token
  AWS STS verifies the token is from GitHub's OIDC issuer
  AWS STS verifies the token's "sub" claim matches the allowed repo/branch
  AWS STS issues temporary credentials (1-hour TTL, auto-expired)
  
  IAM trust policy for the GitHub Actions role:
  {
    "Principal": { "Federated": "arn:aws:iam::123456789012:oidc-provider/token.actions.githubusercontent.com" },
    "Action": "sts:AssumeRoleWithWebIdentity",
    "Condition": {
      "StringEquals": {
        "token.actions.githubusercontent.com:aud": "sts.amazonaws.com"
      },
      "StringLike": {
        "token.actions.githubusercontent.com:sub": "repo:company/eks-dynatrace-gitops-project:ref:refs/heads/main"
      }
    }
  }
  
  This means: ONLY the main branch of ONLY this specific repo can use this role.
  No other repo. No feature branches. Only main.
```

---

## Verification After GitHub Actions Setup

```bash
# Verify OIDC provider exists in IAM:
aws iam list-open-id-connect-providers | grep "token.actions.githubusercontent.com"
# Expected: an ARN containing "token.actions.githubusercontent.com"

# Check GitHub Actions workflow files are present:
ls .github/workflows/
# Expected: app-ci.yaml terraform-infra.yaml terraform-dynatrace.yaml

# Simulate what happens on a PR (run plan locally):
cd terraform/
export TF_VAR_dynatrace_env_url="..."
export TF_VAR_dynatrace_api_token="..."
terraform plan -no-color 2>&1 | tail -20
# Expected: "No changes." if infrastructure matches the code

# Check recent workflow runs:
gh run list --workflow=app-ci.yaml --limit 5
gh run list --workflow=terraform-infra.yaml --limit 5
```
