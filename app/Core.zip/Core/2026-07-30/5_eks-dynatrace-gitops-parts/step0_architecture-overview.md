# Step 0: Architecture Overview — How All Pieces Connect

> **What this is:** The mental model for the entire project. Read this first. Every other step only makes sense once you understand how Terraform, ArgoCD, GitHub Actions, and Dynatrace relate to each other.

---

## The Core Promise

```
Zero manual cloud console clicks after initial bootstrap.

Meaning:
  → Every AWS resource (VPC, EKS, IAM) is created by Terraform
  → Every Kubernetes workload is deployed by ArgoCD reading Git
  → Every container image is built and pushed by GitHub Actions
  → Every monitoring rule (alerts, SLOs, dashboards) is created by Terraform
  → Dynatrace OneAgent discovers and monitors everything automatically

If someone manually clicks in the AWS console or edits a Kubernetes
resource directly: that is a violation of this model and must be
reconciled back to code.
```

---

## The Full Architecture

```
┌───────────────────────────────────────────────────────────────────────┐
│  Developer Workflow                                                    │
│                                                                       │
│  git push ──────────────────────────────────────────────────────►    │
│                │                                                       │
│                ├─► GitHub Actions (CI)                                 │
│                │      ├─► lint + test (every PR)                       │
│                │      ├─► docker build + push to ECR (merge to main)  │
│                │      ├─► update image tag in gitops repo             │
│                │      ├─► terraform plan/apply (infra changes)        │
│                │      └─► dynatrace terraform plan/apply (DT changes) │
│                │                                                       │
│                ├─► ArgoCD (CD)                                         │
│                │      detects gitops repo change                       │
│                │      → deploys/updates Kubernetes workloads          │
│                │      → manages ALL platform components               │
│                │                                                       │
│                └─► Dynatrace (Observability)                           │
│                       OneAgent auto-discovers new services             │
│                       within 5 minutes of pod starting                │
└───────────────────────────────────────────────────────────────────────┘

AWS Infrastructure Layer (created by Terraform):
┌───────────────────────────────────────────────────────────────────────┐
│  VPC                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐               │
│  │  AZ-a        │  │  AZ-b        │  │  AZ-c        │               │
│  │  public      │  │  public      │  │  public      │  ← ALB here   │
│  │  private     │  │  private     │  │  private     │  ← EKS nodes  │
│  │  NAT GW      │  │  NAT GW      │  │  NAT GW      │               │
│  └──────────────┘  └──────────────┘  └──────────────┘               │
│                                                                       │
│  EKS Cluster (v1.30, private API endpoint)                           │
│  ┌─────────────────────────────────────────────────────────────────┐ │
│  │  System Node Group (fixed: 3 nodes, m5.large)                  │ │
│  │  → ArgoCD, ALB Controller, ESO, Karpenter controller           │ │
│  │                                                                 │ │
│  │  Karpenter-managed nodes (elastic: 0-100 nodes)                │ │
│  │  → payment-service pods (auto-provisioned, right-sized)        │ │
│  │                                                                 │ │
│  │  DaemonSet: Dynatrace OneAgent (1 pod on EVERY node)           │ │
│  └─────────────────────────────────────────────────────────────────┘ │
│                                                                       │
│  Supporting Services:                                                 │
│    ECR (container images)                                             │
│    Secrets Manager (DT tokens, app credentials)                      │
│    Route53 (DNS for services)                                         │
│    ACM (TLS certificates)                                             │
└───────────────────────────────────────────────────────────────────────┘
```

---

## The Four Pillars and Their Responsibilities

```
PILLAR 1: TERRAFORM (Infrastructure as Code)
  Owns: Everything in AWS
    VPC, subnets, NAT Gateways, VPC Endpoints
    EKS cluster, managed node groups, OIDC provider
    IAM roles (one per K8s component via IRSA)
    Secrets Manager secrets (the secret containers, not the values)
    ECR repositories
    Dynatrace configuration (management zones, alerts, SLOs)

  Does NOT own:
    Kubernetes workloads (those are ArgoCD's job)
    Docker images (those are GitHub Actions' job)

PILLAR 2: ARGOCD (GitOps Continuous Delivery)
  Owns: Everything in Kubernetes
    Platform components (ALB Controller, ESO, Karpenter, Dynatrace Operator)
    Application workloads (payment-service and all future services)
    Namespace management
    Security policies (Kyverno)

  Does NOT own:
    AWS resources (Terraform's job)
    Building container images (GitHub Actions' job)

PILLAR 3: GITHUB ACTIONS (Continuous Integration)
  Owns: Code validation and artifact production
    Running tests (unit, integration)
    Building Docker images
    Pushing to ECR
    Updating image tags in the gitops repo (triggering ArgoCD)
    Running Terraform (as a pipeline step)

  Does NOT own:
    Deploying to Kubernetes directly (ArgoCD's job)
    Creating AWS resources outside of Terraform

PILLAR 4: DYNATRACE (Observability)
  Owns: Visibility into everything
    Auto-discovering all services on EKS
    Capturing distributed traces (PurePath)
    Collecting metrics (error rate, latency, CPU, memory)
    Shipping logs (container stdout → Grail)
    Firing alerts and creating Problems
    SLO tracking with error budget burn rates
```

---

## Why This Layered Approach

### Separation of concerns prevents cascading failures

```
Scenario: A developer deploys a bad payment-service version.

With this architecture:
  ArgoCD rolls out → Dynatrace detects error rate spike → fires alert
  On-call reverts via gitops → ArgoCD rolls back → alert resolves
  
  AWS infrastructure is completely unaffected.
  Other services are completely unaffected.
  The blast radius is isolated to payment-service.

Without separation (everything mixed):
  One broken manifest might block ALL deployments.
  One bad Terraform run might affect ALL workloads.
```

### Every change has an audit trail

```
"Who deployed this version of payment-service at 14:32 yesterday?"
  → Check gitops repo: git log charts/payment-service/values.yaml
  → Find the commit that changed image.tag
  → That commit's author = the person who merged the PR

"Who changed the alert threshold for payment-service?"
  → Check terraform/dynatrace/variables.tf git log
  → Find the commit that changed error_rate_alert

Without this model: "someone changed it in the console" — untraceable.
```

---

## Project File Tree (Complete)

```
eks-dynatrace-gitops-project/
│
├── terraform/                     ← AWS infrastructure IaC
│   ├── main.tf                    ← entry point: calls VPC + EKS modules
│   ├── variables.tf               ← all configurable inputs
│   ├── outputs.tf                 ← values other modules need (cluster endpoint etc.)
│   ├── versions.tf                ← exact provider versions (reproducibility)
│   ├── backend.tf                 ← S3 remote state + DynamoDB lock
│   ├── karpenter.tf               ← Karpenter IAM + SQS interruption queue
│   ├── irsa-lbc.tf                ← IAM for AWS Load Balancer Controller
│   ├── irsa-externaldns.tf        ← IAM for ExternalDNS
│   ├── irsa-eso.tf                ← IAM for External Secrets Operator
│   ├── secrets-manager.tf         ← Dynatrace token secrets (containers only)
│   ├── modules/
│   │   ├── vpc/                   ← VPC module (reusable for staging + prod)
│   │   └── eks/                   ← EKS module (cluster + OIDC + node groups)
│   ├── dynatrace/                 ← Dynatrace config as Terraform code
│   │   ├── main.tf
│   │   ├── management-zones.tf
│   │   ├── alerting-profiles.tf
│   │   ├── notifications.tf
│   │   ├── metric-events.tf
│   │   ├── slos.tf
│   │   └── synthetics.tf
│   └── app-bootstrap/             ← separate root: ECR + app IAM roles
│
├── gitops/                        ← ArgoCD-managed Kubernetes config
│   ├── bootstrap/root-app.yaml    ← THE file you apply once to bootstrap everything
│   ├── argocd/                    ← ArgoCD AppProject (RBAC per team)
│   ├── namespaces/                ← ApplicationSet: creates all namespaces
│   ├── networking/                ← AWS Load Balancer Controller
│   ├── secrets/external-secrets/  ← ESO + ClusterSecretStore
│   ├── auto-scaling/karpenter/    ← Karpenter
│   ├── monitoring/dynatrace/      ← Dynatrace Operator + DynaKube
│   ├── security/kyverno/          ← Kyverno security policies
│   └── app/payment-service/       ← The actual application
│
├── charts/                        ← Helm charts
│   ├── namespaces/                ← trivial chart to create namespace list
│   └── payment-service/           ← full app chart (deployment, service, ingress, HPA, PDB...)
│
├── app/                           ← Python microservice source code
│   ├── main.py
│   ├── requirements.txt
│   ├── Dockerfile
│   └── tests/
│
└── .github/workflows/
    ├── app-ci.yaml                ← CI: test → build → push ECR → update tag
    ├── terraform-infra.yaml       ← IaC: plan on PR, apply on merge
    └── terraform-dynatrace.yaml   ← DT config: plan on PR, apply on merge
```

---

## Verification: Platform Health in One Command

```bash
# Run this any time to check the health of the entire platform
echo "=== Platform Health Check ==="

# AWS Layer
echo "--- AWS ---"
aws eks describe-cluster --name company-prod --query 'cluster.status' --output text
aws eks list-nodegroups --cluster-name company-prod --query 'nodegroups[]' --output table

# Kubernetes Layer
echo "--- Kubernetes ---"
kubectl get nodes -o wide
kubectl get pods -A --field-selector=status.phase!=Running,status.phase!=Succeeded | \
  grep -v "^NAMESPACE" | head -20

# ArgoCD Layer
echo "--- ArgoCD ---"
argocd app list --grpc-web

# Dynatrace Layer
echo "--- Dynatrace ---"
DT_TENANT=$(aws secretsmanager get-secret-value \
  --secret-id production/dynatrace/tenant-url --query SecretString --output text)
DT_TOKEN=$(aws secretsmanager get-secret-value \
  --secret-id production/dynatrace/api-token --query SecretString --output text)
curl -s "${DT_TENANT}/api/v2/problems?problemSelector=status(OPEN)" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  python3 -c "import sys,json; d=json.load(sys.stdin); print(f'Open problems: {d.get(\"totalCount\",0)}')"
```
