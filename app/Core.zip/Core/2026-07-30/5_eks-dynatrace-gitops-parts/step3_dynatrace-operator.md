# Step 3: Dynatrace Operator — Automatic Observability

> **What this step builds:** Full-stack observability of the entire EKS cluster deployed as a single ArgoCD Application. Once running, Dynatrace OneAgent automatically discovers, instruments, and monitors every service — with zero code changes in the applications.

---

## Why OneAgent Over Prometheus-Only

```
Prometheus + Grafana approach:
  → Requires instrumenting EVERY application with metrics endpoints
  → Requires writing PromQL for every dashboard
  → Requires manually configuring scrape targets
  → Logs and metrics are completely separate (no automatic correlation)
  → No distributed tracing without additional tools (Jaeger/Zipkin)
  → Every new service needs manual setup

Dynatrace OneAgent approach:
  → Zero application code changes (OneAgent injects instrumentation)
  → Auto-discovery: every pod is monitored within 5 minutes
  → Logs, metrics, and traces are automatically correlated
  → Davis AI performs root cause analysis automatically
  → One DaemonSet pod per node covers everything
  → New services appear in Dynatrace automatically
```

---

## File: `gitops/monitoring/dynatrace/dynatrace-operator.yaml`

### The ArgoCD Application

```yaml
# This ArgoCD Application installs the Dynatrace Operator via Helm,
# then applies the DynaKube custom resource that configures what to monitor.

apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: dynatrace-operator
  namespace: argocd
  annotations:
    argocd.argoproj.io/sync-wave: "3"  # deploys AFTER ESO (wave 2) so the secret exists
spec:
  project: platform
  sources:
    # Source 1: Dynatrace Operator Helm chart
    - repoURL: https://raw.githubusercontent.com/Dynatrace/dynatrace-operator/main/config/helm/repos/stable
      targetRevision: 1.3.0          # PINNED — never use 'latest' in production
      chart: dynatrace-operator
      helm:
        values: |
          installCRD: true           # installs DynaKube, DynatraceAPI CRDs
          csidriver:
            enabled: true            # required for pod enrichment
    
    # Source 2: Our DynaKube configuration (in our own repo)
    - repoURL: https://github.com/company/eks-dynatrace-gitops-project
      targetRevision: main
      path: gitops/monitoring/dynatrace/config/  # contains dynakube.yaml

  destination:
    server: https://kubernetes.default.svc
    namespace: dynatrace
  
  syncPolicy:
    automated:
      selfHeal: true
    syncOptions:
      - CreateNamespace=true
      - ServerSideApply=true  # required for CRDs with large specs
```

---

## The DynaKube Resource — What Gets Deployed

```yaml
# gitops/monitoring/dynatrace/config/dynakube.yaml
# This is the "settings file" for the Dynatrace Operator.
# It tells the Operator: "deploy OneAgent in this mode with these options."

apiVersion: dynatrace.com/v1beta1
kind: DynaKube
metadata:
  name: dynakube
  namespace: dynatrace
spec:
  apiUrl: https://abc12345.live.dynatrace.com/api
  tokens: dynakube   # name of the K8s Secret containing apiToken + dataIngestToken
                     # this Secret is created by ESO (from AWS Secrets Manager)

  oneAgent:
    cloudNativeFullStack:  # deploys OneAgent as DaemonSet AND injects into pods
      env:
        - name: ONEAGENT_ENABLE_VOLUME_STORAGE
          value: "true"
      resources:
        requests:
          cpu: "100m"
          memory: "512Mi"
        limits:
          cpu: "500m"
          memory: "1Gi"

  activeGate:
    capabilities:
      - routing           # routes data from OneAgent to Dynatrace SaaS
      - kubernetes-monitoring  # K8s API server metrics (pod counts, events, etc.)
      - dynatrace-api     # exposes Dynatrace API locally (for scripting)
    replicas: 2           # HA: if one pod fails, data flow continues
    resources:
      requests:
        cpu: "500m"
        memory: "512Mi"
      limits:
        cpu: "1"
        memory: "1Gi"

  # Enable log monitoring (ships container logs to Dynatrace Grail)
  # THIS REPLACES FLUENT BIT — no separate log shipping DaemonSet needed
  logMonitoring:
    enabled: true

  # Enrich all entities with Kubernetes metadata
  metadataEnrichment:
    enabled: true   # adds namespace, pod name, labels to every metric/trace/log
```

### What each section does

```
oneAgent.cloudNativeFullStack:
  → Deploys a DaemonSet pod on every node (system + Karpenter-provisioned)
  → Injects instrumentation into application pods at startup
    (adds an init container that copies agent libs into the pod)
  → No application code changes needed
  → Captures: CPU, memory, HTTP response time, SQL queries, external calls
  → Captures: Distributed traces (PurePath) — end-to-end request tracking

activeGate:
  → 2 pods (HA) that act as intelligent proxies
  → OneAgent → ActiveGate → Dynatrace SaaS
  → Without ActiveGate: each OneAgent pod has a direct outbound connection
    (100 nodes = 100 connections to Dynatrace SaaS)
  → With ActiveGate: OneAgent → 2 ActiveGate pods → 2 connections to DT SaaS
    (much more efficient; required for enterprise deployments)
  → kubernetes-monitoring capability: reads K8s API server for pod events,
    node conditions, deployment status — complements the DaemonSet metrics

logMonitoring.enabled: true:
  → OneAgent reads /var/log/containers/*.log on every node
  → Ships logs to Dynatrace Grail
  → Automatically adds K8s metadata to every log line
  → Automatically correlates log lines with distributed traces
  → NO separate Fluent Bit DaemonSet needed
  → OneAgent does both metrics/traces AND logs from a single DaemonSet
```

---

## How the `dynakube` Secret Gets Created (ESO Chain)

```
This is the critical dependency chain that sync waves enforce:

Wave 2: ESO installs
  → ESO CRD is registered in the cluster

Wave 4: ClusterSecretStore creates
  → Tells ESO: "when someone asks for a secret, read it from
    AWS Secrets Manager in region ap-northeast-1
    using IRSA role eso-role (no static credentials)"

Wave 3: Dynatrace Operator deploys
  → Creates an ExternalSecret resource:
      secretStoreRef: ClusterSecretStore (from wave 4)
      Wait... wave 4 comes AFTER wave 3?
  
  → This is handled via separate Application with a later wave for the ExternalSecret
  → OR: the DynaKube references the secret name "dynakube"
         ESO creates the "dynakube" Secret at any point
         Once it exists, the DynaKube reconciler sees it and starts OneAgent

The ExternalSecret that creates the dynakube secret:
  apiVersion: external-secrets.io/v1beta1
  kind: ExternalSecret
  metadata:
    name: dynakube-secret
    namespace: dynatrace
  spec:
    refreshInterval: 1h
    secretStoreRef:
      name: cluster-secret-store
      kind: ClusterSecretStore
    target:
      name: dynakube     ← creates a K8s Secret named "dynakube"
    data:
      - secretKey: apiToken
        remoteRef:
          key: production/dynatrace/api-token    ← AWS Secrets Manager path
      - secretKey: dataIngestToken
        remoteRef:
          key: production/dynatrace/paas-token
```

---

## What OneAgent Auto-Discovers

```
After OneAgent DaemonSet is running and pods start on the cluster:

Within 2 minutes:
  → All EKS nodes appear in Dynatrace: Infrastructure → Hosts
  → Each node shows: CPU, memory, disk, network, K8s events

Within 5 minutes (after payment-service pods start):
  → payment-service appears as a "Service" in Dynatrace
    (auto-detected from HTTP traffic on the container's port)
  → Dynatrace shows: request rate, error rate, response time
  → First distributed traces (PurePaths) captured

Within 10 minutes:
  → Database calls from payment-service to its backend are captured
  → Dynatrace shows: which SQL queries, how long they took
  → External HTTP calls are captured (e.g., Stripe API calls)

Ongoing:
  → Every new pod that joins the cluster is automatically instrumented
  → Logs automatically appear in Dynatrace Grail (no configuration needed)
  → Davis AI builds baseline for normal behaviour (CPU, latency, error rate)
  → Any deviation from baseline → Davis creates a Problem → alerts fire
```

---

## Verification After Dynatrace Operator Deploys

```bash
# Check OneAgent DaemonSet is running on all nodes:
kubectl get daemonset -n dynatrace
# Expected: dynakube-oneagent  DESIRED=N CURRENT=N READY=N  (N = number of nodes)

# Check ActiveGate pods are running (should have 2 replicas):
kubectl get pods -n dynatrace -l component=activegate
# Expected: 2 pods in Running state

# Check the dynakube secret was created by ESO:
kubectl get secret dynakube -n dynatrace
# Expected: exists with type=Opaque, data keys: apiToken, dataIngestToken

# Check DynaKube status:
kubectl describe dynakube dynakube -n dynatrace | grep -A 20 "Status:"

# Check Dynatrace API: are EKS nodes appearing?
DT_TENANT=$(aws secretsmanager get-secret-value \
  --secret-id production/dynatrace/tenant-url --query SecretString --output text)
DT_TOKEN=$(aws secretsmanager get-secret-value \
  --secret-id production/dynatrace/api-token --query SecretString --output text)

curl -s "${DT_TENANT}/api/v2/entities?entitySelector=type(HOST)&pageSize=5" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  python3 -c "
import sys, json
d = json.load(sys.stdin)
print(f'EKS nodes in Dynatrace: {d.get(\"totalCount\", 0)}')
for e in d.get('entities', []):
    print(f'  {e[\"displayName\"]}')
"
```
