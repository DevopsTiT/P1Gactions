# EKS + Dynatrace + GitOps Project — Glossary

Every term used across all 7 step files, explained for an SRE beginner.

---

## Infrastructure and AWS

**VPC (Virtual Private Cloud)**
Your private network inside AWS. A logically isolated section of AWS Cloud where you launch resources. Defines IP address ranges, subnets, routing rules, and internet access controls.

**Subnet**
A range of IP addresses within a VPC locked to one Availability Zone. Public subnets have a route to the internet; private subnets route outbound traffic through a NAT Gateway.

**Availability Zone (AZ)**
A physically separate data centre within an AWS region. Using 3 AZs means your service survives a single data centre failure without downtime.

**NAT Gateway (Network Address Translation)**
Allows resources in private subnets (EKS nodes) to make outbound internet connections (downloading packages, pulling images) while remaining unreachable from the internet.

**VPC Endpoint**
A private connection from your VPC to an AWS service (S3, ECR, Secrets Manager) that stays within the AWS backbone — never touches the public internet. Cheaper and more secure than routing through NAT.

**EKS (Elastic Kubernetes Service)**
AWS's managed Kubernetes service. AWS manages the control plane (API server, etcd, scheduler); you manage worker nodes and workloads. Handles upgrades, patches, and HA of the control plane automatically.

**EKS Control Plane**
The Kubernetes master components managed by AWS: API server (receives kubectl commands), etcd (stores cluster state), scheduler (decides which node a pod runs on), controller manager.

**Private API Endpoint**
EKS configuration where the Kubernetes API server is only reachable from within the VPC. Prevents internet access to kubectl. More secure than public endpoint.

**OIDC Provider (OpenID Connect)**
An identity provider AWS creates for your EKS cluster. Allows Kubernetes service accounts to exchange a Kubernetes token for AWS IAM credentials (IRSA). Enables pod-level AWS permissions without instance profiles.

**IRSA (IAM Roles for Service Accounts)**
A mechanism where each Kubernetes pod gets its own scoped AWS IAM role. The pod calls AWS APIs using temporary credentials specific to its service account — not the node's shared IAM role.

**Instance Profile**
An IAM role attached to an EC2 instance (or EKS node). All pods on that node share these permissions. Less secure than IRSA because one compromised pod can access all the node's permissions.

**IAM Role**
An AWS identity with specific permissions. Not tied to a person — assumed by services, pods, or other AWS accounts. Issues temporary credentials (1-hour TTL) rather than long-lived keys.

**Secrets Manager**
AWS's managed service for storing sensitive values (passwords, API tokens, connection strings). Encrypts values with KMS. Supports automatic rotation. Access-controlled by IAM policies.

**KMS (Key Management Service)**
AWS's managed encryption key service. Encrypts Secrets Manager values, S3 state files, and EBS volumes. Keys never leave the HSM (hardware security module).

**ECR (Elastic Container Registry)**
AWS's managed Docker image registry. Private, access-controlled by IAM. Integrated with EKS for image pull. Stores image layers in S3 internally.

**SQS (Simple Queue Service)**
AWS's managed message queue. In this project: receives EC2 Spot interruption warnings so Karpenter can gracefully drain nodes before they're terminated.

**EventBridge**
AWS's event routing service. Routes EC2 Spot interruption events to the SQS queue that Karpenter monitors.

---

## Kubernetes Core

**Pod**
The smallest deployable unit in Kubernetes. Contains one or more containers that share a network namespace and storage. Ephemeral — replaced rather than modified.

**Deployment**
Manages a set of identical pods (replicas). Handles rolling updates, rollbacks, and self-healing. The primary way to run stateless applications.

**ReplicaSet**
Ensures a specified number of pod replicas are always running. Managed automatically by Deployments — rarely interacted with directly.

**DaemonSet**
Ensures one pod runs on every node in the cluster. Used for: monitoring agents (OneAgent), log collectors, node-level security tools. Automatically adds a pod when a new node joins.

**Service (Kubernetes)**
A stable network endpoint for a group of pods. Provides load balancing and a stable DNS name. Pods are ephemeral; Services are stable. Types: ClusterIP (internal), NodePort (node-level), LoadBalancer (cloud LB).

**Ingress**
A Kubernetes resource that defines HTTP routing rules. The AWS Load Balancer Controller reads Ingress objects and creates ALBs from them. Requires an Ingress Controller to actually implement the rules.

**Namespace**
A virtual partition within a cluster. Provides isolation for names, access control, and resource quotas. Best practice: one namespace per team or application.

**ServiceAccount**
A Kubernetes identity for a pod. Used for IRSA — the pod's service account is annotated with an IAM role ARN, and the Kubernetes OIDC token is exchanged for AWS credentials.

**HorizontalPodAutoscaler (HPA)**
Automatically scales the number of pods based on CPU utilisation, memory, or custom metrics. Requires resource requests to be set (otherwise cannot calculate utilisation percentage).

**PodDisruptionBudget (PDB)**
Limits how many pods can be simultaneously unavailable during voluntary disruptions (node drains, rolling updates). Protects service availability during maintenance operations.

**Topology Spread Constraints**
Rules that distribute pods across topology domains (AZs, nodes). `maxSkew: 1` with zone topology key ensures pods are spread evenly across AZs. Prevents all pods from landing in the same AZ.

**Pod Anti-Affinity**
A scheduling rule that prevents pods with matching labels from running on the same node. Combined with topology spread: ensures both AZ and node distribution.

**Rolling Update Strategy**
How Kubernetes replaces pods during a Deployment update. `maxUnavailable: 1` means at most 1 pod is down at any time. `maxSurge: 1` means at most 1 extra pod can exist during the update.

**Liveness Probe**
A check that tells Kubernetes whether a container is alive. If it fails (e.g., process deadlocked), Kubernetes restarts the container. Should check process health, NOT dependency health.

**Readiness Probe**
A check that tells Kubernetes whether a container is ready to receive traffic. If it fails, the pod is removed from Service endpoints. Should check dependency health (DB connection, etc.).

**Startup Probe**
A check run only during pod startup. Gives a slow-starting application time to initialise before liveness and readiness probes begin. Prevents premature restarts during JVM warmup or migration runs.

**Resource Requests**
The minimum CPU and memory a container needs — the scheduler uses these for bin-packing. HPA uses requests to calculate utilisation percentage. Must be set for HPA to work.

**Resource Limits**
The maximum CPU and memory a container can use. CPU throttling occurs at the limit. Memory OOMKill (container restart) occurs at the limit. Prevents runaway containers from consuming all node resources.

---

## Kubernetes Platform Components

**Karpenter**
A Kubernetes node autoscaler that provisions EC2 instances directly (~30s) based on pending pod resource requests. Selects the optimal instance type for each workload. More efficient than Cluster Autoscaler.

**Cluster Autoscaler**
An older Kubernetes node autoscaler. Works at the Auto Scaling Group level (~3 min to provision). Pre-requires defined node groups with specific instance types. Being replaced by Karpenter.

**AWS Load Balancer Controller (ALB Controller)**
A Kubernetes controller that reads Ingress resources and creates AWS Application Load Balancers. Uses IRSA for AWS permissions. Enables IP target mode (routes directly to pod IPs).

**External Secrets Operator (ESO)**
A Kubernetes operator that reads secrets from external stores (AWS Secrets Manager, Vault) and creates Kubernetes Secrets. Application pods reference the K8s Secret without knowing where it came from.

**ClusterSecretStore**
An ESO resource that configures connection to a secret backend. References an IAM role (via IRSA) for authentication. A single ClusterSecretStore serves all namespaces in the cluster.

**ExternalSecret**
An ESO custom resource that defines which external secret to fetch and what K8s Secret to create. The application references the created K8s Secret — never the ExternalSecret directly.

**Kyverno**
A Kubernetes security policy engine. Validates, mutates, or generates resources based on policies. Example: "all containers must have resource limits set" or "no privileged containers allowed."

**ExternalDNS**
A Kubernetes controller that automatically creates Route53 DNS records when you create a Service or Ingress with the right annotations. Eliminates manual DNS management.

---

## GitOps and ArgoCD

**GitOps**
An operational model where Git is the single source of truth for desired system state. All changes go through Git (PR → review → merge → automated apply). ArgoCD continuously reconciles the cluster to match Git.

**ArgoCD**
A declarative GitOps continuous delivery tool for Kubernetes. Watches a Git repo; when changes are detected, applies them to the cluster. Shows sync status, health, and diff between desired (Git) and actual (cluster) state.

**Application (ArgoCD)**
An ArgoCD resource that links a Git repo path to a Kubernetes destination. Defines: which repo, which branch, which path, which cluster, which namespace, and sync policy.

**ApplicationSet**
An ArgoCD resource that generates multiple Applications from a template and a list of parameters. One ApplicationSet generates one Application per team, per service, or per environment.

**App of Apps**
An ArgoCD pattern where a root Application points at a directory of Application resources. ArgoCD discovers and creates all child Applications automatically. Enables full platform recovery from a single `kubectl apply`.

**Sync Wave**
An integer annotation on ArgoCD resources that controls deployment order. Lower number deploys first. Wave N waits until all wave N-1 resources are Healthy before starting. Prevents race conditions in dependency chains.

**Sync Policy (selfHeal)**
ArgoCD configuration that automatically reverts manual changes to cluster resources. If someone runs `kubectl edit deployment payment-service`, ArgoCD restores the Git-defined state within minutes.

**Sync Policy (prune)**
ArgoCD configuration that deletes cluster resources when they are removed from Git. Prevents orphaned resources from accumulating.

**Health Status (ArgoCD)**
ArgoCD's assessment of whether a resource is functioning correctly: Healthy (running), Progressing (deploying), Degraded (failing), Missing (not in cluster), Suspended (paused).

**AppProject (ArgoCD)**
An ArgoCD resource that defines restrictions for a group of Applications: allowed source repos, allowed destination namespaces, allowed cluster-level resources. Provides RBAC at the GitOps level.

**Helm**
A Kubernetes package manager. Charts bundle related Kubernetes resources with templating (`{{ .Values.x }}`). Values files provide environment-specific parameters without duplicating templates.

**values.yaml**
The default configuration file for a Helm chart. Contains all tunable parameters. Can be overridden per environment without changing templates. GitHub Actions updates `image.tag` here on each build.

---

## CI/CD

**GitHub Actions**
GitHub's built-in CI/CD automation platform. Workflows defined in YAML files run on events (push, PR). Used for: running tests, building Docker images, pushing to ECR, running Terraform.

**OIDC Authentication (GitHub Actions → AWS)**
A mechanism where GitHub Actions exchanges a short-lived OIDC token for temporary AWS credentials. No long-lived AWS keys stored in GitHub Secrets. More secure than static keys.

**Commit SHA Tag**
Using the 40-character Git commit hash (shortened: first 8 chars) as the Docker image tag. Immutable — unlike `:latest`, it always refers to exactly one specific build. Enables precise rollbacks and audit trails.

**Terraform Plan**
A Terraform command that previews exactly what infrastructure changes will be made — without making them. Posted as a PR comment so reviewers can validate before approving the merge.

**Dangerous Destroy Check**
A CI step that fails if `terraform plan` would destroy stateful resources (EKS, VPC, RDS). Forces explicit human approval before any destructive change reaches production.

---

## Dynatrace Observability

**OneAgent**
Dynatrace's single monitoring agent. Deployed as a DaemonSet (one pod per node). Automatically discovers all processes, services, and containers. Captures metrics, traces, and logs — no code changes required.

**DaemonSet OneAgent**
Deploys OneAgent as a DaemonSet. Every pod on every node gets OneAgent's monitoring capabilities through injection of the agent libraries at pod startup.

**PurePath**
Dynatrace's term for distributed traces. Captures the full request journey across all services, showing each method call, SQL query, and external API call with precise timing.

**Davis AI**
Dynatrace's AI/ML engine. Learns the normal behaviour of every metric. Detects anomalies, groups related problems, and identifies root causes automatically.

**Grail**
Dynatrace's unified data lake. Stores all logs, metrics, traces, and events. Queryable via DQL (Dynatrace Query Language). Replaces the need for separate ELK/Loki stacks.

**DynaKube**
The Kubernetes custom resource that configures Dynatrace deployment on a cluster. Specifies: which OneAgent mode, ActiveGate capabilities, log monitoring settings, and which K8s secret to use for authentication.

**ActiveGate**
A Dynatrace component that acts as an intelligent proxy. Routes data from OneAgents to Dynatrace SaaS. Reduces the number of outbound connections from your cluster. Enables Kubernetes API monitoring.

**Management Zone**
A Dynatrace filter that scopes entities (services, hosts) to a team. Only entities matching the zone's rules appear in that team's dashboards and trigger that team's alerts.

**SLO (Service Level Objective)**
A target for service reliability: "99.9% of requests to payment-service must succeed in a 7-day rolling window." Dynatrace tracks SLOs in real time and calculates the remaining error budget.

**Error Budget**
The allowed amount of unreliability within an SLO period. 99.9% SLO = 0.1% can fail = 43.2 minutes/month. When exhausted, reliability work takes priority over feature development.

**Burn Rate**
How quickly the SLO error budget is being consumed. A rate of 14× means the budget will be exhausted 14× faster than expected — page now and investigate.

**Synthetic Monitor**
An automated test that checks if a service is reachable from Dynatrace's global infrastructure. Runs even if your cluster is completely down. Provides external visibility that internal monitoring cannot.

**Alerting Profile**
A Dynatrace filter that determines which Problems trigger notifications and with what delay. Critical profiles have 0 delay (immediate page). Warning profiles have a 5+ minute delay to filter transient spikes.

**Problem**
Dynatrace's incident-level event. Davis AI groups related anomalies into one Problem to prevent alert storms. Contains: root cause entity, affected services, evidence, and timeline.
