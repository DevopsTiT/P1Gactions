# Step 4: Terraform Dynatrace Config — Monitoring as Code

> **What this step builds:** ALL Dynatrace configuration — management zones, alerting profiles, PagerDuty/Slack notifications, per-service metric alerts, SLOs, and synthetic monitors — defined as Terraform code. Zero clicks in the Dynatrace UI.

---

## Why Terraform for Dynatrace Config (Not the UI)

```
UI-only Dynatrace configuration:

  Engineer A clicks through the UI to create alerting profiles for payment-service.
  She leaves the company.
  New engineer joins: "Where are the alert configurations? Why are there no SLOs?"
  Cannot reconstruct what was set up without asking everyone what they remember.
  
  Staging environment gets set up 6 months later.
  Nobody remembers the exact configuration from production.
  Staging has different thresholds, different zones, different notification rules.
  "It alerts in staging but not in production" = wasted investigation time.

Terraform Dynatrace configuration:
  All configuration in .tf files → Git → PR review → apply.
  New engineer joins: reads variables.tf → understands entire monitoring setup.
  Staging: call the same Terraform code with different workspace.
  Adding a service: add one block to variables.tf → PR → merge → all DT config created.
  Recovery after DT tenant wipe: terraform apply → everything restored in minutes.
```

---

## File: `terraform/dynatrace/main.tf` — The Services Map

### The central data structure

```hcl
# Every service in the platform is defined in this map.
# All DT configuration for that service is derived from this one entry.

variable "services" {
  type = map(object({
    team             = string
    slo_target       = number
    error_rate_alert = number  # % threshold for error rate alert
    latency_p99_ms   = number  # ms threshold for P99 latency alert
    health_check_url = string  # URL for synthetic HTTP monitor
  }))
  default = {
    "payment-service" = {
      team             = "payments"
      slo_target       = 99.9          # 99.9% of requests must succeed
      error_rate_alert = 0.5           # alert when error rate > 0.5%
      latency_p99_ms   = 500           # alert when P99 > 500ms
      health_check_url = "https://payment.company.com/health"
    }

    "orders-service" = {
      team             = "orders"
      slo_target       = 99.5
      error_rate_alert = 1.0           # orders can tolerate slightly more errors
      latency_p99_ms   = 800           # orders is a slower service
      health_check_url = "https://orders.company.com/health"
    }
    
    # Adding a new service = adding one block here
    # → PR → merge → terraform apply creates:
    #   management zone membership (if team zone exists)
    #   error rate alert
    #   P99 latency alert
    #   SLO (99.x% over 7 days)
    #   synthetic HTTP health check monitor
  }
}
```

---

## File: `terraform/dynatrace/management-zones.tf`

```hcl
# One management zone per team.
# A management zone scopes which entities a team sees in dashboards and alerts.
# Without management zones: everyone sees everything → noise.
# With zones: payments team sees only payments entities.

# Get unique team names from the services map:
locals {
  teams = distinct([for svc in var.services : svc.team])
  # Result: ["payments", "orders", "inventory", "platform"]
}

resource "dynatrace_management_zone_v2" "team" {
  for_each = toset(local.teams)    # creates one zone per team

  name = "${each.key} Team — ${var.environment}"
  # e.g., "payments Team — production"

  rules {
    # Rule 1: Services tagged with team:<team_name>
    rule {
      type    = "ME"
      enabled = true
      attribute_rule {
        entity_type = "SERVICE"
        attribute_conditions {
          attribute    = "SERVICE_TAGS"
          operator     = "EQUALS"
          string_value = "team:${each.key}"
        }
      }
    }

    # Rule 2: Hosts in the team's host group
    rule {
      type    = "ME"
      enabled = true
      attribute_rule {
        entity_type = "HOST"
        attribute_conditions {
          attribute    = "HOST_GROUP_NAME"
          operator     = "CONTAINS"
          string_value = each.key
        }
      }
    }

    # Rule 3: Synthetic monitors tagged for this team
    rule {
      type    = "ME"
      enabled = true
      attribute_rule {
        entity_type = "SYNTHETIC_TEST"
        attribute_conditions {
          attribute    = "SYNTHETIC_TEST_TAGS"
          operator     = "EQUALS"
          string_value = "team:${each.key}"
        }
      }
    }
  }
}
```

---

## File: `terraform/dynatrace/alerting-profiles.tf`

```hcl
# Two profiles per team:
# CRITICAL: fires immediately → PagerDuty (wakes someone up)
# WARNING: fires with delay → Slack (for next-morning review)

resource "dynatrace_alerting" "critical" {
  for_each = toset(local.teams)

  name = "${each.key} — CRITICAL"

  filters {
    filter {
      severity = "AVAILABILITY"   # service completely down
      delay { minutes = 0 }       # page immediately
      text { operator = "CONTAINS"; value = "" }
    }
    filter {
      severity = "ERROR"           # error rate spike
      delay { minutes = 0 }
      text { operator = "CONTAINS"; value = "" }
    }
  }

  management_zones = [dynatrace_management_zone_v2.team[each.key].id]
}

resource "dynatrace_alerting" "warning" {
  for_each = toset(local.teams)

  name = "${each.key} — WARNING"

  filters {
    filter {
      severity = "PERFORMANCE"        # latency degradation
      delay { minutes = 5 }            # wait 5 min before alerting (transient spikes)
      text { operator = "CONTAINS"; value = "" }
    }
    filter {
      severity = "RESOURCE_CONTENTION"  # CPU/memory pressure
      delay { minutes = 10 }
      text { operator = "CONTAINS"; value = "" }
    }
  }

  management_zones = [dynatrace_management_zone_v2.team[each.key].id]
}
```

---

## File: `terraform/dynatrace/metric-events.tf`

```hcl
# Error rate alert per service (for_each over all services):
resource "dynatrace_metric_events" "error_rate" {
  for_each = var.services

  enabled              = true
  event_entity_dimension_key = "dt.entity.service"
  event_type           = "PERFORMANCE"
  summary              = "${each.key} — Error Rate > ${each.value.error_rate_alert}%"

  metric_selector      = "builtin:service.errors.total.rate:avg:names"
  alert_condition      = "ABOVE"
  threshold            = each.value.error_rate_alert    # from services map

  model_properties {
    type               = "STATIC_THRESHOLD"
    violating_samples  = 5    # must exceed threshold 5 consecutive minutes
    samples            = 5
    dealerting_samples = 3    # must be below threshold 3 consecutive minutes to resolve
  }

  management_zones = [
    dynatrace_management_zone_v2.team[each.value.team].id
  ]
}

# P99 latency alert per service:
resource "dynatrace_metric_events" "latency_p99" {
  for_each = var.services

  enabled              = true
  event_entity_dimension_key = "dt.entity.service"
  event_type           = "PERFORMANCE"
  summary              = "${each.key} — P99 Latency > ${each.value.latency_p99_ms}ms"

  metric_selector      = "builtin:service.response.time:percentile(99)"
  alert_condition      = "ABOVE"
  threshold            = each.value.latency_p99_ms * 1000  # DT uses microseconds

  model_properties {
    type               = "STATIC_THRESHOLD"
    violating_samples  = 5
    samples            = 5
    dealerting_samples = 3
  }

  management_zones = [
    dynatrace_management_zone_v2.team[each.value.team].id
  ]
}
```

---

## File: `terraform/dynatrace/slos.tf`

```hcl
# SLO per service (availability = % of successful requests):
resource "dynatrace_slo_v2" "availability" {
  for_each = var.services

  name        = "${each.key} Availability SLO"
  enabled     = true
  description = "99.x% of ${each.key} requests must succeed over 7 days"

  target    = each.value.slo_target          # e.g., 99.9
  warning   = each.value.slo_target - 0.05  # warning at 99.85

  # SLI: percentage of successful requests
  metric_expression = "(100)*(builtin:service.errors.total.successCount:filter(and(in(\"dt.entity.service\",entitySelector(\"type(SERVICE),tag(\\\"service:${each.key}\\\")\"))))):"

  timeframe = "-7d"    # rolling 7-day window

  error_budget_burn_rate {
    fast_burn_threshold              = 14   # alert if burning 14x faster than normal
    burn_rate_visualization_enabled = true
  }
}
```

---

## File: `terraform/dynatrace/synthetics.tf`

```hcl
# HTTP health check monitor per service:
resource "dynatrace_http_monitor" "health_check" {
  for_each = var.services

  name     = "${each.key} — Health Check"
  enabled  = true
  frequency = 1    # check every 1 minute

  locations = [
    "GEOLOCATION-1001",  # Tokyo
    "GEOLOCATION-1002",  # Singapore
    "GEOLOCATION-1003",  # Sydney
  ]

  anomaly_detection {
    outage_handling {
      global_outage = true
      global_outage_policy {
        consecutive_runs = 2  # page after 2 consecutive failures (2 minutes)
      }
      local_outage = true
      local_outage_policy {
        affected_locations = 2  # page if 2+ locations fail
        consecutive_runs   = 3
      }
    }

    loading_time_thresholds {
      enabled = true
      loading_time_threshold {
        type     = "TOTAL"
        value_ms = each.value.latency_p99_ms  # reuse the same latency threshold
      }
    }
  }

  script {
    request {
      description = "Health check"
      url         = each.value.health_check_url
      method      = "GET"
      configuration {
        accept_any_certificate = false
        follow_redirects       = true
      }
      validation {
        rule {
          type          = "httpStatusesList"
          value         = "200"
          pass_if_found = true
        }
      }
    }
  }

  tags {
    tag {
      context = "CONTEXTLESS"
      key     = "service"
      value   = each.key
    }
    tag {
      context = "CONTEXTLESS"
      key     = "team"
      value   = each.value.team
    }
  }
}
```

---

## Running the Dynatrace Terraform

```bash
cd terraform/dynatrace/

# Set credentials (read from Secrets Manager, never hardcode):
export TF_VAR_dynatrace_env_url=$(aws secretsmanager get-secret-value \
  --secret-id production/dynatrace/tenant-url --query SecretString --output text)
export TF_VAR_dynatrace_api_token=$(aws secretsmanager get-secret-value \
  --secret-id production/dynatrace/api-token --query SecretString --output text)

terraform init
terraform plan   # review: management zones + alerting profiles + SLOs + synthetics

# Expected plan output:
# + dynatrace_management_zone_v2.team["payments"]
# + dynatrace_management_zone_v2.team["orders"]
# + dynatrace_alerting.critical["payments"]
# + dynatrace_alerting.warning["payments"]
# + dynatrace_metric_events.error_rate["payment-service"]
# + dynatrace_metric_events.latency_p99["payment-service"]
# + dynatrace_slo_v2.availability["payment-service"]
# + dynatrace_http_monitor.health_check["payment-service"]
# ... (same for orders-service)

terraform apply

# Verify Dynatrace config:
DT_TENANT=$(aws secretsmanager get-secret-value \
  --secret-id production/dynatrace/tenant-url --query SecretString --output text)
DT_TOKEN=$(aws secretsmanager get-secret-value \
  --secret-id production/dynatrace/api-token --query SecretString --output text)

# Check management zones:
curl -s "${DT_TENANT}/api/v1/managementZones" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  python3 -c "import sys,json; d=json.load(sys.stdin); print('MZs:', len(d.get('values', [])))"

# Check SLOs:
curl -s "${DT_TENANT}/api/v2/slo?pageSize=10" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  python3 -c "import sys,json; d=json.load(sys.stdin); print('SLOs:', d.get('totalCount', 0))"

# Check synthetic monitors:
curl -s "${DT_TENANT}/api/v2/synthetic/monitors?pageSize=10" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | \
  python3 -c "import sys,json; d=json.load(sys.stdin); print('Monitors:', d.get('totalCount', 0))"
```
