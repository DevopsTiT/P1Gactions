# Step 1: Terraform Infrastructure — AWS Foundation

> **What this step builds:** The entire AWS foundation — VPC with multi-AZ networking, EKS cluster, IAM roles for each Kubernetes component (IRSA), Secrets Manager secrets for Dynatrace tokens, Karpenter autoscaling infrastructure. This must be complete before anything in Kubernetes can run.

---

## Why Terraform for This (Not CDK, Not Console)

```
Two engineers need to create identical staging and production environments.

Without Terraform:
  Engineer A clicks through AWS console for prod.
  Engineer B clicks through for staging.
  They remember different things. Environments diverge.
  "It works in staging but not in prod" — because staging is missing a VPC endpoint.
  Nobody can prove they're the same.

With Terraform:
  module "vpc" { source = "./modules/vpc"; cidr = "10.0.0.0/16" }   ← prod
  module "vpc" { source = "./modules/vpc"; cidr = "10.1.0.0/16" }   ← staging
  Same module, different variable values.
  Guaranteed identical structure.
  `terraform plan` shows EXACTLY what will change before it changes.
```

---

## File: `terraform/main.tf` — The Orchestrator

### What it does

```
main.tf is the top-level file that orchestrates everything.
It doesn't create resources directly — it calls modules.

Structure:
  1. Providers block: AWS (which region + account)
  2. Locals: cluster_name, common_tags (applied to every resource)
  3. module "vpc": calls ./modules/vpc with prod-specific values
  4. module "eks": calls ./modules/eks, passes vpc.outputs as inputs
  5. data "aws_caller_identity": gets the AWS account ID (for ARN construction)
  6. data "aws_availability_zones": gets AZs dynamically (not hardcoded)
```

### Why two modules instead of one big file

```
Single-file approach (anti-pattern):
  main.tf: 1,200 lines
  → Anyone changing EKS config risks accidentally breaking VPC config
  → Cannot reuse VPC logic for a different project
  → Impossible to unit test

Module approach (correct):
  module "vpc":
    Input: cidr_block, azs, enable_nat_gateway
    Output: vpc_id, private_subnet_ids, public_subnet_ids
    → Completely isolated; VPC changes don't touch EKS code
    → Reusable: staging calls the same module with a different CIDR
  
  module "eks":
    Input: vpc_id (from vpc.outputs), cluster_name, k8s_version
    Output: cluster_endpoint, oidc_provider_arn, cluster_ca_certificate
    → Isolated; EKS changes don't touch VPC code
```

```bash
# Verify the modules are connected correctly after apply:
terraform output
# Should show:
# cluster_endpoint = "https://abc123.gr7.ap-northeast-1.eks.amazonaws.com"
# cluster_name     = "company-prod"
# oidc_issuer_url  = "https://oidc.eks.ap-northeast-1.amazonaws.com/id/..."
# vpc_id           = "vpc-0abc123..."
# private_subnet_ids = ["subnet-0a...", "subnet-0b...", "subnet-0c..."]
```

---

## File: `terraform/modules/vpc/main.tf` — The Network Foundation

### What gets created

```
VPC (10.0.0.0/16 = 65,536 IP addresses):
  Public subnets (3, one per AZ):  10.0.1.0/24, 10.0.2.0/24, 10.0.3.0/24
    → Internet-facing ALBs live here
    → NAT Gateways live here (EC2 nodes use them for outbound internet)
    → One Elastic IP per NAT Gateway

  Private subnets (3, one per AZ): 10.0.11.0/24, 10.0.12.0/24, 10.0.13.0/24
    → EKS worker nodes live here (no public IPs)
    → Outbound-only internet via NAT Gateway
    → Required tags: kubernetes.io/role/internal-elb=1 (for ALB target routing)

  Internet Gateway: one per VPC (public subnet internet access)

  NAT Gateway: one per AZ (resilient outbound for private subnets)
    WHY ONE PER AZ: if AZ-a fails, nodes in AZ-b and AZ-c still have outbound

VPC Endpoints (private connectivity to AWS services without NAT):
  S3 Gateway endpoint:          ECR stores image layers in S3; this avoids NAT cost
  ECR API endpoint:             docker pull without NAT Gateway
  ECR Docker endpoint:          docker pull image layers without NAT Gateway
  Secrets Manager endpoint:     pods read secrets without NAT Gateway
  STS endpoint:                 IRSA token exchange without internet
  CloudWatch Logs endpoint:     log shipping without NAT Gateway

WHY VPC ENDPOINTS:
  Without them: all AWS API calls from pods go NAT → internet → AWS service
  With them: all AWS API calls go through the VPC backbone
  → Cheaper (no NAT data processing charges)
  → Faster (lower latency, no internet hop)
  → More secure (traffic never leaves AWS network)
```

```bash
# Verify VPC endpoints after apply:
aws ec2 describe-vpc-endpoints \
  --filters "Name=vpc-id,Values=$(terraform output -raw vpc_id)" \
  --query 'VpcEndpoints[*].{Service:ServiceName,State:State,Type:VpcEndpointType}' \
  --output table
# Should show 6+ endpoints in available state

# Verify NAT Gateways (one per AZ):
aws ec2 describe-nat-gateways \
  --filter "Name=vpc-id,Values=$(terraform output -raw vpc_id)" \
  --query 'NatGateways[*].{ID:NatGatewayId,AZ:SubnetId,State:State}' \
  --output table
```

---

## File: `terraform/modules/eks/main.tf` — The Kubernetes Cluster

### What gets created

```
EKS Control Plane:
  K8s version: 1.30
  API endpoint: PRIVATE (only reachable from within the VPC or VPN)
  Logging: API server, audit, controller manager, scheduler → CloudWatch
  
  WHY PRIVATE API:
    Public API = the Kubernetes API server is exposed on the internet
    → Brute-force attacks against kubectl
    → Requires strict network policies + RBAC to compensate
    
    Private API = only reachable from within your VPC
    → No internet exposure
    → kubectl access via VPN or bastion (or AWS SSO + kubeconfig)

Managed Node Group (system nodes):
  Instance type: m5.large (2 vCPU, 8GB RAM)
  Min: 3, Max: 6, Desired: 3 (one per AZ minimum)
  Labels: role=system
  Taints: role=system:NoSchedule
    → Only pods with toleration role=system schedule here
    → Prevents application pods from landing on system nodes
    → Ensures ArgoCD, ESO, ALB Controller always have dedicated capacity

OIDC Provider:
  EKS creates an OIDC issuer URL.
  Terraform creates an IAM Identity Provider for it.
  This is what enables IRSA (IAM Roles for Service Accounts).
  
  Without OIDC/IRSA: pods share the node's IAM instance profile
  With OIDC/IRSA: each pod gets its own scoped IAM role
```

```bash
# Verify cluster is running and healthy:
aws eks describe-cluster \
  --name company-prod \
  --query 'cluster.{Status:status,Version:version,Endpoint:endpoint,Logging:logging}' \
  --output json

# Verify OIDC provider is configured:
aws iam list-open-id-connect-providers --query 'OpenIDConnectProviderList[*].Arn'
# Should show an ARN containing your EKS cluster ID

# Verify system node group:
aws eks describe-nodegroup \
  --cluster-name company-prod \
  --nodegroup-name system \
  --query 'nodegroup.{Status:status,Desired:scalingConfig.desiredSize,Min:scalingConfig.minSize}'
```

---

## File: `terraform/karpenter.tf` — Node Autoscaling Infrastructure

### Why Karpenter over Cluster Autoscaler

```
Cluster Autoscaler:
  Works at the node GROUP level.
  To scale up: must pre-define node groups with specific instance types.
  Scale-out time: ~3 minutes (waits for ASG to add the node).
  Cannot mix instance types within a group easily.

Karpenter:
  Works at the individual EC2 instance level.
  Karpenter reads the pending pod's resource requests.
  It selects the optimal instance type for EXACTLY that workload.
  Scale-out time: ~30 seconds.
  Can use any instance type, Spot or On-Demand, automatically.

Example:
  payment-service pod requests: 2 CPU, 4GB RAM
  Cluster Autoscaler: adds an m5.xlarge (4 CPU, 16GB) → wastes 50% capacity
  Karpenter: provisions a c5.large (2 CPU, 4GB) → exactly what the pod needs
```

### What terraform/karpenter.tf creates

```
1. IAM Role for Karpenter Controller (IRSA):
   - Trust policy: only karpenter ServiceAccount in karpenter namespace can assume it
   - Permissions: EC2 RunInstances, TerminateInstances, DescribeInstances, SSM GetParameter
   - This is HOW Karpenter provisions/terminates EC2 nodes

2. IAM Role for Karpenter-provisioned Nodes:
   - The role that NEW nodes launched by Karpenter will use
   - Attached policies: EKS Worker Node Policy, CNI Policy, ECR ReadOnly
   - Without this: newly provisioned nodes can't join the EKS cluster

3. SQS Queue (EC2 Spot Interruption Handling):
   - AWS sends 2-minute warning before reclaiming Spot instances
   - EventBridge rule forwards the interruption event to this SQS queue
   - Karpenter reads the queue and gracefully drains the node BEFORE it's reclaimed
   - Without this: Spot interruption = abrupt pod termination

4. EventBridge Rules:
   - EC2 Spot Interruption Warning → SQS
   - Instance Rebalance Recommendation → SQS
   - EC2 Instance State-change (terminating) → SQS
```

```bash
# Verify Karpenter IAM role exists:
aws iam get-role --role-name KarpenterControllerRole-company-prod \
  --query 'Role.{Name:RoleName,Created:CreateDate}' --output table

# Verify SQS queue for interruptions:
aws sqs get-queue-attributes \
  --queue-url $(aws sqs get-queue-url --queue-name karpenter-interruption-company-prod --query QueueUrl --output text) \
  --attribute-names QueueArn
```

---

## Files: `terraform/irsa-*.tf` — IAM Roles for Service Accounts

### The IRSA Pattern Explained

```
Without IRSA (node instance profile approach):
  All pods on node-1 share the role: NodeInstanceRole
  NodeInstanceRole has: S3 ReadWrite, Secrets Manager ReadWrite, ECR Read
  
  If payment-service pod is compromised:
    Attacker has access to ALL S3 buckets the node can reach
    Attacker has access to ALL secrets the node can read
    Attacker can access ALL ECR repos
  
  This is the blast radius: the entire node's permissions.

With IRSA:
  payment-service pod → assumes role: PaymentServiceRole
    PaymentServiceRole only has: read secrets from prod/payment/* path
  
  orders-service pod → assumes role: OrdersServiceRole
    OrdersServiceRole only has: read secrets from prod/orders/* path
  
  If payment-service pod is compromised:
    Attacker only has payment service permissions.
    Cannot reach orders secrets. Cannot write to S3. Cannot modify ECR.
  
  Blast radius: one service's permissions.

How IRSA works:
  1. EKS creates an OIDC token for the pod (signed by the EKS OIDC issuer)
  2. Pod calls AWS STS with: AssumeRoleWithWebIdentity(token, role_arn)
  3. IAM verifies: does the OIDC token come from OUR EKS cluster?
                   does the token belong to THIS service account in THIS namespace?
  4. If yes: IAM issues temporary credentials (1 hour TTL, auto-rotated)
  5. Pod's AWS SDK uses these credentials transparently
```

### irsa-lbc.tf (AWS Load Balancer Controller)

```
IAM role name: AWSLoadBalancerControllerRole
Trust policy condition:
  OIDC issuer = your EKS cluster
  Subject = system:serviceaccount:kube-system:aws-load-balancer-controller

Permissions granted:
  elasticloadbalancing:CreateLoadBalancer       ← creates ALBs from Ingress objects
  elasticloadbalancing:CreateTargetGroup        ← creates target groups
  elasticloadbalancing:RegisterTargets          ← registers pod IPs as targets
  ec2:DescribeSubnets                           ← finds which subnets to use
  ec2:DescribeSecurityGroups                    ← finds security groups
  acm:ListCertificates                          ← finds ACM certs for HTTPS
  wafv2:AssociateWebACL                         ← attaches WAF to ALB
  ... (full list: ~50 permissions)

WHY SEPARATE ROLE:
  If someone compromises the ALB Controller:
  → They can create and modify load balancers
  → They CANNOT read secrets, create EC2 instances, or access EKS cluster
```

```bash
# Verify IRSA roles after apply:
for ROLE in AWSLoadBalancerControllerRole ExternalDNSRole ExternalSecretsRole; do
  aws iam get-role --role-name "${ROLE}-company-prod" \
    --query 'Role.{Name:RoleName,Created:CreateDate}' 2>/dev/null || \
    echo "${ROLE} not found"
done

# Verify the trust policy uses the correct OIDC issuer:
aws iam get-role --role-name AWSLoadBalancerControllerRole-company-prod \
  --query 'Role.AssumeRolePolicyDocument.Statement[0].Condition' --output json
```

---

## File: `terraform/secrets-manager.tf` — Dynatrace Token Storage

### What it creates and why

```
Creates THREE secret containers in AWS Secrets Manager:
  1. production/dynatrace/api-token
     → Used by Terraform to manage Dynatrace configuration via API
     → Scopes needed: Read config, Write config, Access problems

  2. production/dynatrace/paas-token
     → Used by Dynatrace OneAgent to authenticate back to DT tenant
     → Scopes needed: PaaS integration - Installer download

  3. production/dynatrace/tenant-url
     → The Dynatrace environment URL (e.g., https://abc123.live.dynatrace.com)

IMPORTANT: Terraform creates the SECRET RESOURCE (named container) only.
The ACTUAL VALUES must be set separately:
  aws secretsmanager put-secret-value \
    --secret-id production/dynatrace/api-token \
    --secret-string "dt0c01.XXXXXX..."

WHY NOT PUT VALUES IN TERRAFORM:
  If values were in terraform.tfvars:
    → They'd be in the Terraform state file (S3)
    → S3 state is versioned; old versions retain the secrets forever
    → Anyone with S3 access reads all secrets
  
  With Secrets Manager:
    → Values encrypted with KMS (separate from state)
    → IAM controls who can read each secret
    → Automatic rotation support
    → CloudTrail logs every access (audit trail)
    → The Kubernetes ESO reads these and creates K8s Secrets at runtime
```

```bash
# Set the actual values after terraform apply (done once):
aws secretsmanager put-secret-value \
  --secret-id production/dynatrace/api-token \
  --secret-string "dt0c01.XXXXXXXXXXXXXXXXXXXXXX.YYYY"

aws secretsmanager put-secret-value \
  --secret-id production/dynatrace/paas-token \
  --secret-string "dt0c11.AAAAAAAAAAAAAAAAAAAA.BBBB"

aws secretsmanager put-secret-value \
  --secret-id production/dynatrace/tenant-url \
  --secret-string "https://abc12345.live.dynatrace.com"

# Verify values are set (never print the actual secret value):
for SECRET in api-token paas-token tenant-url; do
  CREATED=$(aws secretsmanager describe-secret \
    --secret-id "production/dynatrace/${SECRET}" \
    --query 'CreatedDate' --output text 2>/dev/null)
  echo "${SECRET}: ${CREATED:-NOT_FOUND}"
done
```

---

## Running the Infrastructure Terraform

```bash
# Step 1: Bootstrap (one-time setup of Terraform backend)
aws s3api create-bucket \
  --bucket company-terraform-state \
  --region ap-northeast-1 \
  --create-bucket-configuration LocationConstraint=ap-northeast-1

aws s3api put-bucket-versioning \
  --bucket company-terraform-state \
  --versioning-configuration Status=Enabled

aws dynamodb create-table \
  --table-name terraform-state-lock \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region ap-northeast-1

# Step 2: Apply infrastructure
cd terraform/
terraform init      # downloads providers, configures S3 backend
terraform plan      # review what will be created (~50 resources)
terraform apply     # takes 15-20 minutes (EKS control plane is slow)

# Step 3: Configure kubectl
aws eks update-kubeconfig \
  --name company-prod \
  --region ap-northeast-1

# Step 4: Verify cluster is ready
kubectl get nodes
# Expected: 3 nodes (system node group) in Ready state

# Step 5: Set Dynatrace secret values (see above)
```

---

## Common Terraform Mistakes and How to Avoid Them

| Mistake | Consequence | Prevention |
|---|---|---|
| `terraform apply` from a laptop in production | No audit trail; risk of applying the wrong state | All applies via GitHub Actions pipeline; laptop = plan only |
| No S3 versioning on state bucket | State corruption = unrecoverable | Enable versioning before first `terraform init` |
| No DynamoDB lock | Two engineers apply simultaneously → state corruption | Always configure `dynamodb_table` in backend.tf |
| Secrets in `terraform.tfvars` | Secrets in S3 state → readable by anyone with S3 access | Use Secrets Manager; reference by name only in Terraform |
| Using default node group for all workloads | System pods compete with app pods; system pods evicted under pressure | System node group with taints; Karpenter for app nodes |
