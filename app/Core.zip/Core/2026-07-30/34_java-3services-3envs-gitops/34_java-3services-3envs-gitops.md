# Java 3 Services × 3 Environments — GitOps Project

> **3 independent Spring Boot microservices** (order, payment, notification), each with its own CI/CD pipeline, Helm chart, and ArgoCD Application — promoted across dev → staging → production in 3 separate AWS accounts.

---

## E2E Flow Summary

```
Developer pushes code to services/payment-service/**
          │
          ▼
.github/workflows/payment-service-ci.yaml   (runs independently per service)
          │
          ├─ Job 1: Unit tests + JaCoCo 70% coverage gate
          │         Path filter: only runs when THIS service's code changes
          │
          ├─ Job 2: Build → push to DEV ECR → sed updates gitops/dev/app/payment-service/
          │         ArgoCD dev cluster syncs → rolling update in payment-ns
          │
          ├─ Job 3: Smoke test dev (/actuator/health/liveness + /readiness + API)
          │
          ├─ Job 4: docker pull dev ECR → docker push staging ECR
          │         sed updates gitops/staging/app/payment-service/
          │         ArgoCD staging cluster syncs
          │
          ├─ Job 5: k6 load test staging (50 VUs, p99 < 800ms)
          │
          ├─ Job 6: MANUAL APPROVAL (GitHub Environment: production)
          │         → reviewer approves → workflow resumes
          │
          ├─ Job 7: docker pull staging ECR → docker push production ECR
          │         sed updates gitops/production/app/payment-service/
          │         ArgoCD production cluster syncs → rolling update (3 replicas)
          │
          └─ Job 8: Verify production smoke tests → FAIL → auto git revert → rollback
```

All three services (order, payment, notification) run **identical pipeline structure** but in **parallel and independently**. A change to notification-service does NOT trigger payment-service CI.

---

## Decision Tree — Which File Controls What

```
Q: What changes the image deployed to dev?
   → gitops/dev/app/<service>/<service>.yaml (tag: field, updated by CI)

Q: What changes pod resource limits?
   → charts/<service>/values.yaml (base) or values-dev/staging.yaml (overrides)

Q: What changes the number of replicas?
   → values.yaml (replicaCount) + HPA in charts/<service>/templates/hpa.yaml

Q: What changes AWS node types?
   → terraform/environments/<env>/terraform.tfvars

Q: What creates the Kubernetes namespaces?
   → gitops/<env>/namespaces/namespaces.yaml (sync-wave: -1)

Q: What bootstraps ArgoCD per environment?
   → gitops/<env>/bootstrap/root-app-<env>.yaml (applied once manually)

Q: Why does a service only redeploy when its own code changes?
   → paths: filter in .github/workflows/<service>-ci.yaml
```

---

## Tool Map

| Tool | Where | What it does |
|------|-------|--------------|
| GitHub Actions | `.github/workflows/` | Builds, tests, promotes each service |
| ArgoCD | `gitops/` | Watches git; applies changes to EKS clusters |
| Helm | `charts/` | Templates Kubernetes manifests per service/env |
| Terraform | `terraform/` | Provisions EKS clusters + Dynatrace alerts |
| ECR | AWS | Separate container registry per AWS account |
| k6 | CI job 5 | Load tests staging (50 VUs, 3 min) |
| Trivy | CI job 2 | Scans built image for CVEs before deploy |
| JaCoCo | CI job 1 | Enforces 70% Java test coverage gate |
| IRSA | `values.yaml` | Pod-level AWS permissions via ServiceAccount annotation |

---

## Part 1 — 3 Services Architecture

### Why 3 separate services (not 1 monolith)

```
order-service       → handles order creation, status, cancellation
payment-service     → handles payment processing, refunds
notification-service → handles email/SMS/push notifications

Each:
  - Has its own database credentials (separate Secrets Manager secret)
  - Has its own IAM role (IRSA) — payment-service cannot read notification-service secrets
  - Has its own CI pipeline — a bug in order-service does not block payment-service CI
  - Has its own Helm chart — different resource limits (notification is lighter than payment)
  - Has its own ArgoCD Application per environment (9 total: 3 services × 3 envs)
```

### Path filters — why each service only deploys its own changes

```yaml
# payment-service-ci.yaml
on:
  push:
    paths: ['services/payment-service/**', 'charts/payment-service/**']
```

```
If you only change notification-service code:
  payment-service-ci.yaml does NOT trigger.
  order-service-ci.yaml does NOT trigger.
  Only notification-service-ci.yaml triggers.

WHY THIS MATTERS:
  Without path filters: every commit triggers all 3 pipelines.
  3 pipelines × 8 jobs each = 24 concurrent CI jobs for a one-line change.
  Path filters: only the changed service's 8 jobs run.
  Faster CI, clearer audit trail, no risk of deploying unintended services.
```

---

## Part 2 — CI Pipeline Per Service (8 Jobs)

### Job 1: Unit Tests + JaCoCo

```yaml
- uses: actions/setup-java@v4
  with: { java-version: '21', distribution: 'temurin', cache: 'gradle' }
- uses: actions/cache@v4
  with:
    path: services/payment-service/app/.gradle
    key: ${{ runner.os }}-gradle-payment-${{ hashFiles('services/payment-service/app/build.gradle') }}
- name: Run tests + coverage
  working-directory: services/payment-service/app
  run: ./gradlew test jacocoTestReport jacocoTestCoverageVerification --no-daemon
```

```
working-directory: services/payment-service/app:
  3-service repo: each service lives under services/<name>/app/.
  Without working-directory: Gradle runs from repo root → cannot find build.gradle.

cache key per-service (gradle-payment-):
  order, payment, notification all have separate .gradle cache keys.
  Changing order-service/build.gradle does NOT invalidate payment-service's Gradle cache.
  Each service's dependency cache is independent.

jacocoTestCoverageVerification:
  Gradle fails with exit code 1 if line coverage < 70%.
  All subsequent jobs (build, deploy) have needs: test.
  Untested code cannot be shipped. The gate is automatic at the job dependency level.
```

### Job 2: Build + Push Dev ECR + Update GitOps

```yaml
- uses: docker/build-push-action@v5
  with:
    context: services/payment-service/app/
    platforms: linux/amd64,linux/arm64
    tags: ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }},${{ env.ECR_DEV }}:latest-dev
    cache-from: type=gha
    cache-to: type=gha,mode=max

- name: Update dev gitops tag
  run: |
    sed -i "s|tag: \".*\"|tag: \"${{ env.IMAGE_TAG }}\"|" \
      gitops/dev/app/payment-service/payment-service.yaml
    git diff --staged --quiet || git commit -m "chore(deploy-dev): payment-service=${{ env.IMAGE_TAG }} [skip ci]"
    git push
```

```
context: services/payment-service/app/:
  Docker build context is scoped to this service's directory only.
  payment-service Dockerfile does not accidentally include order-service source.

platforms: linux/amd64,linux/arm64:
  Both Intel (amd64) and ARM Graviton (arm64) images in a single manifest.
  EKS Graviton nodes (m7g, m6g) pull arm64 automatically.
  No separate CI jobs for each architecture.

latest-dev tag (plus SHA tag):
  SHA tag: immutable, traceable, used by ArgoCD.
  latest-dev: mutable shorthand for "newest dev build" — useful for debugging.
  ArgoCD uses the SHA tag only. latest-dev is for engineers pulling locally.

[skip ci]:
  Without this: CI sees a push to main (the gitops commit) → triggers the same pipeline again.
  With [skip ci]: GitHub Actions skips the workflow for this commit → no infinite loop.

git diff --staged --quiet || git commit:
  If the image tag did not change (same SHA, re-run of same commit): no diff, no commit.
  Prevents empty commits cluttering gitops history.
```

### Job 5: k6 Load Test (Staging)

```yaml
- name: Load test (50 VUs, 3 min)
  run: |
    sleep 30   # JIT warmup
    k6 run --vus 50 --duration 3m \
      --env BASE_URL=https://payment.staging.company.com \
      services/payment-service/app/tests/load/payment-load-test.js
```

```
sleep 30 before load test:
  JVM JIT compiler runs for ~30 seconds after startup.
  During JIT: first requests are interpreted → 3-10× slower than steady state.
  If load test starts during JIT: p99 exceeds 800ms → test fails on a healthy service.
  sleep 30: JIT completes → load test sees real steady-state performance.

50 VUs for staging payment:
  payment-service: each VU submits an HTTP POST /api/v1/payments.
  50 simultaneous payments = reasonable pre-production load signal.
  Does NOT validate production scale (production may see 500-5000 VUs).
  Purpose: catch obvious capacity regressions before production, not prove prod capacity.
```

### Job 6: Manual Approval Gate

```
GitHub Environment "production" with Required Reviewers:
  Configure: GitHub → Repo Settings → Environments → production → Required reviewers.

When Job 6 reaches "environment: production":
  Workflow PAUSES. No code runs.
  GitHub sends email + Slack notification to approvers.
  Approvers see: which SHA, that staging load test passed, link to CI run.
  Approve → Job 7 starts (promote to production).
  Reject → workflow stops, no production deploy.

WHY MANUAL APPROVAL:
  Automated tests cannot catch: wrong deploy window (Friday 5pm), known incident,
  code that passed tests but violates a business rule.
  Human judgment is the final gate before money-handling code goes live.
```

### Job 8: Auto-Rollback

```yaml
- name: Auto-rollback on failure
  if: failure() && steps.smoke.outcome == 'failure'
  run: |
    PREV_TAG=$(git log --oneline -- gitops/production/app/payment-service/payment-service.yaml \
      | awk 'NR==2{print $1}' | xargs git show \
      | grep 'tag:' | head -1 | sed 's/.*tag: "\(.*\)".*/\1/')
    sed -i "s|tag: \".*\"|tag: \"$PREV_TAG\"|" \
      gitops/production/app/payment-service/payment-service.yaml
    git commit -m "chore(rollback-prod): payment-service revert to $PREV_TAG [skip ci]"
    git push
```

```
git log NR==2:
  NR==1 = current (bad) commit.
  NR==2 = previous (good) commit.
  Reads the tag: value from the PREVIOUS commit of this file.
  No kubectl rollout undo needed — Git is the source of truth.

ArgoCD detects the new commit → applies → Kubernetes rolling update back to old image.
Zero manual intervention: failure in production smoke test → rollback starts automatically.
Engineers are notified (CI job failed + rollback commit visible in git history).
```

---

## Part 3 — Helm Charts (Per Service, 3 Values Files)

### Service Differences in Helm

```
payment-service:   replicaCount: 3 (prod), Xmx: 1024m  — heaviest (DB + payment logic)
order-service:     replicaCount: 3 (prod), Xmx: 768m   — medium (order state machine)
notification-service: replicaCount: 2 (prod), Xmx: 512m — lightest (async fire-and-forget)
```

### values.yaml (Production Defaults) — Key Sections

```yaml
startupProbe:
  httpGet: { path: /actuator/health/liveness, port: 8080 }
  failureThreshold: 60    # 60 × 10s = 10 min max startup
  periodSeconds: 10

lifecycle:
  preStop:
    exec:
      command: ["/bin/sh", "-c", "sleep 15"]
terminationGracePeriodSeconds: 60

topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: topology.kubernetes.io/zone
    whenUnsatisfiable: DoNotSchedule   # HARD in production
```

```
failureThreshold: 60 (10 min):
  Java Spring Boot cold start on first pod (empty JVM code cache): 2-8 minutes.
  JVM init + Spring classpath scan + Hibernate schema validation + HikariCP pool: adds up.
  10 min covers worst-case cold start on Graviton nodes.

preStop sleep 15s:
  ALB deregistration takes 10-15 seconds.
  Without preStop: pod shuts down → Tomcat closes → ALB still routes in-flight requests → 503.
  15s sleep: gives ALB time to drain connections before Spring shuts down Tomcat.

DoNotSchedule (hard spread):
  With 3 replicas: 1 pod MUST be in each AZ.
  AZ-a outage: exactly 1 pod lost, 2 remain → service survives.
  Without hard spread: 2 pods could land in AZ-a → AZ-a outage = 66% capacity lost.
```

### values-dev.yaml (Overrides for Dev)

```yaml
replicaCount: 1
resources:
  requests: { cpu: 100m, memory: 384Mi }
  limits:   { cpu: 500m, memory: 512Mi }
env:
  - { name: JVM_OPTS, value: "-Xms128m -Xmx256m -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005" }
  - { name: LOG_LEVEL, value: "DEBUG" }
  - { name: SHOW_SQL, value: "true" }
startupProbe:
  failureThreshold: 120   # 20 min: dev node + expired caches = very slow cold start
pdb:
  enabled: false
topologySpreadConstraints:
  - whenUnsatisfiable: ScheduleAnyway   # SOFT: dev may have only 1 node
```

```
-agentlib:jdwp (debug port 5005):
  Enables remote Java debugger.
  kubectl port-forward pod/<name> 5005:5005 → attach IntelliJ debugger.
  suspend=n: JVM does NOT wait for debugger to connect → pod still starts normally.
  Without suspend=n: pod waits forever for debugger → never passes startupProbe → CrashLoopBackOff.
  ONLY in dev. Never in staging or production (security + performance risk).

pdb: enabled: false:
  PDB with minAvailable=1 on a 1-replica deployment = node can NEVER be drained.
  Karpenter cannot consolidate. EKS upgrades block.
  1 replica in dev → disable PDB entirely. Pod can be evicted freely.

SHOW_SQL: true:
  Spring/Hibernate logs every SQL query to stdout.
  Dev: see exactly what queries your code generates → catch N+1 query bugs early.
  Production: 1000 req/min × 5 queries/req = 5000 SQL log lines/min → never enable.
```

---

## Part 4 — GitOps Structure (ArgoCD Per Environment)

### 9 ArgoCD Applications (3 services × 3 environments)

```
gitops/
  dev/
    bootstrap/root-app-dev.yaml          ← apply once → bootstraps all dev apps
    namespaces/namespaces.yaml           ← sync-wave: -1 (runs first)
    app/
      order-service/order-service.yaml
      payment-service/payment-service.yaml
      notification-service/notification-service.yaml

  staging/   (same structure)
  production/ (same structure)
```

### root-app-*.yaml — The Bootstrap File

```yaml
spec:
  source:
    path: gitops/dev
    directory:
      recurse: true
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
```

```
Applied ONCE manually per environment (kubectl apply -f root-app-dev.yaml).
After that: ArgoCD manages everything itself.

recurse: true:
  ArgoCD scans ALL yaml files under gitops/dev/ recursively.
  Add a new service: create gitops/dev/app/new-service/new-service.yaml → discovered automatically.

prune: true:
  Remove a file from gitops/dev/ → the resource it manages is deleted from the cluster.
  Prevents ghost resources accumulating ("why is this old service still running?").

selfHeal: true:
  Engineer runs kubectl edit on a pod spec → ArgoCD reverts within 3 minutes.
  Forces all changes through Git. Direct kubectl changes are temporary.
```

### sync-wave: -1 (Namespaces First)

```yaml
# gitops/dev/namespaces/namespaces.yaml
annotations:
  argocd.argoproj.io/sync-wave: "-1"
```

```
ArgoCD deploys resources in wave order: -1, then 0, then 1, 2, ..., 8.

Why namespaces need wave -1:
  order-service Deployment targets namespace: order-ns.
  If order-ns does not exist yet: Deployment fails with "namespace not found".
  Wave -1 runs BEFORE any application (wave 8).
  Namespace always exists before any pod tries to schedule into it.
```

### ArgoCD Application — ignoreDifferences

```yaml
ignoreDifferences:
  - group: apps
    kind: Deployment
    jsonPointers:
      - /spec/replicas
```

```
HPA (HorizontalPodAutoscaler) continuously adjusts spec.replicas based on CPU.
ArgoCD desired state: spec.replicas=3 (from Helm values.yaml).
HPA sets: spec.replicas=7 (load spike).

Without ignoreDifferences:
  ArgoCD sees drift (7 ≠ 3) → immediately scales back to 3.
  HPA scales to 7 → ArgoCD scales back to 3 → HPA scales to 7 → infinite fight.
  Service degrades under load while ArgoCD and HPA fight.

With ignoreDifferences on /spec/replicas:
  ArgoCD ignores the replicas field entirely → HPA wins → service scales correctly.
```

---

## Part 5 — Terraform (Infrastructure + Monitoring)

### Environment Differences

| Setting | Dev | Staging | Production |
|---------|-----|---------|------------|
| Node types | t3.medium, t3a.medium | m6g.large, m6g.xlarge | m7g.xlarge, m7g.2xlarge |
| Min nodes | 2 | 3 | 3 |
| Max nodes | 5 | 10 | 15 |
| VPC CIDR | 10.10.0.0/16 | 10.11.0.0/16 | 10.12.0.0/16 |
| DT latency p99 | 2000ms | 800ms | 300ms |
| DT heap alert | 80% | 78% | 70% |
| Traffic min | 0 (disabled) | 2 rps | 10 rps |

### Non-overlapping VPC CIDRs

```
10.10.0.0/16 (dev)
10.11.0.0/16 (staging)
10.12.0.0/16 (production)

WHY NON-OVERLAPPING:
  VPC peering (direct cross-VPC routing) requires non-overlapping CIDR blocks.
  Overlapping CIDRs = peering impossible → cannot add cross-env connectivity later without VPC recreation.
  VPC recreation: requires destroying and recreating EKS clusters → major outage.
  Non-overlapping from day 1: peering can be added in 30 minutes if ever needed.
```

### Dynatrace Alert Thresholds Per Environment

```
production: latency_p99_ms = 300
  SLO: 99% of requests complete in < 300ms.
  Alert fires when p99 exceeds 300ms → engineers investigate immediately.

staging: latency_p99_ms = 800
  k6 load test: first 30s JIT warmup → latency up to 3× higher than steady state.
  800ms: accommodates warmup without false alerts. After 30s: steady state ~200ms.
  If threshold = 300ms: EVERY staging CI run triggers an alert → engineers ignore alerts.

dev: latency_p99_ms = 2000
  Dev JVM on t3.medium + debug port 5005 overhead + cold caches: much slower.
  2000ms: only fires on genuinely broken behaviour, not normal dev slowness.
  Alert fatigue is the enemy: if alerts always fire, engineers learn to ignore them.
```

---

## Common Mistakes

| Mistake | Symptom | Fix |
|---------|---------|-----|
| No `[skip ci]` in gitops commit | Infinite CI loop (pipeline triggers itself) | Add `[skip ci]` to the gitops update commit message |
| Missing `ignoreDifferences` on `/spec/replicas` | HPA and ArgoCD fight; service degrades under load | Add `ignoreDifferences` to ArgoCD Application |
| `pdb: enabled: true` with 1 replica in dev | Node drain blocked forever; EKS upgrades hang | Set `pdb: enabled: false` in values-dev.yaml |
| Wrong Actuator path (`/health/live` not `/actuator/health/liveness`) | Probe returns 404 → endless restart → CrashLoopBackOff | Check Spring Actuator docs: path is `/actuator/health/liveness` |
| `suspend=n` missing from jdwp in dev | Pod waits for debugger → never passes startupProbe → killed | Always add `suspend=n` to jdwp agent string |
| `DoNotSchedule` topology spread in dev (1 node) | Pod stuck in Pending forever | Use `ScheduleAnyway` in values-dev.yaml |
| No path filter in CI workflow | Every commit triggers all 3 service pipelines | Add `paths:` filter scoped to this service's directories |
| `latest-dev` used as ArgoCD image tag | ArgoCD sees no change (tag did not change) → no deploy | ArgoCD must use the immutable SHA tag, not `latest-dev` |
