# Glossary — Java 3 Services × 3 Environments GitOps

Every term, tool, and component mentioned in the main doc. One entry per term: name, definition, why it matters.

---

**Spring Boot**
A Java framework that auto-configures a web server and database connections so you write less boilerplate. Why it matters: all 3 services (order, payment, notification) are Spring Boot apps — every Spring-specific setting (Actuator, JVM, Hibernate) in this project comes from this framework.

**Microservice**
A small, independently deployable application that does one thing. Why it matters: splitting the system into order-service, payment-service, and notification-service means each can be deployed, scaled, and failed independently — a bug in notification does not take down payment.

**GitHub Actions**
A CI/CD system built into GitHub that runs automated jobs (tests, builds, deploys) when code is pushed. Why it matters: this project has 3 workflows (one per service) that build and promote code from dev to production.

**CI (Continuous Integration)**
The practice of automatically testing and building code every time it is pushed. Why it matters: catches bugs before they reach production.

**CD (Continuous Delivery/Deployment)**
Automatically promoting a tested build through environments. Why it matters: removes manual copy-paste deploy steps that are error-prone.

**Path filter (`paths:` in workflow)**
A setting that tells GitHub Actions to only trigger a workflow when files in specific directories change. Why it matters: without it, changing one service's code triggers all 3 pipelines — wasteful and confusing.

**ECR (Elastic Container Registry)**
AWS's container image registry — a place to store and pull Docker images. Why it matters: each AWS account (dev, staging, production) has its own ECR; an image must be explicitly copied between them, preventing accidental cross-environment deploys.

**IMAGE_TAG (`github.sha`)**
The full Git commit SHA used as the Docker image tag (e.g., `a1b2c3d4...`). Why it matters: every image is unique and traceable — "which code is running in production?" → look up the tag → `git show <sha>` → exact code.

**Docker multi-platform build (`linux/amd64,linux/arm64`)**
Building a single Docker image that works on both Intel and ARM processors. Why it matters: EKS Graviton (ARM) nodes pull the arm64 layer automatically — no separate build jobs needed.

**Trivy**
A security scanner that checks Docker images for known CVEs (Common Vulnerabilities and Exposures). Why it matters: catches vulnerable dependencies before they reach Kubernetes; exit-code 1 blocks the deploy if CRITICAL or HIGH CVEs are found.

**JaCoCo**
A Java code coverage tool that measures what percentage of your code is tested. Why it matters: the pipeline enforces 70% line coverage — if tests don't cover enough code, the build fails and no image is built.

**Gradle**
A build tool for Java projects — downloads dependencies, compiles, runs tests, packages JARs. Why it matters: all 3 services use Gradle; CI runs `./gradlew test` and `./gradlew build` to produce deployable artifacts.

**Gradle daemon (`--no-daemon`)**
A background Gradle process that stays alive between builds to speed up repeated builds. Why it matters: in CI containers the daemon provides no benefit (container dies after one build), so `--no-daemon` saves ~200MB RAM.

**JUnit**
The standard Java testing framework. Why it matters: tests are written in JUnit; JaCoCo measures their coverage; CI fails if tests fail.

**Actuator**
A Spring Boot module that exposes health check and metrics HTTP endpoints automatically. Why it matters: Kubernetes probes use `/actuator/health/liveness` and `/actuator/health/readiness` to know if a pod is alive and ready to serve traffic.

**Liveness probe**
Kubernetes checks this URL to know if the JVM (Java process) is still running. Why it matters: if liveness fails, Kubernetes kills and restarts the pod. Path: `/actuator/health/liveness`.

**Readiness probe**
Kubernetes checks this URL to know if the pod is ready to receive traffic (e.g., DB connection is healthy). Why it matters: if readiness fails, the pod is removed from the load balancer — traffic stops going to it until it recovers.

**Startup probe**
A special probe that only runs at pod startup. Kubernetes does NOT kill the pod for failing this probe until `failureThreshold × periodSeconds` seconds have passed. Why it matters: Java takes 1-10 minutes to start; without a startup probe with high `failureThreshold`, Kubernetes kills it before it finishes starting.

**JVM (Java Virtual Machine)**
The runtime that executes Java code. Why it matters: Java does not compile directly to machine code — it compiles to bytecode, and the JVM runs that bytecode. All memory settings (Xmx, G1GC) configure the JVM.

**JIT (Just-In-Time compilation)**
The JVM automatically compiles frequently-run code to native machine code while the program is running. Why it matters: for the first ~30 seconds after startup, the JVM interprets code (slower); after JIT warms up, performance is 5-20× faster. CI waits `sleep 30` before tests to avoid false failures during warmup.

**Xmx / Xms**
JVM flags that set maximum (`-Xmx`) and initial (`-Xms`) heap size. Why it matters: if Xmx is too large, the JVM uses more RAM than the container limit allows → OOM (Out of Memory) kill. If too small → frequent garbage collection → slow response times.

**Heap**
The area of JVM memory where Java objects live. Why it matters: most JVM memory problems are heap-related — if heap fills up, garbage collection runs constantly (slow) or the JVM crashes with OutOfMemoryError.

**G1GC**
The default Java garbage collector since Java 9. Runs in small, incremental pauses instead of one long stop-the-world pause. Why it matters: `-XX:MaxGCPauseMillis=200` tunes G1GC to target pauses under 200ms, keeping API latency stable.

**`-XX:+UseContainerSupport`**
JVM flag that makes the JVM read its memory limit from the container (cgroup), not the host machine. Why it matters: without this, a JVM in a 1.5GB container sees the host's 32GB RAM and tries to use 8GB heap → immediate OOM kill.

**`-XX:MaxRAMPercentage=75.0`**
JVM flag: use at most 75% of the container's memory limit for the heap. Why it matters: leaves 25% for non-heap memory (metaspace, thread stacks, code cache) — prevents total JVM memory from exceeding the container limit.

**OOM (Out of Memory)**
When a process uses more memory than allowed, the Linux kernel kills it. In Kubernetes: the pod status shows `OOMKilled`. Why it matters: this is the most common Java production incident — caused by heap too large for container limit or memory leak.

**ArgoCD**
A GitOps tool that watches a Git repository and keeps a Kubernetes cluster synchronized with what is in Git. Why it matters: this project has one ArgoCD instance per environment (dev, staging, production); CI updates Git files and ArgoCD deploys the changes automatically.

**GitOps**
The practice of storing all infrastructure and deployment configuration in Git and using automated tools to apply changes from Git to live systems. Why it matters: Git becomes the single source of truth — you can see exactly what is deployed by reading the repo, and rollbacks are just git reverts.

**ArgoCD Application**
A Kubernetes custom resource that tells ArgoCD which Git path to watch and which Kubernetes cluster to deploy to. Why it matters: there are 9 Applications in this project (3 services × 3 environments) — each one independently tracks a different service in a different cluster.

**sync-wave**
An ArgoCD annotation that controls the order in which resources are deployed. Lower numbers deploy first. Why it matters: namespaces use wave `-1` so they exist before any pods (wave `8`) try to schedule into them — without this ordering, pods fail with "namespace not found".

**root-app-*.yaml (App of Apps)**
A single ArgoCD Application that watches an entire folder and discovers all child Applications in it automatically. Applied once manually to bootstrap an environment. Why it matters: after bootstrap, adding a new service to the cluster is just adding a YAML file to the gitops folder — no manual `kubectl apply` needed.

**prune: true (ArgoCD)**
ArgoCD deletes cluster resources when the corresponding YAML file is removed from Git. Why it matters: prevents orphaned resources (old services, forgotten Deployments) from accumulating in the cluster.

**selfHeal: true (ArgoCD)**
ArgoCD automatically reverts manual `kubectl edit` changes. Why it matters: enforces GitOps discipline — all changes must go through Git, not direct kubectl commands.

**Helm**
A Kubernetes package manager. You define templates once and fill in different values per environment. Why it matters: all 3 services use Helm charts — `templates/deployment.yaml` is written once; `values-dev.yaml` and `values-staging.yaml` customize it per environment.

**values.yaml (Helm base)**
The default (production) configuration file for a Helm chart. Why it matters: dev and staging override only the fields they need to change; everything else inherits production defaults automatically.

**values-dev.yaml / values-staging.yaml**
Environment-specific Helm value overrides. Why it matters: smaller resources for dev (saves cost), different log levels per env, debugging tools only in dev — controlled without duplicating entire YAML files.

**HPA (HorizontalPodAutoscaler)**
A Kubernetes controller that automatically adds or removes pod replicas based on CPU usage. Why it matters: under load (e.g., k6 test in staging), HPA scales from 2 to 8 pods; without it, pods could be overwhelmed.

**`ignoreDifferences` (ArgoCD)**
Tells ArgoCD to ignore changes to specific fields when comparing desired vs actual state. Why it matters: HPA changes `spec.replicas` dynamically; without `ignoreDifferences`, ArgoCD immediately reverts HPA's scaling decisions, causing a continuous fight between ArgoCD and HPA.

**PDB (PodDisruptionBudget)**
A Kubernetes policy that limits how many pods of a service can be unavailable at once during voluntary disruptions (node drains, upgrades). Why it matters: in production, PDB ensures at least 2 of 3 replicas are always running — a node upgrade cannot take down the entire service.

**Karpenter**
A Kubernetes node autoscaler that provisions new EC2 nodes when pods cannot be scheduled (not enough node capacity). Why it matters: under load, HPA adds pods; if no node has space, Karpenter provisions a new node automatically. Also decommissions underused nodes to save cost.

**IRSA (IAM Roles for Service Accounts)**
Lets a Kubernetes pod assume an AWS IAM role without using static AWS credentials. Why it matters: payment-service gets a specific IAM role that allows reading only its own database credentials from Secrets Manager — another service's pod cannot access payment's secrets.

**Namespace**
A Kubernetes construct that groups resources and isolates them. `payment-ns` holds all payment-service resources; `order-ns` holds order-service. Why it matters: prevents naming collisions and allows per-team access control.

**OTEL (OpenTelemetry)**
An open standard for collecting traces and metrics from applications. Why it matters: each service sends traces to Dynatrace via `OTEL_EXPORTER_OTLP_ENDPOINT` — enables distributed tracing across all 3 services.

**Dynatrace**
An observability platform that ingests metrics, traces, and logs from the services. Why it matters: Terraform creates Dynatrace metric alerts per environment with different thresholds (p99 latency, heap usage, traffic).

**Terraform**
Infrastructure-as-Code tool that creates and manages cloud resources declaratively. Why it matters: this project uses Terraform to provision EKS clusters and Dynatrace alert configurations — reproducible, version-controlled infrastructure.

**terraform.tfvars**
A Terraform variable file that sets environment-specific values (node types, VPC CIDR, min/max nodes). Why it matters: `dev/terraform.tfvars`, `staging/terraform.tfvars`, `production/terraform.tfvars` configure 3 different clusters from the same Terraform module.

**VPC (Virtual Private Cloud)**
An isolated network inside AWS where EC2 instances and EKS clusters live. Why it matters: each environment has its own VPC with a non-overlapping CIDR block, which allows future VPC peering without network conflicts.

**CIDR block**
A way to express an IP address range (e.g., `10.10.0.0/16` = 65,536 addresses). Why it matters: dev, staging, and production use different /16 ranges so they never overlap — required for VPC peering to work.

**k6**
An open-source load testing tool. Runs virtual users (VUs) that send HTTP requests in parallel. Why it matters: staging CI runs a 3-minute k6 test with 50 VUs to validate the service handles concurrent load before production promotion.

**VU (Virtual User)**
A simulated concurrent user in a k6 load test. Why it matters: 50 VUs means 50 HTTP connections hitting the service simultaneously — tests basic concurrency handling.

**p99 latency**
The 99th percentile response time — 99% of requests complete in this time or less. Why it matters: measures worst-case user experience; if p99 > 300ms in production, something is wrong.

**preStop hook**
A command Kubernetes runs inside a pod before sending the SIGTERM shutdown signal. Why it matters: `sleep 15` gives the ALB 15 seconds to stop routing traffic to this pod before Spring Boot shuts down — prevents in-flight requests from getting 503 errors.

**terminationGracePeriodSeconds**
How long Kubernetes waits after SIGTERM before force-killing a pod (SIGKILL). Why it matters: 60 seconds gives Spring Boot time to finish in-flight requests, close DB connections, and run JVM shutdown hooks cleanly.

**ALB (Application Load Balancer)**
AWS's HTTP load balancer that distributes incoming traffic across pods. Why it matters: the ALB needs 10-15 seconds to deregister a pod before it stops sending traffic — the preStop sleep accounts for this delay.

**Rolling update**
Kubernetes replaces pods one at a time — creates new pod, waits for it to be ready, then removes old pod. Why it matters: zero-downtime deploys — traffic never drops to zero during an update.

**CrashLoopBackOff**
A Kubernetes status meaning a pod keeps crashing and Kubernetes keeps restarting it with increasing delays. Why it matters: common causes in this project — wrong startup probe path (404), missing `suspend=n` in jdwp, heap too small for container limit.

**`[skip ci]`**
A string in a Git commit message that tells GitHub Actions to NOT trigger workflows for that commit. Why it matters: CI commits a gitops tag update back to the repo — without `[skip ci]`, this triggers the same CI pipeline again, creating an infinite loop.

**JDWP (Java Debug Wire Protocol)**
The standard protocol for remote Java debugging. Enabled with `-agentlib:jdwp=...` JVM flag. Why it matters: allows IntelliJ or any IDE to connect to a running JVM in the dev cluster and set breakpoints. Never used in staging or production (security risk).

**Topology spread constraints**
Kubernetes settings that control how pods are distributed across nodes and availability zones. Why it matters: with `DoNotSchedule` (hard), Kubernetes refuses to place 2 pods in the same AZ — ensures AZ fault tolerance. With `ScheduleAnyway` (soft), it tries to spread but co-locates if necessary — used in dev where there may be only 1 node.

**AZ (Availability Zone)**
A physically separate data center within an AWS region. Why it matters: AZ outages are the most common AWS incident — spreading pods across 3 AZs means 1 AZ failure loses only 1/3 of capacity.

**Graviton (m6g, m7g)**
AWS ARM-based processors. Better price/performance than x86 (Intel/AMD) for most workloads. Why it matters: staging uses m6g, production uses m7g; both use ARM64 architecture, which is why the Docker build includes `linux/arm64`.

**OIDC (OpenID Connect)**
An authentication protocol used by GitHub Actions to get temporary AWS credentials without storing long-lived access keys. Why it matters: `id-token: write` permission + `configure-aws-credentials` action uses OIDC to assume an IAM role securely.

**HikariCP**
The default JDBC connection pool in Spring Boot — maintains a pool of ready-to-use database connections. Why it matters: Spring Boot startup includes HikariCP establishing minimum connections to RDS/PostgreSQL — adds 5-10 seconds to startup time, which is why startup probes need long timeouts.

**Hibernate**
The ORM (Object-Relational Mapper) used by Spring Boot to map Java classes to database tables. Why it matters: at startup, Hibernate scans all entity classes and validates the schema — adds 10-15 seconds to Java startup time.

**CVE (Common Vulnerabilities and Exposures)**
A numbered database entry describing a known security vulnerability in a software package. Why it matters: Trivy checks container images against the CVE database — CRITICAL or HIGH CVEs block the deploy.

**ArgoCD AppProject**
A resource that restricts which namespaces and clusters an ArgoCD Application can deploy to. Why it matters: `project: payment-team` limits payment-service to deploy only to `payment-ns` — prevents accidental deploys to `kube-system` or another team's namespace.

**ServerSideApply (ArgoCD sync option)**
A Kubernetes API feature where the server (not the client) manages field ownership during `kubectl apply`. Why it matters: avoids conflicts when multiple controllers (ArgoCD, HPA, Karpenter) all manage different fields of the same Deployment object.

**Smoke test**
A quick sanity check after a deploy — hits the key endpoints to verify the service is alive and responding. Why it matters: 3 checks after each deploy (liveness, readiness, API endpoint) catch broken deploys in seconds without running the full test suite again.

**Auto-rollback**
CI automatically reverts a bad deploy by reading the previous Git commit's image tag and pushing a revert commit. Why it matters: if production smoke tests fail, rollback starts within seconds without requiring a human to wake up and manually intervene.
