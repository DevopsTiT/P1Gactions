# Threshold Calibration Guide — Glossary

**Threshold calibration**
The process of finding the right number to use in an alert rule — not too sensitive (fires for normal noise = alert fatigue) and not too loose (misses real problems). Always based on observed baseline data, not guessing.

**Baseline**
The normal behaviour of a metric over 7–14 days of real traffic. Includes the minimum (quiet periods), average (typical), and maximum (peak load). All alert thresholds should be derived from the baseline, not invented from scratch.

**Alert fatigue**
When alerts fire so often for non-problems that engineers start ignoring them. The most dangerous failure mode in monitoring — during a real incident, the relevant alert is missed because engineers are desensitised to constant noise.

**`traffic_min_rps`**
Minimum expected requests per minute for a service. Alert fires when traffic drops BELOW this value for 3+ consecutive minutes. The ONLY signal that catches silent outages where error rate looks healthy because there are no requests.

**Silent outage**
A service failure where error rate is 0% because no traffic is reaching the service. Caused by DNS failure, ALB misconfiguration, or a deployment that never started. Only detectable by monitoring traffic volume.

**`error_rate_alert`**
HTTP 5xx error rate threshold as a decimal percentage (0.5 = 0.5%). Alert fires when the percentage of requests returning 5xx status codes exceeds this value. Tighter thresholds for revenue-critical services.

**`latency_p99_ms`**
P99 response time threshold in milliseconds. Alert fires when the 99th percentile of response times exceeds this. P99 means 99% of requests are faster — the 1% that are slower is what you're alerting on.

**P99 (99th percentile)**
The latency value that 99% of requests complete faster than. If P99 is 300ms, 1% of requests take longer than 300ms. For a service handling 1,000 req/min, that is 10 users per minute experiencing slow responses.

**`cpu_saturation_pct`**
Process CPU utilisation percentage threshold. Alert fires when process CPU stays above this for 5 consecutive minutes. Leading indicator — CPU saturation precedes latency spikes by 3-5 minutes.

**Leading indicator**
A metric that signals trouble BEFORE users experience it. CPU saturation is a leading indicator — it predicts future latency increases. Error rate is a lagging indicator — it fires after users are already failing.

**`memory_usage_pct`**
Container memory utilisation as a percentage of the configured memory limit. Alert fires when memory usage exceeds this. Set below 85% to give headroom before the OOM killer terminates the process.

**OOM kill (Out of Memory Kill)**
When the Linux kernel forcibly terminates a process because it has exceeded its memory limit. The pod immediately restarts. OOM kills are visible as sudden pod restarts with the reason `OOMKilled` in kubectl describe.

**RSS (Resident Set Size)**
The portion of memory a process is currently using in RAM (not swapped out). Used by `builtin:process.memory.usage`. The relevant measure for container memory limits, which are enforced on RSS.

**`jvm_heap_pct`**
JVM heap utilisation as a percentage of the maximum heap size (-Xmx). Only meaningful for Java services. Alert fires at 75% because GC pressure begins to impact latency noticeably above this.

**`-Xmx`**
JVM command-line flag setting the maximum heap size. Example: `-Xmx512m` = max 512MB heap. `jvm_heap_pct` is measured as: heap used / -Xmx × 100.

**JVM Garbage Collection (GC)**
The JVM's automatic memory management process. When heap fills up, the GC runs to reclaim unused objects. Minor GC (fast, < 10ms). Major/Full GC (slow, 100ms–2s). At 85%+ heap, GC runs almost continuously — throughput collapses.

**`pod_restart_threshold`**
Number of pod restarts in a 5-minute window before alerting. Set to 2 for stateless services (rolling deploy = 1 expected restart; 2 = crash loop). CrashLoopBackOff is when a pod restarts repeatedly in quick succession.

**CrashLoopBackOff**
A Kubernetes pod status where the container starts, crashes immediately, and Kubernetes waits an exponentially increasing delay before restarting it. All four golden signals look healthy during CrashLoopBackOff because the pod is never running long enough to receive traffic.

**`network_error_rate_pct`**
Percentage of outbound network packets that result in errors or drops. Normal is < 0.01% in a healthy AWS VPC. Threshold typically set to 1.0% — anything above indicates NIC, security group, or routing issues.

**Packet drop**
A network packet that was lost in transit and never reached its destination. In TCP, dropped packets trigger retransmissions (slowing the connection). High packet drop rates cause cascading latency increases across all services on the affected host.

**`violating_samples`**
In Dynatrace metric events: how many consecutive 1-minute measurements must exceed the threshold before an alert fires. `3` = three consecutive minutes. Filters transient spikes from deployments, GC pauses, or batch jobs.

**`dealerting_samples`**
Consecutive measurements BELOW threshold before a Dynatrace Problem closes. Set higher than `violating_samples` to prevent flapping (rapid open/close cycles). CPU saturation uses 10 because recovery is slow.

**P95 (95th percentile)**
For threshold calibration: using P95 of your observed peak rather than absolute maximum. The absolute maximum might be a one-time anomaly; P95 represents your "almost worst case" — more stable for setting thresholds.

**HPA (HorizontalPodAutoscaler)**
Kubernetes resource that automatically adds pods when CPU or memory exceeds a target. The CPU saturation alert threshold should be set 10 percentage points ABOVE the HPA trigger. This way: HPA fires first (scales), and if scaling doesn't resolve it in time, the alert fires.

**`is_jvm_service`**
A boolean field in the services map indicating whether the service runs on a JVM. When `true`, the `jvm_heap` metric event is created for the service. When `false`, the event is skipped via the `local.jvm_services` filter in Terraform.

**`builtin:process.cpu.usage`**
Dynatrace's process-level CPU metric. Returns 0–100 (percentage). More accurate than Kubernetes pod CPU for alerting because it measures actual process consumption, not cgroup throttling quota usage.

**`builtin:kubernetes.container.memoryLimitUtilization`**
Dynatrace metric returning container memory as a percentage of the configured memory limit. Returns 0–100 directly — no calculation needed. Simpler than comparing raw bytes to the limit.

**`builtin:cloud.kubernetes.workload.restarts`**
Dynatrace metric counting container restarts per workload per minute. Summed across all pods in the Deployment. One alert per workload, not per individual pod — reduces noise during rolling updates.

**`builtin:host.net.errorRate.total`**
Dynatrace metric for total network error rate (errors + drops) as a percentage across all network interfaces on a host. Normal value is < 0.01%. Values above 0.5% indicate infrastructure-layer problems invisible to application metrics.
