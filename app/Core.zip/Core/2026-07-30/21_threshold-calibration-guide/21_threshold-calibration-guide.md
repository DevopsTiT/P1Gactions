# How to Find the Right Threshold for Every Metric Signal

> For each of the 8 signals in `metric-events.tf`: what number to put, where to find the data, and why the existing project values are what they are.

---

## The Universal Rule: Observe First, Threshold Second

Never set thresholds by guessing. Every threshold should come from measured baseline data:

```
Step 1: Deploy with no alerts (or very wide thresholds)
Step 2: Run for 7–14 days — observe normal behaviour
Step 3: Look at charts: what does normal look like at 3am? At peak?
Step 4: Set threshold = 2-3× above normal peak (for ABOVE alerts)
          or = 50% of normal quiet-time minimum (for BELOW alerts)
Step 5: Watch for 7 more days — tune if alert fires too often or too rarely
```

Every service is different. The commands below show you how to get baseline data from Dynatrace.

---

## How to Get Baseline Data from Dynatrace

```bash
DT_TENANT="abc12345"
DT_TOKEN="dt0c01.YOUR_TOKEN"
SERVICE="payment-service"

# ── Get last 7 days of a metric ──────────────────────────────────────────────
# Replace METRIC_KEY with each metric below to see your baseline

curl -s -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{
    \"metricSelector\": \"METRIC_KEY:filter(eq(service.name,\\\"${SERVICE}\\\"))\",
    \"resolution\": \"1h\",
    \"from\": \"now-7d\",
    \"to\": \"now\"
  }" | jq '.result[0].data[0].values | {
    min: min,
    max: max,
    avg: (add / length),
    p95: sort[(.| length * 0.95 | floor)]
  }'
```

---

## Signal 1: `traffic_min_rps` — Traffic Drop Threshold

**What it is:** Minimum requests per minute. Alert fires when traffic drops BELOW this value for 3 consecutive minutes.

**How to find your number:**

```bash
# Step 1: Get minimum traffic over the last 7 days (req/min)
# This shows you the quietest real moment — your true floor
curl -s -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{
    \"metricSelector\": \"builtin:service.requestCount.server:filter(eq(service.name,\\\"${SERVICE}\\\"))\",
    \"resolution\": \"1h\",
    \"from\": \"now-7d\"
  }" | jq '
    .result[0].data[0].values
    | map(select(. != null))
    | {
        minimum_observed: min,
        maximum_observed: max,
        suggested_threshold: (min * 0.5 | floor)
      }'
# minimum_observed = your quietest real minute (3am on Sunday)
# suggested_threshold = 50% of minimum_observed
```

**Decision table:**

| Service type | Rule | Examples |
|---|---|---|
| Always-on API (payments, auth) | 50% of 3am minimum | 3am min = 20 req/min → threshold = 10 |
| Business-hours only (internal tools) | 1–2 req/min during business hours | threshold = 1 or 2 |
| Batch/analytics service | `0` — disable the alert | Batch jobs have natural quiet periods |
| Cron job | `0` — disable | Only runs periodically |

**Why the project values are what they are:**
```hcl
"payment-service"   = traffic_min_rps: 10   # payments runs 24/7, 10 is the 3am floor
"order-service"     = traffic_min_rps: 5    # lower volume than payments
"inventory-service" = traffic_min_rps: 2    # internal service, very low baseline
"analytics-service" = traffic_min_rps: 0    # DISABLED — batch has natural quiet periods
```

---

## Signal 2: `error_rate_alert` — HTTP 5xx Error Rate

**What it is:** HTTP 5xx error rate as a decimal percentage. `0.5` = 0.5%.

**How to find your number:**

```bash
# Step 1: Get your normal error rate baseline
curl -s -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{
    \"metricSelector\": \"builtin:service.errors.server.rate:filter(eq(service.name,\\\"${SERVICE}\\\"))\",
    \"resolution\": \"1h\",
    \"from\": \"now-7d\"
  }" | jq '
    .result[0].data[0].values
    | map(select(. != null))
    | {
        normal_error_rate_pct: (add / length * 100 | . * 100 | round / 100),
        peak_error_rate_pct: (max * 100 | . * 100 | round / 100),
        suggested_threshold: (max * 100 * 3 | . * 100 | round / 100)
      }'
# normal_error_rate_pct = your average error rate (should be < 0.1%)
# suggested_threshold = 3× peak normal error rate
# If your peak normal is 0.05%, threshold = 0.15% — anything above is abnormal
```

**Decision table:**

| Service type | Threshold | Reasoning |
|---|---|---|
| Payment / financial | 0.1% | Any payment error is serious. 1 in 1000 = real money lost. |
| User-facing API | 0.5% | Standard web API tolerance. |
| Internal service | 1.0% | Internal callers retry; lower visibility impact. |
| Async/batch job | 2.0–5.0% | Batch has expected retry failures. |

**Real example — how to tune:**
```
Normal error rate: 0.01% (1 in 10,000 requests)
Peak during deployments: 0.05% (spike during rolling update)
Set threshold to: 0.1% (2× peak — anything above this is a real problem)

After 2 weeks: alert fires during every 3pm batch job that causes 0.15% errors.
Tune to: 0.2% (above the batch job peak but still catches real outages)
```

---

## Signal 3: `latency_p99_ms` — P99 Response Time

**What it is:** P99 latency in milliseconds. Alert fires when 99th percentile exceeds this for 5 consecutive minutes.

**How to find your number:**

```bash
# Step 1: Get P50, P90, P95, P99 baseline
curl -s -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{
    \"metricSelector\": \"builtin:service.response.time:percentile(99):filter(eq(service.name,\\\"${SERVICE}\\\"))\",
    \"resolution\": \"1h\",
    \"from\": \"now-7d\"
  }" | jq '
    .result[0].data[0].values
    | map(select(. != null))
    | map(. / 1000)
    | {
        normal_p99_ms: (add / length | . * 100 | round / 100),
        peak_p99_ms: (max | . * 100 | round / 100),
        suggested_threshold_ms: (max * 2 | . * 100 | round / 100)
      }'
# Values are in microseconds from DT — divide by 1000 for ms
# normal_p99_ms = typical P99 during normal operation
# suggested_threshold = 2× peak P99 (alert only for abnormal slowness)
```

**Decision table:**

| Service type | Rule | Why |
|---|---|---|
| Synchronous user-facing API | 2–3× normal P99 | Users notice latency > 500ms |
| Database query service | 3–5× normal P99 | DB queries are naturally variable |
| Async/message processor | 5–10× normal P99 | High latency is expected, alert only on severe |
| Streaming service | 10× + | Stream processing latency is inherently high |

**Why the project values:**
```hcl
"payment-service"   = latency_p99_ms: 300   # normal P99 ~80ms, 300ms = ~4× peak
"order-service"     = latency_p99_ms: 500   # normal P99 ~150ms, 500ms = ~3× peak
"inventory-service" = latency_p99_ms: 1000  # Go service, low but internal
"analytics-service" = latency_p99_ms: 10000 # 10s — batch queries are legitimately slow
```

---

## Signal 4: `cpu_saturation_pct` — Process CPU %

**What it is:** Process-level CPU utilisation (0–100). Alert fires ABOVE this threshold for 5 consecutive minutes.

**How to find your number:**

```bash
# Step 1: Get CPU baseline (peak during normal operation)
curl -s -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{
    \"metricSelector\": \"builtin:process.cpu.usage:filter(eq(process.name,\\\"${SERVICE}\\\"))\",
    \"resolution\": \"1h\",
    \"from\": \"now-7d\"
  }" | jq '
    .result[0].data[0].values
    | map(select(. != null))
    | {
        normal_peak_cpu_pct: (sort | .[(.| length * 0.95 | floor)]),
        absolute_peak_cpu_pct: max,
        suggested_threshold: ([max * 1.2, 80] | max | . * 10 | round / 10)
      }'
# suggested_threshold = max(your peak × 1.2, 80%)
# If your peak is 50%: threshold = max(60%, 80%) = 80%
# If your peak is 70%: threshold = max(84%, 80%) = 84%
```

**Decision table:**

| Service type | Threshold | Reasoning |
|---|---|---|
| JVM service | 70% | GC kicks in above this; latency starts degrading |
| Go/Python/Node API | 80% | Non-GC runtimes handle higher CPU better |
| CPU-intensive compute | 85–90% | Expected to run hot; alert only near limit |
| Batch/analytics | 90–95% | Batch is designed to use all available CPU |

**The HPA relationship:**
```
HPA triggers scale-up at: 70% CPU (configured in charts/payment-service/hpa.yaml)
CPU saturation alert at:   80% CPU (configured in variables.tf)

Timeline:
  CPU hits 70% → HPA schedules new pod (takes 30-90 seconds to start)
  CPU hits 80% → Saturation alert fires (Slack warning)
  If new pod starts before 5 min: CPU drops, alert never fires
  If pod doesn't start in time: alert fires → investigate HPA/Karpenter
```

---

## Signal 5: `memory_usage_pct` — Container Memory % of Limit

**What it is:** Process RSS memory as percentage of the container's memory limit.

**How to find your number:**

```bash
# Step 1: Get memory utilisation baseline
curl -s -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{
    \"metricSelector\": \"builtin:kubernetes.container.memoryLimitUtilization:filter(eq(k8s.workload.name,\\\"${SERVICE}\\\"))\",
    \"resolution\": \"1h\",
    \"from\": \"now-7d\"
  }" | jq '
    .result[0].data[0].values
    | map(select(. != null))
    | {
        normal_peak_mem_pct: (sort | .[(.| length * 0.95 | floor)]),
        absolute_peak_mem_pct: max,
        OOM_kill_happens_at: 100,
        suggested_alert_at: ([max * 1.1, 80] | min)
      }'
# Alert at: 10% above your peak, capped at 80%
# The OOM kill is at 100% — give yourself 20% headroom
```

**Decision table:**

| Pattern | Threshold | Reasoning |
|---|---|---|
| Stable memory (steady state) | 80% | Normal headroom below OOM |
| Growing memory (potential leak) | 70% | Catch leaks early |
| Known large working set | 85% | Service legitimately uses a lot of memory |
| After OOM kill incidents | 70% | Tighten the threshold after a near-miss |

---

## Signal 6: `jvm_heap_pct` — JVM Heap % of Max

**What it is:** JVM heap used as percentage of `-Xmx` (max heap setting). Only for `is_jvm_service = true`.

**How to find your number:**

```bash
# Step 1: Check JVM heap utilisation
curl -s -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{
    \"metricSelector\": \"builtin:process.memory.jvm.heapUtilization:filter(eq(process.name,\\\"${SERVICE}\\\"))\",
    \"resolution\": \"1h\",
    \"from\": \"now-7d\"
  }" | jq '
    .result[0].data[0].values
    | map(select(. != null))
    | {
        normal_heap_pct: (add / length | . * 100 | round / 100),
        peak_heap_pct: (max | . * 100 | round / 100),
        gc_thrashing_starts_at: 85,
        oom_at: 100,
        suggested_threshold: ([max * 100 * 1.15, 75] | max | . * 10 | round / 10)
      }'
```

**JVM Heap Phases:**
```
< 50%: Healthy — minor GC runs quickly, no impact
50–70%: Normal — GC runs more frequently, latency unaffected
70–80%: ALERT ZONE — GC is frequent, P99 latency starts rising
80–90%: CRITICAL — Major GC pauses (100ms–2s), throughput drops
90%+:   NEAR-OOM — JVM may become unresponsive; full GC every request
100%:   OOM kill — JVM throws OutOfMemoryError, pod crashes
```

**Rules:**
- `is_jvm_service = true` + `jvm_heap_pct = 75`: alert at 75% heap (GC pressure begins)
- `is_jvm_service = false` + `jvm_heap_pct = 0`: field exists but signal is disabled in `locals.jvm_services` filter

---

## Signal 7: `pod_restart_threshold` — Pod Restart Count

**What it is:** Number of pod restarts in a 5-minute window before alerting. Catches CrashLoopBackOff.

**How to find your number:**

```bash
# Step 1: Check historical restart counts (should normally be 0)
kubectl get pods -n YOUR_NAMESPACE -o wide | grep -v Running
# Any pod with restarts > 0 is worth investigating

# In Dynatrace — get restart history
curl -s -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{
    \"metricSelector\": \"builtin:cloud.kubernetes.workload.restarts:filter(eq(k8s.workload.name,\\\"${SERVICE}\\\"))\",
    \"resolution\": \"1h\",
    \"from\": \"now-30d\"
  }" | jq '
    .result[0].data[0].values
    | map(select(. != null and . > 0))
    | {
        restart_events: length,
        max_restarts_per_hour: max,
        recommendation: "Set threshold to 2 for stateless, 1 for stateful"
      }'
```

**Decision table:**

| Service type | Threshold | Reasoning |
|---|---|---|
| Stateless API | 2 | Rolling deploys restart once; crash loop = 2+ |
| Stateful/database sidecar | 1 | Any restart = immediate investigation |
| Batch worker | 3–5 | Workers restart on job failure; expected |
| Init container | N/A | Don't monitor — designed to run and exit |

**Why the project values:**
```hcl
"payment-service"   = pod_restart_threshold: 2  # any crash loop = P1
"inventory-service" = pod_restart_threshold: 3  # Go service, more tolerant
"analytics-service" = pod_restart_threshold: 5  # batch workers restart often
```

---

## Signal 8: `network_error_rate_pct` — Network Packet Error Rate

**What it is:** Percentage of network packets that are errors or drops. Normal is < 0.01%.

**How to find your number:**

```bash
# Check current network error rate on hosts running your service
curl -s -X POST "https://${DT_TENANT}.live.dynatrace.com/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  -H "Content-Type: application/json" \
  -d "{
    \"metricSelector\": \"builtin:host.net.errorRate.total\",
    \"resolution\": \"1h\",
    \"from\": \"now-7d\"
  }" | jq '
    .result[0].data[0].values
    | map(select(. != null))
    | {
        normal_max_pct: (max | . * 100 | round / 100),
        baseline_avg_pct: (add / length | . * 100 | round / 100),
        recommendation: "Set threshold to max(1.0, your normal peak * 5)"
      }'
```

**Decision table:**

| Environment | Threshold | Notes |
|---|---|---|
| Typical AWS VPC | 1.0% | 0.01% is normal; 1% = something is wrong |
| High-frequency trading | 0.1% | Extremely sensitive to packet loss |
| Batch data transfer | 2.0% | Some drops expected in bulk transfers |

---

## Complete Service Calibration Worksheet

Use this to determine thresholds for a new service:

```bash
SERVICE="your-new-service"
DT_TENANT="abc12345"
DT_TOKEN="dt0c01.YOUR_TOKEN"

echo "=== CALIBRATION WORKSHEET for $SERVICE ==="
echo ""
echo "Run AFTER 7+ days of production traffic."
echo ""

# Traffic
echo "--- Signal 1: traffic_min_rps ---"
echo "Min req/min at 3am Sunday (look at DT traffic chart):"
echo "  Set threshold to: [value above] × 0.5"
echo ""

# Error rate
echo "--- Signal 2: error_rate_alert ---"
echo "Normal error rate (7d average):"
echo "Peak error rate (max in 7d, excluding incidents):"
echo "  Set threshold to: [peak] × 3, minimum 0.1%"
echo ""

# Latency
echo "--- Signal 3: latency_p99_ms ---"
echo "Normal P99 latency (7d average):"
echo "Peak P99 latency (max in 7d, excluding incidents):"
echo "  Set threshold to: [peak] × 2"
echo ""

# CPU
echo "--- Signal 4: cpu_saturation_pct ---"
echo "Peak CPU during normal operation (P95 over 7d):"
echo "HPA trigger (from hpa.yaml targetCPUUtilizationPercentage):"
echo "  Set threshold to: HPA trigger + 10%, minimum 75%"
echo ""

# Memory
echo "--- Signal 5: memory_usage_pct ---"
echo "Peak memory % of limit during normal operation:"
echo "  Set threshold to: [peak] × 1.1, maximum 85%"
echo ""

# JVM
echo "--- Signal 6: jvm_heap_pct ---"
echo "Is this a JVM service? [yes/no]"
echo "Peak heap % during normal operation:"
echo "  Set threshold to: 75% (standard) or lower if frequent GC pauses"
echo ""

# Pod restarts
echo "--- Signal 7: pod_restart_threshold ---"
echo "Expected restarts per rolling deploy: 1"
echo "  Set threshold to: 2 (stateless) or 1 (stateful)"
echo ""

# Network
echo "--- Signal 8: network_error_rate_pct ---"
echo "  Set threshold to: 1.0% (standard AWS VPC)"
echo ""
echo "====================================="
```

---

## Current Project Values and Why

| Service | traffic | error% | latency ms | cpu% | mem% | heap% | restarts | net% |
|---|---|---|---|---|---|---|---|---|
| payment-service | 10 | 0.1 | 300 | 70 | 75 | 70 | 2 | 0.5 |
| order-service | 5 | 0.5 | 500 | 80 | 80 | 75 | 2 | 1.0 |
| inventory-service | 2 | 1.0 | 1000 | 85 | 80 | n/a | 3 | 1.0 |
| analytics-service | 0 (off) | 5.0 | 10000 | 92 | 85 | n/a | 5 | 2.0 |

The **strictest thresholds** are on `payment-service` — handles money, zero tolerance.
The **most relaxed** are on `analytics-service` — batch processing, CPU spikes expected.
