# 32 — SRE Practices: Glossary

Every term and tool used in main.md and commands.md, explained for an SRE beginner.

---

**SRE (Site Reliability Engineering)**
A discipline that applies software engineering principles to infrastructure and operations work. The goal: build systems that are reliable, scalable, and maintainable — and respond effectively when they are not. Created at Google; now widely adopted.

**Incident**
Any unplanned interruption or degradation to a service that impacts users or risks impacting users. A pod restarting once and recovering in 2 seconds = not an incident. Payment service down for 30 minutes = incident. The distinction matters because incidents trigger the full response process.

**Incident Management**
The structured process of detecting, responding to, mitigating, and resolving incidents. Includes role assignment, war room coordination, stakeholder communication, and resolution confirmation. The goal is to restore service as fast as possible.

**Severity Level (SEV)**
A classification of how bad an incident is. SEV1 = full outage, page everyone. SEV4 = no current user impact, file a ticket. Severity drives who gets woken up, how fast they must respond, and how loudly the team communicates externally.

**SLA (Service Level Agreement)**
A contractual commitment to a customer about service behavior (e.g., "99.9% uptime guaranteed, or you get a refund"). SLAs are external-facing. Breaching an SLA has financial consequences.

**SLO (Service Level Objective)**
An internal target for reliability (e.g., "99.9% availability over 30 days"). SLOs are the SRE team's working targets — more specific than SLAs and used daily for error budget decisions. An SLO breach does not automatically mean an SLA breach, but it's a warning sign.

**SLI (Service Level Indicator)**
The actual measured metric that an SLO is based on. If your SLO is "99.9% availability," the SLI is the measurement: (successful requests / total requests) × 100. SLIs are the raw numbers; SLOs are the targets built on top of them.

**Error Budget**
The amount of unreliability your SLO allows. 99.9% availability = 0.1% allowed downtime = 43.2 minutes per 30 days. This budget is shared between the entire team — incidents, deployments, and maintenance all consume it. When budget is exhausted, new risky deploys stop until it recovers.

**Incident Commander (IC)**
The person in charge of an incident. NOT the one debugging — the one driving. Assigns tasks, manages communication, makes go/no-go decisions on fixes. Keeps the bridge focused. One IC per incident; role can hand off to another person for long incidents.

**Technical Lead (TL)**
The person doing the hands-on investigation during an incident. Reports findings to the IC. Executes approved fixes. Should be one person to avoid conflicting changes.

**Communications Lead (CL)**
The person writing stakeholder updates during an incident — Slack messages, status page posts, emails to leadership. Keeps external communication accurate and timely so the IC and TL can focus on technical work.

**Scribe**
The person writing down everything that happens during an incident, with timestamps. This real-time log becomes the incident timeline in the postmortem. Without a scribe, the team must reconstruct the timeline from memory after the fact — which is inaccurate and slow.

**War Room / Bridge**
A dedicated space (Slack channel, Zoom call, or physical room) where all incident responders gather during an active incident. Having one channel prevents information being scattered across five different Slack threads.

**PagerDuty**
An incident management platform. Receives alerts from monitoring systems (Dynatrace, Prometheus, etc.) and routes them to the on-call engineer via phone call, SMS, or app push. Manages escalation policies (if person A doesn't respond in 5 min, page person B).

**On-Call**
The engineer responsible for responding to production alerts during a specific time period (e.g., one week). On-call rotates among team members. The on-call engineer is the first to be paged when an alert fires.

**Postmortem**
A written document created after a significant incident that explains what happened, why it happened, and what the team will do to prevent it recurring. Also called a "retrospective" or "incident review" at some companies. Not about blame — about learning.

**Blameless Postmortem**
A postmortem culture where the focus is on fixing the system, not punishing the person who made a mistake. Based on the principle that humans make mistakes when systems put them in difficult positions — so fix the system. Organizations with blameless culture have better incident reporting and faster learning.

**Root Cause Analysis (RCA)**
The process of tracing an incident back to its deepest systemic cause — not just the immediate trigger, but WHY the trigger was possible. The goal: identify fixes that prevent the incident from ever happening again, not just fixes that address the symptom.

**5 Whys**
An RCA technique where you repeatedly ask "Why?" starting from the symptom, until you reach a systemic root cause. Named for the observation that 5 levels of "Why?" often reaches the real cause. The fix for Why 5 prevents recurrence; the fix for Why 1 only masks the symptom.

**Fishbone Diagram (Ishikawa Diagram)**
An RCA visualization tool that organizes contributing causes into categories (People, Process, Technology, Environment, Measurement). Used when a single "why" chain doesn't capture the full complexity. The "fish spine" is the timeline leading to the failure.

**Contributing Factor**
A condition that made an incident more likely or more severe, but was not the sole root cause. For example: "no canary deployment" is a contributing factor — it didn't cause the bug, but it meant the bug hit 100% of users instead of 5%.

**Mitigation**
An action taken during an incident to stop or reduce user impact, even if it doesn't fix the root cause. Example: rolling back a bad deploy (stops the bleeding) rather than fixing the bug in the code (takes hours). Always prefer fast mitigation over slow perfect fix during an incident.

**Rollback**
Reverting to the previous version of a service after a bad deployment. In Kubernetes: `kubectl rollout undo`. Fast and reliable because the previous image is already deployed and cached. The first mitigation to consider in most deploy-caused incidents.

**RED Method**
A framework for investigating service-level problems: Rate (requests per second), Errors (error rate), Duration (latency). Check these three metrics first when a service is behaving badly. Answers "what is the service doing right now?"

**USE Method**
A framework for investigating infrastructure-level problems: Utilization (how busy is the resource?), Saturation (is it queueing work?), Errors (are errors appearing?). Applied to CPU, memory, disk, network, connection pools. Answers "is any resource the bottleneck?"

**DB Connection Pool**
A set of pre-opened database connections held ready for use by an application. Instead of opening a new DB connection for every request (slow), the app reuses connections from the pool (fast). If the pool is full (all connections in use), new requests queue and eventually time out.

**Connection Pool Exhaustion**
When all connections in the pool are occupied and new requests can't get a connection. Typically caused by: slow queries holding connections open too long, or a spike in traffic beyond the pool's capacity. Symptom: requests time out or return 503 errors.

**Canary Deployment**
Releasing a new version to a small percentage of users (e.g., 5%) before rolling it out to everyone. If the canary shows errors or high latency, the rollout stops and only 5% of users were affected. Reduces blast radius of bad deploys.

**Blast Radius**
How many users or systems are affected when something fails. Techniques to limit blast radius: canary deployments, feature flags, circuit breakers, rate limiting. Smaller blast radius = faster incident resolution with less user impact.

**Circuit Breaker**
A software pattern that "opens" (stops sending requests) when a downstream service is failing. Like an electrical circuit breaker: if the current (errors) gets too high, it trips to protect the system. Prevents cascading failures where one slow service takes down all services that depend on it.

**Toil**
Manual, repetitive, automatable work that scales linearly with service growth. Restarting pods every week, manually rotating certs, copy-pasting deploy commands. Google's SRE book says toil should be < 50% of an SRE's time. Toil that isn't eliminated compounds over time.

**MTTA (Mean Time to Acknowledge)**
Average time from when an alert fires to when an on-call engineer acknowledges it. A reliability health metric. Target is usually < 5 minutes for SEV1/2.

**MTTR (Mean Time to Resolve)**
Average time from when an incident starts to when service is restored. Lower MTTR = better incident response. Driven by detection speed, investigation speed, and mitigation options (e.g., fast rollback).

**MTTD (Mean Time to Detect)**
Average time from when a problem starts to when an alert fires. Synthetic monitoring and good alerting thresholds reduce MTTD. A problem that starts at 14:00 but isn't detected until 14:45 = 45 min of silent user impact.

**Runbook**
A step-by-step operational guide for one specific procedure (e.g., "how to increase DB pool size"). Written so a junior SRE who has never done this before can follow it during an incident. Must include: exact commands, expected output, and rollback steps.

**Playbook**
A higher-level guide for a category of incident (e.g., "payment service degraded"). Covers: initial triage steps, which runbooks to use, who to escalate to, how to communicate. Less prescriptive than a runbook.

**Chaos Engineering**
Deliberately injecting failures into a system in a controlled way to verify it handles them correctly. Examples: kill a pod, simulate a network partition, fail a DB connection. Finds weaknesses before real incidents do. Always done with blast radius controls.

**LitmusChaos**
An open-source chaos engineering platform for Kubernetes. Runs chaos experiments (pod delete, network delay, CPU stress, etc.) as Kubernetes Custom Resources. Results are stored as ChaosResult objects that can be reviewed after the experiment.

**ChaosEngine (LitmusChaos)**
A Kubernetes Custom Resource that defines a chaos experiment: which app to target, which experiment to run, and for how long. When applied (`kubectl apply`), LitmusChaos executes the experiment and records results.

**Steady State**
The normal, healthy baseline of a system before a chaos experiment. Defined by metrics: e.g., "p99 latency < 200ms, error rate < 0.1%." A chaos experiment checks whether the system returns to steady state after the injected failure. If it doesn't, a reliability problem was found.

**Hypothesis (Chaos)**
A specific, testable prediction about system behavior under failure. Example: "If the DB fails, the payment service will return HTTP 503 within 5 seconds." The chaos experiment either confirms or refutes the hypothesis.

**HPA (Horizontal Pod Autoscaler)**
A Kubernetes controller that automatically increases or decreases the number of pod replicas based on CPU/memory usage or custom metrics. During a traffic spike, HPA can add pods to handle the load — but only if there are nodes with free capacity.

**kubectl top**
A Kubernetes command that shows CPU and memory usage for pods or nodes in real time. Equivalent of `htop` but for Kubernetes workloads. Requires the Metrics Server to be installed in the cluster.

**kubectl cordon**
Marks a Kubernetes node as "unschedulable" — no new pods will be placed on it, but existing pods keep running. Used during incidents when a node is behaving badly (high CPU, disk pressure) and you don't want more workloads landing on it.

**`watch`**
A Linux command that re-runs another command every N seconds and shows the output. `watch -n 5 "kubectl get pods"` refreshes the pod list every 5 seconds. Useful for monitoring pod restarts during incident mitigation.

**`jq`**
A command-line JSON processor. Used to parse and filter the JSON responses returned by Kubernetes, Dynatrace, PagerDuty, and Jira APIs. Example: `| jq '.incidents[] | {key, summary}'` extracts just the key and summary from each Jira issue.

**`bc`**
A basic calculator for the Linux command line. Used in the commands.md to calculate error budget percentages: `echo 'scale=1; 32/43.2*100' | bc`. Useful for quick math without opening a spreadsheet.

**Reliability Roadmap**
A planned set of engineering investments to reduce the likelihood or impact of future incidents. Driven by postmortem action items, SLO reviews, and toil analysis. Balanced against feature work — the error budget acts as the negotiating lever between the two.

**On-Call Rotation**
The schedule that determines which engineer is on-call during each time period. A healthy rotation distributes the burden evenly so no one person is paged every night. The number of pages per person per rotation is a health metric SREs track monthly.

**Page**
A high-urgency alert sent to the on-call engineer's phone — a PagerDuty call, SMS, or push notification that demands immediate attention. Distinct from a low-urgency notification (email, Slack) that can wait until morning.
