# 32 — SRE Practices: Commands

---

## Phase 0 — First 5 minutes of an incident (READ-ONLY investigation)

```bash
# Check what changed recently — ALWAYS first
kubectl rollout history deployment/payment-service -n production

# Check recent Kubernetes events
kubectl get events -n production --sort-by=.metadata.creationTimestamp | tail -30

# Check pod status — any crashing / restarting pods?
kubectl get pods -n production -l app=payment-service

# Check pod resource usage (CPU/memory pressure)
kubectl top pods -n production -l app=payment-service

# Check recent git merges to main
git log --oneline --since="2 hours ago" origin/main

# Check if any nodes are under pressure
kubectl get nodes
kubectl describe nodes | grep -A 5 "Conditions:"

# Check HPA (autoscaler) — is it trying to scale but can't?
kubectl get hpa -n production
```

---

## Phase 1 — RED method (service-level investigation)

```bash
# Get current error rate from service logs
kubectl logs -n production -l app=payment-service --since=5m | grep -c "ERROR\|500\|503"
kubectl logs -n production -l app=payment-service --since=5m | grep -c "200"

# Get response times from access logs (p95 approximation)
kubectl logs -n production -l app=payment-service --since=5m \
  | grep -oP '"duration":\K[0-9]+' | sort -n | awk 'BEGIN{c=0} {a[c++]=$1} END{print a[int(c*0.95)]}'

# Check active connections to service
kubectl exec -it <pod-name> -n production -- ss -s
```

---

## Phase 2 — USE method (infrastructure investigation)

```bash
# CPU utilization on pods
kubectl top pods -n production --sort-by=cpu | head -10

# Memory utilization
kubectl top pods -n production --sort-by=memory | head -10

# Check OOM kills in last hour
kubectl get events -n production --field-selector reason=OOMKilling

# DB connection pool — check via env var
kubectl exec -it <pod-name> -n production -- env | grep -i "db_pool\|pool_max\|pool_size"

# Check open file descriptors (saturation signal)
kubectl exec -it <pod-name> -n production -- cat /proc/sys/fs/file-nr

# Check thread pool / thread count
kubectl exec -it <pod-name> -n production -- cat /proc/<pid>/status | grep Threads
```

---

## Phase 3 — Mitigation actions

```bash
# Option A: Rollback to previous deployment version
kubectl rollout undo deployment/payment-service -n production
kubectl rollout status deployment/payment-service -n production

# Option B: Increase DB connection pool (env var)
kubectl set env deployment/payment-service -n production DB_POOL_MAX=100
kubectl rollout status deployment/payment-service -n production

# Option C: Restart all pods (clears stuck connections)
kubectl rollout restart deployment/payment-service -n production
kubectl rollout status deployment/payment-service -n production

# Option D: Scale up replicas (spread load)
kubectl scale deployment/payment-service -n production --replicas=10
kubectl get pods -n production -l app=payment-service

# Option E: Cordon a bad node (stop scheduling new pods on it)
kubectl cordon <node-name>

# Verify mitigation worked — watch error rate in real time
kubectl logs -n production -l app=payment-service -f | grep -E "ERROR|500|503"
```

---

## Phase 4 — Confirm resolution (watch for 10–15 minutes)

```bash
# Watch pod restarts — should stabilize at 0
watch -n 5 "kubectl get pods -n production -l app=payment-service"

# Tail logs for any remaining errors
kubectl logs -n production -l app=payment-service -f --since=2m | grep -v "200 OK"

# Check recent events — no new warnings
kubectl get events -n production --sort-by=.metadata.creationTimestamp | tail -10

# Verify current rollout is stable
kubectl rollout status deployment/payment-service -n production

# Check Dynatrace API for current error rate
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=ext:app.payment.error.rate&resolution=1m&from=now-15m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.resolution.data[].values[-5:]'
```

---

## Phase 5 — Post-incident: Collect evidence for postmortem

```bash
# Export pod logs from the incident window to a file
kubectl logs -n production -l app=payment-service \
  --since-time="2026-07-31T14:00:00Z" \
  --until-time="2026-07-31T14:40:00Z" > /tmp/incident-logs-2026-0731.txt

# Export Kubernetes events from incident window
kubectl get events -n production \
  --sort-by=.metadata.creationTimestamp \
  -o json | jq '.items[] | select(.metadata.creationTimestamp > "2026-07-31T13:50:00Z")' \
  > /tmp/k8s-events-2026-0731.json

# Get deployment history with timestamps
kubectl rollout history deployment/payment-service -n production --output=json \
  > /tmp/deploy-history.json

# Get the exact config change that was deployed
kubectl diff deployment/payment-service -n production 2>/dev/null || \
  kubectl get deployment/payment-service -n production -o yaml > /tmp/current-deploy.yaml

# Get git diff of the bad commit
git show v2.14.3 --stat
git diff v2.14.2 v2.14.3 -- src/
```

---

## Phase 6 — Action item tracking (Jira via CLI or API)

```bash
# Create a P1 Jira action item via Jira REST API
curl -X POST "https://your-org.atlassian.net/rest/api/3/issue" \
  -H "Authorization: Basic $(echo -n user@example.com:$JIRA_TOKEN | base64)" \
  -H "Content-Type: application/json" \
  -d '{
    "fields": {
      "project": { "key": "SRE" },
      "summary": "Add DB connection pool saturation alert",
      "description": "Postmortem action PA-101: alert when pool > 80% for 2 min",
      "issuetype": { "name": "Task" },
      "priority": { "name": "High" },
      "labels": ["postmortem-action", "incident-2026-0731-001"],
      "duedate": "2026-08-07"
    }
  }' | jq '.key'

# Query open postmortem action items
curl -s "https://your-org.atlassian.net/rest/api/3/search\
?jql=labels%3Dpostmortem-action+AND+status%21%3DDone&maxResults=50" \
  -H "Authorization: Basic $(echo -n user@example.com:$JIRA_TOKEN | base64)" \
  | jq '.issues[] | {key: .key, summary: .fields.summary, due: .fields.duedate, assignee: .fields.assignee.displayName}'

# Check overdue P1 actions
curl -s "https://your-org.atlassian.net/rest/api/3/search\
?jql=labels%3Dpostmortem-action+AND+priority%3DHigh+AND+duedate<%3Dnow+AND+status%21%3DDone" \
  -H "Authorization: Basic $(echo -n user@example.com:$JIRA_TOKEN | base64)" \
  | jq '.total'
```

---

## Phase 7 — SLO and error budget check

```bash
# Get current SLO status from Dynatrace
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/slo?from=now-30d" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.slo[] | {name, status, evaluatedPercentage, target, errorBudget: (.target - .evaluatedPercentage)}'

# Check how much error budget was consumed by one incident
# 32-minute outage on a 99.9% / 30-day SLO:
# Total minutes: 43200 | Budget: 43.2 min | Consumed: 32/43.2 = 74%
echo "Budget consumed: $(echo 'scale=1; 32/43.2*100' | bc)%"

# Get availability metric history (daily buckets, last 30 days)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=ext:synthetic.http.availability.location.total\
&resolution=1d&from=now-30d" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.resolution.data[].values'
```

---

## Phase 8 — Chaos engineering (LitmusChaos)

```bash
# Install LitmusChaos operator
kubectl apply -f https://litmuschaos.github.io/litmus/litmus-operator-v3.0.0.yaml

# Verify operator is running
kubectl get pods -n litmus

# Apply chaos experiment (pod delete)
kubectl apply -f chaos/pod-delete-payment-service.yaml

# Watch chaos experiment progress
kubectl get chaosengine -n production payment-pod-delete -w

# Check chaos results
kubectl get chaosresult -n production payment-pod-delete-pod-delete -o json \
  | jq '{verdict: .status.experimentStatus.verdict, failStep: .status.experimentStatus.failStep}'

# Clean up after experiment
kubectl delete chaosengine payment-pod-delete -n production
```

---

## Phase 9 — On-call health check

```bash
# Count pages per person in the last 30 days (PagerDuty API)
curl -s "https://api.pagerduty.com/incidents?since=2026-07-01T00:00:00Z&until=2026-07-31T23:59:59Z&limit=100" \
  -H "Authorization: Token token=$PD_API_TOKEN" \
  | jq '[.incidents[].assignments[].assignee.summary] | group_by(.) | map({person: .[0], count: length}) | sort_by(-.count)'

# Get MTTR (mean time to resolve) for last 30 days
curl -s "https://api.pagerduty.com/incidents?since=2026-07-01T00:00:00Z&limit=100&statuses[]=resolved" \
  -H "Authorization: Token token=$PD_API_TOKEN" \
  | jq '[.incidents[] | ((.resolved_at | fromdateiso8601) - (.created_at | fromdateiso8601))] | add/length/60 | "MTTR: \(.) minutes"'

# Get MTTA (mean time to acknowledge)
curl -s "https://api.pagerduty.com/incidents?since=2026-07-01T00:00:00Z&limit=100&statuses[]=resolved" \
  -H "Authorization: Token token=$PD_API_TOKEN" \
  | jq '[.incidents[] | ((.acknowledged_at | fromdateiso8601) - (.created_at | fromdateiso8601))] | add/length/60 | "MTTA: \(.) minutes"'
```
