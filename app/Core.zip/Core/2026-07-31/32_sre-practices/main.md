# 32 — SRE Practices: Incident Management, RCA, and Continuous Improvement

---

## Decision Tree — "Where am I in the SRE lifecycle right now?"

```
Something broke (alert fired / user reported)?
├── YES → Are we actively fighting it RIGHT NOW?
│         ├── YES → INCIDENT MANAGEMENT (Parts 1–5)
│         │         → Declare → Command → Mitigate → Communicate → Resolve
│         └── NO  → Did it just resolve?
│                   ├── YES → POST-INCIDENT (Parts 6–8)
│                   │         → Postmortem → RCA → Action Items
│                   └── NO  → Is it a known recurring problem?
│                             └── YES → CONTINUOUS IMPROVEMENT (Parts 9–12)
│                                       → SLO review → Toil reduction → Reliability roadmap
└── NO  → Proactive SRE work
          → Error budgets · SLO reviews · Reliability reviews · Chaos engineering
```

---

## E2E Flow: From Alert to Improvement

```
[Alert fires in PagerDuty]
        │
        ▼
[On-call acknowledges — Incident Declared]
        │
        ├──► [Incident Commander assigned]
        │
        ├──► [War room / bridge opened — Slack #incident-XXXX]
        │
        ├──► [Investigate → Mitigate → Verify fix]
        │
        ├──► [Stakeholder updates every 30 min]
        │
        ▼
[Service restored → Incident Resolved]
        │
        ▼
[Postmortem written within 48–72 hours]
        │
        ├──► [Timeline reconstructed]
        ├──► [5 Whys / Fishbone → Root Cause identified]
        ├──► [Action items assigned with owners + deadlines]
        │
        ▼
[Action items tracked in Jira]
        │
        ▼
[SLO reviewed → Error budget consumed? → Reliability roadmap updated]
        │
        ▼
[Process improvement → playbooks updated → training run]
```

---

## Tool Map

| Purpose                           | Tool                              |
|-----------------------------------|-----------------------------------|
| On-call alerting + escalation     | PagerDuty                         |
| Incident coordination (war room)  | Slack (#incident channel)         |
| Incident tracking                 | PagerDuty Incidents / Jira        |
| Postmortem writing                | Confluence                        |
| Action item tracking              | Jira                              |
| SLO / error budget tracking       | Dynatrace SLO v2                  |
| Observability (metrics/traces)    | Dynatrace / OpenTelemetry         |
| Runbook / playbook storage        | Confluence / GitHub               |
| Chaos engineering                 | Chaos Monkey / LitmusChaos        |
| Toil tracking                     | Jira (toil label) / spreadsheet   |

---

## Part 1 — Incident Severity Levels (SEV)

Before anything else, every team must define what constitutes each severity level. These drive response time, who gets paged, and how loudly you communicate.

```
┌──────┬──────────────────────────────────────────┬───────────────┬─────────────────────┐
│ SEV  │ Definition                               │ Response SLA  │ Who is paged        │
├──────┼──────────────────────────────────────────┼───────────────┼─────────────────────┤
│ SEV1 │ Full outage — service unavailable        │ < 5 minutes   │ On-call + manager   │
│      │ or data loss in progress                 │               │ + leadership        │
├──────┼──────────────────────────────────────────┼───────────────┼─────────────────────┤
│ SEV2 │ Major degradation — partial outage,      │ < 15 minutes  │ On-call + team lead │
│      │ key feature broken for many users        │               │                     │
├──────┼──────────────────────────────────────────┼───────────────┼─────────────────────┤
│ SEV3 │ Minor degradation — one feature slow     │ < 1 hour      │ On-call             │
│      │ or broken for a subset of users          │               │ (no escalation)     │
├──────┼──────────────────────────────────────────┼───────────────┼─────────────────────┤
│ SEV4 │ No user impact now, but risk of impact   │ Next business │ Ticket only         │
│      │ if not addressed soon                    │ day           │                     │
└──────┴──────────────────────────────────────────┴───────────────┴─────────────────────┘
```

**Key rule:** When in doubt, declare higher severity. Downgrading later is fine. Declaring SEV3 when it's really SEV1 loses critical minutes.

---

## Part 2 — Incident Roles

Every incident needs clear role ownership. When roles are blurry, people talk over each other and no one is driving.

```
┌──────────────────────┬─────────────────────────────────────────────────────────┐
│ Role                 │ Responsibility                                          │
├──────────────────────┼─────────────────────────────────────────────────────────┤
│ Incident Commander   │ Owns the incident end-to-end. Drives the bridge.        │
│ (IC)                 │ Makes decisions. NOT the one debugging — delegates that. │
├──────────────────────┼─────────────────────────────────────────────────────────┤
│ Technical Lead       │ Investigates root cause. Reports findings to IC.        │
│ (TL)                 │ Executes fixes. One person only — avoids conflict.      │
├──────────────────────┼─────────────────────────────────────────────────────────┤
│ Communications Lead  │ Writes stakeholder updates. Drafts status page posts.   │
│ (CL)                 │ Keeps Slack thread clean. IC should NOT do comms.       │
├──────────────────────┼─────────────────────────────────────────────────────────┤
│ Scribe               │ Real-time timeline log. Every action + timestamp.       │
│                      │ Feeds directly into the postmortem.                     │
├──────────────────────┼─────────────────────────────────────────────────────────┤
│ Subject Matter       │ Called in as needed — database expert, network eng,     │
│ Expert (SME)         │ security team. One SME at a time per domain.            │
└──────────────────────┴─────────────────────────────────────────────────────────┘
```

**Common mistake:** the on-call engineer tries to be IC + TL + Comms at the same time. This is the fastest path to missing something critical.

---

## Part 3 — Incident Declaration and Bridge Setup

### 3.1 PagerDuty: Acknowledge and Declare

```
Alert fires → On-call acknowledges in PagerDuty (within SLA)
           → Assess severity (check dashboards / Dynatrace)
           → Declare incident in PagerDuty:
               Title: [SEV1] Payment service – 100% error rate – all regions
               Service: payment-service
               Body: Brief symptom description + first hypothesis
           → PagerDuty auto-creates Slack channel: #incident-2026-0731-001
```

### 3.2 Slack War Room Convention

```
#incident-2026-0731-001
├── Pin: IC name, TL name, CL name, Scribe name
├── Pin: Incident ticket URL (Jira / PagerDuty)
├── Pin: Runbook link
├── Pin: Dashboard link (Dynatrace)
│
├── Thread 1: "TIMELINE" — scribe posts every action as a reply
│   └── 14:03 UTC – alert fired, SEV2 declared
│   └── 14:05 UTC – IC @alice assigned, TL @bob assigned
│   └── 14:08 UTC – Hypothesis: DB connection pool exhausted
│   └── 14:12 UTC – Confirmed: DB pool at 100%, new connections queuing
│   └── 14:15 UTC – Mitigation: increased pool size from 50 to 100, restarting pods
│   └── 14:22 UTC – Error rate dropping, 30% → 5% → 0%
│   └── 14:25 UTC – Service restored, monitoring for 10 min
│   └── 14:35 UTC – Incident resolved
│
└── Thread 2: "STAKEHOLDER UPDATES" — CL posts every 30 min
    └── 14:15 UTC – [UPDATE 1] Investigating payment failures. ETA unknown.
    └── 14:30 UTC – [UPDATE 2] Root cause identified (DB pool). Fix in progress. ETA 15 min.
    └── 14:40 UTC – [RESOLVED] Service restored at 14:35 UTC. Full postmortem within 48h.
```

### 3.3 Incident Ticket Template (Jira / Confluence)

```
Title: [SEV2] Payment service – DB connection pool exhaustion – 2026-07-31

Status: RESOLVED
IC: Alice Chen
TL: Bob Kumar
Severity: SEV2
Start: 2026-07-31 14:03 UTC
End:   2026-07-31 14:35 UTC
Duration: 32 minutes
Impact: Payment failures for ~15% of users

Summary:
  DB connection pool exhausted due to a traffic spike + a slow query
  introduced in deploy v2.14.3. Mitigation: pool size increased.

User Impact:
  ~15,000 users received 503 errors on checkout between 14:03–14:35 UTC.

Timeline: [link to Slack thread]
Postmortem: [link to Confluence page]
```

---

## Part 4 — Investigation Framework (During the Incident)

Don't random-walk through dashboards. Use a structured approach.

### 4.1 The RED Method (for services)

```
R — Rate:    What is the current request rate? Is it normal / spiked / dropped?
E — Errors:  What is the error rate? Which error codes? Which endpoints?
D — Duration: What is p50 / p95 / p99 latency? Is it elevated?
```

Check these three metrics **first** for the failing service in Dynatrace.

### 4.2 The USE Method (for infrastructure)

```
U — Utilization: CPU, memory, disk, network — are any at high %?
S — Saturation:  Queue depths, thread pool usage, connection pool usage
E — Errors:      Kernel errors, OOM kills, disk I/O errors
```

Check these for the hosts and containers behind the failing service.

### 4.3 Hypothesis → Test → Confirm loop

```
NEVER: "Let me just restart everything and see what happens"

ALWAYS:
  1. State a hypothesis: "I think the DB is overloaded"
  2. Check evidence: Dynatrace DB metrics, slow query log
  3. Confirm or reject: "Confirmed — connection pool at 100%, query latency 8s"
  4. Apply targeted fix: "Increasing pool size + killing the slow query"
  5. Verify fix worked: "Error rate now 0%, latency p99 back to 120ms"
```

### 4.4 Change Correlation

The most powerful first question in any incident:

> **"What changed in the last 2 hours?"**

```bash
# Check recent deployments
kubectl rollout history deployment/payment-service -n production

# Check recent config changes
kubectl get events -n production --sort-by=.metadata.creationTimestamp | tail -30

# Check Dynatrace events (deployments, config changes)
# In Dynatrace UI: Events → filter last 2h → look for CUSTOM_DEPLOYMENT events

# Check git log for recent merges
git log --oneline --since="2 hours ago" origin/main
```

80% of incidents are caused by a recent change. Check this first.

---

## Part 5 — Mitigation vs Fix vs Root Cause Fix

These are three different things. Confusing them is a common SRE mistake.

```
┌───────────────────┬─────────────────────────────────────────┬──────────────────────┐
│ Type              │ What it does                            │ Example              │
├───────────────────┼─────────────────────────────────────────┼──────────────────────┤
│ Mitigation        │ Stops the bleeding RIGHT NOW.           │ Rollback the deploy  │
│ (during incident) │ May not fix root cause.                 │ Restart the pods     │
│                   │ Gets users back online fast.            │ Increase pool size   │
├───────────────────┼─────────────────────────────────────────┼──────────────────────┤
│ Fix               │ Resolves the immediate cause.           │ Remove the slow query│
│ (post-incident)   │ Service is now working correctly.       │ Fix the bug in code  │
│                   │ May recur if systemic issue not fixed.  │ Add an index         │
├───────────────────┼─────────────────────────────────────────┼──────────────────────┤
│ Root Cause Fix    │ Addresses WHY the problem was possible. │ Add query timeout    │
│ (action items)    │ Prevents recurrence.                    │ Add connection limit │
│                   │ Takes days/weeks — tracked in Jira.     │ Add regression test  │
└───────────────────┴─────────────────────────────────────────┴──────────────────────┘
```

**Rule:** Always confirm the mitigation worked before calling the incident resolved. Watch metrics for 10–15 minutes after applying a fix.

---

## Part 6 — Postmortem: Structure and Writing Process

A postmortem is **a blameless document** that explains what happened, why it happened, and what will prevent recurrence. It is NOT a blame report.

### 6.1 The Blameless Principle

> People do not make mistakes because they are careless or stupid. They make mistakes because the **system** put them in a position where a mistake was likely. Fix the system, not the person.

**Blame-ful (wrong):**
> "Bob pushed broken code without testing it."

**Blameless (correct):**
> "A code change was merged without sufficient test coverage. Our CI pipeline did not catch the regression. No canary deployment was in place to limit blast radius."

### 6.2 Postmortem Template

```markdown
# Postmortem: [SEV2] Payment Service – DB Pool Exhaustion
**Date:** 2026-07-31
**Duration:** 32 minutes (14:03–14:35 UTC)
**Severity:** SEV2
**Status:** Resolved
**Authors:** Alice Chen, Bob Kumar

---

## Impact
- ~15,000 users received 503 errors on the checkout page
- ~$42,000 estimated revenue impact (based on avg order value × failed transactions)
- No data loss. No security impact.

---

## Timeline

| Time (UTC) | Event                                                         |
|------------|---------------------------------------------------------------|
| 13:55      | Deploy v2.14.3 pushed to production (payment-service)        |
| 14:00      | Traffic increases by 20% (normal afternoon peak)             |
| 14:03      | PagerDuty alert: payment-service error rate > 10%            |
| 14:05      | Alice (IC) and Bob (TL) join bridge                          |
| 14:08      | Hypothesis: DB connection pool exhausted (USE method)        |
| 14:12      | Confirmed: pool at 100%, queries queuing for 8+ seconds      |
| 14:13      | Identified slow query introduced in v2.14.3 (missing index)  |
| 14:15      | Mitigation: pool size 50 → 100, pods restarted              |
| 14:22      | Error rate dropping: 30% → 5%                                |
| 14:25      | Error rate: 0%, latency normal                               |
| 14:35      | Declared resolved after 10 min stable                        |

---

## Root Cause

The deploy v2.14.3 introduced a new ORM query in the payment flow that
performed a full table scan on the `orders` table (missing index on
`user_id`). Under normal load this query took ~200ms. During the afternoon
traffic peak (20% above baseline), this query took 8–12 seconds per call,
exhausting the DB connection pool (max: 50 connections) and causing all
new requests to queue and time out.

---

## Contributing Factors

1. **No query performance test** in CI — slow queries are not caught before deploy.
2. **DB connection pool too small** — 50 connections is insufficient for peak load.
3. **No canary deployment** — change went to 100% of traffic immediately.
4. **No DB slow query alert** — we had no alert for queries exceeding 1 second.

---

## What Went Well

- On-call acknowledged within 3 minutes (within SLA).
- The USE method quickly identified the DB as the bottleneck.
- Stakeholder updates were clear and timely.
- Rollback option was identified early (though mitigation was faster).

---

## What Went Poorly

- No alert on DB connection pool saturation — we found it manually.
- CI did not catch the missing index / slow query.
- Impact assessment (revenue) was only done 2 days later.

---

## Action Items

| ID     | Action                                      | Owner     | Priority | Due        |
|--------|---------------------------------------------|-----------|----------|------------|
| PA-101 | Add DB connection pool saturation alert     | Bob Kumar | P1       | 2026-08-07 |
| PA-102 | Add slow query (>500ms) alert in Dynatrace  | Bob Kumar | P1       | 2026-08-07 |
| PA-103 | Add `orders.user_id` index + regression test| Carol Lin | P1       | 2026-08-05 |
| PA-104 | Increase connection pool to 150 (+ verify)  | Bob Kumar | P2       | 2026-08-10 |
| PA-105 | Implement canary deployments for payment-svc| Alice Chen| P2       | 2026-08-21 |
| PA-106 | Add query EXPLAIN plan check to CI pipeline | DevOps    | P3       | 2026-09-01 |

---

## Recurrence Prevention

If PA-101 through PA-103 are completed, a recurrence of this exact
incident would be: (a) detected 10+ minutes earlier via pool alert, and
(b) prevented entirely because the missing index would be caught in CI.
```

---

## Part 7 — Root Cause Analysis Techniques

### 7.1 The 5 Whys

Start from the symptom. Ask "why?" until you reach a systemic cause (not a human action).

```
Symptom: Payment service returned 503 errors

Why 1: Why did users get 503s?
  → The payment service exhausted its DB connection pool.

Why 2: Why did the connection pool exhaust?
  → A slow DB query held connections open for 8–12 seconds each.

Why 3: Why was there a slow DB query?
  → Deploy v2.14.3 introduced an ORM query missing an index on user_id.

Why 4: Why did a query without an index reach production?
  → There is no automated query performance check in the CI pipeline.

Why 5: Why is there no query performance check in CI?
  → The team has never had a slow query incident before; it was not
    considered a risk during pipeline design.

ROOT CAUSE: No automated mechanism to detect missing indexes or slow
queries before code reaches production.
```

The fix for Why 1 is: "restart the service."
The fix for Why 5 is: "add EXPLAIN plan check to CI."
Only the fix for Why 5 prevents recurrence.

---

### 7.2 Fishbone Diagram (Ishikawa)

Used when there are **multiple contributing factors** and a single "why" chain doesn't capture the full picture. Organizes causes into categories.

```
                        PEOPLE          PROCESS
                           \              /
                    slow reaction \    / no canary deploy
                                   \  /
 DB connection pool ────────────────[OUTAGE]────────────── TECHNOLOGY
 too small (50)                    /  \                  missing index
                                  /    \                 no pool alert
                      ENVIRONMENT        MEASUREMENT
                    afternoon traffic   no slow query alert
                    spike (20% above)   no pool saturation alert
```

Use the 6 M's as category prompts: **Methods, Machines, Materials, Measurement, Man (People), Mother Nature (Environment)**.

---

### 7.3 Timeline Reconstruction

A precise timeline is the foundation of any RCA. Without it, you are guessing.

```
Sources to cross-reference:
  ├── Dynatrace: exact timestamps of metric anomalies
  ├── Dynatrace: deployment events (when v2.14.3 landed)
  ├── PagerDuty: alert triggered, acknowledged timestamps
  ├── Slack #incident thread: every action the team took
  ├── kubectl events / pod logs: container restarts, OOM kills
  └── Git log: merge timestamps for recent commits
```

**The gap between deploy time and incident time is critical:**
- Deploy at 13:55, incident at 14:03 = 8-minute lag → likely a traffic trigger
- Deploy at 13:55, incident at 13:57 = 2-minute lag → deploy was directly causal

---

## Part 8 — Action Item Lifecycle (Jira)

An action item from a postmortem is worthless if it disappears into a backlog. Track it with discipline.

```
Postmortem written
      │
      ▼
Action items created as Jira tickets
  Labels: postmortem-action, incident-2026-0731-001
  Priority: P1/P2/P3
  Assignee: named person (not a team)
  Due date: set at postmortem meeting
      │
      ▼
Weekly SRE review: "How many postmortem actions are overdue?"
  Target: 0 P1 actions overdue, < 3 P2 actions overdue
      │
      ▼
Action completed → link Jira ticket to the postmortem Confluence page
      │
      ▼
Monthly: "Did our actions actually prevent recurrence?"
  Check: Has this type of incident recurred since the fix?
```

**Priority definitions for action items:**

| Priority | Meaning                                              | Expected completion |
|----------|------------------------------------------------------|---------------------|
| P1       | Without this fix, the same incident WILL recur      | Within 1 week       |
| P2       | Without this fix, a similar incident is likely      | Within 1 month      |
| P3       | Quality/resilience improvement, low recurrence risk | Within 1 quarter    |

---

## Part 9 — SLO Reviews and Error Budget Management

### 9.1 What an Error Budget Tells You

```
SLO target: 99.9% availability over 30 days
Total minutes in 30 days: 43,200
Allowed downtime (error budget): 43,200 × 0.001 = 43.2 minutes

After the incident (32 min outage):
  Error budget consumed: 32 / 43.2 = 74%
  Error budget remaining: 26% = ~11 minutes
```

**What 74% consumed means for SRE decisions:**

```
Error budget consumed    │ What to do
─────────────────────────┼──────────────────────────────────────────────────
< 50%                    │ Normal. Continue feature velocity.
50–75%                   │ Warning zone. Slow risky deploys. Review reliability work.
75–99%                   │ Danger zone. Freeze risky changes. Prioritize reliability.
> 100% (budget exhausted)│ No new features until budget recovers. Full reliability focus.
```

### 9.2 Monthly SLO Review Agenda

```
1. Error budget status for each SLO (current consumption %)
2. Which incidents consumed the most budget?
3. Are postmortem action items on track?
4. Are current SLO targets realistic? (too tight = always in red; too loose = no signal)
5. New SLOs needed? (new services, new user journeys)
6. Reliability work items to prioritize next sprint
```

---

## Part 10 — Toil Identification and Reduction

**Toil** = manual, repetitive, automatable work that scales with service growth and adds no lasting value.

### 10.1 How to identify toil

Ask your team:

> "What do you do repeatedly during or after incidents that you wish was automated?"

Common SRE toil examples:

| Toil activity                            | Automation target                        |
|------------------------------------------|------------------------------------------|
| Manually restarting pods after OOM kill  | Kubernetes liveness probe + auto-restart |
| Manually purging cache when deploys fail | Runbook automation / PagerDuty webhook   |
| Manually checking certificate expiry     | Synthetic monitor cert check alert       |
| Manually rotating credentials           | Vault dynamic secrets / auto-rotation    |
| Copy-pasting incident updates to Slack   | PagerDuty → Slack webhook automation     |
| Manually creating postmortem Confluence pages | Postmortem template bot + Jira webhook |

### 10.2 Toil Budget Rule (Google SRE)

> SREs should spend **no more than 50% of their time on toil**. The other 50% must be engineering work that permanently reduces future toil or improves reliability.

Track toil as a Jira label. Review % monthly.

---

## Part 11 — Runbooks and Playbooks

### 11.1 Difference

```
Playbook = high-level guide for a CATEGORY of incident
           "What to do when the payment service is degraded"
           → Who to page, what signals to check, escalation path

Runbook  = step-by-step recipe for ONE specific procedure
           "How to increase the DB connection pool size"
           → Exact commands, expected output, rollback steps
```

### 11.2 Runbook Structure (in Confluence)

```markdown
# Runbook: Increase DB Connection Pool Size

**Service:** payment-service
**Last updated:** 2026-07-31
**Owner:** Platform SRE

## When to use this
When DB connection pool saturation alert fires, or during payment-service
incidents where the DB pool is the bottleneck.

## Prerequisites
- kubectl access to production cluster (role: sre-operator)
- Dynatrace access (read-only sufficient for investigation)

## Steps

### 1. Verify the problem
```bash
kubectl get pods -n production -l app=payment-service
kubectl exec -it <pod-name> -n production -- env | grep DB_POOL
```
Expected output: `DB_POOL_MAX=50`

### 2. Increase pool size
```bash
kubectl set env deployment/payment-service -n production DB_POOL_MAX=100
kubectl rollout status deployment/payment-service -n production
```
Expected output: `deployment "payment-service" successfully rolled out`

### 3. Verify fix
Check Dynatrace: DB connection pool utilization should drop below 80%.

### 4. Rollback (if change made things worse)
```bash
kubectl set env deployment/payment-service -n production DB_POOL_MAX=50
kubectl rollout status deployment/payment-service -n production
```

## Notes
- Pool size above 150 may overload the DB itself — check DB CPU before going higher.
- File a Jira ticket to make this change permanent in the Helm chart.
```

---

## Part 12 — Continuous Improvement Cadence

SRE is not a one-time setup. It requires structured, recurring rituals.

```
Daily
├── On-call handoff: what happened, any open actions, anything to watch
└── Synthetic monitor / SLO dashboard reviewed by on-call

Weekly
├── Incident review: walk through any incidents from the past week
├── Postmortem action item review: are P1 items on track?
└── Toil log review: new toil identified?

Monthly
├── SLO review: error budget status for all services
├── Reliability roadmap: prioritize next reliability investments
└── Runbook audit: are runbooks still accurate?

Quarterly
├── Chaos engineering exercise: simulate failure, test response
├── On-call rotation health: is the burden distributed fairly?
└── SLO target review: are targets still meaningful?

After every SEV1/SEV2
└── Postmortem published within 48–72 hours (non-negotiable)
```

---

## Part 13 — Chaos Engineering (Proactive Resilience)

**Chaos engineering** = intentionally injecting failures in a controlled way to verify your systems handle them gracefully.

### 13.1 The Chaos Experiment Format

```
Hypothesis:  "If the payments DB becomes unavailable, the payment service
              will return a clear error to users within 5 seconds and
              will NOT take down the rest of the application."

Steady state: Payment service p99 latency < 200ms, error rate < 0.1%

Experiment:  Simulate DB connection failure for 60 seconds

Blast radius control:
  - Run in staging first
  - Run on 10% of production traffic only
  - Halt immediately if error rate > 5%

Observe:
  - Does payment service fail fast (not hang)?
  - Does it return HTTP 503 (not 200 with wrong data)?
  - Does the circuit breaker open?
  - Does the rest of the app (non-payment) stay healthy?

Result:
  - Payment service hung for 30 seconds before timing out → bug found
  - Circuit breaker was NOT configured → action item created
```

### 13.2 LitmusChaos on Kubernetes (YAML)

```yaml
# chaos/pod-delete-payment-service.yaml
apiVersion: litmuschaos.io/v1alpha1
kind: ChaosEngine
metadata:
  name: payment-pod-delete
  namespace: production
spec:
  appinfo:
    appns: production
    applabel: "app=payment-service"
    appkind: deployment
  engineState: active
  chaosServiceAccount: litmus-admin
  experiments:
    - name: pod-delete
      spec:
        components:
          env:
            - name: TOTAL_CHAOS_DURATION
              value: "60"      # 60 seconds
            - name: CHAOS_INTERVAL
              value: "10"      # delete one pod every 10 seconds
            - name: FORCE
              value: "false"
```

---

## Common Mistakes

| Mistake                                  | What goes wrong                                  | Fix                                                 |
|------------------------------------------|--------------------------------------------------|-----------------------------------------------------|
| No IC declared — everyone debugging      | No one is driving; poor comms; missed steps      | First action on bridge: assign IC                   |
| Blame in postmortem                      | People hide information; culture degrades        | Enforce blameless language in postmortem review     |
| Postmortem action items not tracked      | Same incident recurs in 3 months                 | Every action item gets a Jira ticket + owner + date |
| Resolving incident before verifying fix  | Incident re-opens 10 minutes later               | Watch metrics for 10–15 min after mitigation        |
| SLO targets set too tight (99.999%)      | Constant alert fatigue; team burns out           | Set targets based on actual user pain tolerance     |
| Runbooks never updated after incidents   | On-call follows stale steps, wastes time         | Runbook review is part of postmortem action items   |
| Chaos engineering in production without  | Real outage triggered during experiment          | Blast radius controls + staging first               |
| blast radius controls                    |                                                  |                                                     |
| On-call rotation imbalanced              | Burnout; attrition; incidents handled poorly     | Track pages-per-person; redistribute load           |
