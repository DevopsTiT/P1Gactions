# Dynatrace Observability — Glossary for SRE Beginners

Every term used in main.md, one entry per term.

---

**Dynatrace**
A full-stack observability and AIOps platform. It collects metrics, traces, logs, and synthetic test results from your applications and infrastructure, then uses AI (Davis) to automatically find root causes of problems. Unlike tools that just store metrics, Dynatrace correlates everything into a single answer.

**Observability**
The ability to understand what is happening inside a system from the outside — by looking at its outputs (metrics, traces, logs). A highly observable system lets you answer "why is this slow?" without guessing or adding new instrumentation. The three pillars are metrics, traces, and logs.

**APM (Application Performance Monitoring)**
Monitoring the performance of software applications at the code level: which methods are slow, which SQL queries take longest, which HTTP endpoints have errors. Dynatrace's OneAgent does this automatically for Java without any code changes.

**OneAgent**
Dynatrace's monitoring agent. Runs as a DaemonSet (one pod per Kubernetes node). Uses JVMTI to hook into every JVM process on the node, capturing all HTTP requests, DB calls, JVM metrics, and logs — with zero application code changes required.

**DaemonSet**
A Kubernetes resource that runs exactly one copy of a pod on every node in the cluster. As new nodes are added, the DaemonSet automatically schedules a pod on them. OneAgent uses a DaemonSet so every node is always monitored, even after cluster autoscaling.

**JVMTI (Java Virtual Machine Tool Interface)**
A Java API that allows external agents to hook into a running JVM. Dynatrace uses this to inject bytecode instrumentation at runtime — intercepting method calls, HTTP handlers, JDBC calls — without modifying the application's JAR file.

**DynaKube**
A Kubernetes custom resource (CRD) that tells the Dynatrace Operator how to configure monitoring in the cluster: which mode (DaemonSet, sidecar), ActiveGate settings, which features to enable. One DynaKube per cluster.

**Dynatrace Operator**
A Kubernetes controller that watches for DynaKube resources and deploys the monitoring stack accordingly (OneAgent DaemonSet, ActiveGate Deployment). You configure it by writing a DynaKube YAML; the Operator handles all the pod creation.

**ActiveGate**
A Dynatrace relay/proxy deployed as a Kubernetes Deployment. OneAgent pods send all collected data to ActiveGate (one connection per cluster). ActiveGate batches and forwards to the Dynatrace SaaS tenant. Also responsible for Kubernetes API scraping and log analytics. Production runs 2 replicas for HA.

**PurePath**
Dynatrace's term for a distributed trace — one end-to-end request captured from entry (ALB) through all microservices (payment → order → notification) to all backends (DB, SQS). Contains every operation with its exact timing, in a tree structure. Named "PurePath" because it captures the complete execution path purely from the instrumentation, no sampling.

**Distributed trace**
A record of a single user request as it flows through multiple services. Each service adds its own timing data (called a "span"). Combined, the spans form a tree showing exactly where time was spent. Essential for debugging latency in microservice architectures where one request touches 3+ services.

**Span**
A single timed operation within a distributed trace. "DB query: SELECT * FROM accounts" taking 12ms is one span. Spans nest inside each other — the HTTP handler span contains the DB query spans inside it.

**Management zone**
A Dynatrace filter that scopes the entire UI to specific entities. `payments-production` zone shows only services, processes, and hosts tagged with `team:payments AND environment:production`. Each team has their own zone — no noise from other teams.

**Auto-tagging**
Dynatrace automatically applies tags to entities (services, hosts, process groups) based on rules. In this project: OneAgent reads Kubernetes pod labels (`team: payments`, `environment: production`) and applies them as Dynatrace tags. Management zone rules then match on these tags.

**Alerting profile**
A Dynatrace configuration that maps a problem severity to: which notification channel to use, and how many minutes to wait before notifying. Four tiers: CRITICAL (0 min, PagerDuty), HIGH (2 min, PagerDuty), WARNING (5 min, Slack), INFO (15 min, Slack).

**Delay (alerting)**
The minimum duration a problem must persist before Dynatrace sends a notification. A 2-minute delay on ERROR alerts means the error rate must stay elevated for 2+ continuous minutes before anyone is paged. Filters out transient blips (retry storms, rolling deploy interruptions) that self-resolve.

**Problem (Dynatrace)**
Davis AI's unified view of an incident — one Problem, not a storm of individual alerts. Davis correlates all related metric events, log anomalies, and performance signals into one root-cause finding. One Problem might represent 6 separate threshold violations happening because of one root cause.

**Davis AI**
Dynatrace's AI/causation engine. Continuously analyzes all collected data, detects anomalies, and builds causal graphs: "heap increased → GC pauses → latency spike → error rate increase → service degraded." Opens one Problem with root cause evidence rather than flooding on-call with separate alerts.

**SLO (Service Level Objective)**
A numeric reliability target for a service, measured over a rolling time window. "99.9% of payment-service requests must succeed in the last 30 days." Dynatrace tracks actual compliance and the remaining error budget continuously.

**Error budget**
The total allowed failures within an SLO window. For 99.9% availability over 30 days: 0.1% × 30 days × 1440 min = 43.2 minutes of allowed downtime. Once the budget is exhausted, the SLO is breached. Burn rate alerts fire before exhaustion.

**Burn rate (SLO)**
How fast the error budget is being consumed relative to the expected rate. Burn rate = 1.0 means consuming budget at the normal (sustainable) pace. Burn rate = 14.4 means consuming budget 14.4× faster — at this rate, a 30-day budget is gone in ~2 days.

**Error budget burn rate alert**
A Dynatrace SLO alert that fires when the budget is depleting too fast. `fast_burn_threshold = 14.4` fires when the budget would be exhausted in ~2 days. `slow_burn_threshold = 3.0` fires when exhaustion would happen in ~10 days. Both fire well before the SLO is actually missed.

**HTTP Synthetic monitor**
An active health check run by Dynatrace's external probe nodes (real data centers in Tokyo, Singapore, etc.) that sends real HTTP requests to your service endpoints every 5 minutes. Validates HTTP status AND response body. Catches failures invisible to internal monitoring.

**Synthetic location**
A physical Dynatrace data center from which synthetic monitors run. `GEOLOCATION-6F55B7E4B5E7A52F` = Tokyo. Running probes from multiple locations (Tokyo + Singapore) distinguishes local network problems from true service outages.

**Global outage (synthetic)**
When ALL synthetic probe locations fail to reach the service. 1 global failure = alert. Evidence that the service itself is down (not just a regional network issue between one probe and the ALB).

**Local outage (synthetic)**
When ONE synthetic probe location fails while others succeed. Requires 3 consecutive local failures before alerting — filters single-packet-loss events. Indicates a regional network issue between that location and the service.

**Log analytics**
Dynatrace's feature that streams container logs from OneAgent into the Dynatrace tenant, making them searchable alongside metrics and traces. Filterable by Kubernetes labels (`team:payments`), time range, log level. Links log lines to distributed traces via trace IDs in the log message.

**MDC (Mapped Diagnostic Context)**
A Java logging feature (from SLF4J) that attaches key-value pairs to every log line within a thread's context. When a request starts, the trace ID is added to MDC → every log statement in that request automatically includes the trace ID → Dynatrace can link the log line to its trace.

**Kubernetes monitoring (DT)**
Dynatrace's collection of cluster-level metrics via the Kubernetes API: node conditions, pod restart counts, deployment replica status, resource quota usage, HPA scaling events. ActiveGate calls the K8s API server (not pods) to collect these.

**Metric event**
A Dynatrace configuration that monitors a specific metric and fires a Problem event when it crosses a threshold for N consecutive samples. "If `builtin:service.errors.server.rate > 0.1%` for 3 consecutive 1-minute intervals → fire ERROR event."

**`alert_on_no_data`**
A metric event option. When true: if no data arrives during the evaluation window, treat it as a threshold violation. Catches silent outages where the service has crashed completely and isn't sending any metrics at all. Used only on the traffic-drop signal.

**`violating_samples`**
The number of consecutive evaluation periods the metric must exceed the threshold before the event fires. `violating_samples = 3` with `resolution = 1m` means the metric must be above threshold for 3 consecutive minutes. Prevents alerts from momentary spikes.

**`dealerting_samples`**
The number of consecutive periods the metric must be BELOW the threshold before Dynatrace marks the Problem resolved. `dealerting_samples = 3` prevents a rapidly oscillating metric from generating a flood of open-and-close alerts.

**Traffic drop alert**
Signal 1 in this project. Fires when a service receives fewer requests than the minimum threshold (`traffic_min_rps`). With `alert_on_no_data = true`, also fires when the service sends zero metrics — catches the silent outage. Dev has `traffic_min_rps = 0` so no traffic drop alerts (dev services are often idle).

**P99 (99th percentile)**
A latency statistic. If P99 = 300ms, it means 99% of requests completed in under 300ms. The slowest 1% may be slower. P99 represents the worst experience that most users have — it's more meaningful than average (which hides outliers) and less extreme than P99.9 (which is noise for most services).

**Microseconds (µs)**
Dynatrace stores all latency internally in microseconds (millionths of a second). 1 millisecond = 1,000 microseconds. The Terraform module multiplies all `latency_p99_ms` values by 1000 before setting the threshold, so humans write `300` (ms) and Dynatrace receives `300000` (µs).

**RSS (Resident Set Size)**
The total physical memory a JVM process is using, including: heap, off-heap (Metaspace, CodeCache, DirectByteBuffer), native library memory, and JVM internal overhead. OOMKill happens when RSS hits the container memory limit, not when heap hits Xmx. RSS > heap always.

**JVM heap utilization**
The percentage of the JVM's configured maximum heap (`-Xmx`) that is currently in use. At >70%, G1GC starts running more aggressively. At >85%, GC pauses become frequent and long. At 100%, `java.lang.OutOfMemoryError: Java heap space` is thrown.

**G1GC (Garbage First Garbage Collector)**
Java's modern low-pause garbage collector. Splits the heap into many equal-size regions and collects the most-garbage regions first. Designed for large heaps (1GB+) with bounded pause time goals. Pause times increase non-linearly above ~70% heap utilization.

**GC pause**
A stop-the-world pause where all Java application threads are frozen while the garbage collector runs. Short pauses (< 50ms) are normal. Long pauses (> 200ms) cause request timeouts and P99 spikes. OneAgent captures GC events automatically from JVM metrics.

**OOMKill (Out of Memory Kill)**
When a Linux container's RSS memory usage hits the container memory limit, the Linux kernel sends `SIGKILL` (unblockable kill) to the container. No graceful shutdown. The pod disappears and Kubernetes creates a new one. Appears as a pod restart in Kubernetes and Signal 7 (pod restarts) alert in Dynatrace.

**`builtin:` metrics**
Dynatrace's built-in metric keys for standard platform signals. `builtin:service.requestCount.server` = incoming HTTP request count to a service. `builtin:process.memory.jvm.heapUtilization` = JVM heap percent. These are collected automatically by OneAgent — no configuration needed.

**OTLP (OpenTelemetry Protocol)**
The wire protocol used by OpenTelemetry SDKs to send telemetry data. Dynatrace ActiveGate has an OTLP endpoint (port 4318). Applications that use the OTel SDK can send their spans/metrics/logs to ActiveGate, which forwards them to the DT tenant. Enables custom business metrics alongside auto-instrumented ones.

**PagerDuty**
An incident management and on-call scheduling platform. When Dynatrace fires a CRITICAL or HIGH alert and routes it to PagerDuty, PagerDuty pages the on-call engineer via phone call, SMS, and push notification — even at 3am. Used only for production CRITICAL and HIGH alerts in this project.

**Integration key (PagerDuty)**
A service-specific API key used to send alerts to a specific PagerDuty service (which has its own escalation policy and on-call schedule). `payments → pd-payments-key` means payment-related CRITICAL alerts go to the payments team's on-call rotation, not the entire company's.

**Slack webhook**
A URL that accepts HTTP POST requests and posts a message to a Slack channel. Dynatrace sends WARNING and INFO alerts to per-team Slack channels (`#alerts-payments`) and shared channels (`#monitoring`) via these webhooks. No human review needed — Slack alerts are informational, not emergency pages.

**MTTR (Mean Time To Resolution)**
The average time from when an incident starts to when it is fully resolved. Dynatrace reduces MTTR by eliminating the "where do I even look?" phase. Davis provides root cause evidence within seconds of the Problem opening. In the incident example: MTTR = 8 minutes (vs. 30-90 minutes manually).

**Deployment event**
A custom event pushed to Dynatrace via API when a new application version is deployed. Appears as a vertical marker on all metric graphs at the deployment time. Makes it visually obvious: "this P99 spike started exactly when the new image was deployed."

**Real User Monitoring (RUM)**
Dynatrace feature that instruments the browser (via a JavaScript snippet) to capture real user sessions: page load times, AJAX request timings, JavaScript errors, user clicks. Provides the user's perspective rather than the server's perspective. Complements APM.

**Session replay**
A Dynatrace RUM feature that records user interactions and can replay them as a video. When a user reports "checkout was broken," you can literally watch their browser session — every click, every API call, every error message they saw.

**Dynamic baseline (anomaly detection)**
Instead of a static threshold (`error_rate > 0.1%`), Dynatrace Davis learns the normal pattern of a metric over days/weeks and alerts when it deviates significantly from that learned baseline — even if it never crosses the hard threshold. Useful for services with cyclical traffic patterns (e.g., spikes every Monday morning).

**Alert fatigue**
The phenomenon where on-call engineers receive so many alerts (especially false alarms) that they start ignoring them. Leads to real incidents being missed. Solved by: delay-based alerting, severity tiers, proper thresholds per environment (relaxed in dev, strict in production), and burn-rate alerts instead of instant threshold fires.
