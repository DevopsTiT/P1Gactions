# Dynatrace — Observability & Performance Deep Dive (SRE View)

> This doc is grounded in the actual project: 3 Java Spring Boot services (payment, order, notification) × 3 environments (dev/staging/production) on EKS. Every feature explained maps to real files in `8_java-3envs-dynatrace-complete/`.

---

## The Observability Problem Dynatrace Solves

```
WITHOUT Dynatrace:
  "payment-service is slow"  →  WHERE? Which endpoint? Which DB query?
                                 Which pod? Which node? What happened first?
                                 → hours of log grep, metrics stitching

WITH Dynatrace (this project):
  "payment-service is slow"  →  Davis AI already opened a Problem
                                 → Root cause: heap 82% → GC pauses → P99 spike
                                 → Exact DB queries and their execution times
                                 → Which pods, since when, impacted user count
                                 → 3 minutes to resolve instead of 3 hours
```

Dynatrace's promise: replace the question "where do I even start?" with "here's exactly what is wrong and why."

---

## The Full Observability Stack (What This Project Uses)

```
LAYER 7: Business Metrics
         SLOs (availability + latency compliance, 30-day rolling)
         Error budget burn rate alerts

LAYER 6: Application Performance Monitoring (APM)
         Distributed traces (payment → order → notification flow)
         DB query performance
         HTTP endpoint breakdown

LAYER 5: Metric Events (8 signals × 3 services)
         Traffic drop, error rate, latency P99
         CPU, memory RSS, JVM heap, pod restarts, network errors

LAYER 4: Synthetic Monitoring
         External health checks every 5 min (Tokyo + Singapore)
         Validates both HTTP status AND body content

LAYER 3: Infrastructure Monitoring
         EKS node CPU/memory/disk
         Kubernetes workload health (pod counts, restart counts)

LAYER 2: Log Analytics
         Container log streaming → Dynatrace Log Viewer
         Filterable by team + environment labels

LAYER 1: Auto-Instrumentation (OneAgent)
         JVMTI hooks into every JVM with zero code changes
         All layers above feed from data OneAgent collects
```

---

## FEATURE 1: OneAgent Auto-Instrumentation

### What it is
OneAgent runs as a **DaemonSet** — one pod per Kubernetes node. It uses JVMTI (Java Virtual Machine Tool Interface) to hook into every JVM process on the node. No application code changes. No annotation needed. No OpenTelemetry SDK required (though OTel is also supported).

### How it deploys (from the project):
```yaml
# gitops/dev/monitoring/dynatrace/dynatrace-operator.yaml
apiVersion: dynatrace.com/v1beta1
kind: DynaKube
spec:
  classicFullStack:
    enabled: true           ← deploys OneAgent as a DaemonSet
    resources:
      requests: { cpu: 100m, memory: 512Mi }
      limits:   { cpu: 300m, memory: 768Mi }
  logMonitoring:
    enabled: true           ← streams container logs
  activeGate:
    capabilities: [routing, kubernetes-api-monitoring, log-analytics]
    replicas: 1             ← dev. production has replicas: 2 (HA)
```

### What OneAgent captures automatically for payment-service:

```
HTTP layer:
  Every incoming request: method, URL, HTTP status, response time
  Every outgoing HTTP call: which service called, latency
  Grouping: /api/v1/payments/{id} → all variants grouped as one metric

Database layer (JDBC instrumentation):
  Every SQL statement executed
  Execution time per statement
  Connection pool usage, wait times
  Which queries are slowest (auto-ranked)

JVM layer:
  Heap usage (used / committed / max) — continuous time series
  GC activity: frequency, duration, type (G1 minor/major/full)
  Thread count, thread states (running / waiting / blocked)
  Class loading, JIT compilation

Process layer:
  CPU usage for the JVM process (not the whole container)
  Memory RSS (total process memory, not just heap)
  File descriptor count, socket connections
```

### Why "zero code change" matters for SREs:
If observability required developers to add SDK calls to every method, it would be:
- Partial (some methods instrumented, some not)
- Inconsistent across teams
- Missing from legacy code nobody wants to touch
- A negotiation with each dev team

OneAgent instruments everything — existing code, third-party libraries, Spring internals. SREs get complete coverage without depending on developer effort.

---

## FEATURE 2: Distributed Tracing (End-to-End Request Flow)

### What it captures in this project:
When a user submits a payment:
```
Browser → ALB → payment-service → order-service → notification-service → SQS
```
Dynatrace traces this entire chain as one unit called a **PurePath**.

### How the trace flows:
1. OneAgent intercepts the HTTP request to payment-service
2. Injects a correlation header (`X-dynaTrace: ...`) into all outbound calls
3. OneAgent on the order-service node picks up that header
4. Both services report their spans to ActiveGate
5. ActiveGate assembles the full trace in Dynatrace

The project passes OTEL endpoint in Helm values:
```yaml
# charts/payment-service/values.yaml
env:
  - name: OTEL_EXPORTER_OTLP_ENDPOINT
    value: "http://dynatrace-activegate.dynatrace.svc:4318"
  - name: OTEL_SERVICE_NAME
    value: "payment-service"
```

This means the app can also send its own OpenTelemetry spans — Dynatrace accepts both OTLP (from OTel SDK) and OneAgent auto-instrumentation and merges them into one trace.

### What you see in the Dynatrace UI:
```
PurePath: POST /api/v1/payments
  Total: 243ms
  ├── payment-service (143ms)
  │   ├── DB query: SELECT * FROM accounts WHERE id=?    (12ms)
  │   ├── DB query: UPDATE accounts SET balance=?        (8ms)
  │   └── HTTP call → order-service                      (100ms)
  └── order-service (97ms)
      ├── DB query: INSERT INTO orders (...)              (15ms)
      └── HTTP call → notification-service               (45ms)
          └── notification-service (42ms)
              └── SQS send: payment.confirmed queue      (40ms)
```

**SRE use case:** A user reports their payment was slow (5 seconds). Without tracing, you'd have to check each service's logs separately and try to correlate timestamps. With a PurePath, you open the specific trace and immediately see: SQS send took 3.8 seconds (SQS throttling). Root cause in 30 seconds.

---

## FEATURE 3: Management Zones (Team Scoping)

### What it does:
Filters the entire Dynatrace UI — dashboards, alerts, problems, services — to show only the resources matching your team and environment.

### How it's built in this project:
```hcl
# terraform/modules/dynatrace/main.tf
resource "dynatrace_management_zone_v2" "team" {
  for_each = local.teams    # creates: payments, orders, notifications
  name     = "${each.value}-${var.environment}"   # "payments-production"

  rules {
    rule {
      type = "SERVICE"
      attribute_rule {
        attribute_conditions {
          attribute = "SERVICE_TAGS"
          tag_value = "team:${each.value}"         # matches pod label
        }
        attribute_conditions {
          attribute = "SERVICE_TAGS"
          tag_value = "environment:${var.environment}"
        }
      }
    }
    rule { type = "PROCESS_GROUP" ... }   # same logic for JVM processes
    rule { type = "HOST" ... }            # same logic for EKS nodes
  }
}
```

The tag flow:
```
Kubernetes namespace label:   team: payments
        ↓  (Helm commonLabels propagates to pod)
Pod label:                    team: payments, environment: production
        ↓  (OneAgent reads K8s API metadata)
Dynatrace auto-tag:           tag: team:payments, environment:production
        ↓  (management zone rule matches)
Zone "payments-production":   only shows payment-service entities
```

### Three management zones created per environment:
| Zone name | What it shows |
|-----------|--------------|
| `payments-production` | payment-service: service metrics, traces, alerts, DB queries |
| `orders-production` | order-service: same |
| `notifications-production` | notification-service: same |

**SRE impact:** When `#alerts-payments` fires at 3am, the on-call opens Dynatrace, switches to the `payments-production` zone, and sees ONLY payment-related entities. No noise from order-service or notification-service. Faster orientation, fewer wrong paths.

---

## FEATURE 4: Alerting Profiles (4-Tier Noise Filtering)

### The problem with naive alerting:
A single threshold with no delay fires on every transient blip:
- Pod restarting during a rolling deploy → AVAILABILITY fires → false alarm
- JIT cold start → latency spike for 45s → SLOWDOWN fires → false alarm
- Retry storm from order-service → error rate spikes 30s → ERROR fires → false alarm

SREs stop responding to alerts after too many false alarms → real incidents go unnoticed.

### This project's 4-tier solution:
```hcl
# Tier 1: CRITICAL — production only, 0 min delay
resource "dynatrace_alerting" "critical" {
  for_each = var.environment == "production" ? local.teams : toset([])
  rules {
    rule {
      severity_level   = "AVAILABILITY"   # service down, synth failed
      delay_in_minutes = 0                # downtime is never transient
    }
  }
}

# Tier 2: HIGH — staging + production, 2 min delay
resource "dynatrace_alerting" "high" {
  for_each = contains(["production", "staging"], var.environment) ? local.teams : toset([])
  rules {
    rule {
      severity_level   = "ERROR"          # high error rates
      delay_in_minutes = 2                # filters retry storms, deploy blips
    }
  }
}

# Tier 3: WARNING — all envs, 5 min delay
resource "dynatrace_alerting" "warning" {
  for_each = local.teams
  rules {
    rule {
      severity_level   = "SLOWDOWN"       # latency degradation
      delay_in_minutes = 5                # filters JIT warmup, cold starts
    }
  }
}

# Tier 4: INFO — all envs, 15 min delay
resource "dynatrace_alerting" "info" {
  for_each = local.teams
  rules {
    rule { severity_level = "RESOURCE_CONTENTION"; delay_in_minutes = 15 }
    # CPU, memory, network — trends not emergencies
  }
}
```

### Decision tree: which tier fires for what?

```
Is the service unreachable?
  YES → CRITICAL (0 min) → PagerDuty immediately (production)

Is error rate sustained for 2+ min?
  YES → HIGH (2 min) → PagerDuty (staging+prod) / Slack (dev)

Is P99 latency elevated for 5+ min?
  YES → WARNING (5 min) → Slack #alerts-{team}

Is CPU/memory/heap trending up for 15+ min?
  YES → INFO (15 min) → Slack #monitoring
```

**Impact:** Payment-service gets a rolling deploy. For 30 seconds, one pod is unavailable. With 2-minute delay on ERROR and 5-minute delay on SLOWDOWN, these alerts NEVER fire. SREs don't get paged. Real production-down incidents fire in 0-2 minutes. Alert-to-noise ratio improves dramatically.

---

## FEATURE 5: The 8 Metric Events (Signal Coverage)

Every JVM service gets these 8 signals, configured per environment in the Terraform module.

### Signal map for payment-service (production thresholds):

```
Signal                 Metric key                              Threshold    Delay
─────────────────────────────────────────────────────────────────────────────────
1. Traffic drop        builtin:service.requestCount.server     < 10 rps     0 min
   WHY: catches silent outages (service too broken to emit data)
   KEY CONFIG: alert_on_no_data = true (fires even if NO data received)

2. Error rate          builtin:service.errors.server.rate      > 0.1%       2 min
   WHY: HTTP 5xx rate, 3-min sustained window
   PRODUCTION THRESHOLD: 0.1% = 1 error per 1000 requests

3. Latency P99         builtin:service.response.time:pct(99)   > 300ms      2 min
   WHY: slowest 1% of users, threshold in µs in DT: 300 × 1000 = 300,000µs
   PRODUCTION THRESHOLD: 300ms (dev: 2000ms to account for JIT cold start)

4. CPU saturation      builtin:process.cpu.usage               > 70%        5 min
   WHY: process-level CPU (JVM GC pressure indicator)
   PRODUCTION: 70% (GC intensifies non-linearly above this point)

5. Memory RSS          builtin:process.memory.usage            > 75%        5 min
   WHY: total process RSS as % of container limit (OOMKill risk)
   NOT heap — catches off-heap leaks (Metaspace, DirectByteBuffer, JNI)

6. JVM heap            builtin:process.memory.jvm.heapUtilization  > 70%    5 min
   WHY: heap specifically (memory leak, insufficient Xmx)
   PRODUCTION: 70% alert → scale out BEFORE G1GC causes latency spikes at 80%+

7. Pod restarts        builtin:kubernetes.workload.pods.restarts   > 2      immediate
   WHY: crash loop detection
   violating_samples = 1: fire on first measurement (no 3-min wait)
   Causes: OOMKill, liveness probe failure, config error on startup

8. Network errors      builtin:host.net.errorRate              > 0.5%       5 min
   WHY: host-level (affects all services on a node simultaneously)
   Catches: security group changes, node NIC issues, MTU mismatches
```

### Why signals 5 and 6 are separate (RSS vs. heap):

```
payment-service production:
  container memory limit:  1Gi
  JVM Xmx:                 1024m  (heap can use up to 1Gi)
  JVM Metaspace:           ~128m  (class metadata, not heap)
  JVM CodeCache:           ~64m   (JIT compiled code)
  JVM overhead:            ~64m   (GC tables, threads)
  Total RSS at full heap:  ~1.3Gi  ← EXCEEDS 1Gi limit → OOMKill

Heap alert at 70% of 1Gi = 716MB used   → alert fires → investigate
RSS alert at 75% of 1Gi  = 768MB total  → alert fires → scale up
OOMKill at 100% of 1Gi   = 1024MB total → SIGKILL, no graceful shutdown
```

Heap alert catches memory leaks early. RSS alert catches the OOMKill trajectory before it happens.

---

## FEATURE 6: SLO Tracking (Service Level Objectives)

### Two SLO types per service:

**Availability SLO** (did the request succeed?):
```hcl
resource "dynatrace_slo_v2" "availability" {
  for_each       = var.services
  target_success = each.value.slo_target          # 99.9% for payment-service
  target_warning = each.value.slo_target - 0.1   # 99.8% warning threshold
  evaluation_window = "-1M"                        # rolling 30-day window

  metric_expression = <<-EOT
    100 * (
      builtin:service.requestCount.server
        :filter(and(eq(service.name,"${each.key}"), eq(environment,"${var.environment}")))
        :sum
      - builtin:service.errors.server.count
        :filter(and(eq(service.name,"${each.key}"), eq(environment,"${var.environment}")))
        :sum
    ) / builtin:service.requestCount.server
        :filter(and(eq(service.name,"${each.key}"), eq(environment,"${var.environment}")))
        :sum
  EOT
  # = (total_requests - error_requests) / total_requests × 100
}
```

**Latency SLO** (was the request fast enough?):
```hcl
resource "dynatrace_slo_v2" "latency" {
  # Counts requests that completed WITHIN the threshold as "good"
  metric_expression = <<-EOT
    100 * (
      builtin:service.requestCount.server
        :filter(and(
          eq(service.name,"${each.key}"),
          eq(environment,"${var.environment}"),
          le(builtin:service.response.time, ${each.value.latency_p99_ms * 1000})
        ))
        :sum
    ) / builtin:service.requestCount.server
        :filter(and(eq(service.name,"${each.key}"), eq(environment,"${var.environment}")))
        :sum
  EOT
}
```

### Error budget burn rate:
```hcl
error_budget_burn_rate {
  burn_rate_visualization_enabled = true
  fast_burn_threshold = 14.4   # exhausts monthly budget in ~2 days → CRITICAL alert
  slow_burn_threshold = 3.0    # exhausts monthly budget in ~10 days → WARNING alert
}
```

**What this means for payment-service production (99.9% SLO):**
```
30-day error budget:
  0.1% × 30 days × 24h × 60min = 43.2 minutes of allowed downtime

At 14.4× burn rate:
  Budget used in: 30 days / 14.4 = ~2.1 days
  Alert fires: 2 days BEFORE the SLO month could be breached
  Action required: immediate investigation

At 3.0× burn rate:
  Budget used in: 30 days / 3.0 = 10 days
  Alert fires: 20 days before end of month
  Action required: investigate this week, not emergency paging

Without burn rate alerts:
  You only know the SLO was missed AFTER the 30-day window closes
  The payment team is already in an SLA breach when they find out
```

### SLO per-service targets (production):
| Service | Availability SLO | Latency SLO target |
|---------|-----------------|-------------------|
| payment-service | **99.9%** (43 min/month downtime budget) | 99.4% (requests < 300ms) |
| order-service | 99.5% (3.6h/month) | 99.0% (requests < 500ms) |
| notification-service | 99.0% (7.2h/month) | 98.5% (requests < 1000ms) |

Why notification-service has a lower SLO: it's async (SQS-based). A delayed notification is worse than a missing payment record, but the impact is less immediate.

---

## FEATURE 7: HTTP Synthetic Monitoring

### What it does:
External probes (real HTTP requests from Dynatrace data centers in Tokyo and Singapore) hit the health endpoint every 5 minutes. This is an OUTSIDE-IN view — it catches what real users experience: DNS failures, TLS cert expiry, ALB misconfigurations, Spring startup failures.

### The monitor configuration:
```hcl
resource "dynatrace_http_monitor" "health_check" {
  frequency = 5              # every 5 minutes
  locations  = var.synthetic_locations
  # production: [Tokyo, Singapore]
  # dev:        [Tokyo only]

  script {
    request {
      method = "GET"
      url    = each.value.health_check_url
      # production payment: "https://payment.company.com/actuator/health"

      validation {
        rule {
          type          = "httpStatusesList"
          value         = "2xx"
          pass_if_found = true     # must return HTTP 2xx
        }
        rule {
          type          = "patternConstraint"
          value         = "\"status\":\"UP\""   # body must contain this
          pass_if_found = true
        }
      }
      response_time_limit = each.value.latency_p99_ms * 3  # 300ms × 3 = 900ms limit
    }
  }

  anomaly_detection {
    outage_handling {
      global_consecutive_outage_count_threshold = 1   # 1 global failure = alert
      local_consecutive_outage_count_threshold  = 3   # 3 local = alert (filters regional blips)
    }
    loading_time_thresholds {
      enabled  = true
      thresholds {
        type     = "TOTAL"
        value_ms = each.value.latency_p99_ms * 2   # 600ms = slow synthetic alert
      }
    }
  }
}
```

### Why validate the body AND the HTTP status:
Spring Boot Actuator can return HTTP 200 with:
```json
{
  "status": "DOWN",
  "components": {
    "db": { "status": "DOWN", "details": { "error": "Connection refused" } }
  }
}
```
The HTTP server is running → returns 200. But the app is broken (can't reach DB). ALB health checks (which also check `/actuator/health/readiness`) would catch this, but synthetics check from OUTSIDE the cluster. If ALB itself is broken, the synthetic still runs from Tokyo's internet.

### What synthetics catch that internal monitoring misses:
```
Scenario: ACM TLS certificate expires
  Internal monitoring: still connected via internal cluster DNS → looks fine
  Synthetic from Tokyo: sees SSL certificate error → AVAILABILITY alert fires
  Time to detect: < 5 minutes

Scenario: Route53 DNS record deleted by mistake
  Internal monitoring: pod-to-pod still works → looks fine
  Synthetic from Tokyo: DNS NXDOMAIN → AVAILABILITY alert fires
  Time to detect: < 5 minutes

Scenario: ALB security group blocks port 443
  Internal monitoring: internal traffic unaffected → looks fine
  Synthetic from Tokyo: connection timeout → AVAILABILITY alert fires
  Time to detect: < 5 minutes
```

---

## FEATURE 8: Log Analytics

### How it's enabled:
```yaml
# DynaKube spec
logMonitoring:
  enabled: true
```

With `logMonitoring: true`, the OneAgent DaemonSet pod on each node tails all container logs and streams them to Dynatrace. Combined with the namespace labels (`team: payments`, `environment: production`), you can search:

```
DT Log Viewer query:
  log.source = "payment-service"
  AND kubernetes.namespace = "payment-ns"
  AND content = "ERROR"
  AND timeframe = last 1h

Results: all ERROR-level log lines from all payment-service pods,
         sorted by time, with pod name, node name, and full message
```

### What the app logs that feeds into DT:
```yaml
# charts/payment-service/values.yaml (production)
env:
  - { name: LOG_LEVEL, value: "WARN" }      # only WARN+ goes to DT in production

# charts/payment-service/values-dev.yaml (dev)
env:
  - { name: LOG_LEVEL, value: "DEBUG" }     # all logs in dev
  - { name: SHOW_SQL,  value: "true" }      # SQL queries logged in dev
```

**SRE use case:** Davis AI opens a Problem for payment-service at 02:14. You navigate to the Problem in Dynatrace, click "Relevant events", and the log analytics panel shows the WARN/ERROR log lines from payment-service that occurred during the problem window — without opening a separate log system.

### Log + Trace correlation:
If the Java app includes trace IDs in log output (standard Spring + MDC):
```
2026-07-31 02:14:33 WARN [payment-service] [trace=abc123,span=def456] Payment processing failed
```

Dynatrace links that log line to the distributed trace for `trace=abc123`. Click the trace ID → jump from the log to the full PurePath showing exactly which DB query or downstream call failed at that moment.

---

## FEATURE 9: Kubernetes Monitoring (Infrastructure Layer)

### How it's enabled:
```yaml
# DynaKube spec
spec:
  activeGate:
    capabilities: [routing, kubernetes-api-monitoring, log-analytics]
  kubernetesMonitoring:
    enabled: true
  annotations:
    feature.dynatrace.com/automatic-kubernetes-api-monitoring: "true"
```

ActiveGate calls the Kubernetes API server and scrapes cluster-state metrics:

```
Kubernetes-level metrics Dynatrace collects:

Node metrics:
  Node CPU utilization (per node, per AZ)
  Node memory utilization
  Node disk pressure, memory pressure, network unavailability conditions

Workload metrics:
  Deployment replicas desired vs. available
  Pod restart counts (feeds Signal 7: pod restarts alert)
  Pod pending time (how long pods wait to be scheduled)
  OOMKill events

Container metrics:
  Container CPU throttling (% of time CPU was throttled)
  Container memory usage vs. limit

Cluster-level:
  Total cluster CPU/memory utilization
  Resource quota usage
  Node count over time (HPA-driven scaling visible)
```

**SRE use case:** Payment-service P99 spiked at 14:30. You check the Kubernetes workload view in Dynatrace and see: at 14:28, the payment-service HPA scaled from 3 to 6 pods. The new pods were in `Pending` state for 2 minutes while nodes were provisioned by Karpenter. During that 2-minute gap, the 3 original pods were overloaded → P99 spiked. Root cause: HPA scale-out lag. Fix: add more buffer capacity or pre-warm nodes.

---

## FEATURE 10: Davis AI (Automatic Root Cause Analysis)

### What Davis does automatically (no configuration needed):
Davis is Dynatrace's AI engine that correlates all the data above into a unified **Problem** rather than a storm of individual alerts.

**Example scenario:**
```
14:30:00  JVM heap rises to 75% (signal 6 fires: WARNING level, 15 min delay not yet hit)
14:30:30  G1GC full GC pause: 800ms
14:30:31  P99 latency jumps to 650ms (signal 3 fires after 2 min sustained: WARNING)
14:32:00  Error rate rises to 0.3% (signal 2 fires: HIGH level)
14:32:30  Traffic drop detected (fewer requests completing successfully)
14:33:00  Synthetic probe: response_time_limit exceeded
14:33:05  Synthetic probe: HTTP timeout
14:33:05  AVAILABILITY: payment-service unreachable (CRITICAL: 0 min delay → PagerDuty fires)
```

Without Davis: on-call gets 6 separate alerts in 3 minutes and has to manually figure out which was the root cause.

**With Davis:**
```
Davis opens ONE Problem: "payment-service performance degradation"
Root cause: JVM heap exhaustion → GC pauses → latency cascade → service degraded
Evidence trail:
  1. Heap utilization increased (started 14:29)
  2. GC pause detected (14:30:30)
  3. Response time increase began (14:30:31)
  4. Error rate increase (14:32:00)
  5. Service unavailable (14:33:05)
Affected entities: payment-service, 3 pods, 3 upstream users
Suggested action: scale out (HPA has headroom) or increase Xmx
```

One Problem, one root cause, one action. MTTR drops from hours to minutes.

### Davis correlates across:
- Deployment events (did a new image deploy just before this?)
- Config changes (Terraform applied recently?)
- Infrastructure changes (node added/removed?)
- Cross-service dependencies (did order-service slow down first, causing payment cascade?)

---

## FEATURE 11: Notification Channels (PagerDuty + Slack)

### The routing by severity:
```hcl
# CRITICAL (production only) → PagerDuty (wakes up on-call at 3am)
resource "dynatrace_pagerduty_notification" "critical" {
  for_each         = var.pagerduty_integration_keys
  alerting_profile = dynatrace_alerting.critical[each.key].id
  service_api_key  = each.value     # map: payments → pd-payments-key
}

# HIGH (prod + staging) → PagerDuty
resource "dynatrace_pagerduty_notification" "high" {
  for_each = contains(["production", "staging"], var.environment) ? var.pagerduty_integration_keys : {}
}

# WARNING → Slack #alerts-{team}
resource "dynatrace_slack_notification" "warning" {
  for_each = var.slack_webhook_urls
  channel  = "#alerts-${each.key}"    # #alerts-payments, #alerts-orders, etc.
  message  = "[${upper(var.environment)}] {State} | {ProblemSeverity} | {ProblemTitle} | {ProblemURL}"
}

# INFO → Slack #monitoring (shared channel)
resource "dynatrace_slack_notification" "info" {
  for_each = var.slack_webhook_urls
  channel  = "#monitoring"
  message  = "[INFO][${upper(var.environment)}] {State} | ${each.key} | {ProblemTitle} | {ProblemURL}"
}
```

### Routing matrix:
| Severity | Dev | Staging | Production |
|----------|-----|---------|------------|
| CRITICAL (AVAILABILITY) | — | — | PagerDuty (immediate) |
| HIGH (ERROR) | — | PagerDuty | PagerDuty |
| WARNING (SLOWDOWN) | Slack #alerts-{team} | Slack #alerts-{team} | Slack #alerts-{team} |
| INFO (RESOURCE) | Slack #monitoring | Slack #monitoring | Slack #monitoring |

**Design rationale:**
- Dev: no on-call paging. Dev is intentionally relaxed. Slack only.
- Staging: paged for HIGH because staging validates production readiness. A real error rate in staging must be investigated before it reaches production.
- Production CRITICAL: immediate page. Downtime costs money and violates SLOs.
- WARNING/INFO everywhere: Slack is enough for trend-based signals. On-call paging is reserved for active emergencies.

---

## FEATURE 12: Terraform-as-Code for Observability Config

### Why managing Dynatrace config in Terraform matters:

Without IaC for observability:
```
Scenario: production has strict thresholds (0.1% error rate)
Someone manually sets staging to also use 0.1% → constant false alerts
Someone manually deletes the payment-service management zone → wrong team gets alerts
New service "search-service" added → nobody creates DT config → no alerts at all
```

With Terraform:
```
Add search-service to services map in staging/main.tf:
  "search-service" = {
    team = "search"
    slo_target = 99.5
    ...
  }

terraform apply:
  + dynatrace_management_zone_v2.team["search"]
  + dynatrace_alerting.critical["search"]
  + dynatrace_alerting.high["search"]
  + dynatrace_metric_events.traffic_drop["search-service"]
  + dynatrace_metric_events.error_rate["search-service"]
  + (24 more resources)

All 24 DT resources created automatically. Search team has full observability in 5 minutes.
```

### The terraform-dynatrace-production.yaml CI pipeline:
```yaml
apply-production:
  environment: production    ← requires manual approval
  steps:
    - terraform apply -auto-approve
```

Even Dynatrace config changes to production require human approval. Accidentally lowering the error-rate threshold from 0.1% to 0.01% could trigger thousands of false alerts and page every on-call engineer in the company.

---

## How All Features Connect: The Incident Response Flow

```
02:14 UTC
  Synthetic probe (Tokyo): payment.company.com response time > 900ms
  OneAgent: P99 latency on payment-service = 1.2s (threshold: 300ms)
  OneAgent: JVM heap utilization = 84% (threshold: 70%)
  OneAgent: error rate = 0.2% (threshold: 0.1%)

  Davis AI:
    Opens Problem: "payment-service performance degradation"
    Root cause: JVM heap → GC pauses → latency → errors
    Severity: CRITICAL (service degraded)

  Alerting profile: CRITICAL → 0 min delay → PagerDuty fires
  PagerDuty: pages payments team on-call (Alice)

02:16 UTC  Alice opens the Problem in Dynatrace
  Management zone: payments-production (only payment entities)
  Davis shows: root cause = heap exhaustion since 02:09

02:17 UTC  Alice clicks "Analyze traces"
  PurePaths: payment/checkout requests taking 1.4s (normally 200ms)
  Trace shows: no slow DB queries, no slow downstream calls
  GC activity: multiple G1GC full GC events visible in JVM metrics

02:18 UTC  Alice checks the Log Viewer
  Log Analytics: 3 log lines: "GC overhead limit exceeded" at 02:09, 02:12, 02:14
  Links to traces: all three payment failures correlated

02:19 UTC  Alice scales out via HPA:
  kubectl patch hpa payment-service -n payment-ns \
    --patch '{"spec":{"minReplicas":6}}'

02:21 UTC  New pods running, heap distributed across 6 pods instead of 3
  P99: back to 210ms
  Error rate: 0%
  Heap per pod: 42%

02:22 UTC  Davis closes the Problem automatically
  Total MTTR: 8 minutes
  Without Dynatrace: 30-90 minutes of log grepping
```

---

## Enhancement Opportunities Beyond the Current Setup

The project covers the foundation. SRE teams typically add these next:

### 1. Custom Business Metrics via OTLP
```java
// In payment-service application code
Meter meter = openTelemetry.getMeter("payment-service");
LongCounter paymentsProcessed = meter.counterBuilder("payments.processed")
  .setDescription("Total payments processed")
  .build();

// Record on each payment:
paymentsProcessed.add(1, Attributes.of(
  AttributeKey.stringKey("currency"), payment.getCurrency(),
  AttributeKey.stringKey("method"), payment.getMethod()
));
```

The `OTEL_EXPORTER_OTLP_ENDPOINT` in values.yaml already points to ActiveGate. This custom metric appears in Dynatrace automatically. SRE dashboard: "payments.processed by currency, last 24h."

### 2. Session Replay (Real User Monitoring)
Add the DT RUM JavaScript snippet to the frontend. Dynatrace records user sessions — exactly which buttons were clicked, which API calls were made, and what errors the user saw. When a user reports "checkout was broken at 2pm", you can replay their exact session.

### 3. Davis Feedback Loop
When Davis opens a Problem and an SRE fixes it, mark the Problem resolution with a "root cause confirmation" in Dynatrace. Davis learns from this feedback and improves its future root-cause accuracy for your specific service patterns.

### 4. Anomaly Detection (Dynamic Baselines)
Instead of static thresholds (error rate > 0.1%), Davis can learn the normal pattern and alert when the metric deviates significantly from its own baseline — even if it never crosses the hard threshold. Useful for services with variable traffic patterns (e.g., order-service spikes every Monday morning).

### 5. Release Tracking (Deployment Events)
In the CI pipeline, after a deploy, push a deployment event to Dynatrace:
```bash
curl -X POST "https://TENANT.live.dynatrace.com/api/v1/events" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  -d '{
    "eventType": "CUSTOM_DEPLOYMENT",
    "source": "GitHub Actions",
    "deploymentName": "payment-service",
    "deploymentVersion": "$IMAGE_TAG",
    "entitySelector": "type(SERVICE),tag(payment-service)"
  }'
```

Dynatrace shows a vertical marker on ALL metric graphs at the deploy time. "This P99 spike started exactly when the new image deployed" becomes visually obvious.
