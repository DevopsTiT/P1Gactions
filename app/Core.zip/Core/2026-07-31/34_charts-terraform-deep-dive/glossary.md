# Glossary — Charts, Terraform Modules, Dockerfile Deep-Dive
Every term from main.md. One entry per term. SRE beginner level.

---

**Helm**
A Kubernetes package manager. A Helm chart bundles all Kubernetes YAML templates for a service into a reusable, parameterized package. Why it matters: instead of maintaining 7 separate YAML files per environment (21 total for 3 envs), you maintain 7 templates + 3 small values files.

**Helm chart**
A directory containing `Chart.yaml` (metadata), `values.yaml` (default config), and `templates/` (YAML templates with Go template syntax). Why it matters: the chart is the single source of truth for how a service is deployed to Kubernetes.

**`values.yaml`**
The default configuration for a Helm chart. Contains production-grade defaults. Overridden by `values-dev.yaml` or `values-staging.yaml` for other environments. Why it matters: production defaults protect against accidental under-provisioning — base config is always production-grade.

**`values-dev.yaml` / `values-staging.yaml`**
Override files containing ONLY the fields that differ from production defaults. Merged on top of `values.yaml` — later file wins on conflicts. Why it matters: avoids duplicating the full config per environment — only the diff (1 replica, smaller JVM) is in the override file.

**Helm template (`{{- range }}`)**
Go template syntax for iterating over a list. `{{- range .Values.namespaces }}` creates one Kubernetes Namespace object per item in the list. Why it matters: one template creates all 6 namespaces — no copy-paste of the same YAML block 6 times.

**`toYaml | nindent 4`**
Helm function that serializes a Go map/list to YAML and indents it by 4 spaces. Used for injecting structured values (labels, resources, probes) into templates. Why it matters: prevents YAML indentation errors when embedding maps inside templates.

**Multi-stage Docker build**
A Dockerfile pattern with multiple `FROM` lines. Stage 1 compiles the code (full JDK). Stage 2 runs it (JRE only). Final image contains only Stage 2. Why it matters: production image excludes compiler, source code, and build tools — smaller and more secure.

**eclipse-temurin**
An OpenJDK distribution maintained by the Eclipse Adoptium project. Provides official Docker images for Java 21 LTS. Why it matters: a trusted, regularly patched JDK for production containers — not an unofficial or unmaintained build.

**Alpine Linux**
A minimal Linux distribution (~5MB) used as base image for Docker containers. Uses musl libc instead of glibc. Why it matters: 5× smaller than Debian-based images, fewer packages = fewer CVEs in Trivy scans, faster image pulls.

**`bootJar` (Gradle Spring Boot)**
A Gradle task that creates a "fat JAR" — a single executable JAR file containing the application code AND all dependencies (Spring, Hibernate, AWS SDK, etc.). Why it matters: the entire application ships as one file; the container needs only `java -jar app.jar` to start.

**`--no-daemon` (Gradle)**
Disables the Gradle background daemon process. The daemon is designed for persistent local development. In Docker builds there's no next build to warm up for. Why it matters: the daemon stays alive waiting for a next build that never comes, wasting memory in CI.

**`$JVM_OPTS`**
An environment variable injected by Kubernetes (from the Helm values `JVM_OPTS` field) into the container at runtime. The Dockerfile ENTRYPOINT reads it: `java $JVM_OPTS -jar app.jar`. Why it matters: different JVM settings per environment (dev: 256m heap, prod: 1024m heap) without rebuilding the Docker image.

**`-Xms` / `-Xmx`**
JVM flags for initial and maximum heap size. `-Xms128m -Xmx256m` = start with 128MB heap, grow to max 256MB. Why it matters: setting these correctly prevents OOM kills (limit too low) and memory waste (limit too high).

**`-XX:+UseContainerSupport`**
JVM flag that makes the JVM read memory limits from the container cgroup (not the host). Without it: JVM inside a 1GB container thinks it has access to the node's 32GB RAM → allocates huge heap → OOM kill. Why it matters: required for every Java container on Kubernetes.

**`-XX:+UseG1GC`**
Explicitly enables the G1 Garbage Collector (default since Java 9, but explicit is clearer). Why it matters: G1GC is designed for large heaps with bounded pause times, suitable for latency-sensitive services.

**`-XX:MaxGCPauseMillis=200`**
Hints to G1GC: try to keep GC stop-the-world pauses under 200ms. G1GC adjusts its collection frequency to meet this target. Why it matters: for payment-service with 300ms P99 SLO, a 200ms GC pause eats 67% of the budget — this flag limits GC impact on latency.

**`jdwp` (Java Debug Wire Protocol)**
A protocol for remote Java debugging. `-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005` opens port 5005 for a debugger connection. Why it matters: dev engineers can `kubectl port-forward` and attach IntelliJ/VS Code debugger to a live dev pod — set breakpoints, inspect variables.

**`suspend=n`**
JDWP option meaning "do not wait for debugger to attach before starting the JVM." Without this: the pod waits indefinitely for a debugger connection → never starts → fails startupProbe → CrashLoopBackOff. Why it matters: critical — always include `suspend=n` in debug agent string.

**`readOnlyRootFilesystem: true`**
Kubernetes security context setting that prevents the container from writing to its own filesystem. Any write attempt returns "Permission denied." Why it matters: a compromised container cannot install malware, modify binaries, or persist data across restarts — the attack surface is dramatically reduced.

**`runAsNonRoot: true`**
Forces the container to run as a non-root user. If the image's USER is root, Kubernetes refuses to start the pod. Why it matters: root in a container has host-level privileges if the container escapes (kernel exploit). Non-root limits the blast radius.

**`capabilities: drop: ["ALL"]`**
Removes all Linux capabilities from the container process. Normal processes have capabilities like `NET_RAW` (raw sockets), `SYS_PTRACE` (process tracing). Why it matters: fewer capabilities = fewer ways a compromised container can attack the host or other containers.

**Namespace (Kubernetes)**
A virtual partition inside a cluster that groups related resources. `payment-ns` contains payment-service pods, services, secrets. Why it matters: namespaces enable RBAC (only payments team can access payment-ns), network policies, and resource quotas per team.

**Namespace labels (Kubernetes)**
Key-value tags on a Namespace that all pods inside inherit for certain purposes (like Dynatrace auto-tagging). `team: payments, environment: production`. Why it matters: OneAgent reads these to auto-tag all pods in the namespace — powers the entire Dynatrace alerting routing chain.

**`ClusterIP` (Kubernetes Service type)**
A Service type that assigns a stable virtual IP reachable only WITHIN the cluster. External traffic cannot reach ClusterIP directly. Why it matters: all internal service-to-service communication uses ClusterIP. External traffic goes through an ALB → Ingress → Service.

**`port` vs `targetPort` (Kubernetes Service)**
`port`: what callers use to connect to the Service (e.g., port 80). `targetPort`: the actual port the container listens on (e.g., 8080). The Service translates between them. Why it matters: decouples the internal port (8080, Spring Boot default) from the calling convention (80, HTTP standard).

**`replicaCount`**
The desired number of pod replicas. Set to 3 in production (one per AZ), 2 in staging, 1 in dev. Why it matters: production needs 3 for AZ redundancy — one AZ failure leaves 2 pods running.

**Rolling update strategy**
Kubernetes deployment strategy that replaces pods gradually, maintaining availability throughout. `maxUnavailable: 0, maxSurge: 1` = never reduce below current count, add 1 at a time. Why it matters: zero-downtime deploys — users are always served by the current version until new pods are proven healthy.

**`maxUnavailable: 0`**
During a rolling deploy, this prevents the number of running pods from dropping below `replicaCount`. Always at least 3 pods are serving traffic. Why it matters: prevents partial-capacity deploys from causing latency spikes under production load.

**`maxSurge: 1`**
During a rolling deploy, at most 1 extra pod above `replicaCount` can exist simultaneously. With 3 replicas: max 4 pods at any one time. Why it matters: limits the resource overhead of the deploy window (only 1 extra pod, not 3 extra).

**Startup probe**
A Kubernetes health check that runs ONLY during the initial pod startup phase. Other probes are paused while the startup probe runs. `failureThreshold: 60 × periodSeconds: 10 = 10 min`. Why it matters: Java Spring Boot with Dynatrace injection takes 5-10 min on first cold start. Without startup probe, liveness kills the pod before it finishes starting.

**Readiness probe**
A Kubernetes health check that runs continuously after startup. Failing pods are removed from the Service's load balancing pool (no traffic sent to them) but NOT killed. Why it matters: detects "temporarily unhealthy" states (DB is slow, cache reconnecting) without triggering a restart.

**Liveness probe**
A Kubernetes health check that runs continuously. Failing pods are KILLED and restarted. `failureThreshold: 3 × periodSeconds: 15 = 45s` before restart. Why it matters: detects true deadlocks or zombie processes that can never recover on their own.

**`/actuator/health/liveness` vs `/actuator/health/readiness`**
Spring Boot Actuator health endpoints. `/liveness`: "is the JVM alive?" (lightweight). `/readiness`: "are all dependencies (DB, cache, queue) connected?" (heavyweight). Why it matters: never use `/readiness` for liveness — if DB is down, liveness would restart all pods indefinitely.

**`preStop` hook**
A lifecycle hook that runs BEFORE the container receives SIGTERM. Used here: `sleep 15` to allow ALB deregistration (takes 10-15s) to complete before the Spring Boot shutdown begins. Why it matters: without this sleep, ALB continues routing to the shutting-down pod for ~15s → 503 errors for users during every rolling deploy.

**`terminationGracePeriodSeconds: 60`**
Total time Kubernetes gives a pod to exit cleanly after SIGTERM before sending SIGKILL. `15s preStop + 30s Spring shutdown + 15s buffer = 60s`. Why it matters: if Spring Boot takes longer than 60s to drain in-flight requests, Kubernetes kills it mid-request — payment transactions in-flight would fail.

**`topologySpreadConstraints`**
Kubernetes settings controlling how pods are distributed across failure domains (AZs, nodes). `maxSkew: 1, topologyKey: zone, whenUnsatisfiable: DoNotSchedule` = hard: 1 pod per AZ. Why it matters: guarantees payment-service pods spread across 3 AZs — one AZ failure never takes down all replicas.

**`whenUnsatisfiable: DoNotSchedule` vs `ScheduleAnyway`**
`DoNotSchedule` = hard constraint: pod stays Pending rather than violate the spread rule. Production. `ScheduleAnyway` = soft constraint: Kubernetes tries to spread but co-locates if necessary. Dev/staging. Why it matters: production must guarantee AZ spread; dev may have only 1 node.

**HPA (Horizontal Pod Autoscaler)**
A Kubernetes controller that automatically adjusts `spec.replicas` based on CPU/memory/custom metrics. Scale up fast (3 pods/min), scale down slow (1 pod/min, 5-min window). Why it matters: handles traffic spikes automatically — no manual intervention needed when load increases.

**`stabilizationWindowSeconds: 300`**
HPA setting: wait 5 minutes of sustained LOW load before scaling down. Prevents flapping (scale down → traffic returns → scale up → scale down). Why it matters: JVM warmup cost — keeping warm pods alive is cheaper than destroying them and paying warmup cost again.

**PDB (PodDisruptionBudget)**
A Kubernetes policy that limits how many pods of a deployment can be voluntarily disrupted simultaneously. `minAvailable: 2` with 3 replicas = at most 1 pod can be evicted at a time. Why it matters: prevents EKS node upgrades from draining all payment-service pods at once, leaving zero capacity.

**`minAvailable`**
The minimum number of pods that must remain running during voluntary disruptions. `minAvailable: 2` = at most 1 pod can be evicted. If `minAvailable == replicaCount`: node drain is blocked forever — a common mistake. Why it matters: the PDB setting determines whether EKS upgrades can proceed at all.

**Voluntary vs involuntary disruption**
Voluntary: Kubernetes-controlled events (node drain, rolling update, `kubectl delete pod`). PDB protects against these. Involuntary: hardware failure, OOM kill, kernel panic. PDB cannot prevent these. Why it matters: PDB gives you control over planned maintenance windows, not random failures.

**ServiceAccount (Kubernetes)**
An identity for a pod. Used by IRSA to grant the pod AWS IAM permissions. Every pod has a service account (default if not specified). Why it matters: the service account is the mechanism for giving a pod AWS access without static credentials.

**IRSA (IAM Roles for Service Accounts)**
AWS feature that links a Kubernetes ServiceAccount to an IAM role via OIDC. The pod gets temporary AWS credentials that auto-rotate every hour. No static access keys needed. Why it matters: secure, zero-credential-management AWS access for pods — used by payment-service to access RDS, SQS, Secrets Manager.

**ExternalSecret**
An ESO custom resource that pulls secrets from AWS Secrets Manager and creates a Kubernetes Secret. The Deployment reads the K8s Secret via `envFrom.secretRef`. Why it matters: DB passwords never live in Git or Helm values — they come from Secrets Manager at runtime, refreshed hourly.

**`refreshInterval: 1h` (ExternalSecret)**
ESO re-reads the Secrets Manager path every hour. If RDS rotates the DB password, the K8s Secret is updated within 1 hour. Why it matters: supports automated credential rotation — no manual intervention needed when RDS rotates passwords.

**`creationPolicy: Owner`**
ExternalSecret setting: ESO "owns" the created K8s Secret. When ExternalSecret is deleted, the K8s Secret is also deleted (no orphaned secrets left in the namespace). Why it matters: clean teardown — decommissioning a service removes all its secrets automatically.

**VPC CIDR**
The IP address range for the entire VPC. `10.0.0.0/16` = 65,536 IP addresses. Divided into subnets for public, private, and database tiers. Why it matters: the CIDR must be large enough to accommodate all subnets and future growth.

**`cidrsubnet()`**
Terraform function that calculates a subnet CIDR from a parent CIDR. `cidrsubnet("10.0.0.0/16", 4, 16)` = `10.0.0.0/20` (4096 IPs). Why it matters: automatically calculates non-overlapping subnet CIDRs — no manual IP planning.

**Private subnet `/20`**
A subnet with 4096 IP addresses. Used for EKS pods because VPC CNI assigns one IP per pod. 10 nodes × 58 pods/node = 580 pod IPs needed, plus future growth. Why it matters: `/24` (256 IPs) fills up quickly with HPA scaling — `/20` provides room for hundreds of pods.

**NAT Gateway**
An AWS managed service that allows resources in private subnets (EKS pods) to make outbound internet connections (ECR image pulls, DT ActiveGate → DT cloud) without having public IPs. Why it matters: without NAT, private subnet pods cannot reach the internet.

**`one_nat_gateway_per_az = true`**
Creates a separate NAT Gateway in each AZ. More expensive (~3× cost) but means an AZ-specific NAT failure only affects that AZ's private subnet. Why it matters: production resilience — a single NAT failure would cut all pods' internet access.

**VPC Gateway Endpoint for S3**
A free AWS network endpoint that routes S3 traffic through AWS's private network instead of the public internet. ECR Docker image layers are stored in S3 — without this endpoint, every image pull goes through the NAT Gateway. Why it matters: eliminates NAT data transfer charges for image pulls — can save hundreds of dollars/month.

**Private subnet tags for ALB and Karpenter**
Tags like `kubernetes.io/role/elb = "1"` tell the AWS Load Balancer Controller which subnets to create ALBs in. `karpenter.sh/discovery = cluster_name` tells Karpenter where to launch new EC2 instances. Why it matters: without these tags, ALB creation fails and Karpenter cannot provision new nodes.

**`cluster_endpoint_public_access = false`**
Disables public internet access to the Kubernetes API server. API access only works from inside the VPC. Why it matters: the k8s API server is the master control plane — internet-exposed API servers are prime targets for credential stuffing and CVE exploitation.

**IMDSv2 (`http_tokens = "required"`)**
Instance Metadata Service version 2 — requires a token to access node metadata. Prevents pods from easily accessing the EC2 instance's IAM credentials via a simple curl. Why it matters: prevents a compromised pod from stealing node IAM credentials and escalating to full EC2 control.

**`http_put_response_hop_limit = 2`**
Sets the TTL for IMDS requests to 2. Hop 1 = the EC2 instance. Hop 2 = containers on the instance. Setting to 1 blocks pod IMDS access (breaks IRSA). Setting to 2 allows IRSA to work while still blocking nested container escapes. Why it matters: the exact right value for EKS — enables IRSA while maintaining security.

**EKS managed addons**
AWS-managed Kubernetes components installed and upgraded by AWS. CoreDNS (DNS), kube-proxy (iptables), VPC CNI (pod IPs), EBS CSI driver (persistent volumes). Why it matters: AWS handles patching and upgrades — no manual addon management.

**CoreDNS**
The DNS server for the Kubernetes cluster. Resolves service names like `payment-service.payment-ns.svc.cluster.local` to their ClusterIPs. Why it matters: without CoreDNS, all inter-service calls by name fail — the entire cluster's service mesh collapses.

**VPC CNI**
AWS VPC Container Network Interface plugin. Assigns real VPC IP addresses to pods (not virtual overlay IPs). `before_compute = true` ensures it's installed before nodes join. Why it matters: without VPC CNI, pods have no network connectivity. Must be installed first — if nodes start without it, pods remain in a broken state.

**`taint: dedicated=system:NoSchedule`**
A Kubernetes taint on system nodes that prevents application pods (without a matching toleration) from being scheduled there. Keeps CoreDNS, Dynatrace Operator, and other system components on dedicated hardware. Why it matters: application pods consuming all CPU on a system node could kill CoreDNS → DNS fails → entire cluster communication breaks.

**EKS audit logs (`cluster_enabled_log_types`)**
CloudWatch log streams for the EKS control plane: `audit` (every kubectl command), `api` (API server internals), `authenticator` (IAM auth). Why it matters: required for security compliance and forensics — if there's a breach, audit logs show exactly what commands were run and by whom.
