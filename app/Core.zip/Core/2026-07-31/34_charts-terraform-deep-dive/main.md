# Every File Deep-Dive — charts/ + terraform/modules/ + services/Dockerfile
> Project: `38_java-3envs-dynatrace`
> This document covers the files NOT yet deep-dived: Helm charts, Terraform infra modules, and Dockerfiles.

---

## File Tree — What This Document Covers

```
38_java-3envs-dynatrace/
│
├── services/
│   └── payment-service/Dockerfile          ← Part 1
│
├── charts/
│   ├── namespaces/
│   │   ├── Chart.yaml
│   │   ├── values.yaml
│   │   └── templates/namespace.yaml        ← Part 2
│   │
│   └── payment-service/   (order + notification are identical pattern)
│       ├── Chart.yaml                      ← Part 3
│       ├── values.yaml          (production defaults)  ← Part 4
│       ├── values-dev.yaml      (dev overrides)        ← Part 5
│       ├── values-staging.yaml  (staging overrides)    ← Part 5
│       └── templates/
│           ├── deployment.yaml             ← Part 6
│           ├── service.yaml                ← Part 7
│           ├── ingress.yaml                ← Part 8
│           ├── hpa.yaml                    ← Part 9
│           ├── pdb.yaml                    ← Part 10
│           ├── serviceaccount.yaml         ← Part 11
│           └── external-secret.yaml        ← Part 12
│
└── terraform/modules/
    ├── vpc/main.tf                         ← Part 13
    └── eks/main.tf                         ← Part 14
```

---

## Part 1 — `services/payment-service/Dockerfile`

```dockerfile
FROM eclipse-temurin:21-jdk-alpine AS builder
WORKDIR /app
COPY build.gradle settings.gradle ./
COPY src ./src
RUN ./gradlew bootJar --no-daemon

FROM eclipse-temurin:21-jre-alpine
WORKDIR /app
COPY --from=builder /app/build/libs/*.jar app.jar
EXPOSE 8080
ENTRYPOINT ["sh", "-c", "java $JVM_OPTS -jar app.jar"]
```

### Multi-stage build — why two FROM lines

```
STAGE 1 (builder): eclipse-temurin:21-jdk-alpine
  Contains: full JDK (compiler, build tools, Gradle)
  Size: ~350MB
  Purpose: compile Java source code → produce app.jar

STAGE 2 (final): eclipse-temurin:21-jre-alpine
  Contains: JRE only (just the runtime, no compiler)
  Size: ~85MB
  Purpose: RUN the app.jar in production

Final image only contains Stage 2.
Stage 1 artifacts (build tools, source code, Gradle cache) are DISCARDED.

Why this matters:
  Without multi-stage: image includes the full JDK + source code = security risk + large image
  With multi-stage: production image = only JRE + compiled JAR = smaller attack surface
  Production image: ~150MB total vs ~500MB without multi-stage
```

### `eclipse-temurin:21-jdk-alpine`

```
eclipse-temurin: OpenJDK distribution maintained by the Eclipse Foundation (Adoptium)
21: Java 21 LTS (Long-Term Support) — virtual threads, record classes, pattern matching
alpine: based on Alpine Linux (5MB base OS) instead of Debian (100MB)

Why Alpine:
  Smaller attack surface — fewer packages = fewer CVEs
  Faster image pulls (less to download)
  Same JVM performance (Alpine uses musl libc, Temurin handles this correctly)
```

### `./gradlew bootJar --no-daemon`

```
gradlew: the Gradle wrapper — uses the project-specific Gradle version (no system Gradle needed)
bootJar: Spring Boot Gradle task — creates a fat JAR (app + all dependencies in one file)
--no-daemon: disables the Gradle daemon background process
  Why no-daemon in Docker?
  The daemon is designed to persist between builds (speeds up local dev).
  In Docker, each RUN command is a one-time build — the daemon has no future builds to warm up.
  Keeping it alive would waste memory and delay container shutdown.
```

### `COPY --from=builder /app/build/libs/*.jar app.jar`

```
--from=builder: copies FROM the first stage (builder), not from the host filesystem
/app/build/libs/*.jar: the fat JAR produced by bootJar
app.jar: renames it to a simple, consistent name

Why rename to app.jar?
  The actual file is named like: payment-service-2.3.1.jar
  Using app.jar: ENTRYPOINT never needs to change when the version changes
  One less thing to update on every release
```

### `ENTRYPOINT ["sh", "-c", "java $JVM_OPTS -jar app.jar"]`

```
["sh", "-c", "..."]: exec form — runs sh to expand the $JVM_OPTS variable
                     (direct exec form ["java", "$JVM_OPTS", "-jar", "app.jar"] 
                      does NOT expand env vars — shell expansion required)

$JVM_OPTS: injected by Kubernetes via env vars in values.yaml:
  Production: -Xms512m -Xmx1024m -XX:+UseContainerSupport -XX:MaxGCPauseMillis=200
  Dev:        -Xms128m -Xmx256m  -XX:+UseContainerSupport -agentlib:jdwp=...

Why external JVM_OPTS (not hardcoded in Dockerfile)?
  Same image for all 3 environments.
  Dev uses Xmx=256m (cheap). Production uses Xmx=1024m (powerful).
  No image rebuild needed when tuning JVM settings — just change values.yaml → redeploy.
```

### Key security settings in the Deployment (not in Dockerfile)

```yaml
# From deployment.yaml template:
securityContext:
  runAsNonRoot: true
  runAsUser: 1000       # runs as a non-root user (UID 1000)
  fsGroup: 1000

containers:
  securityContext:
    readOnlyRootFilesystem: true          # container cannot write to its own filesystem
    allowPrivilegeEscalation: false        # cannot gain more privileges than it started with
    capabilities:
      drop: ["ALL"]                        # removes all Linux capabilities (NET_RAW, SYS_ADMIN, etc.)

Why readOnlyRootFilesystem?
  A compromised container cannot write malware to disk (no persistence).
  Any write attempt → permission denied immediately.
  Spring Boot runs fine with read-only root (writes go to /tmp, which is a tmpfs mount).
```

---

## Part 2 — `charts/namespaces/templates/namespace.yaml`

```yaml
{{- range .Values.namespaces }}
apiVersion: v1
kind: Namespace
metadata:
  name: {{ .name }}
  labels:
    {{- toYaml .labels | nindent 4 }}
---
{{- end }}
```

### The Helm `range` loop

```
{{- range .Values.namespaces }}: iterates over the namespaces list in values.yaml
  Each iteration: `.name` = namespace name, `.labels` = the labels map
  `---` separator: produces multiple Kubernetes objects in one YAML file

Input (values.yaml from gitops ArgoCD app):
  namespaces:
    - name: payment-ns
      labels: { team: payments, environment: dev }
    - name: order-ns
      labels: { team: orders, environment: dev }
    - name: dynatrace
      labels: { team: platform, environment: dev }

Output (rendered YAML sent to Kubernetes):
  apiVersion: v1
  kind: Namespace
  metadata:
    name: payment-ns
    labels:
      team: payments
      environment: dev
  ---
  apiVersion: v1
  kind: Namespace
  metadata:
    name: order-ns
    labels:
      team: orders
      environment: dev
  ---
  ... (one block per namespace)
```

### Why the labels on namespaces are critical

```
These labels feed the ENTIRE Dynatrace alerting chain:

namespace label team: payments
       ↓ (OneAgent reads pod namespace labels)
DT auto-tag: team:payments applied to all services in payment-ns
       ↓
Management zone "payments-production" rule: include services tagged team:payments
       ↓
Alerting profile scoped to that management zone
       ↓
PagerDuty notification → payments team on-call

If you forget the labels:
  DT tags nothing → management zone is empty → NO alerts fire for payment-service
  This is the #1 "why is nobody getting paged?" bug

The namespace chart creates the labels ONCE, in one place.
Every service deployed to payment-ns automatically gets the right tags.
```

### How ArgoCD passes different values per environment

```
gitops/dev/namespaces/namespaces.yaml (ArgoCD Application):
  helm:
    values: |
      environment: dev
      namespaces:
        - name: payment-ns
          labels: { team: payments, environment: dev }   ← "dev"

gitops/production/namespaces/namespaces.yaml:
  helm:
    values: |
      environment: production
      namespaces:
        - name: payment-ns
          labels: { team: payments, environment: production }  ← "production"

Same chart template. Different labels injected at deploy time by ArgoCD.
```

---

## Part 3 — `charts/payment-service/Chart.yaml`

```yaml
apiVersion: v2
name: payment-service
description: Helm chart for the payment-service Java microservice
type: application
version: 1.0.0
appVersion: "1.0.0"
keywords: [payment, java, microservice]
maintainers:
  - name: Payments Team
    email: payments@company.com
```

### Fields explained

```
apiVersion: v2     → Helm 3 format (v1 = Helm 2, deprecated)
                     Must be v2 for Helm 3 charts.

name:              → used by Helm as the release name prefix
                     helm install payment-service ./charts/payment-service

type: application  → this chart deploys a running application
                     alternative: "library" (shared templates, not deployable)

version: 1.0.0     → CHART version (how the chart packaging changed)
                     Independent from appVersion.
                     Increment when you change templates or add/remove features.

appVersion: "1.0.0" → APPLICATION version (the payment-service binary version)
                      This is overridden at deploy time via:
                        image.tag: "${{ github.sha }}"
                      Informational only — the actual tag comes from values.

maintainers:       → who owns this chart (for documentation and contact)
                     shown in helm inspect output
```

### Why `version` and `appVersion` are separate

```
Chart changes (version bump):
  Added a new Kubernetes resource (e.g., added NetworkPolicy)
  Changed a template structure (e.g., renamed a label)
  Added a new configurable value (e.g., added sidecars support)

App changes (appVersion bump):
  New Java code → new JAR → new Docker image
  Does NOT require chart version change

Example:
  Chart v1.0.0 + App v2.3.1 → chart has these templates, app runs this code
  Chart v1.1.0 + App v2.3.1 → chart added NetworkPolicy, app is unchanged
  Chart v1.1.0 + App v2.4.0 → both changed independently

In this project: appVersion is mostly ignored because
image.tag = github.sha (set at CI time, not in Chart.yaml).
```

---

## Part 4 — `charts/payment-service/values.yaml` (Production Defaults)

```yaml
replicaCount: 3
image:
  repository: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  tag: "PLACEHOLDER"
  pullPolicy: IfNotPresent
```

### `replicaCount: 3` — why 3, not 2 or 5

```
3 replicas = the minimum for:
  1. High availability across 3 AZs (1 pod per AZ via topologySpreadConstraints)
  2. Zero-downtime rolling deploys:
     maxUnavailable: 0, maxSurge: 1 → during a deploy, 4 pods exist briefly (3+1)
     At no point are fewer than 3 pods serving traffic
  3. PDB minAvailable: 2 → at most 1 pod disrupted during node drain
     With 2 replicas and PDB=2: node drain is BLOCKED (can't evict the only remaining pod)
     With 3 replicas and PDB=2: node drain removes 1 pod, 2 remain healthy

Why not 2:
  2 replicas: if 1 pod dies, you have 50% capacity and zero redundancy
  In a 3-AZ cluster: 2 replicas = one AZ has no pod = traffic imbalance

Why not 5 (default):
  HPA handles scaling from 3 → 20 based on real load
  Starting at 5 wastes resources when traffic is low
  HPA is the right tool for this, not a high base count
```

### `image.pullPolicy: IfNotPresent` (production)

```
IfNotPresent: if the image already exists on the node, don't pull it again
Always:       always pull from ECR on every pod start
Never:        never pull (must already be cached)

Production uses IfNotPresent:
  Production pods are long-lived (weeks/months) and rarely restart
  SHA-tagged images are IMMUTABLE — same SHA = same bytes = no need to re-pull
  Reduces ECR bandwidth and pod startup time

Dev uses Always (in values-dev.yaml):
  Dev uses "latest-dev" tag which changes with every push
  Without Always: node's cached "latest-dev" is stale after next CI push
  With Always: every pod restart pulls the newest image
```

### Resources — requests vs limits

```yaml
resources:
  requests: { cpu: 250m, memory: 768Mi }
  limits:   { cpu: 1000m, memory: 1Gi }
```

```
requests:
  What Kubernetes RESERVES for this pod on the node.
  Kubernetes scheduler uses requests to find a node with enough capacity.
  250m CPU = 0.25 cores reserved. Other pods can use the rest.
  768Mi memory = guaranteed available (node won't be overbooked below this)

limits:
  The MAXIMUM the pod is allowed to use.
  CPU limit: if pod tries to use >1000m, Linux throttles it (slows down, not killed)
  Memory limit: if pod uses >1Gi, Linux OOM-kills it IMMEDIATELY (no warning)

Why limits > requests?
  Java Spring Boot is "bursty": uses 250m normally, spikes to 1000m during GC or traffic bursts
  If limit = request (250m): any traffic burst → throttled → latency spike
  Giving 4× headroom (250m → 1000m): absorbs spikes without throttling

Memory: requests (768Mi) vs limits (1Gi):
  JVM -Xmx=1024m: JVM can allocate up to 1024m heap
  Plus off-heap: JVM metadata, compiled code cache, thread stacks ≈ 300m
  Total JVM RSS at peak: ~1.3Gi → limit is 1Gi (tight!)
  Wait — but Xmx is 1024m and limit is 1Gi (1024Mi)?
  The limit is 1Gi = 1073Mi. JVM won't try to use 1024m heap simultaneously with all off-heap.
  In practice: heap utilization at 70% alert = 716m. Plenty of room.
```

### Probes — startup, readiness, liveness

```yaml
startupProbe:
  httpGet: { path: /actuator/health/liveness, port: 8080 }
  failureThreshold: 60
  periodSeconds: 10

readinessProbe:
  httpGet: { path: /actuator/health/readiness, port: 8080 }
  periodSeconds: 5
  failureThreshold: 3

livenessProbe:
  httpGet: { path: /actuator/health/liveness, port: 8080 }
  periodSeconds: 15
  failureThreshold: 3
```

```
THREE PROBES, THREE PURPOSES:

startupProbe (fires FIRST, during initial startup only):
  Question: "has the app finished starting up?"
  Fires every 10s, allows up to 60 failures = 10 minutes max startup time
  Why 10 minutes? Spring Boot + Dynatrace OneAgent injection + JIT = slow cold start
  WHILE startupProbe is running: readiness and liveness probes are PAUSED
  startupProbe passing once → switches to readiness + liveness

  If you removed startupProbe:
    livenessProbe would kill the pod after 3 × 15s = 45s even if it just needs more time
    Result: pod is killed during startup → CrashLoopBackOff → deployment hangs

readinessProbe (fires continuously after startup):
  Question: "is this pod ready to receive traffic?"
  Checks: /actuator/health/readiness → Spring checks DB connection, cache, queue connections
  Failing readiness: pod is removed from Service endpoints (traffic stops going to it)
  Pod is NOT killed — it just gets no new requests until it recovers
  Use case: DB is slow → readiness fails → pod removed from rotation → no 5xx for users

livenessProbe (fires continuously after startup):
  Question: "is this pod alive and not deadlocked?"
  Checks: /actuator/health/liveness → Spring checks that it can respond (no deadlock)
  Failing liveness (3 consecutive failures): pod is KILLED and restarted
  More dangerous than readiness — triggers a restart
  failureThreshold: 3 × periodSeconds: 15 = 45 seconds before restart

/liveness vs /readiness paths:
  /liveness: "can I respond at all?" (lightweight — just checks the JVM is alive)
  /readiness: "are all my dependencies working?" (heavyweight — checks DB, cache, queue)
  Never use /readiness for liveness — if DB is down, liveness would kill pods infinitely
```

### `preStop` hook and `terminationGracePeriodSeconds`

```yaml
lifecycle:
  preStop:
    exec:
      command: ["/bin/sh", "-c", "sleep 15"]
terminationGracePeriodSeconds: 60
```

```
When Kubernetes decides to stop a pod (rolling deploy, scale-down, node drain):

WITHOUT preStop sleep:
  1. Kubernetes sends SIGTERM to the pod
  2. Pod starts shutting down (Spring Boot graceful shutdown: 30s)
  3. Kubernetes removes pod from Service endpoints (ALB target group)
  Problem: Step 2 and Step 3 happen simultaneously.
  ALB takes 10-15s to deregister the target after receiving the deregistration signal.
  During those 15 seconds: ALB still routes requests to the shutting-down pod → 503 errors

WITH preStop sleep 15:
  1. Kubernetes triggers preStop hook → pod sleeps 15 seconds
  2. SIMULTANEOUSLY: Kubernetes removes pod from Service endpoints
  3. ALB deregisters the target (takes ~10-15 seconds — completed before sleep ends)
  4. After 15s sleep: pod receives SIGTERM → Spring Boot graceful shutdown begins
  5. By the time Spring Boot starts shutting down, ALB is already NOT sending it traffic
  Result: zero 503 errors during rolling deploys

terminationGracePeriodSeconds: 60:
  Total time Kubernetes waits before force-killing with SIGKILL.
  15s (preStop) + 30s (Spring shutdown) + 15s buffer = 60s total.
  If the pod doesn't exit within 60s → SIGKILL (instant death, in-flight requests fail)
```

### `topologySpreadConstraints` — AZ distribution

```yaml
topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: topology.kubernetes.io/zone
    whenUnsatisfiable: DoNotSchedule
    labelSelector:
      matchLabels: { app: payment-service }
```

```
maxSkew: 1:
  Maximum allowed difference in pod count between any two zones.
  With 3 pods and 3 AZs: target = 1 pod per AZ (0 skew = perfectly balanced)
  maxSkew: 1 allows: [2,1,0] but not [3,0,0] or [2,1,0] → actually [2,1,0] is allowed
  In practice: ensures no single AZ has 0 pods

topologyKey: topology.kubernetes.io/zone:
  Kubernetes spread constraint scope = AWS Availability Zone
  Each AZ is a separate failure domain (power, networking, hardware)

whenUnsatisfiable: DoNotSchedule:
  HARD constraint. Pod stays Pending rather than violating the spread.
  "DoNotSchedule" = Kubernetes will NOT place a pod in a zone that would exceed maxSkew
  
  Why hard in production:
    Payment service with all 3 pods in one AZ:
    AZ failure → all 3 pods die → payment service completely down → revenue loss
    Hard constraint: guarantees 1 pod per AZ at all times

  Why soft (ScheduleAnyway) in dev:
    Dev cluster may have only 1 node (single AZ).
    Hard constraint: no new pods can be scheduled (only 1 zone → maxSkew violated)
    Soft constraint: pods co-locate on the one available zone
```

---

## Part 5 — values-dev.yaml and values-staging.yaml

### Values merge mechanics

```
ArgoCD applies values files in ORDER:
  valueFiles: [values.yaml, values-dev.yaml]

Merge rule: LATER FILE WINS on conflicts, non-conflicting fields from earlier file are KEPT.

values.yaml:
  replicaCount: 3
  resources.limits.cpu: 1000m
  env[0]: SPRING_PROFILES_ACTIVE = production
  startupProbe.failureThreshold: 60

values-dev.yaml:
  replicaCount: 1                     ← OVERRIDES values.yaml
  resources.limits.cpu: 500m          ← OVERRIDES values.yaml
  env[0]: SPRING_PROFILES_ACTIVE = dev ← OVERRIDES (first env entry)
  startupProbe.failureThreshold: 120  ← OVERRIDES (more time for dev cold start)
  pdb.enabled: false                  ← ADDS / overrides

Result (what Kubernetes receives):
  replicaCount: 1         (from dev override)
  resources.limits.cpu: 500m (from dev override)
  startupProbe.failureThreshold: 120 (from dev)
  pdb.enabled: false      (from dev)
  readinessProbe: ...     (from values.yaml, untouched)
  livenessProbe: ...      (from values.yaml, untouched)
```

### Dev-specific settings explained

```yaml
# values-dev.yaml
replicaCount: 1         # 1 pod saves ~60% resource cost in dev
pullPolicy: Always      # always pull to get latest-dev tag changes
resources:
  limits: { cpu: 500m, memory: 512Mi }  # half of prod (cheap dev nodes)

JVM_OPTS:
  -Xms128m -Xmx256m                     # 4× smaller heap than prod
  -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005
  #   ↑ enables remote Java debugger
  #   jdwp = Java Debug Wire Protocol
  #   address=*:5005 = listen on port 5005, all interfaces
  #   suspend=n = app starts immediately (doesn't wait for debugger to attach)
  #   engineers use: kubectl port-forward pod/payment-service-xxx 5005:5005
  #   then: IntelliJ → Run → Attach to Remote JVM → localhost:5005

startupProbe:
  failureThreshold: 120  # 120 × 10s = 20 min startup budget
  # dev: slow because:
  #   - t3.medium node (not the powerful Graviton)
  #   - Docker image cache may be cold (VM restarted)
  #   - JIT compilation runs slower without warmup
  #   - Dynatrace OneAgent injection adds ~30s overhead on first start

pdb.enabled: false
  # PDB with 1 replica = node drain BLOCKED FOREVER
  # If PDB says "minAvailable: 1" and there's only 1 replica:
  #   Kubernetes needs to evict the pod for node drain
  #   But PDB says: "at least 1 must be available"
  #   Kubernetes refuses to evict
  #   Node drain hangs indefinitely
  # Fix: disable PDB entirely in dev (1 replica = no HA anyway)

topologySpreadConstraints.whenUnsatisfiable: ScheduleAnyway
  # dev cluster may have 1 or 2 nodes
  # Hard spread: pod stays Pending if it can't be placed in a new zone
  # Soft spread: pod schedules wherever it fits (co-location allowed)
```

### Staging-specific settings explained

```yaml
# values-staging.yaml
replicaCount: 2      # 2 replicas = real HA (not production-grade) but enough for k6

JVM_OPTS:
  -Xms256m -Xmx512m  # between dev (256m) and prod (1024m)
  # staging k6 with 50 VUs: heap fills to ~78% of 512m = 399m
  # our jvm_heap_pct threshold for staging is 78% → alert fires exactly at k6 peak

hpa:
  maxReplicas: 8     # k6 50 VUs may trigger CPU-based scale-out (prod allows 20)

pdb:
  enabled: true
  minAvailable: 1    # 2 replicas → at most 1 disrupted (half capacity during drain)
  # prod is minAvailable: 2 (3 replicas → at most 1 disrupted = 2 remaining)

topologySpreadConstraints.whenUnsatisfiable: ScheduleAnyway
  # staging cluster: 2 AZs (not 3 like production)
  # ScheduleAnyway: if only 2 AZs, both pods may land in same zone (acceptable for staging)
```

---

## Part 6 — `templates/deployment.yaml`

### Rolling update strategy

```yaml
strategy:
  type: RollingUpdate
  rollingUpdate:
    maxUnavailable: 0
    maxSurge: 1
```

```
maxUnavailable: 0:
  AT NO POINT can running replicas drop below the configured replicaCount.
  With 3 replicas: always at least 3 pods are Running and Ready during a deploy.

maxSurge: 1:
  At most 1 extra pod above replicaCount can exist during a deploy.
  With 3 replicas: max 4 pods during the rollout window.

Rolling deploy sequence with these settings (3 replicas):
  Start: [v1, v1, v1]
  Step 1: create 1 new v2 pod → [v1, v1, v1, v2(starting)]
  Step 2: v2 pod passes startupProbe + readinessProbe → [v1, v1, v1, v2(ready)]
  Step 3: terminate 1 v1 pod → [v1, v1, v2]
  Step 4: create 1 new v2 pod → [v1, v1, v2, v2(starting)]
  Step 5: v2 ready → terminate another v1 → [v1, v2, v2]
  ... (repeat until [v2, v2, v2])

At every step: at least 3 pods are serving traffic.
At no step: traffic drops below normal capacity.
```

### Template labels — why they appear twice

```yaml
metadata:
  labels:              # labels on the DEPLOYMENT object itself
    app: payment-service
    {{- range .Values.commonLabels }}
    {{ $k }}: {{ $v }}
    {{- end }}

spec:
  template:
    metadata:
      labels:          # labels on each POD
        app: payment-service
        {{- range .Values.commonLabels }}
        {{ $k }}: {{ $v }}
        {{- end }}
```

```
Deployment labels: for organizing/finding the Deployment object
Pod labels: for:
  1. Service selector (ClusterIP → pods with app=payment-service)
  2. HPA selector (targets Deployment named payment-service)
  3. PDB selector (matches pods with app=payment-service)
  4. Dynatrace auto-tagging (OneAgent reads pod labels)
  5. topologySpreadConstraints labelSelector

If pod labels are missing:
  Service can't route traffic to pods (selector doesn't match)
  DT auto-tagging misses the pods
  PDB protects nothing (no pods match its selector)
```

### `envFrom` and `env` — two sources of environment variables

```yaml
envFrom:
  - secretRef:
      name: payment-service-db-credentials  # creates env vars from ALL keys in the Secret
                                             # DB_HOST, DB_PORT, DB_NAME, DB_USERNAME, DB_PASSWORD
env:
  - { name: SPRING_PROFILES_ACTIVE, value: "production" }
  - { name: JVM_OPTS, value: "..." }
  - { name: OTEL_EXPORTER_OTLP_ENDPOINT, value: "..." }
```

```
envFrom (block import):
  Pulls ALL key-value pairs from a Secret as environment variables.
  payment-service-db-credentials Secret has: DB_HOST, DB_PORT, DB_NAME, DB_USERNAME, DB_PASSWORD
  All become env vars available to the Java process.
  Created by the ExternalSecret resource (which pulls from AWS Secrets Manager).

env (individual):
  Individual env vars — some from values.yaml (overridable per environment).
  SPRING_PROFILES_ACTIVE tells Spring Boot which profile to use (dev/staging/production)
  JVM_OPTS is read by the ENTRYPOINT in Dockerfile: java $JVM_OPTS -jar app.jar

Order of precedence (what wins if same key appears in both):
  env wins over envFrom (env is more specific → higher priority).
  This means: you can override an envFrom value by adding the same key to env.
```

---

## Part 7 — `templates/service.yaml`

```yaml
apiVersion: v1
kind: Service
metadata:
  name: payment-service
  namespace: payment-ns
spec:
  type: ClusterIP
  selector:
    app: payment-service
  ports:
    - name: http
      port: 80
      targetPort: 8080
      protocol: TCP
```

### `type: ClusterIP` — internal only

```
ClusterIP: gives the Service a stable internal IP address reachable only INSIDE the cluster.
  payment-service.payment-ns.svc.cluster.local → resolves to the ClusterIP
  All pods in the cluster can call payment-service on port 80.
  External traffic CANNOT reach ClusterIP directly.

External traffic path:
  Internet → ALB → Ingress → Service (ClusterIP) → pods

Why ClusterIP not LoadBalancer?
  LoadBalancer creates a new AWS ELB for each Service (expensive, slow).
  ClusterIP + Ingress: ONE ALB (from aws-load-balancer-controller) routes to all services.
  Much cheaper: 1 ALB total vs 1 ALB per service.
```

### port: 80 vs targetPort: 8080

```
port: 80:        what OTHER services inside the cluster use to call this Service
                 other-service calls: http://payment-service.payment-ns:80/api/v1/payments

targetPort: 8080: what port the actual container listens on
                  Spring Boot default: 8080
                  EXPOSE 8080 in the Dockerfile

The Service does port translation:
  Caller → port 80 → Service → port 8080 → pod

Why port 80 externally but 8080 internally?
  Port 80 = HTTP standard. Callers don't need to know/remember the Spring Boot port.
  If you ever change Spring Boot to port 9090: update targetPort only — all callers unchanged.
```

---

## Part 8 — `templates/ingress.yaml`

```yaml
annotations:
  alb.ingress.kubernetes.io/scheme: internet-facing
  alb.ingress.kubernetes.io/target-type: ip
  alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS": 443}]'
  alb.ingress.kubernetes.io/certificate-arn: {{ .Values.ingress.certArn }}
  alb.ingress.kubernetes.io/ssl-redirect: "443"
  alb.ingress.kubernetes.io/healthcheck-path: /actuator/health/readiness
  alb.ingress.kubernetes.io/healthcheck-interval-seconds: "15"
```

### Each ALB annotation explained

```
scheme: internet-facing
  Creates a public ALB with a public IP address accessible from the internet.
  Alternative: "internal" (VPC-only, no public IP — for internal APIs).
  payment.company.com must be internet-facing (customers access it).

target-type: ip
  ALB routes directly to POD IPs (not node IPs).
  Alternative: "instance" (routes to node IP → iptables → pod).
  "ip" is faster (one fewer hop), requires VPC CNI mode (which EKS uses).

listen-ports: HTTP:80 and HTTPS:443
  ALB listens on BOTH ports.
  ssl-redirect: "443" → any HTTP request is 301-redirected to HTTPS.
  Users typing http://payment.company.com automatically go to HTTPS.

certificate-arn: .Values.ingress.certArn
  The AWS Certificate Manager (ACM) TLS certificate ARN.
  ALB terminates HTTPS using this cert.
  Dev: certArn = "" → no HTTPS (Ingress template skips the annotation)
  Production: certArn = actual ACM cert ARN → HTTPS enabled

healthcheck-path: /actuator/health/readiness
  ALB sends health checks to this path on each target (pod).
  If health check fails: ALB removes pod from rotation.
  Must use /readiness (not /liveness): readiness checks DB, cache connectivity.
  If DB is down: readiness fails → pod removed from ALB → no 503s for users
  (users see no connection at all, which is handled by circuit breakers upstream)

healthcheck-interval-seconds: 15
  ALB checks every 15 seconds.
  If a pod is unhealthy, ALB detects it within 15s (plus the failureThreshold × 15s wait).
```

---

## Part 9 — `templates/hpa.yaml`

```yaml
spec:
  minReplicas: {{ .Values.hpa.minReplicas }}   # 3 (prod), 2 (staging), 1 (dev)
  maxReplicas: {{ .Values.hpa.maxReplicas }}   # 20 (prod), 8 (staging)
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70   # scale when average CPU > 70%
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: 80

  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300    # wait 5 min before scaling down
      policies:
        - type: Pods
          value: 1
          periodSeconds: 60              # remove at most 1 pod per minute
    scaleUp:
      policies:
        - type: Pods
          value: 3
          periodSeconds: 60              # add at most 3 pods per minute
```

### Scale up vs scale down behavior — why asymmetric

```
scaleUp: add 3 pods per minute (fast)
  Traffic spike happens fast (flash sales, bot attacks, viral moment).
  Adding replicas quickly prevents overload.
  3 pods/min: gets from 3 → 12 pods in 3 minutes if load is sustained.

scaleDown: remove 1 pod per minute with 5-min window (slow)
  Why slow?
  1. Traffic can come back: removing pods too fast → traffic returns → must scale up again → flapping
  2. JVM warmup cost: each new pod needs 1-5 min to warm up JIT. Destroying a warm pod is wasteful.
  3. stabilizationWindowSeconds: 300 → HPA waits until load has been LOW for 5 minutes before removing any pod.

The asymmetry protects against:
  Traffic fluctuation: scale up quickly to handle it, scale down slowly to avoid yo-yo behavior
  JVM cold start cost: keep warm pods alive longer (they serve faster than cold pods)
```

### Why HPA and ArgoCD's ignoreDifferences work together

```
ArgoCD gitops file says: replicaCount: 3
HPA changes spec.replicas to 8 during a traffic spike.
Without ignoreDifferences:
  ArgoCD detects "desired: 3, actual: 8" → drift!
  ArgoCD reverts replicas to 3 → HPA sees traffic → scales back to 8 → ArgoCD reverts → loop

With ignoreDifferences:
  gitops/dev/app/payment-service/payment-service.yaml:
    ignoreDifferences:
      - group: apps
        kind: Deployment
        jsonPointers: [/spec/replicas]
  ArgoCD ignores spec.replicas field when comparing desired vs actual.
  HPA manages replicas dynamically. ArgoCD manages everything else.
```

---

## Part 10 — `templates/pdb.yaml`

```yaml
{{- if .Values.pdb.enabled }}
apiVersion: policy/v1
kind: PodDisruptionBudget
spec:
  minAvailable: {{ .Values.pdb.minAvailable }}
  selector:
    matchLabels:
      app: payment-service
{{- end }}
```

### What PDB actually prevents

```
PDB protects against VOLUNTARY disruptions:
  Node drain (EKS upgrade, Karpenter scale-down, manual maintenance)
  kubectl delete pod
  Deployment rollout that would leave too few pods

PDB does NOT protect against INVOLUNTARY disruptions:
  Node hardware failure (Kubernetes can't stop that)
  OOM kill (kernel decides, not Kubernetes)
  Network partition

Production (3 replicas, minAvailable: 2):
  At most 1 pod can be disrupted at a time.
  Node drain removes 1 pod → waits until that pod is replaced before removing next.
  Result: during EKS upgrade (rolling node replacement), always ≥ 2 payment-service pods running.

Staging (2 replicas, minAvailable: 1):
  At most 1 pod can be disrupted.
  Node drain removes 1 pod (leaving 1 running) → replacement pod starts → then drains next.
  Result: brief period with 1 replica (50% capacity) during node drain.

Dev (pdb.enabled: false):
  No PDB created.
  1 replica + PDB minAvailable:1 = permanent node drain deadlock.
```

### The minAvailable math

```
For N replicas with minAvailable M:
  Max concurrent disruptions = N - M

Production: 3 replicas, minAvailable: 2 → max disruptions: 1
Staging: 2 replicas, minAvailable: 1 → max disruptions: 1
Dev: 1 replica, no PDB → unlimited disruptions allowed

If you set minAvailable equal to replicaCount:
  3 replicas, minAvailable: 3 → max disruptions: 0
  Node drain BLOCKED FOREVER — no pod can ever be evicted
  This is a common mistake that prevents EKS upgrades
```

---

## Part 11 — `templates/serviceaccount.yaml`

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: payment-service
  namespace: payment-ns
  annotations:
    {{- toYaml .Values.serviceAccount.annotations | nindent 4 }}
```

### The IRSA annotation — why it matters

```yaml
# Set in gitops/dev/app/payment-service/payment-service.yaml ArgoCD values:
serviceAccount:
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-payment-service
```

```
IRSA = IAM Roles for Service Accounts.

Without IRSA:
  payment-service pod needs to call AWS RDS (for DB connection strings), SQS, maybe S3.
  Without credentials: API calls fail with "Access Denied".
  With static credentials (bad): access keys hardcoded in env vars or ConfigMaps.
  Risk: key rotation is manual, keys can leak from logs/YAML files.

With IRSA:
  The ServiceAccount annotation tells EKS: "this pod should assume this IAM role".
  EKS OIDC provider + AWS STS: issues a temporary JWT token to the pod automatically.
  The Java AWS SDK picks up this token → assumes the IAM role → makes API calls.
  Token rotates automatically every hour.
  No static credentials anywhere.

The IAM role (company-dev-payment-service) has specific permissions:
  Allow: rds:DescribeDBClusters (read DB connection details)
  Allow: sqs:SendMessage, sqs:ReceiveMessage (for order events)
  Allow: secretsmanager:GetSecretValue (for DB passwords)
  Deny: everything else (least-privilege)

This is created by Terraform in environments/dev/main.tf (EKS module sets up IRSA roles).
```

---

## Part 12 — `templates/external-secret.yaml`

```yaml
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
spec:
  refreshInterval: 1h
  secretStoreRef:
    name: aws-secrets-manager
    kind: ClusterSecretStore
  target:
    name: payment-service-db-credentials
    creationPolicy: Owner
  data:
    - secretKey: DB_HOST
      remoteRef:
        key: {{ .Values.commonLabels.environment }}/payment-service/db-credentials
        property: host
    - secretKey: DB_PASSWORD
      remoteRef:
        key: {{ .Values.commonLabels.environment }}/payment-service/db-credentials
        property: password
```

### Dynamic path from environment label

```
key: {{ .Values.commonLabels.environment }}/payment-service/db-credentials

Dev environment:   key = "dev/payment-service/db-credentials"
Staging:           key = "staging/payment-service/db-credentials"
Production:        key = "production/payment-service/db-credentials"

Same chart template, same ExternalSecret definition.
Different environment → different Secrets Manager path → different credentials.
No hardcoded paths per environment.
```

### `refreshInterval: 1h` and `creationPolicy: Owner`

```
refreshInterval: 1h:
  ESO re-reads the Secrets Manager path every hour.
  If the DB password is rotated (via RDS automatic rotation): within 1h, the K8s Secret is updated.
  Pods pick up the new password when they next restart (or when Spring Boot re-initializes the pool).

creationPolicy: Owner:
  ESO "owns" the created K8s Secret.
  When the ExternalSecret is deleted: the K8s Secret is also deleted automatically (no orphans).
  Alternative "Merge": ESO adds to an existing Secret without owning it.
```

---

## Part 13 — `terraform/modules/vpc/main.tf`

### Subnet CIDR calculation

```hcl
locals {
  public_subnets   = [for i, az in var.azs : cidrsubnet(var.vpc_cidr, 8, i + 1)]
  private_subnets  = [for i, az in var.azs : cidrsubnet(var.vpc_cidr, 4, i + 16)]
  database_subnets = [for i, az in var.azs : cidrsubnet(var.vpc_cidr, 8, i + 100)]
}
```

```
Example: vpc_cidr = "10.0.0.0/16", azs = [ap-northeast-1a, 1c, 1d]

cidrsubnet("10.0.0.0/16", 8, 1) = 10.0.1.0/24   (256 IPs) — public AZ-a
cidrsubnet("10.0.0.0/16", 8, 2) = 10.0.2.0/24   (256 IPs) — public AZ-c
cidrsubnet("10.0.0.0/16", 8, 3) = 10.0.3.0/24   (256 IPs) — public AZ-d

cidrsubnet("10.0.0.0/16", 4, 16) = 10.0.0.0/20  (4096 IPs) — private AZ-a
cidrsubnet("10.0.0.0/16", 4, 17) = 10.0.16.0/20 (4096 IPs) — private AZ-c
cidrsubnet("10.0.0.0/16", 4, 18) = 10.0.32.0/20 (4096 IPs) — private AZ-d

Why /20 (4096 IPs) for private subnets?
  EKS VPC CNI assigns one IP per POD (not per node).
  Each node can have 30–110 pods depending on instance type.
  m7g.xlarge: up to 58 pods per node.
  10 nodes × 58 pods = 580 IPs just for pods (plus node IPs).
  /24 (256 IPs) would fill up quickly.
  /20 (4096 IPs) provides massive headroom for HPA scale-out.
```

### NAT Gateway — one per AZ (not shared)

```hcl
single_nat_gateway     = false
one_nat_gateway_per_az = true
```

```
single_nat_gateway = true (cheaper, DEFAULT for many setups):
  All 3 private subnets share ONE NAT Gateway in ONE AZ.
  Cost: ~$32/month for the NAT Gateway + data transfer.
  Problem: if that AZ has a partial failure → all private subnets lose internet access
           even though the pods in other AZs are fine.

one_nat_gateway_per_az = true (production-grade):
  Each AZ has its own NAT Gateway.
  Cost: 3 × $32 = ~$96/month.
  Benefit: AZ-a NAT failure → only AZ-a private subnet loses egress
           AZ-c and AZ-d continue working normally.

Production payment service: the extra $64/month is worth AZ-level NAT resilience.
```

### Subnet tags for EKS and Karpenter

```hcl
public_subnet_tags = {
  "kubernetes.io/role/elb"                    = "1"
  "kubernetes.io/cluster/${var.cluster_name}" = "shared"
}

private_subnet_tags = {
  "kubernetes.io/role/internal-elb"           = "1"
  "kubernetes.io/cluster/${var.cluster_name}" = "shared"
  "karpenter.sh/discovery"                    = var.cluster_name
}
```

```
kubernetes.io/role/elb = "1" on PUBLIC subnets:
  Tells AWS Load Balancer Controller: "you may create internet-facing ALBs in these subnets"
  Without this tag: ALB Controller cannot find subnets → ALB creation fails → Ingress stays Pending

kubernetes.io/role/internal-elb = "1" on PRIVATE subnets:
  Tells ALB Controller: "you may create internal ALBs in these subnets"
  Used for internal services (not payment-service which is internet-facing)

karpenter.sh/discovery = cluster_name on PRIVATE subnets:
  Tells Karpenter (automatic node provisioner): "provision new nodes in these subnets"
  Karpenter reads this tag to know WHERE to launch EC2 instances when HPA demands more pods

kubernetes.io/cluster/<name> = "shared":
  Marks these subnets as usable by the named EKS cluster.
  "owned" would mean only that cluster can use them.
  "shared" allows multiple clusters or resources to use the same subnet.
```

### VPC Gateway Endpoint for S3

```hcl
resource "aws_vpc_endpoint" "s3" {
  vpc_id            = module.vpc.vpc_id
  service_name      = "com.amazonaws.${data.aws_region.current.name}.s3"
  vpc_endpoint_type = "Gateway"
  route_table_ids   = module.vpc.private_route_table_ids
}
```

```
Without S3 Gateway endpoint:
  Pods pulling ECR Docker images → ECR stores layers in S3
  Traffic path: pod → NAT Gateway → internet → S3
  Cost: NAT Gateway data transfer charges for ALL Docker image pulls
  At scale: hundreds of pods pulling images = significant cost

With S3 Gateway endpoint:
  Traffic path: pod → VPC → S3 (private AWS backbone, no internet)
  Cost: FREE (Gateway endpoints have no data transfer charges)
  Security: image pulls never leave the AWS private network

This single resource can save hundreds of dollars/month in NAT data transfer costs.
```

---

## Part 14 — `terraform/modules/eks/main.tf`

### EKS cluster security settings

```hcl
cluster_endpoint_private_access = true
cluster_endpoint_public_access  = false
```

```
cluster_endpoint_public_access = false:
  The Kubernetes API server is NOT accessible from the internet.
  You can only reach it from WITHIN the VPC (or via VPN/bastion).
  Why: the k8s API server is the most sensitive endpoint in the cluster.
  If publicly accessible: internet-exposed to credential stuffing, CVE exploits.

cluster_endpoint_private_access = true:
  GitHub Actions runners and bastion hosts INSIDE the VPC can reach the API server.
  kubectl commands from CI/CD (via VPC-connected runners) still work.

cluster_enabled_log_types = ["audit", "api", "authenticator"]:
  Sends these log types to CloudWatch:
  audit: every kubectl command by every user (who did what, when)
  api: API server internal logs
  authenticator: IAM authentication attempts
  Why: required for security compliance. If there's a breach: audit logs show exactly what happened.
```

### IMDS hop limit and metadata security

```hcl
metadata_options = {
  http_tokens                 = "required"   # IMDSv2 only
  http_put_response_hop_limit = 2
}
```

```
http_tokens = "required" (IMDSv2 only):
  IMDS = Instance Metadata Service (http://169.254.169.254/)
  Pods can call this to get node IAM credentials.
  IMDSv1 (no token required): any pod → curl 169.254.169.254/latest/meta-data/iam/security-credentials/
                               → gets the EC2 node's IAM credentials → privilege escalation!
  IMDSv2 (token required):    must first get a session token with a PUT request
                               → pods can't easily do this → much harder to exploit

http_put_response_hop_limit = 2:
  TTL for IMDS requests.
  hop_limit = 1: only the EC2 instance itself can call IMDS (pods can't — they're one hop away)
  hop_limit = 2: the EC2 instance AND containers one hop away (pods) can call IMDS
  Why 2 not 1? IRSA requires pods to call IMDS to get their IAM credentials.
  Setting 1 would break IRSA (pods can't get their credentials → AWS SDK calls fail).
```

### EKS-managed addons

```hcl
cluster_addons = {
  coredns            = { most_recent = true }
  kube-proxy         = { most_recent = true }
  vpc-cni            = { most_recent = true; before_compute = true }
  aws-ebs-csi-driver = { most_recent = true }
}
```

```
coredns:
  DNS server for the cluster. Resolves service names like:
  payment-service.payment-ns.svc.cluster.local → ClusterIP
  Without CoreDNS: inter-service calls using service names fail.

kube-proxy:
  Runs on every node. Manages iptables rules for Service routing.
  When traffic arrives at a ClusterIP → iptables routes to one of the pods.

vpc-cni (before_compute = true):
  AWS VPC CNI assigns real VPC IP addresses to pods (one IP per pod).
  before_compute: must be installed BEFORE nodes join the cluster.
  If installed after: pods start without VPC IPs → no network connectivity.

aws-ebs-csi-driver:
  Allows Kubernetes PersistentVolumes backed by AWS EBS volumes.
  Required if any services use StatefulSets with persistent storage (e.g., PostgreSQL in-cluster).
  Even if you use RDS (external DB), it's good practice to have this available.
```

### The system node group taint

```hcl
taints = {
  dedicated = {
    key    = "dedicated"
    value  = "system"
    effect = "NO_SCHEDULE"
  }
}
labels = { "node-type" = "system" }
```

```
Taint "dedicated=system:NoSchedule":
  Kubernetes will NOT schedule pods on these nodes UNLESS the pod has a matching toleration.

Purpose: keeps system components (CoreDNS, kube-proxy, Karpenter, Dynatrace Operator)
         on DEDICATED nodes, separate from application pods.

Application pods (payment-service etc.) do NOT have this toleration → they go to app nodes.
System pods (DynaKube has a toleration for this) → they CAN go to system nodes.

Why separate?
  A misbehaving application pod consuming all CPU on a system node could kill CoreDNS.
  No CoreDNS = no DNS resolution = entire cluster's service-to-service calls fail.
  Dedicated system nodes prevent application workloads from impacting cluster infrastructure.
```
