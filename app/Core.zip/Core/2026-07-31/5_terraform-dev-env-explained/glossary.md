# Glossary — terraform/environments/dev/main.tf

Every term, concept, and tool mentioned in main.md. One entry per term.

---

**`terraform {}` block**
The configuration block that declares which provider plugins Terraform needs and where to store state. Required at the top of every root module. Without it, Terraform doesn't know which cloud provider to use or where to save what it creates.

**Terraform provider**
A plugin that translates Terraform resource declarations into real API calls. The `hashicorp/aws` provider translates `resource "aws_s3_bucket"` into AWS API calls. The `dynatrace-oss/dynatrace` provider translates `resource "dynatrace_management_zone_v2"` into Dynatrace API calls.

**`~>` (pessimistic constraint operator)**
A version constraint in Terraform meaning "accept this version and any patch/minor updates, but not the next major version." `~> 5.50` allows 5.50, 5.51, 5.99, but NOT 6.0. Prevents breaking changes from a major version upgrade silently breaking your configuration.

**Terraform state file**
A JSON file that records every resource Terraform manages — what exists, what its properties are, and what Terraform's ID for it is. On every `terraform plan`, Terraform reads this file to know what already exists and calculate what needs to change. Without state, Terraform would try to create everything from scratch every time.

**S3 backend (Terraform)**
Stores the Terraform state file in an S3 bucket instead of locally on disk. Allows multiple engineers and CI pipelines to share the same state. Prevents the state file from being lost if a laptop is destroyed. Required for any team-operated infrastructure.

**`key` (Terraform S3 backend)**
The S3 object path for the state file within the bucket. `"dev/terraform.tfstate"` means the state file is stored at this path in the bucket. Different environments use different keys, which keeps their state files separate and isolated.

**`encrypt = true` (Terraform backend)**
Tells Terraform to encrypt the state file at rest in S3 using the bucket's server-side encryption. The state file can contain sensitive values (resource IDs, partial secret data). Without encryption, anyone with S3 read access to the bucket can read it in plain JSON.

**DynamoDB state lock**
A DynamoDB record that Terraform writes before starting any apply operation. If two Terraform runs start at the same time (two engineers, two CI pipelines), the second one sees the lock and waits or fails. Prevents two simultaneous applies from making conflicting changes and corrupting the state file.

**`terraform init`**
The first Terraform command you run in any directory. It downloads provider plugins (like the AWS provider), initializes the backend (connects to S3 for state), and sets up the module cache. Must be run before `terraform plan` or `terraform apply`.

**`terraform plan`**
Reads the `.tf` files and the current state, then shows a diff of what would change if you ran `terraform apply`. It doesn't change anything — it's a dry run. Shows `+` for resources to add, `~` for resources to modify, `-` for resources to destroy.

**`terraform apply`**
Actually creates, modifies, or destroys AWS/DT resources based on the `.tf` files. Reads the plan, then makes the API calls. `-auto-approve` skips the interactive "yes/no" prompt (used in CI since there's no terminal). Updates the state file after each resource is created.

**`provider "aws"` block**
Configures how Terraform authenticates to AWS. The region tells Terraform which AWS region to make API calls to. Credentials come from environment variables (set by GitHub Actions OIDC or `aws configure` locally) — never hardcoded in the provider block.

**OIDC (OpenID Connect) for AWS**
A way for GitHub Actions to authenticate to AWS without storing AWS access keys in GitHub Secrets. GitHub gets a short-lived token from AWS's STS service. The token is valid only for the duration of the CI job and only for the specific IAM role configured in the trust policy. Nothing to rotate, nothing to leak.

**`default_tags`**
A Terraform AWS provider setting that automatically applies a set of tags to every AWS resource created in this run. Tags are key-value labels used for: cost allocation (filter S3 costs by `environment=dev`), audit (find Terraform-managed resources), and incident investigation (which environment owns this resource).

**`data` source (Terraform)**
A way to READ existing infrastructure without managing it. `data "aws_secretsmanager_secret_version"` reads a secret's value from Secrets Manager but does NOT create or own the secret. The secret must already exist. The read value is available as `data.<type>.<name>.<attribute>`.

**`data.aws_secretsmanager_secret_version`**
A Terraform data source that reads the current value of an AWS Secrets Manager secret. `secret_id` is the path (name) of the secret. `.secret_string` returns the value as a plain string at `terraform apply` time. The value is sensitive and Terraform won't print it in logs.

**AWS Secrets Manager**
An AWS service that stores and retrieves secrets (API tokens, database passwords, webhook URLs) with encryption at rest. Supports automatic rotation. Access is controlled by IAM — only principals with explicit `secretsmanager:GetSecretValue` permission can read a secret.

**Secret path convention (`dev/dynatrace/api-token`)**
The naming convention for secrets where the first segment is the environment. This allows IAM policies to grant access using `arn:aws:secretsmanager:*:*:secret:dev/*` — the dev IAM role can read dev secrets only, and cannot access `staging/*` or `production/*` secrets even in an accident or misconfiguration.

**`jsondecode()`**
A Terraform built-in function that parses a JSON string into a Terraform map or list. Used here because `slack_webhooks` is stored in Secrets Manager as a JSON string (`{"payments":"https://...","orders":"https://..."}`). After `jsondecode()`, it becomes a Terraform `map(string)` that `for_each` can iterate over.

**`module "dynatrace"` block**
Calls a reusable Terraform module at the specified path. All the input variables (environment, thresholds, credentials) are passed as arguments. The module's `main.tf` runs with those inputs and creates the Dynatrace resources. One module call per environment, same module code for all three.

**`source = "../../modules/dynatrace"`**
A relative path pointing from `terraform/environments/dev/` to `terraform/modules/dynatrace/`. Terraform follows this path to find the module's `.tf` files. Local modules (starting with `./` or `../`) are not downloaded from the registry — they're read directly from the local filesystem.

**`environment = "dev"`**
A string variable passed to the module that controls which resources are conditionally created. The module uses it in ternary expressions to skip CRITICAL and HIGH alerting profiles in dev, include both in production. Also used for naming resources and filtering DT metric events to the right environment.

**`pagerduty_integration_keys = {}`**
An empty Terraform map passed to the module. Inside the module, `for_each = var.pagerduty_integration_keys` with an empty map creates zero PagerDuty notification resources. This is the Terraform pattern for "skip this resource in this environment" without needing `if/else` logic.

**`for_each = {}` (zero resources pattern)**
When `for_each` receives an empty map or set, Terraform creates zero resources of that type. No `count = 0` or conditional block needed. The module logic stays clean — it just iterates over whatever map it receives.

**Alert fatigue**
When alerts fire so frequently that engineers start ignoring them. Usually caused by thresholds that are too tight for the environment (e.g., production latency thresholds in dev). Once engineers learn to ignore alerts in dev, they carry that habit to production — and miss real incidents. Relaxed thresholds in dev prevent this.

**`synthetic_locations`**
A list of Dynatrace location IDs where synthetic health check monitors run. Dev uses only Tokyo (1 location, lower cost). Staging and production use Tokyo + Singapore (2 locations, can distinguish local DT node issues from real outages). The location IDs are Dynatrace's internal identifiers for their global monitoring node network.

**Dynatrace DDU (Data Units)**
Dynatrace's billing unit for synthetic monitors. Each synthetic check from each location per unit time consumes DDUs. Fewer locations = fewer DDUs. Dev uses 1 location to save cost since SLA-grade multi-region monitoring is unnecessary for development.

**`services = { ... }` map**
The single source of truth for all Dynatrace monitoring thresholds per environment. All 11 threshold values for all 3 services live here. The same module code reads this map and creates metric events, SLOs, and synthetics with these exact values. Changing any value here changes the corresponding Dynatrace configuration on the next `terraform apply`.

**`team` (service field)**
The team that owns a service. Used to group services into management zones (one zone per team), name alerting profiles, and target Slack channels (`#alerts-payments`). All services with the same team value share a management zone and alerting configuration.

**`slo_target` (service field)**
The availability percentage target for the SLO dashboard. In dev at 90%, it's purely informational — the SLO burns budget constantly but no burn rate alerts affect dev operations. In production at 99.9%, burn rate alerts fire when the budget is depleting too fast.

**`health_check_url` (service field)**
The URL the Dynatrace HTTP synthetic monitor checks every 5 minutes. Always points to `/actuator/health` — the Spring Boot Actuator health endpoint that reports both HTTP 2xx status AND a JSON body with `"status":"UP"`. Both must pass for the synthetic to succeed.

**Spring Boot Actuator**
A Spring Boot add-on that automatically exposes management endpoints. `/actuator/health` reports application health including downstream dependencies (database, caches). `/actuator/health/liveness` and `/actuator/health/readiness` are used by Kubernetes probes. The synthetic monitors target the plain `/actuator/health` endpoint.

**`traffic_min_rps = 0` (disable traffic alert)**
Setting traffic minimum to 0 signals the module to not create a traffic drop metric event for this service. The module uses `if svc.traffic_min_rps > 0` to filter services into the traffic alert resource. Dev services have no real users, so no traffic minimum makes sense.

**Traffic drop signal**
A Dynatrace metric event that fires when request count falls BELOW a minimum threshold for 3 consecutive minutes. The most important monitoring signal because all other signals (error rate, latency, CPU, memory) show green when traffic is zero — only traffic drop catches silent outages where the service is completely unreachable.

**`alert_on_no_data = true`**
A metric event setting that fires an alert even when Dynatrace receives zero data points (not just when the metric crosses a threshold). Used on the traffic drop signal only — if Dynatrace stops receiving any metrics at all (OneAgent died, network partition, service completely crashed), the alert still fires instead of showing false green.

**`error_rate_alert` (service field)**
The HTTP 5xx error rate percentage above which Dynatrace creates an ERROR problem. In dev at 10%: only catastrophic failures (everything is broken) trigger an alert. In production at 0.1%: even rare errors are significant enough to alert.

**`latency_p99_ms` (service field)**
The P99 response time threshold in milliseconds. If 99% of requests complete within this time, the service is healthy. The module multiplies this by 1000 to convert to microseconds (Dynatrace's internal unit). Dev values are 5-7× higher than production to account for JIT cold start and slower t3.medium nodes.

**P99 (99th percentile)**
The response time value that 99% of requests are FASTER than. If P99 = 300ms: 99 out of every 100 requests finish in under 300ms. The slowest 1% may take longer. P99 is preferred over average because it reflects the worst experience most users have, while average hides slow outliers.

**JIT (Just-In-Time compiler)**
The Java mechanism that compiles frequently-used bytecode into optimized native machine code at runtime. Cold JVM: all code runs as slow interpreted bytecode. After ~60 seconds of traffic: hot methods are compiled to native code, running 5-10× faster. First requests after pod start are always slower — this is JIT warmup.

**t3.medium (dev) vs m7g.xlarge (production)**
EC2 instance types. t3.medium: 2 vCPU, 4GB RAM, burstable CPU (can use 100% briefly but throttles if sustained). m7g.xlarge: 4 dedicated Graviton ARM vCPUs, 16GB RAM. The performance difference is 3-5× for CPU-intensive Java workloads, which is why dev latency thresholds are much higher than production.

**`cpu_saturation_pct` (service field)**
The CPU usage percentage above which Dynatrace creates a RESOURCE_CONTENTION problem. Dev is 90% because dev workloads are bursty (test runs, pod restarts). Production is 70-80% because Java GC needs CPU headroom — above 70%, G1GC starts competing with application threads and pause times increase.

**G1GC (Garbage First Garbage Collector)**
The JVM garbage collector used by these services (`-XX:+UseG1GC`). Designed for low-latency workloads. Runs GC incrementally across small heap regions. Above ~70% heap utilization, GC runs more frequently and pause times increase — this is why the production JVM heap alert threshold is 70%.

**`memory_usage_pct` (service field)**
The RSS memory (resident set size = actual RAM used) as a percentage of the container's `limits.memory` setting. Different from JVM heap — RSS includes heap + non-heap (metaspace, code cache, threads, OS buffers). Dev at 85% because the container limit is smaller (512Mi) and there's less headroom.

**RSS (Resident Set Size)**
The actual physical RAM a process is using right now. For a Java process: RSS = JVM heap (objects) + JVM non-heap (class metadata, JIT code cache, thread stacks) + native libraries + OS buffers. RSS exceeding the container's memory limit causes an OOM kill by Kubernetes.

**`jvm_heap_pct` (service field)**
The JVM heap used as a percentage of the maximum heap size (`-Xmx`). At 70% in production: G1GC pressure increases, pause times start growing — alert before users feel it. In dev at 85% (with Xmx=256m): Spring Boot idle context already uses 70% of 256m, so 85% threshold prevents constant false alerts.

**`-Xmx` (JVM heap maximum)**
JVM flag that sets the maximum heap size. `values-dev.yaml: -Xmx256m`, `values-staging.yaml: -Xmx512m`, `values.yaml (prod): -Xmx1024m`. The `jvm_heap_pct` threshold is calibrated against this value — changing Xmx requires updating the threshold accordingly.

**`pod_restart_threshold` (service field)**
The number of pod restarts in a 5-minute window above which Dynatrace creates an ERROR problem. Dev at 5 because developers actively iterate on code that may crash. Production at 2 because any restart loop indicates a real problem (OOM kill, crash, config error) that needs immediate attention.

**OOM kill (Out of Memory kill)**
When Kubernetes terminates a container because its RSS memory exceeded the container's memory limit. Manifests as: pod restarts with reason `OOMKilled`. The `memory_usage_pct` and `jvm_heap_pct` thresholds both aim to alert BEFORE an OOM kill happens.

**`network_error_rate_pct` (service field)**
The packet error rate on the node's network interface above which Dynatrace creates a RESOURCE_CONTENTION problem. Measures NIC-level errors (packet retransmits, checksum errors) — not HTTP errors. Dev at 5% accounts for t3.medium instances on shared hardware. Production at 0.5-1% because dedicated instances should have near-zero packet errors.

**Async service (notification-service)**
A service that accepts a request, queues the work for background processing, and immediately returns success without waiting for the actual work to complete. `POST /api/v1/notifications` returns `{"status":"queued"}` instantly, then SQS/SNS handles actual email/SMS delivery in the background. This is why notification-service has a higher latency threshold — the API call includes SQS publish time.

**SQS (Simple Queue Service)**
AWS's managed message queue service. notification-service publishes notification messages to SQS on every API call. SQS SDK initialization on a cold JVM (first call) includes: HTTPS connection setup + IAM credential fetch via IRSA + SQS endpoint resolution. This adds ~1-2 seconds to the first call, which is why `latency_p99_ms = 3000` for notification-service in dev.

**`jsondecode` + `map(string)` pattern**
A Terraform technique for storing multiple related values (one per team) as a single JSON secret in Secrets Manager. Instead of 3 separate secrets for 3 Slack webhooks, one JSON object contains all of them. `jsondecode()` converts the string to a Terraform map. Adding a new team requires only updating the JSON in Secrets Manager, not changing any Terraform code.

**`-auto-approve` (terraform apply)**
Skips the interactive confirmation prompt that `terraform apply` normally shows before making changes. Required in CI since there's no terminal for a human to type "yes". Never use in local development without carefully reviewing the plan first — it will apply changes immediately without confirmation.

**`-no-color` (terraform)**
Removes ANSI color escape codes from Terraform output. In a terminal these produce colored text. In CI logs (GitHub Actions, Jenkins) without a proper terminal, they render as garbage characters like `[0;32m`. Always use `-no-color` in CI pipelines.

**Terraform module (local)**
A directory of `.tf` files that encapsulates reusable logic. Called with `source = "../../modules/dynatrace"` (relative path). Different from registry modules (`source = "terraform-aws-modules/vpc/aws"`). Local modules are version-controlled in the same repo and don't require a registry lookup.

**Blast radius isolation**
The practice of ensuring a mistake in one environment cannot affect another environment. Separate S3 buckets per environment, separate IAM roles per environment, separate Secrets Manager secret paths (`dev/*` vs `production/*`) — all contribute to limiting the "blast radius" (damage) of any single mistake or misconfiguration.
