# terraform/environments/dev/main.tf — Line-by-Line Explained

> **What this file IS:** The Terraform entry point for the dev environment. It declares where to store state, how to authenticate to AWS, reads secrets from Secrets Manager, and calls the shared Dynatrace module with dev-specific thresholds. It does NOT define any infrastructure directly — it only CALLS modules and reads data.

---

## Decision Tree — How This File Connects to Everything

```
This file (dev/main.tf)
        │
        ├── terraform block
        │     └── backend "s3" ──────────────────► S3 bucket: company-terraform-state-dev
        │                                           Key: dev/terraform.tfstate
        │                                           Lock: DynamoDB table terraform-state-lock
        │
        ├── provider "aws"
        │     └── authenticates via OIDC (GitHub Actions assumes IAM role)
        │         default_tags ──────────────────► every AWS resource gets environment=dev tag
        │
        ├── data "aws_secretsmanager_secret_version" (×3)
        │     └── reads from Secrets Manager at plan/apply time ──► dt_api_token
        │                                                            dt_tenant_url
        │                                                            slack_webhooks (JSON)
        │
        └── module "dynatrace"
              source = "../../modules/dynatrace"    ◄── ONE shared module, called with dev values
              │
              ├── environment = "dev"               ◄── controls conditional resource creation
              ├── pagerduty_integration_keys = {}   ◄── empty map = 0 PD resources created
              ├── slack_webhook_urls = jsondecode(…)◄── parsed from JSON secret
              ├── synthetic_locations = [Tokyo only]◄── 1 location (dev cost saving)
              └── services = { … }                 ◄── 3 services, relaxed thresholds
```

---

## Block 1 — `terraform {}` — required providers + state backend

```hcl
terraform {
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.50" }
  }
  backend "s3" {
    bucket         = "company-terraform-state-dev"
    key            = "dev/terraform.tfstate"
    region         = "ap-northeast-1"
    encrypt        = true
    dynamodb_table = "terraform-state-lock"
  }
}
```

### `required_providers`

```
aws = { source = "hashicorp/aws", version = "~> 5.50" }
```

**What it means:**
- `source = "hashicorp/aws"` — download the AWS provider plugin from the official HashiCorp registry
- `version = "~> 5.50"` — the `~>` is the "pessimistic constraint" operator, meaning: allow `5.50`, `5.51`, `5.99`, but NOT `6.0`. It accepts patch and minor upgrades within the same major version
- Without this declaration: `terraform init` would download the LATEST version of the AWS provider — which might be a breaking major version. Pinning ensures every engineer and every CI run uses the same API surface

**Why provider pinning matters:**
```
Terraform provider v5.50 → adds new resource type
Terraform provider v6.0  → renames an attribute (breaking change)

Without pin: CI machine downloads v6.0, your .tf file uses the old attribute name → plan fails
             But dev engineer downloaded v5.50 yesterday → works on laptop, fails in CI
             
With pin ~> 5.50: everyone gets 5.x.x, never 6.x.x. Same behavior everywhere.
```

---

### `backend "s3"` — where Terraform stores its state file

```
bucket         = "company-terraform-state-dev"
key            = "dev/terraform.tfstate"
region         = "ap-northeast-1"
encrypt        = true
dynamodb_table = "terraform-state-lock"
```

**What Terraform state is:**
Every resource Terraform creates (a VPC, a DT management zone, an IAM role) is recorded in a JSON file called the state file. On the next `terraform plan`, Terraform compares the state file against your `.tf` files to compute what needs to change. Without state, Terraform doesn't know what already exists.

**Why S3 (not local file):**
```
Local state: state file lives on your laptop.
  Problem 1: Two engineers run terraform apply simultaneously → both read the old state
             → both try to create the same resources → duplicate resources or errors
  Problem 2: Laptop dies → state file lost → Terraform no longer knows what it manages
             → must import every resource manually or destroy and recreate everything
             
S3 state: state file stored centrally, accessible to all engineers and CI
  + DynamoDB table "terraform-state-lock" prevents concurrent applies
  + S3 versioning allows rollback to previous state if something corrupts it
```

**Why separate bucket per environment:**
```
company-terraform-state-dev     → key: dev/terraform.tfstate
company-terraform-state-staging → key: staging/terraform.tfstate
company-terraform-state-prod    → key: production/terraform.tfstate

If all 3 environments shared one bucket:
  A CI pipeline misconfiguration could point dev to key: production/terraform.tfstate
  A terraform destroy in dev → destroys production infrastructure
  
Separate buckets = physically impossible to point to the wrong environment's state
  (different bucket name, different IAM permissions per account)
```

**`encrypt = true`:**
The state file contains sensitive values (IAM role ARNs, resource IDs, and in some cases partial secret values). `encrypt = true` tells Terraform to encrypt the state file at rest in S3 using the bucket's server-side encryption (SSE) key. Without this, state is stored in plain JSON readable by anyone with S3 read access to the bucket.

**`dynamodb_table = "terraform-state-lock"`:**
Before any `terraform apply`, Terraform writes a lock record to this DynamoDB table. If another apply is already running (same lock key exists), the new run waits or fails with "state is locked." After apply completes, the lock is released. This prevents two simultaneous applies from corrupting the state by making conflicting changes.

---

## Block 2 — `provider "aws"` — authentication + default tags

```hcl
provider "aws" {
  region = "ap-northeast-1"
  default_tags { tags = { environment = "dev", managed-by = "terraform" } }
}
```

### `region = "ap-northeast-1"`

All AWS API calls from this Terraform run go to the Tokyo region. Every resource created by this module (Secrets Manager reads, any future EC2/EKS resources) lands in Tokyo. Without this, Terraform uses the default region from the AWS CLI config, which may differ per engineer.

### Authentication (not written in the file — intentional)

There is NO `access_key`, `secret_key`, or `profile` in the provider block. This is correct. The AWS provider automatically reads credentials from the environment:

```
In CI (GitHub Actions):
  uses: aws-actions/configure-aws-credentials@v4
    with:
      role-to-assume: arn:aws:iam::123456789010:role/github-actions-dynatrace-apply
  → Sets AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_SESSION_TOKEN env vars
  → Terraform reads them automatically
  → Credentials are temporary (15 min), OIDC-based, no stored secrets

On developer laptop:
  aws configure sso  or  aws-vault exec dev-account
  → Sets the same env vars locally
  → Terraform picks them up the same way
```

**Why credentials are NOT in the file:**
```
Mistake: provider "aws" { access_key = "AKIAIOSFODNN7..." secret_key = "abc123..." }
→ These get committed to Git
→ Visible to: all engineers, GitHub, anyone who forks the repo
→ AWS will usually scan public repos and auto-revoke keys it finds there
→ But private repos still expose keys to all repo members

Correct: credentials come from environment variables, never from .tf files
```

### `default_tags`

```hcl
default_tags { tags = { environment = "dev", managed-by = "terraform" } }
```

These two tags are automatically applied to EVERY AWS resource created by this provider block — EC2 instances, IAM roles, S3 buckets, DynamoDB tables, etc. You never need to add them individually.

**Why `managed-by = "terraform"` matters operationally:**
```
Scenario: You're investigating a production incident and find an IAM role you don't recognize.
  Without tag: Was this created manually? By a script? Do I dare delete it?
  With tag managed-by=terraform: It's managed by Terraform. I can look it up in the state file.
                                  I can run terraform plan to see what it does.
                                  
Scenario: Cost explorer shows unexpected charges in us-east-1
  Filter by tag environment=dev → see all dev resources across all AWS services
  Filter by tag managed-by=terraform → see only Terraform-managed resources (vs manually created)
  
These tags cost nothing but are invaluable for auditing and incident investigation.
```

---

## Block 3 — `data "aws_secretsmanager_secret_version"` (×3) — reading secrets

```hcl
data "aws_secretsmanager_secret_version" "dt_api_token" {
  secret_id = "dev/dynatrace/api-token"
}
data "aws_secretsmanager_secret_version" "dt_tenant_url" {
  secret_id = "dev/dynatrace/tenant-url"
}
data "aws_secretsmanager_secret_version" "slack_webhooks" {
  secret_id = "dev/dynatrace/slack-webhooks"
}
```

### What `data` means vs `resource`

```
resource "aws_s3_bucket" "my_bucket" { ... }
→ Terraform CREATES and MANAGES this S3 bucket. It appears in state. Terraform owns it.

data "aws_secretsmanager_secret_version" "dt_api_token" { ... }
→ Terraform READS this from AWS but does NOT create or own it.
→ The secret must already exist in Secrets Manager (created manually or by another process).
→ The value is fetched at plan/apply time and used in variables.
→ It does NOT appear in state as a managed resource.
```

### Why secrets are stored in Secrets Manager (not hardcoded or in GitHub Secrets)

```
Option A — hardcoded in .tf file:
  dt_api_token = "dt0c01.XXXX..."
  → Committed to Git → everyone who can read the repo can read the token
  → Cannot rotate without editing code + re-committing
  → NEVER do this

Option B — GitHub Actions Secret:
  ${{ secrets.DT_API_TOKEN }}
  → Better: not in code
  → Problem: CI only. A developer running terraform apply locally can't use GH secrets.
  → Also: secret is in GitHub's system, not the same account as the resources it controls

Option C — AWS Secrets Manager (this file):
  secret_id = "dev/dynatrace/api-token"
  → Secret lives in the same AWS account as everything else
  → Access controlled by IAM (the same role that runs Terraform can read it)
  → Both CI and developers with appropriate IAM access can run Terraform
  → Rotation: update the secret in Secrets Manager → next terraform apply reads new value
  → CORRECT approach
```

### The `secret_id` naming convention

```
"dev/dynatrace/api-token"
"staging/dynatrace/api-token"
"production/dynatrace/api-token"
```

The first path segment is the environment. This means:
- The dev IAM role (`github-actions-dynatrace-apply`) has permission to read `dev/*` secrets only
- It CANNOT read `production/*` secrets — even if the CI pipeline targets the wrong environment
- Separate permissions per environment path = blast radius isolation

### What `.secret_string` contains

```hcl
dt_api_token = data.aws_secretsmanager_secret_version.dt_api_token.secret_string
```
`.secret_string` returns the current version's value as a plain string. For `dt_api_token`, this is the raw Dynatrace API token string (e.g., `dt0c01.XXXXX.YYYYYYY`).

```hcl
slack_webhook_urls = jsondecode(data.aws_secretsmanager_secret_version.slack_webhooks.secret_string)
```
For `slack_webhooks`, the Secrets Manager value is stored as JSON (because there are multiple webhooks — one per team):
```json
{
  "payments": "https://hooks.slack.com/services/T00/B00/XXXX",
  "orders": "https://hooks.slack.com/services/T00/B00/YYYY",
  "notifications": "https://hooks.slack.com/services/T00/B00/ZZZZ"
}
```
`jsondecode()` parses this JSON string into a Terraform map: `{ "payments" = "https://...", "orders" = "https://...", "notifications" = "https://..." }`. This is then passed to the module's `slack_webhook_urls` variable which expects `map(string)`.

---

## Block 4 — `module "dynatrace"` — the module call

```hcl
module "dynatrace" {
  source      = "../../modules/dynatrace"
  environment = "dev"
  ...
}
```

### `source = "../../modules/dynatrace"`

Relative path from `terraform/environments/dev/` to `terraform/modules/dynatrace/`. This is a LOCAL module (not from the Terraform Registry). The module's `main.tf` and `variables.tf` define what resources to create and what inputs they need. This file provides those inputs.

**Why a shared module (not 3 copies of the DT config):**
```
Without module — 3 separate DT config directories:
  terraform/dynatrace-dev/     ← 7 .tf files
  terraform/dynatrace-staging/ ← copy of dev (7 .tf files)
  terraform/dynatrace-prod/    ← copy of staging (7 .tf files)

Problem: You find a bug in the SLO metric expression.
  Fix it in terraform/dynatrace-dev/slos.tf
  Forget to fix it in staging and prod
  Result: dev has correct SLOs, staging and prod have the bug for weeks
  
With one module:
  Fix it in terraform/modules/dynatrace/main.tf → ALL 3 environments get the fix
  on their next terraform apply. One source of truth for logic.
```

---

### `environment = "dev"`

This single string controls which resources exist and which are skipped inside the module:

```hcl
# Inside modules/dynatrace/main.tf:

# CRITICAL alerting profile — production ONLY:
resource "dynatrace_alerting" "critical" {
  for_each = var.environment == "production" ? local.teams : toset([])
  # dev passes "dev" → condition false → toset([]) → for_each on empty set → 0 resources
}

# HIGH alerting profile — production + staging:
resource "dynatrace_alerting" "high" {
  for_each = contains(["production", "staging"], var.environment) ? local.teams : toset([])
  # dev passes "dev" → not in list → toset([]) → 0 resources
}

# WARNING alerting profile — ALL environments:
resource "dynatrace_alerting" "warning" {
  for_each = local.teams
  # dev passes "dev" → local.teams has 3 entries → 3 resources created
}
```

**What gets created in dev vs not:**

| Resource | Dev | Staging | Production |
|---|---|---|---|
| Management zones | ✅ 3 (one per team) | ✅ 3 | ✅ 3 |
| WARNING alerting profiles | ✅ 3 | ✅ 3 | ✅ 3 |
| INFO alerting profiles | ✅ 3 | ✅ 3 | ✅ 3 |
| HIGH alerting profiles | ❌ 0 | ✅ 3 | ✅ 3 |
| CRITICAL alerting profiles | ❌ 0 | ❌ 0 | ✅ 3 |
| PagerDuty notifications | ❌ 0 | ✅ (high only) | ✅ (critical + high) |
| Slack notifications | ✅ 3 | ✅ 3 | ✅ 3 |
| HTTP Synthetics | ✅ 3 (Tokyo only) | ✅ 3 (Tokyo+SG) | ✅ 3 (Tokyo+SG) |
| Traffic drop metric event | ❌ 0 (traffic_min_rps=0) | ✅ 3 | ✅ 3 |
| Other 7 metric events | ✅ all | ✅ all | ✅ all |
| SLOs (availability) | ✅ 3 (90% target) | ✅ 3 (95% target) | ✅ 3 (99.x% target) |
| SLOs (latency) | ✅ 3 | ✅ 3 | ✅ 3 |

---

### `pagerduty_integration_keys = {}`

```hcl
pagerduty_integration_keys = {}
```

An empty Terraform map. Inside the module:
```hcl
resource "dynatrace_pagerduty_notification" "critical" {
  for_each = var.pagerduty_integration_keys   # {} in dev
  ...
}
```
`for_each = {}` creates **zero** resources. The module doesn't need a `if dev then skip` condition — the data itself (empty map) eliminates the resources.

**Why no PagerDuty in dev:**
```
PagerDuty = phone calls + push notifications to on-call engineers.
Dev services:
  - Restart frequently during active development
  - Have intentional bugs under test
  - Are stopped and started by developers at any time
  - Have no real users
  
If PagerDuty fired for dev:
  3am: dev pod OOMKills during a developer's experiment → phone wakes on-call engineer
  Engineer: "...this is the dev cluster again"
  
After 3 false pages: engineers start ignoring alerts → miss REAL production issues.
Alert fatigue kills observability.
```

---

### `slack_webhook_urls = jsondecode(...)`

```hcl
slack_webhook_urls = jsondecode(data.aws_secretsmanager_secret_version.slack_webhooks.secret_string)
```

**Flow:**
```
AWS Secrets Manager: dev/dynatrace/slack-webhooks
  Value (stored as JSON string):
  "{\"payments\":\"https://hooks.slack.com/XXX\",\"orders\":\"https://hooks.slack.com/YYY\",...}"

.secret_string:
  returns the raw JSON string above

jsondecode(...):
  parses it → Terraform map:
  {
    "payments"      = "https://hooks.slack.com/XXX"
    "orders"        = "https://hooks.slack.com/YYY"
    "notifications" = "https://hooks.slack.com/ZZZ"
  }

Inside the module (modules/dynatrace/main.tf):
  resource "dynatrace_slack_notification" "warning" {
    for_each = var.slack_webhook_urls    ← the map above
    url      = each.value               ← "https://hooks.slack.com/XXX"
    channel  = "#alerts-${each.key}"    ← "#alerts-payments"
  }
  
Creates 3 Slack warning notifications:
  payments team     → "#alerts-payments"
  orders team       → "#alerts-orders"
  notifications team → "#alerts-notifications"
```

**Why store webhooks as JSON in one secret (not 3 separate secrets):**
```
Option A — 3 separate secrets:
  dev/dynatrace/slack-webhook-payments
  dev/dynatrace/slack-webhook-orders
  dev/dynatrace/slack-webhook-notifications
  → Requires 3 data blocks in this file
  → Adding a new service = editing this file + adding a new secret
  → When you add a 4th team (infra), you need to change both Terraform files

Option B — 1 JSON secret (this approach):
  dev/dynatrace/slack-webhooks
  → Contains ALL team webhooks in one place
  → Adding a new team = update the JSON in Secrets Manager only
  → Terraform just calls jsondecode() and passes the whole map
  → No code change needed for new teams
```

---

### `synthetic_locations = ["GEOLOCATION-6F55B7E4B5E7A52F"]` (Tokyo only)

```hcl
synthetic_locations = [
  "GEOLOCATION-6F55B7E4B5E7A52F", # Tokyo
]
```

This list is passed to the module and used in every HTTP synthetic monitor:
```hcl
resource "dynatrace_http_monitor" "health_check" {
  locations = var.synthetic_locations  # ["GEOLOCATION-6F55B7E4B5E7A52F"]
  frequency = 5   # every 5 minutes
}
```

**Dev: 1 location. Staging/Production: 2 locations (Tokyo + Singapore).**

```
Why 2 locations in production:
  If synthetics run from Tokyo only and the Tokyo monitoring node has a network issue:
    DT synthetic fails → alert fires → "service is down!"
    But the service is FINE — it's just the Tokyo DT node that has a problem
    False page to on-call engineer
    
  With Tokyo + Singapore:
    Tokyo fails, Singapore succeeds → "local outage" → just Slack warning
    Tokyo AND Singapore fail → "global outage" → PagerDuty page
    You can distinguish "DT Tokyo node issue" from "service actually down"
    
Why only Tokyo in dev:
  Each synthetic location costs Dynatrace DDUs (billing units).
  Dev has no SLA and no real users. The synthetic just confirms the service is alive.
  One location is sufficient for "is it alive?" in dev.
  Cost savings compound: 3 services × 5min × 2 locations = double the DDU cost for no benefit.
```

**`GEOLOCATION-6F55B7E4B5E7A52F` — what this ID is:**
These are Dynatrace's internal IDs for their public synthetic monitoring nodes. You find them in the Dynatrace UI under `Synthetic → Private Locations` or via the DT API: `GET /api/v1/synthetic/locations`. The ID is stable — it doesn't change unless DT decommissions the location.

---

## Block 5 — `services = { ... }` — the threshold map

This is where ALL per-environment decisions live. Same module, different numbers.

### The outer structure

```hcl
services = {
  "payment-service" = {
    team             = "payments"
    slo_target       = 90.0
    health_check_url = "https://payment.dev.company.com/actuator/health"
    
    traffic_min_rps        = 0
    error_rate_alert       = 10.0
    latency_p99_ms         = 2000
    cpu_saturation_pct     = 90
    memory_usage_pct       = 85
    jvm_heap_pct           = 85
    pod_restart_threshold  = 5
    network_error_rate_pct = 5.0
  }
  
  "order-service"        = { ... }
  "notification-service" = { ... }
}
```

The map key (`"payment-service"`) is used as:
- The Dynatrace metric filter: `value = each.key key = "service.name"` — filters metrics to ONLY this service
- The resource name: `"[DEV] payment-service: P99 latency >2000ms"`
- The synthetic URL label and management zone scoping

---

### Field-by-field breakdown

#### `team = "payments"`

```hcl
team = "payments"
```

Used by the module to:
1. Group services into management zones: `local.teams = toset([for svc in values(var.services) : svc.team])` → `{"notifications", "orders", "payments"}`
2. Name alerting profiles: `"${each.value}-${var.environment}-warning"` → `"payments-dev-warning"`
3. Set Slack channel: `"#alerts-${each.key}"` → `"#alerts-payments"`
4. Match management zone to alerting profile

---

#### `slo_target = 90.0`

```
Dev:     90.0%   — "just to see the dashboard, no real SLA"
Staging: 95.0%
Prod:    99.9%   (payment), 99.5% (order), 99.0% (notification)
```

**What 90% means in practice for dev:**
```
90% availability = 10% of requests can fail
In dev with ~1 req/min (smoke tests + occasional developer testing):
  1 req/min × 60 × 24 × 30 = 43,200 requests/month
  10% budget = 4,320 allowed failures/month
  
This is so loose that the SLO almost never burns down.
The 90% target in dev is purely for dashboard visibility — to see the SLO widget work.
It does NOT affect alerting. Only the metric events (error_rate_alert, latency_p99_ms) drive alerts.
```

---

#### `health_check_url = "https://payment.dev.company.com/actuator/health"`

The URL the HTTP synthetic monitor pings every 5 minutes. Always points to the Spring Boot Actuator health endpoint.

```
/actuator/health response (Spring Boot):
{
  "status": "UP",
  "components": {
    "db": { "status": "UP" },
    "diskSpace": { "status": "UP" }
  }
}
```

The synthetic validates: HTTP 2xx AND body contains `"status":"UP"`. If the DB goes down, Spring Boot returns:
```json
{ "status": "DOWN", "components": { "db": { "status": "DOWN" } } }
```
The HTTP status is still 200, but body check FAILS → synthetic fails → alert fires. This catches "200 but broken" — the most common silent failure mode.

---

#### `traffic_min_rps = 0` — the most important threshold in dev

```
Dev:     0    → traffic alert DISABLED
Staging: 2    → alert if below 2 req/min
Prod:    10   (payment), 5 (order), 3 (notification)
```

**How the module handles `0`:**
```hcl
# In modules/dynatrace/main.tf:
locals {
  services_with_traffic = {
    for name, svc in var.services : name => svc
    if svc.traffic_min_rps > 0   ← filters out entries where traffic_min_rps = 0
  }
}

resource "dynatrace_metric_events" "traffic_drop" {
  for_each = local.services_with_traffic  ← in dev, this is {} → 0 resources created
```

Setting `traffic_min_rps = 0` doesn't create a threshold of "alert if below 0 req/min." It removes the alert entirely. The `if svc.traffic_min_rps > 0` filter in the `locals` block eliminates the service from the traffic drop resource creation.

**Why traffic drop must be disabled in dev:**
```
Traffic drop = "I expected ≥N req/min but got less"
In dev: expected traffic = 0 (no real users)
If threshold = even 1: alert fires 24/7 since no one is using dev at 3am
If threshold = 0 and alert enabled: logically fires when receiving 0 traffic (always in dev off-hours)

The correct answer: don't create a traffic drop alert at all in dev.
Set = 0 → module creates 0 traffic drop resources → no noise.
```

**Why traffic drop is the MOST important signal in production:**
```
Error rate  = 0% when traffic = 0 (no requests to fail)
Latency P99 = undefined when traffic = 0 (no requests to measure)
CPU, memory = look normal (no load)
JVM heap    = looks normal (no GC pressure)

All 7 OTHER signals show GREEN when the service is completely unreachable.
Only traffic drop catches:
  - ALB pointing to wrong target group
  - DNS not resolving (ExternalDNS broke)
  - Ingress misconfigured after a deploy
  - Service so broken it crashes before accepting connections
```

---

#### `error_rate_alert = 10.0`

```
Dev:     10.0%  — "dev code may have intentional bugs under test"
Staging: 1.0%
Prod:    0.1%   (payment), 0.5% (order), 1.0% (notification)
```

**10% in dev — when this fires:**
```
10% = 1 in 10 requests fails with HTTP 5xx
In dev with ~1 req/min: 6 errors in 60 requests would fire
This is loud enough to catch "everything is broken" but quiet enough to ignore "I pushed code that fails some test cases"

Real-world dev scenarios:
  Developer pushing new auth code that returns 401s during testing → not 10% of requests → no alert
  Accidental NPE that crashes every request → 100% error rate → alert fires → good
  
If threshold were 1% (production value in dev):
  Any integration test that exercises a 500 error path → alert fires constantly
  Developer: "oh it's just the tests" → engineers learn to ignore alerts
```

---

#### `latency_p99_ms = 2000`

```
Dev:     2000ms (payment, order) / 3000ms (notification)
Staging: 800ms  (payment) / 1000ms (order) / 2000ms (notification)
Prod:    300ms  (payment) / 500ms  (order) / 1000ms (notification)
```

**Why dev JVM is 5-7× slower than production:**

```
Production: m7g.xlarge (Graviton, 4 vCPU, 16GB) + JIT fully warmed
  - Spring Boot starts: 8-10 seconds
  - First request after start: 800ms (JIT still warming)
  - After 60 seconds of traffic: 150ms P99 (JIT fully warmed)
  
Dev: t3.medium (2 vCPU, 4GB)
  - Spring Boot starts: 30-60 seconds
  - First request: 2000-3000ms (JIT cold, slower CPU)
  - After 60 seconds: 400-600ms P99 (JIT warmed but slower CPU than prod)
  
JIT (Just-In-Time compiler):
  Java compiles methods to optimized native machine code at runtime.
  Cold JVM: runs interpreted bytecode → slow
  After ~60 seconds of traffic: hot methods are compiled → fast
  This is why the first few requests after a pod starts are always slower.
```

**`latency_p99_ms = 2000` (not 3000) for payment-service in dev:**
Payment-service is synchronous — it calls the DB and returns. Even on a cold t3.medium, DB roundtrip + Spring overhead = <2 seconds.

**`latency_p99_ms = 3000` for notification-service in dev:**
Notification-service publishes to SQS/SNS (async queue). The API call itself includes: Spring overhead + SQS SDK client setup on cold JVM + SQS network roundtrip. On a dev t3.medium with cold JIT, this legitimately takes 2-3 seconds for the first requests. `3000ms` threshold prevents false alerts during notification-service cold start.

**The unit is milliseconds — but Dynatrace uses microseconds:**
```
Inside the module:
  threshold = each.value.latency_p99_ms * 1000   # convert to µs
  
So dev "2000ms" threshold becomes 2,000,000µs in the Dynatrace metric event.
Human-readable values in this file (ms), automatic conversion in the module.
If you forget the *1000 and set threshold = 2000 directly in DT: 
  2000 microseconds = 2ms → fires on every single request constantly.
```

---

#### `cpu_saturation_pct = 90`

```
Dev:     90%   — "dev workloads are bursty"
Staging: 85%
Prod:    70%   (payment), 80% (order + notification)
```

**Why 90% is correct for dev (not a mistake):**
```
Dev workloads are bursty by nature:
  - Developer runs a full test suite: CPU spikes to 100% for 30 seconds, then drops to 5%
  - A pod restarts: Spring Boot startup is CPU-intensive (class loading, JIT compilation)
  - IDE breakpoints or profiling tools consume CPU in dev
  
If threshold = 70% (prod value) in dev:
  Every test suite run → alert fires
  Every pod restart → alert fires during startup
  Engineers: "the CPU alert fires 20 times a day in dev, never actionable"
  Result: alert fatigue → alert ignored in production too (same habit)
  
90% threshold in dev: only fires when CPU is truly and continuously saturated
  Not: "CPU spiked during test run"
  Yes: "CPU is stuck at 95% for 5 consecutive minutes with no test running"
```

**Why production needs headroom (70% for payment-service):**
```
Java GC behavior:
  G1GC runs in background threads that also consume CPU.
  At 70% CPU: GC threads can use their fair share → GC runs smoothly → latency stays flat
  At 90% CPU: GC threads compete for CPU → longer GC pauses → P99 latency spikes
  
70% threshold: alerts before GC starts impacting latency.
By the time the alert fires (CPU trending toward 70%), engineers can scale out
BEFORE users experience latency degradation.
```

---

#### `memory_usage_pct = 85`

```
Dev:     85%   — "relaxed"
Staging: 80%
Prod:    75%   (payment), 80% (order + notification)
```

**This measures RSS memory as % of container memory limit (`limits.memory`).**

```
Dev container limit: 512Mi (from values-dev.yaml)
85% threshold: fires when RSS > 435MB

Spring Boot idle on dev:
  JVM heap (Xmx=256m): ~180MB at idle
  JVM non-heap (metaspace, code cache, etc.): ~120MB
  Total RSS: ~300MB = 58% of 512MB limit

85% threshold fires at >435MB:
  Only when the app is under real load or has a memory leak growing beyond normal
  
Production container limit: 1Gi
75% threshold: fires when RSS > 768MB
  Normal load RSS: ~400-600MB
  Alert when memory is trending toward OOM, not at normal usage
```

---

#### `jvm_heap_pct = 85`

```
Dev:     85%   (Xmx=256m)
Staging: 78%   (Xmx=512m)
Prod:    70%   (Xmx=1024m)
```

**This is the most tightly coupled threshold to the Helm values.**

```
Dev Xmx=256m (from values-dev.yaml: JVM_OPTS = -Xmx256m):
  Spring Boot loads at startup: security config, JPA metadata, Hibernate schemas, etc.
  All of this lives in heap.
  Idle heap after full Spring Boot context load: ~180MB = 70% of 256m
  
  If threshold = 70%: alert fires BEFORE YOU WRITE A SINGLE LINE OF CODE
  The app has just started and the alert is already red.
  85%: only fires when heap is truly near exhaustion (>218MB)
  
Staging Xmx=512m (from values-staging.yaml: JVM_OPTS = -Xmx512m):
  k6 load test (50 VUs) fills heap to ~78% at peak
  78% threshold: fires if k6 causes MORE than the normal load test peak
  Indicates: possible memory leak OR GC not collecting fast enough under load
  
Prod Xmx=1024m (from values.yaml: JVM_OPTS = -Xmx1024m):
  Normal load: 30-50% heap
  Heavy load peak: 60-65%
  70% threshold: fires before G1GC pause times start degrading latency
  G1GC pause times increase non-linearly above 70% heap utilization
```

**The dependency chain (why you must change BOTH if you change Xmx):**
```
values-dev.yaml: JVM_OPTS = -Xmx256m
                            ↓ determines
dev/main.tf: jvm_heap_pct = 85  (calibrated for 256m baseline)

If you change Xmx to 512m in dev but don't update jvm_heap_pct:
  Spring Boot idle at 512m: ~180MB = 35%
  85% threshold: fires at >435MB
  Under k6-like load: heap goes to ~300MB = 58% → alert NEVER fires
  A real memory leak growing to 80% → still no alert
  Threshold is now too relaxed for the new Xmx
```

---

#### `pod_restart_threshold = 5`

```
Dev:     5 restarts in 5 minutes
Staging: 3 restarts in 5 minutes
Prod:    2 restarts in 5 minutes
```

**The metric is `builtin:kubernetes.workload.pods.restarts` counted over a 5-minute window.**

```
Dev scenario — why 5 is correct:
  Developer is actively fixing a crash bug:
    Push broken code → pod starts → crashes immediately → K8s restarts → crashes → repeat
    4 restarts in 3 minutes while developer is looking at the logs is normal
    5th restart: "ok this is more than a quick fix, you need to look at this"
    
  Developer changes config (wrong DB_HOST):
    Pod start → DB connection fails → crash → restart (×4 in 2 min)
    Alert: pod is in a restart loop, go check your config
    
  Developer intentionally stops a pod: 0 restarts (pod is just gone, not restarting)
  
Prod scenario — why 2 is strict:
  In production, there should be ZERO pod restarts under normal operation.
  Even 2 restarts in 5 minutes means something is wrong:
    OOM kill: pod used too much memory → K8s killed it → investigate immediately
    DB connectivity: transient DB outage causing connection errors → investigate
    Unhandled exception: bug in production code → investigate
    
  Threshold = 2: any restart loop, even a small one, pages immediately.
  In production, "a few restarts is fine" is never acceptable.
```

---

#### `network_error_rate_pct = 5.0`

```
Dev:     5.0%
Staging: 2.0%
Prod:    0.5% (payment), 1.0% (order + notification)
```

**The metric is `builtin:host.net.errorRate` — network packet errors on the node's network interface.**

```
What this measures:
  Packet retransmits, checksum errors, dropped packets at the NIC level
  NOT HTTP errors (that's error_rate_alert)
  NOT application-level failures
  This is the network HARDWARE / driver layer

Dev: 5% threshold
  Dev clusters often share underlying AWS hardware with other workloads
  t3.medium instances sometimes have slightly elevated network error rates
  during EC2 instance "noisy neighbor" situations
  5% threshold: only fires when there's a real network degradation, not background noise

Production: 0.5% threshold
  Dedicated m7g.xlarge nodes with predictable network quality
  Any network error rate above 0.5% for 5+ consecutive minutes = investigate
  Could indicate: bad ENI, NIC driver issue, physical host problem → notify AWS support
```

---

## Why notification-service gets `latency_p99_ms = 3000` (not 2000)

This is the one difference between the three services in dev.

```
payment-service:    latency_p99_ms = 2000
order-service:      latency_p99_ms = 2000
notification-service: latency_p99_ms = 3000   ← different
```

**The design reason:**
```
payment-service flow:
  POST /api/v1/payments
  → Spring validates request
  → JPA saves to PostgreSQL
  → Returns {"status": "created"}
  
  Latency = Spring overhead + DB write (usually <50ms on warm connection)
  On cold dev t3.medium: max ~2 seconds for all JIT + DB setup

notification-service flow:
  POST /api/v1/notifications
  → Spring validates request
  → Publishes message to AWS SQS
  → Returns {"status": "queued"}
  
  Latency = Spring overhead + SQS SDK initialization (cold JVM) + SQS API roundtrip
  SQS SDK client: first call requires HTTPS connection setup, auth via IRSA, region resolution
  On cold dev t3.medium: SQS first call can take 2-4 seconds
  After warmup: ~200-300ms
  
  3000ms threshold: handles the cold-start SQS SDK initialization
  2000ms threshold would alert on EVERY pod restart in dev (pod start → smoke test → SQS cold start → 2.5s → alert)
```

---

## What this file does NOT contain (intentionally)

| Missing thing | Where it IS | Why not here |
|---|---|---|
| EKS cluster config | `terraform/modules/eks/` | Infra and monitoring config are separate concerns, separate pipelines |
| VPC / network config | `terraform/modules/vpc/` | Same reason |
| IAM roles | `terraform/modules/eks/` | EKS module creates IRSA roles for all services |
| ECR repositories | `terraform/modules/ecr/` | ECR is app infra, not monitoring |
| Kubernetes resources | `gitops/<env>/` | ArgoCD manages K8s, Terraform manages AWS/DT |
| Staging thresholds | `terraform/environments/staging/main.tf` | Same module, different callers |
| Production thresholds | `terraform/environments/production/main.tf` | Same module, different callers |

---

## What breaks if you change specific values

| Change | Immediate effect | How it manifests |
|---|---|---|
| `traffic_min_rps = 1` (dev) | Traffic alert enabled in dev | Alert fires 24/7 during off-hours when no one is testing |
| `error_rate_alert = 0.1` (dev) | Production threshold applied to dev | Any integration test exercising error paths → constant Slack noise |
| `latency_p99_ms = 300` (dev) | Production threshold applied to dev | Every pod restart (JIT cold start) triggers latency alert → alert fatigue |
| `jvm_heap_pct = 70` (dev, Xmx=256m) | Alert fires at idle | Spring Boot loads 70% heap just starting up → permanent red alert |
| `slo_target = 99.9` (dev) | Strict SLO in dev | SLO burns through error budget on routine dev activity → burn rate alerts fire constantly |
| `pagerduty_integration_keys = {team: "abc"}` (dev) | PagerDuty enabled in dev | On-call engineers get paged for dev issues at 3am |
| Remove `synthetic_locations` entry | Synthetic not created | No external health check → silent outage detection gap |
| Change `bucket` to prod bucket name | Dev state stored in prod S3 | Extremely dangerous: dev Terraform state corrupts prod; destroy in dev destroys prod |
