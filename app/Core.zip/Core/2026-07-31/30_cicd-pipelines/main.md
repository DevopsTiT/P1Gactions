# Build and Optimize CI/CD Pipelines — Deep Dive for SREs

---

## E2E Flow Summary

```
Developer pushes code
        │
        ▼
  [CI: Continuous Integration]
        │
        ├─ 1. Trigger (push/PR/tag)
        ├─ 2. Checkout code
        ├─ 3. Install dependencies       ← cache here = massive time savings
        ├─ 4. Lint + Static Analysis
        ├─ 5. Unit Tests
        ├─ 6. Build artifact (jar/image)  ← cache layers here
        ├─ 7. Integration Tests
        ├─ 8. Security Scan
        ├─ 9. Push artifact to registry
        │
        ▼
  [CD: Continuous Delivery/Deployment]
        │
        ├─ 10. Deploy to DEV             ← automatic
        ├─ 11. Smoke Tests
        ├─ 12. Deploy to STAGING         ← automatic
        ├─ 13. E2E / Performance Tests
        ├─ 14. Deploy to PRODUCTION      ← manual gate OR automatic
        └─ 15. Post-deploy verification  ← canary, health checks
```

**One-line goal:** Every code change automatically builds, tests, validates, and deploys itself — with zero manual steps except intentional gates, and rollback available in under 5 minutes.

---

## Decision Tree — What Pipeline Pattern Do I Need?

```
What are you deploying?
│
├── A library / shared package
│       └── Pipeline: build → test → publish to Artifactory/NPM
│           No deployment stage needed
│
├── A microservice (container)
│       └── Pipeline: build → test → docker build → push to registry → deploy to k8s
│
├── Infrastructure (Terraform)
│       └── Pipeline: validate → plan → (manual gate) → apply
│
├── Frontend SPA
│       └── Pipeline: lint → test → build bundle → push to CDN/S3
│
Is the target environment PRODUCTION?
│
├── Yes, high traffic / critical service
│       └── Use: Canary or Blue/Green deployment strategy
│
├── Yes, but low risk / internal tool
│       └── Use: Rolling update with health check gate
│
└── No (dev/staging)
        └── Use: Direct deployment, no manual gates
```

---

## Tool Map

| Tool | Role |
|---|---|
| GitHub Actions | CI/CD platform hosted by GitHub |
| GitLab CI | CI/CD built into GitLab |
| Jenkins | Self-hosted CI/CD server |
| Bitbucket Pipelines | CI/CD built into Bitbucket |
| ArgoCD | GitOps CD for Kubernetes |
| Flux | GitOps CD for Kubernetes |
| Docker | Build container images |
| Kaniko | Build Docker images inside Kubernetes (no Docker daemon) |
| Artifactory / ECR / GCR | Container and artifact registries |
| Helm | Kubernetes package manager (used in CD) |
| Trivy / Snyk | Security scanning of images and dependencies |
| SonarQube | Static code analysis / code quality |
| k6 / Gatling | Performance testing in pipeline |

---

## Part 1 — CI vs CD: What They Actually Mean

### CI — Continuous Integration

**What:** Every code push triggers automatic building and testing.

**Goal:** Detect integration problems within minutes, not days. When 10 developers push code daily, CI ensures their changes don't break each other.

```
Without CI:
  Developer A and B both modify auth module for 2 weeks
  → Merge → 200 conflicts, mysterious failures
  → "Integration hell" — takes days to sort out

With CI:
  Developer A pushes → tests run in 5 min → pass
  Developer B pushes → tests run in 5 min → FAIL on conflict with A's change
  → Developer B fixes in minutes, not days
```

### CD — Continuous Delivery vs Continuous Deployment

```
Continuous DELIVERY:
  Pipeline automates everything UP TO production.
  Deployment to production requires a HUMAN to click "approve."
  → "The code is always ready to deploy"

Continuous DEPLOYMENT:
  Pipeline automates ALL the way to production automatically.
  No human gate.
  → "Every green build automatically ships to prod"
```

Most companies use Continuous Delivery (human gate for prod) or Deployment with canary + automatic rollback.

---

## Part 2 — Pipeline Structure: Stages and Jobs

### Stages (Sequential) vs Jobs (Parallel)

```
STAGE 1: Test          STAGE 2: Build       STAGE 3: Deploy
─────────────────      ──────────────────   ──────────────────
job: lint     ─┐       job: docker-build    job: deploy-staging
job: unit-test ┼► all  (sequential after    job: deploy-dev ─┐ (parallel)
job: sec-scan ─┘  pass stage 1)             job: notify     ─┘
```

**Key principle:** Jobs WITHIN a stage run in parallel (free speed). Stages run sequentially (enforce order).

### Fail-Fast Strategy

Put CHEAP, FAST checks first. Fail quickly before running expensive tests.

```
Stage order (optimized):
  1. Lint (10 seconds)          ← fail here = no wasted test runner time
  2. Unit tests (2 minutes)     ← fast, catches most bugs
  3. Build (3 minutes)          ← only build if tests pass
  4. Integration tests (10 min) ← only run if build succeeds
  5. Security scan (5 minutes)  ← non-blocking warning or blocking
  6. Deploy (2 minutes)         ← only if everything above passes
```

---

## Part 3 — GitHub Actions Deep Dive

### Basic Workflow Structure

```yaml
# .github/workflows/ci-cd.yml

name: CI/CD Pipeline

on:
  push:
    branches: [main, 'release/**']
  pull_request:
    branches: [main]
  workflow_dispatch:          # allow manual trigger

env:
  REGISTRY: ghcr.io
  IMAGE_NAME: ${{ github.repository }}
  JAVA_VERSION: '17'

jobs:
  # ── STAGE 1: Test ──────────────────────────────────────────
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          java-version: ${{ env.JAVA_VERSION }}
          distribution: temurin
          cache: maven              # cache ~/.m2 automatically
      - name: Run Checkstyle
        run: mvn checkstyle:check

  unit-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          java-version: ${{ env.JAVA_VERSION }}
          distribution: temurin
          cache: maven
      - name: Run unit tests
        run: mvn test -Dtest="*UnitTest" --batch-mode
      - name: Upload test results
        uses: actions/upload-artifact@v4
        if: always()              # upload even on failure
        with:
          name: unit-test-results
          path: target/surefire-reports/

  # ── STAGE 2: Build ─────────────────────────────────────────
  build:
    needs: [lint, unit-test]    # wait for BOTH stage 1 jobs
    runs-on: ubuntu-latest
    outputs:
      image-tag: ${{ steps.meta.outputs.tags }}
      image-digest: ${{ steps.build.outputs.digest }}
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-java@v4
        with:
          java-version: ${{ env.JAVA_VERSION }}
          distribution: temurin
          cache: maven

      - name: Build JAR
        run: mvn package -DskipTests --batch-mode

      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3

      - name: Log in to Container Registry
        uses: docker/login-action@v3
        with:
          registry: ${{ env.REGISTRY }}
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}

      - name: Extract Docker metadata
        id: meta
        uses: docker/metadata-action@v5
        with:
          images: ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}
          tags: |
            type=sha,prefix=sha-
            type=ref,event=branch
            type=semver,pattern={{version}}

      - name: Build and push Docker image
        id: build
        uses: docker/build-push-action@v5
        with:
          context: .
          push: true
          tags: ${{ steps.meta.outputs.tags }}
          labels: ${{ steps.meta.outputs.labels }}
          cache-from: type=gha         # GitHub Actions cache
          cache-to: type=gha,mode=max  # store ALL layers

  # ── STAGE 3: Security Scan ─────────────────────────────────
  security-scan:
    needs: build
    runs-on: ubuntu-latest
    steps:
      - name: Run Trivy vulnerability scanner
        uses: aquasecurity/trivy-action@master
        with:
          image-ref: ${{ needs.build.outputs.image-tag }}
          format: sarif
          output: trivy-results.sarif
          severity: CRITICAL,HIGH
          exit-code: '1'            # fail pipeline on CRITICAL findings

      - name: Upload Trivy results to GitHub Security
        uses: github/codeql-action/upload-sarif@v2
        if: always()
        with:
          sarif_file: trivy-results.sarif

  # ── STAGE 4: Deploy to Staging ─────────────────────────────
  deploy-staging:
    needs: [build, security-scan]
    runs-on: ubuntu-latest
    environment: staging           # uses GitHub environment protection rules
    steps:
      - uses: actions/checkout@v4

      - name: Deploy to staging
        env:
          IMAGE_TAG: ${{ needs.build.outputs.image-tag }}
          KUBECONFIG: ${{ secrets.STAGING_KUBECONFIG }}
        run: |
          helm upgrade --install checkout ./charts/checkout \
            --namespace staging \
            --set image.tag=${IMAGE_TAG} \
            --set replicaCount=2 \
            --wait \
            --timeout=5m

      - name: Run smoke tests
        run: |
          kubectl wait --for=condition=ready pod \
            -l app=checkout -n staging --timeout=120s
          curl -f https://staging.checkout.internal/health

  # ── STAGE 5: Deploy to Production ──────────────────────────
  deploy-production:
    needs: deploy-staging
    runs-on: ubuntu-latest
    environment: production        # requires manual approval in GitHub UI
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to production (canary)
        env:
          IMAGE_TAG: ${{ needs.build.outputs.image-tag }}
          KUBECONFIG: ${{ secrets.PROD_KUBECONFIG }}
        run: |
          helm upgrade --install checkout ./charts/checkout \
            --namespace production \
            --set image.tag=${IMAGE_TAG} \
            --set canary.enabled=true \
            --set canary.weight=10 \
            --wait --timeout=10m
```

---

## Part 4 — Docker Layer Caching (The Biggest Speed Win)

Docker images are built in layers. If a layer hasn't changed, Docker reuses it from cache. Bad Dockerfile ordering destroys this.

### Bad Dockerfile (No Cache Optimization)

```dockerfile
FROM eclipse-temurin:17-jre-alpine

COPY . /app                    # ← copies ALL files including src/
WORKDIR /app
RUN mvn package                # ← runs FULL build every time
                               # ANY file change = full rebuild
EXPOSE 8080
CMD ["java", "-jar", "target/app.jar"]
```

**Problem:** Any change to a single `.java` file invalidates the COPY layer → full `mvn package` runs every time → 5 min per build.

### Good Dockerfile (Layer Cache Optimized)

```dockerfile
FROM eclipse-temurin:17-jdk-alpine AS builder

WORKDIR /app

# Step 1: copy ONLY dependency manifests first
COPY pom.xml .
COPY .mvn/ .mvn/
COPY mvnw .

# Step 2: download dependencies (cached until pom.xml changes)
RUN ./mvnw dependency:go-offline -B

# Step 3: copy source code (cache invalidated only when src changes)
COPY src/ src/

# Step 4: build
RUN ./mvnw package -DskipTests -B

# ─── Runtime stage (small image) ───────────────────────────
FROM eclipse-temurin:17-jre-alpine AS runtime

WORKDIR /app
COPY --from=builder /app/target/*.jar app.jar

# Run as non-root (security best practice)
RUN addgroup -S appgroup && adduser -S appuser -G appgroup
USER appuser

EXPOSE 8080
ENTRYPOINT ["java", "-jar", "app.jar"]
```

**Result:** `mvn dependency:go-offline` layer (the slow part) is cached until `pom.xml` changes. Source code changes only rebuild the `mvn package` step → build time drops from 5 min to 30 seconds.

### Multi-Stage Build (Smaller Production Images)

```
Builder stage:  JDK (400MB) + Maven + source code → builds jar
Runtime stage:  JRE (80MB) + jar only

Without multi-stage: 450MB image
With multi-stage:    90MB image
Smaller image = faster pull, smaller attack surface
```

---

## Part 5 — Caching Strategies

### 1. Dependency Cache (Maven / npm / pip)

```yaml
# GitHub Actions — Maven cache
- uses: actions/setup-java@v4
  with:
    java-version: '17'
    distribution: temurin
    cache: maven              # caches ~/.m2/repository

# GitHub Actions — npm cache
- uses: actions/setup-node@v4
  with:
    node-version: '20'
    cache: npm                # caches ~/.npm

# GitHub Actions — pip cache
- uses: actions/setup-python@v5
  with:
    python-version: '3.11'
    cache: pip
```

**Impact:** Maven dependency download: 3 minutes cold → 5 seconds cached.

### 2. Docker Layer Cache

```yaml
# Use GitHub Actions Cache for Docker layers
- uses: docker/build-push-action@v5
  with:
    cache-from: type=gha
    cache-to: type=gha,mode=max    # max = cache all layers including intermediate

# Use registry cache (better for self-hosted runners)
- uses: docker/build-push-action@v5
  with:
    cache-from: type=registry,ref=ghcr.io/myorg/myapp:buildcache
    cache-to: type=registry,ref=ghcr.io/myorg/myapp:buildcache,mode=max
```

### 3. Test Result Caching

```yaml
# Cache test results — skip tests if source hasn't changed
- name: Cache test results
  uses: actions/cache@v4
  id: test-cache
  with:
    path: target/surefire-reports
    key: test-${{ hashFiles('src/**/*.java') }}

- name: Run tests
  if: steps.test-cache.outputs.cache-hit != 'true'
  run: mvn test
```

### 4. Tool Cache (Terraform, kubectl, helm)

```yaml
- uses: hashicorp/setup-terraform@v3
  with:
    terraform_version: '1.7.0'
    # automatically cached by the action

- uses: azure/setup-helm@v3
  with:
    version: '3.13.0'
```

---

## Part 6 — Parallelism Optimization

### Parallel Matrix Builds

Run tests across multiple Java versions or OS in parallel:

```yaml
test:
  strategy:
    matrix:
      java: ['17', '21']
      os: [ubuntu-latest, windows-latest]
    fail-fast: false           # don't cancel others if one fails
  runs-on: ${{ matrix.os }}
  steps:
    - uses: actions/setup-java@v4
      with:
        java-version: ${{ matrix.java }}
```

### Parallel Test Sharding

Split a large test suite across multiple runners:

```yaml
test:
  strategy:
    matrix:
      shard: [1, 2, 3, 4]    # 4 parallel runners
  steps:
    - name: Run test shard ${{ matrix.shard }} of 4
      run: |
        mvn test \
          -Dsurefire.forkCount=1 \
          -Dgroups="shard${{ matrix.shard }}"

# Or with pytest:
    - run: |
        pytest --splits 4 --group ${{ matrix.shard }} tests/
```

**Impact:** 20-minute test suite → 5 minutes with 4-way sharding.

### DAG-Based Pipeline (Directed Acyclic Graph)

Design your pipeline as a DAG to maximize parallelism:

```
          ┌──── lint ────┐
push ────►├──── unit-test ┼──► build ──► sec-scan ──► deploy-staging ──► deploy-prod
          └──── sec-code ─┘               │
                                          └──► integration-test ──► (join) ──► deploy-staging
```

Only add `needs:` where there is a TRUE dependency. Unnecessary sequential ordering wastes time.

---

## Part 7 — Deployment Strategies

### Strategy 1: Rolling Update

Replace old pods with new ones gradually. Kubernetes default.

```yaml
# deployment.yaml
spec:
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 0        # never reduce below desired count
      maxSurge: 1              # create 1 extra pod during update
  replicas: 5
```

```
Before: [v1][v1][v1][v1][v1]
Step 1: [v1][v1][v1][v1][v2]
Step 2: [v1][v1][v1][v2][v2]
Step 3: [v1][v1][v2][v2][v2]
Step 4: [v1][v2][v2][v2][v2]
Step 5: [v2][v2][v2][v2][v2]
```

**Good for:** Low-risk changes, zero-downtime. **Risk:** Both versions run simultaneously (backward compat required).

### Strategy 2: Blue/Green Deployment

Run two complete environments. Switch traffic instantly.

```
BLUE (current production): [v1][v1][v1][v1][v1]  ← traffic here
GREEN (new version):       [v2][v2][v2][v2][v2]  ← ready, no traffic

Test green → switch load balancer → green gets 100% traffic
If bad:  switch back to blue in seconds (instant rollback)
```

```yaml
# Pipeline step: switch traffic
- name: Switch to green
  run: |
    kubectl patch service checkout \
      -p '{"spec":{"selector":{"version":"green"}}}'
```

**Good for:** Instant rollback capability. **Cost:** Requires 2x infrastructure during switch.

### Strategy 3: Canary Deployment (Best Practice for Production)

Send small % of traffic to new version, observe, then gradually increase.

```
v1 (stable):  ──────────────────────────────────► 90% of users
v2 (canary):  ──────────────────────────────────►  10% of users
                    │
                    ▼ observe: error rate, latency, business metrics
                    │
              if good: increase to 25% → 50% → 100%
              if bad:  route 0% to canary, rollback instantly
```

```yaml
# Argo Rollouts canary config
apiVersion: argoproj.io/v1alpha1
kind: Rollout
spec:
  strategy:
    canary:
      steps:
        - setWeight: 10          # 10% traffic to new version
        - pause: {duration: 5m}  # observe for 5 minutes
        - setWeight: 25
        - pause: {duration: 5m}
        - setWeight: 50
        - pause: {duration: 10m}
        - setWeight: 100         # full cutover
      analysis:
        templates:
          - templateName: success-rate
        args:
          - name: service-name
            value: checkout
```

**Good for:** Catching production issues before they affect all users. Requires progressive delivery tooling (Argo Rollouts, Flagger).

---

## Part 8 — GitOps with ArgoCD

GitOps means: **Git is the single source of truth for what runs in production.** No `kubectl apply` from pipelines directly.

### How GitOps Works

```
Developer Pipeline:
  code push → CI builds image → pushes image to registry
                              → updates image tag in Git (config repo)

ArgoCD (continuous):
  watches Git config repo → detects change → syncs cluster to match Git
```

### ArgoCD Application

```yaml
# argocd-app.yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: checkout-production
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/myorg/k8s-configs
    targetRevision: main
    path: apps/checkout/production
  destination:
    server: https://kubernetes.default.svc
    namespace: production
  syncPolicy:
    automated:
      prune: true           # delete resources removed from Git
      selfHeal: true        # revert manual kubectl changes
    syncOptions:
      - CreateNamespace=true
      - PrunePropagationPolicy=foreground
    retry:
      limit: 3
      backoff:
        duration: 5s
        factor: 2
```

### CI Pipeline Updates ArgoCD via Image Tag

```yaml
# In CI pipeline: update image tag in config repo
- name: Update image tag in config repo
  run: |
    git clone https://github.com/myorg/k8s-configs
    cd k8s-configs

    # Update the image tag (using yq or kustomize)
    yq e -i \
      '.images[0].newTag = "${{ steps.meta.outputs.version }}"' \
      apps/checkout/production/kustomization.yaml

    git config user.email "ci@myorg.com"
    git config user.name "CI Pipeline"
    git add .
    git commit -m "chore: update checkout to ${{ github.sha }}"
    git push
    # ArgoCD detects this commit and syncs automatically
```

**Why GitOps beats direct kubectl:** Every production change is a Git commit → full audit trail, PR review for production changes, easy rollback (just revert the commit).

---

## Part 9 — Security in CI/CD Pipelines

### Secrets Management

```yaml
# WRONG: hardcoded secret in workflow
- run: docker login -u myuser -p mysecretpassword   # ← NEVER DO THIS

# RIGHT: use GitHub Secrets
- run: |
    echo "${{ secrets.REGISTRY_PASSWORD }}" | \
      docker login -u ${{ secrets.REGISTRY_USERNAME }} --password-stdin
```

**Never put secrets in:**
- Workflow YAML files
- Docker images
- Logs (mask them)
- Environment variables that get printed

Use: GitHub Secrets, HashiCorp Vault, AWS Secrets Manager, GCP Secret Manager.

### OIDC — Keyless Cloud Authentication

Instead of storing long-lived cloud credentials as secrets:

```yaml
# GitHub OIDC → AWS (no AWS_SECRET_ACCESS_KEY needed)
permissions:
  id-token: write    # required for OIDC
  contents: read

- name: Configure AWS credentials
  uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789:role/github-actions-role
    aws-region: ap-northeast-1
    # No secret keys needed — GitHub exchanges OIDC token for temp AWS creds
```

### Image Signing (Supply Chain Security)

```yaml
# Sign the image with Cosign after push
- name: Sign image
  run: |
    cosign sign --yes \
      ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}@${{ steps.build.outputs.digest }}

# In deployment pipeline: verify signature before deploying
- name: Verify image signature
  run: |
    cosign verify \
      --certificate-identity=https://github.com/myorg/myapp/.github/workflows/ci.yml@refs/heads/main \
      --certificate-oidc-issuer=https://token.actions.githubusercontent.com \
      ${{ env.IMAGE }}
```

### Dependency Scanning in Pipeline

```yaml
# Scan dependencies for known CVEs
- name: Run Snyk dependency scan
  uses: snyk/actions/maven@master
  env:
    SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
  with:
    args: --severity-threshold=high --fail-on=all

# Scan container image
- name: Run Trivy
  uses: aquasecurity/trivy-action@master
  with:
    image-ref: ${{ env.IMAGE }}
    severity: CRITICAL
    exit-code: '1'
```

---

## Part 10 — Pipeline Optimization Checklist

### Speed Optimization

```
□ Dependencies cached (Maven/npm/pip)?
□ Docker layers ordered correctly (dependencies before source)?
□ Docker layer cache enabled (type=gha or registry)?
□ Multi-stage Docker build? (reduces image size AND build time)
□ Jobs within stages run in parallel?
□ Tests sharded across multiple runners?
□ Only run expensive jobs on main branch (not PRs)?
□ Cancel in-progress runs on new push (concurrency control)?
```

```yaml
# Cancel in-progress runs when new commit is pushed to same branch
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true
```

### Reliability Optimization

```
□ Retry transient failures (network, registry pull)?
□ Timeouts on every job?
□ Post-deploy health checks before marking deploy complete?
□ Rollback automated on health check failure?
□ Artifacts archived for debugging failed builds?
□ Test results published for PR visibility?
```

```yaml
# Retry with timeout
- name: Deploy with retry
  uses: nick-fields/retry@v2
  with:
    timeout_minutes: 10
    max_attempts: 3
    command: helm upgrade --install ...
```

### Post-Deploy Verification

```bash
# Health check gate after deploy
kubectl rollout status deployment/checkout -n production --timeout=5m

# Smoke test
for i in {1..10}; do
  response=$(curl -s -o /dev/null -w "%{http_code}" https://api.prod.com/health)
  if [ "$response" != "200" ]; then
    echo "Health check failed: $response"
    exit 1
  fi
  sleep 5
done

# Auto-rollback on failure
if ! helm test checkout -n production; then
  echo "Tests failed — rolling back"
  helm rollback checkout -n production
  exit 1
fi
```

---

## Part 11 — Pipeline Metrics: How to Measure Pipeline Health

SREs don't just run pipelines — they MEASURE them like services.

### Key Pipeline Metrics (DORA Metrics)

```
1. DEPLOYMENT FREQUENCY
   How often you successfully deploy to production
   Elite: multiple times per day
   Low: less than once per month

2. LEAD TIME FOR CHANGES
   Time from code commit to running in production
   Elite: < 1 hour
   Low: 1-6 months

3. CHANGE FAILURE RATE
   % of deploys that cause a production incident
   Elite: 0-15%
   Low: 46-60%

4. MEAN TIME TO RESTORE (MTTR)
   How long to recover from a production incident
   Elite: < 1 hour
   Low: 1 week to 1 month
```

### Measuring Pipeline Duration

```yaml
# GitHub Actions — emit timing to monitoring
- name: Record pipeline duration
  if: always()
  run: |
    END_TIME=$(date +%s)
    START_TIME=${{ steps.start.outputs.time }}
    DURATION=$((END_TIME - START_TIME))

    # Send to Prometheus pushgateway
    cat <<EOF | curl --data-binary @- http://pushgateway:9091/metrics/job/cicd
    pipeline_duration_seconds{pipeline="${{ github.workflow }}",branch="${{ github.ref_name }}",status="${{ job.status }}"} ${DURATION}
    EOF
```

### Pipeline SLOs

```
Build success rate:    > 90%   (10% failure = developer experience problem)
Average build time:   < 10 min (longer = developers stop waiting for CI)
Deploy success rate:  > 95%   (rollback needed too often = stability problem)
Lead time (p95):      < 30 min (commit to production)
```

---

## Common Mistakes and Fixes

| Mistake | Symptom | Fix |
|---|---|---|
| No dependency caching | Every build downloads 200MB of deps | Add `cache: maven/npm` to setup actions |
| COPY . before dependency install | Docker cache invalidated on any file change | Copy pom.xml/package.json first, then source |
| No `for:` on health checks | Pipeline succeeds before app is ready | `kubectl rollout status --timeout=5m` |
| Secrets in logs | `echo $SECRET` prints to CI logs | Use secret masking, never echo secrets |
| No concurrency control | 10 PRs = 10 simultaneous builds eating all runners | Add `concurrency:` with `cancel-in-progress: true` |
| Deploy on every branch | Feature branches deploy to prod | Only deploy from `main` or release tags |
| No test in pipeline | "Works on my machine" bugs reach prod | Minimum: unit tests on every PR |
| Single job pipeline | 20-min pipeline blocks every PR review | Parallelize lint/test/scan jobs |
| No rollback automation | Bad deploy needs manual fix at 3am | Add `helm rollback` on health check fail |
| Large final Docker image | 2GB image → 3-min pull on every deploy | Multi-stage build, use alpine/distroless base |
| Long-lived cloud credentials in secrets | Secret rotation is a pain, rotation failure = outage | Use OIDC keyless auth |
| `kubectl apply` from pipeline | No audit trail, no GitOps | Use ArgoCD/Flux — pipeline updates Git, ArgoCD deploys |
