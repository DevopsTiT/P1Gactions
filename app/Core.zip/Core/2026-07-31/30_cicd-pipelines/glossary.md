# CI/CD Pipelines Glossary — SRE Beginner Reference

Every term from main.md explained in plain language. One entry per term.

---

**CI (Continuous Integration)**
The practice of automatically building and testing code every time a developer pushes a change. Detects integration problems in minutes instead of days. "Continuous" means it happens on every single push, not once a week.

**CD (Continuous Delivery)**
Automating everything in the pipeline up to production, but requiring a human to click "approve" before the final deployment. The code is always in a deployable state — the human just decides when to ship.

**Continuous Deployment**
Like Continuous Delivery, but with no human gate — every successful build automatically deploys to production. Requires very high confidence in automated testing and canary/rollback capabilities.

**Pipeline**
A sequence of automated steps that code goes through from commit to deployment. Think of it as an assembly line — each station (stage) performs a specific task and passes the result to the next.

**Stage**
A group of steps in a pipeline that run in sequence. Stage 1 (tests) must finish before Stage 2 (build) starts. Stages enforce order; jobs within a stage run in parallel.

**Job**
A single unit of work in a pipeline that runs on one machine (runner). Multiple jobs within the same stage run in parallel if there are no dependencies between them.

**Runner**
The machine (virtual or physical) that executes pipeline jobs. GitHub provides hosted runners (`ubuntu-latest`). You can also use self-hosted runners on your own infrastructure for more control or speed.

**Trigger**
The event that starts a pipeline. Common triggers: push to a branch, opening a PR, creating a git tag, a scheduled cron time, or manual click.

**GitHub Actions**
GitHub's built-in CI/CD platform. Workflows are defined in `.github/workflows/*.yml` files. Free for public repos; uses "minutes" quota for private repos.

**Workflow (GitHub Actions)**
A YAML file defining a pipeline for GitHub Actions. Contains: when to trigger (`on:`), what jobs to run, and what steps each job performs.

**`on: push` / `on: pull_request`**
GitHub Actions trigger syntax. `on: push` fires the workflow when code is pushed to a branch. `on: pull_request` fires when a PR is opened or updated. You can specify which branches.

**`needs:`**
GitHub Actions keyword that creates a dependency between jobs. `needs: [lint, unit-test]` means "don't start this job until both lint and unit-test complete successfully."

**`environment:` (GitHub Actions)**
A named deployment target (e.g., "staging", "production") with optional protection rules. You can require manual approval, specific reviewers, or wait timers before a job targeting that environment runs.

**Artifact (Pipeline)**
A file or set of files produced by a pipeline job and stored for later use or download. Examples: compiled JAR, test results, Docker image digest, coverage report. Artifacts let later jobs use outputs from earlier jobs.

**`actions/cache`**
A GitHub Actions action that stores and restores files between pipeline runs to speed up workflows. Used for Maven `~/.m2`, npm `node_modules`, pip packages, etc.

**Cache Key**
A string that identifies a specific cache entry. Usually based on a hash of the dependency file (`pom.xml`, `package-lock.json`). If the file changes, the key changes and the cache is rebuilt.

**Docker**
A tool for packaging applications and their dependencies into portable, isolated containers (images). CI pipelines typically build a Docker image as the deployable artifact.

**Dockerfile**
The recipe for building a Docker image. Each line creates a layer. Order matters enormously for cache efficiency — put rarely-changing steps first.

**Docker Layer**
One step in a Dockerfile's build process stored as a separate chunk. Docker caches each layer independently. If a layer hasn't changed, Docker reuses the cached version — this is the source of Docker's build speed.

**Layer Cache Invalidation**
When a change causes Docker to re-execute a layer and all layers that come after it. If you `COPY . /app` early in the Dockerfile, ANY file change in the repo invalidates that layer and everything below it.

**Multi-Stage Docker Build**
A Dockerfile technique that uses multiple `FROM` statements. An early "builder" stage compiles the code using a large JDK image; a final "runtime" stage copies only the compiled artifact into a small JRE image. Result: tiny, secure production image.

**Distroless / Alpine**
Minimal Linux base images for Docker containers. Alpine (~5MB) includes a shell; distroless (~2MB) includes almost nothing — just the runtime. Smaller = faster pulls, fewer CVEs, smaller attack surface.

**BuildKit**
The modern Docker build engine (enabled by `DOCKER_BUILDKIT=1`). Supports parallel stage building, better caching, secrets in build, and cache export/import. Required for advanced cache features.

**`cache-from` / `cache-to` (Docker build)**
Docker BuildKit options that import/export layer caches from external storage (GitHub Actions cache or a container registry). Allows cache to persist between pipeline runs on different machines.

**Container Registry**
A server that stores and serves Docker images. Examples: GitHub Container Registry (ghcr.io), AWS ECR, Google GCR, Docker Hub. Like npm for Docker images.

**Image Tag**
A human-readable label attached to a Docker image to identify a specific version. Examples: `latest`, `v1.2.3`, `sha-abc123`. Using the git commit SHA as the tag creates an immutable, traceable reference.

**Image Digest**
A content-addressable hash (SHA256) of the exact image contents. Unlike a tag (which can be overwritten), a digest is immutable — `image@sha256:abc123` always refers to the same bytes.

**Rolling Update**
A Kubernetes deployment strategy that replaces old pods with new ones one at a time. Zero downtime, but both versions run simultaneously during the transition — requires backward compatibility.

**Blue/Green Deployment**
A deployment strategy where two full environments exist: "blue" (current live) and "green" (new version). Traffic switches from blue to green in one instant. Rollback is instant too — just switch back to blue.

**Canary Deployment**
A deployment strategy that sends a small percentage of traffic (e.g., 10%) to the new version while most users stay on the stable version. If the canary looks healthy, gradually increase. If not, instantly redirect all traffic back.

**Progressive Delivery**
The umbrella term for deployment strategies (canary, feature flags, A/B tests) that release changes gradually to subsets of users instead of everyone at once. Reduces blast radius of bad deployments.

**Argo Rollouts**
A Kubernetes controller that adds advanced deployment strategies (canary, blue/green) to Kubernetes. Works alongside Kubernetes Deployments and adds pause/promote/abort controls.

**Flagger**
Another progressive delivery tool for Kubernetes (from Flux ecosystem). Automates canary analysis using metrics — automatically promotes if metrics are healthy, rolls back if they degrade.

**GitOps**
A deployment philosophy where Git is the single source of truth for what should run in production. Changes to production happen by changing Git, not by running commands directly. The cluster continuously syncs to match Git state.

**ArgoCD**
A GitOps continuous delivery tool for Kubernetes. Watches a Git repository containing Kubernetes manifests and automatically keeps the cluster in sync with what Git says. "Git says 3 replicas → cluster has 3 replicas."

**Flux**
Another GitOps tool for Kubernetes, similar to ArgoCD but with a different architecture (pull-based controllers). Both serve the same purpose: sync cluster state from Git.

**Kustomize**
A Kubernetes configuration management tool. Uses a `kustomization.yaml` file to overlay and patch base manifests for different environments (dev/staging/prod) without templating. Built into `kubectl`.

**Helm**
A Kubernetes package manager. Applications are packaged as "charts" with Go templates and a `values.yaml` for configuration. `helm upgrade --install` deploys or updates an application. Popular in CI/CD pipelines.

**Helm Chart**
A package of pre-configured Kubernetes resources. Like an apt/brew package but for Kubernetes apps. Contains templates for Deployment, Service, Ingress, etc.

**`helm upgrade --install`**
A Helm command that installs a chart if it doesn't exist, or upgrades it if it does. The workhorse of Helm-based CD pipelines.

**`helm rollback`**
Command to revert a Helm release to a previous revision. Kubernetes applies the old manifests, replacing new pods with old ones. Useful for emergency rollbacks.

**`--wait` (Helm)**
Flag that makes `helm upgrade` block until all pods are ready. Without it, Helm returns "success" as soon as the manifest is applied, even if pods are crashlooping.

**`kubectl rollout status`**
Command that watches a Kubernetes rollout and exits 0 (success) when all pods are healthy, or exits 1 (failure) on timeout. Essential for post-deploy verification in pipelines.

**`kubectl rollout undo`**
Command to immediately revert a Kubernetes Deployment to the previous version. The fastest manual rollback mechanism — one command, pods start replacing in seconds.

**Smoke Test**
A minimal test run immediately after deployment to verify the application is basically alive. Not a full test suite — just enough to catch "the app isn't even starting." Usually: does `/health` return 200?

**Health Check**
An endpoint (`/health`, `/readiness`) that returns the application's current status. Kubernetes uses liveness/readiness probes to decide whether to send traffic to a pod. CI/CD pipelines use health checks as post-deploy gates.

**Trivy**
An open-source security scanner (by Aqua Security) that scans container images, filesystems, and Kubernetes configs for known CVEs and misconfigurations. Integrates into CI pipelines; can fail the build on CRITICAL findings.

**Snyk**
A commercial security platform that scans code dependencies, containers, and IaC for vulnerabilities. Has GitHub Actions integration. Provides remediation advice alongside findings.

**CVE (Common Vulnerabilities and Exposures)**
A standardized identifier for publicly known security vulnerabilities. `CVE-2021-44228` is the Log4Shell vulnerability. Security scanners check your dependencies against the CVE database.

**SBOM (Software Bill of Materials)**
A complete inventory of all components, libraries, and dependencies in a software artifact. Like a food label for software. Required by some compliance frameworks and useful for tracking which apps are affected when a new CVE is published.

**Cosign**
A tool for signing and verifying container images using cryptographic signatures. Ensures that the image you pull is exactly the one your pipeline built — prevents supply chain attacks.

**Supply Chain Attack**
An attack that compromises software by targeting the build/delivery pipeline rather than the application itself. Example: injecting malicious code into a dependency or a compromised base image. Image signing, dependency scanning, and OIDC authentication all defend against this.

**OIDC (OpenID Connect) in CI/CD**
A protocol that lets CI/CD systems (GitHub Actions) exchange short-lived cryptographic tokens for cloud credentials instead of storing long-lived secret keys. Eliminates the need for `AWS_SECRET_ACCESS_KEY` in GitHub Secrets.

**Parallel Matrix Build**
A GitHub Actions feature where the same job runs simultaneously with different parameters (e.g., Java 17 AND Java 21 at the same time). Useful for compatibility testing.

**Test Sharding**
Splitting a large test suite across multiple parallel runners. If you have 1000 tests taking 20 minutes, 4-way sharding runs 250 tests per runner simultaneously → ~5 minutes total.

**Fail-Fast**
A pipeline design principle: run the quickest, cheapest checks FIRST. If linting takes 10 seconds and fails, don't waste 10 minutes running integration tests. Stop early, report quickly.

**Concurrency Control (GitHub Actions)**
The `concurrency:` block that cancels in-progress workflow runs when a new commit is pushed to the same branch. Prevents 10 queued builds after a rapid series of commits.

**`act`**
An open-source tool that runs GitHub Actions workflows locally in Docker. Useful for testing workflow YAML changes without committing and pushing to GitHub.

**DORA Metrics**
Four metrics developed by the DevOps Research and Assessment group that measure software delivery performance: Deployment Frequency, Lead Time for Changes, Change Failure Rate, and Mean Time to Restore (MTTR).

**Lead Time for Changes**
DORA metric: the time from when a developer commits code to when that code runs in production. Measures pipeline efficiency. Elite teams achieve less than 1 hour.

**Deployment Frequency**
DORA metric: how often a team successfully deploys to production. Elite teams deploy multiple times per day. Low-performing teams deploy less than once per month.

**Change Failure Rate**
DORA metric: the percentage of deployments that cause a production incident requiring rollback or hotfix. Elite: 0-15%. High rates indicate insufficient testing or risky deployment strategies.

**MTTR (Mean Time to Restore)**
DORA metric: average time to recover from a production failure. Elite: under 1 hour. This is why automated rollback in pipelines matters — it directly reduces MTTR.

**Pushgateway (Prometheus)**
A Prometheus component that accepts metrics pushed from short-lived jobs (like CI/CD pipelines) that can't be scraped. CI pipelines push build duration/status metrics to Pushgateway; Prometheus scrapes it.

**`promtool`**
The Prometheus command-line utility for checking rule syntax, running unit tests on alert rules, and debugging PromQL. Also used to validate recording rules used in SLO-based alerting.

**`yq`**
A command-line YAML processor (like `jq` but for YAML). Used in GitOps pipelines to update image tags in `kustomization.yaml` or `values.yaml` files as part of the automated release process.

**Kustomization.yaml**
The root config file for Kustomize. Defines which base resources to include, which patches to apply, and (crucially for GitOps) which image tags to use. CI pipelines update the `newTag` field here to trigger ArgoCD deployments.
