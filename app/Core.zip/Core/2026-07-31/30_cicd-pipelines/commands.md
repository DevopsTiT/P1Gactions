# CI/CD Pipeline Tuning — Commands Reference

---

## Phase 0 — Inspect Current Pipeline State

```bash
# GitHub CLI — list recent workflow runs
gh run list --repo myorg/myapp --limit 20

# Show details of a specific run
gh run view <run-id> --repo myorg/myapp

# Show failed step logs
gh run view <run-id> --log-failed --repo myorg/myapp

# List all workflows in the repo
gh workflow list --repo myorg/myapp

# Show average duration of a workflow over last 20 runs
gh run list --workflow=ci-cd.yml --limit 20 --json databaseId,conclusion,createdAt,updatedAt \
  | jq '[.[] | {duration: ((.updatedAt | fromdateiso8601) - (.createdAt | fromdateiso8601)), conclusion}]'

# Watch a running workflow live
gh run watch --repo myorg/myapp
```

---

## Phase 1 — Validate Docker Build and Caching Locally

```bash
# Build with BuildKit enabled (required for cache features)
DOCKER_BUILDKIT=1 docker build -t myapp:local .

# Build with detailed cache output
DOCKER_BUILDKIT=1 docker build --progress=plain -t myapp:local . 2>&1 | \
  grep -E "CACHED|RUN|COPY"

# Check image layers and sizes
docker history myapp:local --human --format "table {{.Size}}\t{{.CreatedBy}}"

# Check final image size
docker images myapp:local --format "{{.Size}}"

# Inspect image for secrets accidentally baked in (never do this in prod)
docker run --rm -it myapp:local sh -c "env | sort"

# Multi-platform build (build for both amd64 and arm64)
docker buildx build \
  --platform linux/amd64,linux/arm64 \
  --push \
  -t ghcr.io/myorg/myapp:latest .
```

---

## Phase 2 — Test Pipeline Locally with act

```bash
# Install act (runs GitHub Actions locally)
brew install act

# List all workflows and jobs
act --list

# Run the full CI pipeline locally (dry run first)
act push --dryrun

# Run specific job only
act push --job unit-test

# Run with secrets from a file
act push --secret-file .secrets

# Run with specific runner image
act push -P ubuntu-latest=catthehacker/ubuntu:act-latest

# Check what Docker images act would pull
act push --dryrun 2>&1 | grep "image"
```

---

## Phase 3 — Cache Analysis

```bash
# Check GitHub Actions cache usage
gh api /repos/myorg/myapp/actions/cache/usage

# List all caches
gh api /repos/myorg/myapp/actions/caches | jq '.actions_caches[] | {id, key, size_in_bytes, created_at}'

# Delete a stale cache entry
gh api --method DELETE /repos/myorg/myapp/actions/caches/<cache-id>

# Check Maven local cache size (on runner or locally)
du -sh ~/.m2/repository/

# Check npm cache size
du -sh ~/.npm/

# Check Docker build cache
docker buildx du

# Prune old Docker build cache
docker buildx prune --filter until=24h
```

---

## Phase 4 — Helm Deployment Commands

```bash
# Lint Helm chart before deploy
helm lint ./charts/checkout

# Dry run — see what would be applied without applying
helm upgrade --install checkout ./charts/checkout \
  --namespace production \
  --set image.tag=sha-abc123 \
  --dry-run

# Diff between current and proposed release (requires helm-diff plugin)
helm plugin install https://github.com/databus23/helm-diff
helm diff upgrade checkout ./charts/checkout \
  --namespace production \
  --set image.tag=sha-abc123

# Deploy and wait for pods to be ready
helm upgrade --install checkout ./charts/checkout \
  --namespace production \
  --set image.tag=sha-abc123 \
  --wait \
  --timeout=10m

# Check deploy status
helm status checkout -n production

# List all releases
helm list -n production

# View release history
helm history checkout -n production

# Rollback to previous release
helm rollback checkout -n production

# Rollback to specific revision
helm rollback checkout 3 -n production

# Rollback and wait
helm rollback checkout -n production --wait --timeout=5m
```

---

## Phase 5 — ArgoCD Operations

```bash
# Install ArgoCD CLI
brew install argocd

# Login to ArgoCD
argocd login argocd.internal --username admin --password <password>

# List all applications
argocd app list

# Get application status
argocd app get checkout-production

# Sync application (trigger deployment)
argocd app sync checkout-production

# Sync and wait for healthy
argocd app sync checkout-production --timeout 300

# Force sync (overrides any local changes)
argocd app sync checkout-production --force

# Check sync status
argocd app wait checkout-production --health --timeout=300

# Rollback to previous version
argocd app rollback checkout-production

# Rollback to specific history ID
argocd app history checkout-production
argocd app rollback checkout-production <history-id>

# Pause auto-sync (manual maintenance mode)
argocd app set checkout-production --sync-policy none

# Resume auto-sync
argocd app set checkout-production --sync-policy automated

# Check what ArgoCD would do (diff)
argocd app diff checkout-production
```

---

## Phase 6 — Kubernetes Deployment Verification

```bash
# Watch rollout in real time
kubectl rollout status deployment/checkout -n production --timeout=10m

# Check pod readiness after deploy
kubectl get pods -n production -l app=checkout -w

# Describe a failing pod (check Events section)
kubectl describe pod -n production -l app=checkout | tail -30

# Check pod logs during rollout
kubectl logs -n production -l app=checkout --since=5m --follow

# Verify new image is running
kubectl get deployment checkout -n production \
  -o jsonpath='{.spec.template.spec.containers[0].image}'

# Check rollout history
kubectl rollout history deployment/checkout -n production

# Undo last rollout (emergency rollback)
kubectl rollout undo deployment/checkout -n production

# Undo to specific revision
kubectl rollout undo deployment/checkout -n production --to-revision=3

# Run smoke test against deployed service
kubectl run smoke-test --image=curlimages/curl --restart=Never --rm -it \
  -- curl -f http://checkout.production.svc.cluster.local/health
```

---

## Phase 7 — Security Scanning

```bash
# Scan container image with Trivy
trivy image \
  --severity CRITICAL,HIGH \
  --exit-code 1 \
  ghcr.io/myorg/checkout:latest

# Scan filesystem (for IaC and source code)
trivy fs \
  --severity CRITICAL,HIGH \
  --exit-code 1 \
  .

# Scan Kubernetes manifests
trivy config \
  --severity CRITICAL,HIGH \
  ./k8s/

# Generate SBOM (Software Bill of Materials)
trivy image \
  --format cyclonedx \
  --output sbom.json \
  ghcr.io/myorg/checkout:latest

# Scan with Snyk
snyk container test ghcr.io/myorg/checkout:latest \
  --severity-threshold=high

# Check for secrets accidentally in image
trivy image \
  --scanners secret \
  ghcr.io/myorg/checkout:latest

# Sign image with Cosign (keyless, using OIDC)
cosign sign --yes ghcr.io/myorg/checkout@<image-digest>

# Verify image signature
cosign verify \
  --certificate-identity=https://github.com/myorg/checkout/.github/workflows/ci.yml@refs/heads/main \
  --certificate-oidc-issuer=https://token.actions.githubusercontent.com \
  ghcr.io/myorg/checkout:latest
```

---

## Phase 8 — Pipeline Timing Analysis

```bash
# GitHub CLI — extract job timing for all recent runs
gh run list --workflow=ci-cd.yml --limit 50 --json databaseId,createdAt,updatedAt,conclusion | \
  jq '.[] | {
    id: .databaseId,
    conclusion: .conclusion,
    duration_min: (((.updatedAt | fromdateiso8601) - (.createdAt | fromdateiso8601)) / 60 | floor)
  }'

# Average duration by conclusion
gh run list --workflow=ci-cd.yml --limit 50 --json createdAt,updatedAt,conclusion | \
  jq 'group_by(.conclusion) | map({
    conclusion: .[0].conclusion,
    avg_minutes: ([.[] | ((.updatedAt | fromdateiso8601) - (.createdAt | fromdateiso8601))] | add / length / 60 | floor),
    count: length
  })'

# Identify slowest steps in a specific run
gh run view <run-id> --json jobs | \
  jq '.jobs[].steps | sort_by(.completedAt) | .[] | {name: .name, duration_seconds: ((.completedAt | fromdateiso8601) - (.startedAt | fromdateiso8601))}'
```

---

## Phase 9 — Canary Deployment with Argo Rollouts

```bash
# Install Argo Rollouts kubectl plugin
brew install argoproj/tap/kubectl-argo-rollouts

# Watch canary rollout live
kubectl argo rollouts get rollout checkout -n production --watch

# Manually promote canary to next step
kubectl argo rollouts promote checkout -n production

# Abort canary and rollback to stable
kubectl argo rollouts abort checkout -n production

# Retry a failed rollout
kubectl argo rollouts retry rollout checkout -n production

# Check rollout history
kubectl argo rollouts history rollout checkout -n production

# Set canary weight manually
kubectl argo rollouts set image checkout \
  checkout=ghcr.io/myorg/checkout:sha-new123 \
  -n production
```

---

## Phase 10 — DORA Metrics Calculation

```bash
# Deployment frequency: count successful prod deploys in last 30 days
gh run list \
  --workflow=deploy-production.yml \
  --status=success \
  --limit=100 \
  --json createdAt \
  --jq '[.[] | select(.createdAt > "2026-07-01")] | length'

# Lead time: time from first commit in PR to merge
gh pr list --state=merged --limit=50 --json mergedAt,createdAt,headRefName | \
  jq '[.[] | {
    branch: .headRefName,
    lead_time_hours: ((.mergedAt | fromdateiso8601) - (.createdAt | fromdateiso8601)) / 3600
  }] | sort_by(.lead_time_hours) | reverse | .[0:10]'

# Change failure rate: failed deploys / total deploys
gh run list --workflow=deploy-production.yml --limit=100 \
  --json conclusion | \
  jq '{
    total: length,
    failed: [.[] | select(.conclusion == "failure")] | length,
    failure_rate: ([.[] | select(.conclusion == "failure")] | length) / length * 100
  }'
```

---

## Phase 11 — Kustomize Image Tag Update (GitOps)

```bash
# Install kustomize
brew install kustomize

# Update image tag in kustomization.yaml
cd k8s-configs/apps/checkout/production

kustomize edit set image \
  ghcr.io/myorg/checkout=ghcr.io/myorg/checkout:sha-abc123

# Verify the change
cat kustomization.yaml | grep -A2 images

# Build and preview what would be applied
kustomize build . | kubectl diff -f -

# Apply directly (if not using GitOps)
kustomize build . | kubectl apply -f -

# Use yq to update image tag in values.yaml
yq e -i \
  '.image.tag = "sha-abc123"' \
  helm-values/production/checkout.yaml
```
