# 77 — Dynatrace Log-Based Metric Events: Glossary

Every term from main.md explained for an SRE beginner.

---

**Log-Based Metric Event**
A Dynatrace alert that fires based on patterns found in log lines, not standard performance metrics. You define what text to search for in logs, count how often it appears per minute, and alert when the count crosses a threshold. Faster detection than waiting for infrastructure metrics to reflect a crash.

**Log Metric (Log Monitoring Metric)**
A custom metric in Dynatrace that counts (or measures) log lines matching a specific query, per minute. Created in DT UI under Metrics → Log metrics. You define a filter query using log attributes; DT counts matching lines and stores the result as a metric time series.

**`log.payment.oom` (metric key)**
The custom name you give to a log metric. By convention: `log.<service>.<what>`. This key is referenced in the Metric Event configuration to tell the alert which metric to watch. Must be unique across your DT tenant.

**`matchesValue()`**
A Dynatrace log query function that checks whether a log attribute matches a pattern. Supports `*` wildcards. `matchesValue(log.content, "*OutOfMemoryError*")` matches any log line where the content contains "OutOfMemoryError" anywhere in the string.

**`log.content`**
A Dynatrace log attribute that holds the full text of a log line. This is the primary field you filter on when searching for specific exception names, error messages, or keywords in application logs.

**`k8s.namespace.name`**
A Dynatrace log attribute automatically attached by OneAgent that identifies which Kubernetes namespace the log came from. Used to scope log metrics to a specific service's namespace to avoid false positives from other teams or environments.

**Wildcard (`*`)**
A character that matches any sequence of characters in `matchesValue()`. `*OutOfMemoryError*` matches "java.lang.OutOfMemoryError: Java heap space" because `*` covers the text before and after. Without wildcards, only exact full-string matches work.

**Aggregation = COUNT / OCCURRENCE**
The method used to convert matching log lines into a metric value. COUNT/OCCURRENCE = count how many log lines matched in the evaluation window. This is almost always what you want for log-based alerting. Alternative: ATTRIBUTE (measure a numeric field extracted from the log line).

**Metric Event**
A Dynatrace configuration that watches a metric and creates a Problem when the metric crosses a threshold for N consecutive evaluation cycles. References a metric key (like `log.payment.oom`) and defines threshold, event type, and entity scope.

**`threshold = 1`**
The numeric value the metric must exceed to trigger a violation. For OOM errors: `threshold = 1` means alert on the first occurrence (any single OOM line = immediately alert). Higher thresholds allow more tolerance before alerting.

**`event_type = "ERROR_EVENT"`**
The severity of the Dynatrace Problem created when the alert fires. ERROR_EVENT creates an ERROR severity Problem. Other options: AVAILABILITY_EVENT (highest — service completely down), PERFORMANCE_EVENT (latency-related), INFO_EVENT (informational only). The severity determines which alerting profiles activate.

**`violating_samples`**
How many consecutive 1-minute evaluation windows must exceed the threshold before a Problem is created. `violating_samples = 1` means alert immediately after the first violating minute. `violating_samples = 3` means the threshold must be exceeded for 3 minutes in a row.

**`dealerting_samples`**
How many consecutive 1-minute evaluation windows must show no violation before the Problem closes. `dealerting_samples = 3` means the metric must be clean (below threshold) for 3 minutes in a row. Prevents rapid open/close flapping.

**`samples` (sliding window)**
The total number of recent evaluation windows considered when checking for violations. `samples = 5` means: "look at the last 5 minutes; if `violating_samples` of them exceeded the threshold, create a Problem."

**`alert_condition = "ABOVE"`**
Direction of the threshold check. ABOVE = alert when metric > threshold. BELOW = alert when metric < threshold (used for things like availability dropping below a target).

**`event_entity_dimension_key`**
Tells DT which type of entity to link the Problem to when it fires. `dt.entity.service` = the Problem is linked to a SERVICE entity. This matters because alerting profiles filter by management zone, and management zones contain SERVICE entities. Using the wrong dimension key breaks the alerting profile filter.

**`dt.entity.service`**
The Dynatrace entity dimension key for HTTP service entities. The correct value to use for `event_entity_dimension_key` when monitoring application logs, because services are the entities that management zones track and alerting profiles scope to.

**`entity_filter`**
A filter inside the Metric Event configuration that scopes the alert to a specific service or set of entities. Without it, the metric event would fire for all services in the tenant. Using `conditions { type = "NAME", operator = "EQUALS", value = "payment-service" }` scopes it to just that service.

**`dimension_filter`**
A filter on a metric dimension (like namespace) inside the Metric Event. Used to further narrow which data the metric event evaluates. Example: only evaluate `log.payment.oom` data where `k8s.namespace.name = "payment-ns"`.

**`dynatrace_log_metrics` (Terraform resource)**
The Terraform resource type for creating a Dynatrace log metric. Calls the Dynatrace Settings API to create the log metric definition. The `name` field becomes the metric key used in Metric Events.

**`dynatrace_metric_events` (Terraform resource)**
The Terraform resource type for creating a Dynatrace Metric Event (alert rule). References a metric key and defines threshold, event type, entity scope, and timing parameters.

**`for_each` (Terraform)**
A Terraform meta-argument that creates multiple copies of a resource from a map. Used to create OOM log metrics and metric events for all three services (payment, order, notification) from a single resource block with different values per service.

**Log Monitoring (DynaKube)**
A DynaKube Custom Resource setting that must be enabled for OneAgent to collect and forward stdout logs to the Dynatrace tenant. Without `logMonitoring.enabled = true`, no logs flow to DT and log metrics produce zero counts.

**Log Ingestion Delay**
The time between a log line being written to stdout and it appearing in the Dynatrace tenant. Typically 20–60 seconds for OneAgent-collected logs. This adds to the detection time: OOM happens → ~30s log ingestion → ~60s metric evaluation → alert fires. Total: ~90 seconds.

**OOM (OutOfMemoryError)**
`java.lang.OutOfMemoryError` — thrown by the JVM when it runs out of heap memory. Critical: it typically crashes the pod within seconds of appearing in logs. This is why `violating_samples = 1` is essential — by the time the pod restarts, the window for detection via `pod_restarts` metric may already be over.

**`/proc/1/fd/1`**
The file descriptor for stdout of the main process (PID 1) inside a container. Writing to this path using `kubectl exec` injects a line into the container's stdout log stream, which OneAgent picks up as if the application wrote it. Used for testing the log monitoring pipeline without restarting the real service.

**DT Logs Search API (`/api/v2/logs/search`)**
The Dynatrace REST API endpoint for querying recent log entries. Used to verify that logs are flowing from pods to the DT tenant before relying on log-based metric events. Returns log lines matching a query with their timestamps and content.

**Alerting Profile (Dynatrace)**
A filter that routes DT Problems to notification channels (PagerDuty, Slack). The log metric event creates an ERROR severity Problem → alerting profile checks: is this Problem in the right management zone AND the right severity? If yes → notification fires. The `event_entity_dimension_key = "dt.entity.service"` ensures the Problem is linked to a service that IS in the management zone.

**Problem (Dynatrace)**
A Dynatrace event representing a detected issue. Created automatically by Metric Events when thresholds are crossed. Contains: title, severity, affected entity, start time, related changes, and timeline. The alert that PagerDuty receives is triggered by Problems being created or resolved.

**OneAgent**
Dynatrace's Kubernetes monitoring agent deployed as a DaemonSet. Instruments JVMs, captures logs from container stdout, and sends everything to the ActiveGate → DT tenant. Required for log-based metric events to work — without it, logs don't reach DT.

**`kubectl exec`**
A Kubernetes command that runs a command inside a running pod's container. Used here to inject a test log line to verify the log monitoring pipeline without causing a real OOM condition.

**`jq '.resolution.data[].values'`**
A `jq` filter that extracts the array of metric values from a Dynatrace metrics query API response. Each element is the metric value for one time bucket (e.g., one minute). Used to verify whether the log metric is counting correctly.
