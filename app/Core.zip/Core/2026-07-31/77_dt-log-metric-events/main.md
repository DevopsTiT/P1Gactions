# 77 — Dynatrace Log-Based Metric Events: Setup Deep Dive

> **What this covers:** How to build an alert that fires when a specific string
> (like "OutOfMemoryError") appears in logs — before the pod even restarts.
> Two-step process: create a Log Metric, then create a Metric Event on top of it.

---

## Why Log-Based Metric Events (vs Standard Metrics)

```
Standard metric alert (e.g., error rate):
  Log line with exception → JVM crashes → pod restarts → K8s restarts counter goes up
  → Metric threshold crossed → Alert fires
  Lag: 2–5 minutes after the crash

Log-based metric alert:
  Log line with "OutOfMemoryError" appears → count = 1 → threshold exceeded → Alert fires
  Lag: ~60 seconds (log ingestion + metric evaluation)

Log-based = faster detection + can catch ANY pattern in any log line,
            not just what OneAgent surfaces as a built-in metric
```

---

## The Two-Step Architecture

```
STEP 1 — Log Metric (counts matching log lines per minute)
  DT Log → filter by content + namespace → count() → metric key: log.payment.oom

STEP 2 — Metric Event (alerts when the count exceeds threshold)
  metric key: log.payment.oom → threshold ≥ 1 → ERROR_EVENT → PagerDuty
```

---

## E2E Flow: One OOM Line → PagerDuty

```
[JVM throws OutOfMemoryError]
      │
      ▼
[Log line written to stdout:
 "java.lang.OutOfMemoryError: Java heap space"]
      │
      ▼ (~30s log ingestion delay)
[Dynatrace Log Ingest: log.content = "...OutOfMemoryError..."]
      │
      ▼ (log metric evaluated every 60s)
[Log Metric: matchesValue(log.content,"*OutOfMemoryError*")
             AND matchesValue(k8s.namespace.name,"payment-ns")
             → count = 1]
      │
      ▼ (metric event evaluation: every 60s)
[Metric Event: log.payment.oom ≥ 1 → THRESHOLD MET]
      │
      ▼
[Dynatrace Problem created: ERROR severity]
      │
      ▼
[Alerting Profile: payments-production matches → 0 min delay]
      │
      ▼
[PagerDuty fires → on-call paged]
```

---

## Step 1 — Create the Log Metric (Dynatrace UI)

```
Navigate: Dynatrace UI → Metrics → Log metrics → Create metric

Field          Value                                       Why
─────────────────────────────────────────────────────────────────────────────
Metric name    log.payment.oom                             Unique key used by metric event
                                                          Convention: log.<service>.<what>

Query          matchesValue(log.content,"*OutOfMemoryError*")
               AND matchesValue(k8s.namespace.name,"payment-ns")

               First condition:  log.content contains "OutOfMemoryError" (wildcard * on both sides)
               Second condition: only from pods in namespace "payment-ns"
               AND = both must be true simultaneously

Aggregation    count                                       Count of log lines matching per minute
                                                          (not sum/avg/max — just count occurrences)
```

### Query Syntax Reference

```
matchesValue(log.content, "*OutOfMemoryError*")
  │           │              └─ Pattern: * = any characters (wildcard)
  │           └─ Attribute: the full text content of the log line
  └─ Function: matchesValue = pattern match (supports * wildcards)

matchesValue(k8s.namespace.name, "payment-ns")
  │           │                    └─ Exact namespace name (no wildcard needed)
  │           └─ Attribute: Kubernetes namespace attached by OneAgent
  └─ Function: exact or wildcard match

Other useful log attributes:
  log.content                  full text of the log line
  k8s.namespace.name           kubernetes namespace
  k8s.pod.name                 pod name
  k8s.container.name           container name
  dt.entity.service            the DT service entity
  log.level                    INFO, WARN, ERROR, etc.
  log.source                   log file path or stream name
```

### More Query Examples

```
Alert on any ERROR level log in payment-ns:
  matchesValue(log.level,"ERROR")
  AND matchesValue(k8s.namespace.name,"payment-ns")

Alert on database connection failures:
  matchesValue(log.content,"*Connection refused*")
  AND matchesValue(k8s.namespace.name,"payment-ns")

Alert on specific exception class:
  matchesValue(log.content,"*NullPointerException*")
  AND matchesValue(dt.entity.service,"*payment*")

Alert on HTTP 500 in access logs:
  matchesValue(log.content,"*HTTP/1.1\" 500*")
  AND matchesValue(k8s.namespace.name,"payment-ns")
```

---

## Step 1 (Alternative) — Create Log Metric via Terraform

```hcl
# infra/dynatrace/log-metrics.tf

resource "dynatrace_log_metrics" "payment_oom" {
  name = "log.payment.oom"

  query = <<-EOT
    matchesValue(log.content,"*OutOfMemoryError*")
    AND matchesValue(k8s.namespace.name,"payment-ns")
  EOT

  measure {
    measure          = "OCCURRENCE"   # count of matching lines
    # Alternative: "ATTRIBUTE" to measure a numeric field extracted from logs
  }

  dimensions {
    # Optional: split the metric by service or namespace
    # If omitted, metric is a flat count
    dimension = "k8s.namespace.name"
  }
}
```

### Full parameterized version for multiple services

```hcl
# infra/dynatrace/log-metrics.tf

locals {
  log_metric_definitions = {
    "log.payment.oom" = {
      service_ns  = "payment-ns"
      pattern     = "*OutOfMemoryError*"
    }
    "log.payment.db_conn" = {
      service_ns  = "payment-ns"
      pattern     = "*Connection refused*"
    }
    "log.order.oom" = {
      service_ns  = "orders-ns"
      pattern     = "*OutOfMemoryError*"
    }
    "log.notification.oom" = {
      service_ns  = "notifications-ns"
      pattern     = "*OutOfMemoryError*"
    }
  }
}

resource "dynatrace_log_metrics" "services" {
  for_each = local.log_metric_definitions

  name = each.key

  query = <<-EOT
    matchesValue(log.content,"${each.value.pattern}")
    AND matchesValue(k8s.namespace.name,"${each.value.service_ns}")
  EOT

  measure {
    measure = "OCCURRENCE"
  }
}
```

---

## Step 2 — Create the Metric Event (Dynatrace UI)

```
Navigate: Dynatrace UI → Settings → Anomaly detection → Metric events → Add metric event

Field                  Value                         Why
──────────────────────────────────────────────────────────────────────────────
Summary                OOM detected in payment-service    Shown in DT Problem title
Metric key             log.payment.oom                    References the log metric from Step 1
Aggregation            COUNT                              Match what the log metric produces
Threshold              1                                  Alert on first occurrence (any OOM = problem)
Alert condition        ABOVE                              alert when count ≥ 1
Violating samples      1                                  Alert immediately (1 matching minute)
Dealerting samples     3                                  Close after 3 clean minutes
Event type             ERROR_EVENT                        Creates ERROR severity Problem
                                                          (maps to "high" alerting profile)
Entity dimension key   dt.entity.service                  Links the Problem to the service entity
Entity filter          service.name = "payment-service"   Scope to the right service
```

---

## Step 2 (Alternative) — Create Metric Event via Terraform

```hcl
# infra/dynatrace/metric-events.tf

resource "dynatrace_metric_events" "payment_oom" {
  summary    = "[PRODUCTION] payment-service: OutOfMemoryError detected"
  enabled    = true
  event_type = "ERROR_EVENT"

  query_definition {
    type             = "METRIC_KEY"
    metric_key       = "log.payment.oom"      # from Step 1
    aggregation      = "COUNT"
    query_offset     = 0

    entity_filter {
      conditions {
        type     = "NAME"
        operator = "EQUALS"
        value    = "payment-service"
      }
    }

    dimension_filter {
      filter {
        dimension_key   = "k8s.namespace.name"
        dimension_value = "payment-ns"
      }
    }
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    threshold          = 1           # alert on first occurrence
    alert_condition    = "ABOVE"
    violating_samples  = 1           # immediately (1 evaluation cycle = 1 minute)
    dealerting_samples = 3           # close after 3 consecutive clean minutes
    samples            = 5           # sliding window
  }

  event_entity_dimension_key = "dt.entity.service"
}
```

### Parameterized across all services

```hcl
# infra/dynatrace/metric-events-log.tf

locals {
  log_event_definitions = {
    "payment-service" = {
      metric_key = "log.payment.oom"
      namespace  = "payment-ns"
      summary    = "[PRODUCTION] payment-service: OutOfMemoryError detected"
    }
    "order-service" = {
      metric_key = "log.order.oom"
      namespace  = "orders-ns"
      summary    = "[PRODUCTION] order-service: OutOfMemoryError detected"
    }
    "notification-service" = {
      metric_key = "log.notification.oom"
      namespace  = "notifications-ns"
      summary    = "[PRODUCTION] notification-service: OutOfMemoryError detected"
    }
  }
}

resource "dynatrace_metric_events" "log_oom" {
  for_each = local.log_event_definitions

  summary    = each.value.summary
  enabled    = true
  event_type = "ERROR_EVENT"

  query_definition {
    type        = "METRIC_KEY"
    metric_key  = each.value.metric_key
    aggregation = "COUNT"

    entity_filter {
      conditions {
        type     = "NAME"
        operator = "EQUALS"
        value    = each.key                    # service name
      }
    }

    dimension_filter {
      filter {
        dimension_key   = "k8s.namespace.name"
        dimension_value = each.value.namespace
      }
    }
  }

  model_properties {
    type               = "STATIC_THRESHOLD"
    threshold          = 1
    alert_condition    = "ABOVE"
    violating_samples  = 1
    dealerting_samples = 3
    samples            = 5
  }

  event_entity_dimension_key = "dt.entity.service"
}
```

---

## Threshold Tuning Guide

```
threshold = 1, violating_samples = 1
  → Alert on FIRST OOM, immediately
  → Best for: OOM errors (any OOM = problem, no tolerance)

threshold = 5, violating_samples = 2
  → Alert only if 5+ OOM lines appear in 2 consecutive minutes
  → Best for: noisy logs where some pattern occasionally appears non-critically

threshold = 1, violating_samples = 3
  → Pattern must appear in 3 consecutive 1-minute windows
  → Best for: patterns that occasionally appear without real impact
```

```
dealerting_samples = 3
  → Problem closes only after 3 consecutive clean minutes (count = 0 for 3 mins)
  → Prevents rapid open/close flapping if OOMs appear intermittently
```

---

## Verifying It Works

### Step 1: Confirm log metric is receiving data

```bash
# Query the log metric via DT API to verify it's counting
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=log.payment.oom:count\
&resolution=1m&from=now-10m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.resolution.data[].values'
# If this returns non-null values, the log metric is working
```

### Step 2: Trigger a test log line to verify the pipeline

```bash
# Inject a test log line directly into a payment-service pod
# (confirm the full pipeline works before relying on it in production)
kubectl exec -it \
  $(kubectl get pod -n payment-ns -l app=payment-service -o name | head -1) \
  -n payment-ns -- \
  sh -c 'echo "java.lang.OutOfMemoryError: Java heap space" >> /proc/1/fd/1'

# Then wait 60-90 seconds and check if the metric count rose
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=log.payment.oom:count\
&resolution=1m&from=now-5m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.resolution.data[].values'
# Should show count = 1 in the most recent minute
```

### Step 3: Verify the Metric Event fires

```bash
# Check for open problems related to this metric event
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/problems\
?status=open&from=now-10m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.problems[] | select(.title | contains("OutOfMemory")) | {title, severity, status}'
```

---

## Common Mistakes

```
Mistake 1: Log metric aggregation = SUM or AVG instead of COUNT (OCCURRENCE)
  Effect:   Metric evaluates to null or 0 — metric event never fires
  Fix:      Use measure = "OCCURRENCE" / aggregation = "COUNT"

Mistake 2: Pattern has no wildcards — "OutOfMemoryError" instead of "*OutOfMemoryError*"
  Effect:   Only matches log lines where the ENTIRE content is exactly "OutOfMemoryError"
            Most log lines have timestamps, class names etc. → zero matches
  Fix:      Always wrap patterns in * wildcards: "*OutOfMemoryError*"

Mistake 3: Namespace filter missing
  Effect:   Alert fires for OOM in ANY namespace (staging, dev, other teams)
  Fix:      Always add AND matchesValue(k8s.namespace.name,"payment-ns")

Mistake 4: violating_samples = 3 for OOM alerts
  Effect:   OOM must appear in 3 consecutive minutes — but OOM often crashes the pod
            in < 1 minute, so only 1 minute of logs exists → alert never fires
  Fix:      violating_samples = 1 for OOM (alert on first occurrence)

Mistake 5: event_entity_dimension_key = "dt.entity.process_group_instance" (wrong)
  Effect:   Problem links to a process entity, not the service
            Alerting profiles scoped to management zones (which use SERVICE tags) won't match
  Fix:      event_entity_dimension_key = "dt.entity.service"

Mistake 6: Log metric created but logs are not flowing to DT
  Effect:   Metric always shows 0 even when OOM occurs
  Fix:      Verify OneAgent is running + DynaKube has log monitoring enabled:
              kubectl get pods -n dynatrace -l app.kubernetes.io/name=oneagent
            Also check DynaKube spec: logMonitoring.enabled = true
```

---

## Enabling Log Monitoring in DynaKube (Prerequisite)

For logs to flow to Dynatrace at all, the DynaKube CR must have log monitoring enabled:

```yaml
# gitops/dev/monitoring/dynatrace/dynakube.yaml (relevant section)
spec:
  oneAgent:
    classicFullStack:
      env:
        - name: ONEAGENT_ENABLE_LOG_MONITORING
          value: "true"
  logMonitoring:
    enabled: true
```

Or via Terraform on the DynaKube resource settings:
```hcl
resource "dynatrace_oneagent_features" "log_monitoring" {
  feature = "LOG_MONITORING"
  enabled = true
}
```

Verify logs are flowing:
```bash
# Check DT Logs UI for recent log entries from payment-ns
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/logs/search\
?query=k8s.namespace.name%3A%22payment-ns%22\
&from=now-5m&limit=10" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.results[] | {timestamp: .timestamp, content: .content[0:100]}'
```
