# Part 7 — Root Cause Analysis Techniques: Deep Dive

---

## What RCA Is and Why It Is Hard

Root Cause Analysis is the process of tracing an incident back to the deepest
systemic cause — not just the surface trigger, but the answer to "why was it
possible for this trigger to exist?"

**Why it is hard:**
1. Under time pressure, teams stop at the first plausible cause ("it was a bad deploy")
2. People unconsciously stop asking "why" when the answer would implicate a team process
3. Complex systems have multiple interacting causes — a single root cause may not exist
4. The "root cause" is partly a choice about where to stop asking "why"
5. Human memory is unreliable — timelines get reconstructed incorrectly

Good RCA requires deliberate technique, a blameless culture, and someone willing
to keep asking "why" even when it gets uncomfortable.

---

## Technique 1: The 5 Whys — Full Walkthrough

### The Mechanics

Start from the user-facing symptom. Ask "Why did this happen?" Record the answer.
Then ask "Why did THAT happen?" Continue until you reach a systemic root cause —
typically something in how the organization builds, tests, deploys, or monitors.

**Rule: Stop when the answer is a process or system gap, not another technical fact.**

### Full Example: DB Pool Exhaustion Incident

```
Symptom: Users received 503 errors on checkout for 32 minutes.

WHY 1: Why did users get 503 errors?
  Answer: The payment service exhausted its database connection pool.
  (Technical fact. Not a root cause. Keep going.)

WHY 2: Why did the connection pool exhaust?
  Answer: A database query was taking 8–12 seconds per request, holding
          connections open far longer than normal (baseline: 200ms).
  (Technical fact. Not a root cause. Keep going.)

WHY 3: Why was the database query taking 8–12 seconds?
  Answer: Deploy v2.14.3 introduced an ORM query that performed a full
          sequential scan on the 40M-row orders table because the query
          filtered on user_id, which has no index.
  (Technical fact. Getting closer. Keep going.)

WHY 4: Why did a query without an index reach production?
  Answer: The CI pipeline tests query functional correctness but has no
          performance check. The code review did not identify the missing
          index because the reviewer did not check the EXPLAIN plan.
  (Process gap! This is likely the root cause layer. But dig one more.)

WHY 5: Why does the CI pipeline have no query performance check?
  Answer: The team has never experienced a slow-query-caused incident
          before. Performance testing in CI was not considered a
          requirement when the pipeline was designed two years ago.
  (Organizational/process root cause. Stop here.)

ROOT CAUSE: The engineering process has no mechanism to detect database
query performance regressions before code reaches production.

ROOT CAUSE FIX: Add automated query EXPLAIN plan analysis to the CI
pipeline that fails the build when a query on a large table lacks an index.
```

### When to Stop

```
Stop when the answer is one of:
  - "We didn't have a process for that"
  - "That risk was never considered during system design"
  - "We had no automated check for that"
  - "The monitoring for that didn't exist"
  - "The team was not trained to do that"

These are fixable organizational/process gaps. One level deeper than any of
these typically returns an answer outside the team's control ("the database
vendor's ORM generates inefficient SQL") — at which point you've gone too far.
```

### Branching 5 Whys

Some incidents have multiple independent causal chains. Use a branching tree:

```
Symptom: 503 errors for 32 minutes
      │
      ├─── WHY 1a: Pool exhausted
      │         │
      │         ├─── WHY 2a: Slow query (8s per request)
      │         │         │
      │         │         └─── WHY 3a: Missing index in v2.14.3
      │         │                   │
      │         │                   └─── WHY 4a: No EXPLAIN check in CI ← ROOT CAUSE A
      │         │
      │         └─── WHY 2b: Pool max = 50, too small for peak
      │                   │
      │                   └─── WHY 3b: Pool sized for average load, not peak
      │                             │
      │                             └─── WHY 4b: No pool saturation alert to detect drift ← ROOT CAUSE B
      │
      └─── WHY 1b: Impact affected 100% of users
                │
                └─── WHY 2b: No canary deploy; went to 100% traffic
                          │
                          └─── WHY 3b: Canary deployment not implemented for payment-service ← ROOT CAUSE C
```

Three root causes, three root cause fixes. All must be addressed.

---

## Technique 2: Fishbone (Ishikawa) Diagram — Full Explanation

### What It Is

The Fishbone diagram organizes causes into categories using a visual structure.
The "head" of the fish is the effect (the incident). The "bones" are categories
of causes. The technique prevents the team from fixating on one type of cause
while ignoring others.

### The 6 M Categories (adapted for SRE)

```
PEOPLE          = Human decisions, knowledge gaps, communication failures
PROCESS         = How work is done: deploy process, review process, testing process
TECHNOLOGY      = Software, hardware, infrastructure choices
MEASUREMENTS    = Alerting, monitoring, observability gaps
MATERIALS       = Data, configuration, dependencies (third-party)
ENVIRONMENT     = Traffic patterns, time of day, external events
```

### Full Fishbone for the DB Pool Incident

```
          PEOPLE                    PROCESS
            │                          │
  IC role not assigned         ─── No canary deploy policy
  immediately (3 min delay)   │   No EXPLAIN plan review in code review
  No DB expert on call         ─── Staging dataset unrealistic (500K vs 40M)
            │                          │
            └──────────────────────────┘
                               │
    ════════════════════════[ OUTAGE — 503 errors, 32 min ]════════
                               │
            ┌──────────────────┴──────────────────┐
            │                                     │
    TECHNOLOGY                              MEASUREMENTS
    Missing user_id index                   No pool saturation alert
    Pool max 50 (too small)                 No slow query alert (>500ms)
    ORM generates full scan                 Alert threshold too conservative
                                            (5% error before firing)
    MATERIALS/CONFIG                        ENVIRONMENT
    Deploy went to 100% pods                20% traffic spike at 14:00
    No feature flag for new query           Afternoon peak not load-tested
    Config: DB_POOL_MAX=50 (static)        
```

### When to Use Fishbone vs. 5 Whys

```
Use 5 Whys when:
  - The causal chain is relatively linear
  - You want to trace ONE specific technical failure to its root
  - The incident was straightforward (one trigger, one failure mode)

Use Fishbone when:
  - Multiple contributing factors from different domains
  - A complex SEV1 with many interacting causes
  - You want a team brainstorm to ensure no category of cause is missed
  - You need a visual representation for a presentation or report
```

---

## Technique 3: Timeline Reconstruction — In Depth

The timeline is the factual backbone of the RCA. Without an accurate timeline,
the causal chain you reconstruct is fiction.

### Sources to Use (and their reliability)

```
Source                    Reliability   Notes
─────────────────────────────────────────────────────────────────
Dynatrace metric graphs   HIGH          Machine-generated, precise timestamps
PagerDuty audit log       HIGH          Precise alert + ack + resolve times
Kubernetes event log      HIGH          Event timestamps are reliable
Scribe's Slack thread     HIGH          If scribe posted in real time
Git commit timestamps     HIGH          Immutable
Deployment timestamps     HIGH          From CI/CD system logs
Engineer memory           LOW           Degrades quickly under stress
Reconstructed from logs   MEDIUM        Accurate but may have gaps
```

**The most important timestamp relationship:**

```
Deploy time vs. incident start time:

  Deploy: 13:55:00
  Alert:  14:03:12
  Gap:    8 minutes 12 seconds

  This gap is not suspicious — the bug needed a traffic trigger (afternoon peak).
  The peak started at 14:00:15. The pool exhausted at 14:02:47. The alert fired
  at 14:03:12. This chain is coherent and causal.

  Compare to a deploy that directly crashes the service:
    Deploy: 14:00:00
    Alert:  14:00:45
    Gap:    45 seconds — direct causation, no trigger needed.
```

### The Invisible Portion of the Timeline

Most incident timelines record what the team did. They often miss what the
system did before the team got involved. This invisible portion is crucial.

```
Visible timeline (what team recorded):
  14:03 — Alert fired
  14:05 — IC assigned
  14:08 — Hypothesis formed
  ...

Invisible timeline (reconstructed from system logs):
  13:55 — Deploy v2.14.3 completes
  14:00 — Traffic spike begins
  14:01 — Query latency crosses 2s (silent — no alert)
  14:02 — Query latency crosses 5s (silent — no alert)
  14:02:47 — Pool reaches 100% (silent — no alert)
  14:03:00 — First user-facing 503 errors
  14:03:12 — Alert fires (28-second detection lag after first user impact)
```

Reconstructing the invisible portion reveals where monitoring gaps allowed
the problem to develop silently before the team knew anything was wrong.

---

## Technique 4: Five Whys Anti-Patterns

Knowing what NOT to do is as important as knowing the technique.

### Anti-Pattern 1: Stopping Too Early

```
Symptom: 503 errors

WHY 1: Why did users get 503s?
  → Pool exhausted.

Root cause declared: "Pool exhausted."

Action item: "Increase pool size."

WRONG. This is the trigger, not the root cause. The pool will exhaust
again next time a slow query is deployed. Nothing systemic was fixed.
```

### Anti-Pattern 2: Assigning Blame at Why 2

```
WHY 1: Why did users get 503s? → Pool exhausted.
WHY 2: Why did the pool exhaust? → Bob deployed code with a slow query.

"Root cause: Bob deployed slow code."
Action item: "Bob should be more careful."

WRONG. This is blame masquerading as RCA. "Bob should be more careful"
is not an actionable, systemic fix. Bob was careful — he just didn't have
the tools (EXPLAIN plan check, staging data parity) to catch the issue.
```

### Anti-Pattern 3: Stopping at a Non-Actionable Answer

```
WHY 5: Why was there no query performance check in CI?
  → Because query performance testing is hard to implement.

Action item: "Look into query performance testing."

BETTER: Push through to an actionable answer.
  → "Because we have not yet built it, and no one was assigned to build it."
  Action item: "Assign @DevOps to add EXPLAIN plan check to CI. Due: 2026-09-01."
```

### Anti-Pattern 4: The Why That Goes Nowhere

```
WHY 4: Why did a slow query reach production?
  → Because humans make mistakes.

This is true but useless. "Humans make mistakes" is never a root cause fix.
Every time this answer appears, ask: "What system change would prevent
human error from causing this outcome?" THAT is the root cause fix.
```

---

## Technique 5: Impact Classification for RCA Priority

Not all incidents deserve the same depth of RCA. Use this matrix to decide
how deep to go:

```
                    │  LOW user impact  │  HIGH user impact
────────────────────┼───────────────────┼────────────────────
LIKELY TO RECUR     │  MEDIUM depth     │  MAXIMUM depth
                    │  5 Whys           │  5 Whys + Fishbone
                    │  2–3 action items │  Full postmortem
────────────────────┼───────────────────┼────────────────────
UNLIKELY TO RECUR   │  LIGHT depth      │  STANDARD depth
                    │  Timeline only    │  5 Whys
                    │  1 action item    │  3–5 action items
```

**"Likely to recur"** = the root cause is a systemic gap that exists in your
current codebase/process right now. If nothing changes, a similar incident
will happen again within 6 months.

**"Unlikely to recur"** = caused by a one-time event (external service went down,
hardware failure, cosmic ray — just kidding, but genuinely rare events).
