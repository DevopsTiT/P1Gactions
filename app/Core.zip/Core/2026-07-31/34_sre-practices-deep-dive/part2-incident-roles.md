# Part 2 — Incident Roles: Deep Dive

---

## Why Roles Exist

When a production system is on fire, the most dangerous thing is ambiguity.
If nobody is clearly "in charge," this happens:

```
Three engineers all jump into the DB at the same time.
Each makes a different change.
Nobody knows what the current state is.
Someone restarts the service before someone else's change is verified.
Communication to stakeholders is contradictory.
The incident takes 2 hours instead of 30 minutes.
```

Roles eliminate ambiguity. Each role has **one owner**, **one job**, and **clear boundaries**.
The moment an incident is declared, the first action is always: **assign the IC**.

---

## The Four Core Roles

### Role 1: Incident Commander (IC)

**The single most important role. Everything flows through the IC.**

The IC does NOT debug. The IC does NOT write code. The IC does NOT fix things.
The IC **drives the process** so that the people who ARE debugging can focus entirely
on the technical problem.

```
IC Responsibilities:
  ├── Declare the incident and set severity
  ├── Open the war room (Slack channel + video bridge)
  ├── Assign TL and CL and Scribe
  ├── Keep the bridge focused — silence side conversations
  ├── Make go/no-go decisions on proposed fixes
  │     "TL proposes rolling back. IC says: approved, do it."
  ├── Decide when to escalate (bring in SMEs)
  ├── Decide when the incident is resolved
  ├── Hand off the IC role if the incident runs long
  └── Ensure postmortem is scheduled before closing
```

**What the IC does NOT do:**
- Write code or run kubectl commands
- Debug individually in a corner
- Send stakeholder updates (CL does that)
- Take notes (Scribe does that)

**The IC's superpower:** Because the IC isn't debugging, they maintain the 10,000-foot view.
They notice when the team has been stuck on one hypothesis for 20 minutes and calls it:
> "We've been on the DB theory for 20 minutes with no progress. Let's pivot.
>  TL — pivot to checking the deploy. What changed in the last 2 hours?"

**IC authority:**
The IC has the authority to make unilateral decisions to restore service faster:
- Roll back a deploy without waiting for the original developer
- Bring in engineers from other teams
- Scale down a feature to protect core functionality
- Declare a major incident and escalate to leadership

---

### Role 2: Technical Lead (TL)

**The primary debugger. One person only.**

The TL is the engineer with the deepest relevant knowledge of the system being investigated.
They own the technical investigation end-to-end during the incident.

```
TL Responsibilities:
  ├── Investigate root cause using RED/USE methods
  ├── Form hypotheses and test them
  ├── Report findings to the IC in plain language
  │     "IC: confirmed — DB pool at 100%, slow query causing it"
  ├── Propose mitigations to the IC
  │     "IC: recommend rollback. Can do it in 2 minutes."
  ├── Execute approved mitigations
  ├── Verify that mitigations worked (watch metrics)
  └── Request SMEs from IC when hitting limits of knowledge
```

**Critical rule: ONE TL at a time.**

If two engineers are both running kubectl commands and changing configs simultaneously,
the system is in an unknown state. It becomes impossible to know which change helped
or hurt. The IC enforces: one TL, one set of hands on the system.

**Handoff protocol:**
If the incident is long and the TL needs a break, handoff must be explicit:
```
TL @alice: "Handing off to TL @bob. Current state: DB pool was exhausted,
increased to 100, still seeing 2% error rate. Hypothesis: something else
is wrong. Bob, take the wheel."
```

---

### Role 3: Communications Lead (CL)

**The voice of the incident to the outside world.**

The CL protects the IC and TL from communication interruptions.
Without a dedicated CL, the TL gets pinged by 10 different Slack threads asking
"what's going on?" and loses focus every 3 minutes.

```
CL Responsibilities:
  ├── Write stakeholder updates on the defined cadence (every 30 min for SEV2)
  ├── Post to the status page
  ├── Draft internal Slack updates for the company (if major incident)
  ├── Respond to questions in the incident channel so IC/TL aren't interrupted
  ├── Escalate communication to execs if SEV1 and leadership isn't looped in
  └── Write the final "all clear" message when incident resolves
```

**What good CL communication looks like:**

```
[UPDATE 1 — 14:15 UTC]
We are investigating elevated error rates in the payment service.
Approximately 5% of checkout attempts are failing.
Root cause: under investigation.
Our team is actively working on this.
Next update: 14:45 UTC.

[UPDATE 2 — 14:30 UTC]
Root cause identified: database connection pool exhaustion.
Mitigation in progress (increasing pool size).
Expected resolution: within 15 minutes.
Next update: 14:45 UTC or sooner if resolved.

[RESOLVED — 14:38 UTC]
Payment service has been restored. Error rate is now 0%.
Total impact: ~5% of checkout attempts failed between 14:03–14:35 UTC.
A full postmortem will be published within 72 hours.
```

**Why honest, timely updates matter:**
Users and internal stakeholders will tolerate a long incident if they know
someone is aware and working on it. The damage multiplies when stakeholders
find out about an outage by hearing from *their* customers, not from you.

---

### Role 4: Scribe

**The historian of the incident.**

The Scribe writes down everything that happens, with timestamps.
This is not glamorous, but it is irreplaceable.

```
Scribe Responsibilities:
  ├── Log every action with timestamp in the Slack timeline thread
  ├── Record every hypothesis formed ("14:08 — hypothesis: DB pool exhausted")
  ├── Record every command run and its outcome
  ├── Record every decision made ("14:10 — IC decided not to rollback yet")
  ├── Record when people join and leave the bridge
  └── Export the timeline to the postmortem doc after resolution
```

**What a Scribe log looks like:**

```
14:03 UTC  PagerDuty alert fired: payment-service error rate > 5%
14:05 UTC  IC: @alice. TL: @bob. CL: @carol. Scribe: @david.
14:06 UTC  Bridge opened: #incident-2026-0731-001
14:07 UTC  TL checking Dynatrace: error rate 7%, p99 latency 12s (normally 200ms)
14:08 UTC  Hypothesis 1: DB connection pool exhausted
14:09 UTC  TL running: kubectl get pods -n production -l app=payment-service
14:10 UTC  TL confirmed: all pods running, no restarts
14:11 UTC  TL checking DB metrics in Dynatrace
14:12 UTC  CONFIRMED: DB pool at 100%, 80 queries queuing
14:13 UTC  TL identified slow query in v2.14.3 ORM change (missing user_id index)
14:14 UTC  TL proposes: increase pool size 50→100, rolling restart
14:14 UTC  IC approved mitigation
14:15 UTC  TL running: kubectl set env deployment/payment-service DB_POOL_MAX=100
14:16 UTC  Rolling restart in progress
14:19 UTC  Restart complete. Error rate: 30% → 12%
14:22 UTC  Error rate: 5% → 1%
14:25 UTC  Error rate: 0%. Latency p99: 180ms (normal).
14:35 UTC  Monitored 10 min — stable. IC declared resolved.
```

Without this log, the postmortem author must reconstruct the timeline from
memory at 2 AM after a 2-hour incident. Reconstructed timelines are inaccurate.

---

### Role 5: Subject Matter Expert (SME)

**Called in as needed. One SME per domain at a time.**

SMEs are engineers with specialized knowledge called in when the TL hits the limits of their expertise.

```
Examples:
  - Database administrator called in when the DB query behavior is unexpected
  - Network engineer called in for routing/firewall issues
  - Security engineer called in when breach is suspected
  - Payment vendor support called in for third-party API behavior
```

**IC manages SME involvement:**
> "TL, you've been on the DB angle for 20 minutes. IC calling in @sarah (DB expert).
>  Sarah — Bob will brief you. You have the DB investigation. Bob, pivot to app logs."

**Why ONE SME per domain at a time:**
Two DB experts arguing about the correct fix in the bridge creates noise.
One person investigates, proposes, IC approves.

---

## Role Assignment Anti-Patterns

```
❌ Anti-pattern 1: The Solo Hero
   One engineer tries to be IC + TL + CL + Scribe simultaneously.
   Result: nothing gets communicated, debugging is chaotic, incident takes 3× longer.

❌ Anti-pattern 2: Committee Debugging
   Five engineers all running commands at the same time.
   Result: unknown system state, changes conflict, nobody knows what worked.

❌ Anti-pattern 3: The Missing IC
   "Everyone just jump in and fix it" — no IC declared.
   Result: no one is driving, team goes in circles, escalation never happens.

❌ Anti-pattern 4: IC Debugging
   IC starts running kubectl commands because they know the system well.
   Result: no one is watching the clock, no one is making go/no-go calls,
   comms fall apart.

❌ Anti-pattern 5: Roles Without Authority
   IC exists but nobody listens — TL ignores IC's "stop, pivot" call.
   Result: role structure is theater, not functional.
   Fix: IC authority must be culturally enforced and trained.
```

---

## Role Handoff: Long Incidents

For incidents lasting more than 2 hours, IC and TL burn out. Explicit handoff is mandatory.

```
IC handoff protocol:
  1. Outgoing IC summarizes current state in the Slack channel:
     "IC handoff to @frank. Current situation: service partially restored
      (2% error rate), investigating secondary cause in message queue.
      Outstanding: need to verify queue depth is draining."
  2. Incoming IC acknowledges:
     "@frank taking IC. Confirmed: continuing queue investigation."
  3. Outgoing IC leaves the bridge (or goes silent).

Same protocol for TL handoff.
```

Without explicit handoff, both people think the other is driving.
For 10 minutes, nobody is driving.

---

## Rotation: Who Learns Each Role

Every SRE should be capable of filling any role. Rotate role assignments across incidents so nobody is permanently the scribe and nobody is permanently the IC. Training tracks:

```
Junior SRE     → Start as Scribe. Observe how incidents run.
Mid SRE        → TL on SEV3/4. IC on SEV3 with coaching.
Senior SRE     → IC on SEV1/2. Coach juniors on TL.
Staff SRE      → Design and improve the incident management process itself.
```
