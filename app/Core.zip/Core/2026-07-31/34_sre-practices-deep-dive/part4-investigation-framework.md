# Part 4 — Investigation Framework: RED, USE, and Hypothesis Testing

---

## The Trap: Random-Walk Debugging

Under pressure, engineers do this:
```
"Let me check the logs... hmm, now let me check the DB... 
 actually let me restart the service... wait let me look at 
 Kubernetes events... maybe it's a network issue..."
```

This is random-walk debugging. It feels like action but produces no signal.
An incident where the TL is random-walking is an incident that will take 10×
longer than it needs to. The IC's job is to notice this and call it:
> "TL, you've been jumping around for 10 minutes. Stop.
>  State your current hypothesis. What are you testing right now?"

Structured investigation frameworks replace random walking with a repeatable,
fast path to root cause.

---

## Framework 1: RED Method (for services and APIs)

**When to use:** When an HTTP service, microservice, or API is the thing that is broken.

**The three questions:**

```
R — Rate
   What is the current request rate?
   Is it HIGHER than normal? (traffic spike causing overload)
   Is it LOWER than normal? (something upstream is broken, traffic not arriving)
   Is it ZERO? (complete routing failure, or no traffic being sent)

E — Errors
   What is the current error rate?
   Which HTTP status codes? (503 = server overloaded/unavailable, 500 = app crash,
                             504 = timeout, 429 = rate limited)
   Which endpoints are erroring? (all endpoints, or just one specific path?)
   Are errors random, or ALL requests to one endpoint failing?

D — Duration (latency)
   What is the current latency?
   Check p50 (typical request), p95 (slow requests), p99 (very slow requests)
   Is p50 normal but p99 elevated? → slow for some requests, not all
   Is everything slow? → systemic resource contention
   Is latency EXACTLY at a timeout value (e.g., exactly 30 seconds)?
       → something is timing out at a downstream call
```

**What RED tells you:**

```
High rate + high errors → the service is being overwhelmed by traffic
Normal rate + high errors → the service has a bug or a dependency is broken
Low/zero rate + no errors → traffic isn't reaching the service (routing issue)
Normal rate + high latency → a downstream dependency (DB, external API) is slow
Zero errors but high latency → not user-impacting yet but will be soon
```

**How to check RED in Dynatrace:**

```
Dynatrace → Services → [your service] → Overview
  → Request rate graph (last 30 min vs. last week same time)
  → Failure rate graph
  → Response time graph (p50, p95, p99)
```

---

## Framework 2: USE Method (for infrastructure)

**When to use:** When you suspect the problem is in the underlying infrastructure —
hosts, containers, databases, network — rather than in the application code itself.

**The three questions:**

```
U — Utilization
   For each resource, what % of its capacity is being used?
   
   CPU:     kubectl top pods / Dynatrace host CPU
            → > 80% sustained = likely cause of slowness
   Memory:  kubectl top pods
            → > 90% = risk of OOM kill (container crashes)
   Disk:    df -h on host
            → > 85% = writes may start failing
   Network: iftop / Dynatrace network
            → Sustained > 80% of NIC capacity = packet loss

S — Saturation
   Is any resource unable to handle more work and has started QUEUING?
   This is different from utilization — a resource at 60% utilization can
   still be saturated if its queue is full.
   
   DB connection pool: pool at 100% = new connections queuing
   Thread pool:        all threads busy = new requests queuing
   CPU run queue:      load average > # of cores = processes waiting for CPU
   Network send buffer: TX queue depth > 0 sustained = network saturated
   Disk I/O queue:     await time > 20ms = disk saturated

E — Errors
   Are there errors at the resource level (not application errors)?
   
   OOM kills:         kubectl get events | grep OOM
   Disk I/O errors:   dmesg | grep -i "i/o error"
   Network drops:     netstat -s | grep "segments retransmitted"
   Kernel errors:     dmesg | tail -50
```

**What USE tells you:**

```
High CPU utilization → service running too slowly, or inefficient code
High memory + OOM events → memory leak, or under-provisioned containers
DB pool saturated → slow queries holding connections, or traffic spike
Disk nearly full → writes about to fail; logs growing too fast
Network saturated → large data transfers, DDoS, or noisy neighbor
```

---

## Framework 3: Hypothesis → Test → Confirm

This is the core scientific method applied to incident investigation.
It prevents random-walking by requiring you to **state a hypothesis before taking any action**.

### The Loop

```
Step 1: FORM HYPOTHESIS
  Based on RED/USE findings, make a specific, testable claim.
  
  GOOD hypothesis: "The DB connection pool is exhausted because a slow query
                    introduced in today's deploy is holding connections for 8+s."
  
  BAD hypothesis:  "Something is wrong with the database."
                   (Too vague — cannot be tested or refuted)

Step 2: IDENTIFY EVIDENCE
  Before running any commands, identify what evidence would confirm or refute
  the hypothesis.
  
  "If this hypothesis is correct, I expect to see:
   - DB connection pool at or near 100%
   - Query latency significantly above baseline
   - Slow queries correlating with the new ORM code in v2.14.3"

Step 3: COLLECT EVIDENCE
  Now run the commands to check. Do not change anything yet.
  
  kubectl exec ... -- env | grep DB_POOL
  Check Dynatrace DB metrics
  Check slow query log

Step 4: CONFIRM OR REFUTE
  
  CONFIRMED: "Pool is at 100%. Query latency 8s (baseline 200ms).
              Slow query matches new ORM code. Hypothesis confirmed."
  
  REFUTED:   "Pool is at 30%. Latency is normal for DB queries.
              DB is not the issue. Hypothesis refuted.
              Forming new hypothesis: app-level bug, not DB."

Step 5: MITIGATE (only after confirmation)
  Propose a targeted fix to the IC. Do not execute without IC approval.
  
  "IC: propose increasing pool size 50→100 and rolling restart.
   This is reversible. ETA 3 minutes."

Step 6: VERIFY MITIGATION WORKED
  After applying the fix, actively verify with metrics — do not assume.
  
  "Error rate is now 0%. Latency p99 back to 180ms. Pool at 60%.
   Monitoring for 10 minutes to confirm stability."
```

---

## Framework 4: Change Correlation

**The most powerful first question in any incident:**

> "What changed in the last 2 hours?"

80% of production incidents are caused by a recent change:
a deployment, a config change, a database migration, a traffic pattern shift,
a certificate rotation, a third-party API change.

**Sources to check (in order of probability):**

```
1. Deployments
   kubectl rollout history deployment/<service> -n production
   → Check if any deployment happened in the last 2 hours
   → Check the time gap: deployment at 13:55, incident at 14:03 = likely causal

2. Kubernetes config changes
   kubectl get events -n production --sort-by=.metadata.creationTimestamp | tail -30
   → ConfigMap changes, secret rotations, HPA limit changes

3. Infrastructure changes (Terraform)
   git log --oneline infra/ --since="2 hours ago"
   → Database parameter changes, network policy changes, scaling policy changes

4. Feature flags
   Check your feature flag system (LaunchDarkly / Unleash)
   → Did a feature flag get toggled in the last 2 hours?

5. External dependencies
   → Did a third-party API (payment processor, auth provider) have an outage?
   → Check their status page
   → Check Dynatrace external call latency

6. Traffic patterns
   → Is today a scheduled event (product launch, sale, marketing campaign)?
   → Is there an unusual traffic spike from a specific region?
```

**The correlation heuristic:**

```
Time between change and incident:
  < 5 minutes   → Change is almost certainly the cause. Rollback as first mitigation.
  5–30 minutes  → Change is likely the cause. Check traffic levels (may need a trigger).
  30–120 min    → Change may be the cause, combined with a traffic trigger.
  > 2 hours     → Change is less likely causal. Look at infrastructure drift or data growth.
```

---

## Framework 5: Divide and Conquer (for distributed systems)

When a request flows through multiple services (A → B → C → DB), the failure
can be at any layer. Divide and conquer finds it systematically.

```
User → [Frontend] → [API Gateway] → [Payment Service] → [DB]
            ↓               ↓                ↓              ↓
       Is it up?      Is it healthy?   Is it healthy?   Is it healthy?

Start from the user-facing symptom and work INWARD:

1. Check the outermost service (the one the user hits directly).
   "Is the payment-service returning errors, or is the API gateway itself broken?"

2. If the outermost service is the symptom, check its downstream dependencies.
   "Payment-service is erroring. Is it the DB, or is it the auth service it calls?"

3. Continue inward until you find the first healthy service.
   The unhealthy service just downstream of that is the root layer.
```

**Practical example:**

```
Alert: payment-service 503 errors

Check payment-service: ERROR RATE 7% → unhealthy
  └── Check payment-service → DB calls: LATENCY 8s → unhealthy
        └── Check DB health: CPU 95%, connection pool 100% → unhealthy
              └── Check DB queries: slow query 8s full table scan → ROOT LAYER FOUND

The DB is the root layer. Fix: address the slow query / connection pool.
```

---

## Common Investigation Mistakes

```
Mistake 1: Changing things before confirming the hypothesis
  "Let me just restart the pods, maybe that helps"
  Risk: Masks the problem, makes it harder to find real cause,
        may cause a second incident if restart causes data loss.

Mistake 2: Checking only the alerting service, ignoring dependencies
  "Payment service is broken" → only checks payment-service metrics
  Reality: Payment-service is fine; the auth-service it calls is broken.

Mistake 3: Ignoring the time correlation with changes
  Spending 40 minutes investigating when the answer is "just rollback v2.14.3"

Mistake 4: Declaring resolution before verifying
  "I increased the pool size, should be fixed"
  → Incident reopens 10 minutes later because the slow query is still there.
  Rule: always watch metrics for 10 minutes minimum after mitigation.

Mistake 5: Hypothesis shopping
  Confirming a hypothesis you want to be true, ignoring refuting evidence.
  "The DB utilization is only at 50%, but I still think it's a DB issue..."
  Fix: If the evidence refutes the hypothesis, abandon it immediately.
```
