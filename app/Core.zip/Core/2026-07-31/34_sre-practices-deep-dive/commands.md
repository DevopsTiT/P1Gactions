# 34 — SRE Practices Deep Dive: Commands Reference

All commands from all 12 parts, organized by phase.

---

## Phase 0 — Incident Declaration: First 3 Minutes

```bash
# Confirm what recently changed (always check this first)
kubectl rollout history deployment/payment-service -n production

# Check recent Kubernetes events (sort by newest)
kubectl get events -n production --sort-by=.metadata.creationTimestamp | tail -30

# Check pod status — any crashes or restarts?
kubectl get pods -n production -l app=payment-service

# Check resource usage — any memory/CPU pressure?
kubectl top pods -n production -l app=payment-service

# Quick git log — any recent merges to main?
git log --oneline --since="2 hours ago" origin/main
```

---

## Phase 1 — RED Method (Service Investigation)

```bash
# Count errors in last 5 minutes
kubectl logs -n production -l app=payment-service --since=5m \
  | grep -cE "ERROR|500|503|504"

# Count successful responses (to calculate rate manually)
kubectl logs -n production -l app=payment-service --since=5m \
  | grep -c "200 OK"

# Check current error rate via Dynatrace API
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=ext:app.payment.error.rate&resolution=1m&from=now-10m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.resolution.data[].values'

# Check p99 latency via Dynatrace API
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=ext:app.payment.latency.p99&resolution=1m&from=now-10m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.resolution.data[].values'

# Check request rate vs baseline (compare to same window last week)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=ext:app.payment.requests.rate&resolution=1m&from=now-10m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.resolution.data[].values'
```

---

## Phase 2 — USE Method (Infrastructure Investigation)

```bash
# CPU and memory usage for all payment-service pods
kubectl top pods -n production -l app=payment-service

# Check for OOM kills in the last hour
kubectl get events -n production --field-selector reason=OOMKilling

# Check current DB pool config
kubectl exec -it \
  $(kubectl get pod -n production -l app=payment-service -o name | head -1) \
  -n production -- env | grep -iE "db_pool|pool_max|pool_min|pool_size"

# Check active TCP connections from a pod
kubectl exec -it \
  $(kubectl get pod -n production -l app=payment-service -o name | head -1) \
  -n production -- ss -s

# Check disk usage on nodes
kubectl get nodes -o wide
kubectl describe nodes | grep -A 3 "Allocatable:"

# Check HPA status (is autoscaler trying to scale but can't?)
kubectl get hpa -n production
kubectl describe hpa payment-service -n production
```

---

## Phase 3 — Change Correlation

```bash
# Full deployment history for the service
kubectl rollout history deployment/payment-service -n production

# Precise timestamp of the most recent deployment
kubectl get deployment payment-service -n production \
  -o jsonpath='{.metadata.annotations.deployment\.kubernetes\.io/revision}'

# What changed in that deployment vs. the previous one
kubectl diff -f infra/payment-service/deployment.yaml 2>/dev/null

# Recent git commits that touched the service
git log --oneline --since="3 hours ago" -- services/payment-service/

# Recent Terraform applies (from CI/CD logs — or check infra git log)
git log --oneline --since="3 hours ago" infra/

# Check feature flag changes (if using LaunchDarkly CLI)
# ld changes --since "2 hours ago" --project payment
```

---

## Phase 4 — Mitigation Actions

```bash
# OPTION A: Rollback to previous deployment version
kubectl rollout undo deployment/payment-service -n production
kubectl rollout status deployment/payment-service -n production

# OPTION B: Increase DB connection pool size (rolling restart)
kubectl set env deployment/payment-service -n production DB_POOL_MAX=100
kubectl rollout status deployment/payment-service -n production

# OPTION C: Scale up replicas (spread load)
kubectl scale deployment/payment-service -n production --replicas=10
kubectl get pods -n production -l app=payment-service

# OPTION D: Restart all pods (clears in-memory state)
kubectl rollout restart deployment/payment-service -n production
kubectl rollout status deployment/payment-service -n production

# OPTION E: Cordon a bad node (stop new pods landing on it)
kubectl cordon <node-name>
kubectl get pods -n production -o wide | grep <node-name>   # see existing pods on node

# OPTION F: Drain a node (move all pods off it gracefully)
kubectl drain <node-name> --ignore-daemonsets --delete-emptydir-data
```

---

## Phase 5 — Verify Mitigation (Watch for 10–15 Minutes)

```bash
# Watch pod state in real time
watch -n 5 "kubectl get pods -n production -l app=payment-service"

# Tail logs for remaining errors
kubectl logs -n production -l app=payment-service -f --since=2m \
  | grep -vE "200 OK|INFO"

# Check rollout is stable
kubectl rollout status deployment/payment-service -n production

# Verify pool config was applied to all pods
kubectl get pods -n production -l app=payment-service -o name | while read pod; do
  echo -n "$pod: "
  kubectl exec -it "$pod" -n production -- env 2>/dev/null | grep DB_POOL_MAX
done

# Check error rate trend (run every 60s for 10 min)
watch -n 60 "curl -s 'https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=ext:app.payment.error.rate&resolution=1m&from=now-2m' \
  -H 'Authorization: Api-Token $DT_API_TOKEN' | jq '.resolution.data[].values'"
```

---

## Phase 6 — Post-Incident Evidence Collection

```bash
# Export logs from the incident window to a file
kubectl logs -n production -l app=payment-service \
  --since-time="2026-07-31T13:55:00Z" \
  > /tmp/incident-2026-0731-logs.txt 2>&1

# Export Kubernetes events from incident window
kubectl get events -n production \
  --sort-by=.metadata.creationTimestamp \
  -o json | jq --arg since "2026-07-31T13:50:00Z" \
  '.items[] | select(.metadata.creationTimestamp > $since)' \
  > /tmp/incident-2026-0731-events.json

# Get the exact diff of the bad deploy
git show v2.14.3 --stat
git diff v2.14.2 v2.14.3 -- services/payment-service/

# Get current deployment YAML for the record
kubectl get deployment payment-service -n production \
  -o yaml > /tmp/payment-service-deploy-2026-0731.yaml

# Get PagerDuty incident details
curl -s "https://api.pagerduty.com/incidents?since=2026-07-31T13:00:00Z&limit=10" \
  -H "Authorization: Token token=$PD_API_TOKEN" \
  | jq '.incidents[] | {id, title, created_at, resolved_at, urgency}'
```

---

## Phase 7 — Postmortem and Action Item Management

```bash
# Create P1 Jira action item via API
curl -X POST "https://your-org.atlassian.net/rest/api/3/issue" \
  -H "Authorization: Basic $(echo -n 'user@example.com:'"$JIRA_TOKEN" | base64)" \
  -H "Content-Type: application/json" \
  -d '{
    "fields": {
      "project": { "key": "SRE" },
      "summary": "Add DB connection pool saturation alert (PA-101)",
      "issuetype": { "name": "Task" },
      "priority": { "name": "High" },
      "labels": ["postmortem-action", "incident-2026-0731-001"],
      "duedate": "2026-08-07",
      "assignee": { "accountId": "BOB_JIRA_ACCOUNT_ID" }
    }
  }' | jq '{key: .key, url: (.self | split("/rest")[0] + "/browse/" + .key)}'

# Query all open postmortem action items
curl -s "https://your-org.atlassian.net/rest/api/3/search\
?jql=labels%3Dpostmortem-action+AND+status%21%3DDone+ORDER+BY+priority+ASC\
&maxResults=50&fields=summary,priority,duedate,assignee,status" \
  -H "Authorization: Basic $(echo -n 'user@example.com:'"$JIRA_TOKEN" | base64)" \
  | jq '.issues[] | {
      key: .key,
      summary: .fields.summary,
      priority: .fields.priority.name,
      due: .fields.duedate,
      assignee: .fields.assignee.displayName,
      status: .fields.status.name
    }'

# Find overdue P1 action items
curl -s "https://your-org.atlassian.net/rest/api/3/search\
?jql=labels%3Dpostmortem-action+AND+priority%3DHigh+AND+duedate+%3C+now()+AND+status%21%3DDone" \
  -H "Authorization: Basic $(echo -n 'user@example.com:'"$JIRA_TOKEN" | base64)" \
  | jq '.total'
```

---

## Phase 8 — SLO and Error Budget

```bash
# Get all SLO status from Dynatrace
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/slo?from=now-30d&pageSize=50" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.slo[] | {
      name,
      status,
      evaluatedPercentage,
      target,
      errorBudgetBurnRate: (.evaluatedPercentage - .target),
      budgetConsumedPercent: (((.target - .evaluatedPercentage) / (100 - .target)) * 100 | floor)
    }'

# Calculate error budget consumed by a specific incident
# 32-minute incident on 99.9% SLO over 30 days
python3 -c "
slo_target = 99.9
window_minutes = 30 * 24 * 60
budget_minutes = window_minutes * (1 - slo_target/100)
incident_minutes = 32
consumed_pct = incident_minutes / budget_minutes * 100
remaining_minutes = budget_minutes - incident_minutes
print(f'Error budget (total): {budget_minutes:.1f} minutes')
print(f'Incident consumed:    {incident_minutes} minutes ({consumed_pct:.1f}%)')
print(f'Budget remaining:     {remaining_minutes:.1f} minutes')
"

# Check burn rate over last 1 hour
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=ext:app.payment.error.rate&resolution=1m&from=now-1h" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '[.resolution.data[].values[]] | add/length'
```

---

## Phase 9 — Toil Measurement

```bash
# Count pages per on-call engineer (last 30 days via PagerDuty API)
curl -s "https://api.pagerduty.com/incidents\
?since=$(date -v-30d +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date -d '30 days ago' +%Y-%m-%dT%H:%M:%SZ)\
&until=$(date +%Y-%m-%dT%H:%M:%SZ)&limit=100&statuses[]=resolved" \
  -H "Authorization: Token token=$PD_API_TOKEN" \
  | jq '[.incidents[].assignments[].assignee.summary] \
    | group_by(.) \
    | map({person: .[0], pages: length}) \
    | sort_by(-.pages)'

# Calculate MTTA (mean time to acknowledge) over last 30 days
curl -s "https://api.pagerduty.com/incidents\
?since=2026-07-01T00:00:00Z&limit=100&statuses[]=resolved" \
  -H "Authorization: Token token=$PD_API_TOKEN" \
  | jq '[.incidents[]
    | select(.acknowledged_at != null)
    | ((.acknowledged_at | fromdateiso8601) - (.created_at | fromdateiso8601))]
    | (add/length/60) | "MTTA: \(. | round) minutes"'

# Calculate MTTR (mean time to resolve) over last 30 days
curl -s "https://api.pagerduty.com/incidents\
?since=2026-07-01T00:00:00Z&limit=100&statuses[]=resolved" \
  -H "Authorization: Token token=$PD_API_TOKEN" \
  | jq '[.incidents[]
    | ((.resolved_at | fromdateiso8601) - (.created_at | fromdateiso8601))]
    | (add/length/60) | "MTTR: \(. | round) minutes"'
```

---

## Phase 10 — Chaos Engineering

```bash
# Install LitmusChaos operator
kubectl apply -f https://litmuschaos.github.io/litmus/litmus-operator-v3.0.0.yaml
kubectl get pods -n litmus --watch

# Run pod-delete experiment
kubectl apply -f chaos/pod-delete-payment-service.yaml

# Watch experiment progress
kubectl get chaosengine -n production payment-pod-delete -w

# Get experiment results
kubectl get chaosresult -n production payment-pod-delete-pod-delete \
  -o json | jq '{
    verdict: .status.experimentStatus.verdict,
    failStep: .status.experimentStatus.failStep,
    passPercent: .status.experimentStatus.passPercent
  }'

# Clean up after experiment
kubectl delete chaosengine payment-pod-delete -n production

# Verify service recovered to steady state
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=ext:app.payment.error.rate&resolution=1m&from=now-5m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.resolution.data[].values'
```

---

## Phase 11 — Runbook Maintenance Audit

```bash
# List all runbooks in Confluence (via Confluence API)
curl -s "https://your-org.atlassian.net/wiki/rest/api/search\
?cql=space%3D%22SRE%22+AND+title+%3D+%22Runbook%22+AND+type+%3D+%22page%22\
&limit=50&expand=version" \
  -H "Authorization: Basic $(echo -n 'user@example.com:'"$CONFLUENCE_TOKEN" | base64)" \
  | jq '.results[] | {
      title: .title,
      lastUpdated: .version.when,
      url: ("https://your-org.atlassian.net/wiki" + .url)
    }'

# Find runbooks not updated in > 6 months
curl -s "https://your-org.atlassian.net/wiki/rest/api/search\
?cql=space%3D%22SRE%22+AND+title+%3D+%22Runbook%22+AND+lastModified+%3C+%222026-01-31%22\
&limit=50" \
  -H "Authorization: Basic $(echo -n 'user@example.com:'"$CONFLUENCE_TOKEN" | base64)" \
  | jq '[.results[] | .title]'

# Test a runbook verification step in staging
kubectl exec -it \
  $(kubectl get pod -n staging -l app=payment-service -o name | head -1) \
  -n staging -- env | grep DB_POOL_MAX
# Expected output from runbook: DB_POOL_MAX=50
```
