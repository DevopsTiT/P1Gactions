# Part 6 — Postmortem: Structure and Writing Process Deep Dive

---

## What a Postmortem Is (and Isn't)

**IS:** A structured document written after a significant incident that captures what
happened, why it happened at a systemic level, and what concrete actions will
prevent it from happening again.

**IS NOT:**
- A blame report ("Bob's mistake caused the outage")
- A technical log dump (pasting kubectl output without analysis)
- A box-ticking exercise (written to satisfy a process, not to learn)
- Optional for SEV1/2 (it is mandatory)

The postmortem is the **primary mechanism by which an organization learns from
incidents**. An organization that skips postmortems is doomed to repeat incidents.

---

## The Blameless Principle: Deep Explanation

The blameless principle is often misunderstood. It does NOT mean:
- "We never criticize anything"
- "Everyone gets a participation trophy"
- "Bad work has no consequences"

It means: **when a human makes a mistake, the question is not "who is at fault?"
but "why did the system create conditions where a mistake was likely?"**

### The theoretical foundation

James Reason's "Swiss Cheese Model" of accidents:
```
Each layer of defense has holes (imperfections):

[Code Review] ○○○●○○  ←  hole: reviewer missed the missing index
[CI Pipeline]  ○●○○○○  ←  hole: no query performance test
[Canary Deploy] ●○○○○  ←  hole: no canary (went to 100%)
[Monitoring]   ○○●○○○  ←  hole: no pool saturation alert

An incident happens when the holes line up:
→ Bug slips through → reaches all prod traffic → detected late → impact is large

If you blame "the reviewer," you plug one tiny hole but leave all the
others open. The next bug with a different reviewer goes through the same
Swiss cheese and causes the same incident.

If you analyze all four holes and fix them all, you have genuinely improved
the system's resilience.
```

### Blame-ful vs. blameless language

```
Blame-ful                          Blameless
─────────────────────────────────────────────────────────────
"Bob deployed without testing"  →  "The deploy reached production
                                    without automated index validation"

"Alice should have caught this   →  "Code review did not surface the
 in review"                          performance implications of this
                                    ORM query pattern"

"The on-call was slow to respond" → "The on-call was paged 8 minutes
                                    after the incident began; the alert
                                    threshold was set too conservatively"

"David made a configuration      → "A configuration change reached
 mistake"                            production without a verification step"
```

In all cases, the blameless version points to a fixable system property.
The blame-ful version points to a person — and you cannot "fix" a person.

---

## Postmortem Timeline: When to Write It

```
Incident resolves
      │
      ▼ within 24 hours
Schedule the postmortem meeting (30–60 min, all key responders)
      │
      ▼ within 48 hours (SEV1) / 72 hours (SEV2)
Draft postmortem published in Confluence
  - Timeline reconstructed
  - Root cause identified
  - Contributing factors listed
  - Action items created in Jira
      │
      ▼ at the postmortem meeting
Review the draft together
  - Correct any factual errors in the timeline
  - Challenge the root cause analysis (is it deep enough? is it blameless?)
  - Assign owners and due dates for action items
      │
      ▼ within 1 week
Final postmortem published, shared with leadership
```

**Why the 48/72-hour deadline matters:**
- Details are still fresh in people's memories
- Action items get created while urgency is high
- If you wait 2 weeks, the timeline reconstruction will have gaps, and the
  action items will be deprioritized because the incident "feels like old news"

---

## The Full Postmortem Template (Every Section Explained)

### Section 1: Header Block

```markdown
# Postmortem: [Severity] [Service] – [One-line symptom]
# Example: Postmortem: [SEV2] Payment Service – DB Connection Pool Exhaustion

Date of incident:   2026-07-31
Duration:           32 minutes (14:03–14:35 UTC)
Severity:           SEV2
Status:             RESOLVED / CLOSED
Authors:            Alice Chen, Bob Kumar
Reviewers:          Carol Lin (DB lead), Frank Muller (Platform lead)
```

**Why "Reviewers" matters:** At least one person who was NOT involved in
the incident should review the postmortem. They bring fresh eyes and can
catch when the team is being too easy on itself in the analysis.

---

### Section 2: Impact

```markdown
## Impact

Quantify the impact as precisely as possible. Three dimensions:

User impact:
  ~15,000 checkout attempts failed between 14:03–14:35 UTC.
  This represents ~5% of total checkout traffic during that window.
  Affected users received a generic error message and were not charged.
  No data was lost; failed transactions did not partially complete.

Business impact:
  Estimated revenue impact: ~$42,000
  (Calculation: 15,000 failed checkouts × $2.80 avg. order value)
  Note: this is an estimate; some users may have retried successfully.

Reliability impact:
  32 minutes of degraded service.
  Error budget consumed: 32/43.2 min = 74% of monthly budget.
  SLO availability for July 2026: 99.93% (target: 99.9%) — SLO met.
```

**Why quantify impact:**
- Creates accountability: if the same incident happens again, you can compare impact
- Motivates action items: "we lost $42K" is more compelling than "some users got errors"
- Feeds into SLO/error budget reviews
- Allows external comms to be precise (not "many users were affected")

---

### Section 3: Timeline

```markdown
## Timeline

| Time (UTC) | Event                                                         |
|------------|---------------------------------------------------------------|
| 13:55:00   | Deploy v2.14.3 reaches 100% of payment-service pods          |
| 14:00:15   | Afternoon traffic peak begins (20% above baseline)           |
| 14:02:47   | DB connection pool reaches 100% for the first time           |
| 14:03:12   | PagerDuty alert fires: payment-service error rate > 5%       |
| 14:04:55   | On-call @alice acknowledges alert                            |
| 14:05:30   | Alice declares SEV2, opens #incident-2026-0731-001           |
| 14:05:45   | IC: @alice, TL: @bob, CL: @carol, Scribe: @david            |
| 14:07:00   | TL checks Dynatrace: error rate 7%, p99 latency 12s          |
| 14:08:10   | TL forms hypothesis: DB connection pool exhausted            |
| 14:10:30   | TL checks pool metrics: confirmed 100%, 80 connections queuing|
| 14:12:45   | TL identifies slow query in v2.14.3 ORM code (no index)     |
| 14:14:00   | TL proposes mitigation: increase pool 50→100, rolling restart|
| 14:14:20   | IC approves mitigation                                       |
| 14:15:00   | CL posts UPDATE 1 to stakeholders                            |
| 14:15:10   | TL runs: kubectl set env ... DB_POOL_MAX=100                 |
| 14:16:00   | Rolling restart begins                                       |
| 14:19:30   | Rolling restart complete                                     |
| 14:21:00   | Error rate: 30% → 12%                                        |
| 14:25:00   | Error rate: 0%, p99 latency: 180ms (normal)                 |
| 14:35:00   | 10 min stable — IC declares incident resolved               |
| 14:38:00   | CL posts RESOLVED message to all stakeholders               |
```

**Key rules for timelines:**
- Include second-level timestamps where possible (from PagerDuty, Dynatrace, Slack)
- Include both what the system did AND what the team did
- Note the time between deploy and incident (helps establish causation)
- Note the time each hypothesis was formed and confirmed/refuted
- Note when stakeholder updates were sent (demonstrates comms was timely)

---

### Section 4: Root Cause

```markdown
## Root Cause

Be specific. "A bug was introduced" is not a root cause.

Deploy v2.14.3 introduced a new ORM query in the payment checkout flow:

  # Old code (v2.14.2): used primary key lookup — O(1)
  order = Order.find(order_id)

  # New code (v2.14.3): queries by user_id — full table scan without index
  order = Order.where(user_id: user_id).where(status: 'pending').first

The `orders` table contains 40 million rows. Without an index on `user_id`,
this query performs a full sequential scan, taking 8–12 seconds under
normal load and 12–30 seconds during the afternoon traffic peak.

With the DB connection pool at max 50 connections and each connection held
for 8–12 seconds per request, the pool exhausted during the 20% traffic
spike at 14:00–14:03 UTC, causing all new checkout requests to queue and
eventually time out (HTTP 503).

Root cause: Missing database index on `orders.user_id` combined with
insufficient connection pool size relative to query latency under peak load.
```

---

### Section 5: Contributing Factors

```markdown
## Contributing Factors

List all conditions that made the incident more likely or more severe.
These are not root causes — they are amplifiers or missed defenses.

1. No query performance validation in CI
   The missing index was not caught during code review or automated testing.
   An EXPLAIN plan check in CI would have flagged a full sequential scan on
   a 40M-row table before merge.

2. Connection pool undersized for peak traffic
   At max 50 connections and 8s+ query latency during peak:
   50 connections / 8 seconds per connection = max 6 requests/second.
   The service typically handles 500+ requests/second at peak.
   The pool was insufficient by an order of magnitude when queries were slow.

3. No canary deployment for payment-service
   The deploy went to 100% of pods simultaneously. If 5% canary was in place,
   only 750 users/minute (vs. 15,000) would have been affected before rollback.

4. No connection pool saturation alert
   The pool first reached 100% at 14:02:47 UTC. The error rate alert fired
   at 14:03:12 UTC — only 25 seconds later, which is fast. However, a pool
   saturation alert would have provided an earlier, more actionable signal.

5. Slow query not identified in pre-production testing
   Load testing in staging uses a 500K-row dataset (not 40M rows in production).
   The slow query performed acceptably in staging but not in production.
```

---

### Section 6: What Went Well

```markdown
## What Went Well

This section is not optional or perfunctory. It identifies practices to preserve.

1. Alert detection was fast: 25 seconds between pool exhaustion and PagerDuty alert.
2. On-call acknowledged within 2 minutes (SLA: 5 minutes).
3. IC and TL assigned within 3 minutes of declaration.
4. The USE method quickly narrowed focus to DB infrastructure.
5. Stakeholder updates were timely and clear — no executive escalation required.
6. Scribe maintained a precise timeline that required minimal cleanup for this postmortem.
7. Rollback was available and understood — team didn't need to look up the command.
```

---

### Section 7: What Went Poorly

```markdown
## What Went Poorly

Honest assessment. This is where learning happens.

1. No pool saturation alert existed. Team learned of pool exhaustion by seeing
   user-facing errors, not by catching the leading indicator (pool usage > 80%).

2. CI did not catch the missing index. The test suite had no coverage for
   query performance — only for functional correctness.

3. Revenue impact calculation was done 2 days after the incident, not same-day.
   Impact numbers should be in the postmortem draft within 24 hours.

4. Staging load testing uses an unrealistic data volume (500K rows vs. 40M prod).
   This is a systemic gap — any query that performs differently at scale will
   pass staging and fail production.
```

---

### Section 8: Action Items

```markdown
## Action Items

Every action item must have: description, owner (a person, not a team), priority, due date.

| ID     | Action                                        | Owner      | Priority | Due        | Status |
|--------|-----------------------------------------------|------------|----------|------------|--------|
| PA-101 | Add Dynatrace alert: pool utilization > 80%   | Bob Kumar  | P1       | 2026-08-07 | Open   |
| PA-102 | Add Dynatrace alert: slow query > 500ms       | Bob Kumar  | P1       | 2026-08-07 | Open   |
| PA-103 | Add orders.user_id index + regression test    | Carol Lin  | P1       | 2026-08-05 | Open   |
| PA-104 | Right-size connection pool via load test      | Bob Kumar  | P2       | 2026-08-10 | Open   |
| PA-105 | Implement canary deploy for payment-service   | Alice Chen | P2       | 2026-08-21 | Open   |
| PA-106 | Add EXPLAIN plan check to CI pipeline         | DevOps     | P3       | 2026-09-01 | Open   |
| PA-107 | Scale staging dataset to match production     | Bob Kumar  | P3       | 2026-09-15 | Open   |
```

**Rules for action items:**
- P1 items: if not done, this exact incident can recur. Non-negotiable deadline.
- No Jira ticket = it doesn't exist. Every item must have a ticket number.
- "The team" is not an owner. A named person is an owner.
- Review at weekly SRE meeting until all P1/P2 items are closed.

---

### Section 9: Lessons Learned

```markdown
## Lessons Learned

A brief synthesis of the most important takeaways for the broader team.

1. Staging data volume must match production order of magnitude.
   A 100× difference in data size means performance tests in staging are meaningless
   for queries that do table scans. This is a systemic risk across all services.

2. Leading indicators should alert before user impact.
   A DB pool saturation alert at 80% gives ~3 minutes of warning before exhaustion.
   This time allows the on-call to investigate and potentially mitigate before users
   are affected. We need this pattern for all resource pools, not just this one.

3. Canary deployments are not optional for revenue-critical services.
   The blast radius of this incident was 15,000 users in 32 minutes.
   With a 5% canary, it would have been ~750 users in 5 minutes before rollback.
   A 20× reduction in impact is worth the operational overhead.
```
