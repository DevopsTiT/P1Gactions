# Part 11 — Runbooks and Playbooks: Deep Dive

---

## The Problem They Solve

Imagine it is 3 AM. Your phone rings. PagerDuty: payment-service is down.
You are the on-call engineer. You've never seen this specific failure mode before.

Without a runbook:
```
You try to remember what to check.
You spend 10 minutes just logging into the right systems.
You run the wrong kubectl commands.
You don't know what "normal" looks like in the metrics.
You call someone else. They're also half asleep. They don't remember either.
30 minutes pass before you even identify the problem.
```

With a runbook:
```
You open the #incident channel, click the pinned runbook link.
Step 1 tells you exactly what to check.
Step 2 shows you what "normal" looks like vs. what you're seeing.
Step 3 gives you the exact commands to run for the most common causes.
Step 4 is the mitigation procedure with expected output.
8 minutes pass. Problem solved. Users back online.
```

Runbooks are the operational equivalent of emergency procedures on an airplane.
No pilot memorizes every emergency procedure. They follow the checklist.
This is not a sign of incompetence — it is a sign of operational discipline.

---

## Playbook vs. Runbook: Full Distinction

```
PLAYBOOK
  Scope:    A category of incidents or a service's failure modes
  Audience: IC, TL (first responders) 
  Format:   High-level: triage → diagnose → escalate
  Question: "What kind of problem is this and who/what handles it?"
  Length:   1–2 pages
  Update frequency: When escalation contacts change, or service architecture changes
  
  Example title: "Payment Service Degraded — Playbook"
  Example content:
    - First things to check (3 bullet points)
    - Severity classification decision tree
    - Who to escalate to for each sub-type
    - Links to relevant runbooks
    - Links to dashboards

─────────────────────────────────────────────────────────────────

RUNBOOK
  Scope:    One specific procedure
  Audience: TL (executing a fix)
  Format:   Numbered steps with exact commands and expected output
  Question: "How do I do this specific thing, step by step?"
  Length:   As long as needed — completeness > brevity
  Update frequency: After every time the procedure changes, or after incidents
                    where the runbook didn't reflect reality
  
  Example title: "How to Increase DB Connection Pool Size for payment-service"
  Example content:
    - Exact kubectl commands
    - Expected output at each step
    - How to verify success
    - Rollback procedure
```

---

## Runbook Structure: Every Section Explained

### Section 1: Header

```markdown
# Runbook: [Specific procedure name]

Service:        payment-service
Namespace:      production
Last updated:   2026-07-31
Owner:          Platform SRE (@bob-kumar)
Alert that triggers this: "DB Connection Pool Saturation" (PA-101)
```

**Why "Alert that triggers this" matters:**
When an alert fires, the on-call should be able to click directly from the
PagerDuty alert to the runbook. The runbook should reference the alert so
the on-call can confirm they are in the right runbook.

---

### Section 2: When to Use This Runbook

```markdown
## When to Use This Runbook

Use this runbook when:
- The "DB Connection Pool Saturation" Dynatrace alert fires
  (pool utilization > 80% for 2+ consecutive minutes)
- The payment-service error rate is elevated AND Dynatrace shows high
  DB connection wait times
- The on-call suspects connection pool exhaustion as a contributing factor
  to a payment-service incident

Do NOT use this runbook if:
- The DB itself is down (use runbook: "Payment Service DB Failover")
- The error rate is high but DB pool utilization is normal (different cause)
```

---

### Section 3: Prerequisites

```markdown
## Prerequisites

Access required:
- kubectl access to production cluster (RBAC role: sre-operator)
  → If you don't have this: run `kubectl auth can-i get pods -n production`
    If denied: page @platform-oncall for emergency access grant

- Dynatrace access (read-only sufficient for investigation)
  → Login: https://YOUR_TENANT.live.dynatrace.com

- Optionally: DB admin access (if direct query investigation needed)
  → Contact @db-team for emergency read-only access
```

---

### Section 4: Step-by-Step Procedure

This is the core of the runbook. Every step has:
- What to do
- Exact command
- Expected output (what good looks like)
- What to do if the output is unexpected

```markdown
## Procedure

### Step 1: Verify the Alert Is Real

Check Dynatrace for DB connection pool utilization:
```bash
# Get current pool utilization from Dynatrace API
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=ext:db.connectionPool.utilization&resolution=1m&from=now-10m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.resolution.data[].values[-1]'
```
Expected output: A number between 0 and 100.
If > 80: pool is saturated. Continue to Step 2.
If < 80: alert may have been a spike. Monitor for 5 minutes. If drops below 70, close alert.

### Step 2: Check Current Pool Configuration

```bash
kubectl exec -it \
  $(kubectl get pod -n production -l app=payment-service -o name | head -1) \
  -n production -- env | grep DB_POOL
```
Expected output:
```
DB_POOL_MAX=50
DB_POOL_MIN=5
DB_POOL_IDLE_TIMEOUT=10000
```
If DB_POOL_MAX is 50: the pool is at the original (too-small) value. Proceed to Step 3.
If DB_POOL_MAX is already 100 or higher: pool increase already applied. Skip to Step 4.

### Step 3: Check for Active Slow Queries

```bash
# Check Dynatrace for queries taking > 1 second
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=ext:db.query.latency.p99&resolution=1m&from=now-10m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.resolution.data[].values'
```
Expected baseline: < 200ms (0.2 in the response)
If > 1000ms: there is a slow query. Note the value and continue.
The slow query is likely what is exhausting the pool (each query holds a connection longer).
This does not change the immediate mitigation — but include in incident notes.

### Step 4: Apply Mitigation — Increase Pool Size

⚠️  Get IC approval before running this step.
⚠️  This triggers a rolling restart of all payment-service pods.
⚠️  Rolling restart takes ~3 minutes. Error rate may temporarily increase during restart.

```bash
# Increase pool max to 100
kubectl set env deployment/payment-service -n production DB_POOL_MAX=100

# Verify the change was applied to the deployment spec
kubectl get deployment payment-service -n production \
  -o jsonpath='{.spec.template.spec.containers[0].env}' | jq '.[] | select(.name=="DB_POOL_MAX")'
```
Expected output: `{"name": "DB_POOL_MAX", "value": "100"}`

```bash
# Watch the rolling restart
kubectl rollout status deployment/payment-service -n production
```
Expected output after ~3 minutes:
`deployment "payment-service" successfully rolled out`

### Step 5: Verify Mitigation Worked

```bash
# Watch error rate in real time (re-run every 30 seconds for 5 minutes)
kubectl logs -n production -l app=payment-service --since=1m \
  | grep -cE "ERROR|503|500"
```
Expected output: decreasing count per minute, reaching 0 within 3 minutes.

Also check Dynatrace pool utilization — should drop below 60% within 2 minutes.

### Step 6: Monitor for Stability (10 minutes)

After error rate reaches 0, monitor for 10 minutes before declaring mitigation complete.

Watch for:
- Error rate returning (would indicate pool is still insufficient or other cause)
- Memory spike (pool increase means more DB connections held = more memory)
- DB CPU increase (more concurrent connections = more DB load)

If stable after 10 minutes: mitigation successful. Report to IC.

### Step 7: File Follow-Up Actions

Regardless of outcome, file a Jira ticket to make the pool increase permanent
in the Helm chart (the env var change above is temporary — it will reset on next deploy):

```bash
# Create Jira ticket (or note in the incident ticket)
# Title: "Make DB_POOL_MAX=100 permanent in payment-service Helm chart"
# Priority: P1 (will revert on next deploy otherwise)
# Assignee: Current TL or DB team
```
```

---

### Section 5: Rollback Procedure

```markdown
## Rollback

If the pool size increase made things WORSE (unexpected — but possible if
the DB cannot handle 100 concurrent connections):

```bash
kubectl set env deployment/payment-service -n production DB_POOL_MAX=50
kubectl rollout status deployment/payment-service -n production
```

If pool size change is not helping at all after 5 minutes:
→ Consider full service rollback (use runbook: "payment-service rollback")
→ Page DB team to investigate DB-side connection limits
```

---

### Section 6: Escalation

```markdown
## Escalation

If this runbook does not resolve the issue within 15 minutes, escalate:

DB pool is exhausted but no slow queries found:
  → Escalate to DB team: @db-oncall (PagerDuty: "Database Engineering")
  → Possible: DB-side connection limit, DB host resource exhaustion

DB pool increase did not reduce error rate:
  → Different root cause. Escalate to IC.
  → Next investigation: check application error logs for non-DB errors

DB host CPU/memory critically high:
  → Escalate to DB team immediately
  → This is a DB-level incident, not a pool configuration issue
```

---

## Runbook Quality Standards

A runbook that is hard to follow is worse than no runbook — it gives false
confidence while wasting time.

```
Quality checklist for every runbook:

✓ Can a junior engineer who has never seen this failure follow it?
  → If no: add more context, more expected output, more decision points

✓ Are all commands copy-paste ready?
  → No hand-waving. Every command must be runnable verbatim.

✓ Does it show what "good" looks like?
  → Expected output for every command. Not just what to run, but what to expect.

✓ Does it show what "bad" looks like and what to do?
  → "If output is X, do Y. If output is Z, escalate."

✓ Does it have a rollback section?
  → Every mitigation must be reversible. If it is not reversible, say so explicitly.

✓ Is it linked from PagerDuty?
  → The runbook is useless if on-call cannot find it at 3 AM.

✓ Was it reviewed after the last incident where it was used?
  → The true test of a runbook is using it during an incident.
  → Every incident where a runbook was followed should produce a runbook update.
```

---

## Runbook Maintenance

A runbook that reflects a system from 2 years ago is actively harmful.
It directs the on-call to take incorrect actions.

```
Triggers for runbook review:
  1. After any incident where this runbook was used → verify it was accurate
  2. After any architectural change to the service → update commands/paths
  3. After any access control change → update prerequisites section
  4. During quarterly runbook audit → check all runbooks for staleness

Quarterly runbook audit:
  For each runbook:
  - Run the verification commands (Step 1, Step 2 of each runbook) in staging
  - Confirm commands produce expected output
  - Update "Last updated" date
  - If a runbook hasn't been touched in 12 months: either update it or archive it
```
