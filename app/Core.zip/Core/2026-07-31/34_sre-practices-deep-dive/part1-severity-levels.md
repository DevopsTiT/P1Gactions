# Part 1 — Severity Levels: Deep Dive

---

## What This Is

A severity level (SEV) is the **official classification of how bad an incident is**. It is the first decision made when an incident is declared, and it drives every other decision: who gets paged, how fast they must respond, how the team communicates, and how much authority the Incident Commander has to take drastic action.

Without a severity framework, every incident looks the same. The team treats a slow dashboard the same way it treats a complete payment outage — wasting time, burning people out, or (worse) under-responding to a real crisis.

---

## The Core Decision: How Do You Classify?

```
Is any user unable to complete a critical business action (pay, log in, buy)?
├── YES, 100% of users affected → SEV1
├── YES, a significant % of users affected (>5%) → SEV2
├── YES, a small % of users affected (<5%) OR a non-critical feature → SEV3
└── NO user impact now, but a risk is building → SEV4

Is there active data loss or data corruption?
└── YES → SEV1 regardless of user impact percentage

Is there a security breach in progress?
└── YES → SEV1 regardless of anything else
```

---

## Severity Table (Full Detail)

```
┌──────┬───────────────────────────────────────────────────────────────────┐
│ SEV1 │ CRITICAL — Full service outage or data loss in progress           │
│      │                                                                   │
│      │ Definition:                                                       │
│      │   The service is completely unavailable, or a critical feature    │
│      │   is broken for all users, or data is being lost/corrupted.       │
│      │                                                                   │
│      │ Examples:                                                         │
│      │   - Payment API returning 503 for 100% of requests               │
│      │   - Login service down (no one can authenticate)                 │
│      │   - Database writes failing — orders not being saved             │
│      │   - Active security breach (data exfiltration in progress)       │
│      │                                                                   │
│      │ Response SLA: Acknowledge within 5 minutes                       │
│      │ Who is paged: On-call + team lead + engineering manager           │
│      │               + customer success + (often) VP Engineering         │
│      │ Comms cadence: Every 15–20 minutes to stakeholders               │
│      │ Status page: Update immediately, mark as "Major Outage"          │
│      │ Postmortem: Required, due within 48 hours                        │
│      │ Error budget: This incident alone may exhaust the monthly budget  │
└──────┴───────────────────────────────────────────────────────────────────┘

┌──────┬───────────────────────────────────────────────────────────────────┐
│ SEV2 │ HIGH — Significant degradation, key feature broken for many users │
│      │                                                                   │
│      │ Definition:                                                       │
│      │   A major feature is broken or severely slow for a meaningful     │
│      │   percentage of users. Service is partially available.            │
│      │                                                                   │
│      │ Examples:                                                         │
│      │   - Checkout is working but takes 45 seconds (normally 2s)       │
│      │   - Search is returning no results for 30% of users              │
│      │   - Email notifications not being sent (business process broken) │
│      │   - One of three regions is completely down                      │
│      │                                                                   │
│      │ Response SLA: Acknowledge within 15 minutes                      │
│      │ Who is paged: On-call + team lead                                │
│      │ Comms cadence: Every 30 minutes to stakeholders                  │
│      │ Status page: Update within 10 min, mark as "Partial Outage"      │
│      │ Postmortem: Required, due within 72 hours                        │
└──────┴───────────────────────────────────────────────────────────────────┘

┌──────┬───────────────────────────────────────────────────────────────────┐
│ SEV3 │ MEDIUM — Minor degradation, small subset of users affected        │
│      │                                                                   │
│      │ Definition:                                                       │
│      │   A non-critical feature is broken, or a minor feature is        │
│      │   broken for a small % of users. Core flows still work.          │
│      │                                                                   │
│      │ Examples:                                                         │
│      │   - Export-to-CSV feature failing for all users                  │
│      │   - Dark mode rendering incorrectly on one browser               │
│      │   - One API endpoint returning stale data due to cache bug       │
│      │   - Latency elevated by 20% but still within acceptable range    │
│      │                                                                   │
│      │ Response SLA: Acknowledge within 1 hour (business hours)         │
│      │ Who is paged: On-call only (no escalation)                       │
│      │ Comms cadence: None required unless escalates                    │
│      │ Status page: Optional (usually "Investigating")                  │
│      │ Postmortem: Optional — team's discretion                         │
└──────┴───────────────────────────────────────────────────────────────────┘

┌──────┬───────────────────────────────────────────────────────────────────┐
│ SEV4 │ LOW — No current user impact, but a risk is building              │
│      │                                                                   │
│      │ Definition:                                                       │
│      │   No users are affected right now, but something is degraded     │
│      │   in a way that increases the probability of a real incident.    │
│      │                                                                   │
│      │ Examples:                                                         │
│      │   - Disk at 85% (normal is 40%) — will fill in ~3 days          │
│      │   - SSL cert expires in 10 days                                  │
│      │   - A non-critical background job has been failing for 2 hours  │
│      │   - Memory usage trending up (possible memory leak)              │
│      │                                                                   │
│      │ Response SLA: Next business day                                  │
│      │ Who is notified: Jira ticket filed, no page                      │
│      │ Comms cadence: None                                              │
│      │ Status page: No update                                           │
│      │ Postmortem: Not required                                         │
└──────┴───────────────────────────────────────────────────────────────────┘
```

---

## The Golden Rule: Declare High, Downgrade Later

When you are unsure whether something is SEV2 or SEV3, **always declare SEV2**.

Why this matters:
- Declaring SEV3 on a real SEV2 delays bringing in the right people by 45 minutes
- Declaring SEV2 on a real SEV3 wastes 15 minutes of a team lead's time
- The cost of a false SEV2 is far smaller than the cost of a missed SEV1/2

Downgrading mid-incident is completely normal and expected:
```
"We declared SEV2 out of caution. After investigation, this is SEV3.
 Downgrading. On-call will handle. Team lead stand down."
```

---

## Severity vs. Priority

These are different concepts that beginners often conflate.

```
Severity  = how bad the technical impact is right now
Priority  = how urgently it needs to be fixed

A SEV4 disk-full warning on a payment server has:
  - LOW severity (no users affected yet)
  - HIGH priority (will become SEV1 in 3 days if not fixed)

A SEV3 broken export feature has:
  - MEDIUM severity (some users affected)
  - LOW priority (non-critical feature, fix next sprint)
```

---

## How Severity Flows Into Everything Else

```
Severity declared
      │
      ├─► Paging policy (who gets woken up)
      ├─► Bridge protocol (Slack channel vs. just a ticket)
      ├─► Comms cadence (every 15 min vs. next morning)
      ├─► Status page update (or not)
      ├─► Postmortem required (or not)
      └─► Error budget consumed (how much)
```

---

## Calibrating Severity Over Time

The first time a team defines severity levels, the definitions are hypothetical.
After 6–12 months of real incidents, you should review:

1. Were there incidents where the team disagreed on severity?
2. Were any incidents under-declared (should have been higher)?
3. Were there "alert fatigue" periods where too many SEV2/3 fired?
4. Are your response SLAs actually being met?

Adjust the definitions and thresholds based on what you learn.
Good severity levels are **calibrated to your specific users and business** —
not copied verbatim from another company.

---

## Real Example: Walking Through a Classification

```
Alert fires: "payment-service error rate > 5%"

Question 1: Is a critical business action broken?
  → Yes. Checkout is the core revenue flow.

Question 2: How many users are affected?
  → Error rate 5% → roughly 5% of checkout attempts failing.
  → During peak: ~10,000 requests/min → 500 users/min getting errors.

Question 3: Is it 100% broken or partially degraded?
  → 95% of requests succeed. Partially degraded.

Classification: SEV2
  → Significant degradation of a critical business flow
  → Large absolute number of users affected
  → Calls for full incident response

If the error rate had been 0.2% on a non-critical feature:
  → SEV3 (small % of users, non-critical path)

If it had been 100% errors on checkout:
  → SEV1 (full outage of critical path)
```
