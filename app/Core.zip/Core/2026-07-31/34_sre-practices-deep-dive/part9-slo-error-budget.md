# Part 9 — SLO Reviews and Error Budget Management: Deep Dive

---

## The Problem SLOs Solve

Without SLOs, reliability is managed by feelings:
- "The system seems slow lately"
- "We've had a few incidents this month"
- "The ops team is worried"

These feelings produce political arguments, not rational decisions.
SLOs replace feelings with measurements and transform reliability into a
negotiation between two legitimate goals: moving fast (features) and being reliable.

---

## The SLI → SLO → SLA Hierarchy

```
SLI (Service Level Indicator)
│  The raw measurement. A specific metric.
│  Example: "percentage of HTTP requests that return status 200 within 500ms"
│  This is a NUMBER you measure continuously.
│
▼
SLO (Service Level Objective)
│  A target for the SLI over a time window.
│  Example: "99.9% of requests must return 200 within 500ms, measured over 30 days"
│  This is an INTERNAL commitment — your team holds itself to this.
│
▼
SLA (Service Level Agreement)
   A contractual promise to customers based on SLOs.
   Example: "If availability drops below 99.5% in a calendar month, customers
             receive a 10% service credit."
   This is an EXTERNAL commitment — breaching it has financial consequences.
   SLA targets are always looser than SLO targets (buffer for safety).
```

---

## Choosing the Right SLIs

Not every metric is a good SLI. A good SLI directly measures **what users experience**.

```
Good SLIs:
  ✓ Request success rate (% of requests returning 2xx)
  ✓ Request latency (% of requests completing within X ms)
  ✓ Checkout success rate (% of checkout flows completing without error)
  ✓ Data freshness (% of time the data shown is < 5 min old)
  ✓ Durability (% of writes that are successfully persisted)

Bad SLIs:
  ✗ CPU utilization (users don't directly experience CPU %)
  ✗ Memory usage (same — infrastructure metric, not user metric)
  ✗ Deployment frequency (measures velocity, not reliability)
  ✗ Number of alerts fired (measures alert volume, not user impact)
```

**The SLI test:** Replace "SLI is at X%" in a sentence.
"Users are experiencing X% success rate" — does this make sense? Good SLI.
"Users are experiencing 45% CPU utilization" — meaningless. Bad SLI.

---

## Setting the Right SLO Target

SLO targets should reflect actual user pain tolerance — not "the highest number
that sounds impressive."

### The Cost of Targets That Are Too High

```
99.999% availability over 30 days = 26 seconds of allowed downtime
  → Every deployment that causes even a brief error burst blows the budget
  → Every pod restart that takes 10 seconds burns meaningful budget
  → The team is always in "reliability emergency" mode
  → Alert fatigue: everything is a P1, so nothing is treated as a real P1
  → Engineers burn out and leave
```

### The Cost of Targets That Are Too Low

```
90% availability over 30 days = 3 days of allowed downtime
  → Users are tolerating service that is down 7 hours a day
  → No signal: when incidents happen, the budget has plenty of room
  → No pressure to fix reliability: "we have plenty of budget left"
  → Product quality erodes silently
```

### How to Calibrate

Start by measuring your current reliability. Then ask:

```
1. What is our current actual availability (last 90 days)?
   Example: 99.82%

2. What do users notice? At what degradation level do we get support tickets?
   Example: Users file tickets when error rate > 1% for > 5 minutes.
   This implies users tolerate brief blips but not sustained degradation.

3. What does our SLA say?
   Example: SLA guarantees 99.5% availability.

4. Set SLO with a buffer between current performance and SLA:
   Current: 99.82%
   SLA: 99.5%
   SLO: 99.9% (above current = stretch goal, well above SLA = safety buffer)
```

---

## Error Budget: Mechanics

### Calculating the Budget

```
SLO: 99.9% availability over 30 days

Step 1: Calculate total request-minutes (or just minutes for availability)
  Minutes in 30 days: 30 × 24 × 60 = 43,200 minutes

Step 2: Calculate allowed downtime (error budget)
  Allowed downtime = 43,200 × (1 - 0.999) = 43,200 × 0.001 = 43.2 minutes

Step 3: Calculate error budget per incident
  Incident duration: 32 minutes
  Budget consumed: 32 / 43.2 = 74.07%
  Budget remaining: 11.2 minutes
```

### Error Budget Policy: The Decision Framework

```
Budget consumed    │ What this means        │ SRE policy
───────────────────┼────────────────────────┼────────────────────────────────────
0–25%             │ Healthy                 │ Normal velocity. All deploys allowed.
                   │                         │ Focus on feature work.
───────────────────┼────────────────────────┼────────────────────────────────────
25–50%            │ On track                │ Normal velocity.
                   │                         │ Monitor trends.
───────────────────┼────────────────────────┼────────────────────────────────────
50–75%            │ Warning zone            │ Yellow flag.
                   │                         │ Review P2 action items.
                   │                         │ Reduce risky deploy frequency.
───────────────────┼────────────────────────┼────────────────────────────────────
75–99%            │ Danger zone             │ Red flag.
                   │                         │ Freeze non-critical deploys.
                   │                         │ All hands on reliability work.
                   │                         │ P1 action items must complete NOW.
───────────────────┼────────────────────────┼────────────────────────────────────
> 100%            │ Budget exhausted        │ No new feature deploys until budget
                   │ (SLO breached)          │ recovers.
                   │                         │ Full team on reliability sprint.
                   │                         │ SLA review (may owe credits).
```

---

## Multi-Window Error Budgets

A single 30-day window is too coarse. A sophisticated SLO setup uses multiple windows:

```
Short window (1 hour):
  Purpose: Detect active incidents fast.
  "Is the SLO being violated RIGHT NOW?"
  Alert immediately if current-hour consumption rate would exhaust budget in < 2 days.

Medium window (6 hours):
  Purpose: Catch sustained degradation not severe enough for immediate alert.
  "Is there a trend I should address today?"

Long window (30 days):
  Purpose: Monthly reliability review.
  "How are we trending overall? Will we breach the SLO this month?"
```

**Burn rate alerting:**

Instead of alerting when budget reaches a percentage threshold, alert on the
*rate at which the budget is being consumed*.

```
Budget burn rate = (current error rate) / (SLO error rate threshold)

Example:
  SLO: 99.9% → allowed error rate: 0.1%
  Current error rate: 5%
  Burn rate: 5% / 0.1% = 50×

  At 50× burn rate: the monthly budget (43.2 min) will exhaust in:
    43.2 / 50 = 0.86 hours = 52 minutes

  Alert: "If current error rate continues, budget exhausted in 52 minutes."

Alert thresholds (example):
  Burn rate > 14.4×: page immediately (budget exhausts in < 2 hours if 5% error rate sustained)
  Burn rate > 6×  : ticket (budget exhausts in < 5 hours)
  Burn rate > 1×  : review (consuming faster than the SLO allows)
```

---

## The Monthly SLO Review: Full Agenda

This meeting should happen every month. It is the mechanism by which
reliability work is prioritized relative to feature work.

```
1. Error Budget Status (10 min)
   For each SLO-tracked service:
   - Current budget consumed %
   - Budget consumed vs. same time last month
   - Which incidents consumed the most budget?
   - Trend: are we improving or degrading month over month?

2. Incident Review (10 min)
   - How many SEV1/2 incidents this month?
   - What was the total user impact?
   - Are postmortem action items on track?
   - Did any previously postmortemed incident recur?

3. SLO Target Review (5 min)
   - Are current SLO targets appropriate?
   - Any services that consistently operate far above their SLO target?
     (Consider tightening the target to reduce false confidence)
   - Any services consistently near or below their SLO target?
     (Either improve reliability or adjust target if it was miscalibrated)

4. Reliability Investment Prioritization (10 min)
   - Based on error budget consumption, what reliability work should we
     prioritize next sprint?
   - Example: "Payment service consumed 74% of budget. We commit to:
     - PA-101, PA-102, PA-103 this week (P1)
     - PA-105 (canary deployment) by end of sprint (P2)"

5. Forward Look (5 min)
   - Upcoming high-risk events: big product launches, infrastructure migrations
   - Any planned maintenance that will consume error budget?
   - Adjust reliability work priorities accordingly
```

---

## The Error Budget as a Negotiation Tool

This is the most powerful aspect of the SLO framework for SREs.
The error budget converts reliability into a language that product managers
and engineering leaders understand: **risk tolerance**.

**The conversation without SLOs:**
> Product: "We need to deploy 5 major features this sprint."
> SRE: "That feels risky, we've had a lot of incidents lately."
> Product: "We have a deadline. Ship it."

**The conversation with SLOs:**
> Product: "We need to deploy 5 major features this sprint."
> SRE: "We have 11 minutes of error budget remaining this month. Each of your
>       5 deploys has historically caused ~5–10 minutes of degradation during
>       rollout if something goes wrong. We have enough budget for 1–2 deploys
>       before we exhaust the budget and breach the SLA.
>       Options: (1) deploy 2 features now, hold 3 for next month, or
>                (2) implement canary deploys first (reduces risk per deploy),
>                    then deploy all 5."
> Product: "Let's prioritize the canary deployment first."

The SRE won the reliability argument by making the tradeoff quantitative and visible.

---

## Dynatrace SLO Configuration (Terraform)

```hcl
# infra/slo/payment-availability.tf

resource "dynatrace_slo_v2" "payment_availability" {
  name        = "Payment Service – Availability"
  enabled     = true
  description = "99.9% of payment service requests succeed within 30 days"

  evaluation_type   = "AGGREGATE"
  
  # Numerator: successful requests (status 2xx)
  # Denominator: all requests
  metric_expression = "100*(ext:app.payment.requests.success)/(ext:app.payment.requests.total)"

  target    = 99.9   # SLO target
  warning   = 99.95  # alert when approaching target
  timeframe = "-30d"

  filter = "type(\"SERVICE\"),entityName(\"payment-service\")"
}

resource "dynatrace_slo_v2" "payment_latency" {
  name        = "Payment Service – Latency"
  enabled     = true
  description = "95% of payment requests complete within 500ms"

  evaluation_type   = "AGGREGATE"
  metric_expression = "100*(ext:app.payment.requests.fast)/(ext:app.payment.requests.total)"

  target    = 95.0
  warning   = 97.0
  timeframe = "-30d"

  filter = "type(\"SERVICE\"),entityName(\"payment-service\")"
}
```
