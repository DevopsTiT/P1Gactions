# Part 12 — Continuous Improvement Cadence: Deep Dive

---

## Why "Continuous" Requires Structure

"Continuous improvement" sounds like it should happen organically —
you have an incident, you learn from it, you improve. But without structured
rituals, this learning does not actually transfer to the system:

- Engineers learn individually but the knowledge stays in their heads
- Action items get created but nobody reviews whether they were done
- The same incident happens 6 months later and everyone says "didn't we fix this?"
- The team is always reactive (fighting fires) and never proactive (preventing fires)

Structured rituals convert individual incident learning into systemic improvement.
Each ritual exists because without it, a specific type of learning fails to happen.

---

## Daily: On-Call Handoff

**Purpose:** Transfer operational state from outgoing to incoming on-call.
Without this, the incoming on-call starts blind — unaware of recent incidents,
active risks, or in-progress investigations.

**Format:** 5–10 minute Slack message or short video. NOT a meeting.

**Template:**
```
ON-CALL HANDOFF — 2026-07-31 → 2026-08-01

ACTIVE INCIDENTS:
  None.

INCIDENTS IN LAST 24H:
  [SEV2] Payment DB pool exhaustion — RESOLVED 14:35 UTC
  Postmortem scheduled: 2026-08-01 14:00 UTC
  Action items created: PA-101 through PA-103 in Jira

THINGS TO WATCH:
  - payment-service: error budget at 74% consumed. Watch for any
    further errors — any new incident will exhaust the budget.
  - orders-db: disk at 78% (alert threshold: 85%). Slow growth
    but worth checking daily this week.
  - cert-manager: cert for api.example.com expires in 18 days.
    Ticket SRE-443 open — verify auto-renewal is working.

UPCOMING RISKS:
  - 2026-08-02: Big product launch (marketing email to 500K users).
    Expect 3× normal traffic 14:00–16:00 UTC. Pre-scaled HPA config
    is in infra/scaling/launch-aug02.yaml — apply at 13:45 UTC.

OUTSTANDING RUNBOOK GAPS:
  None noted.

NOTES:
  Bob Kumar is OOO until 2026-08-03. DB questions: escalate to Carol Lin.
```

**What happens without the handoff:**
The new on-call doesn't know the cert is about to expire, doesn't know about
the upcoming traffic spike, doesn't know the error budget is nearly exhausted.
The next incident reveals all of these as surprises instead of managed risks.

---

## Weekly: Incident and Action Item Review

**Purpose:**
1. Walk through every incident from the past week (even small ones)
2. Review postmortem action item status
3. Identify recurring patterns
4. Catch action items that are at risk of missing their deadline

**Format:** 30-minute team meeting. Recurring, never skipped.

**Agenda:**
```
[10 min] Incident walkthrough
  For each SEV1/2/3 from the past week:
  - What was the symptom?
  - What was the root cause?
  - Is a postmortem written/scheduled?
  - Any quick wins we can implement immediately?

[10 min] Action item review
  Open the Jira filter: label = postmortem-action AND status != Done
  For each item:
  - Is it on track for its due date?
  - Blocked? What's the blocker?
  - Any P1 items overdue? (This triggers escalation protocol)

[5 min] Toil log
  - Did any on-call engineer log new toil this week?
  - Is any existing toil pattern getting worse?

[5 min] Open items / AOB
```

**Health metrics to track weekly:**
```
Metric                          Target        This week
──────────────────────────────────────────────────────────
P1 action items overdue         0             ?
P2 action items overdue         < 3           ?
SEV1/2 incidents this week      < 2           ?
Postmortems published on time   100%          ?
On-call pages per engineer      < 5/shift     ?
```

---

## Monthly: SLO Review

**Purpose:**
Connect reliability metrics (SLO/error budget) to engineering priorities.
This is the mechanism that uses the error budget as a lever in product planning.

**Format:** 45-minute meeting. Engineering lead + SRE lead + Product lead all attend.
The product lead's presence is NOT optional — this is where the tradeoff between
feature velocity and reliability is negotiated.

**Agenda:**
```
[15 min] SLO Dashboard Review
  For each service with an SLO:
  - Current compliance %
  - Error budget consumed this month
  - Budget consumed vs. last month (improving or degrading?)
  - Incidents that consumed the most budget

[10 min] Incident Themes
  - Were there recurring incident types this month?
  - Are postmortem actions being completed?
  - If an incident type recurred: why? Which action items were supposed to prevent it?

[10 min] SLO Target Review
  - Any SLO that is consistently breached? → Need to improve reliability or
    adjust target if unrealistic
  - Any SLO with near-zero consumption? → Target may be too loose; tighten it
    to create meaningful signal
  - Any new services that need an SLO?

[10 min] Next Sprint Reliability Work
  - Based on error budget status, what reliability work is prioritized?
  - If budget is < 25% remaining: reliability work takes priority over features
  - Specific items proposed for next sprint with owner and size estimate

Product lead makes commitments:
  - "We will hold feature X until PA-105 (canary deploy) is complete"
  - "We agree that PA-101 and PA-102 are P1 and will be in this sprint"
```

**The output of this meeting is binding:**
The commitments made here go into the sprint. SRE lead tracks them.
If the product team deprioritizes agreed reliability work mid-sprint,
SRE lead escalates to engineering director.

---

## Monthly: Reliability Metrics Report

**Purpose:** Visible, quantitative record of reliability trends over time.
Used by engineering leadership to understand the team's operational health.

**Format:** 1-page Confluence document. Published within 3 days of month end.

**Template:**
```markdown
# Reliability Report — July 2026

## SLO Status
| Service           | SLO Target | Actual    | Error Budget Used | Status |
|-------------------|------------|-----------|-------------------|--------|
| payment-service   | 99.9%      | 99.93%    | 74%               | ⚠️     |
| order-service     | 99.9%      | 99.97%    | 22%               | ✅     |
| auth-service      | 99.95%     | 99.99%    | 5%                | ✅     |

## Incident Summary
- SEV1: 0
- SEV2: 1 (payment-service DB pool exhaustion — 32 min)
- SEV3: 3
- Total user impact: ~15,000 affected users

## MTTA / MTTR
- MTTA (mean time to acknowledge): 3.5 minutes (target: < 5 min) ✅
- MTTR (mean time to resolve): 28 minutes (target: < 60 min for SEV2) ✅

## Action Items
- P1 items completed on time: 3/3 (100%) ✅
- P2 items completed on time: 1/3 (33%) ⚠️ (PA-104 and PA-105 in progress)
- P3 items completed on time: 0/1 (pending)

## Toil Rate
- Team average toil rate: 48% (target: < 50%) ✅

## Key Wins
- Liveness probe for memory restart toil: eliminates 3 pages/week
- Post-deploy cache clear hook: eliminates 2 manual cache clears/week

## Risks for Next Month
- Payment service error budget at 74% consumed with 31 days to recover.
  PA-101, PA-102, PA-103 must complete this week to reduce recurrence risk.
- August 2 product launch: 3× traffic expected. Pre-scaling plan in place.
```

---

## Quarterly: Chaos Engineering Exercise

**Purpose:** Proactively discover resilience gaps before real incidents do.
Test assumptions about how systems handle failure.

**Format:** Half-day planned exercise. Engineers take turns injecting failures.

**Structure:**
```
1. PRE-EXERCISE (1 week before)
   - Define hypotheses to test
     "We believe: if auth-service goes down, payment-service returns 503
      within 5 seconds and does not take down the rest of the app"
   - Define steady state (what "healthy" looks like)
   - Define abort criteria (stop experiment if error rate > 5% in unrelated services)
   - Notify customer success: "We are running planned resilience testing
     on [date] from [time] to [time]. Impact should be minimal."

2. STAGING RUN (3 days before)
   - Run the same experiments in staging first
   - Discover and fix issues before doing it in production
   - A staging run that reveals no issues = you may be testing the wrong things

3. PRODUCTION RUN (exercise day)
   - Start with low-impact experiments (pod restarts)
   - Progress to higher-impact (network partition, dependency failure)
   - One experiment at a time. Verify steady state restored after each.
   - Scribe logs everything (this feeds the postmortem-equivalent document)

4. POST-EXERCISE (1 week after)
   - Write a findings document (format similar to postmortem)
   - Create action items for every hypothesis that was refuted
   - Share findings with broader engineering team
```

**Example experiments for a microservices payment system:**

```
Experiment 1: Pod failure
  Hypothesis: If 1 of 3 payment-service pods is deleted, the other 2
              handle load without user impact.
  Method: kubectl delete pod payment-service-xxxx
  Verify: Error rate stays 0%, latency stays < 500ms

Experiment 2: Dependency failure
  Hypothesis: If auth-service is unavailable, payment-service returns
              HTTP 503 within 5 seconds (not hang for 30 seconds).
  Method: kubectl scale deployment auth-service --replicas=0
  Verify: payment-service returns 503 within 5s, not a timeout at 30s

Experiment 3: Resource exhaustion
  Hypothesis: If CPU is throttled to 50%, service stays available but
              latency increases gracefully (not a cliff-edge failure).
  Method: LitmusChaos cpu-hog experiment
  Verify: Error rate < 1%, latency p99 < 2s (graceful degradation)

Experiment 4: Network latency injection
  Hypothesis: 200ms of added network latency to DB does not cause errors
              (our timeout settings have sufficient headroom).
  Method: LitmusChaos network-latency experiment
  Verify: Error rate stays 0%, latency p99 increases proportionally
```

---

## Quarterly: On-Call Health Review

**Purpose:** Ensure the on-call burden is sustainable and distributed fairly.
On-call burnout is the biggest operational risk to an SRE team.

**Metrics to review:**
```
Pages per person per rotation:
  Target: < 5 actionable pages per on-call shift
  If > 10 pages per shift consistently: either too much noise (tune alerts)
  or service is too unreliable (redirect all work to reliability)

Nights and weekends paged:
  Track separately from business hours pages
  Consistent midnight pages for the same service = reliability project needed

Alert accuracy:
  What % of pages required human action?
  If < 70% of pages were actionable = alert fatigue is a problem
  Tune or eliminate the noisy alerts

Time-to-sleep (after incident):
  After a midnight SEV2 resolved at 3 AM, what is the on-call engineer doing?
  If they're going back on-call immediately, that's a health risk.
  Policy: after an incident that runs past midnight, on-call hands off until morning.
```

---

## Quarterly: SLO Target Review

**Purpose:** SLO targets set 6 months ago may no longer reflect reality.

```
Questions to ask:

1. Is this SLO too tight?
   Signal: Team is always in "red" for this SLO. Every incident triggers a
   budget crisis. Engineers feel constant pressure. Incidents always breach the SLO.
   Action: Measure actual user impact. If users are tolerating the current level
   of unreliability (support tickets are low), loosen the SLO.

2. Is this SLO too loose?
   Signal: Budget is never under 90%. The SLO hasn't been threatened in 12 months.
   Action: Tighten the SLO to create meaningful signal. A reliability metric
   that never gets close to its target provides no useful information.

3. Is this SLI measuring the right thing?
   Signal: SLO is green, but users are complaining about reliability.
   Action: The SLI doesn't capture what users actually experience.
   Example: "HTTP 200 rate" is green, but the response has wrong data.
   Fix: Add an assertion-based SLI (synthetic monitor checks response content).

4. Does this service need a new SLO dimension?
   Signal: Availability is fine but latency is the real user pain.
   Action: Add a latency SLO in addition to availability.
```
