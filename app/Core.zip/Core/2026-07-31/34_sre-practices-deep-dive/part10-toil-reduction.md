# Part 10 — Toil Identification and Reduction: Deep Dive

---

## What Toil Is (Precise Definition)

Toil is not just "annoying work" or "work I don't enjoy."
Google's SRE book defines toil as work that has ALL of these properties:

```
1. MANUAL        — done by a human, not automated
2. REPETITIVE    — done over and over, not a novel problem each time
3. AUTOMATABLE   — could be done by a machine if someone built the automation
4. TACTICAL      — interrupt-driven, reactive work (vs. strategic, planned work)
5. NO LASTING VALUE — doing it again next week doesn't benefit from having done it this week
6. SCALES WITH LOAD — the more services/users/traffic, the more toil
```

**The key test:** Does this work grow linearly with service scale?
If you triple the number of services you manage and your toil triples,
that's real toil. If you triple services but the work stays the same,
it's not toil (it's overhead that doesn't scale, which is fine).

---

## Toil vs. Overhead vs. Engineering Work

```
┌──────────────────────────────────────────────────────────────────┐
│ TOIL                                                             │
│ Manual, repetitive, automatable, scales with service count.      │
│ Examples:                                                        │
│   - Manually restarting pods every Monday (OOM leak)             │
│   - Copy-pasting deployment configs for each new service         │
│   - Manually checking cert expiry dates every 2 weeks            │
│   - Responding to the same "is the service down?" Slack ping     │
│     every time the dashboard is slow                             │
├──────────────────────────────────────────────────────────────────┤
│ OVERHEAD                                                         │
│ Necessary organizational work. Doesn't scale with service count. │
│ Acceptable in small doses.                                       │
│ Examples:                                                        │
│   - Weekly team standup                                          │
│   - Quarterly performance reviews                               │
│   - Writing postmortems (necessary, but doesn't grow linearly)   │
├──────────────────────────────────────────────────────────────────┤
│ ENGINEERING WORK                                                 │
│ Reduces future toil or overhead. Creates lasting value.          │
│ This is what SREs should be spending at least 50% of time on.   │
│ Examples:                                                        │
│   - Building the automation that eliminates the manual restart  │
│   - Writing the Terraform module that eliminates config copying  │
│   - Building the synthetic cert-expiry check                    │
└──────────────────────────────────────────────────────────────────┘
```

---

## Identifying Toil: The Practical Methods

### Method 1: The Toil Audit

At the start of each sprint, every SRE answers:
> "What did you do last sprint that you would describe as repetitive,
>  manual, and should probably be automated?"

Collect the answers in a shared doc. Patterns emerge quickly:
- If three engineers independently mention "manually updating cert expiry tickets," that's toil.
- If one engineer mentions it, it might be a one-off; if everyone mentions it, it's systemic.

### Method 2: Interrupt Tracking

Toil often comes in as interrupts — ad hoc requests, pings, alerts that require
manual action. Track interrupts for one sprint:

```
Each time you are interrupted to do something repetitive, log it:
  Date | What was requested | Time spent | Is this automatable? | How often does this occur?

After 2 weeks:
  - Sort by frequency
  - Sort by time spent
  - The highest entries are your highest-value toil targets
```

### Method 3: On-Call Shadow

The on-call rotation is toil-dense. An SRE who rarely takes on-call shifts
doesn't see the toil. Require every team member to:
- Take at least 1 on-call rotation per quarter
- Keep a toil log during the rotation
- Bring the log to the next team meeting

This surfaces toil that is normalized by the regular on-call engineers.

---

## Toil Categories in SRE

```
Category 1: MANUAL REMEDIATION ACTIONS
  Description: Humans executing fixes that machines could execute automatically.
  
  Examples:
    - Restarting a service when its health check fails (should be: liveness probe)
    - Clearing a Redis cache when deploys complete (should be: post-deploy hook)
    - Scaling up pods on Monday morning peak (should be: HPA schedule)
    - Acknowledging "known false positive" alerts 20 times per day
  
  Automation approach:
    - Kubernetes liveness/readiness probes for restarts
    - Deploy hooks for cache clearing
    - KEDA or HPA for scaling
    - Alert tuning to eliminate false positives at source

─────────────────────────────────────────────────────────────────

Category 2: MANUAL CONFIGURATION MANAGEMENT
  Description: Humans copying and modifying config files for new services.
  
  Examples:
    - Copy-pasting a Helm values.yaml for each new microservice
    - Manually creating Datadog/Dynatrace dashboards for each service
    - Manually adding new services to the PagerDuty escalation policy
    - Manually creating Jira project boards for new teams
  
  Automation approach:
    - Service scaffolding scripts ("new-service" CLI tool)
    - Dashboard-as-code (Grafana/Dynatrace Terraform provider)
    - IaC for all infrastructure configuration
    - Service catalog with auto-provisioning

─────────────────────────────────────────────────────────────────

Category 3: MANUAL MONITORING AND CHECKING
  Description: Humans periodically checking things that machines should monitor.
  
  Examples:
    - Logging into the DB every Friday to check for long-running queries
    - Running df -h on servers weekly to check disk usage
    - Manually checking SSL cert expiry dates in a spreadsheet
    - Reading Kubernetes event logs daily for warning signs
  
  Automation approach:
    - Dynatrace anomaly detection for all of the above
    - Synthetic monitors for cert expiry
    - Automated disk usage alerts at 80%/90%

─────────────────────────────────────────────────────────────────

Category 4: MANUAL INCIDENT PROCESS STEPS
  Description: Repetitive procedural steps during incidents that could be automated.
  
  Examples:
    - Manually creating the #incident-XXXX Slack channel
    - Manually posting "I acknowledge this incident" in PagerDuty + Slack
    - Manually copying the incident template into Confluence
    - Manually sending the first stakeholder update
  
  Automation approach:
    - PagerDuty + Slack integration: auto-create channel on SEV1/2 declaration
    - Incident template bot: pre-populate the Confluence page on incident creation
    - Auto-post initial "investigating" status page update

─────────────────────────────────────────────────────────────────

Category 5: TICKET ADMINISTRATION TOIL
  Description: Repetitive Jira/ticket management that adds no value.
  
  Examples:
    - Manually moving tickets across sprint boards every Monday
    - Manually adding labels to every postmortem action item
    - Manually updating ticket status to match what Git branches say
  
  Automation approach:
    - Jira automation rules for label assignment
    - GitHub → Jira integration: move tickets automatically on PR merge
    - Sprint planning templates that pre-configure the board
```

---

## The 50% Rule: Enforcing It

Google's SRE book says: SREs should spend no more than 50% of time on toil.
The other 50% must be engineering work that permanently reduces future toil
or improves reliability.

**How to measure:**

```
Each sprint, each SRE categorizes their work:

  TOIL / INTERRUPT WORK:
    [3h] Manual pod restarts due to OOM leak
    [2h] Responding to false positive alerts
    [1h] Manual cert rotation for three services
    [1h] Manually creating incident Slack channels
    Total toil: 7 hours

  ENGINEERING WORK:
    [4h] Writing liveness probe to replace manual pod restarts
    [3h] Tuning alert thresholds to reduce false positives
    [2h] Building cert rotation automation
    Total engineering: 9 hours

  OVERHEAD:
    [2h] Meetings, standups, postmortems
    Total overhead: 2 hours

  TOTAL: 18 hours
  Toil %: 7/16 (excl. overhead) = 44% ← Acceptable (target: < 50%)
```

**When toil exceeds 50%:**
This is an escalation signal, not just a personal observation.

```
SRE to manager:
"Our team toil rate is 65% this sprint. We cannot sustainably operate at this level.
The top drivers are: [list top 3 toil sources].
To get below 50%, we need either: (a) 2 sprints to build automation for these toil
sources, or (b) to transfer some services to teams with spare capacity."

Without this conversation, toil grows until engineers burn out and leave.
Burnout, not workload itself, is the actual risk — because replacing experienced
on-call engineers takes 6–12 months.
```

---

## Toil Reduction Project: Example End-to-End

**Toil identified:** Manual pod restarts when payment-service memory usage grows.
On-call is paged 3× per week at 2 AM to run `kubectl rollout restart`.

**Step 1: Quantify the toil**
```
Frequency: 3× per week
Time per occurrence: 15 minutes (wake up, log in, diagnose, restart, verify)
Annual toil: 3 × 52 × 15 min = 2,340 minutes = 39 hours/year per on-call engineer
Plus: sleep disruption (unquantifiable but real)
```

**Step 2: Design the automation**
```
Option A: Kubernetes liveness probe
  - Kubernetes restarts the pod automatically when the probe fails
  - No human involved
  - Implementation: 30 minutes

Option B: VPA (Vertical Pod Autoscaler)
  - Automatically increases memory limit when usage grows
  - Addresses root cause (insufficient memory limit)
  - Implementation: 2 hours + testing

Chosen: Option A as immediate fix, Option B as root cause fix.
```

**Step 3: Implement and deploy**
```yaml
# Added to payment-service deployment.yaml

livenessProbe:
  httpGet:
    path: /health
    port: 8080
  initialDelaySeconds: 30
  periodSeconds: 10
  failureThreshold: 3   # restart after 3 consecutive failures
  timeoutSeconds: 5

readinessProbe:
  httpGet:
    path: /ready
    port: 8080
  initialDelaySeconds: 10
  periodSeconds: 5
  failureThreshold: 2   # remove from load balancer after 2 consecutive failures
```

**Step 4: Measure the outcome**
```
Before: 3 manual restarts/week, 15 min each = 45 min/week of on-call toil
After:  0 manual restarts/week (Kubernetes handles it)
        Pod downtime per auto-restart: ~30 seconds (vs. 15+ minutes manual)
        
Toil eliminated: 45 min/week = 39 hours/year
On-call sleep disruptions: 0 (previously 3×/week)
User impact of auto-restart: ~30 seconds (previously 15+ minutes)

ROI: 30-minute implementation eliminated 39 hours/year of toil.
```

---

## Toil Reduction Roadmap Template

```
Quarter 1 — Quick wins (< 4 hours each)
  [ ] Liveness probe: payment-service memory restart toil
  [ ] Alert threshold tuning: eliminate top 5 false positive alerts
  [ ] Cert expiry: add synthetic monitoring for all 12 services

Quarter 2 — Medium automation (1–3 days each)
  [ ] Service scaffolding CLI: new-service command generates Helm chart + Dynatrace dashboard
  [ ] Incident channel bot: PagerDuty → Slack auto-creates #incident-XXX channel
  [ ] Post-deploy hook: automated cache clear for 4 services

Quarter 3 — Systemic changes (weeks each)
  [ ] HPA for all stateless services (eliminate morning scale-up toil)
  [ ] Terraform for all Dynatrace configuration (eliminate click-ops)
  [ ] On-call runbook coverage: document and automate top 10 on-call actions

Target: reduce team toil from 65% → 35% by end of Q3.
```
