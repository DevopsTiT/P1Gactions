# Part 8 — Action Item Lifecycle: Deep Dive

---

## Why Action Items Die

The postmortem meeting feels productive. A list of actions is created.
Six months later, the same incident happens again. Everyone says "didn't we
already postmortem this?" — and yes, you did, but the action items were never completed.

This is the most common failure mode of SRE postmortem processes.
The root cause of THIS failure is always one of:

```
1. No ticket created   → "We discussed it but didn't track it anywhere"
2. No owner named      → "The team" owns it = nobody owns it
3. No due date         → "We'll get to it" = we won't
4. No review process   → Nobody checked whether it was done
5. Deprioritized       → Product backlog ate it; no SRE advocate to defend it
6. Owner left the team → Work stopped but nobody noticed
```

A strong action item process closes all six of these failure modes.

---

## The Action Item Standard

Every action item from a postmortem must have ALL of the following:

```
┌──────────────────────────────────────────────────────────────────┐
│ 1. DESCRIPTION                                                   │
│    One sentence. What specifically will be built/changed/added?  │
│    BAD:  "Improve monitoring"                                    │
│    GOOD: "Add Dynatrace alert for DB connection pool > 80%       │
│           utilization for 2+ consecutive minutes"                │
├──────────────────────────────────────────────────────────────────┤
│ 2. OWNER                                                         │
│    A named individual, not a team.                               │
│    BAD:  "Platform team"                                         │
│    GOOD: "Bob Kumar"                                             │
├──────────────────────────────────────────────────────────────────┤
│ 3. PRIORITY                                                      │
│    P1 / P2 / P3 — see definitions below                         │
├──────────────────────────────────────────────────────────────────┤
│ 4. DUE DATE                                                      │
│    A specific calendar date, not a sprint or quarter.            │
│    BAD:  "Q3"                                                    │
│    GOOD: "2026-08-07"                                            │
├──────────────────────────────────────────────────────────────────┤
│ 5. JIRA TICKET ID                                                │
│    Linked to the postmortem Confluence page.                     │
│    Labeled: postmortem-action, incident-YYYY-MMDD-NNN            │
│    Without a ticket, it does not exist.                         │
├──────────────────────────────────────────────────────────────────┤
│ 6. POSTMORTEM LINK                                               │
│    The Jira ticket links back to the postmortem that created it. │
│    Why: when someone asks "why was this work requested?" the     │
│    answer is one click away.                                     │
└──────────────────────────────────────────────────────────────────┘
```

---

## Priority Definitions

These definitions must be team-agreed, written down, and applied consistently.
Without definitions, everyone uses P1 for everything.

```
P1 — CRITICAL
   Definition: Without this action item completed, this exact incident
               CAN and WILL recur. The system has a known unfixed hole.
   
   Test: "If tomorrow's deploy has the same type of bug, will we catch it?"
         If no → P1.
   
   Expected completion: Within 1 week.
   
   Who reviews: SRE lead verifies completion. Not just "ticket closed."
   
   Example: "Add DB connection pool alert" — without this, next pool
            exhaustion is detected only after users see errors.

P2 — HIGH
   Definition: Without this action item, a similar incident is likely
               to happen within the next 3–6 months.
   
   Test: "Does this systemic gap still exist in our codebase/process?"
         If yes, and similar patterns exist → P2.
   
   Expected completion: Within 1 month.
   
   Example: "Implement canary deployment" — we got lucky this time;
            the next bad deploy will also affect 100% of traffic.

P3 — MEDIUM
   Definition: This improves reliability or reduces blast radius but
               the incident is unlikely to recur soon.
   
   Test: "Would skipping this increase our risk meaningfully?"
         If not immediately → P3.
   
   Expected completion: Within the quarter.
   
   Example: "Scale staging dataset to match production" — this is a
            quality improvement but the current risk is low because
            we'll now have the query performance check in CI (PA-103).
```

---

## The Jira Action Item Ticket Template

```
Title: [Postmortem Action] Add DB connection pool saturation alert

Type: Task
Priority: High (P1)
Labels: postmortem-action, incident-2026-0731-001
Assignee: Bob Kumar
Due Date: 2026-08-07
Linked to: [Postmortem Confluence page URL]

Description:
  Context:
    During the 2026-07-31 SEV2 payment service incident, the DB connection
    pool reached 100% utilization at 14:02:47 UTC. This was detected only
    when user-facing errors appeared at 14:03:00 UTC — a 13-second lag.
    A pool utilization alert would have provided earlier warning.

  Action required:
    Configure a Dynatrace alert that fires when:
      - DB connection pool utilization exceeds 80% for 2+ consecutive minutes
      - Service: payment-service
      - Notification: PagerDuty (SEV3 priority — no immediate page, but visible)

  Definition of done:
    - Alert configured in Dynatrace (and in Terraform, committed to infra repo)
    - Alert tested by artificially raising pool utilization in staging
    - Alert fires within 2 minutes of pool crossing 80%
    - Alert linked to runbook: "DB connection pool remediation"

  Rollback: N/A (adding an alert has no rollback needed)
```

**Why "Definition of Done" matters:**
"Added the alert" is ambiguous. Was it tested? Does it fire correctly?
Is it codified in Terraform or is it a click-ops alert that will be lost
in the next Dynatrace tenant reset? A specific definition of done makes
the completion criteria unambiguous.

---

## The Action Item Review Cadence

### Weekly SRE Review (15 minutes)

Every week, the SRE team reviews the open action item backlog:

```
Agenda:
  1. How many P1 action items are open? (target: 0 overdue P1s)
  2. How many P2 action items are open? (target: < 3 overdue P2s)
  3. Any action items at risk of missing their due date?
     → Reassign or get engineering manager involved
  4. Any action items completed this week?
     → Verify done is actually done (not just ticket closed)
     → Update postmortem status

Questions to ask for each overdue item:
  "Is this blocked? What's needed to unblock it?"
  "Has the owner changed teams or left? Reassign."
  "Is this still relevant? (Sometimes the system changed and the fix is moot)"
```

### Monthly Reliability Review

A broader review connecting action items to outcomes:

```
Questions:
  1. Did any incidents this month repeat a type we've already postmortemed?
     → If yes: which action items were supposed to prevent this? Were they done?

  2. Error budget status: are we consuming budget faster or slower than last month?
     → If faster: which recurring issue is the driver?

  3. Action item completion rate: what % of P1/P2 items were completed on time?
     → Target: > 90% P1 on time, > 80% P2 on time

  4. Are there recurring themes across postmortems?
     → If DB-related incidents are 40% of all incidents, that's a systemic signal
     → Requires a reliability project, not just individual action items
```

---

## Action Item Completion: Verification Standards

"Done" is not when the ticket is marked closed. Done is when:

```
For an alert:
  - Alert exists in Dynatrace (or as Terraform code in the infra repo)
  - Alert was tested: manually triggered the condition in staging
  - Alert fires within the expected timeframe
  - Alert routes to the correct PagerDuty service

For a code fix:
  - Fix is deployed to production
  - The specific failure scenario has been tested in staging
  - A regression test exists in CI that would catch recurrence
  - The regression test is passing on main

For a process change:
  - New process is documented (Confluence / runbook)
  - Team has been trained (sync meeting or Loom recording)
  - Process has been followed at least once on a real incident/deploy

For an infrastructure change:
  - Change is in Terraform (not click-ops)
  - Change has been applied to staging and production
  - Change has been load-tested (if relevant)
```

---

## The Connection Between Action Items and Error Budget

Action items have a direct relationship with the error budget:

```
Month 1: Incident consumes 74% of error budget.
         Action items PA-101 through PA-103 created.
         PA-101, PA-102 completed within 1 week.
         PA-103 completed within 2 weeks.

Month 2: Similar code pattern deployed.
         CI catches the missing index → build fails → merge blocked.
         Pool saturation alert fires in staging during load test → team notified.
         Zero production incident.
         Error budget consumed this month: 0%.

Month 3: Canary deployment (PA-105) complete.
         Next bad deploy affects 5% of users, caught in 4 minutes, rolled back.
         Error budget consumed: 3% (vs. 74% before action items).
```

This is the mechanism by which postmortem action items directly improve
reliability metrics and protect the error budget.

---

## Escalation: When Action Items Don't Get Done

If action items are consistently not completed, this is a signal about
organizational priorities, not individual performance.

**Escalation path:**

```
Week 1: P1 overdue
  → SRE lead sends a reminder, checks for blockers

Week 2: P1 still overdue
  → SRE lead escalates to engineering manager
  → "This action item is blocking our reliability commitments.
     What needs to happen to get it prioritized this week?"

Week 3: P1 still overdue
  → Report at the monthly reliability review
  → Include in the error budget review: "Our error budget is at risk
     because we have X unresolved P1 postmortem action items"
  → Engineering director is now in the loop

The tool: error budget as leverage.
"We are not able to approve the next feature deployment sprint because
we have outstanding P1 reliability actions from last month's SEV1."
This is not a threat — it is SRE's contractual position when error budget is at risk.
```
