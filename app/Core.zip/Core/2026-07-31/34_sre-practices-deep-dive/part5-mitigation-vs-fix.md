# Part 5 — Mitigation vs. Fix vs. Root Cause Fix: Deep Dive

---

## The Three Layers of Response

Every incident has three distinct response layers. Confusing them is one of the
most common SRE mistakes — it causes teams to either close incidents too early
(before the real problem is fixed) or spend too long during an active incident
trying to fix the root cause when they should be mitigating.

```
┌──────────────────────────────────────────────────────────────────┐
│  LAYER 1: MITIGATION                                             │
│  Goal: Stop the bleeding. Get users back online. NOW.            │
│  Happens: During the incident                                    │
│  Time to execute: Minutes                                        │
│  Fixes root cause: Usually NO                                    │
│  Example: Rollback the deploy                                    │
├──────────────────────────────────────────────────────────────────┤
│  LAYER 2: FIX                                                    │
│  Goal: Resolve the immediate technical cause                     │
│  Happens: Same day or next day                                   │
│  Time to execute: Hours                                          │
│  Fixes root cause: Partially — addresses the trigger             │
│  Example: Add the missing DB index                               │
├──────────────────────────────────────────────────────────────────┤
│  LAYER 3: ROOT CAUSE FIX                                         │
│  Goal: Ensure this category of problem cannot recur              │
│  Happens: Days to weeks after the incident                       │
│  Time to execute: Days to weeks                                  │
│  Fixes root cause: YES                                           │
│  Example: Add query performance check to CI pipeline             │
└──────────────────────────────────────────────────────────────────┘
```

---

## Layer 1: Mitigation (During Incident)

**The only goal is speed.** A mitigation that works in 2 minutes beats a perfect
fix that takes 45 minutes. While users are seeing errors, every minute counts.

### The Mitigation Toolkit (in order of speed)

```
1. ROLLBACK — fastest and safest first option
   If the incident was triggered by a deployment:
     kubectl rollout undo deployment/<service> -n production
   
   Why it's the best first option:
   - Pre-tested: the previous version was already running in production
   - Fast: ~2 minutes in most Kubernetes setups
   - Reversible: if rollback makes things worse, you can roll forward again
   - Low risk: you're returning to a known-good state

2. FEATURE FLAG DISABLE — if you have feature flags
   Toggle off the new feature that's causing problems in LaunchDarkly/Unleash.
   Zero restart needed. Often sub-second. Requires the feature to be flag-gated.

3. SCALE UP — if the problem is resource exhaustion from traffic
   kubectl scale deployment/<service> --replicas=10 -n production
   Adds capacity without changing code. Only works if nodes have free resources.

4. CONFIG CHANGE — if the problem is a misconfiguration
   kubectl set env deployment/<service> DB_POOL_MAX=100 -n production
   Changes a config value and triggers a rolling restart.

5. RESTART — if the service is in a bad state (memory leak, stuck thread)
   kubectl rollout restart deployment/<service> -n production
   Clears in-memory state. Does NOT fix code bugs — they will come back.
   Use when you're sure the problem is transient state, not a persistent bug.

6. TRAFFIC SHIFT — route traffic away from the broken region/instance
   If using a load balancer or service mesh:
   - Remove the broken pods from the load balancer target group
   - Shift traffic to a healthy region via DNS change or load balancer weight
```

### Mitigation Decision Tree

```
Was there a recent deployment (< 2 hours)?
├── YES → Rollback first. Fast and safe.
└── NO  → Is it a resource exhaustion problem (CPU/memory/pool)?
           ├── YES → Scale up or increase limits
           └── NO  → Is the service in a stuck/unhealthy state?
                      ├── YES → Restart pods
                      └── NO  → Is traffic routed incorrectly?
                                 └── YES → Traffic shift
```

### Rules for Mitigation

```
Rule 1: Get IC approval before executing any mitigation.
  Never run kubectl rollout undo without telling the IC first.
  The IC needs to know, approve it, and ensure the Scribe logs it.

Rule 2: Prefer reversible mitigations.
  A rollback is reversible (you can roll forward).
  Deleting data is not reversible.
  Dropping a table is not reversible.
  If a mitigation is irreversible, it requires explicit IC sign-off AND
  a second engineer confirming.

Rule 3: One mitigation at a time.
  If you apply two changes simultaneously, you don't know which one helped.
  You also don't know which one caused the new problem if things get worse.

Rule 4: Verify the mitigation worked. Do not assume.
  After every mitigation:
  - Watch the error rate graph in Dynatrace for at least 2 minutes
  - Watch p99 latency return to baseline
  - Confirm with a synthetic check if available
  - Only then declare "mitigation successful"

Rule 5: Don't optimize during mitigation.
  The goal during an incident is to restore service, NOT to write perfect code.
  Do not say: "Let me fix the root cause properly rather than just rolling back."
  Fix it right after the incident. Restore it now.
```

---

## Layer 2: Fix (Post-Incident, Same Day / Next Day)

After the mitigation restores service, the incident is resolved — but the
underlying problem still exists. Layer 2 is the technical fix that addresses
the immediate trigger.

### Example Fixes (after the DB pool exhaustion incident)

```
Trigger:  Missing index on orders.user_id causing slow queries

Layer 2 fix actions:
  1. Write a database migration to add the index:
       CREATE INDEX CONCURRENTLY idx_orders_user_id ON orders(user_id);
     Note: CONCURRENTLY means the index is built without locking the table.
     This is safe to run on a live production database.

  2. Test the query with EXPLAIN ANALYZE:
       EXPLAIN ANALYZE SELECT * FROM orders WHERE user_id = 12345;
       Before index: Seq Scan on orders (cost=...) rows=1000000
       After index:  Index Scan using idx_orders_user_id (cost=...) rows=1

  3. Deploy the migration to production via the normal CI/CD pipeline.

  4. Verify query latency returns to < 50ms.
```

The Layer 2 fix resolves the immediate technical trigger. But the question
the 5 Whys asks is: **why was it possible for this bug to reach production?**
That's Layer 3.

---

## Layer 3: Root Cause Fix (Post-Incident, Days/Weeks — Action Items)

The root cause fix addresses the systemic gap that allowed the incident
to happen in the first place.

### Mapping Root Cause Fixes to Contributing Factors

```
Contributing Factor 1: No query performance test in CI
  Root Cause Fix: Add an automated EXPLAIN plan check to the CI pipeline
  Why: Every ORM query change gets tested for index usage before merge
  Jira ticket: PA-106, owner: DevOps, P3, due: 2026-09-01

Contributing Factor 2: DB connection pool too small for peak traffic
  Root Cause Fix: Right-size pool based on traffic analysis + load test
  Why: Pool should handle 3× current peak without exhaustion
  Jira ticket: PA-104, owner: Bob Kumar, P2, due: 2026-08-10

Contributing Factor 3: No canary deployment for payment-service
  Root Cause Fix: Implement canary (10% traffic) for all payment-service deploys
  Why: Next bad deploy hits 10% of users, not 100%
  Jira ticket: PA-105, owner: Alice Chen, P2, due: 2026-08-21

Contributing Factor 4: No DB connection pool saturation alert
  Root Cause Fix: Add Dynatrace alert when pool > 80% for 2+ minutes
  Why: Team detects pool exhaustion 10 minutes earlier (detection → mitigation faster)
  Jira ticket: PA-101, owner: Bob Kumar, P1, due: 2026-08-07
```

---

## The Critical Distinction: Mitigation is Not Resolution

A common mistake: **calling an incident resolved when only the mitigation is done**.

```
Timeline A (wrong):
  14:35 — Rollback deployed, error rate 0%
  14:35 — IC declares incident resolved
  15:00 — Team deploys the "fix" without the rollback
  15:03 — Incident reopens (same cause, same outcome)

Timeline B (correct):
  14:35 — Rollback deployed, error rate 0%
  14:35 — IC declares incident resolved (mitigation)
  14:36 — Postmortem scheduled for tomorrow
  14:37 — PA-101, PA-102, PA-103 Jira tickets created
  Next day — PA-103 completed: index added + regression test in CI
  Next day — PA-103 verified in staging: query takes 40ms (was 8s)
  Next day — Deploy the fix to production WITH THE CI REGRESSION TEST blocking bad queries
  The same incident cannot recur because the regression test would catch it in CI.
```

---

## How Long Should Mitigation Take?

**Goal: 80th percentile mitigation time < 15 minutes for SEV1/2**

If your team is consistently taking > 30 minutes to mitigate SEV1/2 incidents,
these are the most likely root causes:

```
Problem: No rollback mechanism
  Fix: Ensure every service can be rolled back to the previous version in < 5 minutes.
  This is an infrastructure requirement, not optional.

Problem: No runbook for common mitigation actions
  Fix: Write runbooks for the 5 most common mitigations.
  On-call should not be figuring out the kubectl syntax under pressure.

Problem: Access issues (on-call can't run kubectl in production)
  Fix: SRE on-call must have production access. This is non-negotiable.
  Access takes minutes to use; the approval process for access takes hours.

Problem: IC not assigned — everyone is random-walking
  Fix: First action on every bridge: assign IC.

Problem: Mitigation options are too complex
  Fix: Design systems for operability. A service that can only be fixed by
  understanding its internals is a service that will have long MTTR forever.
```
