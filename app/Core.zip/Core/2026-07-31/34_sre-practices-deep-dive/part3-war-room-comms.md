# Part 3 — War Room Setup and Stakeholder Communication: Deep Dive

---

## What This Is

The "war room" is the operational center of an incident — the shared space where the
response team coordinates. In modern distributed teams this is always a Slack channel
plus an optional video/voice bridge. The way you set it up, and how you communicate
during and after an incident, determines whether the team can work efficiently and
whether stakeholders trust you.

---

## Why Communication Structure Matters

During a high-stress incident, people default to chaos:
- Multiple Slack threads about the same incident in different channels
- Stakeholders pinging the on-call directly with "is this fixed yet?"
- Engineers typing updates that conflict with each other
- No one knows what the current status is because nobody wrote it down

A structured war room eliminates all of this by creating **one source of truth**.

---

## Setting Up the Slack War Room

### Channel Naming Convention

```
#incident-YYYY-MMDD-NNN

Examples:
  #incident-2026-0731-001   (first incident on July 31)
  #incident-2026-0731-002   (second incident same day)

Why a unique name per incident:
  - Easy to search history later
  - Clear when an old incident is resolved vs. a new one
  - Links to this channel in postmortems remain precise
```

### What to Pin Immediately (first 3 minutes)

```
Pin 1: Role assignments
  "IC: @alice | TL: @bob | CL: @carol | Scribe: @david"

Pin 2: Incident ticket link
  "Jira/PagerDuty: https://..."

Pin 3: Primary dashboard
  "Dynatrace: https://... (payment-service overview)"

Pin 4: Runbook
  "Runbook: https://confluence.../payment-service-degraded"

Pin 5: Severity
  "SEV2 — Payment service degraded — ~5% error rate — declared 14:03 UTC"
```

Pins let anyone who joins late immediately understand the current situation
without reading 100 messages of back-and-forth.

---

## The Two-Thread Rule

Keep the main channel signal-to-noise ratio high by enforcing two threads:

```
#incident-2026-0731-001 (main channel)
│
├── [PINNED] Roles, ticket, dashboard, runbook, severity
│
├── Thread: "📋 TIMELINE — scribe posts here only"
│   └── 14:03 UTC — alert fired
│   └── 14:05 UTC — IC/TL assigned
│   └── 14:08 UTC — hypothesis: DB pool
│   └── 14:12 UTC — CONFIRMED: pool 100%, 80 queries queuing
│   └── 14:15 UTC — mitigation: pool size increased to 100
│   └── 14:22 UTC — error rate dropping
│   └── 14:35 UTC — RESOLVED
│
├── Thread: "📢 STAKEHOLDER UPDATES — CL posts here only"
│   └── [UPDATE 1] 14:15 UTC — Investigating payment errors. ~5% failure rate. ETA unknown.
│   └── [UPDATE 2] 14:30 UTC — Root cause found. Fix in progress. ETA 15 min.
│   └── [RESOLVED] 14:38 UTC — Service restored. Postmortem within 72 hours.
│
└── Free-form technical discussion in the main thread
    (hypotheses, log snippets, metric screenshots)
```

Why two separate threads:
- Scribe can post frequently without polluting the stakeholder update thread
- Executives can read just the stakeholder thread and understand everything
- The timeline thread becomes the postmortem timeline with no extra work

---

## Stakeholder Update Template

Every stakeholder update must answer exactly four questions:

```
1. What is broken?     (the symptom, in non-technical language)
2. Who is affected?    (% of users, which feature, which region)
3. What are we doing?  (one sentence, active voice)
4. What's next?        (ETA or next update time)
```

**Bad update (what NOT to write):**
```
"We're looking into the DB connection pool issue. The ORM query introduced
in v2.14.3 is doing a full table scan on orders.user_id which is causing
the pool to fill up at peak traffic. We're going to increase the pool size
and then investigate adding an index."
```
Why it's bad: Too technical. Stakeholders don't know what "connection pool" or
"full table scan" means. No clear ETA. No user impact quantified.

**Good update:**
```
[UPDATE 2 — 14:30 UTC]
What's broken: Approximately 5% of checkout attempts are failing with an error.
Who is affected: Customers trying to complete a purchase. Other features are working.
What we're doing: We have identified the cause (a database performance issue from
today's deployment) and are applying a fix now.
Expected resolution: Within 15 minutes.
Next update: 14:45 UTC.
```

---

## Stakeholder Communication Cadence

| Severity | Update cadence during incident | First update deadline |
|----------|-------------------------------|----------------------|
| SEV1     | Every 15–20 minutes            | Within 10 minutes of declaration |
| SEV2     | Every 30 minutes               | Within 15 minutes of declaration |
| SEV3     | Only at resolution             | N/A                  |
| SEV4     | Not required                   | N/A                  |

**The cadence rule exists for a specific reason:**
If you don't provide updates on a schedule, stakeholders fill the silence with
their own worst-case assumptions. A stakeholder who hasn't heard anything for
45 minutes assumes it's still completely broken and starts escalating to VPs.
Regular updates — even "no new findings, still investigating" — keep the
temperature low and trust intact.

---

## Status Page Updates

The status page is the public face of your incident. It's read by:
- Enterprise customers who have SLA contracts
- Users trying to understand why the product isn't working
- Third parties who integrate with your APIs

### What to post

```
Incident created: "We are investigating reports of payment failures."
                  (post within 5 min of SEV1 declaration, 10 min of SEV2)

Identified:       "We have identified an issue with our payment processing
                   service. A fix is being deployed."

Monitoring:       "A fix has been deployed. We are monitoring to confirm
                   full resolution."

Resolved:         "This incident has been resolved. All services are
                   operating normally. We apologize for the inconvenience.
                   A full postmortem will be published within [X] hours."
```

### What NOT to post on the status page

- Technical details (DB pool sizes, query plans, k8s commands)
- Blame ("an engineer deployed broken code")
- Speculation ("we think it might be...")
- Internal names ("Bob is working on it")

The status page is for customers, not engineers.

---

## The "All Clear" Message

When the incident resolves, the CL sends a final message to all stakeholders.
This is distinct from the status page update — it goes to internal Slack channels,
email lists, and any stakeholders who were directly notified during the incident.

```
Subject: [RESOLVED] Payment service incident — 2026-07-31

At 14:35 UTC today, the payment service was fully restored after a 32-minute
degradation affecting approximately 5% of checkout attempts.

Impact summary:
  - Duration: 14:03–14:35 UTC (32 minutes)
  - ~15,000 checkout attempts failed with an error
  - No data was lost. Orders that failed were not charged.

What happened:
  A code deployment at 13:55 UTC introduced a slow database query that
  caused high load during the afternoon traffic peak.

What we're doing to prevent recurrence:
  - Adding a database performance alert (this week)
  - Adding a regression test for query performance (this week)
  - Full postmortem will be published within 72 hours

We apologize for the disruption.
— Payment Platform SRE Team
```

---

## Video Bridge Protocol

For SEV1 incidents, audio/video bridges are often more efficient than Slack for
rapid back-and-forth. Rules for bridges:

```
1. Only core roles on the bridge — IC, TL, CL. SMEs invited as needed.
   Everyone else follows in Slack.

2. IC moderates: only one person speaks at a time.
   "TL, what are you seeing?" — then TL speaks.

3. Scribe is still posting to Slack in real time.
   The bridge conversation is NOT the record — the Slack thread is.

4. No "thinking out loud" on the bridge. State facts and hypotheses clearly.
   Bad:  "uhh, I'm looking at the thing, let me just... hmm, wait..."
   Good: "DB pool is at 100%. Queuing 80 connections. Hypothesis: slow query."

5. When joining the bridge after initial setup, announce yourself:
   "This is Sarah joining as DB SME."
```

---

## Post-Resolution Channel Archiving

After an incident resolves, the Slack channel should be:
1. Left open for 72 hours (postmortem is being written, questions may come up)
2. Then archived (not deleted — archived channels are searchable forever)
3. Tagged with: `resolved`, `postmortem-link`, `severity-level`

The archive is your team's institutional memory. Six months from now,
when a similar incident happens, the first thing a good SRE does is:
> "Has this happened before? Let me search Slack for old incident channels."
