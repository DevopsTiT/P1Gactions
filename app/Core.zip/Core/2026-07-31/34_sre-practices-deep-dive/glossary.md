# 34 — SRE Practices Deep Dive: Glossary

Every term from all 12 parts, explained for an SRE beginner. One entry per term.

---

**SRE (Site Reliability Engineering)**
A discipline that applies software engineering thinking to infrastructure and operations. Treats reliability as a product feature, not an afterthought. Balances feature velocity (moving fast) against reliability (not breaking things) using data (SLOs/error budgets) instead of feelings.

**Incident**
Any unplanned event that disrupts or degrades service for users, or risks doing so soon. Not every alert is an incident. An alert that fires and auto-resolves in 30 seconds is not an incident. A service that is down for users for any meaningful duration is an incident.

**Severity Level (SEV1–SEV4)**
A classification of how bad an incident is. SEV1 = complete outage. SEV4 = no current impact but growing risk. Drives who is paged, how fast they respond, whether you post to the status page, and whether a postmortem is required.

**Incident Declaration**
The formal act of saying "this is now an incident." It triggers the full response process: opening a war room, assigning roles, starting stakeholder communication. Without explicit declaration, the team is in a grey zone where nobody is officially responsible.

**Incident Commander (IC)**
The single person in charge of an incident. Drives the process, assigns tasks, makes decisions. Does NOT debug personally — delegates all technical work so they can maintain the 10,000-foot view. First role assigned when an incident is declared.

**Technical Lead (TL)**
The engineer running the hands-on investigation during an incident. Forms hypotheses, tests them, executes approved fixes. One person at a time — having two TLs simultaneously creates conflicting changes and an unknown system state.

**Communications Lead (CL)**
The person writing stakeholder updates during an incident. Protects the IC and TL from communication interruptions. Without a CL, the TL gets pinged by 10 different Slack threads asking "what's happening?" and loses focus every 3 minutes.

**Scribe**
The person writing down everything that happens during an incident, with timestamps. Their log becomes the postmortem timeline. Without a scribe, the timeline must be reconstructed from memory after the fact — which is inaccurate.

**Subject Matter Expert (SME)**
An engineer with specialized knowledge called in during an incident when the TL hits the limits of their expertise. DB expert, network engineer, security engineer, etc. Called in by the IC as needed. One SME per domain at a time.

**War Room**
The shared operational space where all incident responders coordinate. In distributed teams: a Slack channel + optional video bridge. Named "war room" because it is the dedicated space for fighting the incident — everything else happens elsewhere.

**Slack Channel Naming Convention**
A consistent naming pattern for incident channels: `#incident-YYYY-MMDD-NNN`. The date and sequence number make channels unique and searchable. After the incident, the channel is archived (not deleted) so it remains part of institutional memory.

**Two-Thread Rule**
Keeping the incident Slack channel organized by having two threads: one for the scribe's real-time timeline log, one for stakeholder updates from the CL. Keeps technical chatter and external communication separate so each audience can read just what they need.

**Status Page**
A public webpage showing the current state of your service (Operational / Degraded / Outage). Read by customers and enterprise clients. Should be updated within 5–10 minutes of a SEV1/2 declaration. Never include technical details or speculation — only plain-language status.

**RED Method**
An investigation framework for service-level problems: Rate (request rate), Errors (error rate), Duration (latency). Check these three things first when a service is behaving badly. Answers "what is the service doing right now?" without random-walking through logs.

**USE Method**
An investigation framework for infrastructure-level problems: Utilization (how busy is the resource?), Saturation (is it queuing work?), Errors (are there resource-level errors?). Applied to CPU, memory, disk, network, connection pools. Answers "is any infrastructure resource the bottleneck?"

**Hypothesis**
A specific, testable claim about what is causing the incident. "The DB connection pool is exhausted because a slow query is holding connections." Good hypotheses are specific enough to be confirmed or refuted by checking a specific metric. "Something is wrong with the database" is not a hypothesis.

**Change Correlation**
The practice of asking "what changed in the last 2 hours?" as the first investigation step. 80% of production incidents are caused by a recent change: a deployment, config update, infrastructure change, or traffic pattern shift. Checking this first saves enormous time.

**Mitigation**
An action taken during an incident to stop or reduce user impact, even if it does not fix the root cause. Rollback, pod restart, traffic re-routing, scaling up. Speed is the priority — imperfect mitigation in 2 minutes beats perfect root cause fix in 45 minutes.

**Rollback**
Reverting to the previous version of a service after a bad deployment. In Kubernetes: `kubectl rollout undo`. Fast, reliable, safe. The pre-existing image is already in the cluster. Best first mitigation option when the incident correlates with a recent deploy.

**Blast Radius**
The scope of damage when something fails — how many users are affected. Reducing blast radius is a key reliability engineering goal. Canary deployments reduce blast radius of bad deploys. Circuit breakers reduce blast radius of cascading failures.

**Root Cause Analysis (RCA)**
The process of tracing an incident back to the deepest systemic cause — not just "what triggered it" but "why was it possible for this trigger to exist?" A good RCA identifies fixes that prevent recurrence, not just fixes that address the symptom.

**5 Whys**
An RCA technique: repeatedly ask "why?" starting from the symptom until you reach a systemic cause. Named for the observation that 5 levels of "why?" often reaches the process/organizational root cause. The fix for Why 5 prevents recurrence; the fix for Why 1 just masks the symptom.

**Fishbone Diagram (Ishikawa Diagram)**
A visual RCA tool that organizes causes into categories (People, Process, Technology, Measurements, Materials, Environment). Used when an incident has multiple interacting causes from different domains. Prevents the team from fixating on one type of cause.

**Swiss Cheese Model**
James Reason's accident model: each layer of defense has holes. An incident happens when the holes line up (bug slips past code review → CI → canary → monitoring). Fixing one hole (one person's mistake) leaves all other holes open. Fix the system, not the person.

**Blameless Postmortem**
A postmortem written with the principle that humans make mistakes when systems put them in difficult positions — so the analysis focuses on fixing system gaps, not punishing individuals. Blameless culture improves incident reporting and organizational learning.

**Contributing Factor**
A condition that made an incident more likely or more severe but was not the sole root cause. "No canary deployment" is a contributing factor — it didn't cause the bug, but it meant 100% of users were affected instead of 5%.

**Postmortem Timeline**
A precise, timestamped record of every relevant event during an incident — what the system did and what the team did. Built from Dynatrace graphs, PagerDuty logs, Kubernetes events, and the Scribe's notes. The foundation of any RCA.

**Action Item**
A specific task created from a postmortem to prevent recurrence. Must have: description, named owner, priority (P1/P2/P3), due date, Jira ticket. Without all five, it will not be completed. "The team will improve monitoring" is not an action item.

**P1/P2/P3 Priority**
P1 = this exact incident can recur without this fix (due within 1 week). P2 = a similar incident is likely without this fix (due within 1 month). P3 = quality improvement, low recurrence risk (due within the quarter).

**Definition of Done**
The specific, testable criteria that must be met for an action item to be considered complete. "Alert added" is not done. "Alert configured in Terraform, tested in staging, verified to fire within 2 minutes of threshold breach" is done.

**SLI (Service Level Indicator)**
The actual measured metric an SLO is based on. Example: "percentage of HTTP requests returning 200 within 500ms." Must measure what users actually experience, not infrastructure metrics like CPU utilization.

**SLO (Service Level Objective)**
An internal reliability target: "99.9% of requests succeed over 30 days." The SRE team holds itself to this. SLOs drive error budget calculations and the negotiation between feature velocity and reliability investment.

**SLA (Service Level Agreement)**
A contractual promise to customers, typically with financial consequences for breach. SLA targets are always looser than SLO targets — the SLO is the team's internal stretch goal; the SLA is the floor below which customers get credits.

**Error Budget**
The amount of unreliability an SLO allows. 99.9% availability = 43.2 minutes of downtime per 30 days. This budget is the shared resource between the SRE team (reliability) and the product team (feature velocity). When it's exhausted, risky feature work stops.

**Burn Rate**
The speed at which the error budget is being consumed. Normal = 1× (consuming at exactly the sustainable rate). During an incident at 5% error rate = 50× (50 times faster than sustainable). Burn rate alerting catches problems faster than budget percentage thresholds.

**Multi-Window SLO**
Using multiple time windows (1 hour, 6 hours, 30 days) to detect problems at different timescales. Short window = detect active incidents fast. Medium window = catch sustained degradation. Long window = monthly reliability review.

**Toil**
Manual, repetitive, automatable work that scales with service size and adds no lasting value. Restarting pods every Monday, manually rotating certs, copy-pasting deployment configs. Google's SRE book says toil should be < 50% of an SRE's time.

**50% Rule**
Google's SRE guideline: SREs must spend no more than 50% of their time on toil. The other 50% must be engineering work that permanently reduces future toil or improves reliability. Enforcing this prevents operations from consuming the entire team capacity.

**Interrupt Tracking**
A method of identifying toil: logging every time you are interrupted to do something repetitive, noting what it was, how long it took, and whether it was automatable. After 2 weeks, patterns reveal the highest-value toil reduction targets.

**Liveness Probe**
A Kubernetes health check that restarts a pod when it fails. Configured in the deployment spec with a path, timeout, and failure threshold. Replaces toil like "manually restart pods when they enter a bad state." When the probe fails 3 consecutive times, Kubernetes kills and restarts the pod automatically.

**Readiness Probe**
A Kubernetes health check that removes a pod from the load balancer when it fails, without restarting it. Used during startup (pod not ready yet) or when a pod is in a degraded state that doesn't warrant a restart. Prevents traffic from reaching unhealthy pods.

**Playbook**
A high-level guide for a category of incidents or a service's common failure modes. Answers: "what kind of problem is this, and who/what runbook handles it?" 1–2 pages. Links to dashboards, escalation contacts, and specific runbooks for each sub-type.

**Runbook**
A step-by-step procedure for one specific operational task. Every step has an exact command, expected output, and decision branch for unexpected output. Used by TLs during incidents. Must include a rollback section. Must be tested and updated after every incident that uses it.

**On-Call Handoff**
A structured summary message transferred from the outgoing to incoming on-call engineer at the start of each shift. Covers: active incidents, recent incidents, things to watch, upcoming risks, team availability. Without it, the new on-call starts every shift blind.

**On-Call Rotation**
The schedule distributing who is on-call during each time window. Healthy rotations distribute burden evenly. Pages per person per rotation is a key health metric. > 10 actionable pages per shift = either too much noise or an unreliable service that needs a reliability project.

**Alert Accuracy**
The percentage of pages that required actual human action. Target: > 70%. If < 70%, the team is being paged for false positives — which causes alert fatigue (ignoring alerts becomes a habit). Improving alert accuracy is a toil reduction project.

**Chaos Engineering**
The practice of deliberately injecting failures (pod crashes, network delays, dependency outages) into a system in a controlled way to verify that the system handles them correctly. Finds resilience gaps before real incidents do.

**LitmusChaos**
An open-source Kubernetes-native chaos engineering platform. Runs experiments (pod-delete, cpu-hog, network-latency) as Kubernetes Custom Resources (ChaosEngine). Results are stored as ChaosResult objects.

**Steady State**
The healthy baseline of a system before a chaos experiment. Defined by metrics: e.g., "error rate < 0.1%, p99 latency < 200ms." After injecting a failure, you observe whether the system returns to steady state. If it doesn't, a resilience problem was found.

**Abort Criteria**
Pre-defined conditions that immediately stop a chaos experiment. Example: "if error rate in any unrelated service exceeds 2%, stop the experiment." Prevents a controlled experiment from becoming an uncontrolled incident.

**MTTA (Mean Time to Acknowledge)**
Average time from when an alert fires to when an on-call engineer acknowledges it. Measures how responsive the on-call rotation is. Target for SEV1/2: < 5 minutes. Long MTTA = either on-call isn't reachable or the alert is buried in noise.

**MTTR (Mean Time to Resolve)**
Average time from incident start to service restoration. Lower is better. Improved by: fast detection (good alerts), fast diagnosis (runbooks, RED/USE methods), fast mitigation (rollback capability). The headline SRE response metric.

**MTTD (Mean Time to Detect)**
Average time from when a problem starts to when an alert fires. Improved by: lower alert thresholds, synthetic monitoring, burn rate alerting. Silent user impact before detection is the gap MTTD measures.

**Quarterly SLO Review**
A periodic review of whether SLO targets are still appropriate. Tighten SLOs that are never threatened (targets too loose). Loosen SLOs that are constantly breached and causing fatigue (targets too tight). Verify that each SLI still measures what users actually experience.

**Chaos Hypothesis**
A specific, testable prediction about system behavior under failure: "If auth-service goes down, payment-service returns HTTP 503 within 5 seconds." The chaos experiment either confirms or refutes it. A refuted hypothesis reveals a resilience gap.

**kubectl rollout undo**
The Kubernetes command to revert a deployment to its previous version. The fastest mitigation for deployment-caused incidents. Pre-existing image is already in the cluster registry — no download needed.

**kubectl set env**
A Kubernetes command that changes an environment variable in a running deployment, triggering a rolling restart of pods with the new config. Used to change config values (like DB_POOL_MAX) without redeploying the container image.

**kubectl drain**
Marks a Kubernetes node as unschedulable AND moves all pods off it gracefully (respecting PodDisruptionBudgets). Used to take a node out of service for maintenance or when a node is misbehaving. More thorough than `kubectl cordon` (which only stops new pods, doesn't move existing ones).

**HPA (Horizontal Pod Autoscaler)**
A Kubernetes controller that automatically increases or decreases pod count based on CPU/memory metrics or custom metrics. Replaces the toil of manually scaling pods during traffic spikes. Only works if nodes have free capacity to schedule new pods onto.

**`watch` command**
A Linux utility that re-runs a command on a schedule and displays the output. `watch -n 5 "kubectl get pods"` refreshes pod status every 5 seconds. Essential for monitoring pod restarts and rollout progress during incident mitigation.

**`jq`**
A command-line JSON processor. Used to parse and filter JSON responses from Kubernetes, Dynatrace, PagerDuty, and Jira APIs. Essential for working with these APIs from the command line without writing full scripts.

**`python3 -c`**
Runs a Python expression directly in the terminal without creating a file. Used for quick calculations (error budget arithmetic) that are too complex for `bc` (basic calculator) but too simple to warrant a full script.

**`grep -cE`**
Counts the number of lines in input that match a pattern. `-c` = count. `-E` = extended regex (for patterns with `|` alternation). Used to count error log lines per minute during incident investigation.
