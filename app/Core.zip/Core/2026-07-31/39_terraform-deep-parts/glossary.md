# Terraform Deep Dive — Glossary

All new terms introduced across parts 1–8, explained for an SRE beginner.

---

**State Reconciliation Engine**
The concept at the heart of Terraform — it continuously compares what you *want* (your `.tf` files) against what *exists* (the real cloud) and takes the minimum actions to close the gap. Like a thermostat: you set a target temperature, it figures out whether to heat or cool.

**Dependency Graph**
Terraform's internal map of which resources depend on which others. If resource B references resource A's ID, Terraform knows to create A first. Built automatically from resource references — you rarely need to manage it manually.

**`depends_on`**
An explicit dependency declaration. Used when resource B must wait for resource A, but B doesn't directly reference A's attributes. Terraform can't infer this dependency on its own.

**Immutable Attribute**
A cloud resource property that cannot be changed in place — changing it requires destroying the old resource and creating a new one. Example: an EC2 instance's AMI or availability zone. In Terraform plan, shows as `-/+` (destroy + create). Data loss risk for stateful resources.

**Mutable Attribute**
A cloud resource property that can be updated in place without recreation. Example: EC2 tags, instance type (for stopped instances). Shows as `~` in Terraform plan.

**`-/+` in Plan Output**
The symbol combination in `terraform plan` that means "replace" — Terraform will destroy the existing resource and create a new one. Dangerous for stateful resources (databases, storage) because the old data is gone unless you have backups.

**`~` in Plan Output**
Means "update in place" — the resource will be modified without destroying it. Generally safe.

**`+` in Plan Output**
Means "create" — a new resource will be added.

**`-` in Plan Output**
Means "destroy" — the resource will be removed from the cloud. Always read `-` lines carefully before applying.

**`(known after apply)`**
Appears in plan output for attributes that the cloud will only assign after the resource is created — like an EC2 instance ID or public IP. Terraform shows this as a placeholder during planning.

**Splat Expression (`[*]`)**
Shorthand in HCL for "get this attribute from every item in the list." `aws_instance.workers[*].id` is equivalent to `[for w in aws_instance.workers : w.id]`.

**For Expression**
A loop expression in HCL that transforms lists or maps. Like a map/filter operation in programming. `[for n in names : upper(n)]` produces an uppercase version of every item.

**Dynamic Block**
A way to generate repeated nested blocks inside a resource using `for_each`. Used when the number of blocks (e.g. security group rules, ingress entries) is variable and comes from an input.

**`each.key` / `each.value`**
Inside a `for_each` block, `each.key` is the current map key (or set item), and `each.value` is the current map value. How you reference per-item data when creating multiple resources.

**`count.index`**
Inside a `count` block, the zero-based index of the current resource copy. `count.index = 0` for the first copy, `1` for the second, etc.

**Index Shifting**
The dangerous behavior of `count` when you remove an item from the middle of a list — all subsequent items get their index decreased by 1, causing Terraform to destroy and recreate them at new addresses. Avoidable by using `for_each` with stable map keys instead.

**`toset()`**
A Terraform function that converts a list to a set (removing duplicates). Used when passing a list of strings to `for_each`, because `for_each` requires a set or map, not a list.

**`values()`**
A Terraform function that extracts the values of a map as a list. Used when you have a `for_each` map and need a plain list of the resulting resources' attributes.

**`merge()`**
A Terraform function that combines two or more maps into one. If both maps have the same key, the later map's value wins. Commonly used to merge common tags with resource-specific tags.

**`cidrsubnet()`**
A built-in Terraform function that calculates a sub-CIDR from a parent CIDR. Takes the parent CIDR, how many bits to add for the subnet prefix, and which subnet number to return. Eliminates hardcoding subnet ranges.

**`can()`**
A Terraform function that returns `true` if an expression evaluates without error, `false` otherwise. Used in validation blocks to check if a value matches a pattern.

**`regex()`**
A Terraform function that applies a regular expression to a string. Returns the match or throws an error if no match. Often wrapped in `can()` for validation.

**Provider Version Constraint**
A rule specifying which versions of a provider are acceptable. `~> 5.0` means "any 5.x version but not 6.0." Prevents surprise breaking changes when HashiCorp releases new provider versions.

**`terraform init -upgrade`**
Re-runs initialization and upgrades providers and modules to the newest version allowed by your version constraints. Updates `.terraform.lock.hcl` with new hashes.

**`terraform init -migrate-state`**
Re-runs initialization and moves existing local state to a newly configured remote backend. Used when adding a remote backend to an existing project for the first time.

**`-input=false`**
A flag for `terraform init`, `plan`, and `apply` that disables interactive prompts. Required in CI/CD pipelines where there is no human to answer prompts — the command fails instead of hanging.

**`-no-color`**
A flag that removes ANSI color codes from Terraform output. Used in CI/CD because color codes make log output hard to read in plain-text systems.

**`-detailed-exitcode`**
A flag for `terraform plan` that changes exit code behavior: 0 = success no changes, 1 = error, 2 = success with changes. Used in CI/CD scripts to detect drift programmatically.

**`-refresh-only`**
A plan or apply mode that updates the state file to match current cloud reality WITHOUT proposing any infrastructure changes. Used for drift detection or syncing state after manual changes you want to keep.

**OIDC (OpenID Connect)**
An authentication protocol that lets CI/CD systems like GitHub Actions prove their identity to AWS without storing static credentials. GitHub's runner gets a short-lived token from GitHub's identity provider; AWS verifies it and issues temporary AWS credentials. No secrets stored anywhere.

**`sts:AssumeRoleWithWebIdentity`**
The AWS API call that exchanges an OIDC token for temporary AWS credentials. This is what happens behind the scenes when GitHub Actions authenticates to AWS via OIDC.

**AdministratorAccess**
An AWS IAM policy that grants full permission to do anything. Never give this to a Terraform IAM role — use least-privilege policies scoped to only the services Terraform needs to manage.

**Least Privilege**
The security principle of giving a process only the exact permissions it needs and nothing more. A Terraform role managing EC2 and RDS doesn't need S3 permissions unrelated to state storage.

**`random_password` resource**
A Terraform resource (from the `hashicorp/random` provider) that generates a cryptographically random string. Used to generate database passwords, API keys, etc. at plan time. The result is stored in state.

**`aws_secretsmanager_secret_version`**
An AWS Secrets Manager resource that stores a specific version of a secret's value. Can be used as both a `resource` (to create/store a secret) and a `data` source (to read an existing secret).

**`jsonencode()`**
A Terraform function that converts an HCL object/map into a JSON string. Used when an AWS resource (like an IAM policy) expects its value as a JSON string rather than an HCL block.

**Plan Artifact**
The saved `tfplan` binary file produced by `terraform plan -out=tfplan`. Passed between CI/CD pipeline stages so the apply stage executes exactly the plan that was reviewed, not a re-plan.

**GitHub Environment**
A GitHub Actions feature that can require manual approval before a job runs. Used to gate production Terraform applies — a human must explicitly approve before the pipeline applies to prod.

**Cron Schedule (in CI/CD)**
A time-based trigger for CI/CD pipelines. `cron: "0 */6 * * *"` means "run every 6 hours." Used for drift detection jobs that need to run regularly without a code change to trigger them.

**`terraform_remote_state` data source**
A Terraform data source that reads outputs from another Terraform project's state file. Allows separate Terraform configurations to share data (e.g., one project creates a VPC and exports its ID; another project reads that ID to place resources in it).

**State Versioning (S3)**
The S3 feature that keeps every previous version of an object. When applied to a Terraform state file, every `terraform apply` creates a new version. Old versions can be retrieved for rollback or forensic investigation.

**`terraform state push`**
A command that uploads a local state file to the remote backend, overwriting the current remote state. Emergency recovery tool — used to restore a previous state version. Bypasses all safety checks; use only in emergencies.

**Thumbprint (OIDC)**
A hash of the OIDC provider's SSL certificate. Required when registering an OIDC provider in AWS IAM — proves the certificate hasn't changed and the connection is legitimate. GitHub's thumbprint is a well-known public value.
