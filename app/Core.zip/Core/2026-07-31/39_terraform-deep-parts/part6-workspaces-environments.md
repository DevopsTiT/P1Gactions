# Part 6 — Workspaces & Multi-Environment Patterns: Deep Dive

---

## The Core Problem: Same Code, Different Environments

You have one set of infrastructure code. You need it deployed three ways:
- **dev** — 1 instance, t3.micro, no HA, cheap
- **staging** — 2 instances, t3.small, basic HA
- **production** — 5 instances, t3.large, full HA, Multi-AZ

Two approaches solve this. They have very different failure modes.

---

## Approach 1: Workspaces

### What a Workspace Is

A workspace is a **named slot for a separate state file** within the same directory and code.

```
Directory: infra/
├── main.tf
├── variables.tf
├── backend.tf       ← S3 backend configured
└── terraform.tfvars ← default values

State in S3 bucket:
  env:/dev/infra/terraform.tfstate        ← workspace "dev"
  env:/staging/infra/terraform.tfstate    ← workspace "staging"
  production/infra/terraform.tfstate      ← workspace "default" (no env: prefix)
```

Workspaces share the same `.tf` code but maintain completely separate state.

### Workspace Commands

```bash
# See all workspaces (* marks the current one)
terraform workspace list
#   default
# * dev
#   staging
#   production

# Show current workspace
terraform workspace show
# dev

# Create and switch to a new workspace
terraform workspace new staging
terraform workspace new production

# Switch to existing workspace
terraform workspace select production

# Now every terraform command acts on production state
terraform plan    # plans for production
terraform apply   # applies to production

# Delete a workspace (must switch away first, workspace must be empty)
terraform workspace select default
terraform workspace delete dev
```

### Using Workspace Name in `.tf` Code

The magic variable `terraform.workspace` returns the current workspace name as a string:

```hcl
locals {
  # Map workspace name to config values
  env_config = {
    dev = {
      instance_type    = "t3.micro"
      instance_count   = 1
      enable_multi_az  = false
      retention_days   = 7
    }
    staging = {
      instance_type    = "t3.small"
      instance_count   = 2
      enable_multi_az  = false
      retention_days   = 14
    }
    production = {
      instance_type    = "t3.large"
      instance_count   = 5
      enable_multi_az  = true
      retention_days   = 90
    }
  }

  # Select config for current workspace
  config = local.env_config[terraform.workspace]
}

resource "aws_instance" "app" {
  count         = local.config.instance_count
  instance_type = local.config.instance_type
  ami           = var.ami_id

  tags = {
    Name        = "${terraform.workspace}-app-${count.index}"
    Environment = terraform.workspace
  }
}

resource "aws_db_instance" "main" {
  instance_class = local.config.instance_type == "t3.micro" ? "db.t3.micro" : "db.t3.medium"
  multi_az       = local.config.enable_multi_az
  backup_retention_period = local.config.retention_days
}
```

### Workspace-Specific Resource Naming

Prevent dev and production from having name collisions:

```hcl
resource "aws_s3_bucket" "app_data" {
  bucket = "my-company-app-data-${terraform.workspace}"
  # dev:        my-company-app-data-dev
  # staging:    my-company-app-data-staging
  # production: my-company-app-data-production
}
```

### The Workspace CI/CD Pattern

```bash
#!/bin/bash
# Deploy to the environment matching the git branch

BRANCH=$(git rev-parse --abbrev-ref HEAD)

case "$BRANCH" in
  "main")        ENV="production" ;;
  "staging")     ENV="staging"    ;;
  "develop")     ENV="dev"        ;;
  *)             ENV="dev"        ;;
esac

cd infra/
terraform workspace select "$ENV" || terraform workspace new "$ENV"
terraform plan  -out=tfplan
terraform apply tfplan
```

---

## Workspace Risks — Why Prod Teams Often Avoid Them

### Risk 1: All workspaces share the same code

A syntax error or bad variable change in `main.tf` breaks ALL workspaces simultaneously. You push a change to test in dev → it breaks the production configuration before you can fix it.

### Risk 2: No blast-radius isolation

```bash
# Developer in "production" workspace by accident
terraform workspace select production  # forgot they did this
# (later, in a different terminal tab)
terraform destroy   # thinks they're in dev
# → destroys production
```

With separate directories, you must `cd` to `environments/production/` to touch production. An accidental `terraform destroy` in `environments/dev/` cannot reach production.

### Risk 3: Plan output mixes workspace context

It's easy to forget which workspace you're in. There's no directory-level separation to remind you.

---

## Approach 2: Separate Directories (Recommended for Production)

### Structure

```
infra/
├── modules/
│   ├── networking/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── outputs.tf
│   └── compute/
│       ├── main.tf
│       ├── variables.tf
│       └── outputs.tf
│
└── environments/
    ├── dev/
    │   ├── main.tf         ← calls modules with dev values
    │   ├── variables.tf
    │   ├── terraform.tfvars
    │   └── backend.tf      ← dev-specific state path
    │
    ├── staging/
    │   ├── main.tf
    │   ├── variables.tf
    │   ├── terraform.tfvars
    │   └── backend.tf
    │
    └── production/
        ├── main.tf
        ├── variables.tf
        ├── terraform.tfvars   ← DO NOT commit if secrets
        └── backend.tf         ← prod state — restricted IAM access
```

### Example: Dev Environment

```hcl
# environments/dev/backend.tf
terraform {
  backend "s3" {
    bucket         = "my-company-terraform-state"
    key            = "dev/terraform.tfstate"
    region         = "ap-northeast-1"
    dynamodb_table = "terraform-state-lock"
  }
}

# environments/dev/main.tf
module "networking" {
  source              = "../../modules/networking"
  environment         = "dev"
  vpc_cidr            = "10.0.0.0/16"
  public_subnet_count = 1
  enable_nat_gateway  = false   # save cost in dev
}

module "compute" {
  source         = "../../modules/compute"
  environment    = "dev"
  instance_type  = "t3.micro"
  instance_count = 1
  vpc_id         = module.networking.vpc_id
  subnet_ids     = module.networking.public_subnet_ids
}
```

```hcl
# environments/production/main.tf
module "networking" {
  source              = "../../modules/networking"
  environment         = "production"
  vpc_cidr            = "10.10.0.0/16"   # different CIDR — no overlap
  public_subnet_count = 3                # one per AZ
  enable_nat_gateway  = true
}

module "compute" {
  source         = "../../modules/compute"
  environment    = "production"
  instance_type  = "t3.large"
  instance_count = 5
  vpc_id         = module.networking.vpc_id
  subnet_ids     = module.networking.public_subnet_ids
}
```

### Why Separate Directories Win for Production

| Property | Workspaces | Separate Directories |
|---|---|---|
| Blast radius | Shared code — all envs affected by one change | Isolated — prod has its own code version |
| Accidental destroy | Easy to destroy wrong env | Must physically `cd` into the env directory |
| IAM isolation | Same AWS credentials for all workspaces | Each dir can use a different IAM role |
| Review | One PR can affect all environments | PR touches one env directory at a time |
| Module version pinning | Cannot pin modules per env | Production pins v1.2; dev tests v1.3 |

---

## `.tfvars` Files — Environment Variable Values

```hcl
# environments/dev/terraform.tfvars
environment     = "dev"
aws_region      = "ap-northeast-1"
instance_type   = "t3.micro"
instance_count  = 1
enable_deletion_protection = false

# environments/production/terraform.tfvars
environment     = "production"
aws_region      = "ap-northeast-1"
instance_type   = "t3.large"
instance_count  = 5
enable_deletion_protection = true
```

Auto-loaded files (Terraform reads these automatically):
- `terraform.tfvars` in the working directory
- `*.auto.tfvars` in the working directory

Manually specified (use `-var-file` flag):
```bash
terraform plan -var-file="production-secrets.tfvars"
```

**What to commit vs not commit:**

```
✅ Commit:  terraform.tfvars (non-secret values)
✅ Commit:  variables.tf (variable declarations, no values)
❌ Never:   *secrets*.tfvars (passwords, API keys)
❌ Never:   terraform.tfvars if it contains sensitive values
```

For secrets, use environment variables instead:
```bash
export TF_VAR_db_password="$(aws secretsmanager get-secret-value \
  --secret-id production/db/password \
  --query SecretString --output text)"
terraform apply
```
