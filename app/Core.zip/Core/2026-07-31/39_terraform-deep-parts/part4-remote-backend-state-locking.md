# Part 4 — Remote Backend & State Locking: Deep Dive

---

## Why Remote Backend Is Non-Negotiable for Teams

Default behavior: Terraform stores `terraform.tfstate` as a plain file in your current directory on your laptop.

This works for one person experimenting. It breaks immediately for teams:

```
Without remote backend:

  Engineer A (laptop):              Engineer B (laptop):
  terraform.tfstate v1              terraform.tfstate v1
        │                                 │
        ▼                                 ▼
  terraform apply                   terraform apply
  creates EC2 i-aaa                 creates EC2 i-bbb  ← DUPLICATE
  writes tfstate v2 locally         writes tfstate v2 locally
  
  Now A and B have DIFFERENT state files.
  Neither knows about the other's resources.
  Running destroy removes only what YOU know about.
```

With remote backend:
```
  Engineer A                        Engineer B
        │                                 │
        └──────────┬──────────────────────┘
                   │
              S3 Bucket
          terraform.tfstate (SHARED)
          DynamoDB Lock Table
                   │
        Only one apply runs at a time.
        Both engineers see the same state.
```

---

## The S3 Backend in Full Detail

### Architecture

```
┌────────────────────────────────────────────────────────┐
│                    AWS Account                         │
│                                                        │
│  ┌─────────────────────────────┐                      │
│  │  S3 Bucket                  │  ← stores tfstate    │
│  │  my-company-terraform-state │     versioned        │
│  │  ├── production/            │     encrypted        │
│  │  │   └── terraform.tfstate  │     private          │
│  │  ├── staging/               │                      │
│  │  │   └── terraform.tfstate  │                      │
│  │  └── dev/                   │                      │
│  │      └── terraform.tfstate  │                      │
│  └─────────────────────────────┘                      │
│                                                        │
│  ┌─────────────────────────────┐                      │
│  │  DynamoDB Table             │  ← lock records      │
│  │  terraform-state-lock       │                      │
│  │  ├── LockID: prod/tf.state  │  ← Engineer A holds  │
│  │  └── (empty = unlocked)     │     lock while applying│
│  └─────────────────────────────┘                      │
└────────────────────────────────────────────────────────┘
```

### Full Backend Configuration

```hcl
# backend.tf
terraform {
  backend "s3" {
    # Where to store the state file
    bucket = "my-company-terraform-state"
    key    = "production/terraform.tfstate"   # path within the bucket
    region = "ap-northeast-1"

    # Security
    encrypt = true   # AES-256 encryption at rest

    # Locking — prevents concurrent applies
    dynamodb_table = "terraform-state-lock"

    # Optional: use a specific IAM role to access state
    role_arn = "arn:aws:iam::123456789012:role/TerraformStateRole"

    # Optional: workspace-aware key (auto-adds workspace name)
    # key = "environments/${terraform.workspace}/terraform.tfstate"
  }
}
```

### Bootstrap Script — Creating the State Infrastructure

The catch-22: you need Terraform to manage infrastructure, but the S3 bucket and DynamoDB table must exist BEFORE Terraform can run. Bootstrap them manually with AWS CLI:

```bash
REGION="ap-northeast-1"
BUCKET="my-company-terraform-state"
TABLE="terraform-state-lock"

# 1. Create the S3 bucket
aws s3api create-bucket \
  --bucket "$BUCKET" \
  --region "$REGION" \
  --create-bucket-configuration LocationConstraint="$REGION"

# 2. Enable versioning — critical for state recovery
#    Every apply creates a new version. Roll back state by restoring a version.
aws s3api put-bucket-versioning \
  --bucket "$BUCKET" \
  --versioning-configuration Status=Enabled

# 3. Enable default AES-256 encryption
aws s3api put-bucket-encryption \
  --bucket "$BUCKET" \
  --server-side-encryption-configuration \
  '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'

# 4. Block ALL public access (state files must never be public)
aws s3api put-public-access-block \
  --bucket "$BUCKET" \
  --public-access-block-configuration \
  "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

# 5. Create DynamoDB lock table
#    LockID is the partition key — Terraform writes to it before every apply
aws dynamodb create-table \
  --table-name "$TABLE" \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region "$REGION"

echo "Backend infrastructure ready. Now run: terraform init"
```

---

## How State Locking Works — Step by Step

```
terraform apply sequence with DynamoDB lock:

Step 1: Terraform writes lock record to DynamoDB:
        LockID = "my-company-terraform-state/production/terraform.tfstate"
        Info = { who: "alice@company.com", created: "2026-07-31T10:00:00Z" }

Step 2: If another process tries to apply simultaneously:
        → DynamoDB ConditionalWrite fails (item already exists)
        → Terraform prints: "Error: state lock already acquired by alice"
        → Second apply exits without making any changes

Step 3: First apply completes:
        → Terraform deletes the lock record from DynamoDB
        → State is unlocked

Step 4: Now the second apply can proceed.
```

### Breaking a Stale Lock

If a `terraform apply` dies mid-run (laptop crash, Ctrl+C, CI timeout), the lock is never released. Next apply fails:

```
Error: Error acquiring the state lock

Lock Info:
  ID:        abc-def-ghi
  Path:      my-bucket/production/terraform.tfstate
  Operation: OperationTypeApply
  Who:       alice@company.com
  Version:   1.7.5
  Created:   2026-07-31 10:00:00 +0000 UTC
  Info:
```

To force-release the lock (ONLY do this after confirming the original apply is truly dead):

```bash
terraform force-unlock abc-def-ghi
# This deletes the DynamoDB lock record
# DANGEROUS if the original apply is still running — you'd have two concurrent applies
```

---

## State File Versioning — Your Safety Net

With S3 versioning enabled, every `terraform apply` creates a new S3 object version of the state file. This is your recovery mechanism.

```bash
# List all versions of the state file
aws s3api list-object-versions \
  --bucket my-company-terraform-state \
  --prefix production/terraform.tfstate \
  --query 'Versions[*].{VersionId:VersionId,LastModified:LastModified}' \
  --output table

# Download a specific old version
aws s3api get-object \
  --bucket my-company-terraform-state \
  --key production/terraform.tfstate \
  --version-id "abc123VersionId" \
  state-backup.json

# Inspect the old state
cat state-backup.json | jq '.resources[] | .type + "." + .name'

# Restore an old state (pushes it as the current state)
# DANGEROUS — only do this if you know what you're restoring
terraform state push state-backup.json
```

---

## Migrating State — Local to Remote

When you add a backend to an existing project that previously had local state:

```bash
# Before adding backend.tf:
# terraform.tfstate exists locally with your resources

# Add backend.tf with S3 config, then:
terraform init -migrate-state

# Terraform will:
# 1. Ask: "Do you want to copy existing state to the new backend?"
# 2. On yes: upload local state to S3
# 3. Delete (or keep) local state file
```

---

## Separate State Per Environment — The Right Pattern

Never mix environments in one state file. Each environment gets its own:
- State file path in S3
- Backend configuration
- Apply permissions (IAM roles)

```
S3 bucket: my-company-terraform-state
├── dev/terraform.tfstate        ← dev team can apply
├── staging/terraform.tfstate    ← platform team can apply
└── production/terraform.tfstate ← only CI/CD pipeline can apply (restricted IAM)
```

Each environment directory has its own `backend.tf`:

```hcl
# environments/dev/backend.tf
terraform {
  backend "s3" {
    bucket = "my-company-terraform-state"
    key    = "dev/terraform.tfstate"
    region = "ap-northeast-1"
    dynamodb_table = "terraform-state-lock"
  }
}

# environments/production/backend.tf
terraform {
  backend "s3" {
    bucket = "my-company-terraform-state"
    key    = "production/terraform.tfstate"   # different key
    region = "ap-northeast-1"
    dynamodb_table = "terraform-state-lock"
  }
}
```

---

## Reading Another State — `terraform_remote_state`

When two separate Terraform projects need to share data (e.g. networking project creates a VPC, app project needs the VPC ID):

```hcl
# In the networking project, output the VPC ID:
output "vpc_id" {
  value = aws_vpc.main.id
}

# In the app project, read the networking state:
data "terraform_remote_state" "networking" {
  backend = "s3"
  config = {
    bucket = "my-company-terraform-state"
    key    = "production/networking/terraform.tfstate"
    region = "ap-northeast-1"
  }
}

# Use the output from the networking state
resource "aws_instance" "app" {
  subnet_id = data.terraform_remote_state.networking.outputs.public_subnet_ids[0]
}
```

This creates a dependency between projects — the networking project must be applied before the app project.

---

## GCS Backend (GCP equivalent)

```hcl
terraform {
  backend "gcs" {
    bucket  = "my-company-terraform-state"
    prefix  = "production/terraform"
    # GCS has built-in object locking — no separate lock table needed
  }
}
```

```bash
# Create GCS bucket with versioning
gsutil mb -l asia-northeast1 gs://my-company-terraform-state
gsutil versioning set on gs://my-company-terraform-state
gsutil uniformbucketlevelaccess set on gs://my-company-terraform-state
```
