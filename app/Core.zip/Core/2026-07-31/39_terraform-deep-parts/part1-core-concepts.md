# Part 1 — Core Concepts: Desired State, Actual State, State File

---

## The Central Mental Model

Terraform is a **state reconciliation engine**. It does one job:
> "Compare what you *want* (`.tf` files) against what *exists* (cloud + state), then take the minimum actions to make reality match the blueprint."

Everything else in Terraform — modules, backends, lifecycle rules — exists to support this one loop.

```
┌─────────────────────────────────────────────────────────────────┐
│                     THE TERRAFORM LOOP                          │
│                                                                 │
│  ┌──────────────┐    terraform plan    ┌──────────────────────┐ │
│  │  .tf files   │ ──────────────────►  │  diff engine         │ │
│  │  (DESIRED)   │                      │  desired vs actual   │ │
│  └──────────────┘                      └──────────┬───────────┘ │
│                                                   │             │
│  ┌──────────────┐    API refresh       ┌──────────▼───────────┐ │
│  │  .tfstate    │ ◄──────────────────  │  cloud provider API  │ │
│  │  (KNOWN)     │                      │  (ACTUAL)            │ │
│  └──────────────┘                      └──────────────────────┘ │
│         │                                                        │
│         │  terraform apply                                       │
│         ▼                                                        │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  API calls: CREATE / UPDATE / DESTROY resources          │   │
│  │  Then write new .tfstate reflecting what now exists      │   │
│  └──────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Three Sources of Truth

### 1. `.tf` files — Desired State

What YOU write. What you WANT to exist. Lives in Git.

```hcl
resource "aws_instance" "web" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t3.medium"
}
```

This file makes a claim: "There should be an EC2 instance with these properties."

### 2. `.tfstate` — Known State (Terraform's Memory)

A JSON file Terraform maintains. Records every resource it has ever created and all their current attributes.

```json
{
  "resources": [
    {
      "type": "aws_instance",
      "name": "web",
      "instances": [
        {
          "attributes": {
            "id": "i-0abc123def456",
            "ami": "ami-0c55b159cbfafe1f0",
            "instance_type": "t3.medium",
            "public_ip": "54.12.34.56",
            "private_ip": "10.0.1.5"
          }
        }
      ]
    }
  ]
}
```

Key insight: the state file stores **more** than your `.tf` file. It stores everything the cloud returned after creation — IDs, IPs, ARNs, timestamps — attributes you never typed but need to reference.

### 3. Real Cloud — Actual State

What AWS/GCP/Azure actually has running right now. Terraform queries this via provider API calls during `plan` to verify the state file is still accurate.

---

## What `terraform plan` Actually Does (Step by Step)

```
Step 1: Read all .tf files in the directory
        → Build the "desired" resource graph

Step 2: Read the .tfstate file
        → Know what Terraform last created

Step 3: Call cloud APIs to refresh current attributes
        → Detect if something was changed outside Terraform (drift)

Step 4: Compute the diff:
        For each resource in .tf:
          - Not in state?         → CREATE  (+)
          - In state but changed? → UPDATE  (~)  or REPLACE (-)/(+) if immutable
          - In state, unchanged?  → No-op   (=)

        For each resource in state but NOT in .tf:
          → DESTROY  (-)

Step 5: Print the plan. Nothing has been changed yet.
```

### Understanding Plan Output

```
# aws_instance.web will be created
+ resource "aws_instance" "web" {
    + ami           = "ami-0c55b159cbfafe1f0"
    + instance_type = "t3.medium"
    + id            = (known after apply)   ← cloud assigns this
    + public_ip     = (known after apply)
  }

Plan: 1 to add, 0 to change, 0 to destroy.
```

The `+` means create. The `-` means destroy. The `~` means in-place update. The `-/+` means **replace** — destroy the old, create the new. **This is where data loss happens.** A rename or changing an immutable attribute (like an EC2 AMI) triggers `-/+`.

---

## Drift — When Reality Diverges From State

**Drift** = someone changed the cloud manually (console, AWS CLI, auto-scaler) and `.tfstate` now disagrees with real cloud.

```
Scenario:
  .tf says:      instance_type = "t3.medium"
  .tfstate says: instance_type = "t3.medium"
  Real cloud:    instance_type = "t3.large"   ← ops engineer changed it manually

terraform plan output:
  ~ aws_instance.web
      ~ instance_type = "t3.large" -> "t3.medium"   ← Terraform wants to REVERT it

This is Terraform trying to enforce your desired state.
```

Handling drift:
```bash
# Option A: Let Terraform revert the drift (enforce IaC)
terraform apply

# Option B: Accept the drift — update .tfstate and .tf to match reality
terraform apply -refresh-only   # update state to show t3.large
# Then edit your .tf to say instance_type = "t3.large"
```

---

## The State File Is Sacred — Why

The state file is **the only thing connecting your .tf code to real cloud resources**.

If you lose the state file:
- Terraform has no idea it created those resources
- `terraform apply` will try to CREATE everything again → duplicate resources, naming conflicts, chaos
- You cannot run `terraform destroy` — Terraform doesn't know what to destroy
- You must manually `terraform import` every resource one by one

If you corrupt the state file (bad manual edit, two simultaneous applies):
- Terraform may think a resource doesn't exist when it does
- Or think it exists when it was deleted
- Both cause apply to fail or produce wrong results

### State File Security Warning

The state file contains **plaintext secrets** — database passwords, access keys, private IPs, TLS certificates — anything the cloud provider returned. Never commit it to Git.

```bash
# .gitignore must always contain:
*.tfstate
*.tfstate.*
.terraform/
```

---

## Immutable vs Mutable Attributes

Some cloud resource attributes can be changed **in place** (mutable). Others require **destroying and recreating** the resource (immutable).

| Resource | Mutable (update in place) | Immutable (requires replace) |
|---|---|---|
| aws_instance | instance_type, tags | ami, availability_zone |
| aws_s3_bucket | tags, versioning config | bucket name |
| aws_db_instance | instance_class, storage | engine, db name |
| aws_security_group | rules (ingress/egress) | vpc_id |

When Terraform needs to replace an immutable attribute, the plan shows `-/+` (destroy old + create new). For databases, this means **data loss**. Use `lifecycle { prevent_destroy = true }` to make Terraform error before destroying.

---

## Dependency Graph

Terraform builds an implicit dependency graph from resource references. Resources that reference each other are created in the correct order automatically.

```hcl
resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}

resource "aws_subnet" "public" {
  vpc_id     = aws_vpc.main.id   # references VPC → VPC created FIRST
  cidr_block = "10.0.1.0/24"
}

resource "aws_instance" "web" {
  subnet_id = aws_subnet.public.id  # references subnet → subnet created FIRST
  ami       = "ami-0c55b159cbfafe1f0"
}
```

Execution order: `aws_vpc.main` → `aws_subnet.public` → `aws_instance.web`

Destruction order is reversed: `aws_instance.web` → `aws_subnet.public` → `aws_vpc.main`

For explicit (non-reference) dependencies, use `depends_on`:

```hcl
resource "aws_iam_role_policy_attachment" "app" {
  role       = aws_iam_role.app.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonS3ReadOnlyAccess"

  depends_on = [aws_iam_role.app]   # explicit dependency
}
```
