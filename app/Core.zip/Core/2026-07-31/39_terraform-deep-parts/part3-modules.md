# Part 3 — Modules: Reusable Infrastructure Patterns

---

## What Is a Module and Why Does It Exist?

A **module** is a directory of `.tf` files that acts as a reusable function for infrastructure. You write the pattern once (e.g. "create a VPC with public and private subnets") and call it multiple times with different inputs (dev vs production, different regions, different CIDR ranges).

Without modules:
```
environments/
  dev/
    vpc.tf        ← copy-paste
    subnets.tf    ← copy-paste
    nat.tf        ← copy-paste
  staging/
    vpc.tf        ← copy-paste (slightly different)
    subnets.tf    ← slightly different
  production/
    vpc.tf        ← slightly different again
```
A bug fix or security change must be applied in 3 places. Someone forgets one. Environments drift.

With modules:
```
modules/
  networking/     ← written once, parameterized
    main.tf
    variables.tf
    outputs.tf
environments/
  dev/main.tf     ← calls module with dev values
  staging/main.tf ← calls module with staging values
  production/main.tf ← calls module with production values
```
Fix the bug once in the module → all environments inherit the fix.

---

## Module Anatomy — The Three Required Files

### `variables.tf` — The Module's API (Inputs)

```hcl
# modules/networking/variables.tf

variable "environment" {
  description = "Deployment environment label"
  type        = string
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "public_subnet_count" {
  description = "How many public subnets to create (one per AZ)"
  type        = number
  default     = 2
}

variable "enable_nat_gateway" {
  description = "Whether to create a NAT gateway for private subnets"
  type        = bool
  default     = false   # disabled by default to save cost in dev
}

variable "tags" {
  description = "Additional tags to apply to all resources"
  type        = map(string)
  default     = {}
}
```

### `main.tf` — The Module's Logic (Resources)

```hcl
# modules/networking/main.tf

# Look up available AZs in the current region
data "aws_availability_zones" "available" {
  state = "available"
}

resource "aws_vpc" "main" {
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true
  enable_dns_hostnames = true

  tags = merge(var.tags, {
    Name = "${var.environment}-vpc"
  })
}

resource "aws_subnet" "public" {
  count = var.public_subnet_count

  vpc_id                  = aws_vpc.main.id
  cidr_block              = cidrsubnet(var.vpc_cidr, 4, count.index)
  availability_zone       = data.aws_availability_zones.available.names[count.index]
  map_public_ip_on_launch = true

  tags = merge(var.tags, {
    Name = "${var.environment}-public-${count.index + 1}"
    Tier = "public"
  })
}

resource "aws_internet_gateway" "main" {
  vpc_id = aws_vpc.main.id
  tags   = merge(var.tags, { Name = "${var.environment}-igw" })
}

resource "aws_eip" "nat" {
  count  = var.enable_nat_gateway ? 1 : 0
  domain = "vpc"
  tags   = merge(var.tags, { Name = "${var.environment}-nat-eip" })
}

resource "aws_nat_gateway" "main" {
  count         = var.enable_nat_gateway ? 1 : 0
  allocation_id = aws_eip.nat[0].id
  subnet_id     = aws_subnet.public[0].id
  tags          = merge(var.tags, { Name = "${var.environment}-nat" })
}
```

### `outputs.tf` — The Module's Return Values

```hcl
# modules/networking/outputs.tf

output "vpc_id" {
  description = "ID of the created VPC"
  value       = aws_vpc.main.id
}

output "public_subnet_ids" {
  description = "List of public subnet IDs"
  value       = aws_subnet.public[*].id
}

output "vpc_cidr_block" {
  description = "CIDR block of the VPC"
  value       = aws_vpc.main.cidr_block
}

output "nat_gateway_id" {
  description = "NAT Gateway ID (empty if not created)"
  value       = length(aws_nat_gateway.main) > 0 ? aws_nat_gateway.main[0].id : null
}
```

---

## Calling a Module — The `module` Block

```hcl
# environments/production/main.tf

module "networking" {
  source = "../../modules/networking"   # relative path to module directory

  # Pass input variable values
  environment         = "production"
  vpc_cidr            = "10.10.0.0/16"
  public_subnet_count = 3
  enable_nat_gateway  = true
  tags = {
    Team    = "platform"
    CostCenter = "infra"
  }
}

# Use module outputs in other resources
module "compute" {
  source = "../../modules/compute"

  environment      = "production"
  vpc_id           = module.networking.vpc_id           # module output → input
  subnet_ids       = module.networking.public_subnet_ids
}
```

**After changing `source`, always run `terraform init` to download the module.**

---

## Module Sources — Where Modules Come From

```hcl
# Local path (relative or absolute)
source = "../../modules/networking"
source = "/absolute/path/to/module"

# Terraform Registry (public, free)
source  = "terraform-aws-modules/vpc/aws"
version = "~> 5.0"

# Private registry (Terraform Cloud / Enterprise)
source  = "app.terraform.io/my-org/networking/aws"
version = "~> 2.1"

# GitHub (public repo)
source = "github.com/my-org/terraform-modules//networking"

# GitHub with specific tag/branch
source = "git::https://github.com/my-org/terraform-modules.git//networking?ref=v1.2.0"

# S3 bucket (private)
source = "s3::https://s3-eu-west-1.amazonaws.com/my-modules/networking.zip"
```

---

## Module Versioning and the Lock File

When using registry modules, pin versions:

```hcl
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"   # allows 5.x but not 6.x
}
```

`terraform init` creates/updates `.terraform.lock.hcl` with exact version hashes. Commit this file — it ensures everyone uses the same version:

```hcl
# .terraform.lock.hcl (commit this file)
provider "registry.terraform.io/hashicorp/aws" {
  version     = "5.31.0"
  constraints = "~> 5.0"
  hashes = [
    "h1:abc123...",
  ]
}
```

To upgrade a module/provider to a newer allowed version:
```bash
terraform init -upgrade
```

---

## Passing Data Between Modules (Parent → Child → Parent)

```
PARENT
  │
  ├── module "networking"  ← creates VPC, returns vpc_id
  │         └── output "vpc_id"
  │
  └── module "compute"     ← receives vpc_id from networking
            ├── var "vpc_id"  =  module.networking.vpc_id
            └── creates EC2 instances in that VPC
```

```hcl
# Parent config
module "networking" {
  source = "./modules/networking"
  vpc_cidr = "10.0.0.0/16"
}

module "compute" {
  source  = "./modules/compute"
  vpc_id  = module.networking.vpc_id           # output of networking → input of compute
  subnets = module.networking.public_subnet_ids
}

# Access grandchild outputs at root level
output "app_url" {
  value = module.compute.load_balancer_dns
}
```

Terraform's dependency engine ensures `networking` completes before `compute` starts because `compute` references `networking`'s output.

---

## Module Best Practices

### 1. One module = one responsibility

Good: `modules/networking`, `modules/compute`, `modules/database`
Bad: `modules/everything` — a module that creates VPC + EC2 + RDS + S3 + IAM

### 2. Always declare all outputs you might need

If a caller might need the VPC ID, the subnet IDs, the route table IDs, and the CIDR — output all of them. You can't access internal resources of a module from outside, only its declared outputs.

### 3. Default variables to the safe/cheap option

```hcl
variable "enable_nat_gateway" {
  default = false   # saves $30/month in dev; production sets it to true
}
variable "instance_type" {
  default = "t3.micro"   # dev default; production overrides to t3.large
}
```

### 4. Do not hardcode environment-specific values inside a module

Bad:
```hcl
# Inside a module — WRONG
resource "aws_instance" "app" {
  instance_type = "t3.large"  # hardcoded — dev can't use this module cheaply
}
```

Good:
```hcl
# Inside a module — CORRECT
resource "aws_instance" "app" {
  instance_type = var.instance_type   # caller decides
}
```

### 5. Use `README.md` in every module

Document: what the module creates, all input variables, all outputs, example usage. This is especially important for team-shared modules.

---

## The `terraform-aws-modules` Public Registry

HashiCorp and the community maintain battle-tested modules for common patterns:

```hcl
# Complete VPC with public, private, database subnets
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"

  name = "production-vpc"
  cidr = "10.0.0.0/16"

  azs             = ["ap-northeast-1a", "ap-northeast-1c", "ap-northeast-1d"]
  public_subnets  = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
  private_subnets = ["10.0.11.0/24", "10.0.12.0/24", "10.0.13.0/24"]

  enable_nat_gateway = true
  single_nat_gateway = false   # one NAT per AZ for HA
}

# EKS cluster
module "eks" {
  source  = "terraform-aws-modules/eks/aws"
  version = "~> 20.0"

  cluster_name    = "production-eks"
  cluster_version = "1.29"
  vpc_id          = module.vpc.vpc_id
  subnet_ids      = module.vpc.private_subnets
}
```

Before writing your own networking or EKS module, check the registry — the community version likely handles edge cases (multi-AZ NAT, endpoint policies, node group upgrades) that you'd miss building from scratch.
