# Part 8 — CI/CD Integration, Drift Detection & Security

---

## CI/CD for Terraform — The Full Pipeline

### Why CI/CD Matters for IaC

Without CI/CD, Terraform is still manual. Two engineers both have access to `terraform apply`. One runs it from their laptop with a newer provider version. The other runs it with outdated modules. State conflicts happen. No review process. No audit trail.

With CI/CD:
- Every infra change goes through a PR with plan output as a comment
- Only the pipeline can `apply` to production (engineers cannot)
- All applies are logged, versioned, reproducible

---

## The Standard Terraform CI/CD Pipeline

```
┌─────────────────────────────────────────────────────────────────────┐
│  PR STAGE (on every commit to a PR branch)                         │
│                                                                     │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────┐              │
│  │ terraform   │  │ terraform    │  │ terraform    │              │
│  │ fmt -check  │→ │ validate     │→ │ plan -out=   │              │
│  │ (lint)      │  │ (syntax)     │  │ tfplan       │              │
│  └─────────────┘  └──────────────┘  └──────┬───────┘              │
│                                             │                       │
│                                             ▼                       │
│                                    Post plan as PR comment          │
│                                    (human reviews diff)             │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│  MERGE STAGE (on merge to main)                                     │
│                                                                     │
│  ┌─────────────┐  ┌──────────────┐  ┌──────────────┐              │
│  │ terraform   │  │ Download     │  │ terraform    │              │
│  │ plan -out=  │→ │ saved tfplan │→ │ apply tfplan │              │
│  │ tfplan      │  │ from PR stage│  │ (exact plan) │              │
│  └─────────────┘  └──────────────┘  └──────────────┘              │
└─────────────────────────────────────────────────────────────────────┘
```

### Why Save and Reuse the Plan (`-out=tfplan`)

If you run `terraform plan` in CI and then `terraform apply` (without `-out`), Terraform re-plans during apply. Between the PR plan and the merge apply, someone else might have applied changes to the same state. The re-plan would reflect those new changes, possibly doing something you never reviewed.

The safe pattern:
```bash
# PR stage: save the plan
terraform plan -out=tfplan

# Store tfplan as a CI artifact (GitHub Actions, GitLab CI)
# Upload to S3 for the apply stage to retrieve

# Merge/apply stage: apply EXACTLY the saved plan
terraform apply tfplan   # no re-plan, no surprises
```

---

## GitHub Actions Pipeline — Complete Example

```yaml
# .github/workflows/terraform.yml

name: Terraform

on:
  pull_request:
    branches: [main]
    paths: ["infra/**"]
  push:
    branches: [main]
    paths: ["infra/**"]

env:
  TF_VERSION: "1.7.5"
  AWS_REGION: "ap-northeast-1"
  WORKING_DIR: "infra/environments/production"

jobs:
  # ─────────────────────────────────────────
  # PR: Lint + Plan
  # ─────────────────────────────────────────
  plan:
    if: github.event_name == 'pull_request'
    runs-on: ubuntu-latest
    permissions:
      id-token: write      # for OIDC AWS auth
      contents: read
      pull-requests: write # to post plan comment

    steps:
      - uses: actions/checkout@v4

      - name: Setup Terraform
        uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: ${{ env.TF_VERSION }}

      - name: Configure AWS credentials (OIDC — no static keys)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/GitHubActionsReadOnly
          aws-region: ${{ env.AWS_REGION }}

      - name: terraform init
        working-directory: ${{ env.WORKING_DIR }}
        run: terraform init -input=false

      - name: terraform fmt check
        working-directory: ${{ env.WORKING_DIR }}
        run: terraform fmt -check -recursive
        # Fails the pipeline if any .tf file is not formatted

      - name: terraform validate
        working-directory: ${{ env.WORKING_DIR }}
        run: terraform validate

      - name: terraform plan
        id: plan
        working-directory: ${{ env.WORKING_DIR }}
        run: |
          terraform plan -no-color -out=tfplan 2>&1 | tee plan_output.txt
          echo "exitcode=${PIPESTATUS[0]}" >> $GITHUB_OUTPUT
        env:
          TF_VAR_db_password: ${{ secrets.DB_PASSWORD }}

      - name: Upload plan artifact
        uses: actions/upload-artifact@v4
        with:
          name: tfplan
          path: ${{ env.WORKING_DIR }}/tfplan
          retention-days: 5

      - name: Post plan as PR comment
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs');
            const plan = fs.readFileSync('${{ env.WORKING_DIR }}/plan_output.txt', 'utf8');
            const maxLen = 65000;
            const truncated = plan.length > maxLen
              ? plan.substring(0, maxLen) + '\n... (truncated)'
              : plan;
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: `## Terraform Plan\n\`\`\`\n${truncated}\n\`\`\``
            });

  # ─────────────────────────────────────────
  # Merge to main: Apply
  # ─────────────────────────────────────────
  apply:
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    environment: production   # requires manual approval in GitHub Environments
    permissions:
      id-token: write
      contents: read

    steps:
      - uses: actions/checkout@v4

      - name: Setup Terraform
        uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: ${{ env.TF_VERSION }}

      - name: Configure AWS credentials (write role for apply)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/GitHubActionsApply
          aws-region: ${{ env.AWS_REGION }}

      - name: terraform init
        working-directory: ${{ env.WORKING_DIR }}
        run: terraform init -input=false

      - name: Download plan artifact
        uses: actions/download-artifact@v4
        with:
          name: tfplan
          path: ${{ env.WORKING_DIR }}

      - name: terraform apply
        working-directory: ${{ env.WORKING_DIR }}
        run: terraform apply -input=false tfplan
        env:
          TF_VAR_db_password: ${{ secrets.DB_PASSWORD }}
```

---

## AWS Authentication — OIDC (Best Practice, No Static Keys)

Never store `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY` as CI secrets. Use OIDC:

```hcl
# Terraform config to create the OIDC trust relationship
resource "aws_iam_openid_connect_provider" "github" {
  url = "https://token.actions.githubusercontent.com"
  client_id_list = ["sts.amazonaws.com"]
  thumbprint_list = ["6938fd4d98bab03faadb97b34396831e3780aea1"]
}

resource "aws_iam_role" "github_actions_apply" {
  name = "GitHubActionsApply"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Federated = aws_iam_openid_connect_provider.github.arn
      }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "token.actions.githubusercontent.com:aud" = "sts.amazonaws.com"
        }
        StringLike = {
          # Only allow from this specific repo's main branch
          "token.actions.githubusercontent.com:sub" = "repo:my-org/my-repo:ref:refs/heads/main"
        }
      }
    }]
  })
}
```

Benefits:
- No long-lived credentials stored anywhere
- AWS issues short-lived tokens per pipeline run
- Scoped to specific repo + branch (PR branch cannot apply, only main can)

---

## Drift Detection — Scheduled Plans

Run `terraform plan` on a schedule to detect manual changes before they cause incidents:

```yaml
# .github/workflows/drift-detection.yml
name: Drift Detection

on:
  schedule:
    - cron: "0 */6 * * *"   # every 6 hours

jobs:
  drift-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      # ... setup terraform, AWS auth ...

      - name: Check for drift
        id: drift
        run: |
          terraform plan -detailed-exitcode -refresh-only 2>&1 | tee drift_output.txt
          echo "exitcode=$?" >> $GITHUB_OUTPUT
        # Exit codes: 0 = no changes, 1 = error, 2 = changes detected

      - name: Alert on drift
        if: steps.drift.outputs.exitcode == '2'
        run: |
          # Send to Slack, PagerDuty, email, etc.
          curl -X POST "$SLACK_WEBHOOK" \
            -H "Content-Type: application/json" \
            -d "{\"text\": \"⚠️ Terraform drift detected in production!\"}"
```

---

## Security: Secrets in Terraform

### What Not to Do

```hcl
# NEVER DO THIS
resource "aws_db_instance" "main" {
  password = "super-secret-password-123"   # hardcoded in Git
}

# NEVER DO THIS EITHER
variable "db_password" {
  default = "super-secret-password-123"   # in Git
}
```

### Pattern 1: Environment Variables (Simple)

```bash
# Set before running terraform
export TF_VAR_db_password="$(aws secretsmanager get-secret-value \
  --secret-id production/db/password \
  --query SecretString --output text)"
terraform apply
```

### Pattern 2: Fetch Secrets at Plan Time (Best Practice)

```hcl
# Fetch from AWS Secrets Manager during plan/apply
data "aws_secretsmanager_secret_version" "db_password" {
  secret_id = "production/rds/master-password"
}

resource "aws_db_instance" "main" {
  password = data.aws_secretsmanager_secret_version.db_password.secret_string
}
```

The password is never in `.tf` files or CI env vars. It's fetched from the secret store at apply time.

### Pattern 3: Generate and Store (Self-Managed Rotation)

```hcl
# Generate a random password
resource "random_password" "db" {
  length           = 32
  special          = true
  override_special = "!#$%&*()-_=+[]{}<>:?"
}

# Store it in Secrets Manager
resource "aws_secretsmanager_secret" "db_password" {
  name = "production/rds/master-password"
  lifecycle { prevent_destroy = true }
}

resource "aws_secretsmanager_secret_version" "db_password" {
  secret_id     = aws_secretsmanager_secret.db_password.id
  secret_string = random_password.db.result
}

# Use it
resource "aws_db_instance" "main" {
  password = random_password.db.result
}
```

**Warning**: `random_password.db.result` is stored in plain text in `.tfstate`. This is another reason your state file must be encrypted and access-controlled.

---

## IAM Least Privilege for Terraform

Never give Terraform AdministratorAccess. Create a scoped role:

```hcl
resource "aws_iam_role" "terraform_deploy" {
  name = "TerraformDeploy-Production"

  # Policy allowing only what production infra needs
  inline_policy {
    name = "TerraformDeployPolicy"
    policy = jsonencode({
      Version = "2012-10-17"
      Statement = [
        {
          Effect = "Allow"
          Action = [
            "ec2:*",
            "rds:*",
            "elasticloadbalancing:*",
            "eks:*",
            "iam:PassRole",   # needed to assign roles to EC2/EKS
          ]
          Resource = "*"
        },
        {
          # State bucket access
          Effect = "Allow"
          Action = ["s3:GetObject", "s3:PutObject", "s3:DeleteObject", "s3:ListBucket"]
          Resource = [
            "arn:aws:s3:::my-terraform-state",
            "arn:aws:s3:::my-terraform-state/production/*"
          ]
        },
        {
          # State lock table
          Effect = "Allow"
          Action = ["dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:DeleteItem"]
          Resource = "arn:aws:dynamodb:ap-northeast-1:*:table/terraform-state-lock"
        }
      ]
    })
  }
}
```

Separate read-only role for PRs (plan only):
```hcl
resource "aws_iam_role" "terraform_plan" {
  name = "TerraformPlan-Production"
  # ReadOnlyAccess + state bucket read permission
  # This role can never change anything — safe for PR pipelines
}
```
