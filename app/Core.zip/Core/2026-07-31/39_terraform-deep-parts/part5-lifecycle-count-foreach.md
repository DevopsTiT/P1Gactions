# Part 5 — Lifecycle Rules, count, for_each: Deep Dive

---

## `lifecycle` Block — Overriding Terraform's Default Behavior

By default Terraform:
- Destroys before creating (for replace operations)
- Allows destroy of any resource
- Tracks and reverts ALL attribute changes

The `lifecycle` block lets you override these behaviors per resource.

---

## `prevent_destroy` — The Production Database Protector

Without it:
```bash
# Developer accidentally runs this in production directory
terraform destroy
# → Destroys the RDS database
# → All customer data gone
# → You are on the front page of tech news
```

With it:
```hcl
resource "aws_db_instance" "production" {
  identifier     = "production-db"
  engine         = "postgres"
  instance_class = "db.r6g.large"

  lifecycle {
    prevent_destroy = true
  }
}
```

```bash
terraform destroy
# Error: Instance cannot be destroyed
# Resource aws_db_instance.production has lifecycle.prevent_destroy set,
# but the plan calls for this resource to be destroyed.
```

**What it blocks:**
- `terraform destroy`
- `terraform apply` when a resource rename or immutable attribute change would trigger recreation

**What it does NOT block:**
- Removing the `prevent_destroy = true` line from `.tf` and then running `terraform apply`
- Deleting the resource directly via AWS console (Terraform doesn't control that)

**Where to use it:**
- RDS databases and Aurora clusters
- S3 buckets with data
- Terraform state buckets themselves
- Any stateful resource where data loss = catastrophe

---

## `create_before_destroy` — Zero-Downtime Replacements

Terraform's default replace sequence:
```
Default (downtime):
  1. DESTROY old resource  ← service goes down
  2. CREATE new resource   ← service comes back up
  
  Gap between steps 1 and 2 = downtime
```

With `create_before_destroy`:
```
create_before_destroy = true:
  1. CREATE new resource   ← service keeps running on old
  2. DESTROY old resource  ← only removed after new is ready
  
  Overlap = zero downtime
```

```hcl
resource "aws_instance" "app" {
  ami           = var.ami_id
  instance_type = "t3.medium"

  lifecycle {
    create_before_destroy = true
  }
}
```

**When it's automatically needed:**
- Changing an EC2 AMI (immutable attribute → forces replace)
- Changing the name of an AWS security group
- Changing a certificate ARN on a load balancer

**The naming conflict problem:**
Some resources have unique name constraints. If you try to create-before-destroy but both need the same name, the create step will fail:

```hcl
resource "aws_security_group" "app" {
  name   = "app-security-group"   # unique within VPC

  lifecycle {
    create_before_destroy = true
  }
  # PROBLEM: Can't create the new SG with the same name while old one exists
}
```

Solution: use name_prefix instead of name (AWS appends a random suffix):
```hcl
resource "aws_security_group" "app" {
  name_prefix = "app-security-group-"   # AWS generates unique names
  lifecycle {
    create_before_destroy = true
  }
}
```

---

## `ignore_changes` — Let External Systems Do Their Job

Some attributes get legitimately changed by external systems:
- Auto-scaling changes desired instance count
- AWS Systems Manager patches AMIs
- Kubernetes operators update image tags
- Config management tools update user-data

Without `ignore_changes`, Terraform will revert these every apply — fighting with the external system.

```hcl
resource "aws_autoscaling_group" "app" {
  desired_capacity   = 3        # initial value
  min_size           = 1
  max_size           = 10

  lifecycle {
    ignore_changes = [
      desired_capacity,         # let auto-scaler control this
    ]
  }
}

resource "aws_instance" "app" {
  ami           = var.ami_id
  instance_type = "t3.medium"

  lifecycle {
    ignore_changes = [
      ami,           # let AWS Systems Manager patch the AMI
      user_data,     # let external config management handle this
      tags["LastDeployedAt"],   # ignore a specific tag key
    ]
  }
}
```

**Special case: ignore all changes to all attributes:**
```hcl
lifecycle {
  ignore_changes = all   # Terraform never modifies this resource after creation
}
```

Use `ignore_changes = all` for resources that are bootstrapped by Terraform but then fully managed by another system (e.g. a Kubernetes namespace created by Terraform but then managed by GitOps).

---

## `replace_triggered_by` — Force Replacement When a Related Resource Changes

Replaces this resource whenever specific other resources (or their attributes) change:

```hcl
resource "aws_launch_template" "app" {
  name_prefix   = "app-"
  image_id      = var.ami_id
  instance_type = "t3.medium"
}

resource "aws_autoscaling_group" "app" {
  desired_capacity = 3

  launch_template {
    id      = aws_launch_template.app.id
    version = "$Latest"
  }

  lifecycle {
    replace_triggered_by = [
      aws_launch_template.app   # when launch template changes → replace ASG
    ]
  }
}
```

---

## `count` — Create Multiple Identical Resources

`count` creates N copies of the same resource. Each copy is addressed by its zero-based index.

```hcl
variable "worker_count" { default = 3 }

resource "aws_instance" "worker" {
  count         = var.worker_count
  ami           = var.ami_id
  instance_type = "t3.medium"

  tags = {
    Name = "worker-${count.index}"   # worker-0, worker-1, worker-2
  }
}
```

Resources created:
```
aws_instance.worker[0]   → EC2 i-aaa  "worker-0"
aws_instance.worker[1]   → EC2 i-bbb  "worker-1"
aws_instance.worker[2]   → EC2 i-ccc  "worker-2"
```

Referencing count resources:
```hcl
# All IDs as a list
output "worker_ids" {
  value = aws_instance.worker[*].id   # ["i-aaa", "i-bbb", "i-ccc"]
}

# One specific instance
resource "aws_eip" "worker_0" {
  instance = aws_instance.worker[0].id
}
```

### The `count` Problem — Index Shifting

```
Initial:  count = 3
  worker[0] → worker-a   (i-aaa)
  worker[1] → worker-b   (i-bbb)
  worker[2] → worker-c   (i-ccc)

Remove worker-b (middle item):  count = 2, and reorder list
  worker[0] → worker-a   (i-aaa)  ← no change
  worker[1] → worker-c   (i-ccc)  ← WAS [2], now [1] → REPLACE (destroy i-ccc, create new)
  
  Result: worker-c is DESTROYED and RECREATED unnecessarily!
  In production: this is unexpected downtime for a running service.
```

This is why **`count` is only safe for truly interchangeable resources** (worker nodes, NAT EIPs) — not for named, distinct services.

---

## `for_each` — Create Multiple Resources with Stable Keys

`for_each` is the safe alternative to `count` for named resources. Each resource gets a stable string key instead of a numeric index.

### `for_each` with a map

```hcl
variable "services" {
  default = {
    payments  = { port = 8080, instance_type = "t3.medium" }
    checkout  = { port = 8081, instance_type = "t3.small"  }
    inventory = { port = 8082, instance_type = "t3.small"  }
  }
}

resource "aws_instance" "service" {
  for_each      = var.services

  ami           = var.ami_id
  instance_type = each.value.instance_type   # access map value
  tags = {
    Name    = each.key                        # "payments", "checkout", "inventory"
    Port    = each.value.port
  }
}
```

Resources created (stable keys):
```
aws_instance.service["payments"]   → EC2 i-aaa
aws_instance.service["checkout"]   → EC2 i-bbb
aws_instance.service["inventory"]  → EC2 i-ccc
```

Remove "checkout" from the map:
```
aws_instance.service["payments"]   → EC2 i-aaa  ← unchanged
aws_instance.service["inventory"]  → EC2 i-ccc  ← unchanged
aws_instance.service["checkout"]   → DESTROYED  ← only this one
```

No other resources are touched. This is why `for_each` is safer than `count`.

### `for_each` with a set of strings

```hcl
variable "availability_zones" {
  default = toset(["ap-northeast-1a", "ap-northeast-1c", "ap-northeast-1d"])
}

resource "aws_subnet" "private" {
  for_each          = var.availability_zones
  vpc_id            = aws_vpc.main.id
  availability_zone = each.key    # "ap-northeast-1a", etc.
  cidr_block        = cidrsubnet(var.vpc_cidr, 4, index(tolist(var.availability_zones), each.key))
  tags = { Name = "private-${each.key}" }
}
```

### Referencing `for_each` resources elsewhere

```hcl
# Get a map of key → attribute
output "service_ips" {
  value = {
    for name, instance in aws_instance.service :
    name => instance.private_ip
  }
  # → { payments = "10.0.1.5", checkout = "10.0.1.6", inventory = "10.0.1.7" }
}

# Pass all subnet IDs as a list to another resource
resource "aws_lb" "main" {
  subnets = values(aws_subnet.private)[*].id
  # values() extracts the values from the for_each map
}
```

---

## `count` vs `for_each` — When to Use Each

| Situation | Use |
|---|---|
| Creating N identical, interchangeable units (workers, NAT IPs) | `count` |
| Creating N named, distinct resources (services, regions, AZs) | `for_each` |
| The number comes from a variable integer | `count` |
| The set of items comes from a map or list of names | `for_each` |
| You need to remove a specific item without touching others | `for_each` |
| All items are the same and order doesn't matter | `count` |

### Converting from `count` to `for_each` (Dangerous Migration)

If you already have resources created with `count` and want to switch to `for_each`, Terraform sees entirely new resource addresses and will destroy + recreate everything:

```bash
# count creates: aws_instance.worker[0], worker[1], worker[2]
# for_each creates: aws_instance.worker["a"], worker["b"], worker["c"]
# Different addresses → Terraform says: destroy old, create new

# To migrate without recreating, use state mv:
terraform state mv 'aws_instance.worker[0]' 'aws_instance.worker["worker-a"]'
terraform state mv 'aws_instance.worker[1]' 'aws_instance.worker["worker-b"]'
terraform state mv 'aws_instance.worker[2]' 'aws_instance.worker["worker-c"]'
# Then update the .tf file to use for_each
# Now terraform plan should show no changes
```

---

## Dynamic Blocks — `for_each` Inside a Block

When a resource has a nested block you want to repeat (e.g. multiple ingress rules in a security group):

```hcl
variable "ingress_rules" {
  default = [
    { port = 80,  protocol = "tcp", cidr = "0.0.0.0/0" },
    { port = 443, protocol = "tcp", cidr = "0.0.0.0/0" },
    { port = 8080,protocol = "tcp", cidr = "10.0.0.0/8" },
  ]
}

resource "aws_security_group" "app" {
  name   = "app-sg"
  vpc_id = aws_vpc.main.id

  dynamic "ingress" {
    for_each = var.ingress_rules
    content {
      from_port   = ingress.value.port
      to_port     = ingress.value.port
      protocol    = ingress.value.protocol
      cidr_blocks = [ingress.value.cidr]
    }
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
```

Without dynamic blocks you'd have to hardcode each `ingress {}` block separately and the config would not be parameterizable.
