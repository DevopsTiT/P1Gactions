# Part 2 — HCL Syntax Deep Dive: Every Block Type Explained

---

## HCL Structure — The Anatomy of a .tf File

Every statement in HCL follows this pattern:

```
<block_type> "<type_label>" "<name_label>" {
  <argument> = <value>
}
```

- **block_type**: what kind of thing this is (`resource`, `variable`, `output`, `data`, `locals`, `module`, `terraform`, `provider`)
- **type_label**: the specific type (e.g. `aws_instance`, `aws_vpc`)
- **name_label**: your local name for this thing — only used inside Terraform to reference it
- **arguments**: key = value pairs inside the block

---

## 1. `resource` Block — The Core Building Block

```hcl
resource "aws_instance" "web_server" {
  # Required arguments (differ per resource type — read provider docs)
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t3.medium"
  subnet_id     = aws_subnet.public.id     # reference another resource

  # Nested block — some attributes are themselves blocks
  root_block_device {
    volume_size = 20
    volume_type = "gp3"
    encrypted   = true
  }

  # Tags are a map argument
  tags = {
    Name        = "web-server"
    Environment = var.environment
    ManagedBy   = "terraform"
  }
}
```

**How to reference this resource elsewhere:**
```hcl
# Format: <resource_type>.<local_name>.<attribute>
aws_instance.web_server.id
aws_instance.web_server.public_ip
aws_instance.web_server.private_ip
aws_instance.web_server.arn
```

**The resource address** (used in `terraform state`, `-target`, `terraform import`):
```
aws_instance.web_server
```

---

## 2. `variable` Block — Inputs (Full Detail)

Variables make your config reusable. They are like function parameters — callers provide values.

```hcl
variable "environment" {
  description = "Deployment environment"   # shown in terraform plan output
  type        = string                     # enforces type at plan time
  default     = "dev"                      # optional: used if no value provided
}
```

### All Variable Types

```hcl
# Primitive types
variable "name"    { type = string }
variable "count"   { type = number }
variable "enabled" { type = bool   }

# Collection types
variable "availability_zones" {
  type    = list(string)
  default = ["ap-northeast-1a", "ap-northeast-1c"]
}

variable "instance_sizes" {
  type = map(string)
  default = {
    dev        = "t3.micro"
    staging    = "t3.small"
    production = "t3.large"
  }
}

variable "ports" {
  type    = set(number)
  default = [80, 443, 8080]
}

# Object type — structured shape
variable "database_config" {
  type = object({
    instance_class    = string
    allocated_storage = number
    multi_az          = bool
  })
  default = {
    instance_class    = "db.t3.medium"
    allocated_storage = 20
    multi_az          = false
  }
}

# Tuple type — fixed-length list with mixed types
variable "server_config" {
  type    = tuple([string, number, bool])
  default = ["t3.medium", 3, true]
}
```

### Sensitive Variables

```hcl
variable "db_password" {
  description = "Database master password"
  type        = string
  sensitive   = true   # value hidden in plan/apply output
  # NO default — forces caller to always provide it
}
```

Plan output shows:
```
+ password = (sensitive value)   ← never printed to logs
```

### Validation Rules

```hcl
variable "environment" {
  type = string
  validation {
    condition     = contains(["dev", "staging", "production"], var.environment)
    error_message = "Environment must be dev, staging, or production."
  }
}

variable "instance_type" {
  type = string
  validation {
    condition     = can(regex("^t3\\.", var.instance_type))
    error_message = "Only t3 family instances are allowed."
  }
}
```

### How Variable Values Are Supplied (Priority Order, Highest First)

```
1. -var flag on command line:        terraform apply -var="environment=production"
2. -var-file flag:                   terraform apply -var-file="prod.tfvars"
3. terraform.tfvars file in directory (auto-loaded)
4. *.auto.tfvars files (auto-loaded alphabetically)
5. TF_VAR_<name> environment variables
6. Default value in variable block
7. Interactive prompt (if none of the above and no default)
```

---

## 3. `output` Block — Exports (Full Detail)

Outputs expose values after `terraform apply`. Three uses:
1. Print useful info to the operator (IP address, DNS name)
2. Pass data between modules (child module output → parent input)
3. Share data across separate Terraform configs via `terraform_remote_state`

```hcl
output "web_server_public_ip" {
  description = "Public IP address of the web server"
  value       = aws_instance.web_server.public_ip
}

# Sensitive output — value hidden in terminal, still stored in state
output "db_connection_string" {
  description = "Database connection string"
  value       = "postgresql://${var.db_user}:${var.db_password}@${aws_db_instance.main.endpoint}/app"
  sensitive   = true
}

# Computed output using expressions
output "instance_count" {
  value = length(aws_instance.workers)
}

# Output a map
output "service_endpoints" {
  value = {
    for name, svc in aws_instance.services :
    name => svc.public_ip
  }
}
```

Reading outputs:
```bash
terraform output                          # all outputs
terraform output web_server_public_ip     # specific output
terraform output -json                    # machine-readable JSON
terraform output -raw web_server_public_ip # raw value, no quotes (for scripts)
```

---

## 4. `locals` Block — Computed Values

Locals are computed once and reused. Prevents repeating the same expression. Like a `const` in JavaScript.

```hcl
locals {
  # Simple concatenation
  name_prefix = "${var.project}-${var.environment}"

  # Computed from a variable
  is_production = var.environment == "production"

  # Conditional value
  instance_type = local.is_production ? "t3.large" : "t3.micro"

  # Common tag map to apply to everything
  common_tags = {
    Project     = var.project
    Environment = var.environment
    ManagedBy   = "terraform"
    Owner       = var.team
  }

  # List manipulation
  azs = slice(data.aws_availability_zones.available.names, 0, 3)
}

# Usage — reference with local.<name>
resource "aws_instance" "app" {
  ami           = var.ami_id
  instance_type = local.instance_type
  tags          = merge(local.common_tags, { Name = "${local.name_prefix}-app" })
}
```

`merge()` combines two maps — the second overrides keys in the first.

---

## 5. `provider` Block — Cloud Authentication

```hcl
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"   # any 5.x version
    }
    dynatrace = {
      source  = "dynatrace-oss/dynatrace"
      version = ">= 1.0"
    }
  }
  required_terraform = ">= 1.5.0"
}

provider "aws" {
  region = var.aws_region

  # Optional: assume a specific IAM role (for cross-account deployments)
  assume_role {
    role_arn = "arn:aws:iam::123456789012:role/TerraformDeployRole"
  }

  # Apply these tags to EVERY resource by default
  default_tags {
    tags = {
      ManagedBy   = "terraform"
      Environment = var.environment
    }
  }
}

# Multiple provider instances with aliases (e.g. multi-region)
provider "aws" {
  alias  = "us_east"
  region = "us-east-1"
}

provider "aws" {
  alias  = "ap_northeast"
  region = "ap-northeast-1"
}

# Use aliased provider in a specific resource
resource "aws_s3_bucket" "us_backup" {
  provider = aws.us_east   # this bucket is in us-east-1
  bucket   = "my-backup-bucket-us"
}
```

### Version Constraints

```hcl
version = "= 5.0.0"   # exactly 5.0.0
version = ">= 5.0.0"  # 5.0.0 or higher
version = "~> 5.0"    # >= 5.0, < 6.0  (minor updates only)
version = "~> 5.0.0"  # >= 5.0.0, < 5.1.0  (patch updates only)
```

---

## 6. `data` Block — Read Existing Infrastructure

Data sources query existing resources WITHOUT managing them.

```hcl
# Look up the latest Amazon Linux 2 AMI automatically
data "aws_ami" "amazon_linux" {
  most_recent = true
  owners      = ["amazon"]

  filter {
    name   = "name"
    values = ["amzn2-ami-hvm-*-x86_64-gp2"]
  }
}

# Use it in a resource
resource "aws_instance" "app" {
  ami           = data.aws_ami.amazon_linux.id   # always latest AMI
  instance_type = "t3.medium"
}

# Look up an existing VPC (not managed by this Terraform)
data "aws_vpc" "shared_vpc" {
  tags = { Name = "shared-platform-vpc" }
}

# Look up available AZs in the current region
data "aws_availability_zones" "available" {
  state = "available"
}

# Fetch a secret from AWS Secrets Manager
data "aws_secretsmanager_secret_version" "db_password" {
  secret_id = "production/db/master-password"
}

# Use the secret
resource "aws_db_instance" "main" {
  password = data.aws_secretsmanager_secret_version.db_password.secret_string
}
```

Key rule: **data sources never create, modify, or destroy resources**. If the thing they reference doesn't exist, the plan fails with an error.

---

## 7. `terraform` Block — Meta Configuration

```hcl
terraform {
  # Minimum Terraform version required
  required_version = ">= 1.5.0"

  # Provider sources and version constraints
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  # Remote backend (where state is stored)
  backend "s3" {
    bucket         = "my-terraform-state"
    key            = "production/terraform.tfstate"
    region         = "ap-northeast-1"
    encrypt        = true
    dynamodb_table = "terraform-state-lock"
  }

  # Experimental features (rarely needed)
  experiments = [module_variable_optional_attrs]
}
```

---

## 8. Expressions and Functions

### String Interpolation

```hcl
name = "web-server-${var.environment}"   # → "web-server-production"
name = "${var.project}-${var.env}-db"    # → "myapp-production-db"
```

### Conditionals (Ternary)

```hcl
instance_type = var.environment == "production" ? "t3.large" : "t3.micro"
multi_az      = var.environment == "production" ? true : false
```

### For Expressions

```hcl
# Transform a list
variable "names" { default = ["alice", "bob", "carol"] }
locals {
  upper_names = [for n in var.names : upper(n)]
  # → ["ALICE", "BOB", "CAROL"]
}

# Filter a list
locals {
  prod_instances = [for inst in var.instances : inst if inst.env == "production"]
}

# Build a map from a list
locals {
  name_to_id = {for inst in aws_instance.workers : inst.tags["Name"] => inst.id}
}
```

### Splat Expressions

```hcl
# Get all IDs from a list of resources
output "all_instance_ids" {
  value = aws_instance.workers[*].id
  # same as: [for w in aws_instance.workers : w.id]
}
```

### Common Built-in Functions

```hcl
# String functions
upper("hello")        # "HELLO"
lower("HELLO")        # "hello"
trimspace("  hi  ")   # "hi"
replace("a-b-c", "-", "_")  # "a_b_c"
format("%-10s %5d", "name", 42)  # padded string

# Collection functions
length(["a","b","c"])           # 3
concat(["a","b"], ["c","d"])    # ["a","b","c","d"]
flatten([["a","b"],["c"]])      # ["a","b","c"]
distinct(["a","b","a"])         # ["a","b"]
contains(["a","b"], "a")        # true
merge({a=1}, {b=2})             # {a=1, b=2}
keys({a=1, b=2})                # ["a","b"]
values({a=1, b=2})              # [1, 2]

# Numeric functions
max(1, 2, 3)    # 3
min(1, 2, 3)    # 1
ceil(1.2)       # 2
floor(1.8)      # 1

# Encoding
base64encode("hello")           # "aGVsbG8="
jsonencode({key = "value"})     # "{\"key\":\"value\"}"
jsondecode("{\"key\":\"value\"}")  # {key = "value"}

# IP / CIDR functions
cidrsubnet("10.0.0.0/16", 8, 1)   # "10.0.1.0/24"
cidrhost("10.0.1.0/24", 5)        # "10.0.1.5"

# Type conversion
tostring(42)      # "42"
tonumber("42")    # 42
tolist(toset(["a","b","a"]))  # ["a","b"] — deduped
```
