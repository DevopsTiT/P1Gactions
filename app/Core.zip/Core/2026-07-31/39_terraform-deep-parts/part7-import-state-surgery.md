# Part 7 — Importing Existing Infrastructure & State Surgery

---

## Why You Need `terraform import`

In the real world, infrastructure exists before Terraform does. Before IaC was adopted:
- Ops engineers clicked through AWS console to create VPCs, RDS instances, EC2 servers
- CI/CD pipelines used AWS CLI scripts
- Other tools like CloudFormation or Pulumi managed some resources

`terraform import` solves the "adopt existing infra" problem: it writes a real cloud resource into Terraform's state file, bringing it under Terraform management WITHOUT recreating it.

```
Before import:
  Real cloud: RDS instance "production-db" (db-i-abc123)
  .tfstate:   (nothing — Terraform doesn't know about it)
  .tf files:  (nothing)

After import:
  Real cloud: RDS instance "production-db" (db-i-abc123)  ← unchanged
  .tfstate:   { "aws_db_instance.main": { id: "production-db", ... } }
  .tf files:  resource "aws_db_instance" "main" { ... }  ← you must write this
```

---

## The Import Workflow — Step by Step

### Step 1: Find the resource's import ID

Every resource type has a specific ID format for importing. Check the provider documentation:

| Resource | Import ID format | Example |
|---|---|---|
| aws_instance | instance ID | `i-0abc123def456789` |
| aws_s3_bucket | bucket name | `my-bucket-name` |
| aws_db_instance | DB identifier | `production-db` |
| aws_vpc | VPC ID | `vpc-12345678` |
| aws_security_group | SG ID | `sg-12345678` |
| aws_iam_role | role name | `my-role-name` |
| aws_eks_cluster | cluster name | `production-eks` |
| kubernetes_namespace | namespace name | `monitoring` |
| aws_route53_record | zone_id/name/type | `Z1234/_acme-challenge.example.com/CNAME` |

```bash
# Find the resource ID from AWS CLI:
aws ec2 describe-instances \
  --filters "Name=tag:Name,Values=production-web" \
  --query "Reservations[*].Instances[*].InstanceId" \
  --output text
# i-0abc123def456789

aws rds describe-db-instances \
  --query "DBInstances[*].DBInstanceIdentifier" \
  --output text
# production-db

aws s3api list-buckets \
  --query "Buckets[*].Name" \
  --output text
```

### Step 2: Write the empty resource block in `.tf`

Import puts the resource into state, but you still need a `.tf` declaration. Start with a minimal block:

```hcl
# main.tf — placeholder before import
resource "aws_db_instance" "main" {
  # empty — we'll fill this in after import
}
```

### Step 3: Run `terraform import`

```bash
# terraform import <resource_address> <import_id>
terraform import aws_db_instance.main production-db
# Importing from ID "production-db"...
# Import successful!
# The resources that were imported are shown above. These resources are now in
# your Terraform state and will henceforth be managed by Terraform.
```

### Step 4: Run `terraform plan` to see the gaps

```bash
terraform plan
# This will show everything Terraform found in state but you haven't declared in .tf:

# ~ aws_db_instance.main
#   + engine                = "postgres"          (required, missing from .tf)
#   + instance_class        = "db.r6g.large"      (required, missing from .tf)
#   + allocated_storage     = 100                 (required, missing from .tf)
#   + deletion_protection   = true                (required, missing from .tf)
#   ...50 more attributes...
```

### Step 5: Fill in the `.tf` resource until `plan` shows no changes

```hcl
resource "aws_db_instance" "main" {
  identifier        = "production-db"
  engine            = "postgres"
  engine_version    = "15.4"
  instance_class    = "db.r6g.large"
  allocated_storage = 100
  storage_type      = "gp3"
  storage_encrypted = true

  db_name  = "app_production"
  username = "dbadmin"
  password = var.db_password   # sensitive — from env var

  multi_az               = true
  deletion_protection    = true
  skip_final_snapshot    = false
  final_snapshot_identifier = "production-db-final"

  backup_retention_period = 7
  backup_window           = "03:00-04:00"
  maintenance_window      = "Mon:04:00-Mon:05:00"

  vpc_security_group_ids = [aws_security_group.db.id]
  db_subnet_group_name   = aws_db_subnet_group.main.name

  tags = {
    Name        = "production-db"
    Environment = "production"
    ManagedBy   = "terraform"
  }

  lifecycle {
    prevent_destroy = true
    ignore_changes  = [password]   # managed externally via rotation
  }
}
```

```bash
terraform plan
# No changes. Your infrastructure matches the configuration.
# ← This is the goal. Import is complete.
```

---

## Modern Import: `import` Blocks (Terraform 1.5+)

Instead of running a CLI command, declare the import in code:

```hcl
# main.tf
import {
  to = aws_db_instance.main
  id = "production-db"
}

resource "aws_db_instance" "main" {
  # attributes...
}
```

Benefits:
- Import is version-controlled and reviewable in PRs
- Can import multiple resources in one `terraform apply`
- Works in CI/CD pipelines

```bash
terraform plan   # shows what will be imported + any config gaps
terraform apply  # performs the import and reconciles config
```

After apply, the `import` block is no longer needed and can be removed from `.tf`.

---

## Terraform `generate` — Auto-Write the Resource Config (1.5+)

Terraform 1.5+ can generate the `.tf` code for you from existing state:

```bash
# After writing the import block and running init:
terraform plan -generate-config-out=generated.tf

# generated.tf now contains a fully populated resource block
# Review it, edit as needed, then move to main.tf
```

This saves the tedious step of manually filling in all attributes.

---

## State Surgery — `terraform state` Subcommands

State surgery = directly modifying what Terraform knows about, without touching real infrastructure. Used for refactors, migrations, recovery.

### `terraform state list` — See Everything in State

```bash
terraform state list
# aws_vpc.main
# aws_subnet.public[0]
# aws_subnet.public[1]
# aws_subnet.public[2]
# module.compute.aws_instance.app["payments"]
# module.compute.aws_instance.app["checkout"]
# aws_db_instance.main

# Filter by prefix
terraform state list module.compute
# module.compute.aws_instance.app["payments"]
# module.compute.aws_instance.app["checkout"]
```

### `terraform state show` — Inspect One Resource

```bash
terraform state show aws_db_instance.main
# # aws_db_instance.main:
# resource "aws_db_instance" "main" {
#     address                               = "production-db.abc123.ap-northeast-1.rds.amazonaws.com"
#     allocated_storage                     = 100
#     arn                                   = "arn:aws:rds:ap-northeast-1:123456:db:production-db"
#     id                                    = "production-db"
#     instance_class                        = "db.r6g.large"
#     multi_az                              = true
#     ...
# }

# Very useful for finding attribute values (IDs, ARNs, endpoints) to use in other resources
```

### `terraform state mv` — Rename or Move a Resource

Used when you refactor your `.tf` code (rename a resource, move it into a module) and need Terraform to know the old resource is the same as the new address — otherwise it would destroy + recreate.

```bash
# Scenario: you renamed aws_instance.web_server to aws_instance.app
# Without state mv: plan shows destroy web_server, create app
# With state mv:

terraform state mv aws_instance.web_server aws_instance.app
# Moved aws_instance.web_server to aws_instance.app successfully.

terraform plan
# No changes. ← The instance was not recreated

# Scenario: you moved a resource into a module
terraform state mv aws_instance.app module.compute.aws_instance.app

# Scenario: you converted from count to for_each
terraform state mv 'aws_instance.worker[0]' 'aws_instance.worker["payments"]'
terraform state mv 'aws_instance.worker[1]' 'aws_instance.worker["checkout"]'
```

### `terraform state rm` — Remove from State Without Destroying

Removes Terraform's knowledge of a resource. The real cloud resource continues to exist — Terraform just stops managing it.

Use cases:
- Migrating a resource from one Terraform project to another
- Stopping Terraform from managing something that another tool will take over
- Removing orphaned state records for resources that no longer exist (cleanup)

```bash
# Remove a single resource from state
terraform state rm aws_instance.old_server
# Removed aws_instance.old_server from state successfully

# Remove all resources in a module from state
terraform state rm module.old_module

# After state rm: if the resource block still exists in .tf,
# terraform plan will want to CREATE it again.
# Either: remove the .tf block too (forget about it)
# Or: re-import it somewhere else
```

### `terraform state pull` and `terraform state push` — Raw State Access

```bash
# Download current remote state to local file
terraform state pull > current-state.json

# Inspect it
cat current-state.json | jq '.resources[] | {type: .type, name: .name}'

# Push a modified state back (DANGEROUS — skips all safety checks)
terraform state push modified-state.json

# Common recovery scenario:
# 1. Pull current state
# 2. Edit JSON to fix a specific issue (e.g. remove a corrupted record)
# 3. Push back
# This bypasses all Terraform validation — only for emergency recovery
```

---

## Recovering from Lost State

Worst case: the S3 bucket is gone, no versioning was enabled, state file is lost.

Recovery process:
```bash
# Step 1: Create empty state (or start fresh with terraform init)
terraform init

# Step 2: Write .tf files describing what exists (if you don't have them)

# Step 3: Import every resource one by one
terraform import aws_vpc.main vpc-12345678
terraform import aws_subnet.public[0] subnet-aaa
terraform import aws_subnet.public[1] subnet-bbb
terraform import aws_db_instance.main production-db
# ... continue for every resource

# Step 4: Run terraform plan, fill in .tf until no changes
terraform plan

# This is extremely tedious — prevention (S3 versioning + backup) is far better
```

Prevention:
```bash
# Schedule regular state backups
aws s3 cp \
  s3://my-company-terraform-state/production/terraform.tfstate \
  s3://my-company-terraform-backups/state-$(date +%Y%m%d).tfstate
```
