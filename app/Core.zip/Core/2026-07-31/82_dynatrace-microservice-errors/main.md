# Common Dynatrace Errors for Microservices — Deep Dive Troubleshooting

---

## Master Error Map

```
Dynatrace microservice errors split into 6 categories:

┌─────────────────────────────────────────────────────────────────────┐
│  Category 1: Agent / Injection Errors                               │
│    - OneAgent not injecting into pods                               │
│    - Agent connected but no services appearing                      │
│    - Agent version mismatch                                         │
├─────────────────────────────────────────────────────────────────────┤
│  Category 2: Distributed Trace Errors                               │
│    - Traces broken / split across services                          │
│    - Missing spans / incomplete traces                              │
│    - W3C vs Dynatrace trace propagation conflict                    │
├─────────────────────────────────────────────────────────────────────┤
│  Category 3: Service Detection Errors                               │
│    - Wrong service name (generic "Java" instead of real name)       │
│    - Multiple services merged into one                              │
│    - One service split into many                                    │
├─────────────────────────────────────────────────────────────────────┤
│  Category 4: Metric / Alert Errors                                  │
│    - Alert fires on wrong service / wrong threshold                 │
│    - Missing metrics (JVM, DB, custom)                              │
│    - Metric cardinality explosion                                   │
├─────────────────────────────────────────────────────────────────────┤
│  Category 5: Log Monitoring Errors                                  │
│    - Logs not appearing                                             │
│    - Log parsing wrong (fields missing / mistyped)                  │
│    - Log ingest limit hit                                           │
├─────────────────────────────────────────────────────────────────────┤
│  Category 6: Tagging / Management Zone Errors                       │
│    - Tags not propagating to services                               │
│    - Management zone showing wrong entities                         │
│    - Alerting profile not firing for the right team                 │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Category 1 — Agent / Injection Errors

### Error 1.1: OneAgent Not Injecting Into Pods

**What you see:**
- Pod is running but no service appears in Dynatrace UI
- `kubectl exec` into pod: `/opt/dynatrace/oneagent/` directory does not exist
- Dynatrace UI: host has infrastructure metrics but NO service / traces

**Why it happens:**
```
Root cause A: Namespace missing dynatrace.com/inject=true label
Root cause B: DynaKube namespaceSelector doesn't match namespace
Root cause C: Pod was running before injection was enabled (old pods not recycled)
Root cause D: OneAgent Operator not healthy (crash loop, wrong token)
Root cause E: Pod has opt-out annotation: oneagent.dynatrace.com/inject=false
```

**Diagnose:**
```bash
# Step 1: Check namespace label
kubectl get namespace <your-ns> --show-labels
# Must show: dynatrace.com/inject=true

# Step 2: Check DynaKube namespaceSelector matches
kubectl describe dynakube dynakube -n dynatrace | grep -A10 "Namespace Selector\|namespaceSelector"

# Step 3: Check the Operator is healthy
kubectl get pods -n dynatrace
# All pods should be Running, not CrashLoopBackOff or Pending

# Step 4: Check pod injection status
kubectl get pod <pod-name> -n <ns> -o jsonpath='{.metadata.annotations}' | python3 -m json.tool
# Look for: "oneagent.dynatrace.com/injected": "true"
# If missing or "false" → not injected

# Step 5: Check for opt-out annotation on the pod spec
kubectl describe pod <pod-name> -n <ns> | grep "oneagent.dynatrace.com/inject"

# Step 6: Check Operator webhook logs (the webhook does the injection)
kubectl logs -n dynatrace \
  $(kubectl get pod -n dynatrace -l app.kubernetes.io/component=webhook -o name) \
  --tail=50 | grep -iE "error|inject|denied|<pod-name>"

# Step 7: Check the CSI driver is healthy (mounts the agent code module)
kubectl get pods -n dynatrace -l app=dynatrace-operator
kubectl logs -n dynatrace \
  $(kubectl get pod -n dynatrace -l app.kubernetes.io/component=csi-driver -o name | head -1) \
  --tail=30
```

**Fix:**
```bash
# Fix A: Add missing namespace label
kubectl label namespace <your-ns> dynatrace.com/inject=true

# Fix B: Update DynaKube to include your namespace
kubectl edit dynakube dynakube -n dynatrace
# Change or remove namespaceSelector to include your namespace

# Fix C: Restart pods so injection takes effect
kubectl rollout restart deployment/<deployment-name> -n <your-ns>

# Fix D: Recreate the Dynatrace API token secret
kubectl delete secret dynakube -n dynatrace
kubectl create secret generic dynakube \
  --namespace=dynatrace \
  --from-literal="apiToken=<NEW_API_TOKEN>" \
  --from-literal="dataIngestToken=<NEW_INGEST_TOKEN>"
kubectl rollout restart deployment/dynatrace-operator -n dynatrace

# Fix E: Remove opt-out annotation from pod spec
kubectl annotate pod <pod-name> -n <ns> oneagent.dynatrace.com/inject-
# OR edit the Deployment spec to remove the annotation
```

---

### Error 1.2: Agent Connected but No Services Appear

**What you see:**
- Host appears under Infrastructure → Hosts
- No entries under Applications & Microservices → Services
- Process groups appear but no service entity

**Why it happens:**
```
- Service is not making HTTP/gRPC/DB calls that Dynatrace can detect
- Port not recognized (custom port, not standard 8080/443/5432)
- Process starts but exits before agent can attach
- Protocol is not supported without configuration (e.g. raw TCP, AMQP)
```

**Diagnose:**
```bash
# Step 1: Confirm process is detected (process group ≠ service)
# In DT UI: Infrastructure → Hosts → [host] → Processes tab
# If the Java/Node process appears here but no service exists → agent sees it but no calls detected

# Step 2: Check what ports the process listens on
kubectl exec -n <ns> <pod> -- ss -tlnp
# If listening on a non-standard port (e.g. 9000), Dynatrace may not auto-detect the protocol

# Step 3: Check if the app actually receives requests
kubectl exec -n <ns> <pod> -- curl -s http://localhost:8080/health
# If no one is calling the service, no service entity is created

# Step 4: Check agent log for protocol detection
kubectl exec -n <ns> <pod> -- ls /opt/dynatrace/oneagent/log/
kubectl exec -n <ns> <pod> -- tail -50 /opt/dynatrace/oneagent/log/oneagent.log \
  | grep -iE "service|detect|protocol|sensor"
```

**Fix:**
```bash
# Fix: Configure custom service detection rule in Dynatrace UI
# Settings → Service Detection → Custom Service Detection
# Add rule: if port = 9000 AND protocol = HTTP → create service named "my-service"

# OR: Configure port via process group detection
# Settings → Processes and Containers → Process Group Detection
# Rule: executable = "java" AND listen-port = 9000 → group as "payment-service"
```

---

### Error 1.3: Agent Version Mismatch Warning

**What you see:**
- Yellow warning in Dynatrace UI: "Agent version outdated"
- Some features (log monitoring, traces) missing because agent is too old
- DynaKube shows version drift across nodes

**Diagnose:**
```bash
# Check agent version on a specific pod
kubectl exec -n <ns> <pod> -- \
  /opt/dynatrace/oneagent/agent/tools/oneagentctl --version

# Check DynaKube current version vs target version
kubectl describe dynakube dynakube -n dynatrace | grep -iE "version|image"

# Check all DaemonSet pods and their agent versions
kubectl get pods -n dynatrace -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.spec.containers[0].image}{"\n"}{end}'

# Check if auto-update is enabled in DynaKube
kubectl get dynakube dynakube -n dynatrace -o yaml | grep -A5 "autoUpdate"
```

**Fix:**
```bash
# Enable automatic agent updates in DynaKube
kubectl patch dynakube dynakube -n dynatrace --type=merge -p '
{
  "spec": {
    "oneAgent": {
      "cloudNativeFullStack": {
        "autoUpdate": {
          "enabled": true,
          "maxUnavailable": 1
        }
      }
    }
  }
}'

# Force immediate update by deleting old DaemonSet pods (they restart with new image)
kubectl delete pods -n dynatrace -l app.kubernetes.io/component=oneagent
# DaemonSet controller immediately recreates them with the latest version
```

---

## Category 2 — Distributed Trace Errors

### Error 2.1: Traces Broken / Split Across Services

**What you see:**
- A request goes: API Gateway → Order Service → Payment Service
- In Distributed Traces UI: you see 3 SEPARATE traces instead of 1 connected trace
- Trace IDs don't match across service boundaries
- Can't see the full end-to-end flow

**Why it happens:**
```
Root cause A: Service B does NOT propagate the Dynatrace trace headers
              (custom HTTP client that doesn't use injected byte buddy agent)
Root cause B: Service B uses a different trace format (W3C traceparent vs DT x-dynatrace)
Root cause C: Async call via message queue — correlation lost without explicit propagation
Root cause D: Service B is not instrumented (no OneAgent)
Root cause E: Load balancer or proxy strips the x-dynatrace header
```

**Diagnose:**
```bash
# Step 1: Verify trace headers are being sent
kubectl exec -n <ns> <caller-pod> -- \
  curl -v http://payment-service:8080/api/charge 2>&1 | grep -i "x-dynatrace\|traceparent\|b3"
# If NO trace headers in request → instrumentation not injecting headers

# Step 2: Check if receiver sees the header
kubectl exec -n <ns> <receiver-pod> -- \
  nc -l -p 9999 &  # temporary listener
# Send request through it and see raw headers

# Step 3: Check if W3C trace context is enabled
# In DT UI: Settings → Server-side service monitoring → Deep monitoring
# → Distributed tracing → confirm "W3C Trace Context" is enabled

# Step 4: Check if the proxy / ingress strips headers
kubectl exec -n <ns> <pod> -- \
  curl -v -H "x-dynatrace: FW3;..." http://localhost:8080/ 2>&1 | grep -i "x-dynatrace"
# If header is not passed through, the proxy is stripping it

# Step 5: For async (Kafka/RabbitMQ) — check if message headers are set
# DT auto-instruments Kafka consumer/producer only for supported clients
# Check: Settings → Distributed Tracing → Messaging systems → Kafka enabled?
```

**Fix:**
```bash
# Fix A: Enable W3C trace context propagation (both sides must use it)
# Settings → Server-side service monitoring → Distributed tracing
# → Enable "W3C Trace Context"
# This makes Dynatrace send AND accept the standard "traceparent" header

# Fix B: Configure ingress to pass trace headers
# For nginx-ingress:
kubectl patch configmap nginx-configuration -n ingress-nginx --type=merge -p '
{
  "data": {
    "proxy-set-headers": "x-dynatrace",
    "enable-opentelemetry-sdk": "true"
  }
}'

# For AWS ALB ingress — add annotation to the Ingress resource:
# alb.ingress.kubernetes.io/load-balancer-attributes: routing.http.x_amzn_trace_id.enabled=true

# Fix C: For async messaging — manually propagate trace context
# In Java (Spring Kafka):
# Producer: add DT trace header to ProducerRecord headers
# Consumer: extract header before processing
# DT SDK: DynatraceSDK.getInstance().traceContextPropagation()

# Fix D: For an un-instrumented hop (third-party service) — use Entry Point
# Settings → Service Detection → Custom Entry Points
# Declare that service X is the entry point for calls coming from Y
```

---

### Error 2.2: Missing Spans in Trace (Incomplete Traces)

**What you see:**
- Trace shows A → C but B is missing in the middle
- Trace has gaps: A ends at T+100ms, C starts at T+200ms, 100ms unaccounted
- "Unknown service" placeholder in the trace waterfall

**Why it happens:**
```
- Service B uses an unsupported framework version
- Service B uses a custom HTTP client (not HttpURLConnection / OkHttp / RestTemplate)
- Service B is a native binary (C/Go) — requires OpenTelemetry SDK, not OneAgent auto-instrumentation
- Span sampling rate < 100% — some spans randomly dropped
- Agent lost connection to DT cluster during the window
```

**Diagnose:**
```bash
# Step 1: Check the agent actually traced service B's calls
kubectl exec -n <ns> <service-b-pod> -- \
  tail -f /opt/dynatrace/oneagent/log/oneagent.log | grep -iE "trace|span|request"

# Step 2: Check supported technologies
# DT UI: Infrastructure → Hosts → [host] → [process] → Properties
# Look for "Technologies" list — if your framework is missing, it's not auto-instrumented

# Step 3: Check sampling rate
# DT UI: Settings → Server-side service monitoring → Adaptive traffic management
# If "Adaptive sampling" is on with low rate → spans are dropped
# For microservices in dev/test: disable sampling or set to 100%

# Step 4: Confirm agent connectivity
kubectl exec -n <ns> <pod> -- \
  /opt/dynatrace/oneagent/agent/tools/oneagentctl --get-server
# Should return your DT environment URL, not empty
```

**Fix:**
```bash
# Fix 1: For unsupported custom HTTP client — use OpenTelemetry SDK
# Add OTel SDK to the service and configure the DT OTel exporter:
# OTEL_EXPORTER_OTLP_ENDPOINT=https://<ENV>.live.dynatrace.com/api/v2/otlp
# OTEL_EXPORTER_OTLP_HEADERS=Authorization=Api-Token <TOKEN>

# Fix 2: Disable adaptive sampling for critical services
# Settings → Adaptive traffic management
# Set "Capture all traffic" for payment-service and other critical paths

# Fix 3: For Go/C/Rust services — instrument with OTel
# Go example:
# import "go.opentelemetry.io/otel"
# Then export to DT OTLP endpoint

# Fix 4: Restart agent if connectivity dropped
kubectl delete pod -n <ns> <pod-name>
# Pod recreates with fresh agent connection
```

---

## Category 3 — Service Detection Errors

### Error 3.1: Service Named "Java" Instead of Real Name

**What you see:**
- In DT UI: service is called "Java" or "node.js" or "Python"
- All your microservices merge into one generic entity
- Can't distinguish payment-service from checkout-service in dashboards

**Why it happens:**
```
- No process group detection rules defined
- Service doesn't expose a name via metadata (no spring.application.name)
- Multiple apps running in the same JVM process
- JVM started with generic launcher (wrapper script, not direct jar)
```

**Diagnose:**
```bash
# Step 1: Check what Dynatrace sees as the executable name
# DT UI: Infrastructure → Hosts → [host] → Processes
# Look at "Process name" and "Working directory" columns

# Step 2: Check if spring.application.name is set
kubectl exec -n <ns> <pod> -- env | grep -iE "SPRING_APPLICATION_NAME\|APP_NAME\|SERVICE_NAME"

# Step 3: Check JVM startup args
kubectl exec -n <ns> <pod> -- cat /proc/1/cmdline | tr '\0' ' '
# Look for: -Dspring.application.name=payment-service
# or: -jar /app/payment-service.jar (the jar name is a fallback)
```

**Fix:**
```bash
# Fix 1: Set spring.application.name in deployment env vars
kubectl patch deployment payment-service -n payment-ns --type=json -p='[
  {
    "op": "add",
    "path": "/spec/template/spec/containers/0/env/-",
    "value": {"name": "SPRING_APPLICATION_NAME", "value": "payment-service"}
  }
]'

# Fix 2: Create Process Group Detection rule in DT UI
# Settings → Processes and Containers → Process Group Detection → Add rule
# Rule: if command_line contains "payment-service.jar" → name = "payment-service"

# Fix 3: Use environment variable DT_CUSTOM_PROP (DT-native naming)
kubectl patch deployment payment-service -n payment-ns --type=json -p='[
  {
    "op": "add",
    "path": "/spec/template/spec/containers/0/env/-",
    "value": {
      "name": "DT_CUSTOM_PROP",
      "value": "SERVICE_NAME=payment-service TEAM=payments"
    }
  }
]'
# DT reads DT_CUSTOM_PROP as process group properties and uses SERVICE_NAME
```

---

### Error 3.2: Services Incorrectly Merged or Split

**What you see (merge):**
- 5 microservices appear as ONE service in Dynatrace
- All request counts, error rates are combined — can't isolate one service

**What you see (split):**
- One service appears as 10 different services (one per pod, one per AZ)
- Can't see aggregate metrics — dashboards are fragmented

**Why it happens:**
```
Merge: all services run on same port (8080) without name differentiation
Split: each pod has a unique property (hostname, IP) used in process group name
```

**Diagnose:**
```bash
# Check current process group naming
# DT UI: Infrastructure → Process Groups
# Look at the "Process Group Naming" property for each group

# For split issue — check if hostname/IP is in process name
kubectl exec -n <ns> <pod> -- env | grep -iE "hostname|pod_name|DT_"
# If DT sees hostname as part of the identifier → each pod = separate group
```

**Fix:**
```bash
# Fix for MERGE: separate by adding unique identifiers to each service
# Add SERVICE_NAME env var to each deployment individually (see Error 3.1 Fix 1)

# Fix for SPLIT: override DT's process group identification
# DT UI: Settings → Processes and Containers → Process Group Detection
# Create rule that strips hostname/pod from the group name:
# Rule: "if executable=java AND port=8080 → name = command_line_arg(-Dservice.name)"

# Fix via DT_ENTITY_TAGS on each deployment
kubectl patch deployment payment-service -n payment-ns --type=json -p='[
  {
    "op": "add",
    "path": "/spec/template/spec/containers/0/env/-",
    "value": {
      "name": "DT_TAGS",
      "value": "service:payment microservice:true"
    }
  }
]'
```

---

## Category 4 — Metric / Alert Errors

### Error 4.1: Alert Fires on Wrong Service / Threshold Too Sensitive

**What you see:**
- PagerDuty fires at 2am for a dev environment service
- Alert fires for 0.1% error rate (should only fire at 1% for this service)
- Wrong team gets notified

**Why it happens:**
```
- Alerting profile not scoped to management zone
- Threshold is global (applies to all services equally)
- No environment filter on the alerting profile
```

**Diagnose + Fix:**
```bash
# In DT UI:
# Step 1: Check Alerting Profile → which management zones it covers
# Alerting → Alerting Profiles → [profile] → Management Zones filter
# If "All entities" → every service triggers it

# Step 2: Create environment-specific profiles
# Alerting → Alerting Profiles → Add profile
# Name: "Production - Payments Team"
# Management Zone: "payments-production"
# Severity filter: Error, Availability
# Delay: 5 minutes (don't page on transient 1-minute spikes)

# Step 3: Assign profile to the right notification channel
# Alerting → Problem notifications → Add notification
# → PagerDuty / Slack → Filter by alerting profile "Production - Payments"

# Step 4: Tune per-service thresholds
# Settings → Anomaly Detection → Services
# Select: payment-service → Custom thresholds
# Error rate threshold: 1% (not global 0.5%)
# Response time threshold: 800ms P95 (not global 200ms)
```

---

### Error 4.2: JVM / Custom Metrics Missing

**What you see:**
- JVM heap, GC time, thread count not visible in Dynatrace
- Custom `micrometer` / Prometheus metrics not showing up
- Metric exists in Prometheus but not in DT

**Why it happens:**
```
- JVM deep monitoring not enabled for this process group
- Micrometer DT exporter not configured
- Custom metric API endpoint not configured
- Metric prefix filtered out
```

**Diagnose + Fix:**
```bash
# Fix 1: Enable JVM deep monitoring
# DT UI: Settings → Server-side service monitoring → Deep monitoring
# → Java / Kotlin (JVM) → Enable JVM metrics
# → Select process groups: payment-service ✓

# Fix 2: Configure Micrometer → DT export (Spring Boot)
# Add to application.properties:
# management.dynatrace.metrics.export.enabled=true
# management.dynatrace.metrics.export.uri=https://<ENV>.live.dynatrace.com
# management.dynatrace.metrics.export.api-token=<TOKEN>
# management.dynatrace.metrics.export.step=30s

# Fix 3: Push custom metrics via DT Metrics API
curl -X POST \
  "https://<ENV_ID>.live.dynatrace.com/api/v2/metrics/ingest" \
  -H "Authorization: Api-Token <TOKEN>" \
  -H "Content-Type: text/plain; charset=utf-8" \
  -d "payment.processing.time,service=payment-service 245.5"
# Format: <metric.key>,<dimensions> <value>

# Fix 4: Ingest Prometheus metrics via DT scraping
# In DT UI: Settings → Cloud and virtualization → Prometheus
# Add scrape config:
# Target: http://payment-service:8080/actuator/prometheus
# Namespace: payment-ns
```

---

### Error 4.3: Metric Cardinality Explosion

**What you see:**
- "Too many metric dimensions" warning in DT UI
- Custom metrics stop ingesting
- DT billing spikes suddenly

**Why it happens:**
```
- Using pod name, trace ID, or user ID as a metric dimension
- These have unbounded cardinality (millions of unique values)
- DT limits: 100,000 unique dimension value combinations per metric key
```

**Diagnose + Fix:**
```bash
# In DT UI: Settings → Metrics → Metric metadata
# Find your metric and check the dimension count

# Fix: Remove high-cardinality dimensions (pod name, trace ID, request ID)
# BAD:  payment.latency,pod=payment-6d7f9b-xyz,trace=abc123 245
# GOOD: payment.latency,service=payment,env=production 245

# In Micrometer — use only stable low-cardinality tags:
# MeterRegistry.config().commonTags("service", "payment", "env", "production")
# NEVER tag with: userId, orderId, requestId, podName, traceId
```

---

## Category 5 — Log Monitoring Errors

### Error 5.1: Logs Not Appearing in Dynatrace

**What you see:**
- Application is logging but Log Viewer in DT shows empty
- Logs appear in `kubectl logs` but not in DT UI

**Why it happens:**
```
- Log content (stdout/stderr) not configured as a log source
- Log monitoring not enabled for the process group
- Log file path not configured (if writing to file, not stdout)
- Log ingest token missing permissions
```

**Diagnose + Fix:**
```bash
# Step 1: Verify log monitoring is enabled globally
# DT UI: Settings → Log Monitoring → Log sources and storage
# → "Monitor OneAgent log sources" must be ON

# Step 2: Enable for this specific process group
# DT UI: Settings → Log Monitoring → Log sources and storage
# → Add log source
# Process group: payment-service
# Log source type: Container runtime / stdout-stderr

# Step 3: For file-based logs (not stdout)
# Add custom log source:
# Path: /var/log/payment/*.log
# Process group: payment-service

# Step 4: Verify via DT API that logs are being received
curl -s \
  "https://<ENV>.live.dynatrace.com/api/v2/logs/search?from=now-15m&query=payment" \
  -H "Authorization: Api-Token <TOKEN>" | jq '.results | length'
# If 0 → logs not reaching DT
```

---

### Error 5.2: Log Parsing Wrong (Fields Missing)

**What you see:**
- Logs appear but as raw unstructured text
- Severity field missing (all logs show as INFO even when they're ERROR)
- Timestamp is wrong or missing
- Can't filter by `level:ERROR` or `service.name:payment`

**Why it happens:**
```
- App logs in a custom format (not JSON, not standard log4j pattern)
- JSON log field names don't match DT's expected schema
- Log timestamp in wrong timezone or format
```

**Diagnose + Fix:**
```bash
# Step 1: Switch to JSON structured logging (Spring Boot)
# application.properties:
# logging.structured.format.console=ecs  (Elastic Common Schema — DT understands this)
# OR: use logstash-logback-encoder for JSON output

# Step 2: Create a custom log processing rule in DT
# DT UI: Settings → Log Monitoring → Log processing
# Add rule for process group: payment-service
# Processor:
#   PARSE(content, "JSON{STRING:level AS loglevel, STRING:message AS content}")
#   | FIELDS_ADD(severity: loglevel)

# Step 3: Map your JSON fields to DT schema
# DT expected fields:
#   "severity" or "level" → maps to log level (ERROR/WARN/INFO)
#   "timestamp" → log timestamp (ISO 8601)
#   "message" or "msg" → main log line
#   "service.name" → Dynatrace service linkage
#   "trace_id" → links log to distributed trace
#
# If your app uses different names, create a mapping rule:
# FIELDS_RENAME(severity: log_level, content: msg)

# Step 4: Verify structured log output from pod
kubectl logs -n payment-ns <pod-name> --tail=5
# Should see JSON: {"timestamp":"2026-07-31T10:00:00Z","level":"ERROR","message":"..."}
```

---

### Error 5.3: Log Ingest Limit Hit

**What you see:**
- "Log ingest limit exceeded" warning in DT UI
- Logs from high-traffic services start disappearing
- DT billing shows unexpected log data volume

**Diagnose + Fix:**
```bash
# Step 1: Check current log usage
# DT UI: Settings → Log Monitoring → Log storage configuration
# Shows: daily log ingest volume vs limit

# Fix 1: Reduce log verbosity for non-critical services
# Set INFO level in production (not DEBUG):
kubectl patch configmap app-config -n payment-ns --type=merge -p '
{"data": {"LOG_LEVEL": "INFO"}}'
# Then restart the pod

# Fix 2: Filter out noisy low-value logs before ingest
# DT UI: Settings → Log Monitoring → Log processing
# Add filter rule:
# IF log.level == "DEBUG" AND service.name != "payment-service" THEN DROP
# IF content CONTAINS "/actuator/health" THEN DROP  ← health check spam

# Fix 3: Set retention per log source (shorter retention for dev)
# Settings → Log Monitoring → Log storage configuration
# Production logs: 35 days
# Dev/staging logs: 7 days
```

---

## Category 6 — Tagging / Management Zone Errors

### Error 6.1: Tags Not Propagating to Services

**What you see:**
- You set `team: payments` on the namespace / pod
- DT service entity has NO tags
- Management zone rule based on `team:payments` shows empty

**Why it happens:**
```
- metadataEnrichment disabled in DynaKube
- Auto-tagging rule not created for the tag key
- Tags on namespace but pods don't inherit them (wrong DynaKube config)
- DT_TAGS env var not set in the deployment
```

**Diagnose + Fix:**
```bash
# Step 1: Check metadataEnrichment in DynaKube
kubectl get dynakube dynakube -n dynatrace -o yaml | grep -A5 "metadataEnrichment"
# Must show: enabled: true

# Fix: Enable it
kubectl patch dynakube dynakube -n dynatrace --type=merge -p '
{
  "spec": {
    "metadataEnrichment": {
      "enabled": true
    }
  }
}'

# Step 2: Add auto-tagging rule in DT UI
# Settings → Tags → Automatically applied tags → Add new rule
# Tag name: team
# Source: Kubernetes label
# Key: team
# Apply to: Services, Process Groups, Hosts

# Step 3: Verify namespace has the label AND pods have them too
kubectl get ns payment-ns --show-labels
kubectl get pods -n payment-ns --show-labels
# Both must show: team=payments

# Step 4: Set DT_TAGS directly in deployment (most reliable method)
kubectl patch deployment payment-service -n payment-ns --type=json -p='[
  {
    "op": "add",
    "path": "/spec/template/spec/containers/0/env/-",
    "value": {
      "name": "DT_TAGS",
      "value": "team=payments environment=production"
    }
  }
]'
# DT reads this env var and creates tags regardless of namespace labels

# Step 5: Restart pods to apply new env vars and let DT pick up tags
kubectl rollout restart deployment/payment-service -n payment-ns

# Verify in DT UI:
# Applications & Microservices → Services → payment-service
# → Properties → Tags: team:payments ✓
```

---

### Error 6.2: Management Zone Shows Wrong / Missing Entities

**What you see:**
- Team logs into Dynatrace but sees no services in their management zone
- Services from another team's environment show up in your zone
- Alert fires but goes to wrong team (wrong zone assigned to alerting profile)

**Why it happens:**
```
- Management zone rule uses wrong tag key or wrong operator
- Service entity doesn't have the expected tag yet
- Rule applies to "Hosts" but not to "Services" separately
```

**Diagnose + Fix:**
```bash
# Step 1: Check current management zone rules
# DT UI: Settings → Management Zones → [zone name] → Rules
# Verify: rule type = Service AND condition = tag(team) = "payments"
# NOT: rule type = Host (which only shows hosts, not services)

# Fix: Each entity type needs its own rule
# Rule 1: Apply to Services WHERE tag:team = payments
# Rule 2: Apply to Process Groups WHERE tag:team = payments
# Rule 3: Apply to Hosts WHERE tag:team = payments
# Rule 4: Apply to Kubernetes Workloads WHERE label:team = payments

# Step 2: Test the rule before saving
# In the rule editor: click "Preview" → shows matching entities live

# Step 3: Verify tag exists on the entity (often the tag is missing — see Error 6.1)
# DT UI: Services → [service] → Properties → Tags
# If no tags → fix tagging first (Error 6.1), then management zone auto-populates
```

---

## Quick Diagnosis Cheat Sheet

| Symptom | Category | First Check |
|---|---|---|
| Pod running, no service in DT | 1.1 — Injection | `kubectl get ns <ns> --show-labels` |
| Service shows as "Java" | 3.1 — Service name | `kubectl exec <pod> -- env | grep SPRING_APPLICATION` |
| Trace broken across services | 2.1 — Trace split | `curl -v <url> 2>&1 | grep x-dynatrace` |
| Alert fires in dev/wrong team | 4.1 — Alert scope | Check alerting profile → management zone filter |
| Logs visible in `kubectl logs` but not DT | 5.1 — Log source | DT UI → Log Monitoring → Log sources enabled? |
| Tag on pod, not on DT service | 6.1 — Tag propagation | `kubectl get dynakube -n dynatrace -o yaml | grep metadataEnrichment` |
| Missing spans in trace | 2.2 — Missing spans | DT UI → Settings → Adaptive traffic management → sampling rate |
| Multiple services look like one | 3.2 — Merge | DT UI → Process Group Detection rules |
| JVM metrics missing | 4.2 — JVM metrics | DT UI → Deep monitoring → JVM enabled for process group? |
| Log fields wrong / no severity | 5.2 — Log parsing | `kubectl logs <pod> --tail=3` → is it JSON? |
