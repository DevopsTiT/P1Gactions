# Dynatrace Microservice Errors — Glossary

Every term, tool, and concept from main.md explained for an SRE beginner.

---

**OneAgent**
Dynatrace's primary monitoring agent. Installed on a host or injected into Kubernetes pods. Automatically instruments applications (Java, Node.js, Python, .NET, Go) without code changes. Monitors at the process, service, and request level.

**Injection (OneAgent)**
The act of inserting the OneAgent code module into a running application container at pod startup. After injection, the application's frameworks are automatically instrumented — HTTP calls, DB queries, and distributed traces are captured without changing application code.

**DynaKube**
A Kubernetes Custom Resource that configures everything about how Dynatrace works in a cluster — which namespaces to inject agents into, how to connect to the Dynatrace environment, whether to enable metadata enrichment, etc. Lives in the `dynatrace` namespace.

**`dynatrace.com/inject: "true"`**
A Kubernetes namespace label that tells the Dynatrace Operator to inject OneAgent into all pods in that namespace. Without this label, pods only get infrastructure-level (CPU/memory) monitoring — no service entities, no traces.

**Dynatrace Operator**
A Kubernetes controller that manages all Dynatrace components in a cluster. Watches DynaKube resources and ensures the correct OneAgent DaemonSet, CSI driver, and webhook are running.

**Webhook (Dynatrace)**
A Kubernetes admission webhook that intercepts pod creation requests and modifies the pod spec to include the OneAgent code module mount. This is the mechanism that performs injection at pod start time.

**CSI Driver (Dynatrace)**
Container Storage Interface driver used by Dynatrace to mount the OneAgent code module into application pods as a volume. Provides injection without modifying container images. Required for `cloudNativeFullStack` mode.

**`oneagent.dynatrace.com/inject: "false"` annotation**
A pod-level annotation that opts a specific pod OUT of OneAgent injection even if the namespace has `dynatrace.com/inject: "true"`. Used to exclude known-problematic pods or pods that don't need monitoring.

**`oneagent.dynatrace.com/injected: "true"` annotation**
A pod annotation that Dynatrace writes AFTER successfully injecting the code module. If this annotation is absent on a running pod, injection did not occur.

**Process Group**
A Dynatrace entity representing all running instances of the same process across multiple hosts or pods. Example: all pods running `payment-service.jar` form one Process Group. Different from a Service — a Process Group is the process itself; a Service is the logical capability it exposes.

**Service (Dynatrace entity)**
A high-level Dynatrace entity representing a logical capability — like "payment-service" — that receives requests. Automatically created when Dynatrace detects HTTP, gRPC, or database traffic entering a monitored process. The entity that holds response time, error rate, and throughput metrics.

**Process Group Detection Rule**
A configuration in Dynatrace UI (`Settings → Processes and Containers → Process Group Detection`) that controls how Dynatrace names and groups process entities. Used to fix generic names like "Java" into meaningful names like "payment-service".

**`SPRING_APPLICATION_NAME`**
A Spring Boot environment variable that sets the application's name. Dynatrace reads this to name the service entity. Without it, the service may be named after the JVM executable ("java") or the JAR file name.

**`DT_CUSTOM_PROP`**
A Dynatrace-specific environment variable read by OneAgent. Set key=value pairs to define process group properties. Used to name services, add tags, and pass metadata without using Kubernetes labels.

**`DT_TAGS`**
A Dynatrace environment variable that directly creates tags on the monitored process/service entity. Format: `key=value key2=value2`. The most reliable way to ensure tags appear regardless of namespace label propagation.

**Distributed Trace**
A recording of one end-to-end request as it flows through multiple microservices. Each service's portion is called a span. All spans in one request share a Trace ID. Allows you to see the full call chain: API Gateway → Order Service → Payment Service → Database.

**Span**
A single unit of work within a distributed trace — one service's handling of a request. Has a start time, end time, status, and any error information. Multiple spans make up a trace.

**Trace ID**
A unique identifier shared by all spans in a single end-to-end request. Used to correlate spans from different services into one trace. If trace propagation is broken, each service generates its own Trace ID and spans appear as separate disconnected traces.

**Trace Propagation**
The mechanism by which a Trace ID (and other context) is passed from one service to the next via HTTP headers. Dynatrace uses the `x-dynatrace` header (proprietary) or `traceparent` (W3C standard). If a service or proxy strips these headers, the trace is broken.

**`x-dynatrace` header**
Dynatrace's proprietary HTTP header used to propagate trace context between services. Contains the Trace ID, span ID, and sampling flags. OneAgent automatically injects this header on outbound calls and reads it on inbound calls.

**`traceparent` header**
The W3C Trace Context standard HTTP header for distributed tracing. Format: `00-traceId-parentId-flags`. Supported by OpenTelemetry and optionally by Dynatrace. When enabled, Dynatrace can connect traces with services using OTel instrumentation.

**W3C Trace Context**
An industry standard (RFC) for how distributed trace identifiers should be propagated in HTTP headers. Allows different tracing systems (Dynatrace, Jaeger, Zipkin, OTel) to interoperate by using the same `traceparent` header format.

**Adaptive Traffic Management (Sampling)**
A Dynatrace feature that automatically reduces trace collection when traffic is very high, to control data volume and costs. Can cause spans to be missing from traces. For critical services, this should be disabled or set to 100% capture.

**OpenTelemetry (OTel)**
An open-source observability framework providing APIs, SDKs, and tools for generating traces, metrics, and logs. Used for languages/frameworks that Dynatrace's auto-instrumentation doesn't support (Go, Rust, C++) or when you need to instrument code manually.

**OTLP (OpenTelemetry Protocol)**
The standard data format and transport protocol used by OpenTelemetry to send telemetry data. Dynatrace accepts OTLP data at its API endpoint (`/api/v2/otlp`), allowing OTel-instrumented services to send traces/metrics directly to Dynatrace.

**Micrometer**
A popular Java metrics library (used by Spring Boot by default). Collects application metrics (request counts, latencies, JVM stats) and exports them to monitoring backends. Has a Dynatrace exporter that pushes metrics directly to the DT Metrics API.

**JVM Deep Monitoring**
A Dynatrace feature that collects Java-specific metrics: heap memory usage, garbage collection frequency/duration, thread counts, class loading. Must be explicitly enabled per process group in Dynatrace settings.

**Metric Cardinality**
The number of unique combinations of dimension values for a metric. High cardinality (millions of combinations) consumes excessive storage and hits platform limits. Pod names, trace IDs, and user IDs are high-cardinality dimensions — avoid using them as metric tags.

**Metric Dimension**
A label attached to a metric data point to allow filtering and grouping. Example: `payment.latency` metric with dimensions `service=payment` and `env=production`. Low-cardinality dimensions (like service name, environment) are fine. High-cardinality dimensions (like pod name) cause problems.

**Management Zone**
A Dynatrace scope that restricts visibility to specific entities. Configured with rules (e.g. "show entities with tag `team:payments`"). Each team sees only their own services, hosts, and alerts. Prevents information overload and security boundaries.

**Alerting Profile**
A Dynatrace configuration that controls which problems trigger notifications and filters them by management zone, severity, and delay. Without management zone filtering, every team gets paged for every problem in the environment.

**Problem Notification**
A Dynatrace integration that sends an alert when a problem is detected — to PagerDuty, Slack, email, OpsGenie, etc. Linked to an Alerting Profile to control what triggers it.

**Log Monitoring (Dynatrace)**
A Dynatrace feature that collects, stores, and indexes application and system logs. Supports auto-discovery of known log formats and custom parsing rules. Can be ingested via OneAgent (from files or stdout) or via the Logs API.

**Log Source**
Configuration in Dynatrace defining where to collect logs from — a specific file path, container stdout/stderr, or a specific process group. Without a log source configured, logs don't appear in DT even if the app is writing them.

**Log Processing Rule**
A Dynatrace configuration that transforms raw log text into structured fields. Extracts log level, timestamp, service name, and other fields from custom log formats using Dynatrace's pattern-matching language. Required when the app doesn't use standard JSON logging.

**Elastic Common Schema (ECS)**
A standard JSON log format created by Elastic. Spring Boot 3+ can output ECS-formatted logs (`logging.structured.format.console=ecs`). Dynatrace understands ECS field names natively — severity, timestamp, and message are automatically mapped.

**`logstash-logback-encoder`**
A Java library that formats Logback logs as JSON with configurable field names. Commonly used with Spring Boot to produce structured JSON logs that DT (and ELK) can parse without custom processing rules.

**Log Ingest Limit**
The maximum volume of log data Dynatrace will accept per day. Exceeding this causes logs to be dropped. Controlled by reducing log verbosity (INFO instead of DEBUG), filtering out noisy log lines, and setting shorter retention periods for non-production environments.

**Log Retention**
How long Dynatrace stores log data. Configurable per log source. Production logs typically kept for 35 days. Dev/staging logs kept for 7 days to control costs and stay under ingest limits.

**`metadataEnrichment`**
A DynaKube setting (`metadataEnrichment.enabled: true`) that tells the Dynatrace Operator to read Kubernetes metadata (namespace labels, pod labels, annotations) and propagate them as tags on Dynatrace entities. Without this, labels exist in Kubernetes but never appear in DT.

**Auto-Tagging Rule**
A Dynatrace configuration (`Settings → Tags → Automatically applied tags`) that defines a condition: "when an entity has Kubernetes label `team`, create Dynatrace tag `team:<value>`." Applied automatically to all matching new and existing entities.

**`DT_CUSTOM_PROP` vs `DT_TAGS`**
Both are environment variables read by OneAgent. `DT_CUSTOM_PROP` sets process group properties (used for naming, detection). `DT_TAGS` directly creates Dynatrace tags on the entity. For tag propagation, `DT_TAGS` is the most direct and reliable method.

**`kubectl rollout restart`**
A Kubernetes command that gradually replaces all pods in a deployment with fresh ones. Used after changing environment variables (like `DT_TAGS`) or namespace labels so the new settings take effect on running pods.

**Structured Logging**
A practice of outputting logs as machine-readable JSON instead of plain text. Each field (level, message, timestamp, service) is a separate JSON key. Makes log parsing by Dynatrace (and other tools) trivial — no custom processing rules needed for standard fields.

**`kubectl exec`**
A Kubernetes command to run a command inside a running container. Used throughout this guide to inspect agent files, check env vars, test connectivity, and read agent logs from inside the pod.

**Admission Webhook**
A Kubernetes API extension point that intercepts resource creation/modification requests and can modify or reject them. Dynatrace uses a mutating admission webhook to modify pod specs at creation time, adding the OneAgent init container and volume mounts.
