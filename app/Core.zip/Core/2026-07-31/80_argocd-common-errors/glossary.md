# Glossary: ArgoCD Common Errors

Every term from the main guide explained for an SRE beginner.

---

**ArgoCD**
A GitOps continuous delivery tool for Kubernetes. It watches a git repository and automatically keeps your Kubernetes cluster in sync with what the git repo declares. "If it's in git, it should be in the cluster."

**Application (ArgoCD)**
An ArgoCD object that links a git source (repo + path + branch) to a Kubernetes destination (cluster + namespace). One Application = one microservice's manifests being managed.

**App of Apps**
An ArgoCD pattern where one parent Application manages a set of child Applications. Used for microservice platforms where you have dozens of services — the parent deploys all the service Applications as its children.

**OutOfSync**
ArgoCD status meaning: the live state in the Kubernetes cluster does not match what the git repository says it should be. Either you need to sync (apply git → cluster) or git needs to be updated to match the cluster.

**Degraded**
ArgoCD health status meaning: the application was deployed but is not healthy. A Deployment is Degraded if pods are crash-looping, the desired replica count isn't met, or a rollout is stuck. Degraded = something is wrong with the running application.

**Progressing**
ArgoCD health status meaning: a sync or rollout is in progress and not yet complete. If stuck in Progressing for a long time, a pod is failing to start or a Job hook is hanging.

**Unknown**
ArgoCD health status meaning: ArgoCD doesn't know how to evaluate the health of this resource type. Usually affects Custom Resources (CRDs) that don't have a built-in health check. You must define a custom health check.

**Sync**
The operation where ArgoCD applies the git manifests to the Kubernetes cluster — making the live state match the desired state. Can be manual or automatic (auto-sync).

**Auto-sync**
An ArgoCD Application setting that automatically triggers a sync whenever git changes are detected. Without it, you must manually click "Sync" or run `argocd app sync`.

**Sync Wave**
An ordering mechanism for ArgoCD syncs. Resources annotated with `argocd.argoproj.io/sync-wave: "N"` are applied in order from lowest to highest N. Lower waves finish (and become healthy) before higher waves start. Used to deploy databases before the services that need them.

**Sync Hook**
A Kubernetes Job or resource that ArgoCD runs at a specific point in the sync process: PreSync (before applying manifests), Sync (during), PostSync (after). Used for database migrations, smoke tests, cache warming.

**`activeDeadlineSeconds` (Job)**
A Kubernetes field on Jobs that sets a maximum runtime. If the Job doesn't complete within this time, Kubernetes kills it. Essential on ArgoCD sync hook Jobs — without it, a stuck Job keeps ArgoCD in "Progressing" forever.

**ignoreDifferences**
An ArgoCD Application field that tells ArgoCD to ignore certain fields when comparing git vs. live state. Used for fields managed by Kubernetes controllers (like HPA-managed replica counts) that will always differ from the git manifest.

**HPA (HorizontalPodAutoscaler)**
A Kubernetes object that automatically scales the number of pod replicas based on CPU or custom metrics. When HPA is active, the live replica count will differ from the git manifest's fixed replicas — causing constant OutOfSync unless `ignoreDifferences` is configured.

**CRD (Custom Resource Definition)**
A Kubernetes extension that defines a new resource type not built into Kubernetes (e.g., `ServiceMonitor`, `Certificate`, `SealedSecret`). ArgoCD will fail to sync manifests that use a CRD if the CRD hasn't been installed in the cluster first.

**SealedSecret**
A Kubernetes Secret encrypted with a cluster-specific key, safe to store in git. Managed by the Sealed Secrets controller (runs in the cluster), which decrypts it into a real Secret. Re-sealing with the wrong cluster's key = decryption failure.

**ExternalSecrets Operator**
A Kubernetes operator that reads secrets from external stores (AWS Secrets Manager, HashiCorp Vault, GCP Secret Manager) and creates Kubernetes Secrets from them. Errors usually involve IAM permissions or wrong key paths.

**`kubeseal`**
The CLI tool for creating SealedSecrets. Encrypts a plain Kubernetes Secret YAML using the public key from your cluster's Sealed Secrets controller. The result is safe to commit to git.

**AppProject**
An ArgoCD object that groups Applications and enforces RBAC rules: which git repositories are allowed, which Kubernetes clusters and namespaces can be targeted, and which users/teams can manage which apps.

**Repo Server (`argocd-repo-server`)**
The ArgoCD component responsible for connecting to git repositories, cloning repos, and rendering manifests (Helm, Kustomize, plain YAML). Git authentication errors and rate limiting appear in its logs.

**Application Controller (`argocd-application-controller`)**
The ArgoCD component that watches the cluster state, compares it to git, and triggers syncs. On large clusters with many applications, it can OOMKill if not given enough memory.

**Liveness Probe**
A Kubernetes health check that determines if a container is alive. If it fails, Kubernetes kills and restarts the container. Should only check if the process is responsive — NOT external dependencies.

**Readiness Probe**
A Kubernetes health check that determines if a container is ready to receive traffic. If it fails, Kubernetes removes the pod from the Service's load balancer. ArgoCD waits for readiness before declaring a Deployment healthy.

**CrashLoopBackOff**
A Kubernetes pod status indicating the container keeps crashing and Kubernetes keeps restarting it with increasing delays. Common causes: application code error, wrong environment variables, missing config, OOMKill.

**ImagePullBackOff**
A Kubernetes pod status indicating the container image couldn't be pulled from the registry. Causes: image doesn't exist, wrong tag, registry authentication missing, network issue.

**OOMKill**
"Out of Memory Kill" — Kubernetes killed the container because it exceeded its memory limit. The pod's memory limit is too low or the application has a memory leak.

**`kubectl rollout restart`**
The Kubernetes command that triggers a rolling restart of all pods in a Deployment without changing any configuration. Used to force pods to reload updated ConfigMaps or Secrets.

**Reloader (stakater/reloader)**
A Kubernetes operator that automatically restarts Deployments when their referenced ConfigMaps or Secrets change. Solves the problem of "new config in git, but pods still use old config."

**Kustomize**
A Kubernetes-native templating tool that customizes YAML manifests without templating syntax. ArgoCD supports Kustomize natively — it renders the final manifests by overlaying patches on base manifests.

**Helm**
A Kubernetes package manager that deploys applications using parameterized templates called Charts. ArgoCD supports Helm charts — you specify the chart + values file(s) in the Application spec.

**`valueFiles` (Helm + ArgoCD)**
An ArgoCD Application field listing values files to pass to Helm during rendering. Paths are relative to the Helm chart directory in git, NOT the repository root. Wrong paths = ArgoCD applies wrong configuration silently.

**`argocd app diff`**
The CLI command that shows the difference between the live Kubernetes state and the desired git state, without applying any changes. The first command to run when debugging OutOfSync.

**`argocd app manifests`**
The CLI command that shows the rendered Kubernetes manifests ArgoCD would apply from git (after Helm/Kustomize processing). Used to debug whether values files are being applied correctly.

**`argocd app refresh`**
Forces ArgoCD to re-fetch the git repository and re-evaluate the application state immediately, bypassing the poll interval (default 3 minutes).

**`argocd app refresh --hard`**
A deeper refresh that bypasses ArgoCD's manifest cache in addition to re-fetching git. Use when a regular refresh doesn't pick up changes.

**`argocd app sync --dry-run`**
Previews what changes would be applied without actually applying them. Useful for validating sync operations before running them in production.

**NetworkPolicy**
A Kubernetes resource that controls which pods can communicate with each other and with external endpoints. In a microservices architecture, misconfigured NetworkPolicies silently block cross-namespace service calls.

**Fully Qualified Domain Name (FQDN) in Kubernetes**
The full internal DNS name for a Kubernetes Service: `<service>.<namespace>.svc.cluster.local`. Required for cross-namespace service calls. Using just `<service-name>` only works within the same namespace.

**`CreateNamespace=true` (ArgoCD sync option)**
An ArgoCD syncOption that instructs ArgoCD to create the target namespace if it doesn't exist during sync. Without it, deploying to a non-existent namespace fails with "namespace not found."

**GitHub Personal Access Token (PAT)**
A token used instead of a password to authenticate API calls to GitHub. ArgoCD uses PATs to clone private repositories. Use fine-grained PATs scoped to specific repos for security.

**Webhook (ArgoCD)**
A GitHub/GitLab/Bitbucket notification sent to ArgoCD's `/api/webhook` endpoint when code is pushed. Triggers an immediate sync instead of waiting for the 3-minute poll interval.

**Rate limiting (GitHub)**
GitHub limits unauthenticated API requests to 60/hour and authenticated requests to 5000/hour. ArgoCD polling many repos without credentials can hit rate limits. Fix: use authenticated access (PAT or SSH).

**`argocd-application-controller` OOMKill**
When the ArgoCD application controller runs out of memory and is killed. Happens in large clusters with 100+ Applications. Fix: increase the memory limit in the StatefulSet and tune the controller parallelism settings.

**`ignoreDifferences` with `managedFieldsManagers`**
A more targeted way to ignore fields added by specific Kubernetes controllers. Instead of ignoring a JSON path (which might be too broad), you ignore fields managed by a named controller like `kube-controller-manager`.
