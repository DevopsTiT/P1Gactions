# ArgoCD Common Errors for Microservices — Deep Dive

---

## Decision Tree: Where Is Your Error?

```
ArgoCD showing a problem
  │
  ├─ App shows "OutOfSync" ──────────────────→ Section 1
  │
  ├─ App shows "Degraded" ───────────────────→ Section 2
  │
  ├─ App shows "Unknown" ────────────────────→ Section 3
  │
  ├─ Sync triggered but nothing changes ─────→ Section 4
  │
  ├─ App stuck in "Progressing" forever ─────→ Section 5
  │
  ├─ Sync succeeds but pods never become Ready → Section 6
  │
  ├─ Secret / config not updating ───────────→ Section 7
  │
  ├─ Multi-service dependency failures ──────→ Section 8
  │
  └─ ArgoCD itself not working ───────────────→ Section 9
```

---

## Quick Diagnostics — Run These First

```bash
# What apps exist and their current status
argocd app list

# Full detail on a specific app
argocd app get <app-name>

# Show what ArgoCD thinks is different (OutOfSync diff)
argocd app diff <app-name>

# Show the last sync result and error message
argocd app get <app-name> -o json | jq '.status.operationState'

# Show all events on an app
argocd app get <app-name> -o json | jq '.status.conditions'

# Show sync history
argocd app history <app-name>

# Check ArgoCD server logs
kubectl logs -n argocd deploy/argocd-server --tail=100 | grep -E "ERROR|WARN"

# Check application controller logs (where sync actually happens)
kubectl logs -n argocd deploy/argocd-application-controller --tail=100 | grep -E "ERROR|WARN"

# Check repo-server logs (where git operations happen)
kubectl logs -n argocd deploy/argocd-repo-server --tail=100 | grep -E "ERROR|WARN"
```

---

## Section 1 — OutOfSync Errors

### Error 1.1: App Constantly OutOfSync Even After Sync

**Symptom:** You sync the app, it goes green, then immediately goes OutOfSync again.

**Root causes and fixes:**

```
CAUSE A: A controller is modifying the resource after ArgoCD applies it
  Example: HPA (HorizontalPodAutoscaler) changes replica count
           ArgoCD sets replicas: 3, HPA changes it to 5
           ArgoCD sees replicas: 5 ≠ 3 in git → OutOfSync forever

  Fix: Tell ArgoCD to ignore that field
  
  # In the Application manifest — ignoreDifferences block:
  spec:
    ignoreDifferences:
      - group: apps
        kind: Deployment
        jsonPointers:
          - /spec/replicas        # ignore replica count changes
      - group: autoscaling
        kind: HorizontalPodAutoscaler
        jsonPointers:
          - /spec/minReplicas
          - /spec/maxReplicas

CAUSE B: Defaulting by the Kubernetes API server adds fields not in git
  Example: Kubernetes adds imagePullPolicy: IfNotPresent even when not in manifest
           serviceAccount token auto-mount fields added by admission controller
  
  Fix: Either add those fields to your manifests explicitly
       OR use ignoreDifferences for those specific paths:
  
  spec:
    ignoreDifferences:
      - group: apps
        kind: Deployment
        managedFieldsManagers:
          - kube-controller-manager   # ignore fields managed by K8s controllers

CAUSE C: Resource was manually modified in the cluster (kubectl edit / kubectl apply)
  ArgoCD sees the live state differs from git → correct OutOfSync
  
  Fix: Never kubectl edit resources managed by ArgoCD
       If you did: run argocd app sync to overwrite with git version
       If the manual change was intentional: update git to match
```

**Diagnose which fields are different:**
```bash
# Show the exact diff between git and live cluster
argocd app diff <app-name> --hard-refresh

# Show diff for a specific resource
argocd app diff <app-name> --resource apps:Deployment:<deployment-name>
```

---

### Error 1.2: OutOfSync — "ComparisonError"

**Symptom:** App status shows "OutOfSync" with message like:
```
ComparisonError: rpc error: code = Unknown desc = authentication required
ComparisonError: repository not found
ComparisonError: failed to get app details
```

```bash
# Check the repository connection
argocd repo list
argocd repo get https://github.com/org/repo

# Re-test connection to the repository
argocd repo get <repo-url> --refresh

# Check if the secret for the repo exists and has correct keys
kubectl get secret -n argocd -l argocd.argoproj.io/secret-type=repository
kubectl describe secret -n argocd <repo-secret-name>

# Common fix: re-add the repository credentials
argocd repo add https://github.com/org/repo \
  --username git \
  --password <token> \
  --insecure-skip-server-verification  # only if TLS cert is self-signed
```

---

### Error 1.3: OutOfSync — CRD Not Recognized

**Symptom:**
```
the server could not find the requested resource
error: resource mapping not found for kind "ServiceMonitor"
```

**Cause:** ArgoCD is trying to sync a Custom Resource (like a Prometheus `ServiceMonitor`) but the CRD for that resource doesn't exist in the cluster yet, or ArgoCD doesn't have permission to read it.

```bash
# Check if the CRD exists in the cluster
kubectl get crd | grep servicemonitor

# If CRD is missing: install the CRD first (helm chart, operator, etc.)
# For Prometheus Operator CRDs:
kubectl apply -f https://raw.githubusercontent.com/prometheus-operator/prometheus-operator/main/example/prometheus-operator-crd/...

# ArgoCD sync order fix: ensure CRDs are applied before resources that use them
# Use sync waves to order: CRDs in wave 0, resources that use them in wave 1
# Add this annotation to your CRD manifest:
metadata:
  annotations:
    argocd.argoproj.io/sync-wave: "-1"   # negative = applies first
```

---

## Section 2 — Degraded Errors

### Error 2.1: Health "Degraded" — Deployment Rollout Stuck

**Symptom:** ArgoCD shows `Health: Degraded` for a Deployment.

**What ArgoCD is actually checking:**
```
ArgoCD declares a Deployment "Degraded" when:
  - The desired replica count is not reached
  - A pod fails to start (crash loop, image pull error)
  - A rollout has been in progress > 10 minutes (configurable)
```

**Diagnose:**
```bash
# Check the deployment status
kubectl rollout status deployment/<name> -n <namespace>

# Check events on the deployment
kubectl describe deployment <name> -n <namespace> | grep -A 20 "Events:"

# Check pods for error state
kubectl get pods -n <namespace> -l app=<name>

# Check pod logs for crash reason
kubectl logs -n <namespace> <pod-name> --previous
kubectl logs -n <namespace> <pod-name>

# Check events for the specific pod
kubectl describe pod <pod-name> -n <namespace>
```

**Common causes:**
```
CrashLoopBackOff:
  → Pod starts and crashes repeatedly
  → Check: kubectl logs --previous for the crash message
  → Fix: Fix the application error, rollback ArgoCD app to last good commit

ImagePullBackOff / ErrImagePull:
  → Image doesn't exist, wrong tag, or registry credentials missing
  → Check: kubectl describe pod | grep "Failed to pull image"
  → Fix: Correct the image tag in git, or add registry secret:
  
  kubectl create secret docker-registry registry-secret \
    --docker-server=registry.company.com \
    --docker-username=<user> \
    --docker-password=<token> \
    -n <namespace>
  
  # Then reference in deployment:
  spec:
    imagePullSecrets:
      - name: registry-secret

OOMKilled:
  → Pod ran out of memory and was killed
  → Check: kubectl describe pod | grep OOMKilled
  → Fix: Increase memory limits in the deployment manifest in git
```

---

### Error 2.2: Health "Degraded" — PVC Not Bound

**Symptom:**
```
PersistentVolumeClaim is degraded: Pending (cannot bind to PersistentVolume)
```

```bash
# Check PVC status
kubectl get pvc -n <namespace>
kubectl describe pvc <pvc-name> -n <namespace>

# Common cause: StorageClass doesn't exist or provisioner is unavailable
kubectl get storageclass
kubectl describe storageclass <storage-class-name>

# Fix: ensure StorageClass exists and dynamic provisioning is working
# OR manually create a PersistentVolume that matches the claim
```

---

### Error 2.3: Health "Degraded" — Service with No Endpoints

```bash
# ArgoCD checks Service health — if no endpoints, it may report Degraded
kubectl get endpoints <service-name> -n <namespace>

# If endpoints is empty: the Service selector doesn't match any pod labels
kubectl get pods -n <namespace> --show-labels
# Compare the pod labels against the Service selector in the manifest

# Fix: ensure Service selector matches pod labels exactly (case-sensitive)
# Service spec:  selector: app: my-service
# Pod label:     labels: app: my-service  ← must match
```

---

## Section 3 — Unknown Status

### Error 3.1: Application Health is "Unknown"

**Symptom:** ArgoCD shows `Health: Unknown` for the whole app or a resource.

**Cause:** ArgoCD doesn't have a health check defined for this resource type.

```bash
# Check which resource is Unknown
argocd app get <app-name> --output json | jq '.status.resources[] | select(.health.status == "Unknown")'

# Custom Resource without a health check → ArgoCD doesn't know how to evaluate it
# Fix option 1: Define a custom health check in argocd-cm ConfigMap

kubectl edit configmap argocd-cm -n argocd
# Add under data:
data:
  resource.customizations.health.mygroup_MyResource: |
    hs = {}
    if obj.status ~= nil then
      if obj.status.phase == "Running" then
        hs.status = "Healthy"
        hs.message = "Resource is running"
        return hs
      end
    end
    hs.status = "Progressing"
    hs.message = "Waiting for status"
    return hs

# Fix option 2: Tell ArgoCD to ignore health for this resource type
kubectl edit configmap argocd-cm -n argocd
data:
  resource.customizations.ignoreDifferences.mygroup_MyResource: |
    jqPathExpressions:
      - '.status'
```

---

## Section 4 — Sync Triggered But Nothing Changes

### Error 4.1: Sync Says "Succeeded" But Old Version Still Running

**Symptom:** ArgoCD shows green sync but pods are still on the old image.

```bash
# Verify what image is actually running
kubectl get pods -n <namespace> -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.spec.containers[0].image}{"\n"}{end}'

# Check if ArgoCD actually applied the manifest (check sync result detail)
argocd app get <app-name> -o json | jq '.status.operationState.syncResult.resources'

# Most common cause: image tag not changed in git
# ArgoCD only updates Kubernetes when the MANIFEST changes
# If the image digest is the same → K8s won't restart the pod
# → Even if the image registry has a new image at :latest, if the tag hasn't changed
#   in the git manifest, ArgoCD won't do anything

# Fix: use immutable tags (never use :latest in production)
# Use commit SHA or semantic version:
image: my-registry/my-service:1.2.3-abc123   ← correct
image: my-registry/my-service:latest          ← WRONG for GitOps
```

### Error 4.2: ArgoCD Not Detecting Git Changes

**Symptom:** You pushed to git but ArgoCD never picks it up.

```bash
# ArgoCD polls git every 3 minutes by default
# Force an immediate refresh:
argocd app refresh <app-name>
argocd app refresh <app-name> --hard   # bypass cache

# Check the last refresh time
argocd app get <app-name> | grep "Last Refresh"

# If using webhooks: check if webhook is configured in your git provider
# GitHub: Settings → Webhooks → check payload URL = https://argocd.company.com/api/webhook

# Check if ArgoCD received the webhook
kubectl logs -n argocd deploy/argocd-server | grep "webhook"

# If polling timeout is too slow, reduce it in argocd-cm:
kubectl edit configmap argocd-cm -n argocd
# Add:
data:
  timeout.reconciliation: 60s    # default is 180s (3 min)
```

---

## Section 5 — Stuck in "Progressing"

### Error 5.1: App Stuck in Progressing Forever

**Symptom:** ArgoCD shows `Progressing` for many minutes. The sync never finishes.

```bash
# What is still progressing?
argocd app get <app-name> -o json \
  | jq '.status.resources[] | select(.health.status == "Progressing")'

# Check which pods are not yet Ready
kubectl get pods -n <namespace>

# For a Deployment stuck in Progressing:
kubectl rollout status deployment/<name> -n <namespace>
# If stuck: check why pods aren't starting (see Section 2)
```

**Common cause: Job or Hook that never completes:**
```bash
# ArgoCD waits for Jobs to complete before declaring sync done
# If a pre-sync or post-sync Hook Job is hanging:
kubectl get jobs -n <namespace>
kubectl describe job <job-name> -n <namespace>
kubectl logs -n <namespace> job/<job-name>

# Fix: Add a timeout to sync hooks in the manifest
metadata:
  annotations:
    argocd.argoproj.io/hook: PreSync
    argocd.argoproj.io/hook-delete-policy: HookSucceeded
spec:
  activeDeadlineSeconds: 120    # job must finish in 2 min or be killed
```

**Common cause: Rollout strategy too slow:**
```bash
# If using maxUnavailable: 0 AND maxSurge: 0 (impossible rollout)
# Check:
kubectl get deployment <name> -n <namespace> -o jsonpath='{.spec.strategy}'

# Fix: ensure at least one of maxUnavailable or maxSurge is > 0
spec:
  strategy:
    rollingUpdate:
      maxUnavailable: 0
      maxSurge: 1          # must have headroom to create new pod
```

---

## Section 6 — Sync Succeeds But Service Unavailable

### Error 6.1: Sync Green, But Service Returns Errors or Is Unreachable

**Cause:** ArgoCD only checks that the Kubernetes objects were applied. It doesn't check if the application inside the container actually works.

```bash
# ArgoCD says: sync ✓, health ✓
# But application is returning 500s

# Step 1: Check pod readiness
kubectl get pods -n <namespace>
# STATUS = Running but READY = 0/1 means readiness probe failing

# Step 2: Check readiness probe
kubectl describe pod <pod-name> -n <namespace> | grep -A 10 "Readiness"

# Step 3: Check application logs
kubectl logs -n <namespace> <pod-name>

# Step 4: Check the readiness probe endpoint manually
kubectl exec -n <namespace> <pod-name> -- curl -sf http://localhost:8080/health/ready

# Common fix: readiness probe is checking a dependency (DB, cache) that isn't ready yet
# Or readiness probe path is wrong (returns 404)
```

### Error 6.2: ConfigMap or Secret Not Mounted / Wrong Values

```bash
# Check that ConfigMap exists with correct data
kubectl get configmap <name> -n <namespace> -o yaml

# Check that Secret exists
kubectl get secret <name> -n <namespace>

# Verify the pod actually has the env var or mounted file
kubectl exec -n <namespace> <pod-name> -- env | grep MY_ENV_VAR
kubectl exec -n <namespace> <pod-name> -- cat /etc/config/my-config.yaml

# Common cause: ConfigMap was updated in git but pods not restarted
# Kubernetes does NOT auto-restart pods when a ConfigMap changes
# Fix: Use Reloader (stakater/reloader) to auto-restart on ConfigMap change
# OR: trigger a rollout restart manually:
kubectl rollout restart deployment/<name> -n <namespace>
```

---

## Section 7 — Secret and Sealed Secret Errors

### Error 7.1: Secret Not Syncing / "Forbidden" on Secret

**Symptom:**
```
failed to sync: secret "my-secret" is forbidden: User "argocd" cannot create resource "secrets"
```

```bash
# Check ArgoCD's RBAC permissions for the namespace
kubectl get rolebinding -n <namespace> | grep argocd
kubectl describe clusterrolebinding argocd-application-controller

# ArgoCD application controller needs permissions to manage secrets
# Fix: add a RoleBinding in the target namespace

kubectl create rolebinding argocd-secret-manager \
  --clusterrole=admin \
  --serviceaccount=argocd:argocd-application-controller \
  -n <namespace>
```

### Error 7.2: SealedSecret Not Decrypting

**Symptom:** SealedSecret is synced to cluster but the resulting Secret is empty or doesn't exist.

```bash
# Check sealed-secrets controller logs
kubectl logs -n kube-system deploy/sealed-secrets-controller --tail=50

# Check if the SealedSecret has a status
kubectl describe sealedsecret <name> -n <namespace>
# Look for: "condition: type: Synced, status: True"
# If False: decryption failed

# Common causes:
# 1. Secret was sealed with a key from a different cluster
#    Fix: re-seal the secret using the current cluster's public key:
kubeseal --fetch-cert \
  --controller-name=sealed-secrets-controller \
  --controller-namespace=kube-system \
  > pub-cert.pem

kubectl create secret generic my-secret \
  --from-literal=password=mysecret \
  --dry-run=client -o yaml \
  | kubeseal --cert pub-cert.pem \
  -o yaml > my-sealedsecret.yaml

# 2. Namespace mismatch — SealedSecret was sealed for a different namespace
#    SealedSecrets are namespace-scoped by default
#    Fix: re-seal with correct namespace
```

### Error 7.3: External Secrets Not Syncing (if using ExternalSecrets Operator)

```bash
# Check ExternalSecret status
kubectl get externalsecret -n <namespace>
kubectl describe externalsecret <name> -n <namespace>

# Check external-secrets operator logs
kubectl logs -n external-secrets deploy/external-secrets --tail=100

# Common errors:
# "SecretStore validation failed" → credentials to secret manager (AWS/Vault) wrong
# "secret not found in store"     → key path in Vault/AWS SSM doesn't exist
# "access denied"                 → IAM role / service account doesn't have permission

# Fix IAM permission for AWS Secrets Manager:
# ServiceAccount needs annotation:
metadata:
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::123456789:role/my-secrets-role
```

---

## Section 8 — Multi-Service / Microservices Specific Errors

### Error 8.1: Apps Deployed Out of Order — Dependency Not Ready

**Symptom:** Service B deploys before Service A (its dependency). B crash-loops waiting for A.

```bash
# Fix: Use App of Apps pattern with sync waves
# In the Application manifest for Service A (deployed first):
metadata:
  annotations:
    argocd.argoproj.io/sync-wave: "1"   # deploy in wave 1

# In the Application manifest for Service B (depends on A):
metadata:
  annotations:
    argocd.argoproj.io/sync-wave: "2"   # deploy in wave 2, after wave 1 is healthy

# Sync wave order: lower number = earlier
# ArgoCD waits for wave N to be healthy before starting wave N+1

# Typical ordering for microservices:
# Wave -1: Namespaces, CRDs
# Wave  0: ConfigMaps, Secrets, PVCs
# Wave  1: Databases, message queues (infrastructure services)
# Wave  2: Core backend services (depend on DB)
# Wave  3: Frontend / API gateway (depend on backends)
# Wave  4: Monitoring agents, sidecars
```

### Error 8.2: Multiple Apps, One App Blocking Others ("App of Apps" Sync Failure)

```bash
# In App of Apps pattern, if one child app fails:
# ArgoCD may block syncing other child apps in the same wave

# Check which app is blocking
argocd app list | grep -E "OutOfSync|Degraded"

# Force sync a specific child app independently
argocd app sync <child-app-name>

# If the blocking app should be skipped during sync (e.g., it's optional):
# Add to the Application manifest:
spec:
  syncPolicy:
    syncOptions:
      - FailOnSharedResource=false
```

### Error 8.3: Namespace Not Created Before Resources

**Symptom:**
```
namespaces "my-namespace" not found
```

```bash
# ArgoCD tries to apply resources before the namespace exists

# Fix 1: Include the Namespace manifest in your repo and give it wave -1
apiVersion: v1
kind: Namespace
metadata:
  name: my-namespace
  annotations:
    argocd.argoproj.io/sync-wave: "-1"

# Fix 2: Enable namespace auto-creation in the Application spec
spec:
  syncPolicy:
    syncOptions:
      - CreateNamespace=true
```

### Error 8.4: Cross-Namespace Service Discovery Failing

**Symptom:** Microservice A in namespace `team-a` can't reach Service B in namespace `team-b`.

```bash
# In Kubernetes, cross-namespace DNS format:
# <service-name>.<namespace>.svc.cluster.local

# Verify the service is reachable from the other namespace
kubectl exec -n team-a <pod-name> -- \
  curl -sf http://service-b.team-b.svc.cluster.local:8080/health

# Common mistake: using short hostname (service-b) which only works in same namespace
# Fix: always use the full DNS name in cross-namespace service references

# Check NetworkPolicy is not blocking cross-namespace traffic
kubectl get networkpolicy -n team-b
kubectl describe networkpolicy <policy-name> -n team-b
# If policy only allows traffic from same namespace → add team-a namespace to ingress rules
```

### Error 8.5: Helm Chart Values Not Applied Correctly

**Symptom:** ArgoCD syncs but the deployed resources don't match what you expect from Helm values.

```bash
# Check what values ArgoCD is using for the Helm release
argocd app get <app-name> -o json | jq '.spec.source.helm'

# Preview the Helm template output ArgoCD will apply
argocd app manifests <app-name>

# Check if a values file path is wrong (common issue)
spec:
  source:
    helm:
      valueFiles:
        - values/production.yaml   # ← must be relative to the chart root in git

# Common mistake: values file path starts from repo root vs. chart directory
# If chart is at: charts/my-service/
# And values is at: charts/my-service/values/production.yaml
# Then valueFiles path is: values/production.yaml (relative to chart dir)
# NOT: charts/my-service/values/production.yaml

# Verify Helm template locally first:
helm template my-release ./charts/my-service \
  -f charts/my-service/values/production.yaml \
  --debug
```

---

## Section 9 — ArgoCD Infrastructure Errors

### Error 9.1: ArgoCD UI/API Unreachable

```bash
# Check all ArgoCD pods are running
kubectl get pods -n argocd

# If argocd-server pod is not running:
kubectl describe pod -n argocd -l app.kubernetes.io/name=argocd-server
kubectl logs -n argocd -l app.kubernetes.io/name=argocd-server --previous

# Restart ArgoCD server
kubectl rollout restart deployment/argocd-server -n argocd
kubectl rollout status deployment/argocd-server -n argocd

# If using Ingress — check ingress is configured correctly
kubectl get ingress -n argocd
kubectl describe ingress argocd-server -n argocd
```

### Error 9.2: "Permission Denied" When Syncing

**Symptom:**
```
permission denied: application sync is not permitted in project default
```

```bash
# Check AppProject RBAC settings
kubectl get appproject -n argocd <project-name> -o yaml

# The project may have destination restrictions
# spec.destinations defines which clusters and namespaces are allowed
spec:
  destinations:
    - namespace: '*'
      server: https://kubernetes.default.svc   # only local cluster allowed

# If app is trying to deploy to a different cluster/namespace:
# Add it to the project destinations

# Check user/role permissions
argocd proj role list <project-name>
argocd proj role get <project-name> <role-name>
```

### Error 9.3: "Too Many Requests" / Git Rate Limiting

**Symptom:** ArgoCD logs show git rate limit errors:
```
failed to fetch repository: rate limit exceeded for GitHub
```

```bash
# Fix: use a GitHub App token or Personal Access Token with higher rate limit
# GitHub Apps get 5000 requests/hour vs 60/hour for unauthenticated

# Update the repository secret with credentials:
argocd repo update https://github.com/org/repo \
  --username x-token \
  --password <github-pat-token>

# Or configure SSH key authentication (no rate limit):
argocd repo add git@github.com:org/repo.git \
  --ssh-private-key-path ~/.ssh/id_rsa
```

### Error 9.4: ArgoCD Application Controller OOMKilled (Large Clusters)

**Symptom:** `argocd-application-controller` pod keeps restarting.

```bash
# Check memory usage
kubectl top pod -n argocd

# Increase memory limit for application controller
kubectl edit statefulset argocd-application-controller -n argocd
# Increase: resources.limits.memory: 2Gi (default is 512Mi)

# For very large clusters (100+ apps), also tune:
kubectl edit configmap argocd-cmd-params-cm -n argocd
# Add:
data:
  controller.operation.processors: "25"    # default 10
  controller.status.processors: "50"       # default 20
  controller.repo.server.timeout.seconds: "120"
```

---

## Common Mistakes Summary Table

| Mistake | Symptom | Fix |
|---|---|---|
| Using `image:latest` tag | Sync never detects image changes | Use immutable tags (`:1.2.3` or `:commit-sha`) |
| kubectl-editing ArgoCD-managed resources | Constant OutOfSync | Never `kubectl edit` — always edit git |
| Not ignoring HPA-managed replica fields | Constant OutOfSync on replicas | `ignoreDifferences` for `/spec/replicas` |
| Deploying services before dependencies | CrashLoopBackOff on startup | Use `sync-wave` annotations to order deployment |
| Short hostname for cross-namespace calls | Connection refused between services | Use full DNS: `svc.namespace.svc.cluster.local` |
| SealedSecret sealed for wrong cluster | Secret never created | Re-seal with current cluster's public cert |
| ConfigMap change, pods not restarted | App using old config | Use Reloader or `rollout restart` |
| Namespace missing before resource apply | "namespace not found" error | Add `CreateNamespace=true` or Namespace in wave -1 |
| Helm values file wrong path | Wrong configuration deployed | Path is relative to chart root, not repo root |
| No readiness probe or broken probe | Sync green but traffic fails | Fix readiness probe endpoint to return 200 when ready |
| Sync hook job hangs | App stuck in Progressing forever | Add `activeDeadlineSeconds` to hook Job spec |
| ArgoCD RBAC too restrictive | "permission denied" on sync | Update AppProject destinations and RBAC roles |
