# JLPT Reading — Long Text Comprehension: N5 to N2 Deep Dive

---

## Why Long Text Is the Hardest Section

```
Short text (短文):  ~150–200 chars  → Read everything. One clear question.
Medium text (中文): ~400–500 chars  → Scan for key info. 2–3 questions.
Long text (長文):   ~700–1000 chars → Strategy required. 3–4 questions.
                                      NO TIME to read every word.

The failure pattern:
  Student reads every single word carefully
  → Runs out of time on the last 2 passages
  → Guesses blind → loses 6–8 points
  → Fails the reading subscore
  
The solution:
  Learn what to READ and what to SKIP
  Long text = structured argument — follow the structure, not every word
```

---

## The Universal 5-Step Method (Works N5 → N2)

Use this same method at every level. The text length and vocabulary increase, but the strategy is identical.

```
STEP 1: Read the QUESTION first (not the text)
  Time: 30 seconds
  Purpose: You now know what you're hunting for

STEP 2: Read the FIRST PARAGRAPH only
  Time: 60 seconds
  Purpose: Sets up the topic and the author's stance

STEP 3: Scan for DISCOURSE MARKERS
  Time: 30 seconds
  Purpose: Find the skeleton of the argument

STEP 4: Read the LAST PARAGRAPH only
  Time: 60 seconds
  Purpose: Author's conclusion — almost always the answer to "what is the main point"

STEP 5: Answer questions using ELIMINATION
  Time: 60–90 seconds per question
  Purpose: Cross out wrong answers; don't need to be 100% certain

Total per passage: ~4–6 minutes (vs. 10–15 if you read everything)
```

---

## Discourse Markers — The Skeleton of Every Long Text

These words are your navigation system. They tell you exactly where the argument is going without reading the surrounding sentences.

### Category 1: Contrast (the MOST important for finding answers)

```
しかし          BUT / HOWEVER          ← biggest contrast signal
けれども        although / but
ところが        however (unexpected result)
一方（で）      on the other hand
それに対して    in contrast to that
とはいえ        that said / even so
もっとも        however / admittedly (softening)
ただし          however / provided that
それでも        even so / still

WHY THEY MATTER:
  The sentence AFTER しかし almost always contains the author's REAL point.
  Example:
    "毎日運動は大切だと言われている。しかし、実は睡眠の方が健康に重要だ。"
    "Exercise daily is said to be important. HOWEVER, sleep is actually more
     important for health."
  → The answer to "what does the author think?" = 睡眠が健康に重要
  → You don't need to read the exercise paragraphs before this
```

### Category 2: Cause and Result (follow the logic chain)

```
だから          therefore / so
そのため（に）  for that reason
したがって      therefore / consequently (formal)
その結果        as a result
よって          therefore (very formal, written)
ゆえに          therefore / hence (literary/academic)
それで          and so / because of that
こうして        in this way / thus
```

### Category 3: Summary / Restatement (answer is HERE)

```
つまり          in other words / in short    ← HIGHEST VALUE marker
要するに        to sum up / in short         ← HIGHEST VALUE marker
すなわち        that is to say / namely
言い換えると    in other words
まとめると      to summarize
以上のことから  from the above / based on the above
```

**Rule:** When you see `つまり` or `要するに`, the sentence that follows is the direct answer to "what is the author saying?" Read that sentence carefully even if you skipped everything before it.

### Category 4: Addition (building the argument)

```
また            also / in addition
さらに          furthermore / moreover
そのうえ        in addition / on top of that
おまけに        moreover / what's more (informal)
それだけでなく  not only that but
加えて          in addition to
```

### Category 5: Example and Specification

```
たとえば        for example
具体的には      specifically / concretely
とくに          in particular / especially
なかでも        among those / especially
```

**Rule:** Skip the examples. Examples support a point but are NOT the point. If you see `たとえば`, read to the end of the example and jump past it.

### Category 6: Topic Introduction

```
まず            first of all
次に / つぎに   next / secondly
最後に          finally / lastly
一般的に        generally
〜と言われている it is said that / 〜 is considered to be
```

---

## The Argument Skeleton Diagram

Every JLPT long text follows one of three structures. Identify which one in Step 2 (first paragraph), then you know where the answer is.

```
Structure A: PROBLEM → SOLUTION
  ┌─────────────────────────────────┐
  │ Para 1: There is a problem      │  ← Read this (Step 2)
  │ Para 2: Details of the problem  │  ← SKIP
  │ Para 3: Examples of the problem │  ← SKIP (たとえば signal)
  │ Para 4: Solution proposed       │  ← しかし/そのため signal → READ
  │ Para 5: Why the solution works  │  ← つまり signal → READ
  └─────────────────────────────────┘
  Answer is in: Para 4 or Para 5

Structure B: COMMON BELIEF → AUTHOR'S COUNTER-ARGUMENT
  ┌─────────────────────────────────┐
  │ Para 1: What people usually think│ ← Read this
  │ Para 2: Why they think that     │  ← SKIP
  │ Para 3: しかし — the real truth  │  ← READ (contrast marker)
  │ Para 4: Evidence for real truth  │  ← SKIP (たとえば)
  │ Para 5: つまり — conclusion      │  ← READ
  └─────────────────────────────────┘
  Answer is in: Para 3 or Para 5

Structure C: BACKGROUND → CHANGE → IMPLICATION
  ┌─────────────────────────────────┐
  │ Para 1: Background situation    │  ← Read this
  │ Para 2: How it changed          │  ← その結果 signal → READ
  │ Para 3: Examples of the change  │  ← SKIP
  │ Para 4: What this means now     │  ← したがって → READ
  │ Para 5: Author's conclusion     │  ← つまり → READ
  └─────────────────────────────────┘
  Answer is in: Para 4 or Para 5
```

---

## N5 Level — Long Text Strategy

### What N5 Long Text Looks Like

```
Length:         ~150–200 characters (still short — barely "long" at this level)
Vocabulary:     N5 words (~800 words total)
Kanji:          ~100 basic kanji, all with furigana
Topic:          Daily life — schedules, messages, short instructions
Question type:  "What did [person] do?" / "Which is correct?"
Question count: 1–2 questions per passage
```

### Sample N5 Long Text

```
たなかさんは まいあさ 6じに おきます。
そして、あさごはんを たべます。7じに がっこうへ いきます。
がっこうは 3じに おわります。
うちに かえってから、しゅくだいを します。
よるは かぞくと ばんごはんを たべます。
```

### N5 Sample Questions and Answers

```
Q: たなかさんは まいにち なんじに おきますか。
   (What time does Tanaka wake up every day?)

A: 6じ ✓

Q: たなかさんは うちに かえってから、なにを しますか。
   (After Tanaka returns home, what does he do?)

A: しゅくだいを します ✓
```

### N5 Strategy

```
At N5 level, there IS enough time to read the whole text.
The challenge is vocabulary, not strategy.

Approach:
  1. Read the question first (1 question usually — what are they asking?)
  2. Read the text once slowly
  3. Find the sentence with the answer (usually stated directly)

N5 answer pattern:
  The answer is STATED in the text. It is never implied. Never inferred.
  If you understand the sentence, the answer is obvious.
  
  Common mistake: choosing an answer that SOUNDS right but isn't in the text.
  Rule: The correct answer must be directly supported by a specific sentence.
```

---

## N4 Level — Long Text Strategy

### What N4 Long Text Looks Like

```
Length:         ~200–300 characters
Vocabulary:     N4 words (~1,500 total)
Kanji:          ~300 kanji, with furigana on hard ones
Topic:          Letters, emails, simple explanations
Question type:  "Why did [person] do X?" / "What does the writer want to say?"
Question count: 2–3 questions
```

### N4 Introduces: Simple Inference Questions

N4 is where "find the sentence" no longer always works. The question may ask about something that is IMPLIED.

```
Text: 「日曜日にデパートに行きました。でも、ほしいものは売っていませんでした。」
      "I went to the department store on Sunday. But the thing I wanted wasn't being sold."

Q: この人はどんな気持ちですか。
   (How does this person feel?)

A: がっかりした (disappointed) ✓

Why? The word "disappointing" never appears.
But: they went → couldn't get what they wanted → the implied feeling is disappointment.

This is your first "inference" question. It's still simple inference at N4.
```

### N4 Strategy

```
Step 1: Read the question (especially if it asks "how does X feel?" or "what does X want?")
Step 2: Read the full text (N4 texts are still short enough)
Step 3: For factual questions → find the exact sentence
Step 4: For feeling/intention questions → identify the situation, infer the emotion
        (disappointed, relieved, happy, worried — one of these four covers most N4 inference)

N4 discourse markers to know:
  でも / しかし → but/however (signals a problem or contrast)
  だから → so/therefore (signals a reason → result)
  〜たので → because... (signals cause)
```

---

## N3 Level — Long Text Strategy

### What N3 Long Text Looks Like

```
Length:         ~300–500 characters
Vocabulary:     N3 words (~3,750 total)
Kanji:          ~600 kanji (furigana on uncommon ones)
Topic:          Social topics, explanations, light opinion pieces
Question type:  "What does the author want to say?" / "Why does X happen?"
                "What does [word/phrase] in line X refer to?"
Question count: 3 questions
```

### N3 Introduces: The "What does this phrase refer to?" Question

```
Text: 「〜。このような状況が増えている。」

Q: 「このような状況」とは何を指していますか。
   (What does "this kind of situation" refer to?)

Strategy:
  "このような" / "このこと" / "それ" / "そのため" always refer to
  the IMMEDIATELY PRECEDING sentence or paragraph.
  
  Find the phrase in the text.
  Read the sentence BEFORE it.
  That is the referent.
```

### N3 Strategy — Apply the 5-Step Method Here

```
Step 1: Read all questions (2–3 questions — know what you're hunting)
Step 2: Read the first paragraph
Step 3: Scan for discourse markers — circle しかし, つまり, だから
Step 4: Read last paragraph
Step 5: Answer each question:
  - Factual question → scan for the specific sentence
  - "What does the author want to say?" → use つまり sentence or last paragraph
  - "What does this phrase refer to?" → sentence immediately before the phrase
  - Inference → find the situation, infer logically

N3 wrong answer traps:
  Trap 1: "The text mentions X, so the answer is X"
    → Distractor: X is mentioned but is NOT the answer — it's a supporting detail
    → Test: does the answer answer THE SPECIFIC QUESTION or just appear in the text?
    
  Trap 2: "This sounds logically right"
    → Rule: the answer must be SUPPORTED BY THE TEXT, not just logical
    → Unsupported logic = wrong answer at JLPT
```

---

## N2 Level — Long Text Strategy (Full Deep Dive)

### What N2 Long Text Looks Like

```
Length:         ~700–1,000 characters
Vocabulary:     N2 words (~6,000 total)
Kanji:          ~1,000 kanji (furigana only on very rare kanji)
Topic:          Academic-adjacent: society, science, culture, psychology,
                education policy, environmental issues, technology
Style:          Written Japanese — formal, dense, abstract nouns heavy
Question type:  4 question types (see below)
Question count: 3–4 questions per passage
Passages:       Usually 2–3 long passages in the reading section
```

### The Four N2 Long Text Question Types

```
TYPE 1: "What does the author want to say / what is the main argument?"
  筆者が最も言いたいことは何か。
  この文章のテーマは何か。
  筆者の考えとして最もふさわしいものはどれか。
  
  → Answer: Last paragraph, or the sentence after つまり/要するに
  → Strategy: Read last paragraph first (after Step 1 question read)

TYPE 2: "Why does X happen?" / "What is the reason for X?"
  なぜ〜か。 / 〜理由は何か。
  〜のはなぜか。
  
  → Answer: Sentence immediately after the word/event X, or sentence with だから/ため/から
  → Strategy: Find X in the text, read the 2 sentences that follow it

TYPE 3: "What does [this word / phrase] mean here?"
  〜とはどういうことか。
  〜とは何を指しているか。
  「〜」の意味として正しいものはどれか。
  
  → Answer: The definition is built from context surrounding the word
  → Strategy: Read the full sentence containing the word + 1 sentence before + 1 after
  → The correct answer paraphrases the context in simpler language

TYPE 4: "Which matches the content of the text?"
  文章の内容と合っているものはどれか。
  本文の内容として正しいものはどれか。
  
  → Answer: One of the 4 options is directly supported by the text
  → Strategy: Use elimination — test each option against the text
  → Fastest approach: test options starting from the last paragraph backwards
```

### N2 Long Text: Elimination Method in Detail

```
The 4 answer options for TYPE 4 questions follow predictable patterns:

WRONG option type A: "Too strong"
  Text says: "〜かもしれない" (might be)
  Wrong answer says: "〜は確実だ" (is definitely)
  → Any answer that makes a stronger claim than the text = WRONG

WRONG option type B: "Reversed"
  Text says: AはBよりCだ (A is more C than B)
  Wrong answer says: BはAよりCだ (B is more C than A)
  → Reversal of comparison or cause/effect = WRONG

WRONG option type C: "Not mentioned"
  The option sounds reasonable but the text never discusses it
  → Reasonable but unmentioned = WRONG (this is the sneakiest trap)

WRONG option type D: "True in real life but contradicts the text"
  The author argues AGAINST a common belief
  The wrong option restates the common belief
  → Real-world true but author disagrees = WRONG

CORRECT option:
  → Directly paraphrases a specific sentence or paragraph
  → Uses different words but same meaning as text
  → Makes no stronger claim than the text
```

### N2 Long Text Practice: Reading Speed Targets

```
At exam pace, you have approximately 105 minutes for the combined
language knowledge + reading section (for N2).

Typical time budget:
  Vocabulary questions:   ~25 minutes (35 questions × ~40 sec)
  Grammar questions:      ~25 minutes (34 questions × ~45 sec)
  Reading — short texts:  ~15 minutes (3–4 passages × ~4 min)
  Reading — medium texts: ~20 minutes (2 passages × ~10 min)
  Reading — long texts:   ~20 minutes (2 passages × ~10 min)

Per long passage breakdown:
  Read questions (3–4 questions): 1 minute
  First paragraph:                1.5 minutes
  Scan for markers:               30 seconds
  Last paragraph:                 1.5 minutes
  Answer 3–4 questions:           4 minutes
  Total:                          ~8–9 minutes per long passage
```

### N2 Sample Passage + Full Analysis

**Sample text (condensed):**
```
近年、若者の活字離れが問題となっている。スマートフォンの普及により、
短い文章や動画を消費することが増え、長い文章を読む機会が減っているという。
しかし、こうした見方には疑問がある。実際のデータを見ると、電子書籍の
利用者は年々増加しており、読書量が減っているとは言えない。
つまり、問題は「読む量」ではなく「読む内容」の変化にあるのかもしれない。
若者は読んでいる。ただ、読む対象が変わっただけだ。
```

**Step-by-step analysis:**

```
Step 1: Read the question first
  Q: 筆者が最も言いたいことは何か。
  → I'm looking for the AUTHOR'S MAIN ARGUMENT

Step 2: Read first paragraph
  "近年、若者の活字離れが問題となっている"
  → Topic: Young people's declining reading (common belief setup)

Step 3: Scan for discourse markers
  しかし (line 3) → CONTRAST — author is about to disagree with the common belief
  つまり (line 5) → SUMMARY — this sentence = the author's point

Step 4: Read last paragraph
  "若者は読んでいる。ただ、読む対象が変わっただけだ。"
  → Young people ARE reading. Just what they read has changed.

Step 5: Answer the question
  Author's main argument = the sentence after つまり:
  "問題は「読む量」ではなく「読む内容」の変化にある"
  = The problem is not HOW MUCH they read but WHAT they read.

Correct answer (paraphrase):
  "若者の読書量が減ったわけではなく、読む内容が変化しただけである"
  (Young people haven't reduced reading — only what they read has changed)

Wrong answers (and why):
  ✗ "若者はスマートフォンで読書をしている" → mentioned but not the main point
  ✗ "若者の活字離れは深刻な問題だ" → REVERSED — author argues against this
  ✗ "電子書籍の利用を増やすべきだ" → NOT MENTIONED — author makes no prescription
```

---

## The Three Killer Traps Across All Levels

### Trap 1: The True-But-Not-The-Point Answer

```
This answer is supported by the text — but it answers the WRONG question.

Example:
  Q: 筆者の主張は何か (What is the author's main argument?)
  Text mentions: 電子書籍の利用者は増えている (ebook users are increasing)
  
  Wrong answer: 電子書籍の利用者が増えている (ebook users are increasing)
  → TRUE — text says this. But this is a SUPPORTING DETAIL, not the main argument.
  
  Test: The correct answer must be the CONCLUSION, not a supporting fact.
  Signal: The conclusion comes AFTER つまり / 要するに / last paragraph.
```

### Trap 2: The "Stronger Than the Text" Answer

```
The text uses hedging language. The wrong answer removes the hedge.

Text says:    「〜かもしれない」 (might be)
              「〜と考えられる」 (it is thought that)
              「〜傾向がある」  (there is a tendency to)
              「〜ことが多い」  (often / frequently)

Wrong answer: 「必ず〜だ」   (definitely)
              「〜である」   (is — with certainty)
              「常に〜だ」   (always)

Rule: If the text hedges → the correct answer also hedges.
      An answer more certain than the text = WRONG.
```

### Trap 3: The "Reasonable But Absent" Answer

```
This answer sounds completely logical and reasonable — but the text NEVER says it.

JLPT tests reading comprehension of THIS text, not general knowledge.
An answer can be true in the real world but wrong on JLPT if the text doesn't say it.

Detection:
  After reading each answer option, ask: "Which sentence in the text supports this?"
  If you can't point to a specific sentence → WRONG ANSWER.
  
Example:
  Q: What does the author suggest about education?
  Option: "Teachers should use more technology in the classroom"
  The text discusses education and technology → sounds right → but the author never says this
  → WRONG (absent from text)
```

---

## Discourse Marker Quick-Reference Chart

```
When you see...     Read the next sentence because...
─────────────────────────────────────────────────────────────────────
つまり             = THE ANSWER (author's conclusion in plain language)
要するに           = THE ANSWER (summary of everything before)
しかし             = THE REAL POINT (contrast with what was said before)
ところが           = UNEXPECTED RESULT (story takes a turn)
したがって         = LOGICAL CONCLUSION (from evidence to conclusion)
その結果           = WHAT HAPPENED (result of the problem/action described)
たとえば           = EXAMPLE FOLLOWS → SKIP after reading 1 sentence
なぜなら           = REASON FOLLOWS (explains the previous claim)
一方               = CONTRASTING PERSPECTIVE (the other side's view)
ただし             = EXCEPTION or QUALIFICATION (important condition)
```

---

## Level Comparison: How the Difficulty Escalates

```
        N5              N4              N3              N2
Length  ~200 chars      ~300 chars      ~500 chars      ~700–1000 chars
Vocab   ~800 words      ~1,500 words    ~3,750 words    ~6,000 words
Kanji   ~100            ~300            ~600            ~1,000
Furigana All kanji      Most kanji      Hard kanji      Rare kanji only
Style   Plain/simple    Letter/email    Light opinion   Academic/formal
Answer  Stated directly Mostly direct   Some inference  Always inference
        in text         + simple infer  + "what refers" + abstraction
Markers None needed     でも/だから     しかし/つまり   Full set required
Time    No pressure     Some pressure   Timed practice  Critical to master

Strategy at each level:
  N5: Read all → find sentence → match to answer
  N4: Read all → distinguish fact vs. implied feeling
  N3: 5-step method → "refers to" = previous sentence
  N2: 5-step + elimination + 4 question types + marker mastery
```

---

## Weekly Practice Plan (All Levels)

```
BEGINNER (N5–N4):
  Day 1–5:  1 short/medium passage per day (10 min)
            After: check answer, find the EXACT sentence that supports it
  Day 6:    Review wrong answers — WHY was your answer wrong?
  Day 7:    Rest

INTERMEDIATE (N3):
  Day 1–5:  1 N3 long passage per day using 5-step method (15 min)
            Time yourself — N3 target: 1 passage in 8 min
  Day 6:    Review discourse markers + wrong answers
  Day 7:    1 full reading section simulation

ADVANCED (N2):
  Day 1–3:  1 N2 long passage per day (10 min, strictly timed)
            Practice elimination: for each wrong answer, write WHY it's wrong
  Day 4:    1 medium + 1 long passage back-to-back (simulate exam pressure)
  Day 5:    Discourse marker drill (write 3 sentences using 5 different markers)
  Day 6:    Full reading section simulation (timed: 40 min for full section)
  Day 7:    Review all wrong answers + update Anki with unknown vocab from passages
```

---

## The Single Most Important Rule

```
The correct answer to ANY JLPT long text question is ALWAYS:
  ✓ Directly supported by a specific sentence or paragraph in the text
  ✓ Not stronger than what the text says
  ✓ The answer to the SPECIFIC question asked (not just true in the text)

If you can point to the exact sentence that supports your answer → high confidence.
If you chose an answer because it "sounds right" → danger zone.

Practice this until it's automatic:
  Every time you answer correctly: "Which sentence supports this?"
  Every time you answer incorrectly: "What type of trap did I fall for?"
```
