# Glossary: JLPT Long Text Reading Strategy

Every term from the main guide explained for a JLPT beginner.

---

**長文理解 (ちょうぶんりかい) — Long Text Comprehension**
The JLPT reading question type that uses the longest passages (~700–1000 characters at N2). Requires strategy because there is not enough time to read every word carefully. The main challenge is identifying what to read and what to skip.

**短文理解 (たんぶんりかい) — Short Text Comprehension**
Reading questions with ~150–200 character passages. Short enough to read everything. The question is usually factual: "What did X do?" Common at N5 and N4.

**中文理解 (ちゅうぶんりかい) — Medium Text Comprehension**
Reading questions with ~400–500 character passages. The "question-first" method starts becoming useful here. Common at N3 and N4.

**Discourse Marker (談話マーカー)**
A word or phrase that signals the logical relationship between sentences — "however," "therefore," "in other words." In Japanese: しかし, つまり, したがって. Finding these is the core skill for navigating long texts without reading every word.

**つまり**
"In other words" / "In short." The single most important discourse marker for JLPT. The sentence immediately after つまり is almost always the author's main conclusion — and the answer to "what does the author want to say?"

**要するに (ようするに)**
"To sum up" / "In short." Equivalent to つまり in function. The sentence after 要するに = author's main point. Learn to spot this instantly.

**しかし**
"However" / "But." A contrast marker. The sentence after しかし contains the REAL point — the author is about to contradict or qualify what was just said. Most JLPT texts follow the pattern: common belief → しかし → author's different view.

**ところが**
"However" (with a nuance of unexpected result). Similar to しかし but emphasizes that the result was surprising or contrary to expectation. The sentence after ところが is important.

**したがって**
"Therefore" / "Consequently." Formal written Japanese. Signals a logical conclusion drawn from previous evidence. The sentence after したがって = the logical outcome the author is building toward.

**その結果 (そのけっか)**
"As a result." Signals the consequence of the situation described in the previous sentences. Marks the cause → effect transition.

**たとえば**
"For example." Signals that an example follows. The example itself is almost never the answer to a question — the CLAIM being illustrated (the sentence before たとえば) is more important. Skip examples after reading one sentence.

**一方（で）(いっぽう(で))**
"On the other hand." Signals a contrasting perspective or comparison. In N2 integrated comprehension questions (two texts), this marker appears when the texts are compared.

**ただし**
"However" / "Provided that." Signals an exception or important qualification to a rule or claim. The sentence after ただし adds a condition that limits or refines what was just said.

**なぜなら**
"Because." Signals that the reason for the previous claim follows. Unlike だから (which comes after the cause), なぜなら comes before the explanation.

**Question-first method**
The reading strategy of reading the exam question before reading the passage. Knowing what you're looking for before you read means you can scan efficiently rather than reading everything.

**5-Step Method**
The universal long-text reading strategy: (1) Read question, (2) Read first paragraph, (3) Scan for discourse markers, (4) Read last paragraph, (5) Answer with elimination. Applies at N3–N2.

**Elimination method**
Answering multiple-choice questions by crossing out clearly wrong options rather than trying to identify the perfect correct answer. Three wrong options eliminated = one correct answer found.

**Inference question**
A reading question where the answer is IMPLIED by the text but not stated directly. "How does the person feel?" — the text shows the situation, you infer the emotion. First appears at N4, becomes common at N3 and N2.

**"Refers to" question (指示語問題 しじごもんだい)**
A reading question asking what a pronoun or demonstrative (このような, それ, このこと) refers to. The answer is almost always the immediately preceding sentence. Key skill introduced at N3.

**筆者 (ひっしゃ)**
"The author" / "The writer." Appears in questions like 筆者が最も言いたいことは何か (What does the author most want to say?). The answer to this question type is always the author's conclusion, not a supporting detail.

**主張 (しゅちょう)**
"Argument" / "Claim." 筆者の主張 = the author's main argument. The conclusion, not the supporting evidence.

**Trap: "True but not the point"**
A wrong answer that is supported somewhere in the text but answers the wrong question. It states a supporting detail, not the main conclusion. The most common trap at N3–N2. Test: does this answer the specific question, or just appear in the text?

**Trap: "Stronger than the text"**
A wrong answer that makes a more certain or absolute claim than the text does. If the text says 「かもしれない」(might), the correct answer also hedges. An answer saying 「確実だ」(definitely) is wrong.

**Trap: "Reasonable but absent"**
A wrong answer that sounds logical and reasonable in real life but is never mentioned in the text. JLPT tests YOUR READING of THIS text, not your general knowledge. If it's not in the text, it's wrong.

**Hedging language**
Words that soften or qualify a claim. Common in academic-style N2 texts: かもしれない (might), 〜と考えられる (it is thought that), 〜傾向がある (there is a tendency), 〜ことが多い (often). The correct answer to "what does the author say" must match the level of certainty in the text.

**活字離れ (かつじばなれ)**
"Declining engagement with print." The drifting away from reading printed text. A common social topic in N2 reading passages — used as the sample text topic in this guide.

**電子書籍 (でんししょせき)**
"E-book" / "Electronic book." Digital books read on devices. Appears frequently in N2 social/technology reading passages.

**Text structure (Structure A/B/C)**
The three common argument frameworks in JLPT long texts: A = problem → solution, B = common belief → counter-argument, C = background → change → implication. Identifying the structure in the first paragraph lets you predict where the answer will be.

**Skimming**
Reading quickly to get the general topic and structure, without processing every word. Used in Steps 2 and 4 of the 5-step method (first and last paragraphs).

**Scanning**
Moving your eyes quickly over text to find a specific word, number, or phrase without reading everything. Used when you know WHAT you're looking for (from Step 1) and just need to locate it.

**Paraphrase**
Expressing the same meaning using different words. In JLPT, the correct answer is almost never a direct quote from the text — it is a paraphrase. This is why you need to understand meaning, not just match vocabulary.

**Supporting detail**
A fact, example, or explanation that backs up the author's main point but is not the main point itself. Supporting details appear after たとえば, 具体的には, なぜなら. They are often used in wrong answers to distract you from the real conclusion.

**N5 → N2 escalation**
The progression in difficulty: N5 (answer stated directly, ~200 chars), N4 (simple inference added, ~300 chars), N3 (refers-to questions + discourse markers needed, ~500 chars), N2 (full strategy required, formal style, ~700–1000 chars, 4 question types).
