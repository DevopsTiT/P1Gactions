# Terraform IaC — Glossary

Every term, tool, and concept from main.md explained for an SRE beginner.

---

**Terraform**
An open-source tool by HashiCorp that lets you describe infrastructure (servers, databases, networks) as code in text files, then creates/updates/deletes that infrastructure automatically. Like a blueprint system for cloud resources.

**Infrastructure as Code (IaC)**
The practice of managing infrastructure through machine-readable files checked into version control instead of manual clicks in a web console. Makes infra reproducible, auditable, and reviewable like software.

**HCL (HashiCorp Configuration Language)**
The language Terraform files are written in. Looks like JSON but more human-readable. Files use the `.tf` extension.

**.tf file**
A text file written in HCL that describes infrastructure resources. Terraform reads all `.tf` files in a directory together as one configuration.

**Provider**
A plugin that teaches Terraform how to talk to a specific platform — AWS, GCP, Azure, Kubernetes, Dynatrace, GitHub, etc. Each provider knows the API calls needed to create/read/update/delete resources on that platform.

**Resource**
The fundamental unit in Terraform — one cloud object you want to exist. Examples: an EC2 instance, an S3 bucket, a DNS record, a Kubernetes namespace. Declared with a `resource` block.

**Data Source**
A read-only lookup — fetches information about infrastructure that exists but is NOT managed by this Terraform config. Like a `SELECT` query. Declared with a `data` block.

**Variable**
An input parameter for your Terraform config. Like a function argument — callers pass in different values so the same code works for dev, staging, and production.

**Output**
A value that Terraform exports after `apply` — like a function return value. Used to pass information between modules (e.g. the VPC ID created by the networking module, passed into the compute module).

**Local Value (locals)**
A computed value you define once inside a `.tf` file and reuse in multiple places. Like a local variable in a function. Avoids repetition.

**Module**
A reusable, self-contained bundle of `.tf` files with declared inputs (variables) and outputs. Like a function in programming — you write it once and call it with different arguments for each environment.

**State File (.tfstate)**
A JSON file that records what Terraform believes currently exists in the real cloud. Terraform's memory. Used to compute diffs between desired state (`.tf` files) and actual state. NEVER commit to Git.

**Desired State**
What your `.tf` files say should exist. The blueprint.

**Actual State**
What is really running in the cloud. What `terraform plan` reads by making API calls to verify.

**Drift**
When someone makes a manual change in the cloud console and the `.tfstate` no longer matches reality. `terraform plan` detects and shows drift as a diff.

**terraform init**
The setup command — downloads required providers, initializes the backend, and downloads any referenced modules. Must be run before any other Terraform command in a directory.

**terraform plan**
A dry-run command that computes what changes Terraform would make WITHOUT making them. Shows a diff: `+` for creates, `~` for updates, `-` for destroys. Always review before applying.

**terraform apply**
Executes the plan — makes API calls to create/update/destroy resources to match your `.tf` files. Updates the state file when done.

**terraform destroy**
Destroys all resources managed by the current config. The nuclear option. Usually restricted to dev environments.

**terraform import**
Brings an existing cloud resource (created manually) under Terraform management by writing its current state into `.tfstate`. Lets you adopt existing infra without recreating it.

**terraform state**
A subcommand for inspecting and surgically modifying the state file. Used for moving resources after refactors (`state mv`) or removing orphaned records (`state rm`).

**Remote Backend**
Configuration that stores the `.tfstate` file in a shared remote location (S3 bucket, GCS bucket, Terraform Cloud) instead of locally on your laptop. Required for team use — everyone reads/writes the same state.

**S3 Backend**
A popular remote backend that stores state in an AWS S3 bucket. Usually paired with a DynamoDB table for state locking.

**State Locking**
A mechanism that prevents two engineers from running `terraform apply` at the same time, which would corrupt the state file. With S3 backend, a DynamoDB table serves as the lock.

**DynamoDB (for state lock)**
An AWS NoSQL database used as a locking mechanism for the S3 Terraform backend. Terraform writes a lock record before applying and deletes it when done. If two applies run simultaneously, the second one waits or errors.

**Backend**
The configuration block in Terraform that defines where the state file lives and how it's accessed. Can be local (default, not recommended for teams) or remote (S3, GCS, Terraform Cloud).

**Workspace**
A named slot for a separate state file within the same Terraform configuration directory. Lets one set of `.tf` files maintain independent state for dev/staging/production. Simple but can be dangerous — all workspaces share the same code.

**terraform.tfvars**
A file containing actual variable values. Like a `.env` file — you have one per environment. NEVER commit this file if it contains secrets.

**TF_VAR_ (environment variable prefix)**
A way to pass variable values to Terraform without a tfvars file. `TF_VAR_db_password=secret` is equivalent to setting `db_password = "secret"` in tfvars. Useful for CI pipelines.

**TF_LOG**
An environment variable that controls Terraform's debug logging verbosity. Set to `DEBUG` to see every API call Terraform makes.

**lifecycle block**
A configuration inside a `resource` block that overrides Terraform's default create/update/destroy behavior. Common settings: `prevent_destroy`, `create_before_destroy`, `ignore_changes`.

**prevent_destroy**
A lifecycle setting that makes `terraform destroy` (and `plan -destroy`) error out on that resource. Used to protect production databases and critical buckets from accidental deletion.

**create_before_destroy**
A lifecycle setting that tells Terraform to create the replacement resource BEFORE deleting the old one. Reduces downtime during replacements.

**ignore_changes**
A lifecycle setting that tells Terraform to stop tracking and reverting changes to specific attributes. Useful when external systems (auto-scalers, config management) legitimately change values Terraform initially set.

**count**
A meta-argument that creates multiple copies of a resource. `count = 3` creates 3 identical resources named `resource.name[0]`, `resource.name[1]`, `resource.name[2]`. Bad for named resources because removing the middle one renumbers the rest.

**for_each**
A meta-argument that creates one resource per item in a map or set. Better than `count` for named resources because each item has a stable key (e.g. `resource.name["payments"]`) — removing one item doesn't affect the others.

**`.terraform.lock.hcl`**
A lock file that records the exact version and hash of every provider downloaded. Ensures all team members and CI pipelines use the same provider versions. Should be committed to Git.

**tfenv**
A version manager for Terraform, similar to `nvm` for Node.js. Lets you install and switch between multiple Terraform versions on the same machine — useful when different projects require different versions.

**terraform fmt**
Formats `.tf` files to Terraform's canonical style (consistent indentation, alignment). Like `prettier` for HCL. Running it in CI (`-check` flag) enforces consistent formatting across the team.

**terraform validate**
Checks syntax and internal references in `.tf` files without making any cloud API calls. Faster than plan — useful as the first CI gate.

**-out flag (terraform plan -out=tfplan)**
Saves the computed plan to a binary file. When you then run `terraform apply tfplan`, Terraform executes exactly that plan — no re-planning. Prevents surprises when state changes between plan and apply in CI.

**-target flag**
Restricts `plan` or `apply` to only a specific resource or module. Useful for surgical changes but dangerous — it can create partial states where some resources are updated and others are not. Use sparingly.

**refresh-only**
A `plan` or `apply` mode that only updates the state file to match real cloud state, WITHOUT proposing any changes to infrastructure. Used to sync Terraform's knowledge of drift without acting on it.

**cidrsubnet() function**
A built-in Terraform function that calculates a subnet CIDR block from a larger network CIDR. Example: `cidrsubnet("10.0.0.0/16", 4, 1)` returns `"10.0.1.0/20"`. Useful in networking modules to avoid hardcoding subnet ranges.

**Sensitive variable**
A variable declared with `sensitive = true` in its definition. Terraform hides its value in plan/apply output (shows `(sensitive value)`) to prevent secrets appearing in logs.
