# Terraform IaC — Commands Reference

---

## Phase 0 — Setup & Installation

```bash
# Check Terraform is installed
terraform version

# Install via Homebrew (macOS)
brew tap hashicorp/tap
brew install hashicorp/tap/terraform

# Install specific version via tfenv (version manager)
brew install tfenv
tfenv install 1.7.5
tfenv use 1.7.5
terraform version
```

---

## Phase 1 — Init (Always First)

```bash
# Initialize working directory (downloads providers + modules, sets up backend)
terraform init

# Re-init after adding a new provider or module
terraform init -upgrade

# Init without backend (for testing / CI lint stages)
terraform init -backend=false

# Migrate state from local to remote backend
terraform init -migrate-state

# Check what providers were downloaded
ls .terraform/providers/
cat .terraform.lock.hcl   # shows pinned provider versions
```

---

## Phase 2 — Validate & Format

```bash
# Check syntax and internal references (no cloud API calls)
terraform validate

# Auto-format all .tf files in current directory
terraform fmt

# Check formatting without changing files (CI use)
terraform fmt -check
terraform fmt -check -recursive   # check all subdirectories

# Show diff of what fmt would change
terraform fmt -diff
```

---

## Phase 3 — Plan

```bash
# Show what Terraform would change (no changes made)
terraform plan

# Save the plan to a file (use this in CI)
terraform plan -out=tfplan

# Plan with specific var values
terraform plan -var="environment=production" -var="instance_count=3"

# Plan using a tfvars file
terraform plan -var-file="production.tfvars"

# Plan for a specific target only (dangerous — use carefully)
terraform plan -target=aws_instance.web_server

# Refresh-only plan: show drift without proposing infra changes
terraform plan -refresh-only

# Show plan in JSON (for parsing in CI)
terraform show -json tfplan | jq '.resource_changes[] | select(.change.actions[] | contains("delete"))'
```

---

## Phase 4 — Apply

```bash
# Apply and confirm interactively
terraform apply

# Apply a saved plan (no re-plan, safe for CI)
terraform apply tfplan

# Apply without interactive confirmation (CI use only)
terraform apply -auto-approve

# Apply with var overrides
terraform apply -var="environment=staging"

# Apply only a specific resource (surgical change)
terraform apply -target=module.compute.aws_instance.app

# Accept drift into state without changing infra
terraform apply -refresh-only
```

---

## Phase 5 — Outputs & State Inspection

```bash
# Show all output values
terraform output

# Show a specific output
terraform output load_balancer_dns

# Output as JSON (for scripting)
terraform output -json

# List all resources in state
terraform state list

# Show full details of one resource
terraform state show aws_instance.web_server
terraform state show module.networking.aws_vpc.main

# Pull remote state to local file
terraform state pull > state-snapshot.json

# Show formatted view of entire state
terraform show
```

---

## Phase 6 — Workspaces

```bash
# List workspaces
terraform workspace list

# Show current workspace
terraform workspace show

# Create a new workspace
terraform workspace new dev
terraform workspace new staging
terraform workspace new production

# Switch to a workspace
terraform workspace select production

# Delete a workspace (must be empty / not current)
terraform workspace delete dev
```

---

## Phase 7 — Import Existing Resources

```bash
# Import an existing AWS EC2 instance
terraform import aws_instance.web_server i-1234567890abcdef0

# Import an existing S3 bucket
terraform import aws_s3_bucket.logs my-existing-bucket-name

# Import an existing security group
terraform import aws_security_group.app sg-12345678

# Import a Kubernetes namespace
terraform import kubernetes_namespace.monitoring monitoring

# After import: plan to see what config needs to be added to .tf
terraform plan
```

---

## Phase 8 — State Surgery (Use With Care)

```bash
# Remove a resource from state WITHOUT destroying it in cloud
terraform state rm aws_instance.old_server

# Move a resource to new address (after refactoring)
terraform state mv aws_instance.web_server module.compute.aws_instance.web_server

# Move a resource between state files (requires both configs loaded)
terraform state mv -state-out=../new-project/terraform.tfstate \
  aws_s3_bucket.logs aws_s3_bucket.logs

# Replace state with a previous version (emergency recovery)
terraform state push state-backup.json
```

---

## Phase 9 — Destroy

```bash
# Destroy ALL resources managed by this config (VERY DANGEROUS)
terraform destroy

# Destroy with auto-approve (CI use — be very careful with scope)
terraform destroy -auto-approve

# Destroy only a specific resource
terraform destroy -target=aws_instance.old_server

# Preview what would be destroyed without doing it
terraform plan -destroy
```

---

## Phase 10 — Backend Bootstrap (S3 + DynamoDB)

```bash
# Create state bucket
aws s3api create-bucket \
  --bucket my-company-terraform-state \
  --region ap-northeast-1 \
  --create-bucket-configuration LocationConstraint=ap-northeast-1

# Enable versioning on state bucket
aws s3api put-bucket-versioning \
  --bucket my-company-terraform-state \
  --versioning-configuration Status=Enabled

# Enable default encryption
aws s3api put-bucket-encryption \
  --bucket my-company-terraform-state \
  --server-side-encryption-configuration \
    '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'

# Block all public access
aws s3api put-public-access-block \
  --bucket my-company-terraform-state \
  --public-access-block-configuration \
    "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

# Create DynamoDB lock table
aws dynamodb create-table \
  --table-name terraform-state-lock \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region ap-northeast-1
```

---

## Phase 11 — Debugging

```bash
# Enable debug logging
export TF_LOG=DEBUG
terraform plan 2>&1 | tee terraform-debug.log

# Less verbose — just errors
export TF_LOG=ERROR
terraform apply

# Log to a file
export TF_LOG=DEBUG
export TF_LOG_PATH=./terraform.log
terraform apply

# Disable debug logging
unset TF_LOG

# Check which version of a provider is being used
terraform providers

# Verify provider lock file matches installed
terraform providers lock
```

---

## Phase 12 — Common One-Liners

```bash
# Find all .tf files in project
find . -name "*.tf" | sort

# Grep for a resource type across all files
grep -r "aws_instance" . --include="*.tf"

# Check for hardcoded secrets (basic scan)
grep -rE "(password|secret|token)\s*=\s*\"[^\"]{8,}\"" . --include="*.tf"

# List all resource types used in this config
grep -h "^resource" **/*.tf | awk '{print $2}' | sort -u

# Count resources by type in state
terraform state list | sed 's/\[.*//' | sed 's/\..*//' | sort | uniq -c | sort -rn
```
