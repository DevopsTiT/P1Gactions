# Terraform Infrastructure as Code — SRE Deep Dive

---

## E2E Flow Summary

```
[Write .tf files describing desired infra]
        │
        ▼
[terraform init]  ← downloads providers + modules, sets up backend
        │
        ▼
[terraform plan]  ← compares desired state (.tf) vs current state (.tfstate)
        │                produces a diff: what will be created / changed / destroyed
        ▼
[terraform apply] ← executes the plan against the real cloud provider API
        │
        ▼
[State file updated] ← .tfstate now reflects actual infra
        │
        ▼
[Drift? Run plan again] ← if someone changed infra manually, plan shows drift
```

---

## Decision Tree — Which Terraform Concept to Reach For?

```
Need to manage cloud resources?
  └── Write resource blocks in .tf files

Need to reuse the same pattern across envs (dev/staging/prod)?
  └── Use a MODULE (reusable parameterized .tf bundle)

Need to share outputs between separate Terraform projects?
  └── Use terraform_remote_state or data sources

Need to store state safely for a team (not local)?
  └── Configure a REMOTE BACKEND (S3 + DynamoDB, GCS, Terraform Cloud)

Need to run same infra in 3 environments with different values?
  └── Use WORKSPACES or separate state files per env + tfvars files

Infra was changed manually and Terraform doesn't know about it?
  └── Run terraform plan to see drift, then apply to reconcile
      OR terraform import to pull existing resource into state

Need to destroy everything cleanly?
  └── terraform destroy (DANGEROUS — confirm scope first)
```

---

## Tool Map

| Tool / Concept             | What it does                                              |
|----------------------------|-----------------------------------------------------------|
| `terraform init`           | Download providers, modules, set up backend               |
| `terraform plan`           | Diff desired vs actual state — no changes made            |
| `terraform apply`          | Execute the plan — changes real infra                     |
| `terraform destroy`        | Tear down all resources managed by this config            |
| `terraform import`         | Bring existing infra under Terraform management           |
| `terraform state`          | Inspect / move / remove items from state file             |
| `terraform output`         | Read output values from state                             |
| `terraform fmt`            | Auto-format .tf files to canonical style                  |
| `terraform validate`       | Check syntax and internal references without calling API  |
| `terraform workspace`      | Manage multiple named state files from one config         |
| Provider                   | Plugin that knows how to talk to AWS/GCP/Azure/Dynatrace  |
| Module                     | A reusable bundle of .tf files with inputs and outputs    |
| State file (.tfstate)      | JSON record of what Terraform believes exists in real life|
| Remote backend             | Stores state file remotely (S3, GCS) instead of locally  |
| Data source                | Read existing infra (not managed by Terraform) into your config |

---

## Part 1 — Core Concepts

### 1.1 What Problem Terraform Solves

Without IaC: you click through a cloud console to create servers, networks, databases. Tomorrow you do it again for staging. Six months later nobody remembers what exact settings were used. Manual changes accumulate. Environments drift apart.

With Terraform: infrastructure is described in text files checked into Git. Creating staging is `terraform apply`. Reproducing prod in a disaster is `terraform apply`. The diff between what you have and what you want is `terraform plan`. Everything is auditable, repeatable, version-controlled.

### 1.2 Desired State vs Actual State

This is the core mental model:

```
.tf files  =  what you WANT to exist
.tfstate   =  what Terraform THINKS exists
Real cloud =  what ACTUALLY exists

terraform plan  =  diff(.tf vs .tfstate + cloud API)
terraform apply =  make real cloud match .tf, then update .tfstate
```

If someone changes infra manually in the console (called **drift**), the next `plan` will show Terraform wanting to revert it.

### 1.3 The State File Is Sacred

The `.tfstate` file is Terraform's memory. If you lose it:
- Terraform no longer knows it manages those resources
- Running `apply` again would try to CREATE duplicates
- Destroying infra becomes manual

Rules:
- Never edit `.tfstate` manually
- Never store it in Git (it may contain secrets)
- Always use a remote backend for team use
- Use state locking (DynamoDB for S3 backend) to prevent concurrent applies

---

## Part 2 — File Structure

### 2.1 Standard Layout for a Single Environment

```
infra/
├── main.tf          # core resources
├── variables.tf     # input variable declarations
├── outputs.tf       # values to export after apply
├── providers.tf     # provider configuration (AWS, GCP, etc.)
├── versions.tf      # required Terraform + provider versions
├── terraform.tfvars # actual variable values (do NOT commit if secrets)
└── backend.tf       # remote state configuration
```

### 2.2 Standard Layout for Multi-Environment (Recommended)

```
infra/
├── modules/
│   ├── networking/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── outputs.tf
│   └── compute/
│       ├── main.tf
│       ├── variables.tf
│       └── outputs.tf
├── environments/
│   ├── dev/
│   │   ├── main.tf        # calls modules with dev values
│   │   ├── terraform.tfvars
│   │   └── backend.tf     # dev state bucket
│   ├── staging/
│   │   └── ...
│   └── production/
│       └── ...
```

Each environment directory has its own state file. Running `terraform apply` in `environments/dev/` only touches dev infra.

---

## Part 3 — HCL Syntax Deep Dive

### 3.1 Resource Block

The fundamental building block — declares a real cloud object:

```hcl
# Syntax: resource "<provider_type>" "<local_name>" { ... }
resource "aws_instance" "web_server" {
  ami           = "ami-0c55b159cbfafe1f0"
  instance_type = "t3.medium"
  subnet_id     = aws_subnet.public.id   # reference to another resource

  tags = {
    Name        = "web-server-prod"
    Environment = var.environment        # reference to a variable
    Team        = "payments"
  }
}
```

The local name (`web_server`) is only used within Terraform to reference this resource. It has no effect on the cloud resource name.

### 3.2 Variable Block

Declares an input — like a function parameter:

```hcl
# variables.tf
variable "environment" {
  description = "Deployment environment (dev/staging/production)"
  type        = string
  default     = "dev"
}

variable "instance_count" {
  description = "Number of EC2 instances"
  type        = number
  default     = 1
}

variable "allowed_cidr_blocks" {
  description = "CIDRs allowed to reach the load balancer"
  type        = list(string)
  default     = ["10.0.0.0/8"]
}

variable "db_password" {
  description = "Database master password"
  type        = string
  sensitive   = true   # hides value in plan/apply output
}
```

### 3.3 Output Block

Exports values after apply — like a function return value:

```hcl
# outputs.tf
output "web_server_public_ip" {
  description = "Public IP of the web server"
  value       = aws_instance.web_server.public_ip
}

output "load_balancer_dns" {
  description = "DNS name of the ALB"
  value       = aws_lb.main.dns_name
}
```

Read outputs after apply:
```bash
terraform output web_server_public_ip
terraform output -json   # all outputs as JSON
```

### 3.4 Provider Block

Tells Terraform which cloud and how to authenticate:

```hcl
# providers.tf
provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      ManagedBy   = "terraform"
      Environment = var.environment
    }
  }
}

provider "dynatrace" {
  dt_env_url   = var.dynatrace_env_url
  dt_api_token = var.dynatrace_api_token
}
```

### 3.5 Data Source Block

Read existing infrastructure — resources NOT managed by this Terraform:

```hcl
# Look up an existing VPC by tag
data "aws_vpc" "existing" {
  tags = {
    Name = "production-vpc"
  }
}

# Use it in a resource
resource "aws_subnet" "new_subnet" {
  vpc_id     = data.aws_vpc.existing.id
  cidr_block = "10.0.10.0/24"
}
```

Data sources are read-only. Terraform will never create, modify, or destroy a `data` block resource.

### 3.6 Local Values

Computed values you want to reuse — like local variables:

```hcl
locals {
  name_prefix    = "${var.project}-${var.environment}"
  common_tags    = {
    Project     = var.project
    Environment = var.environment
    ManagedBy   = "terraform"
  }
}

resource "aws_s3_bucket" "logs" {
  bucket = "${local.name_prefix}-logs"
  tags   = local.common_tags
}
```

---

## Part 4 — Modules Deep Dive

### 4.1 Why Modules

Without modules: you copy-paste the same networking .tf for dev, staging, prod. A fix must be applied 3 times. With modules: one module, called 3 times with different inputs.

### 4.2 Writing a Module

```
modules/networking/
├── main.tf       # the actual resources
├── variables.tf  # inputs the caller must provide
└── outputs.tf    # what the caller can read back
```

```hcl
# modules/networking/variables.tf
variable "vpc_cidr" {
  type = string
}
variable "environment" {
  type = string
}

# modules/networking/main.tf
resource "aws_vpc" "main" {
  cidr_block = var.vpc_cidr
  tags = { Name = "${var.environment}-vpc" }
}

resource "aws_subnet" "public" {
  vpc_id     = aws_vpc.main.id
  cidr_block = cidrsubnet(var.vpc_cidr, 4, 1)
}

# modules/networking/outputs.tf
output "vpc_id" {
  value = aws_vpc.main.id
}
output "public_subnet_id" {
  value = aws_subnet.public.id
}
```

### 4.3 Calling a Module

```hcl
# environments/production/main.tf
module "networking" {
  source      = "../../modules/networking"
  vpc_cidr    = "10.0.0.0/16"
  environment = "production"
}

module "compute" {
  source            = "../../modules/compute"
  environment       = "production"
  vpc_id            = module.networking.vpc_id        # module output used as input
  public_subnet_id  = module.networking.public_subnet_id
}
```

After adding or changing a module source, run `terraform init` to download/update it.

---

## Part 5 — Remote Backend & State Locking

### 5.1 S3 Backend (AWS)

```hcl
# backend.tf
terraform {
  backend "s3" {
    bucket         = "my-company-terraform-state"
    key            = "production/terraform.tfstate"
    region         = "ap-northeast-1"
    encrypt        = true
    dynamodb_table = "terraform-state-lock"  # prevents concurrent applies
  }
}
```

Create the S3 bucket and DynamoDB table before running `terraform init`:

```bash
# Create state bucket
aws s3api create-bucket \
  --bucket my-company-terraform-state \
  --region ap-northeast-1 \
  --create-bucket-configuration LocationConstraint=ap-northeast-1

# Enable versioning (so you can recover old state)
aws s3api put-bucket-versioning \
  --bucket my-company-terraform-state \
  --versioning-configuration Status=Enabled

# Enable encryption
aws s3api put-bucket-encryption \
  --bucket my-company-terraform-state \
  --server-side-encryption-configuration \
    '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'

# Create DynamoDB lock table
aws dynamodb create-table \
  --table-name terraform-state-lock \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region ap-northeast-1
```

### 5.2 GCS Backend (GCP)

```hcl
terraform {
  backend "gcs" {
    bucket  = "my-company-terraform-state"
    prefix  = "production/terraform"
  }
}
```

### 5.3 Why State Locking Matters

If two engineers run `terraform apply` simultaneously:
- Both read the same state
- Both make changes
- One overwrites the other's state update
- State is now out of sync with reality — very bad

DynamoDB lock table prevents this: the first `apply` acquires a lock; the second one waits or errors.

---

## Part 6 — Workspaces vs Separate State Files

### 6.1 Workspaces (Simple Cases)

Workspaces let one set of .tf files maintain multiple independent state files:

```bash
terraform workspace new dev
terraform workspace new staging
terraform workspace new production

terraform workspace select production
terraform apply   # applies to production state only
```

Inside .tf files, reference current workspace:
```hcl
locals {
  instance_size = {
    dev        = "t3.micro"
    staging    = "t3.small"
    production = "t3.large"
  }
}

resource "aws_instance" "app" {
  instance_type = local.instance_size[terraform.workspace]
}
```

### 6.2 Separate Directories (Recommended for Prod)

Workspaces share the same .tf code which can be risky — a mistake in production config affects all workspaces. Separate directories isolate risk:

```
environments/
├── dev/        ← completely independent, own backend, own tfvars
├── staging/
└── production/ ← touching this directory only affects prod
```

Rule of thumb: use workspaces for truly identical environments; use separate directories when environments differ in significant ways (different regions, different security groups, different providers).

---

## Part 7 — Lifecycle Rules & Meta-Arguments

### 7.1 prevent_destroy

Protects critical resources from accidental `terraform destroy`:

```hcl
resource "aws_rds_instance" "production_db" {
  # ... config ...

  lifecycle {
    prevent_destroy = true   # terraform destroy will ERROR on this resource
  }
}
```

### 7.2 create_before_destroy

By default, Terraform destroys the old resource then creates the new one (causes downtime). This reverses the order:

```hcl
resource "aws_instance" "app" {
  # ... config ...

  lifecycle {
    create_before_destroy = true
  }
}
```

### 7.3 ignore_changes

Tell Terraform to stop managing certain attributes (e.g. when auto-scaling changes instance count externally):

```hcl
resource "aws_autoscaling_group" "app" {
  desired_capacity = 3

  lifecycle {
    ignore_changes = [desired_capacity]  # don't revert auto-scaler's changes
  }
}
```

### 7.4 count and for_each (Creating Multiple Resources)

```hcl
# count — simple repetition
resource "aws_instance" "workers" {
  count         = var.worker_count
  ami           = var.ami_id
  instance_type = "t3.medium"
  tags = { Name = "worker-${count.index}" }
}

# for_each — iterate over a map (better for named resources)
variable "services" {
  default = {
    payments  = { port = 8080, size = "t3.medium" }
    checkout  = { port = 8081, size = "t3.small"  }
    inventory = { port = 8082, size = "t3.small"  }
  }
}

resource "aws_instance" "service" {
  for_each      = var.services
  ami           = var.ami_id
  instance_type = each.value.size
  tags = { Name = each.key }
}
# Creates: aws_instance.service["payments"], aws_instance.service["checkout"], ...
```

---

## Part 8 — Importing Existing Infrastructure

When infra was created manually and you want Terraform to manage it:

```bash
# Step 1: Write the resource block in .tf (empty or with known config)
# resource "aws_s3_bucket" "logs" { }

# Step 2: Import the real resource into state
terraform import aws_s3_bucket.logs my-existing-bucket-name

# Step 3: Run plan to see what config is missing/different
terraform plan
# Terraform will show you what attributes it found vs what you declared

# Step 4: Update your .tf to match, until plan shows no changes
```

Modern Terraform (1.5+) has `import` blocks directly in .tf:

```hcl
import {
  to = aws_s3_bucket.logs
  id = "my-existing-bucket-name"
}
```

---

## Part 9 — CI/CD Integration

### 9.1 Typical Pipeline

```
PR opened
  └── terraform fmt -check    (fail if not formatted)
  └── terraform validate      (fail if syntax error)
  └── terraform plan          (post plan as PR comment)

PR merged to main
  └── terraform apply -auto-approve
```

### 9.2 Safe Apply Pattern

Never run `apply` without a saved plan in CI:

```bash
# In plan stage — save the plan
terraform plan -out=tfplan

# In apply stage — apply EXACTLY the saved plan (no re-plan, no surprises)
terraform apply tfplan
```

This prevents the plan and apply from seeing different state (e.g. someone else applied in between).

### 9.3 Environment Variables for Credentials

Never hardcode credentials in .tf files:

```bash
# AWS
export AWS_ACCESS_KEY_ID="..."
export AWS_SECRET_ACCESS_KEY="..."
export AWS_DEFAULT_REGION="ap-northeast-1"

# Pass variable values without a tfvars file
export TF_VAR_db_password="super-secret"
# Terraform reads TF_VAR_<name> automatically
```

---

## Part 10 — Drift Detection & Day-2 Operations

### 10.1 Detecting Drift

```bash
# Refresh state from real cloud, then show diff
terraform plan -refresh-only
# Shows what changed outside Terraform (manual console changes, auto-scaling, etc.)

# Accept drift into state WITHOUT changing real infra
terraform apply -refresh-only
```

### 10.2 State Surgery (Advanced — Use With Extreme Care)

```bash
# List all resources in state
terraform state list

# Show full details of one resource in state
terraform state show aws_instance.web_server

# Remove a resource from state WITHOUT destroying it
# Use when you want Terraform to forget about a resource
terraform state rm aws_instance.web_server

# Move a resource to a new address (e.g. after refactor)
terraform state mv aws_instance.web_server module.compute.aws_instance.web_server

# Pull current remote state to local file (for inspection)
terraform state pull > state-backup.json
```

---

## Common Mistakes

| Mistake | Consequence | Fix |
|---|---|---|
| State file committed to Git | Credentials/secrets exposed; concurrent edits corrupt state | Use remote backend; add `*.tfstate` to `.gitignore` |
| No state locking | Two simultaneous applies corrupt state | Add DynamoDB lock table to S3 backend |
| `terraform apply` without reviewing `plan` | Unexpected destroys (e.g. renaming a resource = destroy + recreate) | Always review plan output; look for `-` lines |
| `count` instead of `for_each` for named resources | Removing middle item renumbers all resources → mass destroy+recreate | Use `for_each` with maps for named resources |
| No `prevent_destroy` on stateful resources | `terraform destroy` or a refactor wipes the production DB | Add lifecycle `prevent_destroy = true` to databases, state buckets |
| `terraform destroy` in wrong workspace/directory | Destroys the wrong environment | Always check `terraform workspace show` before destroy |
| Hardcoded credentials in .tf files | Secrets in Git history forever | Use env vars (`TF_VAR_*`, `AWS_*`) or secret managers |
| No `.terraform.lock.hcl` committed | Different engineers get different provider versions | Commit the lock file; it pins provider versions like a lockfile |
