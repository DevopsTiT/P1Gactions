# Part 3 Deep Dive — Proactive Performance Monitoring

---

## The Core Distinction: Reactive vs Proactive

```
REACTIVE MONITORING (fire-alarm model):
  Something breaks → alarm sounds → SRE responds → users already hurt

  Timeline:
    T+0:00   Problem starts
    T+0:05   Alert threshold crossed, alert fires
    T+0:07   On-call acknowledges
    T+0:25   Root cause found
    T+0:35   Fix deployed
    T+0:40   Users recover
    ─────────────────────────────
    Total user impact: 40 minutes

PROACTIVE MONITORING (smoke-detector model):
  Trend identified → SRE investigates → fix applied → users never notice

  Timeline:
    T-7d     Memory slowly growing (trend alert fires)
    T-6d     SRE investigates: memory leak in connection pool
    T-5d     Fix deployed in staging, validated
    T-3d     Fix deployed in production
    T+0:00   Problem that would have happened — never happens
    ─────────────────────────────
    Total user impact: 0 minutes
```

Proactive monitoring requires three capabilities reactive monitoring doesn't:
1. **Trend detection** — not just current state, but direction of travel
2. **Baseline awareness** — knowing what "normal" looks like so you can detect drift
3. **Predictive alerting** — alerting on WHERE you're going, not just WHERE you are

---

## The Four Monitoring Layers — Each Catches Different Failures

```
Layer 4: Business / User Experience
  What: Are users succeeding at their goals?
  Tools: RUM, synthetic transactions, business metrics
  Catches: Silent failures (HTTP 200 but wrong answer),
           UX regressions, conversion rate drops

Layer 3: Application / Code Level
  What: How does the code perform internally?
  Tools: APM (Dynatrace, Jaeger, OTel), JVM metrics, profiling
  Catches: Slow DB queries, N+1 query patterns, thread pool saturation,
           GC pressure, memory leaks in application code

Layer 2: Service / Container Level
  What: How are the running containers performing?
  Tools: Prometheus + cAdvisor, Kubernetes metrics
  Catches: CPU throttling, OOMKill risk, pod restarts,
           container startup time regressions

Layer 1: Infrastructure / Node Level
  What: How is the underlying hardware/VM performing?
  Tools: node_exporter, cloud provider metrics (AWS CloudWatch, etc.)
  Catches: Disk filling, network packet loss, noisy neighbors,
           kernel-level issues, disk I/O saturation
```

Why monitor all four? Because a problem can start at any layer and only show up at a higher layer later:
- Disk filling (Layer 1) → DB runs out of space (Layer 2) → DB queries fail (Layer 3) → User orders fail (Layer 4)
- A Layer 4 alert tells you WHAT is broken; Layers 1–3 tell you WHY

---

## Layer 4: Business & User Experience Monitoring

### Real User Monitoring (RUM)

RUM collects telemetry from actual browsers and mobile apps, reflecting true user experience including:
- Network conditions (mobile vs broadband)
- Device performance (old phone vs new laptop)
- Geographic latency (users far from your servers)
- Browser/app rendering time (separate from server response time)

Key RUM metrics:
```
TTFB (Time to First Byte):
  Time from request sent to first byte received
  Measures: server processing + network latency
  Target: < 200ms for APIs, < 800ms for page loads

FCP (First Contentful Paint):
  Time until user sees first content (text, image)
  Measures: full round-trip + rendering
  Target: < 1.8s (Google "Good" threshold)

LCP (Largest Contentful Paint):
  Time until largest content element is visible
  Measures: critical rendering path performance
  Target: < 2.5s

CLS (Cumulative Layout Shift):
  How much page layout shifts during load
  Measures: visual stability
  Target: < 0.1

INP (Interaction to Next Paint):
  Delay from user interaction to visual response
  Measures: page interactivity
  Target: < 200ms
```

### Synthetic Monitoring — Testing Before Users Do

Synthetic tests run your own scripted user journeys 24/7 from multiple geographic locations.

**The four types of synthetic tests:**

```
1. Availability (Ping) Test:
   Frequency: every 1 minute
   Does: HTTP GET to /health endpoint
   Checks: status 200, response time < 2s
   Purpose: Detect complete outages within 1 minute

2. API Functional Test:
   Frequency: every 5 minutes
   Does: POST to /api/orders with test payload
   Checks: status 201, response body has order_id field
   Purpose: Detect partial failures (endpoint up but broken)

3. Full Journey Test (Browser):
   Frequency: every 15 minutes
   Does: Login → search → add to cart → checkout
   Checks: each step completes within threshold
   Purpose: Detect UX regressions, JS errors, auth issues

4. API Chain Test:
   Frequency: every 10 minutes
   Does: Create resource → read it back → verify data matches
   Checks: round-trip correctness
   Purpose: Detect data integrity issues
```

**Why test from 3+ external regions:**
```
Your internal monitoring sees:
  ✓ Pod responding → "Service healthy"

But users in Asia see:
  ✗ CDN misconfigured → 404 for static assets
  ✗ DNS propagation incomplete → old IP address
  ✗ Firewall rule blocks Pacific region

External synthetic tests from us-east-1 + eu-west-1 + ap-southeast-1
catch geography-specific failures your internal monitoring is blind to.
```

### Business Metric Monitoring (The Most Important Layer)

Business metrics reveal what users actually care about, independent of HTTP status codes:

```promql
# Orders completed per minute (revenue-generating actions)
sum(rate(orders_completed_total[5m]))

# Payment success rate (not just HTTP 200, but actually charged)
sum(rate(payments_confirmed_total[5m]))
/ sum(rate(payments_attempted_total[5m]))

# Search result click-through rate (are results relevant?)
sum(rate(search_result_clicks_total[5m]))
/ sum(rate(searches_total[5m]))

# User session creation rate (are users logging in successfully?)
sum(rate(sessions_created_total[5m]))

# Notification delivery rate (are messages reaching users?)
sum(rate(notifications_delivered_total[5m]))
/ sum(rate(notifications_sent_total[5m]))
```

Alert on RELATIVE drops (week-over-week), not absolute values:
```promql
# Alert: orders/min dropped > 20% vs same time last week
# This accounts for natural traffic patterns (low at 3am, high at noon)
- alert: OrderRateAnomalousDrop
  expr: |
    sum(rate(orders_completed_total[10m]))
    <
    0.80 * sum(rate(orders_completed_total[10m] offset 7d))
  for: 5m
  annotations:
    summary: "Order rate 20%+ below same time last week"
```

---

## Layer 3: Application Performance Monitoring (APM)

### Distributed Tracing — Following a Request Through Every Service

A trace shows the full path of a single request:
```
User Request: POST /api/checkout
  │
  ├─ [span] api-gateway:        3ms   (auth token validation)
  │
  ├─ [span] order-service:     45ms
  │    ├─ [span] validate-cart:  2ms
  │    ├─ [span] db-query:      38ms  ← SLOW (N+1 query problem)
  │    └─ [span] serialize:      5ms
  │
  ├─ [span] payment-service:  210ms
  │    ├─ [span] fraud-check:   15ms
  │    └─ [span] stripe-api:   195ms  ← EXTERNAL call (normal)
  │
  └─ [span] notification-svc:   8ms

Total: 266ms (p99 is 420ms due to occasional DB slowness)
```

Without tracing, you see "p99 = 420ms" on a dashboard. You don't know WHERE the 420ms goes.
With tracing, you see "DB query takes 38ms normally but 380ms at p99 — look at the DB."

### Key Application Metrics to Track

**JVM (Java applications):**
```promql
# Heap usage ratio (> 0.85 = GC pressure, > 0.95 = OOMKill imminent)
jvm_memory_used_bytes{area="heap"}
/ jvm_memory_max_bytes{area="heap"}

# GC pause time (long pauses = latency spikes for users)
rate(jvm_gc_pause_seconds_sum[5m])
/ rate(jvm_gc_pause_seconds_count[5m])
# Alert if > 200ms average GC pause

# GC frequency (if GC runs > 5x/sec, memory is under severe pressure)
rate(jvm_gc_pause_seconds_count[1m])

# Thread pool saturation (if active == max, requests are queueing)
jvm_threads_states_threads{state="runnable"}
# Compare against jvm_threads_states_threads{state="waiting"} — high waiting = blocked on I/O
```

**Database connection pools:**
```promql
# HikariCP (Java connection pool) saturation
hikaricp_connections_active{pool="main"}
/ hikaricp_connections_max{pool="main"}
# Alert if > 0.8 (80% — connections about to be exhausted)

# Connection wait time (how long threads wait for a DB connection)
rate(hikaricp_connections_timeout_total[5m])
# Any timeouts = connection pool too small or DB too slow

# pgBouncer (PostgreSQL connection pooler)
pgbouncer_pools_sv_active / (pgbouncer_pools_sv_active + pgbouncer_pools_sv_idle)
```

**HTTP client (outbound calls to other services):**
```promql
# Error rate on outbound calls (detect dependency failures)
sum(rate(http_client_requests_total{status=~"5.."}[5m])) by (target_host)
/ sum(rate(http_client_requests_total[5m])) by (target_host)

# Outbound call latency p99
histogram_quantile(0.99,
  sum(rate(http_client_request_duration_seconds_bucket[5m])) by (le, target_host)
)
```

---

## Layer 2: Container & Service Performance

### CPU Throttling — The Invisible Performance Killer

CPU throttling is one of the most misunderstood Kubernetes performance issues.

**How it works:**
```
CPU limit: 500m (0.5 CPU cores)
Pod actually needs: 600m at peak

Kubernetes mechanism:
  Each 100ms window: pod gets 50ms of CPU time (500m × 100ms = 50ms)
  If pod tries to use more than 50ms: it's THROTTLED (paused) for remaining window

Impact: Everything inside the container stops during throttle
        HTTP requests in-flight → delayed
        GC runs → delayed → heap pressure increases
        Result: Latency spikes exactly when traffic peaks (worst time)
```

**Detecting throttling:**
```promql
# Throttled time fraction (> 0.25 = 25% of CPU time is being throttled)
rate(container_cpu_throttled_seconds_total{container!=""}[5m])
/ rate(container_cpu_usage_seconds_total{container!=""}[5m])

# Alert: > 25% throttling for 5 minutes
- alert: HighCPUThrottling
  expr: |
    rate(container_cpu_throttled_seconds_total{container!=""}[5m])
    / rate(container_cpu_usage_seconds_total{container!=""}[5m]) > 0.25
  for: 5m
  labels:
    severity: warning
  annotations:
    summary: "{{ $labels.pod }} throttled >25% — CPU limit too low"
```

**Fix options:**
1. Increase CPU limit (quick fix, higher cost)
2. Profile the application to reduce CPU usage
3. Increase HPA target replicas (distribute load over more pods)

### Memory and OOMKill Prevention

```promql
# Working set as fraction of limit (> 0.85 = OOMKill risk)
container_memory_working_set_bytes{container!=""}
/ container_spec_memory_limit_bytes{container!=""}

# Alert: memory > 85% of limit
- alert: HighMemoryPressure
  expr: |
    container_memory_working_set_bytes{container!=""}
    / container_spec_memory_limit_bytes{container!=""}
    > 0.85
  for: 10m
  labels:
    severity: warning
  annotations:
    summary: "{{ $labels.pod }} memory at {{ $value | humanizePercentage }} of limit"

# Memory trend (is it growing? = memory leak)
# Week-over-week memory ratio > 1.2 = 20% growth in 7 days
container_memory_working_set_bytes{container!=""}
/ container_memory_working_set_bytes{container!=""} offset 7d
```

---

## Layer 1: Infrastructure Performance

### Disk — The Most Common Proactive Win

`predict_linear` is the most valuable proactive PromQL function for disk:

```promql
# Will this disk be full in < 24 hours based on the last 6 hours of trend?
predict_linear(node_filesystem_avail_bytes{mountpoint="/"}[6h], 24 * 3600) < 0

# Will this disk be full in < 4 hours? (urgent)
predict_linear(node_filesystem_avail_bytes{mountpoint="/"}[6h], 4 * 3600) < 0

# Alert rules
- alert: DiskWillFillIn24Hours
  expr: predict_linear(node_filesystem_avail_bytes{mountpoint="/"}[6h], 24*3600) < 0
  for: 30m
  labels:
    severity: warning
  annotations:
    summary: "Disk on {{ $labels.instance }} predicted full in < 24h"

- alert: DiskWillFillIn4Hours
  expr: predict_linear(node_filesystem_avail_bytes{mountpoint="/"}[6h], 4*3600) < 0
  for: 10m
  labels:
    severity: critical
  annotations:
    summary: "URGENT: Disk on {{ $labels.instance }} predicted full in < 4h"
```

Why this is better than threshold-based:
```
Threshold approach: "Alert when disk > 85%"
  Problem: At 2GB/hour write rate, 85% → 100% in 2 hours
           Alert fires at 85% → not enough time to act

predict_linear approach: "Alert when disk will be full in < 24 hours"
  Fire at 60% if growth rate is fast → plenty of time to act
  Don't fire at 90% if disk is static → no false alarm
```

### Network — Detecting Packet Loss and Retransmits

```promql
# Network error rate (hardware-level errors)
rate(node_network_receive_errs_total[5m])
+ rate(node_network_transmit_errs_total[5m])

# TCP retransmit rate (soft indicator of packet loss)
rate(node_netstat_Tcp_RetransSegs[5m])
/ rate(node_netstat_Tcp_OutSegs[5m])
# Alert if > 0.01 (1% retransmit rate)

# Network bandwidth saturation
rate(node_network_receive_bytes_total{device!~"lo"}[5m]) * 8
# Compare against NIC capacity (e.g., 10Gbps = 10e9 bits/sec)
```

---

## Capacity Planning With Trend Alerts

### The Four Resources to Trend

```
1. Disk space
   predict_linear(node_filesystem_avail_bytes[6h], N) < 0

2. Memory growth (memory leaks)
   container_memory_working_set_bytes
   / container_memory_working_set_bytes offset 7d
   # Alert if ratio > 1.3 (30% week-over-week growth)

3. CPU headroom
   avg(rate(container_cpu_usage_seconds_total[5m])) by (pod)
   / avg(container_spec_cpu_quota / container_spec_cpu_period) by (pod)
   # Alert if > 0.8 (80% of limit) for 30+ minutes

4. DB connections
   pg_stat_activity_count
   / pg_settings_max_connections
   # Alert if > 0.8 (80% of max_connections)
```

### Capacity Planning Dashboard Layout

```
Row 1: Growth rate sparklines
  - Disk growth rate (GB/day)
  - Memory growth rate (MB/day per pod)
  - Request rate trend (RPS week-over-week)

Row 2: Time-to-exhaustion
  - Disk: hours until full (predict_linear result)
  - DB connections: % of max
  - Pod CPU: % of limit

Row 3: Scaling indicators
  - HPA current vs max replicas
  - Node capacity: total pods / max pods per node
  - PVC usage across all volumes

Row 4: Cost/efficiency
  - CPU request vs actual usage (right-sizing opportunity)
  - Memory request vs actual usage
  - Idle node count
```
