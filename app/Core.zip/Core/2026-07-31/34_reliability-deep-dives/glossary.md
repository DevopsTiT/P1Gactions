# Glossary: Reliability, Availability & Performance — Deep Dives

Every term from all 6 parts explained for an SRE beginner.

---

## Part 1 — Reliability Foundations

**Availability**
The fraction of time a system responds successfully to requests. Formula: successful requests / total requests. A system can be available (responding) but not reliable (correct answers). Both must be monitored separately.

**Reliability**
The system does what it promises, consistently. A service returning HTTP 200 with wrong data is available but not reliable. Reliability is measured through business metrics and content validation, not just HTTP status codes.

**Performance**
The system responds fast enough to be useful. Slow IS a failure. Users abandon requests after 2–3 seconds. Measured with latency percentiles (p50, p95, p99), never with averages.

**Percentile (p50, p95, p99)**
A statistical measure of latency. p99 = 99% of requests were faster than this value. p99 is the most important: it represents the worst 1% of users. Average latency hides this tail completely.

**Error Budget**
The amount of failure allowed per SLO period. For 99.9% SLO over 30 days = 43.2 minutes of allowed downtime. When it runs out, deployments freeze until reliability is restored.

**Level 1–5 Reliability Hierarchy**
Five levels of reliability maturity: Level 1 = basic availability, Level 2 = functional correctness, Level 3 = performance SLOs, Level 4 = dependency reliability, Level 5 = resilience under failure. Must be built bottom-up.

**Latency Budget**
The total time allowed for a user-facing operation (e.g., 500ms) broken into allocations per component (DNS, gateway, service, DB). Helps SRE identify which component is eating the budget.

**SRE Contract**
The agreement between SRE and development teams: when the error budget is healthy, development moves fast; when it's burning, reliability work takes priority. The budget is the arbiter, not individual opinions.

---

## Part 2 — SLOs, SLIs, SLAs

**SLI (Service Level Indicator)**
The actual metric you measure to assess reliability. Must directly reflect user experience: error rate, p99 latency, % jobs completing on time. CPU usage is NOT a good SLI (users don't feel CPU directly).

**SLO (Service Level Objective)**
Your internal reliability target: "Error rate < 0.1%." The goal you commit to internally. Should be set slightly below your actual baseline to give headroom for maintenance.

**SLA (Service Level Agreement)**
A legal contract with customers: "We guarantee 99.9% or you get a refund." Must always be LOOSER than your internal SLO. The gap gives you time to fix issues before breaching the SLA.

**Availability SLI**
The fraction of requests that succeed. Formula: good_requests / total_requests. "Good" means HTTP 2xx/3xx, responds within timeout.

**Latency SLI**
The fraction of requests completing within a threshold. "What % of requests completed in < 500ms?" Produces a 0–1 ratio usable in SLO calculations.

**Freshness SLI**
For data pipelines and batch jobs: how recently was data last successfully updated? Formula: time_since_last_success < threshold.

**Correctness SLI**
For batch processing: the fraction of outputs that are correct. Used when response body content matters, not just status code.

**Burn Rate**
How fast you're consuming error budget relative to the allowed rate. Burn rate 14.4x means you'll exhaust a monthly budget in ~2 days. The critical alert threshold.

**Multi-window Alerting**
Using two time windows simultaneously to confirm a burn rate is real (e.g., 1h + 5m must BOTH exceed threshold). Prevents false positives from short spikes while still catching sustained problems.

**Rolling Window**
Measuring SLO compliance over the last 30 days continuously, not per calendar month. Recommended because it doesn't create incentives to take risks at the start of a month.

**Recording Rule (Prometheus)**
A pre-computed Prometheus metric derived from a more complex query. Stored as a new metric. Used to make alert expressions simpler and evaluation faster.

**Error Budget Policy**
A written document defining what engineering teams must do at each budget level: full velocity when healthy, freeze deployments when exhausted. Only works if actually enforced.

---

## Part 3 — Proactive Performance Monitoring

**Proactive Monitoring**
Watching for trends and early warning signals to catch problems before users notice. Opposite of reactive monitoring (users report it first).

**predict_linear()**
A Prometheus function that uses linear regression to predict where a metric will be in N seconds, based on recent trend. Used to alert "disk will be full in 4 hours" before it actually fills.

**RUM (Real User Monitoring)**
Telemetry collected from actual browsers/apps, reflecting true end-user experience including their network speed, device performance, and geographic latency. Tools: Dynatrace, DataDog, New Relic.

**Synthetic Monitoring**
Automated tests that simulate user behavior on a schedule from external locations. Run 24/7 even when real traffic is low. Detect failures before real users do. Best run from 3+ regions to catch geographic issues.

**TTFB (Time to First Byte)**
Time from when a browser sends a request to when it receives the first byte of the response. Measures server processing + network latency. Target: < 200ms for APIs.

**LCP (Largest Contentful Paint)**
Time until the largest visible content element (image, heading) is rendered in a browser. Google Core Web Vital. Target: < 2.5 seconds. Relevant for web frontend monitoring.

**CLS (Cumulative Layout Shift)**
How much page content moves around during loading. High CLS = buttons jumping around while loading. Google Core Web Vital. Target: < 0.1.

**Business Metric Monitoring**
Tracking user-facing outcomes (orders/min, payments/min, logins/min) instead of just HTTP codes. If HTTP is fine but orders drop, something is wrong. The highest-value monitoring layer.

**APM (Application Performance Monitoring)**
Monitoring inside the application code — which functions are slow, which queries take time, which dependencies are called. Tools: Dynatrace, Jaeger, New Relic. Requires instrumentation in your code.

**Distributed Tracing**
Recording the path of a single request through all services as a tree of "spans." Shows exactly where time is spent (API gateway: 3ms, order service: 45ms, DB query: 380ms). Essential for microservices.

**Span**
One unit of work within a distributed trace. A span has a name, start time, duration, and status. Spans are nested — a parent span contains child spans (e.g., the "checkout" span contains "validate-cart", "charge-payment", etc.).

**CPU Throttling**
When a Kubernetes container exceeds its CPU limit, the OS pauses it until the next time window. Results in latency spikes that correlate with traffic peaks. Detected via `container_cpu_throttled_seconds_total`.

**Working Set Memory**
The memory a container is actually using (excludes OS-managed page cache that can be evicted). `container_memory_working_set_bytes` is the correct metric for OOMKill risk, not `container_memory_usage_bytes`.

**OOMKill**
"Out of Memory Kill" — Kubernetes kills a container because it exceeded its memory limit. Prevents one container from consuming all node memory. Detected in events as `OOMKilling`. Fix: increase limit or fix memory leak.

**HikariCP**
The default Java database connection pool (used in Spring Boot). Manages a fixed number of DB connections shared across threads. If all connections are in use, threads wait. Saturation > 80% = risk.

**N+1 Query Problem**
A performance bug where code executes 1 query to get a list, then 1 more query per item in the list. For 100 items: 101 queries instead of 1. Detectable only with APM tracing. A common source of DB latency regressions.

**Capacity Planning**
Predicting future resource needs before running out. Uses historical growth trends (disk, memory, connections) to schedule upgrades proactively.

**VPA (Vertical Pod Autoscaler)**
A Kubernetes component that recommends or automatically adjusts CPU and memory requests/limits for pods based on actual usage patterns. Prevents OOMKills from under-provisioned limits.

---

## Part 4 — Proactive Reliability Practices

**Change Management**
The processes around controlling production changes to minimize incidents. Industry data: 80% of incidents are caused by recent changes. Change management is the highest-leverage reliability practice.

**Blast Radius**
The number of users, services, or systems affected if a change or failure occurs. Small blast radius = only 5% of pods; large blast radius = payment system for all users. Good reliability engineering limits blast radius.

**Canary Deployment**
Releasing a new version to a small fraction of traffic (e.g., 5%) before rolling out to everyone. If the canary behaves worse, it's rolled back with minimal user impact.

**Argo Rollouts**
A Kubernetes controller that provides advanced deployment strategies: canary, blue/green, progressive delivery. Can automatically rollback based on Prometheus metrics.

**Analysis Template (Argo)**
A reusable Prometheus query definition used by Argo Rollouts to decide whether a canary is healthy. If the query fails (e.g., error rate > 1%), the rollout automatically rolls back.

**Circuit Breaker**
A reliability pattern that stops sending requests to a failing downstream service after N consecutive failures. Fails fast instead of waiting for a timeout. Prevents cascade failures.

**Cascade Failure**
When one service failure causes dependent services to fail, which cause their dependents to fail, until the entire system is down. Circuit breakers and timeouts prevent cascade failures.

**CLOSED state (circuit breaker)**
Normal operating state — requests pass through to downstream service. Counter tracking failure rate.

**OPEN state (circuit breaker)**
Failing-fast state — all requests immediately rejected without contacting downstream. Entered after failure threshold exceeded.

**HALF-OPEN state (circuit breaker)**
Recovery-testing state — allows a small number of probe requests through to check if downstream recovered. Returns to CLOSED if probes succeed; back to OPEN if they fail.

**Resilience4j**
A Java library implementing circuit breakers, retry, rate limiting, and bulkhead patterns. The standard library for Java microservices resilience.

**Liveness Probe**
Kubernetes health check that answers: "Is this process alive and not deadlocked?" Failure → container killed and restarted. Should NEVER check database connections — only check if the process is responsive.

**Readiness Probe**
Kubernetes health check that answers: "Is this container ready to receive traffic?" Failure → removed from load balancer (not killed). Should check all required dependencies (DB, cache, config).

**Startup Probe**
Kubernetes health check that runs only during container startup. Prevents slow-starting apps (Java, ML models) from being killed by liveness probe before they finish initializing.

**`failureThreshold`**
How many consecutive probe failures before Kubernetes acts. Prevents a single transient failure from triggering a restart or removal from load balancer.

**503 Service Unavailable**
HTTP response code meaning the server cannot handle the request right now. Kubernetes readiness probe failure causes the pod to stop serving traffic but does NOT cause a 503 — the load balancer routes around the unready pod.

**Graceful Degradation**
When a service loses a non-critical dependency, it continues with reduced functionality instead of failing completely. Example: Redis down → serve from DB (slower, not broken).

**Fallback**
The alternative behavior a service uses when its primary path fails. A circuit breaker's fallback might return cached data, a default response, or a user-friendly error.

**Dependency Map**
A documented inventory of every service, database, and external system your service depends on. Essential for incident triage: "Is this my problem or my dependency's problem?"

---

## Part 5 — Incident Response

**SEV (Severity) Level**
A classification of how serious an incident is. SEV1 = complete outage, all users affected, revenue impacted. SEV4 = low impact, next-business-day response. Determines who gets paged and how fast.

**Incident Commander (IC)**
The single person in charge during an incident. Does NOT fix the problem — assigns tasks, makes decisions, controls communication cadence. The most important role in fast incident resolution.

**Subject Matter Expert (SME)**
The engineer who knows the broken system deeply. Assigned specific investigation tasks by the IC. Reports findings to IC; does not make mitigation decisions unilaterally.

**Communications Lead**
The person responsible for keeping stakeholders (executives, customers) informed during an incident. Separate from technical responders so they can focus on fixing, not explaining.

**Scribe**
Records every action taken during an incident with timestamps. Produces the raw material for the post-mortem timeline. Used in SEV1 incidents.

**MTTA (Mean Time to Acknowledge)**
Average time from alert firing to on-call acknowledging. Measures on-call responsiveness. Target: < 5 minutes for SEV1/2.

**MTTR (Mean Time to Resolve)**
Average time from incident start to full resolution. Measures effectiveness of incident response process + runbooks. Improving MTTR is a core SRE goal.

**War Room**
A dedicated Slack channel (or virtual space) opened for a specific incident where all response activity is centralized. Naming convention: #incident-YYYY-MM-DD-service-description.

**Blast Radius (incident)**
How many users are affected by the incident. Determines severity level. "All users on payment" = higher blast radius than "one customer's admin dashboard."

**Mitigation**
Stopping user pain, regardless of whether root cause is known. A rollback is mitigation. Root cause investigation happens AFTER mitigation is complete.

**Rollback**
Reverting a service to a previous known-good version. `kubectl rollout undo deployment/my-service` is the most common rollback in Kubernetes. Always faster and safer than deploying a fix.

**Status Page**
A public-facing page that reports service health. Updated during incidents to keep customers informed. Separate from internal Grafana dashboards. Examples: Atlassian Status Page, Statuspage.io.

**PagerDuty**
Incident management platform that receives alerts, manages on-call schedules, escalation policies, and incident records.

**Escalation Policy**
Defines who gets paged if the primary on-call doesn't acknowledge within N minutes. Ensures no alert is silently ignored.

**Triage**
The process of quickly assessing an incident to determine: what is broken, who is affected, when it started, and whether it's getting worse. Done in the first 10–20 minutes.

**Alert Fatigue**
When on-call engineers receive so many noisy or false-positive alerts that they start ignoring pages. The most dangerous monitoring failure mode.

---

## Part 6 — Post-Incident and Toil

**Blameless Post-Mortem**
An incident review that focuses on system failures, not individual mistakes. "What conditions allowed this to happen?" not "Who made this mistake?" Required for psychological safety and honest root cause analysis.

**Counterfactual Test**
During a post-mortem, for each human action ask: "Would a reasonable, competent engineer have done the same?" If yes → system failure. If no → human failure (rare in honest post-mortems).

**5 Whys**
A root cause analysis technique: for any problem, ask "Why did this happen?" five times. Each answer becomes the input to the next "why." Surfaces the underlying system failure, not just the surface symptom.

**Contributing Factor**
A condition that made an incident possible or worse, without being the single root cause. Complex incidents have multiple contributing factors. Fixing only one often doesn't prevent recurrence.

**Timeline (post-mortem)**
The chronological record of every action taken during an incident with timestamps. Used to understand the sequence of events, find delays, and identify improvement opportunities.

**Action Item**
A specific, measurable task from a post-mortem with an owner and due date. Must have all four: action, type (prevention/detection/mitigation/process), owner, due date. Without all four, it won't get done.

**Toil**
Manual, repetitive, automatable operational work that scales with service load. Google SRE target: < 50% of time on toil. > 50% is unsustainable and blocks reliability improvements.

**Toil Elimination**
Converting repetitive manual operations into automated or self-healing systems. The highest-leverage investment for improving SRE team capacity.

**Monthly Reliability Review**
A recurring team meeting to review SLO status, incident trends, alert quality, toil metrics, and post-mortem action item progress. The mechanism for continuous reliability improvement.

**False Positive (alert)**
An alert that fires when there is no real user-facing problem. If > 5% of alerts are false positives, trust in the alerting system degrades. Must be tuned or removed aggressively.

**Error Budget Policy**
The written agreement between SRE and development teams defining what happens at each budget level. Only effective if actually enforced through tooling (CI gates, deployment approval requirements).

**Reliability Sprint**
A sprint (or period) where engineering teams focus entirely on reliability work: fixing post-mortem action items, reducing toil, improving test coverage. Triggered when error budget is exhausted.
