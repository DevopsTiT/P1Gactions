# Part 1 Deep Dive — Reliability Foundations: What Does "Reliable" Actually Mean?

---

## Why This Part Matters

Before you write a single alert, deploy a single monitor, or create a single runbook, you need to answer one question:

> "What are we actually trying to protect?"

Most SRE teams jump straight to dashboards and alerts without agreeing on what "working correctly" means. The result: alerts that fire for the wrong reasons, dashboards that look healthy while users suffer, and incidents that recur because nobody agreed on the standard.

This part builds the foundation everything else rests on.

---

## The Three Pillars — Why All Three Must Be True Simultaneously

### Pillar 1: Availability

**Definition:** The system is reachable and responds to requests.

**Measured as:**
```
availability = successful_requests / total_requests

Example:
  total requests in last hour: 100,000
  failed requests (5xx, timeout, connection refused): 50
  availability = 99,950 / 100,000 = 99.95%
```

**Common failure modes that break availability:**
- Pod crash-looping (process dies, Kubernetes restarts it, dies again)
- Node failure (underlying VM goes down)
- Network partition (pods can't reach each other)
- DNS failure (service discovery breaks)
- Load balancer misconfiguration (traffic can't reach pods)
- Certificate expiry (HTTPS connections rejected)

**How to observe it:**
```promql
# Availability over 5-minute window
1 - (
  sum(rate(http_requests_total{status=~"5.."}[5m]))
  /
  sum(rate(http_requests_total[5m]))
)
```

**The trap:** Availability metrics lie if your probes are too lenient.
- If `/health/live` just returns 200 without checking anything real, your availability shows 100% while users get errors from the real endpoints.
- Always measure availability from the USER's perspective (real traffic), not just health check traffic.

---

### Pillar 2: Reliability

**Definition:** The system does what it promises, consistently and correctly.

**Why it's different from availability:**
- A system is AVAILABLE if it responds
- A system is RELIABLE if it responds CORRECTLY

**Real example:**
```
Scenario: Payment service returns HTTP 200 to every request
          but silently discards 5% of payment confirmations

Availability: 100% (always responds)
Reliability:  95% (5% of responses are wrong — user pays but gets no confirmation)

From a monitoring perspective: alerts show green. Users are furious.
```

**Measured as:**
```
reliability = correct_responses / total_responses

What "correct" means depends on the service:
  - API: status code 200 + response body matches schema
  - Batch job: output data matches expected format + record count
  - Search: results contain expected items
  - Payment: transaction committed in DB + confirmation returned
```

**How to observe it:**
- Synthetic transactions that verify response CONTENT, not just status code
- Assertion-based health checks: `response.body.status == "ok" AND response.body.items.length > 0`
- Data quality checks on batch outputs
- Business metric monitoring: "number of successful orders per minute" (drops even if HTTP is fine)

**The business metric layer:**
```promql
# Orders per minute (if this drops without a traffic drop, reliability issue)
sum(rate(orders_completed_total[5m]))

# Payment confirmation rate (should be near 1.0)
sum(rate(payments_confirmed_total[5m]))
/
sum(rate(payments_initiated_total[5m]))
```

---

### Pillar 3: Performance

**Definition:** The system responds fast enough to be useful.

**Why it's separate from availability and reliability:**
- A system can respond correctly but take 30 seconds per request
- Users abandon requests after 2-3 seconds
- "Slow" IS a failure mode from the user's perspective

**The percentile imperative:**
```
NEVER monitor average latency. Here's why:

Request latencies (ms): 10, 12, 11, 13, 9, 10, 12, 11, 8000, 10

Average = (10+12+11+13+9+10+12+11+8000+10) / 10 = 890ms

But 9 out of 10 users got < 15ms responses.
One user got 8 seconds.

Average = 890ms → suggests "things are slow for everyone" → WRONG
p99 = 8000ms → "1% of users wait 8 seconds" → CORRECT
p50 = 11ms   → "typical user gets 11ms" → ALSO CORRECT

Monitor: p50 (typical experience), p95 (most users), p99 (worst 1%)
Never monitor: average
```

**Performance measured correctly:**
```promql
# p50, p95, p99 latency simultaneously
histogram_quantile(0.50, sum(rate(http_request_duration_seconds_bucket[5m])) by (le))
histogram_quantile(0.95, sum(rate(http_request_duration_seconds_bucket[5m])) by (le))
histogram_quantile(0.99, sum(rate(http_request_duration_seconds_bucket[5m])) by (le))
```

**The latency budget concept:**
```
User action: "Search for a product"

End-to-end budget: 500ms total (before user perceives slowness)

Breakdown:
  DNS resolution:          5ms
  TLS handshake:          20ms
  Load balancer:           2ms
  API Gateway:            10ms
  Search service:        200ms  ← your service
  Database query:        100ms  ← depends on DB team
  Cache lookup:           10ms
  Response serialization: 15ms
  Network return:         20ms
  ──────────────────────────────
  Total:                 382ms  (118ms headroom)

If DB query grows to 300ms, total = 582ms → user notices
SRE must monitor EACH hop's latency, not just the final total
```

---

## The Five-Level Reliability Hierarchy — Build Bottom-Up

### Why the Order Matters

You cannot have Level 5 without Level 1. This sounds obvious, but teams regularly try to add circuit breakers or chaos engineering (Level 5) to services that don't have readiness probes (Level 1). The result is sophisticated failure on a broken foundation.

```
Level 5: Resilience Under Failure          ← advanced reliability engineering
Level 4: Dependency Reliability            ← external health monitoring
Level 3: Performance SLOs                 ← latency targets met
Level 2: Functional Correctness           ← right answers, not just responses
Level 1: Basic Availability               ← is it running and reachable?
```

### Level 1 — Basic Availability

What you need:
- Health check endpoint returning 200 when alive
- Kubernetes liveness + readiness probes configured
- Alerting on pod crash loops and pod count < desired count
- Uptime monitoring from outside the cluster

Prometheus alerts to have at Level 1:
```yaml
# Pod not running (basic availability)
- alert: PodNotRunning
  expr: kube_pod_status_phase{phase!~"Running|Succeeded"} == 1
  for: 5m
  labels:
    severity: warning

# Pod crash looping
- alert: PodCrashLooping
  expr: rate(kube_pod_container_status_restarts_total[15m]) > 0
  for: 5m
  labels:
    severity: critical

# Deployment has fewer replicas than desired
- alert: DeploymentReplicasMismatch
  expr: kube_deployment_spec_replicas != kube_deployment_status_available_replicas
  for: 5m
  labels:
    severity: warning
```

### Level 2 — Functional Correctness

What you need:
- Synthetic tests that validate response body content
- Business metric monitoring (orders, logins, searches per minute)
- Data pipeline output validation
- Schema validation on API responses

Example business metric alert:
```yaml
# Orders dropped > 20% vs 7-day average — reliability issue, not traffic issue
- alert: OrderRateAnomalyDrop
  expr: |
    sum(rate(orders_completed_total[10m]))
    < 0.8 * sum(rate(orders_completed_total[10m] offset 7d))
  for: 5m
  labels:
    severity: critical
  annotations:
    summary: "Order completion rate dropped 20%+ vs same time last week"
```

### Level 3 — Performance SLOs

What you need:
- Histogram metrics for all user-facing operations
- p99 latency alerts per critical endpoint
- SLO burn rate alerts (see Part 2 for full detail)

### Level 4 — Dependency Reliability

What you need:
- Dashboard showing health of every downstream service
- Alerts when dependency latency or error rate spikes
- Defined fallback behavior for each dependency

Example dependency tracking:
```yaml
# Downstream service latency exceeds SLO
- alert: DependencyHighLatency
  expr: |
    histogram_quantile(0.99,
      sum(rate(http_client_request_duration_seconds_bucket{target_service="payment-api"}[5m])) by (le)
    ) > 1.0
  for: 3m
  labels:
    severity: warning
  annotations:
    summary: "Payment API p99 latency > 1s — my-service may degrade"
```

### Level 5 — Resilience Under Failure

What you need:
- Circuit breakers on all external HTTP calls
- Retry logic with exponential backoff + jitter
- Timeout on every external call (never infinite wait)
- Graceful degradation paths tested in staging
- Chaos engineering validation (kill pods in staging, verify behavior)

Timeout + retry + circuit breaker pattern:
```
External call configuration:
  timeout:         500ms     (never wait more than this per attempt)
  retries:         2         (total 3 attempts)
  backoff:         100ms, 200ms (exponential, with jitter)
  circuit_breaker:
    threshold:     5 failures in 10s
    open_duration: 30s       (don't try for 30s after tripping)
    half_open:     1 probe   (send 1 request to test recovery)
```

---

## The SRE Contract with the Business — The Full Mental Model

### The Tension

```
Engineering (Product/Dev) wants:
  ✓ New features shipped fast
  ✓ Experiments and A/B tests
  ✓ Frequent deployments
  ✓ Architectural changes
  ✓ High velocity

Operations / SRE wants:
  ✓ Stability
  ✓ Predictable behavior
  ✓ Low change risk
  ✓ Time to fix technical debt
  ✓ Reliability for users
```

Traditional ops resolves this by slowing everything down. SRE resolves it with error budgets.

### How Error Budgets Resolve the Tension

```
Step 1: Agree on an SLO.
  "Our payment service will have < 0.1% error rate per 30-day window."

Step 2: Calculate the error budget.
  0.1% of all requests in 30 days = the budget
  If you handle 10M requests/month, budget = 10,000 failed requests

Step 3: Track budget consumption in real time.
  Current period: 6,200 failed requests consumed of 10,000 budget
  Budget remaining: 3,800 requests (38%)
  Days remaining: 15 of 30

Step 4: Apply the policy:
  38% budget remaining → Full velocity (dev can deploy, experiment, take risks)
  Budget drops to 15% → Caution mode (canary all deploys, no risky changes)
  Budget drops to 5%  → Freeze mode (only bug fixes, no features)
  Budget exhausted     → Full stop (SRE can veto all releases)

Result:
  When reliability is good → dev moves fast (everyone happy)
  When reliability is bad  → dev slows down to fix it (both teams aligned)
  SRE isn't the "no" team — the budget is
```

### Why This Is Better Than "Reliability vs Features"

The old model: SRE says "no deploy" → Dev says "you're blocking us" → Political conflict.

The budget model: The budget says "no deploy" → Both teams look at the data → Shared decision.

SRE's job is to:
1. Define and measure SLIs accurately
2. Set SLOs at the right level (not too tight, not too loose)
3. Build the tooling that tracks budget in real time
4. Enforce the error budget policy consistently

---

## What "Five Nines" Actually Means (The Number Behind the SLO)

This table is memorized by every SRE:

```
SLO Target   | Monthly Downtime | Weekly Downtime | Daily Downtime
─────────────────────────────────────────────────────────────────
99%          | 7h 18m           | 1h 41m          | 14m 24s
99.5%        | 3h 39m           | 50m 24s         | 7m 12s
99.9%        | 43m 49s          | 10m 4s          | 1m 26s
99.95%       | 21m 54s          | 5m 2s           | 43s
99.99%       | 4m 22s           | 1m 0s           | 8.6s
99.999%      | 26s              | 6s              | 864ms
```

Key insight: The jump from 99.9% to 99.99% is NOT a 0.09% improvement — it's a 10x harder requirement. Going from 43 minutes/month allowed downtime to 4 minutes requires fundamentally different architecture (no single points of failure, automated failover, zero-downtime deploys).

Set your SLO at the level you can actually achieve with your current architecture, then improve the architecture to allow tighter SLOs over time.

---

## Common Mistakes at the Foundation Level

### Mistake 1: Setting SLOs at 100%

```
100% SLO = 0 error budget = any single error triggers an incident
Result:
  - Every noisy alert pages someone
  - Developers can never deploy
  - On-call burns out from constant false alarms
  - Team stops trusting alerts

Fix: Set SLO based on what you actually deliver. Measure first, then set target.
```

### Mistake 2: Measuring from the Wrong Perspective

```
Wrong: Measuring availability at the load balancer
  "Load balancer returned 200 → service is available"
  Reality: Load balancer returned 200 but the response body was an error page

Wrong: Measuring from inside the cluster only
  "Internal health check passes → service is available"
  Reality: Firewall rule broken, external users can't connect

Right: Measure from the user's perspective
  - Synthetic test from outside the cluster
  - Real user traffic error rates
  - Business metric rates (not just HTTP codes)
```

### Mistake 3: Conflating the Three Pillars

```
Alert fires: "High error rate"
SRE investigates: HTTP 200 responses look fine
Conclusion: "Alert is wrong"

Reality: Payment confirmations silently failing (reliability issue)
         HTTP status fine; response body content broken
         Wrong pillar was being monitored

Fix: Separate dashboards and alerts for:
  - Availability: HTTP success rate
  - Reliability: Business metric rate (orders, payments, searches)
  - Performance: Latency percentiles
```
