# Part 5 Deep Dive — Incident Response: The Full Lifecycle

---

## The Fundamental Principle: Incidents Are Normal

In complex systems, incidents are inevitable. The goal is not zero incidents — it's:
1. Detect fast (minutes, not hours)
2. Mitigate fast (stop user pain, don't wait for root cause)
3. Communicate clearly (stakeholders always know what's happening)
4. Learn deeply (each incident makes the system more reliable)

A team that has incidents and closes the loop well is more reliable than a team that has fewer incidents but doesn't learn from them.

---

## Incident Severity Levels — The Full Definition

### Why Severity Levels Matter

Severity determines:
- Who gets paged (on-call only, or also their manager, or the VP)
- How fast they must respond (5 minutes vs 1 hour)
- Who else gets involved (just SRE, or also Comms, Legal, Executives)
- Whether to skip normal processes (can you deploy a hotfix without a PR review?)

Without defined severity levels, every alert feels equally urgent — which means nothing is urgent.

### Severity Level Definitions (Complete)

```
SEV 1 — Critical (All-Hands)
  Definition: Production completely down, ALL users affected, revenue impacted
  
  Criteria (any one triggers SEV1):
    - Error rate > 50% for > 5 minutes
    - Core service (auth, payment, checkout) completely unavailable
    - Data loss confirmed or suspected
    - Security breach confirmed or suspected
    - SLA breach in progress for a major customer

  Response time:    Acknowledge within 5 minutes, 24/7
  Who is paged:     On-call SRE + Engineering Manager + VP Engineering
  Communication:    Status page updated, customer communication prepared
  Bridge:           Incident war-room channel opened immediately
  Authority:        IC can approve emergency deploys without PR review
  Post-mortem:      Mandatory, within 24 hours

SEV 2 — Major
  Definition: Significant degradation, significant % of users affected, revenue at risk
  
  Criteria (any one triggers SEV2):
    - Error rate 10–50%
    - Core service degraded (slow but partially functional)
    - Single major customer completely blocked
    - SLO burn rate in critical zone (>14.4x)
    - Data pipeline delayed > 1 hour affecting business decisions

  Response time:    Acknowledge within 15 minutes, 24/7
  Who is paged:     On-call SRE (escalate to manager if not resolved in 30 min)
  Communication:    Internal Slack update every 15 minutes
  Bridge:           Incident channel opened
  Post-mortem:      Mandatory, within 48 hours

SEV 3 — Minor
  Definition: Partial degradation, limited user impact, workaround available
  
  Criteria:
    - Error rate 1–10%
    - Non-critical feature broken
    - Single geographic region degraded
    - Performance degraded but within 5x of normal

  Response time:    Acknowledge within 1 hour during business hours
  Who is paged:     On-call SRE (Slack DM, not phone call)
  Communication:    Slack notification in team channel
  Post-mortem:      Optional (encouraged for recurring SEV3)

SEV 4 — Low
  Definition: Cosmetic, low-impact, no user-facing degradation
  
  Criteria:
    - Log pipeline delayed
    - Non-critical batch job failed
    - Dashboard broken (metrics still collected, just not displayed)
    - Alert firing but confirmed to be false positive

  Response time:    Next business day
  Who is notified:  Slack message in team channel (no page)
  Post-mortem:      Not required
```

---

## The Incident Response Workflow — Every Step In Detail

### Phase 1: Detection (T+0 to T+5 min)

The fastest and most reliable detection chain:

```
[Automated alert] → [PagerDuty] → [On-call phone call/SMS] → [Acknowledge]

Backup chain (if primary fails):
  [User report] → [#incidents Slack] → [On-call is pinged]

NEVER rely solely on user reports. If users are telling you something is broken,
you've already lost 15-30 minutes of detection time.
```

**On-call best practices:**
- PagerDuty configured to call your phone, not just notify the app
- If you don't acknowledge in 5 minutes → escalate to secondary on-call
- If secondary doesn't acknowledge in 5 more minutes → escalate to manager
- Keep your phone charged and audible during on-call shifts

**At detection, answer three questions immediately:**
```
1. Is this a real incident or a false positive?
   - Check the dashboard for the service
   - If one alert fired but everything looks fine → false positive, silence
   - If metrics confirm user impact → proceed

2. What is the blast radius?
   - All users? One region? One customer? One feature?
   - Determines severity immediately

3. Has there been a recent change?
   - Check: kubectl rollout history, git log, Terraform plan history
   - Recent change → strong candidate for cause → rollback path ready
```

### Phase 2: Assemble (T+5 to T+10 min)

**Open the incident channel immediately:**
```
Channel naming: #incident-YYYY-MM-DD-service-brief-description
Example: #incident-2026-07-31-payment-high-error-rate

First message in channel (template):
  🚨 [SEV2 INCIDENT OPEN] payment-service elevated error rate
  
  Status: INVESTIGATING
  Impact: ~20% of payment requests failing since 14:32 UTC
  Last change: payment-service v3.2.1 deployed at 14:20 UTC
  
  IC: @alice
  Comms: @bob  
  SME (payment): @charlie
  
  Updates every 10 minutes.
  All response activity in this channel.
```

**Assign roles explicitly:**
```
Incident Commander (IC):
  - ONLY ONE PERSON holds this role
  - Does NOT debug the problem
  - Assigns investigation tasks
  - Makes decisions on mitigation strategy
  - Calls for escalation
  - Controls the update cadence

Subject Matter Expert (SME):
  - The person who knows the code/system
  - Assigned specific investigation tasks by IC
  - Reports findings to IC; does NOT make mitigation decisions

Communications Lead:
  - Writes all external and executive updates
  - Keeps non-technical stakeholders informed
  - Does NOT participate in technical investigation

Scribe (optional for SEV1):
  - Records timeline of every action taken with timestamps
  - Does NOT investigate
  - Produces the raw material for the post-mortem timeline
```

### Phase 3: Triage (T+10 to T+25 min)

**The five questions that define every triage:**

```
Q1: What is broken? (symptoms)
  - Which endpoints? (check error rate per endpoint)
  - Which users? (all? specific region? specific plan?)
  - Error type? (5xx? timeouts? connection refused? wrong data?)
  
  Commands:
    kubectl logs -n production deploy/payment-service --tail=100 | grep -E "ERROR|FATAL"
    curl -s "http://prometheus:9090/api/v1/query" \
      --data-urlencode 'query=topk(10, rate(http_requests_total{status=~"5.."}[5m]) by handler))'

Q2: When did it start?
  - Look at the error rate time series — find the exact inflection point
  - Was there a deploy/change just before?
  
  Commands:
    kubectl rollout history deployment/payment-service -n production
    git log --oneline --since="2026-07-31 13:00" origin/main

Q3: Is it a dependency?
  - Check DB latency, downstream service error rates
  - If dependency is down → your service is a victim, not the cause
  
  Commands:
    curl -s "http://prometheus:9090/api/v1/query" \
      --data-urlencode 'query=pg_up{job="payment-db"}'
    kubectl exec -n production deploy/payment-service -- curl -s http://fraud-check-service/health

Q4: Is it getting better, worse, or stable?
  - Trending worse → needs immediate mitigation
  - Trending better → possible self-healing, monitor closely
  - Stable → systematic failure, needs investigation

Q5: Is there an obvious fix?
  - Recent deploy → rollback is the first move
  - DB full → increase storage or delete old data
  - Memory leak → restart pods immediately, fix in next deploy
```

### Phase 4: Mitigation (T+15 to T+60 min)

**The cardinal rule: MITIGATE FIRST, ROOT CAUSE SECOND.**

Users are in pain right now. Every minute you spend debugging instead of mitigating is another minute of user impact. You can find root cause AFTER users are unblocked.

**The mitigation priority order:**

```
Priority 1: Rollback (safest, fastest, most reliable)
  If there was a recent deploy → rollback immediately
  Don't wait to confirm it's the cause
  Rollback if in doubt — you can always redeploy with a fix
  
  Command: kubectl rollout undo deployment/payment-service -n production
  Verify: kubectl rollout status deployment/payment-service -n production -w

Priority 2: Feature flag off (if you have feature flags)
  For new feature causing issues:
    - Turn off the feature flag → reverts behavior without deploy
    - Much faster than a full rollback
    - Can turn on again once fixed

Priority 3: Scale up (if load-related)
  If error rate correlates with high traffic:
    kubectl scale deployment/payment-service --replicas=20 -n production
  Watch: does error rate drop after scaling? If yes, it's a capacity issue.

Priority 4: Traffic redirection (if region-specific)
  If one region is affected:
    - Update DNS weights / load balancer rules to send traffic to healthy regions
    - Affords time to fix the broken region without user impact

Priority 5: Database / storage intervention
  Only if DB/storage is the confirmed cause:
    - Connection pool restart
    - Kill long-running queries
    - Failover to read replica
    - Add emergency storage capacity
```

**What "mitigation" looks like in the incident channel:**
```
14:42 UTC [alice/IC]: Rolling back payment-service to v3.2.0
14:43 UTC [charlie/SME]: Rollback started, watching pods
14:44 UTC [alice/IC]: 5 pods on v3.2.0, 15 still on v3.2.1
14:46 UTC [charlie/SME]: Error rate dropping: 20% → 12% → 6%
14:47 UTC [alice/IC]: All pods on v3.2.0
14:48 UTC [charlie/SME]: Error rate at 0.2% — back to baseline
14:48 UTC [alice/IC]: @bob please post status update: rollback complete, monitoring
```

### Phase 5: Resolution

**Don't declare resolved too early.** Premature "resolved" declarations are embarrassing:

```
Requirements before declaring resolved:
  □ Error rate at or below baseline for 15+ minutes
  □ Latency at or below baseline for 15+ minutes
  □ Business metrics (orders/min) at expected level
  □ No new alerts firing for same service
  □ On-call confirmed: "I am comfortable this is resolved"
  □ Stakeholders notified: "Incident resolved at HH:MM UTC"
```

**Resolution message template:**
```
✅ [SEV2 RESOLVED] payment-service

Resolved at: 14:53 UTC
Duration: 21 minutes (14:32 – 14:53 UTC)

User impact:
  ~20% of payment requests failed for 21 minutes
  Estimated ~4,200 failed payment attempts
  No data loss confirmed

Root cause (preliminary):
  Deployment v3.2.1 at 14:20 UTC introduced a validation change
  that rejected payment cards with spaces in the number (valid format)
  
Mitigation:
  Rolled back to v3.2.0 at 14:43 UTC

Next steps:
  - Post-mortem scheduled for 2026-08-02 14:00 UTC (owner: @alice)
  - Fix being prepared in v3.2.2 (owner: @charlie)
  - Status page updated

Monitoring: watching for 1 hour to confirm stability
```

---

## Communication Templates — Full Library

### Status Page Updates

```
INVESTIGATING (first update, within 10 min of incident open):
  We are investigating reports of elevated error rates for payment processing.
  Our team is working to identify the cause. Updates every 15 minutes.
  [Posted: 14:35 UTC]

IDENTIFIED (once cause known):
  We have identified that a recent deployment introduced a validation issue
  affecting payment card processing. We are rolling back the deployment.
  [Posted: 14:45 UTC]

MONITORING (after mitigation):
  We have rolled back the problematic deployment. Error rates have returned
  to normal. We are monitoring the system and will update when resolved.
  [Posted: 14:50 UTC]

RESOLVED:
  The payment processing issue has been resolved. A deployment rollback
  restored normal operation at 14:53 UTC. Total duration: 21 minutes.
  A full post-mortem will be published within 48 hours.
  [Posted: 14:55 UTC]
```

### Escalation Message (when IC needs help)

```
@oncall-manager — Escalating payment service SEV2

Current status: 21 min in, user impact ongoing
What we've tried: Rollback (failed — new version was same as old), scale-up (no improvement)
What we need: Someone who knows the payment DB schema to check migration logs
Current metrics: Error rate 18%, p99 latency 4s (4x normal)
IC: @alice in #incident-2026-07-31-payment-high-error-rate
```

---

## Incident Triage Decision Tree (Expanded)

```
ALERT FIRES: High error rate on payment-service
│
├── Step 1: Confirm it's real
│     Check dashboard → error rate confirmed at 20%
│     NOT a false positive → continue
│
├── Step 2: Check for recent changes
│     kubectl rollout history → v3.2.1 deployed 12 min ago
│     YES recent change → SET ROLLBACK AS PLAN A (don't investigate yet)
│
├── Step 3: Scope the impact
│     Which endpoints? → /api/v1/payments (100% error) + others (fine)
│     Which users? → All users, all regions
│     Error type? → HTTP 422 Unprocessable Entity
│     → SEV2 (major feature broken, all users, not complete outage)
│
├── Step 4: Is it a dependency?
│     Check DB: pg_up = 1 (DB fine)
│     Check downstream: fraud-check-service healthy
│     → Not a dependency issue → it's the deployment
│
├── Step 5: Execute mitigation
│     kubectl rollout undo deployment/payment-service -n production
│     Watch metrics → error rate dropping → confirmed: deployment was cause
│
├── Step 6: Confirm resolution
│     Error rate < 0.3% for 15 min → resolved
│
└── Step 7: Post-mortem scheduled
      Root cause: regex change in PaymentValidator
      Fix needed: test with raw user input formats
```
