# Part 6 Deep Dive — Post-Incident: Closing the Reliability Loop

---

## Why Post-Incidents Are Where Reliability Is Actually Built

The incident is over. Users are unblocked. The temptation is to move on.

This is the most expensive mistake in SRE.

Every incident contains exact information about WHY your system is fragile and WHAT to fix. A post-mortem that results in real action items makes that class of incident rare or impossible. A post-mortem that's skipped guarantees the same incident recurs.

Google SRE data: teams that run rigorous post-mortems reduce incident recurrence by 60–80% within 6 months.

---

## The Blameless Post-Mortem — Philosophy First

### Why "Blameless"

The goal of a post-mortem is to improve systems, not punish people.

```
Blame model (wrong):
  "Charlie deployed bad code → Charlie is responsible → Charlie gets a warning"
  
  Result:
    Engineers hide mistakes
    No one deploys on Fridays (fear of blame)
    Post-mortems become defensive documents
    Root causes never identified (everyone protects themselves)
    SAME INCIDENT RECURS because real cause wasn't surfaced

Blameless model (right):
  "The deployment process allowed bad code to reach production →
   the system needs better safeguards →
   let's add integration tests and canary validation"
  
  Result:
    Engineers feel safe reporting exactly what happened
    Post-mortems are honest
    Real root causes are found
    Systems improve
    Future engineers are protected by better systems, not warned to be careful
```

### The Counterfactual Test

For every action a human took, ask: "Given the information available at the time, would a reasonable, competent engineer have done the same thing?"

If yes → this is a SYSTEM failure (the system didn't give enough information, protection, or automation to prevent the action).

If no → then it is a human failure (rare; most post-mortems reveal system failures, not human failures).

---

## Post-Mortem Document — Full Template With Commentary

```markdown
# Post-Mortem: payment-service Validation Bug — 2026-07-31
Status: Draft (due final version: 2026-08-02)
Severity: SEV2
Author: @alice (IC during incident)
Reviewers: @charlie (SME), @bob (Comms), @eng-manager

────────────────────────────────────────────────────
## IMPACT

Duration: 21 minutes (14:32 – 14:53 UTC, 2026-07-31)
Users affected: All users attempting payment processing
Requests failed: ~4,200 payment requests
Revenue impact: ~$8,400 estimated (assuming $2 average order value)
SLO impact: 0.0042% of monthly budget consumed (21 min / 43.2 min budget × error rate)

[Commentary: Be specific. Vague "some users affected" is not useful for
 prioritizing future work. Quantify the impact so the team can decide
 how much engineering effort the fix deserves.]

────────────────────────────────────────────────────
## TIMELINE

All times UTC. Actions by: @alice (IC), @charlie (SME), @bob (Comms).

14:20  v3.2.1 deployed to production (automated deployment pipeline)
       Changed file: PaymentValidator.java (regex update for card number validation)
       
14:32  Alert fired: MyAPI_SLO_FastBurn (1h + 5m windows, 14.4x threshold)
       Burn rate: 22x (20% error rate vs 0.1% budget rate)
       Alert-to-acknowledge: 2 minutes ✓ (within 5-min SLA)
       
14:34  @alice acknowledged PagerDuty page
       Opened #incident-2026-07-31-payment-high-error-rate
       Identified last deployment at 14:20 as prime suspect
       
14:35  @charlie joined, confirmed: all errors are HTTP 422 on /api/v1/payments
       Error message: "Invalid card number format"
       
14:36  @alice: noted that card number "4111 1111 1111 1111" (with spaces) is valid ISO format
       Conclusion: regex in v3.2.1 is rejecting valid cards with spaces
       Decision: rollback immediately (don't wait for fix)
       
14:38  Rollback initiated: kubectl rollout undo deployment/payment-service -n production
       Note: took 2 minutes to decide to rollback (could have been done at 14:36)
       IMPROVEMENT OPPORTUNITY: faster rollback decision needed
       
14:43  Rollback complete: all 20 pods on v3.2.0
       Error rate: 20% → 4% → 0.2%
       
14:47  Error rate at baseline for 5 minutes
       @bob posted status page update: "Monitoring"
       
14:53  Error rate at baseline for 15 minutes, all metrics stable
       @alice declared incident resolved
       @bob posted status page: "Resolved"
       
14:53  Channel archived; post-mortem assigned to @alice (due 2026-08-02)

[Commentary: The timeline is the most factual part of the document.
 Every minute matters. Include the DECISIONS made, not just the actions.
 Note improvement opportunities inline — they feed into action items.]

────────────────────────────────────────────────────
## ROOT CAUSE

Primary: PaymentValidator.java was updated in v3.2.1 to use a stricter regex
that does not allow spaces in card numbers. ISO/IEC 7813 allows spaces
in card number display format. The regex rejected valid user input.

Contributing factor 1: Staging test data uses sanitized card numbers (no spaces).
Real users often copy-paste from statements/wallets which include spaces.
→ Test data does not represent production input diversity.

Contributing factor 2: The change was classified as "low-risk" (text/regex only)
and deployed without canary. "Low-risk" judgment was incorrect for payment code.
→ Risk classification process doesn't account for the payment path sensitivity.

Contributing factor 3: No integration test exists that validates raw user input
formats against PaymentValidator. Only unit tests with pre-sanitized inputs.
→ Test coverage gap: unit tests passed, integration gap undetected.

[Commentary: Use "Contributing factors" instead of "Root cause" — complex systems
 have MULTIPLE contributing factors. Fixing only one often doesn't prevent recurrence.
 The "5 Whys" technique: for each factor, ask "why did this happen?" 5 times.]

5 Whys for Contributing Factor 1:
  Why did staging miss this?
  → Test data was sanitized
  Why was test data sanitized?
  → Sanitization was added 18 months ago for PCI compliance testing
  Why wasn't raw input test data added?
  → No process requires production-realistic test data for payment code
  Why is there no such process?
  → Payment code risk classification doesn't flag this as required
  Why doesn't the risk classification include this?
  → It was written before we had production payment data to model from

Root fix: Add raw user input test cases from production patterns to staging.

────────────────────────────────────────────────────
## WHAT WENT WELL

1. Alert fired within 2 minutes of incident start (2-minute detection) ✓
2. On-call acknowledged within 2 minutes (within 5-min SLA) ✓  
3. Recent deployment was identified as prime suspect quickly (4 min) ✓
4. Rollback decision was made in 14 minutes (acceptable for SEV2) ✓
5. Clear IC role meant no confusion about who was making decisions ✓
6. Status page was updated proactively before customers asked ✓

[Commentary: What went well is as important as what went wrong.
 Teams that only document failures become risk-averse and depressed.
 Document what worked so you don't accidentally remove it in future "improvements".]

────────────────────────────────────────────────────
## WHAT WENT WRONG / COULD BE IMPROVED

1. Rollback decision delayed by 2 minutes (14:36 cause confirmed → 14:38 rollback started)
   Why: IC wanted one more minute of log analysis to "be sure"
   Fix: Pre-authorize rollback: "If recent deploy + cause confirmed in payment path → rollback without further discussion"

2. No canary on payment-service v3.2.1
   Why: Classified as "low-risk regex change"
   Fix: ALL changes to payment/ directory require canary, regardless of change size

3. Test coverage gap for raw card number input
   Why: Test data was sanitized; no requirement for raw format testing
   Fix: Add test fixture library with production-pattern card number formats

4. 12-minute gap between deployment and alert fire
   Why: 20% error rate × 14.4x threshold detection at 1h + 5m windows
   Fix: Consider adding a 10-minute window for payment-specific fast detection

────────────────────────────────────────────────────
## ACTION ITEMS

| # | Action | Type | Owner | Due Date | Status |
|---|---|---|---|---|---|
| 1 | Add raw card number test cases to staging fixture library | Prevention | @charlie | 2026-08-07 | Open |
| 2 | Enforce canary for ALL changes in payment/ directory via CI policy | Prevention | @platform-sre | 2026-08-05 | Open |
| 3 | Add integration test: PaymentValidator with spaces, dashes, raw formats | Detection | @charlie | 2026-08-10 | Open |
| 4 | Update runbook: "if recent deploy + payment path → rollback NOW" | Process | @alice | 2026-08-03 | Open |
| 5 | Add 10-minute SLO window alert for payment-service specifically | Detection | @alice | 2026-08-04 | Open |
| 6 | Audit risk classification policy: payment path = high-risk always | Process | @eng-manager | 2026-08-14 | Open |

[Commentary: Action items must have: action, type (prevention/detection/mitigation/process),
 owner (one person), due date. Without all four, they don't get done.
 Review status at the next team meeting — close the loop on every item.]

────────────────────────────────────────────────────
## LESSONS LEARNED (distilled for the team)

1. "Low-risk text change" is not a valid category in payment code.
   Any change to payment validation logic is high-risk by definition.

2. Staging test data quality is a reliability risk.
   Production-realistic test data is not optional for payment flows.

3. The 2-minute delay on rollback decision cost users ~800 additional failed payments.
   When cause is confirmed in a critical path: rollback authority is pre-granted.

4. Our alert fired in 2 minutes. This is working well — don't change it.
```

---

## Toil Reduction — The Engineering Work After Incidents

### What Counts as Toil

Google's definition: manual, repetitive, automatable work that scales with service load.

```
TOIL (should be eliminated):
  - Manually restarting pods that OOMKill (recurring)
  - Manually running disk cleanup when disk > 80%
  - Manually reviewing "DiskSpaceWarning" alerts that always resolve themselves
  - Manually checking if a deploy is healthy by watching Grafana for 30 min
  - Manually creating incidents in PagerDuty for every Prometheus alert
  - Manually copying metrics from Prometheus to a weekly report spreadsheet
  - Manually checking which Kubernetes nodes need draining before maintenance

NOT TOIL (valuable operational work):
  - Writing a new runbook (knowledge, not toil)
  - Debugging a novel performance issue (investigation, not toil)
  - Designing an improved deployment pipeline (engineering work)
  - Training a new team member (capacity building)
```

### Toil Elimination Patterns

**Pattern 1: Automate the manual remediation**
```
Toil: Manually restart pods that OOMKill repeatedly
  Why it's toil: Same action every time, no judgment needed
  
Eliminate with:
  1. VPA (Vertical Pod Autoscaler) — auto-adjusts memory limits
  2. If VPA not available: custom Kubernetes controller that
     detects OOMKill + auto-increases memory limit + restarts
  3. At minimum: write a script that both restarts AND opens a Jira ticket
     so the memory leak gets fixed (not just masked)
```

**Pattern 2: Fix the alert, not the response**
```
Toil: Alertmanager fires "DiskSpaceWarning" weekly, SRE runs cleanup script

Step 1: Why does disk fill? → Log retention policy not enforced automatically
Step 2: Fix the cause → Configure log rotation with max_size + max_age
Step 3: Delete the alert → DiskSpaceWarning never fires again
Step 4: Replace with predict_linear alert → only fires if genuinely abnormal growth

Result: 0 manual interventions, better signal from the predict_linear alert
```

**Pattern 3: Turn runbook into automation**
```
Toil: On-call follows 5-step runbook to clear a stuck database connection pool
  Step 1: Check if connections > 90%
  Step 2: Run "SELECT pg_terminate_backend(pid) WHERE state = 'idle in transaction' AND wait_duration > '5min'"
  Step 3: Check if connection count dropped
  Step 4: If not, restart pgBouncer
  Step 5: Update Jira ticket

Eliminate with:
  A PagerDuty automation that runs steps 1–3 automatically when the alert fires
  Only pages on-call if automated remediation fails (step 4+)

Result: 70% of alert triggers resolve without human intervention
```

### Measuring Toil

Track these metrics to show toil reduction progress:

```
Weekly on-call toil report:
  - Number of pages this week: 23
  - Pages that required human action: 8 (35%)
  - Pages auto-resolved or false positive: 15 (65%)
  - Average time-per-page when human required: 12 minutes
  - Total toil hours: 8 × 12min / 60 = 1.6 hours

Target:
  - Reduce pages requiring human action to < 20%
  - Reduce average time-per-page to < 8 minutes
  - SRE toil hours < 25% of total work time

Progress tracked quarterly. If toil > 50% of time → SRE team
is allowed to block new feature requests until toil is reduced.
```

---

## Error Budget Policy — How to Enforce It

### The Enforcement Mechanism

The error budget policy is only useful if it's actually enforced. Here's how:

```
Tooling required:
  1. Real-time error budget dashboard (visible to everyone)
  2. Automated budget calculation (not manually tracked in spreadsheets)
  3. Policy document signed by Engineering Manager + SRE Lead
  4. Integration with deployment pipeline (optional but powerful)

Dashboard required fields:
  - Current error rate (live)
  - Budget consumed this period (%)
  - Days remaining in period
  - Budget at current burn rate: will it be exhausted before period ends?
  - Last 7 days: budget consumption chart

Deployment pipeline integration:
  When budget < 10%:
    CI/CD pipeline adds required approval: "ERROR BUDGET < 10%: SRE approval required"
    SRE approves only bug fixes and security patches
    Feature PRs are automatically labeled: "blocked by error budget"
```

### What to Do When Budget Is Exhausted

```
Budget exhausted: What this means
  - You've used ALL allowed failures for this month
  - Any additional failure is in SLA breach territory
  - Engineering MUST stop and fix reliability

Immediate steps (first 24 hours):
  1. Block all non-emergency deployments (SRE can enforce via branch protection)
  2. List the top 5 reliability issues by impact (use incident history)
  3. Assign engineers to reliability sprint
  4. Daily status to VP Engineering: "Budget exhausted; fixing these 5 issues"

Recovery criteria (before unblocking deployments):
  1. Root cause of budget exhaustion fixed
  2. 7-day clean run at normal error rate
  3. SRE signs off: "Budget recovery confirmed"

Why 7-day clean run?
  One day is not enough to confirm stability
  7 days covers weekday + weekend traffic patterns
  7 days of clean run = budget starting to recover toward normal
```

---

## The Reliability Review — Monthly Cadence

Every SRE team should run a monthly reliability review:

```
Monthly Reliability Review Agenda (60 minutes):

1. SLO status (10 min)
   - Current availability, latency, error rate vs targets
   - Error budget remaining
   - Is trend improving or declining?

2. Incident review (20 min)
   - Number of incidents by severity
   - MTTR trend (is it improving?)
   - MTTA trend (are we detecting faster?)
   - Top 3 recurring incident types

3. Alert quality review (15 min)
   - False positive rate (should be < 5%)
   - Alerts with no runbook (must be 0)
   - Noisy alerts (fired > 10x last month = candidate for tuning)
   - Alerts that never fired (necessary? or dead alert?)

4. Toil review (10 min)
   - Toil hours as % of total SRE time
   - Top 3 toil sources
   - Any toil eliminated this month?

5. Action item review (5 min)
   - Post-mortem actions: on track?
   - Any blocked? Who is blocking?
   - What needs escalation?
```
