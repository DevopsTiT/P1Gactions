# Part 2 Deep Dive — SLOs, SLIs, SLAs: The Complete Measurement Framework

---

## Why Measurement Is the Hardest Part of SRE

You cannot improve what you do not measure. And you cannot measure well without agreeing on:
- WHAT to measure (SLI selection)
- HOW GOOD it must be (SLO target)
- WHAT HAPPENS when it's not good enough (error budget policy)
- WHAT YOU'VE PROMISED customers (SLA)

Getting this wrong is worse than not measuring at all — false confidence in the wrong metrics leads to missed incidents and wrong priorities.

---

## SLI — Service Level Indicator: The Metric You Actually Track

### What Makes a Good SLI

A good SLI passes all four tests:

```
Test 1: Does it directly reflect user experience?
  PASS: Error rate (users see failures)
  FAIL: CPU usage (users don't feel CPU directly)

Test 2: Is it measurable with high precision?
  PASS: HTTP request success/failure (binary, countable)
  FAIL: "User happiness" (not directly measurable)

Test 3: Does it correlate with user complaints?
  PASS: p99 latency (slow p99 → users abandon → complaints)
  FAIL: Average latency (average can be fine while p99 is terrible)

Test 4: Is it stable under normal conditions?
  PASS: Error rate stays near 0% normally
  FAIL: Queue depth fluctuates constantly even when healthy
```

### SLI Categories and Examples

**Availability SLI (is it responding?):**
```
Formula: good_requests / total_requests

Where "good" means:
  - HTTP 2xx or 3xx response
  - Responds within timeout
  - Not a connection refused / timeout error

PromQL:
  sum(rate(http_requests_total{status!~"5.."}[5m]))
  /
  sum(rate(http_requests_total[5m]))
```

**Latency SLI (is it fast enough?):**
```
Formula: requests_within_threshold / total_requests

Two approaches:

Option A — Threshold-based:
  "What % of requests completed in < 500ms?"
  sum(rate(http_request_duration_seconds_bucket{le="0.5"}[5m]))
  /
  sum(rate(http_request_duration_seconds_count[5m]))
  → Returns: 0.987 = 98.7% of requests within 500ms

Option B — Percentile-based:
  "What was the 99th percentile latency?"
  histogram_quantile(0.99,
    sum(rate(http_request_duration_seconds_bucket[5m])) by (le)
  )
  → Returns: 0.847 = p99 is 847ms

Option A is better for SLOs because it produces a ratio (0–1),
which can be used directly in burn rate calculations.
```

**Freshness SLI (is the data up to date?):**
```
Formula: time since last successful data update < threshold

For data pipelines, batch jobs, cache refresh:
  time() - last_successful_pipeline_run_timestamp < 300
  → "Data is fresh if last update was < 5 minutes ago"

PromQL:
  time() - pipeline_last_success_timestamp_seconds < 300
```

**Correctness SLI (are the results right?):**
```
Formula: correct_outputs / total_outputs

For batch processing:
  records_processed_correctly / records_attempted

For APIs (requires synthetic test or shadow comparison):
  responses_matching_expected_schema / total_responses
```

**Coverage SLI (did we process everything?):**
```
Formula: items_processed / items_expected

For data ingestion:
  kafka_messages_consumed / kafka_messages_produced
  → Should be near 1.0; drops indicate consumer lag or failures
```

### Choosing SLIs by Service Type

```
Web / REST API:
  Primary: Availability (error rate)
  Secondary: Latency (p99 < 500ms)
  Tertiary: Correctness (response schema valid)

Database:
  Primary: Availability (query success rate)
  Secondary: Latency (query p99)
  Tertiary: Replication lag (< 5s behind primary)

Message Queue Consumer:
  Primary: Coverage (consumption rate vs production rate)
  Secondary: Latency (time from message enqueue to processing)
  Tertiary: Error rate (failed message processing)

Batch / ETL Job:
  Primary: Freshness (completed within time window)
  Secondary: Correctness (output record count within expected range)
  Tertiary: Coverage (all input records processed)

CDN / Static Assets:
  Primary: Availability (cache hit + origin fallback)
  Secondary: Latency (TTFB p95)
  Tertiary: Error rate (404s, 5xx from origin)
```

---

## SLO — Service Level Objective: Your Target

### How to Set the Right SLO

**The three mistakes teams make:**

```
Mistake 1: Aspirational SLO (too tight)
  "We should have 99.99% availability"
  Reality: You've never actually achieved it
  Result: Permanent error budget crisis; team demoralized

Mistake 2: Trivial SLO (too loose)
  "We just need 99% availability"
  Reality: You're at 99.9% normally; budget never consumed
  Result: No signal; budget means nothing

Mistake 3: Copying someone else's SLO
  "Google says 99.9%, so that's ours"
  Reality: Your architecture, users, and business requirements differ
  Result: Wrong target for your actual constraints
```

**The right process:**

```
Step 1: Measure your actual baseline
  What availability, latency, error rate do you deliver today
  over the last 30, 60, 90 days?
  → This is your current de facto SLO

Step 2: Assess user expectations
  What latency makes users abandon? (research: ~3s for web, ~100ms for real-time)
  What error rate makes users complain? (usually anything > 1%)

Step 3: Check your architecture ceiling
  Single region? Maximum practical SLO ≈ 99.9% (need multi-region for more)
  Single DB? Maximum ≈ 99.9% (DB maintenance windows)
  Multi-region active/active? Could achieve 99.99%

Step 4: Set SLO slightly below your baseline
  Baseline: 99.95% availability
  SLO: 99.9% (leaves headroom for planned maintenance)

Step 5: Review quarterly
  As you improve the system, tighten the SLO
  Never loosen SLOs without a business reason
```

### SLO Windows: Rolling vs Calendar

```
Rolling window (recommended):
  "99.9% over the last 30 days, measured continuously"
  Pros: Smooth; past good performance doesn't disappear on the 1st of the month
  Cons: Harder to explain to customers

Calendar window:
  "99.9% per calendar month"
  Pros: Easy to understand; matches billing cycles
  Cons: "Budget reset" problem — team takes risks at start of month
        knowing budget resets on the 1st
```

---

## Error Budget Math — The Full Calculation

### Basic Budget Calculation

```
SLO: 99.9% availability
Error rate budget: 100% - 99.9% = 0.1%

Time-based budget (30-day month):
  0.1% × 30 days × 24 hours × 60 minutes = 43.2 minutes downtime allowed

Request-based budget (if you handle 10M requests/month):
  0.1% × 10,000,000 = 10,000 failed requests allowed
```

### Burn Rate Calculation

```
Burn rate = actual_error_rate / slo_error_budget_rate

Example:
  SLO error budget rate: 0.1% = 0.001
  Actual error rate right now: 0.5% = 0.005
  Burn rate = 0.005 / 0.001 = 5x

What 5x means:
  Budget covers 30 days at 1x burn rate
  At 5x burn rate: 30 / 5 = 6 days until budget exhausted
```

### Multi-Window Burn Rate Alert Thresholds (Full Derivation)

Why 14.4 for the critical threshold? Here's the math:

```
Goal: Alert when we'll exhaust budget within 1 hour

Monthly budget: 30 days × 24h × 60min = 43,200 minutes
1 hour as fraction of budget period: 60min / 43,200min = 0.00139 = 0.139%

If current error rate consumes 0.139% of budget per minute,
budget is gone in 1 hour.

Burn rate to exhaust in 1 hour:
  1 hour = 1/720 of 30-day period
  burn_rate = 1 / (1/720) = 720
  Wait, that can't be right...

Let me redo this properly:
  Budget rate: 0.1% per 30 days
  Budget rate per hour: 0.1% / (30×24) = 0.000139% per hour

  If burn rate = 14.4:
    Consumption per hour = 14.4 × 0.1% / (30×24)
    = 14.4 × 0.000139%
    = 0.002% per hour

  Time to exhaust 0.1% at 0.002%/hour:
    0.1% / 0.002% = 50 hours — wait, still not 1 hour

Correct derivation (Google's method):
  "14.4x over 1 hour consumes 14.4/720 = 2% of monthly budget"
  They use: at this burn rate, you'll exhaust budget in 30/14.4 = ~2 days
  The threshold is chosen so it's worth waking someone up because
  budget will be gone in < 2 days, not necessarily < 1 hour

  Practical meaning of 14.4x: 
    You are burning through your monthly budget 14.4x faster than allowed
    Budget exhausted in: 30 days / 14.4 = 2.08 days (50 hours)
    This justifies an immediate page
```

The thresholds in context:

```
Threshold | Burn rate | Budget exhausted in | Action
──────────────────────────────────────────────────────────────────
14.4x     | 14.4      | ~2 days             | Page on-call NOW (SEV2+)
6x        | 6         | ~5 days             | Slack alert; investigate today
3x        | 3         | ~10 days            | Ticket; fix this sprint
1x        | 1         | 30 days             | Monitoring; acceptable pace
< 1x      | < 1       | Never exhausted     | Budget healthy; full velocity
```

---

## The Full Prometheus SLO Implementation

### Step 1: Recording Rules (Pre-compute SLIs)

```yaml
# prometheus/rules/slo-recording-rules.yaml
groups:
  - name: slo.my-api.recording
    interval: 30s
    rules:

      # 5-minute error rate (used in fast burn detection)
      - record: job:slo_error_rate:5m
        expr: |
          sum(rate(http_requests_total{job="my-api", status=~"5.."}[5m]))
          /
          sum(rate(http_requests_total{job="my-api"}[5m]))
        labels:
          job: my-api

      # 30-minute error rate (used in slow burn detection)
      - record: job:slo_error_rate:30m
        expr: |
          sum(rate(http_requests_total{job="my-api", status=~"5.."}[30m]))
          /
          sum(rate(http_requests_total{job="my-api"}[30m]))
        labels:
          job: my-api

      # 1-hour error rate (used in fast burn detection)
      - record: job:slo_error_rate:1h
        expr: |
          sum(rate(http_requests_total{job="my-api", status=~"5.."}[1h]))
          /
          sum(rate(http_requests_total{job="my-api"}[1h]))
        labels:
          job: my-api

      # 6-hour error rate (used in slow burn detection)
      - record: job:slo_error_rate:6h
        expr: |
          sum(rate(http_requests_total{job="my-api", status=~"5.."}[6h]))
          /
          sum(rate(http_requests_total{job="my-api"}[6h]))
        labels:
          job: my-api

      # Burn rate (normalize by SLO error budget 0.001 for 99.9%)
      - record: job:slo_burn_rate:1h
        expr: job:slo_error_rate:1h{job="my-api"} / 0.001
        labels:
          job: my-api
```

### Step 2: Alert Rules

```yaml
# prometheus/rules/slo-alert-rules.yaml
groups:
  - name: slo.my-api.alerts
    rules:

      # CRITICAL: Fast burn — page immediately
      # Both 1h and 5m windows must exceed threshold (reduces false positives)
      - alert: MyAPI_SLO_FastBurn
        expr: |
          job:slo_error_rate:1h{job="my-api"} > (14.4 * 0.001)
          and
          job:slo_error_rate:5m{job="my-api"} > (14.4 * 0.001)
        for: 2m
        labels:
          severity: critical
          team: platform
          slo: availability
        annotations:
          summary: "[CRITICAL] my-api SLO fast burn — budget depleting rapidly"
          description: |
            Current 1h burn rate: {{ $value | humanizePercentage }}
            SLO target: 99.9% (budget: 0.1%)
            Budget will exhaust in approximately {{ printf "%.1f" (div 30.0 (div $value 0.001)) }} days
          runbook_url: "https://wiki.internal/runbooks/my-api-slo-fast-burn"
          dashboard_url: "https://grafana.internal/d/my-api-slo"

      # WARNING: Slow burn — investigate in business hours
      - alert: MyAPI_SLO_SlowBurn
        expr: |
          job:slo_error_rate:6h{job="my-api"} > (6 * 0.001)
          and
          job:slo_error_rate:30m{job="my-api"} > (6 * 0.001)
        for: 15m
        labels:
          severity: warning
          team: platform
          slo: availability
        annotations:
          summary: "[WARNING] my-api SLO slow burn — steadily consuming error budget"
          description: |
            6h error rate: {{ $value | humanizePercentage }} (6x budget rate)
            Budget will exhaust in approximately {{ printf "%.1f" (div 30.0 (div $value 0.001)) }} days
          runbook_url: "https://wiki.internal/runbooks/my-api-slo-slow-burn"

      # INFO: Budget consumption tracking (no page, just a ticket)
      - alert: MyAPI_SLO_BudgetDraining
        expr: |
          job:slo_error_rate:6h{job="my-api"} > (3 * 0.001)
        for: 1h
        labels:
          severity: info
          team: platform
        annotations:
          summary: "[INFO] my-api error budget consuming at 3x rate — review this sprint"
```

### Step 3: Unit Tests for SLO Rules

```yaml
# prometheus/rules/slo-alert-rules-test.yaml
rule_files:
  - slo-recording-rules.yaml
  - slo-alert-rules.yaml

evaluation_interval: 1m

tests:
  - interval: 1m
    input_series:
      # Simulate 2% error rate (20x budget rate — should trigger fast burn)
      - series: 'http_requests_total{job="my-api", status="200"}'
        values: '0+98x60'   # 98 successful per minute
      - series: 'http_requests_total{job="my-api", status="500"}'
        values: '0+2x60'    # 2 failures per minute = 2% error rate

    alert_rule_test:
      - eval_time: 65m   # after enough data accumulates
        alertname: MyAPI_SLO_FastBurn
        exp_alerts:
          - exp_labels:
              severity: critical
              team: platform
              job: my-api
```

---

## SLA — Service Level Agreement: The Business Contract

### SLA vs SLO: Why They Must Differ

```
SLO: Your internal target     — 99.9% availability
SLA: Your customer commitment — 99.5% availability

The gap (0.4%) is intentional:
  - Gives you room to fix issues before breaching the SLA
  - SLO breach → internal alert, team fixes it
  - SLA breach → customer compensation, executive escalation, trust damage

Rule: SLA must always be LOOSER than SLO
      If SLA = SLO, any SLO breach is immediately an SLA breach
      You have no buffer to fix issues before customer penalties apply
```

### Common SLA Structures

```
Tiered SLA (common for B2B SaaS):
  Enterprise tier: 99.9% → if breached, 10% service credit
  Business tier:   99.5% → if breached, 5% service credit
  Free tier:       no SLA → best effort

What the SLA document must specify:
  1. Measurement period (monthly calendar month)
  2. What counts as downtime (all 5xx? Or only connection refused?)
  3. Exclusions (scheduled maintenance, customer-caused issues)
  4. How credits are calculated
  5. How customers report a breach (support ticket, automatic)
  6. Maximum credit (usually capped at % of monthly bill)
```

### What Counts as "Downtime" — The Definition Battle

This is where SLAs get complicated. Define it precisely before you need it:

```
Option A: Error rate threshold
  "Downtime = any 5-minute window where error rate > 5%"
  Pros: Measurable, objective
  Cons: Brief spikes might trigger SLA breach calculations

Option B: Consecutive failures
  "Downtime = any period where > 50% of requests fail for > 2 consecutive minutes"
  Pros: Filters transient spikes
  Cons: More complex to measure

Option C: Synthetic test failure
  "Downtime = synthetic health check fails from 2+ of 3 regions"
  Pros: Clear, external perspective
  Cons: Doesn't capture partial failures

Recommendation: Use Option C for SLA (simple, external, objective)
                Use Option A for SLO (better signal, internal only)
```

---

## Error Budget Policy — What Happens at Each Level

This must be a written, agreed document, not an informal agreement:

```
POLICY DOCUMENT: my-api Error Budget Policy
Last updated: 2026-07-31
SLO: 99.9% availability (30-day rolling window)
Budget: 0.1% = 43.2 minutes downtime equivalent

LEVEL 1: Budget > 50% remaining (> 21.6 min remaining)
  Allowed: All feature deployments, experiments, risky changes
  Canary: Optional
  Deploys: Up to 3/day with any review process
  Review: Monthly SLO review

LEVEL 2: Budget 25%–50% remaining (10.8 – 21.6 min remaining)
  Allowed: Feature deployments with canary required
  Not allowed: Risky architectural changes, load tests in production
  Deploys: Max 2/day, require SRE review
  Review: Weekly SLO review

LEVEL 3: Budget 10%–25% remaining (4.3 – 10.8 min remaining)
  Allowed: Only bug fixes and security patches
  Not allowed: Feature work, experiments
  Deploys: Max 1/day, IC on standby during deploy
  Review: Daily SLO check; engineering manager notified

LEVEL 4: Budget < 10% remaining (< 4.3 min remaining)
  Allowed: Only hotfixes for active incidents
  Not allowed: All feature work frozen
  Deploys: Require VP Engineering approval
  Review: Engineering director notified; reliability sprint begins

LEVEL 5: Budget exhausted (0 remaining)
  All deployments: FROZEN (SRE can block merges to main branch)
  Escalation: VP Engineering + CTO aware
  Recovery: Budget does not reset until root cause fixed + 7-day clean run
  Review: Daily executive status update until SLO restored

OWNERS:
  SLO measurement: SRE team
  Policy enforcement: SRE team + Engineering Manager
  Exception approval: VP Engineering
```
