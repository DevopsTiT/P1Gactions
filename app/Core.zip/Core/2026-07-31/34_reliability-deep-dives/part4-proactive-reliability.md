# Part 4 Deep Dive — Proactive Reliability Practices

---

## Why "Proactive" Means Engineering, Not Just Monitoring

Part 3 covered proactive monitoring: watching for early signals.
Part 4 covers proactive reliability: building systems that are harder to break.

The distinction:
```
Proactive monitoring: "We detected the problem 4 hours before users felt it"
Proactive reliability: "The system handled the failure automatically; no one detected anything"

Monitoring detects problems.
Reliability engineering prevents them, or makes them harmless.
```

The five practices in this part:
1. Change management (most incidents are self-inflicted)
2. Canary deployments (limit blast radius when change does cause a problem)
3. Circuit breakers (stop cascade failures)
4. Health checks done right (Kubernetes probe correctness)
5. Dependency mapping (know your risk surface)

---

## Practice 1: Change Management

### The 80% Rule

Industry data consistently shows: 80% of incidents are caused by recent changes.
Not hardware failures. Not random bugs. Changes you made.

```
Types of changes that cause incidents:
  - Code deployments (most common)
  - Configuration changes (feature flags, env vars, Kubernetes manifests)
  - Infrastructure changes (Terraform applies, node scaling)
  - Dependency upgrades (library version bumps)
  - Database migrations (schema changes, index additions)
  - Scaling events (HPA scaling up, new nodes joining)
  - Secret/certificate rotations
  - Third-party provider changes (your CDN, DNS, payment gateway)
```

### Change Risk Matrix

Every change should be assigned a risk level before deployment:

```
Risk Score Formula:
  Blast radius    × Rollback difficulty × Deployment speed
  (1-5)             (1-5)                 (1-5)
  
Risk Score Interpretation:
  1–25:  Low risk (standard deployment, no special measures)
  26–50: Medium risk (canary required, SRE awareness)
  51–75: High risk (staged rollout required, IC on standby)
  76–125: Critical risk (change window, executive awareness)

Blast radius scoring (1–5):
  1: Single pod, one user segment, non-critical feature
  3: One microservice, all users of that feature
  5: Database schema, authentication, payment path, all users

Rollback difficulty scoring (1–5):
  1: Single kubectl rollout undo
  3: Feature flag off + cache flush
  5: DB migration with no rollback script

Deployment speed scoring (1–5):
  1: Canary at 1% for 30 minutes before proceeding
  3: Rolling update over 10 minutes
  5: Full fleet swap in 2 minutes (no canary)
```

### Pre-Deploy Checklist

```
BEFORE EVERY PRODUCTION DEPLOY:

□ 1. What changed?
      List every file/config changed; no "misc fixes" — be specific

□ 2. What is the rollback plan?
      "kubectl rollout undo" is OK for code
      "No rollback possible" = stop and create one before deploying

□ 3. Has staging validated this?
      Staging tested with production-like traffic volume?
      Staging tested with production-like data?

□ 4. Is the deploy observable?
      SLO dashboard open before deploy starts?
      Error rate, latency, business metric panels visible?

□ 5. Is deploy timing acceptable?
      Not deploying during peak traffic hours?
      Not deploying on Friday afternoon?
      Not deploying during a known high-traffic event?

□ 6. Is the right person available?
      Developer who made the change is available for 30 minutes post-deploy?
      On-call SRE aware a deploy is happening?

□ 7. Post-deploy monitoring window planned?
      30 minutes of watching metrics after deploy = standard
      60 minutes for high-risk changes
```

---

## Practice 2: Canary Deployments (Full Implementation)

### Why Canary Deployments Are Non-Negotiable for Reliability

```
Full fleet deployment (dangerous):
  Deploy v2 to 100 pods simultaneously
  If v2 has a bug: 100% of users affected immediately
  MTTR: however long until you detect + rollback (could be 20 min)

Canary deployment (safe):
  Deploy v2 to 5 pods (5% of 100)
  If v2 has a bug: 5% of users affected for 5 minutes
  MTTR: auto-rollback in 5 min, 95% of users never affected
```

### Manual Canary (Kubernetes Only — No Extra Tools)

```yaml
# Manual canary using two Deployments with same label selector
# kubernetes/canary/canary-deploy.yaml

# Stable version (v1) — 95% of traffic
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-service-stable
  namespace: production
spec:
  replicas: 19        # 95% of 20 total pods
  selector:
    matchLabels:
      app: my-service
      version: stable
  template:
    metadata:
      labels:
        app: my-service
        version: stable
    spec:
      containers:
        - name: my-service
          image: my-service:v1.2.3

---
# Canary version (v2) — 5% of traffic
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-service-canary
  namespace: production
spec:
  replicas: 1         # 5% of 20 total pods
  selector:
    matchLabels:
      app: my-service
      version: canary
  template:
    metadata:
      labels:
        app: my-service
        version: canary
    spec:
      containers:
        - name: my-service
          image: my-service:v1.3.0    # new version

---
# Single Service routes to BOTH (Kubernetes load balances by pod count)
apiVersion: v1
kind: Service
metadata:
  name: my-service
  namespace: production
spec:
  selector:
    app: my-service    # matches BOTH stable and canary pods
  ports:
    - port: 80
      targetPort: 8080
```

**Canary comparison PromQL:**
```promql
# Error rate: stable vs canary (should be similar)
sum(rate(http_requests_total{status=~"5..", version="canary"}[5m]))
/ sum(rate(http_requests_total{version="canary"}[5m]))
# Compare with:
sum(rate(http_requests_total{status=~"5..", version="stable"}[5m]))
/ sum(rate(http_requests_total{version="stable"}[5m]))

# p99 latency: canary vs stable
histogram_quantile(0.99,
  sum(rate(http_request_duration_seconds_bucket{version="canary"}[5m])) by (le)
)
# vs
histogram_quantile(0.99,
  sum(rate(http_request_duration_seconds_bucket{version="stable"}[5m])) by (le)
)
```

### Automated Canary with Argo Rollouts

```yaml
# kubernetes/canary/rollout.yaml
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: my-service
  namespace: production
spec:
  replicas: 20
  selector:
    matchLabels:
      app: my-service

  strategy:
    canary:
      # Pause at each step, check metrics automatically
      analysis:
        templates:
          - templateName: success-rate-check
        startingStep: 1
        args:
          - name: service-name
            value: my-service

      steps:
        - setWeight: 5          # 5% canary
        - pause: {duration: 5m}
        - analysis: {}          # run metric analysis here
        - setWeight: 25
        - pause: {duration: 5m}
        - analysis: {}
        - setWeight: 50
        - pause: {duration: 5m}
        - setWeight: 100

---
# The metric analysis template
apiVersion: argoproj.io/v1alpha1
kind: AnalysisTemplate
metadata:
  name: success-rate-check
spec:
  args:
    - name: service-name
  metrics:
    - name: success-rate
      interval: 2m
      successCondition: result[0] >= 0.99    # 99% success rate required
      failureLimit: 1                         # 1 failure = rollback
      provider:
        prometheus:
          address: http://prometheus:9090
          query: |
            sum(rate(http_requests_total{
              job="{{ args.service-name }}",
              status!~"5.."
            }[2m]))
            / sum(rate(http_requests_total{
              job="{{ args.service-name }}"
            }[2m]))
```

When the analysis fails:
1. Argo Rollouts automatically sets weight back to 0%
2. New version pods are scaled down
3. Old version handles 100% of traffic
4. Rollout status changes to `Degraded`
5. You receive an alert: "Canary analysis failed"

---

## Practice 3: Circuit Breakers (Full Deep Dive)

### Why Circuit Breakers Are Essential in Microservices

```
Without circuit breaker — cascade failure scenario:
  Service A receives 1,000 req/sec
  Each request calls Service B
  Service B becomes slow (DB issue) — taking 30s instead of 100ms

  What happens to Service A:
    All 1,000 threads start waiting for Service B
    After 30s: Service A has 30,000 threads waiting (1,000/sec × 30s)
    Thread pool exhausted → Service A starts refusing connections
    Service C (which calls A) also starts failing
    Service D (which calls C) also starts failing

    One slow dependency cascaded into a full outage of the entire system.

With circuit breaker:
    After 5 consecutive failures to Service B:
      Circuit opens → Service A immediately returns error (no waiting)
      Threads freed immediately
      Service A continues serving 1,000 req/sec
      Users of Service A get a partial error (B-dependent features fail)
      Other features continue working
      Service B gets no more load → can recover
      After 30s: circuit tests B → B recovered → circuit closes
```

### Circuit Breaker State Machine

```
CLOSED state (normal operation):
  All requests pass through to the downstream service
  Success/failure counter maintained in rolling window
  Condition to OPEN: N failures in T seconds (configurable threshold)

OPEN state (failing fast):
  All requests immediately rejected (no downstream call made)
  Returns fallback response or error immediately
  Condition to HALF-OPEN: after timeout duration (e.g., 30s)
  Why: Give downstream time to recover; don't keep hammering a broken service

HALF-OPEN state (testing recovery):
  Allow 1 probe request through to downstream
  If probe succeeds → CLOSED (service recovered)
  If probe fails → back to OPEN (still broken, wait more)
```

### Implementing Circuit Breaker in Java (Resilience4j)

```java
// Application configuration
CircuitBreakerConfig config = CircuitBreakerConfig.custom()
    .failureRateThreshold(50)           // Open when 50% of calls fail
    .waitDurationInOpenState(Duration.ofSeconds(30))  // Stay open 30s
    .slidingWindowType(SlidingWindowType.COUNT_BASED)
    .slidingWindowSize(10)              // Look at last 10 calls
    .minimumNumberOfCalls(5)            // Need at least 5 calls to evaluate
    .permittedNumberOfCallsInHalfOpenState(3)  // 3 probes in half-open
    .build();

CircuitBreaker circuitBreaker = CircuitBreaker.of("payment-service", config);

// Usage: decorate your downstream call
CheckedFunction0<PaymentResponse> decoratedCall =
    CircuitBreaker.decorateCheckedSupplier(circuitBreaker,
        () -> paymentServiceClient.processPayment(request));

// Execute with fallback
Try<PaymentResponse> result = Try.of(decoratedCall)
    .recover(CallNotPermittedException.class,
        ex -> PaymentResponse.queuedForRetry(request.getId()))  // fallback
    .recover(Exception.class,
        ex -> PaymentResponse.temporarilyUnavailable());
```

**Circuit breaker Prometheus metrics (Resilience4j exposes these automatically):**
```promql
# Circuit breaker state (0=closed, 1=open, 2=half-open)
resilience4j_circuitbreaker_state{name="payment-service"}

# Failure rate percentage
resilience4j_circuitbreaker_failure_rate{name="payment-service"}

# Calls prevented (circuit was open)
rate(resilience4j_circuitbreaker_not_permitted_calls_total[5m])
```

**Alert on circuit breaker opening:**
```yaml
- alert: CircuitBreakerOpen
  expr: resilience4j_circuitbreaker_state{state="open"} == 1
  for: 1m
  labels:
    severity: warning
  annotations:
    summary: "Circuit breaker {{ $labels.name }} is OPEN — {{ $labels.service }} protecting itself"
    description: "Downstream dependency failing. Fallback mode active."
```

---

## Practice 4: Health Checks — The Common Mistakes

### The Three Probes and Their Exact Purpose

```
Liveness Probe: "Is this process alive and not deadlocked?"
  Kubernetes action if it fails: KILL and RESTART the container
  Check: Only check for deadlock / process responsiveness
  NEVER check: Database, cache, other services

Readiness Probe: "Is this container ready to receive traffic?"
  Kubernetes action if it fails: REMOVE from Service endpoints (stop sending traffic)
  Does NOT kill the container — just stops routing to it
  Check: Database connectivity, cache connectivity, required config loaded

Startup Probe: "Has this slow-starting app finished initializing?"
  Kubernetes action if it fails after failureThreshold: KILL the container
  Runs INSTEAD of liveness probe until it succeeds once
  Use for: Java applications with slow JVM startup, ML model loading
```

### The Critical Mistake: DB Check in Liveness Probe

```
WRONG configuration:
  livenessProbe:
    httpGet:
      path: /health/live   # This endpoint checks DB connection
      ...

What happens when DB has a 30-second hiccup:
  Step 1: DB brief outage (30 seconds)
  Step 2: /health/live checks DB → fails
  Step 3: Kubernetes kills ALL pods (all fail simultaneously)
  Step 4: All pods restart and try to reconnect to DB
  Step 5: 20 pods × connection pool × reconnect = DB overwhelmed
  Step 6: DB can't handle reconnect storm → stays down
  Step 7: 30-second DB hiccup became a 10-minute full outage

CORRECT configuration:
  livenessProbe path: /health/live
    → Only checks: can the HTTP server respond? Is the JVM alive?
    → Returns 200 even if DB is down
  
  readinessProbe path: /health/ready
    → Checks: DB connected? Cache connected? Config loaded?
    → If DB down: pods become Unready, removed from Service
    → Traffic stops going to unready pods → no errors served
    → DB can recover without being hammered
    → When DB recovers: pods become Ready again automatically
```

### Health Check Endpoint Implementation

```java
// Spring Boot example
@RestController
@RequestMapping("/health")
public class HealthController {

    private final DataSource dataSource;
    private final RedisTemplate<String, String> redisTemplate;

    // Liveness: only check if the application itself is responsive
    // Never checks external dependencies
    @GetMapping("/live")
    public ResponseEntity<Map<String, String>> liveness() {
        return ResponseEntity.ok(Map.of("status", "alive"));
    }

    // Readiness: check ALL required dependencies
    // Traffic should not reach this pod unless all dependencies are ready
    @GetMapping("/ready")
    public ResponseEntity<Map<String, Object>> readiness() {
        Map<String, Object> checks = new LinkedHashMap<>();
        boolean allHealthy = true;

        // Check DB
        try (Connection conn = dataSource.getConnection()) {
            conn.isValid(2);  // 2-second timeout
            checks.put("database", "ok");
        } catch (Exception e) {
            checks.put("database", "error: " + e.getMessage());
            allHealthy = false;
        }

        // Check Redis
        try {
            redisTemplate.opsForValue().get("health-check-key");
            checks.put("cache", "ok");
        } catch (Exception e) {
            checks.put("cache", "error: " + e.getMessage());
            allHealthy = false;
        }

        if (allHealthy) {
            return ResponseEntity.ok(Map.of("status", "ready", "checks", checks));
        } else {
            // 503 Service Unavailable → Kubernetes marks pod as Unready
            return ResponseEntity.status(503)
                .body(Map.of("status", "not_ready", "checks", checks));
        }
    }
}
```

---

## Practice 5: Dependency Mapping

### Why You Must Know Your Dependencies Before an Incident

During an incident, the most common question is: "Is this MY problem or a dependency's problem?"
If you don't know your dependencies, you spend 20 minutes investigating your own code before realizing the DB is down.

### The Dependency Inventory

Every service should have a documented dependency map:

```
Service: order-service
Last updated: 2026-07-31

SYNCHRONOUS (in-path — request fails if dependency fails):
  Name              | Protocol | Owner      | Failure mode
  ───────────────────────────────────────────────────────────────
  PostgreSQL        | TCP/5432 | DB team    | Orders fail completely
  inventory-service | HTTP     | Warehouse  | Stock check fails; block checkout
  payment-service   | HTTP     | Payments   | Checkout fails; order not created
  auth-service      | HTTP     | Identity   | All requests fail (no auth)

ASYNCHRONOUS (out-of-path — failures queue up but don't block requests):
  Name              | Protocol | Owner      | Failure mode
  ───────────────────────────────────────────────────────────────
  Kafka             | TCP/9092 | Platform   | Events queue locally; order created
  email-service     | HTTP     | Comms      | Confirmation email delayed
  analytics         | HTTP     | Data       | No analytics event; order still works

OPTIONAL (degradable — service works without it):
  Name              | Protocol | Owner      | Failure mode
  ───────────────────────────────────────────────────────────────
  Redis cache       | TCP/6379 | Platform   | Slower response; no cache hit
  recommendation    | HTTP     | ML team    | "Related items" section empty
  fraud-check       | HTTP     | Risk       | Allow-list by default; process anyway
```

### Dependency Health Dashboard

Every service dashboard must include a "Dependency Health" row:

```promql
# Panels for dependency health row:

# Panel 1: PostgreSQL connection success rate
sum(rate(pg_up[5m]))
# Should be 1.0

# Panel 2: Downstream service latency (inventory-service)
histogram_quantile(0.99,
  sum(rate(http_client_request_duration_seconds_bucket{
    target="inventory-service"
  }[5m])) by (le)
)

# Panel 3: Downstream service error rate (payment-service)
sum(rate(http_client_requests_total{
  target="payment-service", status=~"5.."
}[5m]))
/ sum(rate(http_client_requests_total{target="payment-service"}[5m]))

# Panel 4: Kafka consumer lag (async dependency)
kafka_consumer_group_lag{group="order-service-consumer"}
# Should be near 0; growing lag = consumer falling behind
```

### Graceful Degradation per Dependency

Document and implement what happens when each dependency fails:

```
Redis cache unavailable:
  Default behavior: Serve requests from DB (slower but correct)
  Alert: WARNING (not critical — no user impact)
  Circuit breaker: No (fail-through to DB is fine)
  
  Code pattern:
    try {
      String cached = redis.get(key);
      if (cached != null) return deserialize(cached);
    } catch (RedisException e) {
      log.warn("Cache unavailable, falling back to DB");
      // fall through to DB query
    }
    return db.query(key);

fraud-check-service unavailable:
  Default behavior: Apply conservative rules (allow low-risk, block high-risk by score)
  Alert: WARNING + Slack to fraud team
  Circuit breaker: YES (fast-fail to conservative policy)
  
  Code pattern:
    try {
      return fraudCheckClient.evaluate(order);
    } catch (CallNotPermittedException e) {
      // Circuit open: apply default policy
      return order.riskScore() < 0.3 ? ALLOW : MANUAL_REVIEW;
    }

payment-service unavailable:
  Default behavior: FAIL (cannot complete checkout without payment)
  Alert: CRITICAL (page on-call)
  Circuit breaker: YES (fast-fail with user-visible error)
  
  Code pattern:
    try {
      return paymentClient.charge(order);
    } catch (CallNotPermittedException e) {
      // Circuit open: return clear error
      throw new ServiceUnavailableException(
        "Payment processing temporarily unavailable. Please try again in a few minutes.");
    }
```
