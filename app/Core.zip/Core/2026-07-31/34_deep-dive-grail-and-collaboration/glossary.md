# Glossary — Deep Dive: Grail Logs + SRE Collaboration

Every new term introduced in the deep-dive explanations.

---

**`inotify` (Linux kernel)**
A Linux kernel mechanism that notifies processes when files are changed. Why it matters: OneAgent uses inotify to watch `/var/log/containers/` — when containerd appends a new log line, the kernel instantly notifies OneAgent without polling. Zero CPU overhead at rest.

**Inverted index**
A data structure that maps each word/token to the list of log records containing it. Like a book index: "Connection → lines 4, 17, 892". Why it matters: `matchesPhrase` uses the inverted index for instant lookups. Without it, every query would scan every log line's full text.

**B-tree index**
A balanced tree data structure used for exact-match and range queries on structured fields like `status` or `service.name`. Why it matters: `filter status == "ERROR"` uses the B-tree index — eliminates all non-ERROR records in O(log N) time instead of O(N).

**Column-oriented storage**
Storing all values of one field together (e.g., all `status` values in one column, all `timestamp` values in another). Why it matters: `summarize count(), by: { bin(timestamp, 1h) }` only reads the `timestamp` column — doesn't touch `content` (huge text field) → 10-100× faster aggregations.

**MDC (Mapped Diagnostic Context)**
A thread-local map in Java logging frameworks (Logback, Log4j) where key-value pairs are automatically included in every log line emitted from that thread. Why it matters: the OTEL Java agent puts `dt.trace_id` and `dt.span_id` into the MDC → every log line emitted during a request automatically carries the trace context.

**Thread-local storage**
Memory that is private to a specific thread. Why it matters: MDC is thread-local — trace_id from request A's thread doesn't leak into request B's thread running concurrently. Logs are correctly correlated to their own request.

**`inotify` watch**
A file system watch created by OneAgent on `/var/log/containers/`. When any file in that directory is written, inotify triggers immediately. Why it matters: log lines reach Grail within 1-3 seconds of being written — near real-time for incident investigation.

**`/var/log/containers/` naming convention**
EKS/Kubernetes log file naming: `<pod-name>_<namespace>_<container-name>-<container-id>.log`. Why it matters: OneAgent extracts pod name and namespace FROM THE FILENAME without needing to query the Kubernetes API — fast and reliable.

**Float division vs integer division**
In most languages, `5 / 100 = 0` (integer division truncates). `5 * 100.0 / 100 = 5.0` (float). Why it matters: in DQL `fieldsAdd error_rate = errors * 100.0 / total` — `100.0` forces float division. If you write `errors * 100 / total`, you get 0 for any error rate less than 1%.

**`jq` (JSON query tool)**
A command-line JSON processor used in CI scripts. `jq -r '.slo[0].status'` extracts the `status` field from the first element of the `slo` array. Why it matters: DT API responses are JSON; jq parses them in bash scripts for automated checks.

**`bc -l` (arbitrary precision calculator)**
A bash utility for floating-point arithmetic. `echo "0.6 > 0.5" | bc -l` returns 1 (true). Why it matters: bash cannot natively compare decimal numbers — `if [ 0.6 > 0.5 ]` fails. `bc -l` enables decimal comparisons in CI scripts.

**`:max` (DT metric aggregation)**
A DT metric selector transformation that returns the maximum value in the time range. Why it matters: for error rate checks after deploy, using `:avg` would miss a brief spike (0.6% for 30s averaged over 5min = 0.06%). `:max` returns the spike value.

**`NR==2` (awk)**
AWK's built-in row counter. `NR==1` = first row, `NR==2` = second row. Why it matters: `git log --oneline` lists commits newest-first. `NR==2` gets the PREVIOUS commit (the one before the current bad deploy) — used in auto-rollback to find the last good image SHA.

**`-detailed-exitcode` (Terraform)**
A `terraform plan` flag that returns exit code 0 (no changes), 1 (error), or 2 (infrastructure changes detected). Why it matters: drift detection CI uses this to programmatically determine if DT configuration was manually changed — exit code 2 = drift found.

**`PIPESTATUS`**
A bash array holding the exit codes of all commands in a pipeline. `echo a | grep b; echo ${PIPESTATUS[0]}` shows grep's exit code. Why it matters: `terraform plan ... | tee plan.txt` — PIPESTATUS[0] is terraform's exit code, not tee's. Without PIPESTATUS, tee always returns 0 masking terraform's exit code.

**`sloSelector=name("...")` (DT API)**
A filter parameter for the DT `/api/v2/slo` endpoint that matches SLOs by exact name. Why it matters: must match the `name` field in `dynatrace_slo_v2` Terraform resource exactly, including any suffix like `[production]`.

**`entitySelector` (DT API)**
A query language for selecting Dynatrace entities (services, hosts, process groups) to attach events to. `type(SERVICE),entityName(payment-service)` selects the SERVICE entity named exactly "payment-service". Why it matters: the link between the deployment event and the DT service entity — must match `OTEL_SERVICE_NAME` exactly.

**Davis AI problem correlation**
The DT AI engine that automatically finds deployment events, config changes, and anomalies that occurred just before a problem started and marks them as "likely contributing factors" on the problem timeline. Why it matters: replaces 20 minutes of manual timestamp correlation with a 2-second automated display.

**`/platform/storage/query/v1/query:execute`**
The Grail REST API endpoint for executing DQL queries programmatically. Returns `{"records": [...]}`. Why it matters: used by the Slack bot Lambda to run DQL from outside the DT UI — enables automation and integrations.

**Monotonically increasing (Counter)**
A value that only goes up, never down. Micrometer Counters are monotonically increasing. Why it matters: DT computes the rate of change (per minute) from consecutive counter values — if a counter could decrease, the rate calculation would break.

**JIT compilation (Just-In-Time)**
The JVM's process of converting frequently-executed bytecode to native machine code while the program runs. Why it matters: for the first 30-90 seconds after JVM startup, code runs in interpreted mode (5-10× slower). This is why `sleep 60` is needed before post-deploy checks — otherwise you get false-positive errors from JIT warmup latency.

**`idemopotency retry path`**
A code path that retries a previously-failed operation, expecting that repeating the same request is safe. Why it matters: idempotency retries legitimately generate 4xx/5xx responses as part of normal operation — the error rate threshold for this path should be higher than the primary payment path.

**Cardinality (metrics)**
The number of unique values a metric tag can have. Why it matters: using `userId` as a metric tag creates one time series per user (millions of users = millions of time series = high cardinality = expensive storage). Use tags with low cardinality: `reason` (5-10 values), `operation` (20-50 values), never `userId`.

**`builtin:service.errors.server.rate`**
The DT built-in metric key for HTTP server error rate (HTTP 5xx / total requests × 100). Why it matters: used in post-deploy error rate checks — querying this metric via the DT API is faster and more accurate than calculating from logs.

**`CUSTOM_DEPLOYMENT` event type**
A DT event type that marks a deployment in the DT timeline. Why it matters: this specific type causes DT to show a deployment marker on service dashboards and enables Davis AI to correlate deployments with subsequent problems.

**Sprint planning observability gate**
The practice of SRE attending sprint planning to define SLOs, instrumentation requirements, and runbook location BEFORE development starts. Why it matters: fixes the root cause of "monitoring after launch" — observability requirements are captured when requirements cost nothing to change (before coding starts).

**Heap dump**
A snapshot of all Java objects in the heap at a moment in time. `jmap -dump:live,format=b,file=heap.hprof <pid>` captures it. Why it matters: the definitive tool for diagnosing memory leaks — shows which objects are accumulating and what's holding references to them.

**`jstack`**
A JVM tool that prints a thread dump: the current stack trace of every thread. `kubectl exec -it <pod> -- jstack 1` runs it in the container. Why it matters: identifies deadlocks, thread pool exhaustion, and which code path is consuming CPU.
