# Deep Dive — Every Part of Grail Log Management + SRE Collaboration

> This file explains every section of both `26_dynatrace-grail-logs/main.md` and `33_sre-collaboration-observability-automation/main.md` at maximum depth. Every line of code, every concept, every "why."

---

## SECTION A: GRAIL LOG MANAGEMENT

---

### A1 — Decision Tree: What to do when

```
"Show me errors in payment-service last 30 min"
→  fetch logs, from: now()-30m | filter service.name == "payment-service" | filter status == "ERROR"
```

**Why this exact sequence:**

`fetch logs` — tells Grail which data store to use. Grail stores four types: `logs`, `metrics`, `events`, `bizevents`. Always specify the correct source; mixing them is not possible in one query.

`from: now()-30m` — bounds the time scan. Without this, Grail defaults to scanning the full retention window (35 days = 50,400 minutes). A 30-minute window scans 1/1,680 of that. With 1TB of stored logs, that's the difference between scanning 600MB vs 1TB — 1,700× cheaper.

`filter service.name == "payment-service"` — `service.name` is an indexed field (pre-built B-tree index in Grail). Filtering on indexed fields happens before reading log content. Eliminates all logs from order-service, notification-service, kube-system etc. in microseconds.

`filter status == "ERROR"` — `status` is another indexed field (DT maps log4j level → status automatically). Eliminates WARN, INFO, DEBUG lines — typically 90%+ of all log volume.

```
"Why is payment-service slow?" → DQL + trace_id link
```

A performance problem is not a log problem — it's a timing problem. The correct path is:
1. Find a slow request in the DT Services → payment-service → Top slow requests view
2. Click the trace to see the waterfall: `order-service [120ms] → payment-service [80ms] → PostgreSQL [70ms]`
3. Click the `payment-service` span → "Logs" tab → shows only log lines emitted during THAT specific request (linked by `dt.trace_id`)

Why this works: when OTEL Java agent creates a span, it injects the trace_id into the MDC (Mapped Diagnostic Context). Spring Boot/Logback automatically includes MDC fields in every log line. So `dt.trace_id` appears in the log record. Grail stores this as an indexed field, so filtering by it is instant.

```
"How many OOM errors this week?" → DQL aggregate
```

This is a TREND question, not an investigation. The right DQL shape:
```dql
fetch logs, from: now()-7d
| filter matchesPhrase(content, "OutOfMemoryError")
| summarize count = count(), by: { bin(timestamp, 1h) }
| sort timestamp asc
```
`bin(timestamp, 1h)` groups all timestamps in each 1-hour window into one bucket. Result: 168 rows (7 days × 24 hours), each with a count. Plot as a line chart → shows whether OOMs are increasing, decreasing, or happening at a specific time each day (which would suggest a scheduled batch job).

---

### A2 — E2E Flow: How Logs Get Into Grail

**Step 1: Java writes to stdout**

Spring Boot + Logback writes to stdout (fd 1) of the container process.
```java
logger.error("DB connection failed", exception);
```
The JVM writes this as a byte stream to stdout. The container runtime (containerd on EKS) intercepts all stdout writes and appends them to a file:
```
/var/log/containers/<pod-name>_<namespace>_<container-name>-<container-id>.log
```
Example:
```
/var/log/containers/payment-service-7d9f8b-abc12_payment-ns_payment-service-a1b2c3d4.log
```
This file is on the EKS node's filesystem (not in the container). Every container on the node gets its own log file.

**Step 2: OneAgent reads the file continuously**

OneAgent runs as a DaemonSet pod on every node. It uses `inotify` (Linux kernel mechanism) to watch `/var/log/containers/` for new log lines. When a line is appended, OneAgent reads it and enriches it:

```
Raw line from file:
2024-01-15T10:30:00Z ERROR DB connection failed

After OneAgent enrichment (what gets sent to Grail):
{
  "timestamp": "2024-01-15T10:30:00Z",
  "content": "DB connection failed",
  "status": "ERROR",
  "k8s.namespace.name": "payment-ns",
  "k8s.pod.name": "payment-service-7d9f8b-abc12",
  "k8s.node.name": "ip-10-12-34-56.ap-northeast-1.compute.internal",
  "k8s.deployment.name": "payment-service",
  "k8s.container.name": "payment-service",
  "dt.entity.process_group_instance": "PROCESS_GROUP_INSTANCE-abc",
  "service.name": "payment-service",
  "dt.trace_id": "4bf92f3577b34da6a3ce929d0e0e4736",
  "dt.span_id": "00f067aa0ba902b7"
}
```

How OneAgent gets `service.name`: from the `OTEL_SERVICE_NAME` env var on the pod. OneAgent reads pod spec env vars.
How OneAgent gets `dt.trace_id`: OTEL Java agent injects this into Logback's MDC (Mapped Diagnostic Context). Every log line written inside a trace context gets the trace_id automatically.

**Step 3: OneAgent → ActiveGate → DT Grail**

OneAgent batches enriched log records and sends to the ActiveGate in the `dynatrace` namespace via HTTP POST every few seconds. ActiveGate adds K8s cluster-level metadata (cluster name, region) and forwards to the DT SaaS tenant's Grail ingest API using a single authenticated connection.

Why ActiveGate is the relay:
- All pods need not know the DT tenant URL or hold API tokens
- One connection from ActiveGate to DT (not N connections from N pods)
- ActiveGate buffers if DT is temporarily unreachable → no data loss

**Step 4: Grail stores and indexes**

Grail stores the raw log record + all enriched fields. It builds inverted indexes for:
- `status` → fast equality filters
- `service.name` → fast equality + cardinality queries
- `k8s.namespace.name`, `k8s.pod.name` → fast filters
- `dt.trace_id` → fast lookup for trace→log linking
- `content` → full-text inverted index (tokenized words) for `matchesPhrase`

Numeric fields: stored as column-oriented arrays for efficient `summarize` aggregations.

---

### A3 — DQL Deep Dive: Every Command Explained

#### `fetch logs, from: now()-1h, to: now()`

`fetch` — the DQL command that opens a scan over a Grail data store.
`logs` — specifies the data store. Other stores: `metrics`, `events`, `bizevents`, `dt.entity.*`.
`from: now()-1h` — scan start. `now()` = current wall clock time in the query engine. `-1h` = subtract 1 hour. Supports: `m` (minutes), `h` (hours), `d` (days), `w` (weeks), `M` (months).
`to: now()` — scan end. Can be omitted if you want from→now. Best practice: always include both.

Absolute time also works:
```dql
fetch logs, from: "2024-01-15T14:00:00Z", to: "2024-01-15T15:00:00Z"
```
Use absolute time during incident investigation when you know the exact time range.

#### `| filter status == "ERROR"`

The `|` pipe operator passes the output of the previous stage as input to this stage.
`filter` — keeps rows where the condition is true, drops all others.
`status == "ERROR"` — exact equality on an indexed field. DT maps log levels: ERROR/WARN/INFO/DEBUG/NONE. Stack trace lines (which don't have a level prefix) are usually mapped to ERROR if they follow an ERROR line.

Multiple filters with `|`:
```dql
| filter service.name == "payment-service"
| filter status == "ERROR"
```
These are applied as AND (both must be true). Order matters for performance: put the most selective filter first. `service.name` is usually more selective than `status` (eliminates more rows).

OR inside one filter:
```dql
| filter status == "ERROR" OR status == "WARN"
```

#### `| filter matchesPhrase(content, "OutOfMemoryError")`

`matchesPhrase(field, "text")` — uses the full-text inverted index on `content`.
How it works: Grail tokenizes the content field at ingestion time (splits on spaces, punctuation). "OutOfMemoryError" becomes tokens: ["OutOfMemoryError", "OutOfMemory", "MemoryError"]. `matchesPhrase` looks up the token in the index → returns all log lines containing it. O(log N) lookup, very fast.

`matchesValue(content, "*connection refused*")` — glob pattern. `*` = any characters. The leading `*` prevents index use → Grail must scan all matching rows' content sequentially. Slower than `matchesPhrase`. Use when you need partial matching that can't be a single phrase.

`content matches ".*NullPointerException.*"` — regular expression using the `matches` operator. Full sequential scan of the content column. Slowest option. Use only when regex is unavoidable (e.g., matching variable patterns like `"error code: [0-9]+"`)

**The right operator for each use case:**
- Exception class names: `matchesPhrase(content, "NullPointerException")` — always a whole token
- Error codes you know: `matchesPhrase(content, "PAYMENT_DECLINED")` — known string
- Partial user ID in log: `matchesValue(content, "*user-abc*")` — you don't know full string
- Log lines with a number pattern: `content matches ".*timeout after [0-9]+ms.*"` — regex last resort

#### `| summarize count = count(), by: { bin(timestamp, 5m) }`

`summarize` — the aggregation stage. Reduces many rows to fewer rows.
`count = count()` — counts all rows. `count =` assigns the result to a column named `count`.
`by: { bin(timestamp, 5m) }` — groups rows into time buckets. `bin(timestamp, 5m)` rounds each timestamp down to the nearest 5-minute boundary:
- 14:23:07 → 14:20:00
- 14:24:59 → 14:20:00
- 14:25:01 → 14:25:00

Result: one row per 5-minute window with the count of log lines in that window.

Multi-dimensional grouping:
```dql
| summarize count = count(), by: { bin(timestamp, 5m), service.name }
```
Result: one row per (5-min window, service) combination. Useful for stacked bar charts.

Multiple aggregations at once:
```dql
| summarize
    errors = countIf(status == "ERROR"),
    warns  = countIf(status == "WARN"),
    total  = count(),
    by: { bin(timestamp, 5m) }
```
`countIf(condition)` — counts only rows where condition is true. Single-pass over the data.

#### `| fieldsAdd error_rate = errors * 100.0 / total`

`fieldsAdd` — adds a new computed column to existing rows. Does not drop other columns.
`errors * 100.0 / total` — arithmetic expression. `100.0` (not `100`) forces floating-point division.

Difference from `fields`:
- `fields col1, col2` → keeps ONLY col1 and col2, drops everything else
- `fieldsAdd col3 = expr` → adds col3 while keeping all existing columns

#### `| parse content, "JSON:j"`

`parse content, "JSON:j"` — parses the `content` field as JSON and stores the result in a new variable `j`.

After this:
- `j.userId` → the `userId` field from the JSON object
- `j.errorCode` → the `errorCode` field
- `j.amount` → the `amount` field (number is preserved as number type)

Only works if the log line content IS valid JSON. If parsing fails (content is not JSON), the row is dropped from results. Use a conditional filter before parsing:
```dql
| filter matchesPhrase(content, '"event"')   ← only parse lines that look like events
| parse content, "JSON:j"
```

`fieldsAdd` after parse:
```dql
| parse content, "JSON:j"
| fieldsAdd userId = j.userId
| fieldsAdd errorCode = j.errorCode
```
Now `userId` and `errorCode` are top-level columns — easier to reference in subsequent stages.

#### `| filter isNotNull(dt.trace_id)`

`isNotNull(field)` — returns true only if the field exists AND is not null.
Why needed: not every log line is emitted inside a trace context. A log line written during application startup (before any HTTP request) has no trace_id. `isNotNull` filters out those lines, keeping only logs linked to a specific request.

#### `| sort timestamp desc`

`sort field desc` — descending order (newest first). Good for: "show me the latest errors."
`sort field asc` — ascending order (oldest first). Good for: "when exactly did this start?"

During incident investigation: always start with `sort timestamp asc | limit 50` to find the FIRST occurrence. Then switch to `desc` to see the most recent state.

#### `| limit 100`

Caps the number of rows returned. Without `limit`, DQL returns all rows (can be millions for a broad query). Always add `limit` for interactive queries. For aggregated queries, `limit` is applied AFTER aggregation — limits the number of summary rows (useful for "top N" queries).

---

### A4 — Log Ingestion Setup: Every Configuration Decision

#### `logMonitoring: enabled: true` in DynaKube

This single boolean activates the entire log pipeline on the cluster. What it triggers under the hood:

1. Dynatrace Operator reconfigures the OneAgent DaemonSet to include the log reader module
2. Each OneAgent pod on each node starts watching `/var/log/containers/*.log` via `inotify`
3. The ActiveGate is configured to accept and forward log payloads

Without this: OneAgent collects JVM metrics, HTTP metrics, DB call metrics — but ZERO log lines. The DT Logs UI shows empty.

#### Log ingest rules — why and how

Default behavior: ALL stdout from ALL containers is ingested. Problem at scale:

```
3 services × 3 replicas each = 9 pods
Each pod: 1,000 log lines/minute (INFO level)
DEBUG enabled: 5,000 log lines/minute per pod
Health checks: /actuator/health called every 5s × 9 pods = 108 health check logs/minute

Total without filtering: ~50,000 lines/minute
Grail cost at 1GB/day: significant

Total with filtering (exclude DEBUG + health checks): ~8,000 lines/minute
80% reduction. Same incident investigation capability.
```

Rule evaluation order: rules are evaluated top-to-bottom. First matching rule wins.
```
Rule 1: INCLUDE where status IN ("ERROR", "WARN")
  → Matches: any ERROR or WARN line from anywhere
  → Action: INCLUDE (ingested into Grail)

Rule 2: INCLUDE where namespace IN (app namespaces) AND status == "INFO"
  → Matches: INFO lines from our application services
  → Action: INCLUDE

Rule 3: EXCLUDE where status == "DEBUG"
  → Matches: any DEBUG line not already caught by rules 1-2
  → Action: EXCLUDE (dropped, never reaches Grail)

Rule 4: EXCLUDE where namespace == "kube-system" AND status == "INFO"
  → Matches: verbose system component INFO logs
  → Action: EXCLUDE

Final rule (implicit): INCLUDE everything else
  → WARN from kube-system included (rule 1 matched first)
  → ERROR from anywhere included (rule 1 matched first)
```

Key insight: put broad INCLUDE rules (ERROR/WARN) FIRST. They catch important logs before any EXCLUDE rule can drop them.

#### Log processing rules — field extraction at ingestion time

Why process at ingestion vs at query time:

**Query-time parsing** (in every DQL query):
```dql
fetch logs
| filter service.name == "payment-service"
| parse content, "JSON:j"
| filter j.errorCode == "DB_TIMEOUT"
```
`parse` runs on every query execution, on every matching row. If you run this query 100 times per day, it parses JSON 100× per log line.

**Ingestion-time processing** (configured once, runs once):
```
Log processing rule: for service.name == "payment-service"
  parse content, "JSON:j"
  fieldsAdd userId = j.userId
  fieldsAdd errorCode = j.errorCode
```
This runs ONCE when the log line arrives. `userId` and `errorCode` are stored as indexed fields in Grail. Every subsequent query can use:
```dql
| filter errorCode == "DB_TIMEOUT"   ← uses index, no parsing
```

This is 100-1000× faster for repeated queries during incidents. The trade-off: slightly higher ingest processing time (negligible).

---

### A5 — Log-Based Metric Events: Every Field Explained

#### The full Terraform resource

```hcl
resource "dynatrace_metric_events" "payment_oom" {
  enabled    = true
  event_type = "ERROR_EVENT"
  summary    = "[PROD] payment-service: OutOfMemoryError detected"
  description = "JVM ran out of heap. Pod will restart. Investigate heap usage."
  
  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    threshold          = 0
    violating_samples  = 1
    dealerting_samples = 1
  }
  
  query_definition {
    type       = "METRIC_KEY"
    metric_key = "log.payment.oom_error"
    resolution = "1m"
  }
}
```

`event_type = "ERROR_EVENT"` — this is the DT problem severity type. Maps to the alerting tier:
- `ERROR_EVENT` → AVAILABILITY or ERROR severity → PagerDuty (critical/high tier)
- `PERFORMANCE_EVENT` → SLOWDOWN severity → Slack warning tier
- `RESOURCE_CONTENTION_EVENT` → RESOURCE_CONTENTION → Slack info tier

`threshold = 0` — fires when count > 0 (ANY occurrence). This is intentional for OOM — any OOM is critical, not just if it happens more than N times. For noisy metrics, use `threshold = 5` to require sustained signal.

`violating_samples = 1` — how many consecutive 1-minute windows must exceed threshold before alert fires. For OOM: 1 is correct (fire on first occurrence). For CPU: use 5 (5 consecutive minutes of high CPU = real problem, not a burst).

`dealerting_samples = 1` — how many consecutive windows must be BELOW threshold before the alert closes. For OOM: 1 (if no new OOM in 1 minute, alert closes). For sustained issues: use 3 (requires 3 consecutive clean minutes before closing).

`alert_on_no_data = false` — for log-based metrics, "no data" means no matching log lines (which is the GOOD state). Set to false. (Contrast with traffic drop where `alert_on_no_data = true` because no data means service is completely down.)

`resolution = "1m"` — how often the metric is evaluated. 1m = DT checks the log metric count every minute. For infrequent events (like OOM), 1m is appropriate. For high-frequency events (error rate), 1m is also standard.

---

### A6 — Incident Investigation Workflows: Line by Line

#### Workflow 1: "High error rate"

**STEP 2: Find the first error — why `sort timestamp asc`**

```dql
fetch logs, from: 14:15, to: 14:40
| filter service.name == "payment-service"
| filter status == "ERROR"
| sort timestamp asc    ← critical: ASC shows OLDEST first
| limit 50
```

The instinct is to use `sort timestamp desc` (newest first, most familiar). But you need to answer: "when exactly did this START?" The first error in the result is the moment the problem began. The error message on that first line tells you WHAT went wrong first, before noise accumulates.

Practical example:
- `desc` shows: 1000 lines of "DB connection refused" (current errors)
- `asc` shows: the first line says "GatewayTimeoutException" — the REAL cause. DB errors came later because transactions timed out at the gateway, then the connection pool filled up.

**STEP 3: One pod vs all pods — why this matters**

```dql
| summarize count = count(), by: { k8s.pod.name }
| sort count desc
```

Result interpretation:
```
payment-service-7d9f8b-abc12: 1200 errors
payment-service-7d9f8b-def34: 2 errors (normal noise)
payment-service-7d9f8b-ghi56: 1 error (normal noise)
```
→ One pod (abc12) has almost all errors. The other two are fine.
→ This is a NODE-SPECIFIC issue: the node running abc12 has a problem.
→ Check: is that node's disk full? Is its ENI (network interface) hitting flow limits?
→ Fix: `kubectl drain <node>` → pod rescheduled elsewhere → errors stop.

```
payment-service-7d9f8b-abc12: 400 errors
payment-service-7d9f8b-def34: 398 errors
payment-service-7d9f8b-ghi56: 402 errors
```
→ All pods equally affected.
→ Shared infrastructure: database, network, or application code.
→ Check: distributed trace → is the PostgreSQL span failing on all requests?

#### Workflow 2: Memory leak investigation

**Why "gradual slope" vs "sudden jump" matters**

Gradual slope (heap grows 1% per hour over 7 days):
- Memory LEAK: objects are being created faster than GC can collect
- Usually caused by: caching without eviction, event listeners not removed, thread-local storage not cleared
- Fix: heap dump analysis (`jmap -dump:live,format=b,file=heap.hprof <pid>`)

Sudden jump (heap was 40%, now 85%, happened at 14:22):
- Configuration change or deploy introduced a large in-memory cache
- Fix: check what changed at 14:22 (gitops commit history)

**STEP 3: Cross-referencing heap time with log content**

```dql
| parse content, "JSON:j"
| summarize count = count(), by: { bin(timestamp, 5m), j.paymentType }
```

If results show:
```
14:20 RETAIL: 50, BATCH: 0
14:25 RETAIL: 48, BATCH: 0
14:30 RETAIL: 51, BATCH: 180   ← batch job kicked in
14:35 RETAIL: 49, BATCH: 220
14:40 RETAIL: 50, BATCH: 0
```
And heap spike was at 14:30 — BATCH is the culprit. The batch processor is holding payment objects in memory (maybe accumulating results for a report) without releasing them.

---

### A7 — Log Dashboards: Every Panel Explained

#### Panel 1: Error rate over time

```dql
| summarize
    errors = countIf(status == "ERROR"),
    total  = count(),
    by: { bin(timestamp, 5m) }
| fieldsAdd error_rate = errors * 100.0 / total
```

`countIf(status == "ERROR")` counts ERROR lines.
`count()` counts ALL lines.
`errors * 100.0 / total` — why `100.0` not `100`? Integer division: `5 / 100 = 0` in integer math. `5 * 100.0 / 100 = 5.0` in floating point.

This panel shows: "what fraction of all log lines are errors?" This is a PROXY for error rate (not the same as the HTTP error rate from DT service metrics). Useful for: detecting log storms (total count spikes) vs actual error rate increases.

#### Panel 5: Log volume trend (anomaly detection)

```dql
| summarize count = count(), by: { bin(timestamp, 1h) }
```

Why `1h` resolution? For a 7-day view, 1h gives 168 data points (readable line chart). 5m would give 2,016 points (noisy). 1d would give 7 points (misses intra-day patterns).

**Log volume anomalies and what they mean:**

Spike to 10× normal:
- Verbose logging accidentally enabled (e.g., log4j level changed from INFO to DEBUG)
- Exception loop: an exception is thrown 10,000 times per minute instead of being handled
- Health check logging not excluded

Drop to zero:
- Log ingestion pipeline broken (ActiveGate down, network issue)
- Service stopped entirely
- All pods in CrashLoopBackOff (before they can write logs)

---

### A8 — Integration: Logs + Traces + Metrics Deep Dive

#### The HikariCP connection pool incident

This is the most important part of Part 8 — understanding how multiple signals converge:

```
LOGS say: "Connection pool exhausted" — started at 14:22
TRACES say: payment-service spans are timing out on DB calls (70ms where 5ms was normal)
METRICS say: HikariCP "pending threads" jumped from 0 to 15 at 14:22
```

Three different signals pointing to the SAME root cause: the thread pool grew from 10 to 15 (deploy changed thread pool config), but HikariCP pool stayed at 10. Result: 5 threads always waiting → every request that hits those threads must wait for a connection → latency increases → timeouts → errors.

Without the three-signal correlation:
- Logs alone: "Connection pool exhausted" — tells you WHAT but not WHY
- Traces alone: "DB call slow" — could be DB issue, not pool issue
- Metrics alone: high pending connections — confirms it's pool-related but not why pool is full

With correlation: deploy + thread config → pool exhausted → timeouts → errors. Unambiguous root cause.

#### Why `| sort timestamp asc` for pod restart correlation

```dql
| summarize error_count = count(), by: { bin(timestamp, 5m), k8s.pod.name }
```

If you see:
```
14:20 abc12: 0 errors
14:22 abc12: 350 errors    ← surge in errors
14:25 abc12: 0 errors      ← errors stopped (pod restarted, new pod started clean)
14:25 abc12-new: 0 errors
```

The error surge and then clean stop → pod was restarted. During the restart, a third of requests hit the dying pod (which was overloaded) → errors. After restart, new pod starts fresh → errors stop.

The readinessProbe diagnosis: if the pod shows errors and then restarts, but the readinessProbe should have removed it from service endpoints BEFORE it started failing — this means either the readinessProbe period is too slow, or the liveness probe is killing the pod faster than readiness removes it from the load balancer.

---

### A9 — Log-Based SLIs: Why They're More Accurate

**The critical distinction:**

HTTP SLI:
```
200 OK: {"status": "failed", "reason": "insufficient_funds"}
→ HTTP layer: SUCCESS (200)
→ Business layer: FAILURE (payment rejected)
```

Log-based SLI:
```dql
| filter matchesPhrase(content, '"event":"payment_attempt"')
| parse content, "JSON:j"
| summarize
    total   = count(),
    success = countIf(j.result == "SUCCESS"),
    failed  = countIf(j.result == "FAILED")
```
→ Counts actual business outcomes regardless of HTTP status code.

A payment service that returns 200 for every request but the business logic rejects 30% of payments — HTTP SLI says 100% success, Business SLI says 70% success. One of these is honest.

**When to use which:**
- User-facing reliability (did the HTTP request succeed?): use HTTP SLI
- Business outcomes (did the payment complete?): use log-based SLI
- Payment services: use BOTH, with the log-based SLI as the primary

**The formula explained:**
```dql
| fieldsAdd error_budget_used_pct = (100.0 - success_rate) / (100.0 - 99.9) * 100
```
- `100.0 - success_rate` = actual failure rate (e.g., 0.15% if success_rate=99.85%)
- `100.0 - 99.9` = allowed failure rate at SLO (0.1%)
- Division: `0.15 / 0.1 = 1.5` = consuming budget at 1.5× the allowed rate
- `× 100` = express as percentage: 150% of budget consumed
- Interpretation: if this returns > 100, the SLO is already breached for the period

---

## SECTION B: SRE COLLABORATION

---

### B1 — Decision Tree: Who Owns What

**Why the ownership split matters:**

SRE owns PLATFORM config (things that affect all services equally):
- Management zones: scope which team sees which entities
- Alerting profiles: 4-tier delay structure applied to all teams
- Notification routing: PagerDuty + Slack wiring
- Terraform Dynatrace module: the shared logic that creates all DT resources

Engineering owns SERVICE-LEVEL config (things specific to their service):
- Custom business metrics (batch.payment.completed)
- JSON log field schema (which fields to include in structured logs)
- Health check implementation (what /actuator/health/readiness checks)
- DT dashboard for their own service

Why engineers own their dashboard: if SRE owns it, they don't know the domain. "Batch job queue depth" means nothing to SRE, but engineering knows it should never exceed 10,000. They set the scale on their own chart.

Why SRE owns alerting profiles: if engineering owns them, each team sets different delay values, different tier names, different Slack channels → no consistent on-call experience → confusion during multi-service incidents.

---

### B2 — E2E Flow: Observability Built Together

**The 5 SRE sprint questions — why each one:**

1. "What does success look like?"
   - Gets a measurable SLO target before coding starts
   - "95% of batch jobs complete in < 5 min" → SLO: 95.0%, latency: 300,000μs
   - Without this: after launch you discover no threshold was agreed → every engineer has a different opinion → alert threshold debate during incident

2. "What can fail?"
   - Forces engineering to think about failure modes before writing code
   - "DB timeouts" → add circuit breaker. "Memory pressure" → add heap alert. "Gateway down" → add fallback
   - Without this: failure mode discovered in production during an incident

3. "How will we know it's failing?"
   - Defines the instrumentation requirements
   - "Error count in log + batch_job_failed metric" → SRE knows what to alert on
   - Without this: SRE creates a metric event for `batch_job_failed` that never fires because engineering named it `batch.job.error`

4. "Who gets paged when it fails?"
   - Defines alert ownership BEFORE the alert exists
   - "payments oncall, not platform team" → management zone + notification routing configured correctly
   - Without this: platform oncall gets woken up for a payments feature they've never seen

5. "What is the rollback plan?"
   - Forces a rollback conversation before launch
   - "disable batch feature flag, drain queue" → both teams know the procedure
   - Without this: incident happens → "how do we roll back?" → 30 minutes of debate

**The code → DT automatic path:**

```java
meterRegistry.counter("batch.payment.completed").increment();
```
This code in Spring Boot automatically:
1. Registers the metric with Micrometer's `MeterRegistry`
2. Spring Boot Actuator exposes it at `/actuator/metrics/batch.payment.completed`
3. Dynatrace OneAgent scrapes `/actuator/metrics` every 60 seconds
4. Metric appears in DT as `batch.payment.completed`
5. SRE creates metric event on `batch.payment.completed`
6. Grail stores the metric time series

No manual DT UI configuration needed to SEE the metric — just the code + OneAgent.

---

### B3 — Teaching Structured Logging: The Transformation

**BEFORE — what engineers write naturally:**
```java
log.error("Database error for user " + userId + ": " + e.getMessage());
```

What this produces in DT Grail:
```
content: "Database error for user user-abc123: Connection refused"
status: "ERROR"
```

The problem: every unique userId creates a unique log message. If 1,000 users get the error, there are 1,000 different `content` values. The `summarize count, by: { content }` query returns 1,000 rows instead of 1 row. You can't tell "how many users got DB errors" from the summary view.

**AFTER — structured logging:**
```java
log.error("Database error",
  StructuredArguments.keyValue("userId", userId),
  StructuredArguments.keyValue("errorType", "DB_CONNECTION"),
  StructuredArguments.keyValue("operation", "getPaymentHistory"),
  e);
```

JSON output via logstash-logback-encoder:
```json
{
  "level": "ERROR",
  "message": "Database error",
  "userId": "user-abc123",
  "errorType": "DB_CONNECTION",
  "operation": "getPaymentHistory",
  "stack_trace": "org.springframework.dao..."
}
```

Now:
```dql
| parse content, "JSON:j"
| summarize count = count(), by: { j.errorType, j.operation }
```
Returns:
```
DB_CONNECTION + getPaymentHistory: 1,247
DB_CONNECTION + createPayment: 23
GATEWAY_ERROR + createPayment: 7
```
One query answers "which operations are failing and why" across all users, all pods, all time.

**Why logstash-logback-encoder (not custom code):**

Option A: custom JSON formatter per service
```java
log.error("{\"level\":\"ERROR\",\"message\":\"DB error\",\"userId\":\"" + userId + "\"}");
```
Problems: string concatenation is error-prone, no stack trace formatting, no MDC propagation, no timestamp standardization.

Option B: logstash-logback-encoder
```xml
<encoder class="net.logstash.logback.encoder.LogstashEncoder" />
```
Automatically provides:
- ISO8601 timestamp
- Log level mapped to `level` field
- `message` field
- MDC fields (including `dt.trace_id` injected by OTEL)
- Exception with `stack_trace` field
- Custom fields via `StructuredArguments.keyValue()`

One config line in `logback-spring.xml` + one `build.gradle` dependency → all logs JSON forever, across all services, consistently.

---

### B4 — Custom Metrics: Micrometer Deep Dive

**Counter vs Gauge — which to use and why:**

```java
Counter completedCounter = Counter.builder("batch.payment.completed")
    .register(registry);
completedCounter.increment();   // called each time a payment completes
```

Counter: monotonically increasing (goes up, never down). Used for: counting events that happen.
DT computes the RATE automatically: (current value - previous value) / time interval.
So `batch.payment.completed` = raw count, but DT shows `per minute` rate.

```java
Gauge queueDepthGauge = Gauge.builder("batch.payment.queue_depth",
        queue, BatchQueue::size)
    .register(registry);
```

Gauge: current state (can go up or down). Used for: measuring current quantity.
The lambda `BatchQueue::size` is called by Micrometer every scrape to get the current value.
DT shows the raw value (not rate). Useful for: queue depth, connection count, cache size.

**Tagging failure reasons — why this is critical:**

```java
registry.counter("batch.payment.failed", "reason", "DB_TIMEOUT").increment();
registry.counter("batch.payment.failed", "reason", "GATEWAY_ERROR").increment();
```

Without tags: `batch.payment.failed` goes from 0 to 100. Is it DB? Gateway? Bad input? Unknown.

With tags: DT stores separate time series for each `reason` value:
- `batch.payment.failed{reason="DB_TIMEOUT"}` = 80
- `batch.payment.failed{reason="GATEWAY_ERROR"}` = 20

DT metric event can filter: `filter(eq(reason,DB_TIMEOUT))` → alert only on DB failures.
Different alert thresholds per reason: DB timeouts = page immediately; Gateway errors = Slack warning.

This is the difference between "something is failing" and "specifically the database connection is failing 80 times per minute."

---

### B5 — Alert Notification Automation: Every Field

**The DT webhook payload template:**
```json
{
  "routing_key": "${var.pagerduty_key}",
  "payload": {
    "summary": "[${environment}] {ImpactedEntities[0].name}: {ProblemTitle}",
    "custom_details": {
      "dql_query": "fetch logs,from:now()-30m | filter service.name==\"{ImpactedEntities[0].name}\" | filter status==\"ERROR\" | limit 20"
    }
  }
}
```

`{ImpactedEntities[0].name}` — DT template variable. Replaced at notification send time with the name of the first affected entity (e.g., "payment-service"). DT supports 20+ template variables including:
- `{ProblemTitle}` — the problem title ("High error rate")
- `{ProblemURL}` — direct link to the problem in DT UI
- `{ProblemSeverity}` — AVAILABILITY, ERROR, SLOWDOWN, RESOURCE_CONTENTION
- `{State}` — OPEN or RESOLVED

The DQL query embedded in the notification:
```
fetch logs,from:now()-30m | filter service.name=="payment-service" | filter status=="ERROR" | limit 20
```
This is a pre-built query. The on-call engineer copies it, pastes into DT → Logs, and immediately sees the 20 most recent errors. No navigation, no query writing at 2am.

The `kubectl` commands embedded:
```
kubectl logs -n payment-ns -l app=payment-service --tail=50 --since=10m
kubectl get pods -n payment-ns
```
These are non-DT fallbacks. If DT is down or slow, the engineer can still get recent logs from Kubernetes directly. This matters for the "DT itself has an outage" scenario.

**Why this reduces MTTD2 from 45 minutes to 8 minutes:**

BEFORE enriched notification:
1. PagerDuty fires → engineer wakes up (5 min)
2. Open DT → navigate to service → find the error analysis (5 min)
3. Find which endpoint is failing (3 min)
4. Navigate to logs → write DQL query (5 min)
5. Read stack traces to understand root cause (15 min)
6. Find distributed trace (5 min)
Total: ~38 minutes to root cause understanding

AFTER enriched notification:
1. PagerDuty fires with direct DT link + pre-built DQL + kubectl command (5 min)
2. Click DT problem link → see affected entity, start time, related deploy (1 min)
3. Click DQL link → copy-paste into DT Logs → see top 20 errors (1 min)
4. Click trace_id → see distributed trace, identify failing DB call (2 min)
5. Click "Logs" on span → see exact error message with context (1 min)
Total: ~10 minutes to root cause

The same information was available before. The automation removes the 30 minutes of navigation overhead.

---

### B6 — Post-Deploy Verification: Every Step

**Why `sleep 60` for JVM warmup:**
```yaml
- name: Wait for JVM warmup
  run: sleep 60
```

JVM JIT (Just-In-Time) compilation runs for 30-90 seconds after startup. During this:
- Hot code paths are being profiled and compiled to native machine code
- Before compilation: code runs in interpreted mode → 5-10× slower than compiled
- Before compilation: error rates appear elevated (timeouts on slow interpreted paths)

Without sleep 60: DT SLO check runs after 10 seconds. JVM is still interpreting. Response times are 3× normal. Error rate might be 2% (timeout errors). SLO check fails. Auto-rollback triggers. But the deploy was GOOD — JVM just hadn't warmed up.

With sleep 60: JIT completes. Response times are at steady state. SLO check runs. Accurate result.

**DT API query for SLO status:**
```bash
curl -H "Authorization: Api-Token $DT_API_TOKEN" \
  "$DT_URL/api/v2/slo?sloSelector=name(\"payment-service Availability [production]\")"
```

`sloSelector=name("...")` — filters SLOs by exact name. The name must match the `name` field in the `dynatrace_slo_v2` Terraform resource exactly (including the `[production]` suffix).

Response:
```json
{
  "slo": [{
    "name": "payment-service Availability [production]",
    "status": "SUCCESS",       ← or "WARNING" or "FAILURE"
    "errorBudget": 82.3,       ← % of monthly budget remaining
    "evaluatedPercentage": 99.93
  }]
}
```

`status: "SUCCESS"` = SLO target met.
`status: "WARNING"` = between warning threshold and target (e.g., 99.8-99.9%).
`status: "FAILURE"` = below target (< 99.9%) — SLO is breached.

**DT Metrics API for error rate:**
```bash
$DT_URL/api/v2/metrics/query?metricSelector=builtin:service.errors.server.rate:filter(eq(service.name,payment-service)):max&resolution=5m&from=now-5m
```

Breaking this down:
- `builtin:service.errors.server.rate` — the DT built-in metric for HTTP server error rate
- `:filter(eq(service.name,payment-service))` — filter to only this service
- `:max` — take the maximum value in the time range (conservative: catches any spike)
- `resolution=5m` — aggregate into 5-minute buckets
- `from=now-5m` — only look at the last 5 minutes

Why `:max` not `:avg`? A 5-second spike to 10% error rate averaged over 5 minutes = 0.3% error rate average. We'd miss the spike. `:max` returns 10% and the threshold triggers correctly.

**Auto-rollback git commands explained:**
```bash
PREV_TAG=$(git log --oneline -- \
  gitops/production/app/payment-service/payment-service.yaml \
  | awk 'NR==2{print $1}' | xargs git show | grep 'tag:' | head -1 \
  | awk -F'"' '{print $2}')
```

`git log --oneline -- <file>` — commit history for ONE file only. Each line: `sha1234 message`.
`awk 'NR==2{print $1}'` — NR=2 = second row = previous commit SHA.
`xargs git show` — gets the file content at that commit.
`grep 'tag:' | head -1` — finds the image tag line.
`awk -F'"' '{print $2}'` — extracts the value between the first two quotes.

Then:
```bash
sed -i "s|tag: \".*\"|tag: \"$PREV_TAG\"|" \
  gitops/production/app/payment-service/payment-service.yaml
git add . && git commit -m "chore(rollback): revert to $PREV_TAG [skip ci]"
git push
```
ArgoCD watches this file. The new commit changes the tag to the previous good SHA. ArgoCD detects the diff → applies it → Kubernetes rolling update back to old image. No kubectl commands needed. Git is the source of truth.

---

### B7 — Observability as Code: Why Terraform Beats DT UI

**The audit trail problem:**

DT UI change (no record):
```
14:22: SRE lowered latency threshold from 300ms to 150ms during incident (panic decision)
14:45: Incident resolved
15:00: SRE forgets to revert threshold
Next week: 150ms threshold fires constantly on every minor traffic spike
Engineers tune out all latency alerts
Month later: real performance regression — nobody notices because alerts are ignored
```

Terraform change (full record):
```
git log --follow terraform/environments/production/main.tf

commit abc123 — "Fix: lower latency threshold to 150ms during incident"
  Author: sre-engineer@company.com
  Date: 2024-01-15 14:22 JST
  
  REVERT this after incident resolved
```

Git blame shows WHEN, WHO, WHY. The `REVERT this` note in the commit message reminds the next person.

**The drift detection workflow:**

```
Monday 9am: GitHub Actions runs terraform plan on production
terraform plan output:
  ~ dynatrace_metric_events.latency_p99["payment-service"]
    ~ model_properties.threshold: 300000 → 150000 (changed in DT UI)
  
  Plan: 1 to change.
```

This diff appears in the Slack #sre-alerts channel:
```
⚠️ Dynatrace config drift detected.
Change: payment-service latency threshold changed from 300ms to 150ms in DT UI.
Action required: either update Terraform to match, or run terraform apply to revert.
```

SRE reviews: this was the emergency change. Decision: revert to 300ms (correct threshold). Run `terraform apply`. DT config matches Terraform again. Drift resolved.

---

### B8 — Anti-Patterns: Every Root Cause

**Anti-pattern 1: "SRE owns all observability"**

The failure mode: SRE creates a management zone for `payment-service`. SRE sets thresholds based on what they think is normal. SRE writes the runbook. But SRE doesn't know:
- "Our batch job runs at 2am and uses 80% CPU for 10 minutes — that's normal"
- "Error rate of 0.5% is acceptable for the idempotency retry path"
- "The queue depth alert should fire at 10,000 not 1,000"

Without this domain knowledge: SRE sets thresholds that fire on normal behavior → alert fatigue.
With engineering ownership: engineers set thresholds they understand → alerts fire on actual problems.

**Anti-pattern 2: "Alert on everything, tune later"**

The psychology of alert fatigue:

Week 1: 50 alerts fire. All taken seriously. Some are real (10), most are noise (40).
Week 2: 50 alerts fire. Engineer starts skimming — "probably noise again."
Week 3: 50 alerts fire. Engineer glances at severity. "Not P1, skip."
Week 6: Real P1 fires among 50 alerts. Engineer treats it like noise. Doesn't investigate for 30 minutes. Significant downtime.

Fix: start with 3 alerts per service — traffic, errors, latency. When those 3 are well-tuned (< 10% noise) and drive real action, add 2 more. Never add an alert that doesn't have a defined action in the runbook.

**Anti-pattern 5: "Automate everything immediately"**

The false positive problem: auto-rollback keyed on metric threshold:

```yaml
- name: Check error rate
  run: |
    if (( $(echo "$ERROR_RATE > 0.5" | bc -l) )); then
      # auto-rollback
```

Deploy happens → JVM warmup → 90 seconds of elevated error rate (timeouts on cold interpreted paths) → 0.6% error rate → auto-rollback triggers → good deploy reverted.

30 minutes of confusion: "why did the rollback trigger?" "Was the deploy bad?" "Is the code still broken?" Engineers manually redeploy → JVM warms up → no errors → correct.

Fix: auto-rollback only on SMOKE TEST FAILURE (explicit business logic check), never on metric thresholds (which have many legitimate transient causes).

---

### B9 — Measuring Success: Every Metric Explained

**MTTD calculation:**
```
DT Problem start time:  14:23:07 (when DT detected the anomaly)
PagerDuty alert time:   14:25:15 (when notification was sent)
MTTD = 25:15 - 23:07 = 2 minutes 8 seconds
```

`start time` is determined by DT internally when the metric threshold is first violated for `violating_samples` consecutive periods. With `violating_samples = 3` and `resolution = 1m`: problem detected 3 minutes after the REAL start. The "DT Problem start time" is already 3 minutes after the true start.

True MTTD = 3 min (DT detection delay) + 2 min (notification delay) = 5 min total.

To reduce DT detection delay: lower `violating_samples` to 1 (but increases false positives). Use `violating_samples = 3` for high-noise signals, `1` for binary signals (OOM, service down).

**Alert noise ratio calculation:**
```
DT Problems last 30 days: 150 total
  - 120 "auto-resolved" within 5 minutes (likely transient noise)
  - 30 required human action (real incidents)

Alert noise ratio: 120 / 150 × 100% = 80% noise

Goal: < 10% noise
Actions needed:
  - Raise latency threshold (most auto-resolved = latency spikes during load)
  - Increase violating_samples for CPU (CPU bursts are normal)
  - Add deploy event correlation (many alerts = deploy artifacts)
```

**Failed deploy recovery time — end-to-end:**
```
14:22:00 — Deploy completes (gitops tag updated)
14:23:07 — First ERROR log line (from DT perspective: T+67s)
14:23:07 — Log metric fires (violating_samples=1)
14:23:07 — Smoke test job starts (in CI, runs after 60s warmup = starts at 14:23:07)
14:24:10 — Smoke test fails (HTTP check returns error)
14:24:10 — Auto-rollback starts (git operations take ~15 seconds)
14:24:25 — Rollback commit pushed to main
14:24:28 — ArgoCD detects new commit (webhook → ~3 second delay)
14:24:28 — Kubernetes rolling update starts
14:27:00 — New (old) pods are running and passing readiness probes
14:27:00 — Traffic fully shifted to old image

Total recovery time: 14:27 - 14:22 = 5 minutes
Goal achieved: < 5 minutes
```

Without automation:
```
14:22 — Deploy
14:23 — Errors start
14:28 — PagerDuty fires (2-min delay + detection time)
14:38 — On-call engineer wakes up and acknowledges (10 min wake time)
14:45 — Engineer diagnoses root cause as deploy (7 min in DT)
14:47 — Engineer manually reverts gitops tag and pushes
14:50 — ArgoCD deploys old image
14:52 — Traffic shifted to old image
Total: 30 minutes
```

Auto-rollback reduces recovery time by 6×.

---

### B10 — Concrete Automation Examples: Line by Line

#### Slack bot Lambda

```python
dql = f"""
    fetch logs, from: now()-{window}
    | filter service.name == "{service}"
    | filter status == "ERROR"
    | summarize count = count(), by: {{ content }}
    | sort count desc
    | limit 10
"""
```

`f"""..."""` — Python f-string. `{window}` and `{service}` are Python variables injected at runtime. `{{ content }}` — double braces escape the literal `{` in DQL (since `{...}` is Python f-string syntax).

```python
response = requests.post(
    f"{DT_URL}/platform/storage/query/v1/query:execute",
    headers={"Authorization": f"Api-Token {DT_TOKEN}"},
    json={"query": dql}
)
```

`/platform/storage/query/v1/query:execute` — the Grail query API endpoint. Different from the older `/api/v2/` endpoints. Returns `{"records": [...]}` with the query results.

Why Lambda: Slack slash commands require a response within 3 seconds. A Lambda function cold starts in ~200ms and the DT API call takes ~1-2 seconds. Total: under 3 seconds. If you used an EC2 instance: provisioning + authentication takes longer.

#### Deploy event injection

```bash
curl -X POST \
  -H "Authorization: Api-Token ${{ secrets.DT_API_TOKEN }}" \
  -H "Content-Type: application/json" \
  "${{ secrets.DT_URL }}/api/v2/events/ingest" \
  --data '{
    "eventType": "CUSTOM_DEPLOYMENT",
    "entitySelector": "type(SERVICE),entityName(payment-service)",
    ...
  }'
```

`entitySelector: "type(SERVICE),entityName(payment-service)"` — tells DT which entity to attach this event to. `type(SERVICE)` = DT service entities (not process groups or hosts). `entityName(payment-service)` = the service entity named exactly "payment-service" (must match `OTEL_SERVICE_NAME`).

What happens in DT Problem timeline:
1. DT stores the deployment event linked to the service entity
2. When a problem is created for that service, DT checks: any deployment events in the last 1 hour?
3. Yes: "Deploy at 14:22" marker appears on the timeline
4. Davis AI calculates: problem started 1 minute after deployment → "Deployment likely contributed to this problem"

This `entitySelector` is the only connection between CI/CD and DT. If `OTEL_SERVICE_NAME = "payment-service"` but `entityName("Payment Service")` (capital P, space) → event attaches to wrong entity → no timeline correlation.
