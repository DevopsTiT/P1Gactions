# Phase 5 — CI/CD Pipelines Deep Dive

> The GitHub Actions pipelines automate everything from a code push to a verified production deployment. This phase traces every job in `payment-service-ci.yaml` line by line, explains why each job is structured the way it is, and covers the auto-rollback mechanism.

---

## Pipeline Trigger

```yaml
on:
  push:
    branches: [main]
    paths:
      - 'services/payment-service/**'
      - 'charts/payment-service/**'
  pull_request:
    branches: [main]
    paths:
      - 'services/payment-service/**'
      - 'charts/payment-service/**'
```

**`paths:` filter — why it matters:**
Without `paths:`, every commit to main triggers all three service pipelines — even a README change triggers the payment-service CI, order-service CI, and notification-service CI simultaneously. This wastes 15-20 minutes of CI time and ECR storage on builds that changed nothing.

With `paths:`: a change to `services/notification-service/` only triggers `notification-service-ci.yaml`. The other two pipelines are skipped entirely.

**`on.pull_request:`**
On a PR, the pipeline runs the `test` job only (because `build-and-deploy-dev` has `if: github.event_name == 'push'`). You get test results before merging — PRs can't merge if tests fail.

---

## Global Environment Variables

```yaml
env:
  AWS_REGION:     ap-northeast-1
  IMAGE_TAG:      ${{ github.sha }}          # ← the 40-char git commit SHA
  JAVA_VERSION:   '21'
  SERVICE:        payment-service
  ECR_DEV:        123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  ECR_STAGING:    123456789011.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  ECR_PRODUCTION: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
```

**`IMAGE_TAG: ${{ github.sha }}`**
The git SHA is the perfect image tag:
- Unique per commit — no two commits share the same SHA
- Immutable — the SHA identifies exactly what code is in the image
- Traceable — `git show abc1234` shows the exact diff in that image
- No "latest" ambiguity — `latest` changes meaning with every push

**ECR URLs per account:**
Three ECR registries, one per AWS account. The image SHA travels through all three — the same binary that passed dev tests is what runs in production. No rebuild between environments.

---

## JOB 1: test — Unit Tests + Coverage

```yaml
test:
  runs-on: ubuntu-latest
  steps:
    - uses: actions/checkout@v4
    - uses: actions/setup-java@v4
      with: { java-version: '21', distribution: 'temurin', cache: 'gradle' }
    - uses: actions/cache@v4
      with:
        path: services/payment-service/.gradle
        key: ${{ runner.os }}-gradle-payment-${{ hashFiles('services/payment-service/build.gradle') }}
    - name: Run tests + coverage
      working-directory: services/payment-service
      run: ./gradlew test jacocoTestReport jacocoTestCoverageVerification --no-daemon
    - uses: mikepenz/action-junit-report@v4
      if: always()
      with:
        report_paths: 'services/payment-service/build/test-results/test/*.xml'
```

**`actions/cache@v4` for Gradle:**
The cache key includes `hashFiles('build.gradle')`. This means:
- Same `build.gradle` → restore cached Gradle dependencies → no re-download (~500MB, saves 2-3 min)
- `build.gradle` changed (new dependency) → cache miss → download fresh

**`jacocoTestCoverageVerification`:**
This Gradle task reads the JaCoCo coverage report and FAILS the build if any coverage metric is below the configured threshold (≥70% line coverage). This enforced in CI means no code can reach production without being tested.

**`if: always()` on the JUnit report:**
Even if tests fail (step returns non-zero exit code), the JUnit XML report is still uploaded to GitHub. Developers can see which specific tests failed in the GitHub PR UI without downloading log files.

**Why no Docker build in this job:**
Building a Docker image takes 2-5 minutes. Tests take 1-3 minutes. Running them separately means: if tests fail, CI aborts immediately without wasting 5 minutes building an image that would never be used. Fast feedback.

---

## JOB 2: build-and-deploy-dev

```yaml
build-and-deploy-dev:
  needs: test                        # ← only runs after test passes
  if: github.event_name == 'push'    # ← skip on PRs (only deploy on main push)
  environment: dev
  permissions:
    id-token: write                  # required for OIDC token to assume AWS role
    contents: write                  # required to git push gitops update
```

### Step: OIDC authentication to AWS
```yaml
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789010:role/github-actions-ecr-push
    aws-region: ap-northeast-1
```

This is OIDC — no stored credentials. GitHub gets a JWT token from its identity provider, exchanges it with AWS STS for temporary credentials scoped to the `ecr-push` role. The temporary credentials expire after the job completes.

### Step: Multi-platform Docker build
```yaml
- uses: docker/setup-buildx-action@v3
- uses: docker/build-push-action@v5
  with:
    context: services/payment-service/
    push: true
    platforms: linux/amd64,linux/arm64    # ← builds for BOTH architectures
    tags: |
      ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
      ${{ env.ECR_DEV }}:latest-dev
    cache-from: type=gha
    cache-to: type=gha,mode=max
```

**`platforms: linux/amd64,linux/arm64`:**
AWS offers both x86 (amd64) and ARM (arm64, Graviton) EC2 instances. ARM instances are ~20% cheaper and often faster for Java workloads. Building both architectures means the image can run on either without modification.

**`cache-from/cache-to: type=gha`:**
GitHub Actions build cache. Docker layers that haven't changed (JRE base image, dependency JARs) are cached. Only changed layers (new source code) are rebuilt. A typical incremental build: ~30 seconds instead of ~4 minutes.

### The Dockerfile being built:
```dockerfile
FROM eclipse-temurin:21-jdk-alpine AS builder    # stage 1: full JDK for compilation
WORKDIR /app
COPY build.gradle settings.gradle ./
COPY src ./src
RUN ./gradlew bootJar --no-daemon                 # compiles, tests, packages JAR

FROM eclipse-temurin:21-jre-alpine               # stage 2: JRE only (smaller, no compiler)
WORKDIR /app
COPY --from=builder /app/build/libs/*.jar app.jar
EXPOSE 8080
ENTRYPOINT ["sh", "-c", "java $JVM_OPTS -jar app.jar"]
```

**Multi-stage build:**
Stage 1 (JDK) includes the Java compiler, Gradle, source code, build cache — total size ~500MB.
Stage 2 (JRE) includes only the runtime and the compiled JAR — total size ~150MB.

Final image = stage 2 only. The JDK, source code, and build artifacts are discarded. This matters because:
- Smaller attack surface (no compiler = can't compile malware inside the container)
- Faster image pulls (150MB vs 500MB)
- Less storage cost in ECR

**`$JVM_OPTS` in the entrypoint:**
The JVM flags are NOT hardcoded in the Dockerfile. They come from the `JVM_OPTS` environment variable, which is set per-environment in the Helm values:
```
dev:        -Xms128m -Xmx256m -XX:+UseContainerSupport -agentlib:jdwp=...
staging:    -Xms256m -Xmx512m -XX:+UseContainerSupport
production: -Xms512m -Xmx1024m -XX:+UseContainerSupport -XX:MaxGCPauseMillis=200 -XX:+UseG1GC
```

One image, different JVM tuning per environment.

### Step: Trivy vulnerability scan
```yaml
- uses: aquasecurity/trivy-action@master
  with:
    image-ref: ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
    severity: 'CRITICAL,HIGH'
    exit-code: '1'
    ignore-unfixed: true
```

**`ignore-unfixed: true`:**
Only fails if a CRITICAL/HIGH CVE has a published fix available. If a CVE exists but no patched version of the dependency is released yet, Trivy notes it but doesn't fail the build. Without this, you could be blocked forever on a CVE that has no fix — not actionable.

**`exit-code: '1'`:**
If any CRITICAL or HIGH CVE is found (with a fix available), Trivy exits with code 1 → GitHub Actions marks the step failed → the image is never deployed to any environment.

### Step: Update gitops tag
```yaml
- name: Update dev gitops tag
  run: |
    sed -i "s|tag: \".*\"|tag: \"${{ env.IMAGE_TAG }}\"|" \
      gitops/dev/app/payment-service/payment-service.yaml
    git config user.email "github-actions[bot]@users.noreply.github.com"
    git config user.name  "github-actions[bot]"
    git add gitops/dev/app/payment-service/payment-service.yaml
    git diff --staged --quiet || \
      git commit -m "chore(deploy-dev): payment-service=${{ env.IMAGE_TAG }} [skip ci]"
    git push
```

**`sed -i "s|tag: \".*\"|tag: \"$IMAGE_TAG\"|"`:**
Replaces the current tag in the ArgoCD Application YAML with the new SHA. The YAML line changes from:
```yaml
tag: "abc1234"    →    tag: "def5678"
```

**`git diff --staged --quiet ||`:**
If the image tag didn't change (re-running CI on the same commit), `git diff --staged --quiet` exits 0 (no diff). The `||` means: only run `git commit` if there IS a diff. Prevents empty commits.

**`[skip ci]` in commit message:**
Without `[skip ci]`, pushing this commit triggers the pipeline again → which builds the same image → updates the same tag → commits `[skip ci]`... wait, it DOES have `[skip ci]`. Without it, the loop would be: push code → CI builds → CI commits tag update → THAT commit triggers CI again → CI builds again (same SHA, no change) → CI commits tag update (no diff, no commit) → done. The `[skip ci]` breaks the loop on the first iteration.

### Step: Wait for rollout
```yaml
- name: Wait for dev rollout
  run: |
    sleep 30
    aws eks update-kubeconfig --name company-dev ...
    kubectl rollout status deployment/payment-service -n payment-ns --context dev --timeout=8m
```

**`sleep 30`:**
ArgoCD polls git every ~3 minutes. After the git push, ArgoCD needs ~30 seconds to detect the change, render the Helm chart, and start the rolling update. Starting `rollout status` immediately would see the OLD rollout (already complete) and return success instantly — even though the new image isn't deployed yet.

**`kubectl rollout status --timeout=8m`:**
Waits until the rolling update completes. Returns exit code 1 (failure) if the deployment hasn't finished within 8 minutes. This covers: image pull time, JVM startup, startupProbe passing. If a new image is broken (fails startupProbe), `rollout status` hangs → times out → CI marks the job failed → smoke test never runs → nothing broken reaches staging.

---

## JOB 3: smoke-test-dev

```yaml
smoke-test-dev:
  needs: build-and-deploy-dev
  steps:
    - name: Health + API smoke tests
      run: |
        curl -sf https://payment.dev.company.com/actuator/health/liveness  || exit 1
        curl -sf https://payment.dev.company.com/actuator/health/readiness || exit 1
        RESPONSE=$(curl -sf -X POST \
          -H 'Content-Type: application/json' \
          -d '{"amount":100,"currency":"JPY","userId":"smoke-test"}' \
          https://payment.dev.company.com/api/v1/payments)
        echo "$RESPONSE" | python3 -c "
        import json, sys
        d = json.load(sys.stdin)
        assert d.get('status') == 'created', f'Expected status=created, got: {d}'
        print('✅ payment-service smoke tests passed')
        "
```

**Why two health check calls before the API call:**
1. `/actuator/health/liveness` — is the JVM alive? Tests basic process health
2. `/actuator/health/readiness` — is the app ready to serve traffic? Tests DB connection, dependencies
3. Only if both pass: test actual business logic

This ordering means: if the DB is down, the readiness check fails fast (no need to test payments which will fail for a different reason).

**Why Python for the assertion (not `jq`):**
The assertion `d.get('status') == 'created'` is type-safe and gives a clear error message: `"Expected status=created, got: {'status': 'pending', ...}"`. With `jq`, you'd pipe through `grep` and get a binary pass/fail with no context.

**Why smoke tests and not unit tests here:**
Unit tests mock the database and AWS services. Smoke tests hit the real endpoint in the real cluster. They verify:
- Image was pulled successfully
- App started without configuration errors
- Environment variables (DB credentials, etc.) are correct
- The real database connection works
- Business logic returns the expected result

Unit tests pass → image builds → Trivy passes → deploy → but DB credentials in Secrets Manager are wrong → payment returns 500. Smoke test catches this; unit test wouldn't.

---

## JOB 4: promote-to-staging

```yaml
promote-to-staging:
  needs: smoke-test-dev
```

### Image promotion (not rebuild):
```yaml
- name: Promote image dev → staging
  run: |
    docker pull ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}     # pull from DEV account
    docker tag  ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }} ${{ env.ECR_STAGING }}:${{ env.IMAGE_TAG }}
    docker push ${{ env.ECR_STAGING }}:${{ env.IMAGE_TAG }} # push to STAGING account
```

**Why `docker pull` + `docker tag` + `docker push` instead of rebuilding?**
Rebuilding from source in staging would:
- Take 4-5 extra minutes
- Potentially produce a DIFFERENT binary if dependencies changed (even by seconds)
- Undermine the trust established by dev testing

Promotion copies the EXACT binary from dev ECR to staging ECR. The SHA tag proves it's the same bits. The binary that passed dev tests and Trivy scan is the binary that runs in staging.

**Cross-account ECR access:**
```yaml
# First: authenticate to DEV account (to pull)
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789010:role/github-actions-ecr-read

# Then: authenticate to STAGING account (to push)  
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789011:role/github-actions-ecr-push
```

Two separate `configure-aws-credentials` steps because ECR is per-account. The credentials are refreshed between the pull (from dev account) and push (to staging account).

---

## JOB 5: test-staging (k6 load test)

```yaml
test-staging:
  needs: promote-to-staging
  steps:
    - name: k6 load test
      run: |
        k6 run --vus 50 --duration 3m \
          --env BASE_URL=https://payment.staging.company.com \
          services/payment-service/tests/load/load-test.js
```

**`--vus 50 --duration 3m`:**
50 virtual users sending requests concurrently for 3 minutes = ~150 requests/second (assuming ~300ms response time). This represents a realistic but not peak load.

**What k6 validates:**
The `load-test.js` file defines thresholds:
```javascript
export const options = {
  thresholds: {
    http_req_failed: ['rate<0.01'],      // < 1% errors
    http_req_duration: ['p(99)<800'],    // P99 < 800ms (staging threshold)
  }
};
```
k6 exits with code 1 if either threshold is violated → CI marks job failed → no promotion to production.

**Why run load tests in staging and not production?**
- Staging has ~50% of production capacity (2 replicas vs 3) — intentionally tests the service at capacity limits
- Real production traffic would compound with load test traffic → user impact
- Load test data (fake payments, orders) would need to be cleaned up from production DB

---

## JOB 6: promote-to-production (MANUAL APPROVAL)

```yaml
promote-to-production:
  needs: test-staging
  environment: production       # ← PAUSE HERE until human approves
```

**What "environment: production" does:**
When the pipeline reaches this job:
1. GitHub posts a notification to all configured reviewers: "payment-service wants to deploy to production"
2. The job shows as "Waiting" in GitHub Actions UI
3. A reviewer clicks "Review deployments" → "Approve and deploy"
4. Only then does the job run

**The window: 30 days default timeout.**
If nobody approves within 30 days, the deployment expires. This is configurable.

**Why manual approval and not just automation?**
The k6 load test validates normal load patterns. It cannot validate:
- "Is this a good time to deploy?" (Friday afternoon? During a product launch? During an incident?)
- "Are there business concerns?" (A sales team is demoing this exact feature right now)
- "Are there open P1 incidents?" (Never deploy while fixing an outage)

A human reviewer has context the automation doesn't. The approval gate is the judgment call.

---

## JOB 7: verify-production + Auto-Rollback

```yaml
verify-production:
  needs: promote-to-production
  permissions:
    contents: write    # needed to push the rollback commit
  steps:
    - uses: actions/checkout@v4
      with:
        token: '${{ secrets.GITHUB_TOKEN }}'
        fetch-depth: 0          # ← full git history (needed for rollback)
    
    - name: Production smoke tests
      id: smoke
      run: |
        sleep 60    # JIT warm-up: wait 60s for JVM to compile hot paths
        curl -sf https://payment.company.com/actuator/health/liveness  || exit 1
        curl -sf https://payment.company.com/actuator/health/readiness || exit 1
        echo "✅ payment-service production verified"
    
    - name: Auto-rollback on failure
      if: failure() && steps.smoke.outcome == 'failure'
      run: |
        git pull origin main
        PREV_TAG=$(git log --oneline -- \
            gitops/production/app/payment-service/payment-service.yaml | \
            awk 'NR==2{print $1}' | xargs git show | grep 'tag:' | head -1 | awk -F'"' '{print $2}')
        if [ -n "$PREV_TAG" ]; then
          sed -i "s|tag: \".*\"|tag: \"$PREV_TAG\"|" \
            gitops/production/app/payment-service/payment-service.yaml
          git add gitops/production/app/payment-service/payment-service.yaml
          git commit -m "chore(rollback-prod): payment-service=$PREV_TAG [skip ci]"
          git push
        fi
        exit 1
```

**`sleep 60` — why wait 60 seconds?**
Java's JIT compiler needs traffic to identify "hot" code paths and compile them to native code. For the first 30-60 seconds after startup:
- JVM runs in interpreted mode → 3-5× slower than normal
- `/actuator/health` endpoint itself is JIT-compiled on first call → might be slow
- P99 latency would fail even for a healthy service

After 60 seconds of traffic: JIT has compiled the hot paths, latency stabilizes. The smoke test at t=60s reflects real steady-state performance.

**The auto-rollback script explained:**
```bash
# Get the commit SHA of the SECOND-MOST RECENT change to this specific file
git log --oneline -- gitops/production/app/payment-service/payment-service.yaml
# Output:
# abc1234 chore(deploy-prod): payment-service=def5678 [skip ci]   ← NR==1 (current, bad)
# xyz9876 chore(deploy-prod): payment-service=aaa1111 [skip ci]   ← NR==2 (previous, good)

awk 'NR==2{print $1}'
# → xyz9876 (git commit SHA of the previous deploy)

xargs git show
# → Shows the full commit content of xyz9876

grep 'tag:' | head -1 | awk -F'"' '{print $2}'
# → aaa1111 (the previous image tag)
```

Once `PREV_TAG=aaa1111` is extracted:
1. `sed` replaces the current bad tag with the previous good tag
2. `git commit` writes this as a new commit (not amend — `[skip ci]` prevents re-triggering)
3. `git push` puts it in main
4. ArgoCD detects the change → rolls the deployment back to `aaa1111` → ~3 minutes later production is running the old version

**Why `exit 1` at the end of the rollback script?**
The pipeline should be marked FAILED even after rolling back. The rollback is damage control, not success. The team needs to see a failed pipeline to investigate why the new image failed production smoke tests.

**`if: failure() && steps.smoke.outcome == 'failure'`:**
The rollback only runs if:
1. The job is in `failure()` state (something failed)
2. AND specifically the `smoke` step failed (not some other step)

If the rollback step itself fails (e.g. git push rejected), we don't want to accidentally trigger another rollback attempt.

---

## The Terraform CI Pipelines (terraform-dynatrace-*.yaml)

For completeness: there are also 4 Terraform CI pipelines (1 for infra, 3 for Dynatrace per env).

```
terraform-dynatrace-dev.yaml:
  on PR:   terraform plan → comment plan on PR
  on push: terraform apply

terraform-dynatrace-production.yaml:
  same as dev BUT:
    apply job has: environment: production    ← requires manual approval
```

The production Terraform pipeline requires human approval for the same reason as the service deployment: Dynatrace configuration changes (alerting thresholds, SLO targets) affect production monitoring and on-call behavior. No automation should change these without a reviewer.

---

## Full Pipeline Timeline (push to verified production)

```
t=0:00  git push to main
t=0:30  Job 1 (test): starts
t=2:30  Job 1: complete (tests + coverage)
t=2:35  Job 2 (build+deploy-dev): starts
t=5:00  Docker build complete (with cache)
t=5:30  Trivy scan complete
t=5:35  gitops commit pushed, ArgoCD picks up change
t=6:05  kubectl rollout starts watching
t=8:00  kubectl rollout: deployment complete (dev)
t=8:01  Job 3 (smoke-test-dev): starts
t=8:30  Smoke tests pass
t=8:31  Job 4 (promote-to-staging): starts
t=9:00  Image promoted to staging ECR
t=9:05  gitops staging commit, ArgoCD picks up
t=11:00 Staging rollout complete (2 replicas, slower than dev)
t=11:01 Job 5 (k6 load test): starts
t=14:15 k6 load test complete (3 min duration + setup)
t=14:16 Job 6 (promote-to-production): starts
        ← PAUSED: waiting for human approval
t+?     Human approves (could be minutes to hours)
t+?+1   Image promoted to production ECR
t+?+3   gitops production commit, ArgoCD picks up
t+?+5   Production rollout starts
t+?+10  Production rollout complete (3 replicas)
t+?+11  Job 7 (verify-production): starts
t+?+12  sleep 60
t+?+13  Smoke tests run → pass or rollback
```

Total automated time (excluding human approval wait): ~16 minutes.
