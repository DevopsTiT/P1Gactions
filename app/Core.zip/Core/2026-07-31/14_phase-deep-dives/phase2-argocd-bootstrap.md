# Phase 2 — ArgoCD Bootstrap Deep Dive

> ArgoCD is the GitOps engine. Once installed, it watches your Git repo and automatically applies every YAML file it finds to the cluster. This phase installs ArgoCD and then hands all remaining cluster management over to Git with a single `kubectl apply`.

---

## Why ArgoCD Exists

Without ArgoCD, deploying changes looks like:
```
Developer changes a YAML → CI runs → kubectl apply → done
Problem: cluster state is only as good as the last CI run
         manual kubectl commands override what's in git
         no record of what actually deployed vs. what's in git
         no automatic reconciliation
```

With ArgoCD:
```
Developer changes a YAML → pushes to git → ArgoCD detects diff
→ automatically applies to cluster → cluster ALWAYS matches git
Manual kubectl edit? ArgoCD reverts it in ~3 minutes.
Someone deletes a pod? Kubernetes recreates it. Someone deletes a Deployment?
ArgoCD recreates it from git within 3 minutes.
```

**Git is the single source of truth. The cluster is the enforced outcome.**

---

## What Gets Installed by the ArgoCD Manifest

```bash
kubectl apply -n argocd \
  -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
```

This one YAML creates ~60+ Kubernetes resources:

```
Deployments (running as pods):
  argocd-server              ← the API + UI server (port 443)
  argocd-application-controller ← watches git, compares to cluster, reconciles
  argocd-repo-server         ← clones git repos, renders Helm charts into YAML
  argocd-dex-server          ← OIDC/SSO authentication
  argocd-redis               ← cache for repo-server and application-controller

CRDs (Custom Resource Definitions — new resource types ArgoCD adds to Kubernetes):
  Application                ← the core: "watch this git path, deploy to this cluster"
  AppProject                 ← RBAC container: which repos can deploy to which namespaces
  ApplicationSet             ← template that generates multiple Applications
  ...

RBAC (ClusterRoles + ClusterRoleBindings):
  argocd-application-controller-role ← can read/write all Kubernetes resources
  argocd-server-role                 ← can read resources for the UI
```

---

## Deep Dive: root-app-dev.yaml — The App of Apps Bootstrap

```yaml
# gitops/dev/bootstrap/root-app-dev.yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: root-app-dev
  namespace: argocd
  finalizers:
    - resources-finalizer.argocd.argoproj.io    ← [1]
spec:
  project: platform                              ← [2]
  source:
    repoURL: https://github.com/company/java-3envs-dynatrace.git
    targetRevision: HEAD                         ← [3]
    path: gitops/dev                             ← [4]
    directory:
      recurse: true                              ← [5]
  destination:
    server: https://kubernetes.default.svc       ← [6]
    namespace: argocd
  syncPolicy:
    automated:
      prune: true                                ← [7]
      selfHeal: true                             ← [8]
    syncOptions:
      - CreateNamespace=true
      - ServerSideApply=true                     ← [9]
```

### Annotation explanations:

**[1] `resources-finalizer.argocd.argoproj.io`**
When you delete this Application, ArgoCD will first delete all the resources it manages before removing the Application itself. Without this finalizer, deleting the root-app-dev would leave all the child Applications running as orphans — still syncing, still managing resources, impossible to clean up.

**[2] `project: platform`**
An AppProject that defines which Git repos can deploy to which clusters/namespaces. Think of it as an RBAC sandbox. `platform` project allows deployments to the system namespaces (argocd, kube-system, dynatrace). Application pods are in the `payments`, `orders`, `notifications` projects with narrower permissions.

**[3] `targetRevision: HEAD`**
Always use the latest commit on the default branch. Could be pinned to a specific git SHA for tighter control. `HEAD` means any git push is immediately visible to ArgoCD's next sync cycle.

**[4] `path: gitops/dev`**
ArgoCD watches ONLY this directory in the repo. Changes to `gitops/staging/` are invisible to this Application. Per-environment isolation at the git level.

**[5] `directory: recurse: true`**
ArgoCD walks the entire directory tree under `gitops/dev/` and processes every `.yaml` file it finds. This is what makes the App of Apps work — it finds all the child Application YAMLs (namespaces.yaml, aws-load-balancer-controller.yaml, etc.) and creates them.

**[6] `server: https://kubernetes.default.svc`**
Deploy to the same cluster ArgoCD is running in. In a multi-cluster setup, this would be different cluster API endpoints.

**[7] `prune: true`**
If a YAML file is deleted from git, ArgoCD deletes the corresponding Kubernetes resource. Without this, removing a file from git has no effect on the cluster — orphaned resources accumulate.

**[8] `selfHeal: true`**
If someone runs `kubectl edit` and changes a field, ArgoCD reverts it within ~3 minutes. The git version wins. This enforces that git is always the truth — no undocumented manual changes.

**[9] `ServerSideApply=true`**
Uses Kubernetes Server-Side Apply instead of client-side apply. Required for some resources with complex ownership semantics (like CRDs). Prevents "last-writer-wins" conflicts when multiple controllers manage the same resource fields.

---

## What Happens After `kubectl apply -f root-app-dev.yaml`

```
t=0s  kubectl apply root-app-dev.yaml
      → ArgoCD creates Application "root-app-dev" in namespace argocd

t=3s  argocd-application-controller wakes up
      → sees new Application
      → triggers sync

t=5s  argocd-repo-server clones git repo
      → walks gitops/dev/ recursively
      → finds 9 YAML files (all the child Application YAMLs)

t=10s ArgoCD applies all 9 Application YAMLs to argocd namespace
      → creates: namespaces-dev, aws-lb-controller-dev, external-dns-dev,
                 external-secrets-operator-dev, dynatrace-operator-dev,
                 payment-service-dev, order-service-dev, notification-service-dev

t=15s Each child Application starts its own sync
      → ordered by sync-wave annotation

t=20s Wave -1: namespaces-dev syncs
      → creates: payment-ns, order-ns, notification-ns, dynatrace, external-secrets

t=35s Wave 1: aws-lb-controller-dev syncs
             external-dns-dev syncs
      → installs Helm charts from external repos (downloads, renders, applies)

... (continues through waves 2, 3, 8)
```

---

## The Sync Wave Mechanism Explained

Sync waves are controlled by this annotation:
```yaml
metadata:
  annotations:
    argocd.argoproj.io/sync-wave: "-1"    # on namespaces Application
    argocd.argoproj.io/sync-wave: "1"     # on networking Applications
    argocd.argoproj.io/sync-wave: "2"     # on secrets Application
    argocd.argoproj.io/sync-wave: "3"     # on monitoring Application
    argocd.argoproj.io/sync-wave: "8"     # on app Applications
```

ArgoCD's sync algorithm:
1. Group all resources by wave number
2. Apply wave N resources, wait for them to be Healthy
3. Only then apply wave N+1
4. If any resource in wave N fails, STOP — do not proceed to N+1

**Why this ordering is non-negotiable:**

Wave -1 MUST be before wave 1:
- ALB controller (wave 1) runs in `kube-system` namespace — that namespace already exists (pre-created by EKS)
- But payment-service (wave 8) runs in `payment-ns` — this namespace DOES NOT exist until wave -1 creates it
- If wave 8 runs before wave -1: `Error from server (NotFound): namespaces "payment-ns" not found`

Wave 2 (ESO) MUST be before wave 3 (Dynatrace):
- DynaKube needs a K8s Secret named `dynakube` with the DT API token
- That Secret is created by an ExternalSecret (wave 3) that uses ESO (wave 2)
- If ESO isn't running, the ExternalSecret controller doesn't exist, the Secret is never created
- DynaKube tries to read the secret: `secret "dynakube" not found` → crash loop

Wave 3 (Dynatrace OneAgent) SHOULD be before wave 8 (apps):
- Not strictly required (apps won't crash without OneAgent)
- But: pods that start before OneAgent is running are NOT auto-instrumented
- JVM processes that start before OneAgent's JVMTI hook is in place miss the agent attach
- OneAgent CAN re-instrument them, but there may be a gap in metrics

---

## ArgoCD Application vs. What It Deploys

Each file in `gitops/dev/` is itself an ArgoCD Application (a pointer):
```
gitops/dev/networking/aws-load-balancer-controller.yaml
  kind: Application
  source:
    repoURL: https://aws.github.io/eks-charts     ← external Helm chart repo
    chart: aws-load-balancer-controller
    targetRevision: "1.7.2"                       ← pinned version
  helm:
    values: |
      clusterName: company-dev
      serviceAccount:
        annotations:
          eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-aws-load-balancer-controller
```

ArgoCD fetches the Helm chart from the external repo, renders it with the inline values, and applies the resulting Kubernetes resources to the cluster. The chart version is pinned (`1.7.2`) so a chart author publishing a breaking change doesn't affect your cluster.

---

## Key ArgoCD Configurations in the Payment-Service Application

```yaml
# gitops/dev/app/payment-service/payment-service.yaml
spec:
  source:
    path: charts/payment-service
    helm:
      valueFiles: [values.yaml, values-dev.yaml]    ← [A]
      values: |
        image:
          repository: 123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
          tag: "PLACEHOLDER"                          ← [B]
        ingress:
          host: payment.dev.company.com               ← [C]
  ignoreDifferences:
    - group: apps
      kind: Deployment
      jsonPointers: [/spec/replicas]                  ← [D]
```

**[A] `valueFiles: [values.yaml, values-dev.yaml]`**
Helm merges these files left to right. `values.yaml` has production defaults (3 replicas, Xmx1024m, WARN logs). `values-dev.yaml` overrides only the fields that differ in dev (1 replica, Xmx256m, DEBUG logs). Any field NOT in `values-dev.yaml` falls through to `values.yaml`. This avoids duplicating production-default values in every environment file.

**[B] `tag: "PLACEHOLDER"`**
The initial placeholder. The CI pipeline replaces this with the actual git SHA (`sed -i "s|tag: \".*\"|tag: \"$IMAGE_TAG\"|"`) and commits the change. ArgoCD detects the git change and rolls out the new image.

**[C] `ingress.host: payment.dev.company.com`**
Per-environment hostname. Production uses `payment.company.com` (from values.yaml). This inline override sets the dev-specific hostname without modifying the base chart.

**[D] `ignoreDifferences: /spec/replicas`**
HPA continuously changes the replica count based on CPU/memory. ArgoCD watches the Deployment and would notice `spec.replicas` differs from git (git says 1, HPA set it to 3). Without this, ArgoCD reverts HPA's work every 3 minutes. `ignoreDifferences` tells ArgoCD: "don't manage this field, let HPA own it."

---

## Verifying ArgoCD Works

```bash
# Get ArgoCD initial admin password
kubectl get secret argocd-initial-admin-secret \
  -n argocd \
  -o jsonpath='{.data.password}' | base64 -d

# Port-forward to access UI locally
kubectl port-forward svc/argocd-server -n argocd 8080:443

# Open https://localhost:8080 → login admin + password above

# CLI login
argocd login localhost:8080 --username admin --password <password> --insecure

# Check all applications
argocd app list
# Should show all apps with STATUS=Synced HEALTH=Healthy

# Force a sync (usually not needed — automated)
argocd app sync root-app-dev

# See sync history
argocd app history payment-service-dev

# See diff between git and cluster
argocd app diff payment-service-dev
```

---

## Common Failures in Phase 2

| Symptom | Cause | Fix |
|---------|-------|-----|
| ArgoCD server pod crashes on startup | Not enough memory on system nodes | Nodes need ≥2GB RAM. t3.medium (4GB) is the minimum |
| Child applications stuck in `Unknown` | ArgoCD can't clone git repo | Add git credentials via `argocd repo add` |
| Wave -1 healthy but wave 1 stuck | ALB controller can't find subnets | Check subnet tags: `kubernetes.io/role/elb=1` must exist |
| Wave 2 ESO `SecretSyncError` | IAM role for ESO pod missing or wrong | Check IRSA role ARN in cluster-secret-store.yaml matches actual role ARN |
| Wave 3 DynaKube `secret "dynakube" not found` | Wave 2 ExternalSecret failed | Fix ESO first (wave 2), then wave 3 will self-heal |
| ArgoCD fights HPA on replicas | Missing `ignoreDifferences` | Add `/spec/replicas` to ignoreDifferences in Application YAML |
