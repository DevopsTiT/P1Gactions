# Phase 6 — Verification Deep Dive

> Every layer of the system must be independently verified. A healthy-looking pod can still have broken monitoring. A "Synced" ArgoCD app can still have missing secrets. This phase gives you the exact commands to verify each layer and explains what a healthy state looks like vs. what broken looks like.

---

## Verification Mental Model

```
Layer 1: AWS Infrastructure (VPC, EKS nodes, ECR)
         ↓  nodes running → can schedule pods
Layer 2: Kubernetes (pods, services, ingresses)
         ↓  pods healthy → apps receive traffic
Layer 3: Secrets (ExternalSecrets synced)
         ↓  DB creds available → apps can connect to DB
Layer 4: Networking (ALB, DNS, Routes53)
         ↓  DNS resolves → external traffic reaches pods
Layer 5: ArgoCD (sync status)
         ↓  git = cluster state → GitOps working
Layer 6: Dynatrace (OneAgent, metrics, alerts)
         ↓  data flowing → observability working
Layer 7: CI/CD (pipeline end-to-end)
         ↓  code changes deploy reliably
```

Verify bottom-up. If Layer 2 is broken, don't debug Layer 5 — it's a symptom, not the cause.

---

## Layer 1: AWS Infrastructure

```bash
# Verify EKS cluster is active
aws eks describe-cluster \
  --name company-dev \
  --region ap-northeast-1 \
  --query 'cluster.status'
# Expected: "ACTIVE"

# Verify node groups are running
aws eks list-nodegroups \
  --cluster-name company-dev \
  --region ap-northeast-1

aws eks describe-nodegroup \
  --cluster-name company-dev \
  --nodegroup-name company-dev-system \
  --region ap-northeast-1 \
  --query 'nodegroup.status'
# Expected: "ACTIVE"

# Verify ECR repositories exist and have images
aws ecr describe-repositories \
  --region ap-northeast-1 \
  --query 'repositories[].repositoryName'

aws ecr list-images \
  --repository-name company/payment-service \
  --region ap-northeast-1 \
  --query 'imageIds[0]'
# Expected: shows at least one image digest/tag
```

**What broken looks like:**
- Cluster status `CREATING` after 25 min → stuck, check CloudFormation events
- Node group status `DEGRADED` → nodes not joining, check node IAM role
- ECR repository missing → CI push will fail, Phase 0 step was skipped

---

## Layer 2: Kubernetes — Pods and Resources

```bash
# ── All pods healthy ──────────────────────────────────────────────────────────
kubectl get pods -A --field-selector=status.phase!=Running,status.phase!=Succeeded
# Expected: empty output — everything is Running or Completed (completed jobs)

# ── Detailed pod status by namespace ──────────────────────────────────────────
kubectl get pods -n payment-ns
# Expected:
# NAME                               READY   STATUS    RESTARTS   AGE
# payment-service-xxx-yyy             1/1     Running   0          10m

# ── Check if a pod is stuck ───────────────────────────────────────────────────
kubectl describe pod <pod-name> -n payment-ns | tail -30
# Look for Events section:
# Normal  Scheduled     → pod assigned to a node
# Normal  Pulling       → pulling image from ECR
# Normal  Pulled        → image pulled
# Normal  Created       → container created
# Normal  Started       → container started
# Warning BackOff       → container keeps crashing (check logs)
# Warning FailedMount   → Secret or ConfigMap not found

# ── Container logs (last 100 lines) ──────────────────────────────────────────
kubectl logs -n payment-ns \
  $(kubectl get pod -n payment-ns -l app=payment-service -o jsonpath='{.items[0].metadata.name}') \
  --tail=100

# ── Check probe status ───────────────────────────────────────────────────────
kubectl describe pod <pod-name> -n payment-ns | grep -A 10 "Liveness\|Readiness\|Startup"
# Healthy output:
# Liveness:     http-get http://:8080/actuator/health/liveness delay=0s timeout=1s period=15s ...
# No "Unhealthy" or "probe failed" messages

# ── Verify services and endpoints ────────────────────────────────────────────
kubectl get svc -n payment-ns
# NAME              TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)   AGE
# payment-service   ClusterIP   10.100.200.50   <none>        80/TCP    20m

kubectl get endpoints -n payment-ns
# NAME              ENDPOINTS          AGE
# payment-service   10.0.5.23:8080     20m     ← pod IP listed = service has healthy backends
# If ENDPOINTS shows "<none>": pod readiness probe failing → service has no backends

# ── Verify HPA is working ────────────────────────────────────────────────────
kubectl get hpa -n payment-ns
# NAME              REFERENCE                     TARGETS         MINPODS  MAXPODS  REPLICAS
# payment-service   Deployment/payment-service   20%/70%, 35%/80%   3       20        3

# ── Verify PDB ───────────────────────────────────────────────────────────────
kubectl get pdb -n payment-ns
# NAME              MIN AVAILABLE   MAX UNAVAILABLE   ALLOWED DISRUPTIONS
# payment-service   2               N/A               1           ← 1 pod can be disrupted
```

**What broken looks like:**
- `STATUS: CrashLoopBackOff` → container crashes on startup, check logs for error
- `STATUS: Pending` for more than 2 min → no node available or resource quota exceeded
- `STATUS: ImagePullBackOff` → can't pull from ECR, check IRSA permissions
- `READY: 0/1` → container running but probe failing, check probe endpoint
- `ENDPOINTS: <none>` → all pods failing readiness, service will 503

---

## Layer 3: Secrets (ExternalSecrets)

```bash
# ── Check ClusterSecretStore is connected ────────────────────────────────────
kubectl get clustersecretstore
# NAME                   AGE   STATUS   READY
# aws-secrets-manager    10m   Valid    True
# If STATUS=Invalid: ESO pod can't reach Secrets Manager (check IRSA role)

# ── Check all ExternalSecrets are synced ────────────────────────────────────
kubectl get externalsecrets -A
# NAMESPACE       NAME                           STORE                 REFRESH INTERVAL   STATUS   READY
# payment-ns      payment-service-db-credentials aws-secrets-manager   1h                 Ready    True
# order-ns        order-service-db-credentials   aws-secrets-manager   1h                 Ready    True
# dynatrace       dynakube-tokens                aws-secrets-manager   1h                 Ready    True

# If READY=False, describe for details:
kubectl describe externalsecret payment-service-db-credentials -n payment-ns
# Look for Events:
# Warning  SecretSyncError → check the error message (common: permission denied, secret not found)

# ── Verify the actual K8s Secret was created ────────────────────────────────
kubectl get secret payment-service-db-credentials -n payment-ns
# NAME                             TYPE     DATA   AGE
# payment-service-db-credentials   Opaque   5      10m    ← 5 keys (DB_HOST, DB_PORT, etc.)

# Verify the keys exist (values are base64 — don't print them in logs)
kubectl get secret payment-service-db-credentials -n payment-ns \
  -o jsonpath='{.data}' | jq 'keys'
# Expected: ["DB_HOST", "DB_NAME", "DB_PASSWORD", "DB_PORT", "DB_USERNAME"]
```

**What broken looks like:**
- `STATUS: SecretSyncError` → most common: IAM role missing `secretsmanager:GetSecretValue`, or wrong secret path in Secrets Manager
- `READY: False` → ESO controller not running (wave 2 failed)
- `DATA: 0` → Secret was created but ESO couldn't populate it

---

## Layer 4: Networking (ALB, DNS, Ingress)

```bash
# ── Check Ingress and ALB ────────────────────────────────────────────────────
kubectl get ingress -A
# NAMESPACE    NAME              CLASS   HOSTS                       ADDRESS                                     PORTS
# payment-ns   payment-service   alb     payment.dev.company.com     k8s-paymentns-xxx.ap-northeast-1.elb.amazonaws.com   80, 443

# If ADDRESS is empty: ALB not created yet (ALB controller hasn't processed it)
# Check ALB controller logs:
kubectl logs -n kube-system \
  $(kubectl get pod -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller \
    -o jsonpath='{.items[0].metadata.name}') \
  --tail=50

# ── Verify ExternalDNS created Route53 records ───────────────────────────────
kubectl logs -n kube-system \
  $(kubectl get pod -n kube-system -l app.kubernetes.io/name=external-dns \
    -o jsonpath='{.items[0].metadata.name}') \
  | grep "payment.dev.company.com"
# Expected: "Upserting record 'payment.dev.company.com' → <ALB DNS>"

# Verify DNS resolves
dig payment.dev.company.com
# Should show CNAME → ALB DNS name

# ── End-to-end HTTP test ─────────────────────────────────────────────────────
# HTTP → HTTPS redirect
curl -v -L http://payment.dev.company.com/actuator/health 2>&1 | grep -E "HTTP|status"
# Expected: HTTP/1.1 301 Moved → HTTP/2 200

# HTTPS health check
curl -s https://payment.dev.company.com/actuator/health | jq
# Expected:
# {
#   "status": "UP",
#   "components": {
#     "db": { "status": "UP" },
#     "diskSpace": { "status": "UP" }
#   }
# }

# Business logic test
curl -s -X POST https://payment.dev.company.com/api/v1/payments \
  -H "Content-Type: application/json" \
  -d '{"amount": 100, "currency": "JPY"}' | jq
# Expected: { "id": "...", "status": "created", ... }

# ── ALB target health ────────────────────────────────────────────────────────
# Get the target group ARN
aws elbv2 describe-target-groups \
  --query 'TargetGroups[?contains(TargetGroupName, `payment`)].TargetGroupArn' \
  --output text

# Check pod health in the target group
aws elbv2 describe-target-health \
  --target-group-arn <arn>
# Expected: all targets with HealthState: healthy
# If unhealthy: ALB health check on /actuator/health/readiness is failing
```

**What broken looks like:**
- Ingress ADDRESS empty for 5+ min → check ALB controller logs (usually: missing subnet tags, or missing IAM permission)
- DNS not resolving → ExternalDNS not processing → check domainFilters matches the hostname
- curl 502 Bad Gateway → ALB has no healthy targets → pod readiness failing
- curl SSL error → ACM certificate ARN wrong in Ingress annotation

---

## Layer 5: ArgoCD Sync Status

```bash
# ── All applications synced and healthy ──────────────────────────────────────
kubectl get applications -n argocd
# NAME                                  SYNC STATUS   HEALTH STATUS
# root-app-dev                          Synced        Healthy
# namespaces-dev                        Synced        Healthy
# aws-load-balancer-controller-dev      Synced        Healthy
# external-dns-dev                      Synced        Healthy
# external-secrets-operator-dev         Synced        Healthy
# dynatrace-operator-dev                Synced        Healthy
# payment-service-dev                   Synced        Healthy
# order-service-dev                     Synced        Healthy
# notification-service-dev              Synced        Healthy

# ── Check if git matches cluster ──────────────────────────────────────────────
argocd app diff payment-service-dev
# Expected: no output (git = cluster)
# If there's a diff: ArgoCD may be mid-sync or something changed manually

# ── Force sync (if stuck in OutOfSync) ───────────────────────────────────────
argocd app sync payment-service-dev --force

# ── Check sync history ───────────────────────────────────────────────────────
argocd app history payment-service-dev
# Shows: deployment SHA, when it synced, which user/automation triggered it

# ── Check sync wave progress ─────────────────────────────────────────────────
kubectl get events -n argocd --sort-by='.lastTimestamp' | tail -20
# Should show: sync waves completing in order (-1, 1, 2, 3, 8)
```

**What broken looks like:**
- `SYNC STATUS: OutOfSync` → git changed, ArgoCD hasn't applied it yet (wait 3 min or force sync)
- `HEALTH STATUS: Degraded` → resources applied but Kubernetes reports them unhealthy (check pod logs)
- `HEALTH STATUS: Progressing` → rollout in progress (check `kubectl rollout status`)
- `SYNC STATUS: Unknown` → ArgoCD can't reach git or render the Helm chart (check repo-server logs)

---

## Layer 6: Dynatrace Observability

### OneAgent verification:
```bash
# Check DynaKube status
kubectl get dynakube -n dynatrace
# NAME       APIURL                                   TOKENS    STATUS    AGE
# dynakube   https://abc.live.dynatrace.com/api        dynakube  Running   15m

# Check OneAgent pods (one per node)
kubectl get pods -n dynatrace | grep oneagent
# oneagent-xxxxx   1/1   Running   0   15m   10.0.5.100   ip-10-0-5-100...
# oneagent-yyyyy   1/1   Running   0   15m   10.0.5.101   ip-10-0-5-101...
# (one pod per node = healthy DaemonSet)

# Check ActiveGate
kubectl get pods -n dynatrace | grep activegate
# dynakube-activegate-0   1/1   Running   0   15m

# Check OneAgent logs for JVM instrumentation
kubectl logs -n dynatrace oneagent-xxxxx --tail=50 | grep -i "instrument\|payment\|order"
# Expected: "Successfully instrumented payment-service process" or similar
```

### Dynatrace UI verification:
```
1. Dynatrace UI → Services
   → payment-service should appear
   → Tags: team:payments, environment:dev
   → Click → Response time chart should show data

2. Dynatrace UI → Management Zones → payments-dev
   → Should contain: payment-service (service), payment-service pods (process group)

3. Dynatrace UI → Synthetic monitors
   → payment-service Health Check [dev] → Status: UP
   → Execution results: HTTP 200, body contains "status":"UP"

4. Dynatrace UI → SLOs
   → payment-service Availability [dev]
   → Compliance: X% vs 90% target
   → Error budget: X minutes remaining

5. Dynatrace UI → Problems (open)
   → Ideally empty after a fresh deploy
   → If problems exist: investigate before declaring success
```

**What broken looks like in Dynatrace:**
- Service not appearing after 5+ min → OneAgent not instrumenting JVM → check OneAgent version compatibility with Java 21
- No metrics on service → OneAgent can't connect to ActiveGate → check network policy
- Management zone empty → namespace labels wrong or not propagating to pods

---

## Layer 7: CI/CD End-to-End Verification

```bash
# Make a minimal code change to trigger the pipeline
# (e.g., add a comment to the payment service controller)

# Push and observe in GitHub Actions:
# 1. Actions tab → payment-service CI/CD workflow
# 2. Unit Tests + Coverage → green
# 3. Build → Dev → green (image SHA printed in logs)
# 4. Smoke Tests (Dev) → green ("✅ payment-service smoke tests passed")
# 5. Promote → Staging → green
# 6. Load Tests (Staging) → green (k6 summary shows no threshold violations)
# 7. Promote → Production → PAUSED (waiting for approval)
# 8. Approve → job runs
# 9. Verify Production + Auto-Rollback → green

# Verify the git history shows the deployment trail:
git log --oneline -- gitops/production/app/payment-service/payment-service.yaml
# abc1234 chore(deploy-prod): payment-service=<sha> [skip ci]
# def5678 chore(deploy-prod): payment-service=<prev-sha> [skip ci]
```

### Test the auto-rollback mechanism:
```bash
# To test rollback without real production impact (in dev):
# 1. Manually set the gitops/dev image tag to a non-existent image SHA
sed -i 's/tag: ".*"/tag: "nonexistent-sha"/' \
  gitops/dev/app/payment-service/payment-service.yaml
git add gitops/dev/app/payment-service/payment-service.yaml
git commit -m "test: intentionally bad image tag [skip ci]"
git push

# 2. Watch ArgoCD try to deploy it (will fail - image not in ECR)
kubectl rollout status deployment/payment-service -n payment-ns --timeout=5m
# Expected: timeout or error about ImagePullBackOff

# 3. ArgoCD marks app as Degraded
kubectl get application payment-service-dev -n argocd

# 4. Roll it back manually (simulating what the pipeline does):
PREV_TAG=$(git log --oneline -- gitops/dev/app/payment-service/payment-service.yaml | \
  awk 'NR==2{print $1}' | xargs git show | grep 'tag:' | head -1 | awk -F'"' '{print $2}')
sed -i "s|tag: \".*\"|tag: \"$PREV_TAG\"|" gitops/dev/app/payment-service/payment-service.yaml
git add gitops/dev/app/payment-service/payment-service.yaml
git commit -m "chore(rollback-dev): payment-service=$PREV_TAG [skip ci]"
git push

# 5. Verify ArgoCD deploys the old version successfully
kubectl rollout status deployment/payment-service -n payment-ns --timeout=5m
```

---

## Verification Checklist Summary

| Layer | Command | Expected result |
|-------|---------|----------------|
| EKS cluster | `aws eks describe-cluster --name company-dev --query cluster.status` | `"ACTIVE"` |
| K8s nodes | `kubectl get nodes` | All `Ready` |
| All pods | `kubectl get pods -A \| grep -v "Running\|Completed"` | Empty |
| ExternalSecret | `kubectl get externalsecrets -A` | All `READY=True` |
| ClusterSecretStore | `kubectl get clustersecretstore` | `STATUS=Valid` |
| Ingress/ALB | `kubectl get ingress -A` | ADDRESS populated |
| DNS | `dig payment.dev.company.com` | Returns ALB CNAME |
| HTTP health | `curl -s https://payment.dev.company.com/actuator/health` | `"status":"UP"` |
| ArgoCD apps | `kubectl get applications -n argocd` | All `Synced` + `Healthy` |
| DynaKube | `kubectl get dynakube -n dynatrace` | `STATUS=Running` |
| OneAgent pods | `kubectl get pods -n dynatrace \| grep oneagent` | Count = node count |
| DT service visible | Dynatrace UI → Services | payment-service appears |
| DT management zone | Dynatrace UI → Management Zones | payments-dev has services |
| DT synthetic | Dynatrace UI → Synthetic monitors | Status = UP |
| Terraform drift | `terraform plan -refresh-only -detailed-exitcode` | Exit code 0 |
