# Phase 4 — Dynatrace Terraform Configuration Deep Dive

> The Dynatrace Terraform module creates the observability configuration inside the Dynatrace SaaS platform: management zones, alerting profiles, 8 metric event signals per service, SLOs, synthetic monitors, and notification channels. One module — called three times with different thresholds.

---

## The Module Architecture

```
terraform/modules/dynatrace/main.tf    ← one module, called 3 times
        ↑                  ↑                  ↑
environments/dev/main.tf   environments/staging/main.tf   environments/production/main.tf
(relaxed thresholds)       (medium thresholds)             (strict thresholds + PagerDuty)
```

The same Terraform logic creates IDENTICAL STRUCTURE in each environment. What differs is the VALUES passed in (thresholds, PagerDuty keys, synthetic locations).

**Why one module not three copies?**
If you have a bug in the error-rate alert configuration, you fix it ONCE in the module — all three environments get the fix on the next `terraform apply`. Three separate copies would need three separate fixes, and you'd inevitably miss one.

---

## What the Module Creates

For 3 services × 3 environments = a large number of Dynatrace resources.

Let's count for ONE environment:
```
Management zones:    1 per team × 3 teams = 3
Alerting profiles:   4 tiers × 3 teams    = 12
Metric events:       8 signals × 3 services = 24
SLOs:                2 types × 3 services  = 6
HTTP Synthetics:     1 per service × 3     = 3
PagerDuty notifications: 0-6 depending on env
Slack notifications: 2 types × 3 teams    = 6
───────────────────────────────────────────────
Per environment:     ~54+ Dynatrace resources
Three environments:  ~162 resources total
```

All managed by Terraform. Any manual change in the Dynatrace UI is overwritten on the next `terraform apply`.

---

## Deep Dive: Management Zones

```hcl
locals {
  teams = toset([for svc in values(var.services) : svc.team])
  # from dev/main.tf services map, extracts: ["payments", "orders", "notifications"]
  # toset removes duplicates (if two services had same team)
}

resource "dynatrace_management_zone_v2" "team" {
  for_each    = local.teams              # creates one resource per team
  name        = "${each.value}-${var.environment}"   # "payments-dev"
  
  rules {
    rule {
      type    = "SERVICE"
      attribute_rule {
        attribute_conditions {
          attribute = "SERVICE_TAGS"
          operator  = "TAG_KEY_EQUALS"
          tag_value = "team:${each.value}"       # matches tag team:payments
        }
        attribute_conditions {
          attribute = "SERVICE_TAGS"
          operator  = "TAG_KEY_EQUALS"
          tag_value = "environment:${var.environment}"  # AND environment:dev
        }
      }
    }
    rule { type = "PROCESS_GROUP" ... }    # same logic for process groups
    rule { type = "HOST" ... }             # same logic for hosts
  }
}
```

**How tags flow from Kubernetes to Dynatrace:**

```
Step 1: Namespace YAML sets labels:
  metadata:
    labels:
      team: payments
      environment: dev

Step 2: Helm chart propagates via commonLabels to pod spec:
  template:
    metadata:
      labels:
        team: payments        ← on the pod
        environment: dev

Step 3: OneAgent reads pod metadata from K8s API every 60s
  → detects: this JVM process's pod has labels team=payments, environment=dev
  → applies tags to the Dynatrace Service entity:
    tag: team:payments
    tag: environment:dev

Step 4: Management zone rule evaluates:
  SERVICE_TAGS contains team:payments AND environment:dev
  → Service "payment-service" matches zone "payments-dev"
  → Appears in payments team's dashboard only
```

**What happens without management zones:**
All services from all teams appear in one shared Dynatrace view. The payments team sees order-service alerts. The orders team gets paged for notification-service issues. Alert fatigue → real problems get ignored → slower MTTR.

---

## Deep Dive: Alerting Profiles (4 Tiers)

```hcl
# TIER 1: CRITICAL — production only, 0 min delay
resource "dynatrace_alerting" "critical" {
  for_each = var.environment == "production" ? local.teams : toset([])
  # ↑ Only creates resources in production. Dev and staging: toset([]) = 0 resources
  
  rules {
    rule {
      severity_level   = "AVAILABILITY"    # service down, synthetic failed
      delay_in_minutes = 0                 # fire immediately — downtime is always real
    }
  }
}

# TIER 2: HIGH — production + staging, 2 min delay
resource "dynatrace_alerting" "high" {
  for_each = contains(["production", "staging"], var.environment) ? local.teams : toset([])
  
  rules {
    rule {
      severity_level   = "ERROR"           # high error rates, failed transactions
      delay_in_minutes = 2                 # filter transient errors (retry storms, cold start spikes)
    }
  }
}

# TIER 3: WARNING — all environments, 5 min delay
resource "dynatrace_alerting" "warning" {
  for_each = local.teams    # always created (dev, staging, production)
  
  rules {
    rule {
      severity_level   = "SLOWDOWN"        # latency degradation, response time increase
      delay_in_minutes = 5                 # must be slow for 5+ min before alerting
    }
  }
}

# TIER 4: INFO — all environments, 15 min delay
resource "dynatrace_alerting" "info" {
  for_each = local.teams
  
  rules {
    rule { severity_level = "RESOURCE_CONTENTION"; delay_in_minutes = 15 }
    rule { severity_level = "CUSTOM_ALERT";        delay_in_minutes = 15 }
  }
}
```

**Why delay_in_minutes exists:**
Without delays, every transient blip pages the on-call. Examples of transient problems:
- During a rolling deploy: 1 pod down for 30 seconds → AVAILABILITY fires → on-call paged → false alarm
- Cold start spike: new pod starts, JIT hasn't warmed up → latency high for 60 seconds → SLOWDOWN fires → false alarm
- Retry storm: downstream service hiccups → error rate spikes for 90 seconds → ERROR fires → false alarm

With 2-minute delay for ERROR: the alert only fires if errors persist for 2+ minutes. Most transient issues self-resolve in under 2 minutes. Real problems persist.

**Why AVAILABILITY has 0 delay:**
There is no "transient" reason for a service to be completely unavailable. If availability drops to 0%, something is seriously broken and the on-call needs to know immediately. No false alarms justify delaying this.

---

## Deep Dive: The 8 Metric Events (all signals explained)

### Signal 1: Traffic Drop — the most important signal
```hcl
resource "dynatrace_metric_events" "traffic_drop" {
  for_each = local.services_with_traffic    # only services where traffic_min_rps > 0
  # dev has traffic_min_rps = 0 for all services → zero traffic drop alerts in dev
  
  model_properties {
    type             = "STATIC_THRESHOLD"
    alert_condition  = "BELOW"
    alert_on_no_data = true           # ← fires even when NO data points arrive
    threshold        = each.value.traffic_min_rps
    violating_samples = 3             # 3 consecutive minutes below threshold
  }
  query_definition {
    metric_key = "builtin:service.requestCount.server"
    resolution = "1m"
  }
}
```

**Why `alert_on_no_data = true` is critical:**
A healthy service sends metrics to Dynatrace continuously. If the service crashes completely:
- No requests are being processed
- No metrics are being generated
- A normal threshold alert sees: "no data → skip evaluation → no alert"
- The service is dead and nobody is paged

`alert_on_no_data = true` treats missing data as a threshold violation. Zero data = below minimum RPS = alert fires. This catches the silent outage: "the service is so broken it can't even report metrics."

**Why dev has `traffic_min_rps = 0`:**
Dev services are often idle (no scheduled load). An alert "dev payment-service has 0 RPS at 3am" would be constant noise. Dev gets monitoring visibility (metrics in Dynatrace UI) without paging anyone.

### Signal 2: Error Rate
```hcl
metric_key = "builtin:service.errors.server.rate"
threshold  = each.value.error_rate_alert    # dev:10%, staging:1%, production:0.1%
violating_samples = 3     # must be above threshold for 3 consecutive minutes
dealerting_samples = 3    # must be below threshold for 3 consecutive minutes to resolve
```

**Why production threshold is 0.1% and not 0%:**
- Every web service has background noise: bot traffic, misconfigured clients, invalid requests
- These cause 4xx/5xx responses that aren't actual service failures
- 0% would fire constantly on legitimate non-errors
- 0.1% means "1 error per 1000 requests" — meaningful degradation, not noise

**`dealerting_samples = 3`:**
The alert must stay below the threshold for 3 consecutive minutes before Dynatrace marks it "resolved." Without this, a flapping metric (above-below-above-below) generates a storm of open/close alerts. 3-sample hysteresis smooths this.

### Signal 3: Latency P99
```hcl
metric_key = "builtin:service.response.time:percentile(99)"
threshold  = each.value.latency_p99_ms * 1000    # ← Dynatrace stores in MICROSECONDS
# dev:2000ms × 1000 = 2,000,000µs
# production:300ms × 1000 = 300,000µs
```

**Why the × 1000 multiplication matters:**
Dynatrace's internal representation uses microseconds. If you set `threshold = 300` thinking "300ms," Dynatrace reads it as 300µs = 0.3ms. Every single request is slower than 0.3ms → the alert fires immediately and never stops. The module handles this conversion so human-readable milliseconds are in the Terraform config.

**Why P99 and not average?**
```
Example: 99 requests take 10ms, 1 request takes 5000ms
  Average: (99×10 + 1×5000) / 100 = 59.9ms  ← "great!"
  P99:     5000ms                              ← "1% of users wait 5 seconds"

P99 captures the worst experience that a significant fraction of users have.
Average hides it completely.
```

### Signal 4: CPU Saturation
```hcl
event_entity_dimension_key = "dt.entity.process_group_instance"   # ← per JVM process, not per pod
metric_key = "builtin:process.cpu.usage"
threshold  = each.value.cpu_saturation_pct    # dev:90%, production:80%
violating_samples = 5    # must be above for 5 minutes
```

**Why `process_group_instance` and not `cloud_application` (pod)?**
The process-level entity captures the JVM's CPU consumption directly, including GC activity. Pod-level CPU includes sidecar containers (like Dynatrace OneAgent itself). Process-level is more accurate for Java GC pressure analysis.

**Why production threshold is 80% not 100%?**
At 80% CPU, the JVM's G1GC starts increasing garbage collection frequency. By the time CPU reaches 90-100%, GC pauses are likely already impacting latency. Alerting at 80% gives you time to scale out BEFORE users feel the impact.

### Signal 5: Memory Usage (container RSS)
```hcl
metric_key = "builtin:process.memory.usage"    # RSS as % of container memory limit
threshold  = each.value.memory_usage_pct       # dev:85%, production:75%
```

**RSS vs. heap:**
- RSS (Resident Set Size) = total memory the JVM process uses: heap + off-heap + native libs + JVM overhead
- JVM heap alert (signal 6) catches heap-specific issues (memory leaks, insufficient Xmx)
- RSS alert catches total memory pressure: even if heap is fine, off-heap can grow and cause OOMKill

At 85%+ RSS: the container is approaching its memory limit. When RSS hits 100%, the Linux kernel sends SIGKILL (OOMKill) — not SIGTERM. No graceful shutdown. Just dead pod. Alert at 85% to catch this trend early.

### Signal 6: JVM Heap
```hcl
metric_key = "builtin:process.memory.jvm.heapUtilization"
threshold  = each.value.jvm_heap_pct    # dev:85%, production:70%
```

**Why production threshold is 70% not 85%?**
The G1GC garbage collector has non-linear behavior:
```
Heap utilization:   0-50%    → GC runs normally, short pauses
                    50-70%   → GC works harder, pauses increasing
                    70-80%   → GC consumes significant CPU, latency spikes
                    80-90%   → GC in near-constant operation, full GC pauses possible
                    90%+     → OutOfMemoryError likely
```

Alerting at 70% for production gives the SRE time to scale out (HPA adds pods) or investigate a memory leak BEFORE GC pressure starts causing latency spikes (latency P99 alert would fire at ~80%+).

Dev alerting at 85%: dev services have more tolerance for GC pauses, and they run with small heap (Xmx256m) where 70% = 179MB used — normal operation.

### Signal 7: Pod Restarts
```hcl
event_entity_dimension_key = "dt.entity.cloud_application"   # Kubernetes workload
metric_key = "builtin:kubernetes.workload.pods.restarts"
resolution = "5m"          # check over 5-minute windows
threshold  = each.value.pod_restart_threshold    # dev:5, production:2
violating_samples = 1      # fire immediately on first violation (not after 3 minutes)
```

**Why `violating_samples = 1` (not 3)?**
Pod restarts are discrete events. If a pod restarted 3 times in 5 minutes, it's already in a crash loop. Waiting for 3 consecutive 5-minute windows to confirm this would take 15 minutes — way too slow. One measurement showing >2 restarts is enough to page.

**Common causes of pod restarts:**
- OOMKill: RSS exceeded memory limit → kernel sends SIGKILL
- Failed liveness probe: app deadlocked, not responding → K8s kills and restarts
- Failed readiness probe consistently: misconfig, can't reach DB → K8s might restart eventually
- Config error: missing env var → app crashes on startup → CrashLoopBackOff

### Signal 8: Network Error Rate
```hcl
event_entity_dimension_key = "dt.entity.host"   # at the HOST level, not service
metric_key = "builtin:host.net.errorRate"
```

**Why host-level and not service-level?**
Network errors (dropped packets, TCP RST, MTU mismatches, security group blocks) happen at the infrastructure layer — they affect all services on a node simultaneously. A host-level alert fires once for the host, not 3 times for 3 services on the same host.

If payment-service, order-service, and notification-service all show network errors at the same time — it's a node/network issue, not an application issue. The host-level alert leads the investigation to the right place immediately.

---

## Deep Dive: SLOs

```hcl
resource "dynatrace_slo_v2" "availability" {
  target_success    = each.value.slo_target          # dev:90%, production:99.9%
  target_warning    = each.value.slo_target - 0.1    # 0.1% below target = warning
  evaluation_window = "-1M"                           # rolling 30-day window

  metric_expression = <<-EOT
    100*(
      builtin:service.requestCount.server         # total requests
        :filter(eq(service.name,"payment-service"))
        :splitBy():sum
      -
      builtin:service.errors.server.count         # minus failed requests
        :filter(eq(service.name,"payment-service"))
        :splitBy():sum
    )
    / builtin:service.requestCount.server         # divide by total
      :filter(eq(service.name,"payment-service"))
      :splitBy():sum
  EOT
  # = (total - errors) / total × 100 = success rate percentage

  error_budget_burn_rate {
    fast_burn_threshold = 14.4   # exhausts monthly budget in ~2 days
    slow_burn_threshold = 3.0    # exhausts monthly budget in ~10 days
  }
}
```

**What the burn rate thresholds mean:**

For a 30-day window at 99.9% SLO:
- Total allowed errors: 0.1% × 30 days × 1440 min/day = 43.2 minutes of downtime
- At 14.4× burn rate: budget depletes in 30/14.4 = ~2 days → CRITICAL alert
- At 3.0× burn rate: budget depletes in 30/3 = ~10 days → WARNING alert

These fire BEFORE the SLO is breached, giving you time to fix the problem. Without burn-rate alerts, you only know the SLO was missed AFTER the 30-day window closes.

**Warning threshold = target - 0.1:**
The SLO target is the commitment (99.9%). The warning threshold (99.8%) says "approaching the danger zone" — alerting before an actual breach. This gives an earlier signal to investigate.

---

## Deep Dive: HTTP Synthetic Monitors

```hcl
resource "dynatrace_http_monitor" "health_check" {
  frequency = 5           # check every 5 minutes
  locations = var.synthetic_locations
  # dev: ["GEOLOCATION-6F55B7E4B5E7A52F"]  (Tokyo only)
  # staging+prod: [Tokyo, Singapore]

  script {
    request {
      method = "GET"
      url    = each.value.health_check_url    # https://payment.dev.company.com/actuator/health
      
      validation {
        rule {
          type          = "httpStatusesList"
          value         = "2xx"
          pass_if_found = true              # must return 2xx status
        }
        rule {
          type          = "patternConstraint"
          value         = "\"status\":\"UP\""   # body must contain "status":"UP"
          pass_if_found = true
        }
      }
      response_time_limit = each.value.latency_p99_ms * 3   # 3× normal threshold for synthetics
    }
  }
  
  anomaly_detection {
    outage_handling {
      global_outages = true
      local_outages  = true
      global_consecutive_outage_count_threshold = 1    # 1 global failure = alert
      local_consecutive_outage_count_threshold  = 3    # 3 local failures from one location = alert
    }
  }
}
```

**Why check for `"status":"UP"` in the body?**
A service can return HTTP 200 but report itself as DOWN in the body:
```json
HTTP 200 OK
{
  "status": "DOWN",
  "components": {
    "db": { "status": "DOWN", "details": "Connection refused" }
  }
}
```
This is a common Spring Actuator pattern: the HTTP server is running but the app is unhealthy. HTTP status 200 alone wouldn't detect this. The body validation catches it.

**Why `response_time_limit = latency_p99_ms × 3`?**
Synthetics are run from Dynatrace's external probes in Tokyo/Singapore — farther from the service than typical users. The network round-trip adds 50-100ms. Using 3× the normal P99 threshold as the synthetic limit prevents false alerts from network latency variance while still catching genuinely slow responses.

**Global vs local outages:**
- Local outage: the service is unreachable from ONE location (e.g. Tokyo can't connect but Singapore can) — may be a regional network issue, not a service outage
- Global outage: ALL locations report failure — the service itself is down
- `local_consecutive_outage_count_threshold = 3`: only alert if the same location fails 3 times in a row (filters out one-time network hiccups)

---

## Per-Environment Threshold Summary

| Signal | Dev | Staging | Production |
|--------|-----|---------|------------|
| SLO target | 90% | 95% | 99.9% |
| Traffic min | 0 (disabled) | 2 req/min | 10 req/min |
| Error rate | 10% | 1% | 0.1% |
| Latency P99 | 2000ms | 800ms | 300ms |
| CPU alert | 90% | 85% | 80% |
| Memory RSS | 85% | 78% | 75% |
| JVM heap | 85% | 78% | 70% |
| Pod restarts | 5 | 3 | 2 |
| Network errors | 5% | 2% | 0.5% |
| PagerDuty | None | HIGH only | CRITICAL+HIGH |
| Synthetics | Tokyo | Tokyo+Singapore | Tokyo+Singapore |

**Why dev thresholds are so relaxed:**
Dev services run on small nodes (t3.medium), small heap (Xmx256m), cold caches, JIT not warmed up. Applying production thresholds to dev would result in constant alerts from normal dev behavior — making alerts meaningless (alert fatigue). Dev alerts go only to Slack #dev-alerts, not on-call.
