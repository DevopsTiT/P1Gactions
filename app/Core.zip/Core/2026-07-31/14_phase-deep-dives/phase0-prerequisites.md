# Phase 0 — Prerequisites Deep Dive

> Before a single line of Terraform can run, AWS must have specific resources and GitHub must have specific secrets. Every item here unblocks something else. Missing one = silent failure or cryptic error hours later.

---

## Why Phase 0 Exists

Terraform and GitHub Actions are not self-bootstrapping. They require:
- A place to store state (S3 bucket) — without it `terraform init` fails immediately
- A lock to prevent concurrent runs (DynamoDB) — without it two engineers corrupt the state file
- Credentials stored safely (Secrets Manager) — without them `terraform plan` crashes with `ResourceNotFoundException`
- Docker image destinations (ECR) — without them the first CI build fails to push
- GitHub knows which AWS accounts to deploy to (GitHub Secrets) — without them OIDC auth fails

**The dependency chain:**
```
S3 + DynamoDB  →  terraform init can run
Secrets Manager →  terraform plan can read DT credentials
ECR repos      →  docker push succeeds in CI
GitHub Secrets →  GitHub Actions can assume AWS IAM roles
GitHub Env     →  production approval gate exists before anyone deploys
```

---

## Step 0.1 — Three Separate AWS Accounts

### Why three accounts and not three namespaces?
A single AWS account with dev/staging/production namespaces sounds simpler — but:

| Risk | Single-account | Three-account |
|------|---------------|---------------|
| Terraform mistake deletes prod VPC | Possible | Impossible (different account) |
| Dev IAM role gets prod permissions | Easy mistake | Physically separate IAM |
| Shared billing makes cost attribution hard | Yes | No, separate bills |
| Security incident in dev reaches prod data | Possible | No cross-account access by default |
| Service Quotas (EIP limits, etc.) shared | Yes | Separate quotas per account |

The three accounts are:
```
company-dev         AWS ID: 123456789010   ap-northeast-1
company-staging     AWS ID: 123456789011   ap-northeast-1
company-production  AWS ID: 123456789012   ap-northeast-1
```

---

## Step 0.2 — S3 State Bucket + DynamoDB Lock (per account)

### The S3 backend block in Terraform:
```hcl
# From terraform/environments/dev/main.tf
backend "s3" {
  bucket         = "company-terraform-state-dev"   ← S3 bucket must exist BEFORE terraform init
  key            = "dev/terraform.tfstate"          ← path inside the bucket
  region         = "ap-northeast-1"
  encrypt        = true                              ← server-side encryption
  dynamodb_table = "terraform-state-lock"           ← table must exist BEFORE terraform apply
}
```

### What happens without the S3 bucket?
```
$ terraform init
│ Error: Failed to get existing workspaces: S3 bucket "company-terraform-state-dev" does not exist.
```
Terraform cannot even initialize. Nothing else works.

### What happens without DynamoDB?
```
$ terraform apply
│ Error: Error acquiring the state lock
│ Error message: ResourceNotFoundException: Requested resource not found
```
Or worse: two engineers run `apply` at the same time, both write state simultaneously, state file becomes corrupted. Recovery requires manually editing the state file — dangerous and slow.

### Why enable S3 versioning?
If `terraform apply` partially fails and corrupts `terraform.tfstate`, versioning lets you restore the previous good version from S3. Without versioning, that file is gone.

```bash
# Create state bucket (must do this BEFORE terraform init)
aws s3api create-bucket \
  --bucket company-terraform-state-dev \
  --region ap-northeast-1 \
  --create-bucket-configuration LocationConstraint=ap-northeast-1

# Versioning: recover from bad terraform applies
aws s3api put-bucket-versioning \
  --bucket company-terraform-state-dev \
  --versioning-configuration Status=Enabled

# Block public access (state files must NEVER be public — they contain ARNs, IDs)
aws s3api put-public-access-block \
  --bucket company-terraform-state-dev \
  --public-access-block-configuration \
    "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

# DynamoDB lock table — PAY_PER_REQUEST so you don't pay for idle capacity
aws dynamodb create-table \
  --table-name terraform-state-lock \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region ap-northeast-1
```

---

## Step 0.3 — Secrets in AWS Secrets Manager

### What Terraform reads from Secrets Manager:
```hcl
# From terraform/environments/dev/main.tf
data "aws_secretsmanager_secret_version" "dt_api_token" {
  secret_id = "dev/dynatrace/api-token"      ← must exist before terraform plan
}
data "aws_secretsmanager_secret_version" "dt_tenant_url" {
  secret_id = "dev/dynatrace/tenant-url"
}
data "aws_secretsmanager_secret_version" "slack_webhooks" {
  secret_id = "dev/dynatrace/slack-webhooks"
}
```

### Why Secrets Manager and not environment variables or `.tfvars` files?
| Location | Problem |
|----------|---------|
| `.tfvars` file in git | Token committed → exposed in git history forever |
| GitHub Actions secret | Only available in CI, can't run terraform locally |
| Hardcoded in `.tf` file | Worst — in git, in pull requests, visible to all reviewers |
| **Secrets Manager** | Encrypted, auditable, rotatable, readable locally + in CI |

### The slack webhooks secret format (JSON — multiple keys in one secret):
```json
{
  "payments": "https://hooks.slack.com/services/T.../B.../xxx",
  "orders":   "https://hooks.slack.com/services/T.../B.../yyy",
  "notifications": "https://hooks.slack.com/services/T.../B.../zzz"
}
```

In Terraform: `jsondecode(data.aws_secretsmanager_secret_version.slack_webhooks.secret_string)` converts this to a map. The Dynatrace module's `for_each` iterates over it to create one Slack notification per team.

### DB credentials secret (used by ExternalSecret in Helm charts):
```bash
# The ExternalSecret in charts/payment-service/templates/external-secret.yaml reads:
# key: "dev/payment-service/db-credentials" → properties: host, port, dbname, username, password
aws secretsmanager create-secret \
  --name dev/payment-service/db-credentials \
  --secret-string '{"host":"dev-db.cluster.ap-northeast-1.rds.amazonaws.com","port":"5432","dbname":"payments","username":"app","password":"REPLACE"}' \
  --region ap-northeast-1
```

---

## Step 0.4 — ECR Repositories

### Why ECR and not Docker Hub?
- ECR lives inside your AWS VPC — image pulls from EKS don't cross the internet
- The S3 VPC endpoint means Docker layer pulls are free (no NAT data charges)
- IAM-based auth — no separate Docker Hub credentials to manage
- `scanOnPush=true` — Trivy-equivalent scan runs automatically on every push

### Why one ECR per account (not one shared ECR)?
The CI/CD pipeline promotes the same image SHA across accounts:
```
DEV ECR (123456789010): sha:abc123    ← CI builds here
    ↓ docker pull + docker push
STAGING ECR (123456789011): sha:abc123  ← same bits
    ↓ docker pull + docker push
PRODUCTION ECR (123456789012): sha:abc123  ← same bits
```

If you used one shared ECR, dev operations would need production-account access → violates account isolation.

```bash
# Create in each account (3 accounts × 3 services = 9 repos total)
for svc in payment-service order-service notification-service; do
  aws ecr create-repository \
    --repository-name company/${svc} \
    --image-scanning-configuration scanOnPush=true \
    --encryption-configuration encryptionType=AES256 \
    --region ap-northeast-1
done
```

---

## Step 0.5 — GitHub Secrets and OIDC

### What GitHub needs to assume AWS IAM roles (OIDC — no stored credentials):
```
GitHub Secret Name           Value
──────────────────────────── ────────────────────────────────────────────────
(not needed — uses OIDC)
```

GitHub Actions uses OpenID Connect (OIDC) — it gets a temporary JWT token from GitHub's identity provider and exchanges it for AWS temporary credentials. No AWS access keys are stored as GitHub Secrets. The workflow YAML uses:
```yaml
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789010:role/github-actions-ecr-push
    aws-region: ap-northeast-1
```

For this to work, the IAM role must trust GitHub's OIDC provider. The trust policy on the role:
```json
{
  "Effect": "Allow",
  "Principal": { "Federated": "arn:aws:iam::123456789010:oidc-provider/token.actions.githubusercontent.com" },
  "Action": "sts:AssumeRoleWithWebIdentity",
  "Condition": {
    "StringLike": {
      "token.actions.githubusercontent.com:sub": "repo:company/java-3envs-dynatrace:*"
    }
  }
}
```

### IAM Roles needed per account:
| Role name | Permissions | Used by |
|-----------|-------------|---------|
| `github-actions-ecr-push` | ECR push to this account | CI build/promote jobs |
| `github-actions-ecr-read` | ECR pull from this account | CI promote jobs (pull from prev env) |
| `github-actions-infra-plan` | Terraform read-only | PR plan jobs |
| `github-actions-infra-apply` | Terraform full access | Push apply jobs |
| `company-dev-aws-load-balancer-controller` | ELB + ACM APIs | ALB Controller pod (IRSA) |
| `company-dev-external-dns` | Route53 APIs | ExternalDNS pod (IRSA) |
| `company-dev-eso` | Secrets Manager read | ESO pod (IRSA) |
| `company-dev-payment-service` | Service-specific AWS APIs | App pod (IRSA) |

---

## Step 0.6 — GitHub Environment: "production" with Required Reviewers

### What this does in the CI pipeline:
```yaml
# From payment-service-ci.yaml
promote-to-production:
  environment: production     ← ← ← THIS LINE pauses the pipeline
```

When a job has `environment: production` and the GitHub environment has required reviewers configured, GitHub:
1. Sends notifications to all required reviewers
2. Pauses the job (it shows as "waiting")
3. The job ONLY runs after a reviewer clicks Approve
4. If no reviewer acts within the timeout, the job fails

**Without this:** every push to main auto-deploys to production. One bad commit = production outage with zero human review.

**Setup:** GitHub repo → Settings → Environments → New environment: `production` → Required reviewers: add 2+ team leads → Wait timer: 0 (or set to 5 min to prevent accidental clicks).

---

## Summary: What breaks if you skip each item

| Skipped item | First failure | When |
|-------------|--------------|------|
| S3 state bucket | `terraform init` fails: `NoSuchBucket` | Immediately |
| DynamoDB lock table | `terraform apply` fails: `ResourceNotFoundException` | On first apply |
| DT secrets in Secrets Manager | `terraform plan` fails: `ResourceNotFoundException` | During plan |
| DB secrets in Secrets Manager | ESO ExternalSecret: `SecretSyncError` | After wave 2 |
| ECR repositories | `docker push` fails: `RepositoryNotFoundException` | First CI run |
| OIDC IAM roles | GitHub Actions: `Could not assume role` | First CI run |
| GitHub `production` environment | Production auto-deploys without approval | Silent — dangerous |
