# Phase 3 — ArgoCD Sync Waves Deep Dive

> After the root-app bootstrap (Phase 2), ArgoCD manages everything automatically. This phase explains what ACTUALLY happens inside each wave — line by line through the YAML files.

---

## The Full Wave Map

```
Wave -1  │  namespaces/namespaces.yaml          Creates 5 namespaces with Dynatrace labels
Wave  1  │  networking/aws-load-balancer-       Installs ALB controller via Helm
         │  controller.yaml                     
         │  networking/external-dns.yaml         Installs ExternalDNS via Helm
Wave  2  │  secrets/cluster-secret-store.yaml   Installs ESO + creates ClusterSecretStore
Wave  3  │  monitoring/dynatrace/               Installs DT Operator + fetches DT tokens
         │  dynatrace-operator.yaml              from Secrets Manager + creates DynaKube
Wave  8  │  app/payment-service/               Renders Helm chart (values+values-dev)
         │  payment-service.yaml                → Deployment, Service, Ingress, HPA, PDB,
         │  app/order-service/...               ExternalSecret, ServiceAccount
         │  app/notification-service/...
```

---

## WAVE -1 — Namespaces

### The YAML (gitops/dev/namespaces/namespaces.yaml):
```yaml
kind: Application
annotations:
  argocd.argoproj.io/sync-wave: "-1"      ← deploys first, before everything
spec:
  path: charts/namespaces                   ← references the namespaces Helm chart
  helm:
    values: |
      environment: dev
      namespaces:
        - name: payment-ns
          labels: { team: payments, environment: dev }
        - name: order-ns
          labels: { team: orders, environment: dev }
        - name: notification-ns
          labels: { team: notifications, environment: dev }
        - name: dynatrace
          labels: { team: platform, environment: dev }
        - name: external-secrets
          labels: { team: platform, environment: dev }
```

### The Helm template that renders this (charts/namespaces/templates/namespace.yaml):
```yaml
{{- range .Values.namespaces }}
apiVersion: v1
kind: Namespace
metadata:
  name: {{ .name }}
  labels:
    {{- range $k, $v := .labels }}
    {{ $k }}: {{ $v }}
    {{- end }}
    pod-security.kubernetes.io/enforce: restricted    ← Pod Security Standards
    pod-security.kubernetes.io/warn: restricted
{{- end }}
```

### Why namespace labels are critical (Dynatrace auto-tagging):

The namespace labels `team: payments` and `environment: dev` propagate to pod labels through the Helm `commonLabels` field in each service chart. OneAgent reads pod labels via the Kubernetes API and uses them for auto-tagging.

```
Namespace label: team=payments
        ↓
Pod inherits label via commonLabels in Helm chart
        ↓
Dynatrace OneAgent reads pod metadata from K8s API
        ↓
Service in Dynatrace tagged: team:payments, environment:dev
        ↓
Management zone rule: SERVICE_TAGS contains team:payments AND environment:dev
        ↓
Service appears in "payments-dev" management zone
        ↓
Only payments team sees this service's alerts
```

If you deploy an app to an unlabeled namespace, it appears in Dynatrace with no management zone → wrong team's dashboard → missed alerts.

### `pod-security.kubernetes.io/enforce: restricted`

This namespace label activates Kubernetes Pod Security Standards (PSS). Any pod that doesn't meet the "restricted" profile is REJECTED at admission — it won't start at all. The restricted profile requires:
- `runAsNonRoot: true` (no root processes)
- `readOnlyRootFilesystem: true`
- `capabilities.drop: ["ALL"]`
- No host networking/PID/IPC

The payment-service Deployment's `securityContext` is designed to satisfy all these constraints. If you add a new container without these settings, it will be rejected by this namespace policy.

---

## WAVE 1 — Networking

### ALB Controller (aws-load-balancer-controller.yaml):
```yaml
kind: Application
annotations:
  argocd.argoproj.io/sync-wave: "1"
spec:
  source:
    repoURL: https://aws.github.io/eks-charts
    chart: aws-load-balancer-controller
    targetRevision: "1.7.2"
  helm:
    values: |
      clusterName: company-dev
      serviceAccount:
        annotations:
          eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-aws-load-balancer-controller
      replicaCount: 1          ← dev: 1 replica. production: 2 replicas
```

**What the ALB controller does:**
1. Watches Kubernetes `Ingress` resources
2. When it sees an Ingress with `ingressClassName: alb`, it calls AWS APIs to:
   - Create an Application Load Balancer
   - Create target groups pointing to pod IPs (not node IPs — `target-type: ip`)
   - Create HTTPS listener with the ACM cert
   - Add health check on `/actuator/health/readiness`
3. When the Ingress is deleted, it deletes the ALB

**Why `target-type: ip` (not `instance`)?**
- `instance` mode: ALB routes to NodePort on each EC2 node → node then routes to pod (extra hop)
- `ip` mode: ALB routes directly to the pod's IP address
- With the VPC CNI, each pod has a real VPC IP address. Direct routing is faster, no double NAT, and health checks test the actual pod (not the node's port)

**The IRSA annotation:**
```yaml
eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-aws-load-balancer-controller
```

The ALB controller ServiceAccount is annotated with this IAM role. When the pod starts, it automatically gets AWS credentials scoped to this role. The role needs permissions: `elasticloadbalancing:*`, `ec2:Describe*`, `iam:CreateServiceLinkedRole`, `acm:DescribeCertificate`.

Without IRSA: the controller pod has no AWS credentials → every `kubectl apply Ingress` results in `AWS access denied` → ALB never created → service unreachable.

### ExternalDNS (external-dns.yaml):
```yaml
helm:
  values: |
    serviceAccount:
      annotations:
        eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-external-dns
    provider: aws
    aws:
      region: ap-northeast-1
    domainFilters:
      - dev.company.com            ← ONLY manages records under this domain
    policy: sync                   ← creates AND deletes DNS records
    txtOwnerId: "company-dev"      ← ownership marker in Route53
```

**The `domainFilters` safety net:**
Without `domainFilters: [dev.company.com]`, the dev ExternalDNS could modify ANY Route53 record in your account — including production records. The filter makes it physically impossible for dev ExternalDNS to touch `payment.company.com` (production).

**`txtOwnerId: "company-dev"`:**
ExternalDNS creates a TXT record alongside every A record it manages:
```
payment.dev.company.com    A      10.0.1.1 (ALB IP)
payment.dev.company.com    TXT    "heritage=external-dns,owner=company-dev,resource=ingress/payment-service"
```
The TXT record marks ownership. When a different ExternalDNS instance runs (e.g. staging ExternalDNS with `txtOwnerId: "company-staging"`), it only manages TXT records with its own owner ID. Without `txtOwnerId`, two ExternalDNS instances delete each other's records.

**`policy: sync`:** ExternalDNS both creates records when Ingresses appear AND deletes them when Ingresses are removed. This is safe because `domainFilters` prevents it from touching the wrong domain.

---

## WAVE 2 — External Secrets Operator

### The cluster-secret-store.yaml deploys TWO resources:

**Resource 1: ESO itself (as an ArgoCD Application):**
```yaml
kind: Application
annotations:
  argocd.argoproj.io/sync-wave: "2"
spec:
  source:
    repoURL: https://charts.external-secrets.io
    chart: external-secrets
    targetRevision: "0.9.0"
  helm:
    values: |
      serviceAccount:
        annotations:
          eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-eso
```

ESO is a Kubernetes controller — it watches for `ExternalSecret` custom resources and creates native K8s `Secrets` from them. The IRSA role annotation gives its ServiceAccount permission to call `secretsmanager:GetSecretValue`.

**Resource 2: ClusterSecretStore:**
```yaml
apiVersion: external-secrets.io/v1beta1
kind: ClusterSecretStore
metadata:
  name: aws-secrets-manager
  annotations:
    argocd.argoproj.io/sync-wave: "2"
spec:
  provider:
    aws:
      service: SecretsManager
      region: ap-northeast-1
      auth:
        jwt:
          serviceAccountRef:
            name: external-secrets
            namespace: external-secrets
```

`ClusterSecretStore` is cluster-scoped (not namespaced). It defines the connection to AWS Secrets Manager using JWT auth (IRSA). Any `ExternalSecret` in any namespace can reference it by name (`aws-secrets-manager`).

### The ExternalSecret lifecycle (in wave 3 and wave 8):

```
ExternalSecret created in wave 3 (for DT tokens):
  spec:
    refreshInterval: 1h                          ← re-read from Secrets Manager every hour
    secretStoreRef:
      name: aws-secrets-manager                  ← use the ClusterSecretStore from wave 2
    target:
      name: dynakube                             ← create a K8s Secret named "dynakube"
      creationPolicy: Owner                      ← delete the K8s Secret when this ExternalSecret is deleted
    data:
      - secretKey: apiToken
        remoteRef: { key: dev/dynatrace/api-token }   ← path in Secrets Manager

Result → K8s Secret created:
  kind: Secret
  metadata:
    name: dynakube
    namespace: dynatrace
    ownerReferences: [ExternalSecret/dynakube-tokens]  ← Owner cleanup
  data:
    apiToken: <base64 encoded DT api token>
```

**`creationPolicy: Owner` — why it matters:**
When the ExternalSecret is deleted (e.g. uninstalling Dynatrace), the K8s Secret is automatically deleted too. Without this, deleting the ExternalSecret leaves the Secret orphaned — containing the DT API token forever.

**`refreshInterval: 1h`:**
If the DT API token is rotated in Secrets Manager, ESO picks up the new value within 1 hour. The DynaKube reads the updated Secret and reconnects to Dynatrace using the new token — no pod restart required.

---

## WAVE 3 — Dynatrace Operator + DynaKube

### The dynatrace-operator.yaml deploys THREE resources:

**Resource 1: DT Operator (via Helm):**
```yaml
kind: Application
annotations:
  argocd.argoproj.io/sync-wave: "3"
spec:
  source:
    chart: dynatrace-operator
    targetRevision: "1.3.0"
  helm:
    values: |
      installCRD: true               ← install DynaKube CRD
      resources:
        limits: { cpu: 200m, memory: 256Mi }
```

The Operator is a controller. It watches for `DynaKube` custom resources and deploys the actual monitoring stack.

**Resource 2: ExternalSecret for DT tokens:**
```yaml
kind: ExternalSecret
metadata:
  name: dynakube-tokens
  namespace: dynatrace
  annotations:
    argocd.argoproj.io/sync-wave: "3"
spec:
  data:
    - secretKey: apiToken
      remoteRef: { key: dev/dynatrace/api-token }
    - secretKey: dataIngestToken
      remoteRef: { key: dev/dynatrace/paas-token }
```

This fetches both DT tokens from Secrets Manager and creates the `dynakube` K8s Secret. The DynaKube resource in Resource 3 reads from this Secret.

**Resource 3: DynaKube (the monitoring configuration):**
```yaml
apiVersion: dynatrace.com/v1beta1
kind: DynaKube
metadata:
  name: dynakube
  namespace: dynatrace
  annotations:
    argocd.argoproj.io/sync-wave: "3"
    feature.dynatrace.com/automatic-kubernetes-api-monitoring: "true"    ← [A]
spec:
  apiUrl: https://PLACEHOLDER.live.dynatrace.com/api
  tokens: dynakube                      ← reads the K8s Secret named "dynakube"
  classicFullStack:
    enabled: true                       ← [B]
    tolerations:
      - key: node-role.kubernetes.io/control-plane
        operator: Exists
        effect: NoSchedule              ← [C]
    resources:
      requests: { cpu: 100m, memory: 512Mi }
      limits:   { cpu: 300m, memory: 768Mi }
  logMonitoring:
    enabled: true                       ← [D]
  activeGate:
    capabilities: [routing, kubernetes-api-monitoring, log-analytics]
    replicas: 1                         ← dev: 1. production: 2 (HA)
```

**[A] `automatic-kubernetes-api-monitoring: true`**
ActiveGate calls the Kubernetes API server to scrape cluster-level metrics: node CPU/memory, pod counts, deployment health. These appear in Dynatrace's Kubernetes dashboards. Without this, DT only shows application-level metrics.

**[B] `classicFullStack: enabled: true`**
The full-stack monitoring mode deploys OneAgent as a DaemonSet. OneAgent on each node:
1. Hooks into every JVM on the node via JVMTI (Java Virtual Machine Tool Interface)
2. Instruments HTTP request handling, DB connections, external service calls
3. Captures JVM metrics: heap, GC, thread counts
4. Captures infrastructure metrics: CPU, memory, network, disk

Zero application code changes needed. OneAgent does everything transparently.

**[C] `tolerations: node-role.kubernetes.io/control-plane`**
Without this toleration, OneAgent pods only run on worker nodes. With it, they also run on control plane nodes. For self-managed Kubernetes this matters; for EKS the control plane is managed by AWS and not accessible, but the toleration is harmless to include.

**[D] `logMonitoring: enabled: true`**
OneAgent tails container logs and streams them to Dynatrace. Combined with application labels (team, environment), you can search logs in Dynatrace's Log Viewer filtered to `environment:dev` AND `team:payments`.

### What happens after DynaKube is applied:

```
1. Dynatrace Operator reads DynaKube
2. Creates OneAgent DaemonSet:
   - Schedules one OneAgent pod per node
   - Each pod mounts /proc and /sys (to monitor host)
   - Each pod JVMTI-instruments all JVM processes on that node

3. Creates ActiveGate Deployment:
   - 1 pod (dev), 2 pods spread across AZs (production)
   - OneAgent pods connect to ActiveGate (not directly to DT cloud)
   - ActiveGate batches and forwards: metrics, traces, logs, events

4. After ~60 seconds: Dynatrace SaaS tenant starts receiving data
   - Services appear automatically (payment-service, order-service)
   - JVM heap charts populate
   - HTTP request dashboards appear
   - Management zones start showing data (matching namespace labels)
```

---

## WAVE 8 — Applications (payment-service deep dive)

### The payment-service.yaml ArgoCD Application:
```yaml
kind: Application
annotations:
  argocd.argoproj.io/sync-wave: "8"
spec:
  source:
    path: charts/payment-service
    helm:
      valueFiles: [values.yaml, values-dev.yaml]    ← merge order: base then dev overrides
      values: |
        image:
          repository: 123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
          tag: "PLACEHOLDER"                         ← CI replaces this
        serviceAccount:
          annotations:
            eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-payment-service
        ingress:
          host: payment.dev.company.com
        envFromSecret: payment-service-db-credentials
  ignoreDifferences:
    - group: apps
      kind: Deployment
      jsonPointers: [/spec/replicas]
```

### Helm values merge: what wins?

```
values.yaml (base = production defaults):      values-dev.yaml (dev overrides):
  replicaCount: 3                                replicaCount: 1         ← WINS
  image.pullPolicy: IfNotPresent                 image.pullPolicy: Always ← WINS
  resources.limits.memory: 1Gi                   resources.limits.memory: 512Mi ← WINS
  pdb.enabled: true                              pdb.enabled: false       ← WINS
  JVM_OPTS: -Xms512m -Xmx1024m                  JVM_OPTS: -Xms128m -Xmx256m + jdwp ← WINS
  LOG_LEVEL: WARN                                LOG_LEVEL: DEBUG         ← WINS
  topologySpread: DoNotSchedule                  topologySpread: ScheduleAnyway ← WINS
  startupProbe.failureThreshold: 60             startupProbe.failureThreshold: 120 ← WINS
```

Fields NOT in `values-dev.yaml` fall through to `values.yaml`:
- `service.type: ClusterIP` (same in all envs)
- `readinessProbe`, `livenessProbe` (same config)
- `lifecycle.preStop` (same 15s sleep)
- `terminationGracePeriodSeconds: 60`

### The Deployment template after Helm renders it (dev):

```yaml
# charts/payment-service/templates/deployment.yaml after rendering for dev:
apiVersion: apps/v1
kind: Deployment
metadata:
  name: payment-service
  namespace: payment-ns
  labels:
    app: payment-service
    team: payments                  ← from commonLabels (dev override)
    environment: dev                ← OneAgent reads this → auto-tag
spec:
  replicas: 1                       ← from values-dev.yaml
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 0             ← ZERO downtime: no old pod removed until new one is ready
      maxSurge: 1                   ← one extra pod during update
  template:
    spec:
      serviceAccountName: payment-service   ← IRSA: pod gets AWS credentials
      securityContext:
        runAsNonRoot: true
        runAsUser: 1000
        fsGroup: 1000
      topologySpreadConstraints:
        - maxSkew: 1
          topologyKey: topology.kubernetes.io/zone
          whenUnsatisfiable: ScheduleAnyway   ← dev: best-effort AZ spread
      containers:
        - name: payment-service
          image: "123456789010.dkr.ecr.../payment-service:PLACEHOLDER"
          imagePullPolicy: Always              ← dev: always pull (test latest changes)
          ports:
            - containerPort: 8080
          envFrom:
            - secretRef:
                name: payment-service-db-credentials   ← populated by ExternalSecret
          env:
            - { name: LOG_LEVEL, value: "DEBUG" }      ← dev override
            - { name: JVM_OPTS,  value: "-Xms128m -Xmx256m -XX:+UseContainerSupport -agentlib:jdwp=..." }
          resources:
            requests: { cpu: 100m, memory: 384Mi }
            limits:   { cpu: 500m, memory: 512Mi }
          startupProbe:
            httpGet: { path: /actuator/health/liveness, port: 8080 }
            failureThreshold: 120    ← dev: 20 minutes (cold cache + slow hardware)
            periodSeconds: 10
          readinessProbe:
            httpGet: { path: /actuator/health/readiness, port: 8080 }
            periodSeconds: 5
            failureThreshold: 3      ← 3 failures = removed from Service endpoints
          livenessProbe:
            httpGet: { path: /actuator/health/liveness, port: 8080 }
            periodSeconds: 15
            failureThreshold: 3      ← 3 failures = pod killed and restarted
          lifecycle:
            preStop:
              exec:
                command: ["/bin/sh", "-c", "sleep 15"]   ← ALB deregisters before SIGTERM
          securityContext:
            readOnlyRootFilesystem: true      ← can't write to container filesystem
            allowPrivilegeEscalation: false
            capabilities:
              drop: ["ALL"]                   ← no Linux capabilities
      terminationGracePeriodSeconds: 60       ← Spring graceful shutdown has 30s, +30s buffer
```

### The ExternalSecret for DB credentials:
```yaml
# charts/payment-service/templates/external-secret.yaml (rendered for dev)
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: payment-service-db-credentials
  namespace: payment-ns
spec:
  refreshInterval: 1h
  secretStoreRef:
    name: aws-secrets-manager
    kind: ClusterSecretStore             ← references wave 2's ClusterSecretStore
  target:
    name: payment-service-db-credentials   ← K8s Secret that gets created
    creationPolicy: Owner
  data:
    - secretKey: DB_HOST
      remoteRef:
        key: dev/payment-service/db-credentials   ← Secrets Manager path
        property: host
    - secretKey: DB_PASSWORD
      remoteRef:
        key: dev/payment-service/db-credentials
        property: password
    # ... DB_PORT, DB_NAME, DB_USERNAME
```

The K8s Secret `payment-service-db-credentials` is created by ESO and contains all 5 DB fields. The Deployment's `envFrom.secretRef` mounts all keys as environment variables (DB_HOST, DB_PORT, etc.) inside the container. The app connects to the database using these variables.

### The Ingress (after ALB controller processes it):
```yaml
# charts/payment-service/templates/ingress.yaml (rendered for dev)
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  annotations:
    alb.ingress.kubernetes.io/scheme: internet-facing      ← public ALB
    alb.ingress.kubernetes.io/target-type: ip              ← route to pod IPs directly
    alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS": 443}]'
    alb.ingress.kubernetes.io/certificate-arn: <ACM cert>
    alb.ingress.kubernetes.io/ssl-redirect: "443"          ← HTTP → HTTPS redirect
    alb.ingress.kubernetes.io/healthcheck-path: /actuator/health/readiness
    alb.ingress.kubernetes.io/healthcheck-interval-seconds: "15"
spec:
  ingressClassName: alb
  rules:
    - host: payment.dev.company.com
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service:
                name: payment-service
                port:
                  number: 80
```

When this Ingress is applied:
1. ALB controller reads it
2. Creates an AWS ALB with two listeners (80 → redirect to 443, 443 → forward)
3. Creates a target group for the `payment-service` ClusterIP Service
4. Registers pod IPs as targets in the target group
5. ALB starts health checking `/actuator/health/readiness` every 15 seconds
6. If a pod fails readiness: ALB marks its IP unhealthy → no traffic routes to it

Then ExternalDNS:
1. Sees the new Ingress with `host: payment.dev.company.com`
2. Checks `domainFilters: [dev.company.com]` — matches
3. Creates Route53 record: `payment.dev.company.com → <ALB DNS name>`
4. Traffic flows: browser → Route53 → ALB → healthy pods

---

## Wave 8 HPA and PDB

### HPA (hpa.yaml):
```yaml
spec:
  minReplicas: 3           ← production. dev: 1
  maxReplicas: 20          ← production. dev: 3
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70    ← scale up when avg CPU > 70%
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: 80    ← scale up when avg memory > 80%
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300    ← wait 5 min before scaling down
      policies:
        - type: Pods
          value: 1
          periodSeconds: 60              ← remove at most 1 pod per minute when scaling down
    scaleUp:
      policies:
        - type: Pods
          value: 3
          periodSeconds: 60              ← add up to 3 pods per minute when scaling up
```

**Why `stabilizationWindowSeconds: 300` for scale-down?**
Traffic is spiky. After a 5-minute burst, CPU drops. Without the stabilization window, HPA would immediately scale down — then the next burst arrives and HPA must scale up again. This oscillation wastes time (scaling takes 1-2 minutes) and causes latency spikes. The 5-minute window says: "only scale down if CPU has been low for 5 consecutive minutes."

**Why asymmetric: scale-up 3 pods/min, scale-down 1 pod/min?**
Scale up fast (3 pods) to handle sudden traffic surge immediately. Scale down slowly (1 pod) to avoid removing capacity that might be needed again soon.

### PDB (pdb.yaml) — only exists in staging and production:
```yaml
# In dev: pdb.enabled: false → this file renders nothing
# In staging: pdb.enabled: true, minAvailable: 1
# In production: pdb.enabled: true, minAvailable: 2
{{- if .Values.pdb.enabled }}
apiVersion: policy/v1
kind: PodDisruptionBudget
spec:
  minAvailable: {{ .Values.pdb.minAvailable }}   # production: 2
  selector:
    matchLabels:
      app: payment-service
{{- end }}
```

With `minAvailable: 2` and 3 replicas:
- At most 1 pod can be down at any moment
- During a node drain (maintenance, Karpenter consolidation): Kubernetes evicts pods one at a time, waiting for the replacement to be ready before evicting the next
- Without PDB: all 3 pods could be evicted simultaneously → complete outage during maintenance
