# Phase Deep Dives — Glossary for SRE Beginners

Every term used across all 6 phase deep dive files.

---

**OIDC (OpenID Connect)**
An identity protocol that lets GitHub prove to AWS "I am a GitHub Actions job from this repo" without storing AWS credentials as GitHub Secrets. GitHub gets a signed JWT token from GitHub's identity provider and exchanges it with AWS STS for temporary credentials. The credentials expire after the job ends. No long-lived secrets anywhere.

**STS (AWS Security Token Service)**
AWS service that issues temporary, short-lived credentials. When GitHub Actions does OIDC auth, it calls STS to exchange the JWT for temporary IAM credentials. These credentials auto-expire — if stolen, they can't be used after the job ends.

**JWT (JSON Web Token)**
A digitally signed token that carries claims: "I am GitHub Actions job X from repo Y, commit Z." AWS trusts the signature because it's signed by GitHub's known private key. AWS can verify it without calling GitHub.

**CIDR (Classless Inter-Domain Routing)**
A compact notation for IP address ranges. `10.0.0.0/16` means "all IPs starting with 10.0.x.x" (65,536 addresses). `/24` means 256 addresses. `/20` means 4,096 addresses. The number after the slash is the "prefix length" — higher = smaller range.

**`cidrsubnet()`**
Terraform function that carves a smaller subnet out of a larger CIDR block. `cidrsubnet("10.0.0.0/16", 8, 1)` adds 8 bits to the prefix (making /24) and picks the 1st such subnet = `10.0.1.0/24`. Used in the VPC module to calculate subnet CIDRs automatically.

**VPC CNI (Container Network Interface)**
AWS's VPC-native networking plugin for Kubernetes. Assigns a real VPC IP address to every pod — the same private IPs your EC2 instances use. Enables ALB target-type=ip (direct pod routing). Required for EKS.

**etcd**
A distributed key-value store that is the Kubernetes database. It stores all cluster state: pod definitions, secrets, config maps, deployment specs. Everything `kubectl get` returns comes from etcd. etcd encryption means secrets at rest in etcd are unreadable without the KMS key.

**CoreDNS**
The DNS server running inside Kubernetes. When `payment-service` calls `order-service:8080`, CoreDNS resolves `order-service` to the ClusterIP. Without CoreDNS, pod-to-pod communication by service name fails. It's an EKS managed add-on.

**kube-proxy**
Runs as a DaemonSet on every node. Manages iptables rules that implement Kubernetes Service load balancing. When traffic arrives for a ClusterIP Service, kube-proxy's rules redirect it to one of the healthy pod IPs.

**EBS CSI Driver**
AWS's storage plugin for Kubernetes. Required for `PersistentVolumeClaim` resources that ask for persistent disk storage. Without it, Kubernetes can't provision EBS volumes for stateful workloads. EKS 1.23+ requires this add-on explicitly.

**Control plane (Kubernetes)**
The set of components that manage the cluster: API server (handles kubectl), etcd (stores state), scheduler (assigns pods to nodes), controller-manager (runs reconciliation loops). In EKS, AWS manages the control plane — you never SSH into it.

**Worker node**
The EC2 instance that runs your actual application pods. EKS manages the control plane; you manage (or AWS manages via managed node groups) the worker nodes. Worker nodes register themselves to the control plane on startup.

**Managed node group**
An EKS feature where AWS manages EC2 Auto Scaling Groups for your worker nodes. AWS handles node creation, registration, updates, and draining. You specify instance type and size; AWS does the rest.

**Taint and Toleration**
Kubernetes scheduling mechanism. A taint on a node says "don't schedule pods here unless they explicitly tolerate this." `dedicated=system:NoSchedule` on system nodes keeps application pods off those nodes. Tolerations on system pods let them run there. Ensures infra pods and app pods don't compete for resources.

**`for_each` (Terraform)**
Terraform meta-argument that creates one resource instance per item in a map or set. `for_each = var.services` on a `dynatrace_metric_events` resource creates one metric event per service. If you add a service to the map, Terraform creates one more event automatically.

**`toset()`**
Terraform function that converts a list to a set (removes duplicates, unordered). Used in the Dynatrace module to get unique team names from the services map: `toset([for svc in values(var.services) : svc.team])`.

**`contains()` (Terraform)**
Terraform function that returns true if a list contains a value. `contains(["production", "staging"], var.environment)` is true when the module is called for production or staging. Used to conditionally create PagerDuty alerts for those environments only.

**JVMTI (Java Virtual Machine Tool Interface)**
A Java API that allows external tools to hook into a running JVM. Dynatrace OneAgent uses JVMTI to attach to every JVM process on a node and inject bytecode instrumentation — capturing method entry/exit times, exceptions, HTTP request data — with zero application code changes.

**RSS (Resident Set Size)**
The total amount of physical memory a process is actually using, including heap, off-heap memory (metaspace, code cache, native buffers), and shared libraries. An OOMKill happens when RSS hits the container's memory limit, not when heap hits Xmx.

**G1GC (Garbage First Garbage Collector)**
Java's modern low-latency garbage collector. Divides the heap into small regions and collects the regions with the most garbage first ("garbage first"). Designed for heaps over 4GB with pause time goals under 200ms. Behavior becomes non-linear above ~70% heap utilization.

**JIT (Just-In-Time compiler)**
Java's mechanism that detects hot code paths (executed thousands of times) and compiles them to optimized native machine code. A cold JVM runs bytecode interpreted (slow). After 30-60 seconds of traffic, the JIT has compiled hot paths — performance stabilizes at 3-10× faster.

**`-XX:+UseContainerSupport`**
JVM flag (on by default in Java 11+) that reads Linux cgroup memory limits to determine heap size. Without it on older JVMs: the JVM sees the host's 64GB RAM, allocates a 48GB heap, immediately exceeds the 512Mi container limit → instant OOMKill.

**`-XX:MaxGCPauseMillis=200`**
G1GC tuning flag: "try to keep GC pause times under 200ms." G1 is a soft target — it tries but doesn't guarantee. Sets the expectation for the GC algorithm's region collection size. Production uses this; dev doesn't because dev is tolerant of GC pauses.

**Graceful shutdown**
The process of stopping a service cleanly: stop accepting new requests, finish in-flight requests, release resources (DB connections, file handles), then exit. Spring Boot's `server.shutdown: graceful` does this when it receives SIGTERM. Combined with preStop sleep, ensures no dropped requests during rolling updates.

**SIGTERM / SIGKILL**
Unix signals sent to processes. SIGTERM (signal 15) is the polite shutdown request — the process can catch it and clean up. SIGKILL (signal 9) is the immediate kill — the process cannot catch or ignore it, it just dies. Kubernetes always sends SIGTERM first, waits `terminationGracePeriodSeconds`, then sends SIGKILL.

**Rolling update**
Kubernetes deployment strategy: deploy the new version gradually, one pod at a time, while keeping the old version running. `maxUnavailable: 0` means never remove a pod until a replacement is Ready. `maxSurge: 1` means run one extra pod during the update. Net effect: always at least the configured number of pods serving traffic.

**Canary deployment**
A deployment strategy (not used here but related) where a small percentage of traffic goes to the new version while the rest goes to the old. More controlled than rolling update but requires traffic splitting infrastructure (service mesh or weighted target groups).

**Blue-green deployment**
A deployment strategy (not used here) where two complete environments (blue=current, green=new) run simultaneously, and traffic is switched all at once. Allows instant rollback by switching traffic back. Requires double the infrastructure.

**`sed -i`**
The Unix stream editor with in-place flag. `sed -i "s|old|new|" file` replaces `old` with `new` directly in the file. The CI pipeline uses this to update the Docker image tag in the GitOps YAML: `sed -i "s|tag: \".*\"|tag: \"$SHA\"|"`.

**`git log --oneline -- <path>`**
Shows git commit history for a specific file, one line per commit. Used in the auto-rollback script to find the previous image tag: the second entry in the log for `gitops/production/app/payment-service/payment-service.yaml` is the previous deploy.

**`fetch-depth: 0`**
GitHub Actions `checkout` setting that fetches the complete git history instead of just the last commit (default is `depth=1`). Required for the auto-rollback script because it uses `git log` which needs history going back at least 2 commits on the gitops file.

**VU (Virtual User) — k6**
A simulated concurrent user in a k6 load test. `--vus 50` means 50 virtual users each independently sending requests to the service, simulating 50 concurrent real users. Each VU runs the test script in a loop for the duration.

**k6 threshold**
A pass/fail criterion in a k6 load test. `http_req_failed: ['rate<0.01']` means "the test fails if more than 1% of requests fail." If any threshold is violated, k6 exits with code 1 → CI marks the job failed.

**`docker buildx`**
Docker's multi-platform build tool. `--platform linux/amd64,linux/arm64` builds the image for both x86 and ARM architectures in one command, producing a multi-arch manifest. Whoever pulls the image gets the right architecture automatically.

**Multi-arch manifest**
A Docker image "index" that contains multiple architecture-specific images under one tag. When you `docker pull myimage:latest`, Docker checks your machine's architecture (amd64 or arm64) and pulls the matching image automatically. Enables one tag to work everywhere.

**Trivy CVE database**
The vulnerability database that Trivy scans against. Contains known vulnerabilities (CVEs) with severity ratings (Critical, High, Medium, Low, Informational) and whether a fixed version exists. `ignore-unfixed: true` skips CVEs with no available fix.

**`exit-code: '1'` (Trivy)**
Tells Trivy to return a non-zero exit code (failure) when vulnerabilities are found. Without this, Trivy just prints the findings and exits 0 (success). CI needs exit code 1 to mark the step as failed and stop the pipeline.

**Burn rate (SLO)**
How fast an SLO's error budget is being consumed relative to the expected rate. A burn rate of 1.0 means the budget is depleting at exactly the expected rate and will be exhausted right at the end of the SLO window. A burn rate of 14.4 means it will be exhausted in 1/14.4 of the window = ~2 days for a monthly SLO.

**`evaluation_window: "-1M"`**
Dynatrace SLO setting meaning "evaluate over the last 1 month rolling window." Every day, the window shifts forward by one day. You always see the SLO compliance for the most recent 30 days, not a fixed calendar month.

**`alert_on_no_data`**
Dynatrace metric event setting. When true: if no data points arrive during the evaluation window, treat it as if the threshold was violated. Catches silent outages where the service has crashed completely and isn't even emitting metrics.

**Synthetic probe location**
A data center operated by Dynatrace from which synthetic monitors run. `GEOLOCATION-6F55B7E4B5E7A52F` = Tokyo (ap-northeast-1). The monitor is sent from this location every 5 minutes to test the service from a realistic external network position.

**`domainFilters` (ExternalDNS)**
A safety constraint that limits ExternalDNS to only creating/modifying DNS records under specified domains. `domainFilters: [dev.company.com]` means ExternalDNS physically cannot modify `payment.company.com` (production DNS), even if it has Route53 permissions.

**`txtOwnerId` (ExternalDNS)**
An ownership marker that ExternalDNS writes as a TXT record alongside every DNS A record it creates. Multiple ExternalDNS instances (dev, staging, production) only delete records they own. Without this, dev ExternalDNS could delete production DNS records during a cleanup.

**AppProject (ArgoCD)**
An ArgoCD RBAC sandbox that defines which Git repositories can deploy to which clusters and namespaces. The `platform` project allows system-level deployments. The `payments` project allows only deployments to `payment-ns`. Prevents cross-team deployments.

**`resources-finalizer.argocd.argoproj.io`**
An ArgoCD finalizer on an Application. When you delete the Application, ArgoCD first deletes all Kubernetes resources it manages, then removes the Application. Without it, deleting an ArgoCD Application leaves all deployed resources running as orphans.

**`ServerSideApply=true` (ArgoCD)**
Uses Kubernetes Server-Side Apply (SSA) instead of client-side apply. SSA tracks field ownership at the server level, preventing "last-writer-wins" conflicts. Required for some CRDs with complex field managers (like Dynatrace Operator resources).

**`prune: true` (ArgoCD)**
Tells ArgoCD to delete Kubernetes resources when their YAML is removed from the Git repository. Without prune, deleting `payment-service.yaml` from git leaves the Deployment, Service, Ingress, and all related resources running indefinitely in the cluster.

**Pod Security Standards (restricted)**
A Kubernetes built-in security policy enforced via namespace labels. The "restricted" profile requires: non-root user, read-only root filesystem, no privilege escalation, no host networking/PID/IPC, all capabilities dropped. Pods that violate this are rejected at admission — they never start.

**`capabilities.drop: ["ALL"]`**
Linux security setting. A process normally has capabilities like `NET_ADMIN` (modify network), `SYS_TIME` (change system clock), `CAP_SYS_PTRACE` (attach to other processes). Dropping all capabilities removes every potential privilege escalation vector. Spring Boot needs exactly zero Linux capabilities to serve HTTP traffic.

**`readOnlyRootFilesystem: true`**
Container security setting. The container's root filesystem is mounted read-only. The process cannot write files to it. Prevents an attacker who gains code execution from installing tools, writing backdoors, or modifying configuration. `/tmp` is explicitly mounted as a writable emptyDir volume for JVM heap dumps.

**`allowPrivilegeEscalation: false`**
Security setting that prevents a process inside the container from gaining more privileges than its parent. Blocks `setuid` binaries, `sudo`, and other privilege escalation vectors.

**emptyDir volume**
A Kubernetes volume that starts empty and is created when the pod is created. Lives as long as the pod lives. Used here for `/tmp` — JVM heap dumps go here. Multiple containers in the same pod can share an emptyDir if needed.

**Karpenter**
An AWS open-source Kubernetes node autoscaler. Watches for pods that can't schedule (no node available) and provisions new EC2 instances in seconds. More efficient than the Cluster Autoscaler. The VPC private subnet tag `karpenter.sh/discovery` tells Karpenter which subnets to launch nodes in.
