# Phase 1 — Terraform: VPC + EKS Deep Dive

> Terraform reads the `.tf` files and creates real AWS infrastructure. This phase builds the physical layer everything else runs on: network (VPC) and Kubernetes cluster (EKS).

---

## What Terraform Does (conceptually)

```
terraform init   → download AWS provider plugin (hashicorp/aws ~5.50)
                   configure S3 backend (read/write state from S3 bucket)

terraform plan   → read current .tf files
                   compare to current terraform.tfstate
                   show diff: what will be CREATED (+), CHANGED (~), DESTROYED (-)
                   EXIT — nothing changes in AWS

terraform apply  → execute the plan
                   call AWS APIs to create/modify resources
                   write updated state to S3 bucket
```

The apply order for `terraform/environments/dev/main.tf`:
```
module "vpc"        →  creates VPC first (EKS needs a VPC to live in)
module "eks"        →  creates EKS cluster inside the VPC
module "dynatrace"  →  creates DT config in SaaS (needs DT API token)
```

Terraform figures out the dependency graph automatically from resource references. `module "eks"` references `module.vpc.private_subnet_ids` — Terraform knows to create VPC before EKS.

---

## Deep Dive: VPC Module (terraform/modules/vpc/main.tf)

### CIDR calculation
```hcl
locals {
  public_subnets   = [for i, az in var.azs : cidrsubnet(var.vpc_cidr, 8, i + 1)]
  private_subnets  = [for i, az in var.azs : cidrsubnet(var.vpc_cidr, 4, i + 16)]
  database_subnets = [for i, az in var.azs : cidrsubnet(var.vpc_cidr, 8, i + 100)]
}
```

With `vpc_cidr = "10.0.0.0/16"` and 3 AZs:
```
public_subnets:
  AZ-a: cidrsubnet("10.0.0.0/16", 8, 1)  = 10.0.1.0/24   (256 IPs)
  AZ-b: cidrsubnet("10.0.0.0/16", 8, 2)  = 10.0.2.0/24   (256 IPs)
  AZ-c: cidrsubnet("10.0.0.0/16", 8, 3)  = 10.0.3.0/24   (256 IPs)

private_subnets:
  AZ-a: cidrsubnet("10.0.0.0/16", 4, 16) = 10.0.0.0/20   (4,096 IPs)  ← /4 = bigger subnets
  AZ-b: cidrsubnet("10.0.0.0/16", 4, 17) = 10.0.16.0/20  (4,096 IPs)
  AZ-c: cidrsubnet("10.0.0.0/16", 4, 18) = 10.0.32.0/20  (4,096 IPs)
```

**Why private subnets are /20 (4,096 IPs) and public are /24 (256 IPs):**
EKS uses the VPC CNI plugin, which assigns one IP address per pod (not per node). In a busy cluster with 50 nodes × 50 pods each = 2,500 pods — a /24 only has 256 IPs. Private subnets must be large enough for all pods.
Public subnets only host NAT gateways and ALBs — a handful of IPs is enough.

### Subnet tags — why they matter for EKS
```hcl
public_subnet_tags = {
  "kubernetes.io/role/elb"                    = "1"    ← ALB controller creates internet-facing ALBs here
  "kubernetes.io/cluster/${var.cluster_name}" = "shared"
}
private_subnet_tags = {
  "kubernetes.io/role/internal-elb"           = "1"    ← internal load balancers go here
  "kubernetes.io/cluster/${var.cluster_name}" = "shared"
  "karpenter.sh/discovery"                    = var.cluster_name  ← Karpenter knows where to launch nodes
}
```

The ALB controller reads subnet tags to know WHERE to create load balancers. Without `kubernetes.io/role/elb = 1`, the controller cannot find a public subnet and the ALB creation fails with `no subnets found`.

### NAT Gateway: `one_nat_gateway_per_az = true`
```
single_nat_gateway = false          ← don't share one NAT for all AZs
one_nat_gateway_per_az = true       ← one NAT per AZ
```

**Why this matters:**
```
Option A (single NAT):
  AZ-a, AZ-b, AZ-c pods all route through NAT in AZ-a
  If AZ-a fails: ALL pods lose internet access
  Cost: 1 NAT × $32/month ≈ $32/month

Option B (one per AZ):        ← this project
  AZ-a pods → NAT-a
  AZ-b pods → NAT-b
  AZ-c pods → NAT-c
  If AZ-a fails: AZ-b and AZ-c pods are unaffected
  Cost: 3 NAT × $32/month ≈ $96/month
  Worth it for staging and production.
```

### S3 VPC Gateway Endpoint
```hcl
resource "aws_vpc_endpoint" "s3" {
  vpc_id            = module.vpc.vpc_id
  service_name      = "com.amazonaws.ap-northeast-1.s3"
  vpc_endpoint_type = "Gateway"
  route_table_ids   = module.vpc.private_route_table_ids
}
```

**Why this is important:**
ECR stores Docker image layers in S3. Without this endpoint:
```
EKS pod starts → kubelet pulls image from ECR → ECR layers are on S3
→ S3 traffic goes through NAT Gateway → NAT charges $0.045/GB
```

With this endpoint:
```
EKS pod starts → kubelet pulls image → S3 traffic routes through AWS internal network
→ Zero NAT Gateway data processing charges
→ Faster (no internet round-trip)
```

A busy cluster pulling 100GB/day of images saves ~$4.50/day = ~$1,600/year from this one resource.

---

## Deep Dive: EKS Module (terraform/modules/eks/main.tf)

### The EKS cluster
```hcl
module "eks" {
  cluster_name    = var.cluster_name
  cluster_version = var.cluster_version      # e.g. "1.30"
  vpc_id          = var.vpc_id
  subnet_ids      = var.subnet_ids            # private subnets — nodes go here

  cluster_endpoint_private_access = true
  cluster_endpoint_public_access  = false     # ← no public API server
  ...
}
```

**`cluster_endpoint_public_access = false` — why this matters:**
The Kubernetes API server is what `kubectl` connects to. With public access:
- Anyone on the internet can attempt to connect to `https://<cluster-endpoint>:443`
- Brute-force attacks, credential stuffing, CVE exploits against the API server
- All of these are possible even if they're unlikely to succeed

With `public_access = false`:
- API server is only reachable from inside the VPC
- GitHub Actions CI connects via a VPC-connected runner or assumes an IAM role that makes API calls to EKS via AWS APIs (not raw kubectl)
- You connect via VPN or bastion host when debugging

### KMS encryption
```hcl
cluster_encryption_config = {
  resources = ["secrets"]
}
```

What this does: Kubernetes Secrets (where DB passwords, API tokens are stored as native K8s Secrets) are encrypted in etcd using an AWS KMS key. Without this:
```
$ kubectl get secret payment-service-db-credentials -o yaml
data:
  DB_PASSWORD: c3VwZXJzZWNyZXQ=   ← base64, NOT encrypted
                                     anyone with etcd access can decode this
```

With KMS encryption: the etcd data is actually encrypted. `base64 -d` gives you ciphertext, not the plaintext value.

### Control plane logging
```hcl
cluster_enabled_log_types = ["audit", "api", "authenticator"]
```

**Why each log type:**
| Log type | What it captures | Why you need it |
|----------|-----------------|----------------|
| `audit` | Every API call: who did what, when, from where | Post-mortem: "who deleted that pod?" "who changed this ConfigMap?" |
| `api` | API server errors, slow requests | Debugging `kubectl` timeouts |
| `authenticator` | IAM authentication events | "Why can't the GitHub Actions role access the cluster?" |

These go to CloudWatch Logs. Without them, security investigations and debugging are blind.

### System Node Group
```hcl
eks_managed_node_groups = {
  system = {
    name           = "${var.cluster_name}-system"
    instance_types = var.node_instance_types   # dev: ["t3.medium"], prod: ["m5.xlarge"]
    ...
    taints = {
      dedicated = {
        key    = "dedicated"
        value  = "system"
        effect = "NO_SCHEDULE"                  # ← app pods won't schedule here
      }
    }
    labels = { "node-type" = "system" }
  }
}
```

**What "system" node group means:**
These nodes are tainted `dedicated=system:NoSchedule`. Only pods with a matching `toleration` can schedule here. This keeps system pods (CoreDNS, ALB controller, ExternalDNS, DT ActiveGate) isolated from application pods.

Application pods (payment-service, order-service) go on separate untainted nodes (added later via Karpenter or additional node groups). This prevents a misbehaving app pod from consuming resources that CoreDNS needs.

### IMDSv2: `http_tokens = "required"`
```hcl
metadata_options = {
  http_endpoint               = "enabled"
  http_tokens                 = "required"          # ← require session token
  http_put_response_hop_limit = 2                   # ← allows pods to use IRSA
}
```

**The attack this prevents:**
```
Without IMDSv2:
  Malicious pod/SSRF vulnerability can call:
  http://169.254.169.254/latest/meta-data/iam/security-credentials/
  → gets the EC2 node's IAM role credentials
  → can now access any AWS service the node role can access
  → lateral movement to S3, Secrets Manager, RDS, etc.

With IMDSv2 (required):
  Caller must first GET /latest/api/token with a TTL header → gets a session token
  Then use that token for the actual metadata request
  SSRF vulnerabilities can't do the two-step token dance
  → attack blocked
```

`http_put_response_hop_limit = 2` (not 1): with hop_limit=1, the IMDSv2 session token can only be obtained directly on the EC2 node. With hop_limit=2, pods inside containers on that node can also obtain tokens — required for IRSA to work (pods need to exchange JWT tokens for AWS credentials via the metadata service).

### EKS Add-ons
```hcl
cluster_addons = {
  coredns            = { most_recent = true }  # DNS resolution for pod-to-pod communication
  kube-proxy         = { most_recent = true }  # networking rules on each node
  vpc-cni            = { most_recent = true; before_compute = true }  # IP-per-pod networking
  aws-ebs-csi-driver = { most_recent = true }  # allows PersistentVolumes backed by EBS
}
```

`before_compute = true` on vpc-cni: the VPC CNI must be running BEFORE any worker nodes join. If nodes start before CNI is installed, pods can't get IP addresses and everything stays `Pending` forever. `before_compute` tells Terraform to install the add-on before the node group is created.

---

## The terraform-infra.yaml CI Workflow

### On Pull Request: parallel plan across all 3 environments
```yaml
strategy:
  fail-fast: false          # ← even if dev plan fails, show staging and prod plans too
  matrix:
    env:
      - { name: dev,        account_id: "123456789010", working_dir: terraform/environments/dev }
      - { name: staging,    account_id: "123456789011", working_dir: terraform/environments/staging }
      - { name: production, account_id: "123456789012", working_dir: terraform/environments/production }
```

All three plan jobs run in parallel (they're independent). The plan output is posted as a comment on the PR so reviewers can see exactly what will change in each environment before approving the merge.

### On Push to main: sequential apply
```
apply-dev  →  apply-staging (needs: apply-dev)  →  apply-production (needs: apply-staging)
```

Sequential because:
- Test in dev first before touching staging
- Staging must succeed before production is touched
- If dev apply fails, staging and production are never touched

### Daily drift detection: `cron: '0 17 * * *'` (= 02:00 JST)
```yaml
- name: Drift Detection
  run: |
    terraform plan -refresh-only -detailed-exitcode -no-color 2>&1 | tee drift.txt
    EXIT_CODE=${PIPESTATUS[0]}
    echo "has_drift=$([ $EXIT_CODE -eq 2 ] && echo 'true' || echo 'false')" >> $GITHUB_OUTPUT
```

**`-refresh-only`**: only check if real AWS state matches Terraform state. Do NOT plan any config changes from `.tf` files. This isolates "did someone make a manual change in AWS console?" from "what changes does my new `.tf` code want to make?"

**`-detailed-exitcode`**: changes exit codes:
- `0` = success, no changes
- `1` = error (plan itself failed)
- `2` = success, **changes exist** ← drift detected

When `has_drift=true`, the job creates a GitHub Issue with the full drift diff so the team can investigate and either update Terraform to reflect the manual change, or revert the manual change.

---

## What Each Terraform Resource Actually Creates in AWS

```
After terraform apply (dev):

VPC Resources:
  vpc-xxxxxxxxxx           "company-dev-vpc"           10.0.0.0/16
  subnet-aaa               "company-dev-public-1a"     10.0.1.0/24    (public)
  subnet-bbb               "company-dev-public-1b"     10.0.2.0/24    (public)
  subnet-ccc               "company-dev-public-1c"     10.0.3.0/24    (public)
  subnet-ddd               "company-dev-private-1a"    10.0.0.0/20    (private)
  subnet-eee               "company-dev-private-1b"    10.0.16.0/20   (private)
  subnet-fff               "company-dev-private-1c"    10.0.32.0/20   (private)
  nat-gateway-1a           in public-1a, EIP-xxx       (outbound for private-1a pods)
  nat-gateway-1b           in public-1b, EIP-yyy       (outbound for private-1b pods)
  nat-gateway-1c           in public-1c, EIP-zzz       (outbound for private-1c pods)
  internet-gateway-xxx     attached to VPC             (public subnet internet access)
  vpc-endpoint-s3          Gateway type, private RTs   (free S3 access)

EKS Resources:
  eks-cluster              "company-dev"               Kubernetes 1.30
  eks-nodegroup-system     t3.medium × 3               system nodes, private subnets
  iam-role-cluster         eks.amazonaws.com trust      control plane IAM
  iam-role-node            ec2.amazonaws.com trust      node IAM
  kms-key                  for etcd Secrets encryption
  cloudwatch-log-group     /aws/eks/company-dev/cluster (audit, api, authenticator logs)
  oidc-provider            GitHub + pod OIDC identities

Add-ons (running as managed workloads):
  aws-coredns              2 replicas in kube-system
  aws-kube-proxy           DaemonSet on each node
  aws-vpc-cni              DaemonSet on each node
  aws-ebs-csi-driver       2 controller replicas
```

---

## Common Failures in Phase 1

| Symptom | Cause | Fix |
|---------|-------|-----|
| `terraform init` fails: `NoSuchBucket` | S3 state bucket not created | Run Phase 0.2 commands first |
| `terraform plan` fails: `ResourceNotFoundException` | Secrets not in Secrets Manager | Create secrets (Phase 0.3) |
| `terraform apply` hangs at EKS creation for 25+ min | Normal — EKS takes 15-20 min | Wait. Check AWS console EKS page for status |
| `kubectl get nodes` shows no nodes | Node group not ready | `aws eks list-nodegroups --cluster-name company-dev` to check |
| Node group stuck in `CREATING` | IAM role trust policy wrong | Check node IAM role has `ec2.amazonaws.com` as trusted entity |
| VPC quota exceeded | Default limit is 5 VPCs per region | Request quota increase in AWS console |
