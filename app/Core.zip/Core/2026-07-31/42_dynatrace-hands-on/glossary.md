# Glossary — Dynatrace Hands-On Experience

Every term, UI element, API endpoint, and concept from main.md.

---

**DT tenant**
Your personal Dynatrace environment, accessed at `https://<id>.live.dynatrace.com`. Why it matters: everything in DT lives inside your tenant — metrics, logs, traces, settings, dashboards are all isolated per tenant.

**DT API token**
A credential string that allows programmatic access to DT APIs. Scoped to specific permissions (e.g., `metrics.read`, `logs.read`). Why it matters: used in CI/CD automation, Terraform, Slack bots, and any script that queries DT outside the UI.

**Token scope**
A permission attached to a DT API token that controls what it can do. Example: `slo.read` = can read SLO status, `settings.write` = can create management zones. Why it matters: follow least-privilege — scripts that only read metrics should not have `settings.write` permission.

**Problems view**
The DT UI screen showing all active and resolved incidents detected by DT (Davis AI + custom metric events). Why it matters: the first place to open when an alert fires — shows impact level, affected entities, related deployment events, and Davis AI root cause suggestion.

**Davis AI**
Dynatrace's built-in AI engine that correlates events (deploys, config changes, anomalies) with problems and suggests root causes. Why it matters: automatically flags "deployment X happened 1 minute before this problem" — saves 20+ minutes of manual correlation during incidents.

**Service overview page**
The DT UI page for a specific detected service, showing: response time (P50/P95/P99), failure rate, throughput, and top operations. Why it matters: starting point for service health investigation — links to traces, logs, and infrastructure.

**Failure analysis**
A sub-page in the DT Service view that groups errors by type and exception class, with sample stack traces. Why it matters: identifies the root error type (e.g., `QueryTimeoutException 89%`) before spending time reading individual log lines.

**Top operations table**
A table in the DT Service view listing each HTTP endpoint with its average response time, failure rate, and call count. Why it matters: lets you identify which specific endpoint is slow or failing — not just which service.

**Distributed trace waterfall**
A horizontal bar chart showing each span in a trace positioned at its start time and sized by duration, with parent-child indentation. Why it matters: visually shows where time was spent and where errors occurred in a cross-service request.

**Span**
One unit of work in a distributed trace — represents a single operation (HTTP call, DB query, method). Shown as one bar in the waterfall. Why it matters: clicking a span reveals its details: DB statement text, duration, error message, linked log lines.

**Logs tab (in a trace span)**
A tab inside a specific trace span panel that shows only log lines emitted during that span's execution time, linked by `dt.trace_id`. Why it matters: the fastest path from "a span failed" to "the exact error message in the logs" — no separate DQL query needed.

**Kubernetes view**
The DT UI screen at Observe → Infrastructure → Kubernetes showing clusters, nodes, workloads, and pods with their resource usage and health status. Why it matters: shows pod restarts, CPU/memory usage per pod, and Kubernetes Events (OOMKilled, BackOff) in one place.

**DQL workspace**
The DT UI screen at Logs → Log viewer with a DQL query input, results table, and timeline bar chart. Why it matters: where SREs write and run DQL queries interactively during incident investigation.

**`Ctrl+Enter` (DQL)**
Keyboard shortcut to execute a DQL query in the workspace. Why it matters: faster than clicking the "Run" button — essential muscle memory for incident investigation.

**`Ctrl+Space` (DQL)**
Keyboard shortcut for field name and function autocomplete in the DQL editor. Why it matters: shows all available log fields and their types — helps when you don't remember exact field names like `k8s.namespace.name`.

**SLO detail page**
The DT UI screen for a specific SLO showing: current evaluation %, target, error budget remaining, and burn rate. Why it matters: shows how much reliability budget remains this month — the primary decision input for "should we freeze deploys?".

**Error budget policy**
A team agreement defining what actions to take when error budget crosses specific thresholds (e.g., < 10% remaining = freeze non-critical deploys). Why it matters: converts the error budget number into concrete decisions — prevents "we have 3% budget left, should we deploy?" debates.

**Burn rate (fast/slow)**
Fast burn (14.4×) = error budget consumed in 2 days → PagerDuty. Slow burn (3×) = consumed in 10 days → Slack warning. Why it matters: catches sustained moderate errors that simple error-rate thresholds miss.

**Metric browser**
The DT UI screen at Metrics → Metric browser for exploring all available metrics, applying filters, and viewing time-series charts. Why it matters: used to establish metric baselines before setting alert thresholds — "what is normal P99 for payment-service?"

**Custom chart tile**
A dashboard tile that displays a DT metric as a line chart, bar chart, heatmap, or single value. Configured with metric key, filter, split dimension, and chart type. Why it matters: builds the visual panels that make up an SRE dashboard.

**SLO tile**
A dashboard tile that displays a single SLO's current status, evaluation percentage, and error budget as a gauge. Why it matters: gives instant green/yellow/red health at a glance for each service's reliability.

**Log viewer tile**
A dashboard tile that runs a DQL query and displays the results as a live-updating log table. Why it matters: embedding an error log panel in the dashboard means you see real-time errors without navigating away.

**Heatmap (chart type)**
A 2D grid where rows = services and columns = time buckets, colored by metric value. Why it matters: lets you compare JVM heap utilization across all services simultaneously — one color pattern change signals a problem.

**`builtin:service.response.time:percentile(99)`**
The DT metric key for the 99th percentile response time in microseconds. Why it matters: the SLO metric — must be compared to `latency_p99_ms × 1000` (since DT stores microseconds).

**`builtin:kubernetes.workload.pods.restarts`**
The DT metric key for pod restart count in a 5-minute window. Why it matters: alert on this to catch CrashLoopBackOff before it completes enough cycles to be visible in the pod status.

**`builtin:host.net.errorRate`**
The DT metric key for network packet error rate on a host (EKS node). Why it matters: catches node-level network issues (MTU mismatch, SG misconfiguration) that don't appear in application-level error rates.

**Auto-tagging rules**
DT settings that automatically assign tags to entities based on Kubernetes labels, environment variables, or other entity properties. Why it matters: the bridge between namespace labels (`team=payments`) and management zone filters (`tag: team:payments`).

**Davis AI anomaly detection**
DT's automatic baseline-learning anomaly detection that fires when a metric deviates significantly from its learned normal range. Why it matters: catches relative changes ("suddenly 2× slower than usual") that fixed thresholds miss — complements custom metric events.

**Management zone**
A DT filter scope that limits which entities are visible to a team. Based on entity tags (e.g., `team:payments`). Why it matters: payment team sees only their services; order team sees only theirs — no cross-team noise or wrong-team-paged incidents.

**`sloSelector=name("...")`**
A DT API parameter that matches SLOs by exact name string. Why it matters: the name must exactly match the Terraform `dynatrace_slo_v2.name` field — any mismatch returns empty results.

**`entitySelector`**
A DT API query language for selecting entities. `type(SERVICE),entityName(payment-service)` = the service entity named "payment-service". Why it matters: used in event injection API to link deployment events to the correct service — must match `OTEL_SERVICE_NAME` exactly.

**`CUSTOM_DEPLOYMENT` (event type)**
A DT event type that marks a deployment in DT's timeline and triggers Davis AI correlation. Why it matters: enables the "deploy happened 1 minute before this problem" insight in the DT Problem view.

**Davis AI root cause suggestion**
The "Related events" section in the DT Problem view showing what changed before the problem started: deployment events, config changes, anomaly spikes. Why it matters: often identifies the root cause in under 30 seconds — "deploy at 14:22 → problem at 14:23".

**`-H "Authorization: Api-Token $DT_TOKEN"`**
The HTTP header required for all DT API calls. Why it matters: without this header, all API calls return 401 Unauthorized.

**`jq`**
A command-line tool for parsing and filtering JSON. Used in all DT API curl examples. Why it matters: DT API responses are JSON — jq extracts specific fields for scripting and readable display.

**`/api/v2/problems`**
The DT REST API endpoint for listing and querying problems (incidents). Why it matters: enables automated problem queries in scripts, Slack bots, and CI/CD health checks.

**`/api/v2/metrics/query`**
The DT REST API endpoint for querying metric time series. Returns `{resolution: {dataPoints: [[timestamp, value], ...]}}`. Why it matters: used in CI/CD post-deploy verification to programmatically check if error rate spiked after a deploy.

**`/platform/storage/query/v1/query:execute`**
The Grail REST API endpoint for executing DQL queries programmatically. Returns `{records: [...]}`. Why it matters: enables DQL execution from scripts, Lambda functions, and CI/CD pipelines without opening the DT UI.

**`/api/v2/events/ingest`**
The DT REST API endpoint for injecting custom events (deployment events, config changes). Why it matters: powers the deploy event timeline markers in DT Problem view — must be called from CI after every production deploy.

**`/api/v1/synthetic/monitors`**
The DT REST API endpoint for listing and managing HTTP synthetic monitors. Why it matters: used in scripts to check synthetic monitor status and availability percentages.

**Morning health check**
A set of standardized DT checks performed at the start of each work day: open problems, SLO error budgets, synthetic monitor status, overnight error logs. Why it matters: catches overnight issues before customer reports arrive — establishes situational awareness before starting feature work.

**Post-deploy verification**
DQL queries run immediately after a production deploy to confirm no new errors were introduced. Why it matters: the window between deploy and customer impact is 2-5 minutes — catching errors in this window enables immediate rollback before widespread damage.

**Rollback via gitops**
Updating the image tag in the ArgoCD Application YAML to the previous SHA and pushing to Git. ArgoCD detects the change and rolling-updates the pods to the old image. Why it matters: the safest rollback method — no direct kubectl commands, full audit trail, leverages the same delivery pipeline as forward deploys.

**`PIPESTATUS`**
A bash array holding exit codes of all commands in the most recent pipeline. `${PIPESTATUS[0]}` = exit code of the first command. Why it matters: when piping terraform output through `tee`, `$?` returns tee's exit code (always 0), not terraform's. `PIPESTATUS[0]` returns terraform's actual exit code.

**Percentile (P99/P95/P50)**
P99 = 99% of requests are faster than this value. P95 = 95%. P50 = median (half are faster). Why it matters: P99 measures worst-case user experience; P50 measures typical user experience. Both rising = general degradation. Only P99 rising = tail latency problem (one slow code path affecting some users).

**Baseline (metric)**
The historical normal range of a metric during regular operation, learned by Davis AI or manually observed. Why it matters: alert thresholds should be set above the observed baseline — setting them below normal peak traffic = constant false alerts.

**Connection pool exhaustion**
When all connections in a database connection pool are in use and new requests must wait for one to become available. Symptoms: `HikariCP - Connection pool is exhausted` in logs, latency spikes, timeout errors. Why it matters: the single most common cause of Java service failures under load.

**`HikariCP`**
The default JDBC connection pool library in Spring Boot. Maintains a fixed-size pool of reusable database connections. Why it matters: pool size must be tuned to match the application's thread count — mismatch = pool exhaustion = payment failures.
