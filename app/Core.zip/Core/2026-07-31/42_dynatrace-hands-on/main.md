# Hands-On Experience with Dynatrace Monitoring Solution
## SRE Deep Dive — Every Screen, Every Action, Every Command

> This doc covers what an SRE actually DOES with Dynatrace day-to-day: navigating the UI, writing queries, interpreting dashboards, triaging incidents, tuning alerts, and managing the platform through both the UI and API. Organized by task, not by menu.

---

## The Mental Model: DT's 5 Data Layers

Before touching any screen, understand what DT stores and why each layer matters:

```
Layer 1: TOPOLOGY (who exists, who calls who)
  DT discovers: services, processes, hosts, pods, namespaces
  Auto-built from: OneAgent network analysis + Kubernetes API
  You use this to: understand the blast radius of a failing component

Layer 2: METRICS (numbers over time)
  Built-in: HTTP rate/latency/errors, JVM heap/GC, CPU/memory, pod restarts
  Custom: anything you emit via Micrometer or OTEL
  You use this to: see trends, set thresholds, trigger alerts

Layer 3: TRACES (request path through services)
  Built-in via OTEL Java agent: HTTP calls, DB queries, downstream services
  You use this to: find the exact code path that caused an error or slowdown

Layer 4: LOGS (text output from running code)
  Ingested via: OneAgent reading /var/log/containers/*.log
  You use this to: see error messages, stack traces, business events

Layer 5: EVENTS (point-in-time facts)
  Auto-detected: pod restarts, config changes, anomalies
  Injected by CI: deployment events (CUSTOM_DEPLOYMENT)
  You use this to: correlate "what changed" with "when things broke"
```

---

## Decision Tree — Which UI Path to Take

```
                Alert fired / incident happening
                           │
          ┌────────────────┼────────────────┐
          ▼                ▼                ▼
   Service is DOWN    Error rate HIGH   Latency HIGH
          │                │                │
   Problems view      Problems view    Problems view
   → Availability     → Error analysis  → Response time
   → Check synthetic  → Click trace     → Click trace
   → Check pods       → Check logs      → Check DB spans
          │                │                │
   kubectl get pods   Identify error   Identify slow span
   kubectl describe   message type     (DB? gateway? loop?)
          │                │                │
   Runbook:           Runbook:         Runbook:
   DB down?           Deploy caused?   Query missing index?
   ALB misconfigured? Config error?    N+1 query pattern?
```

---

## Part 1 — First Day: Setting Up Your Environment

### Step 1: Access your DT tenant

Every DT tenant has a URL of the form:
```
https://<environment-id>.live.dynatrace.com
```
Or for Dynatrace Managed (self-hosted):
```
https://<your-server>/e/<environment-id>
```

```bash
# Store as env var — used in all API calls
export DT_URL="https://abc12345.live.dynatrace.com"
export DT_TOKEN="dt0c01.XXXXXXXXXXXXXXXXXXXXXXXX.XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"

# Test connectivity
curl -sf \
  -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/settings/schemas" \
  | jq '.items[0]'
# Should return the first settings schema — confirms auth works
```

**DT API token scopes needed (request from your DT admin):**
```
metrics.read           → query metric time series
metrics.write          → create custom metric events
logs.read              → query Grail logs
logs.ingest            → push log lines (if needed)
problems.read          → read problems/alerts
events.ingest          → inject deployment events
settings.read          → read DT settings
settings.write         → create management zones, alerting profiles
slo.read               → read SLO status/error budget
```

### Step 2: Navigate the DT UI — what lives where

```
Left sidebar:
  📊 Observe and Explore
     → Infrastructure → Hosts (EKS nodes), Kubernetes (clusters/namespaces/pods)
     → Applications & Microservices → Services (auto-detected Java services)
     → Digital Experience → Synthetic monitors, browser monitors

  🔔 Alerting
     → Problems (active + closed incidents)
     → Metric events (custom alert rules)
     → Alerting profiles (who gets paged)

  📋 Logs
     → Log viewer (DQL query interface)
     → Log ingest rules
     → Log processing rules
     → Log metrics

  📈 Metrics
     → Metric browser (explore all available metrics)
     → Custom charts

  🔍 Distributed Traces
     → Full trace list with filters

  📉 SLOs
     → Service Level Objectives list + error budget

  ⚙️ Settings
     → Integration (tokens, webhooks)
     → Anomaly detection
     → Management zones
     → Auto-tagging rules
```

### Step 3: Confirm OneAgent is working

```
Navigate: Observe and Explore → Infrastructure → Kubernetes
→ Select your cluster (company-dev, company-staging, company-prod)
→ Should see:
  - Nodes: 3 (or however many EKS nodes)
  - Workloads: payment-service (3 replicas), order-service, notification-service
  - Namespaces: payment-ns, order-ns, notification-ns, dynatrace, external-secrets

If cluster not visible:
  kubectl get pods -n dynatrace
  # dynatrace-operator pod should be Running
  # dynakube-oneagent-XXXXX pods should be Running (one per node)
  # dynakube-activegate-XXXXX should be Running (2 pods in production)
```

```bash
# CLI: confirm OneAgent on every node
kubectl get pods -n dynatrace -o wide | grep oneagent
# Should show one pod per EKS node, all Running

# Check ActiveGate logs for connection issues
kubectl logs -n dynatrace \
  $(kubectl get pods -n dynatrace -l app.kubernetes.io/component=activegate \
    -o jsonpath='{.items[0].metadata.name}') \
  | grep -E "ERROR|WARN|Connected" | tail -20
# Look for: "Connected to Dynatrace server" — confirms data is flowing
```

---

## Part 2 — Daily Operations: What SRE Does Every Morning

### Morning health check sequence (10 minutes)

**Step 1: Open Problems view**
```
Navigate: Alerting → Problems
Filter: Time: Last 24 hours, Status: Open + Closed
```

What to look for:
- Open problems = active incidents (someone should be working these)
- Problems that opened and closed overnight without human action = possible unresolved issues that suppressed themselves
- Problems with `root cause: deployment event` = last night's deploy may have caused issues

```bash
# CLI equivalent: get all open problems
curl -sf \
  -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/problems?from=now-24h&status=OPEN&pageSize=50" \
  | jq '.problems[] | {title: .title, status: .status, startTime: .startTime, entity: .impactedEntities[0].name}'
```

**Step 2: Check SLO error budgets**
```
Navigate: SLOs
Sort by: Error budget remaining (ascending) — worst first
```

What to look for:
```
payment-service Availability [production]:
  Target: 99.9%
  Current: 99.87%
  Error budget: 13% remaining ← 87% consumed this month

ORDER OF CONCERN:
  < 10% remaining = stop non-critical deploys, investigate
  10-30% remaining = monitor closely, reduce deploy frequency
  30-100% remaining = healthy, proceed normally
```

```bash
# CLI: SLO status for all services
curl -sf \
  -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/slo?from=now-1M&pageSize=50" \
  | jq '.slo[] | {name: .name, status: .status, errorBudget: .errorBudget, evaluatedPercentage: .evaluatedPercentage}' \
  | sort -t'"' -k8 -n
# Shows error budget from lowest (most consumed) to highest
```

**Step 3: Check synthetic monitors**
```
Navigate: Digital Experience → Synthetic → HTTP monitors
Filter: Status: All
```

What to look for:
- Any monitor with status "Problems" or "Warning"
- Any monitor with elevated response times (trend vs last week)
- Any monitor that failed overnight and auto-recovered (may indicate flapping)

```bash
# CLI: check all synthetic monitors
curl -sf \
  -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v1/synthetic/monitors?type=HTTP&enabled=true" \
  | jq '.monitors[] | {name: .name, enabled: .enabled, createdFrom: .createdFrom}'

# Check results for a specific monitor
MONITOR_ID="SYNTHETIC_TEST-ABC123"
curl -sf \
  -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v1/synthetic/monitors/$MONITOR_ID/results?testType=AVAILABILITY&from=now-24h" \
  | jq '.timeSeriesData[0]'
```

**Step 4: Grail overnight error check**
```
Navigate: Logs → Log viewer
```

DQL (paste and run):
```dql
fetch logs, from: now()-8h
| filter k8s.namespace.name =~ "(payment|order|notification)-ns"
| filter status == "ERROR"
| summarize count = count(), by: { service.name, bin(timestamp, 1h) }
| sort timestamp asc
```

What to look for:
- A service that had 0 errors until 3am then spiked → scheduled job issue
- Consistent 5-10 errors/hour → normal noise vs sudden 200/hour → incident
- Any OOM errors:

```dql
fetch logs, from: now()-8h
| filter matchesPhrase(content, "OutOfMemoryError")
     OR matchesPhrase(content, "OOMKilled")
     OR matchesPhrase(content, "GC overhead limit exceeded")
| fields timestamp, service.name, k8s.pod.name, content
| sort timestamp asc
```

---

## Part 3 — Service Monitoring: Hands-On Navigation

### Explore a service end-to-end

```
Navigate: Applications & Microservices → Services
→ Click: payment-service
```

You arrive at the Service Overview page. What every panel means:

```
PANEL: Response time (line chart, last 2 hours)
  Blue line: median (P50) — what most users experience
  Orange line: 95th percentile — worst 5% of users
  Red line: 99th percentile (P99) — worst 1%
  
  SRE action: P99 rising while P50 stable = tail latency issue
    → Usually: one slow DB query + connection pool saturation
    → NOT a general performance regression

PANEL: Failure rate (percentage)
  Red line: HTTP 5xx as % of total requests
  
  SRE action: if rising → click "Failure analysis" below the chart
  → Shows which endpoint has failures
  → Click an endpoint → shows which error type

PANEL: Throughput (requests per minute)
  Green line: total requests/min
  
  SRE action: if drops to 0 (with no planned maintenance) → CRITICAL
  → Traffic drop is a silent outage indicator
  → Check: is synthetic monitor also failing? → ALB/DNS issue

PANEL: Top operations (table)
  Lists each HTTP endpoint with: avg time, failure %, call count
  
  SRE action: sort by failure rate → find the broken endpoint
  Sort by avg time → find the slow endpoint
```

### Drill into a specific error

```
From the Service Overview:
→ Click: Failure analysis
→ See: breakdown of errors by type
→ Click: the top error type

Example: "org.springframework.dao.QueryTimeoutException (47 occurrences)"
→ DT shows: sample stack trace + affected operations
→ Click: "View in distributed tracing" → opens traces filtered to this error
→ Click: any trace → full waterfall:
  payment-service [500ms] ← FAILED
    └── HikariCP.getConnection [490ms] ← timeout here
          (no downstream span — connection never acquired)
```

```bash
# CLI: query failed requests for a service
curl -sf \
  -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/metrics/query?metricSelector=builtin:service.errors.server.count:filter(eq(service.name,payment-service)):sum&resolution=5m&from=now-1h" \
  | jq '.resolution.dataPoints'
# Returns array of [timestamp, value] pairs — error count per 5 minutes
```

### Navigate to the Kubernetes view

```
Navigate: Observe and Explore → Infrastructure → Kubernetes
→ Select cluster: company-prod
→ Click: Workloads tab
→ Find: payment-service
```

What you see:
```
payment-service (Deployment)
  Replicas: 3/3 running
  CPU requested: 750m (3 pods × 250m)
  CPU used: 485m (65% of requested)
  Memory requested: 2.3Gi (3 × 768Mi)
  Memory used: 1.8Gi (78%)
  Restarts: 0 (last 24h) ← GREEN
```

Click into a specific pod:
```
payment-service-7d9f8b-abc12
  Status: Running
  Node: ip-10-12-34-56.ap-northeast-1.compute.internal
  Started: 4 hours ago
  CPU: 185m / 1000m limit (18.5%)
  Memory: 612Mi / 1Gi limit (60%)
  Restarts: 0
  
  Tabs:
  → Logs: pod logs directly in DT (same as Grail but pre-filtered to this pod)
  → Metrics: CPU/memory time series for just this pod
  → Events: Kubernetes events (OOMKilled, BackOff, Pulled, Started)
```

```bash
# CLI equivalents
kubectl top pods -n payment-ns
# Shows: CPU and memory usage for each pod

kubectl describe pod -n payment-ns payment-service-7d9f8b-abc12
# Shows: events, resource requests/limits, probe config

kubectl get events -n payment-ns --sort-by='.lastTimestamp' | tail -20
# Shows: recent Kubernetes events (restarts, failures, scaling)
```

---

## Part 4 — Distributed Tracing: Hands-On

### Find a slow trace

```
Navigate: Applications & Microservices → Distributed Traces
→ Filter:
    Service: payment-service
    Duration: > 500ms (show only slow traces)
    Time: Last 1 hour
→ Sort by: Duration (descending)
→ Click: the slowest trace
```

The trace waterfall:
```
order-service          |████████████████████████████| 1240ms
  └── HTTP POST payment  |░░░░░░░░░░░████████████| 800ms  starts at T+200ms
        payment-service    |░░░░████████████| 800ms
          ├── HikariCP.getConnection |░░░███| 300ms  ← SLOW (normal: 2ms)
          └── SELECT payments        |░░░░░░░███| 200ms  ← also slow
```

Reading the waterfall:
- Horizontal position = when it started (relative to trace start)
- Width = duration
- Indentation = parent-child relationship
- Color: green = success, red = error, yellow = warning

**What the `HikariCP.getConnection: 300ms` span tells you:**
- Normal: 1-5ms (acquiring a pooled connection)
- 300ms: had to WAIT for a connection → pool is exhausted
- Root cause: too many concurrent requests, pool size too small, or slow queries holding connections

**Clicking into a span:**
```
Click: SELECT payments span
→ Shows:
  DB system: PostgreSQL
  DB statement: SELECT * FROM payments WHERE user_id = ? AND created_at > ?
  Duration: 200ms (normal: 3ms)
  DB rows: 15,000 ← returned 15,000 rows for one user

SRE analysis:
  15,000 rows returned is the problem.
  Query is missing: LIMIT clause or a date range that's too broad.
  Fix: add index on (user_id, created_at) + LIMIT 100 + paginate
```

### Find a trace for a specific user/request

```
Navigate: Distributed Traces
→ Filter → Add tag: dt.trace_id = "4bf92f3577b34da6a3ce929d0e0e4736"
→ (get trace_id from: a log line in Grail, a PagerDuty alert, or a user complaint)
```

```bash
# CLI: get recent traces with errors for payment-service
curl -sf \
  -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/traces?service=payment-service&status=ERROR&from=now-30m&pageSize=10" \
  | jq '.traces[] | {traceId: .traceId, duration: .duration, rootServiceName: .rootServiceName}'
```

### Read the Logs tab within a trace span

```
In the trace waterfall:
→ Click: payment-service span
→ Click: "Logs" tab (appears in the right panel)
→ Shows: ALL log lines emitted during the exact duration of this span
   (DT correlates using dt.trace_id + timing)
```

This is the fastest path from "something failed" to "the exact error message":
```
14:23:07.001 ERROR: Database query timed out after 5000ms for query: SELECT...
14:23:07.002 WARN: Returning fallback response for userId=user-abc123
14:23:07.003 INFO: Request completed with status=500 in 5001ms
```

---

## Part 5 — Writing and Running DQL Queries

### The DQL workspace

```
Navigate: Logs → Log viewer
```

The workspace has 3 main areas:
1. **Query input** (top): where you write DQL
2. **Results panel** (middle): rows returned
3. **Timeline** (bottom): auto-generated bar chart of matching log volume over time

**Keyboard shortcuts:**
- `Ctrl+Enter` / `Cmd+Enter` → run query
- `Ctrl+Space` → autocomplete (field names, functions)
- `Ctrl+/` → comment/uncomment current line

### Query patterns you use every day

**Pattern 1: See what's happening right now**
```dql
fetch logs, from: now()-15m
| filter k8s.namespace.name =~ "(payment|order|notification)-ns"
| filter status == "ERROR"
| fields timestamp, service.name, k8s.pod.name, content
| sort timestamp desc
| limit 50
```
Run this when: alert just fired, or you want a quick health snapshot.

**Pattern 2: Count errors per minute over last hour**
```dql
fetch logs, from: now()-1h
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize count = count(), by: { bin(timestamp, 1m) }
| sort timestamp asc
```
Run this when: you need to see the shape of an incident — when did it start, is it getting worse or recovering?

**Pattern 3: Top error messages (triage)**
```dql
fetch logs, from: now()-30m
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize count = count(), by: { content }
| sort count desc
| limit 10
```
Run this when: PagerDuty fires — what is the MOST COMMON error? That's your root cause focus.

**Pattern 4: Error breakdown by pod**
```dql
fetch logs, from: now()-30m
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize count = count(), by: { k8s.pod.name }
| sort count desc
```
Run this when: you need to know if one pod is bad (node issue) or all pods (application bug).

**Pattern 5: Parse JSON and extract fields**
```dql
fetch logs, from: now()-1h
| filter service.name == "payment-service"
| filter status == "ERROR"
| filter matchesPhrase(content, '"errorCode"')
| parse content, "JSON:j"
| fields timestamp, j.userId, j.errorCode, j.paymentId, j.amount, k8s.pod.name
| sort timestamp desc
| limit 20
```
Run this when: you need to identify which users / payment IDs are affected.

**Pattern 6: Full stack trace recovery**
```dql
// Step 1: find the first exception occurrence
fetch logs, from: now()-2h
| filter service.name == "payment-service"
| filter matchesPhrase(content, "QueryTimeoutException")
| sort timestamp asc
| limit 1
| fields timestamp, k8s.pod.name

// Step 2: get all lines from that pod around that moment (copy timestamp + pod from step 1)
fetch logs, from: "2024-01-15T14:23:06Z", to: "2024-01-15T14:23:12Z"
| filter k8s.pod.name == "payment-service-7d9f8b-abc12"
| sort timestamp asc
| fields timestamp, content
```

**Pattern 7: Count events per hour for trend analysis**
```dql
fetch logs, from: now()-7d
| filter service.name == "payment-service"
| filter matchesPhrase(content, "Payment declined")
| summarize count = count(), by: { bin(timestamp, 1h) }
| sort timestamp asc
```
Run this when: business asks "has this error been increasing over the last week?"

**Pattern 8: Log-based error budget calculation**
```dql
fetch logs, from: now()-30d
| filter service.name == "payment-service"
| filter matchesPhrase(content, '"event":"payment_attempt"')
| parse content, "JSON:j"
| summarize
    total   = count(),
    success = countIf(j.result == "SUCCESS"),
    failed  = countIf(j.result == "FAILED")
| fieldsAdd success_pct  = success * 100.0 / total
| fieldsAdd budget_used  = (100.0 - success_pct) / (100.0 - 99.9) * 100
```
Run this: weekly or when SLO review comes up.

---

## Part 6 — Alert Tuning: Hands-On

### Check current metric events

```
Navigate: Alerting → Metric events
→ See list of all custom metric events
→ Click any event to see: metric key, threshold, current value
```

```bash
# CLI: list all metric events
curl -sf \
  -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/settings/objects?schemaId=builtin:anomaly-detection.metric-events&pageSize=50" \
  | jq '.items[] | {id: .objectId, summary: .value.summary, threshold: .value.modelProperties.threshold, enabled: .value.enabled}'
```

### Tune a threshold that fires too often

**Scenario:** payment-service latency alert fires 3-4 times per day but always auto-resolves within 5 minutes. These are transient JIT spikes, not real incidents.

**Step 1: Check the metric baseline**
```
Navigate: Metrics → Metric browser
Search: builtin:service.response.time
Filter: service.name = payment-service
→ Select percentile(99)
→ Time range: last 2 weeks
→ Right-click chart → "Analyze" → see average, P95, max
```

What you see:
```
Normal P99: 150-200ms
Peak (14:00-16:00 JST): 250-300ms
Transient spikes (deploys, GC): 450-600ms lasting <2 minutes
Current threshold: 300ms

Diagnosis: threshold is below normal peak traffic P99
Fix: raise threshold to 500ms (above normal operations, below real incidents)
```

**Step 2: Update the threshold in Terraform**
```hcl
# terraform/environments/production/main.tf
"payment-service" = {
  latency_p99_ms = 500   # was 300 — raised after observing 2-week baseline
  # Documented: threshold raised 2024-01-15 after 60% noise ratio.
  # Normal P99 peak = 280ms. Real incidents = 700ms+.
}
```

```bash
# Apply the change
cd terraform/environments/production
terraform plan   # shows: latency threshold 300000μs → 500000μs
terraform apply
```

**Step 3: Verify the change took effect**
```
Navigate: Alerting → Metric events → payment-service latency
→ Confirm threshold now shows 500,000 (microseconds)
→ Wait 1 week → check: Problems list for false positives
```

### Tune an alert that MISSES real incidents

**Scenario:** pod restart alert has `threshold = 5` but CrashLoopBackOff starts at 2 restarts. By the time 5 restarts happen, the pod has been in CrashLoop for 20 minutes.

```hcl
"payment-service" = {
  pod_restart_threshold = 2   # was 5 — lowered for faster detection
  # Any 2 restarts in 5 minutes = crash loop starting
}
```

---

## Part 7 — SLO Management Hands-On

### Read an SLO and understand the error budget

```
Navigate: SLOs
→ Click: payment-service Availability [production]
```

What you see:
```
Target:           99.9%
Current (30d):    99.87%
Error budget:     0.1% total allowed error rate per month
Consumed:         87% of error budget used (0.087% actual error rate)
Remaining:        13% of budget = 5.6 minutes remaining this month

Burn rate (fast):  0.8× (not burning fast enough to worry yet)
Burn rate (slow):  0.4× (very slow burn — budget consumed gradually)

Status:           WARNING (between 99.8% warning target and 99.9% target)
```

**What the burn rate means:**
```
1.0× = consuming budget at exactly the allowed rate
       = will exhaust exactly at the end of the month
14.4× = exhausting monthly budget in 2 days → PAGE
3.0×  = exhausting monthly budget in 10 days → SLACK WARNING
0.8×  = consuming 80% of allowed rate → on track to have 20% budget left at end of month
```

### Check which requests consumed the error budget

```
From the SLO detail page:
→ Click: "Error rate details" or "Linked problems"
→ See: which time periods had the highest error rates
→ Click a period → jumps to Services → payment-service → that time range
```

```bash
# CLI: get SLO with full detail
curl -sf \
  -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/slo/payment-service-availability-production?from=now-1M" \
  | jq '{
      status: .status,
      evaluatedPct: .evaluatedPercentage,
      errorBudget: .errorBudget,
      burnRate: .burnRateMetrics
    }'
```

### Set an error budget policy

When error budget drops below 10%:
1. Freeze all non-critical deploys (update deployment policy in GitHub)
2. Post in #engineering: "Payment-service is at 10% error budget — no deploys until investigated"
3. Run DQL to find what consumed the budget:

```dql
fetch logs, from: now()-30d
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize count = count(), by: { bin(timestamp, 1d) }
| sort timestamp asc
```
→ Shows which days had the most errors → correlate with deploy events or incidents.

---

## Part 8 — Working with the DT API

### Most useful API endpoints for SRE daily work

```bash
# ── PROBLEMS ──────────────────────────────────────────────────────────────

# List open problems
curl -sf -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/problems?status=OPEN&from=now-24h" \
  | jq '.problems[] | {id: .problemId, title: .title, impact: .impactLevel, entity: .impactedEntities[0].name}'

# Get details of a specific problem
curl -sf -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/problems/P-1234567890ABCDEF" \
  | jq '{title, status, startTime, rootCauseEntity: .rootCauseEntity.name}'


# ── METRICS ───────────────────────────────────────────────────────────────

# Query error rate for payment-service (last 5 min)
curl -sf -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/metrics/query?metricSelector=builtin:service.errors.server.rate:filter(eq(service.name,payment-service)):max&from=now-5m&resolution=1m" \
  | jq '.resolution.dataPoints'

# Query JVM heap for all pods
curl -sf -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/metrics/query?metricSelector=builtin:process.memory.jvm.heapUtilization:filter(eq(process.group.name,payment-service)):max&from=now-1h&resolution=5m" \
  | jq '.resolution.dataPoints'

# List all custom metrics (discover what engineering added)
curl -sf -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/metrics?metricSelector=batch.payment.*&pageSize=20" \
  | jq '.metrics[].metricId'


# ── LOGS (GRAIL API) ───────────────────────────────────────────────────────

# Execute DQL query via API
curl -sf -X POST \
  -H "Authorization: Api-Token $DT_TOKEN" \
  -H "Content-Type: application/json" \
  "$DT_URL/platform/storage/query/v1/query:execute" \
  --data '{
    "query": "fetch logs, from: now()-30m | filter service.name == \"payment-service\" | filter status == \"ERROR\" | summarize count = count(), by: { content } | sort count desc | limit 10"
  }' \
  | jq '.records'


# ── SYNTHETICS ────────────────────────────────────────────────────────────

# List all HTTP monitors and their status
curl -sf -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v1/synthetic/monitors?type=HTTP&enabled=true" \
  | jq '.monitors[] | {id: .entityId, name: .name}'

# Get recent results for a monitor (last 24h availability %)
curl -sf -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v1/synthetic/monitors/$MONITOR_ID/results?from=now-24h&testType=AVAILABILITY" \
  | jq '.timeSeriesData[0]'


# ── SLOs ──────────────────────────────────────────────────────────────────

# Get all SLOs with error budget
curl -sf -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/slo?from=now-1M&pageSize=50" \
  | jq '.slo[] | {name: .name, status: .status, budget: .errorBudget}'


# ── EVENTS ────────────────────────────────────────────────────────────────

# Inject deployment event (use in CI/CD pipeline)
curl -sf -X POST \
  -H "Authorization: Api-Token $DT_TOKEN" \
  -H "Content-Type: application/json" \
  "$DT_URL/api/v2/events/ingest" \
  --data '{
    "eventType": "CUSTOM_DEPLOYMENT",
    "title": "Deploy: payment-service=abc1234",
    "entitySelector": "type(SERVICE),entityName(payment-service)",
    "properties": {
      "git_sha": "abc1234",
      "deployed_by": "github-actions"
    }
  }'
```

---

## Part 9 — Building and Reading Dashboards

### Create a service health dashboard from scratch

```
Navigate: Observe and Explore → Dashboards → New dashboard
```

**Panel 1: SLO status tiles (one per service)**
```
Add tile → SLO tile
→ Select SLO: payment-service Availability [production]
→ Shows: current % + error budget remaining + status color

Repeat for: order-service, notification-service
```

**Panel 2: Error rate line chart**
```
Add tile → Custom chart
→ Metric: builtin:service.errors.server.rate
→ Split by: service.name
→ Filter: service.name IN (payment-service, order-service, notification-service)
→ Chart type: line
→ Add threshold line at 0.1% (payment SLO), 0.5% (order SLO)
```

**Panel 3: JVM heap heatmap**
```
Add tile → Custom chart
→ Metric: builtin:process.memory.jvm.heapUtilization
→ Split by: process.group.name
→ Chart type: heatmap
→ Color scale: green (0%) → yellow (70%) → red (90%)

Reading the heatmap:
  Each row = one service
  Color = heap utilization at that time
  If a row goes red → heap pressure → action needed
```

**Panel 4: Kubernetes pod count**
```
Add tile → Custom chart
→ Metric: builtin:kubernetes.workload.pods.running
→ Split by: workload.name
→ Filter: namespace IN (payment-ns, order-ns, notification-ns)
→ Chart type: line

What to look for:
  Lines should be stable (3 payment-service, 3 order-service)
  Sudden drop = pod crash
  Gradual rise = HPA scaling under load
```

**Panel 5: Live log viewer**
```
Add tile → Log viewer tile
→ DQL:
  fetch logs, from: now()-15m
  | filter k8s.namespace.name =~ "(payment|order|notification)-ns"
  | filter status == "ERROR"
  | fields timestamp, service.name, content
  | sort timestamp desc
  | limit 20

This panel auto-refreshes → shows real-time errors
```

### Reading an existing dashboard during an incident

```
When something is wrong, scan the dashboard in THIS ORDER:

1. SLO tiles: is any SLO showing red (FAILURE)?
   → If yes: this is your primary focus. Error budget is being consumed.

2. Error rate chart: which service has the elevated error rate?
   → Click the spike → you're in the Services view for that service

3. Pod count: are pods restarting or scaling?
   → Sudden drops = crashes. Gradual rise = load-triggered scaling.

4. JVM heap heatmap: is heap elevated?
   → If heap is red AND errors are high → likely OOM causing pod restarts
   → If heap is green AND errors are high → code bug, not resource issue

5. Live log viewer: what is the most recent error message?
   → First message in the log viewer = what's failing right now
```

---

## Part 10 — Incident Response: Full Walkthrough

### Real incident: "payment-service Availability SLO degraded"

**T+0:00 — PagerDuty fires**
```
Alert: [PROD] payment-service: High error rate (2.3% > 0.1%)
Started: 14:23 JST
Problem URL: https://abc12345.live.dynatrace.com/ui/problems/P-9876543210
DQL: fetch logs,from:now()-30m | filter service.name=="payment-service" | filter status=="ERROR" | limit 20
```

**T+0:02 — Open DT problem**
```
Navigate: click the Problem URL from PagerDuty
Problem view shows:
  Impact: HIGH
  Affected: payment-service
  Start: 14:23:07
  Related events: [CUSTOM_DEPLOYMENT: payment-service=a1b2c3 at 14:22:00] ← deploy 1 min before!
  Root cause: payment-service (suggested by Davis AI)
```

**T+0:03 — Confirm: was it the deploy?**
```bash
git log --oneline -- gitops/production/app/payment-service/payment-service.yaml | head -3
# a1b2c3 chore(deploy-prod): payment-service=a1b2c3 [skip ci]
# d4e5f6 chore(deploy-prod): payment-service=d4e5f6 [skip ci]  ← previous good deploy
```

**T+0:04 — Check the error in DT**
```
Navigate: (stay in Problem view) → Click "payment-service" entity link
→ Response time: spiked at 14:23
→ Failure rate: 2.3% (was 0.02% before)
→ Click "Failure analysis"
  → org.springframework.dao.QueryTimeoutException: 89%
  → Connection refused: 11%
```

**T+0:05 — DQL: what is the FIRST error?**
```dql
fetch logs, from: "2024-01-15T14:22:00Z", to: "2024-01-15T14:25:00Z"
| filter service.name == "payment-service"
| filter status == "ERROR"
| sort timestamp asc
| limit 10
| fields timestamp, content, k8s.pod.name
```
Result:
```
14:23:07.004  ERROR: HikariCP - Connection pool is exhausted. Pool size: 10, Pending threads: 15
              pod: payment-service-7d9f8b-abc12
14:23:07.089  ERROR: HikariCP - Connection pool is exhausted. Pool size: 10, Pending threads: 15
              pod: payment-service-7d9f8b-def34
14:23:07.103  ERROR: HikariCP - Connection pool is exhausted. Pool size: 10, Pending threads: 15
              pod: payment-service-7d9f8b-ghi56
```

"Pool size: 10, Pending threads: 15" — the new deploy changed thread pool to 15 but HikariCP pool is still 10.

**T+0:06 — Confirm: all pods affected (not node issue)**
```dql
fetch logs, from: "2024-01-15T14:22:00Z", to: "2024-01-15T14:30:00Z"
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize count = count(), by: { k8s.pod.name }
| sort count desc
```
Result: all 3 pods have ~100 errors each. Shared config issue confirmed.

**T+0:07 — Rollback decision**

Root cause confirmed: deploy a1b2c3 increased thread pool from 10 to 15 but HikariCP pool size wasn't increased. Fix: rollback → then increase pool size in next deploy.

**T+0:08 — Execute rollback**
```bash
# Option 1: automated (CI auto-rollback should have already triggered)
# Check if auto-rollback fired:
git log --oneline -- gitops/production/app/payment-service/payment-service.yaml | head -3
# If you see "chore(rollback): revert to d4e5f6" → auto-rollback worked

# Option 2: manual rollback if auto-rollback didn't trigger
git pull origin main
sed -i 's|tag: "a1b2c3"|tag: "d4e5f6"|' \
  gitops/production/app/payment-service/payment-service.yaml
git add gitops/production/app/payment-service/payment-service.yaml
git commit -m "chore(rollback-prod): payment-service=d4e5f6 [skip ci]"
git push
# ArgoCD detects change → rolling update to d4e5f6
```

**T+0:12 — Verify recovery in DT**
```dql
fetch logs, from: now()-5m
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize count = count(), by: { bin(timestamp, 1m) }
| sort timestamp asc
```
Result:
```
14:24: 89 errors
14:25: 41 errors (rollback starting)
14:26: 8 errors (rolling update in progress)
14:27: 0 errors ← recovery confirmed
```

**T+0:15 — Close the incident**
```
Navigate: DT Problem view → "Close problem" (if it hasn't auto-closed)
→ Add root cause note: "Deploy a1b2c3 increased thread pool size without matching HikariCP pool size increase. Rolled back to d4e5f6."
```

**T+0:20 — Post-incident DQL for postmortem**
```dql
// How much error budget was consumed during this incident?
fetch logs, from: "2024-01-15T14:22:00Z", to: "2024-01-15T14:27:00Z"
| filter service.name == "payment-service"
| summarize
    total_requests = count(),
    errors = countIf(status == "ERROR")
| fieldsAdd error_rate = errors * 100.0 / total_requests
| fieldsAdd affected_users = errors   // each error = one failed user request

// Result:
// total_requests: 4,200 (1,400 req/min × 3 min incident)
// errors: 97 (2.3%)
// affected_users: 97 failed payment attempts
// SLO impact: 97/4200 = 2.3% failure rate for 3 minutes
//             = 0.0023 × 3/60/24/30 = 0.00016% of monthly requests
//             Error budget consumed: 0.00016% / 0.1% = 0.16% of monthly budget
```

---

## Part 11 — Key DT Settings Every SRE Must Configure

### Auto-tagging rules (what makes management zones work)

```
Navigate: Settings → Tags → Automatically applied tags
→ Click: Create tag

Tag name: team
Rule:
  Apply to: KUBERNETES_CLUSTER, POD, SERVICE, PROCESS_GROUP, HOST
  Conditions:
    Kubernetes namespace label "team" exists → Apply tag: team:{label value}

Tag name: environment
Rule:
  Apply to: (same as above)
  Conditions:
    Kubernetes namespace label "environment" exists → Apply tag: environment:{label value}
```

Result: payment-ns namespace has `team=payments, environment=production` labels → all services, pods, processes in that namespace get auto-tagged with `team:payments` and `environment:production`. Management zones filter by these tags.

```bash
# Verify auto-tagging worked
curl -sf -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/entities?entitySelector=type(SERVICE),tag(team:payments)&fields=tags" \
  | jq '.entities[] | {name: .displayName, tags: .tags}'
# Should show payment-service with tags team:payments, environment:production
```

### Anomaly detection settings

```
Navigate: Settings → Anomaly detection → Services
→ Select: payment-service
→ Adjust thresholds:
    Response time degradation:
      Alert if median > 50% higher than baseline for 5 minutes
    Error rate increase:
      Alert if error rate increases by 50% (relative)
      Alert if absolute error rate > 5% for 5 minutes
    Throughput drop:
      Alert if throughput drops by 50% for 5 minutes
```

These are DT's AUTOMATIC anomaly detection (Davis AI) — separate from your custom metric events. Davis AI uses machine learning to learn normal baselines automatically. Your metric events use fixed thresholds.

When to use each:
- Davis AI anomaly detection: catches RELATIVE changes (suddenly 2× slower than normal)
- Custom metric events: catches ABSOLUTE thresholds (P99 > 300ms regardless of baseline)
- Use BOTH: Davis catches unexpected degradation, custom events enforce SLO boundaries

---

## Part 12 — Checklist: SRE Dynatrace Competency

### Things you should be able to do without referring to docs

```
NAVIGATION (< 1 minute each):
  □ Open Problems view and filter to a specific management zone
  □ Navigate from a Service overview to its distributed traces
  □ Find the "Logs" tab within a specific trace span
  □ Open the Kubernetes view and find a specific pod's metrics
  □ Check an SLO's error budget remaining

DQL QUERIES (write from memory):
  □ Top 10 error messages for a service in last 30 min
  □ Error count per minute over last 2 hours (for incident timeline)
  □ Which pods are producing errors (sorted by error count)
  □ Parse a JSON log field and filter on it
  □ Find the first occurrence of a specific error (sort asc)

API CALLS (run from terminal):
  □ Query error rate for a service
  □ Check SLO status and error budget
  □ Inject a deployment event
  □ Execute a DQL query via API
  □ Get open problems

ALERT MANAGEMENT:
  □ Find which metric event is generating a noisy alert
  □ Identify the current threshold and compare to observed baseline
  □ Update threshold in Terraform and apply
  □ Verify the change in DT UI

INCIDENT RESPONSE:
  □ Open problem → read Davis AI root cause suggestion
  □ Confirm it's all pods or one pod (via DQL)
  □ Find the first error message (sort asc, limit 10)
  □ Link the error to its distributed trace via dt.trace_id
  □ Execute manual rollback via gitops + ArgoCD
  □ Verify recovery via DQL error count trending to 0
```

---

## Reference: DT Metric Keys Used Daily

```
# SERVICE METRICS
builtin:service.requestCount.server          → requests per minute
builtin:service.errors.server.rate          → HTTP 5xx error rate (%)
builtin:service.response.time               → response time (microseconds)
builtin:service.response.time:percentile(99) → P99 response time
builtin:service.errors.server.count         → error count

# JVM METRICS
builtin:process.memory.jvm.heapUtilization  → heap used % of Xmx
builtin:process.memory.usage                → RSS memory % of limit
builtin:process.cpu.usage                   → process CPU %
builtin:process.threads.count              → thread count

# KUBERNETES METRICS
builtin:kubernetes.workload.pods.running    → running pod count
builtin:kubernetes.workload.pods.restarts   → restart count (5m window)
builtin:kubernetes.container.cpu.usage     → container CPU usage
builtin:kubernetes.container.memory.usage  → container memory usage

# HOST/NODE METRICS
builtin:host.cpu.usage                     → node CPU %
builtin:host.mem.usage                     → node memory %
builtin:host.net.errorRate                 → network error rate %
builtin:host.disk.used.percent             → disk usage %
```
