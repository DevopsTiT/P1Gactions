# Part 11 — SRE Day-to-Day Terraform Workflows Deep Dive

> The practical application of everything. Five real workflows an SRE executes regularly, with the exact commands, decision points, and verification steps for each.

---

## Workflow 1: Adding a New Service to Observability

### Context:
The platform team is launching `search-service`. It needs full Dynatrace observability: management zone, alerting profiles, 8 metric events, 2 SLOs, 1 synthetic monitor, PagerDuty and Slack notifications.

### Step-by-step:

```bash
# ── STEP 1: Edit the services map ────────────────────────────────────────────
# terraform/environments/production/main.tf
# Add inside the services = { ... } block:

"search-service" = {
  team             = "search"
  slo_target       = 99.5
  health_check_url = "https://search.company.com/actuator/health"

  traffic_min_rps        = 5
  error_rate_alert       = 0.3
  latency_p99_ms         = 500
  cpu_saturation_pct     = 80
  memory_usage_pct       = 78
  jvm_heap_pct           = 75
  pod_restart_threshold  = 2
  network_error_rate_pct = 1.0
}

# ── STEP 2: Validate the syntax ──────────────────────────────────────────────
cd terraform/environments/production
terraform validate
# Success! The configuration is valid.
# (If error: fix typo, missing comma, wrong type)

# ── STEP 3: Plan with target (only DT module) ────────────────────────────────
terraform plan -target=module.dynatrace -out=search-svc.plan
# Count what will be created:
# Plan: 27 to add, 0 to change, 0 to destroy.
# (24 metric events + 2 SLOs + 1 synthetic = 27 expected)

# ── STEP 4: Verify the plan shows ONLY new resources ─────────────────────────
terraform show search-svc.plan | grep "search-service" | head -20
# Should show: all 27 search-service resources being created
# Should NOT show: any existing payment/order/notification resources changing

terraform show search-svc.plan | grep "will be destroyed"
# Should return: nothing (0 destroys)

# ── STEP 5: Apply (or open PR for CI to apply) ───────────────────────────────
# Option A: direct apply (if you have production apply permissions)
terraform apply search-svc.plan

# Option B: PR workflow (standard team process)
git add terraform/environments/production/main.tf
git commit -m "feat(observability): add search-service Dynatrace monitoring"
git push origin add-search-service-monitoring
# → CI runs plan on PR → reviewer approves → CI applies on merge

# ── STEP 6: Verify in Dynatrace UI ───────────────────────────────────────────
# DT UI → Management Zones → search-production should appear
# DT UI → SLOs → search-service Availability [production] should appear
# DT UI → Synthetic monitors → search-service Health Check [production] should appear

# ── STEP 7: Confirm no drift ─────────────────────────────────────────────────
terraform plan -target=module.dynatrace
# Plan: 0 to add, 0 to change, 0 to destroy.
# (everything just created matches the .tf code)
```

---

## Workflow 2: Updating Production Alert Thresholds

### Context:
The payment team reviewed SLO performance for the last quarter. The latency P99 threshold of 300ms is too strict — legitimate traffic occasionally hits 350ms due to Japan→Singapore round trips. They want to increase it to 400ms. This requires a PR because production changes need review.

### Step-by-step:

```bash
# ── STEP 1: Create a feature branch ──────────────────────────────────────────
git checkout -b tune/payment-latency-threshold

# ── STEP 2: Make the change ──────────────────────────────────────────────────
# terraform/environments/production/main.tf
# Change:
#   "payment-service" = {
#     latency_p99_ms = 300  → 400
#   }

# ── STEP 3: Plan to see the exact diff ──────────────────────────────────────
terraform plan -target='module.dynatrace.dynatrace_metric_events.latency_p99["payment-service"]'
# Expected output:
#   ~ module.dynatrace.dynatrace_metric_events.latency_p99["payment-service"] {
#       id      = "metric-event-uuid"
#     ~ threshold = 300000 → 400000   ← DT uses microseconds (300ms × 1000 = 300000µs)
#     ~ summary   = "[PRODUCTION] payment-service: P99 latency >300ms"
#                 → "[PRODUCTION] payment-service: P99 latency >400ms"
#     }

# ── STEP 4: Also check the latency SLO (depends on latency_p99_ms) ──────────
terraform plan -target='module.dynatrace.dynatrace_slo_v2.latency["payment-service"]'
# The SLO metric_expression uses latency_p99_ms × 1000 in its filter condition
# This should also change to reflect the new threshold

# ── STEP 5: Open PR ──────────────────────────────────────────────────────────
git add terraform/environments/production/main.tf
git commit -m "tune(payment-service): increase P99 latency threshold from 300ms to 400ms

Reason: Japan→Singapore round trips add 50-100ms legitimately.
The 300ms threshold was generating false alerts during off-peak hours.
Historical 95th percentile: 280ms. 99.5th percentile: 390ms.
400ms threshold gives 0.5% headroom above observed P99.9."

git push origin tune/payment-latency-threshold
# → Opens PR
# → CI runs plan on all 3 environments:
#   production: 2 changes (metric event + SLO)
#   staging:    0 changes (staging threshold is 800ms, not affected)
#   dev:        0 changes (dev threshold is 2000ms, not affected)

# ── STEP 6: Reviewer sees in PR ──────────────────────────────────────────────
# ⚠️ Infra Plan — PRODUCTION
# ~ dynatrace_metric_events.latency_p99["payment-service"]
#     threshold = 300000 → 400000
# ~ dynatrace_slo_v2.latency["payment-service"]
#     ...
# Plan: 0 to add, 2 to change, 0 to destroy.
#
# Reviewer approves: "threshold change looks correct, matches the analysis"

# ── STEP 7: After merge → CI applies → verify ────────────────────────────────
# In Dynatrace UI:
# Services → payment-service → Performance metrics
# P99 alert threshold should now fire at 400ms not 300ms
# Synthetic loading time threshold: 400 × 3 = 1200ms (auto-updated)
```

---

## Workflow 3: Emergency Lock Release

### Context:
It's 3pm on a Friday. A GitHub Actions production apply job crashed mid-run (the runner was preempted). The DynamoDB lock was never released. Nobody can run `terraform apply` in production. An urgent configuration change needs to go out.

### Step-by-step:

```bash
# ── STEP 1: Inspect the lock ─────────────────────────────────────────────────
aws dynamodb get-item \
  --table-name terraform-state-lock \
  --key '{"LockID":{"S":"company-terraform-state-prod/production/terraform.tfstate"}}' \
  --region ap-northeast-1 \
  --output json | jq '.Item.Info.S | fromjson'

# Output:
# {
#   "ID": "abc123-lock-uuid",
#   "Operation": "OperationTypeApply",
#   "Who": "GitHub Actions (job: apply-production, run: 12345)",
#   "Version": "1.8.0",
#   "Created": "2026-07-31T14:30:00Z",
#   "Path": "company-terraform-state-prod/production/terraform.tfstate"
# }

# ── STEP 2: Confirm the locking job is dead ──────────────────────────────────
# Check GitHub Actions:
gh run view 12345 --repo company/infra
# Status: cancelled (or failed)
# Confirms: the job is dead, not still running

# ── STEP 3: Check if any state was partially written ─────────────────────────
# Download current state from S3
aws s3 cp s3://company-terraform-state-prod/production/terraform.tfstate /tmp/state-backup.json

# Verify state is not corrupted (basic check: is it valid JSON?)
python3 -c "import json; json.load(open('/tmp/state-backup.json')); print('State is valid JSON')"

# Check S3 versions (if versioning enabled)
aws s3api list-object-versions \
  --bucket company-terraform-state-prod \
  --prefix production/terraform.tfstate \
  --query 'Versions[0:3].[VersionId,LastModified,Size]'
# Shows last 3 versions — compare timestamps to the crash time

# ── STEP 4: Release the lock ─────────────────────────────────────────────────
cd terraform/environments/production
terraform force-unlock "abc123-lock-uuid"

# Output:
# Do you really want to force-unlock?
#   Terraform will remove the lock on the remote state.
#   This will allow local Terraform commands to modify this state, even though it
#   may be still in use. Only 'yes' will be accepted to confirm.
#
#   Enter a value: yes
#
# Terraform state has been successfully unlocked!

# ── STEP 5: Verify state is consistent ───────────────────────────────────────
terraform plan -refresh-only
# If the crashed apply created some resources: they appear in AWS but not in state
# Plan shows: resources to add (the ones that were created but not written to state)
# If plan shows nothing: the crash happened before any resources were created

# ── STEP 6: Reconcile if needed ──────────────────────────────────────────────
# If plan shows resources to add (created but not in state):
terraform plan   # full plan showing all diffs
# Review: are these the expected resources from the crashed apply?
terraform apply  # re-applies to complete the interrupted operation

# ── STEP 7: Document the incident ────────────────────────────────────────────
# Add to the incident post-mortem:
# - What caused the runner to crash (AWS Spot interruption? GitHub runner limit?)
# - Time the lock was held: 2026-07-31 14:30:00Z to 15:45:00Z (1h15m)
# - Any state inconsistency found (yes/no)
# - Remediation: force-unlock + re-apply
```

---

## Workflow 4: Recovering From Corrupted State

### Context:
Someone manually edited `terraform.tfstate` with a text editor (trying to fix a resource ID) and corrupted it. `terraform plan` now fails with "Error reading JSON".

### Step-by-step:

```bash
# ── STEP 1: Attempt to diagnose ──────────────────────────────────────────────
terraform plan
# Error: error loading state:
# Error parsing state file: invalid character 'i' looking for beginning of value

# ── STEP 2: Download current (corrupted) state ───────────────────────────────
aws s3 cp s3://company-terraform-state-prod/production/terraform.tfstate \
  /tmp/state-corrupted.json

# Try to validate the JSON:
python3 -m json.tool /tmp/state-corrupted.json
# Errors will show the line number of the corruption

# ── STEP 3: Get the previous version from S3 (versioning enabled) ─────────────
# List versions sorted by date
aws s3api list-object-versions \
  --bucket company-terraform-state-prod \
  --prefix production/terraform.tfstate \
  --query 'sort_by(Versions, &LastModified)[*].[VersionId,LastModified]' \
  --output table

# Download the version from BEFORE the manual edit:
aws s3api get-object \
  --bucket company-terraform-state-prod \
  --key production/terraform.tfstate \
  --version-id "version-id-from-before-corruption" \
  /tmp/state-previous.json

# Verify it's valid:
python3 -m json.tool /tmp/state-previous.json > /dev/null && echo "Valid JSON"
terraform show /tmp/state-previous.json  # should show resources, not errors

# ── STEP 4: Restore the previous state ───────────────────────────────────────
terraform state push /tmp/state-previous.json
# This replaces the remote state with the previous version
# Terraform will increment the serial number automatically

# ── STEP 5: Verify recovery ──────────────────────────────────────────────────
terraform plan -refresh-only
# Should run successfully now
# May show drift if the manual state edit was trying to reflect real changes
# Handle drift per Workflow in Part 7

# ── STEP 6: If previous version also corrupted ───────────────────────────────
# Look at more versions (list all versions, find a clean one)
# If no clean state exists: terraform state pull from a machine that still has a local cache
# In the worst case: manually reconstruct state using terraform import for each resource
#   (extremely time-consuming, see next section)
```

---

## Workflow 5: Full Environment Bootstrap (Initial Setup)

### Context:
Setting up a brand new staging environment from scratch. No resources exist yet. This workflow takes approximately 35 minutes end-to-end.

### Step-by-step:

```bash
# ── PREREQUISITE: Create S3 and DynamoDB (must exist BEFORE terraform init) ──
aws s3api create-bucket \
  --bucket company-terraform-state-staging \
  --region ap-northeast-1 \
  --create-bucket-configuration LocationConstraint=ap-northeast-1

aws s3api put-bucket-versioning \
  --bucket company-terraform-state-staging \
  --versioning-configuration Status=Enabled

aws s3api put-public-access-block \
  --bucket company-terraform-state-staging \
  --public-access-block-configuration \
    "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"

aws dynamodb create-table \
  --table-name terraform-state-lock \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region ap-northeast-1

# ── PREREQUISITE: Create secrets in Secrets Manager ──────────────────────────
aws secretsmanager create-secret \
  --name staging/dynatrace/api-token \
  --secret-string "dt0c01.ACTUAL_STAGING_TOKEN" \
  --region ap-northeast-1

# (also create: staging/dynatrace/tenant-url, staging/dynatrace/slack-webhooks,
#               staging/dynatrace/pagerduty-keys)

# ── STEP 1: Initialize ───────────────────────────────────────────────────────
cd terraform/environments/staging
terraform init
# Expected: downloads providers, creates empty state file in S3

# ── STEP 2: Validate ─────────────────────────────────────────────────────────
terraform validate
# Must pass before any planning

# ── STEP 3: Plan the full environment ────────────────────────────────────────
terraform plan -out=staging-bootstrap.plan 2>&1 | tee staging-plan.txt

# Count expected resources:
grep "to add" staging-plan.txt | tail -1
# Plan: 127 to add, 0 to change, 0 to destroy.

# Look for potential issues:
grep "forces replacement" staging-plan.txt  # should be empty
grep "will be destroyed" staging-plan.txt   # should be empty

# ── STEP 4: Apply (will take 25-35 minutes) ──────────────────────────────────
terraform apply staging-bootstrap.plan

# Watch for:
# - VPC creates in ~30 seconds
# - EKS cluster takes 15-20 minutes (normal — Terraform polls until ACTIVE)
# - DT resources create in ~3 minutes (parallel to EKS wait)
# - EKS node group takes 5 minutes after cluster

# If it fails partway through:
# → Note the error
# → terraform apply staging-bootstrap.plan again (resumes from failure)
#   (failed resources are retried, completed resources are skipped)

# ── STEP 5: Connect kubectl ──────────────────────────────────────────────────
aws eks update-kubeconfig \
  --name company-staging \
  --region ap-northeast-1

kubectl get nodes
# NAME                                         STATUS   ROLES    AGE
# ip-10-0-5-100.ap-northeast-1.compute.internal   Ready    <none>   2m

# ── STEP 6: Verify all resources ─────────────────────────────────────────────
# Terraform state
terraform state list | wc -l
# Should show 127 (all resources created)

# Kubernetes
kubectl get namespaces  # shows cluster is accessible

# Dynatrace
# DT UI → Management Zones → payments-staging, orders-staging, notifications-staging
# DT UI → Synthetic monitors → running health checks every 5 min

# ── STEP 7: Confirm clean state ──────────────────────────────────────────────
terraform plan
# Plan: 0 to add, 0 to change, 0 to destroy.
# Clean state — ready for ArgoCD bootstrap and application deployments.
```

---

## The "First -target, then Full Apply" Safety Pattern

Every time `-target` is used, complete the workflow with a full plan:

```bash
# Pattern: use -target for speed, then confirm nothing else is pending

# Targeted apply (fast):
terraform apply -target=module.dynatrace -auto-approve

# Immediately verify nothing else is pending:
terraform plan -detailed-exitcode
# Exit 0: clean, nothing pending → done
# Exit 2: other pending changes → INVESTIGATE NOW before they accumulate

# If exit 2, review the pending changes:
terraform plan 2>&1 | grep -E "will be (created|updated|destroyed)"
# Decide: apply them now, or create a PR for them
```

This pattern prevents the "drift accumulation" anti-pattern described in Part 9.
