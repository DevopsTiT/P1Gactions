# Part 5 — The `-target` Flag Deep Dive

> `-target` is the most misused Terraform feature. Used correctly in specific scenarios it saves time. Used routinely it creates invisible technical debt that leads to production surprises.

---

## What `-target` Does

```bash
terraform apply -target=module.dynatrace
# Reads the full .tf files and state
# Plans and applies ONLY resources that are:
#   a) Directly named by the target (module.dynatrace.*)
#   b) DEPENDENCIES of the target that also need changes
# Everything else: NOT touched, NOT refreshed, NOT planned
```

**The dependency inclusion rule:**

```
If you target module.dynatrace.dynatrace_slo_v2.availability["payment-service"]:
  Terraform ALSO includes:
    - module.dynatrace.dynatrace_management_zone_v2.team["payments"]
      (the SLO alert references the management zone → management zone is a dependency)
  
  But NOT:
    - module.dynatrace.dynatrace_metric_events.error_rate["payment-service"]
      (this is a SIBLING resource, not a dependency)

You can observe this by running:
  terraform plan -target=module.dynatrace.dynatrace_slo_v2.availability[\"payment-service\"]
  → Plan will include the SLO AND its management zone dependency
```

---

## The Three Legitimate Use Cases

### Use Case 1: First-Time Partial Apply During Setup

```bash
# Scenario: setting up a new environment for the first time
# VPC + EKS takes 25 minutes. Dynatrace takes 5 minutes.
# You want to set up Dynatrace NOW using an existing EKS cluster
# rather than waiting for the VPC module to finish.

cd terraform/environments/dev

# Apply ONLY the Dynatrace configuration
terraform apply -target=module.dynatrace
# Takes ~5 minutes
# VPC and EKS are completely untouched

# Later, apply the infrastructure
terraform apply -target=module.vpc
terraform apply -target=module.eks
# Then: terraform apply (full apply to reconcile everything)
```

### Use Case 2: Adding a New Service Without Touching Existing Config

```bash
# Scenario: adding "search-service" to the services map
# Only want to create 24 new Dynatrace resources
# Don't want to refresh VPC (50+ resources → 50 AWS API calls → 30 seconds)

# After editing environments/production/main.tf to add search-service:
terraform plan -target=module.dynatrace -out=search-svc.plan

# Plan shows: 24 to add (search-service resources only), 0 to change, 0 to destroy
# None of the existing payment/order/notification resources are shown → correct
# None of the VPC/EKS resources are shown → correct (not in scope)

terraform apply search-svc.plan
# ~3 minutes to create 24 DT resources
# Everything else: untouched
```

### Use Case 3: Emergency Targeted Fix

```bash
# Scenario: an alert shows the payment-service SLO target was manually changed
# in the Dynatrace UI from 99.9% to 95%. Need to revert IMMEDIATELY.
# Don't want to run a full apply (might catch other pending changes).

# Revert ONLY the specific SLO:
terraform apply \
  -target='module.dynatrace.dynatrace_slo_v2.availability["payment-service"]'

# Plan output:
#   ~ dynatrace_slo_v2.availability["payment-service"] {
#       ~ target_success = 95.0 -> 99.9
#     }
# 
# Apply: fixes the SLO in ~10 seconds
# All other resources: untouched
```

---

## Why Routine `-target` Use Is Dangerous

### Danger 1: Silent State Divergence

```
Scenario:
  You regularly use: terraform apply -target=module.dynatrace
  (to avoid slow VPC refresh)
  
  Meanwhile, someone changes the EKS version from 1.29 to 1.30 in .tf.
  
  Your next `terraform apply -target=module.dynatrace`:
    Plans and applies ONLY Dynatrace
    Does NOT see the EKS version change
    Does NOT apply the EKS update
    Does NOT report "there are pending EKS changes"
    
  The EKS change sits unapplied for days/weeks.
  During this time:
    - State says 1.29, .tf says 1.30 → silent divergence
    - One day someone runs `terraform apply` (full, no target):
      Plans include the EKS update + ALL pending changes
      The EKS update happens unexpectedly
      Nodes are replaced during a high-traffic period
      Outage.
```

### Danger 2: Dependency Out-of-Sync

```
Scenario:
  Module A depends on module B.
  Module B needs an update (critical security patch).
  You apply module A with -target, skipping module B.
  
  Module A now runs against the OLD version of module B.
  If the security patch changed an API endpoint:
    Module A is misconfigured until module B is also applied.
    But -target never told you this dependency was pending.
```

### Danger 3: The -target "Debt" Accumulation

```
Week 1: terraform apply -target=module.dynatrace (skipped VPC refresh)
Week 2: terraform apply -target=module.dynatrace (skipped VPC and EKS refresh)
Week 3: terraform apply -target=module.dynatrace -target=module.eks.aws_eks_node_group.system

After 3 weeks:
  Full terraform plan shows:
    7 pending VPC changes
    2 pending EKS add-on updates
    3 pending security group rule changes
    1 pending IAM policy update
  
  These were accumulating while -target was applied repeatedly.
  Nobody knows which changes are safe to apply together.
  The full apply becomes scary → people avoid it → more -target debt.
  
  Eventually: someone must review weeks of accumulated pending changes
  at once, under time pressure during an incident.
```

---

## The Correct Alternative: `terraform refresh`

```bash
# If the problem with full terraform plan is slow refresh:
# Skip the refresh (not the plan) using -refresh=false

terraform plan -refresh=false
# Skips AWS API calls for each resource (~30 second savings for 50+ resources)
# Still shows ALL resource diffs based on .tf vs state file
# Does NOT miss pending changes in .tf files
# Trade-off: won't detect manual AWS changes (drift)
```

**When `-refresh=false` vs `-target`:**
```
Problem: "plan is too slow because of refresh"
  Fix: terraform plan -refresh=false  ← correct
  Antifix: terraform plan -target=module.X ← hides other changes

Problem: "I only want to apply changes for one module"
  Scenario A: intentional staged rollout (first time setup)
    Fix: terraform apply -target=module.X  ← legitimate
  
  Scenario B: avoiding pending changes in other modules
    Fix: terraform apply (full) ← correct, accept all changes
    Antifix: terraform apply -target=module.X ← accumulates debt
```

---

## How to Safely Use `-target` Without Accumulating Debt

**Rule 1: Always follow up with a full plan**
```bash
# Apply targeted change
terraform apply -target=module.dynatrace

# IMMEDIATELY run a full plan to see what else is pending
terraform plan -detailed-exitcode
# Exit 0: nothing else pending → clean state
# Exit 2: other pending changes → review them NOW, don't defer
```

**Rule 2: Document why -target was used**
```bash
# In CI commit message or PR description:
# "Used -target=module.dynatrace to immediately add search-service alert.
#  Full plan shows no other pending changes (verified with terraform plan)."
```

**Rule 3: After -target, always do a full apply**
```bash
# Pattern: target for speed, then full apply to confirm clean state
terraform apply -target=module.dynatrace  # fast partial apply
terraform plan                            # verify nothing else is pending
terraform apply                           # full apply (should be: 0 changes)
```

---

## Target Address Syntax

```bash
# Target an entire module
-target=module.dynatrace

# Target a specific resource type within a module
-target=module.dynatrace.dynatrace_slo_v2.availability

# Target a specific resource with for_each key
# Note: must escape the quotes in bash
-target='module.dynatrace.dynatrace_slo_v2.availability["payment-service"]'

# Target a nested module
-target=module.eks.module.eks_cluster.aws_eks_cluster.this

# Multiple targets (all must be specified with separate -target flags)
terraform apply \
  -target=module.dynatrace \
  -target='module.eks.aws_eks_node_group.system'

# Get the exact address from state list:
terraform state list | grep "availability"
# module.dynatrace.dynatrace_slo_v2.availability["notification-service"]
# module.dynatrace.dynatrace_slo_v2.availability["order-service"]
# module.dynatrace.dynatrace_slo_v2.availability["payment-service"]

# Use the exact address (copy-paste from state list):
terraform apply -target='module.dynatrace.dynatrace_slo_v2.availability["payment-service"]'
```

---

## Terraform's Warning (Always Appears with -target)

```
Warning: Resource targeting is in effect

Terraform is currently working on a subset of your configuration.
This mode is valid only when used for exceptional purposes such as
recovering from mistakes or working around Terraform limitations.

Applied changes may not be visible to other Terraform operations,
and Terraform may undo or alter previously applied changes when
run without the -target flag.

Do you want to perform these actions?
  Terraform will perform the following actions:
  [only the targeted resources...]

  Enter a value: yes
```

**What "Terraform may undo" means:**
```
Scenario:
  You -target applied a resource with a specific attribute value.
  The .tf file has a DIFFERENT value for that same attribute.
  (You manually tested something by targeting a one-off value)
  
  Next full terraform apply:
    Detects: resource has attribute X, .tf says attribute Y
    Changes: resource → attribute Y
  
  This is correct behavior (Git is truth).
  The warning says: "be aware that targeted applies may create
  temporary states that full applies will correct."
```
