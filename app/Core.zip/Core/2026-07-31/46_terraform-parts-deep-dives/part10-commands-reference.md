# Part 10 — Practical Commands Reference Deep Dive

> Every Terraform command an SRE needs, with the flag combinations that actually matter in production. Each command is explained as a decision: WHY use this form instead of another.

---

## Initialization Commands

```bash
# ── BASIC INIT ────────────────────────────────────────────────────────────────
terraform init
# When to use: first time in a new directory, or after changing backend/providers
# What it does: downloads providers, configures backend, copies modules
# Safe to run multiple times (idempotent)

# ── INIT WITH PROVIDER UPGRADE ───────────────────────────────────────────────
terraform init -upgrade
# When to use: you want to get the latest provider version within your constraint
# What it does: re-downloads providers, ignoring cached versions
# Updates .terraform.lock.hcl
# After running: git add .terraform.lock.hcl && git commit

# ── INIT RECONFIGURE ─────────────────────────────────────────────────────────
terraform init -reconfigure
# When to use: you changed the backend configuration (different S3 bucket, different key)
# What it does: forces re-initialization of the backend, ignores cached backend config
# WARNING: if changing buckets, migrate state first (terraform state pull/push)

# ── INIT WITHOUT BACKEND (local state) ───────────────────────────────────────
terraform init -backend=false
# When to use: testing modules locally, running terraform validate in CI quickly
# What it does: initializes providers but uses local state (not S3)
# Use case: running validate/fmt in CI without needing AWS credentials

# ── INIT FOR MULTIPLE PLATFORMS ──────────────────────────────────────────────
terraform providers lock \
  -platform=linux_amd64 \
  -platform=darwin_amd64 \
  -platform=darwin_arm64
# When to use: before committing .terraform.lock.hcl
# Why: the lock file must contain hashes for ALL platforms your team uses
# Without this: developer on Mac M1 (darwin_arm64) can't use a lock file
# that only has linux_amd64 hashes
# After running: commit .terraform.lock.hcl
```

---

## Validation and Formatting

```bash
# ── VALIDATE (syntax + references) ───────────────────────────────────────────
terraform validate
# Always run BEFORE plan in CI — catches typos in 1 second vs 30 seconds for plan
# No AWS credentials needed
# Exit code 0: valid. Exit code 1: errors (shown in output).

# ── FORMAT CHECK (CI) ─────────────────────────────────────────────────────────
terraform fmt -check -recursive
# In CI: exit code 1 if any .tf file needs formatting → fail the job
# Never run this with -write in CI (read-only CI runner)

# ── FORMAT IN PLACE (developer) ──────────────────────────────────────────────
terraform fmt -recursive
# Rewrites all .tf files in current directory and subdirectories
# Run before every commit
# git diff after: shows formatting changes (should be styling only, not logic)

# ── FORMAT A SINGLE FILE ─────────────────────────────────────────────────────
terraform fmt terraform/modules/dynatrace/main.tf
# More targeted, useful when only one file was edited
```

---

## Planning Commands — Decision Guide

```bash
# ── BASIC PLAN (interactive review) ──────────────────────────────────────────
terraform plan
# Use when: iterating on code, want quick feedback
# Does NOT save the plan
# Someone could change code between plan and apply → different result

# ── PLAN TO FILE (production deploys) ────────────────────────────────────────
terraform plan -out=production.tfplan
# Use when: reviewing before production apply
# Saves exact plan to binary file
# terraform apply production.tfplan → applies EXACTLY what was reviewed
# If code changed between plan and apply:
#   terraform apply production.tfplan  →  "Saved plan is stale"
#   → prevents surprise changes

# ── PLAN WITH EXACT EXIT CODE (CI/scripts) ───────────────────────────────────
terraform plan -detailed-exitcode
echo $?
# 0 = success, no changes needed (already up-to-date)
# 1 = error (plan failed)
# 2 = success, changes exist
# Use in CI:
#   terraform plan -detailed-exitcode 2>&1 | tee plan.txt
#   EXIT=${PIPESTATUS[0]}
#   if [ $EXIT -eq 2 ]; then create_pr_comment; fi

# ── PLAN WITHOUT REFRESH (fast, uses cached state) ───────────────────────────
terraform plan -refresh=false
# Use when: you just applied and know state is current
#           OR: plan is slow because of many AWS API calls
# Does NOT miss .tf code changes — only skips the AWS API check for each resource
# Useful for rapid iteration during development
# NOT for production drift detection (drift won't show)

# ── PLAN WITH REFRESH ONLY (drift detection) ─────────────────────────────────
terraform plan -refresh-only
# Shows ONLY: things that changed in AWS since last apply
# Does NOT show: pending .tf code changes
# Use for: drift detection, investigating manual changes
# Combined with -detailed-exitcode:
#   terraform plan -refresh-only -detailed-exitcode
#   Exit 2 = drift found

# ── PLAN FOR A SPECIFIC MODULE ────────────────────────────────────────────────
terraform plan -target=module.dynatrace
# Use when: only adding/changing DT config, not touching VPC/EKS
# Legitimate for staged rollouts

# ── PLAN WITH VARIABLE OVERRIDE ──────────────────────────────────────────────
terraform plan -var="environment=dev" -var="dt_api_token=test-token"
# Overrides variable values from the command line
# Useful for testing different values without editing .tf files
# For secrets: use this pattern in CI to avoid hardcoding
# (pass secrets as CI environment variables, not in .tf files)

# ── PLAN TO DESTROY ───────────────────────────────────────────────────────────
terraform plan -destroy
# Shows all resources that WOULD be destroyed by terraform destroy
# Does NOT destroy anything
# Use to review destruction before committing to it
```

---

## Apply Commands — Decision Guide

```bash
# ── APPLY SAVED PLAN (production, safest) ────────────────────────────────────
terraform apply production.tfplan
# The ONLY safe way to apply to production
# Applies exactly what was reviewed in the PR plan comment
# If plan is stale: "Saved plan is stale, please re-run plan"

# ── APPLY WITH AUTO-APPROVE (CI, non-interactive) ────────────────────────────
terraform apply -auto-approve
# For CI/CD pipelines where there's no human to type "yes"
# NEVER use interactively in production — removes the confirmation prompt safety check
# In CI: protect with approval gates (GitHub environment: production)

# ── APPLY A SPECIFIC RESOURCE ────────────────────────────────────────────────
terraform apply -target='module.dynatrace.dynatrace_slo_v2.availability["payment-service"]'
# Targeted apply — see Part 5 for full guidance
# Quote marks required in bash: -target='...'
# Note the escaped quotes inside: [\"payment-service\"] or wrap in single quotes

# ── APPLY WITH FORCED RECREATION ─────────────────────────────────────────────
terraform apply -replace='module.eks.aws_eks_node_group.system'
# Forces destroy + recreate of a specific resource
# Use when: a node is unhealthy, a resource is stuck, need a fresh start

# ── APPLY WITH HIGHER PARALLELISM ────────────────────────────────────────────
terraform apply -parallelism=20
# Default is 10. Increase for large initial deployments.
# Risk: AWS API rate limiting at high parallelism
# Safe range: 10-20 for most environments, 5 for rate-limited accounts

# ── APPLY WITH LOCK TIMEOUT ───────────────────────────────────────────────────
terraform apply -lock-timeout=10m
# Wait up to 10 minutes for the DynamoDB lock before failing
# Default: wait indefinitely (or until killed)
# Useful in CI: fail fast if another apply is running for more than 10 minutes

# ── APPLY WITHOUT LOCK (dangerous) ──────────────────────────────────────────
terraform apply -lock=false
# Skips DynamoDB locking entirely
# NEVER use in production — allows concurrent applies → state corruption
# Use case: local testing when DynamoDB table doesn't exist
```

---

## Destroy Commands — Decision Guide

```bash
# ── DESTROY ONE RESOURCE (safe) ───────────────────────────────────────────────
terraform destroy -target='module.dynatrace.dynatrace_http_monitor.health_check["payment-service"]'
# Destroys ONLY this specific resource
# All others: untouched
# Most common legitimate use of -target

# ── DESTROY ONE MODULE ────────────────────────────────────────────────────────
terraform destroy -target=module.dynatrace
# Destroys all resources in the module
# Other modules (vpc, eks): untouched
# Use for decommissioning a specific stack component

# ── DESTROY WITH PLAN REVIEW FIRST ────────────────────────────────────────────
terraform plan -destroy          # review what would be destroyed
terraform destroy                # then destroy (if plan was acceptable)
# Always review before destroying

# ── DESTROY ALL (dangerous — use only in dev) ─────────────────────────────────
terraform destroy
# Destroys EVERYTHING in the current workspace
# Interactive prompt: "Do you really want to destroy all resources?"
# Requires typing "yes"
# NEVER run in production without careful consideration
```

---

## State Management Commands

```bash
# ── LIST ALL MANAGED RESOURCES ────────────────────────────────────────────────
terraform state list
terraform state list | wc -l                          # count managed resources
terraform state list | grep "payment"                 # filter by name
terraform state list | grep "dynatrace_slo"           # find all SLOs

# ── INSPECT ONE RESOURCE ──────────────────────────────────────────────────────
terraform state show 'module.dynatrace.dynatrace_slo_v2.availability["payment-service"]'
# Shows all attributes as they appear in state (last-applied values)
# Compare with AWS/DT UI to confirm if resource matches state

# ── RENAME A RESOURCE ─────────────────────────────────────────────────────────
terraform state mv \
  'old.resource.address["key"]' \
  'new.resource.address["key"]'
# Use when refactoring .tf code (renaming resource blocks)
# Prevents unnecessary destroy+recreate

# ── REMOVE FROM TRACKING ──────────────────────────────────────────────────────
terraform state rm 'module.dynatrace.dynatrace_dashboard.network_overview'
# Removes from state WITHOUT deleting the real resource
# Resource still exists in DT/AWS — Terraform just stops managing it
# MUST also remove from .tf files to prevent Terraform from trying to re-create

# ── ADOPT AN EXISTING RESOURCE ────────────────────────────────────────────────
terraform import \
  'module.dynatrace.dynatrace_slo_v2.availability["payment-service"]' \
  "actual-uuid-from-dynatrace-api"
# Add .tf block FIRST, then import
# After import: terraform plan → shows drift between state and .tf
# Update .tf to match → no changes on next plan

# ── DOWNLOAD THE STATE FILE ───────────────────────────────────────────────────
terraform state pull > state-backup.json
# Creates a local copy of the remote state file
# Useful for: inspecting state, making manual edits (dangerous!), backups

# ── UPLOAD A STATE FILE (DANGEROUS) ──────────────────────────────────────────
terraform state push state-modified.json
# Replaces the remote state with a local file
# Use ONLY for recovery from state corruption
# ALWAYS back up the remote state first (S3 versioning helps)

# ── RELEASE A STUCK LOCK ──────────────────────────────────────────────────────
terraform force-unlock "lock-uuid-from-dynamodb"
# ONLY if the locking process is confirmed dead
# Gets lock UUID from: aws dynamodb get-item --table-name terraform-state-lock ...
```

---

## Inspection Commands

```bash
# ── ALL OUTPUTS ───────────────────────────────────────────────────────────────
terraform output
# Shows all output values defined in outputs.tf
# Useful for getting cluster endpoints, ARNs, etc.

# ── SINGLE OUTPUT AS PLAIN TEXT ───────────────────────────────────────────────
terraform output -raw cluster_endpoint
# Returns: "https://ABCDEF.gr7.ap-northeast-1.eks.amazonaws.com"
# -raw: no quotes, no formatting, just the value
# Useful in scripts:
EKS_ENDPOINT=$(terraform output -raw cluster_endpoint)
aws eks update-kubeconfig --name company-dev

# ── OUTPUT IN JSON ────────────────────────────────────────────────────────────
terraform output -json
# Returns all outputs as a JSON object
# Useful for: scripting, piping to jq

# ── VISUALIZE THE DEPENDENCY GRAPH ────────────────────────────────────────────
terraform graph | dot -Tpng > infrastructure-graph.png
# Requires: graphviz installed (brew install graphviz)
# Generates a visual graph of all resource dependencies
# Useful for: understanding which resources depend on which
# Warning: very large for complex configurations (hundreds of resources)

# ── LIST ALL PROVIDERS ────────────────────────────────────────────────────────
terraform providers
# Shows which providers are used and their versions
# Useful for: auditing provider versions, finding unused providers

# ── CHECK TERRAFORM AND PROVIDER VERSIONS ────────────────────────────────────
terraform version
# Terraform v1.8.0
# on darwin_arm64
#
# Your version of Terraform is out of date! The latest version is 1.9.0.
# You can update by downloading from https://www.terraform.io/downloads.html
```

---

## Quick Reference: When to Use Which

```
FIRST TIME SETUP:
  terraform init
  terraform validate
  terraform plan -out=init.plan
  terraform apply init.plan

DAILY DEVELOPMENT:
  [edit .tf files]
  terraform fmt
  terraform validate
  terraform plan -refresh=false   (fast iteration)
  terraform apply

BEFORE MERGING TO MAIN:
  terraform fmt -check -recursive
  terraform validate
  terraform plan -out=pr.plan
  [post plan output to PR for review]

PRODUCTION DEPLOY:
  terraform plan -out=production.tfplan 2>&1 | tee plan-review.txt
  [human reviews plan-review.txt]
  [approval gate in CI/CD]
  terraform apply production.tfplan

DRIFT CHECK:
  terraform plan -refresh-only -detailed-exitcode
  [if exit 2]: investigate and resolve drift

ADDING A SERVICE:
  [edit services map in environment/main.tf]
  terraform plan -target=module.dynatrace -out=new-service.plan
  terraform apply new-service.plan

EMERGENCY REVERT:
  terraform apply -target='module.dynatrace.SPECIFIC.RESOURCE'
  [reverts that resource to .tf state]
```
