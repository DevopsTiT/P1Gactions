# Part 9 — Common Mistakes Deep Dive

> Each mistake is explained with: what happens, why it's dangerous, and the exact fix. These are real patterns that destroy production environments and burn SRE teams.

---

## Mistake 1: Committing `.tfstate` to Git

**What happens:**
```
Engineer Alice does:
  cd terraform/environments/production
  terraform apply
  git add .
  git commit -m "applied terraform"
  git push
  
.gitignore doesn't have *.tfstate
  → terraform.tfstate (or .terraform.tfstate.lock.info) is committed
```

**Why it's dangerous:**
```
terraform.tfstate in plaintext JSON contains:
  - AWS resource ARNs (tells attackers your infrastructure topology)
  - EKS cluster endpoint URLs (attack surface)
  - Any sensitive values stored in resources (even if marked sensitive = true)
    → the state file has them in plaintext regardless
  - RDS connection strings (if terraform manages RDS)
  - IAM role ARNs (tells attackers what permissions to target)

Once in git history, it's PERMANENT:
  git rm terraform.tfstate removes it from HEAD
  but it's still in every previous commit
  git clone downloads the full history → attacker gets the state file
  
If GitHub is public: credentials are PUBLIC immediately
If GitHub is private: still exposed to all repo readers
```

**The fix:**
```bash
# 1. Ensure .gitignore has these entries:
cat >> .gitignore << 'EOF'
*.tfstate
*.tfstate.*
.terraform/
*.tfplan
.terraform.lock.hcl.backup
EOF

# 2. Remove from git index (but keep the file locally):
git rm --cached terraform.tfstate
git rm --cached -r .terraform/

# 3. If already pushed to GitHub — rewrite history:
# WARNING: destructive, all collaborators must re-clone
git filter-branch --force --index-filter \
  'git rm --cached --ignore-unmatch terraform.tfstate \
   terraform.tfstate.backup .terraform.tfstate.lock.info' \
  --prune-empty --tag-name-filter cat -- --all

# 4. Force push (requires team coordination):
git push origin --force --all

# 5. Rotate ALL credentials that appeared in the state file:
# - AWS access keys
# - Dynatrace API tokens
# - PagerDuty integration keys
# - Slack webhook URLs
# All of these must be treated as compromised
```

---

## Mistake 2: `terraform destroy` Without `-target`

**What happens:**
```
Engineer types "terraform destroy" intending to tear down a test resource.
Terraform shows: "Plan: 0 to add, 0 to change, 127 to destroy."
Engineer types "yes" without reading the 127.
Entire production environment is destroyed:
  - EKS cluster deleted
  - VPC deleted (takes all subnets, security groups with it)
  - All Dynatrace configuration deleted
```

**Why it happens:**
```
Cognitive automation: typing "yes" after a plan output is muscle memory.
Scale of destruction isn't obvious: "127 to destroy" doesn't convey:
  "the EKS cluster running 50 services for 10,000 users"
```

**The fix:**
```bash
# ALWAYS use -target for partial destruction:
terraform destroy -target='module.dynatrace.dynatrace_http_monitor.health_check["payment-service"]'
# Only this ONE synthetic monitor is destroyed
# All other 126 resources are untouched

# For full environment teardown: use additional safeguards:
# 1. First: plan and READ the output
terraform plan -destroy   # shows all resources that would be destroyed
                          # same as terraform destroy but without applying

# 2. Require the environment name as confirmation:
# Terraform doesn't have a built-in "type the environment name" feature,
# but you can add a pre-destroy check:
ENV=$(terraform output -raw environment_name 2>/dev/null)
echo "You are about to destroy: $ENV"
echo "Type '$ENV' to confirm:"
read CONFIRM
if [ "$CONFIRM" != "$ENV" ]; then
  echo "Confirmation failed. Exiting."
  exit 1
fi
terraform destroy

# 3. Use prevent_destroy lifecycle:
resource "aws_eks_cluster" "this" {
  ...
  lifecycle {
    prevent_destroy = true
    # Terraform refuses to destroy this resource
    # Plan will show: "Error: Instance cannot be destroyed"
    # Must FIRST remove prevent_destroy from .tf before destroying
  }
}
```

---

## Mistake 3: Ignoring the Plan Output (especially `-/+` lines)

**What happens:**
```
Engineer runs: terraform plan → sees many lines of output → scrolls to
"Plan: 5 to add, 3 to change, 2 to destroy" → types "yes" without reading

Hidden in the plan output:
  -/+ aws_subnet.private["az-a"] (forces replacement)
  CIDR changed: "10.0.0.0/24" → "10.0.0.0/20"
  
  This destroys the subnet, removing it as a valid AZ-a location.
  EKS can't schedule new pods in AZ-a until the subnet is recreated.
  Existing pods stay running (they're not evicted by subnet deletion).
  But if an AZ-a node is drained, new pods can't replace it.
```

**The fix — what to look for in every plan:**
```
READ EVERY LINE. Specifically:

1. Lines starting with - (RED): something is being DESTROYED
   - aws_eks_cluster.this   ← the entire EKS cluster will be deleted
   Is this intentional? If not: stop, investigate.

2. Lines starting with -/+ (RED+GREEN): destroy AND recreate
   -/+ aws_subnet.private["az-a"]   ← subnet destroyed and recreated
   This causes disruption for resources in that subnet.
   EKS pods, RDS instances, ElastiCache — all affected.

3. "forces replacement" annotation:
   ~ cidr_block = "10.0.0.0/24" → "10.0.0.0/20" (forces replacement)
   Some attributes are immutable. Changing them means destroy+recreate.
   
4. Large numbers:
   "Plan: 0 to add, 0 to change, 127 to destroy"
   If you expected 1 destroy and see 127: something is very wrong.

5. Resources you didn't change:
   If you only edited dynatrace thresholds but the plan shows EKS changes:
   Another change was pending (drift, or a colleague's unrelated change).
   Stop. Understand each change before applying.
```

**The recommended plan review process:**
```bash
# Save plan to file
terraform plan -out=review.tfplan 2>&1 | tee plan-output.txt

# Count destroys
grep "^  #.*will be destroyed" plan-output.txt | wc -l

# Show only destroy and replace operations
grep -E "^  - |^  -/\+" plan-output.txt

# Show forces replacement
grep "forces replacement" plan-output.txt

# Count creates, updates, destroys at the summary
tail -5 plan-output.txt
```

---

## Mistake 4: Hardcoding Secrets in `.tf` Files

**What happens:**
```hcl
# In environments/production/main.tf
module "dynatrace" {
  dt_api_token = "dt0c01.XXXX.actual_token_value_here"
  ...
}
```

```
git push → "dt0c01.XXXX..." in git history forever
Even after deletion: visible in git log, any cached mirror, GitHub API
Any repo reader can extract the token
Dynatrace API access: create/delete alerts, SLOs, management zones
```

**Why developers do it:**
```
"It's just a test" → test becomes production
"The repo is private" → private repos get compromised too, or go public
"I'll rotate it later" → "later" never comes
"It's just a read-only token" → scope often gets expanded later
```

**The fix:**
```hcl
# CORRECT: read from Secrets Manager at plan time
data "aws_secretsmanager_secret_version" "dt_api_token" {
  secret_id = "production/dynatrace/api-token"
}

module "dynatrace" {
  dt_api_token = data.aws_secretsmanager_secret_version.dt_api_token.secret_string
}
# The token value is NEVER in any .tf file
# The token is fetched at runtime (plan/apply time)
# If the token needs rotation: update Secrets Manager, next apply picks it up
```

**What to do if a secret was already committed:**
```bash
# 1. Revoke the exposed token IMMEDIATELY
# For Dynatrace API tokens: DT UI → Account → Access tokens → revoke
# For AWS keys: IAM → Users → Security credentials → Deactivate key

# 2. Create a new token
# 3. Store in Secrets Manager
# 4. Update Terraform to use Secrets Manager
# 5. Rewrite git history to remove the old token
git filter-branch --force --index-filter \
  'git rm --cached --ignore-unmatch environments/production/main.tf' \
  --prune-empty --tag-name-filter cat -- --all
# Note: this rewrites ALL commits touching main.tf
# Then add the file back correctly (using data source) and commit
```

---

## Mistake 5: Missing Version Constraints

**What happens:**
```hcl
# Missing version constraint:
terraform {
  required_providers {
    aws = { source = "hashicorp/aws" }  # no version pin
  }
}
```

```
January 2026:  terraform init downloads aws provider 5.50.0
               Everything works fine
               
April 2026:    AWS releases provider 6.0.0 (major version)
               Major version = breaking changes:
                 - Some resource types renamed
                 - Some attributes removed
                 - New required fields added
               
               Engineer runs: terraform init
               Downloads 6.0.0 (no version pin to prevent it)
               
               terraform plan:
               │ Error: Unsupported argument
               │ An argument named "cluster_endpoint_public_access" is not
               │ expected here. Did you mean "cluster_endpoint_public_access_cidrs"?
               
               The attribute was renamed. All three environments now fail to plan.
               Production is BLOCKED until the code is updated for v6.
               But v6 may have other breaking changes too — discovery takes hours.
```

**The fix:**
```hcl
terraform {
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.50" }
    # ~> 5.50 = allow 5.50.x, 5.51.x, 5.52.x
    #           block 6.0.0 (major version)
    
    # Most restrictive (patch-only updates):
    aws = { source = "hashicorp/aws", version = "= 5.50.0" }
    # Requires manual update to any new version
    # Safest for production, but requires active maintenance
    
    # Recommended middle ground:
    aws = { source = "hashicorp/aws", version = "~> 5.50" }
    # Gets bugfixes automatically, blocks breaking changes
  }
  
  required_version = ">= 1.8.0, < 2.0.0"
  # Also pin Terraform itself
  # Different Terraform versions may behave differently with same .tf code
}
```

**Updating pinned providers safely:**
```bash
# Check if updates are available
terraform providers lock -platform linux_amd64 -platform darwin_amd64

# Update to latest within constraint (e.g., 5.50 → 5.52):
terraform init -upgrade
# Downloads the latest allowed version
# Updates .terraform.lock.hcl
git add .terraform.lock.hcl
git commit -m "chore: upgrade AWS provider to 5.52.0"

# Before upgrading, check the provider changelog:
# https://github.com/hashicorp/terraform-provider-aws/releases
# Look for: BREAKING CHANGES, deprecated attributes, removed resources
```

---

## Mistake 6: Using `count` for Stable Collections

**What happens:**
```hcl
variable "alerting_levels" {
  default = ["critical", "high", "warning", "info"]
}

resource "dynatrace_alerting" "level" {
  count = length(var.alerting_levels)
  name  = "${var.alerting_levels[count.index]}-alerts"
}
```

```
State:
  level[0] = critical-alerts
  level[1] = high-alerts
  level[2] = warning-alerts
  level[3] = info-alerts

Request: "remove high-alerts, we don't need it"
Change: alerting_levels = ["critical", "warning", "info"]

New state after plan:
  level[0] = critical-alerts (unchanged)
  level[1] = warning-alerts  ← WAS high-alerts, now mapped to index 1
  level[2] = info-alerts     ← WAS index 3, now index 2

terraform plan shows:
  ~ level[1]: name = "high-alerts" → "warning-alerts"   (MODIFIED high to warning)
  ~ level[2]: name = "warning-alerts" → "info-alerts"   (MODIFIED warning to info)
  - level[3]: name = "info-alerts"                       (DESTROYED)
  
Result: high-alerts becomes warning-alerts, info-alerts DESTROYED
NOT what was intended: only high-alerts should be affected
```

**The fix:**
```hcl
# Use for_each with a set — key-based, stable
resource "dynatrace_alerting" "level" {
  for_each = toset(["critical", "high", "warning", "info"])
  name     = "${each.value}-alerts"
}

# State:
#   level["critical"] = critical-alerts
#   level["high"]     = high-alerts
#   level["warning"]  = warning-alerts
#   level["info"]     = info-alerts

# After removing "high":
# for_each = toset(["critical", "warning", "info"])
# 
# terraform plan shows:
#   - level["high"]: name = "high-alerts"   (DESTROYED — only this one)
#   level["critical"], ["warning"], ["info"]: UNTOUCHED
# 
# Correct behavior.
```

---

## Mistake 7: Not Testing Destroy Behavior

**What happens:**
```
Team writes a module with complex resources.
Deploys to dev, staging, production — all fine.
Six months later: needs to decommission staging.
terraform destroy -target=module.staging

Some resources have dependencies that prevent deletion:
  → IAM role has policies attached → can't delete role until policies detached
  → S3 bucket has objects → can't delete bucket until emptied
  → EKS cluster still has node groups → can't delete cluster until node groups deleted

Terraform outputs error after error.
Manual cleanup required.
Hours of work.
```

**The fix — test teardown in dev:**
```bash
# In dev environment, regularly test:
# 1. terraform destroy → verify clean teardown
# 2. terraform apply   → recreate from scratch
# 3. Verify everything works

# This validates:
# - Destroy ordering (resources deleted in correct order)
# - No orphaned resources (everything cleaned up)
# - Resource re-creation works (no hardcoded IDs anywhere)

# Add lifecycle hooks to handle teardown dependencies:
resource "aws_s3_bucket" "state" {
  bucket = "company-terraform-state-dev"
  
  lifecycle {
    prevent_destroy = true  # prevent accidental destroy
  }
}

# For S3 buckets that need to be destroyable:
resource "aws_s3_bucket_force_delete" "temp" {
  bucket = aws_s3_bucket.temp.id
  # Automatically empties the bucket before deletion
}
```
