# Part 3 — Module Architecture Deep Dive

> Modules are the fundamental unit of reuse in Terraform. This project's module structure — `modules/` vs `environments/` — separates LOGIC from DATA. Understanding this separation explains every design decision in the codebase.

---

## The Core Principle: Logic vs. Data Separation

```
modules/dynatrace/main.tf    → HOW to create observability resources
                                (the algorithm: for each service, create these 8 alerts)

environments/dev/main.tf     → WHAT values to use in dev
environments/staging/main.tf → WHAT values to use in staging
environments/production/main.tf → WHAT values to use in production
```

**Why this separation matters:**

```
WITHOUT the separation (everything in one file per env):
  environments/dev/dynatrace.tf     ← 600 lines of DT config for dev
  environments/staging/dynatrace.tf ← 600 lines, ~identical to dev
  environments/production/dynatrace.tf ← 600 lines, ~identical

  Bug found: error_rate metric has wrong threshold field
  Fix: edit in environments/dev, environments/staging, environments/production
       3 files, easy to miss one
       3 PRs or 1 PR with 3 files changed → harder to review

WITH the separation:
  modules/dynatrace/main.tf   ← 600 lines: the logic ONCE
  environments/dev/main.tf    ← 15 lines: the dev-specific values
  environments/staging/main.tf ← 15 lines
  environments/production/main.tf ← 15 lines

  Bug found: edit ONCE in modules/dynatrace/main.tf
  Next terraform apply in each environment: all three environments fixed
  1 PR, 1 file → easy to review, impossible to miss an environment
```

---

## Directory Structure Deep Dive

```
terraform/
├── modules/                    ← reusable logic (called by environments)
│   ├── vpc/
│   │   ├── main.tf             ← VPC, subnets, NAT gateways, S3 endpoint
│   │   └── variables.tf        ← inputs: name, cidr, azs, cluster_name, tags
│   ├── eks/
│   │   ├── main.tf             ← EKS cluster, node groups, add-ons, IAM
│   │   └── variables.tf        ← inputs: cluster_name, version, vpc_id, subnet_ids
│   └── dynatrace/
│       ├── main.tf             ← full DT stack: zones, alerts, metrics, SLOs, synthetics
│       └── variables.tf        ← inputs: environment, services map, thresholds, credentials
│
└── environments/               ← callers (one directory per AWS account)
    ├── dev/
    │   └── main.tf             ← calls modules with dev-specific values
    ├── staging/
    │   └── main.tf             ← calls modules with staging-specific values
    └── production/
        └── main.tf             ← calls modules with production-specific values
```

**Each `environments/<env>/` directory is a separate Terraform workspace with:**
- Its own `backend "s3"` (separate state file, separate S3 bucket key)
- Its own AWS provider configuration (points to the correct AWS account)
- Its own set of variable values passed to modules
- Completely isolated from other environments — `terraform apply` in dev cannot affect staging

---

## The Module Call: Every Part Explained

```hcl
# From terraform/environments/production/main.tf

module "dynatrace" {
  source = "../../modules/dynatrace"
  # ─── source tells Terraform WHERE the module is ─────────────────────────────
  # Relative path: ./environments/production/../../modules/dynatrace
  #              = ./modules/dynatrace
  #
  # After terraform init: Terraform copies this to .terraform/modules/dynatrace
  # and uses that copy during plan/apply (not the original path)
  #
  # Alternative sources:
  #   Git: "git::https://github.com/company/tf-modules.git//dynatrace?ref=v2.1.0"
  #        (pinned to a specific git tag — best practice for shared teams)
  #   Registry: "hashicorp/eks/aws" (from Terraform Registry)
  #   Local: "../../modules/dynatrace" (what this project uses)

  environment = "production"
  # ─── maps to: variable "environment" in variables.tf ────────────────────────
  # Used inside the module as: var.environment
  # The module uses this to:
  #   - Name all resources: "${each.value}-${var.environment}"
  #   - Conditionally create resources: var.environment == "production" ? ... : toset([])
  #   - Tag all resources with the environment label

  dt_env_url   = data.aws_secretsmanager_secret_version.dt_tenant_url.secret_string
  dt_api_token = data.aws_secretsmanager_secret_version.dt_api_token.secret_string
  # ─── secrets from Secrets Manager, NOT from .tfvars or env vars ─────────────
  # The data source reads the secret VALUE at plan time.
  # .secret_string is the attribute that holds the actual secret text.
  # Passed to the Dynatrace provider inside the module:
  #   provider "dynatrace" {
  #     dt_env_url   = var.dt_env_url
  #     dt_api_token = var.dt_api_token
  #   }

  pagerduty_integration_keys = jsondecode(
    data.aws_secretsmanager_secret_version.pagerduty_keys.secret_string
  )
  # ─── JSON string → Terraform map ─────────────────────────────────────────────
  # The secret contains: '{"payments":"pd-key-abc","orders":"pd-key-def","notifications":"pd-key-ghi"}'
  # jsondecode converts it to: { "payments" = "pd-key-abc", "orders" = "pd-key-def", ... }
  # The module uses: for_each = var.pagerduty_integration_keys
  # Result: one PagerDuty notification per team key in the map
  #
  # In dev: pagerduty_integration_keys = {} (empty map → 0 PD resources)
  # In production: pagerduty_integration_keys = {3 teams → 3 PD resources}

  synthetic_locations = [
    "GEOLOCATION-6F55B7E4B5E7A52F",   # Tokyo
    "GEOLOCATION-D15FBAABA11A2D7D",   # Singapore
  ]
  # ─── list of Dynatrace synthetic probe locations ──────────────────────────────
  # Dev only uses Tokyo (1 location) → cheaper, faster
  # Production uses Tokyo + Singapore (2 locations) → validates from multiple regions

  services = {
    "payment-service" = {
      team             = "payments"
      slo_target       = 99.9
      health_check_url = "https://payment.company.com/actuator/health"
      traffic_min_rps  = 10
      error_rate_alert = 0.1
      latency_p99_ms   = 300
      cpu_saturation_pct = 70
      memory_usage_pct   = 75
      jvm_heap_pct       = 70
      pod_restart_threshold  = 2
      network_error_rate_pct = 0.5
    }
    "order-service" = { ... }
    "notification-service" = { ... }
  }
  # ─── the complete threshold configuration for this environment ────────────────
  # This map drives EVERYTHING in the module:
  #   for_each = var.services → creates alerts for each service
  #   each.value.error_rate_alert → threshold for that service's error rate alert
  #   each.value.team → which management zone to attach the alert to
  #
  # Adding a new service = adding one entry to this map
  # terraform apply: module creates all 24+ resources for the new service automatically
}
```

---

## Module Outputs: How Modules Share Data

```hcl
# modules/eks/main.tf
output "cluster_name" {
  value = module.eks.cluster_name
  # Exposes the EKS cluster name to the calling environment
}

output "cluster_oidc_issuer_url" {
  value       = module.eks.cluster_oidc_issuer_url
  description = "OIDC provider URL for IRSA role trust policies"
  # Sensitive? No — this is a public URL, not a secret
}

output "cluster_ca_certificate" {
  value     = module.eks.cluster_certificate_authority_data
  sensitive = true   # Certificate data, treat as sensitive
}
```

**Using outputs to wire modules together:**

```hcl
# environments/dev/main.tf

module "vpc" {
  source = "../../modules/vpc"
  ...
}

module "eks" {
  source     = "../../modules/eks"
  vpc_id     = module.vpc.vpc_id          # ← output from VPC module
  subnet_ids = module.vpc.private_subnet_ids  # ← output from VPC module
  ...
}

# Create an IRSA role that trusts the EKS cluster's OIDC provider
resource "aws_iam_role" "eso" {
  name = "company-dev-eso"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = {
        Federated = "arn:aws:iam::${local.account_id}:oidc-provider/${
          replace(module.eks.cluster_oidc_issuer_url, "https://", "")
        }"
      }
      # ↑ Uses the OIDC URL output from the EKS module
      # replace() strips "https://" from the URL
      # "https://oidc.eks.ap-northeast-1.amazonaws.com/id/XXXX"
      # → "oidc.eks.ap-northeast-1.amazonaws.com/id/XXXX"
      Action    = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "${replace(module.eks.cluster_oidc_issuer_url, "https://", "")}:sub" =
            "system:serviceaccount:external-secrets:external-secrets"
        }
      }
    }]
  })
}
# This IAM role can only be assumed by the specific Kubernetes ServiceAccount
# "external-secrets" in namespace "external-secrets" in the EKS cluster.
# Without the module output, this role's trust policy would need a hardcoded URL.
```

---

## Module Versioning for Production Safety

The project uses local relative paths (`../../modules/dynatrace`). For larger teams, versioned module references are safer:

```hcl
# Local path (current project): always uses the LATEST local code
module "dynatrace" {
  source = "../../modules/dynatrace"
  # If someone commits a breaking change to the module,
  # ALL environments get it on next init+apply
}

# Git reference (for shared teams): pinned to a specific version
module "dynatrace" {
  source = "git::https://github.com/company/tf-modules.git//dynatrace?ref=v2.1.0"
  # ref=v2.1.0 = a git tag
  # ONLY gets updated when you explicitly change the ref
  # Other environments can be on v2.0.0 while you test v2.1.0 in dev
}
```

**Version bump workflow for shared modules:**
```
1. Develop change in modules repo: git tag v2.2.0
2. Test in dev:    source = "...?ref=v2.2.0" → terraform apply
3. Test in staging: same change → terraform apply
4. Roll to production: same change → PR → approval → apply
```

---

## Module Isolation: Provider Configurations

A subtle but important detail: the Dynatrace module has its OWN provider configuration:

```hcl
# modules/dynatrace/main.tf
terraform {
  required_providers {
    dynatrace = {
      source  = "dynatrace-oss/dynatrace"
      version = "~> 1.55"
    }
  }
}

provider "dynatrace" {
  dt_env_url   = var.dt_env_url
  dt_api_token = var.dt_api_token
}
```

This means the Dynatrace provider is configured WITH THE CREDENTIALS PASSED FROM THE ENVIRONMENT — not from a global provider config.

```
environments/dev/main.tf → passes dev DT credentials → module uses dev DT tenant
environments/production/main.tf → passes prod DT credentials → module uses prod DT tenant
```

If the module used a provider from the CALLING environment (via `providers = { dynatrace = dynatrace.dt }`), you'd need separate provider configurations for each environment in the calling file. The module-scoped provider approach keeps it simpler: credentials come in through variables, the provider is configured inside.

**The dependency chain when a module has a provider:**
```
terraform init:
  Downloads dynatrace provider from the module's required_providers
  Combines with the environment's required_providers
  Result: both aws and dynatrace providers available

terraform apply:
  AWS resources: use the aws provider from environments/dev/main.tf
  DT resources:  use the dynatrace provider from modules/dynatrace/main.tf
                 (configured with var.dt_env_url from Secrets Manager)
```
