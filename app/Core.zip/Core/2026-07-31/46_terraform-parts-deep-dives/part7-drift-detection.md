# Part 7 — Drift Detection Deep Dive

> Drift is the gap between what Terraform says exists and what actually exists in AWS. Left undetected, drift silently grows until a terraform apply produces unexpected changes. This project detects drift daily and auto-creates GitHub Issues.

---

## What Drift Is and Why It Happens

```
Drift = Real AWS state ≠ Terraform state file

Real world at 09:00:
  EKS cluster version: 1.30  (what Terraform set)

Real world at 14:00:
  EKS cluster version: 1.29  (someone rolled it back via AWS console)

Terraform state at 14:00:
  Still says: version = 1.30  (hasn't refreshed since 09:00)

terraform plan -refresh-only at 14:00:
  → Read from AWS: version = 1.29
  → Compare to state: 1.30
  → DRIFT: cluster was changed from 1.30 to 1.29 outside Terraform
```

**Six ways drift happens:**

```
1. MANUAL CONSOLE CHANGES
   Most common. Engineer "just quickly changes" an EKS node count.
   Fix: add the change to .tf and apply, OR apply Terraform to revert.

2. AWS AUTOMATED CHANGES
   AWS automatically updates EKS add-on versions.
   AWS rotates instance IDs during managed node group updates.
   These are "expected drift" — update .tf to reflect the change.

3. FAILED PARTIAL APPLY
   Apply runs, creates 40/50 resources, fails on resource 41.
   State has resources 1-40. Resources 41-50 don't exist.
   Drift: state says resources 1-40 exist; they do. Resources 41-50 differ.
   Fix: re-apply to complete the remaining resources.

4. ANOTHER TEAM'S TERRAFORM
   Another team's Terraform manages overlapping resources.
   Their apply changes a shared security group.
   Your Terraform now sees drift on that security group.
   Fix: clarify ownership, use separate state files.

5. EXTERNAL AUTOMATION
   A compliance tool automatically adds encryption to S3 buckets.
   Your Terraform manages those buckets.
   Now the buckets have different encryption settings than .tf specifies.
   Fix: update .tf to match the compliance tool's configuration.

6. RESOURCE REPLACEMENT
   An EC2 instance is terminated and a new one created (auto-healing).
   Terraform tracks by instance ID. New instance ID ≠ old instance ID.
   State shows old ID, AWS has new ID.
   Fix: terraform refresh to update state with new instance ID.
```

---

## The Drift Detection Pipeline (from `terraform-infra.yaml`)

```yaml
drift-detect:
  name: Drift Detection (${{ matrix.env.name }})
  if: github.event_name == 'schedule'
  # Only runs on schedule — NOT on PR or push
  # (drift detection is for monitoring, not blocking deployments)

  runs-on: ubuntu-latest
  permissions:
    id-token: write       # needed for OIDC → AWS auth
    contents: read
    issues: write         # needed to create GitHub Issues on drift

  strategy:
    fail-fast: false
    # CRITICAL: fail-fast: false means all three environments are checked
    # even if dev drift detection fails.
    # If fail-fast: true, a dev error would prevent staging/production from being checked.
    matrix:
      env:
        - name: dev
          account_id: "123456789010"
          working_dir: terraform/environments/dev
        - name: staging
          account_id: "123456789011"
          working_dir: terraform/environments/staging
        - name: production
          account_id: "123456789012"
          working_dir: terraform/environments/production

  steps:
    - uses: actions/checkout@v4

    - uses: hashicorp/setup-terraform@v3
      with: { terraform_version: "1.8.0" }

    - uses: aws-actions/configure-aws-credentials@v4
      with:
        role-to-assume: arn:aws:iam::${{ matrix.env.account_id }}:role/github-actions-infra-plan
        # Uses the READ-ONLY plan role, NOT the apply role
        # Even drift detection that auto-creates GitHub Issues doesn't need apply permissions
        aws-region: ap-northeast-1

    - name: Terraform Init
      working-directory: ${{ matrix.env.working_dir }}
      run: terraform init -no-color

    - name: Drift Detection
      id: drift
      working-directory: ${{ matrix.env.working_dir }}
      run: |
        set +e    # don't exit on non-zero exit code (exit 2 = drift = expected)
        terraform plan -refresh-only -detailed-exitcode -no-color 2>&1 | tee drift.txt
        EXIT_CODE=${PIPESTATUS[0]}
        # PIPESTATUS captures exit code of the FIRST command in the pipe
        # Without PIPESTATUS: $? would capture tee's exit code (always 0)
        echo "has_drift=$([ $EXIT_CODE -eq 2 ] && echo 'true' || echo 'false')" >> $GITHUB_OUTPUT
        # EXIT_CODE 0: no drift → has_drift=false
        # EXIT_CODE 2: drift found → has_drift=true
        # EXIT_CODE 1: terraform error (auth failure, API error) → has_drift=false but job fails

    - name: Create GitHub Issue on Drift
      if: steps.drift.outputs.has_drift == 'true'
      uses: actions/github-script@v7
      with:
        script: |
          const fs = require('fs');
          const drift = fs.readFileSync('${{ matrix.env.working_dir }}/drift.txt', 'utf8');
          const env = '${{ matrix.env.name }}';
          await github.rest.issues.create({
            owner: context.repo.owner,
            repo: context.repo.repo,
            title: `[DRIFT] Terraform infra drift detected in ${env} — ${new Date().toISOString().split('T')[0]}`,
            body: `## Infrastructure Drift — ${env.toUpperCase()}\n\n
                   Real AWS state differs from Terraform state. Review the drift output below.\n
                   **Actions:**\n
                   1. If the change was intentional: update .tf to match, commit, apply\n
                   2. If the change was accidental: terraform apply to revert\n
                   3. If from AWS automation: update .tf to track the new state\n\n
                   \`\`\`\n${drift.substring(0, 65000)}\n\`\`\``,
            labels: ['terraform-drift', 'infrastructure', env]
          });
```

---

## `-refresh-only` vs Regular Plan: The Critical Difference

```bash
# Regular terraform plan:
# Q: "Given my .tf files AND current AWS state, what changes are needed?"
# Includes BOTH: config drifts AND .tf code changes

terraform plan
# Shows ALL pending changes:
#   ~ eks version "1.30" → "1.29"   (drift — AWS changed it)
#   + new_service alert              (config change — you added to .tf)
# You can't tell which is drift and which is intentional

# terraform plan -refresh-only:
# Q: "What changed in AWS that Terraform doesn't know about?"
# ONLY shows: things that changed in AWS since last terraform apply
# Does NOT show: changes pending in .tf files

terraform plan -refresh-only
# Shows ONLY drift:
#   ~ eks version "1.30" → "1.29"   (drift — AWS changed it)
# Does NOT show the new_service alert (that's a config change, not drift)
# Pure drift signal.
```

**The `-refresh-only` output format:**

```
Note: Objects have changed outside of Terraform

Terraform detected the following changes made outside of Terraform since the
last "terraform apply" which may have affected this plan:

  # module.eks.module.eks.aws_eks_cluster.this has changed
  ~ resource "aws_eks_cluster" "this" {
        id      = "company-production"
      ~ version = "1.30" -> "1.29"   ← changed in AWS, not in .tf
    }

  # module.dynatrace.dynatrace_slo_v2.availability["payment-service"] has changed
  ~ resource "dynatrace_slo_v2" "availability" {
        id             = "abc123-uuid"
      ~ target_success = 99.9 -> 95.0   ← changed in DT UI, not in .tf
    }

Unless you have made equivalent changes to your configuration,
or ignored the relevant attributes using ignore_changes, 
the following plan may include actions to undo or respond to these changes.

Plan: 0 to add, 2 to change, 0 to destroy.
```

**What `exit 2` means in the script:**
```bash
terraform plan -refresh-only -detailed-exitcode
echo $?
# 0: refresh completed successfully, NO drift found → all clear
# 1: refresh failed (Terraform error, API auth failure, etc.) → broken, alert
# 2: refresh completed successfully, DRIFT FOUND → create GitHub Issue

# In CI:
EXIT_CODE=${PIPESTATUS[0]}
# WHY PIPESTATUS and not $?:
#   terraform plan ... | tee drift.txt
#   $? captures tee's exit code (tee always exits 0 unless write fails)
#   ${PIPESTATUS[0]} captures terraform plan's exit code
# Without PIPESTATUS: exit code 2 (drift) would appear as exit code 0 → drift missed
```

---

## The Three Drift Response Options

### Option 1: Accept the Change → Update `.tf`

```
Scenario: AWS automatically upgraded the EKS add-on coredns from v1.10 to v1.11
          Drift: terraform says v1.10, AWS has v1.11

The upgrade is fine. We want Terraform to track v1.11.

Action: Update .tf to match:
  cluster_addons = {
    coredns = { most_recent = true }  # was pinned to "1.10-eksbuild.1", now use most_recent
  }

Then: terraform apply
  Plan: no changes (state is refreshed to v1.11, .tf says most_recent → matches)
  
After apply: next drift check shows 0 changes.
Result: Terraform tracks the current state, drift is resolved.
```

### Option 2: Revert the Manual Change → Apply Terraform

```
Scenario: someone increased EKS node count from 3 to 5 in AWS console
          Drift: state says 3, AWS has 5

The change was not approved. Revert to 3.

Action: terraform apply (no .tf changes)
  terraform plan:
    ~ aws_eks_node_group.system {
        ~ desired_size = 5 -> 3   ← reverts to what .tf says
      }
  terraform apply → node group scales back to 3

After apply: drift is resolved, AWS matches .tf.
Result: manual change is reverted, infrastructure-as-code is enforced.
```

### Option 3: Acknowledge and Document → `ignore_changes`

```
Scenario: AWS keeps automatically rotating the RDS master password
          Drift: terraform tracks a hash that AWS changes on rotation

The rotation is INTENDED (security policy). We want Terraform to stop flagging it.

Action: Add lifecycle ignore_changes:
  resource "aws_rds_cluster" "main" {
    ...
    lifecycle {
      ignore_changes = [master_password]
      # Terraform will no longer track changes to this field
      # Drift detector won't flag password rotations
    }
  }

After apply: terraform plan -refresh-only shows 0 drift for this resource.
Result: drift detector only reports UNEXPECTED changes.
```

---

## Drift Detection Frequency and the 02:00 JST Schedule

```yaml
schedule:
  - cron: '0 17 * * *'   # 17:00 UTC = 02:00 JST
```

**Why 02:00 JST (off-peak hours):**
- Fewest deployments happening at this time → drift report reflects stable state
- Engineers are sleeping → alert sits in GitHub Issues overnight
- Morning standup: team reviews drift issues at start of day
- Gives 8 hours before Tokyo business hours to notice the issue without paging anyone

**If you need real-time drift detection:**
```yaml
# More frequent schedule:
schedule:
  - cron: '0 * * * *'   # every hour

# Or: event-driven (run after any manual AWS console change)
# Not easily implementable in standard GitHub Actions
# Would require CloudTrail → EventBridge → GitHub API webhook chain
```

**GitHub Issue labeling for prioritization:**
```javascript
labels: ['terraform-drift', 'infrastructure', env]
// 'terraform-drift': searchable across all repos
// 'infrastructure': platform team's queue
// env: 'dev', 'staging', 'production' (for priority sorting)
// Production drift → investigated before dev drift
```
