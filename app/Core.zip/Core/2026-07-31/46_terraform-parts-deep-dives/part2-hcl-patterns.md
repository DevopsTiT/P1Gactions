# Part 2 — HCL Language Patterns Deep Dive

> HCL is the language of Terraform. Mastering four block types and three expression patterns covers 95% of what SREs write day-to-day. Everything is grounded in the real project files.

---

## The Four Block Types and When to Use Each

### Block Type 1: `resource` — Create and Manage

```hcl
resource "PROVIDER_TYPE" "LOCAL_NAME" {
  field = value
}
```

A `resource` block tells Terraform: "this object should exist, and I own it."

```hcl
# From terraform/modules/dynatrace/main.tf
resource "dynatrace_management_zone_v2" "team" {
  for_each    = local.teams
  name        = "${each.value}-${var.environment}"
  description = "Auto-generated zone for team '${each.value}' in ${var.environment}."
  ...
}
```

**What "I own it" means:**
- `terraform plan` checks this resource against AWS/DT state
- `terraform apply` creates it if missing, updates it if different
- If you DELETE this block from your `.tf` file: `terraform apply` DESTROYS the resource
- If someone changes the resource outside Terraform: `terraform apply` REVERTS it

**Two-part identifier:** `dynatrace_management_zone_v2.team`
- `dynatrace_management_zone_v2` = the resource type (defined by the provider)
- `team` = local name (arbitrary, used to reference it in other blocks)
- With `for_each`: `dynatrace_management_zone_v2.team["payments"]`

---

### Block Type 2: `data` — Read Without Managing

```hcl
data "PROVIDER_TYPE" "LOCAL_NAME" {
  lookup_field = value
}
```

A `data` block reads an existing object. Terraform does NOT manage it — it won't create, update, or destroy it.

```hcl
# From terraform/environments/production/main.tf
data "aws_secretsmanager_secret_version" "dt_api_token" {
  secret_id = "production/dynatrace/api-token"
}
```

**Critical difference from `resource`:**

| Behavior | `resource` | `data` |
|----------|-----------|--------|
| Creates the object | ✅ yes | ❌ no |
| Destroys if removed from .tf | ✅ yes | ❌ no |
| Fails if object doesn't exist | ❌ no (creates it) | ✅ yes (plan fails) |
| Plan time failure | ❌ only at apply | ✅ at plan time |

**`data` source fails at plan time, not apply time:**
```bash
# The secret "production/dynatrace/api-token" doesn't exist yet
terraform plan
# Error: error reading Secrets Manager Secret Version: ResourceNotFoundException:
# Secrets Manager can't find the specified secret.
# on environments/production/main.tf line 25, in data "aws_secretsmanager_secret_version"

# This is intentional — catches missing prerequisites BEFORE making any changes
```

**Referenced as:** `data.aws_secretsmanager_secret_version.dt_api_token.secret_string`

---

### Block Type 3: `locals` — Computed Values

```hcl
locals {
  name1 = expression1
  name2 = expression2
}
```

`locals` computes values once and makes them available as `local.name`. Reduces repetition and ensures consistency.

```hcl
# From terraform/modules/dynatrace/main.tf
locals {
  teams = toset([for svc in values(var.services) : svc.team])

  services_with_traffic = {
    for name, svc in var.services : name => svc
    if svc.traffic_min_rps > 0
  }
}
```

**Why use locals instead of repeating the expression:**

```hcl
# WITHOUT locals — bad:
resource "dynatrace_alerting" "critical" {
  for_each = toset([for svc in values(var.services) : svc.team])
  ...
}
resource "dynatrace_alerting" "high" {
  for_each = toset([for svc in values(var.services) : svc.team])
  # Same expression duplicated — if the logic changes, must update everywhere
}

# WITH locals — good:
locals {
  teams = toset([for svc in values(var.services) : svc.team])
}
resource "dynatrace_alerting" "critical" {
  for_each = local.teams   # single source of truth
}
resource "dynatrace_alerting" "high" {
  for_each = local.teams   # same reference
}
# Change the teams logic once → all resources update
```

**locals are evaluated lazily** — if a local is never referenced, it's never computed. No performance penalty for defining locals you don't use in all code paths.

---

### Block Type 4: `variable` — Module Inputs

```hcl
variable "NAME" {
  type        = TYPE
  description = "..."
  default     = DEFAULT_VALUE  # optional — if omitted, caller must provide
  sensitive   = true/false
  validation {
    condition     = BOOL_EXPRESSION
    error_message = "..."
  }
}
```

Variables are the PUBLIC API of a module — the knobs callers turn to customize behavior.

```hcl
# From terraform/modules/dynatrace/variables.tf
variable "environment" {
  type        = string
  description = "dev | staging | production"
  # No default: caller MUST provide this
  validation {
    condition     = contains(["dev", "staging", "production"], var.environment)
    error_message = "environment must be dev, staging, or production"
  }
}

variable "services" {
  type = map(object({
    team             = string
    slo_target       = number
    error_rate_alert = number
    latency_p99_ms   = number
    ...
  }))
  # Typed object constraint: every entry in the map must have ALL these fields
  # with the correct types. Terraform validates this at plan time.
}
```

**Variable validation fires at plan time:**
```bash
# Caller passes: environment = "production"
terraform plan  # ✅ validation passes

# Caller passes: environment = "prod" (typo)
terraform plan
# Error: Invalid value for variable
#   on environments/dev/main.tf line 39, in module "dynatrace":
#   39:   environment = "prod"
#     ├────────────────
#     │ var.environment is "prod"
# environment must be dev, staging, or production
```

This catches mistakes BEFORE Terraform makes any API calls — much faster feedback than waiting for a deploy to fail.

**Typed objects in variables:**
```hcl
# The services map enforces structure at the type level
variable "services" {
  type = map(object({
    team             = string    # must be a string
    slo_target       = number    # must be a number (not "99.9" as string)
    latency_p99_ms   = number    # must be a number
  }))
}

# If caller passes:
services = {
  "payment-service" = {
    team         = "payments"
    slo_target   = "99.9"   # string, not number → TYPE ERROR at plan
    latency_p99_ms = 300
  }
}
# Error: Invalid value for input variable
# The given value is not suitable for var.services["payment-service"].slo_target:
# a number is required.
```

---

## The Three Critical Expression Patterns

### Pattern 1: `for_each` — Create N Resources from a Map

```hcl
resource "RESOURCE_TYPE" "NAME" {
  for_each = MAP_OR_SET

  # Inside: use each.key and each.value
}
```

**The fundamental choice: `for_each` vs `count`**

```hcl
# ── count: index-based (FRAGILE) ──────────────────────────────────────────────
resource "dynatrace_alerting" "profile" {
  count = length(local.teams_list)
  name  = local.teams_list[count.index]
}
# Creates: profile[0], profile[1], profile[2]

# If "orders" (index 1) is removed from the list:
#   Before: [0]="notifications", [1]="orders", [2]="payments"
#   After:  [0]="notifications", [1]="payments"
#   Terraform diff:
#     ~ profile[1]: name = "orders" → "payments"   (MODIFY, not destroy orders)
#     - profile[2]: name = "payments"               (DESTROY payments)
#   RESULT: orders alert is changed to "payments", real payments alert DESTROYED

# ── for_each: key-based (SAFE) ────────────────────────────────────────────────
resource "dynatrace_alerting" "profile" {
  for_each = local.teams  # {"notifications", "orders", "payments"}
  name     = each.value
}
# Creates: profile["notifications"], profile["orders"], profile["payments"]

# If "orders" is removed from the set:
#   Terraform diff:
#     - profile["orders"]: DESTROYED (only this one)
#   profile["notifications"] and profile["payments"]: UNTOUCHED
#   RESULT: only orders is destroyed — correct behavior
```

**When to use count (legitimate use cases):**
```hcl
# count is safe for resources that form a fixed-size group
# where order/identity doesn't matter individually:
resource "aws_nat_gateway" "main" {
  count  = length(var.azs)   # one NAT per AZ
  subnet_id = aws_subnet.public[count.index].id
  # If you remove one AZ, you want the last NAT to be destroyed
  # and the remaining ones to be unchanged — which is what count does
}

# But even here, for_each is often safer:
resource "aws_nat_gateway" "main" {
  for_each  = toset(var.azs)
  subnet_id = aws_subnet.public[each.value].id
}
```

**`for_each` with different collection types:**
```hcl
# With a map (most common):
for_each = { "az-a" = "10.0.0.0/20", "az-b" = "10.0.16.0/20" }
# each.key = "az-a", each.value = "10.0.0.0/20"

# With a set of strings (from toset()):
for_each = toset(["payments", "orders", "notifications"])
# each.key = each.value = "payments" (key and value are the same for sets)

# With a filtered map:
for_each = { for k, v in var.services : k => v if v.slo_target > 95 }
# Only creates resources for services with slo_target > 95
```

---

### Pattern 2: `for` expressions — Transform Collections

The `for` expression is HCL's equivalent of Python's list/dict comprehensions.

```hcl
# List comprehension (result is a list):
[for ITEM in SOURCE : EXPRESSION]
[for ITEM in SOURCE : EXPRESSION if CONDITION]

# Map comprehension (result is a map):
{ for KEY, VALUE in SOURCE : NEW_KEY => NEW_VALUE }
{ for KEY, VALUE in SOURCE : NEW_KEY => NEW_VALUE if CONDITION }
```

**Real examples from the project:**

```hcl
# Extract all team names from the services map
# Source: { "payment-service" = { team="payments", ... }, "order-service" = { team="orders", ... } }
locals {
  teams = toset([for svc in values(var.services) : svc.team])
  # values() extracts just the values: [{ team="payments",...}, { team="orders",...}, ...]
  # [for svc in ... : svc.team] maps each value to just the team field: ["payments", "orders", "notifications"]
  # toset() removes duplicates and creates a set: {"notifications", "orders", "payments"}
}

# Filter map: only services with traffic alerts
locals {
  services_with_traffic = {
    for name, svc in var.services : name => svc
    if svc.traffic_min_rps > 0
    # In dev: traffic_min_rps = 0 for ALL services → empty map
    # In production: traffic_min_rps > 0 for all → full map
  }
}

# Transform: compute CIDR blocks for subnets
locals {
  private_subnets = [
    for i, az in var.azs :
    cidrsubnet(var.vpc_cidr, 4, i + 16)
    # i=0: cidrsubnet("10.0.0.0/16", 4, 16) = "10.0.0.0/20"
    # i=1: cidrsubnet("10.0.0.0/16", 4, 17) = "10.0.16.0/20"
    # i=2: cidrsubnet("10.0.0.0/16", 4, 18) = "10.0.32.0/20"
  ]
}

# Invert a map (swap keys and values):
locals {
  service_by_team = {
    for name, svc in var.services : svc.team => name
    # { "payments" = "payment-service", "orders" = "order-service", ... }
  }
}
```

**Common `for` expression mistakes:**

```hcl
# MISTAKE: for expression produces duplicate keys → error
{ for svc in var.services : svc.team => svc.name }
# If two services have the same team, HCL raises:
# "Two items produced the same key"
# FIX: use groupingkeys()or ensure uniqueness before the for expression

# MISTAKE: confusing for expression (in locals) with for_each (in resources)
locals {
  team_list = [for svc in var.services : svc.team]
  # team_list is a LOCAL VALUE (just a list)
}
resource "dynatrace_alerting" "critical" {
  for_each = local.team_list   # ERROR: for_each needs a MAP or SET, not a list
  # FIX: for_each = toset(local.team_list)
}
```

---

### Pattern 3: Conditional `for_each` — Resource On/Off Switch

```hcl
# Pattern: create resource ONLY in specific environments
resource "RESOURCE_TYPE" "NAME" {
  for_each = CONDITION ? FULL_COLLECTION : toset([])
  # toset([]) = empty set = 0 resources created
}
```

```hcl
# From terraform/modules/dynatrace/main.tf:

# CRITICAL alerts: production ONLY
resource "dynatrace_alerting" "critical" {
  for_each = var.environment == "production" ? local.teams : toset([])
  name     = "${each.value}-${var.environment}-critical"
  ...
}
# dev apply:         for_each = toset([]) → creates 0 resources
# staging apply:     for_each = toset([]) → creates 0 resources
# production apply:  for_each = local.teams → creates 3 resources

# HIGH alerts: staging AND production
resource "dynatrace_alerting" "high" {
  for_each = contains(["production", "staging"], var.environment) ? local.teams : toset([])
  # contains() checks membership in a list
}
# dev:         for_each = toset([]) → 0
# staging:     for_each = local.teams → 3
# production:  for_each = local.teams → 3
```

**Why `toset([])` not `{}` (empty map):**
```hcl
# Both work — toset([]) is a set, {} is a map
# Convention: use toset([]) when the source is a set
#             use {} when the source is a map
# Consistency: if your collection is a set, the empty version is toset([])
```

**Alternative: using `count = 0` for single resources:**
```hcl
# For non-for_each resources, use count:
resource "dynatrace_pagerduty_notification" "critical" {
  count            = var.environment == "production" ? 1 : 0
  alerting_profile = dynatrace_alerting.critical["payments"].id
  ...
}
# References: dynatrace_pagerduty_notification.critical[0] (or just critical if count=1)
```

---

## The `sensitive = true` Pattern

### What it does and what it doesn't do:

```hcl
variable "dt_api_token" {
  type      = string
  sensitive = true
}

# WHAT IT DOES:
# 1. Redacts the value in terraform plan output:
#    + dt_api_token = (sensitive value)   ← not shown in logs
# 2. Redacts in terraform output:
#    dt_api_token = (sensitive value)
# 3. Prevents the value from appearing in error messages

# WHAT IT DOES NOT DO:
# 1. Does NOT encrypt the value in terraform.tfstate
#    The state file contains: "dt_api_token": "dt0c01.ACTUAL_TOKEN"
#    In PLAINTEXT JSON
# 2. Does NOT prevent the value from being used in resources
#    (it just won't be logged)
```

**The state file protection chain:**
```
sensitive = true → redacts from logs (prevents accidental exposure)
                     ↓ but state file still has it in plaintext
S3 bucket encryption (encrypt = true in backend) → encrypts at rest
                     ↓ but IAM controls who can decrypt
IAM bucket policy → restricts access to terraform execution roles only
                     ↓ but still accessible to anyone with that role
AWS CloudTrail → logs every S3:GetObject for audit trail
```

**Propagation: sensitive values mark downstream resources:**
```hcl
resource "some_resource" "example" {
  token = var.dt_api_token  # sensitive variable used here
  name  = "not-sensitive"
}

# terraform plan output:
# ~ some_resource.example {
#     + token = (sensitive value)  ← marked sensitive (from var)
#     + name  = "not-sensitive"    ← not sensitive
#   }
```

---

## HCL Built-in Functions Reference for SREs

```hcl
# Type conversion
toset(list)                    # list → set (removes duplicates, unordered)
tolist(set)                    # set → list (deterministic ordering)
tomap(object)                  # object → map
tonumber("300")                # string → number: 300
tostring(300)                  # number → string: "300"

# String manipulation
upper("production")            # "PRODUCTION"
lower("PRODUCTION")            # "production"
replace("https://X/api", "X", var.tenant)  # string substitution
format("[%s] alert", upper(var.env))       # "[PRODUCTION] alert"
trimspace("  hello  ")         # "hello"
split(",", "a,b,c")            # ["a", "b", "c"]
join("-", ["a", "b", "c"])     # "a-b-c"

# Collection manipulation
length(var.services)           # count of items
keys(var.services)             # ["notification-service", "order-service", "payment-service"]
values(var.services)           # [{ team="notifications",... }, ...]
contains(["dev","prod"], var.environment)  # true/false
lookup(var.map, "key", "default")          # safe map access with default
merge(map1, map2)              # combine two maps (map2 wins on conflicts)
flatten([["a","b"],["c"]])     # ["a", "b", "c"] - flatten nested lists

# Math
min(var.latency_ms, 1000)      # minimum of values
max(var.replicas, 3)           # maximum of values
floor(var.float_val)           # round down to integer
ceil(var.float_val)            # round up to integer

# CIDR calculations
cidrsubnet("10.0.0.0/16", 4, 0)   # "10.0.0.0/20" (first /20 subnet)
cidrhost("10.0.0.0/20", 5)        # "10.0.0.5" (5th IP in range)

# Encoding
jsonencode({ key = "value" })    # {"key":"value"}
jsondecode('{"key":"value"}')    # { key = "value" }
base64encode("hello")            # "aGVsbG8="
base64decode("aGVsbG8=")         # "hello"

# Filesystem (use carefully — binds config to specific machine)
file("path/to/file.pem")         # reads file content as string
```
