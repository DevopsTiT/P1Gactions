# Terraform Parts Deep Dives — Glossary for SRE Beginners

Every term used across all 11 part files.

---

**Reconciliation engine**
A system that continuously compares desired state (what you declared) to current state (what exists) and makes the minimum changes to align them. Terraform's core model — run `apply` 10 times on an already-correct environment and it does nothing each time.

**Desired state**
The configuration you write in `.tf` files. "I want an EKS cluster named company-dev running v1.30." Terraform's job is to make AWS match this exactly.

**Current state**
What actually exists in AWS right now, retrieved by calling the AWS API during `terraform plan`. May differ from both desired state (drift) and the state file (partial failure, manual changes).

**State file (`terraform.tfstate`)**
A JSON file mapping every `.tf` resource address to its real-world ID (ARN, UUID, etc.) and all its attributes. Terraform's memory. Without it, every apply would try to create everything from scratch.

**S3 backend**
Storing `terraform.tfstate` in an S3 bucket instead of on disk. Makes state accessible to all team members and CI/CD systems. Configured in `backend "s3" {}`. Must have encryption enabled (state contains sensitive values in plaintext).

**DynamoDB lock table**
A DynamoDB table where Terraform writes a lock record when an apply starts. Prevents two simultaneous applies from corrupting the state file. The `terraform-state-lock` table in this project.

**Lock record**
An item in the DynamoDB lock table containing: who holds the lock, when it was acquired, which state file it protects. Created at apply start, deleted at apply end. If Terraform crashes: the lock stays permanently until manually released.

**`terraform init`**
Downloads provider plugins, configures the S3 backend, and copies module sources. Must run before any other command, and again when providers/modules/backend change.

**Provider**
A plugin that knows how to communicate with a specific API. `hashicorp/aws` speaks EC2, EKS, S3 APIs. `dynatrace-oss/dynatrace` speaks Dynatrace API. Downloaded during `terraform init`, cached in `.terraform/providers/`.

**`.terraform.lock.hcl`**
A lockfile recording exact provider versions and SHA256 hashes. Must be committed to git. Ensures every `terraform init` downloads the same provider binary on every machine.

**`required_providers` block**
Declares which providers a configuration needs and their version constraints. `version = "~> 5.50"` allows 5.50.x and 5.51.x, blocks 6.x. Without a constraint: any version including breaking major versions.

**Version constraint (`~>`, `=`, `>=`)**
Rules for acceptable provider versions. `~> 5.50` (tilde-arrow) = allow minor updates, block major versions. `= 5.50.0` = exact, safest. `>= 5.50` = any version above. The tilde-arrow is the standard recommendation.

**`terraform validate`**
Checks `.tf` files for syntax errors and invalid references without calling any AWS APIs. Fast (~1 second). Run first in CI before the slower plan. Does NOT check if AWS resources can actually be created.

**`terraform fmt`**
Formats `.tf` files to canonical HCL style. `terraform fmt -check` exits non-zero if files are unformatted (use in CI). `terraform fmt -recursive` rewrites files in place (use locally).

**`terraform plan`**
Reads `.tf` files, compares to state and real AWS, outputs a human-readable diff. Changes nothing. Should always be reviewed before applying. The most important safety check.

**`-out=plan.tfplan`**
Saves the exact plan to a binary file. `terraform apply plan.tfplan` then applies exactly what was saved, preventing surprise changes if code was edited between plan and apply.

**`-refresh=false`**
Skips the AWS API call for each resource during plan. Faster plans at the cost of not detecting manual changes in AWS. Safe when you know state is current (e.g., right after an apply).

**`-refresh-only`**
Plans ONLY drift detection — shows what changed in AWS that Terraform doesn't know about. Does NOT show pending code changes. Used for daily drift checks.

**`-detailed-exitcode`**
Changes plan exit codes: 0 = no changes, 1 = error, 2 = changes exist. Essential for CI scripts that need to distinguish "nothing to do" from "found drift."

**`terraform apply`**
Executes changes shown in the plan. Acquires DynamoDB lock, calls AWS APIs to create/update/delete, writes state after each resource, releases lock. The command that makes real changes in AWS.

**`-auto-approve`**
Skips the interactive "Enter 'yes' to confirm" prompt. Required in CI (non-interactive). Never use interactively in production — removes the last safety check.

**`-parallelism=N`**
Sets concurrent resource operations. Default 10. Higher = faster but risks AWS API rate limiting. Lower = slower but safer for rate-limited accounts.

**`-lock-timeout=Xm`**
How long to wait for the DynamoDB lock before failing. Default: wait indefinitely. Set to a short value in CI to fail fast if another apply is running.

**`terraform destroy`**
Deletes all resources in the current workspace. Extremely dangerous without `-target`. Always run `terraform plan -destroy` first to review what would be deleted.

**`-target` flag**
Limits plan/apply/destroy to specific resources or modules. Legitimate for staged rollouts or emergency fixes. Dangerous when used routinely — hides pending changes and accumulates state debt.

**Resource block (`resource`)**
Declares that an infrastructure object should exist and be managed by Terraform. If removed from `.tf`, Terraform destroys the real resource on next apply.

**Data source block (`data`)**
Reads an existing object without managing it. Fails at PLAN time (not apply) if the object doesn't exist. Referenced as `data.TYPE.NAME.attribute`.

**Local block (`locals`)**
Computes values once and makes them available as `local.NAME`. Reduces repetition and ensures consistency across multiple resources that need the same computed value.

**Variable block (`variable`)**
Declares module inputs. Accessed as `var.NAME`. Can have type constraints, validation rules, defaults, and `sensitive = true`. Validation fires at plan time, before any resources are created.

**`for_each`**
Creates one resource instance per item in a map or set. Key-based addressing (`resource["key"]`) is stable — removing an item only affects that key, not other resources. The correct alternative to `count` for any collection where items can be removed from the middle.

**`count`**
Creates N copies of a resource, indexed as `resource[0]`, `resource[1]`. Fragile when items are removed from the middle (renumbers remaining items, causing unexpected destroys). Use only for truly fixed-size groups.

**`each.key` / `each.value`**
Built-in references inside a `for_each` block. `each.key` is the map key. `each.value` is the map value. Used to customise each resource instance.

**`for` expression**
HCL list/map comprehension. `[for x in source : transform(x)]` or `{ for k, v in source : new_key => new_value if condition }`. Used in `locals` to transform or filter collections.

**`toset()`**
Converts a list to a set (removes duplicates, unordered). Required when using a list with `for_each` (which needs a map or set, not a list).

**`contains()`**
Returns true if a list contains a value. `contains(["production", "staging"], var.environment)`. Used for conditional `for_each`: `contains(...) ? full_set : toset([])`.

**`jsondecode()`**
Converts a JSON string to a Terraform value. Used to read JSON-formatted secrets from Secrets Manager: `jsondecode(data.source.secret_string)` returns a Terraform map.

**`sensitive = true`**
Variable/output attribute that redacts the value in plan output and logs. Does NOT encrypt the value in the state file — the state file still has it in plaintext. State bucket encryption and IAM policies protect the actual values.

**Conditional `for_each`**
Pattern for optional resource creation: `for_each = condition ? full_set : toset([])`. An empty set creates zero resources. The standard way to make resources environment-specific.

**Module**
A reusable directory of `.tf` files called with different inputs. Separates logic (how to create things) from data (what values to use). One module called three times with different inputs creates consistent infrastructure across three environments.

**`source` (module)**
Where the module code lives. Can be a local relative path (`../../modules/dynatrace`), a git URL with a tag ref for versioning, or a Terraform Registry address.

**Module output**
A value exposed by a module to its caller. `output "cluster_oidc_issuer_url" { value = ... }`. Callers use `module.eks.cluster_oidc_issuer_url` to reference computed values without hardcoding.

**Dependency graph (DAG)**
A directed acyclic graph of all resources where edges represent dependencies (resource A must exist before resource B). Terraform builds this graph to determine execution order and which resources can be created in parallel.

**`forces replacement`**
A plan annotation meaning a field change requires destroying and recreating the resource (it's immutable after creation). Appears as `-/+` in the plan. Critical to notice — can cause downtime if the resource is in active use.

**`(known after apply)`**
A plan annotation for computed attributes that AWS only returns after creating the resource (e.g., an EKS endpoint URL). Cannot be known at plan time. Populated in state after apply completes.

**Drift**
The difference between real AWS state and Terraform's state file. Caused by: manual console changes, AWS automated updates, failed partial applies. Detected by `terraform plan -refresh-only`.

**`PIPESTATUS`**
A bash array containing the exit codes of each command in a pipeline. `cmd1 | cmd2` — `${PIPESTATUS[0]}` = cmd1's exit code, `${PIPESTATUS[1]}` = cmd2's exit code. Critical for capturing `terraform plan`'s exit code when piping through `tee`.

**`terraform state list`**
Lists all resource addresses currently tracked in the state file. Used to find exact addresses for other state commands, verify resources were created, and audit what Terraform manages.

**`terraform state show`**
Displays all attributes of one specific resource from state. Used to inspect last-applied values and find resource IDs.

**`terraform state mv`**
Renames a resource address in state without making real-world changes. Used when refactoring code (renaming resource blocks) to prevent Terraform from destroying and recreating the resource.

**`terraform state rm`**
Removes a resource from state without deleting the real resource. Used when transferring management to another Terraform workspace or tool. Must also remove from `.tf` files to prevent re-creation.

**`terraform import`**
Brings an existing real-world resource under Terraform management by adding it to state. The resource block must already exist in `.tf` before importing. After import, `terraform plan` shows any drift between the imported state and the `.tf` definition.

**`-replace` flag**
Forces Terraform to destroy and recreate a specific resource, even if configuration hasn't changed. Replaces the deprecated `terraform taint`. Used for: replacing unhealthy nodes, recreating stuck resources.

**`terraform force-unlock`**
Releases a DynamoDB lock that was not cleaned up (e.g., after a crash). Extremely dangerous if the locking process is still running — can cause state corruption. Always confirm the process is dead before using.

**`prevent_destroy`**
A lifecycle meta-argument that makes Terraform refuse to destroy a resource. `lifecycle { prevent_destroy = true }`. The resource block must have `prevent_destroy` removed before `terraform destroy` will succeed. Safety net for critical resources.

**`ignore_changes`**
A lifecycle meta-argument listing attributes Terraform should not track. `lifecycle { ignore_changes = [master_password] }` tells Terraform to ignore changes to that field — useful for attributes managed by external automation (e.g., AWS rotates the RDS password automatically).

**OIDC (OpenID Connect)**
An authentication mechanism letting GitHub Actions prove its identity to AWS without stored credentials. GitHub provides a short-lived JWT; AWS STS exchanges it for temporary credentials. Credentials expire when the job ends.

**Plan role vs Apply role**
Two IAM roles per environment. The plan role has read-only permissions (used on PRs — can't make changes). The apply role has full permissions (used on push to main — requires OIDC auth from the main branch only).

**`fail-fast: false`**
A GitHub Actions matrix strategy setting. Without it, if the dev plan fails, staging and production plans are cancelled. With `fail-fast: false`, all matrix jobs run even if one fails — the full picture of all pending changes across all environments is shown in one PR review cycle.

**Sequential apply (`needs:`)**
The `needs: apply-dev` dependency in CI ensures staging only applies after dev succeeds. Prevents a broken module change from simultaneously damaging all three environments.

**GitHub Environment (`environment: production`)**
A named deployment target in GitHub Actions. When a job has `environment: production`, it pauses and waits for approval from designated reviewers before running. The approval is logged with who approved and when. Protects production from automatic deploys.

**State serial**
A monotonically increasing integer in `terraform.tfstate`. Increments on every successful apply. Terraform uses it to detect concurrent writes — if two applies try to write with the same serial, the second fails, preventing state corruption.

**State lineage**
A UUID generated when a state file is first created. If you accidentally point two environments to the same state S3 key, the lineage mismatch prevents Terraform from merging two different environments' states.
