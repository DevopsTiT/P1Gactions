# Part 1 — Core Concepts: State, Plan, Apply Deep Dive

> The three concepts that everything else in Terraform builds on. Get these wrong and you either destroy production or can't understand why your changes aren't taking effect.

---

## The Reconciliation Engine Mental Model

Terraform is not an imperative script ("do this, then do that"). It is a **declarative reconciliation engine** — you describe the end state, Terraform figures out the steps.

```
You write:
  resource "aws_eks_cluster" "this" {
    name    = "company-dev"
    version = "1.30"
  }

Terraform asks three questions:
  Q1: Does this resource exist at all?         → read the state file
  Q2: What does it look like RIGHT NOW?         → call AWS DescribeCluster API
  Q3: What do I WANT it to look like?          → read the .tf file

  If Q1=no:                      → CREATE (the resource doesn't exist yet)
  If Q1=yes, Q2 matches Q3:      → NO CHANGE (already correct)
  If Q1=yes, Q2 differs from Q3: → UPDATE (drift from desired state)
  If Q1=yes but resource deleted from Q3: → DESTROY
```

This is fundamentally different from Ansible ("run these tasks") or shell scripts ("execute these commands"). Terraform always converges toward the desired state regardless of how many times you run it. Running `terraform apply` on an already-correct environment does nothing — and that's intentional.

---

## Deep Dive: The State File

### What the state file contains (abridged real structure):

```json
{
  "version": 4,
  "terraform_version": "1.8.0",
  "serial": 42,
  "lineage": "abc123-def456-...",
  "outputs": {},
  "resources": [
    {
      "module": "module.dynatrace",
      "mode": "managed",
      "type": "dynatrace_slo_v2",
      "name": "availability",
      "provider": "provider[\"registry.terraform.io/dynatrace-oss/dynatrace\"]",
      "instances": [
        {
          "index_key": "payment-service",
          "schema_version": 0,
          "attributes": {
            "id": "abc123-uuid-from-dynatrace",
            "name": "payment-service Availability [production]",
            "target_success": 99.9,
            "target_warning": 99.8,
            "evaluation_window": "-1M",
            "enabled": true
          },
          "sensitive_attributes": []
        }
      ]
    }
  ]
}
```

**Every field matters:**

| Field | Purpose |
|-------|---------|
| `serial` | Increments on every successful apply. If two applies try to write simultaneously, the second one sees a serial mismatch and fails — a secondary corruption guard |
| `lineage` | A UUID generated when the state was first created. If you accidentally point two environments to the same state key, the lineage mismatch prevents corruption |
| `id` | The real-world identifier (ARN, UUID, name) that lets Terraform call the right API to update/delete the resource |
| `attributes` | The complete last-known configuration. Used to compute diffs on the next plan |

### The state file is the source of truth for Terraform — not your `.tf` files

```
Scenario: You delete a resource block from your .tf file.
          The resource still exists in AWS.

Without state file awareness:
  "I deleted it from the code so it's gone"  ← WRONG

With state file awareness:
  terraform plan shows:
    - resource "aws_eks_cluster" "this" {  ← will be DESTROYED
        id = "company-dev"
      }
  Because: the resource is in state (Terraform manages it)
           but not in .tf (Terraform is told to stop managing it)
  → Terraform DESTROYS the cluster

This is why reviewing the plan output before every apply is critical.
A deleted resource block = a DESTROY operation.
```

### Why S3 for state (not local files):

```
Local state file problems:
  - Your laptop dies: state file gone → Terraform thinks nothing exists
    → Next apply: creates DUPLICATE resources (new cluster alongside existing one)
  - Colleague Alice applies from her machine: state updated on HER machine
    → You apply from your machine: state file is STALE (doesn't know about Alice's changes)
    → Terraform thinks it needs to create resources Alice already created
    → Duplicate resources in AWS

S3 + DynamoDB solution:
  - State lives in one authoritative location (S3)
  - Everyone reads the same state
  - DynamoDB lock prevents simultaneous writes
  - S3 versioning allows rollback if state gets corrupted
```

### S3 state bucket security requirements:

```hcl
# backend "s3" configuration
backend "s3" {
  bucket         = "company-terraform-state-dev"
  key            = "dev/terraform.tfstate"
  region         = "ap-northeast-1"
  encrypt        = true      # SSE-S3 or SSE-KMS encryption at rest
  dynamodb_table = "terraform-state-lock"
}
```

The bucket itself needs:
```
Block all public access: ✅ enabled
  (state file contains resource IDs, some internal details)

Server-side encryption: ✅ enabled
  (state file contains sensitive values marked sensitive = true in plaintext)

Versioning: ✅ enabled
  (allows recovery if state gets corrupted)

Bucket policy: restrict to IAM roles that run Terraform
  No other IAM user/role should have s3:GetObject on this bucket
```

### The DynamoDB lock: exactly how it works:

```
Engineer Alice:
  terraform apply starts
  → DynamoDB PutItem:
    {
      "LockID": "company-terraform-state-dev/dev/terraform.tfstate",
      "Info": {
        "ID": "uuid-of-this-lock",
        "Operation": "OperationTypeApply",
        "Who": "alice@company.com",
        "Version": "1.8.0",
        "Created": "2026-07-31T14:30:00Z",
        "Path": "company-terraform-state-dev/dev/terraform.tfstate"
      }
    }
  Apply runs...
  → DynamoDB DeleteItem (removes lock)

Engineer Bob (starts 30 seconds after Alice):
  terraform apply starts
  → DynamoDB PutItem with condition: item must NOT already exist
  → AWS: ConditionalCheckFailedException (lock already held by Alice)
  → Terraform: "Error acquiring the state lock: ConditionalCheckFailedException"
  → Terraform prints:
    "Lock Info:
      ID:        uuid-of-alice-lock
      Path:      company-terraform-state-dev/dev/terraform.tfstate
      Operation: OperationTypeApply
      Who:       alice@company.com
      Created:   2026-07-31 14:30:00 +0000 UTC"
  → Bob waits or sees the message and knows to wait for Alice to finish
```

**Force-unlock risk:**
```bash
terraform force-unlock "uuid-of-alice-lock"
# ONLY safe if Alice's apply is confirmed dead (process killed, machine crashed)
# If Alice's apply is STILL RUNNING when Bob force-unlocks:
#   Alice writes state with her changes at t=50s
#   Bob writes state with Bob's changes at t=52s
#   Both have serial=42 (before lock release)
#   The second write "wins" — the first write's changes are LOST
#   → State corruption, resource orphaning
```

---

## Deep Dive: terraform plan

### The three-phase plan process:

**Phase 1: Refresh**

```bash
terraform plan              # performs refresh (calls AWS APIs for each resource)
terraform plan -refresh=false  # skips refresh (faster, but misses manual changes)
```

During refresh, for EACH managed resource, Terraform calls the provider's "Read" function:
- `aws_eks_cluster.this` → `eks:DescribeCluster`
- `dynatrace_slo_v2.availability["payment-service"]` → Dynatrace API GET /slo
- `aws_vpc.this` → `ec2:DescribeVpcs`

If a resource exists in state but NOT in AWS (was deleted outside Terraform), Terraform notes it as "tainted" and will plan to CREATE it again.

**Phase 2: Dependency Graph Construction**

```
Terraform builds a directed acyclic graph (DAG):

aws_vpc.this
    ↓ (EKS needs VPC to exist first)
aws_eks_cluster.this
    ↓
aws_eks_node_group.system
    ↓
(all pods implicitly depend on node group)

dynatrace_management_zone_v2.team["payments"]
    ↓
dynatrace_alerting.critical["payments"]
    ↓
dynatrace_pagerduty_notification.critical["payments"]

VPC and Dynatrace are independent of each other → applied in parallel
```

**Phase 3: Diff Computation**

For each resource, Terraform compares three versions:
```
.tf file config  →  desired attributes (what you want)
state file       →  last-known attributes (what Terraform last set)
AWS API response →  current attributes (what actually exists right now)
```

The diff rules:
```
field in .tf == field in AWS:    → no change
field in .tf != field in AWS:    → UPDATE (or REPLACE if immutable field)
field in .tf, not in AWS:        → CREATE
field in AWS, not in .tf:        → may be IGNORED (if computed) or DESTROY (if managed)
```

### Reading plan symbols:

```
+ resource "aws_subnet" "private" {  ← GREEN: will be CREATED
    id   = (known after apply)
    cidr = "10.0.0.0/20"
  }

~ resource "aws_eks_cluster" "this" {  ← YELLOW: will be UPDATED in-place
    id = "company-dev"                     (existing resource, some fields changing)
  ~ version = "1.29" → "1.30"
  }

- resource "aws_security_group" "old" {  ← RED: will be DESTROYED
    id = "sg-abc123"
  }

-/+ resource "aws_subnet" "private" {  ← RED/GREEN: destroy AND recreate
    ~ cidr_block = "10.0.0.0/24" → "10.0.0.0/20"  (forces replacement)
  }
  # This is the DANGEROUS one — means downtime if the resource is in use

<= data "aws_caller_identity" "current" {  ← data source: will be READ
  }
```

### `(known after apply)` — understanding computed values:

```hcl
resource "aws_eks_cluster" "this" {
  name    = "company-dev"
  version = "1.30"
}

output "cluster_endpoint" {
  value = aws_eks_cluster.this.endpoint
  # endpoint is COMPUTED by AWS when the cluster is created
  # It's unknown at plan time
}
```

Plan output:
```
+ resource "aws_eks_cluster" "this" {
    + name     = "company-dev"
    + version  = "1.30"
    + endpoint = (known after apply)  ← AWS assigns this, we can't predict it
    + arn      = (known after apply)
  }
```

After apply, the state file contains the real values:
```json
"attributes": {
  "name": "company-dev",
  "endpoint": "https://ABCDEF.gr7.ap-northeast-1.eks.amazonaws.com",
  "arn": "arn:aws:eks:ap-northeast-1:123456789010:cluster/company-dev"
}
```

### Saving plans for reproducibility:

```bash
# Save the plan
terraform plan -out=production.tfplan

# The plan file is binary — inspect with:
terraform show production.tfplan

# Apply EXACTLY the saved plan (no re-planning)
terraform apply production.tfplan
```

**Why saving matters for production:**
```
Without saved plan:
  09:00 terraform plan → shows "change X and Y"
  09:05 colleague merges a PR that changes module code
  09:06 terraform apply → re-plans with new code → applies "change X, Y, AND Z"
  Z was not reviewed → unexpected change in production

With saved plan:
  09:00 terraform plan -out=prod.plan → saves exact changes
  09:05 colleague merges code
  09:06 terraform apply prod.plan → applies exactly the reviewed plan
  If the code changed after the plan: apply fails:
    "Error: Saved plan is stale"
  → Force re-plan before applying
```

---

## Deep Dive: terraform apply

### The apply execution model:

```
1. ACQUIRE LOCK
   DynamoDB PutItem (conditional) → blocks concurrent applies

2. READ CURRENT STATE
   S3 GetObject → loads terraform.tfstate into memory

3. EXECUTE DEPENDENCY GRAPH
   For each resource (in topological order, parallel where safe):

   CREATE:
     a. Call provider's Create function
     b. Provider calls AWS API (e.g., CreateVpc)
     c. Wait for resource to reach stable state (some operations are async)
        e.g., EKS cluster takes 15 minutes → Terraform polls DescribeCluster
              until status = ACTIVE
     d. Store returned attributes in state
     e. Write state to S3 (incremental — after EACH resource)

   UPDATE:
     a. Call provider's Update function with changed fields
     b. Wait for completion
     c. Update state

   DESTROY:
     a. Call provider's Delete function
     b. Wait for resource to disappear (polling)
     c. Remove from state

4. RELEASE LOCK
   DynamoDB DeleteItem → next person can apply
```

### Why apply writes state incrementally:

```
Large apply: creating 50 resources

Without incremental writes:
  Resources 1-49 created successfully
  Resource 50 fails
  Apply writes state at the END
  → State file shows 0 resources (nothing was written)
  → Next apply: tries to create all 50 again
  → AWS: resource 1 already exists → duplicate resource error

With incremental writes (Terraform's actual behavior):
  Resources 1-49 created and written to state one by one
  Resource 50 fails
  → State file shows 49 resources
  → Next apply: resources 1-49: "already exists, no change"
     resource 50: "create" → picks up where it left off
```

### The `-parallelism` flag and its risks:

```bash
terraform apply -parallelism=10  # default: 10 concurrent resource operations
terraform apply -parallelism=20  # faster applies for large configurations
terraform apply -parallelism=1   # sequential: useful for debugging ordering issues
```

**Risk at high parallelism:**
AWS API rate limits (per-service, per-region, per-account). At `parallelism=50` applying a large EKS configuration:
- 50 concurrent `ec2:CreateSecurityGroup` calls
- AWS throttles: `RequestLimitExceeded`
- Some resources fail with throttling errors
- Apply completes partially (some resources created, some not)
- Next apply retries the failed ones — usually fine, but adds complexity

Safe defaults: parallelism=10 for production (the default), parallelism=20 for dev/CI.

---

## The Complete Lifecycle Diagram

```
DEVELOPER WORKFLOW:
  Edit .tf file
       ↓
  terraform init     (if new providers/modules added)
       ↓
  terraform validate (fast syntax check, no API calls)
       ↓
  terraform plan -out=changes.plan
       ↓
  [REVIEW the plan — especially look for -/+ DESTROY+CREATE lines]
       ↓
  terraform apply changes.plan
       ↓
  [Verify in AWS console / kubectl / DT UI]

CI/CD WORKFLOW:
  Pull Request:
    terraform validate ← fast, always first
    terraform plan     ← post to PR as comment for review

  Merge to main:
    terraform apply -auto-approve ← (dev/staging)
    terraform apply + human approval gate ← (production)

DAILY OPERATIONS:
  terraform plan -refresh-only -detailed-exitcode
    ← checks for drift daily (scheduled cron)
    exit 0: no drift, all clear
    exit 2: drift detected, create GitHub Issue
```
