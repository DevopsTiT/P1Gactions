# Part 6 — State Management Operations Deep Dive

> Six commands that let you manipulate Terraform's view of the world without touching real resources. Essential for refactoring, recovery, and adopting existing infrastructure.

---

## Why State Management Operations Exist

Terraform's state file is a map: `.tf resource address` → `real-world ID`. Sometimes this map needs to be corrected without changing the real world:

```
Scenarios that require state manipulation:
  1. Refactor: you renamed a resource in .tf → state has old name → Terraform wants to destroy+recreate
     Fix: terraform state mv (rename in state to match new .tf name)

  2. Adoption: someone created a resource manually in AWS → not in state → Terraform wants to create again
     Fix: terraform import (add existing resource to state)

  3. Handoff: another team will manage a resource → you don't want to destroy it when you remove it from .tf
     Fix: terraform state rm (remove from state without deleting)

  4. Debugging: understand what Terraform thinks a resource looks like
     Fix: terraform state show (inspect state)

  5. Recovery: a resource is stuck/unhealthy → force recreation
     Fix: terraform apply -replace

  6. Stuck lock: a crash left a DynamoDB lock nobody can release
     Fix: terraform force-unlock
```

---

## `terraform state list` — The Inventory Command

```bash
terraform state list

# Output (production environment, after full apply):
module.dynatrace.dynatrace_alerting.critical["notifications"]
module.dynatrace.dynatrace_alerting.critical["orders"]
module.dynatrace.dynatrace_alerting.critical["payments"]
module.dynatrace.dynatrace_alerting.high["notifications"]
module.dynatrace.dynatrace_alerting.high["orders"]
module.dynatrace.dynatrace_alerting.high["payments"]
module.dynatrace.dynatrace_alerting.info["notifications"]
module.dynatrace.dynatrace_alerting.info["orders"]
module.dynatrace.dynatrace_alerting.info["payments"]
module.dynatrace.dynatrace_alerting.warning["notifications"]
module.dynatrace.dynatrace_alerting.warning["orders"]
module.dynatrace.dynatrace_alerting.warning["payments"]
module.dynatrace.dynatrace_http_monitor.health_check["notification-service"]
module.dynatrace.dynatrace_http_monitor.health_check["order-service"]
module.dynatrace.dynatrace_http_monitor.health_check["payment-service"]
module.dynatrace.dynatrace_management_zone_v2.team["notifications"]
module.dynatrace.dynatrace_management_zone_v2.team["orders"]
module.dynatrace.dynatrace_management_zone_v2.team["payments"]
module.dynatrace.dynatrace_metric_events.cpu_saturation["notification-service"]
... (50+ more)

# Filter with grep:
terraform state list | grep "payment"
module.dynatrace.dynatrace_alerting.critical["payments"]
module.dynatrace.dynatrace_alerting.high["payments"]
module.dynatrace.dynatrace_http_monitor.health_check["payment-service"]
module.dynatrace.dynatrace_slo_v2.availability["payment-service"]
module.dynatrace.dynatrace_slo_v2.latency["payment-service"]

# Count total managed resources:
terraform state list | wc -l
# 127 (for a fully populated production environment)
```

**SRE use cases:**
- "Was the search-service SLO created?" → `terraform state list | grep search-service`
- "Find the exact address to use in state mv/rm/import" → copy from state list output
- "How many resources does this module manage?" → filter and count

---

## `terraform state show` — Inspect One Resource

```bash
terraform state show 'module.dynatrace.dynatrace_slo_v2.availability["payment-service"]'

# Output:
# resource "dynatrace_slo_v2" "availability" {
#     description       = "Availability SLO: 99.9%. Team: payments."
#     enabled           = true
#     evaluation_type   = "AGGREGATE"
#     evaluation_window = "-1M"
#     id                = "abc123-uuid-from-dynatrace-api"
#     metric_expression = <<-EOT
#         100*(builtin:service.requestCount.server
#           :filter(and(eq(service.name,"payment-service"),eq(environment,"production")))
#           :splitBy():sum
#           - builtin:service.errors.server.count
#           :filter(and(eq(service.name,"payment-service"),eq(environment,"production")))
#           :splitBy():sum)
#         / builtin:service.requestCount.server
#           :filter(and(eq(service.name,"payment-service"),eq(environment,"production")))
#           :splitBy():sum
#     EOT
#     name              = "payment-service Availability [production]"
#     target_success    = 99.9
#     target_warning    = 99.8
# }
```

**The `id` field is the most important:**
The `id` is the real-world identifier Terraform uses to look up and modify this specific resource. For Dynatrace resources it's a UUID. For AWS resources it's an ARN or resource ID. If you need to call the provider's API directly (curl, CLI), this is the identifier to use.

**Use case — confirming a drift fix:**
```bash
# Dynatrace UI shows target_success = 95 (was manually changed)
terraform state show 'module.dynatrace.dynatrace_slo_v2.availability["payment-service"]' \
  | grep target_success
# target_success = 99.9  ← what Terraform last set it to
# terraform plan will show: 95 (current) → 99.9 (desired)
```

---

## `terraform state mv` — Rename Without Recreating

```bash
terraform state mv SOURCE_ADDRESS DESTINATION_ADDRESS
```

**The refactoring problem it solves:**

```hcl
# Before refactoring:
resource "dynatrace_alerting" "critical" {
  for_each = local.teams
  ...
}
# State address: module.dynatrace.dynatrace_alerting.critical["payments"]

# After refactoring (rename "critical" to "crit" for brevity):
resource "dynatrace_alerting" "crit" {
  for_each = local.teams
  ...
}
# Terraform sees: NEW address = module.dynatrace.dynatrace_alerting.crit["payments"]
#                 OLD address still in state = module.dynatrace.dynatrace_alerting.critical["payments"]

# WITHOUT state mv:
# terraform plan would show:
#   - module.dynatrace.dynatrace_alerting.critical["payments"]   ← DESTROY old
#   + module.dynatrace.dynatrace_alerting.crit["payments"]       ← CREATE new
# This destroys 3 alerting profiles and creates 3 new ones
# Brief gap in alerting coverage during destroy+create → missed alerts

# WITH state mv:
terraform state mv \
  'module.dynatrace.dynatrace_alerting.critical["payments"]' \
  'module.dynatrace.dynatrace_alerting.crit["payments"]'

terraform state mv \
  'module.dynatrace.dynatrace_alerting.critical["orders"]' \
  'module.dynatrace.dynatrace_alerting.crit["orders"]'

terraform state mv \
  'module.dynatrace.dynatrace_alerting.critical["notifications"]' \
  'module.dynatrace.dynatrace_alerting.crit["notifications"]'

# Now terraform plan shows: 0 changes (state addresses match .tf code)
# Real Dynatrace alerting profiles: UNCHANGED (same UUIDs, same config)
```

**Moving a resource between modules:**
```bash
# Scenario: moving EKS from a flat resource to a module
# Before: resource "aws_eks_cluster" "this" { ... }
# After: module "eks" { ... } → module.eks.aws_eks_cluster.this

terraform state mv \
  aws_eks_cluster.this \
  module.eks.aws_eks_cluster.this
# The EKS cluster is not recreated — only the state address changes
```

**Moving `for_each` resources in bulk:**
```bash
# For loop in shell to move all three teams at once:
for team in payments orders notifications; do
  terraform state mv \
    "module.dynatrace.dynatrace_alerting.critical[\"${team}\"]" \
    "module.dynatrace.dynatrace_alerting.crit[\"${team}\"]"
done
```

---

## `terraform state rm` — Remove From Tracking

```bash
terraform state rm ADDRESS
# Removes the resource from terraform.tfstate
# Does NOT delete the real resource in AWS/Dynatrace
```

**When to use it:**

```bash
# Scenario 1: Transferring resource management to another team
# The payments team will now manage their own DT management zone
# in their own Terraform workspace.

# Step 1: Remove from this workspace's state
terraform state rm 'module.dynatrace.dynatrace_management_zone_v2.team["payments"]'

# Step 2: Remove the resource block from your .tf file
# (if you keep it in .tf after state rm, next plan will try to CREATE it again)

# Step 3: Other team runs terraform import in their workspace
# to adopt the same resource

# Scenario 2: Resource will be managed by a different tool
# The Dynatrace dashboard was exported to a JSON template
# that another tool manages. Stop Terraform from touching it.

terraform state rm 'module.dynatrace.dynatrace_dashboard.network_overview'
# + remove from .tf file
```

**Important: always remove from .tf AFTER state rm:**
```
If you state rm a resource but KEEP it in .tf:
  terraform plan: "resource not in state → CREATE"
  terraform apply: tries to create → may fail (already exists) or creates a duplicate
  
Order of operations:
  1. terraform state rm ADDRESS
  2. Remove the resource block from .tf
  3. terraform plan (should show 0 changes for this resource)
```

---

## `terraform import` — Adopt Existing Resources

```bash
terraform import ADDRESS REAL_WORLD_ID
```

**The manual resource adoption workflow:**

```bash
# Scenario: A Dynatrace SLO was created manually in the UI
# SLO UUID (from Dynatrace UI URL): "existing-slo-uuid-123"

# Step 1: Add the resource block to .tf FIRST (required before import)
# modules/dynatrace/main.tf already has:
resource "dynatrace_slo_v2" "availability" {
  for_each = var.services
  ...
}
# The import address must match a block that exists in .tf

# Step 2: Import the existing SLO
terraform import \
  'module.dynatrace.dynatrace_slo_v2.availability["payment-service"]' \
  "existing-slo-uuid-123"

# Terraform calls Dynatrace API: GET /api/v2/slos/existing-slo-uuid-123
# Reads all attributes (name, target, metric_expression, etc.)
# Stores them in state under the given address

# Step 3: Check for drift between state and .tf
terraform plan
# Likely shows differences between the manually-created SLO and what .tf defines
# Example:
#   ~ target_success = 95 → 99.9
#   ~ evaluation_window = "-7D" → "-1M"

# Step 4: Decide:
#   Option A: fix the resource (apply to match .tf)
#   Option B: update .tf to match the existing resource (no change needed)
```

**Finding the real-world ID for import:**

```bash
# For AWS resources: use AWS CLI
aws eks describe-cluster --name company-dev \
  --query 'cluster.arn' --output text
# arn:aws:eks:ap-northeast-1:123456789010:cluster/company-dev

# For Dynatrace resources: use DT API
curl -s "${DT_URL}/api/v2/settings/objects?schemaIds=builtin:availability.monitoring" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | jq '.[0].objectId'
# "abc123-uuid"

# Some providers have an import section in their documentation:
# "To import, use: terraform import dynatrace_slo_v2.name SLO_ID"
```

---

## `terraform apply -replace` — Force Recreation

```bash
# Force Terraform to DESTROY and RECREATE a specific resource
# Even if configuration hasn't changed

terraform apply -replace='module.eks.aws_eks_node_group.system'

# terraform plan output:
#   -/+ module.eks.aws_eks_node_group.system (tainted)
#       # Forces replacement due to terraform apply -replace
# 
# Apply: destroys the old node group, creates a new one
```

**When to use it:**

```bash
# Scenario 1: An EKS node became unhealthy (OOMKilled, kernel panic)
# kubectl reports node is NotReady, node drain doesn't fix it
terraform apply -replace='module.eks.aws_eks_node_group.system'
# Creates a fresh node group → unhealthy node is replaced

# Scenario 2: A Dynatrace synthetic monitor is stuck in "disabled" state
# Terraform shows it as active, but DT UI shows it disabled
# The resource exists but is functionally broken
terraform apply -replace='module.dynatrace.dynatrace_http_monitor.health_check["payment-service"]'
# Destroys and recreates the monitor → fresh start

# Scenario 3: A TLS certificate was corrupted/expired
terraform apply -replace='aws_acm_certificate.main'
# Requests a new certificate
```

---

## `terraform force-unlock` — Release Stuck Locks

```bash
# First: inspect the lock
aws dynamodb get-item \
  --table-name terraform-state-lock \
  --key '{"LockID":{"S":"company-terraform-state-prod/production/terraform.tfstate"}}' \
  --region ap-northeast-1

# Output:
# {
#   "Item": {
#     "LockID": {"S": "company-terraform-state-prod/production/terraform.tfstate"},
#     "Info": {"S": "{
#       \"ID\": \"abc123-lock-uuid\",
#       \"Operation\": \"OperationTypeApply\",
#       \"Who\": \"alice@company.com\",
#       \"Version\": \"1.8.0\",
#       \"Created\": \"2026-07-31T14:30:00Z\",
#       \"Path\": \"company-terraform-state-prod/production/terraform.tfstate\"
#     }"}
#   }
# }

# Check if Alice's apply is still running:
#   - Check CI/CD platform: is the job still active?
#   - Ask Alice directly
#   - Check process on Alice's machine (if local apply)

# ONLY if confirmed dead:
terraform force-unlock "abc123-lock-uuid"

# ⚠️ DANGER: If Alice's apply IS still running when you force-unlock:
#   Alice's apply: writes state at t=50s (serial=42)
#   Your apply (after unlock): also writes state at t=52s (serial=42)
#   LAST WRITE WINS: one of the applies' changes is silently lost
#   State file is now inconsistent with reality
#   Next plan will show unexpected diffs
```

**The safer alternative to force-unlock:**
```bash
# Instead of force-unlock, manually delete the DynamoDB item
aws dynamodb delete-item \
  --table-name terraform-state-lock \
  --key '{"LockID":{"S":"company-terraform-state-prod/production/terraform.tfstate"}}' \
  --region ap-northeast-1
# Same effect as force-unlock, but done through AWS CLI (may need separate approval)
# Provides an audit trail in CloudTrail (DynamoDB DeleteItem event)
```

---

## State Operation Safety Checklist

Before any `terraform state` operation, answer YES to all:

```
□ I have a state backup (S3 versioning is enabled on the state bucket)
  → aws s3api list-object-versions --bucket company-terraform-state-prod \
     --prefix production/terraform.tfstate
  → confirms the previous version is recoverable

□ I understand what resource I'm operating on
  → terraform state show ADDRESS confirms I have the right resource

□ I've tested this operation on a non-production environment first
  → state mv in dev before production

□ For state mv: I've verified the new address exists in .tf code
  → terraform validate passes after renaming

□ For state rm: I've removed the resource block from .tf
  → grep for the old address → not found

□ For import: I've confirmed the resource ID is correct
  → provider documentation shows what the ID format should be

□ For force-unlock: I've confirmed the locking process is truly dead
  → Slack/email confirmation from the person, or CI job is cancelled
```
