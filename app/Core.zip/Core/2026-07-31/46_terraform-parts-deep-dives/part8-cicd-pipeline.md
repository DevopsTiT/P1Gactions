# Part 8 — CI/CD Pipeline Integration Deep Dive

> The `.github/workflows/terraform-infra.yaml` file is a complete Terraform automation system. Every line serves a specific safety purpose. This deep dive explains the design decisions behind PR-plan → merge-apply → production-gate → drift-detection.

---

## Pipeline Trigger Design

```yaml
on:
  push:
    branches: [main]
    paths:
      - 'terraform/environments/**'
      - 'terraform/modules/eks/**'
      - 'terraform/modules/vpc/**'
  pull_request:
    branches: [main]
    paths:
      - 'terraform/environments/**'
      - 'terraform/modules/eks/**'
      - 'terraform/modules/vpc/**'
  schedule:
    - cron: '0 17 * * *'
```

**`paths:` filter — why it's critical:**
```
Without paths filter:
  README.md changes → triggers all 3 environment plans + all 3 applies
  Costs: 6 × ~2 minutes = 12 minutes of CI time per README change
  Risk: unnecessary state refreshes, potential rate-limit issues with AWS/DT APIs
  
With paths filter:
  README.md changes → no workflow triggered (paths don't match)
  charts/payment-service/ changes → no workflow triggered
  terraform/environments/dev/main.tf changes → pipeline triggers
  terraform/modules/vpc/main.tf changes → pipeline triggers (affects all envs)
```

**Why modules trigger the pipeline for ALL environments:**
```
terraform/modules/vpc/main.tf changed:
  → ALL environments use this module
  → dev plan, staging plan, production plan all need to show the impact

terraform/environments/dev/main.tf changed:
  → Only dev is affected
  → BUT: the paths filter is 'terraform/environments/**' → all envs' pipelines trigger
    Why? The matrix runs plans for all envs regardless → reviewer sees
    dev has changes, staging/production have 0 changes → confirms change is scoped correctly
```

---

## PR Phase: Parallel Plan Across 3 Environments

```yaml
plan:
  name: Plan (${{ matrix.env.name }})
  if: github.event_name == 'pull_request'
  # ONLY runs on PRs, NOT on push to main
  # (applying on PR would be dangerous — PRs may not be merged)
  
  runs-on: ubuntu-latest
  permissions:
    id-token: write      # OIDC: exchange GitHub JWT for AWS credentials
    contents: read       # read the repo code
    pull-requests: write # post the plan as a PR comment
  
  strategy:
    fail-fast: false
    # If dev plan FAILS (e.g., syntax error in dev-specific code),
    # staging and production plans STILL run.
    # Why: you want to see ALL three plans at once in the PR.
    # If fail-fast: true, you'd fix dev, re-push, then find staging also fails.
    # fail-fast: false shows all problems in one PR review cycle.
    
    matrix:
      env:
        - name: dev
          account_id: "123456789010"
          working_dir: terraform/environments/dev
        - name: staging
          account_id: "123456789011"
          working_dir: terraform/environments/staging
        - name: production
          account_id: "123456789012"
          working_dir: terraform/environments/production
  
  steps:
    - uses: aws-actions/configure-aws-credentials@v4
      with:
        role-to-assume: arn:aws:iam::${{ matrix.env.account_id }}:role/github-actions-infra-plan
        # Uses the PLAN role (read-only permissions):
        #   - s3:GetObject (read state)
        #   - eks:Describe* (refresh EKS resources)
        #   - ec2:Describe* (refresh VPC resources)
        # Does NOT have:
        #   - eks:CreateCluster (can't accidentally create)
        #   - ec2:DeleteVpc (can't accidentally delete)
        # Even if the pipeline is misconfigured or hijacked,
        # the plan role cannot make destructive changes.

    - name: Terraform Plan
      working-directory: ${{ matrix.env.working_dir }}
      run: terraform plan -no-color -detailed-exitcode 2>&1 | tee plan.txt
      # -no-color: removes ANSI color codes that GitHub Markdown can't render
      # -detailed-exitcode: exit 2 means "changes exist" (not an error)
      # 2>&1: merge stderr into stdout so both go to tee
      # tee plan.txt: write output to plan.txt AND stdout simultaneously
      # → stdout goes to GitHub Actions log
      # → plan.txt is used by the PR comment step

    - name: Post Plan to PR
      uses: actions/github-script@v7
      with:
        script: |
          const fs = require('fs');
          const plan = fs.readFileSync('${{ matrix.env.working_dir }}/plan.txt', 'utf8');
          const env = '${{ matrix.env.name }}';
          const emoji = plan.includes('No changes') ? '✅' : '⚠️';
          // ✅ = no changes needed (infrastructure already matches desired state)
          // ⚠️ = changes pending (review before merging)
          
          github.rest.issues.createComment({
            issue_number: context.issue.number,
            owner: context.repo.owner,
            repo: context.repo.repo,
            body: `## ${emoji} Infra Plan — ${env.toUpperCase()}\n\`\`\`\n${plan.substring(0, 65000)}\n\`\`\``
            // substring(0, 65000): GitHub API has a comment size limit (~65k chars)
            // Truncates the plan if it's very large
          });
```

**What the PR reviewer sees:**

```
⚠️ Infra Plan — PRODUCTION
```
```
Terraform will perform the following actions:

  # module.dynatrace.dynatrace_slo_v2.availability["payment-service"] will be updated in-place
  ~ resource "dynatrace_slo_v2" "availability" {
        id             = "abc123"
      ~ target_success = 99.9 -> 99.95
    }

Plan: 0 to add, 1 to change, 0 to destroy.
```

```
✅ Infra Plan — DEV
No changes. Infrastructure is up-to-date.

✅ Infra Plan — STAGING
No changes. Infrastructure is up-to-date.
```

**The reviewer's checklist:**
- Is the production change expected? (Does it match the PR description?)
- Are dev and staging showing "No changes" as expected?
- Are there any `-/+` (destroy+recreate) changes? (Could cause downtime)
- Are any changes that should be in dev ONLY accidentally showing in production?

---

## Push Phase: Sequential Apply (dev → staging → production)

```yaml
apply-dev:
  name: Apply (dev)
  if: github.event_name == 'push'
  # Only on push to main (merged PR), NOT on PRs
  
  runs-on: ubuntu-latest
  permissions: { id-token: write, contents: read }
  
  steps:
    - uses: aws-actions/configure-aws-credentials@v4
      with:
        role-to-assume: arn:aws:iam::123456789010:role/github-actions-infra-apply
        # APPLY role (full permissions):
        #   - ec2:CreateVpc, ec2:DeleteSubnet, ...
        #   - eks:CreateCluster, eks:UpdateCluster, ...
        # Much more powerful than the plan role
        # Protected by: OIDC (can only be assumed by GitHub Actions)
        #               Sequential pipeline (dev applied before staging)
    
    - name: Terraform Init
      working-directory: terraform/environments/dev
      run: terraform init -no-color
    
    - name: Terraform Apply
      working-directory: terraform/environments/dev
      run: terraform apply -auto-approve -no-color
      # -auto-approve: no interactive "yes" prompt (CI is non-interactive)
      # This is safe here because:
      #   1. The plan was already reviewed in the PR
      #   2. OIDC limits what the role can do
      #   3. State lock prevents concurrent applies
      #   4. This is dev (not production)

apply-staging:
  name: Apply (staging)
  if: github.event_name == 'push'
  needs: apply-dev    # ← ONLY runs after apply-dev succeeds
  # Sequential: staging waits for dev
  # Why: if the VPC module change breaks dev, staging is protected
  #      If dev has an issue: staging never touched, production never touched
  ...

apply-production:
  name: Apply (production)
  if: github.event_name == 'push'
  needs: apply-staging  # ← ONLY runs after staging succeeds
  environment: production  # ← THE APPROVAL GATE
  # environment: production adds:
  #   1. A pause: pipeline waits for human approval
  #   2. Required reviewers: must be approved by someone in the configured reviewer list
  #   3. Audit trail: GitHub records who approved and when
  ...
```

**Why sequential (not parallel) apply:**

```
Scenario: New EKS version "1.31" in modules/eks/main.tf

Parallel apply (all 3 at once):
  dev applies 1.31:      ✅ works fine
  staging applies 1.31:  ✅ works fine  
  production applies 1.31: ❌ "1.31 not yet supported in ap-northeast-1"
  
  Result: dev and staging upgraded, production failed
  Problem: we didn't catch the regional availability issue in lower envs first
  
Sequential apply (dev → staging → production):
  dev applies 1.31:      ❌ "1.31 not yet supported in ap-northeast-1"
  Pipeline stops: needs: apply-dev failed → apply-staging never triggered
  production: never touched
  
  Result: caught in dev, no blast radius
  Fix: use "1.30" for now, wait for 1.31 availability in ap-northeast-1
```

---

## The Production Approval Gate in Depth

```yaml
apply-production:
  environment: production
```

**GitHub Environment configuration (set up in GitHub UI):**
```
Repository Settings → Environments → New Environment: "production"
  Required Reviewers: [alice@company.com, bob@company.com]
    → At least ONE of these must approve before the job runs
    → Cannot approve your own deployment (prevent self-approval)
  
  Wait timer: 0 minutes
    → No artificial delay, but approval button requires deliberate action
  
  Deployment branches: main only
    → Can only deploy to production from the main branch
    → Feature branches cannot trigger production deploys even if they match
  
  Environment Secrets:
    → Can store environment-specific secrets accessible only to this environment
    → (This project uses AWS Secrets Manager + OIDC instead)
```

**What happens when `environment: production` is reached:**

```
Timeline:
  14:00 PR merged to main
  14:01 apply-dev starts
  14:03 apply-dev completes ✅
  14:03 apply-staging starts (needs: apply-dev passed)
  14:05 apply-staging completes ✅
  14:05 apply-production triggered → PAUSES
        
  GitHub sends notifications to required reviewers:
    Email: "production deployment waiting for approval"
    Slack (if configured): "[company/infra] production deployment pending"
    GitHub mobile app notification
  
  14:05 - 14:20 Job shows as "Waiting" in GitHub Actions UI
               Reviewer can see the PR, the plan comment, the changes
  
  14:20 Alice reviews the plan comment from the PR:
        "~ target_success = 99.9 → 99.95 — yes this is the right change"
        Alice clicks "Review deployments" → "Approve and deploy"
  
  14:20 apply-production unpauses and runs
  14:22 apply-production completes ✅
```

**The 30-day timeout:**
```
If nobody approves within 30 days:
  Job status: "Expired"
  No deployment happens
  
  This protects against abandoned PRs that include production changes.
  If the change is still needed: push a new commit → new pipeline run.
```

---

## OIDC Authentication: Two Roles Per Account

```
github-actions-infra-plan (read-only):
  Permissions: Describe/List/Get only
  Used by: PR plan jobs
  Why: PRs can't make changes even if the workflow is compromised
  
  IAM policy (simplified):
    { "Effect": "Allow", "Action": [
      "eks:Describe*", "ec2:Describe*",
      "s3:GetObject",  "dynamodb:GetItem"
    ], "Resource": "*" }

github-actions-infra-apply (full):
  Permissions: Create/Update/Delete
  Used by: push apply jobs only
  Protected by: OIDC condition on the ref:
  
  Trust policy condition:
    "token.actions.githubusercontent.com:ref": "refs/heads/main"
  → Can ONLY be assumed by workflows triggered from the main branch
  → A feature branch PR can't assume the apply role
```

**How OIDC protects against secret exposure:**
```
Traditional approach (AWS access keys stored in GitHub Secrets):
  AWS_ACCESS_KEY_ID=AKIA...
  AWS_SECRET_ACCESS_KEY=wJal...
  
  Problem: these credentials are permanent (until manually rotated)
  If GitHub is compromised: credentials stolen → AWS compromised
  If key is accidentally logged: permanent exposure until rotated

OIDC approach:
  No permanent credentials stored
  GitHub gets a short-lived JWT from GitHub's OIDC provider
  JWT is exchanged for temporary AWS credentials (1 hour max, 15 min typical)
  Credentials expire when the job ends
  
  If GitHub is compromised: attacker gets expired credentials → useless
  If credentials are logged: they expire automatically → limited window
```

---

## Workflow File Organization

```
.github/workflows/
├── terraform-infra.yaml        ← VPC + EKS (this pipeline)
├── terraform-dynatrace-dev.yaml      ← DT config (dev only, auto-apply)
├── terraform-dynatrace-staging.yaml  ← DT config (staging, auto-apply)
└── terraform-dynatrace-production.yaml ← DT config (production, approval gate)
```

**Why separate workflows for DT vs infrastructure:**
```
Infrastructure (EKS, VPC):
  Changes: infrequent (once a month?)
  Apply time: 20-30 minutes (EKS update)
  Risk: HIGH (touching nodes affects all services)
  Approval: always required for production

Dynatrace config:
  Changes: frequent (weekly threshold adjustments)
  Apply time: 1-3 minutes
  Risk: LOW (changing an alert threshold doesn't affect service availability)
  Approval: required for production, but separate reviewer pool (SRE team)

Separating the workflows:
  → SRE can approve DT changes without knowing EKS internals
  → Infrastructure changes don't block Dynatrace changes
  → Different approval queues for different risk levels
```
