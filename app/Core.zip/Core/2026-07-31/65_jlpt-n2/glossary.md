# JLPT N2 — Glossary: Every Term and Concept Explained

---

**JLPT (日本語能力試験)**
The Japanese Language Proficiency Test. The world's largest standardized Japanese test, administered by the Japan Foundation and JEES. Five levels: N5 (easiest) to N1 (hardest). N2 is the second hardest and widely accepted for work and university in Japan.

**N2 Level**
The second most difficult JLPT level. Covers approximately 6,000 vocabulary items and 1,000 kanji. Tests ability to understand Japanese used in everyday and near-professional contexts — newspapers, formal letters, workplace conversations.

**言語知識 (げんごちしき)**
"Language knowledge" — the first major section of the JLPT covering vocabulary, grammar, and reading. Scored 0–120. You need ≥ 19 points in this section to pass regardless of your total score.

**聴解 (ちょうかい)**
"Listening comprehension" — the second major section. Scored 0–60. You need ≥ 19 points here as well, regardless of total score.

**Subscore requirement**
A feature of JLPT scoring where you must pass each section independently AND meet the total score. Scoring 180/180 on listening but 0 on language knowledge = overall FAIL because the language knowledge subscore of 0 is below 19.

**漢字読み (かんじよみ) — 問題1**
The vocabulary question type where you see a kanji word in context and choose the correct reading (hiragana). Tests whether you can read common N2 kanji accurately.

**表記 (ひょうき) — 問題2**
The vocabulary question type where a word is written in hiragana and you choose the correct kanji spelling. Tests whether you know which kanji corresponds to a given word.

**語形成 (ごけいせい) — 問題3**
"Word formation" question type. Tests knowledge of how Japanese compound words are built — which prefix or suffix creates a real, meaningful word.

**文脈規定 (ぶんみゃくきてい) — 問題4**
"Contextual definition" — choose the word that best fits the sentence's meaning and context. Tests vocabulary in use, not just isolated definitions.

**言い換え類義 (いいかえるいぎ) — 問題5**
"Paraphrase/synonym" questions. The underlined word is given and you choose the word or phrase closest in meaning. Tests depth of vocabulary knowledge.

**用法 (ようほう) — 問題6**
"Usage" questions. A target word is given and you must identify which of four sentences uses it correctly. Tests nuance and proper context of vocabulary.

**文の文法1 (ぶんのぶんぽう) — 問題7**
Fill-in-the-blank grammar questions. One blank per sentence, choose the grammar pattern that correctly completes it. The core grammar section.

**文の文法2 (文整序) — 問題8**
Sentence composition / rearrangement. Four segments are scrambled and you arrange them in the correct order. One position is marked ★ and you identify which segment belongs there.

**文章の文法 (ぶんしょうのぶんぽう) — 問題9**
Grammar-in-context. A short passage has 5 blanks. You choose the correct expression for each blank based on the flow and logic of the surrounding text.

**〜ために (purpose)**
Grammar: "in order to / for the purpose of." Used with volitional verbs (actions you choose to do). 医者になるために勉強する = studying in order to become a doctor.

**〜ように (purpose/state)**
Grammar: "so that / in order that a state results." Used when the goal is a state rather than an action, or when requesting/hoping. 忘れないように書く = write it down so you don't forget.

**〜にもかかわらず**
Grammar: "despite / in spite of / regardless of." Contrasts a fact with an unexpected outcome. 雨にもかかわらず試合が続いた = despite the rain, the game continued.

**〜ものの**
Grammar: "although / even though." Introduces a concession — something is true, but the result was not what you'd expect. 合格したものの就職に苦労した = although I passed, I struggled to find work.

**〜はずだ**
Grammar: "should be / expected to be." Expresses logical expectation based on available information. 彼は着いているはずだ = he should have arrived by now.

**〜わけだ**
Grammar: "which means / that explains it / naturally." Used to present a logical conclusion or explain why something makes sense. 10年いたわけだから上手なのは当然 = since he was there 10 years, it's natural he's good.

**〜わけにはいかない**
Grammar: "cannot afford to / must not." Social, moral, or situational obligation makes the action impossible. 断るわけにはいかない = I can't afford to refuse (social pressure prevents it).

**〜わけではない**
Grammar: "it doesn't mean that / it's not that." Denial of a natural assumption. 嫌いなわけではない = it's not that I dislike it.

**〜かねない**
Grammar: "might well / there's a risk that." Expresses a negative possibility. このままでは失敗しかねない = at this rate, there's a risk of failure.

**〜かねる**
Grammar: "find it difficult to / cannot bring oneself to." Polite refusal or reluctance. お答えしかねます = I'm afraid I cannot answer that. Very common in formal/business Japanese.

**〜次第 (しだい) — as soon as**
Grammar: "as soon as / the moment." 連絡が来次第知らせます = I will let you know as soon as I hear back. Used with a verb stem (連絡が来+ 次第).

**〜次第 (しだい) — depending on**
Grammar: "depending on." 結果次第で変わる = it changes depending on the result. Different meaning from "as soon as" — determined by whether a noun or verb precedes it.

**〜さえ〜ば**
Grammar: "if only / as long as." Sets a single sufficient condition. お金さえあれば何でもできる = if only I had money, I could do anything.

**〜ば〜ほど**
Grammar: "the more... the more." 練習すればするほど上手になる = the more you practice, the better you get. Requires repeating the verb in both ば-form and dictionary form.

**〜限り (かぎり)**
Grammar: "as long as / as far as." 私が知る限り = as far as I know. 生きている限り = as long as I'm alive.

**〜うちに**
Grammar: "while / before (a situation changes)." Implies urgency — do it before the window closes. 若いうちに経験しよう = let's gain experience while we're young.

**〜たとたんに**
Grammar: "the moment / just as." Immediate consequence. ドアを開けたとたん猫が飛び出した = the moment I opened the door, the cat jumped out.

**〜て以来 (ていらい)**
Grammar: "since (that point)." A continuous state that started at a past point. 日本に来て以来ずっと東京にいる = since coming to Japan I've been in Tokyo all along.

**〜一方(で) (いっぽう)**
Grammar: "on the other hand / while." Contrasts two simultaneous or opposing facts. 仕事は楽しい一方責任も重い = while work is enjoyable, the responsibility is heavy.

**〜に対して (にたいして)**
Grammar: "toward / against / in contrast to." 学生に対して説明した = explained to the students. AとBを比べる contrast: AはBに対してどう違う?

**〜において / 〜における**
Grammar: Formal "in / at / in the context of." Modern society に お い て スマホは必需品 = in modern society, smartphones are a necessity. Common in written, academic, and news Japanese.

**〜に際して (にさいして)**
Grammar: "on the occasion of / when (a formal event occurs)." 入学に際して = on the occasion of enrollment. More formal than 〜時に.

**〜にわたって / 〜にわたる**
Grammar: "spanning / over (a range of time or space)." 3日間にわたって = over the span of 3 days. 全国にわたる = spanning the entire country.

**〜をもとに(して)**
Grammar: "based on / drawing from." この映画は実話をもとに作られた = this film was made based on a true story.

**〜に基づいて (にもとづいて)**
Grammar: "based on / in accordance with (rules, data, evidence)." データに基づいて判断する = make judgments based on data. Slightly more formal than をもとに.

**〜ばかりか**
Grammar: "not only... but also (and moreover)." Stronger than だけでなく. 歌が上手なばかりか演技も素晴らしい = not only is she a good singer, but her acting is also wonderful.

**〜はもちろん / はもとより**
Grammar: "needless to say / of course / not to mention." 日本語はもちろん英語も話せる = needless to say Japanese, she also speaks English. はもとより is more formal.

**〜末に (すえに)**
Grammar: "after a long process / finally after." 長い議論の末結論が出た = after a long discussion, a conclusion was reached. Implies a drawn-out process before the result.

**〜あげくに**
Grammar: "after all that trouble / after a lot of effort (often with negative result)." 散々悩んだあげくやめることにした = after agonizing over it endlessly, I decided to quit.

**〜からこそ**
Grammar: "it's precisely because / exactly because." 好きだからこそ厳しく指導する = it's precisely because I care that I teach strictly. Emphasizes the cause as the exact and only reason.

**〜からといって**
Grammar: "just because... doesn't mean..." お金があるからといって幸せになれるわけではない = just because you have money doesn't mean you'll be happy. Refutes an assumption.

**〜とはいえ**
Grammar: "that said / even so / although it may be true that." 春とはいえまだ寒い = that said, it's spring, but it's still cold. Acknowledges a fact then shows a limitation.

**〜にちがいない**
Grammar: "must be / certainly / no doubt." Expresses strong conviction. あの光はUFOに違いない = that light must certainly be a UFO.

**〜だけあって**
Grammar: "as expected of / it's only natural because (of merit)." さすが先生だけあって説明がわかりやすい = as expected of a teacher, the explanation is clear.

**〜だけに**
Grammar: "all the more because / precisely because." 期待が大きかっただけに失望も大きかった = all the more because expectations were high, the disappointment was great.

**〜に過ぎない (にすぎない)**
Grammar: "nothing more than / merely / only." これは推測に過ぎない = this is nothing more than a guess.

**Sonkeigo (尊敬語)**
Honorific language — verbs and expressions that raise the status of the subject (usually the listener or a third party you respect). You use these when talking ABOUT your boss, client, or their actions.

**Kenjōgo (謙譲語)**
Humble language — verbs that lower your own status to show respect to the listener. You use these when talking about YOUR OWN actions to a social superior.

**Teineigo (丁寧語)**
Polite language — the basic politeness level using です/ます forms. Neutral and respectful. Used in most professional situations without the social hierarchy of sonkeigo/kenjōgo.

**いらっしゃる**
Sonkeigo for いる (to be), 行く (to go), and 来る (to come). Context determines which verb it replaces. 先生はいらっしゃいますか = Is the teacher here/in?

**おっしゃる**
Sonkeigo for 言う (to say). 部長がおっしゃったことは正しいです = what the manager said is correct.

**召し上がる (めしあがる)**
Sonkeigo for 食べる/飲む (to eat/drink). What would you like to eat? → 何を召し上がりますか？

**参る (まいる)**
Kenjōgo for 行く (to go) and 来る (to come). 明日参ります = I will come/go tomorrow. (humble — speaker's movement)

**うかがう**
Kenjōgo for 行く (to go — to visit), 来る (to come — to visit), and 聞く (to ask/hear). 明日うかがいます = I will visit tomorrow. / 少しうかがってもよろしいですか = May I ask you something?

**申す (もうす)**
Kenjōgo for 言う (to say). ○○と申します = I am called ○○. (humble self-introduction)

**いたす**
Kenjōgo for する (to do). ご案内いたします = I will guide you. Used for the speaker's own actions.

**拝見する (はいけんする)**
Kenjōgo for 見る (to see/look at). ご資料を拝見します = I will look at your materials.

**存じる / 存じ上げる (ぞんじる / ぞんじあげる)**
Kenjōgo for 知る (to know). 田中様をよく存じ上げております = I know Mr. Tanaka well. 存じ上げる is used for people (shows higher respect).

**課題理解 (かだいりかい) — Listening 問題1**
"Task understanding" listening questions. You hear a situation and must identify what action the person should take. Focus on what they need to DO.

**ポイント理解 (ポイントりかい) — Listening 問題2**
"Point understanding." You identify the key fact, main number, or central information from a conversation.

**概要理解 (がいようりかい) — Listening 問題3**
"Overview understanding." You listen to a lecture, speech, or discussion and identify the main idea or speaker's intention. Don't focus on details — focus on the conclusion.

**即時応答 (そくじおうとう) — Listening 問題4**
"Immediate response." Short question/statement followed by three possible responses. You choose the most appropriate. Tests natural conversational Japanese.

**統合理解 (とうごうりかい) — Listening 問題5**
"Integrated understanding." Longer listening passage, answered by comparing or integrating multiple pieces of information heard.

**中文読解 (ちゅうぶんどっかい)**
Reading of medium-length passages (~500 characters). Tests paragraph-level comprehension, locating specific information, and understanding argument structure.

**長文読解 (ちょうぶんどっかい)**
Reading of long passages (~800+ characters). Tests ability to understand main ideas, author's intent, transitions, and nuanced meaning across a full essay or article.

**情報検索 (じょうほうけんさく)**
"Information retrieval" reading. You search a practical document (timetable, advertisement, flyer) to find specific information meeting given conditions.

**統合理解 (読解) (とうごうりかい)**
Reading integrated comprehension. Two shorter texts (sometimes opposing viewpoints) are given, and you answer questions that require comparing or contrasting both.

**しかし / ところが / でも**
Contrast connectors. しかし = however (neutral formal), ところが = however (unexpected turn, often negative), でも = but (casual). Signal that the next sentence opposes the previous one.

**つまり / すなわち**
Summary/conclusion connectors. つまり = in other words / that is to say (casual-neutral), すなわち = namely / that is (formal). What follows is the key point or summary.

**なぜなら**
"Because / the reason is..." Introduces the explanation AFTER the claim. クラスに来なかった。なぜなら、病気だったからだ = He didn't come to class. Because he was sick.

**ゆえに / したがって**
Formal "therefore / thus / consequently." Used in written or academic Japanese to show logical conclusion. 証拠がある。ゆえに有罪だ = There is evidence. Therefore, guilty.

**SRS (Spaced Repetition System)**
A study method that shows you a flashcard more often when you struggle with it and less often when you know it well. Anki is the most common SRS app. Highly effective for vocabulary and kanji retention because it forces active recall at optimal intervals.

**Anki**
A free flashcard application using spaced repetition. Used by most serious JLPT students to memorize kanji readings, vocabulary, and grammar patterns. Pre-made N2 decks are available online.

**新完全マスター (しんかんぜんマスター)**
"Shin Kanzen Master" — a popular JLPT N2 study series published by 3A Corporation. Considered one of the most thorough preparation books. Has separate volumes for grammar, vocabulary, kanji, reading, and listening.

**JLPT公式問題集 (こうしきもんだいしゅう)**
The official JLPT practice exam book published by the Japan Foundation. Contains actual past exam questions. The most reliable way to experience the real test format and difficulty.

**模擬試験 (もぎしけん)**
Mock test / practice exam. A full simulated exam taken under real time conditions. Essential in the weeks before the actual test to identify weak areas and build exam stamina.

**SLO (scoring)** — NOT software-related here.
See: subscore requirement. Each section of JLPT must independently meet a minimum score.

**半額 (はんがく)**
Half price — a number-related vocabulary item that commonly appears in listening traps. 半額 = 50% off. Similar traps: 2割引 (20% off), 3割引 (30% off), 3倍 (three times), 倍 (double).

**迷惑受身 (めいわくうけみ)**
"Adversative passive." A Japanese passive construction where the subject is inconvenienced by someone else's action. 雨に降られた = I was caught in the rain (the rain inconvenienced me). The rain doesn't "act" on me in English, but in Japanese passive, it does.

**間接受身 (かんせつうけみ)**
"Indirect passive." The subject is affected by an action done to something they possess. 弟に日記を読まれた = my diary was read by my younger brother (I was negatively affected). The subject (I) didn't own the diary in English grammar, but the Japanese construction makes the possessor the subject.

**複合動詞 (ふくごうどうし)**
Compound verbs — two verb stems joined together. 書き直す = write + fix = rewrite. 飛び込む = jump + go in = jump into. N2 requires understanding a large number of these because the meaning isn't always predictable from the parts.
