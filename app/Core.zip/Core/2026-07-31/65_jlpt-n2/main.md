# JLPT N2 — Complete Core Reference

> **What this is:** Every core fact about JLPT N2 — format, scoring, vocabulary, grammar patterns,
> kanji, reading, listening — with examples for each grammar point. Study-ready reference.

---

## Exam Overview

```
Full name:    日本語能力試験 N2 (Nihongo Nōryoku Shiken N2)
Level:        Second highest of 5 levels (N1 > N2 > N3 > N4 > N5)
Who it's for: People who can understand Japanese in everyday and near-professional contexts
Administered: Japan Foundation / JEES — twice per year (July and December)

Required for:
  - Many Japanese university admissions
  - Many Japanese company job applications
  - Professional licensing in Japan (nursing, construction, etc.)
  - Visa categories requiring Japanese proficiency
```

---

## Test Format and Timing

```
┌─────────────────┬───────────────────┬──────────────┬──────────────────────────┐
│ Section         │ Content           │ Time         │ Questions                │
├─────────────────┼───────────────────┼──────────────┼──────────────────────────┤
│ 言語知識         │ Vocabulary        │ 105 minutes  │ ~35 questions            │
│ (言語知識・文法)  │ Grammar           │ (combined)   │ ~34 questions            │
│                 │ Reading           │              │ ~46 questions            │
├─────────────────┼───────────────────┼──────────────┼──────────────────────────┤
│ 聴解            │ Listening         │ 50 minutes   │ ~36 questions            │
└─────────────────┴───────────────────┴──────────────┴──────────────────────────┘

Total testing time: ~155 minutes
```

---

## Scoring

```
Maximum score:     180 points total
  言語知識 (vocabulary + grammar + reading): 0–120 points
  聴解 (listening):                          0–60 points

Passing score:     90 points total (50% of 180)

Subscores ALSO must pass individually:
  言語知識:  ≥ 19 points  (out of 120)
  聴解:     ≥ 19 points  (out of 60)

→ Even if total score ≥ 90, failing ONE subscore = overall FAIL
→ You MUST pass both subscores AND the total

Score reporting: A, B, C, or F
  A = top range
  B = mid range
  C = minimum pass
  F = fail
```

---

## Vocabulary Requirements

```
Words:   ~6,000 vocabulary items (cumulative N5–N2)
Kanji:   ~1,000 kanji (official guideline)
         (Many study resources list ~1,100–1,200 for practical coverage)
```

### Vocabulary Section Question Types

**問題1 — 漢字読み (Reading kanji words)**
Read the underlined kanji word and choose the correct reading.
```
例: 彼女は笑顔で部屋に入ってきた。
    笑顔の読み方は？
    1. えがお  2. わらいがお  3. えがた  4. わらお
    Answer: 1. えがお
```

**問題2 — 表記 (Kanji writing for a hiragana word)**
Choose the correct kanji for the underlined hiragana.
```
例: みんなの前でスピーチをするのはきんちょうする。
    きんちょうの漢字は？
    1. 緊張  2. 近調  3. 緊長  4. 勤張
    Answer: 1. 緊張
```

**問題3 — 語形成 (Word formation — compound words)**
Fill in the blank to complete a compound word.
```
例: ＿＿＿読み
    1. 一  2. 二  3. 黙  4. 音
    Answer: 3. 黙読み (もくどみ — silent reading)
```

**問題4 — 文脈規定 (Contextual definition)**
Choose the word that best fits the sentence context.
```
例: この映画は＿＿＿が高く、世界中で上映されている。
    1. 評判  2. 見当  3. 形成  4. 承知
    Answer: 1. 評判 (ひょうばん — reputation)
```

**問題5 — 言い換え類義 (Paraphrase / synonym)**
Choose the word closest in meaning to the underlined word.
```
例: 彼はいつもおだやかな話し方をする。
    おだやかと近い意味は？
    1. 温かい  2. 穏やかな  3. 正確な  4. 冷静な
    Answer: 2. 穏やかな → but if it's the same word, look for: 静かで落ち着いている
```

**問題6 — 用法 (Usage — which sentence uses the word correctly)**
Choose which of 4 sentences uses the underlined word correctly.
```
例: きちんと (properly, neatly)
    1. きちんと仕事をする  ← correct usage
    2. きちんと雨が降る   ← wrong (weather is not "neat")
```

---

## Grammar Section Question Types

**問題7 — 文の文法1 (Grammar in sentences)**
Fill in the blank with the correct grammar pattern.
```
例: もっと早く起きれば、電車に間に合った＿＿＿。
    1. ものだ  2. のに  3. だけ  4. ほど
    Answer: 2. のに (expressing regret)
```

**問題8 — 文の文法2 (Sentence composition)**
Rearrange 4 items into the correct order; one position is marked with ★.
This tests whether you understand how grammar patterns combine structurally.

**問題9 — 文章の文法 (Text grammar)**
A short passage with 5 blanks; choose the best word/expression for each.
Tests cohesive reading + grammar in context.

---

## Core N2 Grammar Patterns (Complete List with Examples)

### Group 1 — Expressing Reason / Cause

**〜ために / 〜ため**
Purpose or cause depending on whether the preceding verb is volitional or non-volitional.
```
Purpose:  健康のために毎日運動している。
          (I exercise every day for my health.)
Cause:    台風のために、試合が中止になった。
          (Due to the typhoon, the match was cancelled.)
```

**〜せいで / 〜せいか**
Blaming/negative cause.
```
彼のせいで計画が台無しになった。
(Because of him, the plan was ruined.)
寝不足のせいか、今日は集中できない。
(Maybe because of lack of sleep, I can't concentrate today.)
```

**〜おかげで / 〜おかげか**
Positive cause/thanks to.
```
先生のおかげで試験に合格できた。
(Thanks to my teacher, I passed the exam.)
```

**〜からこそ**
Precisely because / It's exactly because.
```
好きだからこそ、厳しく指導するんだ。
(It's precisely because I care that I give strict guidance.)
```

---

### Group 2 — Conditions and Hypotheticals

**〜さえ〜ば**
If only / as long as.
```
お金さえあれば、何でもできる。
(If only I had money, I could do anything.)
```

**〜さえ**
Even (used to emphasize an extreme or unexpected example).
```
子供でさえわかることだ。
(Even a child would understand this.)
```

**〜としたら / 〜とすれば / 〜とすると**
If we assume / supposing that.
```
あなたが社長だとしたら、どうしますか？
(If you were the president, what would you do?)
```

**〜にしたら / 〜にすれば / 〜にしてみれば**
From the perspective of / if you think about it from X's point of view.
```
子供にしてみれば、それは大きな問題だ。
(From the child's perspective, that is a serious problem.)
```

**〜ば〜ほど**
The more... the more.
```
練習すればするほど、上手になる。
(The more you practice, the better you get.)
```

**〜ないことには〜ない**
Unless / cannot...unless.
```
食べてみないことには、おいしいかどうかわからない。
(Unless you try eating it, you won't know if it's good.)
```

---

### Group 3 — Expressing Limits and Extent

**〜限り(は) / 〜かぎり**
As long as / to the best of one's ability.
```
私が知る限り、彼は嘘をついたことがない。
(As far as I know, he has never lied.)
生きている限り、夢を諦めない。
(As long as I'm alive, I won't give up on my dreams.)
```

**〜だけ**
Only / just / as much as.
```
できるだけ早く来てください。
(Please come as quickly as possible.)
```

**〜だけあって**
As expected of / it's only natural that (because of merit).
```
さすが先生だけあって、説明がわかりやすい。
(As expected of a teacher, the explanation is easy to understand.)
```

**〜だけに**
Precisely because / all the more because.
```
期待が大きかっただけに、失望も大きかった。
(All the more because expectations were high, the disappointment was great.)
```

**〜に過ぎない (にすぎない)**
Nothing more than / merely / only.
```
これは推測に過ぎない。
(This is nothing more than a guess.)
```

**〜ほど〜ない**
Not as... as / nothing is more... than.
```
日本語ほど難しい言語はない。
(There is no language as difficult as Japanese.)
```

---

### Group 4 — Expressing Degree / Extent

**〜ほど / くらい**
To the extent that / so much that.
```
泣きたいほど嬉しかった。
(I was so happy I wanted to cry.)
```

**〜次第 (しだい)**
Depending on / as soon as.
```
返事が来次第、連絡します。
(As soon as a reply comes, I will contact you.)
結果次第で、計画が変わる。
(Depending on the result, the plan will change.)
```

**〜に応じて (におうじて)**
In response to / according to / depending on.
```
需要に応じて生産量を調整する。
(We adjust production according to demand.)
```

---

### Group 5 — Expressing Change / Transformation

**〜になる / 〜くなる**
(Standard change expressions — N5 but N2 uses them in complex constructions)

**〜ようになる**
Come to be / reach the point where.
```
日本に来て、毎日日本語を話すようになった。
(After coming to Japan, I came to speak Japanese every day.)
```

**〜ことになる / 〜ことになっている**
It has been decided / it is a rule that.
```
来月から新しい仕事を始めることになった。
(It has been decided that I will start a new job next month.)
9時までに出社することになっている。
(It is a rule that we arrive at work by 9.)
```

**〜ていく / 〜てくる**
A change that moves away from / toward the speaker over time.
```
これからも勉強を続けていく。
(I will continue studying from now on — moving into the future.)
だんだん寒くなってきた。
(It has gradually become colder — approaching the present.)
```

---

### Group 6 — Expressing Concession (Despite / Even Though)

**〜にもかかわらず**
Despite / in spite of / regardless of.
```
雨にもかかわらず、試合は続いた。
(Despite the rain, the match continued.)
```

**〜ながら(も)**
Even though / although (contrast).
```
忙しいながらも、毎日運動している。
(Even though I'm busy, I exercise every day.)
```

**〜くせに / 〜くせして**
Even though / and yet (negative nuance, implies criticism).
```
わかっているくせに、なぜ何も言わないの？
(You know full well, so why don't you say anything?)
```

**〜ものの**
Although / even though (things didn't go as expected).
```
試験には合格したものの、就職には苦労した。
(Although I passed the exam, I struggled to find work.)
```

**〜とはいえ**
That said / even so / although it may be said that.
```
春とはいえ、まだ寒い日もある。
(That said, being spring, there are still cold days.)
```

**〜からといって**
Just because... doesn't mean...
```
お金があるからといって、幸せになれるわけではない。
(Just because you have money doesn't mean you'll be happy.)
```

---

### Group 7 — Expressing Purpose and Result

**〜ように**
So that / in order that (requesting or hoping for a state).
```
忘れないようにメモした。
(I took notes so that I wouldn't forget.)
早く良くなるようにお祈りしています。
(I'm praying that you get better soon.)
```

**〜ために**
In order to (purpose — with volitional verb).
```
医者になるために、一生懸命勉強した。
(I studied hard in order to become a doctor.)
```

**〜結果 (けっか)**
As a result of.
```
長年の研究の結果、新薬が開発された。
(As a result of years of research, a new drug was developed.)
```

**〜末(に) (すえ(に))**
After a long process / finally after.
```
長い議論の末、結論が出た。
(After a long discussion, a conclusion was reached.)
```

**〜あげく(に)**
After a lot of effort/trouble (often negative outcome).
```
散々悩んだあげく、やめることにした。
(After agonizing over it for a long time, I decided to quit.)
```

---

### Group 8 — Expressing Expectation / Presumption

**〜はずだ**
Should be / expected to be (strong expectation based on reason).
```
彼はもう着いているはずだ。
(He should be here already.)
```

**〜はずがない**
There is no way / cannot possibly be.
```
彼が嘘をつくはずがない。
(There's no way he would lie.)
```

**〜わけだ**
That explains it / which means / naturally.
```
彼は10年間日本にいたわけだから、日本語が上手なのは当然だ。
(Since he was in Japan for 10 years, it's natural that his Japanese is good.)
```

**〜わけではない / 〜わけじゃない**
It doesn't mean that / it's not that.
```
嫌いなわけではないが、得意でもない。
(It's not that I dislike it, but I'm not good at it either.)
```

**〜わけにはいかない**
Cannot afford to / must not (social obligation prevents it).
```
彼に頼まれたので、断るわけにはいかない。
(Since he asked me, I can't refuse.)
```

**〜にちがいない**
Must be / certainly (strong conviction).
```
あの光は UFO に違いない。
(That light must certainly be a UFO.)
```

**〜かねない**
Might well / there's a risk that (negative possibility).
```
このままでは失敗しかねない。
(At this rate, there's a risk we might fail.)
```

**〜かねる**
Find it difficult to / cannot bring oneself to.
```
その要求にはお答えしかねます。
(I find it difficult to answer that request. — polite refusal)
```

---

### Group 9 — Expressing Evaluation / Standards

**〜に対して (にたいして)**
Toward / against / in contrast to.
```
学生に対して丁寧に説明した。
(I explained carefully to the students.)
Aが増加しているのに対して、Bは減少している。
(While A is increasing, B is decreasing — contrast)
```

**〜について**
About / concerning / regarding.
```
この問題について話し合おう。
(Let's discuss this issue.)
```

**〜をめぐって**
Over (a contested issue) / centering around.
```
その政策をめぐって議論が続いている。
(Debate continues over that policy.)
```

**〜に関して / 〜に関する**
Regarding / concerning (more formal than について).
```
環境問題に関して、新しい法律が作られた。
(A new law was created regarding environmental issues.)
```

**〜において / 〜における**
In / at / in the context of (formal).
```
現代社会において、スマートフォンは必需品だ。
(In modern society, smartphones are a necessity.)
```

**〜によると / 〜によれば**
According to.
```
天気予報によると、明日は雨だそうだ。
(According to the weather forecast, it will rain tomorrow.)
```

**〜をもとに(して)**
Based on / drawing from.
```
このドラマは実話をもとに作られた。
(This drama was made based on a true story.)
```

---

### Group 10 — Expressing Addition / Listing

**〜うえに**
In addition to / on top of that (both positive or both negative).
```
彼は頭がいいうえに、努力家でもある。
(In addition to being smart, he is also hardworking.)
```

**〜に加えて**
In addition to / on top of.
```
技術力に加えて、コミュニケーション能力も必要だ。
(In addition to technical skills, communication ability is also necessary.)
```

**〜ばかりか〜(も)**
Not only... but also (stronger than だけでなく).
```
彼女は歌が上手なばかりか、演技も素晴らしい。
(Not only is she a good singer, but her acting is also wonderful.)
```

**〜はもちろん / 〜はもとより**
Of course / needless to say / not to mention.
```
日本語はもちろん、英語も話せる。
(Needless to say Japanese, she can also speak English.)
```

---

### Group 11 — Expressing Contrast / Parallel

**〜一方(で) (いっぽう)**
On the other hand / while / at the same time.
```
仕事は楽しい一方、責任も重い。
(While work is enjoyable, the responsibility is also heavy.)
経済が成長している一方で、貧富の差も広がっている。
(While the economy is growing, the gap between rich and poor is also widening.)
```

**〜とともに**
Together with / along with / as.
```
時代とともに、生活スタイルも変化してきた。
(Along with the times, lifestyle has also changed.)
```

**〜に反して (にはんして)**
Contrary to / against (expectations, rules, desires).
```
予想に反して、試験は簡単だった。
(Contrary to expectations, the exam was easy.)
```

---

### Group 12 — Expressing Appearance / Resemblance

**〜ようだ / 〜ようで**
Seems like / appears to (based on observation).
```
外は雨が降っているようだ。
(It seems like it's raining outside.)
```

**〜らしい**
Apparently / it seems (based on indirect evidence or hearsay).
```
田中さんは転職するらしい。
(It seems Tanaka is going to change jobs.)
```

**〜らしい (典型的 — typical of)**
Typical of / that's very characteristic of.
```
さすが日本人らしい礼儀正しさだ。
(That's very characteristic Japanese politeness.)
```

**〜そうだ (様態 — appearance)**
Looks like / seems about to (based on visual appearance).
```
空が暗くなって、雨が降りそうだ。
(The sky has gotten dark; it looks like it's going to rain.)
```

**〜に見える**
Looks / appears to be (visual).
```
彼は実際より若く見える。
(He looks younger than he actually is.)
```

---

### Group 13 — Expressing Passive, Causative, Potential (Advanced Use)

**〜させてもらう / 〜させていただく**
Humbly do something with permission (keigo).
```
発表させていただきます。
(I would like to give a presentation — lit. humbly do so with your permission.)
```

**〜てもらう / 〜ていただく**
Have someone do something for oneself.
```
先生に添削していただいた。
(I had the teacher correct [my work].)
```

**受身 (Passive voice) key patterns:**
```
迷惑受身:  雨に降られた。(I was caught in the rain — adversative passive)
間接受身:  弟に日記を読まれた。(My diary was read by my younger brother — indirect passive)
```

---

### Group 14 — Expressing Scope / Relative Range

**〜しか〜ない**
Only / nothing but (with negative verb — emphasizes restriction).
```
あと30分しかない。
(There are only 30 minutes left.)
```

**〜だけでなく〜も**
Not only... but also.
```
英語だけでなく、フランス語も話せる。
(She can speak not only English but also French.)
```

**〜をはじめ(として)**
Starting with / beginning with / including especially.
```
社長をはじめとして、全員が出席した。
(Beginning with the president, everyone attended.)
```

---

### Group 15 — Expressing Time Relationships

**〜て以来 (ていらい)**
Since (a point in time — continuing state).
```
日本に来て以来、ずっと東京に住んでいる。
(Since coming to Japan, I have been living in Tokyo.)
```

**〜たとたん(に)**
The moment / just as (immediately after).
```
ドアを開けたとたん、猫が飛び出した。
(The moment I opened the door, the cat jumped out.)
```

**〜ながら**
While (simultaneous actions) / although (concession — see Group 6).
```
音楽を聴きながら勉強する。
(I study while listening to music.)
```

**〜てからでないと / 〜てからでなければ**
Not until after.
```
準備が終わってからでないと、始められない。
(We cannot start until the preparation is finished.)
```

**〜うちに**
While / before (a situation changes).
```
若いうちに、いろいろな経験をしたほうがいい。
(While you are young, it is better to have various experiences.)
熱いうちに食べてください。
(Please eat it while it's hot.)
```

---

### Group 16 — Formal / Written Style Expressions

**〜において (formal: in / at)**
```
この点において、両者の意見が一致した。
(On this point, both parties' opinions agreed.)
```

**〜に際して (にさいして — on the occasion of)**
```
入学に際して、準備しておくことがある。
(There are things to prepare for at the occasion of enrollment.)
```

**〜に当たって (にあたって — upon doing)**
```
新年を迎えるに当たって、目標を立てた。
(Upon welcoming the new year, I set goals.)
```

**〜にわたって / 〜にわたる**
Spanning / over (a range of time or space).
```
3日間にわたって会議が行われた。
(The conference was held over 3 days.)
全国にわたる調査が実施された。
(A survey spanning the entire country was conducted.)
```

**〜を通じて / 〜を通して**
Through / throughout / via.
```
インターネットを通じて情報を集める。
(Gather information through the internet.)
一年を通じて温暖な気候だ。
(It has a warm climate throughout the year.)
```

**〜に基づいて (にもとづいて)**
Based on / in accordance with.
```
データに基づいて判断する。
(Make judgments based on data.)
```

---

### Group 17 — Key Keigo (Polite Language) at N2 Level

**Sonkeigo (尊敬語 — honorific)**
```
いる → いらっしゃる    (to be/exist)
行く → いらっしゃる/おいでになる  (to go)
来る → いらっしゃる/おいでになる  (to come)
言う → おっしゃる      (to say)
食べる/飲む → 召し上がる  (to eat/drink)
する → なさる          (to do)
知る → ご存じ          (to know)
もらう → お受け取りになる (to receive)
```

**Kenjōgo (謙譲語 — humble)**
```
いる → おる           (to be/exist — humble)
行く → 参る / うかがう  (to go)
来る → 参る / うかがう  (to come)
言う → 申す           (to say)
食べる/飲む → いただく  (to eat/drink)
する → いたす          (to do)
知る → 存じる / 存じ上げる (to know)
もらう → いただく / 頂戴する (to receive)
見る → 拝見する        (to see/look)
訪ねる → うかがう / お邪魔する (to visit)
あげる → 差し上げる     (to give — to social superior)
```

**Teineigo (丁寧語 — polite neutral)**
```
〜です / 〜ます / 〜ございます
```

---

## Reading Section

```
Passage types in order of appearance:
  問題10: 中文読解 (medium-length passage, ~500 chars) — comprehension Qs
  問題11: 長文読解 (long passage, ~800 chars) — comprehension Qs
  問題12: 統合理解 (integrated comprehension — compare 2 texts)
  問題13: 長文読解 (information-based long passage)
  問題14: 情報検索 (information retrieval — ads, schedules, notices)
```

### Reading Strategy

```
1. Read the question FIRST → know what to look for
2. Skim for structure: introduction → main point → examples → conclusion
3. Key signal words:
   しかし / でも / ところが = contrast (important shift)
   つまり / すなわち     = conclusion/summary
   また / さらに         = addition
   たとえば / 例えば     = example
   一方 / 他方           = contrast / other side
   なぜなら              = reason follows
   ゆえに / したがって   = therefore (formal)
4. Author's opinion is usually in the last paragraph
5. For 情報検索: scan for specific data (dates, prices, conditions)
```

---

## Listening Section

```
問題1: 課題理解 — What should the person do? (5 items)
問題2: ポイント理解 — What is the key point? (6 items)
問題3: 概要理解 — What is the overall idea? (5 items)
問題4: 即時応答 — Short Q&A, choose the best response (12 items)
問題5: 統合理解 — Listen to longer content, answer multiple questions (4 items)
```

### Listening Strategy

```
1. Read the question during the preparation time before audio plays
2. 問題1, 2: focus on what the person should do or the main fact
3. 問題3: wait until the whole audio ends — the conclusion is the answer
4. 問題4: most common traps are:
   - Accepting something you should refuse
   - Agreeing with incorrect assumption
   - Answering a different question than asked
5. Number-related traps: 半額/2割引/3倍 — calculate during listening
```

---

## High-Frequency N2 Vocabulary Categories

### Time and Change
```
急速に (きゅうそくに)    rapidly
徐々に (じょじょに)      gradually
依然として (いぜんとして) still / as before
かつて                    formerly / once
たちまち                  instantly / in no time
いずれ                    eventually / some day
```

### Degree and Quantity
```
ほぼ          approximately / almost
わずか        only / merely / just a little
かなり        considerably / fairly
相当 (そうとう) considerable / quite
著しく (いちじるしく) remarkably / notably
一層 (いっそう) even more / all the more
```

### Abstract / Academic Vocabulary
```
課題 (かだい)      issue / task / assignment
根拠 (こんきょ)    basis / grounds / evidence
観点 (かんてん)    viewpoint / standpoint
背景 (はいけい)    background / context
要因 (よういん)    factor / cause
結果 (けっか)      result
影響 (えいきょう)  influence / effect
過程 (かてい)      process
目的 (もくてき)    purpose / objective
手段 (しゅだん)    means / method
```

### Verbs (Key N2 Verbs)
```
把握する (はあくする)   to grasp / understand fully
促す (うながす)        to urge / encourage / promote
妨げる (さまたげる)    to hinder / obstruct
依頼する (いらいする)  to request / commission
提案する (ていあんする) to propose / suggest
判断する (はんだんする) to judge / determine
確認する (かくにんする) to confirm / verify
検討する (けんとうする) to examine / consider
改善する (かいぜんする) to improve
維持する (いじする)    to maintain / keep up
```

### Adjectives and i-adjectives
```
わずらわしい   troublesome / annoying
もったいない   wasteful / what a waste
ものたりない   unsatisfying / leaving something to be desired
頼もしい (たのもしい)  reliable / dependable (person)
めまぐるしい   dizzying / rapid (change)
やむを得ない   unavoidable / can't be helped
```

---

## Key N2 Kanji Groups

### Business / Work
```
就職 (しゅうしょく)   finding a job
昇進 (しょうしん)    promotion
給与 (きゅうよ)      salary / pay
退職 (たいしょく)    retirement / resignation
雇用 (こよう)        employment
契約 (けいやく)      contract
```

### Society / News
```
政策 (せいさく)    policy
制度 (せいど)      system / institution
措置 (そち)        measures / steps
議論 (ぎろん)      argument / debate
批判 (ひはん)      criticism
主張 (しゅちょう)  claim / assertion / insistence
```

### Human Relations / Psychology
```
信頼 (しんらい)    trust
尊重 (そんちょう)  respect
配慮 (はいりょ)    consideration / thoughtfulness
感謝 (かんしゃ)    gratitude
謝罪 (しゃざい)    apology
誤解 (ごかい)      misunderstanding
```

### Nature / Environment
```
環境 (かんきょう)   environment
汚染 (おせん)      pollution / contamination
節約 (せつやく)    saving / conservation
再生 (さいせい)    regeneration / recycling
被害 (ひがい)      damage / harm
防止 (ぼうし)      prevention
```

---

## Common N2 Compound Verb Patterns

```
〜直す (なおす)    redo / redo correctly  書き直す = rewrite
〜込む (こむ)      into / intensely      飛び込む = jump in / 込み合う = be crowded
〜出す (だす)      begin / outward       走り出す = start running / 取り出す = take out
〜上げる (あげる)  upward / complete     仕上げる = finish / 積み上げる = pile up
〜合う (あう)      mutually             話し合う = discuss / 助け合う = help each other
〜抜く (ぬく)      through / to the end  やり抜く = carry through / 走り抜く = run through
〜続ける (つづける) continue             読み続ける = keep reading
〜始める (はじめる) begin               降り始める = begin to rain/snow
```

---

## Common N2 Errors and Traps

### Grammar Traps
```
わけにはいかない vs わけではない:
  わけにはいかない = cannot afford to (obligation)
  わけではない     = it doesn't mean that (denial)

ために vs ように:
  ために = intentional purpose (volitional: 食べるために行く)
  ように = non-volitional purpose / so that a state results (忘れないように書く)

ものだ vs ものの:
  ものだ  = used to / it is natural that / should
  ものの  = although / even though (concessive)

はずだ vs わけだ:
  はずだ = expectation based on logic
  わけだ = natural conclusion / it explains things

らしい vs ようだ vs そうだ:
  らしい  = hearsay / indirect evidence / typical of
  ようだ  = seems / appears (based on direct observation)
  そうだ  = hearsay (info from someone else) OR looks like (based on appearance)
```

### Vocabulary Traps
```
以上 (いじょう) vs 以外 (いがい):
  以上 = more than / above / that's all
  以外 = except / other than

見当 (けんとう) vs 検討 (けんとう):  (same reading, different kanji)
  見当 = rough guess / direction → 見当がつかない = can't even guess
  検討 = consideration / examination → 検討する = to examine/consider

〜的 (てき) suffix:
  科学的 = scientific
  積極的 = proactive / positive
  消極的 = passive / negative
  具体的 = concrete / specific
  抽象的 = abstract
```

---

## Study Plan Framework

```
PHASE 1 — Foundation (Weeks 1–4)
  Kanji: 30 new kanji/day using Anki + JLPT Kanji Workbook
  Grammar: 3–4 grammar patterns/day with example sentences (write your own)
  Vocabulary: 20 new words/day with context sentences

PHASE 2 — Integration (Weeks 5–8)
  Reading: 1 N2 reading passage/day timed (10 min per medium, 15 min per long)
  Listening: 1 full N2 listening section/day
  Mock vocab/grammar: 30-question timed practice daily

PHASE 3 — Exam Simulation (Weeks 9–12)
  Full mock exam: 1 complete exam per week (timed exactly as real exam)
  Review all wrong answers immediately — categorize error type
  Focus on weakest section for additional daily practice
  Day before exam: review grammar list only (no new material)

Resources:
  Grammar:     新完全マスター N2 文法 (Shin Kanzen Master)
  Vocabulary:  新完全マスター N2 語彙 (Shin Kanzen Master)
  Kanji:       新完全マスター N2 漢字
  Reading:     新完全マスター N2 読解
  Listening:   新完全マスター N2 聴解
  Mock tests:  JLPT公式問題集 N2 (official practice)
  App:         Anki (SRS for kanji + vocab)
```

---

## Quick Score Targets

```
To safely pass with buffer:
  Vocabulary section:  aim for 65% correct (21/35 approx)
  Grammar section:     aim for 65% correct (22/34 approx)
  Reading section:     aim for 60% correct (28/46 approx)
  Listening:           aim for 65% correct (24/36 approx)

Raw score equivalent:
  Passing minimum: 90/180 (50%) with both subscores ≥ 19
  Safe target:     120+/180 (67%)
  Comfortable:     140+/180 (78%)
```
