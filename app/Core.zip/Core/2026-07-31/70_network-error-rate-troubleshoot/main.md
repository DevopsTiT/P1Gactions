# High Network Error Rate — SRE Troubleshooting Deep Dive

---

## Baselines & Alert Thresholds

```
Normal:          < 0.01%   (1 error per 10,000 packets)
Warning:         0.1–0.5%  (investigate — likely early congestion or config drift)
Alert fires:     0.5–1%    (service-dependent — see table below)
Critical/page:   > 1%      (active user impact almost certain)
```

Per-service threshold guidance:

| Service Type | Alert At | Page At | Reason |
|---|---|---|---|
| Payment API | 0.3% | 0.7% | Every error = failed transaction |
| Internal gRPC | 0.5% | 1% | Retries absorb some errors |
| Batch / async | 1% | 3% | Retries and queues mask impact |
| DNS / discovery | 0.1% | 0.3% | Single failure cascades widely |
| Health check endpoint | 0.5% | 1% | False positives cause restarts |

---

## E2E Troubleshooting Flow

```
Alert fires: network error rate > threshold
        │
        ▼
Step 1: LOCATE ── Which node / pod / direction is affected?
        │         (single node = hardware/SG; cluster-wide = MTU/congestion)
        │
        ▼
Step 2: CLASSIFY ── What type of error?
        │   TX errors → NIC hardware or driver
        │   RX drops  → congestion / buffer overflow
        │   ICMP unreachable → security group / routing
        │   Fragmentation → MTU mismatch
        │
        ▼
Step 3: ROOT CAUSE ── Pick the matching branch below
        │
        ├── Network congestion    (Part 2)
        ├── MTU mismatch          (Part 3)
        ├── Security group issue  (Part 4)
        ├── NIC hardware failure  (Part 5)
        └── VPC ENI flow limits   (Part 6)
        │
        ▼
Step 4: FIX & VERIFY ── Apply fix, confirm error rate returns to < 0.01%
```

---

## Part 1 — First Triage Commands (Run These Before Anything Else)

These are read-only. Run them immediately when the alert fires to gather context.

```bash
# ── 1. See error counters on ALL interfaces on the node ──────────────────
ip -s link show
# Key fields:
#   RX: errors  dropped  overrun
#   TX: errors  dropped  carrier  collisions
# Any non-zero TX errors or RX drops → go to Part 5 (NIC) or Part 2 (congestion)

# ── 2. Watch counters update in real time (1-second intervals) ────────────
watch -n1 "ip -s link show eth0"
# If counters are actively growing → problem is happening NOW

# ── 3. Detailed per-interface statistics ─────────────────────────────────
cat /proc/net/dev
# Shows running totals since boot for all interfaces

# ── 4. Kernel network statistics — drops, buffer overflows ───────────────
netstat -s 2>/dev/null || ss -s
# Look for:
#   "packets pruned from receive queue" → RX buffer overflow (congestion)
#   "segments retransmitted" → TCP layer seeing errors
#   "failed connection attempts"
#   "resets received"

# ── 5. ethtool — hardware-level NIC statistics ───────────────────────────
sudo ethtool -S eth0 2>/dev/null | grep -iE "error|drop|miss|fail|bad|crc|fragment"
# Non-zero values here = hardware / driver level errors
# CRC errors → cable or NIC hardware problem
# rx_missed_errors → CPU can't drain RX ring fast enough (congestion)

# ── 6. Which pods on this node are generating traffic? ───────────────────
kubectl get pods --all-namespaces \
  -o wide --field-selector spec.nodeName=$(hostname) \
  | sort -k4

# ── 7. Node resource pressure check ─────────────────────────────────────
kubectl describe node $(hostname) | grep -A10 "Conditions:\|Allocatable:\|Allocated"
# Look for: NetworkUnavailable, MemoryPressure, DiskPressure

# ── 8. Recent kernel messages about network ───────────────────────────────
sudo dmesg --ctime | grep -iE "eth|eni|network|neterr|dropped|reset|timeout|mtu" | tail -30
# NAPI errors, NIC resets, driver warnings all appear here

# ── 9. Is this one node or many? ─────────────────────────────────────────
kubectl top nodes
# If one node is CPU-maxed → likely that node's NIC is overwhelmed
# Compare error rates across nodes in Dynatrace:
#   Infrastructure → Hosts → compare "Network errors" metric across all nodes
```

---

## Part 2 — Network Congestion (Node Saturated, Packets Dropped at NIC)

### What It Looks Like

```
Symptoms:
  ip -s link: RX dropped climbing rapidly
  ethtool -S: rx_missed_errors, rx_no_buffer_count, rx_fifo_errors > 0
  kubectl top node: CPU at 90%+  OR  network bandwidth near instance limit
  Dynatrace: Network errors AND high CPU AND high network throughput all at once
  Application: timeouts, retries, increased latency — not hard failures
```

### Why It Happens

Every NIC has a ring buffer — a small circular memory area where incoming packets
wait before the kernel processes them. When the CPU is too busy to drain the ring
buffer, new packets have nowhere to go and are silently dropped.

```
Packets arrive → NIC ring buffer → kernel driver drains → TCP stack → app
                      ↑
             IF CPU too busy to drain:
             new packets dropped here → RX drops increment
```

### Diagnosis Commands

```bash
# Check CPU steal / interrupt time (time spent handling NIC interrupts)
mpstat -P ALL 1 5
# HIGH %irq or %softirq on one CPU core = that core is overwhelmed by NIC interrupts
# Solution: spread NIC IRQs across more cores (see fix below)

# Check which CPU cores handle eth0 interrupts
cat /proc/interrupts | grep eth0
# If all interrupt counts are on CPU 0 → single-core bottleneck

# Check NIC ring buffer size (current vs max)
sudo ethtool -g eth0
# Output:
#   Ring parameters for eth0:
#   Pre-set maximums:
#     RX: 4096
#   Current hardware settings:
#     RX: 256      ← if much less than max, this is your problem
# Fix: sudo ethtool -G eth0 rx 4096

# Check network bandwidth utilization
sar -n DEV 1 10
# rxkB/s and txkB/s columns — compare against instance type limit
# t3.medium: 5 Gbps = ~625 MB/s
# c5.large: 10 Gbps = ~1250 MB/s
# If you're at 80%+ of the limit → bandwidth saturation

# Check TCP retransmissions (symptom of dropped packets at receiver)
ss -ti | grep retrans
# OR
nstat | grep RetransSegs
```

### Fix — Congestion

```bash
# Fix 1: Increase NIC ring buffer (immediate, survives reboot with tuned-adm)
sudo ethtool -G eth0 rx 4096 tx 4096

# Fix 2: Spread NIC IRQs across all CPU cores (IRQ balancing)
# Check current IRQ affinity
cat /proc/irq/$(grep eth0 /proc/interrupts | awk '{print $1}' | tr -d :)/smp_affinity
# Set to all CPUs (bitmask ffffff = all 24 cores)
echo "ffffff" | sudo tee /proc/irq/$(grep eth0 /proc/interrupts | awk '{print $1}' | tr -d :)/smp_affinity

# Fix 3: Enable irqbalance daemon (automatic IRQ spreading)
sudo systemctl enable --now irqbalance

# Fix 4: Increase kernel receive buffer
sudo sysctl -w net.core.rmem_max=134217728
sudo sysctl -w net.core.rmem_default=65536
sudo sysctl -w net.ipv4.tcp_rmem="4096 87380 134217728"
# Make permanent:
echo "net.core.rmem_max=134217728" | sudo tee -a /etc/sysctl.d/99-network.conf
sudo sysctl -p /etc/sysctl.d/99-network.conf

# Fix 5 (Kubernetes): If one pod is the culprit, add network rate limits
# Edit the deployment to add resource limits:
kubectl patch deployment payment-service -n payment-ns --type=json -p='[
  {"op":"add","path":"/spec/template/spec/containers/0/resources/limits",
   "value":{"memory":"512Mi","cpu":"500m"}}
]'

# Fix 6 (AWS): Move to a larger instance type with more network bandwidth
# t3.medium: 5 Gbps  →  m5.xlarge: 10 Gbps  →  c5.2xlarge: up to 10 Gbps
# Check current instance type
curl -s http://169.254.169.254/latest/meta-data/instance-type
```

---

## Part 3 — MTU Mismatch (Packets Too Large → Fragmentation → Drops)

### What It Looks Like

```
Symptoms:
  ip -s link: TX errors or RX dropped only for LARGE packets
  ping works fine with small packets, fails/fragments with large ones
  ethtool -S: tx_errors incrementing — NOT rx_drops
  Application: works for small requests, fails for large payloads
  Common in: VPN tunnels, VXLAN overlays, AWS VPC with jumbo frames
```

### The MTU Problem Explained

```
Standard Ethernet MTU:       1500 bytes
AWS VPC jumbo frames:        9001 bytes  (if enabled)
VXLAN overlay (Flannel/Calico): 1450 bytes (adds 50 bytes of tunnel header)
AWS VPN / Direct Connect:    1400–1450 bytes

If a pod tries to send a 1500-byte packet through a VXLAN tunnel:
  1500 (payload) + 50 (VXLAN header) = 1550 bytes > 1500 MTU → DROPPED
  If DF bit set: ICMP "fragmentation needed" sent back
  If DF bit not set: packet fragmented → performance hit + possible drops
```

### Diagnosis Commands

```bash
# Check current MTU on all interfaces
ip link show
# Look for: mtu 1500  or  mtu 9001  or  mtu 1450
# Different MTUs on same path = mismatch

# Test with large packet (don't fragment flag = -M do, size = 1472 + 28 header = 1500)
ping -c 5 -M do -s 1472 <destination-ip>
# If this FAILS but small ping succeeds → MTU mismatch confirmed

# Binary search for the actual MTU of the path
ping -c 3 -M do -s 1400 <destination-ip>  # pass?
ping -c 3 -M do -s 1450 <destination-ip>  # pass?
ping -c 3 -M do -s 1472 <destination-ip>  # fail?
# Work up/down to find the exact boundary

# Check for ICMP fragmentation-needed messages in kernel
sudo dmesg | grep -i "frag\|mtu\|pmtu"

# Check PMTU (Path MTU Discovery) cache
ip route show cache | grep mtu
# Shows cached MTU for specific destinations

# Check Kubernetes CNI MTU setting
# For Calico:
kubectl get configmap calico-config -n kube-system -o yaml | grep mtu
# For Flannel:
kubectl get configmap kube-flannel-cfg -n kube-system -o yaml | grep MTU

# Check pod's actual MTU
kubectl exec -n payment-ns <pod-name> -- ip link show eth0
# Should match CNI configuration

# Verify fragmentation counters on the NIC
cat /proc/net/snmp | grep Ip
# "Ip: InHdrErrors" → bad IP headers (possibly from fragments)
# "Ip: ReasmFails" → fragment reassembly failing

# AWS-specific: check if jumbo frames are enabled on the VPC
aws ec2 describe-network-interfaces \
  --network-interface-ids $(curl -s http://169.254.169.254/latest/meta-data/network/interfaces/macs/$(curl -s http://169.254.169.254/latest/meta-data/network/interfaces/macs/ | head -1)/interface-id) \
  --query 'NetworkInterfaces[0].{MTU:Description,Status:Status}'
```

### Fix — MTU Mismatch

```bash
# Fix 1: Set interface MTU to match the network path
# If using VXLAN overlay → reduce pod MTU to 1450
sudo ip link set eth0 mtu 1450
# Make permanent via /etc/network/interfaces or cloud-init

# Fix 2: For Calico CNI — set correct MTU
kubectl patch configmap calico-config -n kube-system --type=merge -p '
{
  "data": {
    "veth_mtu": "1450"
  }
}'
# Then restart Calico pods
kubectl rollout restart daemonset calico-node -n kube-system

# Fix 3: For Flannel — set correct MTU in the ConfigMap
kubectl edit configmap kube-flannel-cfg -n kube-system
# Change: "Backend": {"Type":"vxlan","VNI":1,"Port":8472,"MTU":1450}

# Fix 4: Enable jumbo frames on the entire VPC path (AWS)
# All instances on the path must support jumbo frames
# Instance must be in a VPC with jumbo frames (most do, default 9001)
sudo ip link set eth0 mtu 9001  # only if all hops support 9001

# Fix 5: Clamp TCP MSS to handle mismatches without changing MTU
# This tells TCP to use smaller maximum segment sizes to avoid fragmentation
sudo iptables -t mangle -A FORWARD \
  -p tcp --tcp-flags SYN,RST SYN \
  -j TCPMSS --clamp-mss-to-pmtu
# Verify:
sudo iptables -t mangle -L FORWARD -n -v | grep TCPMSS
```

---

## Part 4 — Security Group Issue (SG Blocking Traffic → Packets Rejected)

### What It Looks Like

```
Symptoms:
  Specific port/protocol fails while others work
  netstat / ss shows SYN_SENT but no SYN_ACK → connection never completes
  ip -s link: TX packets sent, but RX drops or nothing comes back
  VPC Flow Logs: REJECT entries for your service's port
  Application: connection refused or connection timeout (not retransmit)
  Pattern: started after a deployment or SG rule change
```

### Diagnosis Commands

```bash
# ── Check connectivity to a specific port ────────────────────────────────
nc -zv <destination-ip> 8080
# "succeeded" = port reachable
# "Connection refused" = port exists but nothing listening (app, not SG)
# (hangs with no output) = SG blocking → packets silently dropped

# ── Trace TCP connection attempt ─────────────────────────────────────────
sudo tcpdump -n -i eth0 host <destination-ip> and port 8080 -c 20
# If you see: SYN sent but no SYN-ACK received → remote SG blocking
# If you see: SYN + RST immediately → connection refused (not SG)
# If you see nothing: local SG may be blocking outbound

# ── Check VPC Flow Logs for REJECT records ───────────────────────────────
# In CloudWatch Logs — search for your instance's IP with REJECT action
aws logs filter-log-events \
  --log-group-name /aws/vpc/flowlogs \
  --filter-pattern '"REJECT" "<your-pod-ip>"' \
  --start-time $(date -d '30 minutes ago' +%s000) \
  --output json | jq '.events[].message' | head -20
# Flow log format: version account-id interface-id srcaddr dstaddr srcport dstport protocol packets bytes start end action

# ── List current security group rules for this instance ──────────────────
# Get instance's security groups
INSTANCE_ID=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
SG_IDS=$(aws ec2 describe-instances \
  --instance-ids $INSTANCE_ID \
  --query 'Reservations[0].Instances[0].SecurityGroups[*].GroupId' \
  --output text)
echo "Security groups: $SG_IDS"

# Check inbound rules for each SG
for SG in $SG_IDS; do
  echo "=== Rules for $SG ==="
  aws ec2 describe-security-groups \
    --group-ids $SG \
    --query 'SecurityGroups[0].IpPermissions[*].{Port:FromPort,Protocol:IpProtocol,Source:IpRanges[0].CidrIp}' \
    --output table
done

# ── Check if the SG allows traffic FROM the calling service ──────────────
# If pod A (10.0.1.5) can't reach pod B (10.0.2.10:8080):
aws ec2 describe-security-groups \
  --filters "Name=ip-permission.from-port,Values=8080" \
  --query 'SecurityGroups[*].{ID:GroupId,Name:GroupName,Rules:IpPermissions}' \
  --output json

# ── Kubernetes Network Policy check ──────────────────────────────────────
# K8s NetworkPolicies can block traffic independently of AWS SGs
kubectl get networkpolicies -n payment-ns
kubectl describe networkpolicy <policy-name> -n payment-ns
# Look for: which pods are selected, what ingress/egress is allowed

# ── Test with a debug pod in the same namespace ───────────────────────────
kubectl run debug-pod --image=nicolaka/netshoot \
  --rm -it --restart=Never -n payment-ns -- \
  curl -v http://payment-service:8080/health
# If this fails but curl from outside works → NetworkPolicy is blocking
```

### Fix — Security Group Issue

```bash
# Fix 1: Add missing ingress rule via AWS CLI
aws ec2 authorize-security-group-ingress \
  --group-id sg-0abc123def \
  --protocol tcp \
  --port 8080 \
  --cidr 10.0.0.0/8   # allow from internal VPC range
# OR allow from a specific SG (better than CIDR):
aws ec2 authorize-security-group-ingress \
  --group-id sg-0abc123def \
  --protocol tcp \
  --port 8080 \
  --source-group sg-0caller123

# Fix 2: Add via Terraform (the correct long-term fix)
# Add to security group resource:
# ingress {
#   from_port       = 8080
#   to_port         = 8080
#   protocol        = "tcp"
#   security_groups = [aws_security_group.caller.id]
# }
# Then: terraform plan && terraform apply

# Fix 3: Fix Kubernetes NetworkPolicy (if that's the blocker)
kubectl apply -f - <<'EOF'
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: allow-payment-ingress
  namespace: payment-ns
spec:
  podSelector:
    matchLabels:
      app: payment-service
  policyTypes:
    - Ingress
  ingress:
    - from:
        - namespaceSelector:
            matchLabels:
              team: checkout   # allow checkout namespace to call payment
      ports:
        - protocol: TCP
          port: 8080
EOF

# Verify after fix:
nc -zv <destination-ip> 8080
# Should now succeed
```

---

## Part 5 — NIC Hardware Issue (Physical Packet Errors)

### What It Looks Like

```
Symptoms:
  ethtool -S: CRC errors, bad_length, rx_crc_errors, tx_aborted_errors > 0
  ip -s link: TX errors (not just drops) incrementing
  dmesg: NIC driver errors, device resets, "Link is Down/Up" oscillation
  AWS: likely EC2 hardware failure — AWS detects and reports this
  Pattern: errors on ONE specific node/instance, others fine
  NOT related to load — errors happen even at low traffic
```

### Diagnosis Commands

```bash
# ── Hardware-level error counters ────────────────────────────────────────
sudo ethtool -S eth0 | grep -iE "error|bad|crc|reset|abort|carrier|collision|fifo"
# Key bad fields:
#   rx_crc_errors:       cable/connector fault or NIC hardware dying
#   tx_aborted_errors:   NIC giving up on transmission — hardware issue
#   rx_missed_errors:    CPU couldn't drain RX ring (also seen in congestion)
#   rx_length_errors:    received packets with wrong size — NIC or driver bug

# ── Kernel ring messages for NIC events ──────────────────────────────────
sudo dmesg --ctime | grep -iE "eth0|ena|ixgbe|link|reset|down|error" | tail -40
# ena = AWS Elastic Network Adapter driver
# "Link is Down" / "Link is Up" cycling → NIC instability
# "device reset" → driver is resetting the NIC (usually hardware fault)

# ── NIC driver and firmware info ─────────────────────────────────────────
sudo ethtool -i eth0
# driver: ena  (AWS) or ixgbe (10G Intel) or vmxnet3 (VMware)
# version: 2.8.0
# firmware-version: (may show outdated firmware)

# ── AWS instance health check (gold standard for hardware issues) ─────────
INSTANCE_ID=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
aws ec2 describe-instance-status \
  --instance-ids $INSTANCE_ID \
  --query 'InstanceStatuses[0].{
    InstanceStatus: InstanceStatus.Status,
    SystemStatus: SystemStatus.Status,
    Events: Events
  }' \
  --output json
# SystemStatus: "impaired" → AWS hardware problem detected
# Events: scheduled maintenance, reboot, retirement

# ── Check if instance retirement is scheduled ────────────────────────────
aws ec2 describe-instance-status \
  --instance-ids $INSTANCE_ID \
  --query 'InstanceStatuses[0].Events' \
  --output json
# code: "instance-retirement" → AWS is retiring the hardware under this instance

# ── Compare error rate across all nodes ──────────────────────────────────
# In Dynatrace: Infrastructure → Hosts → All hosts
# Sort by "Network errors/s" — one outlier node = NIC hardware issue
# Cluster-wide = not hardware (MTU/SG/congestion)
```

### Fix — NIC Hardware Issue

```bash
# Fix 1: Drain the node (stop new pods scheduling there)
NODE_NAME=$(kubectl get pod <pod-name> -n payment-ns -o jsonpath='{.spec.nodeName}')
kubectl cordon $NODE_NAME
# "cordoned" = no new pods scheduled here

# Fix 2: Evict existing pods gracefully
kubectl drain $NODE_NAME \
  --ignore-daemonsets \
  --delete-emptydir-data \
  --grace-period=60
# Pods move to healthy nodes; service continues

# Fix 3: Stop the EC2 instance (for AWS hardware replacement)
# AWS replaces underlying hardware on START of a STOPPED instance
aws ec2 stop-instances --instance-ids $INSTANCE_ID
# Wait until stopped:
aws ec2 wait instance-stopped --instance-ids $INSTANCE_ID
# Start on new hardware:
aws ec2 start-instances --instance-ids $INSTANCE_ID
aws ec2 wait instance-running --instance-ids $INSTANCE_ID

# Fix 4: If instance is NOT in an ASG — replace manually
# Launch replacement, verify it's healthy, terminate the broken one

# Fix 5: Uncordon after hardware replacement and verification
kubectl uncordon $NODE_NAME
# Verify NIC is clean:
sudo ethtool -S eth0 | grep -iE "error|crc|bad"
# All should be zero (or very close)

# Fix 6 (Kubernetes + EKS): Node Group rolling replacement
aws eks update-nodegroup-version \
  --cluster-name production-eks \
  --nodegroup-name workers \
  --force
# Replaces ALL nodes in the group — overkill for single NIC issue
# but useful if you can't identify which node or want clean slate
```

---

## Part 6 — VPC ENI Flow Limits (AWS ENI Connection Tracking Exhausted)

### What It Looks Like

```
Symptoms:
  AWS: no kernel-level NIC errors — ip -s link looks fine
  VPC Flow Logs: new connections REJECT even though SG rules are correct
  CloudWatch: conntrack_allowance_exceeded metric > 0
  dmesg: no errors (this is an AWS layer problem, not OS layer)
  Pattern: large instances (c5.18xlarge, m5.24xlarge) with many connections
  Application: random connection failures at high connection count
```

### The Flow Limit Explained

AWS tracks every TCP/UDP connection through the ENI (Elastic Network Interface).
Each ENI has a maximum tracked connections limit:

```
Instance family    Tracked connections limit
t3.medium          128,000
m5.large           256,000
m5.xlarge          524,288
c5.2xlarge         1,048,576
c5.18xlarge        4,194,304
```

When you hit the limit, NEW connections are rejected — even if SG rules allow them.

### Diagnosis Commands

```bash
# ── Check conntrack table size (Linux side) ───────────────────────────────
cat /proc/sys/net/netfilter/nf_conntrack_count
# Current tracked connections

cat /proc/sys/net/netfilter/nf_conntrack_max
# Maximum allowed — if count approaches max → near limit

# Watch conntrack in real time
watch -n1 "cat /proc/sys/net/netfilter/nf_conntrack_count"

# ── AWS CloudWatch: conntrack_allowance_exceeded ──────────────────────────
INSTANCE_ID=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)
aws cloudwatch get-metric-statistics \
  --namespace AWS/EC2 \
  --metric-name conntrack_allowance_exceeded \
  --dimensions Name=InstanceId,Value=$INSTANCE_ID \
  --start-time $(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 60 \
  --statistics Sum \
  --output json | jq '.Datapoints[] | {Timestamp,Sum}'
# Any non-zero Sum = you hit ENI flow limits

# ── AWS CloudWatch: conntrack_allowance_available ─────────────────────────
aws cloudwatch get-metric-statistics \
  --namespace AWS/EC2 \
  --metric-name conntrack_allowance_available \
  --dimensions Name=InstanceId,Value=$INSTANCE_ID \
  --start-time $(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 60 \
  --statistics Minimum \
  --output json | jq '.Datapoints[] | {Timestamp,Minimum}'
# If Minimum approaches 0 → near limit

# ── See what's consuming connections ─────────────────────────────────────
# Connections by state
ss -tan | awk 'NR>1 {counts[$1]++} END {for(s in counts) print s, counts[s]}' | sort -k2 -rn
# Many TIME_WAIT = connections not being reused (fix: connection pooling)
# Many ESTABLISHED = normal for a busy service

# Count connections by remote IP
ss -tan state established | awk 'NR>1 {print $5}' | cut -d: -f1 | sort | uniq -c | sort -rn | head -20
# Is one IP holding thousands of connections? → that client needs pooling

# Active conntrack entries
sudo conntrack -L 2>/dev/null | wc -l
# or:
cat /proc/net/nf_conntrack | wc -l
```

### Fix — VPC ENI Flow Limits

```bash
# Fix 1: Enable TCP TIME_WAIT reuse (reduces stale connections)
sudo sysctl -w net.ipv4.tcp_tw_reuse=1
sudo sysctl -w net.ipv4.tcp_fin_timeout=15       # default 60 → faster cleanup
sudo sysctl -w net.ipv4.tcp_keepalive_time=600    # default 7200 → detect dead sooner
sudo sysctl -w net.ipv4.tcp_keepalive_intvl=30
sudo sysctl -w net.ipv4.tcp_keepalive_probes=5
# Make permanent:
cat >> /etc/sysctl.d/99-conntrack.conf << 'EOF'
net.ipv4.tcp_tw_reuse=1
net.ipv4.tcp_fin_timeout=15
net.ipv4.tcp_keepalive_time=600
net.ipv4.tcp_keepalive_intvl=30
net.ipv4.tcp_keepalive_probes=5
EOF
sudo sysctl -p /etc/sysctl.d/99-conntrack.conf

# Fix 2: Increase conntrack max (Linux-side only, does not increase AWS ENI limit)
sudo sysctl -w net.netfilter.nf_conntrack_max=1048576
# This only helps if you hit the Linux limit before the ENI limit

# Fix 3: Scale horizontally — spread connections across more nodes
# More nodes = more ENIs = more total connection tracking capacity
# Example: 4 nodes × 256,000 = 1,024,000 total vs 1 node × 256,000

# Fix 4: Move to a larger instance (more connections per ENI)
# Current: m5.large (256,000) → Upgrade to: m5.2xlarge (1,048,576)
# AWS console or:
aws ec2 modify-instance-attribute \
  --instance-id $INSTANCE_ID \
  --instance-type '{"Value": "m5.2xlarge"}'
# Requires instance stop/start

# Fix 5: Use a NLB instead of direct instance-to-instance (bypasses conntrack)
# Network Load Balancer handles connection tracking at the LB layer
# Instances behind NLB see fewer direct tracked connections

# Fix 6: Enable connection pooling in the application
# This reduces the number of distinct TCP connections:
# WITHOUT pooling: 100 requests/s × 200ms each = 20 concurrent connections
# WITH pooling: same 100 req/s reuses 5 persistent connections
# → 4x reduction in connection count

# Verify after fix:
aws cloudwatch get-metric-statistics \
  --namespace AWS/EC2 \
  --metric-name conntrack_allowance_exceeded \
  --dimensions Name=InstanceId,Value=$INSTANCE_ID \
  --start-time $(date -u -d '15 minutes ago' +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 60 --statistics Sum --output json \
  | jq '.Datapoints[].Sum'
# Should be 0 after fix
```

---

## Part 7 — Dynatrace: How to Read Network Error Rate

### In the UI

```
Infrastructure → Hosts → [host name]
  → Disk & Network tab
  → "Network error rate" chart (errors / total packets × 100)
  → Compare: incoming vs outgoing
  → Anomaly detection fires when > your set threshold
```

### Query in DQL (Grail Notebooks)

```
# Network error rate for a specific host
fetch dt.entity.host
| fields entity.name, dt.entity.host
| filter entity.name == "payment-node-01"
| lookup [
    timeseries avg(dt.host.network.errors.rx.rate), by:{dt.entity.host}
  ], sourceField:dt.entity.host, lookupField:dt.entity.host
```

### Set a Custom Anomaly Detection Rule

```
Settings → Anomaly detection → Infrastructure → Custom thresholds
  → Add rule for: Host network error rate
  → Threshold: 0.5%
  → Sensitivity: Medium
  → Apply to: Hosts with tag environment:production
```

---

## Cheat Sheet — Symptom → Root Cause → First Command

| Symptom | Most Likely Cause | First Command |
|---|---|---|
| `ip -s link` RX dropped rising fast | Congestion / buffer overflow | `sudo ethtool -S eth0 \| grep rx_miss` |
| `ip -s link` TX errors (not drops) | NIC hardware failure | `sudo dmesg \| grep -i "eth\|link\|reset"` |
| Works for small packets, breaks for large | MTU mismatch | `ping -M do -s 1472 <dest>` |
| Specific port fails, others work | Security group blocking | `nc -zv <dest> <port>` |
| `ip link` clean, VPC logs show REJECT | ENI flow limit | `cat /proc/sys/net/netfilter/nf_conntrack_count` |
| Errors on ONE node only | Hardware NIC issue | `aws ec2 describe-instance-status --instance-ids <id>` |
| Errors cluster-wide after deployment | MTU change or bad SG rule push | `kubectl get events -A --sort-by=lastTimestamp \| tail -20` |
