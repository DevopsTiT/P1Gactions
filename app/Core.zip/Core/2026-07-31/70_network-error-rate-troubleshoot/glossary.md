# High Network Error Rate — Glossary

Every term, tool, command, and concept from main.md explained for an SRE beginner.

---

**Network Error Rate**
The percentage of packets that fail to be transmitted or received correctly. Calculated as: (error packets ÷ total packets) × 100. Normal is under 0.01%. Above 0.5% causes visible service degradation.

**Packet**
The basic unit of data transmission on a network. A large message (like an HTTP response) is broken into many packets, each sent independently and reassembled at the destination. If any packet is dropped or corrupted, the receiving system must request a retransmission.

**NIC (Network Interface Card)**
The hardware component in a server that handles physical network communication. Receives packets from the wire, stores them in a ring buffer, and signals the CPU to process them. Also called a network adapter. In AWS, the virtual equivalent is the Elastic Network Adapter (ENA).

**RX (Receive)**
Packets coming INTO this machine from the network. RX errors or drops mean incoming packets are being lost before your application can read them.

**TX (Transmit)**
Packets going OUT from this machine to the network. TX errors mean outgoing packets are failing to leave the machine correctly.

**`ip -s link show`**
A Linux command that shows network interface statistics including packet counts, errors, and drops for both RX (receive) and TX (transmit) directions. The `-s` flag adds statistics. The primary first-look tool for network errors.

**`ethtool -S eth0`**
A Linux command that queries the NIC driver for detailed hardware-level statistics. Shows counters that `ip -s link` doesn't expose — CRC errors, FIFO overruns, missed interrupts. Requires the NIC driver to support it.

**Ring Buffer**
A fixed-size circular memory area in the NIC where incoming packets are stored while waiting for the CPU to process them. If the CPU is too slow to drain the buffer, new packets have nowhere to go and are silently dropped. Viewable with `ethtool -g eth0`.

**RX Drops**
Packets that arrived at the NIC but were discarded before reaching the application — usually because the ring buffer was full (CPU too busy) or the kernel's receive queue was full. Increment the "dropped" counter in `ip -s link`.

**TX Errors**
Packets that the NIC tried to transmit but failed at the hardware level — electrical issue, carrier lost, collision. Distinct from TX drops (which are software-level discards). TX errors suggest NIC hardware problems.

**CRC Error**
Cyclic Redundancy Check error — a packet arrived with its checksum not matching its contents, meaning the data was corrupted in transit. Usually caused by a failing NIC, bad cable (in physical environments), or NIC hardware issue. Visible in `ethtool -S`.

**`netstat -s`**
A Linux command showing cumulative protocol statistics (TCP, UDP, IP) since boot — retransmissions, failed connections, buffer prune events. Being replaced by `ss -s` in modern Linux.

**`ss -s`**
The modern replacement for `netstat`. Shows socket statistics including total connections, TCP connection states, and buffer usage. Faster than `netstat` because it reads from kernel directly.

**Network Congestion**
A condition where traffic demand exceeds the available network capacity — either bandwidth (the pipe is full) or CPU capacity (the NIC ring buffer fills up because the CPU can't drain it fast enough). Results in packet drops.

**Bandwidth Saturation**
When the amount of data flowing through a network interface reaches the maximum rate the interface supports (e.g. 5 Gbps for t3.medium). Packets arriving when the interface is saturated are queued or dropped.

**IRQ (Interrupt Request)**
A signal from hardware (like the NIC) to the CPU saying "new data arrived, please process it." Each received packet or batch of packets generates an IRQ. If all NIC IRQs go to one CPU core, that core becomes a bottleneck — other cores sit idle.

**IRQ Balancing**
Spreading NIC interrupt handling across multiple CPU cores so no single core becomes a bottleneck. The `irqbalance` daemon does this automatically. Can also be set manually via `/proc/irq/<N>/smp_affinity`.

**`mpstat -P ALL`**
A Linux command that shows per-CPU utilization including `%irq` (hardware interrupt time) and `%softirq` (software interrupt time). High `%softirq` on one CPU core while others are idle = NIC interrupts not balanced.

**`sar -n DEV`**
System Activity Reporter — shows historical network statistics per interface, including receive (rxkB/s) and transmit (txkB/s) bandwidth. Useful for confirming whether bandwidth saturation is the cause of drops.

**TCP Retransmission**
When the sender doesn't receive an acknowledgment within a timeout, it resends the packet. Retransmissions are normal at low rates but indicate packet loss at high rates. Visible in `netstat -s` as "segments retransmitted".

**`net.core.rmem_max`**
A Linux kernel parameter controlling the maximum size of the receive socket buffer. Increasing it allows more data to be buffered in the kernel for applications that read slowly. Set with `sysctl`.

**`sysctl`**
A Linux command to read or write kernel parameters at runtime. Example: `sysctl -w net.core.rmem_max=134217728` increases the receive buffer. Changes persist across reboots if written to `/etc/sysctl.d/`.

**MTU (Maximum Transmission Unit)**
The largest packet size (in bytes) that a network path can carry without fragmentation. Standard Ethernet: 1500 bytes. AWS VPC jumbo frames: 9001 bytes. Overlay networks (VXLAN): 1450 bytes (1500 minus tunnel overhead).

**MTU Mismatch**
When different parts of a network path have different MTU values — for example, a pod tries to send a 1500-byte packet through a VXLAN tunnel that only supports 1450 bytes. The packet either gets fragmented (performance hit) or dropped (if the "don't fragment" bit is set).

**VXLAN (Virtual Extensible LAN)**
A network overlay protocol used by Kubernetes CNI plugins (Flannel, Calico) to create virtual networks between nodes. VXLAN wraps original packets in an outer UDP envelope, adding 50 bytes of overhead — which is why CNI MTU must be set 50 bytes lower than the underlying network MTU.

**Fragmentation**
When a packet is too large for a network hop, the router or host splits it into smaller pieces (fragments). Each fragment must be reassembled at the destination. Fragmentation wastes bandwidth, increases CPU usage, and can cause drops if reassembly fails. Avoided by proper MTU configuration.

**DF Bit (Don't Fragment)**
A flag in the IP header telling routers "do not fragment this packet — if it's too large, drop it and send an ICMP error instead." Modern TCP uses DF + ICMP "fragmentation needed" messages to discover the true path MTU (Path MTU Discovery).

**PMTU (Path MTU Discovery)**
The mechanism by which a TCP connection discovers the smallest MTU on the path between source and destination. Sends packets with DF bit set and listens for ICMP "fragmentation needed" responses. Works by binary search. Results cached in the routing table (`ip route show cache`).

**`ping -M do -s 1472`**
A ping command that sends a packet of exactly 1472 bytes with the Don't Fragment bit set. 1472 + 28 bytes (IP + ICMP headers) = 1500 — the standard MTU. If this fails but smaller pings succeed, MTU is less than 1500 on the path.

**TCP MSS Clamping**
A technique using `iptables` to force all TCP connections to use a smaller Maximum Segment Size (MSS), preventing large packets without changing the interface MTU. A workaround when you can't easily fix the MTU mismatch at both ends.

**`iptables -t mangle TCPMSS`**
An iptables rule in the mangle table that modifies the TCP MSS field in SYN packets. `--clamp-mss-to-pmtu` automatically sets the MSS to the discovered path MTU minus TCP/IP header size.

**Security Group (AWS)**
A virtual firewall attached to EC2 instances and ENIs that controls which network traffic is allowed in (ingress) and out (egress). Rules are evaluated statefully — if you allow inbound TCP:8080, the return traffic is automatically allowed. Blocked traffic is silently dropped (no RST sent).

**VPC Flow Logs**
An AWS feature that records metadata about every network packet flowing through your VPC — source IP, destination IP, port, protocol, bytes, and whether the packet was ACCEPT or REJECT by security groups. Essential for diagnosing SG-related drops. Stored in CloudWatch Logs or S3.

**`REJECT` (VPC Flow Logs)**
A flow log entry where the security group or network ACL blocked the traffic. REJECT entries for your service's port when the SG rules appear correct = time to check NetworkPolicies or NACLs.

**Network ACL (NACL)**
A stateless firewall at the subnet level in AWS VPC. Unlike Security Groups (stateful), NACLs require explicit rules for both inbound AND outbound traffic. Numbered rules — lower number = evaluated first. Can block traffic that Security Groups allow.

**Kubernetes NetworkPolicy**
A Kubernetes resource that restricts traffic between pods using label selectors. Like a Security Group but inside Kubernetes — operates independently of AWS SGs. Can silently drop traffic between pods in different namespaces. Check with `kubectl get networkpolicies -A`.

**`nc -zv` (netcat)**
A simple tool to test if a TCP port is reachable. `-z` = scan mode (don't send data), `-v` = verbose. "Connection succeeded" = port open. "(hangs)" = packet dropped by SG. "Connection refused" = port closed at the app level (not SG).

**`tcpdump`**
A packet capture tool that shows the actual network packets flowing through an interface in real time. Can filter by host, port, and protocol. Used to confirm whether SYN packets are sent and whether SYN-ACK responses are received.

**ENI (Elastic Network Interface)**
The virtual network interface attached to an EC2 instance in AWS. Handles all network traffic to/from the instance. Each ENI has a maximum number of tracked connections (connection tracking table). This limit is per ENI, not per security group.

**Connection Tracking (Conntrack)**
A Linux kernel feature (and AWS hardware feature) that tracks the state of every active network connection — source IP, source port, destination IP, destination port, protocol, state. Required for stateful firewalls. Each tracked flow consumes a slot in the conntrack table.

**`conntrack_allowance_exceeded`**
An AWS CloudWatch metric for EC2 instances that counts how many times a new connection was rejected because the ENI's connection tracking table was full. Any non-zero value means you are hitting VPC ENI flow limits.

**`conntrack_allowance_available`**
An AWS CloudWatch metric showing how many more connections can be tracked before hitting the ENI limit. When this approaches 0, you are about to start seeing rejected connections.

**`nf_conntrack_count`**
A Linux kernel value at `/proc/sys/net/netfilter/nf_conntrack_count` showing the current number of tracked connections in the kernel's own conntrack table. Different from (and usually smaller than) the AWS ENI limit.

**`nf_conntrack_max`**
A Linux kernel parameter controlling the maximum connections the kernel will track. Separate from the AWS ENI limit — both limits apply independently.

**TIME_WAIT**
A TCP connection state after the connection is closed. The socket stays in TIME_WAIT for 2× the Maximum Segment Lifetime (typically 60–120 seconds) to prevent stale packets from old connections confusing new ones. Many TIME_WAIT connections = lots of recently closed connections = consider connection pooling.

**`net.ipv4.tcp_tw_reuse`**
A Linux kernel parameter that allows new outgoing connections to reuse sockets in TIME_WAIT state (for outbound connections where timestamps are available). Reduces the conntrack entry count by recycling closed connections faster.

**`net.ipv4.tcp_fin_timeout`**
The time a socket stays in FIN_WAIT_2 state after the local end closes the connection. Default is 60 seconds. Reducing to 15 speeds up cleanup of half-closed connections, freeing conntrack entries sooner.

**Connection Pooling**
An application technique where a fixed set of TCP connections are kept open and reused for multiple requests, instead of opening a new connection for each request. Dramatically reduces connection count. Example: an HTTP client with a pool of 5 persistent connections can serve 100 requests/second while tracking only 5 connections.

**`kubectl cordon`**
Marks a Kubernetes node as unschedulable — no new pods will be placed on it. Existing pods continue running. Used as the first step when a node needs maintenance (like replacing a failing NIC).

**`kubectl drain`**
Evicts all pods from a node (except DaemonSets) and marks it unschedulable. Pods are gracefully terminated and rescheduled on healthy nodes. Used to safely empty a node before maintenance or replacement.

**`kubectl uncordon`**
Removes the unschedulable mark from a node, allowing new pods to be scheduled on it again. Used after a node's hardware is fixed and it's returned to service.

**`aws ec2 describe-instance-status`**
An AWS CLI command that shows the health status of an EC2 instance including AWS's own hardware health checks — InstanceStatus and SystemStatus. "impaired" = AWS detected a problem with the underlying hardware.

**Instance Stop/Start (hardware replacement)**
When you stop an EC2 instance and start it again, AWS migrates it to a different physical host. This is the standard way to force hardware replacement when you suspect a NIC hardware failure. Note: stopping and starting is different from rebooting (reboot keeps the same hardware).

**`aws eks update-nodegroup-version`**
An AWS CLI command that triggers a rolling replacement of all nodes in an EKS node group. Each node is drained, terminated, and replaced with a fresh one. Used for large-scale node replacement or Kubernetes version upgrades.

**`dmesg --ctime`**
Displays kernel messages (the kernel log) with human-readable timestamps instead of seconds-since-boot. Essential for finding NIC driver errors, device resets, and link state changes that happened at specific times during an incident.

**ENA (Elastic Network Adapter)**
AWS's high-performance virtual NIC driver used by most modern EC2 instances. Supports speeds up to 100 Gbps. Kernel module name is `ena`. Error messages from this driver appear in `dmesg` as "ena: ..." entries.

**`aws cloudwatch get-metric-statistics`**
An AWS CLI command to query CloudWatch metrics for a specific time range. Used here to check `conntrack_allowance_exceeded` and `conntrack_allowance_available` to diagnose ENI flow limit issues.

**DQL (Dynatrace Query Language)**
Dynatrace's query language for searching metrics, logs, and entity data in Grail (the Dynatrace data lake). Used in Notebooks to build custom queries for network error rate analysis.
