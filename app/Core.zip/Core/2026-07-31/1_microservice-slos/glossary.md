# Glossary — Microservice SLOs
Every term from main.md. One entry per term. For SRE beginners.

---

**SLO (Service Level Objective)**
A measurable reliability target for a service. Example: "99.9% of requests must return a successful response." SLOs are internal commitments, not contracts with customers. Why it matters: tells you objectively whether your service is healthy — not based on gut feeling, but on math.

**SLA (Service Level Agreement)**
A contract between a company and its customers about reliability. Example: "we guarantee 99.9% uptime; if we miss it, you get a refund." Why it matters: SLOs are the internal version of SLAs — you measure SLOs to make sure you don't breach your SLA.

**SLI (Service Level Indicator)**
The raw metric that feeds an SLO. For an availability SLO, the SLI is: `(successful requests / total requests) × 100`. Why it matters: SLI = the measurement; SLO = the target for that measurement. You can't have an SLO without an SLI.

**Error budget**
The amount of failure allowed within an SLO window before the SLO is breached. For a 99.9% monthly availability SLO: error budget = 0.1% of requests = up to 43.2 minutes of downtime in a 30-day month. Why it matters: instead of "was the service down?" you ask "how much of the budget is left?" — a more nuanced view.

**Burn rate**
How fast you're consuming your error budget compared to the SLO window. A burn rate of 1 = consuming budget exactly as fast as the window allows. A burn rate of 14.4 = consuming 14.4× faster → budget exhausted in 2 days instead of 30. Why it matters: burn rate alerts warn you BEFORE the SLO is breached.

**Fast burn threshold (14.4)**
A burn rate so high that the error budget would be exhausted in 2 days. `14.4 = 30 days / 2 days`. Why it matters: triggers an urgent alert — you need to act NOW or the SLO will breach before the window ends.

**Slow burn threshold (3.0)**
A burn rate of 3× means the budget would last 10 days (`30 / 3`). Not urgent enough for a page but worth investigating. Why it matters: catches slow creeping problems that would breach the SLO without triggering fast burn.

**`evaluation_window: "-1M"`**
The SLO is evaluated over a rolling 30-day window (1 month). `-1M` means "the last 1 month." Why it matters: the SLO resets monthly — you get a fresh error budget at the start of each month. If you had a bad day on day 1, you have 29 days to "make up" the budget.

**`evaluation_type: AGGREGATE`**
The SLO evaluates ALL requests in the window as one single pool (not per-minute averages). Why it matters: 1 million requests, 1000 failed = 99.9% availability. The aggregate view is what users actually experience.

**`target_success`**
The minimum percentage that must be achieved for the SLO to be "in compliance." Example: `99.9`. If the actual value falls below this, the SLO is in breach. Why it matters: this is the number that determines whether you owe customers a credit.

**`target_warning`**
A threshold slightly below `target_success` that triggers a warning alert before breach. Example: if `target_success = 99.9`, set `target_warning = 99.8`. Why it matters: early warning — you can fix the problem before the SLO actually breaches.

**Availability SLO**
Measures what percentage of HTTP requests returned a non-error response (non-5xx). Formula: `(total requests - 5xx errors) / total requests × 100`. Why it matters: the most fundamental SLO — is the service responding successfully to users?

**Latency P99 SLO**
Measures what percentage of requests responded within a target time (e.g., 300ms). Not "what's the average latency" — it's "what % of requests were fast enough." Why it matters: protects the experience of the slowest 1% of users, not just the average user.

**P99 (99th percentile)**
The latency value that 99% of requests are faster than. If P99 = 500ms, then 99 out of 100 requests completed in under 500ms; 1 out of 100 took longer. Why it matters: P99 represents the "worst realistic" user experience, not the "average" experience.

**DB Error Rate SLO**
Measures what percentage of database calls succeeded. Separate from availability because retry logic can hide DB failures from the HTTP error rate. Why it matters: catches DB instability that application retries are masking — signals a problem before retries start to fail.

**DB Latency SLO**
Measures what percentage of database queries completed within a target time. Why it matters: slow DB queries make APIs slow. This SLO fires before the API latency SLO fires — giving you the root cause (DB is slow) before you're getting paged for API latency.

**`builtin:service.dbconnectioncount`**
Dynatrace built-in metric counting the total number of DB connection calls made by a service. Why it matters: the denominator in the DB error rate and latency SLOs.

**`builtin:service.dbconnectionfailcount`**
Dynatrace metric counting failed DB calls. Why it matters: numerator for "how many DB calls failed" — used to calculate DB error rate.

**Dependency Error Rate SLO**
Measures what percentage of outbound calls FROM this service TO other services succeeded. Uses `.client` metrics (outbound) vs `.server` metrics (inbound). Why it matters: distinguishes "this service is broken" from "a dependency this service calls is broken" — saves engineers from debugging the wrong service.

**`builtin:service.requestCount.client`**
DT metric for outbound HTTP calls MADE BY this service (to other services). Different from `.server` which counts inbound calls TO this service. Why it matters: this is the metric for "is our dependency healthy from our perspective?"

**`builtin:service.errors.client.count`**
DT metric for failed outbound calls. Used with `.client` total count to calculate dependency error rate. Why it matters: shows how many of YOUR outbound calls to dependencies are failing.

**Message Processing Success Rate SLO**
Measures what percentage of messages consumed from a queue (Kafka/SQS) were processed without error. Why it matters: when processing fails, messages go to a Dead Letter Queue — no HTTP error is thrown. Standard availability/error rate SLOs are blind to this failure mode.

**Dead Letter Queue (DLQ)**
A separate queue where messages go after failing to be processed a certain number of times. Think of it as a "failed messages bin." Why it matters: if the message processing SLO fires, engineers check the DLQ to see what messages failed and why.

**`ext:custom.*` (DT custom metric)**
A Dynatrace metric sent by application code via OTEL (not auto-captured by OneAgent). Prefix `ext:custom.` marks it as app-emitted. Example: `ext:custom.messages.failed.count`. Why it matters: SLOs for business transactions and message processing require the app to emit these — DT doesn't capture business intent automatically.

**Business Transaction Success Rate SLO**
Measures what percentage of business operations (not just HTTP calls) completed successfully. Example: "what % of payment attempts resulted in a payment being made?" Why it matters: HTTP 200 ≠ business success. A payment that returns `{"status": "declined"}` is HTTP 200 but a business failure.

**`MeterRegistry` (Spring Boot / Micrometer)**
A Spring Boot component that records metrics (counters, gauges, timers) and exports them via OTEL. `meterRegistry.counter("name").increment()` sends a counter metric to Dynatrace. Why it matters: the app-side tool for emitting custom metrics that feed business SLOs and message processing SLOs.

**GC Pause Time SLO**
Measures what percentage of time the JVM is NOT paused for garbage collection. Target: 99.5% (JVM may spend max 0.5% of time in GC pauses). Why it matters: GC pauses freeze all threads — any request in-flight during a Full GC pause just waits. This SLO fires before the latency SLO does, giving you the root cause early.

**G1GC (Garbage-First Garbage Collector)**
The default JVM garbage collector since Java 9. Divides heap into regions, collects the most garbage-filled ones first. Has short incremental pauses (minor GC) and occasional longer pauses (mixed/full GC). Why it matters: at 70%+ heap utilization, G1GC runs more frequently and pauses get longer — the GC pause SLO catches this.

**Minor GC vs Full GC**
Minor GC: short (5-20ms), collects "young generation" objects — happens every few seconds, nearly invisible. Full GC: long (100ms - 10 seconds), collects the entire heap — happens when heap is very full or there's a memory leak. Why it matters: Full GC causes multi-second latency spikes; the GC pause SLO fires when these become frequent.

**`builtin:process.memory.jvm.garbageCollectionTime`**
DT metric measuring total time the JVM spent in garbage collection pauses per minute. Why it matters: the raw measurement for the GC pause SLO — if this is high, the JVM is spending too much time collecting garbage instead of handling requests.

**`has_database = true/false` (Terraform variable)**
A boolean flag on each service in the services map that controls whether the DB SLOs are created for that service. Why it matters: notification-service uses Redis (not SQL), so creating SQL DB connection SLOs for it would always evaluate to "no data" (not useful).

**`for k, v in var.services : k => v if v.has_database`**
Terraform conditional for_each — creates the resource ONLY for services where `has_database = true`. Like an `if` statement inside a loop. Why it matters: avoids creating empty/broken SLOs for services that don't have the feature the SLO measures.

**`le()` filter in DT metric expression**
`le(metric, value)` = "less than or equal to." Used in latency SLOs to count only requests that responded within the threshold. Example: `le(builtin:service.response.time, 300000)` = only count requests that took ≤ 300ms (300,000 µs). Why it matters: this is how you calculate "what % of requests were fast enough."

**Microseconds vs Milliseconds (DT internal unit)**
Dynatrace stores latency metrics internally in microseconds (µs), NOT milliseconds (ms). 300ms must be written as `300000` in metric expressions. Why it matters: the most common SLO configuration mistake — using `300` instead of `300000` makes the SLO fire on almost every request (300µs = 0.3ms is nearly instant).

**Rolling window vs calendar window**
Rolling window (`-1M`): always the last 30 days from NOW. If it's July 15, the window is June 15–July 15. Calendar window: January 1–January 31 exactly. Why it matters: rolling windows give a continuous view of reliability; calendar windows reset abruptly at month boundaries (you can have a terrible day 1 and still meet the monthly SLO).

**Error budget policy**
A team agreement on what to do when the error budget is low: freeze deployments? Shift focus from features to reliability? Why it matters: without a policy, having a burning error budget changes nothing about team behavior — SLOs only matter if they drive decisions.
