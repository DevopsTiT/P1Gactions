# Glossary — Dynatrace Terraform IaC SRE Deep Dive

Every term used in main.md. Plain language for an SRE beginner.

---

**Infrastructure as Code (IaC)**
Writing infrastructure configuration (cloud resources, monitoring rules, alert thresholds) as files in a version-controlled repository, rather than clicking in a UI. Why it matters: every change is reviewable, auditable, and reproducible — "who changed this and when" is always answerable via git.

**Terraform**
An IaC tool that reads `.tf` files and creates/modifies/destroys resources via cloud provider APIs. `terraform plan` shows what would change; `terraform apply` makes it real. Why it matters: the single tool used to manage both AWS infrastructure and Dynatrace configuration in this project.

**Terraform provider**
A plugin that translates HCL resource declarations into real API calls. The `dynatrace-oss/dynatrace` provider translates `resource "dynatrace_metric_events"` blocks into DT REST API calls. Why it matters: without a provider, Terraform doesn't know how to talk to Dynatrace.

**`version = "~> 1.55"` (pessimistic constraint)**
Allows Terraform provider versions 1.55.x and above within the 1.x range, but blocks 2.0+ (potentially breaking changes). Why it matters: without pinning, `terraform init` could download a new major version that renames resources or changes schemas, breaking all plans.

**Terraform module**
A reusable directory of `.tf` files called multiple times with different input values. The `terraform/modules/dynatrace/` folder is called once for dev, once for staging, once for production — same logic, different thresholds. Why it matters: fix a bug once in the module → all environments automatically get the fix on next apply.

**Terraform state file**
A JSON file in S3 that records every resource Terraform manages — including the DT internal ID for each resource. Why it matters: without state, Terraform can't update or delete existing DT resources (it doesn't know their IDs) and would try to create duplicates instead.

**`terraform plan`**
Compares current state + `.tf` files against what actually exists, then shows a diff of what would change: `+` add, `~` modify, `-` destroy. Why it matters: lets engineers review changes before they're applied — the "show your work" step.

**`terraform apply`**
Actually creates, modifies, or destroys resources. `-auto-approve` skips the interactive confirmation (required in CI). Why it matters: the step that turns HCL declarations into real Dynatrace alert rules.

**`terraform validate`**
Checks HCL syntax and variable types without making any API calls. Faster than `plan`. Why it matters: catches typos and missing required fields (like forgetting `jvm_heap_pct`) before CI runs.

**`terraform show`**
Displays the current state in human-readable format — all managed resources and their current attribute values. Why it matters: the authoritative answer to "what is currently configured in production?" without logging into the DT UI.

**`terraform destroy`**
Destroys all resources in state. Why it matters: clean environment teardown — removes all DT alert rules, SLOs, and synthetics for a decommissioned environment without manual UI work.

**`-target` flag (Terraform)**
Applies changes only to a specific resource: `terraform apply -target='dynatrace_metric_events.latency_p99["payment-service"]'`. Why it matters: emergency use during incidents when you need to change one specific alert without touching anything else.

**`terraform import`**
Brings a manually-created resource under Terraform management without destroying and recreating it. Why it matters: when someone creates a DT alert in the UI, import lets Terraform "adopt" it so future changes go through code review.

**`terraform force-unlock`**
Removes a stuck state lock (when a previous apply crashed without releasing its lock). Why it matters: a stuck lock blocks all future applies — you can't deploy anything until the lock is cleared.

**Terraform state lock (DynamoDB)**
A record written to DynamoDB before any apply to prevent two simultaneous applies from corrupting state. Why it matters: without locking, two CI runs triggered at the same time could create race conditions and inconsistent DT configurations.

**`data` source (Terraform)**
Reads existing infrastructure without managing it. `data "aws_secretsmanager_secret_version"` reads a secret without taking ownership. Why it matters: credentials can be fetched at apply time without ever being written to `.tf` files or git history.

**`resource` block (Terraform)**
Declares infrastructure that Terraform creates and manages. `resource "dynatrace_metric_events" "latency_p99"` → Terraform creates this and tracks its DT ID in state. Why it matters: the core building block — every DT alert rule, SLO, and synthetic is declared as a `resource`.

**`for_each` (Terraform)**
Creates one resource instance per item in a map or set. `for_each = var.services` creates one metric event per service. `for_each = {}` (empty map) creates zero resources. Why it matters: eliminates copy-paste — one resource declaration handles all services.

**`toset()` (Terraform)**
Converts a list to a set, removing duplicates. Used to extract unique team names from the services map. Why it matters: management zones are per team, not per service — deduplication ensures you don't create two "payments-production" zones.

**Ternary expression (Terraform)**
`condition ? value_if_true : value_if_false`. Used as: `var.environment == "production" ? local.teams : toset([])`. Why it matters: creates resources conditionally (CRITICAL alerting profiles only in production) without `count` or `if` blocks.

**Zero-resource-via-empty-map pattern**
Passing `{}` to a `for_each` variable to create zero resources of that type. Dev passes `pagerduty_integration_keys = {}` → zero PagerDuty notifications. Why it matters: cleaner than conditional logic — data controls existence, not if-statements in the module.

**`sensitive = true` (Terraform variable)**
Prevents Terraform from printing the variable's value in plan output, apply logs, or `terraform show`. Why it matters: API tokens and PagerDuty keys would otherwise appear in CI logs visible to all engineers and in git blame.

**`jsondecode()` (Terraform function)**
Parses a JSON string into a Terraform map or list. Used to read all Slack webhooks from one JSON secret. Why it matters: adding a new team only requires updating the JSON in Secrets Manager — no Terraform code change, no PR, no pipeline.

**`-refresh-only` (terraform plan flag)**
Checks what changed in real Dynatrace vs what Terraform's state expects — without planning any `.tf` file changes. Why it matters: drift detection needs to show "someone changed DT manually" separately from "what my .tf files would change."

**`-detailed-exitcode` (terraform plan flag)**
Changes exit codes: 0 = success no changes, 1 = error, 2 = success with changes pending. Why it matters: drift detection scripts use exit code 2 to know when drift was found — a normal plan always exits 0 even when changes exist.

**Configuration drift**
When the actual configuration in a system (DT UI) diverges from what's declared in code. Why it matters: if someone manually changes a DT threshold, the next `terraform apply` will overwrite it silently — unless drift detection catches it first.

**Alert fatigue**
When alerts fire so frequently (due to wrong thresholds, environment misconfiguration) that engineers start ignoring them. Why it matters: the most dangerous failure mode in monitoring — a real incident fires and is treated as noise.

**Audit trail**
A record of who changed what, when, and why. Terraform provides this via git history (commit author, timestamp, diff) and PR reviews. Why it matters: "who raised the error rate threshold from 0.1% to 5% in production?" is always answerable.

**PR (Pull Request)**
A request to merge code changes, with a review process before merging. DT threshold changes go through PRs so a second engineer reviews the `terraform plan` output before changes take effect. Why it matters: the human review gate between "I want to change this" and "this is changed."

**DT internal ID**
A UUID assigned by Dynatrace to each resource it manages (e.g., `dt-metric-event-id-abc123`). Stored in Terraform state. Why it matters: Terraform needs this ID to update or delete an existing resource — without it, Terraform tries to create a new resource instead.

**GitHub environment (production gate)**
A named GitHub deployment environment with required human reviewers. When a job has `environment: production`, the CI pipeline pauses and waits for someone to click Approve. Why it matters: no DT production config changes happen without explicit human sign-off, even after a PR is merged.

**OIDC AWS authentication**
GitHub Actions authenticates to AWS without stored credentials by exchanging a GitHub token for temporary STS credentials. Why it matters: no long-lived AWS keys in GitHub Secrets that could be leaked — credentials expire after the CI job.

**`plan` role vs `apply` role (IAM)**
Two separate AWS IAM roles with different permissions. `plan` role: read-only (Secrets Manager read, S3 state read). `apply` role: write permissions. Why it matters: even if a malicious PR modifies the workflow to steal credentials, `plan` credentials cannot create or destroy anything.

**`default_tags` (AWS provider)**
Automatically applies tags (like `environment = "dev"`, `managed-by = "terraform"`) to every AWS resource created by this provider. Why it matters: every resource is labeled so cost reports and incident investigations can filter by environment and ownership.

**S3 backend (Terraform)**
Stores the state file in an AWS S3 bucket instead of locally. Why it matters: multiple engineers and CI pipelines can share the same state; state survives laptop deaths and CI runner restarts.

**DynamoDB lock table**
A DynamoDB table Terraform writes a lock record to before applying, preventing concurrent applies. Why it matters: two CI pipelines triggered simultaneously can't both apply at once and corrupt state or create duplicate DT resources.

**Separate state buckets per environment**
Dev, staging, and production each have their own S3 bucket for state. Why it matters: the dev IAM role can only access the dev state bucket — impossible to accidentally corrupt production state from a dev pipeline.

**`path` trigger (GitHub Actions)**
CI workflow only runs when specific file paths change. `terraform/environments/dev/**` + `terraform/modules/dynatrace/**`. Why it matters: a dev threshold change only triggers the dev pipeline; a module fix triggers all 3 pipelines to pick up the fix.

**`plan.substring(0, 65000)` (PR comment truncation)**
Limits the Terraform plan output posted as a PR comment to 65,000 characters. Why it matters: GitHub PR comments have a size limit — a very large plan would fail to post silently without this truncation.

**`PIPESTATUS[0]` (Bash)**
Captures the exit code of the first command in a pipe. `terraform plan | tee file.txt` → `$?` gives tee's exit code (always 0), `${PIPESTATUS[0]}` gives Terraform's real exit code. Why it matters: drift detection must read Terraform's exit code (2 = drift), not tee's.

**`set +e` (Bash)**
Disables automatic script exit on non-zero exit codes. Why it matters: `terraform plan -detailed-exitcode` exits with code 2 when drift is found — this is expected, not an error. Without `set +e`, the script aborts before capturing and reporting the drift.

**Burn rate (DT SLO)**
How fast the error budget is being consumed. 14.4× = exhausted in ~2 days (page immediately). 3.0× = exhausted in ~10 days (investigate today). Google SRE Workbook standard values. Why it matters: alerts you before the SLO is breached, not after.

**Error budget**
The allowed amount of failures while still meeting the SLO. For 99.9% availability: 0.1% of requests. Why it matters: quantifies how much reliability work is needed — nearly depleted budget = stop feature work, fix reliability.

**`services_with_traffic` local (Terraform)**
A filtered map of services where `traffic_min_rps > 0`, used to create traffic drop metric events only for services that expect real traffic. Why it matters: dev services have `traffic_min_rps = 0` → zero traffic drop events → no 24/7 alert noise from services with no users.

**`OTEL_SERVICE_NAME` env var**
The name the Java application reports for itself in OpenTelemetry traces and metrics. Must exactly match the key in the Terraform `services = { "payment-service" = {...} }` map. Why it matters: if they don't match, DT metric event entity filters find no matching service → metric events never fire.

**Snowflake configuration**
A unique, manually configured environment that differs from all others in ways nobody fully understands. The opposite of IaC. Why it matters: snowflake configs make disaster recovery impossible and adding a new service inconsistent across environments.
