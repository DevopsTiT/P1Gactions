# Maintain and Manage Dynatrace Configurations Using Terraform — SRE Deep Dive

> **Who this is for:** An SRE who needs to understand HOW Dynatrace configuration is written, versioned, changed, reviewed, and deployed using Terraform — and what happens without it.

---

## Decision Tree — When to Change DT Config via Terraform

```
I need to change something in Dynatrace.
         │
         ├── Change a threshold (e.g., latency alert from 300ms to 400ms)
         │         └── Edit terraform/environments/<env>/main.tf
         │             → services map → latency_p99_ms = 400
         │             → PR → plan comment → merge → apply
         │
         ├── Add a new service to monitoring
         │         └── Add entry to services = { ... } map in <env>/main.tf
         │             → All 8 metric events + SLOs + synthetic created automatically
         │
         ├── Change how alerts are structured (e.g., add a new signal)
         │         └── Edit terraform/modules/dynatrace/main.tf
         │             → affects ALL environments on next apply
         │
         ├── Change who gets paged (swap PagerDuty key)
         │         └── Update secret in AWS Secrets Manager
         │             → No Terraform change needed (secret read at apply time)
         │             → OR update pagerduty_integration_keys in <env>/main.tf
         │
         └── NEVER: click in the DT UI to change thresholds
                   → selfHeal/Terraform will overwrite it on next apply
                   → change is not version-controlled, not reviewable, not auditable
```

---

## Part 1 — Why IaC for Dynatrace (What Breaks Without It)

### The manual configuration problem

Before IaC, Dynatrace config is managed through the UI. This creates:

```
1. Configuration drift across environments
   Dev DT:     latency alert = 2000ms (engineer set this last month, forgot)
   Staging DT: latency alert = 800ms  (different engineer, different number)
   Prod DT:    latency alert = 300ms  (correct)
   
   Nobody knows when they diverged. Nobody can prove prod is correctly configured.
   A wrong threshold in prod goes unnoticed for weeks.

2. No audit trail
   "Who changed the error rate threshold from 1% to 5% in production last Tuesday?"
   → No answer. The DT UI has no git blame.
   
3. No review process
   Engineer A sets prod error alert to 5% (allowing 50× more errors before alerting).
   No peer review. No approval. Nobody knows until something breaks.
   
4. No reproducibility
   Disaster recovery: prod DT tenant is corrupted/deleted.
   "What were all our alert thresholds?"
   → Nobody knows. It takes days to manually recreate from memory.
   
5. Snowflake configurations
   Each environment configured by a different person on a different day.
   Cannot add a new service consistently — you'd have to repeat manual steps 3×.
```

### What Terraform gives you

```
1. Version control (git)
   Every threshold change is a git commit with:
   - WHO made the change (git author)
   - WHEN it happened (commit timestamp)
   - WHAT changed (diff: latency_p99_ms = 300 → 400)
   - WHY (PR description, ticket number)

2. Code review
   Threshold changes go through a PR. A second engineer must approve.
   "Why are you raising the error rate threshold to 5%?" → discussion happens.
   
3. Automated plan on PR
   CI runs terraform plan and posts the output as a PR comment:
   ~ dynatrace_metric_events.latency_p99["payment-service"]: threshold 300000 → 400000
   Reviewer can see exactly what will change in DT before approving.

4. Consistent across environments
   Same module called with different values:
   dev: latency_p99_ms = 2000
   staging: latency_p99_ms = 800
   production: latency_p99_ms = 300
   No copy-paste. No drift. The LOGIC is identical; only the VALUES differ.

5. Self-documenting
   terraform/environments/production/main.tf is the authoritative answer to
   "what are all our production monitoring thresholds right now?"
   Read the file. No need to log into DT and click through 50 metric events.

6. Disaster recovery
   DT tenant destroyed → terraform apply → all configuration restored in minutes.
   100% reproducible.
```

---

## Part 2 — Repository Structure (How It's Organized)

```
terraform/
├── modules/
│   └── dynatrace/
│       ├── main.tf        ← ALL DT resource definitions (the logic)
│       └── variables.tf   ← the CONTRACT: what inputs the module accepts
│
└── environments/
    ├── dev/
    │   └── main.tf        ← calls module with DEV thresholds
    ├── staging/
    │   └── main.tf        ← calls module with STAGING thresholds
    └── production/
        └── main.tf        ← calls module with PRODUCTION thresholds
```

### The two-layer design explained

**Layer 1 — The module (`terraform/modules/dynatrace/`):**
Contains ALL the logic for creating DT resources. This never changes per environment. It defines:
- Which resource types to create (management zones, alerting profiles, metric events, SLOs, synthetics, notifications)
- How they connect to each other (alerting profile references management zone)
- Conditional logic (CRITICAL profiles only in production)
- The threshold variable names (but not their values)

**Layer 2 — The environment callers (`terraform/environments/<env>/main.tf`):**
Contains ONLY the values. No resource definitions. Calls the module and passes:
- Which environment this is (`environment = "production"`)
- All threshold values (`latency_p99_ms = 300`)
- Which services to monitor (`services = { "payment-service" = {...} }`)
- Credentials (read from Secrets Manager)
- Notification targets (PagerDuty keys, Slack webhooks)

```
Why this separation?

WITHOUT the module (3 copies of the logic):
  Bug found: latency metric event uses wrong entity dimension key.
  Fix required in: dynatrace-dev/metric-events.tf
                   dynatrace-staging/metric-events.tf
                   dynatrace-production/metric-events.tf
  Miss one → inconsistent behavior across environments.
  Miss two → prod still broken after fix.

WITH the module (one copy of the logic):
  Fix in: terraform/modules/dynatrace/main.tf (one file)
  All three callers automatically use the fix on next apply.
  Zero chance of forgetting an environment.
```

---

## Part 3 — `variables.tf` — The Module Contract

```hcl
##############################################################################
# terraform/modules/dynatrace/variables.tf
##############################################################################

variable "environment" {
  type        = string
  description = "dev | staging | production"
}
```

This single variable controls three things inside `main.tf`:
1. **Resource naming:** `"${each.value}-${var.environment}-critical"` → `"payments-production-critical"`
2. **Conditional resource creation:** `var.environment == "production" ? local.teams : toset([])`
3. **Metric event entity filters:** `value = var.environment key = "environment"` — ensures dev alerts only fire for dev entities

```hcl
variable "dt_env_url" {
  type      = string
  sensitive = true
}
variable "dt_api_token" {
  type      = string
  sensitive = true
}
```

`sensitive = true` means Terraform will NEVER print these in:
- `terraform plan` output
- `terraform show` output
- CI logs
- Error messages

The values still exist in the S3 state file (encrypted by `encrypt = true` in the backend), but they cannot accidentally appear in logs visible to all engineers.

```hcl
variable "pagerduty_integration_keys" {
  type      = map(string)
  sensitive = true
  default   = {}
}
```

`default = {}` means if a caller passes nothing, it gets an empty map. The module uses `for_each = var.pagerduty_integration_keys`. An empty map = zero PagerDuty resources created. This is the **zero-resource-via-empty-map pattern**:

```
dev/main.tf passes:    pagerduty_integration_keys = {}
  → module: for_each = {}
  → Terraform creates 0 PagerDuty notification resources in dev
  → No conditional blocks needed in the module
  → No if-statements about "if dev don't create PD"
  → DATA controls existence, not logic

production/main.tf passes:
  pagerduty_integration_keys = jsondecode(secrets.pagerduty_keys.secret_string)
  → resolves to: { "payments" = "pd-key-xxx", "orders" = "pd-key-yyy", ... }
  → module: for_each = { payments: ..., orders: ..., notifications: ... }
  → Terraform creates 3 PagerDuty notification resources
```

```hcl
variable "services" {
  type = map(object({
    team             = string
    slo_target       = number
    health_check_url = string
    traffic_min_rps        = number
    error_rate_alert       = number
    latency_p99_ms         = number
    cpu_saturation_pct     = number
    memory_usage_pct       = number
    jvm_heap_pct           = number
    pod_restart_threshold  = number
    network_error_rate_pct = number
  }))
}
```

**Why typed objects (not just `any`):**
Terraform validates this at `terraform validate` and at the start of `terraform plan`. If you add a new service to `dev/main.tf` but forget `jvm_heap_pct`, Terraform fails BEFORE making any API calls:

```
Error: Missing required argument
  The argument "jvm_heap_pct" is required, but no definition was found.
```

You cannot ship a half-configured service. The type system enforces completeness.

---

## Part 4 — `main.tf` — The Module Logic

### Provider configuration

```hcl
terraform {
  required_providers {
    dynatrace = {
      source  = "dynatrace-oss/dynatrace"
      version = "~> 1.55"
    }
  }
}

provider "dynatrace" {
  dt_env_url   = var.dt_env_url
  dt_api_token = var.dt_api_token
}
```

The Dynatrace Terraform provider (`dynatrace-oss/dynatrace`) translates HCL resource declarations into DT REST API calls. Every `resource "dynatrace_*"` block becomes an API call to `https://<tenant>.live.dynatrace.com/api/...`.

`version = "~> 1.55"` pins to 1.55.x — allows patch updates, blocks 2.0 (which could break resource schemas). Without version pinning: `terraform init` could download 2.0 next month and break all plans.

### `locals` — the team deduplication

```hcl
locals {
  teams = toset([for svc in values(var.services) : svc.team])
}
```

**Step by step:**
```
var.services keys:
  "payment-service"      → team: "payments"
  "order-service"        → team: "orders"
  "notification-service" → team: "notifications"

values(var.services):
  → extracts just the objects (strips the service name keys)

[for svc in values(...) : svc.team]:
  → ["payments", "orders", "notifications"]

toset(...):
  → removes duplicates
  → { "notifications", "orders", "payments" }
```

**Why this matters:** Management zones and alerting profiles are per TEAM, not per SERVICE. If you add `"payments-audit-service"` with `team = "payments"`, it shares the existing "payments-production" management zone. The `toset()` ensures you don't create two duplicate management zones.

### Management zone resource

```hcl
resource "dynatrace_management_zone_v2" "team" {
  for_each    = local.teams
  name        = "${each.value}-${var.environment}"
```

`for_each = local.teams` creates **one management zone per unique team**:
- "notifications-production"
- "orders-production"
- "payments-production"

Each zone has three rules (SERVICE, PROCESS_GROUP, HOST), each with TWO conditions using AND logic:

```hcl
attribute_conditions {
  attribute = "SERVICE_TAGS"
  operator  = "TAG_KEY_EQUALS"
  tag_value = "team:${each.value}"             # e.g., "team:payments"
}
attribute_conditions {
  attribute = "SERVICE_TAGS"
  operator  = "TAG_KEY_EQUALS"
  tag_value = "environment:${var.environment}" # e.g., "environment:production"
}
```

**Why both conditions (AND, not OR):**
```
Scenario without environment condition:
  Zone "payments-production" matches all entities tagged team:payments
  → includes dev payment-service (also tagged team:payments)
  → dev noisy alerts appear in the production payments zone
  → dev pod restarts generate noise in the production dashboard
  
Scenario with both conditions:
  Zone "payments-production" matches:
    team:payments AND environment:production
  → ONLY production payment-service entities
  → dev and staging are completely excluded
  
Both conditions are mandatory for environment isolation in a shared DT tenant.
```

### Alerting profiles — the conditional creation pattern

```hcl
# CRITICAL — production ONLY
resource "dynatrace_alerting" "critical" {
  for_each = var.environment == "production" ? local.teams : toset([])
```

This is a ternary expression:
- If `var.environment == "production"`: `for_each = local.teams` → creates 3 profiles
- Otherwise: `for_each = toset([])` = empty set → creates 0 profiles

Dev and staging: `toset([])` → zero CRITICAL alerting profiles → zero PagerDuty CRITICAL notifications → nobody gets called for dev/staging availability problems.

```hcl
# HIGH — production + staging
resource "dynatrace_alerting" "high" {
  for_each = contains(["production", "staging"], var.environment) ? local.teams : toset([])
```

Staging oncall gets paged for HIGH (ERROR) severity. This is intentional — staging is where you run k6 load tests. If a deploy causes errors in staging, the team should know before it reaches production.

```hcl
# WARNING + INFO — all environments
resource "dynatrace_alerting" "warning" { for_each = local.teams }
resource "dynatrace_alerting" "info"    { for_each = local.teams }
```

Warning and info notifications go to Slack (not PagerDuty) in all environments. Dev engineers need to know when their dev service has latency issues or resource pressure — just via Slack, not a phone call.

### Traffic drop — the filter pattern

```hcl
locals {
  services_with_traffic = {
    for name, svc in var.services : name => svc
    if svc.traffic_min_rps > 0
  }
}

resource "dynatrace_metric_events" "traffic_drop" {
  for_each = local.services_with_traffic
```

`for name, svc in var.services : name => svc if svc.traffic_min_rps > 0`:
This is a **filter expression** that creates a NEW map containing only services where `traffic_min_rps` is greater than 0.

Dev sets `traffic_min_rps = 0` for all services → `services_with_traffic = {}` → zero traffic drop metric events in dev.

This is cleaner than:
```hcl
# BAD — conditional inside the resource:
resource "dynatrace_metric_events" "traffic_drop" {
  for_each = var.services
  count    = each.value.traffic_min_rps > 0 ? 1 : 0   # doesn't work with for_each
```

The filter creates the right set BEFORE the `for_each`, keeping the resource definition clean.

### The µs conversion (critical correctness)

```hcl
# Signal 3: LATENCY P99
model_properties {
  threshold = each.value.latency_p99_ms * 1000   # DT API uses microseconds
}
```

**This single multiplication prevents the most common Dynatrace Terraform mistake:**
```
What humans write:   latency_p99_ms = 300    (meaning: 300 milliseconds)
What DT API expects: threshold in microseconds

Without * 1000:
  threshold = 300 → Dynatrace reads as 300µs = 0.3ms
  Every request takes more than 0.3ms → alert fires on every single request
  Engineers see constant alerts → disable the alert → production unmonitored

With * 1000:
  threshold = 300 * 1000 = 300,000 µs = 300ms → correct
  Alert fires only when P99 exceeds 300ms
```

The variable is named `latency_p99_ms` (includes the unit). The conversion happens in the module once. Every caller can write human-readable millisecond values safely.

### SLO metric expressions

```hcl
resource "dynatrace_slo_v2" "availability" {
  metric_expression = <<-EOT
    100*(builtin:service.requestCount.server
      :filter(and(eq(service.name,"${each.key}"),eq(environment,"${var.environment}")))
      :splitBy():sum
      - builtin:service.errors.server.count
      :filter(and(eq(service.name,"${each.key}"),eq(environment,"${var.environment}")))
      :splitBy():sum)
    / builtin:service.requestCount.server
      :filter(and(eq(service.name,"${each.key}"),eq(environment,"${var.environment}")))
      :splitBy():sum
  EOT
```

**Breaking this down:**
```
The formula: 100 × (total_requests - errors) / total_requests

total_requests = builtin:service.requestCount.server
  filtered to: this specific service AND this environment

errors = builtin:service.errors.server.count
  filtered to: same service AND environment

Result: percentage of successful requests over the rolling window

Why the environment filter on the SLO:
  Without: SLO aggregates payment-service requests from dev + staging + production
  All environments share one DT tenant
  Dev has high error rate (intentional) → inflates the production SLO calculation
  With filter: each environment's SLO is calculated independently
```

```hcl
  error_budget_burn_rate {
    burn_rate_visualization_enabled = true
    fast_burn_threshold             = 14.4
    slow_burn_threshold             = 3.0
  }
```

These two numbers come from the Google SRE Workbook:
- **14.4×**: At this rate, 2% of the monthly budget is consumed in 1 hour. Budget exhausted in ~2 days. Requires immediate paging.
- **3.0×**: At this rate, 10% of the monthly budget is consumed per day. Budget exhausted in ~10 days. Requires same-day investigation.

DT automatically fires alerting profiles when burn rate exceeds these thresholds.

### HTTP Synthetic monitors

```hcl
resource "dynatrace_http_monitor" "health_check" {
  for_each  = var.services
  frequency = 5            # every 5 minutes
  locations = var.synthetic_locations   # ["Tokyo"] or ["Tokyo", "Singapore"]

  script {
    request {
      url = each.value.health_check_url   # https://payment.<env>.company.com/actuator/health
      validation {
        rule { type = "httpStatusesList";  value = "2xx" }
        rule { type = "patternConstraint"; value = "\"status\":\"UP\"" }
      }
      response_time_limit = each.value.latency_p99_ms * 3   # fail if >3× P99 SLO
    }
  }
```

**`for_each = var.services`**: creates one synthetic per service. No special filter needed — all services get synthetics in all environments.

**`response_time_limit = each.value.latency_p99_ms * 3`**: the synthetic fails if the health endpoint takes more than 3× the latency SLO. For prod payment-service (300ms P99): fails if health takes >900ms. This catches "extremely slow but technically UP" states.

**`var.synthetic_locations`**: the caller controls the locations list. Dev passes `["GEOLOCATION-6F55B7E4B5E7A52F"]` (Tokyo only). Production passes both Tokyo and Singapore. The module doesn't know or care which is which — it just runs checks from whatever list it receives.

---

## Part 5 — Environment Callers (`environments/<env>/main.tf`)

### State backend — isolation per environment

```hcl
# dev/main.tf:
backend "s3" {
  bucket = "company-terraform-state-dev"     ← dev-only bucket
  key    = "dev/terraform.tfstate"
}

# staging/main.tf:
backend "s3" {
  bucket = "company-terraform-state-staging" ← staging-only bucket
  key    = "staging/terraform.tfstate"
}

# production/main.tf:
backend "s3" {
  bucket = "company-terraform-state-prod"    ← production-only bucket
  key    = "production/terraform.tfstate"
}
```

**Why separate buckets (not separate keys in one bucket):**
```
If one bucket:
  IAM policy for dev Terraform: s3:* on company-terraform-state
  → dev CI can read/write staging and production state
  → A bug in dev CI pipeline could corrupt production state

Separate buckets:
  IAM policy for dev Terraform: s3:* on company-terraform-state-dev ONLY
  → dev CI cannot access staging or production state
  Even if dev credentials are compromised: blast radius = dev only
```

### Secrets — reading from Secrets Manager

```hcl
data "aws_secretsmanager_secret_version" "dt_api_token" {
  secret_id = "dev/dynatrace/api-token"      ← path-scoped to dev
}
data "aws_secretsmanager_secret_version" "slack_webhooks" {
  secret_id = "dev/dynatrace/slack-webhooks"
}
```

**`data` vs `resource`:**
```
resource "aws_secretsmanager_secret" "dt_api_token" { ... }
  → Terraform CREATES and MANAGES this secret. It appears in state.
  → terraform destroy would DELETE the secret.

data "aws_secretsmanager_secret_version" "dt_api_token" { ... }
  → Terraform READS this secret. It does NOT appear in state.
  → terraform destroy does nothing to the secret.
  → The secret was created separately (manually or by another TF module).
```

The DT API token is a secret that exists before any Terraform runs. `data` reads it at plan/apply time without taking ownership.

```hcl
# For dev: Slack only, no PagerDuty
slack_webhook_urls = jsondecode(
  data.aws_secretsmanager_secret_version.slack_webhooks.secret_string
)
# The secret value is stored as JSON in Secrets Manager:
# {"payments":"https://hooks.slack.com/XXX","orders":"https://hooks.slack.com/YYY",...}
# jsondecode() converts it to a Terraform map(string)
```

**Why store webhooks as a single JSON secret:**
```
Option A — 3 separate secrets:
  dev/dynatrace/slack-webhook-payments
  dev/dynatrace/slack-webhook-orders
  dev/dynatrace/slack-webhook-notifications
  → Adding a 4th team (infra) requires: new secret + edit dev/main.tf + PR + review + merge + apply

Option B — 1 JSON secret (this approach):
  dev/dynatrace/slack-webhooks
  → {"payments":"...", "orders":"...", "notifications":"...", "infra":"..."}
  → Adding infra: update JSON in Secrets Manager only
  → No Terraform code change needed
  → No PR, no review, no pipeline — the next terraform apply picks it up automatically

Terraform jsondecode() handles any map with any number of keys.
```

### The services map — single source of truth for thresholds

```hcl
services = {
  "payment-service" = {
    team             = "payments"
    slo_target       = 99.9
    health_check_url = "https://payment.company.com/actuator/health"
    
    traffic_min_rps        = 10
    error_rate_alert       = 0.1
    latency_p99_ms         = 300
    cpu_saturation_pct     = 70
    memory_usage_pct       = 75
    jvm_heap_pct           = 70
    pod_restart_threshold  = 2
    network_error_rate_pct = 0.5
  }
  ...
}
```

**This map is the ONLY place in the entire codebase where production monitoring thresholds live.** There is no spreadsheet, no wiki page, no Confluence doc that you need to keep in sync. To answer "what is the production error rate alert for payment-service?" → read this file. It's always current because Terraform is the only way to change DT config.

**The key names matter:** The key `"payment-service"` is used as:
1. The DT metric event filter: `value = "payment-service" key = "service.name"` → only measures this specific service
2. The DT resource name suffix: `"[PRODUCTION] payment-service: High error rate (>0.1%)"` → readable alert names
3. The SLO name: `"payment-service Availability [production]"` → findable in DT UI
4. The synthetic name: `"payment-service Health Check [production]"` → findable in DT UI

The key must exactly match the `OTEL_SERVICE_NAME` env var in the Helm values:
```yaml
# charts/payment-service/values.yaml:
env:
  - name: OTEL_SERVICE_NAME
    value: "payment-service"   ← must match the services map key
```
If they don't match, DT metric event entity filters find no matching service → metric events never fire → silent monitoring gap.

---

## Part 6 — CI/CD Pipelines for DT Terraform

### Three separate pipeline files (one per environment)

```
.github/workflows/
├── terraform-dynatrace-dev.yaml
├── terraform-dynatrace-staging.yaml
└── terraform-dynatrace-production.yaml
```

**Why separate files (unlike infra which uses a matrix):**

```
Infrastructure changes (EKS upgrades, VPC changes):
  Usually affect all 3 environments
  You want ALL 3 plans visible in one PR
  → Use matrix strategy, one file
  
Dynatrace changes (threshold adjustments):
  Often environment-specific (tune dev thresholds, don't touch prod)
  A dev DT change should NOT trigger a prod DT plan
  → Separate files with separate path triggers
  
  If one file with matrix:
    path: terraform/modules/dynatrace/**
    → dev threshold change triggers ALL 3 env plans
    → reviewer must scan 3 plan outputs when only 1 matters
    → noisy, confusing
  
  With separate files:
    terraform-dynatrace-dev.yaml triggers ONLY on:
      - terraform/environments/dev/**
      - terraform/modules/dynatrace/**   ← module changes affect all envs
    terraform-dynatrace-prod.yaml triggers ONLY on:
      - terraform/environments/production/**
      - terraform/modules/dynatrace/**
```

### Why both paths are listed in each workflow

```yaml
# terraform-dynatrace-dev.yaml:
on:
  push:
    paths:
      - 'terraform/environments/dev/**'
      - 'terraform/modules/dynatrace/**'   ← CRITICAL
```

**Scenario without `terraform/modules/dynatrace/**`:**
```
You fix a bug: latency metric event uses wrong entity dimension key.
Edit: terraform/modules/dynatrace/main.tf

CI path filter: only watches terraform/environments/dev/**
→ Module file changed, but dev/main.tf didn't change
→ dev CI does NOT trigger
→ dev still runs old buggy module

prod CI: same issue

Result: the bug is "fixed" but no environment picks up the fix
        until you also touch an env-specific file
        
With both paths:
Module change → ALL 3 env pipelines trigger → ALL 3 get the fix
```

### Plan job — read-only role

```yaml
jobs:
  plan:
    if: github.event_name == 'pull_request'
    steps:
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789010:role/github-actions-dynatrace-plan
```

The `plan` role has only:
- `secretsmanager:GetSecretValue` on `dev/dynatrace/*` paths
- `s3:GetObject` on the state bucket (to read current state)
- `dynamodb:GetItem` on the lock table (to read current locks)
- **NO Dynatrace write permissions** (Terraform reads DT state via the DT API using the token, but the `plan` role controls only AWS access)

Even if a malicious PR modifies a workflow file to exfiltrate credentials: the `plan` role credentials cannot create, modify, or destroy any DT or AWS resources.

### Plan output posted to PR

```yaml
- name: Post plan to PR
  uses: actions/github-script@v7
  with:
    script: |
      const plan = fs.readFileSync('plan.txt', 'utf8');
      github.rest.issues.createComment({
        body: `## Dynatrace Dev Plan\n\`\`\`\n${plan.substring(0,65000)}\n\`\`\``
      });
```

A typical plan comment looks like:
```
## Dynatrace Dev Plan
Terraform will perform the following actions:

  # dynatrace_metric_events.latency_p99["payment-service"] will be updated in-place
  ~ resource "dynatrace_metric_events" "latency_p99" {
      ~ model_properties {
          ~ threshold = 2000000 -> 1500000   # changed from 2000ms to 1500ms
        }
    }

Plan: 0 to add, 1 to change, 0 to destroy.
```

The reviewer sees EXACTLY what will change in DT before approving the PR. No surprises after merge.

`plan.substring(0,65000)`: GitHub PR comments have a size limit (~65,000 characters). Very large plans (many resources to change) would fail to post without this truncation.

### Apply job — write role + sequential execution

```yaml
jobs:
  apply:
    if: github.event_name == 'push'   ← only on merge, never on PRs
    steps:
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789010:role/github-actions-dynatrace-apply
```

The `apply` role has write permissions to DT (via the DT API token in Secrets Manager) and S3 write access to the state bucket. This role is ONLY assumed on `push` events (merges to main). A fork PR cannot trigger apply.

```yaml
# production workflow ONLY — one extra line:
jobs:
  apply:
    environment: production   ← GitHub pauses here for human approval
```

The GitHub `environment: production` setting requires REQUIRED REVIEWERS. The pipeline pauses after detecting the merge and waits for a human to click Approve before `terraform apply` runs. Any DT config change in production requires human sign-off — not just code review, but explicit approval of the apply.

---

## Part 7 — Day-2 Operations (Common Changes)

### Adding a new service to monitoring

```hcl
# Edit: terraform/environments/production/main.tf
services = {
  # ... existing services ...
  
  "inventory-service" = {       ← new entry
    team             = "platform"
    slo_target       = 99.5
    health_check_url = "https://inventory.company.com/actuator/health"
    
    traffic_min_rps        = 3
    error_rate_alert       = 0.5
    latency_p99_ms         = 400
    cpu_saturation_pct     = 80
    memory_usage_pct       = 80
    jvm_heap_pct           = 75
    pod_restart_threshold  = 2
    network_error_rate_pct = 1.0
  }
}
```

**What Terraform creates automatically from this one block:**
```
+ dynatrace_metric_events.traffic_drop["inventory-service"]
+ dynatrace_metric_events.error_rate["inventory-service"]
+ dynatrace_metric_events.latency_p99["inventory-service"]
+ dynatrace_metric_events.cpu_saturation["inventory-service"]
+ dynatrace_metric_events.memory_usage["inventory-service"]
+ dynatrace_metric_events.jvm_heap["inventory-service"]
+ dynatrace_metric_events.pod_restarts["inventory-service"]
+ dynatrace_metric_events.network_error_rate["inventory-service"]
+ dynatrace_slo_v2.availability["inventory-service"]
+ dynatrace_slo_v2.latency["inventory-service"]
+ dynatrace_http_monitor.health_check["inventory-service"]

And if "platform" is a new team (not in existing management zone):
+ dynatrace_management_zone_v2.team["platform"]
+ dynatrace_alerting.critical["platform"]   (production only)
+ dynatrace_alerting.high["platform"]
+ dynatrace_alerting.warning["platform"]
+ dynatrace_alerting.info["platform"]
+ dynatrace_pagerduty_notification.critical["platform"]
+ dynatrace_pagerduty_notification.high["platform"]
+ dynatrace_slack_notification.warning["platform"]
+ dynatrace_slack_notification.info["platform"]

Total: 19 DT resources created from adding ONE entry to the map.
Manual approach would require: clicking through 19 DT UI screens.
```

### Changing a threshold

```hcl
# Before (in production/main.tf):
latency_p99_ms = 300

# After (SRE decision: P99 is legitimately higher due to new feature):
latency_p99_ms = 400
```

**terraform plan output:**
```
~ dynatrace_metric_events.latency_p99["payment-service"] will be updated in-place
  ~ model_properties {
      ~ threshold = 300000 -> 400000
        # (from 300ms to 400ms, in microseconds)
    }
~ dynatrace_slo_v2.latency["payment-service"] will be updated in-place
  ~ metric_expression = <<-EOT
      100*(... le(builtin:service.response.time,300000) ...) -> 400000
    EOT
```

Note: Terraform automatically updates BOTH the metric event AND the SLO latency threshold, because both are derived from `latency_p99_ms`. You change one value; Terraform keeps everything consistent.

### Removing a service from monitoring

```hcl
# Remove "notification-service" from the services map in production/main.tf
services = {
  "payment-service" = { ... }
  "order-service"   = { ... }
  # notification-service removed
}
```

**terraform plan output:**
```
- dynatrace_metric_events.traffic_drop["notification-service"]     will be destroyed
- dynatrace_metric_events.error_rate["notification-service"]       will be destroyed
- dynatrace_metric_events.latency_p99["notification-service"]      will be destroyed
... (all 8 metric events)
- dynatrace_slo_v2.availability["notification-service"]            will be destroyed
- dynatrace_slo_v2.latency["notification-service"]                 will be destroyed
- dynatrace_http_monitor.health_check["notification-service"]      will be destroyed
```

All 11 DT resources for that service are cleanly destroyed. No orphaned alert rules. Compare to manual approach: you'd have to remember to delete 11 resources in the DT UI — and you'd probably forget some.

### Rotating PagerDuty integration keys

```
Situation: PagerDuty integration key needs rotation.

Option A (Terraform change):
  Edit production/main.tf → pagerduty_integration_keys = { "payments" = "new-key" }
  PR → review → merge → apply
  Downside: key visible in git history
  
Option B (Secrets Manager update — recommended):
  aws secretsmanager update-secret \
    --secret-id production/dynatrace/pagerduty-keys \
    --secret-string '{"payments":"new-key","orders":"new-key2","notifications":"new-key3"}'
  
  Next terraform apply (triggered by any change, or manually):
  ~ dynatrace_pagerduty_notification.critical["payments"] will be updated in-place
    ~ service_api_key = (sensitive value)  # changed
  
  Benefit: new key never appears in git. Only in Secrets Manager.
  Terraform picks it up automatically via jsondecode(data.aws_secretsmanager_secret_version...).
```

---

## Part 8 — Terraform State Management

### What the state file contains for DT resources

After `terraform apply`, the state file in S3 records every DT resource:

```json
{
  "resources": [
    {
      "type": "dynatrace_metric_events",
      "name": "latency_p99",
      "instances": [
        {
          "index_key": "payment-service",
          "attributes": {
            "id": "dt-metric-event-id-abc123",  ← DT internal ID
            "summary": "[PRODUCTION] payment-service: P99 latency >300ms",
            "model_properties": {
              "threshold": 300000
            }
          }
        }
      ]
    }
  ]
}
```

**Why the state file is critical:**
```
Terraform needs the DT internal ID (e.g., "dt-metric-event-id-abc123") to:
  - Update the resource (it calls PUT /api/v2/settings/objects/dt-metric-event-id-abc123)
  - Delete the resource (DELETE /api/v2/settings/objects/dt-metric-event-id-abc123)
  
Without state: Terraform doesn't know the DT ID → on next apply, it tries to CREATE
               a new resource instead of updating the existing one → duplicate alert rules.

State file IS the bridge between "Terraform HCL resource definition" and
"real DT resource with a DT-assigned ID."
```

### State locking

```hcl
dynamodb_table = "terraform-state-lock"
```

Before any `terraform apply`, Terraform writes a lock record:
```json
{
  "LockID": "company-terraform-state-prod/production/terraform.tfstate",
  "Info": "{\"Operation\":\"apply\",\"Who\":\"github-actions\",\"Created\":\"2026-07-31T14:23:07Z\"}"
}
```

If another apply starts simultaneously, it reads this lock and either waits or fails:
```
Error: Error acquiring the state lock

Error message: ConditionalCheckFailedException: The conditional request failed
Lock Info:
  ID:        abc123
  Path:      production/terraform.tfstate
  Operation: OperationTypeApply
  Who:       github-actions@ubuntu-runner
  Created:   2026-07-31 14:23:07 UTC
```

**Why this matters for DT config:** If two PRs are merged at the same time and both trigger `terraform apply`, without locking you'd have two processes simultaneously trying to modify the same DT resources — race conditions, partial updates, corrupted state.

### Drift detection

```yaml
# .github/workflows/terraform-infra.yaml (runs daily at 02:00 JST):
- name: Drift Detection
  run: |
    terraform plan -refresh-only -detailed-exitcode -no-color 2>&1 | tee drift.txt
    EXIT_CODE=${PIPESTATUS[0]}
    echo "has_drift=$([ $EXIT_CODE -eq 2 ] && echo 'true' || echo 'false')" >> $GITHUB_OUTPUT

- name: Create GitHub Issue on Drift
  if: steps.drift.outputs.has_drift == 'true'
```

**`-refresh-only`**: tells Terraform to only check what changed in the REAL DT tenant vs what the state file expects. It does NOT plan any config changes from your `.tf` files.

**What causes DT drift:**
```
1. Engineer manually edited a DT metric event via UI
   → Real DT threshold: 500ms
   → Terraform state: 300ms
   → Drift detected: "threshold 300000 → will be changed to threshold 300000"
     (Terraform will reset it back to the .tf-defined value on next apply)

2. DT provider version upgrade changed a resource's schema
   → State has old schema format
   → DT API returns new format
   → Drift detected: schema differences
   
3. Manual DT tenant cleanup deleted a resource
   → State: resource exists with ID abc123
   → Real DT: resource abc123 not found
   → Drift detected: resource will be re-created
```

Drift detection creates a GitHub Issue with the full diff, labeled `terraform-drift` and `production`. The SRE team sees it at the start of their workday (runs at 02:00 JST = detected at ~09:00 JST).

---

## Part 9 — Terraform Commands for Day-to-Day SRE Work

### Viewing current DT state without applying

```bash
# See all DT resources Terraform manages in production
cd terraform/environments/production
terraform show

# See a specific resource
terraform show -json | jq '.values.root_module.resources[] | select(.type == "dynatrace_metric_events") | {name: .name, index: .index, threshold: .values.model_properties[0].threshold}'

# What WOULD change if I applied right now?
terraform plan -no-color
```

### Targeting a specific resource (emergency changes)

```bash
# Only apply changes to payment-service latency alert, nothing else
terraform apply -target='dynatrace_metric_events.latency_p99["payment-service"]'

# Only apply the SLO for order-service
terraform apply -target='dynatrace_slo_v2.availability["order-service"]'
```

**Warning:** `-target` should only be used in emergencies (incident response). It creates state drift — some resources are applied, others are not. Always run a full `terraform apply` after to reconcile.

### Importing manually-created DT resources into state

```bash
# Situation: someone manually created a metric event in the DT UI.
# You want Terraform to manage it without destroying and recreating it.

# 1. Get the DT resource ID (from DT UI: Settings → API Explorer → GET metric events)
# 2. Add the resource definition to main.tf
# 3. Import:
terraform import 'dynatrace_metric_events.latency_p99["new-service"]' "DT-METRIC-EVENT-ID-xyz"

# Now Terraform manages the existing resource. Next plan should show no changes
# (if your HCL matches the existing configuration exactly).
```

### Destroying all DT config (environment teardown)

```bash
# Remove ALL DT monitoring for the dev environment
cd terraform/environments/dev
terraform destroy

# This will destroy ALL resources in state:
# - All metric events
# - All management zones
# - All SLOs
# - All synthetics
# - All notifications
# CAUTION: Do not run this for staging or production without explicit approval
```

---

## Part 10 — Common Mistakes and How to Detect Them

### Mistake 1: Wrong µs threshold

**Symptom:** Constant "P99 latency exceeded" alerts firing every minute, all services.

**Diagnosis:**
```bash
cd terraform/environments/production
terraform show -json | \
  jq '.values.root_module.resources[] | 
      select(.type == "dynatrace_metric_events" and (.name | contains("latency"))) | 
      {service: .index, threshold_us: .values.model_properties[0].threshold}'

# Output: { "service": "payment-service", "threshold_us": 300 }
# 300 µs = 0.3ms → wrong, should be 300000
```

**Fix:**
```hcl
# In main.tf, ensure the multiplication:
threshold = each.value.latency_p99_ms * 1000   # this line must exist
```

### Mistake 2: OTEL_SERVICE_NAME doesn't match services map key

**Symptom:** Metric events exist in DT but never fire. Services show traffic but no alerts.

**Diagnosis:**
```bash
# Check what service name DT is receiving in traces:
# DT UI → Services → click payment-service → check the service name
# If it shows "com.company.PaymentApplication" instead of "payment-service",
# the OTEL_SERVICE_NAME env var is wrong or missing.

kubectl get deployment payment-service -n payment-ns -o json | \
  jq '.spec.template.spec.containers[0].env[] | select(.name == "OTEL_SERVICE_NAME")'
```

**Fix:** Ensure `OTEL_SERVICE_NAME` exactly matches the key in `services = { "payment-service" = {...} }`.

### Mistake 3: Missing `alert_on_no_data = true` on traffic drop

**Symptom:** Service goes completely unreachable, no alert fires. All other signals show green.

**Diagnosis:**
```bash
# Check if alert_on_no_data is set correctly:
terraform show -json | \
  jq '.values.root_module.resources[] |
      select(.type == "dynatrace_metric_events" and (.name | contains("traffic_drop"))) |
      {service: .index, alert_on_no_data: .values.model_properties[0].alert_on_no_data}'
```

**Fix:**
```hcl
# In main.tf traffic_drop resource:
model_properties {
  alert_on_no_data = true   ← this must be true
  alert_condition  = "BELOW"
}
```

### Mistake 4: Module change not picked up by an environment

**Symptom:** Bug fixed in `modules/dynatrace/main.tf` but one environment still has old behavior.

**Diagnosis:**
```bash
# Check CI workflow trigger paths
cat .github/workflows/terraform-dynatrace-staging.yaml | grep -A5 "paths:"
# If terraform/modules/dynatrace/** is missing → staging won't trigger on module changes
```

**Fix:**
```yaml
paths:
  - 'terraform/environments/staging/**'
  - 'terraform/modules/dynatrace/**'   ← this must be present
```

### Mistake 5: State lock left after failed apply

**Symptom:** `terraform apply` fails with "state is locked" even when no apply is running.

**Diagnosis:**
```bash
cd terraform/environments/production
terraform force-unlock <LOCK_ID>
# LOCK_ID from the error message: "ID: abc-123-def-456"
```

**When to use force-unlock:** Only when you're certain no apply is actually running. If CI is still running, wait for it to finish or cancel the workflow first.

---

## Part 11 — Complete Workflow: Making a Threshold Change

### Step-by-step SRE workflow for changing a production threshold

**Context:** Production payment-service P99 is legitimately 350ms after a new feature launch. The alert fires every 30 minutes. SRE decides to raise the threshold to 450ms.

**Step 1: Create a branch**
```bash
git checkout -b threshold/payment-latency-450ms
```

**Step 2: Edit the threshold**
```bash
# terraform/environments/production/main.tf
# Change: latency_p99_ms = 300
# To:     latency_p99_ms = 450
```

**Step 3: Verify locally (optional but recommended)**
```bash
cd terraform/environments/production
terraform init          # if not already done
terraform validate      # syntax check
terraform plan          # see what will change (requires AWS credentials)
```

**Step 4: Create PR**
```
Title: threshold: raise payment-service P99 latency alert from 300ms to 450ms

Description:
  Context: New checkout flow adds 50-80ms for payment validation (intentional).
  P99 is now consistently 320-380ms, causing false alerts every 30 minutes.
  
  Change: latency_p99_ms: 300 → 450
  
  Impact: 
    - DT metric event threshold: 300ms → 450ms (300000µs → 450000µs)
    - DT latency SLO target: requests-within-300ms → requests-within-450ms
    
  Reviewed: payment team sign-off on new latency baseline (see #1234)
  Ticket: JIRA-5678
```

**Step 5: Review the CI plan comment**

CI automatically posts:
```
## Dynatrace Production Plan

~ dynatrace_metric_events.latency_p99["payment-service"] will be updated in-place
  ~ model_properties {
      ~ threshold = 300000 -> 450000
    }
  ~ summary = "[PRODUCTION] payment-service: P99 latency >300ms" -> "...>450ms"

~ dynatrace_slo_v2.latency["payment-service"] will be updated in-place
  ~ metric_expression = <<-EOT
      - 100*(... le(builtin:service.response.time,300000) ...)
      + 100*(... le(builtin:service.response.time,450000) ...)
    EOT

Plan: 0 to add, 2 to change, 0 to destroy.
```

**Step 6: PR approval**
- First reviewer: another SRE confirms the latency baseline investigation
- Second reviewer: payment team lead confirms the new baseline is intentional

**Step 7: Merge**
CI triggers `terraform-dynatrace-production.yaml` apply job. Because `environment: production`, GitHub PAUSES and shows:

```
Required reviewers — 1 approver needed before deploying to production
[Review deployments] button
```

SRE clicks "Review deployments" → confirms the plan once more → clicks Approve.

**Step 8: Terraform apply runs**
```
dynatrace_metric_events.latency_p99["payment-service"]: Modifying... [id=abc123]
dynatrace_metric_events.latency_p99["payment-service"]: Modifications complete after 2s

dynatrace_slo_v2.latency["payment-service"]: Modifying... [id=def456]
dynatrace_slo_v2.latency["payment-service"]: Modifications complete after 1s

Apply complete! Resources: 0 added, 2 changed, 0 destroyed.
```

**Step 9: Verify in DT UI**
DT → Settings → Anomaly detection → Metric events → search "payment-service P99"
→ threshold now shows 450ms

DT → SLOs → "payment-service Latency P99 [production]"
→ metric expression now uses 450000µs

**Total time:** ~15 minutes (writing, PR, review, approve, apply)
**Audit trail:** git commit, PR comments, GitHub Actions log — all permanent
**Rollback:** Revert the PR → revert merge → CI applies old threshold automatically
