# Glossary — SRE Monitoring Deep Dive
Every term from main.md. One entry per term. SRE beginner level.

---

**Monitoring**
The practice of continuously collecting data about a system's behaviour and sending alerts when that behaviour deviates from expected. Why it matters: the difference between "customer calls to report a failure" (30+ min of user impact) and "alert fires at 14:32:05" (0.3ms after the problem starts).

**Observability**
The ability to understand the internal state of a system from its external outputs (metrics, traces, logs). Monitoring = "is it broken?" Observability = "why is it broken?" Why it matters: you can't fix what you can't understand — observability gives you the tools to reason about failures.

**The 7 monitoring layers**
Infrastructure → Container/Pod → JVM/Runtime → Application Metrics → Distributed Traces → Synthetic → Business Metrics. Each layer catches what the one below cannot. Why it matters: a system with only HTTP metrics monitoring is blind to JVM heap pressure, DNS failures, and business outcome failures.

**Leading indicator vs lagging indicator**
Leading: a metric that warns you BEFORE users are affected (JVM heap at 70% → OOM coming in 30 min). Lagging: a metric that only shows you after users are already affected (customer support tickets, revenue drop). Why it matters: SRE goal is leading indicators — detect before users notice.

**OneAgent DaemonSet**
A Dynatrace agent deployed as one pod per EKS node. Reads OS-level metrics directly from `/proc`, injects JVMTI into all Java processes, reads container logs, and sends everything to DT ActiveGate. Why it matters: one component replaces Prometheus node-exporter, Java APM agent, and Fluent Bit.

**`/proc/stat`, `/proc/meminfo`, `/proc/net`**
Linux pseudo-files exposed by the kernel containing real-time system statistics. CPU stats, memory usage, network interface stats. OneAgent reads these directly. Why it matters: ground truth — these are the source data, not derived metrics. OneAgent on `hostNetwork: true` can access these from inside the pod.

**`builtin:host.cpu.usage`**
DT auto-captured metric for the EKS node's overall CPU utilization percentage. Why it matters: a node at 90% CPU means ALL pods on that node are being throttled — multiple services slow simultaneously for the same infrastructure reason.

**`builtin:host.net.errorRate`**
DT metric for the percentage of network packets on the host that fail (TCP errors, dropped packets, NIC errors). Why it matters: network errors at the host level cause intermittent request failures that don't always show as HTTP 5xx — a separate, independent monitoring layer.

**cgroup (control group)**
A Linux kernel feature that limits and isolates resource usage (CPU, memory) for a group of processes. Kubernetes uses cgroups to enforce container resource limits. Why it matters: when a container exceeds its memory cgroup limit, the kernel OOM-kills it instantly. Container monitoring measures usage against the cgroup limit.

**CPU throttling**
When a container tries to use more CPU than its cgroup limit allows, the Linux kernel pauses the process for a fraction of each time period. The container runs 83% of the time instead of 100%. Why it matters: throttled containers serve requests 17% slower — causes latency degradation that's invisible from infrastructure-level monitoring.

**OOM Kill**
Out-of-Memory Kill — the Linux kernel kills a process immediately when it exceeds its memory cgroup limit. No graceful shutdown. All in-flight requests handled by that pod fail instantly. Why it matters: causes pod restarts, in-flight request failures, and CrashLoopBackOff if the cause isn't fixed.

**Pod restart (Kubernetes)**
When a container inside a pod crashes (OOM kill, liveness probe failure, unhandled exception), Kubernetes automatically starts a new container. Why it matters: indicates a serious problem — production pods should never restart. Any restart is worth investigating immediately.

**CrashLoopBackOff**
Kubernetes state where a pod keeps crashing and restarting. Kubernetes adds exponential backoff between restart attempts to avoid overwhelming the system. Why it matters: a service in CrashLoopBackOff is effectively unavailable — new starts fail faster than traffic can be served.

**JVMTI (Java Virtual Machine Tool Interface)**
A Java API that allows external agents to hook into a running JVM at a low level — capturing method calls, memory allocations, GC events. OneAgent uses JVMTI to auto-instrument Java. Why it matters: no code changes needed. OneAgent injects at JVM startup and captures everything.

**`builtin:process.memory.jvm.heapUtilization`**
DT metric for JVM heap used as a percentage of `-Xmx`. Captured by OneAgent via JVMTI. Why it matters: the primary early warning for memory problems — fires 30-60 minutes before an OOM kill if properly thresholded.

**`builtin:process.memory.jvm.garbageCollectionTime`**
DT metric for total milliseconds spent in GC pauses per minute. Normal: 10-30ms/min. Warning: 50-150ms/min. Critical: >200ms/min. Why it matters: rising GC time is the direct cause of P99 latency spikes — GC pauses freeze all threads, including those handling user requests.

**`builtin:process.jvmThreadCount`**
DT metric counting active JVM threads. A growing thread count that never decreases = thread leak. A flat but high count = thread pool exhaustion. Why it matters: each JVM thread consumes ~512KB stack memory. 1,000 threads = 500MB consumed before any heap is allocated.

**`builtin:process.cpu.usage`**
DT metric for CPU used by the JVM process as a percentage. Different from node-level CPU. Why it matters: one JVM can be at 90% CPU while the node is at 40% — the JVM is the bottleneck, not the infrastructure.

**`builtin:process.memory.usage`**
DT metric for RSS (physical memory) as a percentage of the container memory limit. Covers all memory: heap + off-heap (code cache, thread stacks, JVM metadata, NIO buffers). Why it matters: RSS > container limit = OOM kill. Alert at 75% (not 90%) gives time to act before the kill.

**RSS (Resident Set Size)**
The actual physical memory a process is using at this moment. For a JVM: heap + off-heap. Kubernetes enforces memory limits against RSS. Why it matters: `-Xmx=1024m` doesn't mean the JVM only uses 1024m total — it uses 1024m heap PLUS off-heap. Container limit must account for both.

**Four Golden Signals**
Google SRE's framework for what every service must monitor: Traffic, Errors, Latency, Saturation. Together they describe the complete health picture of a service. Why it matters: if you monitor only some of them, you have blind spots that will manifest as missed incidents.

**Traffic (requests per minute)**
The rate of requests hitting the service. The foundation — all other metrics are relative to traffic. Zero traffic = all other metrics are meaningless. Why it matters: traffic drop is the only signal that catches silent outages (DNS broken, ALB misconfigured) where everything else looks healthy.

**`alert_on_no_data = true`**
A DT metric event setting that fires the alert even when DT receives ZERO data points for a metric. Only used on the traffic drop signal. Why it matters: if a service crashes so hard it stops sending any metrics, this flag still fires the alert — catches complete blackouts.

**`alert_condition = "BELOW"`**
The only DT metric event that fires when a value DROPS BELOW the threshold. Used for traffic drop (traffic < 10 req/min = alert). All other 7 signals use "ABOVE." Why it matters: traffic is the one metric where "too low" is the problem — every other metric alerts on excess.

**Error rate (HTTP 5xx %)**
The percentage of requests returning server error status codes (500, 502, 503, 504). Why it matters: direct measure of user-facing failures. Each 5xx = one user request that failed.

**Why HTTP 4xx is not counted as server error**
4xx = client error (bad request, unauthorized, not found). These are the CLIENT's fault, not the server's. Counting them in error rate: every invalid URL someone accesses would inflate the error rate. Why it matters: separating 4xx from 5xx gives a clean signal for YOUR service's reliability, not client behavior.

**P99 (99th percentile)**
The response time below which 99% of requests complete. If P99 = 300ms: 99 out of 100 requests finished in under 300ms; 1 in 100 took longer. Why it matters: P99 shows the worst realistic user experience — not the average that hides slow outliers.

**Bimodal latency distribution**
When the latency distribution has two peaks — most requests are fast (e.g., 150ms) but a significant tail is very slow (e.g., 2000ms). Indicates two distinct code paths with different performance. Why it matters: the average looks fine (200ms maybe) but some users are experiencing terrible performance. Only P99 or distribution analysis reveals this.

**Saturation (leading indicator)**
How "full" a resource is (CPU, memory, heap, thread pool, connection pool). Unlike errors and latency (lagging — users already affected), saturation fires before users notice. Why it matters: fixing saturation before it cascades into errors and latency is the highest-value monitoring activity.

**The progressive JVM warning system**
JVM heap fills (early warning) → CPU rises (GC competing) → memory approaches limit (danger) → OOM kill (users impacted). With monitoring at each stage: 30–60 minutes to act before user impact. Without: first alert is the OOM kill. Why it matters: monitoring the chain gives time to fix rather than firefight.

**Distributed trace**
A record of ONE request's complete journey through ALL services it touched, with timing for every step. Shows: which service/component is the bottleneck, which DB query is slow, N+1 query patterns. Why it matters: impossible to identify root cause of multi-service latency issues from metrics alone.

**Trace ID**
A unique identifier (e.g., `abc123def456`) that follows a request through every service. All spans belonging to the same request share the same trace ID. Why it matters: enables stitching spans from different services into one connected trace — the foundation of distributed tracing.

**Span**
One unit of work in a distributed trace. One service's contribution to a request — has start time, duration, service name, operation name, and whether it errored. Why it matters: the widest span at the deepest level in the trace is almost always where the bottleneck is.

**OTEL (OpenTelemetry)**
Open standard for distributed tracing, metrics, and logs. Java Spring Boot exports traces and custom metrics via OTEL to DT ActiveGate. Why it matters: vendor-neutral standard — the same instrumentation can send data to DT, Jaeger, Prometheus, or any other backend without code changes.

**`OTEL_SERVICE_NAME`**
Environment variable that tells the OTEL SDK what service name to report in spans and metrics. Without it: all services appear as "unknown" in DT traces. Why it matters: DT uses this to group spans by service and display the correct service name in the trace waterfall.

**Trace sampling**
The practice of storing only a subset of traces to control storage cost. Our strategy: 100% for errors and slow requests; 10% for normal requests. Why it matters: 100% sampling at production scale = terabytes/day of storage. 10% sampling = 90% storage reduction with minimal statistical impact.

**Synthetic monitoring**
Sending scheduled HTTP requests from external locations (Tokyo, Singapore) to simulate real user access and validate the full request path works from outside. Why it matters: the only layer that catches DNS failures, ALB misconfigurations, TLS expiry, and CDN issues — all of which make the service unreachable to users while OneAgent shows everything as healthy.

**`patternConstraint` (synthetic validation)**
A DT synthetic validation rule that checks the response body contains a specific string (`"status":"UP"`). Why it matters: HTTP 200 is not enough — Spring Boot can return 200 with `{"status":"DOWN"}` if a dependency is unhealthy. Body validation confirms true application health, not just HTTP layer health.

**Global outage (synthetic)**
All synthetic locations simultaneously fail to reach the service. `global_consecutive_outage_count_threshold = 1` = alert on the very first failure from all locations. Why it matters: if both Tokyo and Singapore can't reach the service, it's almost certainly truly down — immediate alert is correct.

**Local outage (synthetic)**
Only one geographic location fails. `local_consecutive_outage_count_threshold = 3` = need 3 consecutive failures before alerting. Why it matters: a single location failure is often a 30-second transient network blip. 3 consecutive = 15 minutes of sustained regional issue = real problem worth investigating.

**Business metric**
A custom OTEL metric emitted by application code to measure actual business outcomes (payment completed, order created, notification processed). Not captured automatically — requires `meterRegistry.counter()` calls in the Java code. Why it matters: HTTP 200 ≠ business success. Only custom metrics reveal the difference.

**`ext:custom.*` (DT metric namespace)**
DT metric namespace for app-emitted custom metrics. `ext:custom.business.transaction.success.count` vs `builtin:service.requestCount.server`. Why it matters: DT cannot auto-capture business logic — the app must emit these. Business SLOs depend entirely on custom metrics being present.

**MeterRegistry (Spring Boot / Micrometer)**
Spring Boot's metrics interface. `meterRegistry.counter("name", tags...).increment()` records a counter that Micrometer exports via OTEL to DT. Why it matters: the Java API for emitting the custom business metrics that business SLOs depend on.

**Log correlation (log-trace)**
DT feature: click a log line → see the distributed trace for that request. Or: click a trace → see all log lines from that request. Why it matters: eliminates manual trace ID cross-referencing between separate tools — one click connects the error message (log) to the full call chain (trace).

**DT Grail**
Dynatrace's log analytics and storage engine. Stores and indexes container logs. Supports structured JSON queries (`level = "ERROR" AND pool.waiting > 40`). Why it matters: replaces Elasticsearch/Kibana or CloudWatch Logs — logs are automatically correlated with DT entities (services, processes, pods).

**Structured logging (JSON logs)**
Writing log output as JSON objects instead of plain text strings. Each field (level, traceId, message) is a queryable field. Why it matters: JSON logs enable precise queries in DT Grail (`pool.waiting > 40`). Plain text logs only support string matching.

**Davis AI**
DT's built-in AI engine that automatically groups related alerts into one Problem, infers causality, and suggests root causes. Named after the founder's dog. Why it matters: correlates "memory spike + deployment event + latency spike" into one Problem and says "correlated with deployment at 14:20" — saves 5-10 minutes of manual correlation.

**Management zone (DT)**
A logical grouping in DT that defines which entities a team can see and which alerts they receive. `payments-production` = only payment-service entities tagged `team:payments` AND `environment:production`. Why it matters: prevents cross-team alert noise — orders team doesn't receive payment-service alerts.

**Alerting profile (DT)**
A DT configuration defining which problem types (AVAILABILITY, ERROR, SLOWDOWN, RESOURCE_CONTENTION) route to which notification channel, with what delay. 4 tiers in this project: critical (PagerDuty call, 0 min) → high (PagerDuty push, 2 min) → warning (Slack, 5 min) → info (Slack, 15 min). Why it matters: ensures the right severity reaches the right person at the right time.

**Alert routing chain**
The sequence: DT detects problem → Davis AI creates Problem → Management zone scopes it → Alerting profile fires → Notification rule sends to PagerDuty/Slack → on-call engineer paged. Why it matters: each link must be correctly configured. Missing one link = alert fires silently, nobody is paged.

**Runbook**
A step-by-step operational guide for responding to a specific alert. Contains: immediate actions, investigation steps, common fixes, escalation path, related links. Why it matters: enables a half-asleep engineer to handle incidents they've never seen before by following documented procedures — reduces MTTA and MTTR.

**Alert fatigue**
When too many false or low-value alerts fire, engineers start ignoring ALL alerts — including real ones. The #1 failure mode of monitoring. Why it matters: a team that receives 20 false alerts per day will eventually stop responding to all alerts. The 21st alert, which is real, gets ignored.

**Noise ratio**
The proportion of alert firings that were false positives (acknowledged + resolved with no action). Target: <20%. >50% = threshold is wrong, fix it. Why it matters: measuring noise ratio weekly and tuning thresholds is how you drive alert fatigue down over time.

**`violating_samples = 3` out of `samples = 5`**
"Alert fires only when 3 of the last 5 one-minute data points exceed the threshold." Prevents single-minute spikes from triggering. Why it matters: a 60-second CPU spike during GC is normal. Three consecutive minutes of elevated CPU = real problem. The ratio determines sensitivity vs noise.

**Monitoring completeness**
Having all 7 layers correctly configured, with runbooks for every alert, before a service receives production traffic. Why it matters: discovering monitoring gaps during a real incident is too late. The reliability review checklist ensures gaps are found during pre-launch review.
