# Monitoring — SRE Deep Dive
## What It Is, Why It Exists, How Every Layer Works

> Context: 3 Java Spring Boot microservices (payment, order, notification) on AWS EKS,
> observed with Dynatrace, alerting via PagerDuty and Slack.
>
> This guide covers monitoring from first principles through every practical layer.

---

## What Monitoring Actually Is (First Principles)

```
Monitoring = the practice of continuously observing a system's behaviour
             and being notified when that behaviour deviates from expected.

Without monitoring:
  How do you know the payment-service is broken?
  Option A: a customer calls support ("I can't pay")
  Option B: revenue drops at end of month → accounting notices
  Option C: you look at the server and it's crashed

With monitoring:
  How do you know?
  → Dynatrace alert fires at 14:32:05 (0.3ms after the error rate crosses 0.1%)
  → PagerDuty pages on-call engineer at 14:32:10
  → Engineer acknowledges at 14:34:00
  → Resolution at 14:52:00

Customer-reported vs monitoring-detected:
  Customer reports mean users have ALREADY been suffering.
  Monitoring detects the problem and pages you BEFORE enough users
  experience it to call support.

The goal: detect before users notice.
```

---

## The Monitoring Stack — 7 Layers

```
LAYER 7: Business Metrics       ← "did the payment actually succeed?"
LAYER 6: Synthetic Monitoring   ← "can I reach this URL from outside?"
LAYER 5: Application Traces     ← "where in the call chain is time spent?"
LAYER 4: Application Metrics    ← "what % of requests are failing?"
LAYER 3: JVM / Runtime          ← "is the Java process healthy?"
LAYER 2: Container / Pod        ← "is the container within its resource limits?"
LAYER 1: Infrastructure         ← "is the EKS node alive?"

Each layer catches what the layer below cannot.
Example: Layer 1 (node) looks healthy → Layer 4 (app) shows 100% errors.
  → The node is fine but the application code is broken.
  → Without Layer 4 you would have no idea.

You need ALL 7 layers. Each has blind spots the others cover.
```

---

## Part 1 — Layer 1: Infrastructure Monitoring

### What it monitors

```
EKS Nodes (EC2 instances running the cluster):
  CPU utilization:   how much compute is being used
  Memory usage:      how much RAM is being used
  Disk space:        how full the storage is
  Network I/O:       bytes in/out, packet error rate
  Node count:        how many nodes are in the cluster (vs desired)

Why nodes matter:
  Every pod runs ON a node.
  A node at 95% CPU → ALL pods on that node are throttled → ALL services slow.
  A node's disk full → container logs stop writing → logging goes silent.
  A node fails → pods on it are evicted → HPA must replace them.
```

### How Dynatrace collects node metrics

```
OneAgent DaemonSet (one pod per node):
  classicFullStack: enabled: true in DynaKube config
  → OneAgent pod runs ON the host network (hostNetwork: true)
  → Reads directly from /proc/stat (CPU), /proc/meminfo (memory), /proc/net (network)
  → No kubectl, no kube-state-metrics — reads OS-level data directly

Metrics auto-captured (no configuration needed):
  builtin:host.cpu.usage          → node CPU %
  builtin:host.mem.usage          → node memory %
  builtin:host.disk.usedPct       → disk space %
  builtin:host.net.errorRate      → packet error %
  builtin:host.net.bytesRcvd      → network receive throughput
```

### Infrastructure alert we have (Signal 8)

```hcl
# From terraform/modules/dynatrace/main.tf
resource "dynatrace_metric_events" "network_error_rate" {
  metric_key = "builtin:host.net.errorRate"
  threshold  = each.value.network_error_rate_pct  # prod: 0.5–1.0%
  # Fires on HOST entity — not service entity
  # Scoped by environment tag (not service.name — hosts don't have a service.name)
}
```

```
Why network error rate matters:
  Packet errors between the ALB and pods → some HTTP requests get TCP errors
  → Intermittent 504 timeouts that don't show as application-level 5xx
  → Standard error rate SLO misses it (no HTTP error code was generated)
  → Network alert catches it at the infrastructure layer

What it catches that HTTP error rate misses:
  TCP resets (RST packets)
  MTU mismatches causing fragmentation drops
  Node NIC (Network Interface Card) hardware errors
  AWS ENI (Elastic Network Interface) attachment issues
```

---

## Part 2 — Layer 2: Container / Pod Monitoring

### What it monitors

```
Per-container metrics (inside the pod's cgroup):
  Container CPU:    actual CPU used by this container vs its request/limit
  Container memory: RSS memory vs the container's memory limit

Kubernetes workload metrics:
  Pod count:        running pods vs desired (are all 3 payment-service pods up?)
  Pod restarts:     how many times has a pod restarted (crash indicator)
  Pod pending:      pods waiting for a node (capacity problem?)
  Node pressure:    is a node under memory/disk pressure (evicting pods?)
```

### The pod restart signal (Signal 7)

```hcl
resource "dynatrace_metric_events" "pod_restarts" {
  metric_key  = "builtin:kubernetes.workload.pods.restarts"
  resolution  = "5m"        # look at restarts in a 5-minute window
  threshold   = each.value.pod_restart_threshold  # prod: 2, staging: 3, dev: 5
  violating_samples = 1     # even 1 data point above threshold fires
  samples           = 1     # no "3 out of 5" — any restart event is significant
}
```

```
Why pod restarts are a critical signal:
  A restart = the container died and Kubernetes restarted it.

  Causes of restarts (in order of frequency):
    1. OOM Kill:     container used more memory than its limit → kernel killed it instantly
    2. Liveness probe fail: app is stuck/deadlocked → Kubernetes kills and restarts
    3. App crash:    unhandled exception at startup, JVM crash
    4. Config error: missing env var, wrong secret path → app can't start

  Impact of restarts:
    ALL in-flight requests to that pod at the moment of restart: FAIL immediately
    Users see: HTTP 503 (connection refused) or HTTP 502 (bad gateway from ALB)
    Brief error spike in error rate SLO

  Why production threshold = 2 (not 1)?
    Rolling deploys create 1 restart per pod (old pod terminated, new pod starts).
    Threshold = 1 would fire on every single deploy.
    Threshold = 2 = must restart TWICE in 5 minutes = crash loop starting.

  CrashLoopBackOff vs threshold:
    1 restart: threshold = 2 → no alert (could be a deploy)
    2 restarts in 5 min: alert fires → engineer investigates
    If not fixed: 4, 8, 16 seconds between restarts (exponential backoff) → CrashLoopBackOff
```

### Container resource limits and monitoring

```
Why monitoring container CPU/memory separately from node:
  A node at 40% CPU might have one container at 100% CPU (hitting its limit).
  Node-level view: "everything is fine, 40% CPU"
  Container-level view: "payment-service is CPU throttled at 100% of its limit"

  CPU throttled container:
    Container tries to use 1.2 CPU cores, its limit is 1 CPU (1000m).
    Linux cgroups throttle it: 83% of its time, it runs. 17% of its time, it's paused.
    From the service perspective: requests are processing ~17% slower than they should.
    This shows as latency degradation, not errors.

  Memory limit exceeded:
    Container uses 1.1 GiB, its limit is 1 GiB.
    OOM Kill: Linux kernel kills the process INSTANTLY (no graceful shutdown).
    Pod restarts. In-flight requests fail.
```

---

## Part 3 — Layer 3: JVM / Runtime Monitoring

### What it monitors

```
Java-specific metrics captured by OneAgent via JVMTI (zero code change):

Heap:
  builtin:process.memory.jvm.heapUtilization   → % of Xmx used by Java objects
  
GC (Garbage Collection):
  builtin:process.memory.jvm.garbageCollectionTime → ms/min spent in GC pauses
  
Threads:
  builtin:process.jvmThreadCount               → number of active JVM threads

Class loading:
  builtin:process.jvmClassLoadedCount          → loaded classes (slowly growing = memory leak risk)

Process-level:
  builtin:process.cpu.usage                    → CPU used by this JVM process
  builtin:process.memory.usage                 → RSS (physical memory) as % of container limit
```

### The progressive JVM warning system

```
THREE SIGNALS work together as an early warning system:

SIGNAL 6: JVM Heap (threshold: 70% in production)
  "The heap is filling up"
  Fires BEFORE any user impact.
  At 70% heap: G1GC starts running more aggressive collection cycles.
  If not addressed: heap continues to grow → GC thrashes → latency spikes.
  Time to act: typically 30–60 minutes before user impact.

SIGNAL 4: CPU Saturation (threshold: 70% in production)
  "GC is competing for CPU"
  Often fires TOGETHER with heap signal (high heap → heavy GC → high CPU).
  At this point: P99 latency is probably already rising.
  Time to act: 5–15 minutes before significant user impact.

SIGNAL 5: Memory Usage (threshold: 75% in production)
  "RSS is approaching the container limit"
  RSS = heap + off-heap (code cache, thread stacks, JVM metadata).
  At 75% RSS: OOM kill is coming within minutes if the trend continues.
  Time to act: immediate — restart the pod or scale out now.

The chain in a memory leak scenario:
  00:00 heap grows to 70%     → Signal 6 fires (Slack INFO) → "investigate when you can"
  00:30 heap at 78%, CPU 72%  → Signal 4 fires (Slack WARNING) → "investigate now"
  00:45 RSS at 76%            → Signal 5 fires (Slack WARNING) → "act immediately"
  01:00 RSS at 95%            → OOM Kill → pod restarts → Signal 7 fires (PagerDuty push) → "users impacted"
  
Without the three early signals: the first alert would be Signal 7 (users already impacted).
With the chain: you have 45–60 minutes to fix before users notice.
```

### JVM heap: what the numbers mean

```
payment-service production:
  -Xmx = 1024m (max heap)
  Normal load: heap at 30–50% (307–512MB in use)
  Peak load:   heap at 55–65% (563–665MB)
  
  Alert at 70% = 716MB:
    Above the normal peak-load level.
    Signals: either load is unusually high, OR heap usage is growing (leak).
    At 70%: G1GC concurrent marking kicks in more aggressively.
    
  At 85% = 870MB:
    G1GC running very frequent minor collections.
    Likely causing thread pauses → P99 latency rising.
    
  At 95% = 972MB:
    Full GC running (stop-the-world).
    ALL threads paused for 2–10 seconds.
    Every in-flight request stalls.
    OOM kill imminent if GC can't free enough memory.

payment-service dev:
  -Xmx = 256m (max heap)
  Spring Boot idle:   ~180MB = 70% at startup (before any requests)
  Alert at 85% = 218MB:
    Only fires when heap is truly stressed (above idle + buffer).
    At 70% threshold: alert fires the moment Spring Boot loads → useless alert.
```

---

## Part 4 — Layer 4: Application Metrics (The Four Golden Signals)

### Signal 1: Traffic (Request Rate)

```
Metric: builtin:service.requestCount.server
Unit:   requests per minute
Chart:  should show a predictable pattern (peaks during business hours, troughs at night)

Why traffic is the foundation:
  ALL other signals are derived from or relative to traffic.
  Error rate = errors / traffic. If traffic = 0: error rate = 0% (misleading).
  Latency = response time per request. If traffic = 0: latency = "no data" (misleading).
  
  Traffic = 0 when the service IS broken (silent outage).
  That is why traffic drop is Signal 1 — the most important signal.

The traffic drop alert:
  production payment-service: fires when < 10 req/min
  Based on: 30-day minimum observed during quiet hours (midnight–6am) × 50%
  
  How to read traffic patterns:
    Steady baseline: healthy (consistent traffic, no anomalies)
    Sudden drop: ALB unhealthy, DNS failure, Ingress misconfigured, service crashed
    Sudden spike: viral event, bot attack, retry storm (clients retrying failed requests)
    Gradual decline: normal time-of-day pattern (not an alert)
```

### Signal 2: Error Rate

```
Metric: builtin:service.errors.server.rate
Unit:   percentage (0–100%)
What DT counts as an error:
  HTTP 5xx (500, 502, 503, 504) → SERVER errors (your service's fault)
  HTTP 4xx are NOT counted as server errors in DT by default
    (4xx = client's fault — they sent a bad request)
  Exception thrown without HTTP response
  Request timeout

payment-service production threshold: 0.1%
  Means: 1 in 1,000 payment requests fails → ALERT.
  Why so strict?
    Each error = 1 user whose payment failed.
    Failed payments = direct revenue loss + user trust damage.
    "Only 0.1% failing" = still ~50 failed payments/hour at normal load.

notification-service production threshold: 1.0%
  Means: 1 in 100 notification requests fails → ALERT.
  Why relaxed?
    Async service — email/SMS delivery has inherent transient failures.
    External SMTP servers, Twilio API, email bounces — all outside our control.
    1% sustained = something systemic is wrong (not just normal delivery failures).

The error rate chart patterns:
  Spike then recover: rolling deploy (brief errors during pod replacement) — normal
  Spike sustained:    bug in new code, DB down, dependency failed — alert fires
  Gradual creep:      slow memory leak causing occasional timeouts — slow burn SLO alert
  100% errors:        complete service failure — CRITICAL alert fires
```

### Signal 3: Latency (P99 Response Time)

```
Metric:      builtin:service.response.time:percentile(99)
Unit:        microseconds internally (DT), shown as ms in UI
Why P99:     protects the worst 1% of users, not just the average

payment-service threshold: 300ms
  This means: 99% of payment requests must complete within 300ms.
  The 1% that are slower: not alerted on individually.
  But if the P99 consistently exceeds 300ms: alert fires.

Average vs P99:
  100 requests. 99 take 50ms. 1 takes 5,000ms.
  Average: (99×50 + 1×5000) / 100 = 99.5ms → "service is fast"
  P99: 5,000ms → "1% of users waited 5 seconds"
  
  Monitoring only the average: completely misses users having terrible experiences.
  P99 catches: that one slow request that's probably stuck waiting for a DB lock,
               GC pause coincidence, connection pool exhaustion, etc.

The latency distribution tells a story:
  P50 = 150ms, P95 = 200ms, P99 = 300ms, P99.9 = 1200ms:
    → Healthy: most requests fast, occasional slow ones (1 in 1000 = 1.2s)
    → Normal for a production Java service with occasional GC pauses

  P50 = 150ms, P95 = 180ms, P99 = 850ms, P99.9 = 4000ms:
    → Bimodal distribution: two populations (fast normal requests + very slow requests)
    → Cause: specific endpoint or code path much slower than others
    → Investigation: DT trace filtering → which endpoint is slow?

  P50 = 800ms, P95 = 1200ms, P99 = 2000ms:
    → Everything is slow, not just a tail
    → Cause: system-wide issue (DB slow, GC thrashing, CPU throttled)
```

### Signal 4: Saturation (Resource Pressure)

```
Saturation = how "full" a resource is

Leading indicator: saturation rises BEFORE errors and latency spike.
Monitoring saturation buys you time to act.

The resource chain:
  JVM heap fills (heap saturation)
    → GC runs more frequently (CPU saturation)
      → Response time increases (latency saturation)
        → Requests start timing out (error rate rises)
          → Pod OOM-killed (availability breach)

  With saturation monitoring:
    Alert fires at "heap fills" stage.
    You have 15-45 minutes to act before users are affected.

  Without saturation monitoring:
    First alert is "error rate rising" or "availability breach."
    Users are already impacted. You're in firefighting mode.

Resources we monitor and their thresholds:
  CPU:     production payment-service = 70% (G1GC competes for CPU above this)
  Memory:  production payment-service = 75% (OOM kill zone above 90%)
  JVM heap: production payment-service = 70% (G1GC pressure starts here)
  Network: production payment-service = 0.5% packet error rate
```

---

## Part 5 — Layer 5: Distributed Tracing

### What distributed tracing is

```
A trace = the complete journey of ONE request across ALL services it touched.

Without tracing:
  order-service: P99 latency = 900ms. Why?
  → Is it slow because of order-service code?
  → Or because it calls payment-service which is slow?
  → Or because payment-service calls PostgreSQL which is slow?
  You cannot tell from service-level metrics alone.

With tracing:
  order-service request trace:
    order-service [900ms total]
    ├── auth middleware [2ms]
    ├── order validation [5ms]
    ├── HTTP call → payment-service [880ms]  ← !! THIS is where time is spent
    │   ├── auth [2ms]
    │   ├── fraud check [3ms]
    │   └── DB SELECT payments WHERE ... [875ms]  ← ROOT CAUSE
    └── response [8ms]

  Root cause identified in seconds, not minutes.
```

### How traces flow through the system (OTEL)

```
Java app configuration (in Helm values.yaml):
  env:
    - name: OTEL_EXPORTER_OTLP_ENDPOINT
      value: "http://dynatrace-activegate.dynatrace.svc:4318"
    - name: OTEL_SERVICE_NAME
      value: "payment-service"

When order-service calls payment-service:
  1. order-service OTEL SDK creates a trace span:
       traceId: "abc123" (unique for this request)
       spanId:  "span001"
       name:    "POST /api/v1/payments"
       startTime: 14:32:05.000
  
  2. order-service injects trace ID into outbound HTTP headers:
       X-B3-TraceId: abc123
       X-B3-SpanId: span001
  
  3. payment-service reads the trace ID from the incoming HTTP headers.
  4. payment-service creates a CHILD span:
       traceId: "abc123" (SAME — links it to the parent)
       spanId:  "span002"
       parentSpanId: "span001" (reference to order-service span)
  
  5. Both spans sent to DT ActiveGate → forwarded to DT tenant.
  6. DT stitches them together by traceId → shows as one connected trace.
```

### What traces reveal that metrics cannot

```
1. Which ENDPOINT is slow (not just "the service"):
   Metric: "payment-service P99 = 820ms"
   Trace:  "POST /api/v1/payments P99 = 820ms"
           "GET /api/v1/payments/{id} P99 = 45ms"
   → POST is the problem. GET is fine. The fix is in the POST handler.

2. Database query details:
   Metric: "DB connection latency spiked"
   Trace:  "SELECT * FROM payments WHERE user_id = ? [875ms]"
   → Specific SQL query, specific table, specific parameter.
   → With the actual query: DBA can check EXPLAIN ANALYZE → missing index found.

3. N+1 query detection:
   Metric: "payment-service P99 = 600ms after new deploy"
   Trace:  Shows 52 DB calls in one request (instead of 2).
   → N+1 query: new code loads 50 related records with individual queries instead of a JOIN.

4. Cross-service bottleneck:
   Metric: "order-service P99 = 900ms" AND "payment-service P99 = 200ms"
   Trace:  order-service waits for payment-service for 800ms (the remaining 100ms is overhead).
   → payment-service P99 is 200ms for its own operations, but order-service's CALL to it takes 800ms.
   → Network issue between the services? Connection pool wait on order-service's client side?
```

### Trace sampling strategy

```
Why not 100% sampling in production?
  100 req/sec × 100% = 100 traces/sec × ~10KB each = ~1MB/sec = ~86GB/day
  Expensive to store, expensive to query.

Our strategy (configured in DT tenant settings):
  Errors:       100% sampled (every failed request kept)
  Slow requests (> 2× P99): 100% sampled (every outlier kept)
  Normal:       10% sampled (statistically representative)

Result:
  Every production failure is traceable.
  Every slow request is traceable.
  Normal requests: 1 in 10 kept (enough for performance analysis).
  Storage cost: ~90% less than 100% sampling.

Retention:
  Errors: 30 days (RCA for past incidents)
  Normal: 7 days (recent performance trends)
```

---

## Part 6 — Layer 6: Synthetic Monitoring (Outside-In)

### Why synthetic is different from all other layers

```
Layers 1–5 all monitor from INSIDE the cluster (OneAgent runs on the nodes).

What OneAgent CANNOT see:
  ✗ DNS resolution failure (the JVM never even makes the request)
  ✗ ALB target group empty (requests never reach pods)
  ✗ TLS certificate expired (browser rejects before connecting)
  ✗ CDN misconfiguration (traffic goes to wrong origin)
  ✗ Firewall blocking external traffic (packets never arrive)

All of these can cause a complete user-visible outage while:
  - OneAgent shows pods as healthy ✓
  - Error rate = 0% (no requests to fail) ✓
  - P99 latency = normal (nothing to measure) ✓
  - ALL METRICS LOOK GREEN

Synthetic monitoring catches this.
It sends REAL HTTP requests from outside AWS (from Tokyo and Singapore),
just like a real user would, and checks if it gets back a real response.
```

### What the synthetic check validates

```hcl
# From terraform/modules/dynatrace/main.tf
validation {
  rule { type = "httpStatusesList"; value = "2xx" }
  rule { type = "patternConstraint"; value = "\"status\":\"UP\"" }
}
```

```
Check 1: HTTP status must be 2xx
  Catches: 503 (service unavailable), 502 (bad gateway), 404 (wrong URL in Ingress)
  Does NOT catch: healthy HTTP response but broken application

Check 2: Body must contain "status":"UP"
  Spring Boot Actuator /actuator/health response:
    Healthy: {"status":"UP","components":{"db":{"status":"UP"},"redis":{"status":"UP"}}}
    Unhealthy: {"status":"DOWN","components":{"db":{"status":"DOWN"}}} (but HTTP is 200!)
    
  Why "status":"UP" in the body?
    A misconfigured Spring app CAN return HTTP 200 with {"status":"DOWN"}.
    This happens when: spring.boot.admin.client.instance.health-url is wrong,
                       or when a component degrades gracefully.
    HTTP says "I responded" — body says "I'm actually working."
    Both must pass.

response_time_limit = latency_p99_ms × 3:
  payment-service: if health check from Tokyo takes > 900ms (3 × 300ms) → slow alert
  Why 3×? Network round-trip Tokyo→AWS adds ~50-100ms. 3× provides buffer.
```

### Global vs local outage detection

```
Monitors from:
  Tokyo (GEOLOCATION-6F55B7E4B5E7A52F):   closest to our primary user base (Japan/Asia)
  Singapore (GEOLOCATION-D15FBAABA11A2D7D): secondary Asia-Pacific location

Every 5 minutes, BOTH locations send a health check.

GLOBAL OUTAGE (both locations fail simultaneously):
  Setting: global_consecutive_outage_count_threshold = 1
  Meaning: if the very FIRST check from ALL locations fails → global outage alert.
  Action:  CRITICAL/HIGH alert fires immediately.
  Why 1?: If both Tokyo and Singapore can't reach the service:
           it's almost certainly truly down (not a regional network blip).

LOCAL OUTAGE (only 1 location fails):
  Setting: local_consecutive_outage_count_threshold = 3
  Meaning: need 3 CONSECUTIVE failures from one location before alerting.
  Why 3?: 3 failures × 5-min interval = 15 minutes of sustained regional failure.
  
  Single local failure reason:
    Tokyo probe server momentarily overloaded (30 seconds)
    AWS regional transit network blip
    DT synthetic location brief connectivity issue
    
  3 consecutive failures:
    Genuine regional DNS problem
    Tokyo-specific routing issue
    AZ failure affecting our Tokyo-facing infrastructure

The two-location approach prevents false positives from transient regional blips
while catching real global outages immediately.
```

---

## Part 7 — Layer 7: Business Metrics (Custom OTEL)

### Why HTTP metrics are not enough for business

```
payment-service availability SLO: 99.9%
  Measures: HTTP requests returning 2xx

HTTP 200 can be returned for:
  a) Payment completed successfully: customer charged ✓
  b) Payment declined: customer not charged (HTTP 200, body: {"status":"DECLINED"})
  c) Fraud hold: payment held for review (HTTP 200, body: {"status":"PENDING"})
  d) Idempotent duplicate: payment already processed (HTTP 200, previous result returned)

Cases (b), (c), (d) are HTTP 200 but NOT a successful payment.

Availability SLO says 100%: all these return 200, no errors.
Business reality: 20% of payment attempts are being declined.

Without business metrics: you have NO visibility into this.
The service appears "healthy" while the business is failing.
```

### Custom OTEL metric emission (Java code)

```java
// PaymentController.java
@PostMapping("/api/v1/payments")
public ResponseEntity<PaymentResult> processPayment(@RequestBody PaymentRequest req) {

    // Track every attempt (denominator)
    meterRegistry.counter("business.transaction.total.count",
        "service", "payment-service",
        "environment", environment,
        "transaction_type", "payment").increment();
    
    PaymentResult result = paymentService.process(req);
    
    // Track actual completions (numerator)
    if (result.getStatus() == PaymentStatus.COMPLETED) {
        meterRegistry.counter("business.transaction.success.count",
            "service", "payment-service",
            "environment", environment,
            "transaction_type", "payment").increment();
    } else {
        // Track failure reasons (useful for product decisions too)
        meterRegistry.counter("business.transaction.failure.count",
            "service", "payment-service",
            "environment", environment,
            "reason", result.getStatus().name()  // DECLINED, FRAUD_HOLD, TIMEOUT
        ).increment();
    }
    
    return ResponseEntity.ok(result);  // always 200 — outcome is in the body
}
```

```
This emits to DT as:
  ext:custom.business.transaction.total.count
  ext:custom.business.transaction.success.count
  ext:custom.business.transaction.failure.count

OTEL sends via:
  OTEL_EXPORTER_OTLP_ENDPOINT → DT ActiveGate → DT Grail metrics store
```

### The business SLO Terraform resource

```hcl
resource "dynatrace_slo_v2" "business_transaction" {
  name   = "payment-service Business Transaction Rate [production]"
  target_success = 99.9   # 99.9% of payments must actually complete

  metric_expression = <<-EOT
    100 * ext:custom.business.transaction.success.count
      :filter(and(eq(service.name,"payment-service"),eq(environment,"production")))
      :splitBy():sum
    / ext:custom.business.transaction.total.count
      :filter(and(eq(service.name,"payment-service"),eq(environment,"production")))
      :splitBy():sum
  EOT
}
```

```
This SLO fires when:
  Less than 99.9% of payment attempts are resulting in completed payments.
  Even if HTTP availability is 100%.

Real scenario where this matters:
  Payment gateway (Stripe, etc.) having issues → payments failing at the provider level.
  payment-service code handles this gracefully: returns HTTP 200, body: {"status":"DECLINED"}
  HTTP error rate: 0% (looks fine)
  Business transaction rate: 60% (60% of payments completing)
  SLO breach → PagerDuty page → investigate payment provider status
```

---

## Part 8 — Log Monitoring (The "Why" Layer)

### Logs as the only layer that gives you exact error messages

```
Metrics tell you WHAT is wrong (error rate = 2%).
Traces tell you WHERE (DB call in payment-service).
Logs tell you WHY (the exact exception message and stack trace).

Log → Metric → Trace is the typical investigation path:

1. Metric fires: "payment-service error rate > 0.1%"
2. DT shows: traces filtered by error → failing endpoint: POST /api/v1/payments
3. Trace shows: fails at DB call to payments table
4. LOGS show:
   "com.zaxxer.hikari.pool.HikariPool: Connection is not available,
    request timed out after 30000ms.
    Pool stats (total=20, active=20, idle=0, waiting=47)"
   
   Now you know EXACTLY what's wrong:
   DB connection pool is exhausted (20/20 connections in use, 47 threads waiting).
   Not "DB is slow" — "connection pool is the bottleneck."
   Fix: increase hikari.maximum-pool-size OR find what's holding connections.
```

### How logs reach Dynatrace (OneAgent logMonitoring)

```
Flow:
  Java app → writes to stdout (System.out.println / SLF4J → Logback → stdout)
  Docker/containerd → writes to /var/log/containers/<pod-name>_<namespace>_<container-name>.log
  OneAgent (on same node) → reads /var/log/containers/*.log (logMonitoring: enabled: true)
  OneAgent → sends to DT ActiveGate
  DT ActiveGate → stores in DT Grail (log analytics engine)

No log shipper needed (no Fluent Bit, no Logstash, no CloudWatch Agent):
  OneAgent handles it as part of its normal operation.
  1 component instead of 3.

Structured logging (JSON) makes logs queryable in DT Grail:
  {"timestamp":"2026-07-31T14:32:15Z",
   "level":"ERROR",
   "traceId":"abc123",
   "message":"DB connection pool exhausted",
   "pool.active":20,
   "pool.waiting":47}

  Unstructured: grep for keywords (slow, imprecise)
  Structured JSON: query by field (level = "ERROR" AND pool.waiting > 40)
```

### Log-trace correlation — the most powerful DT feature

```
Each log line from a traced request contains the trace ID:
  {"traceId": "abc123def456", "level": "ERROR", "message": "..."}

In DT Logs view:
  Click any log line → "Show trace"
  → DT opens the distributed trace for that exact request.

From the other direction:
  Distributed Traces view → click a failed trace → "View logs"
  → DT shows all log lines emitted during that specific request.

This bidirectional correlation means:
  You see: "DB connection pool exhausted" in logs
  You click: see the full call chain (order-service → payment-service → DB)
  You see: EXACTLY which order triggered the exhaustion
  You see: how long the user waited before seeing an error

Without this: you have logs AND traces, but they're two separate data sources.
             You manually cross-reference trace IDs — slow and error-prone.
With this: one click between logs and traces.
```

---

## Part 9 — Alert Routing Architecture

### The full routing chain

```
DT detects problem:
  payment-service error rate crossed 0.1% for 2+ consecutive minutes
         │
         ▼
Davis AI creates a Problem:
  "[P-12345] Failure rate increase — payment-service [production]"
  Davis suggests: "correlated with deployment at 14:20"
         │
         ▼
Which Alerting Profile matches?
  Problem severity: ERROR
  Management zone: payments-production (payment-service tagged team:payments, environment:production)
  
  Alerting profile "payments-production-high":
    severity = ERROR ✓
    management zone = payments-production ✓
    delay = 2 min → fires at 14:34 (2 min after problem started at 14:32)
         │
         ▼
Which Notification rule fires for this profile?
  dynatrace_pagerduty_notification.high["payments"]:
    alerting_profile = payments-production-high ✓
    service_api_key  = PagerDuty integration key for payments team
         │
         ▼
PagerDuty:
  Creates incident on "payment-service-production" Service
  Looks up current on-call from "payments-oncall" Schedule
  Notifies on-call engineer: push notification → SMS → phone call
         │
         ▼
On-call engineer:
  Acknowledges in PagerDuty
  Opens DT problem (link in PagerDuty notification)
  Starts RCA
```

### Why this routing matters — what breaks without it

```
Without management zones:
  ALL DT alerts → ALL notification profiles → ALL engineers get ALL alerts
  50 engineers all paged for one payment-service alert → chaos, noise, duplicate work

Without environment tag in management zone filter:
  payments-production zone includes payment-service in dev AND staging AND production
  Dev engineer restarts a pod in dev → production on-call gets paged
  "It's just the dev environment." → alert fatigue → real production alerts ignored

Without alert delays:
  Rolling deploy → brief error spike → PagerDuty phone call at 3am
  Deploy completes → errors resolve → "it was just the deploy"
  Engineers disable alerts to stop being woken up → real outages missed

The routing chain is as important as the metrics themselves.
Correct routing = right person paged at the right time for real problems only.
```

---

## Part 10 — Monitoring Completeness Checklist

### For every new service, verify ALL 7 layers

```
LAYER 1 — Infrastructure:
  [ ] Node metrics flowing to DT (OneAgent DaemonSet running on all nodes)
  [ ] network_error_rate metric event configured in Terraform

LAYER 2 — Container/Pod:
  [ ] pod_restarts metric event configured
  [ ] HPA configured (prevents pod count from going to 0 under load)
  [ ] PDB configured (prevents all pods being evicted simultaneously)

LAYER 3 — JVM:
  [ ] jvm_heap metric event configured (threshold = Xmx-based, not flat %)
  [ ] memory_usage metric event configured
  [ ] cpu_saturation metric event configured
  [ ] JVM_OPTS set correctly in Helm values (-Xmx, -XX:+UseContainerSupport)

LAYER 4 — Application Metrics:
  [ ] traffic_drop metric event (alert_on_no_data = true, traffic_min_rps > 0 in prod)
  [ ] error_rate metric event
  [ ] latency_p99 metric event (threshold × 1000 for µs!)
  [ ] All thresholds derived from 30-day baseline + headroom, NOT guessed

LAYER 5 — Tracing:
  [ ] OTEL_EXPORTER_OTLP_ENDPOINT set in Helm values
  [ ] OTEL_SERVICE_NAME set correctly
  [ ] Traces appearing in DT (verify in Distributed Traces view after deploy)

LAYER 6 — Synthetic:
  [ ] HTTP synthetic monitor created per service in Terraform
  [ ] Validates BOTH HTTP 2xx AND "status":"UP" in body
  [ ] Locations: Tokyo + Singapore minimum

LAYER 7 — Business Metrics:
  [ ] App emits custom OTEL counters for business outcomes (payments, orders)
  [ ] Business transaction SLO created in Terraform
  [ ] SLO has burn rate alerts configured (fast_burn: 14.4, slow_burn: 3.0)

ROUTING:
  [ ] Namespace labels configured: team + environment
  [ ] Management zones created (via Terraform)
  [ ] Alerting profiles created (4 tiers)
  [ ] PagerDuty integration key in Secrets Manager
  [ ] Slack webhook in Secrets Manager
  [ ] Notification resources created (Terraform)

RUNBOOK:
  [ ] One runbook per alert in Confluence
  [ ] Runbook has: immediate actions, investigation steps, common fixes, escalation path
  [ ] Runbook linked from DT alert description (and from PagerDuty service)
```

---

## Part 11 — Common Monitoring Mistakes and How to Avoid Them

### The 10 most common mistakes (with real impact)

```
MISTAKE 1: Monitoring averages, not percentiles
  Wrong: alert when AVERAGE latency > 500ms
  Impact: 1 user in 100 waits 5 seconds → average stays at 200ms → no alert
  Fix: ALWAYS use P99 for user-facing latency

MISTAKE 2: Missing traffic drop alert
  Wrong: monitoring only error rate and latency
  Impact: DNS failure → traffic = 0 → error rate = 0%, latency = N/A → ALL GREEN
  Fix: add traffic_min_rps alert with alert_on_no_data = true

MISTAKE 3: Same thresholds in dev and production
  Wrong: latency threshold = 300ms in all environments
  Impact: dev JVM cold start takes 2000ms → alert fires constantly → engineers ignore all alerts
  Fix: dev = 2000ms, staging = 800ms, production = 300ms

MISTAKE 4: Latency threshold in ms not µs in DT
  Wrong: threshold = 300 (thinking it's ms)
  Impact: threshold is actually 0.3ms → fires on nearly every request
  Fix: threshold = 300 * 1000 = 300,000 (DT stores time in microseconds)

MISTAKE 5: Synthetic validates only HTTP status (not body)
  Wrong: validation { rule { type = "httpStatusesList"; value = "2xx" } }
  Impact: service returns HTTP 200 with body {"status":"DOWN"} → synthetic passes → silent degradation
  Fix: add patternConstraint validation for "status":"UP"

MISTAKE 6: alert_on_no_data = true on error rate
  Wrong: error_rate metric event with alert_on_no_data = true
  Impact: during off-hours (zero traffic) → error rate = "no data" → alert fires → 3am noise
  Fix: alert_on_no_data = true ONLY on traffic drop signal

MISTAKE 7: Missing management zone environment filter
  Wrong: zone includes all entities tagged team:payments (all environments)
  Impact: dev engineer kills a pod → production on-call gets paged → alert fatigue
  Fix: zone filter = team:payments AND environment:production

MISTAKE 8: alert_on_no_data missing from traffic drop
  Wrong: traffic_drop metric event with alert_on_no_data = false
  Impact: service completely down → sends NO metrics → traffic drop alert never fires
  Fix: traffic_drop must have alert_on_no_data = true (only this signal)

MISTAKE 9: PDB with replicaCount = minAvailable
  Wrong: replicaCount = 1, pdb.minAvailable = 1
  Impact: node drain blocked forever → EKS upgrades hang indefinitely
  Fix: dev sets pdb.enabled = false; prod: replicaCount (3) > minAvailable (2)

MISTAKE 10: No runbook for an alert
  Wrong: metric event created but no Confluence runbook
  Impact: alert fires at 3am → engineer has no playbook → 30 min of confused investigation
  Fix: every metric event must have a linked runbook created BEFORE it goes to production
```
