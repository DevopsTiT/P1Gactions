# Glossary — How to Define Service Thresholds
Every term from main.md. One entry per term. SRE beginner level.

---

**Threshold**
A number that, when crossed, triggers an alert. Example: `latency_p99_ms = 300` means "alert me when P99 response time exceeds 300ms." Why it matters: thresholds are the translation of "what is healthy?" into math — too tight = noise, too loose = missed incidents.

**Alert fatigue**
When too many false alerts fire, engineers start ignoring ALL alerts — including real ones. Why it matters: a misconfigured threshold that fires every day trains engineers to dismiss the alert. The real incident gets dismissed too.

**P99 (99th percentile)**
The value below which 99% of measurements fall. If P99 latency = 500ms: 99 out of 100 requests completed in under 500ms; 1 out of 100 took longer. Why it matters: P99 represents the worst realistic user experience — not the average. Metrics-based alerts on P99 protect the slowest users.

**P50 (median / 50th percentile)**
The value below which 50% of measurements fall. The "average" experience. Why it matters: P50 looks fine even when 1% of users are experiencing 5-second timeouts. Always use P99 (not P50) for user-facing latency thresholds.

**Baseline**
The normal operating value of a metric during healthy, non-incident periods. Example: "payment-service error rate baseline: 0.01–0.02%." Why it matters: you set thresholds ABOVE the baseline. If you set a threshold below the baseline, the alert fires constantly.

**Headroom / buffer**
The extra percentage added above the normal baseline before triggering an alert. Example: normal CPU = 60%, headroom = 15%, threshold = 75%. Why it matters: without headroom, any brief spike above normal would page someone. Headroom filters out transient blips.

**`traffic_min_rps`**
The minimum requests-per-minute threshold below which a "traffic drop" alert fires. Set to 50% of the quiet-hour minimum observed over 30 days. Why it matters: catches silent failures (DNS broken, ALB misconfigured) where traffic stops but error rate and latency look fine (no requests = nothing to fail).

**Quiet hours**
The time window with the lowest traffic (e.g., midnight–6am in the service's primary timezone). Why it matters: `traffic_min_rps` must be set low enough that it doesn't fire during normal quiet hours — only when something is genuinely wrong.

**`error_rate_alert`**
The HTTP 5xx error rate percentage above which an alert fires. Set to 2×–5× the normal baseline error rate. Why it matters: catching the difference between "normal transient errors" (baseline) and "something is broken" (threshold).

**`latency_p99_ms`**
The P99 response time in milliseconds above which a performance alert fires. Set to peak P99 under normal load × 1.5. Why it matters: users waiting longer than this threshold are having a noticeably bad experience — time to investigate.

**JIT (Just-In-Time) compilation**
The Java JVM starts in interpreter mode (slow) and gradually compiles frequently-run code paths into native machine code (fast). After ~1000 requests: JIT-compiled code is 10× faster. Why it matters: dev and staging JVMs restart often → JIT never fully warms → first requests after startup are slow. Latency thresholds must be 2–5× higher in dev/staging to avoid false alerts.

**JIT warm vs cold**
"JIT warm" = JVM has been running long enough to compile its hot code paths → fast. "JIT cold" = JVM just started, interpreting everything → slow. Why it matters: production pods run for days/weeks (JIT warm). Dev pods restart multiple times a day (JIT cold). Same latency threshold would be completely wrong for both.

**`cpu_saturation_pct`**
The CPU usage percentage above which a resource contention alert fires. Set to normal peak CPU + 15%. Why it matters: high CPU on a Java service triggers more frequent G1GC concurrent threads, which steal CPU from request processing → latency goes up before you even see CPU saturation in your APM.

**G1GC concurrent threads**
G1GC (the Java garbage collector) runs background threads to scan heap while the application runs. These threads consume CPU. At high CPU saturation, GC threads compete with request-serving threads. Why it matters: CPU alert at 70–80% catches this before GC threads start losing the CPU competition, causing latency spikes.

**`memory_usage_pct`**
The RSS (physical memory) usage as a percentage of the container memory limit, above which a resource alert fires. Why it matters: if RSS exceeds the container limit, Kubernetes OOM-kills the pod instantly — no graceful shutdown, all in-flight requests fail.

**OOM Kill (Out of Memory Kill)**
When a container uses more memory than its Kubernetes memory limit, the Linux kernel kills the process immediately. The pod shows `OOMKilled` in `kubectl describe pod`. Why it matters: instant pod death mid-request — any payment or order in-flight at that moment fails without a response.

**RSS (Resident Set Size)**
The actual physical memory a process is currently using (as opposed to virtual memory, which may not be physically allocated). Why it matters: Kubernetes memory limits are enforced against RSS. `memory_usage_pct` threshold is based on RSS ÷ container memory limit.

**Container memory limit**
The maximum memory a pod is allowed to use, set in `resources.limits.memory` in the Helm chart. Example: `2Gi`. Why it matters: `memory_usage_pct = 75` on a 2Gi limit = alert at 1.5Gi RSS. Knowing the limit is required to interpret the threshold correctly.

**`jvm_heap_pct`**
JVM heap used as a percentage of `-Xmx` (max heap), above which a resource alert fires. Why it matters: different from `memory_usage_pct` — heap is only the Java object store; the JVM also uses off-heap memory. Heap specifically drives GC behavior.

**`-Xmx` (JVM max heap)**
A JVM startup flag setting the maximum heap size. `-Xmx=1024m` = JVM can use at most 1GB for Java objects. Set in `values.yaml` under `JVM_OPTS`. Why it matters: `jvm_heap_pct` = (heap used) ÷ (-Xmx). You must know `-Xmx` to set this threshold meaningfully.

**Heap vs RSS relationship**
RSS = heap (Java objects) + off-heap (JVM metadata, class definitions, thread stacks, native memory) + NIO buffers. A JVM with `-Xmx=1024m` may use 1.4GB RSS total. Why it matters: `jvm_heap_pct` alerts on the heap part specifically; `memory_usage_pct` alerts on the total RSS.

**G1GC heap pressure**
When JVM heap utilization exceeds 70%, G1GC starts running more frequent minor GC cycles and may trigger mixed GC collections. Each GC cycle has stop-the-world pauses. Why it matters: `jvm_heap_pct = 70` (production) fires when G1GC is about to start causing latency-affecting pauses.

**Stop-the-world GC pause**
A JVM garbage collection phase where ALL application threads are paused while the GC collects memory. Any HTTP request in-flight during this pause simply stalls. Why it matters: a 200ms GC pause on a 300ms P99 SLO means that one GC pause can breach the SLO for all concurrent requests.

**`pod_restart_threshold`**
The number of pod restarts within a 5-minute window that triggers an alert. Production = 2. Why it matters: a restarting pod means the application crashed (OOM kill, failed readiness probe, unhandled exception). In production, any restart is significant.

**CrashLoopBackOff**
Kubernetes state when a pod keeps crashing and restarting in a loop. Kubernetes adds exponential backoff between restart attempts. Why it matters: `pod_restart_threshold` catches the early stage of a crash loop — 2 restarts in 5 minutes — before it enters full CrashLoopBackOff.

**Readiness probe**
A Kubernetes health check that determines if a pod is ready to receive traffic. If it fails, Kubernetes removes the pod from the Service load balancer. If it fails too many times, Kubernetes restarts the pod. Why it matters: failed readiness probes are a common cause of `pod_restart_threshold` alerts — the probe is failing because the app is overloaded or misconfigured.

**`network_error_rate_pct`**
The percentage of network packets on the host that fail, above which an alert fires. Set to 5× the normal baseline error rate for that node's network interface. Why it matters: network errors at the node level can cause timeouts between services (ALB → pod, pod → DB) that don't appear as 5xx HTTP errors — making it an important independent signal.

**Rolling deploy**
Kubernetes updates pods one at a time: start new pod → wait for readiness → terminate old pod. Some pod restarts occur during rolling deploys. Why it matters: `pod_restart_threshold = 2` (not 1) avoids alerting on the single restart that happens during every normal deploy.

**`builtin:` metrics (Dynatrace)**
DT's auto-collected metrics, captured by OneAgent without any code changes. `builtin:service.errors.server.rate`, `builtin:process.memory.jvm.heapUtilization`, etc. Why it matters: these are the data sources for threshold calibration — pull them from DT to see baseline values before setting thresholds.

**30-day observation window**
The recommended time range for pulling historical metrics when calibrating thresholds. Long enough to capture weekly patterns (weekday vs weekend), monthly peaks (end-of-month traffic spikes), and rolling deploys. Why it matters: a 1-day window misses weekly patterns; a 30-day window catches the full range of "normal."

**Quiet-hour minimum**
The lowest traffic value observed during off-peak hours (e.g., midnight–6am) over 30 days. Used as the basis for `traffic_min_rps` calculation (set threshold at 50% of this value). Why it matters: the threshold must be BELOW the quiet-hour minimum or it fires every night.

**Async service**
A service that processes work in the background without a waiting caller. notification-service: order-service puts a message in SQS, then returns immediately; notification-service processes it later. Why it matters: async services get relaxed latency and error rate thresholds — their "slowness" doesn't directly affect user experience.

**Synchronous service**
A service where the caller waits for the response. payment-service: the browser is waiting at checkout. Why it matters: any latency in a synchronous service is directly felt by the user — tighter thresholds, faster paging.

**Threshold drift**
When thresholds become wrong over time because traffic patterns, service performance, or infrastructure change. Example: 6 months after launch, traffic tripled — the old `traffic_min_rps = 10` is now way below the actual quiet-hour minimum. Why it matters: thresholds should be reviewed quarterly or after major traffic changes.

**Safe starting defaults**
Conservative threshold values for a brand-new service with no historical data. Intentionally relaxed to avoid alert fatigue before you know the real baseline. Why it matters: it's better to start loose and tighten based on real data than to start tight and burn out on-call engineers on day one.

**`terraform apply` (DT thresholds)**
When you change a threshold in `environments/production/main.tf` and run `terraform apply`, Dynatrace updates the metric event immediately — no restart needed. Why it matters: thresholds are "just config" — adjusting them is a 5-minute operation, not a deployment.
