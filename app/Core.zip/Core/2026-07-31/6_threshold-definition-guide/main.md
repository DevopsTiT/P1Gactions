# How to Define Each Service's Thresholds

> Question: how do you decide what numbers to put in each service's `services = { }` block?
> This guide explains the reasoning process for every single threshold — where the number
> comes from, how to measure it, and what happens if you get it wrong.

---

## Decision Tree — How to Derive Any Threshold

```
Step 1: Is this a NEW service (no production history)?
  YES → Start with the "Safe Starting Defaults" table at the bottom.
        Deploy to dev → watch actual metrics for 1 week → adjust from data.
  NO  → Go to Step 2.

Step 2: Pull 30 days of historical Dynatrace metrics for this service.
  For each threshold: find the metric → look at P99 steady-state value → add a buffer.
  "Buffer" = how much above normal do you want before paging someone?

Step 3: Apply the environment multiplier:
  Production threshold = the number you derived from Step 2.
  Staging threshold    = production × 2–3  (JIT not fully warm, smaller instances)
  Dev threshold        = use "safe dev defaults" (no real traffic, relaxed everything)

Step 4: Set it, watch for 2 weeks, adjust.
  If alert fires every day → threshold too tight → relax it.
  If alert never fires even during incidents → threshold too loose → tighten it.
```

---

## The 8 Thresholds — Where Each Number Comes From

### 1. `traffic_min_rps` — Traffic Drop Alert

**What it is:** The minimum requests-per-minute you expect this service to receive even at the quietest time of day (e.g., 3am).

**How to set it — the process:**
```
1. Open Dynatrace → your service → "Service flow" or "Service requests"
2. Set time range to the past 30 days
3. Look at the chart between midnight–6am Tokyo time (your quiet hours)
4. Find the lowest point on the traffic graph
5. Take 50% of that lowest point as your threshold

Example for payment-service:
  30-day quiet-hour minimum: 20 req/min
  50% of 20 = 10 req/min → set traffic_min_rps = 10

If the lowest point is 0 (no real users) → set traffic_min_rps = 0 (disables the alert)
Dev always gets traffic_min_rps = 0 for this reason.
```

**Why 50% of the minimum, not 100%?**
```
If you set it AT the minimum:
  traffic dips to 19 req/min at 3:15am → alert fires
  on-call engineer wakes up
  checks: service is running fine, just quiet tonight
  False alert → alert fatigue

50% buffer: traffic must drop to HALF of its normal quiet level
before you page someone. That's a real problem, not noise.
```

**Per-service reasoning:**
```
payment-service: traffic_min_rps = 10
  Payment traffic never truly stops (global users across timezones, recurring payments).
  Quiet-hour minimum observed: ~20 req/min.
  50% = 10.

order-service: traffic_min_rps = 5
  Order traffic follows business hours more closely.
  Quiet-hour minimum: ~10 req/min.
  50% = 5.

notification-service: traffic_min_rps = 3
  Notifications are triggered by orders. Lower base traffic.
  Quiet-hour minimum: ~6 req/min.
  50% = 3.
```

**Staging:** `traffic_min_rps = 2` — k6 sends at least 2 req/min. If below 2, the test runner itself broke.
**Dev:** `traffic_min_rps = 0` — disables the alert entirely. No real users, no meaningful floor.

---

### 2. `error_rate_alert` — HTTP 5xx Error Rate

**What it is:** The percentage of HTTP requests that return 5xx errors, above which you alert.

**How to set it — the process:**
```
1. Open Dynatrace → your service → "Failure rate"
2. Set time range to 30 days
3. Look at the baseline error rate during NORMAL operation (no incidents)
4. Find the P99 baseline (the highest "normal" error rate, excluding known incidents)
5. Set threshold = 2× to 5× the baseline, depending on service criticality

Example for payment-service:
  Normal baseline error rate: 0–0.02%
  2× = 0.04% — too tight, any noise triggers it
  5× = 0.1%  — catches real problems, not noise
  → set error_rate_alert = 0.1

Example for notification-service:
  Normal baseline: 0.2–0.5% (email delivery can have transient failures)
  2× = 0.4% — too tight (normal spikes would trigger)
  2× of 0.5 = 1.0% — fires when it's twice the normal worst case
  → set error_rate_alert = 1.0
```

**Why payment is 10× stricter than notification:**
```
payment-service error = a user's payment failed.
  One error = one user couldn't pay = revenue lost = urgent.
  0.1% = 1 in 1000 requests → still alert (payments are high-value).

notification-service error = an email wasn't delivered.
  Email delivery inherently has transient failures (recipient server timeouts).
  1% = 1 in 100 requests → borderline acceptable for async delivery.
  1% sustained = something is systematically wrong.
```

**Staging:** multiply prod threshold by 10 (k6 puts more stress on the service, some test failures are expected).
**Dev:** `error_rate_alert = 10.0` — dev code may intentionally fail, 10% catches catastrophic breakage only.

---

### 3. `latency_p99_ms` — P99 Response Time

**What it is:** The 99th percentile response time in milliseconds. 99% of requests must be faster than this.

**How to set it — the process:**
```
1. Open Dynatrace → your service → "Response time" → set to P99
2. Set time range to 30 days, EXCLUDE days with known incidents
3. Look at the P99 under NORMAL PRODUCTION LOAD (not during load tests or incidents)
4. Find the "typical busy hour" P99 — this is your production baseline
5. Add 50% headroom as your threshold

Example for payment-service:
  Typical busy-hour P99: 180–220ms
  Peak (during promotions): 250ms
  Add 50%: 220 × 1.5 = 330ms → round to 300ms
  → latency_p99_ms = 300

Why round DOWN to 300 (not up to 400)?
  Payment is critical. You want to be paged before users notice.
  At 300ms you have time to act. At 400ms users have already complained.
```

**Why notification is 1000ms (3× more relaxed than payment):**
```
notification-service is ASYNC.
  When order-service creates an order, it puts a message in SQS.
  notification-service processes that message and sends an email.
  The USER already got their "order confirmed" response from order-service.
  They don't know or care how long the email took to process internally.

So notification P99 = 1000ms is fine.
If email sending takes 800ms (SMTP timeout, etc.) — not a user-facing problem.

payment-service is SYNCHRONOUS.
  User is waiting at checkout. Browser is waiting for the POST /payments response.
  300ms P99 = user waits up to 0.3s.
  At 500ms = user starts wondering if their payment went through.
  At 1000ms = user may click "Pay" again → duplicate payment risk.
```

**The JIT multiplier for dev/staging:**
```
Java JVM uses JIT (Just-In-Time) compilation.
First request after JVM startup: 2000ms+ (interpreter mode, no optimization)
After 1000 requests: 150ms (JIT compiled, optimized)

Dev JVM restarts frequently (engineers pushing code) → JIT never warms up.
Dev latency_p99_ms = 2000: accounts for JIT cold starts.

Staging JVM restarts less but is still on smaller instances.
Staging k6 first 30 seconds: JIT warming → P99 spikes.
Staging latency_p99_ms = 800 (300ms × 2.5 warmup multiplier).

Production JVM on m7g.xlarge runs for days/weeks → JIT fully warm.
Production latency_p99_ms = 300.
```

---

### 4. `cpu_saturation_pct` — CPU Saturation Alert

**What it is:** The percentage of available CPU at which you alert.

**How to set it — the process:**
```
1. Open Dynatrace → Process/Container → CPU usage for this service
2. Look at CPU during your BUSIEST periods (promotions, end of month, peak hours)
3. Find the peak CPU during normal-but-heavy load
4. Set threshold = that peak + 15–20% headroom

Example for payment-service:
  Peak CPU during busy hours: 55–60%
  60% + 15% headroom = 75%... but wait:
  At 75% CPU, Java GC starts competing for CPU cycles → latency increases.
  "Alert before users notice" → use 70%.
  → cpu_saturation_pct = 70

Example for notification-service:
  Peak CPU: 60–65%
  65% + 15% = 80%
  notification is async — some CPU spike is acceptable.
  → cpu_saturation_pct = 80
```

**Why payment gets 70% and notification gets 80%:**
```
payment-service needs CPU headroom for:
  - G1GC concurrent marking threads (run in background, compete for CPU)
  - Sudden traffic spikes (flash sales, retries after brief outage)
  - At 70%: 30% buffer for these background tasks

notification-service is async and can buffer work in SQS:
  If CPU is high, processing slows but nothing is lost (messages wait in queue).
  80% threshold: fewer false alarms, still catches runaway processes.
```

---

### 5. `memory_usage_pct` — RSS Memory Alert

**What it is:** The percentage of container memory limit (set in Kubernetes) that the process RSS is using.

**How to set it — the process:**
```
1. Open Dynatrace → Process → Memory usage (RSS)
2. Find what percentage of the CONTAINER LIMIT is used at peak load
3. Set threshold = that percentage + 10–15% buffer
   but never above 90% (OOM kill zone starts above 90%)

Example for payment-service:
  Container limit: 2Gi
  Peak RSS at load: 1.3Gi = 65% of 2Gi
  65% + 10% = 75%
  → memory_usage_pct = 75

Why not 85%?
  At 85% of 2Gi = 1.7Gi used.
  JVM old-gen GC at high memory → Full GC → stop-the-world pause → latency spike.
  Alert at 75% gives time to act before the GC spiral starts.
```

**The OOM kill threshold:**
```
Kubernetes OOM killer activates when process uses > container memory limit.
OOM kill = pod crashes immediately, no graceful shutdown.
If pod OOM-kills in production: all in-flight requests fail instantly.

Memory hierarchy (for Java Spring Boot pod with 2Gi limit):
  0–60%: normal operation
  60–75%: elevated, monitor closely
  75–85%: alert zone (this is where memory_usage_pct threshold should sit)
  85–95%: danger zone, GC working overtime
  >95%:  OOM imminent → pod kill incoming

alert at memory_usage_pct = 75: catches the beginning of the danger zone.
```

---

### 6. `jvm_heap_pct` — JVM Heap Utilization

**What it is:** What percentage of the maximum heap (`-Xmx`) is currently used by live Java objects.

**How to set it — the process:**
```
This threshold depends on THREE things:
  (a) What -Xmx is set to in your values.yaml
  (b) How much heap Spring Boot uses at idle (just loaded, no requests)
  (c) How much additional heap each request consumes

Step 1: Find idle heap (what Spring uses just being alive):
  Start the pod with no traffic.
  After 5 minutes: check Dynatrace JVM heap metric.
  Example: payment-service with Xmx=1024m → idle heap = 300–350MB = 30–35%

Step 2: Find peak heap under load:
  During k6 load test: watch Dynatrace JVM heap metric.
  Example: payment-service under 50 VUs → heap reaches 550–620MB = 54–60%

Step 3: Set threshold = peak heap% + 10% buffer, but must be < 80%:
  60% + 10% = 70%
  → jvm_heap_pct = 70
```

**Why each service is different:**
```
payment-service: jvm_heap_pct = 70
  Xmx = 1024m (prod). Peak load heap: ~60%.
  70% threshold = 10% buffer before G1GC major collections.
  Payment is synchronous — GC pauses directly cause latency spikes.

order-service: jvm_heap_pct = 75
  Xmx = 1024m (prod). Slightly more memory-efficient queries.
  Peak heap: ~65%. 75% = 10% buffer.
  order-service latency SLO is 500ms (more lenient than 300ms) — slightly more GC tolerance.

notification-service: jvm_heap_pct = 75
  Xmx = 1024m (prod). Async processing, longer-lived objects.
  Peak heap: ~65–70%. 75% threshold catches issues early.
  Async service: GC pauses don't cause user-visible latency.
```

**Why dev needs 85% (not 70%):**
```
Dev Xmx = 256m (values-dev.yaml — cheap dev resources).
Spring Boot idle heap on 256m:
  Spring context alone: ~180MB = 70% of 256m just at startup.

If dev threshold = 70%: alert fires before you write a single line of code.
Alert fires immediately → engineer ignores it → alert fatigue.

85% on 256m = 218MB threshold.
Spring idle: 180MB = 70%. Only alerts when heap is genuinely stressed.
```

**Why staging needs 78%:**
```
Staging Xmx = 512m (values-staging.yaml).
k6 load test with 50 VUs fills heap to ~78% (more objects in flight simultaneously).
78% threshold: fires exactly when k6 pushes heap above normal operating level.
This catches: memory leaks that only appear under load.
```

---

### 7. `pod_restart_threshold` — CrashLoop Detection

**What it is:** How many pod restarts within a 5-minute window triggers an alert.

**How to set it — the process:**
```
This is simpler than the metric-based thresholds.
The question is: "how many restarts indicate a real problem vs normal operation?"

Production:
  A healthy production pod NEVER restarts.
  ANY restart = something failed (OOM kill, readiness probe timeout, app crash).
  → pod_restart_threshold = 2 (not 1 — allows for 1 transient blip without paging)

Staging:
  Rolling deploys cause restarts. k6 tests may push pods to OOM occasionally.
  → pod_restart_threshold = 3

Dev:
  Engineers restart pods constantly (code pushes, config changes, debugging).
  → pod_restart_threshold = 5
```

**Why 2 and not 1 for production?**
```
Kubernetes has a brief "grace period" during rolling updates where pods restart.
If threshold = 1:
  Any rolling deploy triggers a pod restart → alert fires → on-call wakes up
  → "It's just a deploy." False alarm every single deployment.

If threshold = 2:
  2 restarts in 5 minutes = something repeatedly crashing = real problem.
  A normal deploy restarts each pod once, not twice in 5 minutes.
```

---

### 8. `network_error_rate_pct` — Network Error Rate

**What it is:** The percentage of network packets that fail at the host/node level.

**How to set it — the process:**
```
1. Open Dynatrace → Hosts → Network tab → error rate for your EKS nodes
2. Look at the baseline network error rate during normal operation
3. Find the P99 baseline (highest normal rate)
4. Set threshold = 5× the baseline

Normal EKS node network error rate: 0.01–0.1%
5× = 0.05–0.5%

payment-service (production): 0.5%
  Strictest because network errors to a payment service can mean transactions timeout.

notification-service (production): 1.0%
  Async service — occasional network blips don't lose messages (SQS guarantees delivery).

Dev: 5.0%
  Dev VPC may have less stable networking, security group misconfigs during development.
```

---

## Per-Service Threshold Summary Tables

### Production Thresholds (with reasoning)

| Threshold | payment-service | order-service | notification-service | Key reason for difference |
|-----------|----------------|---------------|---------------------|--------------------------|
| `traffic_min_rps` | 10 | 5 | 3 | Payment has global 24/7 users; notification is event-driven |
| `error_rate_alert` | 0.1% | 0.5% | 1.0% | Payment errors = revenue loss; notifications are async |
| `latency_p99_ms` | 300ms | 500ms | 1000ms | Payment is user-waiting; notification is fire-and-forget |
| `cpu_saturation_pct` | 70% | 80% | 80% | Payment needs CPU headroom for GC concurrent threads |
| `memory_usage_pct` | 75% | 80% | 80% | Payment: prevent OOM kill during payment processing |
| `jvm_heap_pct` | 70% | 75% | 75% | Payment: prevent GC pause during user-waiting request |
| `pod_restart_threshold` | 2 | 2 | 2 | All prod: any restart = real problem |
| `network_error_rate_pct` | 0.5% | 1.0% | 1.0% | Payment transactions must not lose packets |

### Dev vs Staging vs Production Multipliers

| Threshold | Dev | Staging | Production | Reason for difference |
|-----------|-----|---------|------------|----------------------|
| `traffic_min_rps` | 0 (off) | 2 | 10 | Dev: no users. Staging: k6 floor. Prod: quiet-hour minimum |
| `error_rate_alert` | 10.0% | 1.0% | 0.1% | Dev: experimental code. Staging: k6 failures expected. Prod: strict |
| `latency_p99_ms` | 2000ms | 800ms | 300ms | Dev: JIT cold. Staging: JIT warming. Prod: JIT warm |
| `cpu_saturation_pct` | 90% | 85% | 70% | Dev: bursty. Staging: moderate. Prod: needs headroom |
| `memory_usage_pct` | 85% | 80% | 75% | Dev: small Xmx fills fast. Prod: OOM protection |
| `jvm_heap_pct` | 85% | 78% | 70% | Dev: 256m Xmx. Staging: 512m + k6 load. Prod: 1024m |
| `pod_restart_threshold` | 5 | 3 | 2 | Dev: engineers restart pods constantly |
| `network_error_rate_pct` | 5.0% | 2.0% | 0.5–1.0% | Dev: VPC less stable. Prod: zero tolerance |

---

## Part 2 — How to Measure These Values in Dynatrace

Before you can set thresholds, you need to OBSERVE the current values.
These are the exact Dynatrace queries to run for each metric.

```
For each query below:
  Dynatrace UI → "Metrics" or "Explore data" → type the metric key
  Set time range: last 30 days
  Set percentile: P99 (for latency), AVG (for CPU/memory/heap)
  Filter: service.name = "payment-service", environment = "production"
```

| What you're measuring | DT Metric Key | Aggregation | How to use the result |
|-----------------------|--------------|-------------|----------------------|
| Request rate (traffic) | `builtin:service.requestCount.server` | MIN over 30d | Min × 0.5 = traffic_min_rps |
| Error rate | `builtin:service.errors.server.rate` | P99 over 30d | P99 × 5 = error_rate_alert |
| Response time | `builtin:service.response.time` | P99 over 30d (busy hours only) | P99ms × 1.5 = latency_p99_ms |
| CPU usage | `builtin:process.cpu.usage` | P99 over 30d | P99 + 15% = cpu_saturation_pct |
| Memory (RSS) | `builtin:process.memory.usage` | P99 over 30d | P99 + 10% = memory_usage_pct |
| JVM heap | `builtin:process.memory.jvm.heapUtilization` | P99 over 30d | P99 + 10% = jvm_heap_pct (max 80%) |
| Pod restarts | `builtin:kubernetes.workload.pods.restarts` | observation | prod=2, staging=3, dev=5 (judgment) |
| Network errors | `builtin:host.net.errorRate` | P99 over 30d | P99 × 5 = network_error_rate_pct |

---

## Part 3 — For Brand New Services (No Historical Data)

If you are adding a NEW 4th service to this project and have no historical data:

```hcl
# Safe starting defaults — production — Java Spring Boot on m7g.xlarge
"new-service" = {
  team             = "your-team"
  slo_target       = 99.5     # start conservative, tighten after observation
  health_check_url = "https://new-service.company.com/actuator/health"

  traffic_min_rps        = 0       # START: disabled until you know your traffic pattern
  error_rate_alert       = 1.0     # START: 1% is a reasonable catch-all default
  latency_p99_ms         = 500     # START: 500ms — tighten once you see actual P99
  cpu_saturation_pct     = 80      # START: safe default for most services
  memory_usage_pct       = 80      # START: safe default
  jvm_heap_pct           = 75      # START: safe for 1024m Xmx
  pod_restart_threshold  = 2       # START: correct for all prod services
  network_error_rate_pct = 1.0     # START: safe default
}
```

**After 2 weeks of production traffic:**
```
1. Open DT → pull P99 of each metric
2. Adjust thresholds using the formulas above
3. Commit the updated terraform/environments/production/main.tf
4. terraform apply → DT metric events update automatically
```

---

## Common Mistakes in Threshold Setting

| Mistake | Symptom | Correct approach |
|---------|---------|-----------------|
| Setting prod thresholds in dev | Alert fires every time JVM cold-starts (2000ms) | Use 3×–5× relaxed values in dev |
| Using average (AVG) not P99 for latency | Threshold looks fine but slow users are missed | Always use P99 for user-facing latency |
| Setting `jvm_heap_pct` without knowing `Xmx` | 70% of 256m = 179MB alerts at idle Spring startup | Know the Xmx in values.yaml first |
| `traffic_min_rps = 5` in dev (no real traffic) | Alert fires constantly at night (no users = 0 req/min) | Dev always gets `traffic_min_rps = 0` |
| Never revisiting thresholds after launch | After 6 months of growth, old threshold = noisy or stale | Review thresholds quarterly or after major traffic changes |
| Using the same threshold for all services | 0.1% error rate for async notification = too strict | Each service type needs its own thresholds |
