# Glossary — File Audit

**`find -type f`**
Lists only files (not directories) recursively under a path. `-type d` would list directories instead.

**`grep -v DS_Store`**
Excludes macOS `.DS_Store` metadata files from the output — they are not real project files.

**`sed 's|.*/prefix/||'`**
Strips the leading path prefix from each line, leaving only the relative path. Used to make both file lists comparable on equal footing.

**`sort`**
Sorts lines alphabetically. Required before `comm` — `comm` only works correctly on sorted input.

**`comm -23`**
Compares two sorted files. `-23` suppresses columns 2 and 3, showing only lines unique to the first file (i.e., "in original but missing from new"). Column 1 = only in file1, column 2 = only in file2, column 3 = in both.

**`comm -13`**
Shows only lines unique to the second file (i.e., "in new but not in original" = intentionally added files). Opposite of `-23`.

**Process substitution `<(...)`**
Bash syntax that runs a command and feeds its output as if it were a file. Lets you pipe two command outputs directly into `comm` without creating temporary files.
