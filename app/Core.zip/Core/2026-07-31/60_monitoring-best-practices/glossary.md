# Monitoring Best Practices — Glossary for SRE Beginners

Every term used in main.md, one entry per term.

---

**Monitoring philosophy (three questions)**
The three questions every monitoring system must answer: Is something broken now? Why is it broken? Was something about to break? These map directly to alerting (now), observability (why), and trend monitoring (about to break).

**Deployment event (Dynatrace)**
A custom event pushed to Dynatrace via API when a new version is deployed. Appears as a vertical marker on all metric graphs at the deploy time. Makes the connection between "this metric spike" and "a deploy just happened" visually obvious in seconds.

**Drift detection (Terraform)**
Running `terraform plan -refresh-only -detailed-exitcode` on a schedule to detect when real AWS/DT infrastructure changed outside of Terraform. Exit code 2 = drift found. Creates a GitHub Issue with the full diff so the team can investigate.

**`-refresh-only` (Terraform)**
A terraform plan flag that ONLY checks for drift (differences between real AWS state and Terraform state) without showing any pending code changes. Pure infrastructure drift signal, not mixed with configuration intentions.

**`-detailed-exitcode` (Terraform)**
A terraform plan flag that changes exit codes: 0 = no changes, 1 = error, 2 = changes exist. Without this flag, drift detection scripts can't distinguish "plan ran fine, nothing changed" from "plan ran fine, found drift" (both would be exit code 0).

**`${PIPESTATUS[0]}`**
A bash variable that captures the exit code of the first command in a pipe. Critical for drift detection: `terraform plan ... | tee drift.txt` — `$?` would capture `tee`'s exit code (always 0), while `${PIPESTATUS[0]}` captures terraform's actual exit code.

**CloudTrail**
AWS's audit log service that records every API call made in your AWS account: who called what API, when, from where. Used to audit who accessed the Terraform state file (S3 GetObject events) and who assumed OIDC roles.

**State bucket security monitoring**
Monitoring who accesses the Terraform state file in S3. The state file contains resource IDs and (in plaintext) sensitive values. Unexpected access by non-CI principals is a security event. Monitored via CloudTrail + CloudWatch metric filters.

**Signal coverage (8 signals)**
The requirement that every monitored JVM service has all 8 Dynatrace metric events: traffic drop, error rate, latency P99, CPU saturation, memory RSS, JVM heap, pod restarts, and network error rate. Missing any signal creates a blind spot for that failure mode.

**Per-environment threshold tiers**
The practice of using different alert thresholds for dev, staging, and production because they have different hardware, traffic patterns, and JIT warmup states. Using production thresholds in dev causes constant false alerts (alert fatigue). Using dev thresholds in production misses real issues.

**Alert fatigue**
When on-call engineers receive so many alerts (especially false positives) that they start ignoring or dismissing them without investigation. Caused by: missing `for` duration, wrong thresholds, missing environment-specific tiers. Leads to real incidents being missed.

**Management zone (Dynatrace)**
A filter in Dynatrace that scopes the entire UI to specific entities matching tag rules. `payments-production` zone shows only services tagged `team:payments AND environment:production`. Requires the label chain to be unbroken from namespace → pod → DT tag → zone rule.

**Label chain**
The propagation path from a Kubernetes namespace label to a Dynatrace management zone match: namespace label → pod label (via Helm commonLabels) → Dynatrace auto-tag (OneAgent reads K8s API) → management zone rule (matches by tag). Break anywhere = service invisible to the correct team.

**SLO burn rate alert**
An alert that fires when the error budget is being consumed faster than a sustainable rate. More meaningful than a static threshold because it accounts for total budget impact rather than momentary value. `14.4×` burn rate = budget exhausted in ~2 days (page on-call). `3×` = exhausted in 10 days (Slack warning).

**Alerting profile delay**
The minimum time an alert condition must persist before Alertmanager sends a notification. CRITICAL=0 min (downtime is never transient), HIGH=2 min (filters retry storms), WARNING=5 min (filters JIT warmup), INFO=15 min (trends, not incidents). Delays prevent false alarms without hiding real problems.

**Synthetic body validation**
The practice of validating response body content (not just HTTP status) in synthetic monitors. Spring Boot returns HTTP 200 even when `db: DOWN`. Without body validation, the synthetic shows GREEN while the service is completely broken.

**ArgoCD application health**
The Kubernetes-reported health of all resources managed by an ArgoCD Application. `Healthy` = all pods running, deployments complete. `Progressing` = rollout in progress. `Degraded` = pods crashing, deployment failed. `Unknown` = can't determine state. Monitored via `argocd_app_info` metric.

**ArgoCD sync status**
Whether the cluster state matches what's in Git. `Synced` = cluster matches git. `OutOfSync` = git has changes not yet applied to cluster. Normal sync lag: 0-3 minutes. Alert after 15+ minutes of OutOfSync.

**Sync wave health**
The requirement that all earlier ArgoCD sync waves remain healthy. Wave -1 (namespaces) must stay healthy for wave 8 (apps) to work. Wave 2 (ESO) must stay healthy for wave 3 (DynaKube) to have its tokens. Earlier wave failures degrade later waves silently.

**Sync latency SLO**
A service-level objective for how quickly a GitOps change propagates from a git commit to a running pod. Dev: <3 min, staging: <5 min, production: <8 min. Exceeding this indicates: ArgoCD is slow, Kubernetes rollout is blocked, PDB is preventing pod replacement.

**`selfHeal: true` (ArgoCD)**
An ArgoCD setting that automatically reverts manual `kubectl` changes to match what's in Git. Monitored because frequent self-healing activity indicates someone is making manual cluster changes that keep being reverted — an operational anti-pattern that should be investigated.

**`ignoreDifferences` (ArgoCD)**
ArgoCD configuration that tells it to not track certain fields (like `spec.replicas` which is managed by HPA). Creates a blind spot — those fields aren't alerted on. Must be compensated with explicit monitoring of the ignored fields via other means (e.g., monitoring HPA scaling failures separately).

**Pipeline duration**
How long a CI/CD pipeline takes to complete. Healthy baseline: ~20-25 minutes for the full deploy pipeline (excluding approval gate). Alert threshold: >40 minutes. Sudden increases indicate: slow Docker builds, Trivy scan delays, Kubernetes rollout issues, or test failures causing retries.

**Production approval gate**
The `environment: production` setting in GitHub Actions that pauses a job until designated reviewers approve. Monitored to ensure: it's being used (not bypassed), reviewers are actually reviewing plans before approving, and approvals are happening in a timely manner.

**OIDC role assumption**
The process by which GitHub Actions proves its identity to AWS and receives temporary credentials to assume an IAM role. Monitored via CloudTrail `AssumeRoleWithWebIdentity` events. Unexpected assumption patterns (wrong IP ranges, wrong repos, unusual hours) indicate potential credential abuse.

**Auto-rollback rate**
The frequency at which the `verify-production` CI job triggers the automatic rollback mechanism (reverts the gitops YAML to the previous image tag). Healthy: 0 per month. Alert at: >1 per month (indicates test coverage gaps), >1 per week (stop deployments, review quality process).

**Unified label schema**
A consistent set of labels (`team`, `environment`, `service`, `managed-by`) applied to all resources across Kubernetes, Dynatrace, ArgoCD, and GitHub. Consistency enables: correct alert routing, management zone filtering, cross-system correlation during incidents.

**Deployment event chain**
The sequence of artifacts created by every deployment: git commit → GitHub Actions run → ECR image push → GitOps YAML update → ArgoCD sync → Dynatrace deployment event → rollout completion → smoke test result. A gap in the chain means that step is unaccountable.

**Monitoring coverage matrix**
A table mapping each component (Terraform, Dynatrace, ArgoCD, CI, services) to four monitoring signals: is it running, is it healthy, is its config correct, was it recently changed. If any cell is empty, that component has a monitoring blind spot.

**Post-mortem integration**
The practice of linking incident artifacts across systems: Dynatrace Problem ID → GitHub Issue → post-mortem document → Jira action items → verification with monitoring after fix. Creates institutional memory that prevents the same incident from happening twice.

**Monitoring feedback loop**
The process of using each incident to improve monitoring: incident → root cause → action items → implementation → metric verification → threshold tuning → runbook update → faster resolution of next similar incident. Monitoring improves over time only if this loop is closed.

**`amtool`**
The command-line interface for Alertmanager. Used for: creating silences during maintenance, testing routing configuration (`amtool config routes test severity=critical environment=production`), listing active alerts, querying silence status.

**Alert routing test**
The practice of using `amtool config routes test` to verify that a specific set of labels routes to the correct receiver BEFORE an incident happens. Prevents discovering at 3am that critical production alerts were being silently dropped or routed to the wrong Slack channel.

**Compensating monitor**
An additional monitoring check created to cover a blind spot created by something like `ignoreDifferences`. If ArgoCD ignores `spec.replicas`, a compensating monitor checks HPA scaling failures and replica count vs desired count separately. Every intentional blind spot needs a compensating monitor.

**Gitleaks**
An open-source tool that scans git commit history and CI pipelines for accidentally committed secrets (API tokens, passwords, private keys). Used in GitHub Actions as a pre-commit and CI check to prevent secrets from reaching ECR images or git history.

**Trivy secret scan**
An Aqua Security open-source scanner that scans Docker images for embedded secrets (credentials, tokens, private keys). Used with `scanners: 'secret'` mode in addition to the CVE vulnerability scan. Ensures no credentials were accidentally baked into the Docker image at build time.

**CloudWatch metric filter**
An AWS feature that processes CloudWatch Logs in real-time and creates a metric when log lines match a pattern. Used to count Terraform state file access events from non-CI principals and alert when the count exceeds zero — detecting potential credential theft attempts.

**GitOps YAML**
The files in `gitops/*/app/*/` that ArgoCD watches to determine which Docker image tag to deploy to each environment. The CI pipeline updates these files with a new image SHA and pushes them, triggering ArgoCD to roll out the new version. Monitored for: unauthorized changes, missing `[skip ci]` tags, and sync latency.

**Helm commonLabels**
A Helm values field that propagates specified labels to BOTH the Deployment metadata AND the pod template spec labels. `commonLabels: {team: payments, environment: production}` ensures pods have both labels — required for Dynatrace auto-tagging to work correctly, since OneAgent reads pod labels from the Kubernetes API.
