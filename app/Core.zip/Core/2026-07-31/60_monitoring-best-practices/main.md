# Monitoring Best Practices — Terraform, Dynatrace, GitOps, ArgoCD, GitHub Actions

> A unified best-practice reference grounded in the real project: 3 Java services × 3 environments on EKS. Each section answers: what to monitor, how to configure it correctly, and what breaks when you don't.

---

## The Monitoring Philosophy

```
Three questions every monitoring system must answer:

1. IS SOMETHING BROKEN RIGHT NOW?
   → Alerting: synthetic checks, error rate alerts, service down
   → Fires within 0-5 minutes of an incident

2. WHY IS IT BROKEN?
   → Observability: distributed traces, JVM metrics, network signals
   → Root cause in minutes, not hours

3. WAS SOMETHING ABOUT TO BREAK?
   → Trend monitoring: SLO burn rate, resource saturation, drift detection
   → Fires days before the SLO is breached

Every monitoring best practice maps to one of these three questions.
```

---

## SECTION 1: Terraform Monitoring Best Practices

### BP-TF-01: Monitor Terraform State Freshness

**What to monitor:** When was the state last successfully updated? A state file that hasn't been written in >24h means either:
- No applies have run (infrastructure is static — verify this is intentional)
- Applies are failing silently
- The CI/CD pipeline is broken

```hcl
# Add a monitoring resource to terraform/modules/dynatrace/main.tf
# that tracks the "last successful apply" timestamp via a custom metric

# Push a deployment event to Dynatrace after every successful apply:
resource "dynatrace_deployment_event" "terraform_apply" {
  for_each         = toset(["terraform-apply"])
  name             = "Terraform Apply: ${var.environment}"
  entity_selector  = "type(CLOUD_APPLICATION),tag(environment:${var.environment})"
  source           = "Terraform"
  event_type       = "CUSTOM_DEPLOYMENT"
  description      = "terraform apply completed for ${var.environment}"
}
```

In CI (`.github/workflows/terraform-infra.yaml`):
```yaml
- name: Notify Dynatrace on successful apply
  if: success()
  run: |
    curl -X POST "${DT_URL}/api/v2/events/ingest" \
      -H "Authorization: Api-Token ${DT_API_TOKEN}" \
      -H "Content-Type: application/json" \
      -d '{
        "eventType": "CUSTOM_DEPLOYMENT",
        "title": "Terraform apply: '"${ENVIRONMENT}"'",
        "entitySelector": "type(KUBERNETES_CLUSTER),tag(environment:'"${ENVIRONMENT}"')",
        "properties": {
          "terraform_version": "'"${TF_VERSION}"'",
          "applied_by": "github-actions",
          "commit_sha": "'"${GITHUB_SHA}"'"
        }
      }'
```

**Why:** When an alert fires and you suspect a recent infrastructure change caused it, Dynatrace shows the deployment event as a vertical marker on every metric graph at the exact apply time. Root cause identification drops from 30 minutes to 30 seconds.

---

### BP-TF-02: Drift Detection = Infrastructure Monitoring

**What to monitor:** Daily drift between `.tf` desired state and real AWS state. From `terraform-infra.yaml`:

```yaml
drift-detect:
  schedule:
    - cron: '0 17 * * *'    # 02:00 JST daily
  steps:
    - name: Drift Detection
      run: |
        terraform plan -refresh-only -detailed-exitcode -no-color 2>&1 | tee drift.txt
        EXIT_CODE=${PIPESTATUS[0]}
        echo "has_drift=$([ $EXIT_CODE -eq 2 ] && echo 'true' || echo 'false')" >> $GITHUB_OUTPUT

    - name: Create GitHub Issue on Drift
      if: steps.drift.outputs.has_drift == 'true'
      uses: actions/github-script@v7
```

**Best practices for drift detection:**
```
✅ Run at off-peak hours (02:00 JST = low change rate, easy morning review)
✅ Use -refresh-only (pure drift signal, not code changes)
✅ Use -detailed-exitcode (exit 2 = drift, not an error)
✅ Use ${PIPESTATUS[0]} not $? (tee would mask terraform's exit code)
✅ fail-fast: false in matrix (check all 3 environments even if one fails)
✅ Auto-create GitHub Issue with full diff (actionable, not just a notification)
✅ Label issues: 'terraform-drift', 'infrastructure', env (prioritisable)

❌ Don't run terraform plan -refresh-only without -detailed-exitcode
   (exit code is always 0 without it — drift is invisible)
❌ Don't create alerts for every drift occurrence
   (some drift is expected: AWS automated updates, version bumps)
❌ Don't use -target in drift detection
   (you must check all resources, not just selected ones)
```

---

### BP-TF-03: Monitor Terraform State Access Patterns

**What to monitor:** Who accessed the state file (potential credential exposure) and whether the state bucket has encryption.

```bash
# CloudTrail query for state file access in the last 24h
aws cloudtrail lookup-events \
  --lookup-attributes AttributeKey=ResourceType,AttributeValue=AWS::S3::Object \
  --start-time $(date -u -v-24H +%Y-%m-%dT%H:%M:%SZ) \
  --region ap-northeast-1 \
  | jq '.Events[] | select(.Resources[].ResourceName | contains("terraform-state")) | {
      time: .EventTime,
      user: .Username,
      action: .EventName,
      source_ip: .SourceIPAddress
    }'

# Alert on unexpected access: set up CloudWatch metric filter
aws logs put-metric-filter \
  --log-group-name "CloudTrail/production" \
  --filter-name "TerraformStateUnexpectedAccess" \
  --filter-pattern '{ ($.eventName = "GetObject") && ($.requestParameters.bucketName = "company-terraform-state-prod") && ($.userIdentity.arn != "*github-actions*") }' \
  --metric-transformations metricName=UnexpectedStateAccess,metricNamespace=TerraformSecurity,metricValue=1
```

**Best practices for state security monitoring:**
```
✅ S3 server access logging enabled on state bucket
✅ CloudTrail logging for all S3 access
✅ Alert on GetObject by non-CI principals (potential secret extraction)
✅ Alert on PutObject during non-CI hours (potential manual state manipulation)
✅ S3 versioning enabled (detect/recover from corruption)
✅ KMS key rotation monitoring (alert if key not rotated in >90 days)
```

---

### BP-TF-04: Monitor Terraform Module Version Drift

**What:** Track when module versions or provider versions in different environments fall out of sync.

```bash
# Check provider versions across environments:
for env in dev staging production; do
  echo "=== $env ==="
  cd terraform/environments/$env
  terraform version -json | jq '{
    terraform: .terraform_version,
    providers: (.provider_selections | to_entries | map({name: .key, version: .value}))
  }'
done

# Alert if production uses a different provider version than staging:
STAGING_VER=$(cd terraform/environments/staging && terraform version -json | jq -r '.provider_selections["registry.terraform.io/hashicorp/aws"]')
PROD_VER=$(cd terraform/environments/production && terraform version -json | jq -r '.provider_selections["registry.terraform.io/hashicorp/aws"]')
if [ "$STAGING_VER" != "$PROD_VER" ]; then
  echo "WARNING: Provider version drift: staging=$STAGING_VER production=$PROD_VER"
fi
```

---

## SECTION 2: Dynatrace Monitoring Best Practices

### BP-DT-01: Signal Coverage Must Be Complete (8 Signals Per Service)

Every JVM service must have ALL 8 signals. Missing a signal = blind spot. From the Terraform module:

```
Required signals for every service:
  1. Traffic drop (alert_on_no_data=true) → catches silent outages
  2. Error rate → catches functional failures
  3. Latency P99 → catches performance degradation
  4. CPU saturation → catches GC pressure, compute saturation
  5. Memory RSS → catches OOMKill trajectory
  6. JVM heap → catches memory leaks, GC spiral
  7. Pod restarts → catches crash loops
  8. Network error rate → catches infrastructure-layer failures
```

**Verification command:**
```bash
# Verify all 8 signals exist for all services in production
export DT_URL="https://TENANT.live.dynatrace.com"
export DT_TOKEN="dt0c01.xxx"

curl -s "${DT_URL}/api/v2/settings/objects?schemaIds=builtin:anomaly-detection.metric-events" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  | jq '[.items[] | .value.summary] | sort'

# Expected: 8 × 3 services = 24 metric events
# If fewer: run terraform plan to see what's missing
```

---

### BP-DT-02: Per-Environment Threshold Tiers (Never Use Same Values)

**The anti-pattern:**
```hcl
# WRONG: same thresholds everywhere
services = {
  "payment-service" = {
    error_rate_alert = 0.1   # production threshold
    latency_p99_ms   = 300   # production threshold
  }
}
# Dev runs on t3.medium, cold JIT → P99 routinely 800ms → constant false alerts
# This destroys alert quality in dev → team starts ignoring alerts
```

**The correct pattern (from the project):**
```hcl
# environments/dev/main.tf
services = {
  "payment-service" = {
    error_rate_alert = 10.0   # 100× looser: dev has test traffic + JIT startup
    latency_p99_ms   = 2000   # 6.7× looser: JIT cold start, small instances
    jvm_heap_pct     = 85     # 21% looser: dev heap is small (256MB)
  }
}

# environments/production/main.tf
services = {
  "payment-service" = {
    error_rate_alert = 0.1    # strict: customer-impacting
    latency_p99_ms   = 300    # strict: SLA requirement
    jvm_heap_pct     = 70     # strict: fire before GC causes latency spikes
  }
}
```

**Threshold tier decision guide:**

| Signal | Dev | Staging | Production | Why different |
|--------|-----|---------|------------|--------------|
| Error rate | 10% | 1% | 0.1% | Dev has test errors; staging validates pre-prod behavior |
| P99 latency | 2000ms | 800ms | 300ms | JIT warmup in dev; staging uses same HW as prod |
| JVM heap | 85% | 78% | 70% | Dev heap is small; G1GC non-linear above 70% in prod |
| Traffic min | 0 (disabled) | 2 rps | 10 rps | Dev is often idle; prod must always have traffic |
| Pod restarts | 5 | 3 | 2 | Dev restarts often; prod restarts = serious |
| PagerDuty | none | HIGH only | CRITICAL+HIGH | Dev noise would exhaust on-call |

---

### BP-DT-03: Management Zones Must Match Namespace Labels

**The label chain must be unbroken:**
```
Namespace YAML label   → Pod label (via Helm commonLabels) → DT tag → Management zone rule

Break anywhere in this chain:
  → Service appears in no management zone
  → Wrong team's alerts fire
  → Post-mortem: "we didn't know this service existed in Dynatrace"
```

**Verification:**
```bash
# Check namespace labels are correct
kubectl get namespace payment-ns -o jsonpath='{.metadata.labels}' | jq
# Expected: {"team":"payments","environment":"production"}

# Check pod labels are propagated
kubectl get pods -n payment-ns -l app=payment-service \
  -o jsonpath='{.items[0].metadata.labels}' | jq
# Expected: includes "team":"payments","environment":"production"

# Check Dynatrace management zone has entities
curl -s "${DT_URL}/api/v2/entities?entitySelector=type(SERVICE),mzName(payments-production)" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  | jq '.entities[].displayName'
# Expected: "payment-service" appears

# Alert if zone is empty (run in CI after terraform apply):
ENTITY_COUNT=$(curl -s "${DT_URL}/api/v2/entities?entitySelector=type(SERVICE),mzName(payments-production)" \
  -H "Authorization: Api-Token ${DT_TOKEN}" | jq '.totalCount')
if [ "$ENTITY_COUNT" -eq "0" ]; then
  echo "ERROR: Management zone payments-production has no entities"
  exit 1
fi
```

---

### BP-DT-04: SLO Burn Rate Alerts Over Static Threshold Alerts

**Why burn rate > static threshold for SLO tracking:**
```
Static threshold: "alert if error rate > 1%"
  Problem: alert fires on a 90-second spike that consumes 0.001% of monthly budget
  On-call gets paged at 3am for something that self-resolved
  
Burn rate: "alert if budget depleting > 14.4× sustainable rate"
  Fast burn (1h window, 14.4×): budget gone in 2 days → page on-call
  Slow burn (6h window, 3×):   budget gone in 10 days → Slack warning
  No page for momentary spikes that don't threaten the budget

From the Terraform module:
  error_budget_burn_rate {
    burn_rate_visualization_enabled = true
    fast_burn_threshold = 14.4   # exhausts 30-day budget in ~2 days → CRITICAL
    slow_burn_threshold = 3.0    # exhausts 30-day budget in ~10 days → WARNING
  }
```

**Best practices for SLO configuration:**
```
✅ Both availability SLO and latency SLO per service (different failure modes)
✅ Rolling 30-day window (-1M in Dynatrace) not calendar month
✅ Target warning = target - 0.1 (early warning before breach)
✅ Error budget visualization enabled (shows remaining budget visually)
✅ Different SLO targets per service tier (payment: 99.9%, notification: 99.0%)

❌ Don't set SLO targets without historical baseline data
   (setting 99.99% for a service that historically achieves 99.5% = constant breach)
❌ Don't use the same SLO target for dev and production
   (dev SLOs are meaningless without production-like traffic)
❌ Don't disable SLOs during deployments
   (rolling updates with maxUnavailable:0 don't need SLO silencing)
```

---

### BP-DT-05: Synthetic Monitors Must Validate Content, Not Just Status

**Anti-pattern (HTTP status only):**
```hcl
# WRONG: only checks HTTP 200
validation {
  rule { type = "httpStatusesList"; value = "2xx"; pass_if_found = true }
}
# Spring Boot returns 200 even when db: DOWN
# Synthetic shows GREEN while service is completely broken
```

**Correct pattern (from project):**
```hcl
# RIGHT: also validates response body
validation {
  rule { type = "httpStatusesList";  value = "2xx";             pass_if_found = true }
  rule { type = "patternConstraint"; value = "\"status\":\"UP\""; pass_if_found = true }
}
# Catches: HTTP server running BUT database/dependencies DOWN
```

**Best practices for synthetics:**
```
✅ Validate both HTTP status AND response body content
✅ Run from ≥2 locations in production (global vs local outage distinction)
✅ Set response_time_limit = latency_p99_ms × 3 (accounts for network RTT)
✅ Use local_consecutive_outage_count_threshold = 3 (filters single-packet losses)
✅ Tag monitors with team/environment/service labels (for management zone filtering)
✅ Use multi-step monitors: step1=service health, step2=dependency health (DB connectivity)

❌ Don't run synthetics only from production probes
   (catches failures invisible from within the cluster: DNS, TLS, ALB)
❌ Don't set frequency = 1m for all services (costs monitoring units)
   (5m is sufficient for most; use 1m only for most critical)
❌ Don't remove synthetics during maintenance
   (create a Silence in DT instead — synthetics keep running but don't alert)
```

---

### BP-DT-06: Alerting Profile Delays Are Intentional Noise Filters

```
CRITICAL (0 min delay): AVAILABILITY
  WHY 0: downtime is never transient. Fire immediately.
  Risk of false alarms: near zero
  
HIGH (2 min delay): ERROR
  WHY 2: filters rolling-deploy blips (30s pod restart) and retry storms (90s)
  A 2-min sustained error rate = real problem, not transient
  
WARNING (5 min delay): SLOWDOWN
  WHY 5: filters JIT cold-start latency spikes (60s) and transient DB slow queries
  5-min sustained slowdown = architectural or load problem
  
INFO (15 min delay): RESOURCE_CONTENTION
  WHY 15: CPU/memory trends don't need immediate action
  15-min sustained: capacity planning alert, not incident response
```

**Common mistake:**
```
Setting ALL severities to 0 min delay:
  Every rolling deploy: 30 seconds of pod unavailability → CRITICAL alert fires
  Every JIT cold start: 60 seconds of high latency → WARNING fires
  Every retry storm: 90 seconds of errors → HIGH fires
  
  On-call response: "just ignore alerts during deploys"
  Result: alert fatigue → real incidents go unnoticed
  
Fix: 0 delay ONLY for AVAILABILITY. Use delays for everything else.
```

---

### BP-DT-07: Terraform as the Source of Truth for Observability Config

```
Anti-pattern: configure Dynatrace manually in UI
  → Someone changes SLO target from 99.9% to 95% during an incident
  → Change is permanent (no review, no audit trail)
  → Team doesn't know why alerts stopped firing
  → Drift detected next day but nobody knows who changed it

Correct pattern: all DT config in Terraform
  → terraform plan shows any UI changes as drift
  → terraform apply reverts unauthorized changes
  → git blame shows who changed what and why
  → New service = add 10 lines to main.tf → 24 DT resources auto-created
```

**Daily Dynatrace config drift check:**
```bash
# From .github/workflows/terraform-dynatrace-production.yaml
# (same drift detection pattern as infrastructure)
terraform plan -refresh-only -detailed-exitcode -no-color 2>&1 | tee dt-drift.txt
EXIT_CODE=${PIPESTATUS[0]}
if [ "$EXIT_CODE" -eq 2 ]; then
  echo "Dynatrace config drift detected — someone changed DT config outside Terraform"
  # Create GitHub Issue with full diff
fi
```

---

## SECTION 3: GitOps / ArgoCD Monitoring Best Practices

### BP-ARGO-01: Monitor ArgoCD Application Health as a First-Class Signal

**What healthy looks like:**
```bash
kubectl get applications -n argocd
# NAME                            SYNC STATUS   HEALTH STATUS
# root-app-production             Synced        Healthy
# payment-service-production      Synced        Healthy
# order-service-production        Synced        Healthy
# notification-service-production Synced        Healthy
# dynatrace-operator-production   Synced        Healthy
```

**Alert on ANY non-healthy application:**
```yaml
# In Prometheus (if using kube-prometheus-stack alongside DT):
- alert: ArgoCDAppNotHealthy
  expr: argocd_app_info{health_status!="Healthy"} == 1
  for: 5m
  labels:
    severity: warning
    team: platform
  annotations:
    summary: "ArgoCD app {{ $labels.name }} is {{ $labels.health_status }}"
    description: "App {{ $labels.name }} in namespace {{ $labels.namespace }} has been unhealthy for 5+ minutes"

- alert: ArgoCDAppOutOfSync
  expr: argocd_app_info{sync_status="OutOfSync"} == 1
  for: 15m   # some sync lag is normal; alert after 15m
  labels:
    severity: warning
  annotations:
    summary: "ArgoCD app {{ $labels.name }} is OutOfSync for >15 minutes"
```

**ArgoCD metrics to monitor (exposed at :8082/metrics):**
```
argocd_app_info{name, namespace, health_status, sync_status}
argocd_app_sync_total{name, phase}          ← sync success/failure rate
argocd_git_request_total{request_type}      ← git fetch rate
argocd_git_request_duration_seconds         ← git fetch latency
argocd_kubectl_exec_total{command}          ← kubectl apply calls
argocd_app_reconcile_duration_seconds       ← how long reconciliation takes
argocd_app_k8s_request_total{verb}          ← Kubernetes API call rate
```

---

### BP-ARGO-02: Sync Wave Order Must Be Validated

**The dependency chain must be monitored, not assumed:**
```
Wave -1 (namespaces) → wave 1 (networking) → wave 2 (secrets) → wave 3 (monitoring) → wave 8 (apps)

What breaks if a wave fails silently:
  Wave 2 (ESO) fails: wave 3 (DynaKube) needs the DT token Secret
    → DynaKube shows: "secret 'dynakube' not found"
    → OneAgent never starts
    → DT shows no data for production services
    → SLO appears 100% (no data = no errors = misleading)
```

**Monitoring wave progression:**
```bash
# Check which wave an application is in and its current health
kubectl get applications -n argocd \
  -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.metadata.annotations.argocd\.argoproj\.io/sync-wave}{"\t"}{.status.health.status}{"\t"}{.status.sync.status}{"\n"}{end}' \
  | sort -k2 -n

# Expected output (production):
# namespaces-production         -1  Healthy  Synced
# aws-lb-controller-production   1  Healthy  Synced
# external-dns-production        1  Healthy  Synced
# external-secrets-production    2  Healthy  Synced
# dynatrace-operator-production  3  Healthy  Synced
# payment-service-production     8  Healthy  Synced
# order-service-production       8  Healthy  Synced
# notification-service-production 8  Healthy  Synced
```

**Alert if earlier waves degrade:**
```bash
# Script: check if any non-app wave resource is unhealthy
UNHEALTHY=$(kubectl get applications -n argocd \
  --selector='!argocd.argoproj.io/app-name' \
  -o json | jq '[.items[] | select(.status.health.status != "Healthy")] | length')
if [ "$UNHEALTHY" -gt 0 ]; then
  echo "CRITICAL: infrastructure wave resource is unhealthy → app deployments may be affected"
fi
```

---

### BP-ARGO-03: Monitor GitOps Sync Latency (Git → Cluster)

**What to measure:** Time from a git commit (image tag update) to when the pod is running the new image.

```bash
# In the CI pipeline (payment-service-ci.yaml), record sync start time:
git commit -m "chore(deploy-prod): payment-service=$IMAGE_TAG [skip ci]"
SYNC_START=$(date -u +%Y-%m-%dT%H:%M:%SZ)
echo "sync_start=$SYNC_START" >> $GITHUB_OUTPUT

# After kubectl rollout status completes, record end time:
SYNC_END=$(date -u +%Y-%m-%dT%H:%M:%SZ)
SYNC_DURATION=$(( $(date -d "$SYNC_END" +%s) - $(date -d "$SYNC_START" +%s) ))
echo "Sync latency: ${SYNC_DURATION}s"

# Alert if sync latency > threshold:
if [ $SYNC_DURATION -gt 600 ]; then   # 10 minutes
  echo "WARNING: GitOps sync took ${SYNC_DURATION}s (expected: <5m)"
fi
```

**Healthy sync latency targets:**
```
Dev:        < 3 minutes  (1 replica, small cluster)
Staging:    < 5 minutes  (2 replicas, HPA to consider)
Production: < 8 minutes  (3 replicas, zero-downtime rolling, PDB constraints)
```

---

### BP-ARGO-04: `selfHeal: true` Creates a Monitoring Obligation

```yaml
# From root-app-production.yaml
syncPolicy:
  automated:
    prune: true
    selfHeal: true    # reverts manual changes within 3 minutes
```

**What selfHeal = true means for monitoring:**
```
selfHeal is a feature AND a monitor:
  If selfHeal fires frequently (many reverts): someone is manually changing the cluster
  Normal: selfHeal fires 0-1 times per week
  Concerning: selfHeal fires > 5 times per day

Monitor selfHeal activity:
  argocd_app_sync_total{phase="Succeeded"} — normal syncs from git pushes
  argocd_app_sync_total{phase="Succeeded",initiated_by="automated"} — auto-syncs
  
  Sudden spike in automated syncs = someone is making manual changes that
  ArgoCD keeps reverting → investigate WHO and WHY
```

---

### BP-ARGO-05: ignoreDifferences Must Be Explicitly Monitored

```yaml
# From payment-service.yaml (ArgoCD Application)
ignoreDifferences:
  - group: apps
    kind: Deployment
    jsonPointers: [/spec/replicas]
```

**Why this needs monitoring:**
```
ignoreDifferences = "ArgoCD doesn't check this field"
If HPA breaks silently:
  replicas collapses to 1 (from HPA's scaling down to minimum)
  ArgoCD ignores replicas → doesn't alert
  DT: pod count drops → traffic per pod rises
  No ArgoCD alert because ignoreDifferences covers it

Compensating monitor:
```

```bash
# Monitor actual replica count vs HPA desired count
kubectl get hpa -n payment-ns payment-service \
  -o jsonpath='{.status.currentReplicas},{.status.desiredReplicas}'
# If currentReplicas != desiredReplicas for >5m → HPA is not scaling

# Alert if HPA can't scale (blocked by PDB or resource limits):
kubectl get events -n payment-ns \
  --field-selector reason=FailedScale \
  --sort-by='.lastTimestamp' | tail -5
```

---

## SECTION 4: GitHub Actions Monitoring Best Practices

### BP-GHA-01: Monitor Pipeline Duration as a Health Signal

**What healthy pipeline duration looks like:**
```
payment-service-ci.yaml timeline:
  test:                    1-3 min    (Gradle + JaCoCo)
  build-and-deploy-dev:    4-6 min    (Docker buildx + Trivy + gitops push)
  smoke-test-dev:          30 sec
  promote-to-staging:      3-5 min
  load-test-staging:       4 min      (k6 3min + setup)
  [human approval]:        variable
  promote-to-production:   4-6 min
  verify-production:       2 min      (sleep 60 + smoke test)

Total (excluding approval): ~20-25 minutes

Alert threshold: > 40 minutes without approval gate → pipeline is slow/stuck
```

**Monitoring pipeline health via GitHub API:**
```bash
# Check recent workflow run durations
gh run list \
  --workflow=payment-service-ci.yaml \
  --limit=10 \
  --json databaseId,status,conclusion,createdAt,updatedAt \
  | jq '[.[] | {
    id: .databaseId,
    status: .status,
    conclusion: .conclusion,
    duration_minutes: (((.updatedAt | fromdateiso8601) - (.createdAt | fromdateiso8601)) / 60 | floor)
  }]'

# Check failure rate
gh run list \
  --workflow=payment-service-ci.yaml \
  --limit=20 \
  --json conclusion \
  | jq '[.[] | select(.conclusion == "failure")] | length'

# Alert if > 3 failures in last 10 runs:
FAILURES=$(gh run list --workflow=payment-service-ci.yaml --limit=10 --json conclusion \
  | jq '[.[] | select(.conclusion == "failure")] | length')
if [ "$FAILURES" -gt 3 ]; then
  echo "WARNING: CI pipeline failure rate: $FAILURES/10 runs"
fi
```

---

### BP-GHA-02: Monitor the Production Approval Gate

**What to monitor:** Is the production gate being used correctly? Is it being bypassed?

```bash
# GitHub API: list all recent deployment approvals for production
gh api repos/company/java-3envs-dynatrace/environments/production/deployment_branch_policies \
  | jq '.'

# Check deployment history (who approved what, when)
gh api repos/company/java-3envs-dynatrace/deployments \
  --jq '.[] | {id: .id, env: .environment, sha: .sha, creator: .creator.login, created_at: .created_at}' \
  | head -20

# Alert if production deployed without matching staging success in the last 2h:
# (someone may have bypassed the sequential pipeline)
PROD_DEPLOYS=$(gh run list --workflow=payment-service-ci.yaml \
  --json conclusion,jobs,createdAt --limit 5 \
  | jq '[.[] | select(.jobs[].name | contains("Promote → Production")) | 
         select(.conclusion == "success") | 
         select(.createdAt > "'$(date -u -v-2H +%Y-%m-%dT%H:%M:%SZ)'")] | length')
STAGING_DEPLOYS=$(gh run list --workflow=payment-service-ci.yaml \
  --json conclusion,jobs,createdAt --limit 5 \
  | jq '[.[] | select(.jobs[].name | contains("Promote → Staging")) | 
         select(.conclusion == "success") |
         select(.createdAt > "'$(date -u -v-2H +%Y-%m-%dT%H:%M:%SZ)'")] | length')
if [ "$PROD_DEPLOYS" -gt 0 ] && [ "$STAGING_DEPLOYS" -eq 0 ]; then
  echo "ALERT: Production deployed without matching staging deployment in last 2h"
fi
```

---

### BP-GHA-03: Security Monitoring — Detect Credential Exposure

**What to monitor in GitHub Actions:**

```yaml
# In CI: add a step that scans for secrets BEFORE committing
- name: Secret scan (gitleaks)
  uses: gitleaks/gitleaks-action@v2
  env:
    GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
    GITLEAKS_LICENSE: ${{ secrets.GITLEAKS_LICENSE }}

# In CI: verify no secrets are in the Docker image
- name: Trivy secret scan
  uses: aquasecurity/trivy-action@master
  with:
    scan-type: 'image'
    image-ref: ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
    scanners: 'secret'
    exit-code: '1'
```

**Monitor OIDC role assumption patterns:**
```bash
# CloudTrail: alert on unexpected role assumptions
aws cloudtrail lookup-events \
  --lookup-attributes AttributeKey=EventName,AttributeValue=AssumeRoleWithWebIdentity \
  --start-time $(date -u -v-1H +%Y-%m-%dT%H:%M:%SZ) \
  --region ap-northeast-1 \
  | jq '.Events[] | {
    who: .UserIdentity.userName,
    role: .RequestParameters.roleArn,
    from: .SourceIPAddress,
    time: .EventTime
  }'

# Alert on role assumption from non-GitHub IP ranges:
# GitHub Actions runners use specific IP ranges (published in meta.github.com API)
```

---

### BP-GHA-04: Monitor Image Build and Deployment Events as Markers

**Push deployment events to Dynatrace from CI:**
```yaml
# In payment-service-ci.yaml, after each successful deployment step:

- name: DT deployment event (dev)
  if: success()
  run: |
    curl -s -X POST "${DT_URL}/api/v2/events/ingest" \
      -H "Authorization: Api-Token ${{ secrets.DT_API_TOKEN }}" \
      -H "Content-Type: application/json" \
      -d '{
        "eventType": "CUSTOM_DEPLOYMENT",
        "title": "payment-service deployed to dev",
        "entitySelector": "type(SERVICE),tag(service:payment-service),tag(environment:dev)",
        "properties": {
          "imageTag": "'"${{ env.IMAGE_TAG }}"'",
          "gitCommit": "'"${{ github.sha }}"'",
          "triggeredBy": "'"${{ github.actor }}"'",
          "ciRunUrl": "'"${{ github.server_url }}/${{ github.repository }}/actions/runs/${{ github.run_id }}"'"
        }
      }'
```

**Why deployment events are critical for monitoring:**
```
Without deployment events in DT:
  Alert fires at 15:30. P99 latency spike started at 15:28.
  On-call investigates: JVM metrics look fine, no code changes visible.
  15 minutes later: finds a deploy happened at 15:27.
  Total investigation: 15+ minutes.

With deployment events in DT:
  Alert fires at 15:30.
  DT shows: vertical line at 15:27 "payment-service deployed: commit abc123"
  On-call immediately: "deploy at 15:27, issue at 15:28 → rollback"
  Total investigation: 2 minutes.
```

---

### BP-GHA-05: Monitor Auto-Rollback as a Quality Signal

**From verify-production job:**
```yaml
- name: Auto-rollback on failure
  if: failure() && steps.smoke.outcome == 'failure'
  run: |
    PREV_TAG=$(git log --oneline -- \
      gitops/production/app/payment-service/payment-service.yaml | \
      awk 'NR==2{print $1}' | xargs git show | grep 'tag:' | head -1 | awk -F'"' '{print $2}')
    # ... rollback logic
```

**Track rollback frequency as a quality metric:**
```bash
# Count rollbacks in the last 30 days
git log --oneline --since=30.days -- gitops/production/ \
  | grep "rollback" \
  | wc -l

# Alert if rollback rate > 1/week (indicates quality problem):
ROLLBACKS=$(git log --oneline --since=7.days -- gitops/production/ | grep "rollback" | wc -l)
if [ "$ROLLBACKS" -gt 1 ]; then
  echo "WARNING: $ROLLBACKS production rollbacks in last 7 days — review test coverage"
fi
```

**Healthy rollback rate by environment:**
```
Dev:        rollbacks are fine (experimental environment)
Staging:    < 1 rollback/month (staging should catch problems)
Production: 0 rollbacks/month (target)
            > 1/month: investigate CI test coverage gaps
            > 1/week: stop deployments, review quality process
```

---

## SECTION 5: Cross-Cutting Best Practices

### BP-CROSS-01: Unified Label Schema Across All Tools

**The label standard for this project:**
```
team:     payments | orders | notifications | platform
environment: dev | staging | production
service:  payment-service | order-service | notification-service
managed-by: terraform | helm | argocd
```

**Where each label must appear:**
```
Kubernetes namespace:  team + environment  (drives DT auto-tagging)
Kubernetes pod:        team + environment + service (via Helm commonLabels)
Dynatrace tag:         team + environment  (auto-tagged from K8s labels)
Dynatrace management zone: matches team + environment
ArgoCD Application:    team label on the Application resource
GitHub PR:             team label for routing
Alertmanager routing:  team label to route to correct Slack channel
```

**Verification — check label consistency:**
```bash
# 1. Namespace labels
kubectl get namespaces -o json | jq '.items[] | select(.metadata.name | contains("-ns")) | {
  name: .metadata.name,
  team: .metadata.labels.team,
  environment: .metadata.labels.environment
}'

# 2. Pod labels match namespace labels
kubectl get pods -n payment-ns -l app=payment-service \
  -o jsonpath='{.items[0].metadata.labels}' | jq 'pick(.team,.environment,.app)'

# 3. Dynatrace tags match
curl -s "${DT_URL}/api/v2/entities?entitySelector=type(SERVICE),entityName(payment-service)" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  | jq '.entities[0].tags[] | select(.key | IN("team","environment")) | {key,value}'

# All three should show: team=payments, environment=production (consistent)
```

---

### BP-CROSS-02: The Deployment Event Chain

**Every deployment must leave a trail in every monitoring system:**
```
1. GitHub commit created       → git log shows timestamp + author
2. CI pipeline triggered       → GitHub Actions shows duration + result
3. Image pushed to ECR         → ECR shows image tag + push time
4. GitOps YAML updated         → git log shows "chore(deploy-prod): tag=sha"
5. ArgoCD synced               → ArgoCD UI shows sync time + commit ref
6. Deployment event pushed     → Dynatrace shows vertical line on all graphs
7. Rollout completed           → kubectl rollout status shows completion time
8. Smoke test passed           → CI shows test result + response time

Break in the chain = gap in accountability:
  Missing step 6: "what changed at 15:28?" takes 15 minutes to answer
  Missing step 5: ArgoCD out-of-sync not noticed until next morning
  Missing step 8: broken production deploy goes undetected
```

---

### BP-CROSS-03: Monitoring Coverage Matrix

**For each component, verify these monitoring signals exist:**

| Component | Is It Running? | Is It Healthy? | Is Its Config Correct? | Was It Just Changed? |
|-----------|---------------|----------------|----------------------|---------------------|
| Terraform infra | EKS node count | Terraform plan: 0 changes | Daily drift check | Deployment event in DT |
| Dynatrace config | DT module resources exist | DT alerts are firing correctly | Daily DT drift check | Deployment event in DT |
| ArgoCD | App sync status | App health status | ignoreDifferences coverage | Sync events |
| GitOps YAML | ArgoCD OutOfSync alert | Rolling update completes | Helm chart validation in CI | Git commit in gitops/ |
| CI pipelines | GitHub Actions status | Build success rate | Secret scan passes | Workflow run history |
| Services (payment/order/notify) | DT synthetic monitor | Error rate < threshold | SLO compliance > target | Deployment event in DT |

---

### BP-CROSS-04: Alert Routing Must Match Team Ownership

**Routing matrix (from Alertmanager config + Dynatrace alerting profiles):**

```
Alert severity + environment + team → channel

CRITICAL + production + any team    → PagerDuty (wake on-call)
HIGH     + production + payments    → PagerDuty payments on-call
HIGH     + production + orders      → PagerDuty orders on-call
HIGH     + staging    + any         → PagerDuty (validation before production)
WARNING  + any + payments           → Slack #alerts-payments
WARNING  + any + orders             → Slack #alerts-orders
WARNING  + any + platform           → Slack #platform-alerts
INFO     + any + any                → Slack #monitoring (shared)
Any      + dev + any                → Slack only (never PagerDuty)
```

**Test routing with amtool (for Alertmanager) or DT config test:**
```bash
# Test Alertmanager routing
amtool config routes test \
  --alertmanager.url=http://alertmanager:9093 \
  severity=critical environment=production team=payments
# Expected: routes to pagerduty-production

amtool config routes test \
  --alertmanager.url=http://alertmanager:9093 \
  severity=warning environment=dev team=payments
# Expected: routes to slack-payments (NOT PagerDuty)
```

---

### BP-CROSS-05: Post-Mortem Integration

**Every production incident must generate linked artifacts:**
```
1. GitHub Issue (from drift detection or manual creation)
   Labels: incident, production, team
   
2. Dynatrace Problem  
   Linked to: service entities, deployment events at the time of incident
   
3. Post-mortem document
   Contains: timeline, root cause, action items with owners and due dates
   
4. Action item tracking
   Each item creates a Jira ticket (or GitHub Issue)
   Linked back to: the Dynatrace Problem ID, the post-mortem document
   
5. Verification
   After action items are implemented: confirm the metric that triggered the incident
   now stays within threshold over a 2-week validation period
```

**The monitoring feedback loop:**
```
Incident fires
    ↓
Root cause identified (aided by DT, ArgoCD events, CI history)
    ↓
Action items created
    ↓
Implementation verified with monitoring
    ↓
Threshold or alert tuned if needed
    ↓
Knowledge encoded in runbook linked from the alert annotation
    ↓
Next similar incident: resolved faster because runbook exists
```

---

## Quick Reference: Best Practices Checklist

```
TERRAFORM:
  □ Deployment events pushed to DT after every apply
  □ Daily drift detection (cron -refresh-only -detailed-exitcode)
  □ State bucket: encryption, versioning, access logging
  □ Provider versions pinned in .terraform.lock.hcl
  □ Production apply requires human approval gate

DYNATRACE:
  □ All 8 signals configured for every service
  □ Per-environment threshold tiers (not same values everywhere)
  □ Management zones match namespace/pod labels (verified)
  □ SLO burn rate alerts configured (14.4× fast, 3.0× slow)
  □ Synthetics validate BODY content, not just HTTP status
  □ Alerting delays: 0m(critical), 2m(high), 5m(warning), 15m(info)
  □ All DT config in Terraform (no manual UI changes)

ARGOCD / GITOPS:
  □ ArgoCD application health alerts (not just "Synced")
  □ Wave health monitoring (earlier waves must stay healthy)
  □ Sync latency SLO (<8m production, <5m staging)
  □ selfHeal activity monitored for unexpected revert rate
  □ ignoreDifferences covered by compensating alerts

GITHUB ACTIONS:
  □ Pipeline duration monitored (alert if >40m excl. approval)
  □ Failure rate tracked (alert if >3/10 recent runs)
  □ Deployment events pushed to DT at each environment promotion
  □ Auto-rollback rate tracked as quality metric (<1/month production)
  □ Secret scanning (gitleaks + Trivy secret mode) in CI
  □ OIDC role assumption patterns monitored via CloudTrail

CROSS-CUTTING:
  □ Unified label schema: team + environment + service everywhere
  □ Deployment event chain complete (git → CI → ArgoCD → DT → rollout)
  □ Alert routing tested with amtool
  □ Monitoring coverage matrix complete for all components
  □ Post-mortem process linked to action item tracking
```
