# Dynatrace Terraform Module + Environment Callers + CI Workflows — Every Line Deep-Dive
> Project: `38_java-3envs-dynatrace`
> Files covered:
>   - `terraform/modules/dynatrace/variables.tf`
>   - `terraform/modules/dynatrace/main.tf` (all 7 resource blocks)
>   - `terraform/environments/dev/main.tf`
>   - `terraform/environments/staging/main.tf`
>   - `terraform/environments/production/main.tf`
>   - `.github/workflows/terraform-dynatrace-dev.yaml`
>   - `.github/workflows/terraform-dynatrace-staging.yaml`
>   - `.github/workflows/terraform-dynatrace-production.yaml`

---

## E2E Flow — How These Files Work Together

```
Developer changes a threshold (e.g., latency_p99_ms: 300 → 250 in production/main.tf)
         │
         ▼
git push → GitHub detects path match:
  terraform/environments/production/** → triggers terraform-dynatrace-production.yaml

         │
         ▼
GitHub Actions (on PR):
  terraform init + terraform plan → output posted as PR comment
  Reviewer sees: "~ 3 metric events to change (threshold 300000 → 250000 µs)"
         │
         ▼
PR approved + merged to main:
  GitHub Actions (on push):
    terraform apply -auto-approve
    [production environment gate: PAUSES for manual approval]
    After approval: Dynatrace metric events updated immediately
         │
         ▼
Dynatrace: next time payment-service P99 > 250ms → alert fires (not 300ms)
```

---

## Part 1 — `terraform/modules/dynatrace/variables.tf`

```hcl
variable "environment" {
  type        = string
  description = "dev | staging | production"
}

variable "dt_env_url" {
  type      = string
  sensitive = true
}

variable "dt_api_token" {
  type      = string
  sensitive = true
}

variable "pagerduty_integration_keys" {
  type      = map(string)
  sensitive = true
  default   = {}
}

variable "slack_webhook_urls" {
  type      = map(string)
  sensitive = true
  default   = {}
}

variable "synthetic_locations" {
  type = list(string)
}

variable "services" {
  type = map(object({
    team                    = string
    slo_target              = number
    health_check_url        = string
    traffic_min_rps         = number
    error_rate_alert        = number
    latency_p99_ms          = number
    cpu_saturation_pct      = number
    memory_usage_pct        = number
    jvm_heap_pct            = number
    pod_restart_threshold   = number
    network_error_rate_pct  = number
  }))
}
```

### Variable by variable

**`environment` (string)**
```
Passed in by the caller: "dev", "staging", or "production".
Used inside the module to:
  - Name resources: "payments-production-critical"
  - Scope alerts: CRITICAL profile only for production
  - Filter metrics: only match this environment's entities
  - Set synthetic locations: prod gets Tokyo + Singapore, dev gets Tokyo only

This single string drives dozens of conditional decisions throughout the module.
```

**`dt_env_url` and `dt_api_token` (sensitive strings)**
```
sensitive = true:
  Terraform hides these in plan/apply output:
    Instead of: dt_api_token = "dt0c01.ABCDEF..."
    You see:    dt_api_token = (sensitive value)
  Still stored in Terraform state file — state must be encrypted (backend "s3" with encrypt=true).

These come from AWS Secrets Manager, read via data sources in the environment callers:
  data "aws_secretsmanager_secret_version" "dt_api_token" {
    secret_id = "production/dynatrace/api-token"
  }
  → dt_api_token = data.aws_secretsmanager_secret_version.dt_api_token.secret_string
```

**`pagerduty_integration_keys` (map(string), default = {})**
```
A map of team name → PagerDuty integration key.
Example:
  {
    "payments"      = "abc123..."
    "orders"        = "def456..."
    "notifications" = "ghi789..."
  }

default = {}:
  Dev passes no PagerDuty keys (empty map).
  When empty: for_each on this map creates ZERO PagerDuty notification resources.
  → No PagerDuty notifications in dev (Slack only).
  → Production passes the full map → creates PagerDuty notifications for each team.

The keys ("payments", "orders", "notifications") match the team names used in management zones.
This is how the module knows which team's integration key to use for which zone.
```

**`synthetic_locations` (list(string))**
```
A list of Dynatrace location IDs (geographic location codes).
Dev:        ["GEOLOCATION-6F55B7E4B5E7A52F"]  # Tokyo only
Staging:    ["GEOLOCATION-6F55B7E4B5E7A52F",   # Tokyo
             "GEOLOCATION-D15FBAABA11A2D7D"]   # Singapore
Production: ["GEOLOCATION-6F55B7E4B5E7A52F",   # Tokyo
             "GEOLOCATION-D15FBAABA11A2D7D"]   # Singapore

Why is this a variable and not hardcoded?
  Callers choose their synthetic coverage.
  A global service might add London and New York.
  A Japan-only service might use only Tokyo.
  The module logic (how the synthetic is configured) never changes.
  The locations (where it checks from) vary per caller.
```

**`services` (map(object(...)))**
```
The most important variable. A map where:
  key   = service name (e.g., "payment-service")
  value = object containing ALL thresholds and metadata for that service

map(object({...})) in Terraform:
  Defines a typed struct. Every service in the map MUST have all these fields.
  If you add a new service and forget jvm_heap_pct: terraform plan fails immediately.
  This enforces completeness — no partial configs silently missing values.

The type contract:
  team:                   which team owns it (used to build management zones and alert routing)
  slo_target:             the availability SLO target (e.g., 99.9)
  health_check_url:       where the synthetic monitor sends requests
  traffic_min_rps:        threshold for silence/traffic-drop alert
  error_rate_alert:       threshold for 5xx alert
  latency_p99_ms:         threshold for P99 latency alert (in ms — converted to µs in module)
  cpu_saturation_pct:     threshold for CPU alert
  memory_usage_pct:       threshold for RSS memory alert
  jvm_heap_pct:           threshold for JVM heap alert
  pod_restart_threshold:  how many restarts in 5 min before alerting
  network_error_rate_pct: threshold for node network error rate
```

---

## Part 2 — `main.tf` Block 1: Provider and Locals

```hcl
terraform {
  required_providers {
    dynatrace = {
      source  = "dynatrace-oss/dynatrace"
      version = "~> 1.55"
    }
  }
}

provider "dynatrace" {
  dt_env_url   = var.dt_env_url
  dt_api_token = var.dt_api_token
}

locals {
  teams = toset([for svc in values(var.services) : svc.team])
}
```

### Provider block

```
source: "dynatrace-oss/dynatrace"
  Registry: registry.terraform.io/dynatrace-oss/dynatrace
  Maintained by Dynatrace OSS (official open-source provider).

version: "~> 1.55"
  Pessimistic constraint operator (~>):
  "~> 1.55" = allow 1.55, 1.56, 1.57, ... but NOT 2.0.0
  Allows patch and minor version upgrades automatically.
  Blocks major version changes (which often have breaking changes).
  Why not "= 1.55.0" (exact)?
    Exact pins require manual updates for every patch.
    Too loose (">= 1.0"): might accidentally pick up a breaking v2.
    ~> 1.55: right balance — auto-gets bug fixes, blocks API-breaking upgrades.

provider "dynatrace":
  dt_env_url:   "https://abc12345.live.dynatrace.com"
    Terraform makes all DT API calls to this URL.
  dt_api_token: the API token (with settings.write, metric.write, synthetic.write scopes)
    Every terraform apply = a series of DT REST API calls authenticated by this token.
```

### The `locals.teams` derived set

```hcl
locals {
  teams = toset([for svc in values(var.services) : svc.team])
}
```

```
Input (services map):
  "payment-service"      → { team = "payments", ... }
  "order-service"        → { team = "orders", ... }
  "notification-service" → { team = "notifications", ... }

Expression breakdown:
  values(var.services):          [ {team:"payments",...}, {team:"orders",...}, {team:"notifications",...} ]
  [for svc in ... : svc.team]:   [ "payments", "orders", "notifications" ]
  toset(...):                    { "notifications", "orders", "payments" }  (deduplicated, unordered)

Why toset (not a list)?
  for_each requires a set or map (not a list).
  toset also deduplicates — if two services had the same team, only one management zone is created.
  A list would try to create the same zone twice → Terraform error.

Result: management zones and alerting profiles are created per TEAM, not per service.
  3 services, 3 different teams → 3 management zones.
  If payment-service and order-service both had team="backend": 1 management zone, 2 services.
```

---

## Part 3 — `main.tf` Block 2: Management Zones

```hcl
resource "dynatrace_management_zone_v2" "team" {
  for_each    = local.teams
  name        = "${each.value}-${var.environment}"   # "payments-production"
  description = "Auto-generated zone for team '${each.value}' in ${var.environment}."

  rules {
    rule { type = "SERVICE"       ... tag_value = "team:${each.value}" AND "environment:${var.environment}" }
    rule { type = "PROCESS_GROUP" ... same tag conditions }
    rule { type = "HOST"          ... same tag conditions }
  }
}
```

### Why 3 entity types (SERVICE + PROCESS_GROUP + HOST)

```
DT Entity hierarchy:
  HOST        → the EKS node (EC2 instance)
  PROCESS_GROUP → the JVM process on that host (payment-service JVM)
  SERVICE     → the HTTP service endpoint (payment-service HTTP API)

Each is a separate entity with its own metrics:
  HOST metrics:     builtin:host.cpu.usage, builtin:host.net.errorRate
  PROCESS metrics:  builtin:process.cpu.usage, builtin:process.memory.jvm.heapUtilization
  SERVICE metrics:  builtin:service.errors.server.rate, builtin:service.response.time

Without all 3 rules:
  A management zone with only SERVICE rule:
    → payments team sees HTTP metrics for payment-service ✓
    → payments team CANNOT see JVM heap metrics (those belong to PROCESS_GROUP entity)
    → payments team CANNOT see host CPU metrics (those belong to HOST entity)
    → Incomplete observability within the management zone

With all 3 rules:
  Each team has a coherent view: HTTP + JVM + host metrics for their services.
```

### The AND logic (two attribute conditions)

```hcl
attribute_conditions {
  attribute = "SERVICE_TAGS"
  tag_value = "team:${each.value}"       # e.g., "team:payments"
}
attribute_conditions {
  attribute = "SERVICE_TAGS"
  tag_value = "environment:${var.environment}"  # e.g., "environment:production"
}
```

```
Both conditions must be TRUE (AND logic, not OR).

Why AND, not just tag team:payments?
  payment-service exists in dev, staging, AND production.
  All three have the tag team:payments.

  Without environment filter:
    Management zone "payments-production" would include:
      payment-service in dev (team:payments, environment:dev)
      payment-service in staging (team:payments, environment:staging)
      payment-service in production (team:payments, environment:production)

    The payments team would see all 3 environments' metrics mixed together.
    Alert fires in dev → production team gets paged → noise.

  With both filters:
    "payments-production" zone = ONLY entities tagged BOTH team:payments AND environment:production.
    Dev and staging never appear in the production management zone.
```

---

## Part 4 — `main.tf` Block 3: Alerting Profiles (4 Tiers)

### The conditional for_each — which environments get which tiers

```hcl
# CRITICAL: production ONLY
resource "dynatrace_alerting" "critical" {
  for_each = var.environment == "production" ? local.teams : toset([])
```

```
Ternary expression: condition ? value_if_true : value_if_false

var.environment == "production" ? local.teams : toset([])
  Production: for_each = {"payments", "orders", "notifications"} → creates 3 critical profiles
  Staging:    for_each = {} (empty set) → creates ZERO critical profiles
  Dev:        for_each = {} (empty set) → creates ZERO critical profiles

Why CRITICAL only for production?
  CRITICAL tier maps to AVAILABILITY events (0-min delay → immediate PagerDuty phone call).
  AVAILABILITY = service is completely down.
  
  Dev services go down constantly:
    Engineer kills the pod to test restart behavior.
    Rolling deploy causes brief unavailability.
    Engineer manually stops the service.
  
  If CRITICAL existed in dev:
    Every kubectl delete pod → PagerDuty phone call at 3am → on-call engineer wakes up.
    "The dev environment's single replica was deleted. Service is back up." → useless wake-up.
  
  Production services should NEVER go down.
  If they do: it's real. Page immediately.
```

```hcl
# HIGH: production AND staging
resource "dynatrace_alerting" "high" {
  for_each = contains(["production", "staging"], var.environment) ? local.teams : toset([])
```

```
contains(["production", "staging"], var.environment):
  Returns true if environment is "production" OR "staging".
  
  Staging gets HIGH because:
    Staging runs k6 load tests (real traffic).
    Staging has the same PagerDuty integration (for catching pre-production regressions).
    An ERROR event in staging during k6 = the new version has a real bug.
    PagerDuty push notification (not phone call) → engineer investigates during business hours.

  Dev gets NO HIGH (no PagerDuty at all):
    Dev error events are expected (development in progress, bugs being fixed).
    Slack-only (warning + info) is sufficient for dev awareness.
```

### The delay_in_minutes — why each tier has a different delay

```hcl
# CRITICAL (AVAILABILITY): delay = 0
  Why: availability loss is never transient. A service that's down is down.
  No need to wait and see if it recovers. Page immediately.

# HIGH (ERROR): delay = 2 minutes
  Why: error spikes during rolling deploys last 60–90 seconds.
  A 2-min delay filters: deploy error spike (resolves in < 2 min) → NO page.
  A real error event (sustained > 2 min) → PAGE.
  
  Example:
    14:20 deploy starts → 14:21 brief 5xx spike → 14:21:30 new pods healthy → spike ends.
    Duration: 90 seconds → below 2-min threshold → no page.
    Real DB failure: 14:20 → 14:25 (5 min sustained) → page fires at 14:22 (2 min after start).

# WARNING (SLOWDOWN): delay = 5 minutes
  Why: P99 latency can spike during JVM cold start, traffic bursts, GC cycles.
  All of these are transient (< 3 min) under normal operation.
  5-min delay: confirms the slowdown is sustained, not a brief spike.
  
  Example:
    Deploy: pod cold starts → JIT not warm → P99 = 1200ms for 2 min → warms up → P99 = 180ms.
    Duration: 2 minutes → below 5-min delay → no Slack message.
    Real latency regression: sustained > 5 min → Slack #alerts-payments.

# INFO (RESOURCE_CONTENTION): delay = 15 minutes
  Why: CPU and memory metrics trend slowly. A 15-min elevation is a real trend.
  Immediate alert on CPU spike: fires every time a Java app cold starts (CPU burst).
  
  Example:
    App startup: CPU spikes to 80% for 3 min → settles at 25%. → below 15-min delay → no alert.
    Memory leak: heap grows from 50% → 72% over 6 hours. → alert fires after sustained 15 min above threshold.
```

---

## Part 5 — `main.tf` Block 4: Metric Events (8 Signals)

### Common structure — `model_properties` explained

```hcl
model_properties {
  type               = "STATIC_THRESHOLD"
  alert_condition    = "ABOVE"          # or "BELOW" for traffic drop
  alert_on_no_data   = false            # true ONLY for traffic drop
  dealerting_samples = 3
  samples            = 5
  threshold          = each.value.error_rate_alert
  violating_samples  = 3
}
```

```
type = "STATIC_THRESHOLD":
  Fires when metric crosses a fixed number.
  Alternative: "AUTO_ADAPTIVE_THRESHOLD" (DT learns the baseline automatically).
  Why static? We set thresholds deliberately — auto-adaptive would not respect our
  per-environment threshold strategy (dev relaxed, prod strict).

alert_condition:
  "ABOVE": fires when metric EXCEEDS threshold (error rate, latency, CPU, memory, heap, restarts)
  "BELOW": fires when metric DROPS BELOW threshold (traffic drop ONLY)
  Only Signal 1 (traffic drop) uses "BELOW" — it's the only signal where "too low" is the problem.

alert_on_no_data:
  false (default): alert does NOT fire when DT receives zero data points.
    Correct for: error rate (no traffic = no errors = 0% error rate = fine)
    Correct for: latency (no traffic = no response times to measure)

  true (ONLY for traffic drop):
    Fires even when DT receives ZERO data points (not just when metric is low).
    Why needed for traffic drop:
      If a service crashes completely, it stops sending ANY metrics.
      error rate = 0% (nothing to error on)
      latency = no data (nothing to measure)
      CPU = no data (process not running)
      
      Only traffic drop with alert_on_no_data = true fires when there's NOTHING.
      "DT received zero data for 3 consecutive minutes" → alert.

samples and violating_samples:
  samples = 5:        look at the last 5 data points (5 minutes for 1m resolution)
  violating_samples = 3: if 3 out of 5 points are above threshold → alert fires
  dealerting_samples = 3: alert clears when 3 consecutive points are BELOW threshold
  
  This "3 out of 5" approach:
    Prevents single-minute spikes from triggering an alert (1/5 violating = no alert)
    Requires sustained violation for 3+ minutes (3/5 violating = alert fires)

Pod restart exception:
  samples = 1, violating_samples = 1:
    Even a SINGLE restart in 1 sample window fires an alert immediately.
    Why: production pods should never restart.
    Unlike latency (which can spike briefly), a pod restart is an unambiguous event.
    No need for "3 out of 5" — any restart is significant.
```

### Signal 1: Traffic Drop — unique properties

```hcl
locals {
  services_with_traffic = {
    for name, svc in var.services : name => svc
    if svc.traffic_min_rps > 0
  }
}

resource "dynatrace_metric_events" "traffic_drop" {
  for_each = local.services_with_traffic   # ← NOT var.services
```

```
Why a separate local (services_with_traffic)?
  Dev sets traffic_min_rps = 0 for all services (no real users → no traffic floor).
  If for_each = var.services and threshold = 0:
    DT metric event with threshold = 0 and alert_condition = "BELOW":
    Any non-zero traffic = not "below 0" = alert never fires (fine)
    But: alert_on_no_data = true and threshold = 0 → fires immediately at startup (bad)
    → Creates a useless, noisy metric event.

  The filter (if svc.traffic_min_rps > 0):
    Dev (traffic_min_rps = 0): filtered OUT → no traffic drop metric event created.
    Staging (traffic_min_rps = 2): included → event monitors for < 2 req/min.
    Production (traffic_min_rps = 10): included → event monitors for < 10 req/min.
  
  Result: traffic drop alerts only exist where they make sense (where real traffic is expected).
```

### Signal 3: Latency P99 — the microseconds conversion

```hcl
threshold = each.value.latency_p99_ms * 1000   # DT uses microseconds
```

```
DT stores all time-based metrics in MICROSECONDS internally.
  latency_p99_ms = 300 (milliseconds, human-readable)
  threshold = 300 * 1000 = 300,000 (microseconds, DT internal unit)

This is the #1 most common mistake when setting up DT metric events.
  Wrong: threshold = 300 → DT fires alert when P99 > 0.3ms (nearly instantaneous!)
  Right: threshold = 300,000 → fires when P99 > 300ms

Same conversion applies to the SLO metric expression:
  le(builtin:service.response.time, ${each.value.latency_p99_ms * 1000})
  "less than or equal to 300,000 microseconds (= 300ms)"

The multiplication happens in Terraform HCL (at plan/apply time), not at DT runtime.
DT only ever sees the pre-calculated microsecond values.
```

### Signal 4–6: entity dimension key differences

```hcl
# Signal 1 (traffic), 2 (error rate), 3 (latency):
event_entity_dimension_key = "dt.entity.service"

# Signal 4 (CPU), 5 (memory), 6 (JVM heap):
event_entity_dimension_key = "dt.entity.process_group_instance"

# Signal 7 (pod restarts):
event_entity_dimension_key = "dt.entity.cloud_application"

# Signal 8 (network):
event_entity_dimension_key = "dt.entity.host"
```

```
Each DT entity type has a different ID namespace:
  dt.entity.service:              "SERVICE-ABC123"  — the HTTP service endpoint
  dt.entity.process_group_instance: "PROCESS-XYZ789" — the JVM process
  dt.entity.cloud_application:    "CLOUD_APPLICATION-..."  — the Kubernetes workload
  dt.entity.host:                 "HOST-DEF456"  — the EC2 node

This key tells DT:
  "When this alert fires, attach it to THIS type of entity."

Why different entities for different signals?
  Traffic/error/latency → measured at SERVICE level (HTTP endpoint metrics)
  CPU/memory/JVM heap → measured at PROCESS level (JVM process metrics)
  Pod restarts → measured at cloud_application level (Kubernetes workload metric)
  Network errors → measured at HOST level (node-level network interface metric)

If all 8 used dt.entity.service:
  CPU alert would attach to the HTTP service entity.
  DT would show "payment-service (service) has a CPU problem."
  But CPU is measured on the JVM PROCESS, not the service endpoint.
  The entity dimension key keeps the alert attached to the right entity.
```

### Signal 8: Network — entity filter difference

```hcl
# Signals 1-7 filter by service.name AND environment:
entity_filter {
  conditions {
    type = "DIMENSION" value = each.key key = "service.name"
  }
  conditions {
    type = "DIMENSION" value = var.environment key = "environment"
  }
}

# Signal 8 (network) filters ONLY by environment:
entity_filter {
  conditions {
    type = "DIMENSION" value = var.environment key = "environment"
  }
}
```

```
Why only environment for network?
  builtin:host.net.errorRate is a HOST-level metric.
  A host (EC2 node) runs multiple pods from multiple services.
  The host doesn't have a "service.name" dimension — it's not a service.

  The host IS tagged with environment (from Kubernetes namespace labels inherited via IRSA).
  So: filter by environment → alerts fire for any host in that environment.

  Side effect: if the EKS node has a network problem affecting all services,
    this alert fires once (for the host), not 3 times (once per service).
    That's correct behavior — the problem is the NODE, not a specific service.
```

---

## Part 6 — `main.tf` Block 5: SLOs

### Availability SLO — metric expression anatomy

```hcl
metric_expression = <<-EOT
  100*(builtin:service.requestCount.server
    :filter(and(eq(service.name,"${each.key}"),eq(environment,"${var.environment}")))
    :splitBy():sum
    - builtin:service.errors.server.count
    :filter(and(eq(service.name,"${each.key}"),eq(environment,"${var.environment}")))
    :splitBy():sum)
  / builtin:service.requestCount.server
    :filter(and(eq(service.name,"${each.key}"),eq(environment,"${var.environment}")))
    :splitBy():sum
EOT
```

```
This is DT Metrics Query Language (MQL).
Breaking it down:

Numerator:
  builtin:service.requestCount.server         ← TOTAL requests (all, including errors)
    :filter(and(...))                          ← scoped to this service + environment
    :splitBy():sum                             ← sum across all instances
  MINUS
  builtin:service.errors.server.count         ← COUNT of 5xx errors
    :filter(and(...))
    :splitBy():sum

Denominator:
  builtin:service.requestCount.server         ← same total request count
    :filter(and(...))
    :splitBy():sum

Full formula:
  100 × (total - errors) / total
  = 100 × (successful requests / total requests)
  = availability percentage

Example:
  10,000 total requests, 5 errors:
  100 × (10,000 - 5) / 10,000
  = 100 × 9,995 / 10,000
  = 99.95% availability
  → SLO target 99.9% is met ✓

Why use :filter() instead of management zone scoping?
  Management zones are for UI scoping (what teams SEE).
  SLO metric expressions need explicit filters to ensure they measure the right service.
  Without filters: the SLO would measure ALL services' requests combined → wrong number.
```

### Latency SLO — the `le()` filter

```hcl
metric_expression = <<-EOT
  100*(builtin:service.requestCount.server
    :filter(and(
      eq(service.name,"${each.key}"),
      eq(environment,"${var.environment}"),
      le(builtin:service.response.time,${each.value.latency_p99_ms * 1000})
    ))
    :splitBy():sum)
  / builtin:service.requestCount.server
    :filter(and(eq(service.name,"${each.key}"),eq(environment,"${var.environment}")))
    :splitBy():sum
EOT
```

```
le() = "less than or equal to"
le(builtin:service.response.time, 300000):
  Filter: ONLY count requests where response time was ≤ 300,000µs (= 300ms)

Numerator: requests that completed within 300ms (fast enough)
Denominator: all requests (regardless of speed)
Result: % of requests that met the latency target

Example:
  100 requests total.
  80 completed within 300ms.
  20 took longer.
  100 × 80/100 = 80% latency SLO compliance.
  SLO target 99.4% (= slo_target - 0.5 = 99.9 - 0.5) → 80% is way below target → SLO breaching.

Why target_success = slo_target - 0.5 for latency?
  Availability SLO target: 99.9%
  Latency SLO target: 99.4% (0.5% below availability)
  
  Why lower?
  Latency SLO is inherently harder to meet 100% than availability:
    During deploys: JIT cold start → P99 spikes briefly → a few requests are "too slow"
    Even healthy traffic has occasional slow requests (complex queries, GC pause coincidences)
  
  Giving latency 0.5% more budget: prevents the latency SLO from burning down during normal deploys.
  Availability SLO: near-perfect (service must always respond)
  Latency SLO: slightly relaxed (occasional slow requests are acceptable)
```

### Burn rate configuration

```hcl
error_budget_burn_rate {
  burn_rate_visualization_enabled = true
  fast_burn_threshold             = 14.4
  slow_burn_threshold             = 3.0
}
```

```
burn_rate_visualization_enabled = true:
  Shows the burn rate chart in the DT SLO dashboard.
  Without this: SLO shows current % only, not the trend.
  With this: you see "currently consuming budget at 6× rate" → act before breach.

fast_burn_threshold = 14.4:
  14.4 × 2 days = 28.8 days ≈ 30-day window.
  If consuming 14.4× normal pace: budget gone in 2 days.
  DT fires a "fast burn" problem → PagerDuty (wired to ERROR alerting profile).

slow_burn_threshold = 3.0:
  3 × 10 days = 30 days.
  Budget would be gone in 10 days at this rate.
  DT fires a "slow burn" problem → Slack (wired to SLOWDOWN alerting profile).

Why 14.4 and not 15?
  14.4 is the exact number to trigger "budget exhausted in exactly 2 days":
  30-day window / 2 days = 15. But DT uses the formula:
  fast_burn_threshold = 1 / (1 - slo_target_decimal) × 1/window_in_days × some factor...
  In practice: 14.4 is the widely used "2-day exhaustion" constant from Google SRE Book.
```

---

## Part 7 — `main.tf` Block 6: HTTP Synthetic Monitor

### Full synthetic configuration explained

```hcl
resource "dynatrace_http_monitor" "health_check" {
  for_each  = var.services
  name      = "${each.key} Health Check [${var.environment}]"
  frequency = 5                            # every 5 minutes
  locations = var.synthetic_locations      # Tokyo + Singapore

  script {
    request {
      method = "GET"
      url    = each.value.health_check_url  # https://payment.company.com/actuator/health

      configuration {
        accept_any_certificate = false    # TLS cert must be valid (no self-signed in prod)
        follow_redirects       = true     # follow HTTP→HTTPS redirect (ssl-redirect: 443)
      }

      validation {
        rule { type = "httpStatusesList"; value = "2xx"; pass_if_found = true }
        rule { type = "patternConstraint"; value = "\"status\":\"UP\""; pass_if_found = true }
      }

      response_time_limit = each.value.latency_p99_ms * 3  # 3× P99 = absolute maximum
    }
  }
```

```
accept_any_certificate = false (production):
  DT synthetic REJECTS expired or self-signed TLS certs.
  Why: an expired cert in production causes browsers to show security warnings.
  The synthetic catches this BEFORE users do.
  Dev: this could be false (dev may use self-signed). But even dev uses proper certs here.

follow_redirects = true:
  payment.company.com → HTTP 301 → https://payment.company.com
  Without follow_redirects: synthetic sees HTTP 301 (not a 2xx) → FAILS.
  With follow_redirects: follows the redirect → hits HTTPS → checks for 2xx.

Two validation rules (BOTH must pass):
  Rule 1: httpStatusesList = "2xx"
    HTTP response code must be 200-299.
    Catches: 503 (service unavailable), 502 (bad gateway), 404 (wrong URL).

  Rule 2: patternConstraint = "\"status\":\"UP\""
    Response body must contain: "status":"UP"
    Spring Boot Actuator /actuator/health response:
      {"status":"UP","components":{"db":{"status":"UP"}}}  → PASSES
      {"status":"DOWN","components":{"db":{"status":"DOWN"}}}  → FAILS (even though HTTP is 200!)
    
    This is the critical second check.
    A misconfigured Spring app CAN return HTTP 200 with body {"status":"DOWN"}.
    HTTP 200 only tells you the web server is running.
    "status":"UP" tells you the application layer AND all dependencies are healthy.

response_time_limit = latency_p99_ms * 3:
  payment-service P99 = 300ms → response_time_limit = 900ms.
  DT synthetic alerts if the health check takes > 900ms to respond.
  3× multiplier: synthetics add ~100ms network overhead from Tokyo/Singapore.
  900ms = "even with network overhead, something is very wrong if it takes this long."
```

### Anomaly detection: global vs local outage

```hcl
anomaly_detection {
  outage_handling {
    global_outages                            = true
    local_outages                             = true
    global_consecutive_outage_count_threshold = 1   # 1 failure from ALL = global
    local_consecutive_outage_count_threshold  = 3   # 3 failures from 1 = local
    local_outages_count_threshold             = 1   # how many locations = "local"
  }
```

```
Global outage (ALL locations fail):
  Tokyo fails AND Singapore fails simultaneously.
  global_consecutive_outage_count_threshold = 1:
    Even 1 failure from ALL locations = global outage alert.
  
  Why only 1 failure for global?
    If both Tokyo AND Singapore can't reach payment.company.com:
    Almost certainly the service is down or DNS is broken globally.
    No need to wait for 3 consecutive failures — immediate alert.

Local outage (1 location fails):
  Tokyo fails, Singapore still succeeds.
  local_consecutive_outage_count_threshold = 3:
    Need 3 CONSECUTIVE failures from Tokyo before alerting.
  
  Why 3 for local?
    A single Tokyo failure could be:
      Tokyo → AWS transit network blip (30 seconds)
      DT synthetic probe server momentarily overloaded
      Transient DNS lookup failure
    3 consecutive = at least 15 minutes of sustained failure from that region.
    That's a real regional issue, not noise.
  
  local_outages_count_threshold = 1:
    How many locations must fail to be considered a "local" outage.
    = 1: any single location failing is treated as a local outage.

Result:
  Service truly down globally: page in <5 min (1 consecutive failure from all locations)
  Regional blip: no page (< 3 consecutive failures)
  Regional sustained issue: page after 15 min (3× 5-min intervals)
```

---

## Part 8 — `main.tf` Block 7: Notifications

### PagerDuty — the conditional for_each

```hcl
# Critical: only when pagerduty_integration_keys is non-empty AND environment is production
resource "dynatrace_pagerduty_notification" "critical" {
  for_each         = var.pagerduty_integration_keys
  alerting_profile = dynatrace_alerting.critical[each.key].id
  service_api_key  = each.value
```

```
var.pagerduty_integration_keys is:
  {} (empty map) in dev: for_each = {} → ZERO PagerDuty resources created
  {"payments": "key1", "orders": "key2", ...} in production: → 3 PagerDuty notification resources

alerting_profile = dynatrace_alerting.critical[each.key].id:
  each.key = "payments"
  References: dynatrace_alerting.critical["payments"].id
  This is a CROSS-RESOURCE REFERENCE:
    dynatrace_alerting.critical["payments"] is the management zone profile for the payments team.
    The PagerDuty notification is WIRED to that specific profile.
    "When the payments-production-critical alerting profile triggers → call PagerDuty with this key."

  If alerting_profile["payments"] doesn't exist (because critical profile wasn't created for dev):
    This would cause a Terraform error ("reference to undeclared resource").
    BUT: pagerduty_integration_keys = {} in dev → for_each = {} → resource never instantiated.
    No reference ever made. Safe.
```

### Slack notifications — the message template

```hcl
resource "dynatrace_slack_notification" "warning" {
  for_each         = var.slack_webhook_urls
  channel          = "#alerts-${each.key}"   # "#alerts-payments", "#alerts-orders", etc.
  message          = "[${upper(var.environment)}] {State} | {ProblemSeverity} | {ProblemTitle} | {ProblemURL}"
}

resource "dynatrace_slack_notification" "info" {
  for_each         = var.slack_webhook_urls
  channel          = "#monitoring"
  message          = "[INFO][${upper(var.environment)}] {State} | ${each.key} | {ProblemTitle} | {ProblemURL}"
}
```

```
{State}:          "OPEN" or "RESOLVED" — DT fills this at alert time
{ProblemSeverity}: "ERROR", "SLOWDOWN", "RESOURCE_CONTENTION"
{ProblemTitle}:   the alert summary (set in metric event summary field)
{ProblemURL}:     direct link to the DT problem — click → immediately see the problem in DT

WARNING → per-team channel (#alerts-payments):
  Only the payments team sees payment alerts.
  Only the orders team sees order alerts.
  No cross-team noise.

INFO → shared #monitoring channel:
  Resource contention (CPU, memory, heap) is shared context.
  Platform SREs want to see all resource alerts across all services.
  App teams don't want to be constantly pinged about CPU fluctuations.
  Shared channel: everyone can see it but nobody is specifically responsible.

upper(var.environment):
  "production" → "PRODUCTION"
  Makes environment immediately visible in the Slack message.
  "[PRODUCTION] OPEN | ERROR | payment-service: error rate > 0.1% | https://dt..."
  vs
  "[production] OPEN | ..."
  The all-caps prefix is visible at a glance in a busy Slack channel.
```

---

## Part 9 — `terraform/environments/*/main.tf` — Environment Callers

### Why 3 separate files (not one parameterized file)

```
Option A (what we have): 3 separate files
  terraform/environments/dev/main.tf
  terraform/environments/staging/main.tf
  terraform/environments/production/main.tf

Option B: one file with workspace or variables
  terraform/environments/main.tf
  Run with: terraform workspace select production → terraform apply

Why Option A is better for this project:

1. SEPARATE STATE FILES:
   Dev state: s3://company-terraform-state-dev/dev/terraform.tfstate
   Prod state: s3://company-terraform-state-prod/production/terraform.tfstate
   
   Separate state = separate blast radius.
   A terraform apply error in dev cannot corrupt the production state.
   With workspaces: all environments share one state file → one corruption = all environments affected.

2. SEPARATE CI TRIGGERS:
   Changing dev thresholds → only terraform-dynatrace-dev.yaml triggers.
   Changing prod thresholds → only terraform-dynatrace-production.yaml triggers.
   With workspaces: any change triggers all environments → unnecessary prod plans/applies for dev changes.

3. SEPARATE IAM ROLES:
   Dev:  role/github-actions-dynatrace-apply in account 123456789010
   Prod: role/github-actions-dynatrace-apply in account 123456789012
   Different AWS accounts = true isolation. Workspaces can't span AWS accounts.

4. INDEPENDENT MANUAL APPROVAL:
   Production has environment: production gate (requires human approval before apply).
   Dev has no gate.
   This is per-file behavior in GitHub Actions — impossible with a single shared workflow.
```

### AWS Secrets Manager data sources — why not hardcoded

```hcl
data "aws_secretsmanager_secret_version" "dt_api_token" {
  secret_id = "production/dynatrace/api-token"
}
data "aws_secretsmanager_secret_version" "dt_tenant_url" {
  secret_id = "production/dynatrace/tenant-url"
}
data "aws_secretsmanager_secret_version" "slack_webhooks" {
  secret_id = "production/dynatrace/slack-webhooks"
}
data "aws_secretsmanager_secret_version" "pagerduty_keys" {
  secret_id = "production/dynatrace/pagerduty-keys"
}
```

```
data "aws_secretsmanager_secret_version":
  A Terraform DATA SOURCE — reads from AWS, doesn't create anything.
  At terraform apply time: Terraform calls AWS Secrets Manager API → retrieves the secret value.
  The value is then passed into the module as a variable.

Why not var.dt_api_token in the root with TF_VAR_dt_api_token env var?
  Environment variables can leak: CI logs, shell history, process list.
  Secrets Manager: audited (CloudTrail), encrypted (KMS), access-controlled (IAM).
  If the CI runner is compromised: env vars are visible, Secrets Manager requires an IAM call.

The path naming convention:
  "production/dynatrace/api-token" = environment/service/secret-name
  Consistent across all secrets in the project.
  IRSA role for the GitHub Actions runner has:
    Allow: secretsmanager:GetSecretValue on "production/dynatrace/*"
  → CI can only read prod DT secrets. Not dev secrets. Not RDS passwords.

jsondecode() for multi-value secrets:
  slack_webhook_urls = jsondecode(data.aws_secretsmanager_secret_version.slack_webhooks.secret_string)
  
  The Slack webhooks secret is stored as JSON:
    {"payments": "https://hooks.slack.com/abc", "orders": "https://hooks.slack.com/def"}
  jsondecode() turns this JSON string into a Terraform map(string).
  The module receives it as the variable type it expects.
```

### The services map — production vs dev thresholds side-by-side

```
payment-service production:           payment-service dev:
  slo_target = 99.9                     slo_target = 90.0
  traffic_min_rps = 10                  traffic_min_rps = 0      (disabled)
  error_rate_alert = 0.1                error_rate_alert = 10.0
  latency_p99_ms = 300                  latency_p99_ms = 2000
  cpu_saturation_pct = 70               cpu_saturation_pct = 90
  memory_usage_pct = 75                 memory_usage_pct = 85
  jvm_heap_pct = 70                     jvm_heap_pct = 85
  pod_restart_threshold = 2             pod_restart_threshold = 5
  network_error_rate_pct = 0.5          network_error_rate_pct = 5.0

Dev latency 2000ms vs prod 300ms:
  Dev JVM: t3.medium, Xmx=256m, JIT never warm (restarts constantly).
  First request after pod start: 2000ms (interpreter mode, no compilation).
  Prod JVM: m7g.xlarge, Xmx=1024m, runs for days (fully JIT-compiled).
  Steady state prod: 150-200ms.
  
  If prod threshold (300ms) applied in dev:
    Pod starts → first request takes 2000ms → alert fires → engineer wakes up.
    "The dev pod just restarted." → useless alert. Alert fatigue.
  
  Dev threshold (2000ms): only fires when dev has a genuine extreme latency problem.
```

---

## Part 10 — GitHub Actions Workflows (3 files)

### Common structure (all 3 workflows share this pattern)

```yaml
on:
  push:
    branches: [main]
    paths:
      - 'terraform/environments/dev/**'
      - 'terraform/modules/dynatrace/**'   ← BOTH paths!
  pull_request:
    branches: [main]
    paths:
      - 'terraform/environments/dev/**'
      - 'terraform/modules/dynatrace/**'
```

### Why both `environments/dev/**` AND `modules/dynatrace/**` in paths

```
Scenario A: Only environments/dev/** in paths
  You fix a bug in terraform/modules/dynatrace/main.tf (the shared module).
  Only the environments you also touch trigger their CI.
  If you ONLY modified main.tf (no env file touched):
    dev CI: does NOT trigger (path didn't match)
    staging CI: does NOT trigger
    prod CI: does NOT trigger
  Result: the bug fix is in the repo but NOBODY runs terraform apply.
  All 3 environments continue using the OLD (buggy) module logic until someone manually applies.

Scenario B: Both paths included (what we have)
  You fix a bug in terraform/modules/dynatrace/main.tf.
  Terraform picks up the module change from the environments/ directory that CALLS the module.
  ALL 3 CI workflows trigger (because modules/dynatrace/** matched).
  All 3 environments get: terraform plan (on PR) → terraform apply (after merge).
  Bug fix reaches all environments automatically.

This is the "trigger on module changes" pattern — critical for shared modules.
```

### Plan on PR — why and how

```yaml
jobs:
  plan:
    name: Dev DT Plan
    if: github.event_name == 'pull_request'
    permissions: { id-token: write, contents: read, pull-requests: write }
    steps:
      - name: Terraform Plan
        run: terraform plan -no-color 2>&1 | tee plan.txt
      - name: Post plan to PR
        uses: actions/github-script@v7
        with:
          script: |
            const plan = fs.readFileSync('${{ env.WORKING_DIR }}/plan.txt', 'utf8');
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              body: `## Dynatrace Dev Plan\n\`\`\`\n${plan.substring(0,65000)}\n\`\`\``
            });
```

```
terraform plan on PR:
  Terraform reads the current state, reads the new config, calculates the DIFF.
  Output format:
    ~ dynatrace_metric_events.latency_p99["payment-service"]:
        ~ model_properties[0].threshold: 300000 → 250000    (threshold changed)
    
    + dynatrace_slo_v2.availability["new-service"] (new SLO to be created)
    
    - dynatrace_http_monitor.health_check["old-service"] (monitor to be destroyed)

  The reviewer sees EXACTLY what changes will happen in DT before approving.
  "+" = create, "~" = modify, "-" = destroy.
  Destroy is the most dangerous operation → reviewer can catch accidental deletions.

2>&1 | tee plan.txt:
  2>&1: redirect stderr to stdout (plan errors are on stderr)
  |: pipe combined output to next command
  tee: write to file AND print to screen
  plan.txt: the file read by the github-script step

plan.substring(0, 65000):
  GitHub API comment size limit: 65,536 characters.
  Terraform plans can be very long (hundreds of resources).
  Truncate at 65,000 to stay within the API limit.
  If plan is longer: the comment shows the first 65,000 chars (usually enough context).
```

### Apply on merge — the OIDC role assumption

```yaml
  apply:
    name: Dev DT Apply
    if: github.event_name == 'push'    # only on merge to main, not on PR
    permissions: { id-token: write, contents: read }
    steps:
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789010:role/github-actions-dynatrace-apply
          aws-region: ap-northeast-1
      - name: Terraform Apply
        run: terraform apply -auto-approve -no-color
```

```
permissions: id-token: write:
  Enables OIDC token generation for this job.
  GitHub generates a JWT (JSON Web Token) signed by GitHub's OIDC provider.
  This JWT is sent to AWS STS (Security Token Service) to assume the IAM role.
  No AWS credentials are stored in GitHub Secrets.

role-to-assume: arn:aws:iam::123456789010:role/github-actions-dynatrace-apply
  Account 123456789010 = dev account.
  This IAM role has permissions:
    Allow: secretsmanager:GetSecretValue on "dev/dynatrace/*"
    Allow: (Dynatrace provider uses the DT API token from Secrets Manager, not AWS APIs)
  
  The role is configured in AWS to trust only:
    GitHub Actions OIDC provider: token.actions.githubusercontent.com
    For repository: company/java-3envs-dynatrace
    For ref: refs/heads/main (only main branch can assume this role)
  
  Security: a PR branch cannot assume this role → no accidental applies from feature branches.

-auto-approve:
  Skips the interactive "Do you want to perform these actions? (yes/no)" prompt.
  In CI there's no terminal to type "yes". Required for non-interactive CI.
  The human approval is handled by the GitHub Environment gate (for production),
  not by the terraform command.
```

### Production workflow — the manual approval gate

```yaml
  apply:
    name: Prod DT Apply
    if: github.event_name == 'push'
    environment: production     # ← THIS is the gate
    steps:
      ...
      - run: terraform apply -auto-approve -no-color
```

```
environment: production:
  References a GitHub Environment named "production" (configured in GitHub repo settings).
  GitHub Environments can have:
    Required reviewers: specific people who must approve before the job runs
    Wait timer: delay before the job starts (e.g., wait 10 minutes before applying to prod)
    Deployment branches: only main branch can deploy to production

  When the workflow reaches the apply job:
    GitHub PAUSES the job.
    Sends notification to required reviewers: "production deployment waiting for approval"
    Reviewer clicks "Approve" in GitHub UI.
    Job resumes and runs terraform apply.
  
  If nobody approves in 30 days: workflow times out.
  If reviewer rejects: workflow fails with "deployment was rejected."

Why manual approval for production only?
  Dev: threshold changes are low risk (no users, no SLA). Auto-apply is fine.
  Staging: threshold changes affect k6 load test results. Auto-apply acceptable (staging has no SLA).
  Production: ANY change to production DT config changes what fires alerts.
    Accidentally deleting a critical alert → silent failures in production → users impacted.
    Human review: "this changes payment-service P99 threshold from 300ms to 250ms.
                   Is this intentional? Is the service reliably performing below 250ms?"
```

### The 3 IAM roles — why different roles per operation

```
github-actions-dynatrace-plan role:
  Permissions: secretsmanager:GetSecretValue (read DT credentials)
               NOTHING else in AWS (plan doesn't create/modify AWS resources)
  Used by: plan job (PR)
  
  Principle of least privilege: the plan job doesn't need to create anything.
  If this role is compromised: attacker can READ DT credentials but not CHANGE anything.

github-actions-dynatrace-apply role:
  Permissions: secretsmanager:GetSecretValue (same as plan)
  Used by: apply job (merge to main)
  
  Why same permissions as plan role?
  The Dynatrace provider calls DYNATRACE APIs, not AWS APIs.
  The only AWS API it needs is Secrets Manager to get the DT token.
  AWS permissions = minimal (just read secrets).
  DT permissions = full (the DT API token has settings.write, metric.write, etc.).
  
  Separation: plan role could be even more restricted (remove all permissions except read)
              but in practice plan also needs to call Secrets Manager to do a complete plan.
  These are TWO DIFFERENT IAM roles → two separate audit trails:
    CloudTrail shows "github-actions-dynatrace-apply" assumed role → terraform apply ran.
    Clearly shows when production changes were applied and by which role.
```

### Dev workflow vs Production workflow — differences table

| Setting | Dev | Staging | Production |
|---|---|---|---|
| AWS Account | 123456789010 | 123456789011 | 123456789012 |
| Plan role | `...-plan` (dev acct) | `...-plan` (staging acct) | `...-plan` (prod acct) |
| Apply role | `...-apply` (dev acct) | `...-apply` (staging acct) | `...-apply` (prod acct) |
| `environment:` on apply | *(none)* | *(none)* | `production` (manual approval) |
| PR comment title | "Dynatrace Dev Plan" | "Dynatrace Staging Plan" | "Dynatrace Production Plan" |
| WORKING_DIR | `terraform/environments/dev` | `terraform/environments/staging` | `terraform/environments/production` |

---

## Common Mistakes in These Files

| Mistake | Where | Symptom | Fix |
|---------|-------|---------|-----|
| Missing `modules/dynatrace/**` in workflow paths | `.github/workflows/*.yaml` | Module bug fix not applied to env | Add both env and module paths |
| `sensitive = false` on dt_api_token | `variables.tf` | Token appears in CI logs | Always `sensitive = true` for credentials |
| latency threshold in ms not µs | `main.tf` model_properties | Alert fires on every request (300 = 0.3ms threshold) | Multiply by 1000: `latency_p99_ms * 1000` |
| `alert_on_no_data = true` on error rate | `main.tf` | Alert fires when service is idle (no traffic) | Only traffic drop gets `alert_on_no_data = true` |
| No `environment: production` gate | production workflow | Production DT changes applied without approval | Add `environment: production` to apply job |
| Same `pagerduty_integration_keys` for dev | dev `main.tf` | Dev alerts page production on-call | `pagerduty_integration_keys = {}` in dev |
| local outage threshold = 1 (not 3) | `main.tf` synthetic | Single regional network blip pages on-call | `local_consecutive_outage_count_threshold = 3` |
| teams derived from services wrong | `main.tf` locals | Extra/missing management zones | Verify `toset([for svc in values(var.services) : svc.team])` |
