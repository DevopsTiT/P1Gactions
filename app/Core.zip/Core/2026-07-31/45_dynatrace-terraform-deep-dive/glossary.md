# Glossary — Dynatrace Terraform Module + Workflows Deep-Dive
Every term from main.md. One entry per term. SRE beginner level.

---

**Terraform module**
A reusable, parameterized block of Terraform resources. Called from multiple places with different inputs. `terraform/modules/dynatrace/main.tf` = one module called 3 times (dev, staging, production). Why it matters: fix a bug once in the module → all 3 environments get the fix on their next `terraform apply`.

**Module caller**
A Terraform file that calls a module with specific input values. `terraform/environments/production/main.tf` calls the dynatrace module with production-specific thresholds. Why it matters: the caller provides the "what" (thresholds, teams, URLs) while the module provides the "how" (which DT resources to create).

**`sensitive = true` (Terraform variable)**
Marks a variable as containing a secret. Terraform hides its value in plan/apply output. Still stored in the state file (which must be encrypted). Why it matters: prevents DT API tokens and PagerDuty keys from appearing in CI logs where anyone with access can read them.

**`map(object({...}))` (Terraform type)**
A Terraform variable type representing a map where every value has the same named fields. Example: `map(object({ team = string, slo_target = number, ... }))`. Why it matters: enforces that every service in the map has ALL required fields — if you add a service and forget a threshold, `terraform plan` fails immediately with a clear error.

**`default = {}` (empty map)**
Gives a variable a default value of an empty map. For `pagerduty_integration_keys = {}` in dev: `for_each` on an empty map creates ZERO notification resources. Why it matters: dev passes no PagerDuty keys → no PagerDuty notifications created → no false on-call pages from dev.

**`toset()` (Terraform function)**
Converts a list to a set (deduplicated, unordered). Used with `for_each`. Why it matters: `for_each` requires a set or map. `toset` also deduplicates — two services on the same team produce only ONE management zone.

**`for svc in values(var.services) : svc.team`**
A Terraform `for` expression iterating over map values to extract one field. Produces a list of team names like `["payments", "orders", "notifications"]`. Why it matters: derives the set of teams dynamically from the services map — no need to separately list teams; adding a new service with a new team automatically creates a management zone for that team.

**Terraform `locals {}`**
A block that defines computed values reused across the module. `locals.teams` = derived set of team names. `locals.services_with_traffic` = filtered services where traffic_min_rps > 0. Why it matters: avoids repeating the same complex expression multiple times; makes intent clear.

**Terraform ternary expression**
`condition ? value_if_true : value_if_false`. Example: `var.environment == "production" ? local.teams : toset([])`. If production: create resources for all teams. Otherwise: create nothing. Why it matters: controls which resources exist per environment without separate resource blocks per env.

**`contains(list, value)` (Terraform)**
Returns true if the list contains the value. `contains(["production", "staging"], var.environment)` = true for staging and production, false for dev. Why it matters: HIGH alerting profile exists in both staging and production (not dev) — this is the conditional that implements that rule.

**Dynatrace Management Zone**
A logical grouping in DT that scopes which entities each team sees and receives alerts for. Created per team per environment: `payments-production`, `orders-production`, etc. Why it matters: payment team only sees payment metrics; they don't see order-service alerts (no cross-team noise).

**`for_each = local.teams`**
Creates one resource per team (one management zone for payments, one for orders, one for notifications). `each.value` = the team name inside the resource block. Why it matters: 3 services = 3 teams = 3 management zones, all from ONE resource block.

**`dynatrace_alerting` resource**
A Terraform resource that creates a DT Alerting Profile — defines which severity levels trigger, with what delay, scoped to which management zone. Why it matters: the alerting profile is the gatekeeper between a DT problem and a notification — it determines who gets notified and when.

**`delay_in_minutes` (alerting profile)**
How many minutes DT waits after detecting a problem before sending a notification. AVAILABILITY: 0. ERROR: 2. SLOWDOWN: 5. RESOURCE_CONTENTION: 15. Why it matters: filters transient blips. A 2-min error delay means a deploy-induced spike (lasting 90s) never pages anyone.

**`STATIC_THRESHOLD` (metric event type)**
A DT metric event model that fires when a metric crosses a fixed threshold. Alternative: AUTO_ADAPTIVE (learns baseline). Why this project uses static: per-environment thresholds are deliberate engineering decisions, not learned baselines. Dev latency = 2000ms by design, not auto-detected.

**`alert_condition = "ABOVE"` vs `"BELOW"`**
`ABOVE`: fires when metric exceeds threshold (7 out of 8 signals). `BELOW`: fires when metric DROPS BELOW threshold (traffic drop only). Why it matters: traffic drop is the only signal where "too low" is the problem — all other signals fire on excess.

**`alert_on_no_data = true`**
Fires the metric event even when DT receives ZERO data points (not just when the metric is above/below the threshold). Used ONLY on traffic drop. Why it matters: if a service crashes completely, it sends NO metrics. `alert_on_no_data = true` fires even when there's nothing to measure.

**`violating_samples` and `dealerting_samples`**
`violating_samples = 3`: alert fires when 3 out of `samples` data points are above threshold. `dealerting_samples = 3`: alert clears when 3 consecutive points are below threshold. Why it matters: prevents single-minute spikes from triggering and clearing alerts constantly.

**`samples = 5, violating_samples = 3`**
"3 out of 5 minutes must violate before alerting." This is a majority vote over a 5-minute window. Why it matters: brief spikes (1-2 minutes) don't trigger alerts. Sustained problems (3+ minutes) do. Balances sensitivity with noise reduction.

**`event_entity_dimension_key`**
Tells DT which type of entity to attach the alert to when it fires. SERVICE, PROCESS_GROUP_INSTANCE, CLOUD_APPLICATION, or HOST. Why it matters: different metrics are measured on different entity types — HTTP metrics on SERVICE, JVM metrics on PROCESS, network metrics on HOST. Using the wrong dimension key misattributes alerts.

**`dt.entity.service`**
The DT entity type for an HTTP service endpoint. Signals 1-3 (traffic, error rate, latency) attach to this type. Why it matters: service-level metrics (request count, error rate, response time) are naturally attributed to the SERVICE entity.

**`dt.entity.process_group_instance`**
The DT entity type for a JVM process instance. Signals 4-6 (CPU, memory, JVM heap) attach to this type. Why it matters: JVM heap is a property of the process, not the HTTP service. Correct entity attachment makes DT dashboards show the alert on the right component.

**`dt.entity.cloud_application`**
The DT entity type for a Kubernetes workload (Deployment). Signal 7 (pod restarts) attaches to this type. Why it matters: pod restarts are a Kubernetes-level event — they belong on the cloud application (workload) entity, not the service or process entity.

**`builtin:service.requestCount.server`**
DT auto-captured metric counting inbound HTTP requests per minute. The basis for traffic drop and availability SLO. Why it matters: when this is zero — and `alert_on_no_data = true` — the service is either down or completely unreachable. The denominator of every availability calculation.

**`builtin:service.errors.server.rate`**
DT auto-captured metric for the percentage of inbound requests returning 5xx status codes. Why it matters: direct measure of user-facing failures — the most watched metric after traffic.

**`builtin:service.response.time:percentile(99)`**
DT metric for the 99th percentile response time in microseconds. `:percentile(99)` is a metric transformation applied server-side. Why it matters: P99 shows the worst realistic user experience — not the average that hides slow tails.

**Microseconds (DT internal unit)**
Dynatrace stores ALL time-based metrics in microseconds (µs) internally. 300ms = 300,000µs. Terraform calculates `latency_p99_ms * 1000` to convert to the correct unit. Why it matters: using 300 (ms) instead of 300,000 (µs) sets a threshold of 0.3ms — nearly every request triggers the alert.

**`<<-EOT ... EOT` (Terraform heredoc)**
A multi-line string syntax. `<<-EOT` starts the string; `EOT` ends it. The `-` allows indented content to be de-indented. Used for DT metric expressions. Why it matters: DT metric expressions are multi-line. Heredoc is cleaner than concatenating strings with `\n`.

**DT Metrics Query Language (MQL)**
The query language for DT metric expressions. Functions: `:filter()`, `:splitBy()`, `:sum`, `:percentile()`, `le()`. Used in SLO metric_expression fields. Why it matters: SLOs are defined using MQL — the expression calculates the % of requests meeting the objective.

**`:filter(and(eq(...), eq(...)))`**
MQL filter function. `eq(service.name, "payment-service")` = only include this service. Multiple conditions inside `and()` must ALL be true. Why it matters: without filters, the SLO would measure ALL services' requests combined — you'd get a meaningless average.

**`:splitBy():sum`**
MQL aggregation. `:splitBy()` = aggregate across all dimensions (no grouping). `:sum` = sum the values. Why it matters: sums request counts across all pods/instances for a total service-level count.

**`le(builtin:service.response.time, 300000)`**
MQL filter: "less than or equal to 300,000 microseconds." Used in latency SLO to count only fast requests. Why it matters: enables calculating "what % of requests were fast enough" — the core of a latency SLO.

**`evaluation_window = "-1M"`**
The SLO looks at the last 30 days (rolling window). `-1M` = minus 1 month. Why it matters: rolling windows give continuous reliability tracking — no artificial reset at calendar month boundaries.

**`evaluation_type = "AGGREGATE"`**
The SLO counts ALL requests in the window as one pool, not as per-minute averages. 1M requests total, 1K errors = 99.9% availability. Why it matters: aggregate is the correct measure of user experience — it's the proportion of ALL interactions that were good.

**`fast_burn_threshold = 14.4`**
DT SLO setting: if consuming error budget 14.4× faster than normal, the budget is exhausted in 2 days. Fires an urgent alert. Why it matters: 14.4 = 30 days / 2 days — the widely used constant from Google SRE Book for "2-day exhaustion" fast burn detection.

**`slow_burn_threshold = 3.0`**
Budget would be exhausted in 10 days at 3× burn rate. Fires a lower-urgency alert. Why it matters: catches gradual degradation — a service that's technically within SLO now but on track to breach it by end of month.

**`dynatrace_http_monitor`**
Terraform resource creating a DT Synthetic HTTP monitor. Sends real HTTP requests from global locations on a schedule. Why it matters: outside-in monitoring — catches DNS failures, ALB misconfigs, TLS cert expiry that OneAgent (inside the cluster) cannot see.

**`accept_any_certificate = false`**
Synthetic monitor setting that rejects expired or self-signed TLS certificates. Why it matters: an expired cert causes browser security warnings for users. The synthetic catches cert expiry before users do.

**`follow_redirects = true`**
Synthetic follows HTTP redirects (e.g., HTTP 301 → HTTPS). Without this: the synthetic sees HTTP 301 (not 2xx) → fails. Why it matters: our Ingress always redirects HTTP → HTTPS — the synthetic must follow the redirect to validate the real response.

**`patternConstraint = "\"status\":\"UP\""`**
Synthetic validation rule: response body must contain the string `"status":"UP"`. Why it matters: Spring Boot Actuator can return HTTP 200 with body `{"status":"DOWN"}` if a dependency is unhealthy. Status 200 alone is not enough — body content must confirm health.

**`response_time_limit = latency_p99_ms * 3`**
Synthetic alert threshold: if the health check takes > 3× P99 to respond, alert fires. For payment-service (300ms P99): fires if health check takes > 900ms. Why it matters: synthetics add network latency from Tokyo → Tokyo to AWS (adds ~50-100ms). 3× P99 accounts for this overhead.

**`global_consecutive_outage_count_threshold = 1`**
Trigger a global outage alert after just 1 failure from ALL synthetic locations simultaneously. Why it matters: if both Tokyo and Singapore can't reach the service, it's almost certainly down globally. No need to wait for multiple failures.

**`local_consecutive_outage_count_threshold = 3`**
Trigger a local outage alert after 3 consecutive failures from ONE location. Why it matters: a single failure from one region could be a 30-second network blip. 3 consecutive = at least 15 minutes of sustained regional issue = real problem, not noise.

**`dynatrace_pagerduty_notification`**
Terraform resource creating a DT notification rule that sends to PagerDuty. Wired to a specific alerting profile. Why it matters: this is the final link — when the payments-production-critical profile fires, THIS resource routes it to the payments team's PagerDuty integration key.

**`dynatrace_slack_notification`**
Terraform resource creating a DT notification rule that posts to a Slack channel via webhook. Why it matters: WARNING tier (slowdowns) and INFO tier (resource contention) go to Slack — the right destination for non-urgent issues that don't need a 3am phone call.

**`{State} | {ProblemSeverity} | {ProblemTitle} | {ProblemURL}` (DT message template)**
DT placeholder variables in notification message templates. Filled at alert time: `{State}` = "OPEN"/"RESOLVED", `{ProblemURL}` = direct link to the DT problem. Why it matters: engineers can click directly from Slack to the DT problem without searching.

**`data "aws_secretsmanager_secret_version"`**
Terraform data source that reads a secret from AWS Secrets Manager at plan/apply time. Not a resource — it doesn't create anything. Why it matters: secrets (DT tokens, PagerDuty keys) are never stored in Terraform files or Git — pulled from Secrets Manager at runtime.

**`jsondecode()`**
Terraform function that parses a JSON string into a Terraform map/list. Used to parse the Slack webhooks secret (stored as JSON in Secrets Manager) into a `map(string)` that the module expects. Why it matters: Secrets Manager stores one JSON blob per secret. `jsondecode` converts it to the correct Terraform type.

**`terraform plan -no-color`**
Runs Terraform plan without ANSI color escape codes. Required for CI environments where color codes appear as garbled characters in logs and PR comments. Why it matters: plan output posted as a GitHub PR comment must be plain text.

**`2>&1 | tee plan.txt`**
Shell pipeline: `2>&1` redirects stderr to stdout (combined stream). `tee` writes the combined output to a file AND continues to stdout. Why it matters: Terraform plan errors go to stderr. Without `2>&1`, error messages are not captured in plan.txt and don't appear in the PR comment.

**`plan.substring(0, 65000)`**
JavaScript string truncation to 65,000 characters. GitHub API comment limit is ~65,536 chars. Why it matters: large plans (many resources) exceed the limit. Truncating ensures the PR comment is created rather than failing with an API error.

**OIDC (OpenID Connect) — GitHub Actions to AWS**
GitHub generates a JWT signed by its OIDC provider. AWS STS exchanges this JWT for temporary IAM credentials. No static access keys stored in GitHub. Why it matters: credentials auto-rotate, can't be leaked from GitHub Secrets, and are audited in CloudTrail with "github-actions" as the assumed role identity.

**`environment: production` (GitHub Actions)**
References a GitHub Environment with protection rules. The apply job PAUSES for a human reviewer to approve before running. Why it matters: prevents accidental Dynatrace config changes in production (deleting an alert threshold, removing a critical notification) without human review.

**`terraform apply -auto-approve`**
Skips the interactive "Do you want to apply? (yes/no)" confirmation. Required in CI (no interactive terminal). Why it matters: without it, `terraform apply` waits forever for keyboard input that never comes — the CI job hangs indefinitely.

**Separate state files per environment**
Each environment (dev, staging, production) has its own Terraform state file in its own S3 bucket. Why it matters: a corrupted or invalid state in dev cannot affect production. Blast radius is isolated per environment.

**`role-to-assume` per environment**
Dev CI uses an IAM role in account 123456789010. Production CI uses a different role in account 123456789012. Why it matters: a bug in the dev CI pipeline cannot accidentally modify production DT configuration — it literally doesn't have permission to call the production AWS account.
