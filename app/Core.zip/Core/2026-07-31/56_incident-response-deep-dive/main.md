# SRE Deep Dive: Incident Response — Complete End-to-End Guide

---

## Decision Tree: Where Are You Right Now?

```
START
  │
  ├─ Alert just fired → you're on-call ───────────────────→ Part 2 (Detect & Assemble)
  │
  ├─ You're in an active incident right now ───────────────→ Part 3 (Triage) or Part 4 (Mitigate)
  │
  ├─ Incident just resolved, writing post-mortem ─────────→ Part 6 (Post-Mortem)
  │
  ├─ Building incident response process from scratch ──────→ Start at Part 1
  │
  └─ Want to improve an existing process ──────────────────→ Part 7 (Improvement Loop)
```

---

## E2E Flow: The Incident Lifecycle

```
[Signal Detected]
  │
  ▼
PHASE 1: DETECT (T+0 to T+5 min)
  Alert fires → On-call acknowledged → Is it real?
  │
  ├─ False positive → silence alert, tune threshold
  │
  └─ Real incident → determine severity
  │
  ▼
PHASE 2: ASSEMBLE (T+5 to T+10 min)
  Open incident channel → Assign IC → Notify stakeholders
  │
  ▼
PHASE 3: TRIAGE (T+10 to T+25 min)
  What is broken? Who is affected? When did it start? Getting worse?
  │
  ▼
PHASE 4: MITIGATE (T+15 to T+60 min)
  STOP user pain NOW — rollback / scale / redirect / disable feature
  │
  ├─ Mitigation successful → user pain stops
  │
  └─ Mitigation failed → escalate, try next strategy
  │
  ▼
PHASE 5: RESOLVE (T+30 to T+120 min)
  Metrics stable for 15+ min → declare resolved → update stakeholders
  │
  ▼
PHASE 6: POST-MORTEM (T+48h to T+72h)
  Timeline → root cause → contributing factors → action items
  │
  ▼
PHASE 7: IMPROVEMENT LOOP (ongoing)
  Close action items → reduce toil → better detection → faster MTTR
```

---

## Part 1 — Incident Severity: Defining the Scale Before You Need It

### Why Pre-Defined Severity Levels Are Critical

During an active incident, there is no time to debate how serious something is. Pre-agreed severity definitions allow immediate, correct responses:
- Who gets paged (on-call only vs. entire team vs. executives)
- How fast they must respond (5 minutes vs. 1 hour)
- What communication is required (status page? customer email? executive update?)
- What process shortcuts are allowed (skip PR review? deploy without canary?)

Without agreed severity levels, every incident becomes a high-stakes negotiation while users suffer.

### The Full Severity Matrix

```
SEV 1 — CRITICAL (All-Hands, Revenue-Impact)
─────────────────────────────────────────────────────────────────
Definition:
  Production completely down, all users affected, revenue stopped,
  or a security breach confirmed or suspected.

Qualifying conditions (ANY ONE triggers SEV1):
  ✓ Error rate > 50% across core service for > 5 minutes
  ✓ Payment / checkout / auth service completely unavailable
  ✓ Data loss confirmed or suspected
  ✓ Security breach: unauthorized data access, leaked credentials
  ✓ SLA breach in progress for a tier-1 customer
  ✓ All pods crash-looping; no healthy replicas

Response SLA:
  Acknowledge: within 5 minutes, 24/7
  First update: within 10 minutes
  Executive notified: within 15 minutes

Who is paged:
  On-call SRE → Engineering Manager → VP Engineering (if >15 min unresolved)

Authority:
  IC can approve emergency deploys without PR review
  IC can approve budget for emergency cloud resources
  IC can skip change freeze

Post-mortem: Mandatory, within 24 hours, published to all of engineering

──────────────────────────────────────────────────────────────────
SEV 2 — MAJOR (Significant User Impact, Revenue at Risk)
─────────────────────────────────────────────────────────────────
Definition:
  Significant degradation, significant % of users affected, or a
  critical business function impaired.

Qualifying conditions:
  ✓ Error rate 10–50% on core service
  ✓ Core service severely degraded (works but slowly — > 5x normal latency)
  ✓ Single enterprise customer completely blocked
  ✓ SLO burn rate > 14.4x sustained > 15 minutes
  ✓ Data pipeline > 2 hours behind, causing business decisions on stale data

Response SLA:
  Acknowledge: within 15 minutes, 24/7
  First update: within 20 minutes
  Manager notified: within 30 minutes if unresolved

Who is paged:
  On-call SRE (phone call via PagerDuty)
  Escalate to manager if not resolved in 30 minutes

Post-mortem: Mandatory, within 48 hours

──────────────────────────────────────────────────────────────────
SEV 3 — MINOR (Partial Degradation, Limited Impact)
─────────────────────────────────────────────────────────────────
Definition:
  Partial degradation, limited user impact, workaround exists.

Qualifying conditions:
  ✓ Error rate 1–10% on non-core endpoint
  ✓ Non-critical feature broken
  ✓ Single geographic region degraded (others healthy)
  ✓ Performance 2–5x worse than baseline but within acceptable range
  ✓ Batch job failed (but real-time service healthy)

Response SLA:
  Acknowledge: within 1 hour during business hours
  Acknowledge: within 4 hours outside business hours

Who is notified:
  Slack DM to on-call (not a phone call)
  Team channel notification

Post-mortem: Optional (encouraged for 3+ recurring SEV3)

──────────────────────────────────────────────────────────────────
SEV 4 — LOW (Cosmetic or Informational)
─────────────────────────────────────────────────────────────────
Definition:
  No user-facing degradation. Cosmetic, non-critical, or informational.

Qualifying conditions:
  ✓ Log pipeline delayed (metrics still collected)
  ✓ Non-critical batch job failed (can rerun tomorrow)
  ✓ Dashboard broken (data collection fine, display broken)
  ✓ Alert confirmed false positive
  ✓ Staging environment degraded (production fine)

Response SLA:
  Next business day

Who is notified:
  Slack message in team channel (no page, no DM)

Post-mortem: Not required
```

### Severity Escalation Rules

```
When to escalate severity UP:
  SEV3 → SEV2: Impact spreading to more users, workaround fails
  SEV2 → SEV1: Error rate reaches 50%, data loss suspected, executive asks
  Any level: Duration > 2x expected resolution time

When to de-escalate severity DOWN:
  Only when MITIGATION is complete AND metrics have been stable for 15+ minutes
  Never de-escalate while mitigation is still in progress
  "It looks like it might be recovering" ≠ de-escalation threshold

The escalation announcement:
  "Upgrading to SEV1. Reason: error rate crossed 50%. 
   Adding @VP-Engineering to the bridge. IC remains @alice."
```

---

## Part 2 — Detect & Assemble: The First 10 Minutes

### The Detection Chain (How You Learn About Incidents)

```
Primary detection (automated — ideal):
  Prometheus alert → Alertmanager → PagerDuty → Phone call

Secondary detection (semi-automated — backup):
  Synthetic monitor fails → external alert → Slack → on-call DM

Tertiary detection (reactive — means monitoring missed it):
  Customer support ticket → #incidents channel → on-call pinged
  Customer Slack message → on-call DM
  Automated ChatBot from uptime service → #incidents

If tertiary detection fires first → monitoring failure.
Post-incident: add proactive alert that would have caught this.

Detection gap formula:
  Customer report time - Alert fire time = Detection gap
  Target: < 0 (alert fires before customer reports)
  Actual: if positive, you failed to detect proactively
```

### PagerDuty On-Call Configuration (Best Practices)

```
On-call schedule:
  Primary on-call:   One engineer per week (rotates among team)
  Secondary on-call: Shadow / backup (rotates offset from primary)
  
Escalation policy:
  T+0:    Alert fires → PagerDuty calls primary on-call (phone call)
  T+5m:   No ack → PagerDuty calls secondary on-call
  T+10m:  No ack → PagerDuty calls Engineering Manager
  T+15m:  No ack → PagerDuty calls VP Engineering
  
Notification channels per severity:
  SEV1: Phone call + SMS + Slack DM simultaneously
  SEV2: Phone call + Slack DM
  SEV3: Slack DM only (no phone call)
  SEV4: Slack channel message only

Critical configuration:
  Phone volume MUST be audible during on-call week
  Phone must NOT be on Do Not Disturb during on-call
  All on-call engineers test PagerDuty setup before their shift
  On-call handoff includes: "Any known issues? Any risky deploys planned?"
```

### Is This a Real Incident? (First 2-Minute Check)

```
On-call receives a page. Before opening an incident channel, do a 2-minute sanity check:

Step 1: Open the dashboard linked in the alert
  Is the metric actually bad? → Yes → real incident
  Does the dashboard show everything healthy? → Alert may be stale or false positive

Step 2: Check Prometheus for the alert expression
  curl -s "http://prometheus:9090/api/v1/alerts" | jq '.data.alerts[] | select(.state=="firing")'
  Is it still firing? → Yes → real
  Already resolved? → False positive, silence it

Step 3: Check for obvious cause
  Recent deploy? → Very likely real
  No recent change? → Check external dependencies (AWS status page, downstream APIs)

Step 4: Decision
  If any evidence of real user impact → open incident, don't wait for 100% confirmation
  Err on the side of opening an incident (easy to close) vs. missing a real one

Time target: < 2 minutes to determine real vs. false positive
```

### Opening the Incident Channel (The First Message Matters)

The incident channel is the single source of truth for the entire response. Everything goes here.

```
Channel naming convention:
  #incident-YYYY-MM-DD-service-brief-description

Examples:
  #incident-2026-07-31-payment-high-error-rate
  #incident-2026-07-31-auth-service-down
  #incident-2026-07-31-db-connection-pool-exhausted

FIRST MESSAGE template (post within 2 minutes of opening channel):

🚨 [SEV2 INCIDENT OPEN] payment-service elevated error rate

Status:  INVESTIGATING
Impact:  ~20% of payment API requests failing since 14:32 UTC
Signal:  SLOFastBurn alert fired (1h window 22x burn rate)
Last change: payment-service v3.2.1 deployed at 14:20 UTC

Roles:
  IC (Incident Commander): @alice
  Comms Lead:              @bob
  SME (payment):           @charlie
  Observer:                @eng-manager

Dashboard:   https://grafana.internal/d/payment-overview
Runbook:     https://wiki.internal/runbooks/payment-high-error-rate
Status page: https://status.company.com

Updates every 10 minutes.
ALL response activity in this channel.
DM @alice if you have relevant information.
```

### Role Assignments — The Most Critical First Action

```
INCIDENT COMMANDER (IC):
  One person. Only one. No exceptions.
  
  What IC does:
    ✓ Assigns tasks explicitly by name: "@charlie check DB connection pool"
    ✓ Makes the call on mitigation strategy
    ✓ Controls the communication cadence
    ✓ Decides when to escalate severity
    ✓ Decides when to declare resolved
    ✓ Keeps the channel organized
  
  What IC does NOT do:
    ✗ Investigate or debug the problem
    ✗ Write code or run commands
    ✗ Make technical decisions unilaterally without SME input
    ✗ Talk to customers directly (that's Comms Lead)
  
  Why only ONE IC?
    Multiple ICs = conflicting decisions = confusion = slower MTTR
    "What should I do?" → only one answer possible with one IC

SUBJECT MATTER EXPERT (SME):
  The engineer who knows the broken system.
  
  What SME does:
    ✓ Runs commands, checks logs, reads code
    ✓ Reports findings to IC ("DB connection pool at 98%, not the cause")
    ✓ Proposes mitigation options
  
  What SME does NOT do:
    ✗ Make decisions to deploy or rollback without IC authorization
    ✗ Go silent — report findings every 5 minutes even if "still investigating"

COMMUNICATIONS LEAD:
  Keeps everyone outside the technical team informed.
  
  What Comms does:
    ✓ Updates the status page
    ✓ Sends executive Slack updates
    ✓ Drafts customer-facing communication
    ✓ Responds to #incidents channel questions from other teams
  
  What Comms does NOT do:
    ✗ Join technical debugging
    ✗ Speculate on root cause in public updates (only confirmed facts)

SCRIBE (SEV1 only):
  Records the timeline with exact timestamps.
  Used directly in the post-mortem.
  Only needed for SEV1 where timeline detail is critical.
```

---

## Part 3 — Triage: What, Who, When, How Bad?

### The Five Triage Questions

Answer these five questions in the first 15 minutes. Everything else comes after.

```
Q1: WHAT is broken?
  - Which endpoints or features? (not just "the service")
  - What error type? (5xx, timeout, wrong data, connection refused)
  - All users or specific segment?
  
  Commands:
    # Which endpoint has the highest error rate?
    kubectl logs -n production deploy/payment-service --tail=200 | grep -E "ERROR|5[0-9][0-9]" | awk '{print $NF}' | sort | uniq -c | sort -rn
    
    # Check error breakdown by endpoint in Prometheus
    curl -s "http://prometheus:9090/api/v1/query" \
      --data-urlencode 'query=topk(10, sum(rate(http_requests_total{status=~"5.."}[5m])) by (handler))' \
      | jq '.data.result[] | {endpoint: .metric.handler, rate: .value[1]}'

Q2: WHO is affected?
  - All users globally?
  - One geographic region?
  - Specific customer / tenant?
  - Specific user group (premium, free, admin)?
  
  Commands:
    # Check error rate by region (if you have region labels)
    curl -s "http://prometheus:9090/api/v1/query" \
      --data-urlencode 'query=sum(rate(http_requests_total{status=~"5.."}[5m])) by (region)' \
      | jq '.data.result[] | {region: .metric.region, rate: .value[1]}'
    
    # Check if only specific pods are failing
    sum(rate(http_requests_total{status=~"5.."}[5m])) by (pod)
    / sum(rate(http_requests_total[5m])) by (pod)

Q3: WHEN did it start?
  - Exact timestamp from the alert (not "a while ago")
  - What happened right before that?
  
  Commands:
    # Find the exact start time by looking at alert history
    curl -s "http://prometheus:9090/api/v1/alerts" \
      | jq '.data.alerts[] | select(.labels.alertname=="SLOFastBurn") | .startsAt'
    
    # Check deployment history — did a deploy precede the problem?
    kubectl rollout history deployment/payment-service -n production
    
    # Check recent Kubernetes events
    kubectl get events -n production --sort-by='.lastTimestamp' | tail -30

Q4: Is it GETTING WORSE, stable, or recovering?
  - Look at the error rate time series: is the line rising, flat, or falling?
  - Trending worse → urgent mitigation needed now
  - Recovering → may be self-healing, watch for 10 min before acting
  - Stable → systematic failure, investigation needed
  
  PromQL to assess trend:
    # Rate of change in error rate (positive = getting worse, negative = recovering)
    deriv(
      (sum(rate(http_requests_total{status=~"5.."}[5m]))
       / sum(rate(http_requests_total[5m])))[10m:]
    )

Q5: Is it YOUR service or a DEPENDENCY?
  This is the most important triage question.
  If it's a dependency: you are a VICTIM, not the CAUSE.
  Don't spend 30 minutes debugging your code when the DB is down.
  
  Commands:
    # Is the database up?
    kubectl exec -n production deploy/payment-service -- \
      pg_isready -h db-host.production.svc -p 5432
    
    # Is the downstream service responding?
    kubectl exec -n production deploy/payment-service -- \
      curl -sf -o /dev/null -w "%{http_code}" http://fraud-check-service/health
    
    # Redis / cache available?
    kubectl exec -n production deploy/payment-service -- \
      redis-cli -h redis.production.svc ping
    
    # Check all external dependency health at once
    kubectl exec -n production deploy/payment-service -- \
      curl -sf http://localhost:8080/health/ready | jq .
    # /health/ready returns status of all dependencies
```

### The Triage Decision Tree (Full)

```
Alert fires: error rate high on payment-service
│
├── CHECK: Is it in Prometheus? (still firing?)
│     NO → False positive, silence alert, done
│     YES → Continue
│
├── CHECK: Recent deployment?
│     YES (within last 60 min) → PRIME SUSPECT
│                                 Set rollback as Plan A BEFORE investigating further
│     NO → Continue
│
├── CHECK: All pods or specific pods failing?
│     SPECIFIC PODS (e.g., 1 of 10) →
│         → Node failure or pod-specific issue
│         → kubectl delete pod <bad-pod> (let it reschedule)
│         → NOT a rollback situation
│     ALL PODS →
│         → Systemic: code, config, or dependency
│         → Continue
│
├── CHECK: All endpoints or specific endpoint?
│     SPECIFIC ENDPOINT →
│         → Narrow code path or specific data-dependent failure
│         → kubectl logs | grep ERROR | grep <endpoint>
│         → Check recent code changes to that handler
│     ALL ENDPOINTS →
│         → Shared dependency (DB, auth, config) or full service crash
│         → Continue
│
├── CHECK: Is dependency down?
│     DB DOWN → Escalate to DB team, apply DB circuit breaker fix
│     AUTH DOWN → Escalate to auth team, apply bypass/fallback if possible
│     DOWNSTREAM API DOWN → Contact downstream team, activate fallback
│     ALL DEPENDENCIES HEALTHY → Problem is in your code
│
├── CHECK: Error type in logs?
│     "Connection refused" → Downstream service port not reachable
│     "OOMKilled" → Memory limit exceeded, pod killed
│     "Context deadline exceeded" → Timeout on outbound call
│     "NullPointerException" / panic → Code bug, likely deploy-related
│     "Too many connections" → DB/Redis connection pool exhausted
│
└── CONCLUDE:
      Assign cause hypothesis → pick mitigation → execute
      Report to IC: "Root cause hypothesis: [X]. Proposing mitigation: [Y]."
```

### Reading Logs Effectively During Triage

```bash
# ── GET THE RELEVANT LOGS FAST ────────────────────────────────────────

# Last 100 lines with only errors
kubectl logs -n production deploy/payment-service --tail=100 \
  | grep -E "ERROR|FATAL|Exception|panic"

# All pods for a service (streaming)
kubectl logs -n production -l app=payment-service --tail=50 -f \
  | grep -v "health check"  # exclude health check noise

# Logs from a specific time window (incident window)
kubectl logs -n production deploy/payment-service \
  --since-time="2026-07-31T14:30:00Z" \
  | grep -E "ERROR|Exception" \
  | head -50

# Previous container logs (if pod restarted — crash log)
kubectl logs -n production <pod-name> --previous \
  | tail -100

# ── EXTRACT PATTERNS FROM LOGS ───────────────────────────────────────

# Most common error messages (find the dominant failure)
kubectl logs -n production deploy/payment-service --tail=500 \
  | grep ERROR \
  | sed 's/[0-9]\{4\}-[0-9]\{2\}-[0-9]\{2\}T[^ ]* //' \
  | sort | uniq -c | sort -rn | head -20

# Stack trace extraction (for code bugs)
kubectl logs -n production deploy/payment-service --tail=500 \
  | awk '/Exception|Error:/{found=1} found{print; if(/^\s*$/)found=0}' \
  | head -100
```

---

## Part 4 — Mitigation: Stop the Pain First

### The Cardinal Rule of Mitigation

```
MITIGATE FIRST. ROOT CAUSE SECOND.

Users are failing RIGHT NOW.
Every minute of debugging instead of mitigating = more user impact.

You can always root-cause AFTER users are unblocked.
You CANNOT un-hurt users who already failed.

The acceptable exception:
  If rollback would cause MORE harm than the current issue
  (e.g., rollback would delete data) → investigate first
  But this is rare. Default is: mitigate first.
```

### The Mitigation Priority Ladder

Always try options in this order (safest/fastest first):

```
Priority 1: ROLLBACK (safest, most reliable, fastest to execute)
  When: Recent deployment is the prime suspect (almost always try this first)
  Time to execute: 2–5 minutes
  Risk: Low (returning to a known-good state)
  
  Commands:
    # Roll back to the previous deployment
    kubectl rollout undo deployment/payment-service -n production
    
    # Watch the rollback proceed
    kubectl rollout status deployment/payment-service -n production -w
    
    # Verify the old image version is deployed
    kubectl get deployment payment-service -n production \
      -o jsonpath='{.spec.template.spec.containers[0].image}'
    
    # Check error rate is dropping (watch the metric)
    watch -n 5 'curl -s "http://prometheus:9090/api/v1/query" \
      --data-urlencode "query=sum(rate(http_requests_total{status=~\"5..\"}[2m])) / sum(rate(http_requests_total[2m]))" \
      | jq ".data.result[0].value[1]"'

Priority 2: FEATURE FLAG OFF (if you have feature flags)
  When: New feature is causing errors; you have a flag to disable it
  Time to execute: < 1 minute
  Risk: Very low (reverts behavior without any deployment)
  
  # LaunchDarkly, Unleash, or homegrown flag system
  # Turn off "new-payment-validator" flag
  # Effect: immediate, no pod restart needed

Priority 3: SCALE UP (if load-related)
  When: Error rate correlates with traffic spikes, CPU/memory saturation high
  Time to execute: 1–3 minutes
  Risk: Low (more pods = more capacity)
  
  Commands:
    # Double the replica count
    kubectl scale deployment/payment-service --replicas=20 -n production
    
    # Watch pods become ready
    kubectl get pods -n production -l app=payment-service -w
    
    # Verify error rate drops after scaling
    # Watch the Grafana dashboard

Priority 4: TRAFFIC REDIRECTION (if region-specific failure)
  When: One region is failing but others are healthy
  Time to execute: 2–10 minutes
  Risk: Medium (requires DNS/load balancer change)
  
  Commands:
    # Update ingress weight to send 0% to broken region
    kubectl annotate ingress payment-service \
      nginx.ingress.kubernetes.io/canary-weight="0" \
      --overwrite -n production
    
    # Or update DNS weights via cloud provider CLI (e.g., AWS Route53)
    aws route53 change-resource-record-sets \
      --hosted-zone-id Z123456 \
      --change-batch file://route53-failover.json

Priority 5: POD RESTART (if specific pods are bad)
  When: Only 1–2 pods are failing; others are healthy
  Time to execute: 1–2 minutes
  Risk: Low (only affects bad pods; rolling restart keeps service up)
  
  Commands:
    # Delete a specific bad pod (Kubernetes auto-recreates it)
    kubectl delete pod payment-service-abc123 -n production
    
    # Or rolling restart all pods (one at a time)
    kubectl rollout restart deployment/payment-service -n production

Priority 6: DATABASE / STORAGE INTERVENTION
  When: DB is confirmed as the cause (connection pool, slow queries, disk)
  Time to execute: 5–30 minutes
  Risk: Medium-High (DB changes can cause data loss if done wrong)
  
  Commands:
    # Kill long-running / blocking queries (PostgreSQL)
    kubectl exec -n production <postgres-pod> -- psql -U postgres -c \
      "SELECT pg_terminate_backend(pid) 
       FROM pg_stat_activity 
       WHERE state = 'idle in transaction' 
       AND query_start < now() - interval '5 minutes';"
    
    # Restart connection pooler (pgBouncer)
    kubectl rollout restart deployment/pgbouncer -n production
    
    # Scale up DB read replicas (if read load is the issue)
    # (Cloud provider specific — e.g., AWS RDS console)

Priority 7: EMERGENCY DISABLE (last resort)
  When: Nothing else works; partial degradation is better than full failure
  Time to execute: 1–5 minutes
  Risk: High (deliberately breaking something)
  
  # Return maintenance page to all users
  kubectl apply -f maintenance-mode-ingress.yaml
  
  # Disable non-critical features via feature flags
  # Accept: users see a degraded but functional service
```

### Communicating During Mitigation (The Update Cadence)

Every 10 minutes during active mitigation, post an update in the incident channel:

```
Update template:
  [TIME UTC] [STATUS] [ACTION TAKEN] [CURRENT STATE] [NEXT STEP]

Examples:

14:42 UTC | MITIGATING
Action: Rolled back payment-service from v3.2.1 → v3.2.0 (started)
Current: 12/20 pods on v3.2.0, error rate dropping 20% → 10%
Next: Watch for full stabilization (~3 more minutes)

14:47 UTC | MONITORING
Action: Rollback complete — all 20 pods on v3.2.0
Current: Error rate 0.15% (near baseline 0.05%)
Next: Monitor for 15 minutes before declaring resolved

14:53 UTC | MONITORING (10 min clean)
Current: Error rate 0.06% — at baseline for 10 minutes
Next: 5 more minutes stable → declare resolved
```

---

## Part 5 — Resolve: Declaring the Incident Over

### Resolution Criteria (Do Not Declare Early)

Premature resolution declarations are embarrassing and damage trust. Meet ALL of these before declaring resolved:

```
□ Error rate at or below pre-incident baseline for 15+ continuous minutes
  (not just "looks like it's recovering" — 15 full minutes of clean data)

□ Latency (p99) at or below pre-incident baseline for 15+ minutes

□ Business metrics (orders/min, payments/min) back to expected levels
  (HTTP may look fine while business logic is still broken)

□ No new related alerts firing

□ On-call SME confirms: "I am comfortable this is resolved"

□ Stakeholders notified: status page updated to "Resolved"

Dangerous shortcut: 
  "It looks like it's recovering" → wait for the 15 minutes, don't declare early
  One false declaration → incident reopens → trust in IC damaged
```

### Resolution Announcement Template

```
✅ [SEV2 RESOLVED] payment-service error rate

RESOLVED at: 14:58 UTC
Duration:    26 minutes (14:32 – 14:58 UTC)

── Impact ───────────────────────────────────────────────────────
~20% of payment requests failed for 26 minutes
Estimated failed transactions: ~6,200
Revenue impact: ~$12,400 (estimated, finance to confirm)
No data loss confirmed.

── Root Cause (preliminary) ─────────────────────────────────────
Deployment v3.2.1 at 14:20 UTC introduced a regex change in
PaymentValidator that rejected card numbers with spaces.
ISO-format card numbers (e.g., "4111 1111 1111 1111") were rejected.

── Mitigation ───────────────────────────────────────────────────
Rolled back to v3.2.0 at 14:43 UTC.
All 20 pods on v3.2.0 by 14:47 UTC.
Error rate at baseline since 14:43 UTC.

── Next Steps ───────────────────────────────────────────────────
Post-mortem: scheduled 2026-08-02 14:00 UTC (owner: @alice)
Fix (v3.2.2): under development (owner: @charlie, due 2026-08-03)

Monitoring continues for 1 hour to confirm stability.
Channel archived. Any questions → DM @alice.
```

### After Resolution: The 60-Minute Watch

```
After declaring resolved, keep watching for 60 minutes:

T+0 (resolution):   Declare resolved, update status page
T+15 min:           Quick check: still clean?
T+30 min:           Check business metrics recovering?
T+60 min:           Final "all clear" post in incident channel
                    Channel can be archived after this

Why 60 minutes?
  Some failures return when traffic patterns shift
  GC pressure can return after initial relief
  Cascades can recur if root cause not fully addressed
  60 minutes covers one traffic peak + trough cycle
```

---

## Part 6 — Post-Mortem: Closing the Learning Loop

### Why Post-Mortems Are the Most Valuable SRE Activity

```
The incident itself cost: 26 minutes of user impact + ~$12,400 revenue
A good post-mortem costs: 3 hours of engineering time
A good post-mortem prevents: The next recurrence of this class of incident

ROI:
  If next incident of same type costs $12,400 and takes 26 minutes
  And post-mortem + action items prevent it
  Time investment: 3 hours
  Return: $12,400 saved + 26 min user impact avoided + on-call sleep saved

If you skip post-mortems: same incident recurs until someone writes the post-mortem.
```

### Blameless Culture — The Prerequisite

```
The wrong question: "Who deployed the bad code?"
The right question: "What conditions allowed bad code to reach production?"

Blame model:
  "Charlie is at fault for not testing card formats"
  Result: Charlie is defensive. Post-mortem hides facts. No systemic fix.
  Outcome: Different engineer makes the same mistake in 6 months.

Blameless model:
  "Our deployment process allowed untested code to reach production.
   Our test data doesn't represent real user input formats.
   Our risk classification didn't flag payment code as high-risk."
  Result: Three systemic fixes identified. Future engineers protected.
  Outcome: This class of incident never recurs.

The counterfactual test:
  "Would a competent, reasonable engineer have done the same thing
   given the same information available at the time?"
  If YES → system failure (the system didn't provide enough safeguards)
  If NO  → rare human failure (still worth examining the system)
```

### Post-Mortem Document — Complete Template With Annotations

```markdown
# Post-Mortem: payment-service Validation Bug
Date: 2026-07-31 | SEV: 2 | Duration: 26 min
Author: @alice (IC) | Reviewers: @charlie, @bob, @eng-manager
Status: DRAFT (due final: 2026-08-02)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## Impact

Duration: 26 minutes (14:32 – 14:58 UTC, 2026-07-31)
Users affected: All users attempting payment processing
Requests failed: ~6,200 payment requests
Revenue impact: ~$12,400 estimated
SLO budget consumed: 0.006% of monthly budget (26 min / 43,200 min budget)
Data loss: None confirmed

[ANNOTATION: Be precise. "Some users affected" is useless for prioritization.
 Specific numbers let the team decide how much engineering effort the fix deserves.]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## Detailed Timeline

All times UTC. IC: @alice | SME: @charlie | Comms: @bob

14:20  v3.2.1 deployed via automated CI/CD pipeline (all 20 pods updated)
       Change: PaymentValidator.java — regex update for card number validation
       
14:32  Alert fired: MyService_SLOFastBurn (1h + 5m windows both at 22x burn rate)
       On-call: @alice
       
14:34  @alice acknowledged PagerDuty alert (2-minute MTTA ✓ — within 5-min SLA)
       Opened #incident-2026-07-31-payment-high-error-rate
       Identified most recent deployment at 14:20 as prime suspect
       
14:35  @charlie joined. Confirmed: 100% of errors are HTTP 422 on POST /api/v1/payments
       Error message: "Invalid card number format"
       
14:36  @alice: Checked ISO 7813 — card numbers with spaces are valid format
       Hypothesis: new regex in v3.2.1 rejects valid cards with spaces
       
14:38  Rollback initiated: kubectl rollout undo deployment/payment-service -n production
       [IMPROVEMENT OPPORTUNITY: 2-minute delay between hypothesis and rollback action.
        Could have been 30 seconds. Rule change needed: confirm cause → rollback immediately.]
       
14:43  Rollback complete: all 20 pods on v3.2.0
       Error rate: 20% → 4% → 0.3%
       
14:47  Error rate 0.06% (baseline = 0.05%) — effectively at baseline
       @bob posted status page update: "Monitoring"
       
14:53  10 minutes at baseline — 5 more minutes needed before declaring
       
14:58  15 minutes at baseline confirmed. @alice declared RESOLVED.
       @bob posted status page: "Resolved at 14:58 UTC"

[ANNOTATION: Exact timestamps are essential. "Around 2:30pm" is not a timeline.
 Every action, observation, and decision must be logged with UTC time.
 The 2-minute delay at 14:36 → 14:38 is a key improvement opportunity.]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## Root Cause

Primary cause:
  PaymentValidator.java was updated in v3.2.1 with a stricter regex that
  does not allow spaces in card numbers. ISO/IEC 7813 permits spaces in
  display format. Real users copy-paste card numbers from statements,
  bank apps, and wallet apps — spaces included. The regex rejected them.

Contributing Factor 1: Test data does not reflect production input diversity
  Staging test data uses sanitized, pre-formatted card numbers (no spaces).
  Production receives raw user input with spaces and dashes.
  → No test would have caught this regression with existing test data.

Contributing Factor 2: Change risk classification was incorrect
  The change was labeled "low-risk" (regex update, no logic change).
  Payment validation code is high-risk by definition — any failure blocks revenue.
  → Risk classification process does not account for code path sensitivity.

Contributing Factor 3: Canary was skipped for "low-risk" change
  Company policy: canary required for high-risk changes.
  Developer classified this as low-risk → canary skipped.
  → If canary had run, 5% blast radius instead of 100% for 12 minutes.

5 Whys on Contributing Factor 1:
  Why did staging miss this?
    → Test data was sanitized.
  Why was test data sanitized?
    → Sanitization added for PCI compliance testing 18 months ago.
  Why weren't raw input test cases added when sanitization was added?
    → No process requires raw-format test cases for payment code.
  Why is there no such process?
    → Payment code risk guidelines were written before production input analysis existed.
  Why haven't the guidelines been updated?
    → No quarterly review process for risk guidelines.
  Root fix: Create quarterly review for risk guidelines + add raw input test fixtures.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## What Went Well

1. Alert fired within 2 minutes of incident start (fast detection) ✓
2. On-call acknowledged within 2 minutes (well within 5-min SLA) ✓
3. Recent deployment identified as prime suspect within 4 minutes ✓
4. Clear IC role: no confusion about who was making decisions ✓
5. Rollback executed and complete within 9 minutes of decision ✓
6. Status page updated before any customers asked ✓
7. Mitigation communication every 5 minutes (team was informed) ✓

[ANNOTATION: Document what worked. If you only document failures:
 - The team grows risk-averse (every change feels dangerous)
 - You might accidentally remove the things that worked when "improving the process"
 - Morale suffers ("we only ever hear about what we did wrong")]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## What Could Have Been Better

1. Rollback decision took 2 minutes after cause was confirmed
   Expected: 30 seconds
   Impact: ~2,500 extra failed payment requests
   Fix: Pre-authorize: "Payment path + recent deploy + confirmed cause → rollback immediately"

2. Canary was skipped for payment code change
   Impact: 100% of users affected instead of 5% for 12 minutes
   Fix: Enforce canary for all payment/ directory changes regardless of perceived risk size

3. No integration test with raw user card input formats
   Impact: Test suite passed while production behavior was broken
   Fix: Add test fixture library with production-realistic card number formats

4. 12-minute gap from deploy to detection
   The deployment at 14:20 went bad immediately but alert didn't fire until 14:32
   This is actually acceptable — the multi-window burn rate alert takes time to detect
   But we can add a shorter window (10m + 5m) specifically for payment endpoints
   Impact: Reduced first-window detection from 12 min to ~4 min

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## Action Items

| # | Action | Type | Owner | Due | Status |
|---|--------|------|-------|-----|--------|
| 1 | Add raw card number test fixtures (spaces, dashes, international formats) | Prevention | @charlie | 2026-08-07 | Open |
| 2 | Enforce canary for ALL changes to payment/ directory via CI gate | Prevention | @platform-sre | 2026-08-05 | Open |
| 3 | Add payment-specific fast-burn alert (10m + 5m window) | Detection | @alice | 2026-08-04 | Open |
| 4 | Update runbook: add "recent deploy → rollback without delay" as step 1 | Process | @alice | 2026-08-03 | Open |
| 5 | Audit risk classification policy: payment/ = always high-risk | Process | @eng-manager | 2026-08-14 | Open |
| 6 | Quarterly review process for payment code risk guidelines | Prevention | @eng-manager | 2026-09-01 | Open |

[ANNOTATION: Every action item MUST have:
 - Specific action (not "improve testing")
 - Type: Prevention / Detection / Mitigation / Process
 - ONE owner (not "team")
 - Due date
 Without all four fields: it does not get done. Experience shows this consistently.]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## Lessons Learned (for the team)

1. "Low-risk text change" is not a valid category in payment validation code.
   Any change to payment/ is high-risk by definition — always canary.

2. Staging test data quality is a production reliability risk.
   If staging data doesn't represent production input patterns,
   tests are false confidence.

3. The 2-minute delay between "cause confirmed" and "rollback executed" cost
   ~2,500 payment failures. Pre-authorizing mitigation for known patterns
   eliminates this delay without sacrificing safety.

4. Our detection speed (2 min to page, 2 min to ack) is working well.
   Protect this — don't reduce alert sensitivity trying to reduce noise.
```

---

## Part 7 — The Improvement Loop: Getting Better After Every Incident

### The Four Levers of MTTR Improvement

```
MTTR = Detection time + Acknowledgment time + Diagnosis time + Mitigation time

Lever 1: Reduce DETECTION time
  Current: Alert fires 12 min after incident starts (multi-window burn rate)
  Target: Alert fires < 5 min
  Method: Add shorter-window SLO alerts for high-priority endpoints
           Add synthetic tests that detect complete failure in < 2 min

Lever 2: Reduce ACKNOWLEDGMENT time
  Current: 2 min (good)
  Target: 1 min
  Method: Better PagerDuty mobile app notification settings
           On-call rotation hygiene (no one takes on-call tired)

Lever 3: Reduce DIAGNOSIS time
  Current: 4 min to identify cause (good because deploy was obvious)
  Target: < 5 min always, not just when deploy is obvious
  Method: Better runbooks with decision trees
           Dependency health panels on every dashboard
           Automatic correlation: "deployment at 14:20, incident at 14:32"

Lever 4: Reduce MITIGATION time
  Current: 5 min from decision to rollback complete
  Target: < 3 min
  Method: Pre-authorized rollback for payment path
           Automated rollback when SLO fast-burn + recent deploy detected
```

### Toil Reduction From Incidents

Every manual action repeated in multiple incidents is toil to eliminate:

```
Pattern observed:      "On-call manually runs disk cleanup script every Tuesday"
Root cause:            Log retention policy not enforced
Fix:                   Automate log rotation; alert only on abnormal growth
Time reclaimed:        30 min/week × 52 weeks = 26 hours/year

Pattern observed:      "On-call manually checks if deploy is healthy for 30 min"
Root cause:            No automated post-deploy health verification
Fix:                   Add Argo Rollouts with automatic metric-based promotion
Time reclaimed:        30 min × 3 deploys/day = 1.5 hours/day

Pattern observed:      "On-call manually restarts pgBouncer when connections exhaust"
Root cause:            Connection leak in application; leak not fixed
Fix:                   Automated remediation script + Jira ticket on trigger
                       AND fix the leak in the next sprint
Time reclaimed:        20 min × 3 per week = 1 hour/week
```

### The Weekly On-Call Review (15 Minutes)

Every Monday morning, the outgoing on-call engineer spends 15 minutes:

```
1. How many pages this week? (target: < 5 for a healthy service)

2. For each page:
   - Was it actionable?        If NO → tune or remove the alert
   - Was the runbook correct?  If NO → update it right now
   - Was the cause new?        If YES → add detection for next time
   - Was resolution > 30 min?  If YES → what would have made it faster?

3. Any toil repeated from last week?
   If YES → create a Jira ticket to automate it this sprint

4. Anything the incoming on-call should know?
   Risky deploys planned? Known issues to watch? External events (traffic spike)?
   
5. Handoff to incoming on-call
   "This week: 3 pages, all actionable, two runbooks updated. 
    Watch out for: staging DB migration happening Thursday that touches prod schema."
```

### MTTR Tracking Dashboard — The Improvement Metric

Build a dashboard that tracks incident response quality over time:

```
Panel 1: MTTA (Mean Time To Acknowledge) — rolling 30-day average
  Target: < 5 min (SEV1/2)
  Alert if: MTTA > 10 min

Panel 2: MTTR (Mean Time To Resolve) — rolling 30-day average
  Target: < 30 min (SEV2)
  Trend: Should decrease over time as runbooks improve

Panel 3: Incidents per week by severity
  Healthy pattern: Mostly SEV3/4, occasional SEV2, rare SEV1
  Unhealthy pattern: Multiple SEV1/2 per week

Panel 4: Alert precision rate (% actionable pages)
  Target: > 95%
  Alert if: drops below 80%

Panel 5: Post-mortem action item completion rate
  Target: 100% of action items completed by due date
  Alert if: items > 2 weeks overdue

Panel 6: Mean time between SEV1 incidents
  Healthy: Getting longer over time (fewer major incidents)
  Unhealthy: Flat or decreasing (same incidents recurring)
```

---

## Common Mistakes in Incident Response

| Mistake | What Happens | Fix |
|---|---|---|
| No Incident Commander assigned | Multiple people investigate same thing; no one communicates; decisions conflict | Assign IC explicitly by name within first 2 minutes |
| IC also debugging the problem | IC loses oversight of the full picture; communication stops | IC assigns investigation to SMEs; IC coordinates only |
| Debugging root cause before mitigation | Users suffer 30+ extra minutes while SRE debugs | Mitigate first (rollback), debug second |
| Premature "resolved" declaration | Incident reopens; trust in IC damaged | 15 minutes of clean metrics required before declaring |
| No runbook URL on alert | On-call spends 15 min researching what the alert means | Every alert requires runbook URL before going to production |
| Post-mortem skipped for "minor" SEV2 | Same incident recurs; no systemic improvement | Mandatory post-mortem for all SEV1/2 regardless of duration |
| Post-mortem action items with no due date | Items never completed; next incident same root cause | Every action item: owner + due date + review in next team meeting |
| Alert silenced instead of fixed | Problem recurs; silenced alert misses it | Every silence must have a companion Jira ticket to fix the root cause |
| Severity level not declared | Stakeholders don't know how to respond; wrong level of escalation | Declare severity in first message; allow IC to change later |
| Incident channel used for unrelated chat | Hard to find decisions and actions in post-mortem | All off-topic goes to DMs; channel is a structured record only |
