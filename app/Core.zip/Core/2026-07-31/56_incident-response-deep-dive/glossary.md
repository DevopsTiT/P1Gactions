# Glossary: Incident Response Deep Dive

Every term from the main guide explained for an SRE beginner.

---

**Acknowledge (PagerDuty)**
The act of an on-call engineer accepting a page — pressing the button that says "I see this, I'm handling it." Until acknowledged, PagerDuty keeps escalating (calling secondary on-call, then manager). MTTA measures how fast this happens.

**Action Item (post-mortem)**
A specific, measurable task with ONE owner and a due date that prevents the incident from recurring. Without an owner and due date, action items are wishes, not commitments.

**Alert Fatigue**
When on-call engineers receive so many noisy or false-positive alerts that they start ignoring pages. The most dangerous monitoring failure mode — engineers tune out the alerts, and a real critical incident gets missed.

**Alert Precision Rate**
The fraction of pages that required a human action. `actionable_fires / total_fires`. Target > 95%. If it drops below 80%, your alerting system is creating noise that erodes on-call trust.

**Alertmanager**
The Prometheus component that receives fired alerts, groups related ones, applies silences and inhibition rules, and routes them to the right destination (PagerDuty, Slack, email).

**Blameless Post-Mortem**
An incident review focused on WHAT failed and WHY, not WHO made a mistake. The goal is to fix systems, not punish people. Required for psychological safety — engineers only share full, honest information in a blameless environment.

**Blast Radius**
The scope of users or systems affected by a failure or change. Canary deployments limit blast radius to 5–10% of traffic during rollout.

**Bridge / War Room**
A dedicated Slack channel (or video call) opened for a specific incident where all response activity is centralized. Named `#incident-YYYY-MM-DD-service-description`. The single source of truth during the incident.

**Canary Deployment**
Releasing a new version to a small fraction of traffic (e.g., 5% of pods) before rolling out to everyone. If the canary shows worse metrics, it's rolled back with only a small fraction of users affected.

**Circuit Breaker**
A reliability pattern that automatically stops sending requests to a failing downstream service after N failures. Returns a fast error instead of waiting for a timeout. Prevents cascade failures from spreading.

**Communications Lead (Comms)**
The role responsible for keeping non-technical stakeholders (executives, customers, support team) informed during an incident. Separate from the technical responders so they can focus on fixing, not explaining.

**Contributing Factor**
A condition that made an incident possible or worse. Complex incidents have multiple contributing factors — fixing only one often doesn't prevent recurrence. The 5 Whys technique surfaces all contributing factors.

**Counterfactual Test**
A blameless post-mortem technique: "Would a competent, reasonable engineer have done the same thing given the same information?" If yes → system failure, not human failure.

**Detection Gap**
The time between when a problem starts and when an alert fires. `Customer report time - Alert fire time`. Target: negative (alert fires before customers report). A positive gap means monitoring failed to detect proactively.

**de-escalate**
To lower the severity level of an incident as the situation improves. Only done when mitigation is complete AND metrics have been stable for 15+ minutes.

**Escalation Policy (PagerDuty)**
The configuration that defines who gets paged if the primary on-call doesn't acknowledge within N minutes. Ensures no alert is silently ignored. Typical: primary → secondary → manager → VP.

**`for` Duration (Prometheus alert)**
The minimum time a condition must be continuously true before an alert fires. `for: 2m` = alert only fires if error rate is elevated for 2 straight minutes, not just a 30-second spike.

**Feature Flag**
A configuration switch that enables or disables a feature without deploying code. During an incident, turning a flag off can instantly revert behavior — faster than a rollback.

**False Positive (alert)**
An alert that fires when there is no real user-facing problem. If > 5% of pages are false positives, trust erodes and engineers start ignoring alerts.

**Incident**
An unplanned disruption or degradation of a production service that requires immediate response. Incidents are categorized by severity (SEV1–SEV4).

**Incident Channel**
The dedicated Slack channel opened for a specific incident. Everything related to the incident goes here — findings, decisions, commands run, updates. Becomes the post-mortem timeline source.

**Incident Commander (IC)**
The single person who owns the incident response from detection to resolution. Does NOT investigate or fix the problem — assigns tasks, makes mitigation decisions, controls communication. One IC only — multiple ICs create conflicting decisions.

**Inhibition Rule (Alertmanager)**
A rule that suppresses lower-severity alerts when a higher-severity alert is already firing for the same service. Prevents one incident from generating 10 separate Slack messages.

**jq**
A command-line JSON processor used to filter and extract fields from API responses. Essential for reading Prometheus query results and PagerDuty alert data from the terminal.

**kubectl**
The command-line tool for managing Kubernetes clusters. Used during incidents to rollback deployments, check pod status, read logs, and scale services.

**Mitigation**
Stopping user pain, regardless of whether the root cause is known. A rollback is mitigation. The cardinal rule: mitigate first, root cause second.

**MTTA (Mean Time To Acknowledge)**
The average time between an alert firing and an on-call engineer acknowledging it. Measures on-call responsiveness. Target: < 5 minutes for SEV1/2.

**MTTR (Mean Time To Resolve)**
The average time from incident start to full resolution. The primary SRE performance metric. Improving MTTR is the measurable outcome of better runbooks, automation, and post-mortem action items.

**Multi-window Alerting**
A burn-rate alerting technique using two time windows simultaneously (e.g., 1h + 5m must both exceed threshold). The long window filters transient spikes; the short window confirms the problem is still happening now.

**On-call**
The engineer (or rotation of engineers) responsible for responding to production alerts at any hour. PagerDuty manages on-call schedules and escalation.

**On-call Handoff**
The transition between outgoing and incoming on-call engineers. Must include: any known issues, risky deploys planned, runbook gaps found, and anything unusual to watch.

**On-call Rotation**
A schedule where on-call responsibility cycles among team members. Prevents burnout from one person always being paged. Typical: 1-week rotation.

**PagerDuty**
An incident management platform that receives alerts, manages on-call schedules, escalation policies, and incident records. Calls your phone (not just sends a notification) for critical alerts.

**Post-Mortem (aka Post-Incident Review)**
A structured document written within 48–72 hours of an incident that covers: impact, timeline, root cause, contributing factors, what went well, what could be better, and action items. The mechanism for reliability improvement.

**`predict_linear()` (Prometheus)**
A function that uses linear regression to predict where a metric will be N seconds in the future. Used for proactive disk-full alerts.

**Priority Ladder (mitigation)**
The ordered list of mitigation strategies to try, from safest/fastest to most complex: rollback → feature flag → scale up → redirect traffic → pod restart → DB intervention → emergency disable.

**PrometheusRule CRD**
A Kubernetes Custom Resource for defining alert and recording rules. The Prometheus Operator watches for these and automatically loads them — no manual Prometheus restart needed.

**Rollback**
Reverting a service to a previous known-good version. `kubectl rollout undo deployment/my-service` is the fastest and safest mitigation for deploy-caused incidents.

**Root Cause**
The underlying systemic failure that made the incident possible. Usually NOT a single thing — complex systems have multiple contributing factors. The 5 Whys technique finds it.

**Runbook**
A step-by-step document telling on-call engineers exactly what to do when a specific alert fires. Every alert must link to a runbook. Without it, engineers spend the first 15 minutes of an incident researching what the alert even means.

**Scribe**
The person who records every action taken during a SEV1 incident with exact timestamps. Produces the raw material for the post-mortem timeline. Does NOT investigate.

**SEV (Severity Level)**
A number (1–4) that classifies how serious an incident is. SEV1 = complete outage, all users, revenue stopped. SEV4 = cosmetic, no user impact, next-business-day response. Determines who gets paged and how fast.

**SLA (Service Level Agreement)**
A legal/contractual commitment to customers about reliability (e.g., "99.9% availability or you get a refund"). Breach triggers customer compensation and executive escalation.

**SLO (Service Level Objective)**
Your internal reliability target (e.g., "error rate < 0.1% per 30-day window"). Defines the error budget. SLO breach → investigation + reliability sprint.

**SLO Burn Rate**
How fast error budget is being consumed relative to the allowed rate. Burn rate 14.4x means the monthly budget will be exhausted in ~2 days. The primary trigger for critical incident alerts.

**SME (Subject Matter Expert)**
The engineer who knows the broken system deeply. During an incident they investigate, run commands, and report findings to the IC. They propose mitigation options but the IC makes the decision.

**Status Page**
A public-facing page reporting service health status. Updated during incidents to keep customers informed. Should be updated within 10 minutes of a confirmed SEV1/2 incident.

**Timeline (incident)**
A chronological log of every observation, action, and decision during an incident with exact UTC timestamps. Used as raw material for the post-mortem. The scribe maintains this during SEV1.

**Toil**
Manual, repetitive operational work that grows with service scale. Running the same cleanup script every Tuesday, watching Grafana for 30 minutes after every deploy. Google SRE target: < 50% of time on toil.

**5 Whys**
A root cause analysis technique: for any problem, ask "Why?" five times. Each answer becomes the next question. Surfaces the systemic failure underneath the surface symptom.

**`pg_isready`**
A PostgreSQL command that checks whether a database server is ready to accept connections. Used during triage to confirm whether the DB is the cause of an incident.

**`kubectl rollout undo`**
The Kubernetes command that reverts a deployment to its previous version. The fastest and safest mitigation for deploy-caused incidents. Takes 2–5 minutes for a 20-pod deployment.

**`kubectl rollout status -w`**
Watches a rollout in real time and exits when all pods are updated. Used to monitor a rollback's progress and confirm it completed.

**`deriv()` (Prometheus function)**
Calculates the per-second rate of change of a metric using linear regression. Positive = metric is increasing; negative = decreasing. Used during triage to determine if a situation is getting better or worse.

**`topk()` (Prometheus function)**
Returns the top N series by value. Used during triage to find the top 10 endpoints by error rate: `topk(10, sum(rate(errors[5m])) by (handler))`.

**Canary Rollout Percentage**
The fraction of traffic sent to the new version during a canary deployment. Typical stages: 5% → 25% → 50% → 100%. If metrics degrade at any stage, roll back with only that fraction of users affected.

**Error Budget**
The allowed amount of failure per SLO period. For 99.9% SLO over 30 days = 43.2 minutes of allowed downtime. When an incident consumes budget, the remaining budget shrinks until it recovers.

**Resolution Criteria**
The conditions that must ALL be met before declaring an incident resolved: error rate at baseline for 15+ min, latency at baseline for 15+ min, business metrics recovered, no new related alerts.

**Drift Detection**
A script or cron job that compares live Grafana dashboard JSON against the version in git and alerts if they differ. Catches unauthorized UI edits before they cause monitoring gaps.

**Monitoring Health Score**
A composite monthly score measuring monitoring maturity: alert precision, detection speed, dashboard coverage, runbook coverage, SLO coverage, and dashboard freshness.
