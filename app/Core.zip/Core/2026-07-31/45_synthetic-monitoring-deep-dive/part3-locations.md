# Part 3 — Locations: Public vs. Private, Multi-Location Strategy

---

## Why Location Matters

The location where a synthetic check runs determines what it can reach
and what its failures actually mean.

```
Public location (Dynatrace cloud node in Frankfurt):
  CAN reach:   Any publicly accessible URL on the internet
  CANNOT reach: Your internal APIs, services behind VPN, staging environments
                behind a corporate firewall
  Failure means: The service is unreachable from a user in Frankfurt

Private location (your own agent inside your network):
  CAN reach:   Internal APIs, services behind VPN, private K8s services
  CANNOT reach: Nothing on the public internet unless you configure it to
  Failure means: The service is unreachable from inside your network
```

If you only use public locations to monitor an internal service, every check
will time out — not because the service is broken, but because the public
location cannot reach it. This produces only noise.

---

## Public Locations: How They Work

Dynatrace operates synthetic agents in ~200+ geographic locations (data centers
in major cities worldwide). When you configure a public location check, Dynatrace
schedules your check on agents running in those cities.

```
Your monitor definition
      │
      ▼
Dynatrace SaaS platform schedules execution
      │
      ├──► Tokyo agent (Dynatrace-managed server in AWS Tokyo region)
      │         → Runs your check
      │         → Sends results back to Dynatrace SaaS
      │
      ├──► Frankfurt agent (Dynatrace-managed server in AWS Frankfurt region)
      │         → Runs your check
      │         → Sends results back to Dynatrace SaaS
      │
      └──► N.Virginia agent (Dynatrace-managed server in AWS us-east-1)
                → Runs your check
                → Sends results back to Dynatrace SaaS
```

You pay per execution (DEM units). You have no control over the agent hardware —
Dynatrace manages it. You just pick the location from a list.

### How to Find Location IDs

```bash
# List all available public locations with their IDs
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/locations?type=PUBLIC" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.locations[] | {entityId, name, city, country, cloudProvider}'
```

Output example:
```json
{
  "entityId": "GEOLOCATION-980DF339B0114B47",
  "name": "Tokyo",
  "city": "Tokyo",
  "country": "Japan",
  "cloudProvider": "AMAZON_EC2"
}
```

---

## Private Locations: Full Architecture

### The Problem They Solve

```
Problem:
  Your payment API lives at: https://payment.internal.company.net
  This URL is only accessible from inside your corporate VPN.
  Public Dynatrace agents in Tokyo/Frankfurt/Virginia cannot resolve this DNS name.
  Every check times out. Every check fires a false alert.

Solution:
  Deploy a Private Synthetic Location INSIDE your network.
  This agent can reach your internal services.
  It phones home to Dynatrace SaaS to receive check definitions
  and to send back results.
```

### Architecture Diagram

```
[Dynatrace SaaS]  ◄────(HTTPS outbound only)────  [Private Location Agent]
                                                         │
                                                         │ (inside your VPN/cluster)
                                                         │
                                                         ▼
                                               [payment.internal.company.net]
                                               [api.internal.company.net]
                                               [db-health.internal.company.net]
```

Key insight: The private location agent only makes **outbound** connections to
Dynatrace SaaS. You do NOT need to open inbound firewall rules to Dynatrace.
You only need: outbound HTTPS from the agent to `*.live.dynatrace.com`.

### Kubernetes Deployment for Private Location

```yaml
# infra/synthetic/private-location/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: dynatrace-synthetic
  labels:
    purpose: synthetic-monitoring
```

```yaml
# infra/synthetic/private-location/secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: dt-synthetic-token
  namespace: dynatrace-synthetic
type: Opaque
stringData:
  # Token must have: DataExport + synthetic.ReadSyntheticData + synthetic.WriteSyntheticData scopes
  DT_TOKEN: "<dynatrace-activegate-token>"
```

```yaml
# infra/synthetic/private-location/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: synthetic-private-location
  namespace: dynatrace-synthetic
spec:
  replicas: 2    # 2 replicas for availability; checks distribute across both
  selector:
    matchLabels:
      app: dt-synthetic-activegate
  template:
    metadata:
      labels:
        app: dt-synthetic-activegate
    spec:
      containers:
        - name: activegate
          image: dynatrace/synthetic-activegate:latest
          env:
            - name: DT_SERVER
              value: "https://YOUR_TENANT.live.dynatrace.com/communication"
            - name: DT_TENANT
              value: "YOUR_TENANT_ID"
            - name: DT_CAPABILITIES
              value: "synthetic"
            - name: DT_TOKEN
              valueFrom:
                secretKeyRef:
                  name: dt-synthetic-token
                  key: DT_TOKEN
          resources:
            requests:
              cpu: "500m"
              memory: "1Gi"
            limits:
              cpu: "2"
              memory: "2Gi"
          # ActiveGate needs outbound HTTPS to Dynatrace SaaS
          # No inbound ports needed
```

```yaml
# infra/synthetic/private-location/networkpolicy.yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: synthetic-activegate-egress
  namespace: dynatrace-synthetic
spec:
  podSelector:
    matchLabels:
      app: dt-synthetic-activegate
  policyTypes:
    - Egress
  egress:
    # Allow DNS resolution
    - ports:
        - port: 53
          protocol: UDP
    # Allow HTTPS to Dynatrace SaaS (for results upload)
    - ports:
        - port: 443
          protocol: TCP
    # Allow HTTP/HTTPS to monitored internal services
    - ports:
        - port: 80
          protocol: TCP
        - port: 443
          protocol: TCP
```

### Register Private Location in Terraform

```hcl
# infra/synthetic/private-location.tf

resource "dynatrace_synthetic_location" "k8s_internal" {
  type      = "PRIVATE"
  name      = "Internal K8s – Production Cluster"
  latitude  = 35.6762
  longitude = 139.6503
  
  # Availability location outage: alert if the location itself goes down
  availability_location_outage = true
}
```

After the agent registers with Dynatrace (takes 1–3 minutes after pod starts),
the location ID appears in Dynatrace. Use it in monitor configurations:

```bash
# Find your new private location ID
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/locations?type=PRIVATE" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.locations[] | {entityId, name, status}'
```

---

## Multi-Location Strategy

### Why At Least 3 Locations?

```
With 1 location:
  "Check failed from Tokyo"
  → Is the service down, or is there a network issue between Tokyo and your service?
  → You cannot tell.
  → False positive rate: HIGH.

With 3 locations:
  "Check failed from Tokyo. Frankfurt OK. N.Virginia OK."
  → Service is up (Frankfurt and Virginia reach it fine).
  → Regional network or CDN issue between Tokyo and your service.
  → False positive correctly identified.

  "Check failed from Tokyo. Frankfurt FAILED. N.Virginia FAILED."
  → All 3 locations fail. This is a global outage.
  → Alert fires immediately. No ambiguity.
```

The rule: **minimum 3 public locations for any production monitor.**

### Alert Logic Based on Locations

```
┌──────────────────────────────────────────────────────────────────┐
│ GLOBAL OUTAGE: All locations failing                             │
│   → Alert IMMEDIATELY (first occurrence)                        │
│   → SEV1 candidate                                              │
│   → Page on-call now                                            │
├──────────────────────────────────────────────────────────────────┤
│ LOCAL OUTAGE: 1 location failing                                 │
│   → Alert after 2 consecutive failures from that location       │
│   → SEV3 candidate (regional, not global)                       │
│   → Investigate CDN, routing, regional infrastructure          │
├──────────────────────────────────────────────────────────────────┤
│ FLAP: 1 location failing, then recovering, then failing again    │
│   → Alert if pattern persists for > 10 minutes                  │
│   → Intermittent connectivity issue or service instability      │
└──────────────────────────────────────────────────────────────────┘
```

### Choosing Locations Strategically

Don't just pick random locations. Match locations to:

```
1. Where your real users are
   If 60% of your users are in Japan → Tokyo is critical.
   If you have no users in Brazil → São Paulo location adds noise, not signal.

2. Where your CDN edge nodes are
   If you use CloudFront with edges in US, Europe, Asia → match those regions.

3. Where your cloud region is
   If your service runs in AWS eu-west-1 (Ireland) → Frankfurt location tests
   intra-Europe latency. N.Virginia tests transatlantic latency.

4. Regulatory/compliance requirements
   If you have EU customers and GDPR data residency requirements →
   EU location catches issues that a US-only location would miss.
```

---

## Choosing: Public vs. Private — Decision Guide

```
Use PUBLIC locations when:
  ✓ Service is publicly accessible on the internet
  ✓ You want to test from a user's geographic perspective
  ✓ You want to test CDN behavior at the edge
  ✓ You want low operational overhead (no agents to manage)

Use PRIVATE locations when:
  ✓ Service is internal (behind VPN, corporate firewall, K8s ClusterIP)
  ✓ Service has no public DNS (only resolves internally)
  ✓ You want to test from inside your own network
  ✓ You need to test staging/dev environments not exposed publicly
  ✓ Data privacy: you cannot have requests going through Dynatrace's cloud
    (e.g., requests contain sensitive PII in the body)

Use BOTH when:
  ✓ Service is publicly accessible BUT also has internal-only components
    → Public: checks the public-facing service from user perspective
    → Private: checks the same service from within your network to isolate
      whether failures are at the public edge or the internal backend
```

---

## Private Location Sizing

For production use, two replicas minimum:

```
1 replica:  Single point of failure. If the pod is restarted during a check,
            the check fails. False positive.

2 replicas: Checks distribute between both pods. One can be restarting
            while the other handles checks. No false positives from pod recycling.

3+ replicas: Appropriate when you have many monitors running frequently
             and a single pod would be a CPU bottleneck.
             Rough sizing: 1 replica per 50 concurrent checks.
```

Resource requirements:
```
Browser monitor: ~500m CPU, ~512Mi memory per concurrent execution
HTTP monitor:    ~50m CPU, ~64Mi memory per concurrent execution

For a mix of 10 HTTP + 2 browser monitors at 5-minute intervals:
  Concurrent executions at any moment: ~1 browser + ~2 HTTP
  Recommended: 2 replicas, 1 CPU / 2Gi memory each
```
