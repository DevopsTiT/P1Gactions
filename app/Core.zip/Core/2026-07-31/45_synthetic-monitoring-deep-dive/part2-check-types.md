# Part 2 — Check Types: HTTP, Browser, Multi-Step, Network

---

## The Type Decision Tree

```
What are you monitoring?
│
├── A URL / API endpoint → HTTP Monitor
│   └── Does it require authentication first? → Multi-Step HTTP Monitor
│
├── A web page that users interact with
│   (click buttons, fill forms, navigate) → Browser Monitor (Scripted)
│   └── Just "is the page up and rendered"? → Single-URL Browser Monitor
│
├── An internal service (behind VPN/firewall)
│   └── Any of the above, but using → Private Location
│
└── Raw connectivity (TCP port, ICMP ping, DNS)
    └── Network Monitor
```

---

## Type 1: HTTP Monitor (Simple API/Endpoint Check)

### What It Is

The most common synthetic check. Sends a single HTTP request (GET, POST, etc.)
and evaluates the response. No browser, no JavaScript rendering — just raw HTTP.

### When to Use It

- Health check endpoints (`/health`, `/api/status`, `/ping`)
- REST API endpoints that return JSON
- Any endpoint where you care about response code + content
- High-frequency checks (1-minute intervals are affordable for HTTP monitors)

### What It Can Assert

```
Response code:  Exact match or list (200, 201, 204)
Response body:  Contains string / Does not contain string
Response body:  JSONPath assertion ($.status == "ok")
Response time:  Total time < N milliseconds
Header value:   Specific header present with specific value
SSL cert:       Expiry > N days
```

### What It Cannot Do

```
✗ Execute JavaScript
✗ Click buttons or interact with UI
✗ Handle browser redirects involving JavaScript (meta-redirects are fine)
✗ Test flows that require session cookies from a login page
  (use Multi-Step for that)
```

### Full Configuration Example (Terraform)

```hcl
# infra/synthetic/http-health.tf

resource "dynatrace_http_monitor" "api_health" {
  name      = "API Health – /api/health"
  enabled   = true
  frequency = 5

  locations = [
    "GEOLOCATION-980DF339B0114B47",   # Tokyo
    "GEOLOCATION-9C4B318DA36C40F9",   # Frankfurt
    "GEOLOCATION-DDE0540079D14F2E",   # N. Virginia
  ]

  script {
    request {
      url         = "https://api.example.com/api/health"
      method      = "GET"
      description = "Main health endpoint"

      # Assert HTTP 200
      validation {
        type  = "httpStatusesList"
        value = "200"
      }

      # Assert body contains expected content
      validation {
        type  = "bodyContains"
        value = "\"status\":\"ok\""
      }
    }
  }

  anomaly_detection {
    outage_handling {
      global_outage       = true
      global_outage_policy {
        consecutive_runs = 1   # alert after first failure from all locations
      }
      local_outage        = true
      local_outage_policy {
        affected_locations = 1
        consecutive_runs   = 2  # alert after 2 consecutive failures from one location
      }
    }
    loading_time_thresholds {
      enabled = true
      threshold {
        type          = "TOTAL"
        value_ms      = 2000    # alert if response > 2000ms
        request_index = 0
      }
    }
  }
}
```

### What the Results Look Like

```
Check run result (each row = one execution):
  Timestamp       Location      Status    Response time   Error
  ─────────────────────────────────────────────────────────────
  14:05:00 UTC    Tokyo         SUCCESS   187ms           –
  14:05:01 UTC    Frankfurt     SUCCESS   210ms           –
  14:05:02 UTC    N.Virginia    SUCCESS   143ms           –
  14:10:00 UTC    Tokyo         FAILED    –               HTTP 503
  14:10:01 UTC    Frankfurt     SUCCESS   214ms           –
  14:10:02 UTC    N.Virginia    SUCCESS   148ms           –

Interpretation: Single location failure at 14:10 = likely regional issue,
not a global outage. Alert fires if it continues for 2 runs.
```

---

## Type 2: Multi-Step HTTP Monitor (API Chain)

### What It Is

A sequence of HTTP requests where the output of one step is used as input
to the next. The most common use case: authenticate first to get a token,
then use that token to call a protected API.

### When to Use It

- Any API flow that requires authentication
- API flows where you need to create a resource and then read it back
- Testing the complete lifecycle of a business process via API
  (create order → confirm order → check order status)

### How Dynamic Variables Work

```
Step 1: POST /oauth/token
  Body: { "client_id": "synth", "client_secret": "..." }
  Response: { "access_token": "eyJhbGc...", "expires_in": 3600 }
                                    ↑
                                    Extracted by dynamic variable
                                    named "auth_token"
                                    
Step 2: GET /api/v1/orders
  Header: Authorization: Bearer {{auth_token}}
                                    ↑
                                    Injected from previous step
  Response: { "orders": [...] }
```

### Full Configuration (Terraform)

```hcl
# infra/synthetic/multi-step-order-api.tf

resource "dynatrace_http_monitor" "order_api_flow" {
  name      = "Order API – Auth + List Orders"
  enabled   = true
  frequency = 10

  locations = [
    "GEOLOCATION-980DF339B0114B47",
    "GEOLOCATION-DDE0540079D14F2E",
  ]

  script {
    # ── STEP 1: Authenticate ──────────────────────────────────────────
    request {
      url         = "https://auth.example.com/oauth/token"
      method      = "POST"
      description = "Get JWT token"

      post_data = "client_id=synth-monitor&client_secret={{.credentials.SynthClientSecret.password}}&grant_type=client_credentials"

      headers = {
        "Content-Type" = "application/x-www-form-urlencoded"
      }

      # Extract the access_token from response body
      dynamic_variables {
        name   = "auth_token"
        source = "RESPONSE_JSON_BODY"
        path   = "$.access_token"
      }

      validation {
        type  = "httpStatusesList"
        value = "200"
      }
      validation {
        type  = "bodyContains"
        value = "access_token"
      }
    }

    # ── STEP 2: Call protected endpoint ──────────────────────────────
    request {
      url         = "https://api.example.com/v1/orders?limit=1"
      method      = "GET"
      description = "List orders (auth required)"

      headers = {
        "Authorization" = "Bearer {{auth_token}}"
        "Accept"        = "application/json"
      }

      validation {
        type  = "httpStatusesList"
        value = "200"
      }
      validation {
        type  = "bodyContains"
        value = "\"orders\""
      }
    }

    # ── STEP 3: Create a test order and verify it was created ──────────
    request {
      url         = "https://api.example.com/v1/orders"
      method      = "POST"
      description = "Create synthetic test order"

      headers = {
        "Authorization" = "Bearer {{auth_token}}"
        "Content-Type"  = "application/json"
      }

      post_data = jsonencode({
        item_id  = "SYNTHETIC-TEST-ITEM"
        quantity = 1
        test     = true          # flag to prevent real fulfillment
      })

      # Extract the new order ID
      dynamic_variables {
        name   = "order_id"
        source = "RESPONSE_JSON_BODY"
        path   = "$.orderId"
      }

      validation {
        type  = "httpStatusesList"
        value = "201"
      }
      validation {
        type  = "bodyContains"
        value = "\"orderId\""
      }
    }

    # ── STEP 4: Verify the order exists ──────────────────────────────
    request {
      url         = "https://api.example.com/v1/orders/{{order_id}}"
      method      = "GET"
      description = "Verify created order is retrievable"

      headers = {
        "Authorization" = "Bearer {{auth_token}}"
      }

      validation {
        type  = "httpStatusesList"
        value = "200"
      }
      validation {
        type  = "bodyContains"
        value = "SYNTHETIC-TEST-ITEM"
      }
    }
  }
}
```

### What Each Step's Failure Tells You

```
Step 1 fails (auth): Auth service is down or credentials are wrong
Step 2 fails (list): API itself is broken, even though auth works
Step 3 fails (create): Write path is broken (read may still work)
Step 4 fails (verify): Read path is broken after write (data pipeline issue)

Each step's failure is a different operational problem requiring
a different on-call action. This is far more diagnostic than
a single check that just says "something is broken."
```

---

## Type 3: Scripted Browser Monitor

### What It Is

Opens a real Chromium browser, executes a JavaScript script that controls
the browser step-by-step, and measures the result. Unlike HTTP monitors,
this actually renders JavaScript, loads CSS, fires DOM events, handles
redirects, and fills in forms — exactly as a real user would.

### When to Use It

- Login flows (the login form is JavaScript-heavy)
- Any flow that requires user interaction (clicking, typing, scrolling)
- Testing the full user journey: search → product page → add to cart → checkout
- Verifying that JavaScript-rendered content appears correctly
- Testing single-page applications (SPAs) where page transitions don't reload

### What Browser Monitors Capture That HTTP Monitors Miss

```
HTTP Monitor sees:          Browser Monitor also captures:
──────────────────────────────────────────────────────────────
HTTP 200 OK                 JavaScript errors in the console
Response body text          DOM elements that failed to render
Response time               Time to first contentful paint (TTFCP)
                            Time to interactive (TTI)
                            Resource loading waterfall (JS, CSS, images)
                            Screenshots at each step
                            Visual rendering completeness
```

### Why This Matters

A page can return HTTP 200 but be completely broken for users if:
- The JavaScript framework throws an error after render
- A required CSS file 404s (page loads but looks broken)
- A required API call from the page itself fails
- A form button does nothing because of a JS bug

Only a browser monitor catches these.

### Scripted Browser Monitor (JavaScript)

```javascript
// scripts/browser/login-and-search.js
// Used in Dynatrace Scripted Browser Monitor

// ── Step 1: Navigate to homepage ──────────────────────────────────
click('a[href="/login"]');
// Assertion: login page loaded
waitForElement('#login-form', { timeout: 5000 });

// ── Step 2: Log in ────────────────────────────────────────────────
type('#email-input', 'synth-user@example.com');
type('#password-input', '{{.credentials.SynthUserPassword.password}}');
click('#login-btn');

// Assertion: successfully logged in (user dashboard appeared)
waitForElement('.user-dashboard', { timeout: 8000 });
assertText('.welcome-message', 'Welcome');

// ── Step 3: Search for a product ──────────────────────────────────
type('#search-box', 'laptop');
click('#search-submit');

// Assertion: search results appeared
waitForElement('.product-card', { timeout: 5000 });
assertElementPresent('.product-card');

// ── Step 4: Add first result to cart ─────────────────────────────
click('.product-card:first-child .add-to-cart-btn');

// Assertion: cart count increased
waitForElement('.cart-badge', { timeout: 3000 });
assertText('.cart-badge', '1');

// ── Step 5: Verify cart page ──────────────────────────────────────
click('a[href="/cart"]');
waitForElement('.cart-item', { timeout: 5000 });
assertElementPresent('.cart-item');
assertText('.cart-total-label', 'Total');
```

### Terraform for Browser Monitor

```hcl
# infra/synthetic/browser-login-search.tf

resource "dynatrace_browser_monitor" "login_and_search" {
  name      = "Browser – Login and Search Flow"
  enabled   = true
  frequency = 15
  type      = "MULTI_PROTOCOL"

  locations = [
    "GEOLOCATION-980DF339B0114B47",   # Tokyo
    "GEOLOCATION-9C4B318DA36C40F9",   # Frankfurt
  ]

  script {
    type    = "javascript"
    version = "1.0"
    events  = file("${path.module}/scripts/browser/login-and-search.js")
  }

  key_performance_metrics {
    load_action_kpm = "VISUALLY_COMPLETE"
    xhr_action_kpm  = "RESPONSE_END"
  }
}
```

### Selector Strategy: `data-test` Attributes

The most common browser monitor maintenance problem: a frontend redesign
changes CSS class names, and suddenly all your selectors are broken.

**Wrong:** `click('.btn-primary.checkout-submit-v2')`
CSS class names change with every UI redesign.

**Right:** `click('[data-test="checkout-submit-btn"]')`
`data-test` attributes are added specifically for automation and should
never be removed by a UI redesign.

```html
<!-- Frontend developer adds this attribute -->
<button class="btn-primary checkout-submit-v2" data-test="checkout-submit-btn">
  Complete Purchase
</button>
```

```javascript
// Synthetic script uses the stable selector
click('[data-test="checkout-submit-btn"]');
// This works even after the CSS classes change in the next redesign
```

---

## Type 4: Network Monitor (Port / Ping / DNS)

### What It Is

The simplest type. Checks raw connectivity — can we reach this host on this port?
Does DNS resolve correctly? Does the server respond to ICMP ping?

### When to Use It

- Verifying a firewall rule allows traffic through
- Checking that a database port is reachable from a specific network
- DNS health checks (does the domain resolve to the expected IP?)
- Monitoring legacy services that have no HTTP endpoint

### What It Does NOT Tell You

```
Network monitor says: port 443 is reachable ✓
It does NOT say:
  - The application behind that port is functioning
  - The TLS certificate is valid
  - The response contains correct data
  
Use an HTTP monitor for all of the above.
Network monitor is a basic reachability check, not a health check.
```

---

## Type Comparison: Which to Use When

```
                    HTTP     Multi-Step    Browser    Network
                    Monitor  HTTP Monitor  Monitor    Monitor
─────────────────────────────────────────────────────────────
Complexity          Low      Medium        High       Lowest
Cost (DEM units)    Low      Medium        High       Lowest
Execution time      Fast     Medium        Slow       Fast
Tests auth flows    No       YES           YES        No
Tests UI rendering  No       No            YES        No
Tests JavaScript    No       No            YES        No
Can chain steps     No       YES           YES        No
Screenshots         No       No            YES        No
HAR waterfall       No       No            YES        No
Good for SLO data   YES      YES           YES        Limited
Recommended freq    5 min    10 min        15 min     5 min
```
