# Part 4 — Assertions and Thresholds: Deep Dive

---

## The Critical Difference

This is the most important conceptual distinction in synthetic monitoring:

```
ASSERTION: "Is the response CORRECT?"
           Pass/fail. Binary. No grey area.
           Example: HTTP status must be 200.
                    Body must contain '{"status":"ok"}'.
           If assertion fails → check FAILS → alert fires.

THRESHOLD: "Is the response FAST ENOUGH?"
           Violation of a threshold is a performance problem, not a correctness problem.
           Example: Total response time must be < 2000ms.
           If threshold violated → check reports SLOW → performance alert fires.
```

**Why this distinction matters:**

A check with no assertions is nearly useless. It measures speed but does not
verify correctness. A service can return HTTP 200 with an error page saying
"Something went wrong" — and a check with no body assertion will mark it as SUCCESS.

A check with assertions but no thresholds will catch complete failures but not
gradual performance degradation that slowly degrades user experience.

You need both.

---

## Assertion Types: Complete Reference

### 1. HTTP Status Code Assertion

```
Type:   httpStatusesList
Value:  "200"          (exact match)
Value:  "200,201,204"  (any of these)

What it catches:
  ✓ 503 Service Unavailable (server overloaded or crashed)
  ✓ 500 Internal Server Error (application bug)
  ✓ 404 Not Found (endpoint removed or URL wrong)
  ✓ 401/403 Unauthorized (auth broke, or credentials rotated and not updated in Dynatrace)
  ✓ 429 Too Many Requests (rate limiting is breaking the check itself)
  ✓ 504 Gateway Timeout (upstream service is slow or dead)

What it does NOT catch:
  ✗ 200 with wrong content (service returns 200 but with an error page body)
  ✗ 200 with stale data (cache is serving old data)
  
That's why body assertions are always needed alongside status assertions.
```

### 2. Response Body Contains Assertion

```
Type:   bodyContains
Value:  "\"status\":\"ok\""   (JSON string — note the escaped quotes)

What it catches:
  ✓ Server returns 200 but with an error page
  ✓ Service returns 200 but with empty/wrong body
  ✓ Maintenance page substituted for the real service
  ✓ Wrong version deployed (body structure changed)
  ✓ Database disconnected (service returns 200 but omits DB-derived fields)

Example — without body assertion:
  Service returns: HTTP 200
  Body: "<!DOCTYPE html><h1>502 Bad Gateway</h1>"
  Check result: SUCCESS ← WRONG, this is a failure

Example — with body assertion:
  Service returns: HTTP 200
  Body: "<!DOCTYPE html><h1>502 Bad Gateway</h1>"
  Assertion: bodyContains '{"status":"ok"}' → NOT FOUND
  Check result: FAILED ← CORRECT
```

### 3. Response Body NOT Contains Assertion

```
Type:   bodyNotContains
Value:  "error"
Value:  "Internal Server Error"
Value:  "maintenance mode"

Use case: when you cannot predict the exact success response,
but you know what a failure response looks like.

Example:
  A legacy service that returns HTTP 200 for both success and error cases,
  but includes "error" in the body for failures.
  
  asserting bodyNotContains "error" catches these cases.
```

### 4. JSONPath Assertion

```
Type:  jsonPathValue
Path:  $.status
Value: ok

More complex examples:
  $.data.user.active    → true     (verify field deeply nested in JSON)
  $.results[0].id       → 12345    (verify first result has expected ID)
  $.count               → 5        (verify count is exactly 5)

What it catches that bodyContains misses:
  bodyContains '"status":"ok"' would also match:
    '{"error_status": "ok", "actual_status": "error"}'
  
  JSONPath $.status == "ok" is precise:
    It ONLY checks the top-level "status" field.
    It will NOT match "error_status".
```

### 5. Response Header Assertion

```
Type:  responseHeader
Name:  Content-Type
Value: application/json

Type:  responseHeader
Name:  X-API-Version
Value: v2

What it catches:
  ✓ Service version regression (API version header changed)
  ✓ Wrong content type (was returning JSON, now returning HTML error page)
  ✓ Missing security headers (HSTS, CSP, X-Frame-Options)
  ✓ Cache control headers missing (CDN config broken)
```

### 6. Certificate Assertion (Implicit in Dynatrace HTTPS checks)

Dynatrace automatically checks SSL certificate validity on every HTTPS monitor.
You can also configure explicit cert expiry alerts:

```hcl
# In anomaly_detection block of an HTTP monitor:
anomaly_detection {
  ssl_certificate {
    enabled              = true
    expiry_days_warning  = 30   # warn 30 days before expiry
    expiry_days_critical = 14   # alert 14 days before expiry
  }
}
```

What it catches:
```
✓ Certificate expired (site becomes unreachable for all users)
✓ Certificate about to expire (early warning: 30 days)
✓ Certificate hostname mismatch (wrong cert served, e.g., after CDN migration)
✓ Self-signed cert served instead of trusted cert (CDN bypass)
✓ Certificate chain broken (intermediate cert missing)
```

---

## Threshold Types: Complete Reference

### 1. Total Response Time Threshold

```
Type:     TOTAL
Value_ms: 2000

This is the most common threshold. It measures the time from when the
synthetic agent sends the request to when it receives the complete response.

For HTTP monitors: time from request sent to last byte received
For browser monitors: time from page navigation start to page fully loaded

Recommended values:
  API health checks:    2000ms  (tight — APIs should be fast)
  API data endpoints:   5000ms  (looser — may fetch from DB)
  Browser page load:    8000ms  (users tolerate up to 8s)
  Browser full flow:    15000ms (multi-step flow can take longer)
```

### 2. Per-Step Threshold (Multi-Step Monitors)

```
Type:          TOTAL
Request_index: 0     ← applies to step 1
Value_ms:      1000  ← 1 second for the auth step

Type:          TOTAL
Request_index: 1     ← applies to step 2
Value_ms:      3000  ← 3 seconds for the data fetch step

This lets you set different expectations for each step.
The auth token request should be very fast (< 1s).
A complex data aggregation endpoint might legitimately take 3s.
```

---

## How Many Assertions Is Enough?

**Minimum for any HTTP check:**
```
1. HTTP status assertion (e.g., status = 200)
2. Body contains assertion (e.g., body contains '{"status":"ok"}')
3. Response time threshold (e.g., total < 2000ms)
```

**For a business-critical API (payment, order creation):**
```
1. HTTP status assertion
2. Body contains specific field (e.g., '"orderId"')
3. JSONPath assertion for a specific value (e.g., $.status == "created")
4. Response time threshold (tight — 500ms)
5. Certificate expiry check
```

**For a browser login flow:**
```
Step 1 (login page loads):
  - waitForElement('#login-form')           ← DOM assertion
  - assertText('h1', 'Sign In')             ← text assertion
  
Step 2 (login succeeds):
  - waitForElement('.user-dashboard')       ← DOM assertion (login worked)
  - assertText('.welcome-message', 'Welcome') ← text assertion
  
Step 3 (search results appear):
  - waitForElement('.product-card')         ← DOM assertion
  - assertElementPresent('.product-card')   ← count assertion (at least 1)
```

---

## Common Assertion Mistakes

### Mistake 1: Asserting on Dynamic Values

```
WRONG: assertText('.order-id', '12345')
   This fails every time the order ID changes (which is always).

RIGHT: assertElementPresent('.order-id')
       or: assertText('.order-confirmation', 'Order confirmed')
   Assert on stable structural content, not dynamic values.
```

### Mistake 2: Overly Strict Body Assertion

```
WRONG: bodyContains '{"status":"ok","version":"1.0","timestamp":"2026-07-31T14:05:00Z"}'
   This fails every second because the timestamp changes.

RIGHT: bodyContains '"status":"ok"'
   Assert on the stable key piece of content.
```

### Mistake 3: No Assertion on the Actual Business Outcome

```
WRONG: Only asserting HTTP 200

RIGHT: Also asserting that the response contains evidence the business
       logic executed:
       - '"orderId"'   (order was created)
       - '"userId"'    (user was authenticated)
       - '"balance"'   (account was retrieved from DB, not served from stale cache)
```

### Mistake 4: Threshold Too Tight for a Database-Backed Endpoint

```
WRONG: Threshold 200ms on an endpoint that queries 3 database tables
   This fires false positives on every slightly loaded check.

RIGHT: Baseline the actual p95 of the endpoint, then set threshold to 2–3×
       the baseline p95.
       
       If current p95 = 320ms → set threshold at 800ms
       
       This catches real performance degradation without constant noise.
```

### Mistake 5: Threshold Too Loose

```
WRONG: Threshold 30000ms (30 seconds) on a health endpoint
   By the time the threshold fires, users have been timing out for minutes.
   The threshold provides no advance warning.

RIGHT: For health endpoints, set thresholds aggressively tight.
       A health endpoint should respond in < 500ms. 
       Set threshold at 1000–2000ms.
```

---

## Calibrating Thresholds from Real Data

Don't guess. Use existing performance data to set thresholds correctly.

```bash
# Get p95 latency for the last 7 days from Dynatrace
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=ext:app.payment.latency:percentile(95)\
&resolution=1h&from=now-7d" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '[.resolution.data[].values[]] | sort | .[(length * 0.95 | floor)]'

# Set your threshold at 2× the 7-day p95:
# If p95 = 380ms → set threshold at 760ms (round to 800ms)
# If p95 = 1200ms → set threshold at 2400ms (round to 2500ms)
```

This gives you a threshold that:
- Never fires during normal operation (baseline is well below it)
- Always fires when there is real performance degradation
- Self-adjusts as you recalibrate every quarter
