# Part 5 — Alert Policies and Notification Routing: Deep Dive

---

## The Problem Without Alert Policies

Synthetic checks generate raw pass/fail data every N minutes.
Without alert policies, you have two bad choices:
1. Alert on every single failure → constant noise, alert fatigue, on-call ignores alerts
2. Never alert → failures accumulate silently, users are impacted for hours

Alert policies sit between raw check results and your pager.
They define the rules: when is a failure serious enough to wake someone up?

```
Check results (raw)
      │
      ▼
Alert Policy (filter/delay logic)
      │
      ├─► Is this a global outage? → Alert immediately
      ├─► Is this a local blip?    → Wait for 2nd failure, then alert
      ├─► Is this performance?     → Wait 5 minutes, then alert
      └─► Is it resolved?          → Send resolution notification
      │
      ▼
Notification channels
  └─► PagerDuty / Slack / Email
```

---

## The Two Axes of Alert Policy Design

### Axis 1: What triggers the alert?

```
AVAILABILITY ALERTS (the check fails = service is down/broken)
  These are urgent. Users are getting errors RIGHT NOW.
  Treat these like a potential SEV1/2.
  
PERFORMANCE ALERTS (the check passes but is slow)
  These are less urgent. Users are experiencing degradation but not failure.
  A 10-second page load is bad, but users can still complete their task.
  Treat these like a SEV3 — important, but not a 3 AM wake-up.
```

### Axis 2: How many failures before alerting?

```
IMMEDIATE (0 delay, 1 failure):
  Best for: Global outages (all locations fail simultaneously)
  Why: If all 3 locations fail at the same time, it is almost certainly
       a real outage, not a network blip.

CONSECUTIVE FAILURES (2-3 from same location):
  Best for: Local/single-location failures
  Why: A single location can fail due to a transient network issue
       between that city and your service. Requiring 2 consecutive
       failures eliminates most false positives.

DELAYED (N minutes):
  Best for: Performance degradation, non-critical monitors
  Why: A brief latency spike should not wake someone up.
       If it persists for 5+ minutes, it is a real problem.
```

---

## Dynatrace Alert Configuration: Full Breakdown

### Global Outage vs. Local Outage

```hcl
# infra/alerting/synthetic-alert-policy.tf

resource "dynatrace_http_monitor" "checkout_api" {
  # ... (monitor config) ...

  anomaly_detection {
    outage_handling {

      # GLOBAL OUTAGE: ALL locations are failing
      # → Alert after the FIRST failure (no delay)
      # → This is a definitive outage
      global_outage = true
      global_outage_policy {
        consecutive_runs = 1   # alert after 1 run where all locations fail
      }

      # LOCAL OUTAGE: Only SOME locations are failing
      # → Wait for 2 consecutive failures from the same location
      # → Filters transient network issues
      local_outage = true
      local_outage_policy {
        affected_locations = 1   # number of locations failing to trigger local alert
        consecutive_runs   = 2   # how many consecutive failures needed
      }
    }

    # PERFORMANCE ALERT: Response time exceeded threshold
    loading_time_thresholds {
      enabled = true
      threshold {
        type          = "TOTAL"
        value_ms      = 2000
        request_index = 0
      }
    }
  }
}
```

### Alerting Profile: Global Routing Rules

Dynatrace's Alerting Profile is a second layer of filtering that sits between
"a problem was detected" and "a notification is sent."

```hcl
# infra/alerting/synthetic-alerting-profile.tf

resource "dynatrace_alerting" "synthetic_critical" {
  name = "Synthetic Monitor – Critical Alerts"

  rules {
    # AVAILABILITY problems: route immediately, no delay
    rule {
      delay_in_minutes = 0
      include_mode     = "INCLUDE_ALL"
      severity_level   = "AVAILABILITY"
      tag_filter {
        include_mode = "INCLUDE_ALL"
      }
    }

    # PERFORMANCE problems: only alert if sustained for 5+ minutes
    rule {
      delay_in_minutes = 5
      include_mode     = "INCLUDE_ALL"
      severity_level   = "PERFORMANCE"
      tag_filter {
        include_mode = "INCLUDE_ALL"
      }
    }
  }
}
```

---

## Notification Channels: PagerDuty, Slack, Email

### Channel 1: PagerDuty (for on-call paging)

PagerDuty is the most important notification channel because it:
- Phones the on-call engineer if they don't acknowledge
- Escalates to a secondary if the primary doesn't respond
- Manages the on-call rotation schedule

```hcl
# infra/alerting/pagerduty-notification.tf

resource "dynatrace_notification" "pagerduty_synthetic" {
  name             = "PagerDuty – Synthetic Failures"
  alerting_profile = dynatrace_alerting.synthetic_critical.id
  type             = "PAGERDUTY"
  active           = true

  pagerduty {
    service_api_key = var.pagerduty_integration_key
    account         = "your-org"
    service_name    = "Synthetic Monitors"
    # When Dynatrace creates a PagerDuty incident, it sets:
    #   - Title: the monitor name + failure details
    #   - Severity: mapped from Dynatrace severity
    #   - Details: check results, location, error message
  }
}
```

**PagerDuty Urgency Mapping:**

```
Dynatrace AVAILABILITY alert → PagerDuty HIGH urgency → phone call + SMS
Dynatrace PERFORMANCE alert  → PagerDuty LOW urgency  → app notification only
```

### Channel 2: Slack (for team visibility)

Even when PagerDuty handles the paging, Slack provides visibility for
the whole team — not just the on-call.

```hcl
# infra/alerting/slack-notification.tf

resource "dynatrace_notification" "slack_synthetic" {
  name             = "Slack – Synthetic Monitor Status"
  alerting_profile = dynatrace_alerting.synthetic_critical.id
  type             = "SLACK"
  active           = true

  slack {
    url     = var.slack_webhook_url    # from Slack "Incoming Webhooks" app
    channel = "#platform-alerts"
    message = "Synthetic monitor: {ProblemTitle}\nStatus: {State}\nMonitor: {ImpactedEntities}"
  }
}
```

**What good Slack notifications look like:**

```
🔴 [OPEN] Synthetic Monitor: Checkout API – /api/checkout
   Status: AVAILABILITY – FAILED from Tokyo (2 consecutive runs)
   First detected: 14:03:12 UTC
   Dashboard: https://...

🟢 [RESOLVED] Synthetic Monitor: Checkout API – /api/checkout
   Status: AVAILABILITY – recovered
   Resolved at: 14:35:44 UTC (duration: 32 minutes)
```

### Channel 3: Email (for audit/management visibility)

Not useful for immediate response (email is too slow). But useful for:
- Weekly digest of alert activity
- Notifying managers of SEV1 incidents automatically
- Audit trail

```hcl
resource "dynatrace_notification" "email_synthetic_sev1" {
  name             = "Email – SEV1 Synthetic Failures"
  alerting_profile = dynatrace_alerting.synthetic_critical.id
  type             = "EMAIL"
  active           = true

  email {
    to      = ["sre-leads@example.com", "engineering-director@example.com"]
    subject = "ALERT: Synthetic Monitor Failure – {ProblemTitle}"
    body    = "Monitor: {ProblemTitle}\nSeverity: {ProblemSeverity}\nImpact: {ImpactedEntities}\nURL: {ProblemURL}"
  }
}
```

---

## Alert Noise Tuning: The Most Overlooked Part

An alert policy that fires too often is as bad as no alert policy.
When on-call engineers see 50 alerts per week, they start ignoring them all —
including the real ones. This is "alert fatigue."

### The Alert Quality Metric

```
Alert accuracy = (actionable alerts / total alerts) × 100

Target: > 80% of alerts should require a human action.

Signs of poor alert quality:
  - Same alert fires and auto-resolves within 5 minutes repeatedly
    → Threshold too tight, or check is flapping on a transient issue
    → Fix: require 2 consecutive failures before alerting
  
  - Alert fires but the service is actually fine when you investigate
    → False positive from a network issue between the agent and service
    → Fix: increase required consecutive_runs or add more locations
  
  - Alert fires for a known, accepted degradation
    → Fix: tag the monitor with a suppression tag during maintenance windows
```

### Maintenance Window Configuration

During planned maintenance, suppress synthetic alerts to avoid noise:

```bash
# Pause a monitor via Dynatrace API (suppress during maintenance)
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/pause" \
  -H "Authorization: Api-Token $DT_API_TOKEN"

# Resume after maintenance
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/resume" \
  -H "Authorization: Api-Token $DT_API_TOKEN"
```

Or use Dynatrace Maintenance Windows (suppresses ALL alerts for a time window):

```hcl
# infra/alerting/maintenance-window.tf

resource "dynatrace_maintenance_window" "weekly_maintenance" {
  name        = "Weekly maintenance – Sunday 02:00–04:00 UTC"
  description = "Planned maintenance window"
  enabled     = true

  schedule {
    type       = "WEEKLY"
    start      = "2026-08-04T02:00:00"  # first occurrence
    duration   = 120                     # 120 minutes
    recurrence_range_start = "2026-08-04"
    recurrence_range_end   = "2027-08-04"
  }

  scope {
    entities = ["SYNTHETIC_TEST-xxxx"]  # specific monitor IDs
    # Or leave empty to suppress all monitors
  }

  suppress_synthetics = true
  suppress_alerts     = true
}
```

---

## Alert Policy for Different Check Types

Not all monitors deserve the same alert urgency:

```
Monitor Type          Alert Policy          Why
──────────────────────────────────────────────────────────────────────
Payment checkout      Global outage: 1 run  Revenue-critical. Any failure matters.
  browser flow        Local outage: 2 runs
                      Performance: 5 min

Health endpoint       Global outage: 1 run  Primary reliability signal.
  /api/health         Local outage: 2 runs
                      Performance: 0 min (tight)

Data endpoint         Global outage: 2 runs Slightly more tolerance for transient issues.
  /api/orders         Local outage: 3 runs
                      Performance: 5 min

Non-critical feature  Global outage: 3 runs Lower priority. SEV3 at most.
  /api/export-csv     Local outage: 3 runs
                      Performance: 10 min

Certificate expiry    Dedicated cert alert  Not time-sensitive.
  SSL check           30 days warning       Schedule weekly check, not 5-minute.
                      14 days critical
```

---

## Resolution Notification

When a synthetic monitor recovers, Dynatrace sends a resolution notification.
This is as important as the opening alert:

```
Without resolution notifications:
  → On-call doesn't know when to stop investigating
  → Team doesn't know the incident is over
  → Stakeholders aren't told service is restored

With resolution notifications:
  → PagerDuty incident auto-resolves when Dynatrace sends the "OK" event
  → Slack posts a "RESOLVED" message in the alert channel
  → On-call can formally declare incident resolved
```

Configure resolution notifications the same way as opening notifications —
they use the same Notification resource in Terraform and are sent automatically
by Dynatrace when the monitor state transitions from FAILURE to SUCCESS.
