# Part 7 — SLO Integration: Using Synthetic Data as the Source of Truth

---

## Why Synthetic Data Makes the Best SLO Source

SLOs measure reliability. For a reliability measurement to be meaningful,
it must be:

```
1. CONSISTENT      — same test every time (not varies by user behavior)
2. CONTINUOUS      — runs 24/7, not just when users happen to visit
3. DETERMINISTIC   — clear pass/fail, not "sometimes it was slow"
4. GEOGRAPHIC      — from multiple locations, not just one
5. INDEPENDENT     — not influenced by what the user was doing
```

Synthetic checks satisfy ALL five requirements.
Real User Monitoring (RUM) satisfies none of them reliably:
- Different users, devices, browsers, network speeds
- No data at 3 AM if no users are active
- Noisy: user experience varies even when the service is healthy

This is why the most reliable SLO data comes from synthetic monitors.

---

## The Availability SLO Formula

```
Availability % = (successful check runs / total check runs) × 100

For a single monitor running every 5 minutes from 3 locations:
  Total runs per day:    3 locations × (60/5 × 24) = 3 × 288 = 864 runs
  Total runs per month:  864 × 30 = 25,920 runs

If 32 minutes of failure (the DB pool incident):
  Failing runs:  3 locations × (32/5 ≈ 7 runs) = ~21 failed runs
  
  Availability = (25,920 - 21) / 25,920 × 100 = 99.919%
```

This is a far more precise measurement than "we were down for about 30 minutes"
— it accounts for the exact number of affected check cycles.

---

## Dynatrace SLO v2 Configuration (Terraform)

### Availability SLO from Synthetic Monitor

```hcl
# infra/slo/payment-api-availability.tf

resource "dynatrace_slo_v2" "payment_api_availability" {
  name        = "Payment API – Availability"
  enabled     = true
  description = "99.9% of synthetic checks must pass over 30 days"

  evaluation_type = "AGGREGATE"

  # The metric expression:
  # Numerator:   count of successful synthetic check executions
  # Denominator: count of all synthetic check executions
  metric_expression = <<-EOT
    100*(builtin:synthetic.http.availability.location.total:filter(
      and(
        eq(dt.entity.synthetic_test,SYNTHETIC_TEST-xxxx)
      )
    ))/(builtin:synthetic.http.availability.location.total:filter(
      and(
        eq(dt.entity.synthetic_test,SYNTHETIC_TEST-xxxx)
      )
    ))
  EOT

  target    = 99.9    # SLO target: 99.9%
  warning   = 99.95   # Warning threshold: alert when approaching target
  timeframe = "-30d"  # Evaluated over rolling 30 days

  filter = "type(\"SYNTHETIC_TEST\"),entityName(\"Payment API – /api/health\")"
}
```

### Latency/Performance SLO from Synthetic Monitor

```hcl
# infra/slo/payment-api-latency.tf

resource "dynatrace_slo_v2" "payment_api_latency" {
  name        = "Payment API – Latency"
  enabled     = true
  description = "95% of synthetic checks must complete within 500ms"

  evaluation_type = "AGGREGATE"

  # Count of checks that completed within 500ms
  # divided by total checks
  metric_expression = <<-EOT
    100*(builtin:synthetic.http.duration.geo:filter(
      and(
        eq(dt.entity.synthetic_test,SYNTHETIC_TEST-xxxx),
        le(value,500)
      )
    ))/(builtin:synthetic.http.duration.geo:filter(
      and(
        eq(dt.entity.synthetic_test,SYNTHETIC_TEST-xxxx)
      )
    ))
  EOT

  target    = 95.0
  warning   = 97.0
  timeframe = "-30d"

  filter = "type(\"SYNTHETIC_TEST\"),entityName(\"Payment API – /api/health\")"
}
```

### Multi-Step Monitor SLO (Business Flow Success Rate)

```hcl
# infra/slo/checkout-flow-slo.tf

resource "dynatrace_slo_v2" "checkout_flow_success" {
  name        = "Checkout Flow – End-to-End Success Rate"
  enabled     = true
  description = "99.5% of synthetic checkout flows must complete without error"

  evaluation_type = "AGGREGATE"

  metric_expression = <<-EOT
    100*(builtin:synthetic.browser.success:filter(
      and(
        eq(dt.entity.synthetic_test,SYNTHETIC_TEST-yyyy)
      )
    ))/(builtin:synthetic.browser.total:filter(
      and(
        eq(dt.entity.synthetic_test,SYNTHETIC_TEST-yyyy)
      )
    ))
  EOT

  target    = 99.5
  warning   = 99.8
  timeframe = "-30d"

  filter = "type(\"SYNTHETIC_TEST\"),entityName(\"Browser – Checkout Flow E2E\")"
}
```

---

## Mapping Monitors to SLOs: Which Checks Feed Which SLO

Not every synthetic check should feed an SLO. Design the mapping deliberately:

```
SLO: Payment Service Availability (99.9%)
  └── Feeds from: "Payment API – /api/health" HTTP monitor
                  (every 5 min, 3 locations)

SLO: Payment Service Latency (95% < 500ms)
  └── Feeds from: Same monitor's duration metric

SLO: Checkout Flow E2E Success (99.5%)
  └── Feeds from: "Browser – Checkout Flow" browser monitor
                  (every 15 min, 2 locations)

SLO: Order API Success (99.9%)
  └── Feeds from: "Order API – Auth + Create" multi-step monitor
                  (every 10 min, 2 locations)

NOT feeding an SLO:
  - Dev/staging environment monitors (not production reliability)
  - Certificate expiry monitors (binary state, not availability %)
  - Experimental feature monitors (not part of the service contract)
```

---

## Error Budget Calculation with Synthetic Data

After the 32-minute DB pool incident with a 99.9% SLO:

```python
# Error budget arithmetic

slo_target = 99.9            # 99.9%
window_days = 30
check_interval_min = 5       # checks every 5 minutes
locations = 3

# Total check runs in the window
checks_per_day = (24 * 60 / check_interval_min) * locations
total_checks = checks_per_day * window_days
# = 288 checks/day × 3 locations × 30 days = 25,920

# Allowed failures (error budget)
allowed_failure_pct = 1 - (slo_target / 100)   # = 0.001
allowed_failures = total_checks * allowed_failure_pct
# = 25,920 × 0.001 = 25.92 ≈ 26 failed checks = 43.2 minutes of downtime

# Actual failures from the 32-minute incident
incident_duration_min = 32
failed_checks_per_location = incident_duration_min / check_interval_min  # ~7 runs
total_failed_checks = failed_checks_per_location * locations              # ~21 runs

# Budget consumed
budget_consumed_pct = (total_failed_checks / allowed_failures) * 100
# = (21 / 25.92) × 100 = 81%

# Budget remaining
budget_remaining_checks = allowed_failures - total_failed_checks   # ~5 checks
budget_remaining_minutes = budget_remaining_checks * check_interval_min / locations
# = 5 × 5 / 3 = 8.3 minutes
```

After the incident: only ~8 minutes of error budget remains.
Any further failure this month will breach the SLO.

---

## SLO Dashboard: Connecting Synthetic to Reliability Story

In Dynatrace, create a dashboard that tells the complete SLO story:

```
Dashboard layout:

Row 1: SLO Status Summary
  [Payment API Availability: 99.93% ⚠️ (target: 99.9%)]
  [Checkout Flow Success: 99.96% ✅ (target: 99.5%)]
  [Order API Success: 99.98% ✅ (target: 99.9%)]

Row 2: Error Budget Gauges
  [Payment API: 74% consumed ⚠️]   [Checkout: 8% consumed ✅]   [Order API: 4% consumed ✅]

Row 3: Synthetic Check Results (last 24h)
  [Payment API check timeline — green/red bars per check run]
  [Checkout flow timeline]
  [Response time trend lines]

Row 4: Location Heatmap
  [World map: green = all locations OK, red = location failing]

Row 5: Recent Incidents
  [List of failed check windows with duration and affected locations]
```

This dashboard is shown at the monthly SLO review to demonstrate:
- Are we meeting our reliability commitments?
- Where is the error budget going?
- Which geographic regions are experiencing issues?

---

## The Feedback Loop: Synthetic → SLO → Action Items → Improved Synthetic

```
1. Synthetic check reveals an issue we didn't know to test for
   (e.g., during an incident, we discover the auth flow is not tested)
        │
        ▼
2. Add a new synthetic check for the auth flow
        │
        ▼
3. Auth flow now has a synthetic check → feeds into SLO data
        │
        ▼
4. SLO review reveals auth flow availability is only 99.7% (below 99.9% target)
        │
        ▼
5. Engineering investigates → finds auth service has intermittent failures
   that were invisible before the synthetic monitor existed
        │
        ▼
6. Engineering fixes the auth service
        │
        ▼
7. Auth flow SLO now at 99.95% → target met
        │
        ▼
8. Coverage is better. Reliability improved. Error budget is protected.
```

Synthetic monitoring coverage should grow after every incident.
If an incident reveals a blind spot (no check existed for the broken flow),
adding that check is always a postmortem action item.
