# Part 6 — Credentials and Secrets Management: Deep Dive

---

## Why This Is a Security-Critical Topic

Synthetic monitors frequently need to authenticate:
- Login flows need a username and password
- API monitors need an OAuth client secret or API key
- Multi-step monitors need a bearer token or session cookie

The naive approach — putting credentials directly in the monitor script
or Terraform config — is a serious security vulnerability.

```
WRONG (secrets in script):
  type('#password-input', 'MySecr3tPassword123!');
  post_data = "client_secret=MySecr3tPassword123!&..."
  
What goes wrong:
  - The password appears in Dynatrace UI logs
  - The password appears in screenshots taken by browser monitors
  - The password is in your Terraform state file (often stored in S3/GCS)
  - The password is in your git repository history
  - Anyone with Dynatrace UI access can read the monitor script
```

Dynatrace's Credential Vault is specifically designed to solve this.

---

## Credential Vault: How It Works

```
┌────────────────────────────────────────────────────────────────┐
│  Dynatrace Credential Vault                                    │
│                                                                │
│  Name: "Synthetic Test User Password"                          │
│  Username: synth-user@example.com                              │
│  Password: [ENCRYPTED — never shown in UI after saving]        │
│                                                                │
│  The vault stores credentials encrypted at rest.               │
│  Scripts reference them by name, never by value.               │
└────────────────────────────────────────────────────────────────┘
         │
         ▼ (at execution time)
┌────────────────────────────────────────────────────────────────┐
│  Synthetic Agent (runs your check)                             │
│                                                                │
│  Script contains: {{.credentials.SynthUser.password}}          │
│  Agent resolves: → [actual password value from vault]          │
│  The resolved value is NEVER logged or stored in results       │
└────────────────────────────────────────────────────────────────┘
```

The credential value is injected at execution time by the agent.
It does not appear in:
- The monitor script stored in Dynatrace
- Check result logs
- Screenshots
- HAR files
- Terraform state (only the vault name is in Terraform, not the value)

---

## Creating Credentials (Terraform)

```hcl
# infra/synthetic/credentials.tf

# USERNAME + PASSWORD credential
resource "dynatrace_credentials" "synth_user" {
  name     = "Synthetic Test User – Payment Flow"
  type     = "USERNAME_PASSWORD"
  scope    = "SYNTHETIC"

  username = "synth-user@example.com"
  password = var.synth_user_password    # from TF_VAR_synth_user_password env var
                                         # NEVER hard-code this value
}

# TOKEN credential (for API key / Bearer token)
resource "dynatrace_credentials" "synth_api_key" {
  name  = "Synthetic API Key – Internal API"
  type  = "TOKEN"
  scope = "SYNTHETIC"

  token = var.synth_api_token
}

# CERTIFICATE credential (for mutual TLS)
resource "dynatrace_credentials" "synth_client_cert" {
  name        = "Synthetic Client Certificate"
  type        = "CERTIFICATE"
  scope       = "SYNTHETIC"
  certificate = var.synth_client_cert_base64  # base64-encoded PEM
  password    = var.synth_cert_password
}
```

```hcl
# infra/synthetic/variables.tf

variable "synth_user_password" {
  type        = string
  sensitive   = true  # marks this as sensitive in Terraform output
  description = "Password for the synthetic test user account"
}

variable "synth_api_token" {
  type        = string
  sensitive   = true
  description = "API token for synthetic internal API checks"
}
```

**How to pass secrets at apply time (never in the .tf file):**

```bash
# Option 1: Environment variable (CI/CD pipelines)
export TF_VAR_synth_user_password="$(vault kv get -field=password secret/synth/user)"
terraform apply

# Option 2: Terraform Cloud / Atlantis variable store (preferred)
# Store variables as "sensitive" in Terraform Cloud workspace settings

# Option 3: AWS Secrets Manager → Terraform data source
data "aws_secretsmanager_secret_version" "synth_pass" {
  secret_id = "synthetic/user_password"
}
variable "synth_user_password" {
  default = data.aws_secretsmanager_secret_version.synth_pass.secret_string
}
```

---

## Referencing Credentials in Scripts

### In HTTP Monitor (Terraform)

```hcl
# infra/synthetic/multi-step-auth.tf

resource "dynatrace_http_monitor" "api_auth_flow" {
  script {
    request {
      url    = "https://auth.example.com/oauth/token"
      method = "POST"

      # Reference the credential by the name set in dynatrace_credentials resource
      post_data = "client_id=synth&client_secret={{.credentials.Synthetic API Key – Internal API.token}}&grant_type=client_credentials"
    }
  }
}
```

**Credential reference syntax:**

```
{{.credentials.<credential-name>.<field>}}

Where <field> is:
  .username   → for USERNAME_PASSWORD type
  .password   → for USERNAME_PASSWORD or CERTIFICATE type
  .token      → for TOKEN type
  .certificate → for CERTIFICATE type
```

**Important: the name is EXACT, including spaces and special characters.**
```
"Synthetic Test User – Payment Flow"  ← correct (exact match)
"synthetic test user – payment flow"  ← WRONG (case-sensitive)
"Synthetic Test User"                 ← WRONG (must be exact name)
```

### In Browser Monitor (JavaScript)

```javascript
// Reference syntax in Dynatrace browser monitor scripts

// Password field
type('#password-input', '{{.credentials.Synthetic Test User – Payment Flow.password}}');

// API key in a header
// (browser monitors can inject headers in some contexts)
// More commonly: use the credentials in the HTTP pre-steps

// For flows requiring the credential in a form POST
// (the value is injected at runtime, never appears in the script log)
type('#api-key-field', '{{.credentials.Synthetic API Key – Internal API.token}}');
```

---

## Credential Rotation Strategy

Synthetic credentials MUST be rotated regularly. A synthetic user account
with a password that never changes is a security risk.

### Rotation Schedule

```
Credential type        Rotation frequency    Justification
─────────────────────────────────────────────────────────────────
Password (human)       90 days               Matches org password policy
Password (service)     180 days              Lower risk, harder to rotate
API token              90 days               Token compromise is invisible
Client certificate     1 year                Before cert expiry
OAuth client secret    180 days              Match org policy
```

### Rotation Process

```bash
# Step 1: Generate the new credential in your identity system
# (create new service account password, rotate API key, etc.)
NEW_SYNTH_PASSWORD="$(openssl rand -base64 32)"

# Step 2: Update the Dynatrace Credential Vault via Terraform
terraform apply \
  -var="synth_user_password=$NEW_SYNTH_PASSWORD" \
  -target=dynatrace_credentials.synth_user

# Step 3: Verify the synthetic check still passes after rotation
# (it should pass within 1-2 check cycles after the vault updates)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-10m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.results[-1] | {status, timestamp}'

# Step 4: If the check fails after rotation:
#   → The new credential may not have been provisioned in the target system yet
#   → The credential reference syntax may be wrong
#   → Revert to old credential in the vault and investigate
```

### Rotation Automation

Fully automate credential rotation using a CI/CD pipeline:

```yaml
# .github/workflows/rotate-synthetic-creds.yml

name: Rotate Synthetic Credentials

on:
  schedule:
    - cron: '0 2 1 */3 *'   # quarterly, 2 AM on the 1st of the month

jobs:
  rotate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Generate new credential
        id: gen
        run: |
          NEW_PASS=$(openssl rand -base64 32)
          echo "::add-mask::$NEW_PASS"     # mask from CI logs
          echo "new_pass=$NEW_PASS" >> $GITHUB_OUTPUT

      - name: Update service account password in IdP
        run: |
          # Update the actual service account in your identity provider
          # (LDAP, Okta, Auth0 management API, etc.)
          ./scripts/update-service-account-password.sh "${{ steps.gen.outputs.new_pass }}"

      - name: Update Dynatrace Credential Vault
        run: |
          terraform apply \
            -auto-approve \
            -var="synth_user_password=${{ steps.gen.outputs.new_pass }}" \
            -target=dynatrace_credentials.synth_user
        env:
          TF_VAR_synth_user_password: ${{ steps.gen.outputs.new_pass }}

      - name: Wait for checks to run with new credential
        run: sleep 300   # wait 5 minutes for next check cycle

      - name: Verify synthetic checks passing
        run: |
          STATUS=$(curl -s "https://$DT_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/$MONITOR_ID/results?from=now-6m" \
            -H "Authorization: Api-Token $DT_API_TOKEN" \
            | jq -r '.results[-1].status')
          if [ "$STATUS" != "SUCCESS" ]; then
            echo "ERROR: Synthetic check failed after rotation"
            exit 1
          fi
```

---

## The Synthetic Test User Account

The synthetic monitor should use a **dedicated test account**, not a real user's account.

```
WRONG: Using a real employee's account for synthetic checks
  Problems:
  - Employee leaves → account disabled → all synthetic checks fail immediately
  - Employee changes password → synthetic checks fail immediately
  - Employee account has 2FA → synthetic cannot log in with just username/password
  - Violates least-privilege principle (employee account has more access than needed)

RIGHT: Create a dedicated synthetic service account
  Properties of a good synthetic account:
  - Username clearly identifies it: synth-monitor@example.com
  - Has ONLY the permissions needed for the synthetic tests
  - Is excluded from 2FA (or uses a non-interactive 2FA method)
  - Has a never-expire policy (or auto-rotation as above)
  - Is monitored: alert if the account is disabled or locked
  - Is documented in a runbook: "This account is used by synthetic monitors.
    Do not disable without first updating the Dynatrace Credential Vault."
```

---

## Security Best Practices Summary

```
✓ Store ALL credentials in Dynatrace Credential Vault (never in scripts)
✓ Use dedicated service accounts (not personal accounts)
✓ Give synthetic accounts minimum permissions (only what the test needs)
✓ Never log credential values (Dynatrace handles this — don't bypass it)
✓ Rotate credentials on schedule (automated via CI/CD is best)
✓ Verify checks still pass immediately after rotation
✓ Document each synthetic account: what it's for, where credentials live
✓ Alert on synthetic account lockout (synthetic checks failing + auth errors)
✓ Store Terraform sensitive variables in Terraform Cloud or secrets manager
✗ Never hard-code credentials in .tf files, scripts, or YAML
✗ Never commit credentials to git (use pre-commit hooks to prevent this)
✗ Never use a personal account for synthetic tests
```
