# Part 10 — Common Mistakes: Deep Dive

---

## Why a Full "Mistakes" Section?

Synthetic monitoring looks simple on the surface: point at a URL, check for 200.
But production synthetic monitoring that is actually useful, accurate, and maintainable
is significantly harder. The mistakes below are drawn from real operational experience
and each one has caused either false positives, missed outages, security incidents,
or monitoring maintenance nightmares.

Understanding these mistakes in depth is the difference between synthetic monitoring
that is a genuine operational tool and synthetic monitoring that is theater.

---

## Mistake 1: Only 1 Synthetic Location

### What Happens

```
Monitor runs from: Tokyo only
Service experiences: network hiccup between Tokyo and your CDN edge

Tokyo check: FAILED (network blip)
→ PagerDuty fires
→ On-call investigates
→ Service is completely healthy
→ Alert was a false positive caused by network between Tokyo and your service

If you had Frankfurt and N.Virginia:
Tokyo FAILED + Frankfurt OK + N.Virginia OK
→ Regional network issue, not a real outage
→ Alert policy requires all 3 to fail before paging on-call
→ No false positive
```

### The Fix

Minimum 3 public locations for any production monitor.
Configure `local_outage_policy` to require 2 consecutive failures before alerting.
Configure `global_outage_policy` to alert immediately only when ALL locations fail.

### Why Teams Make This Mistake

"Adding locations costs more DEM units." This is true. But the cost of
false positives — waking up an on-call engineer at 3 AM for nothing,
repeatedly — is much higher in human terms, and leads to alert fatigue
where real incidents are also ignored.

---

## Mistake 2: No Body Assertions

### What Happens

```
Monitor config:
  URL: https://api.example.com/api/health
  Assertion: HTTP status == 200
  (no body assertion)

Failure scenario 1 (CDN error page):
  Your CDN returns HTTP 200 with body: "<!DOCTYPE html><h1>Gateway Error</h1>"
  Monitor result: SUCCESS ← WRONG

Failure scenario 2 (maintenance mode):
  Your nginx returns HTTP 200 with: "Service under maintenance. Back soon."
  Monitor result: SUCCESS ← WRONG

Failure scenario 3 (empty response):
  Application returns HTTP 200 with body: ""
  Monitor result: SUCCESS ← WRONG

Failure scenario 4 (database disconnected):
  Application returns HTTP 200 with: '{"status":"ok","db_connected":false}'
  If you only assert status==200: SUCCESS ← WRONG
  If you also assert bodyContains '"db_connected":true': FAILED ← CORRECT
```

### The Fix

Always add at least one body assertion. For JSON APIs, assert on the specific
field that confirms the business logic executed correctly — not just any field.

```
Minimum: bodyContains '"status":"ok"'
Better:  JSON path assertion: $.status == "ok"
Best:    JSON path assertions on multiple fields that confirm:
          - The service is up ($.status == "ok")
          - The database is connected ($.db_connected == true)
          - The response is fresh ($.cache_age < 300)
```

---

## Mistake 3: Alert on First Failure (No Consecutive-Run Requirement)

### What Happens

```
Alert policy: global_outage consecutive_runs = 1

Network blip between a Dynatrace cloud agent and your service at 14:05:
  14:05 → Check fails from Tokyo (network blip)
  14:05 → PagerDuty fires IMMEDIATELY
  14:06 → On-call wakes up, checks dashboards
  14:06 → Service is completely fine
  14:10 → Check passes again (blip resolved)
  14:10 → PagerDuty auto-resolves

This happened because a 200ms network hiccup between Dynatrace's Tokyo
agent and your CDN edge triggered an immediate page.

Per month, this can happen 10–20 times from different locations.
On-call engineers stop taking synthetic alerts seriously.
When a real outage happens, response is delayed.
```

### The Fix

```hcl
# For local outages (single-location failures): require 2 consecutive failures
local_outage_policy {
  affected_locations = 1
  consecutive_runs   = 2   # must fail 2 runs in a row (10 min with 5-min schedule)
}

# For global outages (all locations fail): 1 failure is usually OK
# because the probability of ALL locations having simultaneous network blips is very low
global_outage_policy {
  consecutive_runs = 1
}
```

**The trade-off:** Requiring 2 consecutive failures means detection is delayed
by one check interval (e.g., 5 minutes). This is acceptable for most services.
For ultra-critical services (payments), you may want 1 for global outage
but 2 for local.

---

## Mistake 4: Hard-Coded Credentials in Scripts

Already covered in Part 6, but worth restating as a mistake pattern:

```
# WRONG — credential in script
post_data = "client_secret=MySuperSecretPassword123!"

# WRONG — credential in Terraform variable (not sensitive)
variable "synth_secret" {
  default = "MySuperSecretPassword123!"   # visible in terraform.tfstate
}

# WRONG — credential in git repository
synth_password = "MySuperSecretPassword123!"  # visible to anyone with repo access

# RIGHT — credential in Dynatrace Credential Vault
post_data = "client_secret={{.credentials.Synthetic API Key.token}}"
```

**Specific risks of hard-coded credentials:**
1. Terraform state files are often stored in S3 — anyone with S3 read access sees it
2. Git history is forever — even if you delete the file, `git log -p` shows it
3. Dynatrace UI shows the full script — anyone with Dynatrace viewer access sees it
4. Screenshots from browser monitors may capture form values — credential appears in screenshot

---

## Mistake 5: No Alert Calibration After Initial Setup

### What Happens

You set up a synthetic monitor in January. The service's baseline response time
is 200ms. You set the threshold to 2000ms (10× baseline — a safe buffer).

By August, after several infrastructure upgrades, the service's baseline is now 80ms.
But your threshold is still 2000ms.

Now, a real performance regression causes p99 to jump to 1800ms — a 22× increase
from the current baseline, and users are experiencing 2-second page loads.
But the threshold is 2000ms, so no alert fires.

The synthetic monitor is not detecting a real performance problem.

### The Fix

```bash
# Quarterly: recalibrate thresholds based on current baseline
# Get the current p95 response time for this monitor over the last 30 days
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=builtin:synthetic.http.duration.geo:percentile(95)\
&resolution=1d&from=now-30d" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '[.resolution.data[].values[]] | add/length | "Current p95: \(.) ms"'

# If current p95 is 80ms, set threshold at 2-3× p95 = 160–240ms → round to 300ms
# Update the Terraform configuration and apply
```

---

## Mistake 6: Synthetic Checks Pass, Real Users Fail (Wrong Coverage)

### What Happens

The synthetic monitor tests `/api/health` and it passes.
But the real user failure is on `/api/checkout` — a completely different endpoint.

Or: the synthetic monitor uses a simple GET request, but real users trigger
a complex POST with a specific payload that hits a different code path.

Or: the synthetic monitor always runs as the "synthetic test user" with
a freshly-created account, but the real failure only affects accounts
older than 30 days (and the synthetic user is always new).

### The Fix

```
Coverage principle: synthetic monitors should test the SAME code paths
that real users exercise.

Mapping real user flows to synthetic checks:
  Real user: visits homepage → searches → clicks product → adds to cart → pays
  
  Synthetic should cover:
    Check 1: homepage loads (HTTP monitor)
    Check 2: search API returns results (HTTP monitor)
    Check 3: product detail API (HTTP monitor)
    Check 4: add-to-cart API (HTTP monitor)
    Check 5: checkout flow end-to-end (Browser monitor)

NOT just:
    Check 1: /api/health passes
```

**After every incident that wasn't caught by synthetic:**
> "Why didn't our synthetic monitors detect this? What check would have caught it?
>  Add that check as a postmortem action item."

---

## Mistake 7: Monitoring Too Frequently for Browser Checks

### What Happens

Browser monitors are expensive in DEM units. A 1-minute interval on a
browser monitor can consume 50–100× more budget than an HTTP monitor
at the same interval.

Teams set browser monitors to 1-minute intervals "to be safe"
and then discover their monthly Dynatrace bill tripled.

### The Fix

```
HTTP monitor:    1–5 minute intervals are cost-effective
Browser monitor: 15 minutes is usually sufficient
Multi-step API:  5–10 minutes is a good default

The detection window with 15-minute browser checks:
  If the checkout flow breaks at 14:00, you detect it by 14:15 at the latest.
  That's 15 minutes of user impact before detection.
  
  For most business flows, this is acceptable.
  If checkout breaks, users will call support within 15 minutes anyway.
  The 15-minute synthetic detection window is often comparable to real user reporting time.

Exception: if checkout is your primary revenue path and 15 minutes of
undetected downtime is unacceptable → use 5-minute browser checks
but understand the cost implication.
```

---

## Mistake 8: Selector Fragility in Browser Monitors

### What Happens

```javascript
// Browser monitor script using CSS class selectors
click('.btn.btn-primary.checkout-v2-submit');
```

Frontend team does a redesign in the next sprint.
The button now has class `.btn.btn-success.checkout-v3-submit`.
The browser monitor script fails with "element not found."
On-call gets paged at 3 AM. Service is fine. The script is just broken.

This is 100% a false positive caused by brittle selectors.

### The Fix

```javascript
// Use data-test attributes — stable across UI redesigns
click('[data-test="checkout-submit"]');

// Or use text content — also usually stable
click('button:text("Complete Purchase")');

// NOT CSS classes — these change with every redesign
click('.btn-primary.checkout-submit-v3');  // WRONG
```

The frontend team must add `data-test` attributes to all interactive elements
that are used in synthetic scripts. This is a team agreement, enforced in
the PR review process:

```
PR review checklist item:
  [ ] If this PR removes or renames an interactive element,
      check if it is used in any synthetic browser monitor script.
      Update the synthetic script in the same PR.
```

---

## Mistake 9: No Cleanup of Test Data Created by Synthetic Monitors

### What Happens

Your multi-step monitor creates a test order every 10 minutes:
```
10 min interval × 6 checks/hour × 24 hours × 30 days = 4,320 test orders/month
```

These test orders:
- Pollute your database with fake data
- Distort business metrics ("we had 50,000 orders this month!" — actually 4,320 were synthetic)
- May trigger fulfillment workflows for fake orders
- May generate real emails/SMS to the synthetic test user

### The Fix

```
Option 1: Test flag in the payload
  Include a flag in every synthetic request: {"test": true}
  Implement in the service:
  - Orders with test=true are stored in a separate "synthetic" schema or partition
  - They do NOT trigger fulfillment, notifications, or metric aggregations
  - They are auto-deleted after 24 hours

Option 2: Cleanup step in the monitor
  Step 3 of the multi-step monitor: DELETE /api/orders/{{order_id}}
  The monitor creates the order and immediately deletes it.
  
  Risk: if step 3 fails, test data accumulates. Schedule a separate cleanup job.

Option 3: Dedicated synthetic environment
  Route synthetic checks to a staging or shadow environment
  that has its own database.
  Test data is isolated from production.
  Risk: staging may not perfectly match production behavior.
```

---

## Mistake 10: Not Verifying Monitors After Deploy or Config Change

### What Happens

You update a synthetic monitor configuration (new assertion, different URL, new location).
You save it and move on. But you made a typo in the assertion string.
The monitor now runs but always fails — even when the service is healthy.
On-call is paged for every check execution.

Or: you updated the assertion to a stricter value. Now the monitor fails intermittently
under load (real performance degradation that the old assertion didn't catch).
You can't tell if alerts are real or false.

### The Fix

```bash
# After any monitor configuration change:
# 1. Run an on-demand check immediately
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/execute" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"locations": ["GEOLOCATION-980DF339B0114B47"]}'

# 2. Wait for results
sleep 30

# 3. Verify the check passed
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-2m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.results[-1] | {status, errorCode, errorMessage}'
# Expected: { "status": "SUCCESS" }

# 4. If it fails: check the error message before declaring an incident
```

**Make this a Terraform validation step:**

```bash
# In your CI/CD pipeline, after terraform apply for synthetic changes:
# Run verification script
./scripts/verify-synthetic-monitors.sh

# verify-synthetic-monitors.sh:
for MONITOR_ID in $(terraform output -json synthetic_monitor_ids | jq -r '.[]'); do
  # Trigger on-demand run
  curl -X POST ".../monitors/$MONITOR_ID/execute" ...
  sleep 30
  STATUS=$(curl -s ".../monitors/$MONITOR_ID/results?from=now-2m" ... | jq -r '.results[-1].status')
  if [ "$STATUS" != "SUCCESS" ]; then
    echo "FAILED: Monitor $MONITOR_ID failed after Terraform apply"
    exit 1
  fi
done
```
