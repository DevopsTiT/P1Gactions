# 45 — Synthetic Monitoring Deep Dive: Glossary

Every term from all 10 parts, explained for an SRE beginner. One entry per term.

---

**Synthetic Monitoring**
A technique where a robot (an automated script) regularly impersonates a user to test whether a service is working. Runs on a schedule regardless of whether real users are present. The opposite of Real-User Monitoring (RUM), which only captures data from actual users.

**Real-User Monitoring (RUM)**
Collects performance and error data from actual users as they use your application. Reactive — you only see data when users visit. Does not work during off-peak hours. Noisy because user behavior, device, and network vary. Synthetic complements it with proactive, consistent checks.

**Proactive Monitoring**
Detecting problems BEFORE users report them. Synthetic monitoring is proactive because it runs on a schedule — it finds failures even at 3 AM when no real users are active. Contrast with reactive monitoring, which only fires when users are already experiencing problems.

**MTTD (Mean Time to Detect)**
The average time between when a problem starts and when an alert fires. Synthetic monitoring dramatically reduces MTTD — from "when a user files a support ticket" (30–90 minutes) to "when the next scheduled check fails" (1–15 minutes).

**HTTP Monitor**
The simplest synthetic check type. Sends a single HTTP request (GET, POST, etc.) to a URL and evaluates the response code and body. No browser, no JavaScript rendering. Fast, cheap, and good for API health checks.

**Browser Monitor (Scripted)**
A synthetic check that opens a real Chromium browser, navigates a website step-by-step, and interacts with the UI (clicks buttons, fills forms). Catches JavaScript errors, rendering failures, and UI-breaking bugs that HTTP monitors miss. More expensive and slower than HTTP monitors.

**Multi-Step HTTP Monitor**
A sequence of HTTP requests where the output of one step (like a JWT token from a login call) feeds into the next step as input. Used to test API flows that require authentication before calling the main endpoint.

**Network Monitor**
The simplest synthetic check type. Checks raw connectivity: "Can we reach this host on this TCP port?" or "Does this DNS name resolve?" Does not check HTTP response content or application behavior — just basic reachability.

**Synthetic Agent**
The program that actually executes synthetic checks. Receives check definitions from the Dynatrace SaaS platform, runs them, and sends results back. Can be a Dynatrace-managed agent (public location) or your own agent (private location).

**Public Location**
A synthetic agent managed by Dynatrace and running in their cloud infrastructure in cities worldwide (Tokyo, Frankfurt, N.Virginia, etc.). Can only reach publicly accessible services. You pay per execution in DEM units.

**Private Location**
A synthetic agent that YOU deploy inside your own network (e.g., on Kubernetes). Can reach internal services not exposed to the internet. The agent makes outbound HTTPS connections to Dynatrace SaaS to receive instructions and send results — no inbound ports needed.

**ActiveGate**
Dynatrace's on-premises agent that bridges your private network to the Dynatrace SaaS platform. A private synthetic location runs on top of an ActiveGate. Also used for routing OneAgent data from isolated network segments.

**DEM Unit (Digital Experience Monitoring Unit)**
Dynatrace's billing unit for synthetic check executions. Browser monitors consume more DEM units per run than HTTP monitors. Private location checks consume fewer than public. Running checks more frequently = more DEM units consumed.

**Check Frequency / Schedule**
How often a synthetic check runs. Common values: 1 minute (very expensive, for critical revenue paths), 5 minutes (standard for APIs), 15 minutes (standard for browser flows). More frequent = faster detection but higher cost.

**Assertion**
A binary pass/fail rule that a synthetic check must satisfy. "HTTP status must be 200." "Body must contain 'status: ok'." If an assertion fails, the check is marked FAILED and an alert fires. Without assertions, a check only measures speed — it does not verify correctness.

**Threshold**
A performance limit for a synthetic check. "Response time must be under 2000ms." If the threshold is exceeded, a performance alert fires (less urgent than an availability alert). Thresholds catch gradual degradation that assertions alone would miss.

**HTTPStatusesList Assertion**
A Dynatrace assertion type that checks the HTTP response status code. Can match an exact code ("200") or a list ("200,201,204"). The most basic assertion — always include it but never use it alone.

**bodyContains Assertion**
A Dynatrace assertion type that checks whether the HTTP response body contains a specific string. Catches cases where the server returns HTTP 200 but with an error page body. Essential for every API check.

**JSONPath Assertion**
An assertion that checks a specific field in a JSON response using JSONPath syntax. More precise than bodyContains — it targets exactly the field you want to validate, avoiding false positives from partial string matches.

**Dynamic Variable (in multi-step monitors)**
A value extracted from one HTTP response and injected into the next request in a multi-step monitor. Example: extract the JWT access_token from the /oauth/token response, then inject it as the Authorization header in the next request.

**Total Response Time Threshold**
The measurement of total elapsed time from when the synthetic agent sends a request to when it receives the complete response. Set in milliseconds. The most common threshold type.

**Global Outage**
In Dynatrace: when ALL configured locations for a monitor fail simultaneously. Indicates a real service outage rather than a regional network issue. Best practice: alert immediately on a global outage.

**Local Outage**
In Dynatrace: when only SOME locations fail. May indicate a regional CDN/routing issue rather than a full service outage. Best practice: require 2 consecutive failures from the same location before alerting, to avoid false positives from transient network blips.

**Consecutive Runs**
A Dynatrace alert policy setting that requires a check to fail N times in a row before firing an alert. Setting this to 2 eliminates most false positives from transient network issues. Setting it to 1 means any failure immediately pages on-call.

**Flapping Check**
A synthetic check that alternates between FAILED and SUCCESS repeatedly. Almost always indicates a false positive (threshold too tight, unstable network path, or overly strict assertion on a dynamic value). Causes alert fatigue. Must be investigated and tuned.

**Alert Fatigue**
The state where on-call engineers begin ignoring alerts because too many are false positives or low-priority. When alert fatigue sets in, real incidents are also ignored. Caused by: thresholds too tight, no consecutive-run requirements, assertions on dynamic values.

**Alerting Profile**
A Dynatrace filter that sits between "a problem was detected" and "a notification is sent." Defines which severity levels trigger notifications, with what delay. Allows different routing for availability alerts (page immediately) vs performance alerts (5-minute delay).

**PagerDuty**
An incident management platform. Dynatrace sends alert notifications to PagerDuty, which routes them to the on-call engineer via phone call, SMS, or push notification. Manages escalation if the on-call doesn't respond within the configured timeout.

**Credential Vault**
Dynatrace's encrypted storage for synthetic test credentials (usernames, passwords, API tokens). Scripts reference credentials by name — the actual values are never visible in the UI, logs, or screenshots. Prevents secrets from appearing in Terraform state or git history.

**Synthetic Service Account**
A dedicated non-human account created specifically for synthetic monitors to use for authentication. Should have minimum permissions (only what the test needs), be excluded from 2FA, and be clearly named (e.g., synth-monitor@example.com) to avoid accidental disabling.

**Credential Reference Syntax**
The placeholder syntax used in Dynatrace scripts to inject credential values at runtime: `{{.credentials.<name>.<field>}}`. The value is substituted by the agent during execution and never appears in logs or stored results.

**Sensitive Variable (Terraform)**
A Terraform variable marked with `sensitive = true`. Its value is masked in `terraform plan` and `terraform apply` output and in the state file. Required for any variable containing a password, token, or other secret.

**TF_VAR_ prefix**
The environment variable naming convention that Terraform uses to receive variable values from the shell environment. `TF_VAR_synth_user_password=MySecret terraform apply` sets the variable `synth_user_password` to "MySecret" without it appearing in the .tf file.

**SLI (Service Level Indicator)**
The raw measurement an SLO is based on. For synthetic monitoring: `(successful check runs / total check runs) × 100`. A good SLI measures what users actually experience, not infrastructure metrics.

**SLO (Service Level Objective)**
An internal reliability target. Example: "99.9% of synthetic checks must pass over 30 days." Drives error budget calculations and the negotiation between feature velocity and reliability investment. Synthetic data is ideal for SLOs because it is consistent and continuous.

**Error Budget**
The allowed amount of unreliability under an SLO. 99.9% availability = 43.2 minutes of allowed downtime per 30 days. Consumed by incidents. When exhausted, risky feature work should pause until the budget recovers.

**Dynatrace SLO v2**
The current generation of Dynatrace SLO resource in Terraform (`dynatrace_slo_v2`). Evaluates reliability metrics over a rolling time window and exposes the result as a compliance percentage. Can be fed by synthetic monitor availability metrics or application performance metrics.

**k6**
An open-source load and performance testing tool (from Grafana Labs) that also supports synthetic monitoring. Tests are written in JavaScript. Can run a script once (synthetic check), on a schedule via k6 Cloud, or with many virtual users (load test). Same script serves both purposes.

**k6 Browser**
A k6 module that wraps the Playwright browser automation API. Allows running full browser synthetic tests (click buttons, fill forms, assert DOM state) inside a k6 test script. Used for browser-based synthetic checks in CI/CD pipelines.

**Playwright**
A browser automation library from Microsoft. Controls real Chromium, Firefox, or WebKit browsers programmatically via JavaScript/TypeScript. k6 Browser wraps Playwright under the hood. The most popular choice for modern browser-based synthetic testing.

**k6 Cloud**
Grafana's hosted service for running k6 scripts on a schedule from cloud locations globally. Stores results and provides dashboards. Similar to Dynatrace Synthetic but uses your k6 codebase instead of UI-configured monitors.

**`data-test` Attribute**
An HTML attribute added specifically for automated testing and synthetic monitoring: `<button data-test="checkout-submit">`. Using `data-test` selectors in scripts (instead of CSS class names) prevents scripts from breaking when the UI is redesigned. Best practice.

**Selector Fragility**
The problem where browser monitor scripts break because CSS class names or element IDs changed in a UI redesign. Fixed by using stable selectors (`data-test` attributes, text content) instead of CSS classes that change with every styling update.

**HAR File (HTTP Archive)**
A JSON recording of all network requests made during a browser session — URLs, timings, request/response headers and bodies, sizes. Browser monitors generate HAR files for each run. Used to diagnose which specific resource caused a slow page load or failure.

**Waterfall Chart**
A visual timeline of all network requests in a page load, stacked left-to-right in time order. Each bar shows how long one resource (HTML, JS, CSS, image, API call) took to load. Immediately shows which resource is the bottleneck during a slow page investigation.

**On-Demand Check**
Manually triggering a synthetic check to run immediately, outside of its normal schedule. Used after a configuration change (to verify it works), during incident investigation (to get fresh data), or after a maintenance window (to confirm service is healthy).

**Maintenance Window**
A configured time period during which synthetic alerts are suppressed. Used during planned maintenance to prevent false positives. Always use Dynatrace Maintenance Windows (which auto-resume) rather than manually pausing monitors (which require manual resumption).

**False Positive**
An alert that fires when the service is actually healthy. Caused by: checking from only one location, thresholds too tight, no consecutive-run requirement, or selector fragility in browser scripts. Each false positive erodes trust in the alerting system and contributes to alert fatigue.

**Coverage Gap**
A service, endpoint, or user flow that has no synthetic check. If it fails, no synthetic alert fires. Every incident reveals coverage gaps — adding synthetic coverage for the broken path is always a postmortem action item.

**Test Data Pollution**
The accumulation of fake data created by synthetic monitors (e.g., test orders, test users) in a production database. Distorts business metrics and may trigger real workflows (email, fulfillment). Fixed by using test flags, cleanup steps, or a shadow environment.

**`kubectl apply -f`**
Kubernetes command that creates or updates resources defined in a YAML file. Idempotent — running it multiple times is safe. Used to deploy the private location namespace, secret, deployment, and network policy.

**NetworkPolicy (Kubernetes)**
A Kubernetes resource that controls which pods can talk to which other pods or external endpoints. For the synthetic ActiveGate: allows outbound HTTPS to Dynatrace SaaS and to monitored internal services, while blocking all other traffic. Principle of least privilege for network.

**`jq`**
A command-line JSON processor. Used throughout these commands to parse and filter JSON responses from the Dynatrace API, extracting specific fields (monitor status, location IDs, error messages). Essential for working with APIs from the terminal.

**`openssl rand -base64 24`**
A shell command that generates 24 bytes of cryptographically random data, base64-encoded (produces ~32 printable characters). Used for generating new passwords during credential rotation. Produces a strong, unpredictable password every time.
