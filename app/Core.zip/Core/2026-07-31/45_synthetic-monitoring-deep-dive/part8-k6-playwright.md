# Part 8 — k6 and Playwright: Code-First Synthetic Monitoring

---

## Why Code-First Matters

Dynatrace's built-in synthetic monitors (HTTP, Browser) are configured in a UI
or via Terraform. They live in Dynatrace, not in your codebase.

This creates problems:
- Monitor scripts are not version-controlled in git
- Monitor changes are not reviewed in pull requests
- Developers cannot run synthetic tests locally
- CI/CD pipeline cannot run synthetic tests on every PR
- When service contracts change, the monitors are not updated alongside the code

Code-first synthetic monitoring solves all of this:
monitors are JavaScript/TypeScript files in your repository, reviewed in PRs,
run locally by developers, and executed in CI/CD.

---

## k6: What It Is and What It Does

k6 is an open-source load and performance testing tool that also supports
synthetic monitoring. You write tests in JavaScript. k6 runs them as:
- A one-shot synthetic check (run now, check the result)
- A scheduled synthetic check (k6 Cloud runs it every N minutes from cloud locations)
- A load test (run with 100 virtual users for 10 minutes)

```
Same test script can do BOTH:
  k6 run tests/synthetic/checkout.js          ← 1 VU, 1 run = synthetic check
  k6 run --vus 100 --duration 5m tests/...    ← 100 VUs, 5 min = load test
```

This is a major advantage: the same script that validates your API daily
can be used to load-test it before a product launch.

---

## k6 HTTP Synthetic Test (Full Example)

```javascript
// tests/synthetic/api-health.js

import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate, Trend } from 'k6/metrics';

// Custom metrics
const errorRate = new Rate('errors');
const responseDuration = new Trend('response_duration');

// Options: configure this as a synthetic (1 VU, run once)
export const options = {
  vus: 1,
  iterations: 1,

  // Thresholds: the test FAILS if these are violated
  thresholds: {
    http_req_duration: ['p(95)<2000'],   // 95% of requests under 2s
    errors:            ['rate<0.01'],    // < 1% error rate
    checks:            ['rate>0.99'],    // > 99% of checks pass
  },
};

export default function () {
  // ── Step 1: Health check ──────────────────────────────────────────
  const healthRes = http.get('https://api.example.com/api/health', {
    headers: { 'Accept': 'application/json' },
    timeout: '5s',
  });

  const healthOk = check(healthRes, {
    'health endpoint: status 200':    (r) => r.status === 200,
    'health endpoint: body has status ok': (r) => r.json('status') === 'ok',
    'health endpoint: response < 2s': (r) => r.timings.duration < 2000,
  });

  errorRate.add(!healthOk);
  responseDuration.add(healthRes.timings.duration);

  // ── Step 2: Get auth token ────────────────────────────────────────
  const authRes = http.post(
    'https://auth.example.com/oauth/token',
    JSON.stringify({
      client_id:     'synthetic-monitor',
      client_secret: __ENV.SYNTH_CLIENT_SECRET,   // from environment variable
      grant_type:    'client_credentials',
    }),
    {
      headers: { 'Content-Type': 'application/json' },
      timeout: '5s',
    }
  );

  check(authRes, {
    'auth endpoint: status 200':     (r) => r.status === 200,
    'auth endpoint: has access_token': (r) => r.json('access_token') !== undefined,
  });

  const token = authRes.json('access_token');

  // ── Step 3: Call protected endpoint ──────────────────────────────
  const ordersRes = http.get(
    'https://api.example.com/v1/orders?limit=1',
    {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept':        'application/json',
      },
      timeout: '5s',
    }
  );

  check(ordersRes, {
    'orders endpoint: status 200':    (r) => r.status === 200,
    'orders endpoint: has orders key': (r) => Array.isArray(r.json('orders')),
  });

  // Small pause between steps (simulates realistic user behavior)
  sleep(0.5);
}
```

**Run locally:**
```bash
# Install k6
brew install k6

# Run the test
SYNTH_CLIENT_SECRET="your-secret" k6 run tests/synthetic/api-health.js
```

**Output:**
```
✓ health endpoint: status 200
✓ health endpoint: body has status ok
✓ health endpoint: response < 2s
✓ auth endpoint: status 200
✓ auth endpoint: has access_token
✓ orders endpoint: status 200
✓ orders endpoint: has orders key

checks.........................: 100.00% ✓ 7 ✗ 0
http_req_duration..............: avg=187ms min=143ms max=312ms
```

---

## k6 Browser Synthetic Test (Full Example)

k6 Browser wraps the Playwright API, giving you a full browser inside k6:

```javascript
// tests/synthetic/checkout-browser.js

import { browser } from 'k6/experimental/browser';
import { check } from 'k6';

export const options = {
  scenarios: {
    checkout_flow: {
      executor: 'constant-vus',
      exec:     'checkoutTest',
      vus:      1,
      duration: '60s',
    },
  },
  thresholds: {
    checks: ['rate>0.99'],
  },
};

export async function checkoutTest() {
  const context = browser.newContext({
    // Simulate a realistic browser
    viewport: { width: 1280, height: 720 },
    userAgent: 'Mozilla/5.0 (synthetic-monitor)',
  });

  const page = context.newPage();

  try {
    // ── Step 1: Navigate to homepage ─────────────────────────────────
    await page.goto('https://www.example.com', { waitUntil: 'networkidle' });

    check(page, {
      'homepage: title correct': (p) => p.title() === 'Example – Shop Online',
      'homepage: hero section visible': async (p) => {
        return await p.locator('[data-test="hero-section"]').isVisible();
      },
    });

    // ── Step 2: Navigate to login ─────────────────────────────────────
    await page.locator('[data-test="login-nav-link"]').click();
    await page.waitForSelector('[data-test="login-form"]');

    // ── Step 3: Fill login form ───────────────────────────────────────
    await page.locator('[data-test="email-input"]').fill('synth-user@example.com');
    await page.locator('[data-test="password-input"]').fill(`${__ENV.SYNTH_PASSWORD}`);
    await page.locator('[data-test="login-submit"]').click();

    // Wait for post-login redirect
    await page.waitForNavigation({ waitUntil: 'networkidle' });

    check(page, {
      'login: user dashboard visible': async (p) => {
        return await p.locator('[data-test="user-dashboard"]').isVisible();
      },
    });

    // ── Step 4: Search for a product ──────────────────────────────────
    await page.locator('[data-test="search-input"]').fill('wireless headphones');
    await page.locator('[data-test="search-submit"]').click();
    await page.waitForSelector('[data-test="product-card"]');

    check(page, {
      'search: results appeared': async (p) => {
        const cards = p.locator('[data-test="product-card"]');
        return await cards.count() > 0;
      },
    });

    // ── Step 5: Add first result to cart ─────────────────────────────
    await page.locator('[data-test="add-to-cart"]:first-child').click();
    await page.waitForSelector('[data-test="cart-count"]');

    check(page, {
      'cart: item added (count = 1)': async (p) => {
        const text = await p.locator('[data-test="cart-count"]').textContent();
        return text === '1';
      },
    });

    // ── Step 6: Check cart page ───────────────────────────────────────
    await page.locator('[data-test="cart-icon"]').click();
    await page.waitForSelector('[data-test="cart-item"]');

    check(page, {
      'cart page: item visible': async (p) => {
        return await p.locator('[data-test="cart-item"]').isVisible();
      },
      'cart page: total label visible': async (p) => {
        return await p.locator('[data-test="cart-total"]').isVisible();
      },
    });

    // ── Capture a screenshot at the end ──────────────────────────────
    await page.screenshot({ path: '/tmp/synthetic-checkout-result.png' });

  } catch (err) {
    console.error(`Checkout flow failed: ${err.message}`);
    // Capture screenshot on failure for debugging
    await page.screenshot({ path: '/tmp/synthetic-checkout-failure.png' });
    throw err;

  } finally {
    page.close();
    context.close();
  }
}
```

---

## Running k6 in CI/CD (GitHub Actions)

```yaml
# .github/workflows/synthetic-checks.yml

name: Synthetic Monitor Checks

on:
  # Run every 15 minutes (scheduled synthetic check)
  schedule:
    - cron: '*/15 * * * *'
  
  # Also run on every push to main (smoke test after deploy)
  push:
    branches: [main]

jobs:
  http-synthetic:
    name: API Synthetic Checks
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Run k6 API synthetic checks
        uses: grafana/k6-action@v0.3.0
        with:
          filename: tests/synthetic/api-health.js
        env:
          SYNTH_CLIENT_SECRET: ${{ secrets.SYNTH_CLIENT_SECRET }}
          K6_CLOUD_TOKEN:      ${{ secrets.K6_CLOUD_TOKEN }}   # optional: send results to k6 Cloud

  browser-synthetic:
    name: Browser Synthetic Checks
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Install k6 with browser support
        run: |
          sudo gpg -k
          sudo gpg --no-default-keyring --keyring /usr/share/keyrings/k6-archive-keyring.gpg \
            --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys C5AD17C747E3415A3642D57D77C6C491D6AC1D69
          echo "deb [signed-by=/usr/share/keyrings/k6-archive-keyring.gpg] https://dl.k6.io/deb stable main" \
            | sudo tee /etc/apt/sources.list.d/k6.list
          sudo apt-get update && sudo apt-get install -y k6

      - name: Run browser synthetic check
        run: k6 run tests/synthetic/checkout-browser.js
        env:
          K6_BROWSER_HEADLESS: true
          SYNTH_PASSWORD: ${{ secrets.SYNTH_PASSWORD }}

      - name: Upload failure screenshot if check failed
        if: failure()
        uses: actions/upload-artifact@v4
        with:
          name: synthetic-failure-screenshot
          path: /tmp/synthetic-checkout-failure.png
```

---

## k6 Cloud: Scheduled Synthetic Checks

k6 Cloud (Grafana Cloud k6) runs your k6 scripts on a schedule from cloud
locations — similar to Dynatrace Synthetic but using your k6 codebase:

```bash
# Upload and run a test on k6 Cloud
k6 cloud tests/synthetic/api-health.js

# Output:
# execution: cloud
# Script: tests/synthetic/api-health.js
# output: https://app.k6.io/runs/12345
```

**k6 Cloud advantages over Dynatrace Synthetic:**
- Tests are JavaScript files in your repo
- Developers can run the same tests locally
- CI/CD integration is native
- Load testing and synthetic monitoring use the same toolchain

**Dynatrace Synthetic advantages over k6 Cloud:**
- Tighter integration with Dynatrace APM (traces, service maps, SLOs)
- More detailed browser waterfall and screenshots
- Native Terraform provider
- No separate billing for synthetic capacity

Most mature teams use BOTH: k6 for developer-owned smoke tests in CI,
Dynatrace for production continuous monitoring tied to SLOs.

---

## When to Use Each Tool

```
Use Dynatrace Synthetic when:
  ✓ You want checks tied directly to Dynatrace SLOs
  ✓ You want detailed browser waterfall and HAR files
  ✓ You want private locations inside your K8s cluster
  ✓ You want one platform for all observability (metrics + traces + synthetic)
  ✓ The team managing monitors is the SRE/platform team (not developers)

Use k6 / Checkly (code-first) when:
  ✓ Developers own the tests (code lives with the service)
  ✓ Tests need to run in CI on every PR (not just scheduled)
  ✓ You want to use the same tests for load testing and monitoring
  ✓ You want full git history of test changes
  ✓ Your team already has k6 expertise from load testing

Best practice: USE BOTH
  k6 in CI:  developers run synthetic checks on every push to main
             catches regressions before they reach production
  
  Dynatrace: platform SRE team owns continuous production monitoring
             ties into SLOs and alerting pipeline
             provides detailed diagnostics (waterfall, screenshots, HAR)
```
