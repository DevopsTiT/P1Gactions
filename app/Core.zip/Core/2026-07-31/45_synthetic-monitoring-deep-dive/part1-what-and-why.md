# Part 1 — What Synthetic Monitoring Is and Why It Matters

---

## The Core Problem It Solves

Real-User Monitoring (RUM) tells you what happened to actual users.
It is reactive: you see the problem only after users hit it.

Synthetic monitoring inverts this. It is proactive: a robot impersonates a user
on a fixed schedule and tells you whether your service would work for a real user
— BEFORE any real user even tries.

```
WITHOUT synthetic monitoring:

  [Service breaks at 3 AM]
         │
         ▼ (30–90 minutes of silence)
  [First user wakes up, tries to use the service, gets an error]
         │
         ▼ (5–30 minutes more)
  [User files a support ticket]
         │
         ▼
  [Support escalates to engineering]
         │
         ▼
  [On-call wakes up and begins investigation]
  
  Total user impact before detection: 60–120 minutes.

WITH synthetic monitoring:

  [Service breaks at 3 AM]
         │
         ▼ (1–5 minutes — the next scheduled check run)
  [Synthetic agent detects failure, PagerDuty fires]
         │
         ▼
  [On-call wakes up and begins investigation]
  
  Total user impact before detection: 1–5 minutes.
```

That gap — from hours to minutes — is why synthetic monitoring is a
foundational SRE tool, not an optional enhancement.

---

## The Mental Model: A Robot on a Clock

A synthetic monitor is exactly this:

```
┌───────────────────────────────────────────────────────────────┐
│  A robot that runs a script on a schedule                     │
│                                                               │
│  Script: "Go to /api/health. Expect HTTP 200. Expect body     │
│           contains 'status: ok'. Expect response < 2 seconds" │
│                                                               │
│  Schedule: every 5 minutes                                    │
│                                                               │
│  Location: from Tokyo, Frankfurt, and US-East                 │
│                                                               │
│  On failure: fire PagerDuty alert                             │
└───────────────────────────────────────────────────────────────┘
```

It is not magic. It is a disciplined, automated tester that never sleeps,
never takes a vacation, and never gets distracted.

---

## Synthetic vs. Real-User Monitoring: The Full Comparison

```
                     SYNTHETIC MONITORING      REAL-USER MONITORING (RUM)
─────────────────────────────────────────────────────────────────────────
Data source          Robot scripts              Actual users
Timing               Proactive (scheduled)      Reactive (when users visit)
Coverage             Continuous, 24/7           Only when users are active
Off-peak detection   YES — detects outages      NO — no users = no data
  at 3 AM when                                  at 3 AM
  nobody is on
Geographic coverage  You choose the locations   Wherever your users happen to be
  control
Deterministic?       YES — same script every    NO — different users, browsers,
                     run, exact same path        networks every time
Feed SLOs cleanly?   YES — uniform sampling     HARDER — noisy, user-driven
Business flow test   YES — scripted journeys    NO — only what users actually do
  (login → buy)
Certificate expiry   YES — synthetic cert check NO — users just see a browser error
Real user noise      NONE — always the same     HIGH — varies by user behavior,
                     robot behavior              browser, location, device
```

---

## The Four Capabilities Synthetic Monitoring Provides

### Capability 1: Outage Detection Without User Traffic

You have a weekly maintenance window at 2 AM Sunday. Synthetic monitors
keep running throughout. If the maintenance accidentally breaks something,
the synthetic monitor fires within 5 minutes — before Monday morning users arrive.

You also have customers in Asia-Pacific who use your app at times when
your US engineering team is asleep. Synthetic monitors from a Tokyo location
detect failures in that region even when no US engineer is paying attention.

### Capability 2: SLO Data with Zero Noise

SLO availability = (successful checks / total checks) × 100

A synthetic HTTP check runs every 5 minutes from 3 locations.
That's 3 × 12 × 24 × 30 = 25,920 data points per month.
Every data point is from the same script, same assertion, same timeout.

Compare this to RUM where: different users have different network speeds,
different browsers with different rendering behavior, different screen sizes
affecting page load, different CDN edges. RUM data is useful but noisy.
Synthetic data is clean and uniform — ideal for SLO calculations.

### Capability 3: Geographic Fault Detection

A CDN edge node in Frankfurt goes down. Users in Germany get errors.
Users in US and Asia are fine. Your US-based engineering team sees no errors
in their own usage. RUM data is 90% US-based so the German failure is diluted.

A synthetic monitor with a Frankfurt location detects this immediately:
> "Frankfurt location: FAILED. US-East: OK. Tokyo: OK."

You now know it is a regional failure, not a global one.

### Capability 4: Pre-User-Traffic Validation

After a deployment, before you shift real user traffic, run a synthetic check
against the new version:

```
Deploy to canary (5% traffic)
  → Run synthetic check against canary URL
  → If synthetic check passes: proceed to 100% rollout
  → If synthetic check fails: rollback immediately, 0 real users impacted
```

This is a safety net between "code deployed" and "users hit it."

---

## What Synthetic Monitoring Is NOT

Common beginner misunderstandings:

```
NOT a load test
  Synthetic monitoring sends 1 request every N minutes.
  Load testing sends thousands of requests simultaneously to measure capacity.
  Different tools, different goals.

NOT a replacement for application logs
  Synthetic tells you "the check failed."
  Logs tell you "why the check failed at the code level."
  You need both.

NOT a replacement for alerting on real user metrics
  Synthetic catches what the robot tests. Real user errors catch
  failure modes your robot didn't think to test.
  You need both.

NOT 100% representative of real user experience
  The robot has perfect connectivity, no ad blockers, no browser extensions,
  no VPN, no old browser. A real user might fail where the robot succeeds.
  Synthetic is necessary but not sufficient.
```

---

## The Six Components of Every Synthetic Check

No matter which tool you use (Dynatrace, Checkly, k6, Datadog), every
synthetic monitor has the same six building blocks:

```
┌─────────────────────────────────────────────────────────────┐
│  1. SCRIPT / DEFINITION                                     │
│     What to do: URL, steps, what to click, what to type     │
│     What to assert: status code, body content, element text │
├─────────────────────────────────────────────────────────────┤
│  2. SCHEDULE                                                │
│     How often: every 1m / 5m / 15m / 30m                   │
├─────────────────────────────────────────────────────────────┤
│  3. LOCATIONS                                               │
│     Where from: Tokyo, Frankfurt, US-East (public)          │
│     OR: your own data center (private location)             │
├─────────────────────────────────────────────────────────────┤
│  4. ASSERTIONS / THRESHOLDS                                 │
│     Pass/fail criteria:                                     │
│     - HTTP status = 200 (assertion)                         │
│     - Response time < 2000ms (threshold)                    │
│     - Body contains "status: ok" (assertion)                │
├─────────────────────────────────────────────────────────────┤
│  5. ALERT POLICY                                            │
│     When to fire:                                           │
│     - After 1 failure from all locations (global outage)    │
│     - After 2 consecutive failures from one location        │
│     Where to send: PagerDuty / Slack / email                │
├─────────────────────────────────────────────────────────────┤
│  6. RESULTS STORAGE                                         │
│     - Metrics: response time, availability %                │
│     - Screenshots (browser monitors)                        │
│     - HAR files (all requests, timings)                     │
│     - Waterfall charts                                      │
└─────────────────────────────────────────────────────────────┘
```

---

## The Cost/Frequency Tradeoff

Running synthetic checks costs money (DEM units in Dynatrace, credits in Checkly).
More frequent checks = faster detection but higher cost.

```
Check frequency   Detection window   Good for
──────────────────────────────────────────────────────────────
Every 1 minute    0–1 min lag        Critical revenue paths only
                                     (checkout, login, payment)
                                     Cost: expensive

Every 5 minutes   0–5 min lag        Most API health checks
                                     Production services
                                     Cost: moderate

Every 15 minutes  0–15 min lag       Browser / scripted flows
                                     Non-critical UI paths
                                     Cost: lower

Every 30 minutes  0–30 min lag       SSL cert checks
                                     Low-criticality external pages
                                     Cost: low

Every 60+ minutes > 30 min lag       Rarely justified for production
                                     Maybe acceptable for dev/staging
```

**Rule of thumb:** Use 5-minute intervals for most API checks, 15-minute
intervals for browser flows, and 1-minute intervals only for the most
business-critical flows where minutes of downtime have direct revenue impact.
