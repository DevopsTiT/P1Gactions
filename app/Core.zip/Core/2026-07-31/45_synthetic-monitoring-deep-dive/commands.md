# 45 — Synthetic Monitoring Deep Dive: Commands Reference

All shell commands from all 10 parts, organized by phase.

---

## Phase 0 — Discovery: Inspect What Already Exists

```bash
# List all synthetic monitors (name, type, enabled state, frequency)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.monitors[] | {monitorId, name, type, enabled, frequencyMin}'

# List all available public locations (with entity IDs for Terraform)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/locations?type=PUBLIC" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.locations[] | {entityId, name, city, country}'

# List private locations (verify your agent registered correctly)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/locations?type=PRIVATE" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.locations[] | {entityId, name, status}'

# Get full configuration of one specific monitor
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq .

# List all credential vault entries (names only — values are encrypted)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/credentials" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.credentials[] | {id, name, type, scope}'
```

---

## Phase 1 — Private Location Deployment

```bash
# Apply namespace first
kubectl apply -f infra/synthetic/private-location/namespace.yaml

# Create secret (token must have synthetic capabilities)
kubectl apply -f infra/synthetic/private-location/secret.yaml

# Deploy the ActiveGate
kubectl apply -f infra/synthetic/private-location/deployment.yaml

# Apply network policy
kubectl apply -f infra/synthetic/private-location/networkpolicy.yaml

# Watch pods come up
kubectl get pods -n dynatrace-synthetic -w

# Check logs to confirm agent registered with Dynatrace SaaS
kubectl logs -f deployment/synthetic-private-location -n dynatrace-synthetic | grep -i "registered\|connected\|ready"

# Verify the private location now appears in Dynatrace (wait 1-3 minutes)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/locations?type=PRIVATE" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.locations[] | {entityId, name, status}'
# Expected: status = "ENABLED"
```

---

## Phase 2 — Terraform: Apply Monitors

```bash
# Navigate to synthetic infrastructure directory
cd infra/synthetic

# Initialize Terraform (downloads Dynatrace provider)
terraform init

# Preview: HTTP health check
terraform plan -target=dynatrace_http_monitor.api_health

# Apply: HTTP health check
terraform apply -target=dynatrace_http_monitor.api_health

# Preview: Multi-step API monitor
terraform plan -target=dynatrace_http_monitor.order_api_flow

# Apply: Multi-step API monitor
terraform apply -target=dynatrace_http_monitor.order_api_flow

# Apply: Browser monitor
terraform apply -target=dynatrace_browser_monitor.login_and_search

# Apply: Alert policy + notifications
terraform apply -target=dynatrace_alerting.synthetic_critical
terraform apply -target=dynatrace_notification.pagerduty_synthetic
terraform apply -target=dynatrace_notification.slack_synthetic

# Apply: SLOs
terraform apply -target=dynatrace_slo_v2.payment_api_availability
terraform apply -target=dynatrace_slo_v2.checkout_flow_success
```

---

## Phase 3 — Verify After Apply

```bash
# Confirm monitors were created
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.monitors[] | select(.name | contains("API Health")) | {name, enabled, frequencyMin}'

# Trigger an on-demand check immediately (don't wait for schedule)
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/execute" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"locations": ["GEOLOCATION-980DF339B0114B47"]}'

# Wait for results, then check
sleep 30
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-2m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.results[-1] | {status, errorCode, errorMessage, responseTime}'
# Expected: { "status": "SUCCESS" }

# Check SLO status
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/slo?from=now-7d" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.slo[] | {name, status, evaluatedPercentage, target}'
```

---

## Phase 4 — Threshold Calibration

```bash
# Get p95 response time for the last 30 days (calibrate thresholds from real data)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=builtin:synthetic.http.duration.geo:percentile(95)\
&resolution=1d&from=now-30d" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '[.resolution.data[].values[]] | sort | .[(length * 0.95 | floor)] | "30-day p95: \(.) ms"'

# Calculate recommended threshold: 2-3× the p95
# Example: if p95 = 380ms → recommended threshold = 800-1000ms
python3 -c "
p95 = 380   # replace with actual p95 value from above
recommended = int(p95 * 2.5 / 100) * 100   # round to nearest 100ms
print(f'Recommended threshold: {recommended}ms (2.5× p95 of {p95}ms)')
"

# Get availability percentage for the last 30 days
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=builtin:synthetic.http.availability.location.total\
&resolution=1d&from=now-30d" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '[.resolution.data[].values[]] | add/length | "30-day avg availability: \(.)%"'
```

---

## Phase 5 — Incident Investigation (Synthetic Alert Fired)

```bash
# Step 1: Check which locations are failing
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-15m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.results[] | {timestamp, locationName, status, errorCode, responseStatusCode}'

# Step 2: Get detailed error for the most recent failure
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-15m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.results[] | select(.status == "FAILED") | {timestamp, locationName, errorCode, errorMessage}'

# Step 3: Compare synthetic failure to real user error rate
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=ext:app.payment.error.rate&resolution=1m&from=now-15m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.resolution.data[].values'

# Step 4: Trigger an on-demand check from all configured locations
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/execute" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"locations": []}'   # empty = run from all configured locations
```

---

## Phase 6 — Maintenance Window Operations

```bash
# Pause a single monitor (before maintenance starts)
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/pause" \
  -H "Authorization: Api-Token $DT_API_TOKEN"

# Verify it is paused
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.enabled'
# Expected: false

# After maintenance: resume the monitor
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/resume" \
  -H "Authorization: Api-Token $DT_API_TOKEN"

# Verify it is resumed
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.enabled'
# Expected: true

# Trigger immediate on-demand check to confirm service is healthy after maintenance
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/execute" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"locations": []}'
sleep 30
curl -s ".../monitors/{monitorId}/results?from=now-2m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.results[-1].status'
```

---

## Phase 7 — Credential Rotation

```bash
# Check current credential entries in vault
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/credentials" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.credentials[] | {id, name, type, owner}'

# Rotate the synthetic user password via Terraform
NEW_PASSWORD="$(openssl rand -base64 24)"
terraform apply \
  -var="synth_user_password=$NEW_PASSWORD" \
  -target=dynatrace_credentials.synth_user

# Wait for next check cycle, then verify the check still passes
sleep 120   # 2 minutes for credential to propagate + check to run
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-3m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.results[-1] | {status, errorCode}'
# Expected: { "status": "SUCCESS", "errorCode": null }
```

---

## Phase 8 — k6 Synthetic Check (Local + CI)

```bash
# Install k6 (macOS)
brew install k6

# Run API synthetic check once (local verification)
SYNTH_CLIENT_SECRET="your-secret" k6 run tests/synthetic/api-health.js

# Run browser synthetic check (requires chromium)
K6_BROWSER_HEADLESS=true SYNTH_PASSWORD="your-pass" k6 run tests/synthetic/checkout-browser.js

# Run with k6 Cloud (scheduled, from cloud locations)
k6 cloud tests/synthetic/api-health.js

# Run with custom thresholds and summary stats
k6 run \
  --summary-trend-stats="avg,min,med,max,p(95),p(99)" \
  --vus 1 \
  --iterations 3 \
  tests/synthetic/api-health.js

# Send results to Dynatrace
K6_DYNATRACE_URL="https://YOUR_TENANT.live.dynatrace.com" \
K6_DYNATRACE_APITOKEN="$DT_API_TOKEN" \
k6 run --out dynatrace tests/synthetic/api-health.js
```

---

## Phase 9 — Weekly Health Audit

```bash
# Count enabled vs disabled monitors
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '{
      total: (.monitors | length),
      enabled: [.monitors[] | select(.enabled == true)] | length,
      disabled: [.monitors[] | select(.enabled == false)] | length
    }'

# Find monitors with recent failures (availability < 99% in last 24h)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=builtin:synthetic.http.availability.location.total\
&resolution=1h&from=now-24h" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.resolution.data[] | select(.values[] | . < 99) | .dimensionMap.dt_entity_synthetic_test'

# Check private location agent health
kubectl get pods -n dynatrace-synthetic
kubectl top pods -n dynatrace-synthetic

# Check for agent restarts in the last 7 days
kubectl get pods -n dynatrace-synthetic \
  -o jsonpath='{range .items[*]}{.metadata.name}{"\t"}{.status.containerStatuses[0].restartCount}{"\n"}{end}'

# Check all SLOs status
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/slo?from=now-30d&pageSize=50" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.slo[] | {name, status, evaluatedPercentage, target}'
```
