# Part 9 — Operational Runbook: Day-2 SRE Tasks for Synthetic Monitoring

---

## What "Day-2" Means

Day 1 is building and deploying the synthetic monitors.
Day 2 is everything after: maintaining them, responding to alerts,
handling flapping checks, rotating credentials, adding coverage
after incidents, and tuning over time.

This part documents the recurring operational tasks that keep your
synthetic monitoring system healthy and useful.

---

## Task 1: Responding to a Synthetic Alert

When PagerDuty fires for a synthetic monitor failure, this is the workflow:

### Step 1: Identify Scope (global vs. local)

```bash
# Check which locations are failing
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-15m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.results[] | {timestamp, locationId, locationName, status, errorCode}'
```

Expected output interpretation:
```
If ALL locations show FAILED → Global outage → SEV1/2 candidate
If ONE location shows FAILED, others OK → Regional issue → SEV3 candidate
If alternating FAILED/SUCCESS → Flapping check → investigate transient issues
```

### Step 2: Get the Failure Details

```bash
# Get the error message from failed checks
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-30m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.results[] | select(.status == "FAILED") | {
      timestamp,
      locationName,
      errorCode,
      errorMessage,
      responseStatusCode,
      responseTime
    }'
```

Common error codes and what they mean:
```
DNS_ERROR          → Domain does not resolve from that location
                     (check DNS health, CDN config, routing)

CONNECTION_REFUSED → Port is not open or server rejected connection
                     (check if service is running, firewall rules)

CONNECTION_TIMEOUT → Connection established but no response
                     (check server is accepting connections, TLS handshake)

READ_TIMEOUT       → Response started but timed out
                     (service is overloaded, slow query, resource exhaustion)

STATUS_CODE_ERROR  → Wrong HTTP status code
                     (application bug, auth failure, service returning error)

SCRIPT_ERROR       → Browser monitor script crashed
                     (DOM element not found, assertion failed, JS error)
```

### Step 3: Correlate with Real User Impact

Before escalating to SEV1/2, verify whether real users are affected:

```bash
# Check Dynatrace for real user error rate on the same service
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=ext:app.payment.error.rate&resolution=1m&from=now-15m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.resolution.data[].values'
```

Possible outcomes:
```
Synthetic FAILED + Real errors high → Real outage. Escalate immediately.
Synthetic FAILED + Real errors low  → Possible false positive, or the check
                                       tests a code path that's rarely hit by
                                       real users. Investigate but hold severity.
Synthetic OK    + Real errors high  → Synthetic doesn't cover the broken path.
                                       Add a check for this path (action item).
```

### Step 4: Trigger an On-Demand Check

```bash
# Run the check immediately (don't wait for next schedule)
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/execute" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"locations": ["GEOLOCATION-980DF339B0114B47"]}'   # specific location

# Wait 30 seconds, then check results
sleep 30
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-2m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.results[-1] | {status, errorCode, responseTime}'
```

---

## Task 2: Pausing Monitors During Maintenance

When you have a planned maintenance window, synthetic monitors must be paused
or they will fire false alerts throughout the window.

```bash
# Pause a specific monitor
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/pause" \
  -H "Authorization: Api-Token $DT_API_TOKEN"

# Verify it's paused
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.enabled'
# Expected: false

# After maintenance: resume
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/resume" \
  -H "Authorization: Api-Token $DT_API_TOKEN"

# Verify it's resumed and run an on-demand check
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.enabled'
# Expected: true
```

**CRITICAL: Always create a Jira ticket for the maintenance window that includes:**
```
- Which monitors were paused
- Paused at: [timestamp]
- Expected resume at: [timestamp]
- Responsible engineer: [name]
```

If the engineer forgets to resume the monitors after maintenance,
the next on-call shift has no alerting. This has caused real incidents
to be missed for hours.

**Better: use Dynatrace Maintenance Windows (auto-resumes):**

```bash
# Create a maintenance window via API (preferred: set it up in Terraform ahead of time)
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/maintenanceWindows" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Planned maintenance 2026-08-01 02:00-04:00 UTC",
    "description": "Database upgrade",
    "type": "PLANNED",
    "suppression": "DETECT_PROBLEMS_AND_ALERT",
    "suppressSyntheticMonitorsExecution": true,
    "schedule": {
      "recurrenceType": "ONCE",
      "start": "2026-08-01 02:00",
      "end": "2026-08-01 04:00",
      "zoneId": "UTC"
    }
  }'
```

---

## Task 3: Debugging a Flapping Check

A flapping check alternates between FAILED and SUCCESS repeatedly.
This is almost always a false positive — but it generates alert noise and
can cause alert fatigue if not addressed.

```
Symptoms:
  14:05 SUCCESS
  14:10 FAILED
  14:15 SUCCESS
  14:20 FAILED
  14:25 SUCCESS
```

### Diagnosing Flapping

```bash
# Get last 2 hours of results, sorted by time
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-2h" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '[.results[] | {timestamp, locationName, status, responseTime, errorCode}]
    | sort_by(.timestamp)'
```

Questions to answer from the data:
```
1. Is the flapping from one location or all locations?
   One location flapping → likely network path instability between that
   city and your service. Try a more stable public location instead.

2. Is the response time near the threshold when it fails?
   ResponseTime: 1980ms, threshold: 2000ms → threshold is too tight
   → Increase threshold or the check flaps on peak-time slowdowns

3. Is the error code always the same?
   Always TIMEOUT → service is occasionally slow (not a binary failure)
   → Increase the timeout value for this check

4. Does the flapping correlate with deployment times?
   Check git log: does flapping start right after a deploy?
   → The deploy is introducing intermittent issues
```

### Fixing Flapping

```
Root cause: Threshold too tight
  Fix: Increase threshold from 2000ms to 3000ms
  Terraform: change value_ms in the anomaly_detection block

Root cause: Network instability between check location and service
  Fix: Add a second location to replace the flapping one, or
       require 2 consecutive failures before alerting (local_outage_policy)

Root cause: Service has genuine intermittent failures
  Fix: This is not a false positive — investigate the service
  The synthetic check is doing its job; the service is flapping
```

---

## Task 4: Adding Coverage After an Incident

Every incident reveals a path that wasn't covered by synthetic monitoring.
After every postmortem, ask: "If a synthetic monitor had covered this path,
how much earlier would we have detected the failure?"

Then add that check.

```
Post-incident: Payment service DB pool exhaustion incident

Blind spots revealed:
  1. No check on the checkout API endpoint (only /api/health was monitored)
  2. No check that actually creates an order (tests the write path)
  3. No alert on DB connection pool saturation

New monitors to add:
  Monitor 1: "Checkout API – POST /api/checkout"
    → Asserts: 201 status, body contains 'orderId', response < 3000ms
    → Feeds the existing payment-service SLO
  
  Monitor 2: "Order Write Path – Create + Retrieve"
    → Multi-step: POST /api/orders → GET /api/orders/{id}
    → If step 2 fails, write path is broken even though step 1 succeeds
  
Terraform implementation:
  Add to infra/synthetic/payment-service/
  PR: "Add post-incident synthetic coverage for payment checkout path"
```

---

## Task 5: Reviewing Monitor Health (Weekly)

Every week, review the synthetic monitoring health dashboard:

```bash
# Get summary of all monitors: how many are enabled, how many have failures
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '{
      total: (.monitors | length),
      enabled: (.monitors | map(select(.enabled == true)) | length),
      disabled: (.monitors | map(select(.enabled == false)) | length)
    }'

# Get monitors that have failed at least once in the last 24 hours
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=builtin:synthetic.http.availability.location.total\
&resolution=1h&from=now-24h" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.resolution.data[] | select(.values[] | . < 100) | .dimensionMap'

# List monitors that are currently disabled (should be 0 outside maintenance windows)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.monitors[] | select(.enabled == false) | {name, monitorId}'
```

**Weekly health questions:**
```
1. Are there any disabled monitors? If yes: why? Is it intentional?
   (A disabled monitor that was "temporarily" paused 3 months ago is a gap)

2. Are there any monitors with > 1% failure rate this week?
   (Even if no alert fired, consistently flapping checks need tuning)

3. Were any coverage gaps revealed by incidents this week?
   (If yes: create Jira ticket to add coverage)

4. Are any credential expiry dates approaching?
   (Credentials that expire = all synthetic checks for that service fail simultaneously)
```

---

## Task 6: Quarterly Monitor Audit

Once per quarter, do a full audit of your synthetic monitoring coverage:

```
1. Map all production services against synthetic coverage:
   For each service in your service catalog:
   - Does it have an HTTP health check? (minimum requirement)
   - Does it have a multi-step check for its critical flow?
   - Does it feed into an SLO?
   - Does it have private location coverage (if internal)?
   
   Services with no synthetic coverage are reliability blind spots.

2. Review monitor configurations for staleness:
   - Are assertion strings still accurate?
     (If the API response format changed, the body assertion may be wrong)
   - Are thresholds still calibrated correctly?
     (If the service got faster, thresholds should be tightened)
   - Are all location IDs still valid?
     (Rarely, Dynatrace deprecates a location)

3. Review the false-positive rate:
   For each monitor: alerts fired vs. real incidents caused
   If > 20% of alerts were false positives → that monitor needs tuning

4. Verify credentials are not approaching expiry:
   List all credentials and their rotation dates
   Schedule rotation for any credential expiring within 60 days

5. Verify private location agents are healthy:
   kubectl get pods -n dynatrace-synthetic
   → All pods should be Running, no restarts in the last 7 days
```
