# Configure and Manage Application & Infrastructure Monitoring Using Dynatrace
## SRE Deep Dive

> Everything an SRE needs to understand: how DT installs, what it collects automatically, what you must configure manually, how to set thresholds that don't cause alert fatigue, and how to keep the whole system healthy over time.

---

## Decision Tree — Where to start

```
                      You joined a new project using Dynatrace
                                      │
              ┌───────────────────────┼───────────────────────┐
              ▼                       ▼                       ▼
     "Is DT installed?"        "What is DT           "What does DT
     (is OneAgent running?)     monitoring?"           alert on?"
              │                       │                       │
     kubectl get pods           DT UI → Services       DT UI → Alerting
     -n dynatrace                     │                 Profiles + Metric
              │                 Auto-detected           Events
     If not:                    by OneAgent                    │
     → Deploy DynaKube          + manual config          Probably too
       via GitOps/ArgoCD        for custom metrics       many false alerts
              │                       │                       │
     wave 3 in                  Check: SLOs,            Fix: per-env
     sync-wave order             synthetics,             thresholds +
                                 log ingestion           alert delays
```

---

## E2E Summary — Full DT Monitoring Stack

```
Layer 1 — INSTALLATION
  DynaKube CR (GitOps) → Dynatrace Operator → OneAgent DaemonSet on every node
  OneAgent hooks into every JVM, Go, Python process on the node automatically.

Layer 2 — AUTO-DETECTED (zero configuration)
  Services, response time, error rate, throughput, database calls, JVM heap/GC,
  process restarts, container CPU/memory, host metrics, Kubernetes workload state.

Layer 3 — CONFIGURED BY SRE (Terraform)
  Management zones     → scope who sees what
  Alerting profiles    → who gets woken up at what severity
  Metric events        → custom thresholds for the 8 signals
  SLOs                 → error budget tracking
  Synthetics           → external health checks every 5 min
  Notifications        → PagerDuty + Slack routing

Layer 4 — APPLICATION INSTRUMENTATION
  OTEL_EXPORTER_OTLP_ENDPOINT + OTEL_SERVICE_NAME in Helm values.yaml
  → distributed traces across services without code changes

Layer 5 — ONGOING MANAGEMENT
  Threshold tuning, anomaly detection config, log ingestion rules,
  dashboard maintenance, SLO target reviews.
```

---

## Part 1 — Installing Dynatrace on Kubernetes (The Right Way)

### Why GitOps (not manual)

```
Manual install:
  kubectl apply -f dynakube.yaml   ← done once, forgotten, never version-controlled
  Upgrade: hope someone remembers the original flags
  Audit: impossible to know what changed or when

GitOps (ArgoCD) install:
  gitops/<env>/monitoring/dynatrace/dynatrace-operator.yaml → ArgoCD → cluster
  Every change is a Git commit with author + timestamp
  Rollback: git revert → ArgoCD applies → previous config restored
  Drift: if someone edits DynaKube manually → ArgoCD reverts within 3 min (selfHeal: true)
```

### The install chain

```
Step 1: DT tokens stored in AWS Secrets Manager
  Secrets:
    production/dynatrace/api-token    ← DT REST API token (write access)
    production/dynatrace/paas-token   ← OneAgent download token

Step 2: ExternalSecret (sync-wave 3) pulls tokens into K8s Secret "dynakube"
  apiVersion: external-secrets.io/v1beta1
  kind: ExternalSecret
  spec:
    target:
      name: dynakube          ← K8s Secret name DynaKube looks for
    data:
      - secretKey: apiToken   ← key inside the K8s Secret
        remoteRef: { key: production/dynatrace/api-token }
      - secretKey: dataIngestToken
        remoteRef: { key: production/dynatrace/paas-token }

Step 3: Dynatrace Operator (sync-wave 3) installed via Helm
  Watches for DynaKube custom resources

Step 4: DynaKube CR (sync-wave 3) applied
  apiVersion: dynatrace.com/v1beta1
  kind: DynaKube
  spec:
    apiUrl: https://abc12345.live.dynatrace.com/api
    tokens: dynakube           ← name of the K8s Secret above
    classicFullStack:
      enabled: true            ← OneAgent DaemonSet on every node
    logMonitoring:
      enabled: true            ← logs ingested directly (no Fluent Bit)
    activeGate:
      capabilities:
        - routing              ← relay metrics/traces to DT tenant
        - kubernetes-api-monitoring  ← K8s workload metrics
        - log-analytics        ← log processing

Result: OneAgent pod starts on every node. Within 5 minutes:
  - All services appear in DT automatically
  - JVM heap, GC, thread metrics visible
  - HTTP request metrics visible
  - DB call metrics visible
```

### What OneAgent auto-instruments (no config needed)

```
JAVA / JVM:
  ✓ HTTP requests (Spring MVC, JAX-RS, Servlet)
  ✓ Outgoing HTTP calls (RestTemplate, WebClient, OkHttp, Feign)
  ✓ JDBC queries (Hibernate, JPA, raw JDBC) → query text, duration, row count
  ✓ JVM heap utilization, GC pause time, GC collection count
  ✓ Thread pool: active threads, queue depth
  ✓ Class loading, method execution time (entry-point methods)
  ✓ Exception stack traces
  ✓ Log4j / Logback log forwarding (automatically, no appender config)

KUBERNETES:
  ✓ Pod CPU / memory request vs limit vs actual usage
  ✓ Pod restarts (crash loop detection)
  ✓ Deployment rollout status
  ✓ Node CPU / memory / disk
  ✓ Namespace-level resource usage

WHAT IS NOT AUTO-INSTRUMENTED:
  ✗ Custom business metrics (e.g., "payment processing rate", "cart size")
     → Need: DT metric ingest API or OTEL custom metrics
  ✗ Distributed traces across services
     → Need: OTEL_EXPORTER_OTLP_ENDPOINT + OTEL Java agent
  ✗ External dependency health (e.g., "is the payment gateway API up?")
     → Need: HTTP Synthetic monitors
  ✗ Log-based alerting on specific error messages
     → Need: DT log metric rules or metric events on log_lines_count
```

---

## Part 2 — Management Zones (Scope Control)

### What they are and why they matter

```
Management Zone = a filter that scopes which DT entities a team sees.

Without management zones:
  payment team opens DT → sees ALL services (order, notification, inventory, platform...)
  Alert: "payment-service high error rate" fires → payment oncall gets paged
  Alert: "order-service down" also fires → payment oncall gets paged for something they don't own
  → Wrong team woken up, oncall burn-out, ignored alerts

With management zones:
  payments management zone: shows ONLY entities tagged team:payments + environment:production
  orders management zone: shows ONLY entities tagged team:orders + environment:production
  Each team's alerts only fire for their own services.
```

### How tags get onto services automatically

```
This is the chain (no manual tagging needed):

1. Kubernetes namespace created with labels:
     apiVersion: v1
     kind: Namespace
     metadata:
       name: payment-ns
       labels:
         team: payments            ← label on the namespace
         environment: production   ← label on the namespace

2. OneAgent reads pod metadata. Pods inherit namespace labels.
   DT entity "payment-service" gets tags:
     team:payments
     environment:production

3. DT auto-tagging rule (configured in DT UI or API):
   Rule: "if Kubernetes namespace label team=X → add tag team:X to entity"
   Rule: "if Kubernetes namespace label environment=Y → add tag environment:Y to entity"

4. Management zone rule (Terraform):
   resource "dynatrace_management_zone_v2" "team" {
     rules {
       rule {
         attribute_conditions {
           attribute = "SERVICE_TAGS"
           tag_value = "team:payments"
         }
         attribute_conditions {
           attribute = "SERVICE_TAGS"
           tag_value = "environment:production"
         }
       }
     }
   }

Result: only payment-service (tagged team:payments + environment:production)
        appears in the payments production management zone.
```

### Entity types covered by management zones

```
Each management zone in this project covers 4 entity types:

SERVICE          → for HTTP metric events (error rate, latency, traffic)
PROCESS_GROUP    → for JVM heap and CPU metric events
HOST             → for network error rate events
KUBERNETES_CLUSTER → for pod restart and memory events

WHY ALL FOUR:
  A "payment-service alert" might come from:
    - Service layer: error rate → service entity
    - JVM layer: heap 90% → process group entity
    - Node layer: network errors → host entity
    - K8s layer: pod restarts → kubernetes_cluster entity
  
  Without all 4 types in the management zone: some alerts would fall outside
  the zone → wrong team gets them (or no team gets them).
```

---

## Part 3 — Alerting Profiles (Who Gets Woken Up)

### The 4-tier model

```
TIER 1: CRITICAL (AVAILABILITY, 0 min delay)
  When: service completely unavailable (all probes failing)
  Who: PagerDuty → phone call to oncall engineer
  Env: production ONLY
  Delay: 0 minutes — availability loss is never transient

TIER 2: HIGH (ERROR, 2 min delay)
  When: error rate exceeds threshold
  Who: PagerDuty → push notification to oncall phone
  Env: production + staging
  Delay: 2 minutes — filters transient spikes during rolling deploys
         (a deploy causes brief errors for 60-90s → 2 min delay skips this)

TIER 3: WARNING (SLOWDOWN, 5 min delay)
  When: latency P99 exceeds threshold
  Who: Slack #alerts-<team>
  Env: all environments
  Delay: 5 minutes — confirms sustained degradation vs a brief traffic spike

TIER 4: INFO (RESOURCE_CONTENTION, 15 min delay)
  When: CPU, memory, JVM heap, network errors exceeding threshold
  Who: Slack #monitoring (shared channel, all teams)
  Env: all environments
  Delay: 15 minutes — resource trends need time; brief CPU spikes are normal

WHY DELAYS MATTER:
  No delay + high error rate on deploy:
    14:00:00 - rolling update starts
    14:00:30 - pod 1 terminated, pod 2 not ready yet → 33% of requests fail
    14:01:00 - pod 2 ready → error rate drops to 0
    14:00:31 - PagerDuty fires → oncall engineer woken at 2am for a 30-second blip
  
  2 min delay:
    Same deploy scenario: error spike lasts 60s < 2 min → alert never fires
    Real sustained error rate: lasts 10 minutes → alert fires at T+2min
```

### Terraform implementation

```hcl
# TIER 1: CRITICAL — production only
resource "dynatrace_alerting" "critical" {
  for_each        = var.environment == "production" ? local.teams : toset([])
  name            = "${each.value}-${var.environment}-critical"
  management_zone = dynatrace_management_zone_v2.team[each.value].id

  rules {
    rule {
      severity_level   = "AVAILABILITY"
      delay_in_minutes = 0
      include_mode     = "INCLUDE_ALL"
      tag_filter { include_mode = "INCLUDE_ALL" }
    }
  }
}

# TIER 2: HIGH — production + staging
resource "dynatrace_alerting" "high" {
  for_each = contains(["production","staging"], var.environment) ? local.teams : toset([])
  ...
  rules { rule {
    severity_level   = "ERROR"
    delay_in_minutes = 2
  }}
}

# TIER 3: WARNING — all envs
resource "dynatrace_alerting" "warning" {
  for_each = local.teams
  ...
  rules { rule {
    severity_level   = "SLOWDOWN"
    delay_in_minutes = 5
  }}
}

# TIER 4: INFO — all envs
resource "dynatrace_alerting" "info" {
  for_each = local.teams
  ...
  rules {
    rule { severity_level = "RESOURCE_CONTENTION"; delay_in_minutes = 15 }
    rule { severity_level = "CUSTOM_ALERT";        delay_in_minutes = 15 }
  }
}
```

---

## Part 4 — Metric Events (Custom Thresholds)

### The 8 signals and their Terraform resources

#### Signal 1: TRAFFIC DROP (most important — catches silent outages)

```hcl
resource "dynatrace_metric_events" "traffic_drop" {
  event_type  = "ERROR_EVENT"   # routes to HIGH alerting tier → PagerDuty

  model_properties {
    type             = "STATIC_THRESHOLD"
    alert_condition  = "BELOW"    # unique: only this signal fires BELOW threshold
    alert_on_no_data = true       # fires even when DT receives ZERO data points
    threshold        = each.value.traffic_min_rps
    violating_samples = 3         # must be below for 3 consecutive minutes
    dealerting_samples = 5        # must be above for 5 minutes to close
  }

  query_definition {
    metric_key = "builtin:service.requestCount.server"
    resolution = "1m"
  }
}
```

```
WHY THIS IS THE MOST IMPORTANT SIGNAL:
  If DNS breaks, ALB misconfigures, or ingress fails:
    - No requests reach the service
    - Error rate = 0% (nothing to fail)
    - Latency = no data (nothing to measure)
    - JVM heap looks normal (no load)
    - ALL other signals look perfectly healthy

  Only traffic drop catches this scenario.

  alert_on_no_data = true:
    Even if DT stops receiving metrics entirely (e.g., ActiveGate is down,
    network partition) → alert still fires.
    Without this: "no data" is treated as "everything is fine."
```

#### Signal 2: ERROR RATE

```hcl
resource "dynatrace_metric_events" "error_rate" {
  event_type = "ERROR_EVENT"
  model_properties {
    alert_condition    = "ABOVE"
    threshold          = each.value.error_rate_alert   # 0.1 = 0.1%
    violating_samples  = 3
    dealerting_samples = 3
  }
  query_definition {
    metric_key = "builtin:service.errors.server.rate"
    # HTTP 5xx errors / total requests × 100
  }
}
```

```
Threshold guide by service type:
  Payment service:   0.1%  — any error = potential failed transaction
  Order service:     0.5%  — errors cause customer friction
  API service:       1.0%  — acceptable failure rate
  Batch/async:       5.0%  — retries expected

Dev env:   10% (code may have intentional errors under test)
Staging:   1%  (should be close to production behaviour)
Production: per-service, strict
```

#### Signal 3: LATENCY P99

```hcl
resource "dynatrace_metric_events" "latency_p99" {
  event_type = "PERFORMANCE_EVENT"   # routes to WARNING tier → Slack
  model_properties {
    threshold = each.value.latency_p99_ms * 1000
    # IMPORTANT: DT uses MICROSECONDS internally.
    # 300ms = 300,000 microseconds. Multiply by 1000.
  }
  query_definition {
    metric_key = "builtin:service.response.time:percentile(99)"
  }
}
```

```
Why P99, not P50 or average?
  P50 (median): 50% of requests are faster. Hides that 50% could be slow.
  Average:      skewed by outliers. 99 fast requests + 1 10s request = 109ms avg.
  P99:          99% of users experience this or better.
                Catches the tail — the worst 1% of experiences.
                If P99 = 300ms: 1 in 100 requests is slower than 300ms.

P99 threshold rule of thumb:
  Set at 2-3× your normal P99 baseline.
  Normal baseline 100ms → threshold 300ms.
  If your P99 is normally 250ms, a threshold of 300ms will fire constantly.
  Measure your baseline first, THEN set the threshold.
```

#### Signal 4: CPU SATURATION

```hcl
resource "dynatrace_metric_events" "cpu_saturation" {
  event_entity_dimension_key = "dt.entity.process_group_instance"
  event_type = "RESOURCE_CONTENTION_EVENT"   # routes to INFO tier → Slack
  model_properties {
    threshold         = each.value.cpu_saturation_pct   # 70-90%
    violating_samples = 5   # 5 consecutive minutes — CPU spikes are normal
  }
  query_definition {
    metric_key = "builtin:process.cpu.usage"
  }
}
```

```
Why violating_samples = 5 for CPU (not 3)?
  CPU spikes legitimately during:
    - JVM garbage collection (10-15s of high CPU)
    - Batch job kicks off at the top of the hour
    - Rolling deploy: new pod starts, JVM JIT compiles hot paths → CPU spike
  
  3 consecutive minutes would alert during every GC cycle.
  5 consecutive minutes: only alerts on sustained CPU pressure.
  
Java-specific: set threshold LOWER (70%) than non-JVM services (85-90%)
  G1GC starts aggressive collection above 70% CPU → latency increases
  Alert at 70% lets you scale out BEFORE users notice latency degradation
```

#### Signal 5: MEMORY USAGE

```hcl
query_definition {
  metric_key = "builtin:process.memory.usage"
  # RSS memory as % of container memory limit
}
```

```
Container memory limit: 1Gi
RSS memory at 75%: 768MB
OOM kill threshold: ~100% (Linux kills the process)

Leave 25% headroom between alert threshold and OOM:
  Alert at 75% → engineers investigate and scale before OOM at 90-95%
  Without alert: engineers notice when pods are in OOMKilled state → already broken
```

#### Signal 6: JVM HEAP UTILIZATION (Java-specific)

```hcl
query_definition {
  metric_key = "builtin:process.memory.jvm.heapUtilization"
  # heap used / Xmx × 100
}
```

```
JVM heap lifecycle with G1GC:
  0-50%:  Normal. Minor GC keeps heap clean. Pauses <5ms.
  50-70%: G1GC starts more frequent collections. Pauses 10-50ms.
  70-80%: G1GC in "mixed mode" — evacuates old regions. Pauses 100-200ms.
           THIS IS WHERE WE ALERT (production threshold: 70%)
  80-90%: G1GC can't keep up → concurrent mode failure → full GC pause 1-5s
           P99 latency spikes visible to users
  90-100%: OutOfMemoryError → JVM crash → pod restart

Different Xmx = different % baseline:
  Dev   Xmx=256m:  Spring Boot idle = 180MB = 70% at idle → alert threshold: 85%
  Staging Xmx=512m: Spring Boot idle = 200MB = 39% at idle → alert threshold: 78%
  Prod  Xmx=1024m: Spring Boot idle = 350MB = 34% at idle → alert threshold: 70%
```

#### Signal 7: POD RESTARTS

```hcl
resource "dynatrace_metric_events" "pod_restarts" {
  event_type = "ERROR_EVENT"
  model_properties {
    threshold         = each.value.pod_restart_threshold   # 2 in prod
    violating_samples = 1   # one 5-minute window is enough
    samples           = 1
  }
  query_definition {
    metric_key = "builtin:kubernetes.workload.pods.restarts"
    resolution = "5m"   # check every 5 minutes
  }
}
```

```
Why 2 restarts threshold (not 1)?
  1 restart is suspicious but could be:
    - Node recycled (Karpenter spot interruption) → pod re-scheduled → 1 restart
    - Liveness probe caught a transient hang → pod restarted → recovered
  2 restarts in 5 minutes = crash loop pattern → definitely investigate

Pod restarts indicate:
  OOMKilled:       memory limit too low or memory leak → check heap/RSS metrics
  CrashLoopBackOff: application crashing repeatedly → check logs for stack trace
  Liveness failure: application deadlock or hung thread → check thread dump
  Config error:    wrong env var / missing secret → check pod Events (kubectl describe)
```

#### Signal 8: NETWORK ERROR RATE

```hcl
query_definition {
  metric_key = "builtin:host.net.errorRate"
  # packet errors + drops / total packets × 100
}
```

```
Normal network error rate: < 0.01%
Alert threshold: 0.5-1% depending on service

High network error rate indicates:
  Network congestion:     node is saturated, packets dropped at NIC
  MTU mismatch:           packets too large for network path → fragmentation → drops
  Security group issue:   SG rule blocking traffic → packets rejected
  Node hardware issue:    NIC failing → physical packet errors
  VPC flow limits:        hitting AWS ENI flow limits on large instances

This signal is often overlooked but catches AWS-level issues that
don't show up in application-level error rates.
```

---

## Part 5 — SLOs (Service Level Objectives)

### Availability SLO

```hcl
resource "dynatrace_slo_v2" "availability" {
  target_success    = 99.9    # 99.9% = ~43 min downtime/month allowed
  target_warning    = 99.8    # warn 0.1% before breach
  evaluation_window = "-1M"   # rolling 30-day window

  metric_expression = <<-EOT
    100 * (
      builtin:service.requestCount.server   ← total requests
        :filter(eq(service.name,"payment-service"))
        :sum
      -
      builtin:service.errors.server.count   ← error requests
        :filter(eq(service.name,"payment-service"))
        :sum
    )
    / builtin:service.requestCount.server
        :filter(eq(service.name,"payment-service"))
        :sum
  EOT
  # = (successful requests / total requests) × 100
}
```

### Error budget and burn rate alerts

```
SLO target: 99.9% over 30 days
Monthly error budget: 0.1% × 30 days × 24h × 60min = 43.2 minutes

Burn rate alert (fast burn: 14.4×):
  14.4× = burning error budget 14.4 times faster than the allowed rate
  At this rate: 30-day budget exhausted in 2 days
  Action: PAGE immediately — this is a production incident

Burn rate alert (slow burn: 3×):
  3× = budget exhausted in 10 days
  Action: Slack warning — investigate during business hours

WHY BURN RATE BEATS SIMPLE THRESHOLDS:
  Simple threshold: "alert if error rate > 0.1% for 5 minutes"
  Problem: 0.2% error rate for 5 minutes → alert fires → errors stop → alert clears
           But you burned 10 minutes of your 43-minute monthly budget in 5 minutes!
           Simple threshold doesn't track accumulated budget consumption.
  
  Burn rate: "alert if you're consuming error budget faster than you can afford"
  Catches: sustained moderate errors (0.2% for 6 hours) that simple thresholds miss
           because the rate never hits a high threshold.
```

### SLO window types

```
Rolling window (-1M):
  Always covers the last 30 days from RIGHT NOW.
  Error budget resets continuously.
  Pro: reflects current reliability, not calendar effects.
  Con: a bad week at the end of last month still counts for 3 more weeks.

Calendar window (e.g., 2024-01):
  Fixed start/end date (Jan 1 to Jan 31).
  Error budget fully resets on Feb 1.
  Pro: matches billing/reporting cycles.
  Con: "we can afford more errors at the start of the month" culture.

This project uses rolling (-1M) = standard SRE practice.
```

---

## Part 6 — HTTP Synthetic Monitors

### What they check that internal monitoring misses

```
OneAgent (internal monitoring):
  Checks service health FROM INSIDE the cluster.
  Cannot see: DNS resolution, SSL certificate validity, ALB routing, CDN issues.
  If payment-service is healthy internally but the ALB is misconfigured:
    → OneAgent: all green
    → Users: can't reach payment.company.com
    → You only find out when customers complain

Synthetic monitor (external):
  Sends a real HTTP GET from Tokyo/Singapore every 5 minutes.
  Full stack check: DNS → TCP → TLS → HTTP → response body validation.
  If ALB is misconfigured → synthetic fails → alert fires before users notice.
```

### Terraform configuration

```hcl
resource "dynatrace_http_monitor" "health_check" {
  frequency = 5   # every 5 minutes
  locations = [
    "GEOLOCATION-6F55B7E4B5E7A52F",  # Tokyo
    "GEOLOCATION-D15FBAABA11A2D7D",  # Singapore
  ]

  script {
    request {
      url    = "https://payment.company.com/actuator/health"
      method = "GET"

      configuration {
        accept_any_certificate = false  # FAIL on expired/invalid TLS cert
        follow_redirects       = true
      }

      validation {
        rule {
          type          = "httpStatusesList"
          value         = "2xx"
          pass_if_found = true
          # HTTP 200 = ALB is routing, service is alive
        }
        rule {
          type          = "patternConstraint"
          value         = "\"status\":\"UP\""
          pass_if_found = true
          # Body check: Spring Actuator returns {"status":"UP"}
          # HTTP 200 with {"status":"DOWN"} should still fail the synthetic
        }
      }

      response_time_limit = 900   # 3 × 300ms P99 SLO
      # Alert if synthetic takes more than 3× normal P99
      # Loose enough to not false-alert, strict enough to catch real slowdowns
    }
  }

  anomaly_detection {
    outage_handling {
      global_outages = true
      local_outages  = true
      global_consecutive_outage_count_threshold = 1
      # 1 consecutive failure from ALL locations = global outage → alert
      local_consecutive_outage_count_threshold  = 3
      # 3 consecutive failures from ONE location = local issue → alert
    }
  }
}
```

### Why validate the body (not just HTTP 200)

```
Spring Boot Actuator can return HTTP 200 with this body:
  { "status": "DOWN", "components": { "db": { "status": "DOWN" } } }

The service is alive (returns 200) but the database is unreachable.
A payment made now would fail immediately.

HTTP 200 validation only → synthetic passes → no alert → payments fail silently.
Body validation "status":"UP" → synthetic fails → alert fires → SRE investigates.

This matters most for: database outages, downstream API outages, config errors.
```

---

## Part 7 — Log Ingestion and Log-Based Alerts

### How logs flow to Dynatrace

```
With logMonitoring: enabled: true in DynaKube:
  OneAgent reads: /var/log/containers/*.log on each node
  (this is where Docker/containerd writes stdout from every container)
  
  Automatic ingestion: no Fluent Bit, no log shipper needed.
  Logs appear in DT Grail within 30 seconds of being written.

Log format matters:
  JSON structured logging (recommended):
    {"timestamp":"2024-01-15T10:30:00Z","level":"ERROR","service":"payment-service",
     "message":"DB connection refused","trace_id":"abc123"}
  
  DT parses JSON automatically → each field is searchable
  You can filter: log_level = ERROR AND service.name = "payment-service"
  
  Plain text (not recommended):
    ERROR 2024-01-15 DB connection refused
  DT ingests it but fields are not parsed → full-text search only → slower queries
```

### Log-based metric events (alert on specific log patterns)

```
Use case: alert when a specific exception appears in logs, not just when error rate rises.

Example: alert when "OutOfMemoryError" appears in any payment-service log line.

Configure in DT UI: Metrics → Log metrics → Create metric
  Metric name:  log.payment.oom
  Query:        matchesValue(log.content, "*OutOfMemoryError*")
              AND matchesValue(k8s.namespace.name, "payment-ns")
  Aggregation:  count (number of log lines matching per minute)

Then create a Metric Event:
  metric_key = "log.payment.oom"
  threshold  = 1    # alert on first occurrence
  event_type = "ERROR_EVENT"

Result: one OOM log line → metric count = 1 → threshold exceeded → PagerDuty fires.
Faster than waiting for the pod restart to show up in pod_restarts metric.
```

---

## Part 8 — Dashboards (Operational Visibility)

### SRE daily dashboard structure

```
Row 1: AVAILABILITY STATUS (green/red at a glance)
  - Synthetic monitor status: each service × each location
  - SLO compliance: current % vs target (gauge)
  - Error budget remaining: how many minutes left this month (number tile)

Row 2: GOLDEN SIGNALS (last 1 hour)
  - Request rate per service (line chart)
  - Error rate per service (line chart, threshold line at SLO)
  - P99 latency per service (line chart, threshold line)
  - CPU + memory per service (bar chart)

Row 3: JVM HEALTH (Java-specific)
  - JVM heap % per service × environment (heatmap)
  - GC pause time (line chart)
  - Thread count (line chart)
  - Pod restart count (number tiles, red if > 0)

Row 4: INFRASTRUCTURE
  - Node CPU / memory (all nodes in cluster)
  - Pod count per namespace (trend)
  - HPA scale events (number of scale-out events in last 1h)
```

### Key DT metric expressions for dashboards

```
# Request rate (per minute, per service)
builtin:service.requestCount.server
  :filter(eq(service.name,"payment-service"))
  :rate(1m)

# Error rate % (last 5 minutes)
(builtin:service.errors.server.count
  :filter(eq(service.name,"payment-service"))
  :sum)
/ (builtin:service.requestCount.server
  :filter(eq(service.name,"payment-service"))
  :sum)
* 100

# P99 latency in milliseconds
builtin:service.response.time:percentile(99)
  :filter(eq(service.name,"payment-service"))
  / 1000   ← DT stores in microseconds, divide by 1000 for milliseconds

# JVM heap %
builtin:process.memory.jvm.heapUtilization
  :filter(eq(process.group.name,"payment-service"))

# Pod restart count (last 5 minutes)
builtin:kubernetes.workload.pods.restarts
  :filter(eq(workload.name,"payment-service"))
  :sum
```

---

## Part 9 — Ongoing Management (SRE Responsibilities)

### Weekly tasks

```
1. REVIEW ALERT FATIGUE:
   Check: how many alerts fired this week?
   How many were actionable (real incidents) vs noise?
   If noise > 20%: tune thresholds UP (they're too sensitive)
   If you missed an incident: tune thresholds DOWN
   
   Command to check alert history:
     DT UI → Problems → Filter by: last 7 days + management zone: payments-production
     Export to CSV → count "Problem resolved: human action" vs "auto-resolved"

2. REVIEW SLO ERROR BUDGET:
   Check: how much error budget consumed this week?
   If > 50% of monthly budget in 1 week: slow burn alert should fire
   If approaching breach: freeze non-critical deploys
   
   Formula:
     Budget consumed (%) = (1 - actual SLO%) / (1 - target SLO%) × 100
     Actual: 99.85%, Target: 99.9%
     Consumed: (1 - 0.9985) / (1 - 0.999) × 100 = 0.15% / 0.1% × 100 = 150%
     → You've consumed 150% of your budget → breach already!

3. CHECK SYNTHETIC MONITORS:
   Any new SSL certificate expiry warnings? (DT warns 30 days before expiry)
   Any location consistently failing? (indicates regional issue)
   Are response times trending up? (early warning before threshold breach)

4. REVIEW CAPACITY TRENDS:
   Is JVM heap trending up over 2 weeks? (possible memory leak)
   Is pod count growing without traffic growth? (HPA misconfigured)
   Is any node consistently at 85%+ CPU? (needs Karpenter to scale)
```

### Threshold tuning process

```
Step 1: Gather baseline data (1-2 weeks of normal operation)
  DT UI → Metrics → Explore → builtin:service.response.time:percentile(99)
  Note: p99 at off-peak (3am) and peak (6pm JST)

Step 2: Set initial threshold at 3× normal P99
  Normal P99 = 100ms → initial threshold = 300ms
  If alerts fire too often → raise to 400ms
  If an incident was missed → lower to 250ms

Step 3: Document threshold decisions in a THRESHOLD_DECISIONS.md file
  "payment-service latency = 300ms because: normal P99 = 100ms, 3× rule.
   Raised from 250ms on 2024-03-15: too many false alerts during peak traffic."

Step 4: Re-evaluate every quarter
  Traffic patterns change. A threshold correct in Q1 may be wrong in Q4.
  Automated: set a recurring calendar reminder.

Per-environment multipliers (starting points):
  Production = 1× (the SLO)
  Staging    = 2-3× (JIT warmup, smaller nodes)
  Dev        = 5-10× (anything goes)
```

### Adding a new service to monitoring

```
# When a new Java service is added to the project:

Step 1: Add namespace labels (in namespaces.yaml)
  - name: new-service-ns
    labels: { team: payments, environment: production }
  → OneAgent auto-tags the new service within 5 minutes of pod start

Step 2: Add to Terraform services map (environments/production/main.tf)
  "new-service" = {
    team             = "payments"
    slo_target       = 99.5
    health_check_url = "https://new-service.company.com/actuator/health"
    traffic_min_rps  = 5
    error_rate_alert = 0.5
    latency_p99_ms   = 400
    ...
  }
  → terraform apply creates: management zone rule, 8 metric events, SLO, synthetic

Step 3: Add OTEL env vars to new service's Helm values.yaml
  - name: OTEL_EXPORTER_OTLP_ENDPOINT
    value: "http://dynatrace-activegate.dynatrace.svc:4318"
  - name: OTEL_SERVICE_NAME
    value: "new-service"
  → traces appear in DT within 1 minute of pod start

Step 4: Add notification routing
  If new team: add slack_webhook_urls entry for new team channel
  If same team as existing service: already covered by existing notification rules

Step 5: Verify in DT UI after first deploy:
  Services → new-service → check: request count rising, error rate = 0%
  Traces → filter: service.name = "new-service" → should see spans
  SLOs → "new-service Availability [production]" → should show data
  Synthetic → "new-service Health Check [production]" → should be green
```

---

## Part 10 — Incident Response Using Dynatrace

### When PagerDuty fires — SRE workflow in DT

```
STEP 1: Open the Problem in DT (link in PagerDuty alert)
  Problem view shows:
    - Root cause entity: "payment-service in payment-ns"
    - Problem type: "High error rate" / "Service unavailable"
    - Start time, duration, affected users
    - Related events (recent deploys, config changes)

STEP 2: Check the Services view
  DT → payment-service → Response time / Failure rate
  Look for: when exactly did it start? (pinpoint the deploy or event)
  
STEP 3: Check distributed traces
  DT → Distributed Traces → filter: error = true + service = payment-service
  Click on an errored trace → see exactly which call failed and why
  Common: payment-service → PostgreSQL call failing (shows the SQL + error)

STEP 4: Check logs (linked from the trace)
  Each span in the trace has a "Logs" tab → shows log lines from that exact request
  Look for: exception stack trace, error message, connection refused

STEP 5: Check infrastructure
  If application looks healthy but errors persist:
  DT → payment-service → Infrastructure → pods → check: any OOMKilled? Any restarts?
  DT → payment-service → Technology → JVM → is heap at 95%?

STEP 6: Corroborate with K8s events
  kubectl describe deployment payment-service -n payment-ns
  kubectl get events -n payment-ns --sort-by='.lastTimestamp'

STEP 7: If caused by deploy → rollback via GitOps
  git log --oneline -- gitops/production/app/payment-service/payment-service.yaml
  # Roll back: edit tag to previous SHA → git commit → git push
  # ArgoCD detects → rolling update to old image
```

---

## Summary — What SRE Owns vs What DT Does Automatically

```
DYNATRACE DOES AUTOMATICALLY (zero SRE config):
  ✓ Detect all services and their dependencies
  ✓ Collect HTTP metrics (rate, latency, errors) per service
  ✓ Collect JVM metrics (heap, GC, threads)
  ✓ Collect Kubernetes metrics (pod restarts, CPU, memory)
  ✓ Collect host metrics (CPU, memory, disk, network)
  ✓ Ingest container logs (with logMonitoring enabled)
  ✓ Auto-tag entities from Kubernetes labels
  ✓ Build service dependency maps (who calls what)

SRE CONFIGURES AND MANAGES (Terraform + GitOps):
  → Management zones (scope: who sees what)
  → Alerting profiles (who gets woken up at what severity with what delay)
  → Metric events (custom thresholds for the 8 signals, per environment)
  → SLOs (error budget tracking with burn rate alerts)
  → HTTP Synthetic monitors (external health checks)
  → Notification routing (PagerDuty + Slack per team + per tier)
  → OTEL env vars (distributed tracing across services)
  → Log metric rules (alert on specific log patterns)
  → Threshold tuning (ongoing — quarterly review minimum)
  → Dashboard maintenance (operational visibility)
  → New service onboarding (4 steps per new service)
```
