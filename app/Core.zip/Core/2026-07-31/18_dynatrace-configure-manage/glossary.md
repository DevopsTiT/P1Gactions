# Glossary — Configure and Manage Dynatrace Monitoring

Every term from main.md. One entry per term.

---

**Dynatrace (DT)**
A full-stack observability platform that automatically detects services, instruments code, and provides metrics, traces, logs, and alerting. Why it matters: the central tool SREs use to monitor application health and infrastructure in this project.

**OneAgent**
A Dynatrace agent deployed as a DaemonSet (one copy on every Kubernetes node) that automatically instruments every Java, Go, Python, and Node.js process without code changes. Why it matters: this is the collection layer — without OneAgent, DT collects nothing from the cluster.

**DynaKube**
A Kubernetes Custom Resource that tells the Dynatrace Operator what to deploy: OneAgent (classicFullStack), log ingestion (logMonitoring), and data routing (activeGate). Why it matters: the single configuration object that controls the entire DT installation on a cluster.

**Dynatrace Operator**
A Kubernetes Operator (a long-running controller) that watches for DynaKube resources and manages the OneAgent DaemonSet and ActiveGate lifecycle. Why it matters: handles upgrades, configuration changes, and restarts of DT components automatically.

**ActiveGate**
A DT gateway component running inside the cluster that receives OTLP traces, metrics, and logs from application pods and forwards them to the DT SaaS tenant. Why it matters: keeps telemetry data inside the cluster network; the only component that needs outbound internet access to the DT tenant.

**classicFullStack**
A DynaKube deployment mode that runs OneAgent on every node via DaemonSet and auto-instruments all processes. Why it matters: enables JVM heap monitoring, HTTP request capture, DB call capture, and log ingestion with zero application code changes.

**logMonitoring**
A DynaKube setting that enables OneAgent to read container log files from `/var/log/containers/` on each node and ingest them into DT Grail. Why it matters: replaces Fluent Bit — no separate log pipeline configuration needed.

**DT Grail**
Dynatrace's internal data lake that stores logs, metrics, and traces with a unified query language (DQL). Why it matters: all DT log queries and log-based metric rules run against Grail.

**GitOps (for DT install)**
Storing the DynaKube custom resource in a Git repository and having ArgoCD apply it to the cluster. Why it matters: every change to the DT configuration is a git commit — auditable, reversible, and protected from drift by ArgoCD's selfHeal.

**ExternalSecret (for DT tokens)**
A Kubernetes resource that pulls DT API tokens from AWS Secrets Manager and creates a K8s Secret named `dynakube`. Why it matters: tokens are never stored in Git; the DynaKube CR references this Secret by name for authentication.

**Management Zone**
A Dynatrace configuration that filters which entities (services, hosts, processes) are visible to a team, based on entity tags. Why it matters: payment team only sees payment entities; order team only sees order entities — no cross-team noise, correct alert routing.

**Entity tag**
A label on a DT-monitored entity (like `team:payments` or `environment:production`) used by management zones and metric event filters to scope data. Why it matters: tags are the glue that connects Kubernetes namespace labels to DT management zones.

**Auto-tagging rule**
A DT configuration rule that automatically assigns tags to entities based on Kubernetes labels, environment variables, or other properties. Why it matters: when a namespace has `team: payments`, the auto-tagging rule adds `team:payments` tag to all entities in that namespace — no manual tagging.

**Alerting profile**
A DT configuration that defines which problem severity types to alert on, with what delay, and scoped to which management zone. Why it matters: separate profiles for CRITICAL/HIGH/WARNING/INFO prevent all alerts from going to one channel and drowning in noise.

**Severity levels (DT)**
DT's built-in problem severity tiers: AVAILABILITY (service down), ERROR (high error rate), SLOWDOWN (high latency), RESOURCE_CONTENTION (CPU/memory/heap), CUSTOM_ALERT (custom metric events). Why it matters: each severity maps to a different alerting tier and notification channel.

**Alert delay (`delay_in_minutes`)**
How many minutes DT waits after detecting a problem before sending a notification. Why it matters: a 2-minute delay filters out transient error spikes during rolling deploys (which typically last 60-90 seconds).

**4-tier alerting**
The architecture: CRITICAL (0 min, prod only, PagerDuty call) → HIGH (2 min, PagerDuty push) → WARNING (5 min, Slack team channel) → INFO (15 min, Slack shared channel). Why it matters: engineers are only woken up for genuine production availability issues.

**Metric event**
A DT resource that watches a specific metric and creates a problem when the metric crosses a threshold. Why it matters: this is how custom alerts are created — e.g., "alert when payment-service P99 latency exceeds 300ms."

**`STATIC_THRESHOLD` (metric event)**
A metric event model type that fires when a metric continuously exceeds (or falls below) a fixed value for N consecutive minutes. Why it matters: the simplest and most predictable alert type — good starting point for all 8 signals.

**`violating_samples`**
Number of consecutive measurement intervals the metric must violate the threshold before the alert fires. Why it matters: prevents single-point-in-time spikes from triggering false alerts; 3 violating samples = 3 consecutive minutes above threshold.

**`dealerting_samples`**
Number of consecutive measurements that must be back to normal before the alert closes. Why it matters: prevents alert flapping (open-close-open-close) for metrics that hover near the threshold.

**`alert_on_no_data = true`**
Makes a metric event fire even when DT receives zero data points (not just when a value exceeds a threshold). Why it matters: critical for the traffic drop signal — if the service stops sending metrics entirely, this flag ensures the alert still fires.

**`alert_condition = "BELOW"`**
Makes a metric event fire when a value drops BELOW the threshold (instead of above). Used only for traffic drop. Why it matters: traffic drop is the only signal where lower = worse; all other signals fire when values are too HIGH.

**The 8 signals**
Traffic drop, error rate, latency P99, CPU saturation, memory usage, JVM heap utilization, pod restarts, network error rate. Why it matters: together they cover all failure modes; any production incident will cause at least one of these to cross its threshold.

**Traffic drop signal**
The metric event that fires when requests per minute falls below a minimum threshold. Why it matters: the most important signal — the only one that catches silent outages (DNS failure, ALB misconfiguration) where all other signals look healthy because no traffic is reaching the service.

**P99 latency**
The 99th percentile response time — 99% of requests complete in this time or less. Why it matters: measures worst-case user experience; better than average because it isn't distorted by outliers.

**Microseconds (DT latency metric)**
Dynatrace stores latency metrics in microseconds. 300ms = 300,000 microseconds. Why it matters: the `threshold` in Terraform metric events must be in microseconds — forgetting to multiply by 1000 sets the threshold to 300μs instead of 300ms (everything would alert constantly).

**CPU saturation**
The percentage of process CPU time in use. High CPU in Java often indicates GC pressure. Why it matters: alert at 70-75% for JVM services — G1GC starts aggressive collection above this, causing latency spikes before 80-85% is reached.

**G1GC (Garbage-First Garbage Collector)**
The default Java garbage collector. Divides the heap into regions and collects them incrementally to keep pause times under a target. Why it matters: above 70% heap utilization, G1GC starts "mixed mode" collections with longer pauses — this is the early warning zone.

**JVM heap utilization**
Heap memory used as a percentage of Xmx (maximum heap). Why it matters: per-environment thresholds differ because Xmx differs (dev 256m, staging 512m, prod 1024m) — the percentage that triggers GC pressure is different at each size.

**OOMKilled**
Kubernetes pod termination due to the Linux OOM killer — the process exceeded its container memory limit. Why it matters: OOMKilled appears in pod status; the memory usage and JVM heap alerts exist to catch the trend before OOM kill happens.

**Pod restart**
A Kubernetes pod termination and restart event. Why it matters: `builtin:kubernetes.workload.pods.restarts` tracks this; 2+ restarts in 5 minutes = crash loop pattern indicating a serious problem (OOM, config error, deadlock).

**CrashLoopBackOff**
A Kubernetes pod state where the pod keeps crashing and Kubernetes keeps restarting it with exponentially increasing delays. Why it matters: the pod restart metric event catches the first 2 restarts before this state is reached.

**SLO (Service Level Objective)**
A measurable reliability target: e.g., "99.9% of requests succeed over a rolling 30-day window." Why it matters: the contract between the service team and its users; defines how much downtime is acceptable.

**Error budget**
The allowed amount of unreliability within an SLO period. At 99.9% target over 30 days = 43.2 minutes of acceptable downtime. Why it matters: when the error budget is exhausted, all deploys except fixes should stop — reliability over features.

**Burn rate**
How fast the error budget is being consumed relative to the allowed rate. 14.4× burn = budget gone in 2 days. 3× burn = budget gone in 10 days. Why it matters: catches sustained moderate errors that simple threshold alerts miss.

**Rolling window (-1M)**
An SLO evaluation window that always covers the last 30 days from right now — not a calendar month. Why it matters: standard SRE practice; error budget resets continuously instead of all at once on the 1st of each month.

**HTTP Synthetic monitor**
A Dynatrace resource that sends real HTTP requests from geographic locations on a schedule to check that a service is reachable from outside the cluster. Why it matters: catches DNS failures, ALB misconfigurations, SSL certificate expiry, and CDN issues that internal monitoring never sees.

**Global outage (synthetic)**
All synthetic locations fail simultaneously — indicates the service is truly unavailable. Why it matters: DT fires a higher-severity alert for global outage vs local outage (only one region failing).

**Local outage (synthetic)**
Only one geographic location fails. Why it matters: may indicate a regional DNS or network issue, not a full service outage; requires 3 consecutive failures before alerting to avoid false positives from transient network blips.

**Body validation (synthetic)**
Checking that the HTTP response body contains a specific string (e.g., `"status":"UP"`). Why it matters: a service can return HTTP 200 with `{"status":"DOWN"}` — body validation catches this case that pure status-code checking misses.

**Spring Boot Actuator**
A Spring Boot module that exposes `/actuator/health`, `/actuator/health/liveness`, and `/actuator/health/readiness` endpoints. Why it matters: the correct health check paths for Java services — synthetics and Kubernetes probes use these.

**DT Notification (PagerDuty / Slack)**
A Terraform resource that wires a DT alerting profile to a notification channel (PagerDuty API key or Slack webhook URL). Why it matters: connects the alert tier to the right communication channel for each team.

**`dynatrace_pagerduty_notification`**
Terraform resource for creating a DT→PagerDuty notification. Linked to the `critical` or `high` alerting profile. Why it matters: CRITICAL fires PagerDuty phone call; HIGH fires PagerDuty push notification.

**`dynatrace_slack_notification`**
Terraform resource for creating a DT→Slack webhook notification. WARNING goes to `#alerts-<team>`, INFO goes to `#monitoring`. Why it matters: lower-severity alerts go to Slack for async review without waking anyone.

**Log metric rule**
A DT configuration that creates a custom metric by counting log lines matching a pattern (e.g., "OutOfMemoryError" appears in payment-service logs). Why it matters: enables alerting on specific application-level events that don't have dedicated DT built-in metrics.

**Alert fatigue**
The state where so many alerts fire (including false positives) that engineers start ignoring them — including real incidents. Why it matters: the primary enemy of effective monitoring; prevented by correct threshold setting, alert delays, and per-environment tuning.

**Threshold tuning**
The ongoing process of adjusting metric event thresholds based on observed baseline metrics. Why it matters: a threshold set 6 months ago may be wrong today if traffic patterns changed; quarterly review is the minimum.

**Baseline (metric)**
The normal, expected value of a metric during regular operation. Why it matters: all thresholds should be set relative to the baseline (e.g., 3× normal P99 = threshold) — not arbitrary round numbers.

**Burn rate alert**
An SLO alert that fires when error budget is being consumed faster than allowed. Fast burn (14.4×) → page immediately. Slow burn (3×) → Slack warning. Why it matters: catches prolonged moderate errors that simple threshold alerts miss because the error rate never hits a high absolute threshold.

**Capacity trend**
The week-over-week change in resource usage (CPU, memory, pod count) even without a corresponding traffic increase. Why it matters: slowly growing heap over 2 weeks → possible memory leak; SRE reviews this weekly to catch problems before they become incidents.

**New service onboarding**
The 4-step process of adding a new service to DT monitoring: namespace labels → Terraform services map → OTEL env vars → notification routing. Why it matters: a service deployed without these steps is invisible to DT — no alerts, no SLOs, no distributed traces.

**Problem (DT)**
A DT entity created when a metric event threshold is breached or anomaly detected. Groups related events and tracks the incident lifecycle (open → investigating → resolved). Why it matters: the unit of work during an incident — it links affected entities, log anomalies, and deployment events together.

**Root cause entity**
The DT entity that DT's AI (Davis) identifies as the likely source of a problem. Why it matters: in a cascading failure (payment-service errors → order-service errors → high latency everywhere), DT points to payment-service as the root cause — not every downstream symptom.

**Davis AI**
Dynatrace's AI engine that analyzes problems, finds root causes, and suppresses noise from dependent events. Why it matters: in a database outage affecting 10 services, Davis creates one Problem (database issue) not 10 Problems — reduces noise for oncall engineers.

**DQL (Dynatrace Query Language)**
The query language used in DT for log searches, dashboard metric expressions, and SLO definitions. Why it matters: used in dashboards to write custom metric expressions like `builtin:service.response.time:percentile(99) / 1000`.
