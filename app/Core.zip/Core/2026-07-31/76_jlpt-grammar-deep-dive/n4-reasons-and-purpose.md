# N4 Reasons, Purpose, and Explanation — Deep Dive
## から・ので・のに・ために・に行く/来る

---

## Part 1 — から vs ので: Two Ways to Say "Because"

Both から and ので mean "because." But they feel different, are used in different contexts,
and combining them with the wrong endings produces unnatural Japanese.

### から — Personal, Assertive, Casual

から = "because" when the speaker is asserting their personal reason.
It has a slight sense of "and that's why" — the speaker's logic, their perspective.

```
Formation: [plain form / polite form] + から + [result]

疲れているから、早く寝ます。
Because I'm tired, I'll go to bed early. (my personal reason)

寒いから、コートを着た。
Because it was cold, I put on a coat.

子供だから、わからないよ。
Because he's a child, he doesn't understand. (speaker's judgement)
```

から can attach to both plain and polite forms:
```
疲れているから → (casual)
疲れていますから → (polite — old-fashioned but grammatically fine)
```

から naturally leads into requests, commands, and decisions (Y clause = free):
```
雨だから、傘を持ってください。  ✓
```

### ので — Objective, Polite, Formal

ので = "because" when the reason is objective, external, or politely softened.
The speaker presents the cause as a natural, observable fact — not a personal assertion.

```
Formation: [plain form] + ので + [result]
(polite: [ます/です form] + ので is less common but acceptable)

電車が遅れたので、遅刻しました。
Because the train was delayed, I was late. (objective external fact)

体調が悪いので、早退してもいいですか？
Since I'm not feeling well, may I leave early?
(polite framing — ので makes the reason sound less demanding)
```

**The politeness difference:**
- から sounds like YOU are insisting on your reason
- ので sounds like the situation itself caused the result

In formal situations (apologizing to a boss, asking permission), ので is strongly preferred:
```
Formal excuse to boss:
  ✓ 急用ができましたので、先に失礼させていただきます。
    (Since something urgent has come up, I will excuse myself early.)
  
  △ 急用ができたから、帰ります。
    (Because something urgent came up, I'm going home — sounds blunt/assertive)
```

### Key distinction summary

```
から = personal, direct, casual — "My reason is X"
ので = objective, polite, formal — "The situation is X, which naturally leads to Y"
```

---

## Part 2 — のに: "Even Though" (Expectation Violated)

のに is NOT a reason connector like から or ので.
のに expresses that the speaker EXPECTED a certain result from the condition,
but reality turned out DIFFERENTLY — often with disappointment, frustration, or surprise.

```
Formation: [plain form] + のに + [unexpected/disappointing result]

たくさん勉強したのに、試験に落ちた。
Even though I studied a lot, I failed the exam.
(Expected: studying = passing. Reality: failed. Feeling: disappointment)

あんなに練習したのに、うまくなれない。
Even though I practiced that much, I can't get better.
(Expected: practice = improvement. Reality: still not good. Feeling: frustration)

彼は来ると言ったのに、来なかった。
Even though he said he would come, he didn't.
(Expected: said = will come. Reality: didn't come. Feeling: betrayal)
```

**のに with positive surprise:**
のに can also express pleasant surprise when reality is better than expected:
```
こんなに安いのに、おいしい！
Even though it's this cheap, it's delicious!
(Expected: cheap = bad quality. Reality: delicious. Feeling: pleasant surprise)
```

**Common error — confusing のに with から:**
```
✗ 疲れているのに、早く寝ます。
  (Wrong: のに requires the result to CONTRADICT the condition)
  
✓ 疲れているから、早く寝ます。
  (Correct: tired = naturally leads to going to bed)
  
✓ 疲れているのに、まだ働いている。
  (Correct: tired but STILL working = contradicts expectation)
```

---

## Part 3 — ために: Purpose vs Cause

ために has two meanings depending on what precedes it.

### ために as PURPOSE (volitional verb/noun before it)

When the action or noun is something intentionally chosen, ために = "in order to."
The subject WANTS to achieve a goal.

```
Formation: [volitional verb plain form] + ために + [action to achieve goal]
          [noun] + の + ために + [action]

医者になるために、毎日勉強しています。
In order to become a doctor, I study every day.
(Goal: become a doctor — chosen goal → purpose)

健康のために、毎日走っています。
For the sake of my health, I run every day.
(Health = intentional goal → purpose)

日本語を上手にするために、毎日練習する。
In order to improve my Japanese, I practice every day.
```

### ために as CAUSE (non-volitional verb/noun before it)

When the preceding noun or event is non-volitional (not chosen), ために = "because of / due to."
```
病気のために、会社を休んだ。
Because of illness, I took the day off.
(Illness is not chosen → cause)

台風のために、電車が止まった。
Due to the typhoon, the trains stopped.
(Typhoon is not chosen → cause)
```

### How to distinguish: ask "Did the subject choose X?"

```
医者になるために  → becoming a doctor is CHOSEN → purpose
病気のために     → getting sick is NOT chosen  → cause
```

---

## Part 4 — 〜に行く / 〜に来る: Movement + Purpose

Formation: verb STEM (ます-stem) + に + 行く/来る/帰る

```
本を借り + に + 図書館に行きます。
I'm going to the library to borrow books.
(借り = stem of 借りる)

友達に会い + に + 東京に来た。
I came to Tokyo to meet my friend.
(会い = stem of 会う)

野球を見 + に + 行きます。
I'm going to watch baseball.
(見 = stem of 見る)
```

This is used specifically for MOVEMENT to a location with a PURPOSE.
The verb stem tells you WHY you're moving; 行く/来る/帰る tells you the movement.

**Common mistake: using the te-form instead of the stem:**
```
✗ 本を借りて図書館に行きます。
  (This means: I'll borrow a book AND THEN go to the library — sequence, not purpose)
  
✓ 本を借りに図書館に行きます。
  (I'm going to the library FOR THE PURPOSE of borrowing a book)
```

---

## Part 5 — Comparing All Five

```
疲れているから、早く帰ります。
Because I'm tired, I'll go home early.
(REASON — personal cause)

疲れているので、早く帰ります。
Because I'm tired, I'll go home early.
(REASON — polite/objective)

疲れているのに、まだ働いている。
Even though I'm tired, I'm still working.
(CONCESSION — expectation violated)

休むために、早く仕事を終わらせる。
In order to rest, I'll finish work quickly.
(PURPOSE — intentional goal)

休みに家に帰る。
I go home during the holidays.
(MOVEMENT + purpose — に + 帰る pattern)
```

---

## The Formality Gradient for "Because"

```
Most casual ←──────────────────────────────→ Most formal

〜から → 〜ので → 〜ため(に) → 〜ゆえに (N2/N1, literary)
```

```
疲れているから、帰ります。        (casual — to friends)
疲れているので、帰ります。        (polite — in most situations)
疲れているため、帰ります。        (formal written — reports, emails)
疲れているゆえに、帰ります。      (literary/classical — rarely spoken)
```
