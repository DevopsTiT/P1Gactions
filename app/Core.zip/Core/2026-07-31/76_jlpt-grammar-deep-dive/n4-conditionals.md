# N4 Conditionals — Deep Dive: たら・ば・と・なら

> The four conditionals are the most tested N4 grammar topic and produce the most errors.
> Each one has a distinct feeling. Swapping them changes the nuance significantly.

---

## The Big Picture: One English "If" = Four Japanese Patterns

English "if" translates to four different patterns in Japanese:

```
たら  = the most versatile — covers: if, when, after (completed action → result)
ば    = ideal/hypothetical — often implies "if only" or describes general truths
と    = automatic/natural result — laws of nature, directions, habitual sequences
なら  = given that / based on new info — responds to something just said
```

---

## 〜たら — The General-Purpose Conditional

### Formation

Plain past form (た-form) + ら
```
行く → 行った → 行ったら
食べる → 食べた → 食べたら
高い → 高かった → 高かったら
静かだ → 静かだった → 静かだったら
```

### Meaning 1: When (after something happens — sequential)

Used when the first action completes first, THEN the second action happens:
```
家に帰ったら、手を洗います。
When I get home, I wash my hands. (I get home → then I wash)

宿題が終わったら、遊んでいいよ。
When your homework is finished, you can play.
```

The key: the first event must be COMPLETED before the second starts.

### Meaning 2: If (hypothetical — may or may not happen)

```
もっとお金があったら、旅行したい。
If I had more money, I would want to travel.

雨が降ったら、試合は中止だ。
If it rains, the match will be cancelled.
```

### Meaning 3: After (past result — discovering something)

When you do X and then discover/experience Y (often with surprise):
```
冷蔵庫を開けたら、何もなかった。
When I opened the fridge, there was nothing. (discovered on opening)

電話したら、彼はもう寝ていた。
When I called, he was already asleep. (discovered on calling)
```

### Critical rule: The "Y clause" restriction

When Y is a request, command, or strong intention, use たら (not ば or と):
```
駅に着いたら、電話してください。  ✓ (request in Y clause)
駅に着けば、電話してください。   ✗ (ば does not work with requests)
```

---

## 〜ば — Hypothetical / Ideal Condition

### Formation

```
Group 1 u-verbs: change final vowel to え-sound + ば
  書く → 書けば
  飲む → 飲めば
  話す → 話せば
  待つ → 待てば
  帰る → 帰れば

Group 2 ru-verbs: replace る with れば
  食べる → 食べれば
  見る   → 見れば

Group 3 irregular:
  する → すれば
  くる → くれば

い-adjective: remove い + ければ
  高い → 高ければ
  安い → 安ければ

な-adjective/noun + であれば (formal) or だったら (casual)
  静か → 静かであれば
```

### Core meaning: hypothetical ideal condition

ば often implies that the current reality is DIFFERENT from the condition stated, 
or that you're describing a general logical relationship:
```
もっと練習すれば、上手になれる。
If you practiced more (you're not currently practicing enough), you could get good.

早く寝れば、元気になるよ。
If you go to bed early (implying: you should), you'll feel better.
```

### General truth / rule

ば is used for universal, logical, or habitual truths:
```
春になれば、花が咲く。
When spring comes, flowers bloom. (universal truth)

右に曲がれば、駅があります。
If you turn right, there is a station. (logical direction)
```

### 〜ば〜ほど — "The more X, the more Y" (N3/N4 extension)

```
Formation: verb-ば + same verb plain + ほど

練習すればするほど上手になる。
The more you practice, the better you get.

食べれば食べるほど太る。
The more you eat, the more weight you gain.
```

### The restriction: ば cannot be followed by requests or commands in Y clause

```
✗ 早く来れば、電話してください。  (ば + request = WRONG)
✓ 早く来たら、電話してください。  (たら + request = correct)
```

---

## 〜と — Natural/Automatic Result

### Formation

Plain non-past (dictionary form) + と
```
食べる + と = 食べると
行く + と = 行くと
押す + と = 押すと
右に曲がる + と = 右に曲がると
```

### Core meaning: X automatically leads to Y (no human choice)

This is the conditional for things that ALWAYS happen — laws of nature, 
mechanical processes, automatic sequences, and giving directions:

```
春になると、桜が咲きます。
When spring comes, cherry blossoms bloom. (always — natural law)

このボタンを押すと、ドアが開きます。
When you press this button, the door opens. (mechanical — always)

右に曲がると、コンビニがあります。
If you turn right, there is a convenience store. (directions — factual)

北に行くと、山があります。
If you go north, there are mountains. (geographical fact)
```

### Cannot be used for the speaker's choices or requests in Y clause

```
✗ 春になると、旅行します。  (Y = speaker's future choice — use たら instead)
✓ 春になったら、旅行します。
```

### Discovering something (と as a narrative particle)

```
家に帰ると、猫が逃げていた。
When I got home, I found that the cat had escaped.
(natural discovery upon arriving)
```

---

## 〜なら — Given That / Based on New Information

### Formation

Plain form (any) + なら
```
行く + なら = 行くなら
食べた + なら = 食べたなら
高い + なら = 高いなら
学生 + なら = 学生なら
```

### Core meaning: "given that / based on what I just heard"

なら is the ONLY conditional that responds to information just received.
It says: "Given what you just told me / given that situation..."

```
Context: 「日本に行くんですか？」 (Are you going to Japan?)
Response: 日本に行くなら、京都も行ってみてください。
          If you're going to Japan (since you just told me you are),
          please try going to Kyoto too.
```

The critical point: the speaker didn't know X before the conversation.
They are NOW basing their advice on new information.

```
A: 頭が痛いんですが…  (I have a headache...)
B: 頭が痛いなら、早く帰ったほうがいいよ。
   If you have a headache (since you just told me), you should go home early.
```

### なら for giving advice or making recommendations

```
安い店を探しているなら、あそこがいいよ。
If you're looking for a cheap place (= since you told me you are), that place is good.

日本語を勉強したいなら、毎日練習することだ。
If you want to study Japanese, the key is to practice every day.
```

### なら vs たら for counter-factual / topic

なら can also introduce topics without implying the speaker will do it:
```
ロンドンなら、行ったことがある。
If it's London (you're asking about), I've been there.
(Not "if I go to London" — more like "as for London")
```

---

## Side-by-Side Comparison

```
SCENARIO: "If it rains tomorrow, [...]"

と: 雨が降ると、試合は中止だ。
   → This is a RULE: rain always causes cancellation (automatic)

たら: 雨が降ったら、試合は中止だ。
    → This specific upcoming rain → cancellation (completed condition → result)

ば: 雨が降れば、試合は中止だ。
   → General truth / logical consequence (if rain, then logically = cancelled)

なら: 雨が降るなら、傘を持っていってください。
    → Since you (just) told me it's raining / might rain, take an umbrella
      (advice based on information received from the listener)
```

---

## Request Compatibility — The Y-Clause Rule

This is the most tested point on the N4 exam:

```
Can the Y-clause be a request, command, or intention?

たら    → YES   駅に着いたら、電話してください ✓
ば      → NO    駅に着けば、電話してください ✗
と      → NO    駅に着くと、電話してください ✗
なら    → YES   駅に着くなら、電話してください ✓ (given that situation)
```

Memory trick:
- **たら and なら** = human-related conditionals → allow human choices in Y
- **ば and と** = logical/natural conditionals → Y happens automatically, not chosen

---

## Quick Decision Guide

```
Ask yourself:

Is the result AUTOMATIC (nature, machines, directions)?
  → と

Is this a one-time sequence (A finishes, THEN B)?
  → たら

Is this about a specific request or asking what the listener should do?
  → たら or なら

Am I basing my advice on something the other person JUST told me?
  → なら

Am I describing a hypothetical ideal or a general logical truth?
  → ば

Is the structure "the more X, the more Y"?
  → 〜ばするほど
```
