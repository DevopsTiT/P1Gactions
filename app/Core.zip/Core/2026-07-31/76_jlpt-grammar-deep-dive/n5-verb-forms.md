# N5 Verb Forms and Core Patterns — Deep Dive

---

## The Three Verb Groups (Must Know First)

Before any verb form makes sense, you must know which group a verb belongs to.
The group determines HOW you conjugate every form.

```
Group 1 (U-verbs / godan):  dictionary form ends in う・く・ぐ・す・つ・ぬ・ぶ・む・る
  書く (kaku), 飲む (nomu), 話す (hanasu), 待つ (matsu), 帰る (kaeru)
  → Changes the final vowel sound

Group 2 (RU-verbs / ichidan): dictionary form ends in いる or える
  食べる (taberu), 見る (miru), 起きる (okiru), 寝る (neru)
  → Just remove る and add the ending

Group 3 (Irregular): only TWO verbs
  する (suru) → to do
  くる (kuru) → to come
  → Memorize separately — no pattern
```

---

## 〜ます Form — The Polite Present/Future

### Formation

```
Group 1: change final vowel to い-sound + ます
  書く  →  書き  + ます  =  書きます
  飲む  →  飲み  + ます  =  飲みます
  話す  →  話し  + ます  =  話します
  待つ  →  待ち  + ます  =  待ちます
  帰る  →  帰り  + ます  =  帰ります

Group 2: remove る + ます
  食べる  →  食べ  + ます  =  食べます
  見る    →  見    + ます  =  見ます

Group 3: irregular
  する   →  します
  くる   →  きます
```

### The Four Polite Forms

```
Affirmative present/future:  〜ます      食べます       I eat / will eat
Negative present/future:     〜ません    食べません     I don't eat / won't eat
Affirmative past:            〜ました    食べました     I ate
Negative past:               〜ませんでした 食べませんでした  I didn't eat
```

### When Japanese uses "present" for "future"

Japanese does not have a separate future tense. Context and time words carry that meaning:
```
明日食べます。      (I will eat tomorrow — future, same form)
今食べます。        (I'm eating now — present, same form)
毎日食べます。      (I eat every day — habitual, same form)
```

---

## 〜て Form — The Most Versatile Form

The て form is used to: connect sequential actions, make requests, express ongoing states, and build compound patterns (〜ている, 〜てください, 〜てもいい, etc.)

### Formation

```
Group 1:
  〜く → いて:    書く → 書いて
  〜ぐ → いで:    泳ぐ → 泳いで
  〜す → して:    話す → 話して
  〜つ → って:    待つ → 待って
  〜む → んで:    飲む → 飲んで
  〜ぬ → んで:    死ぬ → 死んで
  〜ぶ → んで:    飛ぶ → 飛んで
  〜る → って:    帰る → 帰って
  EXCEPTION:  行く → 行って  (not 行いて)

Group 2: remove る + て
  食べる → 食べて
  見る   → 見て

Group 3:
  する → して
  くる → きて
```

### Use 1: Connecting sequential actions

```
起きて、顔を洗って、朝ごはんを食べます。
Wake up, wash my face, and eat breakfast.
(Actions happen in ORDER — て marks the sequence)
```

Compare: くて connects adjectives simultaneously, not in sequence:
```
この部屋は広くて、明るい。  (spacious AND bright at the same time)
```

### Use 2: Cause/reason (informal)

```
風邪をひいて、学校を休んだ。
I caught a cold and (because of that) missed school.
(て here implies the first action caused the second)
```

---

## 〜ている — The Most Important Two-Meaning Form

〜ている looks simple but has two completely different meanings depending on verb type.

### Meaning 1: Action in progress (action verbs)

For verbs that describe ACTIONS, 〜ている = currently doing:
```
今、ご飯を食べています。      (I am currently eating right now.)
彼女は本を読んでいます。      (She is reading a book right now.)
雨が降っています。            (It is raining.)
```

### Meaning 2: Resulting state (change-of-state verbs)

For verbs that describe a CHANGE (arrive, marry, die, put on, know), 〜ている = the state that resulted from that change:
```
結婚しています。    NOT "is currently getting married"
                    MEANS: got married (and is now IN that state) = is married

知っています。      NOT "is currently knowing"
                    MEANS: came to know and still knows = knows

死んでいます。      NOT "is currently dying"
                    MEANS: died and is now dead = is dead

窓が開いています。  NOT "the window is in the process of opening"
                    MEANS: the window was opened and is now OPEN = is open

眼鏡をかけています。  = is wearing glasses (put them on → now wearing them)
```

### The trap: 〜ている for habitual actions

```
毎朝ジョギングしています。  (I run every morning — habitual, not right-now)
日本語を勉強しています。    (I am studying Japanese — ongoing activity, period)
```

---

## 〜たい — Wanting to Do

Formation: verb stem + たい (conjugates like い-adjective)
```
食べる → 食べたい  (want to eat)
行く   → 行きたい  (want to go)
見る   → 見たい    (want to see)
```

Negative: 〜たくない
```
食べたくない  (don't want to eat)
```

Past: 〜たかった
```
行きたかった  (wanted to go)
```

### Critical rule: Subject must be the speaker (or close)

たい expresses YOUR OWN desires only. For a third person, use 〜たがっている:
```
私は日本に行きたい。      (I want to go — ✓ first person)
彼は日本に行きたがっている。 (He seems to want to go — ✓ third person via たがる)
彼は日本に行きたい。      (✗ Cannot express another person's inner desire directly)
```

---

## 〜てください — Polite Request

Formation: て form + ください
```
書いてください。    Please write.
待ってください。    Please wait.
来てください。      Please come.
```

Negative request (please don't): 〜ないでください
```
走らないでください。  Please don't run.
```

Softer requests (degrees of politeness):
```
〜てくれませんか？           Could you...? (casual-polite)
〜てもらえませんか？         Could you...? (polite)
〜ていただけませんか？       Could you...? (formal keigo)
〜ていただけますでしょうか？  Could you please...? (most formal)
```

---

## 〜てもいいですか — Asking Permission

Formation: て form + もいいですか
```
ここに座ってもいいですか？   May I sit here?
写真を撮ってもいいですか？   May I take a photo?
```

Granting permission:
```
はい、座ってもいいですよ。   Yes, you may sit.
どうぞ。                     Please go ahead.
```

Refusing permission:
```
すみません、座ってはいけません。  Sorry, you may not sit here.
ちょっと困ります。                That would be a bit of a problem. (soft refusal)
```

---

## 〜てはいけません — Prohibition

Formation: て form + はいけません (polite) / はだめです (casual)
```
ここでタバコを吸ってはいけません。  (You must not smoke here.)
廊下を走ってはいけません。         (You must not run in the hallway.)
```

Casual: 〜てはだめ
```
ここで食べてはだめ。  (You can't eat here — casual)
```

---

## い-Adjectives: All Forms at N5

### The い-adjective conjugation table

```
                Positive          Negative
Present:        面白い            面白くない
Past:           面白かった        面白くなかった
て-form:        面白くて          (connect adjectives)
Adverb:         面白く            (modifies verbs)
```

```
この映画は面白い。          This movie is interesting.
昨日の映画は面白かった。    Yesterday's movie was interesting.
あまり面白くない。          Not very interesting.
映画は面白くなかった。      The movie wasn't interesting.
面白くて、長い映画だ。      An interesting and long movie.
面白く話す。                Speak interestingly.
```

### IRREGULAR い-adjective: いい (good)

いい is irregular — its conjugated forms use よい:
```
いい → よかった (was good — NOT いかった ✗)
いい → よくない (not good — NOT いくない ✗)
いい → よくなかった (was not good)
```
```
昨日の天気はよかった。  Yesterday's weather was good.
全然よくない。          Not good at all.
```

---

## な-Adjectives: All Forms at N5

な-adjectives behave more like nouns. They use だ (plain) or です (polite) to conjugate:

```
                Positive          Negative
Present:        静かだ            静かじゃない / 静かではない
Past:           静かだった        静かじゃなかった
て-form:        静かで            (connect to next clause)
Noun modifier:  静かな + noun     (need な before a noun)
```

```
この図書館は静かだ。        This library is quiet.
昨日は静かだった。          Yesterday was quiet.
全然静かじゃない。          Not quiet at all.
静かな部屋が好きだ。        I like quiet rooms. (+ な before noun)
静かで、きれいな部屋だ。    A quiet and clean room. (で connects)
```

---

## Core Sentence Patterns at N5

### いる vs ある — Existence

```
いる = animate beings (people, animals)
ある = inanimate things (objects, plants, abstract things)

公園に子供がいる。         (Children are in the park.)
公園に木がある。           (There are trees in the park.)
公園に花がある。           (There are flowers in the park.)

BUT: 公園に友達がいる。    (My friend is in the park — person = いる)
     公園に自転車がある。   (There is a bicycle in the park — thing = ある)
```

### より〜のほうが — Comparing Two Things

```
Formation: [A] より [B] のほうが [adjective/verb]

犬より猫のほうが好き。     (I like cats more than dogs.)
電車よりバスのほうが安い。 (Buses are cheaper than trains.)
```

Asking which is better:
```
AとBとどちらのほうが好きですか？  (Which do you like better, A or B?)
```

### ましょう / ましょうか — Suggestions

ましょう = strong "let's" (speaker has already decided)
ましょうか = softer "shall we?" (checking if the listener agrees)
```
行きましょう。      Let's go. (speaker is decided)
行きましょうか？    Shall we go? (checking with listener)
手伝いましょうか？  Shall I help you? (offering help)
```
