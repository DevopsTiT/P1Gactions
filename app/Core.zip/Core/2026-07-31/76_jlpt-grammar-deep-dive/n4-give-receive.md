# N4 Giving and Receiving — Deep Dive: あげる・もらう・くれる

> This system is unique to Japanese and has no direct English equivalent.
> English uses one word "give" for multiple situations. Japanese uses three,
> depending on the direction of giving relative to the speaker.

---

## Why Japanese Has Three Words Where English Has One

In Japanese, the verb you choose depends on:
1. Who is giving?
2. Who is receiving?
3. Is the receiver the speaker (or in the speaker's group)?

```
あげる = I/we give TO someone outside my group
もらう = I/we receive FROM someone
くれる = someone outside gives TO me/us
```

The key distinction: **is the receiver in the speaker's group (I/we/my family) or outside?**

---

## The Three Core Verbs (Objects — Things)

### あげる — Give (outward — away from speaker)

The speaker (or someone in their group) gives to someone OUTSIDE their group.
The flow is: speaker → someone else

```
私は友達にプレゼントをあげた。
I gave a present to my friend.
(I = giver, friend = receiver — friend is outside my group → あげる)

先生は学生に本をあげた。
The teacher gave a book to the student.
(Seen from a neutral perspective — teacher → student)
```

**CANNOT use あげる when the receiver is the speaker:**
```
✗ 先生は私にあげた。  (teacher gives TO me — this is くれる, not あげる)
✓ 先生は私にくれた。
```

### もらう — Receive (the speaker gets something)

The speaker (or someone in their group) receives from someone else.
The focus is on the RECEIVER's perspective.

```
私は友達にプレゼントをもらった。
I received a present from my friend.
(I = receiver — my perspective)

彼女は彼氏に花をもらった。
She received flowers from her boyfriend.
(Told from her perspective — she received)
```

**Note the particle:** The giver is marked with に (from) or から (from — emphasis on source):
```
先生にもらった。  OR  先生からもらった。  (I received from the teacher)
```

### くれる — Give (inward — toward the speaker)

Someone OUTSIDE the speaker's group gives to the speaker (or their group).
The flow is: someone else → speaker/my group

```
友達が私にプレゼントをくれた。
My friend gave me a present.
(Friend = giver, I = receiver — gift comes TO me → くれる)

先生が私に本をくれた。
The teacher gave me a book.
(Teacher → me)
```

**くれる requires the receiver to be the speaker or someone in their group:**
```
田中さんが子供にお菓子をくれた。
Tanaka gave candy to (my/our) child.
(Child = member of speaker's family → くれる is correct)
```

---

## Diagram: The Direction of Giving

```
          あげる
 [ME] ──────────────→ [THEM]

          もらう
 [ME] ←────────────── [THEM]

          くれる
 [ME/MY GROUP] ←────── [THEM]
```

---

## て-Form Verbs: Giving and Receiving ACTIONS

The same three verbs attach to the て-form of other verbs to express doing a FAVOR.
This is where the system gets very powerful.

### 〜てあげる — Do a favor for someone (you do it FOR them)

The speaker does an action as a favor for someone else.
```
荷物を持ってあげた。
I carried the luggage for them. (I did the action as a favor)

宿題を手伝ってあげた。
I helped them with their homework. (for them)

道を教えてあげた。
I told them the way. (for their benefit)
```

**Social nuance:** てあげる can sound condescending if used carelessly.
Saying 「してあげますよ」to your boss would be very rude — it implies you're doing
them a favor from a position of superiority. Use it for people of lower status,
close friends, or children.

### 〜てもらう — Have someone do something for you (you benefit)

Someone does an action and the speaker BENEFITS.
Focus is on the speaker as recipient of the favor.
```
先生に説明してもらった。
I had the teacher explain it to me. (I received the explanation)

友達に写真を撮ってもらった。
I had my friend take a photo of me.

医者に診てもらった。
I had the doctor examine me.
```

**Key feeling:** もらう emphasizes RECEIVING BENEFIT. The speaker is grateful.
This is frequently used to express getting help from someone:
```
このことについて、もう少し詳しく話してもらえますか？
Could you tell me a bit more about this matter?
(Could I receive the action of you telling me more?)
```

### 〜てくれる — Someone does a favor for you (they do it FOR you)

Someone else does an action and the SPEAKER benefits.
Focus is on the giver's action and the speaker receiving it.
```
友達が助けてくれた。
My friend helped me. (they did it for me — I benefited)

母が弁当を作ってくれた。
My mother made a bento for me. (she did it for my benefit)

先生が丁寧に説明してくれた。
The teacher explained carefully (for me / for our class).
```

**Key feeling:** くれる emphasizes appreciation. The speaker is describing a kind act received.
```
彼がドアを開けてくれた。
He opened the door for me. (kind act, speaker received it)
```

---

## The Politeness Upgrade: Keigo Versions

```
あげる   → さしあげる  (humble — I give to someone of higher status)
もらう   → いただく    (humble — I receive from someone of higher status)
くれる   → くださる    (honorific — they give to me [respectfully])
```

```
先生に本をさしあげました。
I gave a book to the teacher. (humbly — I gave to my superior)

先生に本をいただきました。
I received a book from the teacher. (humbly — I received from my superior)

先生が本をくださいました。
The teacher gave me a book. (respectfully — teacher gave to me)
```

---

## て-Form Requests: もらえますか / くれますか

These are polite requests built on the give/receive system:

```
手伝ってくれますか？         Could you help me? (casual)
手伝ってもらえますか？       Could you help me? (polite)
手伝っていただけますか？     Could you help me? (formal keigo)
手伝っていただけますでしょうか？ Could you please help me? (most formal)
```

**Why these work:** You're asking the listener to "give you" the action of helping.
くれる = they give to you; もらう = you receive from them — both frame the request
as receiving a favor, which is grammatically and socially correct.

---

## Common Mistakes

### Mistake 1: Using あげる when the receiver is the speaker

```
✗ 先生は私にプレゼントをあげた。
✓ 先生は私にプレゼントをくれた。
  (teacher → me = くれる, not あげる)
```

### Mistake 2: Using くれる when the receiver is a third party

```
✗ 田中さんは山田さんにプレゼントをくれた。
  (Tanaka → Yamada — neither is the speaker → no くれる)
✓ 田中さんは山田さんにプレゼントをあげた。
```

### Mistake 3: Forgetting the で/から particle with もらう

```
✗ 先生もらった。  (no particle)
✓ 先生にもらった。  OR  先生からもらった。
```

### Mistake 4: てあげる with social superiors

```
✗ 部長に資料を持ってあげました。
  (carrying bags for your boss using あげる sounds patronizing)
✓ 部長に資料をお持ちしました。
  (use humble form お〜する instead)
```

---

## Quick Decision: Which Verb?

```
Who is the giver?           Who is the receiver?        Use:
──────────────────────────────────────────────────────────────
Me / my group              Someone outside              あげる
Someone outside            Me / my group                くれる
Someone outside            Me (receiving)               もらう
(viewed from receiver's side)

For actions (favor):
I do the action            For someone else             〜てあげる
Someone does the action    For me (I benefit)           〜てくれる
I receive the action       From someone else            〜てもらう
```
