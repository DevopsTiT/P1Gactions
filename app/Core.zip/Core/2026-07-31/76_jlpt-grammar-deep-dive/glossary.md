# JLPT Grammar Deep Dive: Glossary

Every grammatical term used across all deep-dive files, explained for a beginner.

---

**Particle (助詞 じょし)**
A short word attached after a noun or verb that shows its grammatical role. Japanese uses particles instead of word order. は marks topic, が marks subject, を marks object. Particles are not optional.

**Topic (は)**
What the sentence is "about." The topic doesn't have to be the subject. は says "speaking of X, here is what I want to say about it." Multiple sentences in a conversation can share the same topic without repeating it.

**Subject (が)**
The grammatical actor or experiencer in the sentence. Used to introduce new information, with feeling/ability adjectives (好き、できる), inside relative clauses, and for emphasis ("it is X that").

**Transitive verb (他動詞 たどうし)**
A verb that acts ON something — takes a direct object marked with を. 食べる, 飲む, 書く. Required for てある (someone did it to something).

**Intransitive verb (自動詞 じどうし)**
A verb describing a state or event without acting on an object. 起きる, 開く, 始まる. These cannot take を or be used with てある.

**Volitional verb**
An action the subject CHOOSES to do. 行く, 勉強する, 食べる. Used with ために for purpose ("in order to"). Contrasts with non-volitional verbs/states.

**Non-volitional verb / state**
Something that happens naturally beyond the speaker's control. 病気になる, 眠くなる, 雨が降る. Used with ために for cause ("because of"), and ように for hope/request.

**て-form (連用形 れんようけい)**
The verb form ending in て or で. Used to connect clauses, make requests (〜てください), build compound patterns (〜ている, 〜てある, 〜てしまう, etc.). Essential — every N5-N2 grammar point connects to it.

**Stem form (ます-stem)**
The verb form before ます. 食べ, 行き, 起き. Used for 〜に行く/来る (go/come to do), 〜ながら (while), 〜次第 (as soon as), and compound verbs.

**NAI-form**
The plain negative form of a verb: 食べない, 行かない, しない. Used in ざるを得ない (remove ない), ずにはいられない (remove ない), and many obligation patterns.

**Plain form (普通形 ふつうけい)**
The casual/dictionary form: 食べる, 高い, 静かだ. Used before most N2-N3 grammar patterns as the base.

**Nominalizer (名詞化)**
Converting a verb or clause into a noun using こと or の. 食べること = "eating" (as a noun concept). Needed before patterns like ことがある, ことにする, ことになる.

**Concession (逆接 ぎゃくせつ)**
Grammar that says "even though X, Y." Used when the result contradicts what X would normally lead to. Key patterns: ても (neutral), のに (disappointed), にもかかわらず (formal), ものの (soft), とはいえ (that said).

**Expectation (予期 よき)**
What the speaker logically expects to be true. はずだ = logic-based expectation. にちがいない = strong conviction. でしょう = soft probability.

**Conjecture (推量 すいりょう)**
The speaker's guess about something uncertain. かもしれない (50/50), でしょう (probably), らしい (apparently), ようだ (seems based on observation), そうだ/appearance (looks like).

**Hearsay (伝聞 でんぶん)**
Information the speaker received from someone else — not personally witnessed. そうだ(hearsay) = I heard that. らしい = apparently/I've gathered from indirect signs. によると = according to.

**Cause vs Purpose (原因 vs 目的)**
ために can mean either: purpose when volitional verb precedes (in order to), or cause when non-volitional precedes (because of). Context decides. Examtrap: 病気のために (cause) vs 合格するために (purpose).

**Sequential action**
Two events that happen one after the other. て-form connects them in order: 起きて、歯を磨いて、朝ごはんを食べた (woke up → brushed teeth → ate). たら also expresses completed first event → second event.

**Simultaneous action**
Two events happening at the same time. ながら = while (doing two things at once): 音楽を聴きながら勉強する. Different from sequential て-form.

**Resulting state (結果状態)**
The state that remains AFTER an action completes. ている with change-of-state verbs: 結婚している (is married = got married and is still in that state). てある: 窓が開けてある (the window has been opened and is still open).

**Scope (範囲 はんい)**
How much or how far. だけ = only (neutral). しか〜ない = only (emphasizes insufficiency). に過ぎない = nothing more than. 限り = as long as / as far as.

**Degree (程度 ていど)**
How much. ほど = to the extent that. あまり = so much that (excess → unexpected result). だけあって = as expected (merit justified). だけに = all the more because.

**Logical conclusion (論理的結論)**
A natural/inevitable conclusion drawn from information. わけだ = that explains it / no wonder. ということだ = which means / so it means. Therefore-feeling.

**Obligation (義務 ぎむ)**
Something you must do. なければならない = simple obligation. ざるを得ない = no choice (external force). わけにはいかない = social/moral circumstances prevent avoiding it.

**Irresistible urge (衝動)**
ずにはいられない = internal compulsion you cannot suppress. The feeling comes from within and cannot be resisted, even if you want to.

**Concessive conditional**
"Even if X, Y" — Y happens regardless of X. ても: 雨が降っても行く (even if it rains, I'll go). Different from standard conditional which says "if X then Y."

**Embedded conditional (〜なら)**
A conditional that responds to information received from the listener. "Given that you just told me X..." Unlike たら/ば/と which set up hypothetical situations, なら responds to actual information.

**Automatic result (〜と)**
When X naturally and always leads to Y — no human choice involved. Laws of nature, mechanical processes, directions. 春になると桜が咲く (when spring comes, cherry blossoms bloom — always). Cannot follow this with requests or intentions.

**Hypothetical (〜ば)**
An idealized or logical condition. Often implies the current reality is different from the condition. 練習すればうまくなれる (if you practiced, you could get good — implying you're not practicing enough).

**Passive voice (受身 うけみ)**
A sentence form where the recipient of an action becomes the subject. 食べられた = was eaten. Japanese has two special passive types: adversative (speaker is inconvenienced by someone's action: 雨に降られた) and indirect (speaker is affected by an action done to their possession: 財布を盗まれた).

**Causative-passive (使役受身 しえきうけみ)**
Being forced to do something. Formation: verb stem + させられる. 残業させられた = I was forced to work overtime. Expresses that the speaker did the action against their will.

**Keigo (敬語 けいご)**
The Japanese honorific language system. Three types: sonkeigo (尊敬語 — raises others' status, describes their actions), kenjōgo (謙譲語 — lowers your own status, describes your own actions toward superiors), teineigo (丁寧語 — basic です/ます politeness).

**Sonkeigo (尊敬語)**
Honorific verbs used when describing someone else's (social superior's) actions. いらっしゃる (be/go/come), おっしゃる (say), 召し上がる (eat/drink), なさる (do). You use these to show respect for the subject.

**Kenjōgo (謙譲語)**
Humble verbs used when describing YOUR OWN actions to a social superior. 参る (go/come), 申す (say), いたす (do), いただく (eat/receive), 拝見する (see). You use these to lower your own position.

**Teineigo (丁寧語)**
Basic politeness using です and ます. Not tied to social hierarchy — just general politeness appropriate for strangers, colleagues, formal situations.

**Formality scale**
From casual to formal: から→ので→ため→ゆえに (reason); ても→のに→ながらも→にもかかわらず (concession); で→において (location context); について→に関して (regarding).

**Compound verb (複合動詞 ふくごうどうし)**
Two verb stems joined to create a new meaning. 書き直す (rewrite), 飛び込む (jump into), 取り出す (take out). Common at N3/N2. Meaning is not always predictable from the parts.

**Auxiliary verb (補助動詞 ほじょどうし)**
A verb that follows the て-form and modifies the main verb's meaning. おく (preparation), ある (intentional result), しまう (completion/regret), くる (toward present), いく (toward future). The auxiliary carries the grammatical meaning.

**Serial verb (継続表現)**
A grammatical pattern showing an action continues over time. ていく (continues into future), てくる (has been ongoing up to now), ている (currently ongoing). Direction matters: くる = toward now, いく = away into future.

**Reported speech (引用 いんよう)**
Quoting what someone said or thought. と言う, と思う, そうだ (hearsay). The quoted content appears in plain form before と or そうだ.

**N2 formal register (書き言葉 かきことば)**
Patterns used primarily in written Japanese: において, に関して, にわたって, をはじめ, に際して, をめぐって, に基づいて. These replace casual particles (で→において, について→に関して) in news, academic, and business writing.

**Urgency (緊急性)**
A feature of うちに — the situation is temporary and will change, so you must act before the window closes. 若いうちに (while still young), 熱いうちに (while still hot), 忘れないうちに (before you forget).

**Culmination (到達点)**
末に = the endpoint reached after a significant process. The journey was long; the result is the culmination of effort. Used with long processes: 長年の研究の末に (after years of research), 悩んだ末に (after agonizing deliberation).

**Ironic/negative outcome (残念な結果)**
あげくに often implies the final result is disappointing given all the effort spent. 散々悩んだあげくに (after all that agonizing → disappointing result). Contrasts with 末に which can be positive.
