# N3 State and Result Patterns — Deep Dive
## てある・ておく・てしまう・てくる・ていく

> Five compound verb patterns. All start with て-form + auxiliary verb.
> Each changes the meaning of the main verb dramatically.

---

## Why These Five Are Grouped Together

All five attach to the て-form and modify what the action MEANS in terms of:
- Who is responsible for the state
- Whether it was intentional
- How the result relates to time (past/future/ongoing/direction)

---

## 〜てある — "Has Been Done Intentionally (and the Result Remains)"

### Formation

[Transitive verb て-form] + ある

### Core meaning

Someone intentionally performed an action, and the RESULT of that action is still visible now.
The focus is on the current state as evidence of an intentional past action.

```
窓が開けてある。
The window has been opened (and remains open).
(Someone intentionally opened it — it's still open now)

黒板に今日の予定が書いてある。
Today's schedule has been written on the blackboard.
(Someone wrote it intentionally — it's still there)

テーブルの上に食事が準備してある。
The meal has been prepared on the table.
(Someone prepared it — it's ready and waiting)
```

### Key features

**1. The object is marked with が (subject-like) or を:**
```
窓が開けてある。 (窓 is the object of 開ける, but marked が with てある)
テーブルに食事が準備してある。
```

**2. ONLY transitive verbs work with てある**
(transitive = takes a direct object)
```
✓ 開ける (open something) → 開けてある  (someone opened it)
✗ 開く   (open — intransitive, no object) → ✗ 開いてある → use 開いている instead
```

**3. Contrasted with ている:**
```
窓が開いている。  (The window is open — describes the current state neutrally)
窓が開けてある。  (The window has been opened — someone did it intentionally for a reason)
```

The てある version implies REASON or PURPOSE behind the action:
"Someone opened the window for ventilation / for our arrival / on purpose."

---

## 〜ておく — "Do in Advance / Do for Future Use"

### Formation

[Verb て-form] + おく

### Core meaning

Do something NOW in preparation for future needs, or to maintain a state for future convenience.
おく (置く = to place, to leave as is) carries the idea of "put it in place for later."

```
パーティーの前に料理を作っておく。
I'll make food in advance before the party.
(Prepare now → convenient when party starts)

出発前に地図を調べておいた。
I checked the map in advance before departing.
(Did it beforehand so I'd be ready)

知らせをもらったので、上司に報告しておきました。
I received the news, so I reported it to my boss in advance.
(Took care of it so it wouldn't become a problem later)
```

### The casual contraction: 〜とく / 〜といた

In casual speech, ておく → とく / ておいた → といた:
```
資料を準備しておく → 資料を準備しとく  (casual)
メモしておいた → メモしといた  (casual past)
```

### Nuance: "just leave it as is"

ておく also means "leave it in the current state" (don't change it):
```
このままにしておいてください。
Please leave it as it is.

捨てないで、取っておいてください。
Please keep it (don't throw it away).
```

---

## 〜てしまう — Two Meanings: Completion vs Regret

### Formation

[Verb て-form] + しまう

### Meaning 1: Complete entirely / finish fully

Emphasizes that the action is done COMPLETELY, with a sense of finality.
Often used with positive actions that the speaker worked to complete:

```
宿題を全部やってしまった。
I finished all of my homework. (completely done — relief/satisfaction)

この本を今日中に読んでしまおう。
Let's finish reading this book today. (complete it fully)
```

### Meaning 2: End up doing / unfortunately happened (regret)

The action happened accidentally, unintentionally, or against the speaker's wishes.
There is a sense of regret or unintended consequence:

```
財布を忘れてしまった。
I ended up forgetting my wallet. (not on purpose — regret)

彼に秘密を話してしまった。
I ended up telling him the secret. (accidentally/against my intentions)

遅刻してしまいました。申し訳ありません。
I ended up being late. I'm so sorry. (unintended — apologetic)

食べ過ぎてしまった。
I ended up overeating. (ate more than I intended)
```

### How to tell the meanings apart

Context is the main guide:
- If the result is DESIRABLE → completion nuance (宿題を全部やってしまった ✓)
- If the result is UNDESIRABLE → regret nuance (遅刻してしまった ✓)
- Context words like 「うっかり」(carelessly), 「つい」(without thinking), 「残念ながら」point to regret

### The casual contraction: 〜ちゃう / 〜じゃう

In casual speech, てしまう → ちゃう / でしまう → じゃう:
```
忘れてしまった → 忘れちゃった  (casual)
飲んでしまった → 飲んじゃった  (casual)
```

---

## 〜てくる — Movement/Change Toward the Present

### Formation

[Verb て-form] + くる

くる = to come. So てくる = action "comes" toward the speaker in time or space.

### Meaning 1: Go and come back (physical return)

```
買い物してきます。
I'll go shopping and come back.
(Go out → do the shopping → return)

郵便局に手紙を出してきた。
I went and mailed the letter (and came back).
```

### Meaning 2: Change approaching the present (time coming toward now)

A change that has been happening and has now reached the present moment:
```
だんだん暗くなってきた。
It has gradually gotten dark.
(Darkness increased and is now reaching the present — felt just now)

最近、日本語が話せるようになってきた。
Lately, I've been getting able to speak Japanese.
(Gradual improvement arriving at the present)

寒くなってきたね。
It's gotten cold, hasn't it.
(Change coming toward now — first noticed)
```

### Meaning 3: A state has been going on and continues now

```
ずっと日本語を勉強してきた。
I have been studying Japanese all along (up to now).
(Activity continuing from past toward present)
```

---

## 〜ていく — Movement/Change Away from the Present

### Formation

[Verb て-form] + いく

いく = to go. So ていく = action "goes away" from the speaker in time or space.

### Meaning 1: Go and do something (physical movement away)

```
弁当を持っていく。
I'll take a bento with me (when I go).
(Take it along as I move away)

傘を持っていってください。
Please take an umbrella with you.
```

### Meaning 2: Change moving away into the future

A change that starts now and continues forward into the future:
```
これからも頑張っていきます。
I will continue to do my best from now on.
(Effort extends into the future — going forward)

気温がだんだん下がっていくだろう。
The temperature will gradually decrease.
(Change moving into the future)

この技術は今後も発展していくと思う。
I think this technology will continue to develop going forward.
```

---

## てくる vs ていく — The Direction of Time

```
てくる = change/action comes FROM THE PAST toward the PRESENT (arriving now)
ていく = change/action goes FROM THE PRESENT toward the FUTURE (going forward)

PAST ──────────────────[NOW]──────────────────> FUTURE

         ←── てくる ──── [NOW]
                              [NOW] ──── ていく ──→
```

```
暑くなってきた。  (It has become hot — the heat arrived at the present)
暑くなっていく。  (It will become hot — the heat will continue into the future)

だんだん日本語が上手になってきた。
  (Gradually I've gotten good at Japanese — improvement reached now)
  
これから日本語をもっと上手になっていきたい。
  (From now on I want to get better at Japanese — going forward)
```

---

## Five-Pattern Comparison Chart

```
窓を開ける (to open a window) — how each pattern changes it:

〜てある:  窓が開けてある。
           The window has been opened (intentionally; result remains visible)

〜ておく:  窓を開けておく。
           I'll open the window in advance (for later convenience)

〜てしまう: うっかり窓を開けてしまった。
            I accidentally opened the window (didn't mean to — regret)

〜てくる:  窓を開けてくる。
           I'll go open the window (and come back)

〜ていく:  窓を開けていく。
           I'll open the window (as I go / leave it open when I leave)
```

---

## Exam Traps

**Trap 1: てある vs ている for states**
```
窓が開いている。   (The window is open — neutral state description)
窓が開けてある。   (The window has been opened intentionally — someone did it on purpose)
→ てある implies a human agent and a reason behind the state
```

**Trap 2: てしまう for regret vs completion**
```
食べてしまった。
→ If after a diet: I ended up eating (regret)
→ If after hard work: I finished eating (completion)
Context determines meaning.
```

**Trap 3: てくる vs てくる (physical vs temporal)**
```
食べてくる。    (Go eat and come back — physical movement)
食べてきた。    (I've been eating — has been going on up to now — temporal)
Both are てくる but different meanings based on context.
```
