# N2 Formal Written Patterns — Deep Dive
## において・に関して・に基づいて・にわたって・を通じて・をめぐって・に際して・をはじめ・をもとに・に反して

> These patterns appear constantly in news articles, academic writing, business emails,
> and formal speeches. They are the grammar of WRITTEN Japanese.
> In conversation, simpler alternatives (で、について、など) are preferred.

---

## Why These Patterns Exist

Formal written Japanese has different norms from spoken Japanese:
- More precise about scope (にわたって covers "spanning the whole range")
- More impersonal (に反して rather than と違って)
- Avoids casual particles (において instead of で for formal location)

Learning these patterns transforms your ability to read newspapers, NHK Web Easy,
JLPT reading passages, and official documents.

---

## 〜において / 〜における — "In / At (Formal)"

### Core meaning

において is the formal, written version of で (location of action/context).
It emphasizes that X is the CONTEXT or DOMAIN in which something occurs.

### Formation

```
[Noun] + において + [statement]
[Noun] + における + [following noun]
```

### Examples

```
現代社会において、スマートフォンは必需品だ。
In modern society, smartphones are a necessity.
(Context/domain: modern society)

医療の分野において、AIの活用が進んでいる。
In the field of medicine, the use of AI is advancing.

オリンピックにおける日本選手の活躍は目覚ましい。
Japan's athletes' performance at the Olympics has been remarkable.
(における + noun: "X's performance IN the Olympics")

この問題における最大の課題は何か。
What is the biggest challenge IN this problem?
```

**The key difference: で vs において**
```
学校で日本語を勉強する。  (で — casual/neutral action location)
学校における日本語教育の問題  (において — formal: "issues in Japanese education at schools")
```

において is about DOMAIN/CONTEXT. で is about physical/immediate location.
Use において when writing about social issues, fields of study, events, eras.

---

## 〜に関して / 〜に関する — "Regarding / Concerning (Formal)"

### Core meaning

に関して = more formal than について (which also means "about/concerning").
Often used in formal requests, official correspondence, academic writing.

### Formation

```
[Noun] + に関して + [statement]
[Noun] + に関する + [following noun]
```

### Examples

```
この件に関しては、後日ご連絡いたします。
Regarding this matter, I will contact you at a later date.

環境問題に関する報告書が提出された。
A report concerning environmental issues was submitted.

税制に関して、政府は新しい方針を発表した。
Regarding tax policy, the government announced a new direction.
```

**について vs に関して:**
```
この問題について話し合いましょう。
(Let's talk about this issue — neutral/conversational)

この問題に関して、詳細な調査が必要だ。
(Regarding this issue, a detailed investigation is necessary — formal)
```

に関して is preferred in official, academic, or business contexts.
について works everywhere but sounds less formal.

---

## 〜に基づいて — "Based On / In Accordance With"

### Core meaning

に基づいて = "using X as the foundation/basis for decision or action."
Used with data, evidence, rules, laws, research, principles.

### Formation

```
[Noun] + に基づいて + [action/statement]
[Noun] + に基づく + [following noun]
```

### Examples

```
科学的データに基づいて判断する。
Make judgments based on scientific data.

法律に基づいて処罰が行われた。
Punishment was carried out in accordance with the law.

調査結果に基づく新しい方針が決定された。
A new policy based on survey results was determined.

事実に基づいた報告を書いてください。
Please write a report based on facts.
```

**〜に基づいて vs 〜をもとに:**
```
に基づいて = based on (rules, data, evidence, formal sources)
をもとに   = based on / using as source material (stories, experiences, ideas)

法律に基づいて判断する。 (law = formal basis — に基づいて)
実話をもとに映画を作った。 (true story = material → をもとに)
```

---

## 〜にわたって / 〜にわたる — "Spanning / Over (A Range)"

### Core meaning

にわたって = extends over a range of time, space, or categories.
Emphasizes BREADTH or DURATION — the thing covers the whole range mentioned.

### Formation

```
[Time/space noun] + にわたって + [statement about spanning]
[Time/space noun] + にわたる + [following noun]
```

### Examples

```
3日間にわたって会議が行われた。
The conference was held over a span of 3 days.

長年にわたる研究の成果が発表された。
The results of years of research were announced.
(にわたる + noun: "research spanning many years")

全国にわたって調査が実施された。
A survey was conducted spanning the entire country.

3つの分野にわたる問題について話し合った。
We discussed issues spanning 3 fields.
```

**Time-specific note:**
にわたって is used when emphasizing the BREADTH of coverage — not just the duration.
For simple duration, ～の間/～かけて is more natural:
```
3日間で完成した。 (finished in 3 days — duration only)
3日間にわたって交渉が行われた。 (spanning 3 days — emphasizes the whole period)
```

---

## 〜を通じて / 〜を通して — "Through / Throughout"

### Core meaning (Two uses)

**Use 1: Via / through (a means/medium)**
```
インターネットを通じて情報を集める。
Gather information through the internet.

友人を通じて仕事を紹介してもらった。
I was introduced to a job through a friend.

教育を通して、社会を変えることができる。
Through education, we can change society.
```

**Use 2: Throughout (a whole period/range)**
```
一年を通じて温暖な気候だ。
It has a warm climate throughout the year.

その歌手は活動を通じて多くのファンを獲得した。
Through their activities, the singer gained many fans.
```

**を通じて vs を通して:**
Both are largely interchangeable. を通じて is slightly more formal.
In set phrases: 一年を通じて (throughout the year) — through じて is more fixed.

---

## 〜をめぐって / 〜をめぐる — "Over / Around (Contested Issue)"

### Core meaning

をめぐって is used specifically when people are ARGUING, debating, or struggling over something.
It implies the topic is CONTESTED or at the center of conflict.

### Formation

```
[Noun (contested topic)] + をめぐって + [debate/struggle statement]
[Noun] + をめぐる + [following noun]
```

### Examples

```
その法案をめぐって、激しい議論が起きた。
A fierce debate arose over that bill.

領土問題をめぐって、両国の関係が悪化している。
Relations between the two countries are deteriorating over the territorial dispute.

遺産をめぐる争いが法廷に持ち込まれた。
The dispute over the inheritance was brought to court.
(をめぐる + noun: "dispute OVER the inheritance")
```

**The contested nature:** をめぐって is NOT neutral.
You wouldn't use it for non-controversial topics:
```
✗ 天気をめぐって話した。 (weather is not contested — use について)
✓ 政策をめぐって議論した。 (policy can be contested — ✓)
```

---

## 〜に際して — "On the Occasion Of / At the Time Of"

### Core meaning

に際して = at a special, significant moment — treating the event as a formal occasion.
More formal than 〜とき. Implies the occasion deserves attention or preparation.

### Formation

```
[Noun] + に際して + [action/statement]
[Verb dictionary form] + に際して
```

### Examples

```
卒業に際して、一言ご挨拶申し上げます。
On the occasion of graduation, I would like to say a few words.

試験を受けるに際して、注意事項を確認してください。
When taking the exam, please check the notes of caution.

新プロジェクト開始に際して、全員が集まった。
On the occasion of starting the new project, everyone gathered.

入学に際しての準備について説明します。
I will explain preparations for the occasion of enrollment.
```

**〜に際して vs 〜にあたって:**
Both mean "upon the occasion of." に際して is slightly more formal.
〜にあたって implies more preparation or effort is involved in the occasion.

---

## 〜をはじめ(として) — "Starting With / Including (X as the Main Example)"

### Core meaning

をはじめ introduces a REPRESENTATIVE EXAMPLE before describing a broader group.
"Starting with X (as the main/most important example), [the rest of the group too]."

### Formation

```
[Main example noun] + をはじめ(として) + [broader group statement]
```

### Examples

```
社長をはじめとして、全社員が参加した。
Starting with the president, all employees participated.
(The president is the main/representative figure — others followed)

日本語をはじめとする外国語の学習が広まっている。
Learning of foreign languages, starting with Japanese, is spreading.

東京をはじめ、全国の主要都市でイベントが行われた。
Events were held in major cities across the country, starting with Tokyo.
```

**Nuance:** The first-mentioned item (をはじめ) is presented as the MOST IMPORTANT
or representative member of the group. Others are implied to follow in importance.

---

## 〜に反して / 〜に反する — "Contrary To / Against"

### Core meaning

に反して = the result is OPPOSITE to what was expected, desired, or required.
Used with expectations, rules, wishes, principles.

### Formation

```
[Noun (expectation/rule/wish)] + に反して + [contrary outcome]
[Noun] + に反する + [following noun]
```

### Examples

```
予想に反して、試験はとても簡単だった。
Contrary to expectations, the exam was very easy.

規則に反して行動した結果、処分を受けた。
As a result of acting against the rules, he received a disciplinary action.

親の期待に反して、彼女は芸術の道を選んだ。
Contrary to her parents' expectations, she chose the path of art.

常識に反する発言だ。
That is a remark contrary to common sense.
```

---

## Summary: Which Formal Pattern for Which Situation?

```
Situation                                          Pattern
────────────────────────────────────────────────────────────────
Location/domain/context (formal)                  において
About/regarding (formal requests, reports)         に関して
Based on data, rules, evidence                     に基づいて
Spanning a time period or geographic range         にわたって
Via a medium or throughout a period                を通じて
Over a contested/debated issue                     をめぐって
On the occasion of a significant event             に際して
Starting with X as the main example               をはじめ
Based on material (story, experience, idea)        をもとに
Contrary to expectations/rules                     に反して
```
