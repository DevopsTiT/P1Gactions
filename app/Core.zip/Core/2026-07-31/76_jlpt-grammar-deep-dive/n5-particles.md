# N5 Particles — Deep Dive

> The single most important thing to master in Japanese. Every sentence uses particles.
> Getting particles wrong makes a sentence ungrammatical. Getting them right makes everything else possible.

---

## Why Particles Are Different from English Prepositions

In English, word ORDER tells you the grammatical role:
```
"The cat sees the dog." → cat = subject (first noun)
"The dog sees the cat." → dog = subject (first noun)
```

In Japanese, word ORDER is flexible. **Particles** tell you the grammatical role:
```
猫が犬を見る。  → 猫 = subject (が marks it), 犬 = object (を marks it)
犬を猫が見る。  → same meaning, different word order, same particles
```
This is why particles are not optional decoration — they ARE the grammar.

---

## は (wa) — Topic Marker

### What it actually does

は does not mean "subject." It means **"speaking of X / as for X, what I'm about to say is about X."**
The topic can be the subject, the object, the location — anything you want to focus on.

```
Formation: [topic noun] + は + [comment about the topic]
```

### Basic use — stating what the sentence is about

```
私は学生です。
Speaking of me → I am a student.

東京は物価が高い。
Speaking of Tokyo → prices are high.
```

### Contrast use — は implies "but the other one..."

When は is used with two items, it implies a contrast:
```
コーヒーは飲みます。（でも紅茶は飲みません。）
I do drink coffee. (But I don't drink tea — implied contrast)

この映画は面白い。（でもあの映画はつまらない。）
This movie is interesting. (That one is boring — implied)
```

### は vs が — the most important N5 distinction

| Situation | Use は | Use が |
|---|---|---|
| Introducing NEW information | ✗ | ✓ |
| Talking about known topic | ✓ | ✗ |
| Emotion/ability adjectives (好き、できる) | ✗ | ✓ |
| Relative clause subject | ✗ | ✓ |
| "It is X that..." emphasis | ✗ | ✓ |

```
Q: 誰が来ましたか？  (Who came? — new info requested)
A: 田中さんが来ました。  (NOT は — this is new information)

田中さんは来ましたか？  (Has Tanaka come? — Tanaka is already the known topic)
```

### Common mistake: using は when the subject is new

```
WRONG: 田中さんは来ました。  (as an answer to "who came?")
RIGHT: 田中さんが来ました。  (が introduces new info)

WRONG: 猫はいます。  (answering "what is in the room?")
RIGHT: 猫がいます。  (が marks newly introduced subject)
```

---

## が (ga) — Subject Marker

### Four situations where が is required (not optional)

**Situation 1: New information / introducing something for the first time**
```
あ、雨が降ってきた！  (Oh, it's started raining! — newly noticed fact)
```

**Situation 2: Adjectives expressing feelings and abilities**
These always use が for the "liked/disliked/possible" object:
```
日本語が好きです。      (I like Japanese.)
音楽が得意です。        (I'm good at music.)
泳ぐことができます。    (I can swim.)
水が欲しい。            (I want water.)
```
Why? Because these adjectives describe a FEELING toward an object — が marks what triggers the feeling.

**Situation 3: Subject inside a relative clause**
```
私が読んだ本  (the book that I read — が inside the clause)
彼女が作った料理  (the dish that she made)
```

**Situation 4: "It is X that..." emphasis (exhaustive identification)**
```
田中さんが犯人です。  (It is Tanaka who is the criminal — identifying exactly who)
```

---

## を (wo) — Object Marker

### Marks the direct object of transitive verbs

```
Formation: [object noun] + を + [transitive verb]

りんごを食べます。  (eat an apple)
手紙を書きます。    (write a letter)
音楽を聴きます。    (listen to music)
```

### Special use: path of movement (motion verbs)

を also marks the path/space through which movement occurs:
```
公園を歩く。    (walk through/across the park)
橋を渡る。      (cross the bridge)
空を飛ぶ。      (fly through the sky)
廊下を走る。    (run down the corridor)
```
This is NOT an object — you're not "doing something to the park." You're moving through it.

---

## に (ni) — Direction / Time / Existence Location

に has three completely different jobs depending on context:

### に (1): Direction of movement (destination)

```
Formation: [destination] + に + [verb of movement: 行く・来る・帰る・入る]

東京に行く。      (go to Tokyo)
家に帰る。        (return home)
部屋に入る。      (enter the room)
```

### に (2): Point in time

```
Formation: [specific time] + に + [verb]

8時に起きる。     (wake up at 8 o'clock)
月曜日に来る。    (come on Monday)
3月に卒業した。   (graduated in March)

NOT used with: 今、明日、昨日、今日、毎日、よく
→ 明日行きます。  (no に — 明日 is a relative time word, not a point)
→ 8時に行きます。 (に required — 8時 is a specific clock point)
```

### に (3): Location of existence (with いる・ある)

```
Formation: [location] + に + [noun] + が + いる/ある

公園に犬がいる。    (a dog is in the park)
机の上に本がある。  (a book is on the desk)
```

**Critical distinction: に vs で for location**
```
に = where something EXISTS (static)
で = where an action HAPPENS (dynamic)

図書館に本がある。    (a book exists in the library — に for existence)
図書館で本を読む。    (I read a book at the library — で for action)

部屋に猫がいる。      (a cat is in the room — に for existence)
部屋で猫と遊ぶ。      (I play with the cat in the room — で for action)
```

---

## で (de) — Location of Action / Means / Cause

### で (1): Location where an action takes place

```
Formation: [location] + で + [action verb]

学校で勉強する。    (study at school)
レストランで食べる。 (eat at a restaurant)
公園で走る。        (run in the park)
```

### で (2): Means / tool / method

```
Formation: [means/tool] + で + [verb]

バスで来る。        (come by bus)
はしで食べる。      (eat with chopsticks)
日本語で話す。      (speak in Japanese)
ネットで調べる。    (look up on the internet)
```

### で (3): Cause of a state (especially negative events)

```
病気で休む。        (take off due to illness)
事故で遅れた。      (was late due to an accident)
台風で電車が止まった。 (trains stopped due to typhoon)
```

---

## へ (e) — Direction (Softer)

へ is almost identical to に for direction, but slightly more literary/softer.
In modern speech, に is much more common. You'll encounter へ in formal writing and signs.

```
東京へ行きます。  ≈  東京に行きます。
学校へ向かう。       (head toward school — more literary)
```

The key difference: に can mark the destination you arrive at; へ emphasizes the direction of movement without necessarily specifying arrival.

---

## の (no) — Possession / Noun Modification

### の (1): Possession

```
Formation: [possessor] + の + [possessed]

私の本     (my book)
田中さんの車  (Tanaka's car)
日本の首都    (Japan's capital)
```

### の (2): Noun + の + Noun (modifier relationship)

The FIRST noun modifies the SECOND:
```
日本語の先生   (teacher OF Japanese language)
大学の学生     (student OF a university)
東京の地図     (map OF Tokyo)
木の机         (desk MADE OF wood)
```

### の (3): Nominalizing verbs/clauses (making a noun phrase)

```
泳ぐのが好きです。   (I like swimming — の turns the verb into a noun)
早く帰るのを忘れた。  (I forgot to go home early)
```

---

## と (to) — And / With / Quoting

### と (1): Listing nouns (exhaustive "and")

と lists ALL items — implies nothing is left out:
```
パンとバターとコーヒーを買った。  (I bought bread, butter, AND coffee — that's all)
```
Compare: や = lists some items, implying more exist (non-exhaustive):
```
パンやバターを買った。  (I bought bread, butter, and things like that)
```

### と (2): Together with (accompaniment)

```
友達と映画を見る。   (watch a movie WITH a friend)
一人で行く。         (go ALONE — と's opposite)
```

### と (3): Quoting (content of speech/thought)

```
「明日来る」と言った。   (said "I'll come tomorrow")
おいしいと思う。         (I think it's delicious)
```

---

## も (mo) — Also / Too

も replaces は、が、を to add "also/too" meaning. Other particles (に、で、へ) stack with も.

```
私も行きます。       (I will also go — replaces は)
猫も好きです。       (I like cats too — replaces が)
水も飲みました。     (I drank water too — replaces を)

東京にも行った。     (I also went to Tokyo — に + も)
公園でも遊んだ。     (I also played in the park — で + も)
```

Two もs together = "both":
```
田中さんも山田さんも来た。  (Both Tanaka and Yamada came.)
```

---

## か (ka) — Question Marker

か at the sentence end turns any statement into a question in polite speech.
In casual speech, か can sound harsh — rising intonation alone is used instead.

```
Polite: これは本ですか？    (Is this a book?)
Casual: これ、本？          (This a book? — no か, rising tone)
```

か inside a sentence = embedded question / uncertainty:
```
彼が来るかどうかわからない。  (I don't know whether he'll come.)
何を食べるか決めた。           (I decided what to eat.)
```

---

## Particle Quick Reference Card

```
は    topic / contrast           → 私は学生です
が    subject / new info         → 雨が降っている
を    object / path of motion    → 本を読む / 橋を渡る
に    destination / time / exists → 東京に行く / 3時に / 部屋にいる
で    action location / means    → 学校で / バスで
へ    direction (literary)       → 東京へ
の    possession / modifier      → 私の本 / 日本語の先生
と    and (exhaustive) / with    → パンとバター / 友達と
も    also / too                 → 私も / 猫も
か    question                   → ですか
```
