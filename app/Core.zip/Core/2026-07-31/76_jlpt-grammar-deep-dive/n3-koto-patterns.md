# N3 〜こと Patterns — Deep Dive
## ことがある・ことにする・ことになる・ことにしている・ことになっている

> Five patterns. Same word こと. Completely different meanings.
> The key to each one is what PRECEDES こと and what FOLLOWS it.

---

## What こと Is

こと (事) is a nominalizer — it turns a verb phrase into a NOUN.
"食べる" = eat (verb). "食べること" = eating / the act of eating (noun phrase).

Once you have a noun, you can attach noun patterns: がある、にする、になる、にしている、になっている.
Each combination creates a completely different meaning.

---

## Pattern 1 — 〜ことがある: "Sometimes Happens"

### Formation

[Verb plain NON-past] + ことがある

### Meaning

Expresses that something SOMETIMES happens — a possibility that occurs from time to time.
Not habitual (not always), not past experience (not have-done-before).

```
授業中に眠くなることがある。
I sometimes get sleepy during class.
(It happens sometimes — not always, not never)

うそをついてしまうことがある。
I sometimes end up telling a lie.

仕事で夜12時まで働くことがある。
I sometimes work until midnight because of work.
```

**Critical distinction: ことがある (sometimes) vs たことがある (have done before)**

```
こんな料理を食べることがある。       (現在 / non-past)
→ I sometimes eat this kind of food.  (happens occasionally now)

こんな料理を食べたことがある。        (過去 / past = たことがある)
→ I have eaten this kind of food before. (past experience)
```

The difference is tense: **non-past + ことがある = sometimes** / **past + ことがある = have done**

---

## Pattern 2 — 〜ことにする: "Decide to Do" (Personal Decision)

### Formation

[Verb plain form] + ことにする
[Verb ない form] + ことにする (decide NOT to do)

### Meaning

The SPEAKER (or subject) makes a personal, internal decision.
The key: the decision comes from the person themselves.

```
毎日日記を書くことにした。
I decided to write a diary every day.
(My own decision — nobody told me to)

来年、日本語の試験を受けることにしました。
I have decided to take the Japanese exam next year.

タバコを吸わないことにした。
I decided not to smoke.
(ない form = decide NOT to do)
```

**The "just decided" feeling:**
ことにした (past) often means you just made a decision, or are announcing a recent decision.
ことにする (present) means you are making the decision right now.

```
A: 来週のパーティー、どうするの？
B: 行かないことにした。
   I've decided not to go.
```

---

## Pattern 3 — 〜ことになる: "It Has Been Decided" (External Decision / Natural Outcome)

### Formation

[Verb plain form] + ことになる
[Verb ない form] + ことにならない (it turns out not happening)

### Meaning

Something has been decided by EXTERNAL factors, circumstances, or other people.
OR: a situation has developed (naturally, not by the speaker's choice) to a certain result.

```
来月から大阪に転勤することになった。
It has been decided that I'll be transferred to Osaka next month.
(Company decided this — not my choice → ことになる, NOT ことにした)

結婚式は来年の春に行われることになった。
The wedding has been decided to take place next spring.
(Circumstances/families decided — not a single person's choice)

大学院に進学することになりました。
It has turned out that I'll be going to graduate school.
(Circumstances led to this outcome)
```

**The most important distinction in N3 grammar:**

```
ことにした = I personally decided
ことになった = it was decided (by others/circumstances)

来月から大阪に行くことにした。
→ I decided to go to Osaka next month. (my own choice)

来月から大阪に行くことになった。
→ I'm going to Osaka next month. (company/others decided — not my choice)
```

The natural Japanese way to announce a job transfer or external decision is **ことになった**,
never **ことにした** — using ことにした would imply it was your own personal choice,
which is socially strange for work-related news.

---

## Pattern 4 — 〜ことにしている: "Have Made It a Rule / Practice"

### Formation

[Verb plain form] + ことにしている (present ongoing habit)

### Meaning

Something the speaker has DECIDED to make into a habit or personal rule.
The decision was made in the past, and the habit is ongoing now.
It comes from ことにする (decided) + ている (ongoing state).

```
毎朝ジョギングすることにしている。
I make it a practice to jog every morning.
(I decided to do this, and I'm maintaining that decision)

寝る前にスマホを見ないことにしている。
I make it a rule not to look at my phone before bed.

週に一度は家族と夕食を食べることにしている。
I make it a practice to have dinner with my family once a week.
```

**The nuance:** ことにしている implies a COMMITMENT you made to yourself.
It's slightly stronger than just describing a habit (〜ている).
The 〜にして part shows intention was involved in establishing the habit.

---

## Pattern 5 — 〜ことになっている: "Is Supposed to / There Is a Rule"

### Formation

[Verb plain form] + ことになっている

### Meaning

An existing rule, schedule, arrangement, or social norm that already exists —
not the speaker's personal decision, but an agreed-upon or established rule.
It comes from ことになる (was decided) + ている (the state of having been decided is ongoing).

```
9時に集合することになっています。
We are supposed to meet at 9.
(It has been arranged — someone else set this up)

この学校では制服を着ることになっている。
At this school, you are supposed to wear a uniform.
(School rule — established by the institution)

申請書類は来週の金曜日までに提出することになっている。
Application documents are supposed to be submitted by next Friday.
(Pre-established deadline — externally set)
```

**The most important comparison:**

```
ことにしている = I personally maintain this as a habit/rule
ことになっている = there is an existing rule/arrangement (set by others)

毎朝ランニングすることにしている。
I make it a practice to run every morning. (my personal habit)

学生は8時までに登校することになっている。
Students are supposed to arrive at school by 8. (school rule)
```

---

## Complete Side-by-Side Comparison

```
Same verb: 毎日運動する (exercise every day)

毎日運動することがある。
→ I sometimes exercise every day.
(It occasionally happens — sometimes/not always)

毎日運動することにした。
→ I decided to exercise every day.
(Personal decision, just made)

毎日運動することになった。
→ It has been decided that I exercise every day. (?)
(External decision — unusual for this verb, more natural with work/life events)

毎日運動することにしている。
→ I make it a rule to exercise every day.
(Personal habit I decided to maintain)

毎日運動することになっている。
→ I am supposed to exercise every day.
(Existing rule/arrangement set by others — e.g., doctor ordered it)
```

---

## Exam Tip: ことにする vs ことになる on the Test

This is tested in almost every N3 exam.
The test gives you a sentence where the DECIDING AGENT tells you which to use:

```
A: 「卒業後、どうするの？」
B: 「大学院に___ことにした / ことになった___。」

→ If B is choosing freely: ことにした
→ If B is reporting external circumstances: ことになった

Answer depends on context:
If B adds 「自分で決めた」 → ことにした
If B adds 「成績が良かったから奨学金で行けることになった」 → ことになった
```

**Shortcut test:**
Can you replace the sentence with "I decided..."? → ことにした
Can you replace with "I've been told / things turned out that..."? → ことになった
