# N3 Expectation and Conjecture — Deep Dive
## はずだ・にちがいない・かもしれない・でしょう・らしい・ようだ・そうだ

> This is the most heavily tested N3 area. Seven patterns, each expressing
> a different level of certainty from a different type of evidence.

---

## The Certainty Scale

```
100% certain  ←──────────────────────────────────────→  uncertain

にちがいない → はずだ → でしょう → らしい → ようだ → かもしれない

"must be"     "should be"  "probably"  "apparently"  "seems"  "might be"
(strong conviction) (logic-based) (soft guess) (indirect) (observation) (50/50)
```

And then two そうだ patterns in completely different categories:
- そうだ (appearance) = based on what I see right now
- そうだ (hearsay) = information I was told by someone

---

## 〜はずだ — "Should Be" (Logic-Based Expectation)

はず means "expectation based on reason." The speaker has grounds — logic, knowledge,
a schedule, a rule — that lead them to expect something is true.

### Formation

```
Verb plain form + はずだ
い-adjective + はずだ
な-adjective + な + はずだ
Noun + の + はずだ
```

### Meaning

```
彼はもう着いているはずだ。
He should have arrived already.
(Reason: I know he left 2 hours ago, and it only takes 1 hour — logic)

この薬を飲めば、熱が下がるはずだ。
If you take this medicine, your fever should go down.
(Reason: that's what this medicine does — general knowledge)

今日は木曜日だから、田中さんは会社にいるはずだ。
Since today is Thursday, Tanaka should be at the office.
(Reason: I know his schedule)
```

### 〜はずがない — "There's no way / Impossible"

The negative version expresses strong impossibility based on logic:
```
彼が嘘をつくはずがない。
There's no way he would lie.
(Reason: I know his character — he's always honest)

こんな安い値段のはずがない。
There's no way the price is this cheap.
(Reason: based on market knowledge — something must be wrong)
```

### 〜はずだった — "Was supposed to (but didn't happen)"

Past version — something was expected but the reality was different:
```
彼は来るはずだったが、来なかった。
He was supposed to come, but he didn't.

この計画は成功するはずだったのに、失敗した。
This plan was supposed to succeed, but it failed. (disappointment)
```

---

## 〜にちがいない — "Must Be" (Strong Personal Conviction)

にちがいない = "there's no doubt that / must certainly be."
The speaker has high confidence, often based on a combination of evidence and intuition.
Slightly stronger than はずだ and more personal.

```
Formation: [plain form] + にちがいない

あの光はUFOに違いない。
That light must be a UFO. (strong personal conviction)

彼女は疲れているに違いない。
She must be tired.

昨日の音は地震に違いない。
That sound yesterday must have been an earthquake.
```

**Key difference from はずだ:**
- はずだ = "should be (based on logical reasoning)"
- にちがいない = "must be (based on conviction — I'm sure)"

```
9時に出発したから、もう着いているはずだ。
Since he left at 9, he should have arrived by now. (logical calculation)

彼の様子から、隠しているに違いない。
From his behavior, he must be hiding something. (conviction from observation)
```

---

## 〜かもしれない — "Might / Maybe" (50/50 Possibility)

かもしれない = genuine uncertainty. The speaker thinks it's possible but has no strong evidence.
This is the pattern to use when you're genuinely unsure.

```
Formation: [plain form] + かもしれない

明日は雨かもしれない。
It might rain tomorrow. (no strong evidence either way)

彼は来ないかもしれない。
He might not come.

もしかしたら、間違えたかもしれない。
Maybe I made a mistake. (self-doubt)
```

**Usage tip:** もしかしたら (perhaps), もしかすると (maybe), もしかして (maybe)
are often paired with かもしれない to add more uncertainty softening:
```
もしかしたら、彼は怒っているかもしれない。
Perhaps he might be angry.
```

---

## 〜でしょう / 〜だろう — "Probably"

でしょう (polite) / だろう (casual) = a soft conjecture without strong evidence.
The speaker thinks it's likely but isn't certain.

```
Formation: [plain form] + でしょう (polite) / だろう (casual)

明日は晴れるでしょう。
It will probably be sunny tomorrow.
(Weather forecaster's typical ending — soft prediction)

彼は知っているだろう。
He probably knows. (casual)

これは難しいでしょう。
This is probably difficult.
```

**でしょう for seeking confirmation (rising intonation)**
When said with rising intonation, でしょう seeks agreement:
```
明日、雨でしょう？
It'll rain tomorrow, right? (seeking agreement)
```

**Certainty comparison:**
```
にちがいない (must be) > はずだ (should be) > でしょう (probably) > かもしれない (might)
```

---

## 〜らしい — Three Meanings in One Form

らしい is the most complex of the conjecture patterns because it has three different uses.

### らしい (1): Hearsay / Indirect Evidence

The speaker has information from an indirect source — what they heard, read, or inferred:
```
Formation: [plain form] + らしい

田中さんは会社を辞めるらしい。
Apparently, Tanaka is going to quit the company.
(I heard this from someone / I read it somewhere — not my direct knowledge)

明日は台風が来るらしい。
Apparently a typhoon is coming tomorrow.
(From the news / word of mouth)
```

**Key: the speaker did NOT directly observe or verify this.**

### らしい (2): Typical of / Characteristic of

らしい attached to nouns = "typical/characteristic of X / just like X."
This is VERY different from the hearsay meaning:
```
今日は日本らしい天気だね。
Today has very Japanese-like weather, doesn't it?
(Four seasons, cherry blossoms — typical Japan)

さすが先生らしい答えだ。
That's a very teacher-like answer.
(The answer perfectly fits what you'd expect from a teacher)

男らしい人だ。
He's a very manly man. (typical of men — strong/brave)
```

### らしい (3): Seems like / Appears to be (N1 advanced use)

At higher levels, らしい can express inference from indirect signs.
This overlaps with ようだ but has a nuance of drawing from general knowledge.

---

## 〜ようだ — "Seems / Appears" (Direct Observation + Inference)

ようだ expresses inference based on what the speaker DIRECTLY observes.
"I can see/feel/hear X and based on that, I infer Y."

```
Formation:
  Verb plain form + ようだ
  い-adj + ようだ
  な-adj + な + ようだ
  Noun + の + ようだ

彼は疲れているようだ。
He appears to be tired.
(I can see his face, his posture, his behavior → I infer he's tired)

外は雨が降っているようだ。
It seems it's raining outside.
(I can hear the sound of rain or see wet windows → I infer it's raining)

この料理は辛いようだ。
This dish seems to be spicy.
(I can see red chili peppers, the steam, the color → I infer it's spicy)
```

**ようだ for comparison ("like"):**
```
まるで夢のようだ。
It's just like a dream.

まるで子供のように走っている。
Running just like a child.
```

---

## 〜そうだ — Two Completely Different Meanings

そうだ is one word with two OPPOSITE meanings depending on formation.
This is the most commonly confused pattern at N3/N4.

### そうだ (1): LOOKS LIKE / ABOUT TO (visual appearance)

Based on what the speaker SEES RIGHT NOW. The situation visually appears about to happen.

```
Formation: 
  Verb STEM (ます-stem) + そうだ
  い-adj (remove い) + そうだ
  な-adj + そうだ

雨が降りそうだ。
It looks like it's going to rain.
(I can see dark clouds right now → visual inference of imminent event)

この料理はおいしそうだ。
This food looks delicious.
(I can SEE the food right now — visual appearance)

彼は疲れそうだ。
He looks tired.
(Based on what I'm seeing right now)
```

**Crucial: そうだ(appearance) uses the STEM, not plain form:**
```
降りそうだ  ← 降り = stem of 降る  (correct appearance form)
降るそうだ  ← 降る = plain form    (hearsay form — different meaning!)
```

### そうだ (2): I HEARD THAT (hearsay — reported information)

Based on information received FROM SOMEONE ELSE. Not personal observation.

```
Formation: [plain form] + そうだ

明日は台風が来るそうだ。
I heard that a typhoon is coming tomorrow.
(Someone told me / I read it in the news — hearsay)

田中さんは結婚するそうだ。
I heard that Tanaka is getting married.
(Reported from another source)

あの映画はとても面白いそうです。
I heard that movie is very interesting.
(Someone said it / I read a review)
```

---

## Side-by-Side Comparison: The Four "Seems" Patterns

```
SCENARIO: I think he's angry.

らしい: 彼は怒っているらしい。
  → I HEARD that he's angry / I read something suggesting it.
  → INDIRECT evidence (not my observation)

ようだ: 彼は怒っているようだ。
  → Based on what I OBSERVE (his expression, tone, behavior), he seems angry.
  → DIRECT observation → inference

そうだ: 彼は怒りそうだ。
  → Right now I can SEE he's about to get angry (steam coming out of ears, figuratively)
  → VISUAL appearance of imminent state

にちがいない: 彼は怒っているにちがいない。
  → I'm CONVINCED he's angry.
  → STRONG personal conviction
```

---

## Exam Trap: らしい vs そうだ(hearsay)

Both express hearsay. The difference:
- らしい = inference from indirect signs, could be your own reading of the situation
- そうだ(hearsay) = specifically reporting information given by another person

```
雨が降るらしい。
(It seems it will rain — based on indirect signs: clouds, humidity, forecast I read)

雨が降るそうだ。
(I was told it will rain — someone specifically told me / news said so)
```

In practice, らしい and そうだ(hearsay) overlap heavily in casual speech.
On the exam, they test the FORMATION difference most (らしい = plain form directly;
そうだ = plain form + そうだ after plain form).
