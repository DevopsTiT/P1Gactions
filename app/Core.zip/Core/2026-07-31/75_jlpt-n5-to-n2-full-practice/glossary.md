# Glossary — JLPT N5→N2 Reading, Integration & Listening
All question types, strategy terms, and key concepts explained for beginners.

---

**問題10 (N2/N3 Reading)**
Medium-length reading comprehension passage (~500 characters). Questions test understanding of content, author's intent, and specific information. Strategy: read the question first, then find the answer in the text.

**問題11 (N2 Reading)**
Long reading passage (~800+ characters). Tests deeper comprehension including the author's overall claim and implicit meaning. Strategy: skim paragraph structure, focus on first and last sentences of each paragraph.

**問題12 (N2/N3 Integration)**
Two short texts on a related topic. Questions ask: what do both agree on? How do they differ? What is each author's position? Strategy: read both texts, then identify agreement vs disagreement before answering.

**問題13 (N2 Reading)**
Information-dense long passage, often with data or research. Tests whether you can locate and interpret specific factual information within a long text.

**問題14 (N2 Information Retrieval)**
A practical document (notice, advertisement, flyer, schedule). Questions ask for specific facts. Strategy: scan for the specific piece of data asked (date, price, condition) — do NOT read the whole document from start to finish.

**統合理解 (Integrated Comprehension)**
A reading task where you read two texts and compare them. The most common questions: "What do both authors agree on?" and "How are the two authors' positions different?" Always find textual evidence, not assumed knowledge.

**情報検索 (Information Retrieval)**
The fastest reading section. Practical documents with specific data. The correct answer is always directly stated in the document — no inference needed.

**問題1 (Listening: 課題理解)**
"Task comprehension" — you hear a situation (often a conversation or instruction) and must choose what the person should do next. The key is finding the FINAL action or decision made in the conversation.

**問題2 (Listening: ポイント理解)**
"Point comprehension" — identify the KEY INFORMATION from a script (what changed, what is the main fact). Often involves changes from what was originally planned.

**問題3 (Listening: 概要理解)**
"Gist comprehension" — listen to a longer script (announcement, lecture) and identify the OVERALL MAIN POINT. Do not choose answers about specific examples — choose the big picture answer.

**問題4 (Listening: 即時応答)**
"Immediate response" — a short statement or question, choose the best natural response from 3 options. The most common trap: responding with something related but that doesn't actually answer what was said.

**問題5 (Listening: 統合理解)**
"Integrated listening" — listen to a longer conversation or presentation, sometimes with a visual, and answer 2–3 questions. Requires holding multiple pieces of information simultaneously.

**しかし / でも / ところが**
Contrast markers. Something different is coming after this word. The sentence after a contrast marker often contains the author's true opinion or the important turning point. Always read carefully what follows these.

**つまり / すなわち / 要するに**
Summary/conclusion markers. The author is about to restate or clarify the main point. What follows is often the correct answer to "what does the author mean?"

**なぜなら / というのは**
"Because / the reason is." A reason or explanation follows. If asked "why?", look for these markers in the text.

**〜ものの**
"Although / even though" — concessive conjunction. Acknowledges something true, then introduces an unexpected or contrasting result. 試験に合格したものの就職に苦労した = "Although I passed the exam, I struggled to find work."

**〜にもかかわらず**
"Despite / in spite of." A stronger concessive than ものの. Used in formal/written contexts. 雨にもかかわらず試合は続いた = "Despite the rain, the match continued."

**〜とはいえ**
"That said / even so." Acknowledges a prior point but introduces a qualification. 春とはいえまだ寒い = "That said, it's still cold even though it's spring."

**〜ではないか (rhetorical question)**
The author is not actually asking a question — this form expresses the author's opinion. 「〜ではないか」= "Isn't it the case that...?" This is a STRONG opinion marker. Always read this as the author's position.

**〜べきだ**
"Should / ought to." Used to express the author's recommendation or value judgment. Finding べきだ in a passage = finding the author's prescription.

**〜必要があるだろう**
"There is probably a need to..." — slightly softer than べきだ. Still indicates the author's opinion about what should be done.

**〜と考えられる / 〜といえるだろう**
"It can be thought that / it could be said that." These are hedged opinion markers in academic and formal writing. The author is expressing their view with some tentativeness.

**確かに〜しかし**
"Certainly... however." Classic two-step argument structure. The author first acknowledges the opposing view (確かに), then gives their OWN view (しかし). The answer to "what does the author think?" is ALWAYS after しかし in this pattern.

**Paraphrase (言い換え)**
In N2 and N3 reading, the correct answer option usually rephrases the text rather than copying it word-for-word. A word-for-word copy of the text is often a TRAP (planted distractor). Look for same meaning in different words.

**半額 (はんがく)**
Half price. 1,000円の半額 = 500円. A common number trap in listening — you must calculate, not just choose the number you heard.

**2割引 (にわりびき)**
20% off. 1,000円の2割引 = 800円 (100% - 20% = 80%). N3 and N2 listening frequently tests calculations like this.

**先着順 (せんちゃくじゅん)**
First come, first served. Common in notices. Once the limit (定員) is reached, no more applications accepted.

**定員 (ていいん)**
Maximum capacity / limit. Found in notices for seminars, events, classes. 定員になり次第締め切り = "Will close as soon as the capacity is reached."

**申込締切 (もうしこみしめきり)**
Application deadline. Found in notices. Must apply BY this date/time. Important: different from the キャンセル期限 (cancellation deadline).

**キャンセル期限 (キャンセルきげん)**
The deadline for cancellation. Often different from (and later than) the application deadline. Common trap: mixing up the application deadline and the cancellation deadline.

**見学参加 (けんがくさんか)**
Observer participation — attend but cannot participate (speak, ask questions, etc.). Common in N2 notices. Check whether you qualify as a full participant or only an observer.

**かしこまりました**
"Understood / certainly" — the most formal acceptance response. Used when responding to requests from customers or superiors. More formal than わかりました or 了解しました.

**お世話になりました**
"Thank you for your help / I am in your debt." A formulaic expression of gratitude for past support. Standard response: こちらこそ、ありがとうございました (likewise, thank you).

**お時間よろしいでしょうか**
"Do you have a moment?" Polite way to ask if someone is free to talk. The expected responses are: はい、どうぞ (yes, go ahead) or ただいま少々お時間をいただけますか (could I have a moment?).

**即時応答トラップ (Immediate Response Traps)**
Three common traps in 問題4: (1) giving thanks when the question asks for yes/no, (2) answering a different question from what was asked, (3) choosing a response that's related but socially inappropriate for the relationship.

**概要理解の答え (Gist answer)**
The correct answer for 問題3 (gist comprehension) reflects the WHOLE passage's main message, not a specific example from the middle. If an option sounds very specific or narrow, it is usually wrong.

**N5/N4 notice vocabulary**
Common words in N4/N5 notices: 営業時間 (business hours), 休館日 (closed day), 会員 (member), 無料 (free), 別途 (separately/in addition), 対象 (target/eligible).

**N2 notice vocabulary**
Common words in N2 notices: 先着順 (first come first served), 定員 (capacity), 対象 (eligible parties), 申込方法 (application method), 注意事項 (notes/precautions), 締め切り (deadline), 禁止 (prohibited).
