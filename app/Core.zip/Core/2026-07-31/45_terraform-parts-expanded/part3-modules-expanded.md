# Part 3 Expanded — Modules: Every Pattern, Pitfall, and Best Practice

---

## The Module Mental Model — It's a Function Call

A Terraform module is exactly like a function in any programming language:

```
Function analogy:

def create_networking(vpc_cidr, environment, enable_nat):
    vpc = create_vpc(vpc_cidr)
    subnet = create_subnet(vpc.id)
    if enable_nat:
        nat = create_nat(subnet.id)
    return vpc.id, subnet.id

↕ same concept in Terraform:

module "networking" {
  source             = "./modules/networking"
  vpc_cidr           = "10.0.0.0/16"      # input argument
  environment        = "production"         # input argument
  enable_nat_gateway = true                 # input argument
}
# → module.networking.vpc_id               # return value
# → module.networking.public_subnet_ids    # return value
```

The module is a **black box**: the caller provides inputs, gets outputs, and doesn't need to know the internal implementation. You can change how the module creates the VPC (different AZ strategy, new AWS feature) without changing any caller code, as long as inputs and outputs stay the same.

---

## Root Module vs Child Module

- **Root module** = the working directory where you run `terraform apply`. The `.tf` files you write directly.
- **Child module** = a module called via a `module` block. Lives elsewhere (subdirectory, Git repo, registry).

Every Terraform configuration has exactly one root module. It can call zero or many child modules.

```
Root module (environments/production/)
├── main.tf          ← calls child modules
├── variables.tf
└── outputs.tf

Child modules:
├── modules/networking/   ← called by root, can call other modules
│   └── main.tf
└── modules/compute/      ← called by root
    └── main.tf
```

A child module can call other modules (nested modules). Terraform supports arbitrary nesting depth, but keep it shallow (2-3 levels max) for readability.

---

## Module Directory Structure — Full Template

```
modules/eks-cluster/
├── main.tf           # primary resources
├── variables.tf      # all input declarations
├── outputs.tf        # all exported values
├── versions.tf       # required providers (important for modules!)
├── data.tf           # data sources (separate file keeps main.tf clean)
├── iam.tf            # IAM resources (separate by concern)
├── security.tf       # security groups, NACLs
└── README.md         # required: documents inputs, outputs, usage example
```

Why `versions.tf` in a module? A module must declare the minimum provider version it requires. If the root module uses AWS provider 4.x but the module needs 5.x features, the user gets a clear error:

```hcl
# modules/eks-cluster/versions.tf
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0.0"   # this module needs AWS provider 5.x minimum
    }
  }
  required_version = ">= 1.5.0"
}
```

---

## Writing a Production-Grade Module — Full Example

This example builds a complete application module: load balancer + auto-scaling group + security groups.

```hcl
# modules/app-server/variables.tf

variable "name" {
  description = "Application name — used as prefix for all resource names"
  type        = string
  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,30}$", var.name))
    error_message = "Name must be 3-31 lowercase alphanumeric chars or hyphens, starting with a letter."
  }
}

variable "environment" {
  description = "Deployment environment"
  type        = string
  validation {
    condition     = contains(["dev", "staging", "production"], var.environment)
    error_message = "Environment must be dev, staging, or production."
  }
}

variable "vpc_id" {
  description = "VPC ID where resources will be created"
  type        = string
}

variable "subnet_ids" {
  description = "Subnet IDs for the ASG (use private subnets for app tier)"
  type        = list(string)
  validation {
    condition     = length(var.subnet_ids) >= 2
    error_message = "At least 2 subnets required for high availability."
  }
}

variable "alb_subnet_ids" {
  description = "Subnet IDs for the ALB (use public subnets)"
  type        = list(string)
}

variable "instance_type" {
  description = "EC2 instance type for app servers"
  type        = string
  default     = "t3.small"
}

variable "min_size" {
  type    = number
  default = 1
}

variable "max_size" {
  type    = number
  default = 10
}

variable "desired_capacity" {
  type    = number
  default = 2
}

variable "ami_id" {
  description = "AMI ID for app servers (leave empty to use latest Amazon Linux 2)"
  type        = string
  default     = ""
}

variable "user_data_script" {
  description = "Base64-encoded user data script for instance initialization"
  type        = string
  default     = ""
}

variable "health_check_path" {
  description = "HTTP path for ALB health checks"
  type        = string
  default     = "/health"
}

variable "app_port" {
  description = "Port the application listens on"
  type        = number
  default     = 8080
}

variable "tags" {
  description = "Additional tags to apply to all resources"
  type        = map(string)
  default     = {}
}
```

```hcl
# modules/app-server/main.tf

locals {
  name_prefix = "${var.name}-${var.environment}"
  common_tags = merge(var.tags, {
    Module      = "app-server"
    Application = var.name
    Environment = var.environment
  })
}

# Use provided AMI or latest Amazon Linux 2
data "aws_ami" "amazon_linux_2" {
  count       = var.ami_id == "" ? 1 : 0   # only query if not provided
  most_recent = true
  owners      = ["amazon"]
  filter {
    name   = "name"
    values = ["amzn2-ami-hvm-*-x86_64-gp2"]
  }
}

locals {
  # Coalesce: use provided AMI, fallback to latest AL2
  resolved_ami_id = var.ami_id != "" ? var.ami_id : data.aws_ami.amazon_linux_2[0].id
}

# Security group for ALB (internet-facing)
resource "aws_security_group" "alb" {
  name_prefix = "${local.name_prefix}-alb-"
  vpc_id      = var.vpc_id
  description = "Security group for ${local.name_prefix} ALB"
  tags        = merge(local.common_tags, { Name = "${local.name_prefix}-alb-sg" })

  ingress {
    description = "HTTP from internet"
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  ingress {
    description = "HTTPS from internet"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  lifecycle { create_before_destroy = true }
}

# Security group for app instances (only accept from ALB)
resource "aws_security_group" "app" {
  name_prefix = "${local.name_prefix}-app-"
  vpc_id      = var.vpc_id
  description = "Security group for ${local.name_prefix} app servers"
  tags        = merge(local.common_tags, { Name = "${local.name_prefix}-app-sg" })

  ingress {
    description     = "App port from ALB only"
    from_port       = var.app_port
    to_port         = var.app_port
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]   # reference ALB SG, not CIDR
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  lifecycle { create_before_destroy = true }
}

# Application Load Balancer
resource "aws_lb" "main" {
  name               = "${local.name_prefix}-alb"
  internal           = false
  load_balancer_type = "application"
  security_groups    = [aws_security_group.alb.id]
  subnets            = var.alb_subnet_ids
  tags               = merge(local.common_tags, { Name = "${local.name_prefix}-alb" })

  lifecycle { prevent_destroy = var.environment == "production" }
}

resource "aws_lb_target_group" "main" {
  name_prefix = "${substr(local.name_prefix, 0, 6)}-"
  port        = var.app_port
  protocol    = "HTTP"
  vpc_id      = var.vpc_id
  tags        = local.common_tags

  health_check {
    enabled             = true
    healthy_threshold   = 2
    unhealthy_threshold = 3
    timeout             = 5
    interval            = 30
    path                = var.health_check_path
    matcher             = "200"
  }

  lifecycle { create_before_destroy = true }
}

resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.main.arn
  port              = 80
  protocol          = "HTTP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.main.arn
  }
}

# Launch Template
resource "aws_launch_template" "app" {
  name_prefix   = "${local.name_prefix}-"
  image_id      = local.resolved_ami_id
  instance_type = var.instance_type
  user_data     = var.user_data_script != "" ? var.user_data_script : null

  network_interfaces {
    associate_public_ip_address = false
    security_groups             = [aws_security_group.app.id]
  }

  tag_specifications {
    resource_type = "instance"
    tags          = merge(local.common_tags, { Name = "${local.name_prefix}-instance" })
  }

  lifecycle { create_before_destroy = true }
}

# Auto Scaling Group
resource "aws_autoscaling_group" "app" {
  name_prefix         = "${local.name_prefix}-"
  vpc_zone_identifier = var.subnet_ids
  min_size            = var.min_size
  max_size            = var.max_size
  desired_capacity    = var.desired_capacity

  launch_template {
    id      = aws_launch_template.app.id
    version = "$Latest"
  }

  target_group_arns = [aws_lb_target_group.main.arn]

  health_check_type         = "ELB"
  health_check_grace_period = 300

  lifecycle {
    ignore_changes = [desired_capacity]   # let auto-scaler control this
  }

  dynamic "tag" {
    for_each = merge(local.common_tags, { Name = "${local.name_prefix}-asg" })
    content {
      key                 = tag.key
      value               = tag.value
      propagate_at_launch = true
    }
  }
}
```

```hcl
# modules/app-server/outputs.tf

output "alb_dns_name" {
  description = "DNS name of the Application Load Balancer"
  value       = aws_lb.main.dns_name
}

output "alb_arn" {
  description = "ARN of the Application Load Balancer"
  value       = aws_lb.main.arn
}

output "app_security_group_id" {
  description = "Security group ID for app instances (for DB/cache ingress rules)"
  value       = aws_security_group.app.id
}

output "autoscaling_group_name" {
  description = "Name of the Auto Scaling Group"
  value       = aws_autoscaling_group.app.name
}

output "target_group_arn" {
  description = "ARN of the ALB Target Group"
  value       = aws_lb_target_group.main.arn
}
```

**Calling this module:**
```hcl
module "payments_service" {
  source = "../../modules/app-server"

  name             = "payments"
  environment      = "production"
  vpc_id           = module.networking.vpc_id
  subnet_ids       = module.networking.private_subnet_ids
  alb_subnet_ids   = module.networking.public_subnet_ids
  instance_type    = "t3.medium"
  min_size         = 2
  max_size         = 20
  desired_capacity = 5
  health_check_path = "/api/health"
  app_port         = 8080
  tags             = { Team = "payments", CostCenter = "ecommerce" }
}

# Use the module's output in other resources
resource "aws_route53_record" "payments" {
  zone_id = data.aws_route53_zone.main.id
  name    = "payments.example.com"
  type    = "CNAME"
  records = [module.payments_service.alb_dns_name]
  ttl     = 300
}
```

---

## Module Versioning Strategy — Semver for Infrastructure

Treat your internal modules like libraries. Use Git tags as versions:

```
Versioning convention for modules:
  v0.x.y — pre-release, breaking changes allowed
  v1.0.0 — stable, commitment to backward compatibility
  v1.1.0 — new feature, backward compatible (old callers still work)
  v1.1.1 — bug fix, no new features
  v2.0.0 — breaking change (changed variable name, removed output, etc.)
```

Callers pin to minor versions:
```hcl
module "networking" {
  source = "git::https://github.com/my-org/terraform-modules.git//networking?ref=v1.3.0"
  # ...
}
```

Production uses a tested version. Dev can test a newer version before promoting:
```hcl
# environments/dev/main.tf
module "networking" {
  source = "git::https://github.com/my-org/terraform-modules.git//networking?ref=v1.4.0-beta"
}

# environments/production/main.tf
module "networking" {
  source = "git::https://github.com/my-org/terraform-modules.git//networking?ref=v1.3.0"
}
```

---

## Module Testing with `terraform test` (Terraform 1.6+)

```hcl
# modules/networking/tests/basic.tftest.hcl

run "creates_vpc_with_correct_cidr" {
  variables {
    vpc_cidr    = "10.99.0.0/16"
    environment = "test"
  }

  assert {
    condition     = aws_vpc.main.cidr_block == "10.99.0.0/16"
    error_message = "VPC CIDR block does not match input variable."
  }

  assert {
    condition     = length(aws_subnet.public) == 2
    error_message = "Expected 2 public subnets."
  }
}

run "nat_gateway_not_created_by_default" {
  variables {
    vpc_cidr           = "10.99.0.0/16"
    environment        = "test"
    enable_nat_gateway = false
  }

  assert {
    condition     = length(aws_nat_gateway.main) == 0
    error_message = "NAT gateway should not be created when enable_nat_gateway = false."
  }
}
```

```bash
# Run module tests (creates real resources, then destroys them)
terraform test

# Run a specific test file
terraform test -filter="tests/basic.tftest.hcl"
```
