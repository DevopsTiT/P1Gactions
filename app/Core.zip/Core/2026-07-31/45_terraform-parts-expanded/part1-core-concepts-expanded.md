# Part 1 Expanded — Core Concepts: Every Detail Explained

---

## Why Terraform Exists — The Problem Before IaC

### The World Without Terraform

In 2010–2015, infrastructure meant:
1. Log into AWS console
2. Click "Launch Instance"
3. Fill in 20 form fields
4. Take a screenshot (maybe)
5. Six months later: nobody remembers what was clicked

Problems this caused:
- **No reproducibility** — Can't recreate the same environment reliably
- **No diff** — Can't tell what changed between last Tuesday and today
- **No review** — A database was deleted; nobody knows who did it or why
- **Environment drift** — Dev has port 8080 open; production has port 80; staging has both; nobody is sure which is correct
- **Fear of change** — "Don't touch the production firewall rules, nobody knows what they do"

### What Terraform Solves

Terraform treats infrastructure like code:
- Write what you want in `.tf` files → check them into Git
- Every change is a commit with an author, timestamp, and message
- `git diff` shows exactly what changed between environments
- `terraform plan` shows exactly what will change before it happens
- A new team member can read the `.tf` files and understand the entire infrastructure

---

## The Reconciliation Loop — Deepest Dive

### What "Reconciliation" Means

Reconciliation = continuously comparing "what should be" against "what is" and acting to close any gap.

This is the same pattern used by:
- Kubernetes controllers (desired pod count vs actual pod count)
- A thermostat (desired temperature vs actual temperature)
- Git (desired file state vs actual file state)

Terraform's loop runs on demand (when you run `terraform apply`), not continuously. This distinguishes it from tools like Kubernetes which reconcile in real time.

### Inside `terraform plan` — Every Step Unwrapped

```
terraform plan execution trace:

1. PARSE .tf FILES
   ├── Read every *.tf file in the current directory
   ├── Build an AST (Abstract Syntax Tree) of all blocks
   └── Validate syntax — missing brackets, wrong types, etc.
        Error here = "Error: Unsupported argument" or similar

2. BUILD DESIRED STATE GRAPH
   ├── Create a node for every resource block
   ├── Trace references: "this resource uses that resource's .id"
   └── Build a directed acyclic graph (DAG) of dependencies
        aws_vpc → aws_subnet → aws_instance (order of creation)
        aws_instance → aws_subnet → aws_vpc (order of destruction)

3. LOAD STATE FILE (.tfstate)
   ├── If remote backend: download from S3/GCS
   ├── Parse JSON — deserialize every known resource and its attributes
   └── If state is locked by another process: wait or error
        "Error: Error acquiring the state lock"

4. REFRESH (query cloud APIs)
   ├── For each resource in state: call the provider API to check current attributes
   │    e.g. AWS describes the EC2 instance: is it still running? same instance type?
   ├── If resource was deleted outside Terraform:
   │    → Remove it from the refresh result (plan will show it as "+", need to recreate)
   ├── If resource attributes changed outside Terraform:
   │    → Updated refresh shows different value than state (drift detected)
   └── This refresh step is why plan can be SLOW for large infra (hundreds of API calls)
        Use -refresh=false to skip it (faster, but misses drift)

5. COMPUTE DIFF
   For each resource in desired state (.tf files):
     Case A: Not in state → action = CREATE (+)
     Case B: In state, no drift, config matches → action = NO-OP (=)
     Case C: In state, config changed, attribute is mutable → action = UPDATE (~)
     Case D: In state, config changed, attribute is immutable → action = REPLACE (-/+)
     Case E: In state but removed from .tf → action = DESTROY (-)

6. PRINT PLAN
   └── Structured diff of all proposed changes
        + = create  ~ = update  - = destroy  -/+ = replace
        Lines marked with "(known after apply)" = cloud will assign these at create time
```

### The Three-Way Comparison (Deep)

Most people think Terraform compares `.tf` → cloud. It's actually a three-way comparison:

```
   .tf files         .tfstate          Real Cloud
  (DESIRED)         (KNOWN)            (ACTUAL)
      │                 │                  │
      │                 └──── refresh ─────┤
      │                        │           │
      │            Updated state (known + actual)
      │                        │
      └──────── diff ──────────┘
                    │
              Plan output
```

Why this matters:

Scenario: Your `.tf` says `instance_type = "t3.medium"`. State says `t3.medium`. Cloud says `t3.large` (ops changed it manually).

Without refresh: plan sees `.tf=t3.medium`, state=`t3.medium` → no change proposed → drift silently ignored
With refresh: plan sees `.tf=t3.medium`, refreshed state=`t3.large` → proposes downgrade to `t3.medium` → drift surfaced

---

## State File Internals — JSON Structure Explained

A `.tfstate` file is a JSON document. Understanding its structure helps when doing state surgery or debugging.

```json
{
  "version": 4,              // tfstate format version (not your infra version)
  "terraform_version": "1.7.5",
  "serial": 42,              // increments with every apply — version counter
  "lineage": "abc-def-123",  // unique ID for this state file — never changes
  "outputs": {
    "load_balancer_dns": {
      "value": "my-lb-123.ap-northeast-1.elb.amazonaws.com",
      "type": "string"
    }
  },
  "resources": [
    {
      "module": "module.networking",  // present if inside a module
      "mode": "managed",              // "managed" = resource, "data" = data source
      "type": "aws_vpc",
      "name": "main",                 // your local name in .tf
      "provider": "provider[\"registry.terraform.io/hashicorp/aws\"]",
      "instances": [
        {
          "schema_version": 1,
          "attributes": {
            // EVERY attribute the provider returned after creation
            "id": "vpc-0abc123def456789",
            "arn": "arn:aws:ec2:ap-northeast-1:123456:vpc/vpc-0abc123def456789",
            "cidr_block": "10.0.0.0/16",
            "enable_dns_hostnames": true,
            "enable_dns_support": true,
            "instance_tenancy": "default",
            "tags": { "Name": "production-vpc", "ManagedBy": "terraform" },
            // ... 20+ more attributes
          },
          "sensitive_attributes": [],   // which attrs are marked sensitive
          "private": "base64encodedprivatedata"  // provider-internal metadata
        }
      ]
    }
  ]
}
```

Key fields to understand:

**`serial`**: Every successful `terraform apply` increments this by 1. If two processes try to write state simultaneously, the one with the lower serial loses (state conflict detection).

**`lineage`**: A UUID generated when state is first created. Stays the same forever. If you accidentally push state from a different project, Terraform detects the lineage mismatch and errors.

**`instances`**: An array because of `count` and `for_each`. A resource with `count = 3` has 3 instances in this array.

**`mode: "data"`**: Data sources are also stored in state (cached). Next time you run plan, Terraform uses the cached data source result rather than re-querying the API, unless you `-refresh`.

---

## Dependency Graph — How Terraform Orders Everything

### Implicit Dependencies (Automatic)

When resource B references resource A's attribute, Terraform automatically knows B depends on A:

```hcl
resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}

resource "aws_subnet" "app" {
  vpc_id     = aws_vpc.main.id   // B references A → implicit dependency
  cidr_block = "10.0.1.0/24"
}
```

Terraform's DAG for this config:

```
aws_vpc.main
      │
      ▼ (must exist first)
aws_subnet.app
```

### Explicit Dependencies (`depends_on`)

Sometimes B must wait for A but doesn't use A's attributes directly:

```hcl
resource "aws_iam_role_policy" "app_s3_access" {
  role   = aws_iam_role.app.name
  policy = data.aws_iam_policy_document.s3.json
}

resource "aws_instance" "app" {
  ami           = var.ami_id
  instance_type = "t3.medium"
  iam_instance_profile = aws_iam_instance_profile.app.name

  # The instance needs the IAM policy to be attached BEFORE it starts,
  # because the app bootstraps immediately and tries to access S3.
  # But the instance doesn't reference the policy's attributes directly.
  depends_on = [aws_iam_role_policy.app_s3_access]
}
```

Without `depends_on`: Terraform might launch the EC2 instance BEFORE the IAM policy is attached (they have no reference chain). The app starts, tries to access S3, fails with "Access Denied", and crashes.

With `depends_on`: Terraform guarantees the policy is attached before the instance launches.

### Parallel Execution

Terraform executes independent resources in parallel. The dependency graph determines the parallelism:

```
aws_vpc.main
      │
      ├─────────────────────────┐
      ▼                         ▼
aws_subnet.public          aws_subnet.private
      │                         │
      └──────────┬──────────────┘
                 ▼
         aws_nat_gateway.main
```

In this graph:
- `aws_subnet.public` and `aws_subnet.private` execute in PARALLEL (both depend only on VPC)
- `aws_nat_gateway.main` waits until BOTH subnets are complete

Default parallelism: 10 simultaneous API calls. Override:
```bash
terraform apply -parallelism=20  # increase for large infra
terraform apply -parallelism=1   # serialize everything (debug mode)
```

---

## Providers — The Plugin System Explained

### What a Provider Actually Is

A provider is a compiled Go binary that Terraform downloads from the registry. It:
1. Knows the API schema for every resource type it supports
2. Translates your HCL config into API calls (HTTP requests)
3. Translates API responses back into Terraform attributes
4. Reports which attributes are immutable (triggers replace on change)
5. Handles authentication to the cloud platform

```
Your .tf file          Provider (plugin)          Cloud API
-----------            -----------------          ---------
resource               translates to              POST /ec2/instances
"aws_instance"    →    CreateInstance()      →    { ami: "...", instanceType: "..." }
"web" { ... }          API call
                   ←   returns                ←   { instanceId: "i-abc", publicIp: "..." }
                       attributes
```

### Provider Discovery and Download

```bash
terraform init
# Terraform searches required_providers blocks for source addresses
# Downloads matching binaries from registry.terraform.io
# Stores in: .terraform/providers/registry.terraform.io/hashicorp/aws/5.31.0/linux_amd64/

ls .terraform/providers/registry.terraform.io/hashicorp/aws/
# 5.31.0/
```

### Multiple Providers in One Config

```hcl
# Create resources in AWS AND configure them in Dynatrace simultaneously
provider "aws" {
  region = "ap-northeast-1"
}

provider "dynatrace" {
  dt_env_url   = "https://xyz.live.dynatrace.com/api"
  dt_api_token = var.dynatrace_token
}

# Create the EC2 instance
resource "aws_instance" "app" {
  ami           = var.ami_id
  instance_type = "t3.medium"
}

# Create a Dynatrace alerting profile for it (different provider, same apply)
resource "dynatrace_alerting_profile" "app" {
  name = "app-server-alerts"
  depends_on = [aws_instance.app]
}
```

One `terraform apply` creates both the AWS resource and the Dynatrace config atomically.

---

## Plan Output — Reading Every Symbol

```
Terraform will perform the following actions:

  # aws_instance.web will be created                  ← CREATE (new resource)
  + resource "aws_instance" "web" {
      + ami                          = "ami-0c55b159cbfafe1f0"
      + instance_type                = "t3.medium"
      + id                           = (known after apply)  ← AWS will assign
      + public_ip                    = (known after apply)
      + tags_all                     = (known after apply)  ← computed from provider default_tags
    }

  # aws_instance.old will be destroyed                ← DESTROY
  - resource "aws_instance" "old" {
      - ami           = "ami-old123" -> null
      - instance_type = "t3.small"  -> null
      - id            = "i-0xxxxxxxxxxx" -> null
    }

  # aws_instance.app must be replaced                 ← REPLACE (immutable attr changed)
  # (destroy then create)
-/+ resource "aws_instance" "app" {
      ~ instance_type = "t3.small" -> "t3.medium"  ← mutable, just update
      + ami           = "ami-new456"                ← forces replacement
      - ami           = "ami-old123"                ← old value being removed
        id            = "i-0yyy"  # forces replacement
    }

  # aws_security_group.app will be updated in-place   ← UPDATE (mutable)
  ~ resource "aws_security_group" "app" {
        id   = "sg-12345"
      ~ tags = {
          + "NewTag"    = "value"                   ← tag being added
          - "OldTag"    = "removed"                 ← tag being removed
            "Name"      = "app-sg"                  ← unchanged (no +/-)
        }
    }

Plan: 1 to add, 1 to change, 1 to destroy.
                   │            │            │
                   │            │            └── aws_instance.old
                   │            └── aws_security_group.app
                   └── aws_instance.web
```

The summary line at the bottom is the first thing to read. If it says "3 to destroy" in a config you expected to only add resources — STOP and investigate before applying.
