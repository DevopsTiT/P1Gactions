# Part 7 Expanded — Import & State Surgery: Every Scenario with Full Commands

---

## The Import Problem — Why It's Hard

Importing existing infrastructure is the hardest part of Terraform adoption. The challenge:

1. Real infrastructure has **hundreds of attributes** — you must declare them all in `.tf` or Terraform will try to change them
2. Some attributes are **write-only** (like database passwords) — they were set at creation but the cloud API never returns them
3. Some resources have **complex relationships** — a security group references a VPC, which references nothing, but they must be imported in the right order
4. **Drift accumulates over years** — the actual config has diverged significantly from what was originally intended

### The Import Reality Check

Before importing, estimate the scope:
```bash
# Count resources by type in your AWS account
aws ec2 describe-instances --query 'length(Reservations[*].Instances[*])' --output text
aws rds describe-db-instances --query 'length(DBInstances)' --output text
aws s3api list-buckets --query 'length(Buckets)' --output text

# 50 EC2 instances × 20 min each = 16 hours of import work
# Plan accordingly — don't try to import everything in a weekend
```

---

## Import Strategies — Choose the Right One

### Strategy 1: Incremental Import (Recommended)

Import one resource or one service at a time. Start with the least risky:

```
Week 1: Import S3 buckets (no downtime risk, no data loss risk)
Week 2: Import security groups and VPCs (no services affected)
Week 3: Import EC2 instances (add lifecycle ignore_changes = all initially)
Week 4: Import RDS instances (most careful — data loss risk)
```

### Strategy 2: Brownfield Module Pattern

Write modules that accept a pre-existing resource ID and skip creation if it's provided:

```hcl
# Module variable
variable "existing_vpc_id" {
  description = "Set to reuse an existing VPC instead of creating one"
  type        = string
  default     = ""
}

# Create VPC only if no existing ID provided
resource "aws_vpc" "main" {
  count      = var.existing_vpc_id == "" ? 1 : 0
  cidr_block = var.vpc_cidr
}

# Locals: use existing ID or created ID
locals {
  vpc_id = var.existing_vpc_id != "" ? var.existing_vpc_id : aws_vpc.main[0].id
}
```

During migration: set `existing_vpc_id = "vpc-abc123"` → Terraform uses the existing VPC without creating one, and without needing to import it.

### Strategy 3: Parallel Run and Cut Over

1. Write all `.tf` for a fresh deployment (ignoring existing infra)
2. Deploy fresh infra alongside the old (traffic on old)
3. Test new infra thoroughly
4. Cut traffic over (DNS change, load balancer swap)
5. Decommission old infra manually
6. No import needed — Terraform always owned the new infra

Downside: temporarily double the infrastructure cost.

---

## Step-by-Step Import for Common Resource Types

### AWS EC2 Instance — Full Import Walkthrough

```bash
# Step 1: Find the instance ID
aws ec2 describe-instances \
  --filters "Name=tag:Name,Values=production-web-01" \
  --query "Reservations[0].Instances[0].InstanceId" \
  --output text
# i-0abc123def456789

# Step 2: Describe the instance to get ALL attributes
aws ec2 describe-instances \
  --instance-ids i-0abc123def456789 \
  --output json > instance-details.json
cat instance-details.json | jq '.Reservations[0].Instances[0]'
```

Write the initial `.tf` block:
```hcl
# main.tf
resource "aws_instance" "web_01" {
  # Start with just the required attributes
  ami           = "ami-0c55b159cbfafe1f0"   # from describe output
  instance_type = "t3.medium"

  # After import, plan will tell you what else needs to be set
  lifecycle {
    ignore_changes = all   # ignore all until we've matched the config
  }
}
```

```bash
# Step 3: Import
terraform import aws_instance.web_01 i-0abc123def456789

# Step 4: Show the imported state to see all attributes
terraform state show aws_instance.web_01
# This reveals ALL attributes: subnet_id, security_groups, key_name, iam role, etc.

# Step 5: Run plan and fill in missing attributes iteratively
terraform plan
# Shows: + subnet_id = "subnet-xxx" (missing from .tf)
# Add it. Plan again. Repeat until plan shows no changes.
```

Final `.tf` after iteration:
```hcl
resource "aws_instance" "web_01" {
  ami                         = "ami-0c55b159cbfafe1f0"
  instance_type               = "t3.medium"
  subnet_id                   = "subnet-0123456789abcdef0"
  vpc_security_group_ids      = ["sg-0123456789abcdef0"]
  iam_instance_profile        = "production-app-profile"
  key_name                    = "production-key"
  associate_public_ip_address = false
  disable_api_termination     = true
  monitoring                  = true

  root_block_device {
    volume_type           = "gp3"
    volume_size           = 50
    delete_on_termination = true
    encrypted             = true
  }

  tags = {
    Name        = "production-web-01"
    Environment = "production"
    ManagedBy   = "terraform"
  }

  lifecycle {
    prevent_destroy = true   # now that it's managed, protect it
    ignore_changes = [
      ami,          # SSM manages AMI updates
      user_data,    # bootstrapped externally
    ]
  }
}
```

---

### AWS RDS Instance — Sensitive Attribute Problem

```bash
# Import the RDS instance
terraform import aws_db_instance.main production-postgres
```

The challenge: RDS `password` is write-only. After import:
```bash
terraform state show aws_db_instance.main
# password = (sensitive)  ← null in state, cloud never returns it
```

```bash
terraform plan
# + password = (sensitive value)  ← Terraform wants to SET a password
# because state shows null and your .tf has a var.db_password value
```

Fix: set the password in `.tf` but also tell Terraform not to update it:

```hcl
resource "aws_db_instance" "main" {
  identifier     = "production-postgres"
  engine         = "postgres"
  engine_version = "15.4"
  instance_class = "db.r6g.large"

  username = "dbadmin"
  password = var.db_password   # must match the ACTUAL current password

  lifecycle {
    prevent_destroy = true
    ignore_changes  = [
      password,              # managed by rotation scripts, not Terraform
      snapshot_identifier,   # ignore snapshot-based restores
    ]
  }
}
```

Set `TF_VAR_db_password` to the actual current password before planning:
```bash
export TF_VAR_db_password=$(aws secretsmanager get-secret-value \
  --secret-id production/rds/master-password \
  --query SecretString --output text | jq -r '.password')
terraform plan   # should show no changes
```

---

### Kubernetes Resources — Import Pattern

```bash
# Import a namespace
terraform import kubernetes_namespace.monitoring monitoring

# Import a deployment (format: namespace/name)
terraform import kubernetes_deployment.app default/my-app

# Import a service
terraform import kubernetes_service.app default/my-app-svc

# Import a ConfigMap
terraform import kubernetes_config_map.app "default/app-config"

# Import a secret (format: namespace/name)
terraform import kubernetes_secret.app "default/app-secrets"
```

After importing Kubernetes resources, the `.tf` config is verbose:
```hcl
resource "kubernetes_deployment" "app" {
  metadata {
    name      = "my-app"
    namespace = "default"
    labels = {
      app = "my-app"
    }
  }

  spec {
    replicas = 3
    selector {
      match_labels = { app = "my-app" }
    }
    template {
      metadata {
        labels = { app = "my-app" }
      }
      spec {
        container {
          name  = "app"
          image = "my-registry/my-app:latest"
          port { container_port = 8080 }
        }
      }
    }
  }

  lifecycle {
    ignore_changes = [
      spec[0].template[0].spec[0].container[0].image,  # GitOps manages image
    ]
  }
}
```

---

## State Surgery — Every Command Explained

### `terraform state list` — Finding Resource Addresses

```bash
# List everything
terraform state list
# aws_vpc.main
# aws_subnet.public[0]
# aws_subnet.public[1]
# module.compute.aws_instance.app["payments"]
# module.compute.aws_instance.app["checkout"]
# module.database.aws_db_instance.main

# Filter: only resources in a module
terraform state list module.compute

# Filter: resources matching a pattern
terraform state list 'module.compute.aws_instance.*'

# Filter: a specific for_each key
terraform state list 'module.compute.aws_instance.app["payments"]'

# Count total resources
terraform state list | wc -l
```

### `terraform state show` — Full Attribute Dump

```bash
# Show all attributes of a resource (very useful for import debugging)
terraform state show module.compute.aws_instance.app[\"payments\"]

# Output example:
# resource "aws_instance" "app" {
#     ami                          = "ami-0c55b159cbfafe1f0"
#     arn                          = "arn:aws:ec2:ap-northeast-1:123456:instance/i-0abc123"
#     id                           = "i-0abc123"
#     instance_type                = "t3.medium"
#     private_ip                   = "10.0.1.5"
#     public_ip                    = "54.12.34.56"
#     subnet_id                    = "subnet-0abc123"
#     vpc_security_group_ids       = toset(["sg-0abc123"])
#     # ... 40+ more attributes
# }

# Use with jq for specific fields (via JSON)
terraform show -json | jq '
  .values.root_module.resources[] |
  select(.address == "aws_instance.web") |
  .values | { id, instance_type, private_ip }
'
```

### `terraform state mv` — Rename / Restructure Operations

```bash
# Case 1: Rename a resource
# .tf change: aws_instance.web_server → aws_instance.app
terraform state mv aws_instance.web_server aws_instance.app

# Case 2: Move resource into a module
# .tf change: added module.compute{} block that contains aws_instance.app
terraform state mv aws_instance.app module.compute.aws_instance.app

# Case 3: Move out of a module (reverse)
terraform state mv module.compute.aws_instance.app aws_instance.app

# Case 4: Rename a module
terraform state mv module.old_compute module.compute

# Case 5: Count index to for_each key
terraform state mv 'aws_instance.worker[0]' 'aws_instance.worker["payments"]'
terraform state mv 'aws_instance.worker[1]' 'aws_instance.worker["checkout"]'
terraform state mv 'aws_instance.worker[2]' 'aws_instance.worker["inventory"]'

# After each mv, verify state looks right
terraform state list | grep worker
terraform plan  # should show no changes after all moves complete
```

### `terraform state rm` — Remove From State

```bash
# Remove a resource Terraform should forget about (not destroy)
terraform state rm aws_instance.old_manual_server
# Removed aws_instance.old_manual_server from state successfully.
# The real EC2 instance still exists — Terraform just won't manage it.

# Remove a whole module from state
terraform state rm module.old_module
# Removes ALL resources within that module from state

# After rm: if the .tf block still exists, terraform plan shows + (wants to create)
# So either:
#   1. Delete the .tf block too (ignore the resource forever)
#   2. Re-import it elsewhere
```

---

## Recovering from State Corruption

### Symptom: State Tells You to Create Resources That Exist

```
Plan shows:
  + aws_db_instance.main  ← wants to CREATE the database
  # But the database exists! It's just not in state.
```

Cause: state was lost or reset. Fix: import the existing resource.

### Symptom: State Tells You to Destroy Resources That Are Gone

```
Plan shows:
  - aws_instance.old  ← wants to DESTROY an instance
  # But the instance was already deleted months ago.
```

Cause: resource was manually deleted but state wasn't updated. Fix:
```bash
# Just remove the orphan from state — nothing to destroy
terraform state rm aws_instance.old
# Now plan shows no changes for that resource.
```

### Symptom: Plan Errors "Resource already exists"

```
Error: Error creating Security Group: InvalidGroup.Duplicate: 
The security group 'app-sg' already exists for VPC 'vpc-xxx'
```

Cause: resource exists in cloud but not in state (was imported to a different state, or state was reset). Fix: import it.

### Symptom: State Lock Timeout After Crash

```
Error: Error acquiring the state lock
Lock Info:
  ID: abc-def-ghi
  Who: ci-pipeline@github
  Created: 2026-07-31 03:00:00 (over 6 hours ago)
```

Process died mid-apply 6 hours ago. The lock was never released. Fix:
```bash
# Confirm the original process is truly dead (check CI/CD pipeline status first)
# Then force-release the lock
terraform force-unlock abc-def-ghi

# Verify state is consistent (the apply may have partially completed)
terraform plan
# Review carefully for unexpected creates or destroys before applying
```
