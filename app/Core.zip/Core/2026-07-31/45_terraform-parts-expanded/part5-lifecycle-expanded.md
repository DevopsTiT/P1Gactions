# Part 5 Expanded — Lifecycle, count, for_each: Every Edge Case

---

## Lifecycle Rules — The Full Internal Mechanics

### How Terraform Decides to Replace vs Update

When you change a resource attribute, Terraform checks the provider schema:

```
Provider schema for aws_instance:
  ami:                        ForceNew = true    ← changing this = REPLACE
  instance_type:              ForceNew = false   ← changing this = UPDATE (if stopped)
  availability_zone:          ForceNew = true    ← changing this = REPLACE
  tags:                       ForceNew = false   ← changing this = UPDATE
  vpc_security_group_ids:     ForceNew = false   ← changing this = UPDATE
  subnet_id:                  ForceNew = true    ← changing this = REPLACE
```

`ForceNew = true` is defined in the provider code — you cannot change this behavior through configuration. The `lifecycle` block works around it:
- `create_before_destroy` changes the ORDER of the replace (not whether it happens)
- `ignore_changes` makes Terraform pretend the attribute didn't change (preventing replace)

---

## `prevent_destroy` — Detailed Behavior

```hcl
resource "aws_db_instance" "production" {
  identifier     = "prod-postgres"
  engine         = "postgres"
  instance_class = "db.r6g.xlarge"

  lifecycle {
    prevent_destroy = true
  }
}
```

### What It Blocks — In Detail

Case 1: Direct `terraform destroy`
```bash
terraform destroy
# Error: Instance cannot be destroyed
# Resource module.database.aws_db_instance.production has lifecycle.prevent_destroy
# set, but the plan calls for this resource to be destroyed.
# To avoid this error and continue, remove lifecycle.prevent_destroy from
# the resource.
```

Case 2: Renaming a resource (triggers destroy + create at old + new address)
```hcl
# Change: aws_db_instance.production → aws_db_instance.main
# Without state mv, Terraform sees: destroy old address, create new address
# prevent_destroy stops the destroy step → you must run state mv first
```

Case 3: Changing an immutable attribute (triggers replace = destroy + create)
```hcl
resource "aws_db_instance" "production" {
  db_name        = "newname"   # changing db_name forces replacement (ForceNew=true)
  lifecycle {
    prevent_destroy = true
  }
}
# terraform plan output:
# Error: Instance cannot be destroyed
# The replacement plan requires destroying this resource first,
# but prevent_destroy is set.
```

### What It Does NOT Block

```bash
# Anyone can delete the resource directly via AWS console or CLI
# Terraform doesn't know this happened until the next plan

aws rds delete-db-instance \
  --db-instance-identifier prod-postgres \
  --skip-final-snapshot
# ^ This works. prevent_destroy only stops Terraform itself.
```

### Using `prevent_destroy` Conditionally

```hcl
variable "environment" { type = string }

resource "aws_db_instance" "main" {
  identifier = "${var.environment}-db"

  lifecycle {
    # Only prevent destroy in production
    prevent_destroy = var.environment == "production" ? true : false
    # Terraform 1.3+: can use variables in lifecycle (with restrictions)
  }
}
```

Note: `prevent_destroy` cannot reference variables in older Terraform. Use a separate resource for production:

```hcl
# Production DB with protect
resource "aws_db_instance" "production_db" {
  count = var.environment == "production" ? 1 : 0
  lifecycle { prevent_destroy = true }
}

# Non-production DB without protect
resource "aws_db_instance" "dev_db" {
  count = var.environment != "production" ? 1 : 0
}
```

---

## `create_before_destroy` — The Naming Problem and Solutions

### Why Names Cause the Problem

AWS requires unique names within the same scope (region, VPC, account). If you try to create a new security group named "app-sg" while the old "app-sg" still exists:

```
create_before_destroy sequence:
  Step 1: CREATE aws_security_group "app-sg" (new)
          → ERROR: "Security group named 'app-sg' already exists in vpc-xxx"
  Step 2: Never reached
```

### Solution 1: `name_prefix` (AWS Generates Unique Names)

```hcl
resource "aws_security_group" "app" {
  name_prefix = "app-sg-"   # AWS appends random suffix: "app-sg-20240731-abc123"
  vpc_id      = var.vpc_id

  lifecycle { create_before_destroy = true }
}
# Old SG:  "app-sg-20240101-xyz789"  ← still exists during create
# New SG:  "app-sg-20240731-abc123"  ← created first, different name
# Old SG deleted after new is ready ✓
```

### Solution 2: Version Suffix in Names

```hcl
variable "sg_version" {
  default = "v1"
  # Bump to "v2" when you need to replace
}

resource "aws_security_group" "app" {
  name   = "app-sg-${var.sg_version}"  # "app-sg-v1" then "app-sg-v2"

  lifecycle { create_before_destroy = true }
}
```

### create_before_destroy Propagates to Dependencies

If resource B depends on resource A, and A has `create_before_destroy = true`, then B must also be replaced in create-before-destroy order:

```hcl
resource "aws_security_group" "app" {
  name_prefix = "app-sg-"
  lifecycle { create_before_destroy = true }
}

resource "aws_instance" "app" {
  # This instance depends on the security group
  vpc_security_group_ids = [aws_security_group.app.id]
  # create_before_destroy is INHERITED from the security group
  # You don't need to declare it on the instance
}
```

Terraform automatically propagates the create-before-destroy requirement up the dependency chain.

---

## `ignore_changes` — The Auto-Scaler War Explained

### Why Auto-Scalers and Terraform Fight

```
Timeline without ignore_changes:

T+0:   Terraform sets desired_capacity = 3
T+30m: Traffic spike → auto-scaler increases desired_capacity to 8
T+1h:  Engineer runs terraform apply (routine change to security group)
T+1h:  Terraform sees: .tf says 3, cloud says 8 → plans to set back to 3
T+1h:  Apply runs → desired_capacity slammed back to 3
T+1h:  Service degrades (8 instances handling load, now down to 3)
T+2h:  Pagerduty fires 🔥
```

```
Timeline WITH ignore_changes = [desired_capacity]:

T+0:   Terraform sets desired_capacity = 3 (initial creation only)
T+30m: Traffic spike → auto-scaler increases desired_capacity to 8
T+1h:  Engineer runs terraform apply
T+1h:  Terraform ignores desired_capacity → doesn't touch it
T+1h:  Auto-scaler's value (8) preserved ✓
```

### What Exactly `ignore_changes` Ignores

```hcl
resource "aws_autoscaling_group" "app" {
  name_prefix      = "app-asg-"
  desired_capacity = 3    # set during creation, then ignored

  lifecycle {
    ignore_changes = [
      desired_capacity,                 # ignore specific attribute
      tags["kubernetes.io/cluster/"],   # ignore specific tag key
    ]
  }
}
```

`ignore_changes` affects:
- `terraform plan`: the ignored attribute is excluded from diff calculation
- `terraform apply`: the ignored attribute is not passed in update calls
- `terraform show`: the ignored attribute still appears with its cloud value

`ignore_changes` does NOT affect:
- The initial resource creation (all attributes are set on first create)
- `terraform destroy` (the resource is still destroyed)
- Manual reads of the attribute (still visible in state and output)

### `ignore_changes = all` — Full External Management

```hcl
resource "kubernetes_namespace" "monitoring" {
  metadata {
    name = "monitoring"
    labels = {
      "managed-by" = "terraform"
    }
  }

  lifecycle {
    ignore_changes = all
    # Reason: the namespace is bootstrapped by Terraform but then
    # managed by ArgoCD/Flux which continuously reconciles labels and annotations.
    # We don't want Terraform to fight with GitOps over namespace config.
  }
}
```

---

## `count` vs `for_each` — The Complete Comparison

### Why the Problem Exists — Terraform Addresses Explained

Every resource in Terraform has an address. The address is how Terraform links state records to .tf declarations:

```
count syntax:
  resource "aws_instance" "worker" {
    count = 3
    ...
  }
  
  Creates addresses:
    aws_instance.worker[0]
    aws_instance.worker[1]
    aws_instance.worker[2]
  
  State records keyed by: 0, 1, 2 (integers)

for_each syntax:
  resource "aws_instance" "worker" {
    for_each = { alice = {...}, bob = {...}, carol = {...} }
    ...
  }
  
  Creates addresses:
    aws_instance.worker["alice"]
    aws_instance.worker["bob"]
    aws_instance.worker["carol"]
  
  State records keyed by: "alice", "bob", "carol" (stable strings)
```

### The Index Shift Problem — Step by Step

```hcl
variable "workers" {
  default = ["alice", "bob", "carol"]
}

resource "aws_instance" "worker" {
  count         = length(var.workers)
  instance_type = "t3.medium"
  tags = { Name = var.workers[count.index] }
}
```

Initial state:
```
aws_instance.worker[0] → i-aaa → Name: alice
aws_instance.worker[1] → i-bbb → Name: bob
aws_instance.worker[2] → i-ccc → Name: carol
```

Remove "bob" from the list:
```hcl
variable "workers" {
  default = ["alice", "carol"]  # bob removed
}
```

Terraform's plan:
```
~ aws_instance.worker[1]  # update: Name bob → carol
                           # (this is carol, now at index 1)
- aws_instance.worker[2]  # destroy carol's old instance
                           # (this was carol, but Terraform thinks it's gone)
```

Result: `i-bbb` (was bob) gets renamed to carol. `i-ccc` (was carol) gets destroyed. Two changes instead of one.

### The for_each Solution

```hcl
variable "workers" {
  default = {
    alice = { instance_type = "t3.medium" }
    bob   = { instance_type = "t3.small"  }
    carol = { instance_type = "t3.medium" }
  }
}

resource "aws_instance" "worker" {
  for_each      = var.workers
  instance_type = each.value.instance_type
  tags          = { Name = each.key }
}
```

Remove "bob":
```hcl
variable "workers" {
  default = {
    alice = { instance_type = "t3.medium" }
    # bob removed
    carol = { instance_type = "t3.medium" }
  }
}
```

Terraform's plan:
```
- aws_instance.worker["bob"]   # destroy only bob ✓
  # alice and carol unchanged — their addresses are stable strings
```

---

## Dynamic Blocks — Deep Dive

### When Static Blocks Fail

```hcl
# Static — cannot be parameterized, must hardcode every rule
resource "aws_security_group" "app" {
  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  # What if I need 10 rules? 20? From a module that doesn't know the count?
}
```

### Dynamic Block with All Features

```hcl
variable "ingress_rules" {
  type = list(object({
    port             = number
    protocol         = string
    cidr_blocks      = optional(list(string), [])
    security_groups  = optional(list(string), [])
    description      = string
  }))
}

resource "aws_security_group" "app" {
  name_prefix = "app-"
  vpc_id      = var.vpc_id

  # Dynamic ingress — one block per rule
  dynamic "ingress" {
    for_each = var.ingress_rules
    # iterator = "rule"  ← optional: rename "ingress" to "rule" inside content{}

    content {
      description     = ingress.value.description
      from_port       = ingress.value.port
      to_port         = ingress.value.port
      protocol        = ingress.value.protocol
      cidr_blocks     = ingress.value.cidr_blocks
      security_groups = ingress.value.security_groups
    }
  }

  # Static egress (no dynamic needed if it's always the same)
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
```

### Nested Dynamic Blocks

```hcl
# EKS node groups with multiple taints per group
variable "node_groups" {
  default = {
    general = {
      instance_types = ["t3.medium"]
      taints = []
    }
    spot = {
      instance_types = ["t3.medium", "t3.large"]
      taints = [
        { key = "spot", value = "true", effect = "NO_SCHEDULE" }
      ]
    }
  }
}

resource "aws_eks_node_group" "groups" {
  for_each = var.node_groups

  cluster_name    = aws_eks_cluster.main.name
  node_group_name = each.key

  dynamic "taint" {
    for_each = each.value.taints   # inner loop: taints inside each node group
    content {
      key    = taint.value.key
      value  = taint.value.value
      effect = taint.value.effect
    }
  }
}
```

---

## `moved` Block — Refactoring Without Destroy (Terraform 1.1+)

The `moved` block is the declarative alternative to `terraform state mv`. It lets you refactor resource addresses and check them into code:

```hcl
# You renamed aws_instance.web_server to aws_instance.app
# Without moved block: Terraform destroys web_server, creates app

# With moved block:
moved {
  from = aws_instance.web_server
  to   = aws_instance.app
}
```

```bash
terraform plan
# aws_instance.app has moved from aws_instance.web_server
# (no destroy/create — just an address rename in state)
terraform apply  # commits the move
# After apply: remove the moved{} block — it's done its job
```

Module refactoring:
```hcl
# You moved a resource into a module
moved {
  from = aws_instance.app
  to   = module.compute.aws_instance.app
}

# count to for_each migration
moved {
  from = aws_instance.worker[0]
  to   = aws_instance.worker["payments"]
}
moved {
  from = aws_instance.worker[1]
  to   = aws_instance.worker["checkout"]
}
```

The `moved` block is better than `terraform state mv` because:
- It's reviewable in PRs — teammates see the rename
- It's documented — the reason for the move is in the commit message
- It runs automatically during `apply` — no manual CLI commands
- It can be tested with `terraform plan` before applying
