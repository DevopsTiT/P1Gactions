# Part 8 Expanded — CI/CD, Drift Detection & Security: Full Production Setup

---

## The CI/CD Problem Terraform Solves

Without CI/CD for Terraform:
```
Engineer A: terraform apply (from laptop, v1.5.0)
Engineer B: terraform apply (from laptop, v1.7.0, different provider version)
Engineer C: terraform apply (from prod server, with prod IAM admin credentials)

Nobody knows:
  - Which version of Terraform was used last
  - What the plan showed before it was applied
  - Who applied what and when
  - Whether the plan was reviewed by anyone
```

With CI/CD:
```
All applies go through Git → PR review → pipeline
Pipeline has: consistent Terraform version, consistent credentials,
              saved plan artifacts, audit log in GitHub Actions
```

---

## Pipeline Design Principles

### Principle 1: Plan is Reviewable Before Apply

The `terraform plan` output must be posted as a PR comment BEFORE the PR is merged. A reviewer must see "3 resources to add, 0 to change, 0 to destroy" (or whatever the diff is) and approve it.

### Principle 2: Plan File Is Reused in Apply

```
PR pipeline:    terraform plan -out=tfplan  → save tfplan artifact
Merge pipeline: terraform apply tfplan      ← uses SAVED plan, not re-plan
```

If you re-plan at apply time, the state might have changed (another engineer applied something between your PR and your merge). The saved plan ensures you apply exactly what was reviewed.

### Principle 3: Production Has Manual Approval Gate

Even with automation, production changes should require a human approval:
- GitHub Actions: "Environments" with required reviewers
- GitLab CI: manual jobs
- Atlantis: PR-based workflow with explicit `atlantis apply` command

### Principle 4: Read-Only in PRs, Write in Main

PR pipeline role: ReadOnly + state read = can plan but cannot change infrastructure
Merge pipeline role: Full deploy permissions = can apply

---

## Complete GitHub Actions Pipeline — Explained Line by Line

```yaml
# .github/workflows/terraform-production.yml

name: Terraform — Production

# Triggers
on:
  pull_request:
    branches: [main]
    paths:
      - "environments/production/**"   # only trigger on production changes
      - "modules/**"                   # module changes affect production too

  push:
    branches: [main]
    paths:
      - "environments/production/**"
      - "modules/**"

# Prevent concurrent pipeline runs on the same environment.
# If a second push comes in while the first is running, the second queues.
concurrency:
  group: terraform-production
  cancel-in-progress: false   # DON'T cancel running applies!

env:
  TF_VERSION: "1.7.5"
  AWS_REGION:  "ap-northeast-1"
  WORK_DIR:    "environments/production"

jobs:
  # ─── PLAN JOB (runs on every PR commit) ───────────────────────────────
  plan:
    name: "Terraform Plan"
    if: github.event_name == 'pull_request'
    runs-on: ubuntu-latest

    permissions:
      id-token: write       # needed for OIDC: get a JWT from GitHub
      contents: read        # needed to checkout the repo
      pull-requests: write  # needed to post the plan as a PR comment

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Setup Terraform ${{ env.TF_VERSION }}
        uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: ${{ env.TF_VERSION }}
          # terraform_wrapper: false  # if you parse terraform output in scripts

      # OIDC authentication — no static AWS credentials stored anywhere
      - name: Configure AWS Credentials (read-only role)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::999999999999:role/TerraformPlan
          aws-region: ${{ env.AWS_REGION }}
          role-session-name: terraform-plan-${{ github.run_id }}

      - name: terraform init
        working-directory: ${{ env.WORK_DIR }}
        run: terraform init -input=false -no-color
        # -input=false: fail instead of prompting for missing vars
        # -no-color: cleaner output in CI logs

      - name: terraform fmt check
        working-directory: ${{ env.WORK_DIR }}
        run: |
          terraform fmt -check -recursive -no-color
          echo "✓ All .tf files are properly formatted"

      - name: terraform validate
        working-directory: ${{ env.WORK_DIR }}
        run: terraform validate -no-color

      # Run plan and capture output + exit code
      - name: terraform plan
        id: plan
        working-directory: ${{ env.WORK_DIR }}
        run: |
          set +e  # don't exit on non-zero (exit 2 = changes, not an error)
          terraform plan \
            -no-color \
            -input=false \
            -out=tfplan \
            2>&1 | tee plan_output.txt
          echo "exit_code=${PIPESTATUS[0]}" >> $GITHUB_OUTPUT
          set -e
        env:
          # Secrets passed as environment variables (never in .tf files)
          TF_VAR_db_password:         ${{ secrets.PROD_DB_PASSWORD }}
          TF_VAR_dynatrace_api_token:  ${{ secrets.DYNATRACE_API_TOKEN }}

      # Fail the job if plan errored (exit code 1)
      # Exit code 2 means "success with changes" — that's fine for a plan job
      - name: Check plan exit code
        run: |
          code="${{ steps.plan.outputs.exit_code }}"
          if [ "$code" = "1" ]; then
            echo "terraform plan failed with error"
            exit 1
          fi

      # Upload the saved plan binary so the apply job can use it
      - name: Upload plan artifact
        uses: actions/upload-artifact@v4
        with:
          name: tfplan-production-${{ github.sha }}
          path: ${{ env.WORK_DIR }}/tfplan
          retention-days: 5   # plans older than 5 days shouldn't be applied

      # Post the plan output as a comment on the PR
      - name: Post Plan to PR
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs');
            const planOutput = fs.readFileSync(
              `${{ env.WORK_DIR }}/plan_output.txt`, 'utf8'
            );

            // Truncate if too long for a GitHub comment
            const MAX_LEN = 65000;
            const truncated = planOutput.length > MAX_LEN
              ? planOutput.substring(0, MAX_LEN) + '\n\n⚠️ Output truncated — see full log in Actions'
              : planOutput;

            const exitCode = '${{ steps.plan.outputs.exit_code }}';
            const status = exitCode === '0' ? '✅ No changes' : '⚠️ Changes pending';

            // Find existing plan comment and update it (cleaner than creating a new one)
            const { data: comments } = await github.rest.issues.listComments({
              owner: context.repo.owner,
              repo: context.repo.repo,
              issue_number: context.issue.number
            });

            const existing = comments.find(c => c.body.startsWith('## Terraform Plan'));

            const body = `## Terraform Plan — Production ${status}\n\n\`\`\`hcl\n${truncated}\n\`\`\``;

            if (existing) {
              await github.rest.issues.updateComment({
                owner: context.repo.owner,
                repo: context.repo.repo,
                comment_id: existing.id,
                body
              });
            } else {
              await github.rest.issues.createComment({
                owner: context.repo.owner,
                repo: context.repo.repo,
                issue_number: context.issue.number,
                body
              });
            }

  # ─── APPLY JOB (runs after merge to main) ─────────────────────────────
  apply:
    name: "Terraform Apply"
    if: github.event_name == 'push' && github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest

    # This environment requires approval in GitHub Settings → Environments → production
    # At least 1 designated reviewer must approve before this job runs
    environment:
      name: production
      url: https://app.company.com   # shown in GitHub UI after deploy

    permissions:
      id-token: write
      contents: read

    steps:
      - uses: actions/checkout@v4

      - name: Setup Terraform
        uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: ${{ env.TF_VERSION }}

      # Apply role has WRITE permissions (can modify infrastructure)
      - name: Configure AWS Credentials (deploy role)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::999999999999:role/TerraformDeploy
          aws-region: ${{ env.AWS_REGION }}
          role-session-name: terraform-apply-${{ github.sha }}

      - name: terraform init
        working-directory: ${{ env.WORK_DIR }}
        run: terraform init -input=false -no-color

      # Download the EXACT plan that was reviewed in the PR
      - name: Download plan artifact
        uses: actions/download-artifact@v4
        with:
          name: tfplan-production-${{ github.sha }}
          path: ${{ env.WORK_DIR }}

      # Apply the saved plan — no re-plan, no surprises
      - name: terraform apply
        working-directory: ${{ env.WORK_DIR }}
        run: terraform apply -input=false -no-color tfplan
        env:
          TF_VAR_db_password:         ${{ secrets.PROD_DB_PASSWORD }}
          TF_VAR_dynatrace_api_token:  ${{ secrets.DYNATRACE_API_TOKEN }}

      # Capture outputs for other systems
      - name: Read Terraform Outputs
        working-directory: ${{ env.WORK_DIR }}
        id: outputs
        run: |
          echo "alb_dns=$(terraform output -raw alb_dns_name)" >> $GITHUB_OUTPUT
          echo "db_endpoint=$(terraform output -raw db_endpoint)" >> $GITHUB_OUTPUT

      - name: Update deployment tracking
        run: |
          echo "Applied commit ${{ github.sha }} to production at $(date)"
          # Could post to Dynatrace deployment events API, Slack, PagerDuty, etc.
```

---

## Drift Detection Pipeline — Complete Example

```yaml
# .github/workflows/drift-detection.yml

name: Drift Detection

on:
  # Run every 6 hours
  schedule:
    - cron: "0 */6 * * *"
  # Allow manual trigger for immediate check
  workflow_dispatch:

jobs:
  detect-drift:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        # Check all environments in parallel
        environment: [dev, staging, production]
      fail-fast: false  # check all envs even if one fails

    permissions:
      id-token: write
      contents: read

    steps:
      - uses: actions/checkout@v4
      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: "1.7.5"

      - name: Configure AWS Credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          # Read-only role per environment
          role-to-assume: arn:aws:iam::999999999999:role/TerraformPlan-${{ matrix.environment }}
          aws-region: ap-northeast-1

      - name: terraform init
        working-directory: environments/${{ matrix.environment }}
        run: terraform init -input=false -no-color

      - name: Check for drift
        id: drift
        working-directory: environments/${{ matrix.environment }}
        run: |
          set +e
          # -detailed-exitcode: 0=no changes, 1=error, 2=changes detected
          terraform plan \
            -refresh-only \
            -detailed-exitcode \
            -no-color \
            2>&1 | tee drift_output.txt
          echo "exit_code=$?" >> $GITHUB_OUTPUT
          set -e

      - name: Alert on drift detected
        if: steps.drift.outputs.exit_code == '2'
        uses: actions/github-script@v7
        with:
          script: |
            const fs = require('fs');
            const output = fs.readFileSync('environments/${{ matrix.environment }}/drift_output.txt', 'utf8');
            const env = '${{ matrix.environment }}';

            // Create a GitHub issue for drift
            await github.rest.issues.create({
              owner: context.repo.owner,
              repo: context.repo.repo,
              title: `⚠️ Infrastructure drift detected in ${env}`,
              body: `## Drift Detected\n\nEnvironment: **${env}**\n\nSomeone made manual changes that don't match Terraform config.\n\n\`\`\`\n${output.substring(0, 5000)}\n\`\`\`\n\nRun \`terraform apply -refresh-only\` to accept drift, or \`terraform apply\` to revert it.`,
              labels: ['infrastructure', 'drift', env]
            });

      - name: Alert on drift via Slack
        if: steps.drift.outputs.exit_code == '2'
        run: |
          curl -X POST "${{ secrets.SLACK_WEBHOOK_URL }}" \
            -H "Content-Type: application/json" \
            -d '{
              "text": "⚠️ Terraform drift detected in *${{ matrix.environment }}*!",
              "attachments": [{
                "color": "warning",
                "text": "Manual changes were made outside Terraform. Check GitHub Issues for details.",
                "footer": "Terraform Drift Detection"
              }]
            }'

      - name: Fail job if drift detected (visibility in CI dashboard)
        if: steps.drift.outputs.exit_code == '2'
        run: exit 1

      - name: Fail job on plan error
        if: steps.drift.outputs.exit_code == '1'
        run: exit 1
```

---

## Security Hardening — Complete Checklist

### 1. Never Store Static AWS Credentials

```yaml
# BAD — static credentials in GitHub Secrets
env:
  AWS_ACCESS_KEY_ID:     ${{ secrets.AWS_ACCESS_KEY_ID }}      # ← risky
  AWS_SECRET_ACCESS_KEY: ${{ secrets.AWS_SECRET_ACCESS_KEY }}  # ← risky

# GOOD — OIDC, GitHub exchanges for temporary credentials
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::999:role/GitHubActions
    aws-region: ap-northeast-1
```

### 2. Scan .tf Files for Secrets Before Commit

```bash
# Install tfsec (static security scanner for Terraform)
brew install tfsec

# Scan the config
tfsec environments/production/

# Common findings tfsec catches:
# - S3 buckets without encryption
# - Security groups with 0.0.0.0/0 on sensitive ports
# - RDS without encryption at rest
# - CloudTrail logging disabled
# - IAM policies with wildcard (*) resources

# Add to CI pipeline:
- name: tfsec scan
  run: tfsec environments/production/ --no-color
```

### 3. Use `checkov` for Policy-as-Code

```bash
pip install checkov

# Scan Terraform files
checkov -d environments/production/ --framework terraform

# Common Checkov checks for Terraform:
# CKV_AWS_6:   S3 bucket ACL not public-read
# CKV_AWS_18:  S3 access logging enabled
# CKV_AWS_57:  S3 bucket not public
# CKV_AWS_8:   EC2 instance has termination protection
# CKV_AWS_23:  RDS encryption at rest
# CKV_AWS_157: RDS deletion protection
```

### 4. Secrets in State — What to Do

Some resources store secrets in plaintext in state (passwords, certificates). Mitigations:

```hcl
# Option 1: Use AWS Secrets Manager and NEVER put the value in state
resource "aws_db_instance" "main" {
  password = data.aws_secretsmanager_secret_version.db_pass.secret_string
  # The value fetched from Secrets Manager is stored in state
  # BUT it's also in Secrets Manager, so state adds no new exposure
  lifecycle {
    ignore_changes = [password]  # prevent Terraform from reverting rotations
  }
}

# Option 2: Mark password as sensitive (hides from logs but still in state)
variable "db_password" {
  sensitive = true  # masked in plan output, but still stored in tfstate
}

# Option 3: Encrypt the state bucket (required baseline)
# All sensitive data in state is encrypted at rest in S3 (AES-256)
# + encrypt = true in backend config
```

### 5. State Bucket Security Policy

```hcl
resource "aws_s3_bucket_policy" "terraform_state" {
  bucket = aws_s3_bucket.terraform_state.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        # Block HTTP (only allow HTTPS)
        Sid       = "DenyHTTP"
        Effect    = "Deny"
        Principal = "*"
        Action    = "s3:*"
        Resource  = [
          aws_s3_bucket.terraform_state.arn,
          "${aws_s3_bucket.terraform_state.arn}/*"
        ]
        Condition = {
          Bool = { "aws:SecureTransport" = "false" }
        }
      },
      {
        # Block everything except the Terraform deploy role
        Sid       = "DenyAllExceptTerraform"
        Effect    = "Deny"
        NotPrincipal = {
          AWS = [
            "arn:aws:iam::999999999999:role/TerraformDeploy",
            "arn:aws:iam::999999999999:role/TerraformPlan",
            "arn:aws:iam::999999999999:root"   # account root for emergencies
          ]
        }
        Action   = "s3:*"
        Resource = [
          aws_s3_bucket.terraform_state.arn,
          "${aws_s3_bucket.terraform_state.arn}/*"
        ]
      }
    ]
  })
}
```

---

## Cost Control — Preventing Expensive Surprises

### 1. infracost — Cost Estimation in PRs

```yaml
# .github/workflows/terraform-production.yml (add to plan job)

- name: Setup Infracost
  uses: infracost/actions/setup@v2
  with:
    api-key: ${{ secrets.INFRACOST_API_KEY }}

- name: Generate Infracost cost estimate
  working-directory: ${{ env.WORK_DIR }}
  run: |
    infracost breakdown \
      --path . \
      --format json \
      --out-file infracost.json

- name: Post cost estimate to PR
  uses: infracost/actions/comment@v2
  with:
    path: ${{ env.WORK_DIR }}/infracost.json
    behavior: update
    # Posts estimated monthly cost of the planned changes to the PR:
    # "This change adds $45.20/month (+$12.50)"
```

### 2. Tagging for Cost Attribution

```hcl
# providers.tf — apply to EVERY resource automatically
provider "aws" {
  region = var.aws_region
  default_tags {
    tags = {
      Environment = var.environment
      Team        = var.team
      Project     = var.project
      CostCenter  = var.cost_center
      ManagedBy   = "terraform"
      Repository  = "github.com/my-org/infra"
    }
  }
}
```

With consistent tags, AWS Cost Explorer can show you:
- "Production environment costs: $2,340/month"
- "Payments team infrastructure: $890/month"
- "Cost center EC-001 total: $450/month"
