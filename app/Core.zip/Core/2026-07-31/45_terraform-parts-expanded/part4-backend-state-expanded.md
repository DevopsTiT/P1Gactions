# Part 4 Expanded — Remote Backend & State: Every Scenario Explained

---

## The State File as a Database

Think of the state file as Terraform's own private database. Like any production database:

| Database concept | Terraform state equivalent |
|---|---|
| Tables / rows | Resources and their attributes |
| Primary key | Resource address (`aws_instance.web`) |
| Transactions | `terraform apply` (atomic state update) |
| Backups | S3 versioning |
| Connection pooling | Remote backend (shared access) |
| Row locking | DynamoDB lock table |
| Schema migration | `terraform state mv` |
| Database export | `terraform state pull` |
| Database import | `terraform state push` |

This framing explains WHY you need all the backend infrastructure — you'd never run a production database as a local file without backups, access control, or locking.

---

## What Happens Inside `terraform init` — Backend Init Deep Dive

```bash
terraform init
```

Step-by-step:

```
1. Read terraform{} block from *.tf files
   → Find required_providers
   → Find backend configuration

2. Create .terraform/ directory if not exists

3. Download providers
   → Check .terraform.lock.hcl for pinned versions
   → If lock file exists: download exact hashes
   → If no lock file: resolve version constraints, download, CREATE lock file
   → Store at: .terraform/providers/registry.terraform.io/<namespace>/<name>/<version>/

4. Initialize backend
   → For S3 backend: test connectivity to S3 bucket
   → Verify bucket exists and you have s3:GetObject permission
   → Verify DynamoDB table exists and you have dynamodb:GetItem permission
   → Download existing state from S3 (if any) to verify format compatibility

5. Download modules
   → For each module{} block with source = "registry.terraform.io/..."
   → Download to: .terraform/modules/<module-name>/

6. Print summary:
   "Terraform has been successfully initialized!"
   "Provider requirements have been installed and you can now run terraform plan"
```

`.terraform/` directory contents after init:
```
.terraform/
├── providers/
│   └── registry.terraform.io/
│       └── hashicorp/
│           └── aws/
│               └── 5.31.0/
│                   └── linux_amd64/
│                       └── terraform-provider-aws_v5.31.0_x5  ← binary
├── modules/
│   └── networking/
│       └── (module files)
└── terraform.tfstate           ← only for "local" backend type
                                   NOT present when using S3/GCS backend
```

---

## State File Versioning — Full Recovery Procedure

### Why Every Apply Creates a New Version

When Terraform writes state to S3, it does:
1. `s3:PutObject` → new version created (S3 versioning saves old one)
2. Old version is retained indefinitely (until lifecycle policy deletes it)
3. Each version has: VersionId, LastModified, ETag

This means you can see the full history of your infrastructure:

```bash
# List all versions of production state
aws s3api list-object-versions \
  --bucket my-terraform-state \
  --prefix production/terraform.tfstate \
  --query 'sort_by(Versions, &LastModified)[*].{
    VersionId: VersionId,
    LastModified: LastModified,
    Size: Size
  }' \
  --output table

# Output:
# --------------------------------------------------------------------------
# |                         ListObjectVersions                             |
# +------------------------------------------------------------------------+
# |  LastModified               |  Size   |  VersionId                    |
# +------------------------------------------------------------------------+
# |  2026-07-20T09:00:00.000Z   |  45231  |  abc111...                    |
# |  2026-07-25T14:30:00.000Z   |  48902  |  def222...                    |
# |  2026-07-31T10:00:00.000Z   |  51203  |  ghi333...  ← current         |
# +------------------------------------------------------------------------+
```

### Roll Back to a Previous State

Scenario: Yesterday's apply caused problems. Roll back to before it:

```bash
# Step 1: Identify which version to restore
aws s3api list-object-versions \
  --bucket my-terraform-state \
  --prefix production/terraform.tfstate \
  --output json | jq '.Versions[] | {VersionId, LastModified}'

# Step 2: Download the version from before the bad apply
aws s3api get-object \
  --bucket my-terraform-state \
  --key production/terraform.tfstate \
  --version-id "def222-the-good-version" \
  /tmp/good-state.json

# Step 3: VERIFY the state looks correct before restoring
cat /tmp/good-state.json | jq '.resources[] | .type + "." + .name'
cat /tmp/good-state.json | jq '.serial'  # should be lower than current

# Step 4: Push the old state back as the new current version
# WARNING: This overwrites the current state. Make a backup first.
cp /tmp/good-state.json /tmp/state-backup-before-rollback-$(date +%Y%m%d%H%M).json
terraform state push /tmp/good-state.json

# Step 5: Verify
terraform plan  # should show the diff between the old state and current reality
```

---

## Partial Backend Configuration — For CI/CD Security

Hardcoding bucket names in `backend.tf` is usually fine. But bucket names can differ between accounts, or you might not want them in source code. Partial config solves this:

```hcl
# backend.tf — only the backend type, no specifics
terraform {
  backend "s3" {}   # empty — all values provided at runtime
}
```

```bash
# Provide backend values at init time (CI/CD pipeline)
terraform init \
  -backend-config="bucket=my-company-terraform-state" \
  -backend-config="key=production/terraform.tfstate" \
  -backend-config="region=ap-northeast-1" \
  -backend-config="encrypt=true" \
  -backend-config="dynamodb_table=terraform-state-lock"
```

Or use a backend config file:

```hcl
# backend-production.hcl — not .tf extension, not parsed as config
bucket         = "my-company-terraform-state"
key            = "production/terraform.tfstate"
region         = "ap-northeast-1"
encrypt        = true
dynamodb_table = "terraform-state-lock"
```

```bash
terraform init -backend-config=backend-production.hcl
```

Benefits: the bucket name can be environment-specific, stored in CI/CD variables, not hardcoded in source.

---

## Workspace-Aware State Paths

When using S3 backend with workspaces, Terraform automatically organizes state:

```
Workspace "default":  s3://bucket/production/terraform.tfstate
Workspace "dev":      s3://bucket/env:/dev/production/terraform.tfstate
Workspace "staging":  s3://bucket/env:/staging/production/terraform.tfstate
```

The `env:/` prefix is added automatically by Terraform for non-default workspaces.

To use workspace-aware keys explicitly:

```hcl
terraform {
  backend "s3" {
    bucket = "my-terraform-state"
    key    = "terraform.tfstate"   # simplified key
    # Terraform prepends env:/<workspace>/ automatically
  }
}
```

---

## State Locking — Deep Dive on DynamoDB

### What the Lock Record Contains

When Terraform acquires a lock, it writes this to DynamoDB:

```json
{
  "LockID": {
    "S": "my-terraform-state/production/terraform.tfstate"
  },
  "Info": {
    "S": "{\"ID\":\"abc-def-ghi\",\"Operation\":\"OperationTypeApply\",\"Info\":\"\",\"Who\":\"alice@company.com\",\"Version\":\"1.7.5\",\"Created\":\"2026-07-31T10:00:00.000000+00:00\",\"Path\":\"my-terraform-state/production/terraform.tfstate\"}"
  }
}
```

Terraform uses DynamoDB's **conditional writes** to implement locking:
- Write with `ConditionExpression: "attribute_not_exists(LockID)"` 
- If item already exists: write fails → lock already held
- If item doesn't exist: write succeeds → lock acquired

This is an atomic operation — no race condition possible.

### Monitoring Lock Health

```bash
# See current locks (should be empty when no apply running)
aws dynamodb scan \
  --table-name terraform-state-lock \
  --query 'Items[*]' \
  --output json

# See lock for a specific state path
aws dynamodb get-item \
  --table-name terraform-state-lock \
  --key '{"LockID": {"S": "my-terraform-state/production/terraform.tfstate"}}' \
  --output json

# Delete a stale lock manually (when force-unlock fails or isn't available)
aws dynamodb delete-item \
  --table-name terraform-state-lock \
  --key '{"LockID": {"S": "my-terraform-state/production/terraform.tfstate"}}'
# ONLY DO THIS if you are 100% certain no apply is running
```

---

## Multiple State Files — The Cross-Reference Pattern

In a real organization you have many Terraform projects, each with its own state:

```
Project 1: networking (VPC, subnets)
  State: s3://bucket/networking/terraform.tfstate
  Outputs: vpc_id, private_subnet_ids, public_subnet_ids

Project 2: database (RDS)
  State: s3://bucket/database/terraform.tfstate
  Inputs: vpc_id (from networking), subnet_ids (from networking)
  Outputs: db_endpoint, db_port

Project 3: application (EC2/EKS)
  State: s3://bucket/application/terraform.tfstate
  Inputs: vpc_id, subnet_ids, db_endpoint
```

The application project reads from both other projects' states:

```hcl
# In application project
data "terraform_remote_state" "networking" {
  backend = "s3"
  config = {
    bucket = "my-terraform-state"
    key    = "networking/terraform.tfstate"
    region = "ap-northeast-1"
  }
}

data "terraform_remote_state" "database" {
  backend = "s3"
  config = {
    bucket = "my-terraform-state"
    key    = "database/terraform.tfstate"
    region = "ap-northeast-1"
  }
}

# Use values from other projects
module "app" {
  source     = "../../modules/app-server"
  vpc_id     = data.terraform_remote_state.networking.outputs.vpc_id
  subnet_ids = data.terraform_remote_state.networking.outputs.private_subnet_ids
}

resource "aws_db_proxy_endpoint" "app" {
  target_db_endpoint = data.terraform_remote_state.database.outputs.db_endpoint
}
```

**Drawback of `terraform_remote_state`**: creates hard coupling. The database project's output names become an API contract. If the database team renames `db_endpoint` to `database_endpoint`, the application project breaks.

**Alternative**: Use SSM Parameter Store or Secrets Manager as a looser coupling:

```hcl
# database project stores its output in SSM
resource "aws_ssm_parameter" "db_endpoint" {
  name  = "/production/database/endpoint"
  type  = "String"
  value = aws_db_instance.main.endpoint
}

# application project reads from SSM (no direct state dependency)
data "aws_ssm_parameter" "db_endpoint" {
  name = "/production/database/endpoint"
}
```

---

## State Access Control — IAM Policies

The state bucket contains sensitive data. Control access carefully:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "DenyPublicAccess",
      "Effect": "Deny",
      "Principal": "*",
      "Action": "s3:*",
      "Resource": ["arn:aws:s3:::my-terraform-state", "arn:aws:s3:::my-terraform-state/*"],
      "Condition": {
        "Bool": { "aws:SecureTransport": "false" }
      }
    },
    {
      "Sid": "AllowTerraformRole",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::123456789:role/TerraformDeploy"
      },
      "Action": [
        "s3:GetObject",
        "s3:PutObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::my-terraform-state",
        "arn:aws:s3:::my-terraform-state/production/*"
      ]
    },
    {
      "Sid": "AllowReadOnlyForPlan",
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::123456789:role/TerraformPlan"
      },
      "Action": ["s3:GetObject", "s3:ListBucket"],
      "Resource": [
        "arn:aws:s3:::my-terraform-state",
        "arn:aws:s3:::my-terraform-state/production/*"
      ]
    }
  ]
}
```
