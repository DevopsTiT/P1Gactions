# Terraform Parts Expanded — Glossary

All new terms introduced across the 8 expanded parts, for SRE beginners.

---

**Reconciliation**
The process of comparing a desired state against actual state and automatically taking actions to make them match. Terraform reconciles on-demand (when you run apply). Kubernetes reconciles continuously. Like a thermostat — detects gap, acts to close it, stops when matched.

**Declarative**
A style of configuration where you describe WHAT you want to exist, not HOW to create it. "I want 3 EC2 instances" (declarative) vs "call CreateInstance API three times" (procedural/imperative). Terraform is declarative.

**Abstract Syntax Tree (AST)**
The internal tree structure Terraform builds by parsing your `.tf` files. Each block becomes a node in the tree. Terraform uses it to understand dependencies and validate syntax before making any API calls.

**Directed Acyclic Graph (DAG)**
The dependency map Terraform builds from your resource references. "Directed" = edges have direction (A must happen before B). "Acyclic" = no circular dependencies (A depends on B which depends on A would break everything). Terraform uses this to determine execution order and what can run in parallel.

**ForceNew**
A flag in a provider's resource schema marking that changing this attribute requires destroying and recreating the resource (not updating it in place). Defined in provider code, not your config. Example: changing an EC2 instance's AMI has `ForceNew = true`.

**Provider Schema**
The blueprint a provider uses to describe every resource type it supports — what attributes exist, their types, which are required, which have `ForceNew`. Terraform reads this schema to understand how to plan changes.

**Provider Plugin**
The compiled binary Terraform downloads from the registry and runs locally to make API calls to a cloud platform. The `hashicorp/aws` provider is a Go binary that wraps the AWS SDK.

**Partial Backend Configuration**
A Terraform backend block with only the backend type specified (`backend "s3" {}`), with all connection details provided at `terraform init` time via `-backend-config` flags or a separate `.hcl` file. Used when bucket names differ between accounts or should not be hardcoded in source.

**Conditional Write (DynamoDB)**
An atomic database write operation that only succeeds if a specific condition is true (e.g. "only write if this key does NOT already exist"). Terraform uses this to implement state locking — the lock acquisition either succeeds atomically or fails, preventing race conditions.

**Serial (state file field)**
A counter in `.tfstate` that increments by 1 with every successful `terraform apply`. Used to detect state conflicts — if two processes try to write state and one has an outdated serial, the write is rejected.

**Lineage (state file field)**
A UUID generated when a state file is first created and never changed. If you accidentally push state from a different project or workspace, Terraform detects the lineage mismatch and refuses to proceed.

**State Orphan**
A resource that exists in `.tfstate` but has already been manually deleted from the cloud. `terraform plan` will want to destroy it (it's in state but doesn't exist in cloud). Fix with `terraform state rm` to remove the stale record.

**Brownfield**
Infrastructure that already exists before you start using Terraform. Opposite of "greenfield" (starting fresh). Brownfield adoption requires importing existing resources into Terraform management.

**Greenfield**
A fresh infrastructure deployment with no existing resources to account for. Easiest way to adopt Terraform — you start from scratch and Terraform creates everything.

**Write-Only Attribute**
A resource attribute that can be set on creation but is never returned by the cloud API. Database passwords are the classic example — you set it once, AWS never returns it in describe calls. After importing a database, the `password` attribute will be null in state even though the database has a real password.

**`moved` Block**
A Terraform 1.1+ configuration block that records a resource address rename directly in code (rather than running `terraform state mv` as a CLI command). Lets you document refactors in version-controlled `.tf` files that are reviewable in PRs.

**`terraform test` Command**
A Terraform 1.6+ feature for running automated tests against modules. Tests create real cloud resources, assert conditions about them, then destroy them. Like unit tests but for infrastructure.

**`.tftest.hcl` File**
A file containing Terraform test cases. Defines `run` blocks with input `variables` and `assert` blocks that verify conditions. Evaluated by `terraform test`.

**`terraform validate`**
A command that checks `.tf` syntax and internal references without making any cloud API calls. Runs in milliseconds. Catches typos, missing required arguments, and references to undefined resources.

**`terraform fmt`**
A command that rewrites `.tf` files to Terraform's canonical format — consistent indentation (2 spaces), aligned `=` signs within blocks, standardized whitespace. Run with `-check` in CI to enforce formatting.

**`tfsec`**
An open-source static analysis tool for Terraform files. Scans for security misconfigurations before they reach the cloud — unencrypted S3 buckets, security groups open to the internet, RDS without deletion protection, etc.

**`checkov`**
A policy-as-code tool that scans Terraform (and other IaC) files for security and compliance issues. Has hundreds of built-in checks for AWS, GCP, Azure. Can be configured with custom policies.

**`infracost`**
An open-source tool that estimates the monthly cost of a Terraform plan before you apply it. Integrates with GitHub/GitLab to post cost changes as PR comments: "This PR adds $45.20/month."

**OIDC Token**
A short-lived JSON Web Token (JWT) issued by GitHub (or another identity provider) to prove a pipeline run's identity. AWS verifies this token against the registered OIDC provider and issues temporary credentials. Eliminates the need to store static AWS access keys.

**`role-session-name`**
An identifier attached to the temporary AWS credentials assumed via OIDC or `AssumeRole`. Appears in CloudTrail logs, making it possible to identify which specific pipeline run made which API calls. Best practice: include the git SHA or run ID.

**GitHub Environment (Actions)**
A named deployment target in GitHub Actions settings (e.g. "production") that can require manual approval from designated reviewers before a job runs. Provides a human approval gate for production Terraform applies.

**`concurrency` (GitHub Actions)**
A setting that controls how concurrent workflow runs are handled. For Terraform, `cancel-in-progress: false` ensures a running apply is never interrupted by a new push — it must complete first.

**`-detailed-exitcode`**
A `terraform plan` flag that changes the process exit code to convey more information: 0 = no changes, 1 = error, 2 = changes detected. Used in scripts and CI pipelines to programmatically detect whether drift was found.

**`-refresh=false`**
A flag for `terraform plan` that skips calling cloud APIs to refresh current state. Makes plan much faster but won't detect drift. Safe to use when you know no external changes have occurred.

**`-refresh-only`**
A plan/apply mode that ONLY updates the state file to reflect current cloud reality, without proposing any infrastructure changes. Used for drift detection and to accept manual changes into state without reverting them.

**`infracost.json`**
The output file produced by `infracost breakdown`. Contains a structured breakdown of resource costs. Used by the `infracost/actions/comment` action to post a formatted cost summary to PRs.

**SCP (Service Control Policy)**
An AWS Organizations feature that places guardrails on what IAM policies can do within an account. Used in production accounts to prevent even admins from disabling CloudTrail, creating public S3 buckets, or removing billing alarms. Provides compliance enforcement that IAM policies alone cannot.

**CloudTrail**
AWS's audit logging service — records every API call made in your account (who called what, when, from where). Critical for security investigations. Terraform operations appear in CloudTrail with the role session name as the actor.

**`coalesce()` function**
A Terraform function that returns the first non-null, non-empty string from its arguments. `coalesce(var.provided_ami, data.aws_ami.latest.id)` returns the provided AMI if set, otherwise the latest AMI. Similar to the `||` operator for null-checking.

**`templatefile()` function**
A Terraform function that reads a file as a template and renders it by substituting variable references. Used for user-data scripts, config files, policy JSON — anything too long to write inline in HCL.

**Tag Enforcement**
Using AWS Config rules or SCPs to require that all resources have specific tags (Environment, Team, CostCenter). Without enforcement, developers skip tags; with enforcement, untagged resources are auto-deleted or trigger alerts.
