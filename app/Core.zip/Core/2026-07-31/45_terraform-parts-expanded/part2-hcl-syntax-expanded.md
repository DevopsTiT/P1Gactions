# Part 2 Expanded — HCL Syntax: Every Detail With Real Scenarios

---

## Why HCL Exists (Not JSON, Not YAML)

HashiCorp designed HCL specifically for infrastructure config. Compared to alternatives:

| Format | Problem for IaC |
|---|---|
| JSON | No comments. No multi-line strings. Verbose. `"key": "value"` is noisy. |
| YAML | Indentation-sensitive (one wrong space = broken config). Type inference is surprising (`yes` becomes `true`). |
| Python/Ruby DSL | Too powerful — easy to write code that's hard to understand or predict. |
| HCL | Human-readable. Comments supported. Expressions but not arbitrary code. Predictable evaluation. |

HCL's design philosophy: **declarative, not procedural**. You describe *what*, not *how*.

---

## Block Types — The Complete Reference

### The `terraform` Block — Project Configuration

This block configures Terraform itself, not any cloud resource. It must be consistent across your team (Terraform validates it on `init`).

```hcl
terraform {
  # Minimum version of Terraform this config requires.
  # If someone runs terraform 1.4.0 with this constraint, they get:
  # "Error: Unsupported Terraform Core version"
  required_version = ">= 1.5.0, < 2.0.0"

  # Declare every provider you use + their source + version constraints.
  # Without this block, Terraform tries to guess provider names (unreliable).
  required_providers {
    aws = {
      source  = "hashicorp/aws"   # registry.terraform.io/hashicorp/aws
      version = "~> 5.0"          # 5.0, 5.1, 5.31 — yes. 6.0 — no.
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = ">= 2.20.0"
    }
    dynatrace = {
      source  = "dynatrace-oss/dynatrace"
      version = ">= 1.0.0"
    }
    random = {
      source  = "hashicorp/random"  # for generating passwords, IDs
      version = "~> 3.5"
    }
  }

  # Backend: where state is stored. Covered in depth in Part 4.
  backend "s3" {
    bucket         = "my-terraform-state"
    key            = "production/terraform.tfstate"
    region         = "ap-northeast-1"
    encrypt        = true
    dynamodb_table = "terraform-state-lock"
  }
}
```

---

### The `provider` Block — Authentication and Defaults

```hcl
# AWS provider — full detail
provider "aws" {
  region = var.aws_region    # required — no default region in provider

  # Optional: explicitly set credentials (prefer env vars or IAM roles instead)
  access_key = var.aws_access_key    # prefer: AWS_ACCESS_KEY_ID env var
  secret_key = var.aws_secret_key    # prefer: AWS_SECRET_ACCESS_KEY env var

  # Cross-account deployment: assume a role in another AWS account
  assume_role {
    role_arn     = "arn:aws:iam::999999999:role/TerraformDeploy"
    session_name = "terraform-production"
    external_id  = "unique-secret-id"  # extra security for cross-account
  }

  # Apply these tags to EVERY resource created by this provider.
  # Resources can override specific keys with their own tags block.
  default_tags {
    tags = {
      ManagedBy   = "terraform"
      Environment = var.environment
      Team        = var.team
      Repository  = "github.com/my-org/infra"
    }
  }

  # Ignore specific tag keys that external systems manage
  ignore_tags {
    key_prefixes = ["kubernetes.io/", "k8s.io/"]  # K8s adds these — don't fight it
    keys         = ["LastApplied", "AutoScalingGroupName"]
  }
}

# Multiple AWS providers for multi-region setup
provider "aws" {
  alias  = "tokyo"
  region = "ap-northeast-1"
}

provider "aws" {
  alias  = "singapore"
  region = "ap-southeast-1"
}

# Resources that need a specific region use the aliased provider
resource "aws_s3_bucket" "tokyo_backup" {
  provider = aws.tokyo
  bucket   = "my-app-backup-tokyo"
}

resource "aws_s3_bucket" "singapore_backup" {
  provider = aws.singapore
  bucket   = "my-app-backup-singapore"
}
```

---

### The `variable` Block — Complete Type System

#### Every Primitive Type

```hcl
variable "app_name" {
  type        = string
  description = "Name of the application"
  default     = "my-app"
}

variable "replica_count" {
  type        = number
  description = "Number of replicas (can be integer or decimal)"
  default     = 3
  validation {
    condition     = var.replica_count >= 1 && var.replica_count <= 20
    error_message = "Replica count must be between 1 and 20."
  }
}

variable "enable_https" {
  type        = bool
  description = "Whether to enable HTTPS on the load balancer"
  default     = true
}
```

#### Collection Types in Detail

```hcl
# list(type) — ordered, allows duplicates, accessed by index
variable "availability_zones" {
  type    = list(string)
  default = ["ap-northeast-1a", "ap-northeast-1c", "ap-northeast-1d"]
}
# Access: var.availability_zones[0] = "ap-northeast-1a"
# Length: length(var.availability_zones) = 3

# set(type) — unordered, no duplicates, cannot access by index
# Use when order doesn't matter and uniqueness is required
variable "allowed_instance_types" {
  type    = set(string)
  default = ["t3.micro", "t3.small", "t3.medium"]
}
# Use for_each (not count) with sets

# map(type) — key-value pairs, all values same type
variable "environment_configs" {
  type = map(string)
  default = {
    dev        = "t3.micro"
    staging    = "t3.small"
    production = "t3.large"
  }
}
# Access: var.environment_configs["production"] = "t3.large"
# Access: lookup(var.environment_configs, "production", "t3.micro")
#         (lookup with fallback default if key missing)

# object — structured shape, each key has its own type
variable "database_config" {
  type = object({
    engine            = string
    instance_class    = string
    allocated_storage = number
    multi_az          = bool
    backup_days       = number
    tags              = map(string)    # nested map inside object
  })
  default = {
    engine            = "postgres"
    instance_class    = "db.t3.medium"
    allocated_storage = 20
    multi_az          = false
    backup_days       = 7
    tags              = { "Tier" = "database" }
  }
}
# Access: var.database_config.instance_class
#         var.database_config.tags["Tier"]

# list(object) — list of structured objects
variable "ingress_rules" {
  type = list(object({
    port        = number
    protocol    = string
    cidr_blocks = list(string)
    description = string
  }))
  default = [
    {
      port        = 80
      protocol    = "tcp"
      cidr_blocks = ["0.0.0.0/0"]
      description = "HTTP from internet"
    },
    {
      port        = 443
      protocol    = "tcp"
      cidr_blocks = ["0.0.0.0/0"]
      description = "HTTPS from internet"
    }
  ]
}

# Optional attributes in objects (Terraform 1.3+)
variable "optional_config" {
  type = object({
    required_field = string
    optional_field = optional(string, "default-value")  # has a default
    nullable_field = optional(string)                    # defaults to null
  })
}
```

#### Validation Block — Full Reference

```hcl
variable "environment" {
  type = string

  # Multiple validations are AND-ed together — all must pass
  validation {
    condition     = contains(["dev", "staging", "production"], var.environment)
    error_message = "Environment must be one of: dev, staging, production."
  }
}

variable "vpc_cidr" {
  type = string
  validation {
    # can() returns true if the expression evaluates without error
    # cidrhost() errors on invalid CIDRs — so can(cidrhost(...)) = true only for valid CIDRs
    condition     = can(cidrhost(var.vpc_cidr, 0))
    error_message = "VPC CIDR must be a valid IPv4 CIDR block (e.g. 10.0.0.0/16)."
  }
}

variable "instance_type" {
  type = string
  validation {
    # regex() throws if pattern doesn't match — so can(regex()) checks match
    condition     = can(regex("^(t3|t3a|m5|c5)\\.", var.instance_type))
    error_message = "Only t3, t3a, m5, c5 family instances allowed."
  }
}

variable "replica_count" {
  type = number
  validation {
    # Use floor() to check it's an integer
    condition     = var.replica_count == floor(var.replica_count) && var.replica_count > 0
    error_message = "Replica count must be a positive integer."
  }
}
```

---

### The `output` Block — Complete Reference

```hcl
# Simple string output
output "vpc_id" {
  description = "ID of the VPC"
  value       = aws_vpc.main.id
}

# Sensitive output — hidden in terminal, still accessible via 'terraform output'
output "db_password" {
  description = "Database master password"
  value       = random_password.db.result
  sensitive   = true
  # terraform output db_password → prints warning
  # terraform output -raw db_password → prints value (for scripting)
}

# Computed output — expression result
output "all_instance_ips" {
  description = "Map of instance name to private IP"
  value = {
    for name, instance in aws_instance.services :
    name => instance.private_ip
  }
  # Result: { "payments" = "10.0.1.5", "checkout" = "10.0.1.6" }
}

# Conditional output
output "nat_gateway_ip" {
  description = "NAT Gateway Elastic IP (empty string if not created)"
  value       = length(aws_eip.nat) > 0 ? aws_eip.nat[0].public_ip : ""
}

# Output from a module
output "load_balancer_dns" {
  description = "DNS name of the application load balancer"
  value       = module.compute.alb_dns_name   # accessing module output
}

# Reading outputs from CLI
# terraform output                         → all outputs (formatted)
# terraform output vpc_id                  → specific value
# terraform output -json                   → all outputs as JSON
# terraform output -raw vpc_id             → raw string (no quotes, for scripts)
# terraform output -json | jq '.vpc_id.value'  → parse from JSON
```

---

### The `locals` Block — When and Why to Use It

Locals solve three problems:
1. **Avoid repeating the same expression** — compute it once, reference many times
2. **Make complex expressions readable** — name the intermediate steps
3. **Centralize configuration** — one place to change a value that affects many resources

```hcl
locals {
  # ── Simple naming ────────────────────────────────────────────────────
  name_prefix = "${var.project}-${var.environment}"
  # Use: "${local.name_prefix}-web-server" → "myapp-production-web-server"

  # ── Conditional logic ─────────────────────────────────────────────────
  is_production    = var.environment == "production"
  is_high_env      = contains(["staging", "production"], var.environment)

  # ── Derived config values ─────────────────────────────────────────────
  instance_type  = local.is_production ? "t3.large" : "t3.micro"
  replica_count  = local.is_production ? 5 : 1
  backup_enabled = local.is_high_env

  # ── Central tag map — merge this into every resource ──────────────────
  common_tags = {
    Project     = var.project
    Environment = var.environment
    ManagedBy   = "terraform"
    CostCenter  = var.cost_center
    Repository  = "github.com/my-org/infra"
  }

  # ── List and map transformations ──────────────────────────────────────
  # Take first 3 AZs from the region (regardless of how many exist)
  azs = slice(data.aws_availability_zones.available.names, 0, 3)

  # Build subnet CIDR for each AZ
  subnet_cidrs = {
    for i, az in local.azs :
    az => cidrsubnet(var.vpc_cidr, 4, i)
  }
  # → { "ap-northeast-1a" = "10.0.0.0/20", "ap-northeast-1c" = "10.0.1.0/20", ... }

  # ── Account/region computed values ────────────────────────────────────
  account_id = data.aws_caller_identity.current.account_id
  region     = data.aws_region.current.name
  s3_prefix  = "arn:aws:s3:::${local.name_prefix}"
}

# Usage in resources
resource "aws_instance" "app" {
  instance_type = local.instance_type
  tags          = merge(local.common_tags, { Name = "${local.name_prefix}-app" })
}

resource "aws_subnet" "public" {
  for_each          = local.subnet_cidrs
  availability_zone = each.key
  cidr_block        = each.value
  tags              = merge(local.common_tags, { Name = "${local.name_prefix}-public-${each.key}" })
}
```

---

### The `data` Block — Reading Without Managing

Data sources are queries. They run during `terraform plan` and cache results in state.

```hcl
# ── Most common data sources ──────────────────────────────────────────────

# Current AWS account ID and region (no arguments needed)
data "aws_caller_identity" "current" {}
data "aws_region" "current" {}
# Usage: data.aws_caller_identity.current.account_id
#        data.aws_region.current.name

# Latest Amazon Linux 2 AMI (always up-to-date)
data "aws_ami" "amazon_linux_2" {
  most_recent = true
  owners      = ["amazon"]
  filter {
    name   = "name"
    values = ["amzn2-ami-hvm-*-x86_64-gp2"]
  }
  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}
# Usage: data.aws_ami.amazon_linux_2.id

# Existing VPC (managed by another team/Terraform project)
data "aws_vpc" "platform" {
  # Look up by tag — fails if 0 or >1 match
  tags = { Name = "platform-production-vpc" }
}

# All available AZs in the current region
data "aws_availability_zones" "available" {
  state = "available"
  # Exclude wavelength and local zones
  filter {
    name   = "opt-in-status"
    values = ["opt-in-not-required"]
  }
}

# IAM policy document (generates JSON policy from HCL)
data "aws_iam_policy_document" "app_s3" {
  statement {
    effect  = "Allow"
    actions = ["s3:GetObject", "s3:PutObject"]
    resources = ["arn:aws:s3:::${local.name_prefix}-data/*"]
  }
  statement {
    effect    = "Deny"
    actions   = ["s3:DeleteObject"]
    resources = ["*"]
  }
}
# Usage: data.aws_iam_policy_document.app_s3.json
# → generates the JSON policy string, cleaner than jsonencode()

# Secret from AWS Secrets Manager
data "aws_secretsmanager_secret_version" "api_key" {
  secret_id = "production/external-api-key"
}
# Usage: data.aws_secretsmanager_secret_version.api_key.secret_string
#        jsondecode(data.aws_secretsmanager_secret_version.api_key.secret_string)["api_key"]
```

---

## Expression Deep Dive

### String Templates — Multi-line and Heredoc

```hcl
# Simple interpolation
name = "server-${var.environment}-${count.index}"

# Multi-line string (heredoc) — preserves newlines
user_data = <<-EOT
  #!/bin/bash
  echo "Configuring ${var.environment} server"
  yum install -y amazon-cloudwatch-agent
  systemctl start amazon-cloudwatch-agent
EOT
# <<-EOT strips leading whitespace to the indentation level of EOT

# Template file — read from external file
user_data = templatefile("${path.module}/scripts/init.sh.tpl", {
  environment = var.environment
  app_name    = var.app_name
  db_endpoint = aws_db_instance.main.endpoint
})
```

### Conditional Expressions — Complex Cases

```hcl
# Simple conditional
instance_type = var.environment == "production" ? "t3.large" : "t3.micro"

# Nested conditional (use locals for readability)
locals {
  instance_type = (
    var.environment == "production" ? "t3.large" :
    var.environment == "staging"    ? "t3.small" :
    "t3.micro"  # default for dev and anything else
  )
}

# Conditional resource creation (count = 0 or 1)
resource "aws_eip" "nat" {
  count  = var.enable_nat_gateway ? 1 : 0
  domain = "vpc"
}
# If false: resource not created, eip list is empty
# Access safely: length(aws_eip.nat) > 0 ? aws_eip.nat[0].id : null

# Conditional with for_each (empty map = no resources)
resource "aws_route53_record" "app" {
  for_each = var.enable_dns ? { (var.app_hostname) = var.lb_dns } : {}
  # If enable_dns = false: for_each = {} → nothing created
  zone_id = var.zone_id
  name    = each.key
  type    = "CNAME"
  records = [each.value]
  ttl     = 300
}
```

### `for` Expressions — Every Form

```hcl
# LIST from LIST — transform each element
locals {
  upper_envs = [for e in var.environments : upper(e)]
  # ["dev", "prod"] → ["DEV", "PROD"]

  # With filter — only include elements matching condition
  prod_subnets = [for s in var.subnets : s.id if s.tier == "private"]

  # Compute new value from element
  subnet_cidrs = [for i in range(3) : cidrsubnet(var.vpc_cidr, 4, i)]
  # range(3) = [0, 1, 2] → three CIDRs
}

# MAP from LIST — build key-value pairs
locals {
  az_to_cidr = {
    for i, az in var.availability_zones :
    az => cidrsubnet(var.vpc_cidr, 4, i)
  }
  # → { "ap-northeast-1a" = "10.0.0.0/20", "ap-northeast-1c" = "10.0.1.0/20" }

  # From resource for_each — get attribute of each created resource
  service_ips = {
    for name, instance in aws_instance.services :
    name => instance.private_ip
  }
}

# MAP from MAP — transform values
locals {
  lowercased_tags = {
    for key, value in var.tags :
    lower(key) => lower(value)
  }
}

# Grouping — build map of lists (group items by a key)
locals {
  # Group subnets by tier
  subnets_by_tier = {
    for subnet in var.subnets :
    subnet.tier => subnet.id...  # "..." means collect into a list
  }
  # → { "public" = ["subnet-1", "subnet-3"], "private" = ["subnet-2"] }
}
```

### Functions — The 20 You'll Use Most

```hcl
# ── String ──────────────────────────────────────────────────────────────
format("%-20s: %d", "replica_count", 3)  # "replica_count      : 3"
trimprefix("dev-server", "dev-")          # "server"
trimsuffix("server.log", ".log")          # "server"
split(",", "a,b,c")                       # ["a", "b", "c"]
join("-", ["my", "app", "prod"])          # "my-app-prod"
startswith("production", "prod")          # true
endswith("app.log", ".log")               # true
replace("hello-world", "-", "_")          # "hello_world"
substr("hello-world", 0, 5)               # "hello"

# ── Collection ──────────────────────────────────────────────────────────
length(["a", "b", "c"])                   # 3
length({a=1, b=2})                        # 2 (number of keys)
concat(["a"], ["b", "c"])                 # ["a", "b", "c"]
flatten([["a", "b"], ["c"]])              # ["a", "b", "c"]
distinct(["a", "b", "a", "c"])            # ["a", "b", "c"]
compact(["a", "", "b", null, "c"])        # ["a", "b", "c"] — removes empty/null
slice(["a","b","c","d"], 1, 3)            # ["b", "c"] — index 1 to 2
reverse(["a","b","c"])                    # ["c","b","a"]
sort(["banana","apple","cherry"])         # ["apple","banana","cherry"]
keys({b=2, a=1})                          # ["a", "b"] — sorted alphabetically
values({b=2, a=1})                        # [1, 2] — sorted by key
lookup({a="x", b="y"}, "c", "default")   # "default" — safe map access
contains(["a","b","c"], "b")              # true
index(["a","b","c"], "b")                 # 1 — position of element

# ── Encoding ────────────────────────────────────────────────────────────
jsonencode({key = "value", count = 3})    # "{\"count\":3,\"key\":\"value\"}"
jsondecode("{\"key\":\"value\"}")          # {key = "value"}
base64encode("hello world")               # "aGVsbG8gd29ybGQ="
base64decode("aGVsbG8gd29ybGQ=")         # "hello world"
yamlencode({a = 1, b = [1,2,3]})         # "a: 1\nb:\n- 1\n- 2\n- 3\n"

# ── IP/CIDR ─────────────────────────────────────────────────────────────
cidrsubnet("10.0.0.0/16", 8, 1)          # "10.0.1.0/24"
cidrsubnet("10.0.0.0/16", 8, 255)        # "10.0.255.0/24"
cidrhost("10.0.1.0/24", 10)              # "10.0.1.10"
cidrnetmask("10.0.0.0/16")              # "255.255.0.0"

# ── Type conversion ─────────────────────────────────────────────────────
tostring(42)                              # "42"
tonumber("42")                            # 42
tobool("true")                            # true
tolist(toset(["b","a","b"]))             # ["a","b"] — deduplicated, sorted
tomap([{key="a",value=1},{key="b",value=2}]) # {a=1, b=2} — convert list to map

# ── Filesystem (only usable in root module, not called modules) ──────────
file("${path.module}/scripts/init.sh")    # read file contents as string
filebase64("${path.module}/cert.pem")     # file contents as base64
templatefile("${path.module}/tmpl.tpl", { var1 = "value" })  # render template
```
