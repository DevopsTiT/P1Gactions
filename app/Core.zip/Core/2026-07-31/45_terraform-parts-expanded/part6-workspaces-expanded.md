# Part 6 Expanded — Workspaces & Environments: Real-World Patterns

---

## The Core Question: Workspaces or Directories?

This is one of the most debated Terraform architecture questions. The answer depends on your team size, risk tolerance, and environment differences.

### Decision Framework

```
Are your environments truly identical in structure?
  (same resources, just different sizes/counts)
        │
        YES ──────────────────────────────────────────► Workspaces MAY work
        │                                               But read the risks below
        NO
        │
        ▼
Do your environments use different:
  - AWS accounts?
  - Regions?
  - Resource types (prod has WAF, dev doesn't)?
  - Module versions?
        │
        YES (any of these) ──────────────────────────► Separate directories
        │                                               REQUIRED
        NO
        │
        ▼
Is this a production-grade system with
multiple engineers and a change review process?
        │
        YES ──────────────────────────────────────────► Separate directories
        │                                               Strongly recommended
        NO (personal project / small team)
        │
        ▼
        Workspaces are fine
```

---

## Workspace Internals — How State Isolation Actually Works

### S3 Backend State Paths

```bash
# Default workspace
s3://bucket/path/to/terraform.tfstate

# Named workspaces (prefix "env:/" added automatically)
s3://bucket/env:/dev/path/to/terraform.tfstate
s3://bucket/env:/staging/path/to/terraform.tfstate
s3://bucket/env:/production/path/to/terraform.tfstate
```

Verify by listing the bucket after using workspaces:
```bash
aws s3 ls s3://my-terraform-state/ --recursive | grep terraform.tfstate
# 2026-07-31  my-terraform-state/production/terraform.tfstate
# 2026-07-31  my-terraform-state/env:/dev/production/terraform.tfstate
# 2026-07-31  my-terraform-state/env:/staging/production/terraform.tfstate
```

### Local State and Workspaces

Without a remote backend, workspaces store state locally:
```
.terraform.tfstate.d/
├── dev/
│   └── terraform.tfstate
├── staging/
│   └── terraform.tfstate
└── production/
    └── terraform.tfstate
terraform.tfstate   ← "default" workspace state
```

This is only for local experimentation — never use local state for team workflows.

---

## The `terraform.workspace` Variable — Every Use Case

### Use Case 1: Environment-Specific Resource Sizes

```hcl
locals {
  # Full config map — all environment differences in one place
  env = {
    dev = {
      instance_type          = "t3.micro"
      instance_count         = 1
      db_instance_class      = "db.t3.micro"
      db_multi_az            = false
      db_backup_retention    = 1
      enable_deletion_protect = false
      log_retention_days     = 3
      alarm_threshold_5xx    = 10
      domain_prefix          = "dev"
    }
    staging = {
      instance_type          = "t3.small"
      instance_count         = 2
      db_instance_class      = "db.t3.small"
      db_multi_az            = false
      db_backup_retention    = 3
      enable_deletion_protect = false
      log_retention_days     = 7
      alarm_threshold_5xx    = 5
      domain_prefix          = "staging"
    }
    production = {
      instance_type          = "t3.large"
      instance_count         = 5
      db_instance_class      = "db.r6g.large"
      db_multi_az            = true
      db_backup_retention    = 30
      enable_deletion_protect = true
      log_retention_days     = 90
      alarm_threshold_5xx    = 1
      domain_prefix          = "app"
    }
  }

  # Select config for current workspace
  # Error if workspace name doesn't match any key
  config = local.env[terraform.workspace]
}
```

### Use Case 2: Preventing Accidental Production Changes

```hcl
# Enforce that production can only be applied from CI/CD (not a laptop)
# by checking for a CI environment variable
locals {
  # In CI: CI=true is set by GitHub Actions / GitLab CI
  is_ci = tobool(get_env("CI", "false"))
}

resource "null_resource" "guard_production" {
  count = terraform.workspace == "production" && !local.is_ci ? 1 : 0

  provisioner "local-exec" {
    command = "echo 'ERROR: Production can only be applied from CI/CD' && exit 1"
  }
}
# This is a soft guard — not a security control. Use IAM for hard controls.
```

### Use Case 3: Conditional Resources Per Workspace

```hcl
# Only create expensive resources in production
resource "aws_wafv2_web_acl" "main" {
  count = terraform.workspace == "production" ? 1 : 0
  name  = "production-waf"
  scope = "REGIONAL"
  # WAF costs ~$5/month + per-rule fees — not worth it in dev
}

# Read the WAF ARN safely (might not exist in dev)
locals {
  waf_arn = length(aws_wafv2_web_acl.main) > 0 ? aws_wafv2_web_acl.main[0].arn : null
}

resource "aws_lb" "main" {
  name               = "${terraform.workspace}-alb"

  # Conditionally attach WAF (only if it was created)
  dynamic "access_logs" {
    for_each = local.waf_arn != null ? [1] : []
    content {
      bucket  = aws_s3_bucket.logs.id
      enabled = true
    }
  }
}
```

---

## Separate Directories — Full Implementation Pattern

### Repository Structure for 3 Environments

```
infrastructure/
│
├── modules/                          ← reusable building blocks
│   ├── networking/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   ├── outputs.tf
│   │   └── versions.tf
│   ├── eks/
│   ├── rds/
│   └── monitoring/
│
├── environments/
│   ├── _shared/                      ← values used across all envs
│   │   ├── variables.tf              ← variable type declarations
│   │   └── locals.tf                 ← computed values
│   │
│   ├── dev/
│   │   ├── main.tf
│   │   ├── backend.tf
│   │   ├── providers.tf
│   │   ├── terraform.tfvars          ← committed (no secrets)
│   │   └── secrets.tfvars.example    ← template (not committed)
│   │
│   ├── staging/
│   │   ├── main.tf
│   │   ├── backend.tf
│   │   ├── providers.tf
│   │   └── terraform.tfvars
│   │
│   └── production/
│       ├── main.tf
│       ├── backend.tf
│       ├── providers.tf
│       └── terraform.tfvars
│
├── .github/
│   └── workflows/
│       ├── terraform-dev.yml
│       ├── terraform-staging.yml
│       └── terraform-production.yml
│
└── .gitignore
```

### Environment-Specific `terraform.tfvars`

```hcl
# environments/dev/terraform.tfvars
environment     = "dev"
aws_region      = "ap-northeast-1"
aws_account_id  = "111111111111"   # dev AWS account

vpc_cidr                = "10.0.0.0/16"
enable_nat_gateway      = false
enable_waf              = false
enable_deletion_protect = false

app_instance_type    = "t3.micro"
app_min_size         = 1
app_max_size         = 3
app_desired_capacity = 1

db_instance_class       = "db.t3.micro"
db_multi_az             = false
db_backup_retention     = 1
db_deletion_protection  = false

alert_email = "dev-alerts@company.com"
```

```hcl
# environments/production/terraform.tfvars
environment     = "production"
aws_region      = "ap-northeast-1"
aws_account_id  = "999999999999"   # production AWS account (separate account!)

vpc_cidr                = "10.10.0.0/16"   # non-overlapping with dev/staging
enable_nat_gateway      = true
enable_waf              = true
enable_deletion_protect = true

app_instance_type    = "t3.large"
app_min_size         = 3
app_max_size         = 20
app_desired_capacity = 5

db_instance_class       = "db.r6g.xlarge"
db_multi_az             = true
db_backup_retention     = 30
db_deletion_protection  = true

alert_email = "prod-oncall@company.com"
```

### Why Separate AWS Accounts?

Separate accounts (dev account / staging account / prod account) give you:

1. **Blast radius isolation**: An IAM mistake or `terraform destroy` in dev cannot touch production resources
2. **Cost visibility**: AWS Cost Explorer shows per-account spend without tagging discipline
3. **Compliance**: Production account can have strict SCPs; dev account is permissive for experimentation
4. **Security**: Prod IAM roles are in a separate trust boundary; a compromised dev credential can't access prod

```hcl
# environments/production/providers.tf
provider "aws" {
  region = var.aws_region

  assume_role {
    # CI/CD pipeline assumes this role in the PRODUCTION account
    # The pipeline's base credentials only have permission to assume this one role
    role_arn = "arn:aws:iam::999999999999:role/TerraformDeploy"
  }
}
```

---

## The `tfvars` File Strategy — What to Commit

```
environments/production/
├── terraform.tfvars          ← COMMIT: non-secret values
│                                       environment, region, instance sizes
│
├── terraform.tfvars.json     ← NEVER COMMIT: alternative JSON format
│                                (same as tfvars but JSON)
│
├── secrets.tfvars            ← NEVER COMMIT: actual secret values
│                                (db_password, api_key, etc.)
│                                Add to .gitignore
│
└── secrets.tfvars.example    ← COMMIT: template showing which secrets needed
                                 (values are placeholder text)
```

`.gitignore`:
```
# Terraform state
*.tfstate
*.tfstate.*
.terraform/
.terraform.lock.hcl   # commit this one! Remove this line.

# Secret variable files
secrets.tfvars
*.secrets.tfvars
*-secrets.tfvars

# Terraform plan files (may contain sensitive data)
*.tfplan
tfplan
```

`secrets.tfvars.example`:
```hcl
# Copy this file to secrets.tfvars and fill in real values.
# NEVER commit secrets.tfvars
db_password         = "CHANGE_ME"
dynatrace_api_token = "CHANGE_ME"
slack_webhook_url   = "CHANGE_ME"
```

---

## Practical: Adding a New Environment (Checklist)

When you need to spin up a new environment (e.g. a "canary" environment):

```bash
# Step 1: Create directory
mkdir -p environments/canary

# Step 2: Copy from most similar env
cp environments/staging/backend.tf environments/canary/backend.tf
cp environments/staging/providers.tf environments/canary/providers.tf
cp environments/staging/main.tf environments/canary/main.tf
cp environments/staging/terraform.tfvars environments/canary/terraform.tfvars

# Step 3: Edit backend.tf — new state key
# key = "canary/terraform.tfstate"

# Step 4: Edit terraform.tfvars
# environment = "canary"
# vpc_cidr = "10.20.0.0/16"  ← non-overlapping CIDR

# Step 5: Initialize new environment
cd environments/canary
terraform init

# Step 6: Plan to see what will be created
terraform plan -var-file="terraform.tfvars"

# Step 7: Apply
terraform apply -var-file="terraform.tfvars"

# Step 8: Add CI/CD pipeline file for the new environment
cp .github/workflows/terraform-staging.yml .github/workflows/terraform-canary.yml
# Edit: change paths and environment references
```
