# Part 2 — Terraform: The 4 New Network Metric Events Deep Dive

> These are the Terraform HCL blocks that add 4 explicit alert rules to the existing `terraform/modules/dynatrace/main.tf`. Each one monitors a specific failure mode that the existing 8 application signals miss.

---

## Why Terraform for Dynatrace Config

The existing module already manages 8 metric events per service. Adding network signals using the same pattern means:

```
terraform apply → 4 new signals × 3 services × 3 environments = 36 new DT resources
                  All configured consistently.
                  No manual UI clicking.
                  No risk of forgetting to add signals for a new service.
```

If a 4th service (e.g., `search-service`) is added to the services map, Terraform creates all 4 network signals for it automatically.

---

## Signal A: TCP Retransmission Rate

### Full HCL with every field explained:

```hcl
resource "dynatrace_metric_events" "tcp_retransmission" {
  for_each = var.services
  # Creates one resource per service entry in the services map.
  # Not because the metric is per-service (it's per HOST), but so the
  # alert summary and description include the service name as context.
  # The entity filter uses "environment" to scope across all hosts
  # in that environment — not just hosts running a specific service.

  enabled = true

  event_entity_dimension_key = "dt.entity.host"
  # This alert is ATTACHED to a HOST entity (EC2 node), not a SERVICE.
  # When Davis AI receives this event, it associates it with the node.
  # This lets Davis correlate: "node X has retransmission spikes" with
  # "payment-service on node X has latency spikes" — same physical host.

  event_type = "RESOURCE_CONTENTION_EVENT"
  # The DT problem severity this event creates.
  # RESOURCE_CONTENTION → WARNING tier in alerting profiles
  #   → Slack notification after 5-min delay
  #   → NOT PagerDuty (not an emergency on its own)
  # Because a TCP retransmission spike is a WARNING — it hasn't
  # caused an outage yet, but it will if not addressed.

  summary = "[${upper(var.environment)}] ${each.key}: TCP retransmission spike (>2%)"
  # Shows in PD/Slack: "[PRODUCTION] payment-service: TCP retransmission spike (>2%)"
  # Includes service name so the team knows which service is context,
  # even though the metric is at the host level.

  description = "High TCP retransmission on nodes running ${each.key}. Indicates packet loss or network congestion between pods and their dependencies. Team: ${each.value.team}"

  metadata { configuration_versions = [1] }
  # Versioning for the alert config itself. Increment if you change
  # the definition — helps track which version is active in DT.

  model_properties {
    type = "STATIC_THRESHOLD"
    # We know what "normal" looks like (< 0.5%) and set a hard threshold.
    # Alternative: SEASONAL_BASELINE (dynamic, learns from history).
    # Static threshold is simpler and works well for network metrics
    # which don't have strong time-of-day patterns.

    alert_condition = "ABOVE"
    # Fire when the metric EXCEEDS the threshold.
    # (Contrast with traffic drop alert which uses "BELOW".)

    alert_on_no_data = false
    # Don't fire when Dynatrace receives no data for this metric.
    # WHY: if a node is idle (no traffic), TCP retransmission is 0/0 = undefined.
    # OneAgent reports null, not 0. False-alerting on undefined would page
    # for every node that has no traffic — high-noise, meaningless.

    threshold = 2.0
    # 2% retransmission rate. Unit: percentage (0–100).
    # Normal VPC: < 0.1%
    # 1–2%: congestion avoidance kicks in, TCP slows down
    # > 2%: users start experiencing latency spikes
    # > 5%: throughput can collapse to 10% of nominal

    violating_samples = 3
    # The threshold must be exceeded for 3 CONSECUTIVE evaluation windows
    # before the alert fires. With resolution=1m, this means 3 minutes.
    # Filters out momentary spikes during rolling deploys or HPA scaling.

    dealerting_samples = 3
    # Must be BELOW threshold for 3 consecutive minutes before the
    # Problem is resolved. Prevents rapid open/close alert storms.

    samples = 5
    # Dynatrace evaluates the last 5 data points when checking
    # violating_samples. Out of the last 5 minutes, 3 must be above.
    # This window defines how "recent" the data must be.
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:host.net.retransmission"
    # The specific DT built-in metric. Collected automatically by OneAgent
    # from /proc/net/snmp on each EKS node.

    resolution = "1m"
    # Evaluate every 1 minute. Matches violating_samples cadence.

    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment   # "production", "staging", or "dev"
        key      = "environment"
        # Scopes this alert to only nodes tagged "environment:production".
        # Without this: the production alert would also fire on dev nodes
        # (which have high retransmission from JIT warmup, small instances, etc.)
      }
    }
  }
}
```

### What the alert message looks like in Slack:

```
[PRODUCTION] payment-service: TCP retransmission spike (>2%)
State: OPEN | Severity: RESOURCE_CONTENTION
High TCP retransmission on nodes running payment-service. Indicates packet loss
or network congestion between pods and their dependencies. Team: payments
Link: https://abc.live.dynatrace.com/ui/problems/12345
```

### Investigation checklist when Signal A fires:

```bash
# 1. Which node is affected?
# DT Problem UI → Affected entities → shows hostname

# 2. How many pods on that node?
kubectl get pods -A -o wide | grep <node-name>

# 3. What is the node's current CPU/network?
kubectl describe node <node-name> | grep -A 5 "Capacity\|Allocatable"

# 4. Check network interface stats from inside a pod on that node
kubectl run netdebug --image=nicolaka/netshoot --rm -it --restart=Never \
  --overrides='{"spec":{"nodeName":"<node-name>"}}' -- \
  cat /proc/net/snmp | grep -i "Tcp:"
# Look for: RetransSegs (cumulative retransmits) growing fast

# 5. MTU check — common cause
ip link show eth0          # should show: mtu 9001 (Jumbo Frames in VPC)
# If shows mtu 1500: Jumbo Frames disabled → any packet > 1500B gets fragmented
# Fix: aws ec2 modify-instance-attribute --network-interface-id eni-xxx --source-dest-check
```

---

## Signal B: DNS Resolution Failure Rate

### Full HCL with every field explained:

```hcl
resource "dynatrace_metric_events" "dns_failures" {
  for_each = var.services

  event_entity_dimension_key = "dt.entity.process_group_instance"
  # Attached to a PROCESS INSTANCE entity (specific pod).
  # This means DT shows: "payment-service pod payment-service-abc-xyz
  # has DNS failures." Pinpoints WHICH pod is failing, not just the node.
  # Useful when only some pods have DNS failures (e.g., node-specific DNS issue).

  event_type = "ERROR_EVENT"
  # DNS failure is an ERROR, not just RESOURCE_CONTENTION.
  # ERROR → HIGH tier alerting profile → PagerDuty in staging+production.
  # WHY: DNS failures break ALL service-to-service calls simultaneously.
  # This is not a soft degradation — it's a hard failure for the service.

  summary = "[${upper(var.environment)}] ${each.key}: DNS resolution failures detected"

  model_properties {
    threshold          = 0.5
    # 0.5% of DNS lookups failing.
    # Healthy value is 0.0% — any DNS failure is unusual.
    # 0.5% threshold accounts for:
    #   - ndots:5 generating some NXDOMAIN on external lookups (normal noise)
    #   - Occasional CoreDNS pod restarts (brief gap in service)
    # Above 0.5% = systemic problem, not noise.

    violating_samples  = 2
    # Only 2 minutes required (not 3) because DNS failures cascade fast.
    # A CoreDNS pod crash causes 100% DNS failure within seconds.
    # Waiting 3 minutes means 3 minutes of every service being broken.
    # 2-minute trigger is a balance between false alarms and fast detection.

    dealerting_samples = 3
    samples            = 3
  }

  query_definition {
    metric_key = "builtin:process.network.dnsFailureRate"
    # Source: OneAgent intercepts the JVM's DNS resolution calls
    # (via JVMTI). Every time a Java app calls InetAddress.getByName()
    # or equivalent, OneAgent records success or failure.
    # This is per-process — so you see "payment-service: 3% DNS failures"
    # vs "order-service: 0% DNS failures" → tells you it's a pod-specific issue.

    entity_filter {
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = each.key key = "process.group.name"
        # Filter to THIS specific service's process group.
      }
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = var.environment key = "environment"
      }
    }
  }
}
```

### The ndots:5 problem explained in detail:

```
Every Kubernetes pod has /etc/resolv.conf:
  search payment-ns.svc.cluster.local svc.cluster.local cluster.local
  options ndots:5

When payment-service calls:
  InetAddress.getByName("orders.company.com")

DNS resolution attempts, in order:
  1. orders.company.com.payment-ns.svc.cluster.local → NXDOMAIN
  2. orders.company.com.svc.cluster.local             → NXDOMAIN
  3. orders.company.com.cluster.local                 → NXDOMAIN
  4. orders.company.com.ap-northeast-1.compute.internal → NXDOMAIN
  5. orders.company.com.                              → CNAME → resolves!

5 DNS queries for one external lookup.
Under normal circumstances: each adds ~1ms → 5ms extra latency (acceptable).
Under CoreDNS overload: each takes 500ms → 2.5s extra per request.

Fix: Use fully qualified names (trailing dot) in app config:
  db.host = "payment-db.cluster-abc.ap-northeast-1.rds.amazonaws.com."
  (trailing dot tells DNS: don't append search domains)
```

### Investigation checklist when Signal B fires:

```bash
# 1. CoreDNS pod health
kubectl get pods -n kube-system -l k8s-app=kube-dns
# If any pod is not Running: CoreDNS is down → all DNS fails

# 2. CoreDNS memory usage
kubectl top pod -n kube-system -l k8s-app=kube-dns
# If memory > 80% of limit → CoreDNS is near OOM
# Fix: increase memory limit or add a third CoreDNS replica

# 3. CoreDNS error logs
kubectl logs -n kube-system \
  $(kubectl get pod -n kube-system -l k8s-app=kube-dns \
    -o jsonpath='{.items[0].metadata.name}') \
  --tail=50 | grep -i "error\|SERVFAIL\|refused"

# 4. Test DNS resolution from a pod
kubectl exec -n payment-ns \
  $(kubectl get pod -n payment-ns -l app=payment-service \
    -o jsonpath='{.items[0].metadata.name}') \
  -- nslookup order-service.order-ns.svc.cluster.local
# Should resolve to a ClusterIP immediately (< 5ms)
# If it times out: CoreDNS unreachable from this pod

# 5. DNS query rate (are we overwhelming CoreDNS?)
kubectl exec -n kube-system \
  $(kubectl get pod -n kube-system -l k8s-app=kube-dns \
    -o jsonpath='{.items[0].metadata.name}') \
  -- cat /proc/net/snmp | grep -i "udp"
# High OutDatagrams = high query rate
```

---

## Signal C: Connection Saturation (SNAT Exhaustion)

### Full HCL with every field explained:

```hcl
resource "dynatrace_metric_events" "connection_saturation" {
  for_each = var.services

  event_entity_dimension_key = "dt.entity.process_group_instance"
  # Per-process — so you see which SPECIFIC service has too many connections.
  # payment-service: 200 connections (fine)
  # notification-service: 4,200 connections (problem)
  # → Investigation targets notification-service specifically.

  event_type = "RESOURCE_CONTENTION_EVENT"
  # WARNING level, not ERROR. High connection count is a WARNING:
  # SNAT exhaustion is about to happen but hasn't yet.
  # When it happens, the ERROR signals (error rate, DB failures) will fire.

  model_properties {
    threshold         = 800
    # Per process INSTANCE (one pod).
    # 800 connections for a single Spring Boot service pod is high.
    # Normal breakdown per pod:
    #   DB pool:          10–50
    #   HTTP clients:     20–100
    #   K8s/telemetry:    5–10
    #   Total normal:     ~35–160
    # At 800: either misconfigured pool or connection leak.

    violating_samples  = 5
    # 5-minute persistence required before alerting.
    # WHY: during a traffic spike, connection count naturally rises then
    # falls as pools warm up. 5-minute threshold catches sustained leaks
    # (which only grow, never fall) vs. traffic spikes (which do fall).

    dealerting_samples = 3
    samples            = 5
  }

  query_definition {
    metric_key = "builtin:process.network.connections"
    # OneAgent reads /proc/<jvm-pid>/net/tcp for the JVM process.
    # Counts all TCP connections in any state:
    #   ESTABLISHED, SYN_SENT, SYN_RECV, FIN_WAIT1, FIN_WAIT2,
    #   TIME_WAIT, CLOSE_WAIT, LAST_ACK, LISTEN, CLOSING
    # Note: TIME_WAIT connections stay open for 60s after close.
    # A service that rapidly opens and closes connections accumulates
    # TIME_WAIT entries even if no active work is happening.
  }
}
```

### SNAT port exhaustion — the math that makes 800 dangerous:

```
AWS NAT Gateway SNAT limit per node: 64,512 ports

EKS node (t3.medium) typical pod count: 8–17 pods

Scenario: notification-service pod leaks connections to SQS
  notification-service: 4,200 connections (to SQS, various ports)
  payment-service:         80 connections (normal)
  order-service:           60 connections (normal)
  system pods (kube-dns, etc.): 50 connections
  
  Total on this node: 4,390 connections
  
  NAT Gateway tracks all 4,390 connections
  Remaining SNAT ports: 64,512 - 4,390 = 60,122 (still fine)

But at scale or with multiple leaking pods:
  notification-service × 3 pods on same node: 12,600 connections
  Payment-service × 3 pods:                      240 connections
  System:                                          50 connections
  Total: 12,890 connections
  
  Remaining: 64,512 - 12,890 = 51,622 (still fine)
  
  But if under load ALL nodes have similar counts:
  And burst traffic adds 30,000 MORE connections across the cluster...
  → Some nodes hit 64,512 → New connections fail silently → App sees "Connection refused"
  → On-call gets paged with "payment error rate 5%" with no obvious cause
```

### TCP states to investigate when Signal C fires:

```bash
# From inside the affected pod
kubectl exec -n notification-ns \
  $(kubectl get pod -n notification-ns -l app=notification-service \
    -o jsonpath='{.items[0].metadata.name}') \
  -- ss -tan | awk '{print $1}' | sort | uniq -c | sort -rn

# Expected healthy output:
#   15 ESTAB         ← established connections (small pool)
#    2 TIME-WAIT     ← recently closed, normal 60s wait
#    1 LISTEN        ← service listening on 8080

# Leaking output:
# 4200 ESTAB         ← massive connection count, LEAK
#  850 TIME-WAIT     ← many recently closed (rapid open/close pattern)
# Shows: connections are being created but not going through pool
```

---

## Signal D: Cross-AZ Traffic Spike

### Full HCL with every field explained:

```hcl
resource "dynatrace_metric_events" "cross_az_traffic" {
  for_each = var.services

  event_entity_dimension_key = "dt.entity.host"
  # Host entity — because throughput is per-node, not per-service.
  # One node might host all three services simultaneously.
  # The alert says "this node has high outbound throughput" and
  # lists the service as context (from each.key in the summary).

  event_type = "RESOURCE_CONTENTION_EVENT"
  # WARNING severity. High throughput is not an emergency unless it's
  # causing NIC saturation. Primary use case: cost alerting.

  model_properties {
    threshold         = 104857600
    # 104,857,600 bytes/sec = 100 MB/s = 800 Mbit/s.
    #
    # WHY bytes not MB: Dynatrace stores throughput in bytes/sec.
    # 100MB/s = 100 × 1024 × 1024 = 104,857,600.
    # (Not 100 × 1000 × 1000 = 100,000,000 — DT uses binary MB)
    #
    # t3.medium NIC limit: 5Gbps = 625MB/s.
    # 100MB/s is 16% of capacity — still has headroom, but:
    #   - This is 360GB/hour × $0.01/GB = $3.60/hour if cross-AZ
    #   - At 100MB/s for 30 days = $2,592/month from this one signal
    # Alert early to investigate root cause (misconfigured service, batch job).

    violating_samples  = 10
    # 10-minute persistence. Why so long?
    # Normal batch operations (log shipping, backup) can produce spikes.
    # We only care about SUSTAINED high traffic, not short-lived bursts.
    # 10 minutes of >100MB/s = real pattern, not transient job.

    dealerting_samples = 5
    samples            = 10
  }

  query_definition {
    metric_key = "builtin:host.net.throughput.tx"
    # TX (transmit/send) — the billing signal.
    # AWS charges for DATA LEAVING each AZ.
    # Inbound is free; outbound cross-AZ costs $0.01/GB.
    # RX (receive) would show the same volume on the destination node —
    # alerting on TX at the source is more actionable.

    entity_filter {
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = var.environment key = "environment"
        # All hosts in this environment.
        # Not filtered by service because high throughput on ANY node
        # in the environment is worth investigating.
      }
    }
  }
}
```

### How to identify if throughput is cross-AZ:

```bash
# 1. Identify which node is sending high traffic (from DT alert)
#    Note the node's AZ from EC2 console or:
kubectl get node <node-name> -o jsonpath='{.metadata.labels.topology\.kubernetes\.io/zone}'

# 2. Identify what's talking to what from that node
kubectl run netdebug --image=nicolaka/netshoot --rm -it \
  --overrides='{"spec":{"nodeName":"<node-name>"}}' --restart=Never -- \
  ss -tn | awk '{print $5}' | cut -d: -f1 | sort | uniq -c | sort -rn | head -20
# Shows: top destination IPs from this node
# Cross-reference IPs with RDS, SQS, other pods to find the talker

# 3. Confirm AZ of destination
# RDS instances: AWS console → RDS → check AZ
# Other EKS nodes: kubectl get node <other-node> -o jsonpath='{...topology.../zone}'

# 4. Check which pods are on the high-traffic node
kubectl get pods -A -o wide | grep <node-name>
# Tells you which services to investigate for connection patterns

# Cost calculation
TX_BYTES_PER_SEC=104857600  # 100MB/s
HOURS_PER_MONTH=720
GB_PER_MONTH=$(echo "$TX_BYTES_PER_SEC * $HOURS_PER_MONTH * 3600 / 1024 / 1024 / 1024" | bc)
echo "Monthly cross-AZ cost: \$$(echo "$GB_PER_MONTH * 0.01" | bc)"
# Output: Monthly cross-AZ cost: $2592
```

### How topology spread prevents cross-AZ traffic:

The project's production values have:
```yaml
# charts/payment-service/values.yaml
topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: topology.kubernetes.io/zone
    whenUnsatisfiable: DoNotSchedule   # HARD: never violate
```

This ensures payment-service pods spread across AZs. If payment-service (AZ-a) calls order-service, and order-service has a pod in AZ-a as well, the Kubernetes Service load balancer SHOULD route to the AZ-a pod. But it only does so if `service.kubernetes.io/topology-mode: auto` is set on the Service.

```bash
# Check if topology-aware routing is enabled
kubectl get svc order-service -n order-ns \
  -o jsonpath='{.metadata.annotations}'
# Should contain: service.kubernetes.io/topology-mode: auto
# If not: cross-AZ calls are still possible even with spread
```

---

## Per-Environment Threshold Tuning Reference

```hcl
# terraform/environments/dev/main.tf
network_thresholds = {
  tcp_retransmission_pct   = 5.0      # relaxed: dev has small instances
  dns_failure_rate_pct     = 1.0      # relaxed: dev has intermittent DNS
  max_connections_per_proc = 1200     # relaxed: dev may have pool leaks during development
  node_throughput_bytes    = 209715200 # 200MB/s: dev is less cost-sensitive
}

# terraform/environments/staging/main.tf
network_thresholds = {
  tcp_retransmission_pct   = 3.0
  dns_failure_rate_pct     = 0.5
  max_connections_per_proc = 800
  node_throughput_bytes    = 104857600 # 100MB/s
}

# terraform/environments/production/main.tf
network_thresholds = {
  tcp_retransmission_pct   = 1.0      # strict: any packet loss = customer impact
  dns_failure_rate_pct     = 0.1      # strict: near-zero tolerance
  max_connections_per_proc = 500      # strict: payment-service must manage connections
  node_throughput_bytes    = 52428800 # 50MB/s: alert earlier in production
}
```

**Why production thresholds are tighter than dev:**
- Production: every customer-facing request matters. Alert earlier, fix faster.
- Dev: developers are frequently restarting pods, changing connection pool sizes, testing edge cases. Aggressive thresholds would generate constant noise.
- Staging: validates that production-like behavior works. Medium thresholds catch real production candidates.
