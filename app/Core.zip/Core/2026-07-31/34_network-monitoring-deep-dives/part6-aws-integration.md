# Part 6 — AWS-Side Network Monitoring Integration Deep Dive

> Dynatrace OneAgent sees traffic from inside the EKS nodes. But AWS networking primitives (security groups, NACLs, ALB routing) are invisible to OneAgent. VPC Flow Logs and ALB access logs are the two AWS sources that fill this blind spot. This part explains the full pipeline from AWS log to Dynatrace alert.

---

## The Visibility Gap

```
What OneAgent sees:
  Pod → TCP connection → [connection established or timed out]

What OneAgent does NOT see:
  Was the SYN packet ACCEPTED or DROPPED by the security group?
  Was the packet rejected by a NACL?
  Which ALB target group did this request route to?
  Did the ALB backend connection time out?
  Which connection had a 504 at the ALB level?

These live OUTSIDE the EKS node — in AWS networking infrastructure.
VPC Flow Logs and ALB access logs capture exactly this layer.
```

---

## 6.1 VPC Flow Logs → Dynatrace

### What VPC Flow Logs are:

VPC Flow Logs are a metadata record of every network flow through an AWS VPC. They do NOT capture packet contents (no payload, no headers). They capture:

```
VPC Flow Log v2 format (14 fields):
  version          → log format version (always 2)
  account-id       → AWS account
  interface-id     → ENI ID (e.g., eni-abcdef12)
  srcaddr          → source IP address
  dstaddr          → destination IP address
  srcport          → source port
  dstport          → destination port
  protocol         → 6=TCP, 17=UDP, 1=ICMP
  packets          → packet count in this flow
  bytes            → byte count
  start            → Unix timestamp of first packet
  end              → Unix timestamp of last packet
  action           → ACCEPT or REJECT
  log-status       → OK, NODATA, SKIPDATA
```

Example record:
```
2 123456789010 eni-abc123 10.0.5.23 10.0.10.45 52341 5432 6 15 2400 1690806000 1690806060 REJECT OK
```
Meaning: TCP connection from pod at 10.0.5.23 port 52341 to DB at 10.0.10.45 port 5432 was REJECTED by the security group. 15 packets, 2400 bytes, lasted 60 seconds.

**In plain English:** payment-service tried to connect to RDS port 5432 for 1 minute but the security group blocked it. The app sees a timeout; VPC Flow Logs show the REJECT.

---

### The Full Pipeline Architecture:

```
[1] VPC Flow Logs enabled on the VPC/subnet → CloudWatch Logs
    Log group: /aws/vpc/flowlogs/company-production

[2] CloudWatch Logs subscription filter
    Triggers Lambda when new log records arrive (real-time, < 1 minute lag)

[3] Lambda function (vpc-flow-to-dynatrace/handler.py)
    Parses REJECT records
    Aggregates: count of rejects per minute
    Pushes to Dynatrace Metrics Ingest API

[4] Dynatrace stores: custom.network.vpc_flow_rejects{environment=production}
    Available as a regular metric: alertable, dashboardable

[5] Terraform metric event monitors this custom metric
    > 5 rejects/min → ERROR_EVENT → Slack/PagerDuty alert
```

---

### Setting Up VPC Flow Logs (Terraform):

```hcl
# Add to terraform/modules/vpc/main.tf or terraform/environments/<env>/main.tf

resource "aws_cloudwatch_log_group" "vpc_flow_logs" {
  name              = "/aws/vpc/flowlogs/${var.environment}"
  retention_in_days = 7    # only need recent data for real-time alerting
}

resource "aws_iam_role" "flow_logs" {
  name = "vpc-flow-logs-${var.environment}"
  assume_role_policy = jsonencode({
    Statement = [{
      Effect = "Allow"
      Principal = { Service = "vpc-flow-logs.amazonaws.com" }
      Action = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "flow_logs" {
  role = aws_iam_role.flow_logs.id
  policy = jsonencode({
    Statement = [{
      Effect = "Allow"
      Action = ["logs:CreateLogGroup", "logs:CreateLogStream", "logs:PutLogEvents"]
      Resource = "${aws_cloudwatch_log_group.vpc_flow_logs.arn}:*"
    }]
  })
}

resource "aws_flow_log" "vpc" {
  vpc_id          = module.vpc.vpc_id
  traffic_type    = "REJECT"       # ONLY log rejected traffic (not all traffic)
  iam_role_arn    = aws_iam_role.flow_logs.arn
  log_destination = aws_cloudwatch_log_group.vpc_flow_logs.arn
  log_destination_type = "cloud-watch-logs"
}
```

**Why `traffic_type = "REJECT"` not "ALL":**
VPC Flow Logs for ALL traffic on a busy production cluster generates gigabytes per hour. At $0.50/GB ingested into CloudWatch, this costs hundreds of dollars/month. REJECT-only traffic is small (healthy clusters have near-zero rejects) and captures exactly the security group blocking signals we need.

---

### The Lambda in Detail:

```python
# vpc-flow-to-dynatrace/handler.py
import boto3, json, base64, gzip, urllib.request, os

DT_URL   = os.environ["DT_URL"]        # https://abc.live.dynatrace.com
DT_TOKEN = os.environ["DT_TOKEN"]      # DT API token, metrics.write scope
ENV      = os.environ["ENVIRONMENT"]   # "production", "staging", or "dev"

def handler(event, context):
    # CloudWatch Logs subscription delivers logs as base64(gzip(JSON))
    raw     = event["awslogs"]["data"]
    payload = gzip.decompress(base64.b64decode(raw))
    log_data = json.loads(payload)

    # Parse each log record and count REJECTs
    reject_by_dst = {}   # { "10.0.10.45:5432": count }

    for log_event in log_data["logEvents"]:
        fields = log_event["message"].split()
        # VPC Flow Log v2 has 14 fields
        if len(fields) < 14:
            continue

        action = fields[12]  # field index 12 = "action" (ACCEPT/REJECT)
        if action != "REJECT":
            continue

        dstaddr = fields[4]   # destination IP
        dstport = fields[6]   # destination port

        # Group by destination (tells us WHICH service is being blocked)
        dst_key = f"{dstaddr}:{dstport}"
        reject_by_dst[dst_key] = reject_by_dst.get(dst_key, 0) + 1

    total_rejects = sum(reject_by_dst.values())
    if total_rejects == 0:
        return   # no rejects in this batch, skip API call

    # Build Dynatrace metrics ingest format:
    # metric.name[,dimensions] count=value
    # https://www.dynatrace.com/support/help/how-to-use-dynatrace/metrics/metric-ingestion/metric-ingestion-protocol
    metric_lines = []

    # Total rejects metric
    metric_lines.append(
        f"custom.network.vpc_flow_rejects,environment={ENV} {total_rejects}"
    )

    # Per-destination metrics (which DB/service is being blocked)
    for dst, count in reject_by_dst.items():
        # Sanitize the key (DT dimension values can't contain colons)
        dst_safe = dst.replace(":", "_port_")
        metric_lines.append(
            f"custom.network.vpc_flow_rejects.by_destination,"
            f"environment={ENV},destination={dst_safe} {count}"
        )

    # Push all metrics in one API call
    body = "\n".join(metric_lines).encode()

    req = urllib.request.Request(
        f"{DT_URL}/api/v2/metrics/ingest",
        data=body,
        headers={
            "Content-Type": "text/plain; charset=utf-8",
            "Authorization": f"Api-Token {DT_TOKEN}"
        },
        method="POST"
    )

    try:
        resp = urllib.request.urlopen(req, timeout=5)
        print(f"DT ingest response: {resp.status}, rejects: {total_rejects}")
    except Exception as e:
        print(f"DT ingest failed: {e}")
        raise   # Lambda will retry

```

**The `custom.network.vpc_flow_rejects.by_destination` metric:**
This tells you not just "there are rejects" but "which destination is being blocked." If you see:
```
custom.network.vpc_flow_rejects.by_destination{destination="10.0.10.45_port_5432"} = 45
```
You know something is trying to reach RDS (port 5432) and being blocked. `10.0.10.45` → resolve to IP → find which RDS instance. Security group audit immediately tells you what changed.

---

### CloudWatch Subscription Filter (triggers the Lambda):

```hcl
# Terraform: connect CloudWatch Logs to Lambda

resource "aws_cloudwatch_log_subscription_filter" "vpc_flow_to_lambda" {
  name            = "vpc-flow-reject-to-dynatrace-${var.environment}"
  log_group_name  = aws_cloudwatch_log_group.vpc_flow_logs.name
  filter_pattern  = "REJECT"    # Pre-filter: only trigger Lambda for REJECT records
  destination_arn = aws_lambda_function.vpc_flow_processor.arn
}

resource "aws_lambda_permission" "allow_cloudwatch" {
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.vpc_flow_processor.function_name
  principal     = "logs.amazonaws.com"
  source_arn    = "${aws_cloudwatch_log_group.vpc_flow_logs.arn}:*"
}
```

The `filter_pattern = "REJECT"` means CloudWatch pre-filters log records and only invokes Lambda for batches that contain "REJECT". Lambda is never called for ACCEPT traffic, reducing cost to near-zero for healthy clusters.

---

## 6.2 ALB Access Logs → Dynatrace

### What ALB Access Logs contain:

```
ALB access log fields (selected relevant ones):
  timestamp           → 2026-07-31T14:30:00.123456Z
  type                → https
  elb                 → company-production-alb-1234.ap-northeast-1.elb.amazonaws.com
  client:port         → 203.0.113.50:58423 (user's IP)
  target:port         → 10.0.5.23:8080 (pod IP and port)
  request_processing_time  → 0.000 (time for ALB to receive request)
  target_processing_time   → 0.243 (time for backend pod to respond)
  response_processing_time → 0.000 (time to send response to client)
  elb_status_code     → 200 (ALB's response to client)
  target_status_code  → 200 (pod's response to ALB)
  received_bytes      → 1024
  sent_bytes          → 4096
  request             → GET https://payment.company.com:443/api/v1/payments HTTP/2.0
  user_agent          → Mozilla/5.0 ...
  target_group_arn    → arn:aws:elasticloadbalancing:...
```

**Key fields for network investigation:**

| Field | Normal value | Problem value | Meaning |
|-------|-------------|--------------|---------|
| `elb_status_code` | 200 | 502 | ALB got invalid response from pod |
| `elb_status_code` | 200 | 503 | ALB has no healthy targets |
| `elb_status_code` | 200 | 504 | ALB timed out waiting for pod |
| `target_status_code` | 200 | `-` | ALB couldn't connect to pod (network failure) |
| `target_processing_time` | 0.243 | 30.000 | Pod took 30s (timeout threshold hit) |

`target_status_code = "-"` is the most telling: the ALB tried to connect to the pod but couldn't establish a TCP connection. This happens when: the pod's security group blocks ALB, the pod is crashing, or the pod's network is down.

### CloudWatch Logs Insights Query for ALB Timeout Analysis:

```sql
-- Run this in CloudWatch Logs Insights against the ALB access log group
-- Log group: /aws/applicationloadbalancer/company-production

fields @timestamp, elb_status_code, target_status_code,
       target_processing_time, target_ip, request
| filter elb_status_code = "504"
      or target_status_code = "-"
      or target_processing_time > 5.0
| stats count() as request_count,
        avg(target_processing_time) as avg_backend_time,
        max(target_processing_time) as max_backend_time
  by bin(1min), target_ip
| sort @timestamp desc
| limit 100
```

This query answers: "For each pod IP, how many timeout/connection-failure requests per minute, and what was the average backend processing time?"

**If `target_status_code = "-"` spikes for a specific `target_ip`:**
```
target_ip: 10.0.5.23 → 450 failures
target_ip: 10.0.5.24 → 0 failures
target_ip: 10.0.5.25 → 0 failures

Interpretation:
  Pod at 10.0.5.23 is unreachable from ALB.
  Other pods are fine → not a service-wide issue.
  This specific pod's network is broken.

kubectl get pod -A -o wide | grep "10.0.5.23"
→ payment-service-abc-def in payment-ns on node-prod-1a-002

kubectl describe pod payment-service-abc-def -n payment-ns
→ Look for: network interface issues, OOMKill events, recent restarts
```

### Pushing ALB Timeout Counts to Dynatrace:

```python
# alb-timeouts-to-dynatrace/handler.py
# Triggered by CloudWatch Logs subscription for ALB access logs

import json, base64, gzip, re, urllib.request, os, urllib.parse

DT_URL  = os.environ["DT_URL"]
DT_TOKEN = os.environ["DT_TOKEN"]
ENV     = os.environ["ENVIRONMENT"]

def handler(event, context):
    payload = gzip.decompress(base64.b64decode(event["awslogs"]["data"]))
    log_data = json.loads(payload)

    timeout_count = 0          # 504 responses
    no_target_count = 0        # target_status_code = "-"
    slow_backend_count = 0     # target_processing_time > 5.0

    for log_event in log_data["logEvents"]:
        fields = log_event["message"].split()
        if len(fields) < 14:
            continue

        elb_status    = fields[8]
        target_status = fields[9]

        try:
            target_time = float(fields[6])   # target_processing_time
        except (ValueError, IndexError):
            target_time = 0.0

        if elb_status == "504":
            timeout_count += 1
        if target_status == "-":
            no_target_count += 1
        if target_time > 5.0:
            slow_backend_count += 1

    metrics = [
        f"custom.network.alb.timeouts,environment={ENV} {timeout_count}",
        f"custom.network.alb.no_target,environment={ENV} {no_target_count}",
        f"custom.network.alb.slow_backend,environment={ENV} {slow_backend_count}",
    ]

    body = "\n".join(metrics).encode()
    req = urllib.request.Request(
        f"{DT_URL}/api/v2/metrics/ingest",
        data=body,
        headers={"Content-Type": "text/plain", "Authorization": f"Api-Token {DT_TOKEN}"},
        method="POST"
    )
    urllib.request.urlopen(req, timeout=5)
```

Then alert on these custom metrics:
```hcl
resource "dynatrace_metric_events" "alb_no_target" {
  enabled    = true
  event_type = "ERROR_EVENT"
  summary    = "[${upper(var.environment)}] ALB: pod connection failures detected"
  description = "ALB cannot connect to backend pods (target_status_code = '-'). Pod network broken, security group blocking ALB, or pod crashing. Check pod health immediately."

  model_properties {
    threshold          = 10      # 10 ALB→pod connection failures per minute
    violating_samples  = 2
    dealerting_samples = 3
    samples            = 3
    alert_on_no_data   = false
    alert_condition    = "ABOVE"
    type               = "STATIC_THRESHOLD"
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "custom.network.alb.no_target"
    resolution = "1m"
  }
}
```

---

## Why VPC Flow Logs and ALB Logs Are Complementary

| Question | VPC Flow Logs | ALB Access Logs |
|---------|--------------|----------------|
| Is traffic being blocked by security group? | ✅ REJECT records | ❌ Not visible |
| Is a specific pod unreachable from ALB? | Partially (can see SYN packets) | ✅ target_status="-" |
| Which ALB requests are timing out? | ❌ No request details | ✅ 504 records |
| Which pod is processing requests slowly? | ❌ No application data | ✅ target_processing_time |
| Is there cross-pod traffic being blocked? | ✅ Pod-to-pod REJECT | ❌ ALB only sees external |
| Can I see intra-cluster blocking? | ✅ Pod-to-pod flows | ❌ ALB is external only |

Together, they cover the entire network path:
```
Internet → ALB (ALB logs cover this gap) → Pod → RDS/SQS (VPC Flow Logs cover this gap)
```
