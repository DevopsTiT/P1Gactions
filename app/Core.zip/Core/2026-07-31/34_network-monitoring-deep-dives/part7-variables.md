# Part 7 — Variables Extension for Network Thresholds Deep Dive

> The `network_thresholds` variable block adds per-environment tuning for all 4 new network signals. This keeps threshold values in the environment's `main.tf` file — alongside the existing application thresholds — so one file is the complete truth for how an environment is monitored.

---

## Why Separate Network Threshold Variables

The existing `variables.tf` has service-level thresholds inside the `services` map:

```hcl
# Current: per-service thresholds (inside var.services)
services = {
  "payment-service" = {
    error_rate_alert  = 0.1     # % — per service
    latency_p99_ms    = 300     # ms — per service
    jvm_heap_pct      = 70      # % — per service
    ...
  }
}
```

Network thresholds are DIFFERENT: they apply at the infrastructure level, not per service. TCP retransmission is a property of the node, not the service. DNS failure rate applies cluster-wide, not per service.

So they get their own top-level variable, not embedded in the services map.

---

## The Variable Definition

```hcl
# terraform/modules/dynatrace/variables.tf — add this block

variable "network_thresholds" {
  description = "Per-environment network alert thresholds. All values apply at the infrastructure level (node/cluster), not per-service."
  type = object({
    tcp_retransmission_pct   = number
    # Percentage of TCP segments retransmitted.
    # Type: number (float). Example: 2.0 = 2%.
    # Used by: dynatrace_metric_events.tcp_retransmission
    # Metric: builtin:host.net.retransmission

    dns_failure_rate_pct     = number
    # Percentage of DNS lookups returning an error.
    # Type: number (float). Example: 0.5 = 0.5%.
    # Used by: dynatrace_metric_events.dns_failures
    # Metric: builtin:process.network.dnsFailureRate

    max_connections_per_proc = number
    # Maximum active TCP connections per process (JVM pod).
    # Type: number (integer). Example: 800.
    # Used by: dynatrace_metric_events.connection_saturation
    # Metric: builtin:process.network.connections

    node_throughput_bytes    = number
    # Maximum outbound bytes per second per node.
    # Type: number (integer, bytes). Example: 104857600 = 100MB/s.
    # Used by: dynatrace_metric_events.cross_az_traffic
    # Metric: builtin:host.net.throughput.tx
  })

  default = {
    tcp_retransmission_pct   = 2.0
    dns_failure_rate_pct     = 0.5
    max_connections_per_proc = 800
    node_throughput_bytes    = 104857600   # 100MB/s = 100 × 1024 × 1024
  }
  # The default values are reasonable for most staging/dev environments.
  # Production should always override with stricter values.
}
```

**Why provide a `default`:**
The default lets the module be called without specifying `network_thresholds` — backward compatible with any environment that was set up before this variable was added. The defaults are "medium" values — not too strict (avoids false alerts), not too relaxed (still catches real problems).

---

## Using the Variable in the Module

```hcl
# terraform/modules/dynatrace/main.tf — update the threshold references

resource "dynatrace_metric_events" "tcp_retransmission" {
  for_each = var.services
  ...
  model_properties {
    threshold = var.network_thresholds.tcp_retransmission_pct
    # Before: hardcoded 2.0
    # After:  reads from per-environment config
    # Dev can set 5.0 (relaxed); production sets 1.0 (strict)
    ...
  }
}

resource "dynatrace_metric_events" "dns_failures" {
  for_each = var.services
  ...
  model_properties {
    threshold = var.network_thresholds.dns_failure_rate_pct
    ...
  }
}

resource "dynatrace_metric_events" "connection_saturation" {
  for_each = var.services
  ...
  model_properties {
    threshold = var.network_thresholds.max_connections_per_proc
    ...
  }
}

resource "dynatrace_metric_events" "cross_az_traffic" {
  for_each = var.services
  ...
  model_properties {
    threshold = var.network_thresholds.node_throughput_bytes
    ...
  }
}
```

---

## Per-Environment Values

### Dev (`terraform/environments/dev/main.tf`):

```hcl
module "dynatrace" {
  source      = "../../modules/dynatrace"
  environment = "dev"
  ...

  network_thresholds = {
    tcp_retransmission_pct   = 5.0
    # Dev uses t3.medium instances (4 vCPU, 4GB RAM).
    # Small instances have more variability in network performance.
    # During development, services are frequently restarted →
    # connection bursts → momentary retransmissions.
    # 5% allows normal dev activity without constant alerts.

    dns_failure_rate_pct     = 1.0
    # Dev services are often idle (no traffic for hours).
    # When they restart, there's a brief DNS resolution burst
    # as Spring initializes all HTTP clients simultaneously.
    # 1% threshold avoids false alerts during pod restarts.

    max_connections_per_proc = 1200
    # Developers may test connection pool configurations in dev.
    # A developer setting maxPoolSize=500 to test behavior
    # shouldn't page on-call.
    # 1200 catches runaway leaks while allowing experimentation.

    node_throughput_bytes    = 209715200   # 200MB/s
    # Dev rarely has sustained high traffic.
    # High threshold means dev won't alert on local load tests.
    # Cost monitoring is less critical in dev (smaller instances, less traffic).
  }
}
```

### Staging (`terraform/environments/staging/main.tf`):

```hcl
module "dynatrace" {
  source      = "../../modules/dynatrace"
  environment = "staging"
  ...

  network_thresholds = {
    tcp_retransmission_pct   = 3.0
    # Staging uses similar instance types to production but smaller count.
    # k6 load tests run in staging (50 VUs for 3 min) — these create
    # connection bursts. 3% threshold handles load test traffic spikes
    # while catching real infrastructure problems.

    dns_failure_rate_pct     = 0.5
    # Same as the module default.
    # Staging should validate that DNS works correctly before production.
    # 0.5% catches real CoreDNS issues.

    max_connections_per_proc = 800
    # Same as the module default.
    # Staging validates production-like connection pool behavior.
    # If staging triggers this alert, the production deploy should be blocked.

    node_throughput_bytes    = 104857600   # 100MB/s
    # Same as module default.
    # k6 load tests may push 80–90MB/s momentarily.
    # 100MB/s catches sustained high throughput while allowing load tests.
  }
}
```

### Production (`terraform/environments/production/main.tf`):

```hcl
module "dynatrace" {
  source      = "../../modules/dynatrace"
  environment = "production"
  ...

  network_thresholds = {
    tcp_retransmission_pct   = 1.0
    # Production uses m5.xlarge nodes (4 vCPU, 16GB RAM, 10Gbps NIC).
    # Larger instances → more stable network → retransmission should be near 0.
    # 1% threshold means: "something unusual is happening."
    # In production, this is always customer-impacting → alert immediately.

    dns_failure_rate_pct     = 0.1
    # Near-zero tolerance for DNS failures in production.
    # 0.1% = 1 failed lookup per 1000.
    # ndots:5 can cause some NXDOMAIN noise, but proper ndots config
    # (setting ndots:2 in the pod spec) should reduce this to near zero.
    # 0.1% threshold catches real CoreDNS issues while filtering noise.

    max_connections_per_proc = 500
    # Stricter than dev/staging.
    # payment-service production connection pool is sized appropriately:
    #   HikariCP: maxPoolSize = 20
    #   HTTP clients: ~50 persistent connections
    #   System: ~10
    #   Total expected: ~80 per pod
    # 500 means: "connections are 6× higher than expected" → investigate.
    # (Not 80 because HPA might create more pods under load, or brief spikes)

    node_throughput_bytes    = 52428800   # 50MB/s
    # Stricter than staging.
    # Production nodes should have predictable traffic patterns.
    # 50MB/s sustained outbound from a single node is unusual in production.
    # At normal RPS (100 req/s for payment-service):
    #   Response payload: ~2KB × 100 = 200KB/s per pod
    #   3 pods × 200KB/s = 600KB/s (far below 50MB/s threshold)
    # 50MB/s means: either a batch job ran (scheduled reports?), 
    #   cross-AZ topology spread broke, or a data exfiltration event.
  }
}
```

---

## Threshold Decision Guide

When deciding thresholds for a new environment, answer these questions:

```
For tcp_retransmission_pct:
  What instance type is this environment using?
    t3.medium (dev/staging): use 3–5%
    m5.xlarge (production):  use 1–2%
  Are connection bursts expected (e.g., load tests, rolling deploys)?
    Yes: add 1–2% buffer above expected peaks
    No:  use tighter threshold

For dns_failure_rate_pct:
  Is ndots:2 configured on pods (reduces noise)?
    Yes: 0.1% (near zero)
    No:  0.5–1.0% (ndots:5 generates some NXDOMAIN noise)
  How critical is DNS to this environment?
    Production: 0.1–0.5%
    Dev: 1.0%

For max_connections_per_proc:
  Expected connections per pod (design-time):
    HikariCP pool size: X
    HTTP client pool size: Y
    System connections: ~10
    Expected normal: X + Y + 10
  Threshold: (expected normal) × 5–10× (catches leaks while allowing bursts)
  Example: normal=80, threshold=500 (6.25×)

For node_throughput_bytes:
  Expected peak traffic per node:
    RPS per pod × response size × pods per node = baseline
  Convert to bytes/sec.
  Threshold: baseline × 50–100×
  (You only want to alert on truly anomalous throughput, not normal peaks)
  Example: baseline=600KB/s, threshold=50MB/s (83×)
```

---

## Adding to Production Terraform Plan Review

When `terraform plan` shows changes to `network_thresholds`, the PR review checklist should include:

```
□ Did threshold values increase or decrease?
  Increase (relaxed): acceptable only if we have evidence the old values
    caused false positives. Requires P1 post-mortem or spike analysis.
  
  Decrease (tighter): acceptable only if we know current production
    baseline and the new threshold is above it. Check DT metrics history
    for the last 30 days to confirm no false alarms would have fired.

□ Do all 4 thresholds change together, or just one?
  All 4 changing: likely a copy-paste from another environment → verify each
  One changing: targeted fix → easier to validate reasoning

□ Is the change symmetric across all environments?
  Production tighter ≥ staging tighter ≥ dev relaxed: expected
  Production RELAXED, dev STRICT: red flag, should not happen
```
