# Part 9 — Verification Commands Deep Dive

> Every command needed to confirm that network monitoring is working correctly: from checking if OneAgent is collecting the right metrics, to validating Terraform applied cleanly, to diagnosing specific failure modes when alerts fire.

---

## Verification Philosophy

Network monitoring verification has three stages:

```
Stage 1: SETUP VERIFICATION (run once after terraform apply)
  "Did all the Terraform resources get created correctly in Dynatrace?"
  "Is OneAgent collecting the metrics we depend on?"

Stage 2: STEADY-STATE VERIFICATION (run weekly or after infra changes)
  "Are current network metrics within normal ranges?"
  "Are all synthetic monitors passing?"
  "Has anything drifted?"

Stage 3: INCIDENT VERIFICATION (run when an alert fires)
  "Which specific node/service/pod is the source of the problem?"
  "Has the fix resolved the issue?"
  "Is the DT Problem auto-closing?"
```

---

## Stage 1: Setup Verification

### 1.1 Verify Terraform applied all DT resources

```bash
cd terraform/environments/production

# List all Dynatrace resources Terraform manages
terraform state list | grep dynatrace | sort
# Expected output includes:
#   module.dynatrace.dynatrace_metric_events.tcp_retransmission["payment-service"]
#   module.dynatrace.dynatrace_metric_events.tcp_retransmission["order-service"]
#   module.dynatrace.dynatrace_metric_events.tcp_retransmission["notification-service"]
#   module.dynatrace.dynatrace_metric_events.dns_failures["payment-service"]
#   module.dynatrace.dynatrace_metric_events.connection_saturation["payment-service"]
#   module.dynatrace.dynatrace_metric_events.cross_az_traffic["payment-service"]
#   module.dynatrace.dynatrace_metric_events.coredns_errors
#   module.dynatrace.dynatrace_metric_events.netpol_drops
#   module.dynatrace.dynatrace_metric_events.vpc_flow_rejects
#   module.dynatrace.dynatrace_http_monitor.connectivity_chain["payment-service"]
#   module.dynatrace.dynatrace_dashboard.network_overview

# Verify no drift (all DT config matches Terraform state)
terraform plan -target=module.dynatrace -detailed-exitcode
# Exit code 0 = no changes needed = DT matches Terraform
# Exit code 2 = drift found = someone modified DT config manually
```

### 1.2 Verify OneAgent is collecting network metrics via DT API

```bash
export DT_URL="https://TENANT.live.dynatrace.com"
export DT_TOKEN="dt0c01.xxxx"   # needs metrics.read scope

# Verify builtin:host.net.retransmission data exists for production nodes
curl -s -G "${DT_URL}/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  --data-urlencode "metricSelector=builtin:host.net.retransmission:max:splitBy(dt.entity.host)" \
  --data-urlencode "from=now-30m" \
  --data-urlencode "resolution=1m" \
  --data-urlencode "mzSelector=mzName(\"payments-production\")" \
  | jq '{
    "metric_present": (.resolution.results | length > 0),
    "host_count": (.resolution.results | length),
    "sample_values": [.resolution.results[0].values[0:3]]
  }'
# Expected:
# { "metric_present": true, "host_count": 3, "sample_values": [[0.08, 0.06, 0.09]] }
# If metric_present is false: OneAgent is not running or not reporting

# Verify DNS failure rate data
curl -s -G "${DT_URL}/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  --data-urlencode "metricSelector=builtin:process.network.dnsFailureRate:avg:splitBy(process.group.name)" \
  --data-urlencode "from=now-1h" \
  | jq '[.resolution.results[] | {
    "service": .dimensionMap["process.group.name"],
    "avg_dns_failure_rate": (.values | map(select(. != null)) | add / length)
  }]'
# Expected: list of services with avg_dns_failure_rate near 0.0

# Verify process connection count data
curl -s -G "${DT_URL}/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  --data-urlencode "metricSelector=builtin:process.network.connections:sum:splitBy(process.group.name)" \
  --data-urlencode "from=now-30m" \
  | jq '[.resolution.results[] | {
    "service": .dimensionMap["process.group.name"],
    "total_connections": (.values[-1] // 0)
  }] | sort_by(-.total_connections)'
# Shows services ranked by connection count — highest first
# If payment-service shows 5000+: investigate immediately (Signal C territory)

# Verify TCP throughput data
curl -s -G "${DT_URL}/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  --data-urlencode "metricSelector=builtin:host.net.throughput.tx:max:splitBy(dt.entity.host)" \
  --data-urlencode "from=now-30m" \
  --data-urlencode "resolution=1m" \
  | jq '[.resolution.results[] | {
    "host": .dimensionMap["dt.entity.host"],
    "max_throughput_MBps": ((.values | map(select(. != null)) | max // 0) / 1048576 | floor)
  }]'
# Should show values well below 50 (MB/s) for production threshold
```

### 1.3 Verify synthetic connectivity chain monitors are created and passing

```bash
# List all synthetic monitors
curl -s "${DT_URL}/api/v1/synthetic/monitors" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  | jq '[.monitors[] | select(.name | contains("Connectivity Chain")) | {
    "name": .name,
    "enabled": .enabled,
    "type": .type,
    "locations": (.locations | length)
  }]'
# Expected: 3 monitors (one per service), all enabled, 2 locations (production)

# Get the most recent execution results for payment-service synthetic
curl -s "${DT_URL}/api/v1/synthetic/monitors" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  | jq -r '.monitors[] | select(.name == "payment-service Connectivity Chain [production]") | .entityId' \
  | xargs -I{} curl -s \
  "${DT_URL}/api/v1/synthetic/monitors/{}/results?timeFrom=now-1h&timeTo=now" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  | jq '.monitorResults[0] | {
    "last_result": .status,
    "timestamp": .timestamp,
    "step1_db_up": (.stepResults[1].requestResults[0].responseBody | contains("\"db\":{\"status\":\"UP\"}"))
  }'
# Expected: { "last_result": "SUCCESS", "step1_db_up": true }
```

---

## Stage 2: Steady-State Verification

### 2.1 Weekly network health check

```bash
# ─── Kubernetes layer ─────────────────────────────────────────────────────────

# All application pods running
kubectl get pods -A --field-selector=status.phase!=Running,status.phase!=Succeeded \
  | grep -E "payment|order|notification"
# Expected: empty output

# CoreDNS healthy
kubectl get pods -n kube-system -l k8s-app=kube-dns
kubectl top pod -n kube-system -l k8s-app=kube-dns
# Memory should be below 80% of limit

# No NetworkPolicies in application namespaces (unless intentional)
kubectl get networkpolicy -n payment-ns -n order-ns -n notification-ns
# If any exist: verify they're intentional and documented

# Pod distribution across nodes (verify topology spread is working)
echo "=== payment-service pod distribution ==="
kubectl get pods -n payment-ns -o wide | awk '{print $7}' | sort | uniq -c
# Should show: 1 payment-service pod per node (with 3 nodes, 3 pods)
# If all on 1 node: topology spread broken → Signal D will fire soon

echo "=== notification-service pod distribution ==="
kubectl get pods -n notification-ns -o wide | awk '{print $7}' | sort | uniq -c
# Same expectation

# ─── EKS node network health ──────────────────────────────────────────────────

# Check current node NIC utilization (from CloudWatch)
aws cloudwatch get-metric-statistics \
  --namespace AWS/EC2 \
  --metric-name NetworkOut \
  --dimensions Name=AutoScalingGroupName,Value=company-production-system \
  --start-time $(date -u -v-1H +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 300 \
  --statistics Maximum \
  --region ap-northeast-1 \
  | jq '.Datapoints | sort_by(.Timestamp) | last | {
    "max_network_out_bytes_5min": .Maximum,
    "max_network_out_MBps": (.Maximum / 5 / 60 / 1048576 | floor)
  }'

# ─── NAT Gateway SNAT check ───────────────────────────────────────────────────

# Get NAT Gateway IDs for the production VPC
NAT_GW_IDS=$(aws ec2 describe-nat-gateways \
  --filter "Name=state,Values=available" \
  --filter "Name=tag:environment,Values=production" \
  --query 'NatGateways[].NatGatewayId' \
  --output text \
  --region ap-northeast-1)

for NAT_ID in $NAT_GW_IDS; do
  echo "=== NAT Gateway: $NAT_ID ==="
  aws cloudwatch get-metric-statistics \
    --namespace AWS/NATGateway \
    --metric-name PortAllocationErrorCount \
    --dimensions Name=NatGatewayId,Value=$NAT_ID \
    --start-time $(date -u -v-1H +%Y-%m-%dT%H:%M:%SZ) \
    --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
    --period 3600 \
    --statistics Sum \
    --region ap-northeast-1 \
    | jq '.Datapoints[0] | {nat_gateway: "'$NAT_ID'", "snat_errors_last_hour": (.Sum // 0)}'
done
# Expected: snat_errors_last_hour = 0 for all NAT Gateways
# Non-zero: SNAT port exhaustion is occurring → Signal C threshold too high
```

### 2.2 Verify VPC Flow Logs pipeline is working

```bash
# Check if Flow Logs are enabled
aws ec2 describe-flow-logs \
  --filter "Name=tag:environment,Values=production" \
  --query 'FlowLogs[].{FlowLogId: FlowLogId, Status: FlowLogStatus, DeliverLogsStatus: DeliverLogsStatus}' \
  --region ap-northeast-1
# Expected: FlowLogStatus=ACTIVE, DeliverLogsStatus=SUCCESS

# Check if CloudWatch log group has recent data
aws logs describe-log-streams \
  --log-group-name /aws/vpc/flowlogs/production \
  --order-by LastEventTime \
  --descending \
  --max-items 3 \
  --region ap-northeast-1 \
  | jq '.logStreams[] | {
    stream: .logStreamName,
    last_event: (.lastEventTimestamp / 1000 | todate)
  }'
# Expected: lastEventTimestamp within the last 5 minutes (flow logs are near real-time)

# Verify Lambda is being invoked
aws cloudwatch get-metric-statistics \
  --namespace AWS/Lambda \
  --metric-name Invocations \
  --dimensions Name=FunctionName,Value=vpc-flow-to-dynatrace-production \
  --start-time $(date -u -v-24H +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 3600 \
  --statistics Sum \
  --region ap-northeast-1 \
  | jq '[.Datapoints[].Sum] | add // 0 | {"lambda_invocations_last_24h": .}'
# Expected: some positive number (should be invoked every time new REJECT records arrive)
# If 0: Lambda trigger isn't configured or no REJECTs in 24h (could be normal)

# Verify custom metrics arrived in Dynatrace
curl -s -G "${DT_URL}/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  --data-urlencode "metricSelector=custom.network.vpc_flow_rejects:sum:splitBy(environment)" \
  --data-urlencode "from=now-24h" \
  | jq '{
    "data_present": (.resolution.results | length > 0),
    "total_rejects_24h": (.resolution.results[0].values | map(select(. != null)) | add // 0)
  }'
# data_present=false: Lambda isn't pushing data (check Lambda errors in CloudWatch)
# total_rejects_24h=0: no REJECTs in 24h (healthy) — but verify Lambda IS running
```

---

## Stage 3: Incident Verification

### When Signal A fires (TCP retransmission):

```bash
# Step 1: Find the affected node from the DT Problem
# DT UI → Problem → Affected entities → get hostname, e.g., ip-10-0-5-100

# Step 2: Current retransmission rate
kubectl run netdebug --image=nicolaka/netshoot --rm -it --restart=Never \
  --overrides='{"spec":{"nodeName":"ip-10-0-5-100"}}' -- \
  cat /proc/net/snmp \
  | grep -A1 "^Tcp:"
# RetransSegs: count how fast this grows (run twice, 60s apart, compute diff)

# Step 3: MTU check
kubectl run netdebug --image=nicolaka/netshoot --rm -it --restart=Never \
  --overrides='{"spec":{"nodeName":"ip-10-0-5-100"}}' -- \
  ip link show eth0
# Expected: mtu 9001 (Jumbo Frames for VPC)
# If 1500: MTU was reset → fragmentation on large packets → retransmissions

# Step 4: Fix MTU if needed (on the EC2 node via SSM Session Manager)
aws ssm start-session \
  --target $(kubectl get node ip-10-0-5-100 -o jsonpath='{.spec.providerID}' | cut -d/ -f5) \
  --region ap-northeast-1
# Then inside the session:
# ip link set eth0 mtu 9001
# echo 9001 > /sys/class/net/eth0/mtu
# (permanent fix: update the launch template UserData)

# Step 5: Verify retransmission drops after fix
# Wait 5 minutes, then re-check the Dynatrace dashboard tile
```

### When Signal B fires (DNS failure):

```bash
# Immediate: check CoreDNS pods
kubectl get pods -n kube-system -l k8s-app=kube-dns -o wide
# Note which nodes CoreDNS is on

# Is CoreDNS OOMKilled?
kubectl describe pods -n kube-system -l k8s-app=kube-dns \
  | grep -E "OOMKilled|Reason|Exit Code|Last State"

# CoreDNS error rate in real-time
kubectl exec -n kube-system \
  $(kubectl get pod -n kube-system -l k8s-app=kube-dns \
    -o jsonpath='{.items[0].metadata.name}') \
  -- wget -q -O- localhost:9153/metrics \
  | grep "coredns_dns_responses_total{.*SERVFAIL"

# Fastest fix: add a third CoreDNS replica to distribute load
kubectl patch deployment coredns -n kube-system \
  --patch '{"spec":{"replicas":3}}'

# Verify DNS working again from affected pod
kubectl exec -n payment-ns \
  $(kubectl get pod -n payment-ns -l app=payment-service \
    -o jsonpath='{.items[0].metadata.name}') \
  -- nslookup order-service.order-ns.svc.cluster.local
# Expected: resolves to a ClusterIP in < 5ms
```

### When Signal C fires (connection saturation):

```bash
# Identify which pods are over the threshold (from DT alert)
# Then check connection state breakdown
PODS=$(kubectl get pods -n notification-ns -l app=notification-service \
  -o jsonpath='{.items[*].metadata.name}')
for POD in $PODS; do
  echo "=== $POD ==="
  kubectl exec -n notification-ns $POD -- ss -tan 2>/dev/null \
    | awk '{print $1}' | sort | uniq -c | sort -rn
done
# If ESTAB count is very high: connection pool leak → restart pods and fix pool config
# If TIME-WAIT count is very high: connections closing fast without keep-alive
# Fix: add Connection: keep-alive to HTTP client configuration

# Check SQS connection specifically (notification-service connects to SQS)
kubectl exec -n notification-ns $PODS_FIRST -- ss -tan \
  | grep ":443" | wc -l
# SQS endpoint uses HTTPS port 443
# If count > 100: notification-service is opening new SQS connections per message
# Fix: configure a shared SQSClient with connection pooling in the application
```

### When Signal F fires (NetworkPolicy drop) — zero tolerance:

```bash
# Which namespace/pod is generating drops? (from DT Problem entity)
# Get the affected node
AFFECTED_NODE="ip-10-0-5-100"  # from DT Problem

# Recent NetworkPolicy changes (check gitops history)
git log --oneline --since="2 hours ago" \
  -- gitops/production/app/*/

# List all NetworkPolicies
kubectl get networkpolicy -A
kubectl describe networkpolicy -n <affected-namespace>

# Test if the block is on the expected path
# From payment-service pod → order-service:
kubectl run netdebug --image=nicolaka/netshoot --rm -it \
  -n payment-ns --restart=Never -- \
  nc -zv order-service.order-ns.svc.cluster.local 80
# If "Connection refused" → reached service, port wrong
# If timeout → NetworkPolicy is blocking

# Emergency: remove the suspected policy temporarily
kubectl delete networkpolicy <policy-name> -n <namespace>
# If drops stop: confirmed misconfigured policy
# Recreate with correct rules
```

---

## Quick Verification Checklist

```bash
# ONE-LINER health check for all network monitoring components
echo "=== Kubernetes ===" && \
kubectl get pods -n kube-system -l k8s-app=kube-dns --no-headers && \
echo "=== NAT Errors ===" && \
aws cloudwatch get-metric-statistics \
  --namespace AWS/NATGateway \
  --metric-name PortAllocationErrorCount \
  --dimensions Name=NatGatewayId,Value=$(aws ec2 describe-nat-gateways \
    --filter "Name=state,Values=available" \
    --filter "Name=tag:environment,Values=production" \
    --query 'NatGateways[0].NatGatewayId' --output text --region ap-northeast-1) \
  --start-time $(date -u -v-1H +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 3600 --statistics Sum --region ap-northeast-1 \
  | jq '.Datapoints[0].Sum // 0 | {"snat_errors": .}' && \
echo "=== DT Retransmission ===" && \
curl -s -G "${DT_URL}/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  --data-urlencode "metricSelector=builtin:host.net.retransmission:max" \
  --data-urlencode "from=now-10m" \
  | jq '(.resolution.results[0].values | max // 0) | {"max_retransmission_pct": .}'

# Expected output:
# === Kubernetes ===
# coredns-abc  2/2  Running  0  3d
# === NAT Errors ===
# { "snat_errors": 0 }
# === DT Retransmission ===
# { "max_retransmission_pct": 0.09 }
```
