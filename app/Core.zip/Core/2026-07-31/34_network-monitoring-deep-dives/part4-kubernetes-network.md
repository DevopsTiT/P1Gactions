# Part 4 — Kubernetes-Native Network Monitoring Deep Dive

> Two signals that watch Kubernetes-internal networking: CoreDNS (the cluster's DNS server) and NetworkPolicy packet drops. Both catch failure modes invisible to application-layer monitoring.

---

## Why Kubernetes Needs Its Own Network Monitoring Layer

The signals in Part 2 (TCP retransmission, connection count) are OS-level — they see network problems at the kernel/NIC level. But Kubernetes has additional networking components that live ABOVE the OS but BELOW the application:

```
Application code (Java, HTTP calls)
        ↑  JVMTI instruments here (Parts 1 & 2)
Kubernetes Service (ClusterIP)
        ↑  kube-proxy iptables rules route here
CoreDNS (cluster DNS)
        ↑  UDP/TCP queries happen here
VPC CNI (pod IP assignment)
        ↑  NetworkPolicy enforced here
Linux kernel networking (/proc/net)
        ↑  OneAgent reads here (Part 1)
```

CoreDNS failure and NetworkPolicy drops happen in the middle layers — below JVMTI (so application monitoring misses them) but above the OS (so `builtin:host.net.*` metrics don't directly expose them).

---

## Signal E: CoreDNS Error Rate

### The CoreDNS Architecture:

```
Every pod → /etc/resolv.conf → nameserver 172.20.0.10
                                                ↓
                                         kube-dns Service (ClusterIP: 172.20.0.10)
                                                ↓
                                         CoreDNS Deployment (2 pods)
                                           pod 1: node-a  (leader)
                                           pod 2: node-b  (follower, standby)
                                                ↓
                                         Upstream resolvers:
                                           - AWS VPC DNS: 169.254.169.253
                                           - Route53 Resolver Inbound endpoint
```

If CoreDNS pod 1 crashes:
```
Pod requests → kube-dns Service → routes to pod 2 only
→ pod 2 gets 100% of DNS traffic → may overload
→ DNS response time increases → app connection timeouts
→ Still not an error at the OS level (connection is attempted, just slow)
→ JVMTI sees "DNS failure" but can't distinguish CoreDNS from upstream DNS
```

If CoreDNS pod 2 also goes down (OOMKilled by a query storm):
```
All DNS queries → kube-dns Service → no healthy backends
→ DNS queries return SERVFAIL immediately
→ JVMTI sees 100% DNS failure rate on all services simultaneously
→ Every service-to-service call fails with UnknownHostException
→ Cluster-wide outage in ~30 seconds
```

### CoreDNS Prometheus Metrics (scraped by ActiveGate):

CoreDNS exposes metrics at `/metrics` (port 9153). ActiveGate scrapes this with `kubernetes-api-monitoring` capability:

```
coredns_dns_requests_total{server, zone, proto, family}     ← total queries
coredns_dns_responses_total{server, zone, rcode}            ← responses by return code
coredns_dns_request_duration_seconds{server, zone}          ← query latency histogram
coredns_cache_hits_total{server, type}                      ← cache hit rate
coredns_cache_misses_total{server, type}                    ← cache miss rate
coredns_forward_requests_total{to}                          ← upstream queries
coredns_forward_responses_total{to, rcode}                  ← upstream responses by code
```

In Dynatrace, these appear as `ext:kubernetes.coredns.*` metric keys.

### The DNS response codes (rcode) that matter:

| rcode | Meaning | Cause |
|-------|---------|-------|
| `NOERROR` | Successful resolution | Normal |
| `NXDOMAIN` | Name doesn't exist | Service deleted, typo, ndots:5 noise |
| `SERVFAIL` | CoreDNS internal error | Upstream unreachable, CoreDNS crash |
| `REFUSED` | CoreDNS refused the query | ACL block, wrong zone |

### Full HCL explained:

```hcl
resource "dynatrace_metric_events" "coredns_errors" {
  enabled = true
  # No `for_each = var.services` here.
  # WHY: CoreDNS failure affects ALL services simultaneously.
  # One alert for the cluster, not one alert per service.
  # Creating one alert per service would generate 3× the noise
  # (3 alerts firing at once for the same root cause).

  event_entity_dimension_key = "dt.entity.cloud_application"
  # Attached to the CoreDNS Deployment entity in Kubernetes.
  # Davis AI sees this as a Kubernetes workload problem → correlates
  # with "all services have DNS failures" → one Problem opened.

  event_type = "ERROR_EVENT"
  # ERROR severity → HIGH alerting profile → PagerDuty in production.
  # CoreDNS errors are a production emergency — they break ALL
  # service-to-service communication cluster-wide.
  # Unlike Signal A (TCP retransmission = WARNING), CoreDNS errors
  # require immediate response.

  model_properties {
    threshold         = 10
    # 10 SERVFAIL responses per minute.
    # Why not 0? CoreDNS may occasionally return SERVFAIL for:
    #   - External DNS lookups during Route53 TTL expiry
    #   - Upstream resolver brief blips (AWS DNS at 169.254.169.253)
    # 10/min = real problem (1 NXDOMAIN every 6 seconds is sustained failure)
    # vs. 1–3/min = normal background noise from ndots queries.

    violating_samples  = 2
    # 2 minutes of >10 SERVFAIL/min before alerting.
    # CoreDNS crashes are detected in 2 minutes — fast enough to
    # prevent widespread cascading failures while filtering transient noise.
  }

  query_definition {
    metric_key = "ext:kubernetes.coredns.dns_responses_total"
    resolution = "1m"

    entity_filter {
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = "SERVFAIL" key = "rcode"
        # Filter to ONLY count SERVFAIL responses.
        # NXDOMAIN is excluded (normal ndots:5 noise).
        # REFUSED is excluded (different issue, separate alert if needed).
      }
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = var.environment key = "environment"
      }
    }
  }
}
```

### How to investigate CoreDNS problems:

```bash
# 1. CoreDNS pod status
kubectl get pods -n kube-system -l k8s-app=kube-dns
# If any pod is Pending/CrashLoopBackOff: that's your root cause

# 2. CoreDNS memory/CPU usage
kubectl top pod -n kube-system -l k8s-app=kube-dns
# High memory (>80% of limit) → near OOMKill
# Fix: increase memory limit in the coredns ConfigMap:
kubectl get deployment -n kube-system coredns -o yaml | grep -A 5 "resources"
# Patch:
kubectl patch deployment coredns -n kube-system \
  --patch '{"spec":{"template":{"spec":{"containers":[{"name":"coredns","resources":{"limits":{"memory":"512Mi"},"requests":{"memory":"256Mi"}}}]}}}}'

# 3. CoreDNS query rate
kubectl exec -n kube-system \
  $(kubectl get pod -n kube-system -l k8s-app=kube-dns \
    -o jsonpath='{.items[0].metadata.name}') \
  -- curl -s localhost:9153/metrics | grep "coredns_dns_requests_total"
# If rate is very high → investigate which pods are generating excessive DNS queries
# (ndots:5 + many external calls = query amplification)

# 4. Test DNS from the application pod
kubectl exec -n payment-ns \
  $(kubectl get pod -n payment-ns -l app=payment-service \
    -o jsonpath='{.items[0].metadata.name}') \
  -- nslookup order-service.order-ns.svc.cluster.local
# If SERVFAIL or timeout: CoreDNS problem confirmed

# 5. Fix ndots:5 query amplification in deployment spec
# charts/payment-service/templates/deployment.yaml → add:
# spec:
#   template:
#     spec:
#       dnsConfig:
#         options:
#           - name: ndots
#             value: "2"    ← reduces search domain attempts from 5 to 2
```

---

## Signal F: Network Policy Packet Drops

### Why NetworkPolicy drops are silent in application logs:

```
Normal TCP connection failure (e.g., wrong port):
  App sends SYN → Server replies RST → App gets "Connection refused"
  App log: "Connection refused: connect to 10.0.5.23:5432 failed"
  → Error is visible in application logs immediately

NetworkPolicy DROP (traffic silently discarded):
  App sends SYN → NetworkPolicy drops the packet → No response
  App waits for TCP timeout (~30 seconds by default in Java)
  App log: "Timeout after 30000ms connecting to 10.0.5.23:5432"
  → Application sees a TIMEOUT, not a "connection refused"
  → Root cause is invisible — looks like the server is slow or hung
```

This is why NetworkPolicy problems are so hard to diagnose without dedicated monitoring. The application reports "timeout" for what is actually "packet dropped by policy."

### How VPC CNI exposes drop metrics:

EKS uses VPC CNI with optional network policy enforcement. When enabled, the CNI tracks dropped packets per policy:

```
# From the VPC CNI plugin pod on each node
kubectl exec -n kube-system \
  $(kubectl get pod -n kube-system -l app=aws-node \
    -o jsonpath='{.items[0].metadata.name}') \
  -- cat /proc/net/ip_tables_matches | grep DROP

# In Dynatrace (via ActiveGate Kubernetes monitoring):
ext:kubernetes.network.policy.droppedPackets
  dimensions: {namespace, policy_name, direction}
```

### Full HCL explained:

```hcl
resource "dynatrace_metric_events" "netpol_drops" {
  enabled = true

  event_entity_dimension_key = "dt.entity.host"
  # Host entity — drops are enforced at the node level by the CNI.
  # Each node enforces its own policy rules independently.

  event_type = "ERROR_EVENT"
  # ERROR (not RESOURCE_CONTENTION) because even one dropped packet
  # from a NetworkPolicy is a configuration problem, not resource pressure.

  model_properties {
    threshold         = 0
    # Alert on ANY non-zero drops.
    # WHY threshold = 0:
    #   In a correctly configured cluster with reviewed NetworkPolicy,
    #   there should be ZERO legitimate drops. Every dropped packet is:
    #   a) A misconfigured policy blocking legitimate traffic (production bug)
    #   b) An attacker probing blocked paths (security event)
    #   Both require immediate investigation.

    violating_samples  = 1
    # Fire on FIRST occurrence. No waiting.
    # WHY: a NetworkPolicy that blocks DB access will drop packets
    # from the first connection attempt. Waiting 2+ minutes before
    # alerting means services are timing out for 2 minutes unnecessarily.
    # One data point showing drops = confirmed misconfiguration.

    dealerting_samples = 3
    # Require 3 clean minutes before resolving.
    # A NetworkPolicy fix (delete the blocking rule) takes effect
    # immediately, but we want confirmation that drops truly stopped.

    samples = 2
    # Evaluate last 2 data points.
    # With violating_samples=1 and samples=2: fires if the MOST RECENT
    # data point has any drops. Immediate detection.
  }

  query_definition {
    metric_key = "ext:kubernetes.network.policy.droppedPackets"
    resolution = "1m"

    entity_filter {
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = var.environment key = "environment"
        # All nodes in this environment.
      }
    }
  }
}
```

### How to investigate NetworkPolicy drops:

```bash
# 1. Which namespace/policy is dropping packets?
# From the DT alert, click "Affected entities" to get the node name

# 2. List all NetworkPolicies in application namespaces
kubectl get networkpolicy -n payment-ns
kubectl get networkpolicy -n order-ns
kubectl get networkpolicy -n notification-ns

# 3. If NetworkPolicies exist — describe them to find blocking rules
kubectl describe networkpolicy <policy-name> -n payment-ns
# Look for: Egress or Ingress rules that might block the traffic path

# 4. Test connectivity directly between pods
kubectl run netdebug --image=nicolaka/netshoot --rm -it --restart=Never \
  -n payment-ns -- \
  nc -zv order-service.order-ns.svc.cluster.local 80
# If timeout: NetworkPolicy blocking the connection
# If "Connection refused": port wrong but network works
# If "Connected": network is fine, problem is elsewhere

# 5. Check recent NetworkPolicy changes (if git history available)
git log --oneline -- gitops/production/app/payment-service/
# Was a NetworkPolicy YAML recently added or changed?

# 6. Quick fix: label-based NetworkPolicy debug
# Allow all traffic from payment-ns to order-ns temporarily:
kubectl apply -f - <<EOF
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: debug-allow-all
  namespace: order-ns
spec:
  podSelector: {}
  ingress:
    - from:
        - namespaceSelector:
            matchLabels:
              kubernetes.io/metadata.name: payment-ns
  policyTypes:
    - Ingress
EOF
# If drops stop → the existing NetworkPolicy was too restrictive
# Delete the debug policy after fixing the real one
```

### The Security Angle of Signal F:

```
Scenario: attacker has compromised a dev pod and is probing the cluster

14:45: DT alert: "Network policy: packets dropped (possible misconfiguration)"
       ext:kubernetes.network.policy.droppedPackets = 47 drops/min
       Source: notification-ns pods
       Destination: payment-ns pods AND kube-system pods

Investigation:
  notification-service is ASYNC (SQS-based) — it should NEVER connect to payment-ns
  These drops are from unauthorized lateral movement probing
  
  kubectl get pods -n notification-ns -o wide
  → notification-service-hacked-xxxxx: running but NOT matching any expected image tag
  
  Action: isolate the pod, rotate all secrets, incident response
```

This is why `threshold = 0` matters. Zero legitimate drops = any non-zero is suspicious.

---

## Combining Signals E and F: The Full DNS + Policy Picture

```
Scenario: developer adds a NetworkPolicy to order-ns that accidentally
          blocks DNS traffic (UDP port 53 to CoreDNS)

t=0:00  NetworkPolicy applied
        → UDP port 53 from order-ns blocked by new policy
        → Signal F: "Network policy: packets dropped" fires IMMEDIATELY

t=0:01  order-service pods can no longer resolve DNS names
        → DNS failure rate rises (Signal B)
        → Davis AI correlates: drops in order-ns → DNS failures in order-service

t=0:30  order-service → payment-service calls start failing
        → "UnknownHostException: payment-service.payment-ns.svc.cluster.local"
        → order-service error rate rises (existing Signal 2)

t=1:00  Payment attempts that require order validation fail
        → payment-service error rate rises
        → payment-service P99 rises (waiting for order-service to time out)

Davis AI opens ONE Problem:
  Root cause: Network policy packet drops in order-ns
  → DNS resolution failure for order-service
  → order-service → payment-service calls failing
  → payment-service degraded

Without Signal F: took 15 minutes to diagnose (started at application error, worked backwards)
With Signal F: Davis names the root cause at t=0:01 (1 minute after policy applied)
```
