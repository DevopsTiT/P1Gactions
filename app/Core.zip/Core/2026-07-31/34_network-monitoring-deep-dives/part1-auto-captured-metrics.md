# Part 1 — What Dynatrace Captures Automatically (Zero Config)

> OneAgent is already running as a DaemonSet in this project. It collects network data without any configuration changes. This part explains every automatic metric, where it comes from in the OS, and how to use it to start an investigation.

---

## The Core Principle: OneAgent Reads the OS

OneAgent doesn't insert probes into the network hardware. It reads Linux kernel data structures that the operating system already maintains for every running process and network interface.

```
Linux kernel
  ├── /proc/net/dev           ← per-interface: bytes in/out, errors, drops
  ├── /proc/net/snmp          ← TCP global counters: retransmits, errors
  ├── /proc/net/tcp           ← all active TCP connections
  ├── /proc/net/udp           ← all UDP sockets (DNS uses UDP)
  └── /proc/<pid>/net/        ← per-process network stats (same files, process namespace)

OneAgent reads these every 60 seconds, computes rates and percentages,
and sends the results to ActiveGate → Dynatrace tenant.

Zero traffic on the network itself. Zero overhead on the application.
```

---

## 1.1 Host-Level Network Metrics (per EKS Node)

These metrics apply to an entire EC2 worker node — all pods on that node share them.

### `builtin:host.net.throughput.rx` — bytes received per second

```
Source:  /proc/net/dev → "rx_bytes" column → rate per second
Unit:    bytes/sec
Scope:   per network interface (eth0, ens5, etc.), per host entity
```

**What "bytes received" means for an EKS node:**

```
Everything arriving at the node's NIC:
  - HTTP requests from ALB (internet users → payment-service pod)
  - DB responses from RDS (RDS → payment-service pod)
  - K8s control messages (API server → kubelet → pods)
  - Image pulls from ECR (via S3 VPC endpoint, so no NAT)
  - Cross-pod traffic arriving from other nodes
```

**SRE use case:** If a node is receiving 4.8Gbps (close to t3.medium's 5Gbps limit), ALL pods on that node are about to experience packet queuing and retransmissions — even if the pods themselves are healthy.

```bash
# Check throughput for all nodes right now
kubectl get nodes -o wide
# Get node IP, then cross-reference with Dynatrace host entity

# In Dynatrace UI: Infrastructure → Hosts → select node → Network tab
# Shows: rx/tx throughput timeline, current rate, per-interface breakdown
```

---

### `builtin:host.net.throughput.tx` — bytes sent per second

```
Source:  /proc/net/dev → "tx_bytes" column → rate per second
Unit:    bytes/sec
```

**What "bytes sent" means:**

```
Everything leaving the node's NIC:
  - HTTP responses back to users (via ALB)
  - Queries to RDS, SQS, Secrets Manager
  - Logs to CloudWatch
  - Outbound cross-AZ traffic (most expensive if payment-service pods
    are in AZ-a but DB read replica is in AZ-b)
```

**Why TX matters more than RX for cost monitoring:**
AWS cross-AZ data transfer is charged on the SENDING side. A node in AZ-a sending 100MB/s to resources in AZ-b costs $0.01/GB × 360GB/hour = $3.60/hour. TX is the billing signal.

Signal D in the project (`builtin:host.net.throughput.tx` > 100MB/s) alerts on this. But even below the alert threshold, the dashboard shows this metric for cost awareness.

---

### `builtin:host.net.errorRate` — percentage of packets with errors

```
Source:  /proc/net/dev → (rx_errors + tx_errors) / (rx_packets + tx_packets)
Unit:    percentage (0–100)
Already alerted: Signal 8 in the project → > 0.5% in production
```

**What "error" means at the NIC level:**

| Error type | Meaning | Common cause |
|-----------|---------|-------------|
| `rx_errors` | Packet received with CRC error (corrupted) | Bad cable, NIC hardware issue |
| `tx_errors` | Packet failed to send | NIC queue full, driver error |
| `rx_dropped` | Packet received but dropped (no buffer) | NIC ring buffer overflow, CPU too busy |
| `tx_dropped` | Packet queued for send but dropped | Kernel TX queue full |

**In cloud VMs:** Hardware-level errors are rare (AWS manages the physical NICs). You mostly see `rx_dropped` when the VM can't process packets fast enough (CPU saturation, kernel networking overhead).

**When to escalate to AWS:** If error rate rises and CPU is fine → potential hypervisor issue → open AWS support ticket with the node's instance ID and timestamp.

---

### `builtin:host.net.packetLoss` — percentage of packets lost

```
Source:  Computed from /proc/net/snmp TCP retransmit counters
Unit:    percentage (0–100)
```

**Packet loss vs. error rate:**
- `errorRate` = packets that arrived but were corrupted or couldn't be processed
- `packetLoss` = packets that were sent but never arrived (no acknowledgement)

Packet loss is invisible to the sender at the NIC level — the packet leaves the NIC fine, it's lost somewhere in the network path. TCP detects it via retransmit timeout.

**In the EKS VPC context:**
- Within the same AZ: packet loss should be 0.00% (AWS VPC fabric is extremely reliable)
- Across AZ: also 0.00% under normal conditions
- To the internet via NAT: possible if NAT port tables are stressed

Non-zero `packetLoss` inside a VPC almost always means:
1. Security group silently dropping packets (not rejecting, just not responding)
2. Network policy dropping packets
3. NAT Gateway SNAT port exhaustion (connections silently dropped)

---

### `builtin:host.net.retransmission` — TCP retransmit rate

```
Source:  /proc/net/snmp → RetransSegs / TotalSegments × 100
Unit:    percentage (0–100)
Collected:  per host, 1-minute resolution
```

**The TCP retransmission mechanism explained:**

```
Normal TCP flow:
  Sender:   SEND segment 100
  Receiver: ACK 101 (received segment 100, next expected is 101)
  → Fast, no retransmit

Retransmit scenario:
  Sender:   SEND segment 100
  [packet dropped somewhere in network]
  Receiver: ← nothing arrives
  Sender:   [retransmit timer fires after ~200ms–3s]
  Sender:   SEND segment 100 again
  Receiver: ACK 101

What happened during retransmit timer:
  - TCP's congestion window halved (CWND reduction)
  - Throughput of THIS connection dropped 50%
  - If it happens again: halved again → throughput collapses
```

**Retransmit rate thresholds:**

| Rate | Meaning | Action |
|------|---------|--------|
| 0.0–0.1% | Normal healthy VPC | No action |
| 0.1–1.0% | Minor congestion | Monitor, check for root cause |
| 1–2% | Moderate congestion | Alert (WARNING), investigate node |
| 2–5% | Significant degradation | Alert (RESOURCE_CONTENTION) + page |
| >5% | Severe → throughput may collapse | CRITICAL, escalate immediately |

**Why the project alerts at 2%:** The existing Signal 8 (`errorRate`) already catches hardware errors. TCP retransmission at 2% represents a SOFTWARE/NETWORK path problem: MTU mismatch, NIC queue overflow, or routing issue. This is the first signal of impending latency spikes before users notice.

---

## 1.2 Process-Level Network Metrics (per JVM)

These metrics are scoped to a single JVM process — not the whole node. Collected by OneAgent reading per-process networking data.

### `builtin:process.network.bytesReceived`

```
Source:  OneAgent reads /proc/<pid>/net/dev for the process's network namespace
Unit:    bytes/sec
Scope:   per process group instance (i.e., per service pod)
```

**What this tells you about payment-service:**
```
payment-service receives:
  - HTTP requests from ALB: ~1KB per payment POST
  - DB query results from RDS: ~50KB per payment (fetching account data)
  - Secrets Manager responses: ~512 bytes (token refresh every hour)

At 100 req/s:
  ALB inbound:  ~100KB/s (small)
  DB responses: ~5MB/s  (larger — this is what fills the number)
  Total RX:     ~5.1MB/s = normal for a payments service at 100 RPS
```

**Abnormal pattern:**
If `bytesReceived` suddenly drops to 0 while the service is still running → network path from DB to the pod is cut. This looks different from the service crashing (which shows 0 TCP connections AND 0 bytes).

---

### `builtin:process.network.bytesSent`

```
Unit:    bytes/sec
Scope:   per process group instance
```

**What payment-service sends:**
```
HTTP responses to ALB: ~2KB per payment response
DB queries to RDS: ~500B per query (small SQL text)
External API calls (fraud check, etc.): ~1KB per request

Normal TX rate: ~500KB/s at 100 RPS
```

**Abnormal patterns:**
- TX suddenly very high → service sending unusually large responses or doing data dumps
- TX drops to 0 while RX is still non-zero → service is receiving data but not sending anything back (deadlock, blocking call, full GC pause?)

---

### `builtin:process.network.connections` — active TCP connections

```
Source:  OneAgent reads /proc/<pid>/net/tcp and /proc/<pid>/net/tcp6
Unit:    count (integer)
```

**Connection count breakdown for payment-service:**

```
Normal connections for one pod:
  → RDS PostgreSQL:              2–10 (connection pool)
  → order-service:               5–20 (HTTP client pool)
  → Secrets Manager (HTTPS):     1–2  (long-lived)
  → ActiveGate (telemetry):      1    (always open)
  → Kubernetes API (kubelet):    1    (always open)
  ─────────────────────────────────
  Total:                         ~12–34 per pod

Normal for production (3 pods):
  ~36–102 total connections shown in process.network.connections
```

**What 800+ connections means:**
- connection pool configured too large (e.g., maxPoolSize=200 × 3 pods = 600 to RDS alone)
- HTTP client not using keep-alive → new connection per request → connection count grows
- Threads waiting for connections → many CLOSE_WAIT/TIME_WAIT connections still counted
- Connection pool leak (connections never returned to pool)

**SNAT consequence:** If payment-service has 800 connections and there are 10 pods on the same node → 8,000 connections → NAT Gateway tracks all 8,000. Other pods on that node share the remaining 64,512 - 8,000 = 56,512 SNAT ports. New connections may start failing silently.

---

## 1.3 Service-Level Connection Metrics (from JVMTI Instrumentation)

These come from the same JVMTI hook that captures HTTP latency — OneAgent sees every method call the JVM makes.

### `builtin:service.dbcalls.count` — DB calls per minute

```
Source:  JVMTI intercepts JDBC method calls
Unit:    calls/minute per service
```

**What it shows:**

```
Normal for payment-service at 100 RPS:
  - Each payment: 1 SELECT + 1 UPDATE + 1 INSERT = 3 DB calls
  - 100 RPS × 3 calls = 300 DB calls/min

If suddenly: 3,000 DB calls/min (10×) → N+1 query problem
  (each item in a list triggers a separate DB query instead of one batched query)
```

---

### `builtin:service.dbcalls.successRate` — DB call success rate

```
Source:  JVMTI: exception/success outcome of each JDBC call
Unit:    percentage (0–100)
```

**Why this is a NETWORK signal, not just an application signal:**

```
DB call failure path:
  JDBC call → TCP connection attempt to RDS
  → If TCP times out (network failure): JDBC throws "Connection timed out"
  → successRate drops
  → Looks like application bug but is network issue

  vs.

  JDBC call → TCP succeeds → SQL executes → SQL syntax error
  → JDBC throws "SQLSyntaxError"
  → successRate drops  
  → True application bug (not network)
```

How to distinguish: If `dbcalls.successRate` drops AND `tcp_retransmission` rises simultaneously → network issue. If `dbcalls.successRate` drops AND TCP is fine → application/SQL issue.

---

### `builtin:service.requestCount.client` — outbound HTTP calls

```
Source:  JVMTI intercepts Java HTTP client calls (RestTemplate, WebClient, OkHttp, etc.)
Unit:    calls/min
```

Shows: payment-service is calling order-service 80 times/min, calling fraud-check API 100 times/min.

**SRE use case:** Alert fires on order-service. You check `requestCount.client` for payment-service — it shows 0 calls to order-service in the last 5 minutes. Is order-service actually broken, or did payment-service stop calling it? Two different root causes, two different fixes.

---

### `builtin:service.failureRate.client` — outbound HTTP call failure rate

```
Source:  JVMTI: HTTP status code and exception outcome of each client call
Unit:    percentage
```

**This is the cross-service network probe:**

```
payment-service → order-service:
  failureRate.client = 0%:   healthy connection
  failureRate.client = 100%: all calls to order-service failing
                             → order-service is down, OR
                             → network between payment-ns and order-ns is broken
```

Combined with order-service's own error rate:
- order-service error rate = 0% AND payment→order failureRate.client = 100% → network between namespaces broken (NetworkPolicy misconfiguration)
- order-service error rate = 100% → order-service itself is the problem

---

## Summary: What Zero-Config Metrics Already Show You

```
WHEN: alert fires on payment-service P99 spike

Step 1: Check builtin:host.net.retransmission
  Elevated? → TCP packet loss between pods and DB/order-service
  Normal?   → Go to step 2

Step 2: Check builtin:process.network.connections
  Very high (>500 per pod)? → Connection pool leak or SNAT exhaustion
  Normal?                   → Go to step 3

Step 3: Check builtin:process.network.dnsFailureRate
  Non-zero? → CoreDNS issue, all service calls affected
  Zero?     → Go to step 4

Step 4: Check builtin:service.dbcalls.successRate
  Dropping? AND step 1 normal → DB is returning errors (SQL/schema issue)
  Dropping? AND step 1 elevated → network to DB (RDS subnet, security group)
  Fine?     → Go to application-level investigation (traces, JVM heap)
```

This decision tree uses ONLY zero-config metrics. The additional 7 signals from Parts 2–6 add precision and automation to this same process.
