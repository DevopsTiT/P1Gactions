# Part 8 — How Network Issues Surface in the Full Picture (Davis AI) Deep Dive

> This part explains how Davis AI correlates multiple network signals into one root-cause Problem, and builds the full mental model of how a network failure cascades through application metrics, traces, and logs — all linked in Dynatrace.

---

## The Cascade Model: How Network Failures Become Application Alerts

Network problems almost never fire a single alert. They cascade through layers, generating multiple signals that look unrelated until you see the cause-effect chain.

```
PHYSICAL LAYER (EKS node NIC)
  → saturated → builtin:host.net.throughput.tx spikes
  ↓
TRANSPORT LAYER (TCP)
  → queue overflow → builtin:host.net.retransmission spikes
  ↓
DNS LAYER (CoreDNS using TCP/UDP through saturated node)
  → queries timeout → builtin:process.network.dnsFailureRate rises
  ↓
APPLICATION LAYER (Java HTTP client calls)
  → service calls fail with UnknownHostException
  → builtin:service.failureRate.client rises
  ↓
ERROR RATE LAYER
  → payment transactions fail → builtin:service.errors.server.rate rises
  ↓
LATENCY LAYER
  → surviving requests compete for fewer connections → P99 spikes
  → builtin:service.response.time:percentile(99) exceeds threshold
  ↓
AVAILABILITY LAYER
  → synthetic probe times out
  → HTTP synthetic fails
  → AVAILABILITY problem opens
  ↓
NOTIFICATION
  → PagerDuty pages on-call (CRITICAL: 0 min delay)
```

**Without network monitoring:** on-call sees the bottom of this cascade (PagerDuty: "service unavailable") and has to work backwards through every layer manually. 20–60 minutes.

**With all 8 network signals:** Davis AI sees the TOP of this cascade (NIC throughput spike) first and labels it the root cause. On-call opens the Problem, sees "root cause: NIC saturation → cascade" and takes targeted action in 3–5 minutes.

---

## Detailed Incident Walk-Through: NIC Saturation

### The Scenario

`t3.medium` node running: payment-service pod, notification-service pod (3 replicas each on one node due to scheduler failure to spread across AZs).

Notification-service has a bug: it opens a new SQS connection per message instead of reusing a persistent connection. Under load, it opens 2,000+ connections simultaneously → 90MB/s outbound from one node.

### Timeline in Dynatrace:

```
t=0:00  Node throughput rises to 90MB/s
        builtin:host.net.throughput.tx = 94,371,840 bytes/s
        Metric event "cross_az_traffic" threshold (100MB/s) NOT YET crossed.
        No alert. But visible on the network dashboard.

t=0:30  Throughput stabilizes at 95MB/s (95% of 100MB/s threshold).
        TCP queue on the node begins filling.
        builtin:host.net.retransmission rises to 1.8%
        (below 2% threshold — still no alert)

t=1:00  notification-service opens another wave of connections.
        Throughput: 105MB/s → THRESHOLD CROSSED
        → Signal D fires: RESOURCE_CONTENTION (WARNING)
        → No PagerDuty yet (WARNING → 5 min delay before Slack)

        TCP retransmission: 3.1% → THRESHOLD CROSSED (2%)
        → Signal A fires: RESOURCE_CONTENTION (WARNING)
        → Both signals now active, Davis starts correlation

t=1:30  CoreDNS pods on the same node cannot respond to DNS queries fast enough.
        DNS queries from payment-service pods time out.
        builtin:process.network.dnsFailureRate for payment-service: 0.8%
        → Signal B fires: ERROR_EVENT
        → ERROR → HIGH alerting profile → PagerDuty for staging/production

t=2:00  payment-service HTTP clients can't resolve order-service DNS.
        builtin:service.failureRate.client rises to 15%
        builtin:service.errors.server.rate rises to 0.4% (threshold: 0.1%)
        → Signal 2 (error rate) fires: ERROR_EVENT

t=2:30  builtin:service.response.time:percentile(99) rises to 1.2s (threshold: 300ms)
        → Signal 3 (latency P99) fires: PERFORMANCE_EVENT

t=3:00  Synthetic probe: Tokyo → payment.company.com → 504
        → AVAILABILITY problem opens (0 min delay → PagerDuty immediately)
```

### How Davis AI Builds the Problem:

```
Davis receives events in this order:
  t=1:00  RESOURCE_CONTENTION: host-node-a throughput spike
  t=1:00  RESOURCE_CONTENTION: host-node-a TCP retransmission spike
  t=1:30  ERROR: payment-service DNS failures
  t=2:00  ERROR: payment-service error rate spike
  t=2:30  PERFORMANCE: payment-service P99 spike
  t=3:00  AVAILABILITY: payment-service synthetic failed

Davis AI causal analysis:
  1. Checks if throughput spike and retransmission spike share an entity → YES (node-a)
  2. Checks if DNS failure started AFTER throughput spike → YES (30 seconds later)
  3. Checks if payment-service pods are ON node-a → YES (3 pods)
  4. Checks if payment-service error rate started AFTER DNS failure → YES
  5. Checks if P99 spike followed error rate → YES
  6. Checks if synthetic failure followed P99 spike → YES

Davis opens ONE Problem:
  Title: "Payment-service performance degradation and unavailability"
  Root cause: "Host throughput saturation on node-a causing TCP retransmissions
              leading to DNS failures affecting payment-service"
  Impact: 1 service, 3 pods, estimated 100% of payment-service users affected
  Duration: 3 minutes (and counting)
  Related events: [throughput, retransmission, DNS, errors, latency, availability]
```

**On-call response:**
```
Alice opens the Problem in Dynatrace.
Sees: "Root cause: Host throughput saturation on node-a"
Looks at: which pods are on node-a?

kubectl get pods -A -o wide | grep node-a
  notification-service-abc-def   notification-ns   node-a
  notification-service-ghi-jkl   notification-ns   node-a
  notification-service-mno-pqr   notification-ns   node-a
  payment-service-stu-vwx         payment-ns        node-a

Why are ALL notification-service pods on ONE node?
kubectl get pods -n notification-ns -o wide | grep -v node-a
  (none)
  
→ topologySpreadConstraints failed (nodeSelector typo in last deploy)

Immediate fix:
kubectl cordon node-a
kubectl delete pod notification-service-abc-def -n notification-ns
kubectl delete pod notification-service-ghi-jkl -n notification-ns
kubectl delete pod notification-service-mno-pqr -n notification-ns
# Pods reschedule to other nodes, throughput on node-a drops,
# payment-service DNS failures stop, error rate recovers.

Total MTTR: 7 minutes.
```

---

## Signal Correlation Summary Table

```
Signal fires → What it means for THIS service → What else to check

Signal D (throughput > threshold)
  → Node sending lots of data
  → Check: which pods are on that node? (kubectl get pods -o wide | grep <node>)
  → Check: is notification-service on same node? (async service = high SQS traffic)
  → Check: topology spread — are pods where they should be?
  → If cross-AZ: cost alert. If NIC saturation: performance alert.

Signal A (TCP retransmit > threshold)
  → Packet loss / congestion on that node
  → Check: is node approaching NIC limit? (throughput tile)
  → Check: was there a recent node replacement? (MTU might have changed)
  → Check: kubectl describe node <name> → network interface details
  → Check: /proc/net/snmp → RetransSegs growing

Signal B (DNS failure > threshold)
  → CoreDNS can't resolve names for this service
  → Check: are CoreDNS pods alive? (kubectl get pods -n kube-system -l k8s-app=kube-dns)
  → Check: is retransmission also elevated? (DNS packets dropping too)
  → Check: any recent CoreDNS ConfigMap changes?
  → Check: ndots setting in pod spec

Signal C (connection count > threshold)
  → Service has too many open connections
  → Check: TCP state breakdown (kubectl exec -- ss -tan | awk '{print $1}' | sort | uniq -c)
  → Check: HikariCP pool size in application config
  → Check: is notification-service making per-message SQS connections?
  → Check: CloudWatch NATGateway.PortAllocationErrorCount

Signal E (CoreDNS SERVFAIL)
  → CoreDNS itself is failing
  → Check: ALL services will be affected (not just this one)
  → Fix: kubectl scale deployment coredns -n kube-system --replicas=4 (temporary)
  → Fix: increase CoreDNS memory limits

Signal F (NetworkPolicy drops)
  → A NetworkPolicy is blocking legitimate traffic
  → Check: was a NetworkPolicy added recently? (git log gitops/*/networking/)
  → Check: which pod→destination is being blocked? (DT event dimensions)
  → Check: is the block intentional or misconfigured?

VPC Flow REJECT
  → Security group blocking traffic at VPC level
  → Check: which source IP → destination IP → port is blocked?
  → Check: AWS console → Security Groups → recent inbound/outbound rule changes
  → Check: CloudTrail for recent AuthorizeSecurityGroupIngress/Revoke events

ALB no_target
  → ALB can't connect to a specific pod
  → Check: which pod IP is unreachable? (ALB access logs → target_ip)
  → Check: pod status (kubectl get pod -A -o wide | grep <pod-ip>)
  → Check: security group between ALB and pods
  → Check: pod network namespace (is there a VPC CNI issue?)
```

---

## The 4-Minute Fix: What the Dashboard Shows During This Incident

At `t=3:00` when the PagerDuty fires, Alice opens the network dashboard:

```
┌──────────────────────────────┬──────────────────────────────┐
│ TCP Retransmission           │ DNS Failure Rate              │
│                              │                               │
│  node-a  ────────4%───────   │  payment-svc ──────0.8%────  │
│  node-b  ··········0.1%···   │  order-svc   ··········0%··  │
│  node-c  ··········0.1%···   │  notif-svc   ··········0%··  │
├──────────────────────────────┼──────────────────────────────┤
│ Active TCP Connections       │ Node Outbound Throughput      │
│                              │                               │
│  notif-svc  ────6,200────    │  node-a  ─────105 MB/s─────  │
│  payment-svc ──240──────     │  node-b  ·········40 MB/s··  │
│  order-svc   ──180──────     │  node-c  ·········42 MB/s··  │
└──────────────────────────────┴──────────────────────────────┘
```

In 10 seconds, Alice sees:
1. **node-a** has the throughput and retransmission problem (top-right and top-left tiles)
2. **notification-service** has 6,200 connections (bottom-left tile) — far more than the 240 of payment-service
3. **payment-service** has DNS failures (top-right tile) — because it's on the same node as CoreDNS
4. The root cause connection: notification-service's 6,200 connections → node-a 105MB/s → TCP retransmission on node-a → DNS failures for payment-service

The dashboard makes the root cause VISUALLY obvious in 10 seconds. No log grep. No multi-page investigation. Just pattern recognition on a 2×2 grid.

---

## What Davis Cannot Determine Without Network Signals

Without network signals, Davis has only application-layer data:

```
Davis receives (without network signals):
  t=1:30  ERROR: payment-service DNS failures      ← first signal visible
  t=2:00  ERROR: payment-service error rate spike
  t=2:30  PERFORMANCE: payment-service P99 spike
  t=3:00  AVAILABILITY: payment-service unavailable

Davis opens Problem:
  Title: "Payment-service performance degradation"
  Root cause: "payment-service has increasing error rate"
  (Davis can't explain WHY — it only sees the APPLICATION-LAYER symptoms)

On-call investigation path (wrong direction):
  1. Check payment-service traces → DB queries look fine → 5 min
  2. Check payment-service JVM heap → fine → 3 min
  3. Check payment-service logs → "UnknownHostException" for order-service → 5 min
  4. Verify order-service is running → it is → 3 min
  5. Check CoreDNS → running but slow → 5 min
  6. Why is CoreDNS slow? Check which node it's on → node-a → 3 min
  7. What's happening on node-a? Check manual metrics → NIC saturation → 5 min
  8. Why is node-a saturated? Check pods → notification-service all on same node → 5 min
  Total: 34 minutes, 8 investigation steps

With network signals:
  Davis shows: "root cause: node-a NIC saturation"
  On-call: checks pods on node-a → notification-service cluster → cordon + reschedule
  Total: 7 minutes, 2 investigation steps
```

The difference: 34 minutes vs. 7 minutes. With a 99.9% SLO and 43 minutes monthly error budget, the 34-minute investigation consumes 79% of the monthly budget in one incident. The 7-minute investigation consumes 16%.
