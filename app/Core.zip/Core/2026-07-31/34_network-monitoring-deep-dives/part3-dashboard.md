# Part 3 — Network Monitoring Dashboard Deep Dive

> The dashboard is a single Terraform-managed page in Dynatrace that shows all 4 network signals in one place. This is the first screen an SRE opens when investigating a network-related alert.

---

## Why a Dedicated Network Dashboard

The existing Dynatrace metrics are available everywhere — but scattered. During an incident:

```
Without dedicated dashboard:
  "TCP retransmission is high"
  → Open Dynatrace → Infrastructure → Hosts → find the node → Network tab
  → Switch tab to see DNS → need to go to Services → find the process group → Network tab
  → Cross-reference manually
  Time spent navigating: 3–5 minutes while service is degraded

With dedicated network dashboard:
  Open "Network Health — production"
  → All 4 signals visible in one view, side by side, same time range
  → Correlation is visual: "retransmission spiked at 14:30 AND
    DNS failures started at 14:31 AND connection count rose at 14:32"
  Time spent navigating: 0 minutes
```

The dashboard doesn't add new data — it adds speed of interpretation.

---

## Dashboard Layout: 2×2 Grid

```
┌──────────────────────────┬──────────────────────────┐
│ TCP Retransmission Rate  │ DNS Failure Rate          │
│ (all nodes, max per node)│ (all services, avg)       │
│ Line chart, split by host│ Line chart, split by svc  │
├──────────────────────────┼──────────────────────────┤
│ Active TCP Connections   │ Node Outbound Throughput  │
│ (all services, sum)      │ (all nodes, max per node) │
│ Line chart, split by svc │ Line chart, split by node │
└──────────────────────────┴──────────────────────────┘
```

Each tile covers one column width (494px) and one row height (152px). Total dashboard: 988px wide × 304px tall. Fits on a 1080p monitor without scrolling.

---

## Each Tile Explained

### Tile 1: TCP Retransmission Rate

```hcl
tile {
  name      = "TCP Retransmission Rate — All Nodes"
  tile_type = "DATA_EXPLORER"
  bounds { top = 0; left = 0; height = 152; width = 494 }
  # Position: top-left corner of the dashboard
  # height/width in pixels. This matches Dynatrace's grid system.

  visualization_config {
    type = "GRAPH_CHART"   # Line chart (vs BAR_CHART, SINGLE_VALUE, etc.)
  }

  queries {
    id               = "A"
    metric           = "builtin:host.net.retransmission"
    spaceAggregation = "MAX"
    # MAX across time: shows the PEAK retransmission rate per minute.
    # Why MAX not AVG: a node that has 10% retransmission for 10 seconds
    # and 0% for the rest of the minute would show AVG ≈ 1.7% (hidden).
    # MAX shows 10% → the actual peak that caused the problem.

    timeAggregation = "DEFAULT"
    # Default = use the auto-selected aggregation for the time window.
    # For a 30-minute window: 1-minute data points.
    # For a 6-hour window: 5-minute aggregated points.

    splitBy = ["dt.entity.host"]
    # Creates one line per EKS node.
    # During an incident: one line will be clearly higher than others
    # → immediately identifies the problematic node without clicking.

    filterBy {
      nestedFilters {
        filter {
          criteria     { value = var.environment; evaluator = "EQ" }
          dimensionName = "environment"
          # Shows ONLY nodes in this environment (production/staging/dev).
          # Without this filter, all nodes from all environments appear
          # on the production dashboard → confusing and misleading.
        }
      }
    }
  }
}
```

**What a healthy chart looks like:**
```
% Retransmission
0.15 |
0.10 |  node-a ·····················  (all lines flat, near 0)
0.05 |  node-b ·····················
0.00 |  node-c ·····················
      └─────────────────────────────→ time
```

**What a problem looks like:**
```
% Retransmission
5.00 |                 /node-a\
4.00 |                /        \
3.00 |               /          \
2.00 |              /            \  ← alert threshold
1.00 |        ·····/              \·····
0.00 |  node-b ·····················
      └─────────────────────────────→ time
         ^14:30 node-a replaced → MTU reset to 1500
```

The split-by-host view makes root cause identification visual in under 2 seconds.

---

### Tile 2: DNS Failure Rate

```hcl
tile {
  name  = "DNS Failure Rate — All Services"
  bounds { top = 0; left = 494; height = 152; width = 494 }
  # Position: top-right (left=494 = placed right of tile 1)

  queries {
    metric           = "builtin:process.network.dnsFailureRate"
    spaceAggregation = "AVG"
    # AVG for DNS failure rate, not MAX.
    # WHY: DNS failures are more binary — either CoreDNS is down (100% fail)
    # or it's working (0%). MAX and AVG tell the same story here.
    # AVG is cleaner for comparing across services over time.

    splitBy = ["dt.entity.process_group"]
    # One line per service (process group = all pods of one service).
    # If payment-service and order-service both show DNS failures → CoreDNS is broken (affects all).
    # If only notification-service shows DNS failures → pod-specific issue
    #   (wrong /etc/resolv.conf, DNS misconfiguration in that pod's spec).
  }
}
```

**Correlation insight (tiles 1 and 2 together):**

```
TCP Retransmission tile:
  14:32: node-a retransmission spikes to 4%

DNS Failure Rate tile:
  14:33: payment-service DNS failures spike to 2%
         order-service DNS failures spike to 2%
         notification-service DNS failures spike to 2%

Interpretation:
  ALL services fail DNS at the same time → CoreDNS is the problem, not individual services.
  DNS failures started 1 minute AFTER retransmissions → CoreDNS TCP traffic to upstream
  DNS resolver is also affected by the retransmission issue on node-a.

Root cause: node-a hosts the CoreDNS pods AND has high retransmission.
  CoreDNS can't reach the upstream resolver (8.8.8.8 or Route53) through the
  degraded node → all services that depend on CoreDNS fail.

Fix: kubectl cordon node-a; kubectl drain node-a
  → CoreDNS reschedules to healthy node → DNS restores → all services recover.
```

---

### Tile 3: Active TCP Connections

```hcl
tile {
  name  = "Active TCP Connections — Per Service"
  bounds { top = 152; left = 0; height = 152; width = 494 }
  # Position: bottom-left (top=152 = placed below tile 1)

  queries {
    metric           = "builtin:process.network.connections"
    spaceAggregation = "SUM"
    # SUM across all pods of the same service.
    # WHY: payment-service has 3 pods. Each pod has 80 connections.
    # SUM = 240 total connections for the service.
    # This gives the total load on the NAT Gateway from this service.
    # AVG would show 80 (per pod) — less useful for SNAT calculations.

    splitBy = ["process.group.name"]
    # One line per service name (text label, more human-readable than entity ID).
    # Shows: "payment-service: 240", "order-service: 180", "notification-service: 4,200"
    # The outlier is immediately visible.
  }
}
```

**The SNAT calculation the SUM enables:**

```
From the dashboard:
  payment-service:      240 connections (3 pods × 80 each)
  order-service:        180 connections (3 pods × 60 each)
  notification-service: 4,200 connections (3 pods × 1,400 each — PROBLEM)
  system pods:           50 connections

  Total per cluster: 4,670 connections
  
  If all on the SAME 3 nodes:
    Per node: 4,670 / 3 ≈ 1,557 connections
    NAT remaining: 64,512 - 1,557 = 62,955 (fine)
  
  If notification-service pods all land on ONE node:
    That node: 4,200 (notification) + 80 (payment) + 60 (order) + 50 = 4,390
    NAT remaining: 64,512 - 4,390 = 60,122 (still fine, but monitoring it)
  
  If notification-service CONNECTION LEAK continues and reaches 20,000 per pod:
    One node: 60,000 + 80 + 60 + 50 = 60,190 connections → 95% of NAT capacity
    Any burst traffic could exhaust it → silent connection failures
```

---

### Tile 4: Node Outbound Throughput

```hcl
tile {
  name  = "Node Outbound Throughput (MB/s)"
  bounds { top = 152; left = 494; height = 152; width = 494 }
  # Position: bottom-right

  queries {
    metric           = "builtin:host.net.throughput.tx"
    spaceAggregation = "MAX"
    # MAX per node per minute.
    # Shows peak send rate — relevant for both NIC saturation and cost.

    splitBy = ["dt.entity.host"]
    # One line per node.
    # Color-coded in DT UI: makes it easy to spot one node
    # sending significantly more than others.
  }
}
```

**What a cost-alerting investigation looks like from this tile:**

```
Tile 4 shows at 09:00:
  node-prod-1a-001: 45MB/s  (normal)
  node-prod-1a-002: 112MB/s (ABOVE threshold! Alert fired)
  node-prod-1b-001: 48MB/s  (normal)

Go to tile 3 (connections):
  notification-service: 2,100 connections (elevated but not critical)
  payment-service: 240 (normal)
  order-service: 180 (normal)

Cross-reference: which pods are on node-prod-1a-002?
  kubectl get pods -A -o wide | grep node-prod-1a-002
  → notification-service-abc-def (ALL THREE notification pods landed on this node!)
  → topologySpreadConstraints failed (why? node selector mismatch?)

Root cause: notification-service has incorrect nodeSelector — all 3 pods scheduled
  to the same node → all 3 pods' SQS traffic goes through one node → 112MB/s.

Fix: Remove incorrect nodeSelector, rolling restart → pods spread across AZs.
```

---

## How to Open the Dashboard During an Incident

```bash
# Get the dashboard URL from Terraform output
cd terraform/environments/production
terraform output -raw dynatrace_dashboard_network_url
# Returns: https://abc.live.dynatrace.com/ui/dashboards/12345

# Or navigate manually:
# Dynatrace UI → Dashboards → search "Network Health — production"
# Bookmark this URL in your incident runbook
```

**Dashboard sharing:**
```hcl
sharing_details {
  shared              = true
  link_sharing_active = true
}
```

`link_sharing_active = true` means anyone with the URL can view the dashboard, even if they don't have a Dynatrace login. Useful for sharing a snapshot link in a Slack incident thread: `Network Health: https://abc.live.dynatrace.com/...`

---

## Dashboard Time Range During Incidents

Dynatrace dashboards default to the last 2 hours. During an incident:

```
Right-click any graph → "Focus on this time period"
→ Zoom into 14:30–14:45 (the spike window)
→ All tiles update to show the same 15-minute window
→ Retransmission peak, DNS failure start, connection count growth
   are all visible on one screen with the same time axis

This correlation view (all 4 metrics with the same time axis) is
what makes the dashboard more powerful than checking metrics individually.
```

---

## Terraform Dashboard: What the `bounds` Values Mean

```
Dynatrace dashboard grid system:
  1 unit = 76px
  Tiles snap to 76px grid

bounds example:
  top = 0      → first row (0px from top)
  left = 0     → first column (0px from left)
  height = 152 → 2 grid units tall (152/76 = 2)
  width = 494  → 6.5 grid units wide (approximately)

The 2×2 layout fills 988px × 304px:
  ┌──────494──────┬──────494──────┐
  │ tile1 (top=0) │ tile2 (left=494)│ height=152
  ├───────────────┼───────────────┤
  │ tile3 (top=152)│ tile4 (top=152)│ height=152
  └───────────────┴───────────────┘
```

If you want to ADD tiles (e.g., VPC Flow Reject count from Part 6):
```hcl
tile {
  name  = "VPC Flow REJECT Count"
  bounds { top = 304; left = 0; height = 152; width = 988 }
  # top=304 → third row (below both existing rows)
  # width=988 → full dashboard width (spans both columns)
}
```
