# Part 5 — ALB Network Monitoring via Synthetic Deep Dive

> The connectivity chain synthetic monitor extends the existing health check with a second validation step that tests the network path from the ALB all the way to the database. This is an outside-in network probe.

---

## Why a Separate Connectivity Chain Monitor

The existing synthetic (`dynatrace_http_monitor.health_check`) tests:
```
External probe (Tokyo) → ALB → service → /actuator/health → HTTP 200 + "status":"UP"
```

This validates the top-level availability. But `/actuator/health` in Spring Boot returns UP even when some components are degraded. The readiness endpoint (`/actuator/health/readiness`) validates EVERY dependency:

```
/actuator/health/readiness checks:
  - Database connection pool (JDBC ping)
  - Any custom @ReadinessIndicator beans
  - Cache connectivity (Redis, etc.)
  - Message queue connectivity (SQS, etc.)
```

The connectivity chain synthetic uses this richer endpoint to test not just "is the service alive?" but "can the service reach everything it needs?"

---

## The Two-Step Synthetic Explained

```
Step 1: External path test
  Tokyo probe → internet → Route53 DNS → ALB → service pod → /actuator/health
  Tests: DNS resolution, TLS certificate, ALB routing, service startup

Step 2: DB connectivity test (through the service)
  Tokyo probe → internet → Route53 → ALB → service pod → /actuator/health/readiness
  Tests: everything in step 1, PLUS the service's connection to RDS/downstream
```

The second step uses the service AS A PROXY to test internal connectivity. The probe in Tokyo can't directly reach RDS (in a private subnet). But the service pod can. By asking the service "is your DB connection healthy?", the external probe indirectly tests the private network path.

---

## Full HCL: Every Field Explained

```hcl
resource "dynatrace_http_monitor" "connectivity_chain" {
  for_each  = var.services
  name      = "${each.key} Connectivity Chain [${var.environment}]"
  # Example: "payment-service Connectivity Chain [production]"
  # Distinct from the existing "payment-service Health Check [production]"
  # so they're separately trackable in the DT Synthetic dashboard.

  enabled   = true
  frequency = 5
  # Same 5-minute frequency as the existing health check.
  # Result: if this fails, you know within 5 minutes of the failure.
  # Lower (1 min) is possible but uses more DT monitoring units.

  locations = var.synthetic_locations
  # production: [Tokyo, Singapore]
  # dev:        [Tokyo only]
  # Running from TWO locations validates that failures are real (not local probe issues).
  # If Tokyo fails but Singapore succeeds: Tokyo → service network issue, not service issue.

  script {
    #---------------------------------------------------------------------------
    # REQUEST 1: Top-level health (ALB → service external path)
    #---------------------------------------------------------------------------
    request {
      description = "ALB → ${each.key} health"
      method      = "GET"
      url         = each.value.health_check_url
      # Example: "https://payment.company.com/actuator/health"

      configuration {
        accept_any_certificate = false
        # WHY false: don't accept expired or invalid TLS certificates.
        # A self-signed or expired cert should alert — it's a real problem
        # (ACM cert rotation failure, certificate misconfiguration).
        # If true: certificate issues are silently ignored.

        follow_redirects = true
        # HTTP → HTTPS redirect is expected (ALB redirects port 80 to 443).
        # The probe follows the redirect and tests the final HTTPS endpoint.
        # Without this: the probe would stop at the 301 redirect and
        # not actually test the real endpoint.
      }

      validation {
        rule {
          type          = "httpStatusesList"
          value         = "2xx"
          pass_if_found = true
          # Must return 200, 201, 202, etc.
          # A 503 "Service Unavailable" from ALB (no healthy targets)
          # would fail this validation immediately.
        }
        rule {
          type          = "patternConstraint"
          value         = "\"status\":\"UP\""
          pass_if_found = true
          # Response body must contain exactly "status":"UP".
          # Spring Boot Actuator format. Catches the case where HTTP 200
          # is returned but the app reports itself as DOWN internally.
        }
      }

      response_time_limit = each.value.latency_p99_ms * 3
      # production payment-service: 300ms × 3 = 900ms
      # Why 3×: external probe adds network RTT (Tokyo → Tokyo AWS: ~20ms,
      # Tokyo → Singapore AWS: ~70ms). The probe measures end-to-end
      # time including TLS handshake (~50ms). 3× accounts for this overhead
      # while still catching genuinely slow responses.
    }

    #---------------------------------------------------------------------------
    # REQUEST 2: DB connectivity via readiness endpoint
    #---------------------------------------------------------------------------
    request {
      description = "DB connectivity check via readiness"
      method      = "GET"
      url         = replace(each.value.health_check_url, "/health", "/health/readiness")
      # Transforms: https://payment.company.com/actuator/health
      # Into:       https://payment.company.com/actuator/health/readiness
      #
      # /health          = liveness check (is the JVM alive?)
      # /health/readiness = readiness check (can it serve traffic?)
      #   → Spring Boot readiness checks: DB connection, custom indicators

      validation {
        rule {
          type          = "httpStatusesList"
          value         = "2xx"
          pass_if_found = true
          # /actuator/health/readiness returns:
          #   200 when ALL components are UP
          #   503 when ANY component is DOWN
          # A 503 here means: HTTP server runs BUT DB is unreachable
        }
        rule {
          type          = "patternConstraint"
          value         = "\"db\":{\"status\":\"UP\"}"
          pass_if_found = true
          # The response body must contain this exact substring.
          # Spring Boot Actuator format for the db component:
          #   "db":{"status":"UP","details":{"database":"PostgreSQL","validationQuery":"..."}}
          #
          # If DB is unreachable, the body contains:
          #   "db":{"status":"DOWN","details":{"error":"JDBC Connection refused"}}
          # → validation fails → AVAILABILITY alert fires
          #
          # This is the critical network test: the service MUST reach RDS.
          # If it can't, this synthetic fails even if /actuator/health returns 200.
        }
      }

      response_time_limit = each.value.latency_p99_ms * 2
      # 300ms × 2 = 600ms for production payment-service.
      # The readiness endpoint does a real DB query (SELECT 1 or ping).
      # This adds ~5–10ms for the DB roundtrip + connection pool time.
      # 2× limit is tighter than step 1's 3× because:
      # - No TLS handshake overhead (connection reused from step 1)
      # - Any slowness means DB is slow, not network RTT
    }
  }

  tags {
    tag { key = "team";         value = each.value.team }
    tag { key = "environment";  value = var.environment }
    tag { key = "service";      value = each.key }
    tag { key = "monitor-type"; value = "connectivity-chain" }
    # monitor-type tag separates this from the basic health check.
    # Dynatrace management zone rules can filter on this tag:
    # "only show connectivity-chain monitors in the SRE dashboard"
  }
}
```

---

## What the Readiness Response Looks Like

### Healthy response (DB reachable):
```json
HTTP 200 OK
{
  "status": "UP",
  "components": {
    "db": {
      "status": "UP",
      "details": {
        "database": "PostgreSQL",
        "validationQuery": "isValid()"
      }
    },
    "diskSpace": {
      "status": "UP",
      "details": { "total": 8369815552, "free": 6200000000, "threshold": 10485760 }
    },
    "ping": { "status": "UP" }
  }
}
```

Body contains `"db":{"status":"UP"}` → validation passes.

### Unhealthy response (DB unreachable):
```json
HTTP 503 Service Unavailable
{
  "status": "DOWN",
  "components": {
    "db": {
      "status": "DOWN",
      "details": {
        "error": "org.postgresql.util.PSQLException: Connection refused. Check that the hostname and port are correct and that the postmaster is accepting TCP/IP connections."
      }
    },
    "diskSpace": { "status": "UP" },
    "ping": { "status": "UP" }
  }
}
```

Both validations fail: HTTP status is 503 AND body doesn't contain `"db":{"status":"UP"}` → AVAILABILITY alert fires within 5 minutes of the first probe failure.

---

## Network Failures This Synthetic Detects

### Failure 1: RDS security group changed

```
Scenario: someone modifies the payment-service → RDS security group
          to deny inbound on port 5432

t=0:00  Security group modified in AWS console
t=0:01  Existing DB connections: still open (TCP is stateful, existing connections unaffected)
t=5:00  Connection pool times out idle connections, tries to create new ones
        → New TCP SYN to RDS port 5432 → Security group DROPS it
        → Connection attempt times out (30s TCP timeout)
        → Spring HikariCP throws "Connection refused"
        → /actuator/health/readiness: "db": {"status": "DOWN"}

t=10:00 Synthetic runs (5-minute interval)
        → Step 1: /actuator/health → 200 (HTTP server still up)
        → Step 2: /actuator/health/readiness → 503 "db DOWN"
        → Synthetic FAILS → AVAILABILITY alert fires
        → PagerDuty: "payment-service Connectivity Chain [production] FAILED"
```

Without this synthetic: only the error rate alert (Signal 2) would eventually fire once real users hit payment failures (after the connection pool depletes). The synthetic catches it proactively.

### Failure 2: RDS subnet routing changed

```
Scenario: a route in the private subnet routing table is accidentally deleted
          → EKS pods can no longer reach the RDS subnet

t=0:00  Route deleted
t=0:01  ALL existing DB connections immediately fail (TCP RST or silence)
t=0:02  Spring HikariCP reports all connections invalid
t=0:02  /actuator/health/readiness returns 503 for all payment-service pods
t=0:02  ALB readiness probe fails → ALL payment-service pods removed from ALB targets
t=0:02  ALB returns 503 to users (no healthy targets)

t=5:00  Synthetic: Step 1 → ALB returns 503 (no targets)
        → Already caught by step 1, don't even reach step 2
        → AVAILABILITY alert fires immediately
```

Without this synthetic: the existing health check synthetic would catch this too. The connectivity chain's value here is in step 2 specifically for DB-layer failures that don't surface at the ALB level.

### Failure 3: DNS record for RDS endpoint deleted

```
Scenario: The Spring datasource URL uses the RDS DNS name:
  spring.datasource.url=jdbc:postgresql://payment-db.cluster-abc.ap-northeast-1.rds.amazonaws.com/payments

If this DNS record is deleted:
  → New DB connections (after pool timeout) → DNS lookup → NXDOMAIN
  → Connection fails with "Unknown host"
  → /actuator/health/readiness: "db DOWN" with "Unknown host" error

t=5:00  Synthetic step 2 detects "db DOWN" → AVAILABILITY alert
```

---

## The Global vs. Local Outage Logic for Step 2

```hcl
anomaly_detection {
  outage_handling {
    global_outages                            = true
    local_outages                             = true
    global_consecutive_outage_count_threshold = 1
    # If ALL locations (Tokyo AND Singapore) fail step 2 simultaneously:
    # → 1 consecutive failure → AVAILABILITY alert
    # Global failure = real DB issue (not a regional network problem)

    local_consecutive_outage_count_threshold  = 3
    # If ONLY Tokyo fails step 2 (Singapore is fine):
    # → 3 consecutive failures from Tokyo before alerting
    # → Filters out: one-time Tokyo network blip, probe infrastructure issues
    # → 3 failures at 5-min interval = 15 minutes of Tokyo-specific failure
    # WHY 3 not 1: Tokyo probe failure may be unrelated to the service
    # (Tokyo AWS network issue, DT probe infrastructure maintenance)
    # Singapore still working → service is alive → less urgency

    local_outages_count_threshold = 1
    # Only need 1 location failing locally (not multiple locations independently)
  }
}
```

---

## Using Both Synthetic Monitors Together

The project now has TWO synthetics per service:

| Monitor | Endpoint | Tests | Frequency |
|---------|---------|-------|-----------|
| Health Check | `/actuator/health` | Is the service alive? | 5 min |
| Connectivity Chain | `/actuator/health` + `/actuator/health/readiness` | Is the service alive AND connected to dependencies? | 5 min |

When the Health Check passes but Connectivity Chain fails:
```
→ HTTP server running, JVM alive (step 1 OK)
→ BUT DB/downstream is unreachable (step 2 FAIL)
→ Root cause: network between EKS and dependency (RDS security group, subnet routing, DB host)
→ NOT an application bug — infrastructure issue
```

When both fail:
```
→ Even step 1 fails
→ The service itself is unreachable (ALB issue, DNS, TLS cert, pod not running)
→ Check: ALB target health, pod status, DNS records for the service
```

When neither fails:
```
→ Application is up AND all dependencies are reachable
→ Any performance issues are in the application logic, not infrastructure
→ Check: JVM heap, traces, DB query performance
```
