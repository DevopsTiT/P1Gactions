# Network Monitoring Deep Dives — Glossary for SRE Beginners

Every term used across all 9 part files.

---

**`/proc/net/dev`**
A Linux virtual file (not a real file — generated live by the kernel) that lists all network interfaces and their traffic statistics: bytes sent/received, packets, errors, drops. OneAgent reads this every 60 seconds to compute throughput and error rate metrics. No network traffic is generated to read it.

**`/proc/net/snmp`**
A Linux virtual file with TCP-level global counters for the entire system: total segments sent, retransmitted segments, errors, reset connections. OneAgent reads `RetransSegs / TotalSegs` from this file to compute the TCP retransmission rate.

**`/proc/net/tcp`**
A Linux virtual file listing every active TCP socket on the system: source IP/port, destination IP/port, current state (ESTABLISHED, TIME_WAIT, etc.), and which process owns it. OneAgent reads this to compute `builtin:process.network.connections` — the count of active TCP connections per JVM process.

**`/proc/<pid>/net/`**
Process-specific network statistics. Each JVM process has its own network namespace in Kubernetes. OneAgent reads process-specific network files to attribute traffic to a specific service (payment-service vs. order-service) rather than the entire node.

**CWND (Congestion Window)**
TCP's internal limit on how much data it can send before waiting for an acknowledgement. When packet loss occurs (detected via retransmit timeout), TCP halves the CWND — immediately cutting throughput by 50%. Repeated packet loss causes CWND to shrink to almost nothing, collapsing throughput even though the NIC and network are physically available.

**TCP congestion avoidance**
The algorithm TCP uses when it detects packet loss: slow down, send less data, wait for acknowledgements, then gradually increase speed again. The result is: a 2% retransmission rate doesn't cause 2% throughput reduction — it causes 50-80% throughput reduction because congestion avoidance keeps TCP slow even after individual packets stop being lost.

**SYN / SYN-ACK / ACK (TCP handshake)**
The three-way handshake to establish a TCP connection. SYN: "I want to connect." SYN-ACK: "OK, I'm ready." ACK: "Connection established." A NetworkPolicy DROP happens at the SYN stage — the server never sends SYN-ACK back, so the client waits for the TCP timeout (30+ seconds) before concluding "connection failed."

**TIME_WAIT**
A TCP connection state where the connection has been closed but the kernel keeps it in a "waiting" state for 60 seconds. This ensures any delayed packets from the old connection don't get confused with a new connection on the same port. Services that rapidly open and close connections accumulate many TIME_WAIT entries — they count toward `builtin:process.network.connections` even though no active communication is happening.

**CLOSE_WAIT**
A TCP connection state where the remote side has closed the connection but the local process hasn't called `close()` yet. An accumulation of CLOSE_WAIT connections (seen via `ss -tan`) means the application has a bug: it's receiving the close signal but not processing it. Common cause: a Java connection pool not properly closing connections when they're returned.

**`ss -tan`**
Linux socket statistics command. `-t` = TCP sockets only. `-a` = all states (not just established). `-n` = numeric (don't resolve hostnames). Output shows all TCP connections with their current state. Used to diagnose connection count issues without needing admin access to the network infrastructure.

**`ss -s` (summary)**
Shows aggregate counts: total TCP sockets, how many are established, orphaned, in TIME_WAIT, etc. Faster than `ss -tan` for getting a quick health snapshot. Useful in a debug pod to immediately assess if a pod has abnormal connection counts.

**ENI (Elastic Network Interface)**
A virtual network card attached to an EC2 instance. Each ENI has one primary IP and can have multiple secondary IPs. The VPC CNI assigns secondary IPs to pods. EC2 instance types have limits on ENI count and secondary IPs per ENI — these limits determine the maximum pod count per node.

**VPC CNI (Container Network Interface plugin for AWS VPC)**
The networking plugin that gives each Kubernetes pod a real VPC IP address from the EC2 node's ENI. This enables direct pod-to-pod communication without NAT, and allows ALB target-type=ip (routing directly to pod IPs). Also enforces NetworkPolicy rules at the packet level.

**Jumbo Frames (MTU 9001)**
AWS VPC supports a maximum transmission unit (MTU) of 9001 bytes within the VPC (compared to the internet standard of 1500 bytes). Jumbo frames allow much more data per packet — fewer packets for the same amount of data → less overhead → higher throughput. If a node's MTU is reset to 1500 (e.g., after a configuration change), large packets get fragmented or dropped → TCP retransmissions → latency spikes.

**Fragmentation**
When a packet is larger than the MTU, it must be split into smaller pieces (fragments) before transmission. Fragmentation is computationally expensive and unreliable — if any fragment is lost, the entire original packet must be retransmitted. With `DF` (Don't Fragment) bit set (common in modern systems), large packets are simply DROPPED instead of fragmented, causing silent failures.

**NIC ring buffer**
A circular memory buffer in the NIC hardware where incoming packets are stored before the CPU processes them. If the CPU can't process packets fast enough (due to high CPU load), the ring buffer fills up and new packets are dropped (`rx_dropped` in `/proc/net/dev`). This causes `builtin:host.net.errorRate` to rise without any physical network issue.

**NACL (Network Access Control List)**
A stateless firewall at the subnet boundary in AWS VPC. Unlike security groups (which are stateful — outbound rules automatically allow return traffic), NACLs evaluate each packet independently. If you block outbound port 5432 on a NACL, the return traffic from RDS is also blocked (because NACLs don't track connection state). Usually left at default (allow all). Changes to NACLs are a common cause of mysterious connectivity failures.

**`target_status_code = "-"` (ALB access logs)**
In ALB access logs, this means the ALB successfully received the client's request but was unable to establish a TCP connection to the backend pod. The dash represents "no status" — no HTTP response was received because the connection never succeeded. Causes: pod crashing before accepting connections, security group blocking ALB→pod traffic, VPC CNI IP allocation failure.

**`elb_status_code 504` (ALB)**
HTTP Gateway Timeout. The ALB connected to the backend pod but the pod didn't respond within the timeout period (default 60 seconds). The pod's HTTP server is running and the connection was accepted, but the response took too long. Causes: application deadlock, GC full pause, DB query taking 60+ seconds, CPU starvation.

**`elb_status_code 502` (ALB)**
HTTP Bad Gateway. The ALB connected to the backend pod but received an invalid HTTP response. Causes: backend pod crashed while processing the request (sent a RST mid-response), Spring Boot's graceful shutdown completing before the response was sent.

**`elb_status_code 503` (ALB)**
HTTP Service Unavailable. The ALB has no healthy backend pods to route the request to. Causes: all pods failed health checks, deployment in progress (all pods restarting simultaneously — prevented by `maxUnavailable: 0` in the project), pod IP addresses still registered in the target group after pods were deleted.

**CloudWatch Logs subscription filter**
An AWS feature that pipes log records from a CloudWatch Logs log group to a Lambda function, Kinesis stream, or other destination in real-time. The filter pattern pre-selects which log lines to forward — `filter_pattern = "REJECT"` means only VPC Flow Log lines containing "REJECT" are forwarded, keeping Lambda invocations and costs near zero for healthy clusters.

**Metrics Ingest API (Dynatrace)**
A Dynatrace API endpoint (`/api/v2/metrics/ingest`) that accepts custom metric data in a simple text format. Format: `metric.name[,dimensions] value`. Once ingested, custom metrics behave exactly like built-in metrics — they can be alerted on, added to dashboards, and queried via the Metrics API. Used to bring AWS-native data (VPC Flow rejects, ALB timeouts) into the Dynatrace ecosystem.

**`ext:kubernetes.*` metrics**
Dynatrace metrics collected by ActiveGate from Kubernetes components via the Kubernetes API and Prometheus endpoints. Distinguished from `builtin:` (OneAgent) and `custom.*` (user-pushed) metrics. `ext:kubernetes.coredns.dns_responses_total` comes from CoreDNS's built-in Prometheus metrics endpoint scraped by ActiveGate.

**Prometheus metrics endpoint**
A standard HTTP endpoint (usually `/metrics` on port 9090 or 9153) that exposes application internals in a text format. CoreDNS, kube-state-metrics, and many other Kubernetes components expose this endpoint. Dynatrace ActiveGate can scrape it and store the metrics as `ext:` metrics.

**HikariCP**
The default JDBC connection pool in Spring Boot. Manages a pool of pre-established database connections, reusing them across requests instead of creating a new TCP connection for each query. Key settings: `maximumPoolSize` (max connections per pod), `connectionTimeout` (how long to wait for a free connection), `idleTimeout` (when to close idle connections). Misconfiguration causes either too many connections (SNAT risk) or connection starvation (high latency).

**Connection pool leak**
When code acquires a connection from the pool (via `getConnection()` or implicitly via JPA) but never releases it back. Happens when: exceptions are swallowed before the `finally` block, early returns skip the close call, or a transaction is never committed or rolled back. The pool slowly fills with unreturned connections. New requests wait for a connection that will never be available → timeout errors that look like DB slowness.

**`ndots:5`**
A DNS resolver configuration (in `/etc/resolv.conf`) that says: "if a hostname has fewer than 5 dots, try appending the search domains first." In Kubernetes, this means `orders.company.com` (2 dots) generates 4-5 DNS queries before successfully resolving. Each failed query adds 1-5ms of latency. On a slow CoreDNS, each failure adds 500ms-5s → external service calls take seconds instead of milliseconds.

**Lateral movement**
A security term for an attacker who has compromised one system (e.g., a dev pod) and is trying to reach other systems (e.g., payment-service pods, RDS, secrets). NetworkPolicy drops from unexpected source IPs are a signal of lateral movement probing. Signal F (netpol drops with threshold=0) catches this early.

**Davis Problem (Dynatrace)**
A unified incident object that Davis AI creates when multiple related metric events fire together. Rather than one PagerDuty alert per metric event (which would be 6+ pages for one network cascade), Davis creates ONE Problem with one root cause, one affected entity list, and one Slack/PagerDuty notification. The Problem auto-closes when all underlying metric events return to normal.

**Entity (Dynatrace)**
A monitored object in Dynatrace with a unique ID. Types relevant here: `dt.entity.host` (EC2 node), `dt.entity.process_group_instance` (one JVM pod), `dt.entity.process_group` (all pods of one service), `dt.entity.cloud_application` (Kubernetes Deployment), `dt.entity.service` (auto-discovered service from JVMTI). The `event_entity_dimension_key` in metric events determines which entity type the alert is attached to.

**`violating_samples`**
Number of consecutive evaluation periods a metric must exceed the threshold before a Dynatrace metric event fires. With `resolution=1m` and `violating_samples=3`: the metric must be above threshold for 3 consecutive minutes. Filters transient spikes while catching sustained problems. Lower = faster detection but more false positives. Higher = slower detection but fewer false positives.

**`dealerting_samples`**
Number of consecutive evaluation periods a metric must be BELOW the threshold before a Dynatrace metric event resolves. Prevents rapid open/close oscillation of alerts when a metric hovers around the threshold. With `dealerting_samples=3` and `resolution=1m`: the metric must be below threshold for 3 clean minutes before the Problem is closed.

**`spaceAggregation: MAX` vs `AVG` (DT dashboard)**
In Dynatrace Data Explorer tiles, `spaceAggregation` controls how data is aggregated across multiple entities in the same chart. MAX shows the highest value across all entities (e.g., the most-retransmitting node). AVG shows the average (smoothes out outliers). For network anomaly detection, MAX is usually better — a single misbehaving node is the signal, averaging it with healthy nodes would hide it.

**`splitBy` (DT dashboard)**
Creates one chart line per unique value of the specified dimension. `splitBy: ["dt.entity.host"]` creates one line per EC2 node. `splitBy: ["process.group.name"]` creates one line per service. Without splitBy: all entities are aggregated into one line, hiding which specific entity has the problem.

**`bounds` (DT dashboard tile)**
Pixel coordinates in a Dynatrace dashboard that specify a tile's position and size: `top` (distance from top in pixels), `left` (distance from left), `height`, `width`. Dynatrace uses a pixel grid system; values must align to the grid (multiples of 76 pixels for a 1920px-wide dashboard). Used when defining dashboards via the Terraform provider.

**MTTR (Mean Time To Resolution)**
Average time from incident start to incident resolution. Network monitoring's primary value is reducing MTTR — providing the root cause immediately rather than requiring manual investigation through multiple systems. The incident example in Part 8 shows: 34 minutes without network signals vs. 7 minutes with network signals. For a 99.9% SLO, each minute of avoidable MTTR costs 2.3% of the monthly error budget.
