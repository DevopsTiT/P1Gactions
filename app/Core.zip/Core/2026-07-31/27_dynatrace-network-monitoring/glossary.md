# Dynatrace Network Monitoring — Glossary for SRE Beginners

Every term used in main.md, one entry per term.

---

**TCP (Transmission Control Protocol)**
The reliable transport protocol used by almost all internet and intra-cluster traffic. TCP guarantees delivery by retransmitting lost packets and ordering them correctly. If TCP starts retransmitting packets frequently, it means the network is dropping or corrupting packets — TCP slows down in response, which appears as latency at the application layer.

**TCP retransmission**
When a TCP packet is sent but no acknowledgement arrives within the timeout, TCP sends it again. Retransmissions are a direct indicator of packet loss. Normal healthy networks have < 0.1% retransmission rate. At 2%+, TCP congestion avoidance throttles throughput. At 10%+, applications time out. Caused by: packet loss, queue overflow, MTU mismatch, NIC saturation.

**Packet loss**
When a network packet is sent but never arrives at its destination. Caused by: overloaded network hardware dropping packets, MTU mismatch causing fragmentation failure, security group silently dropping packets. Unlike TCP errors (which return an error message), packet loss causes silent timeouts — the app just waits with no feedback.

**MTU (Maximum Transmission Unit)**
The largest single packet a network interface will send in one piece. Default for Ethernet/VPC: 1500 bytes. AWS supports Jumbo Frames (9001 bytes) on most links inside a VPC. MTU mismatch: if one segment allows 9001 bytes but the next only allows 1500, large packets get fragmented or dropped (if the "don't fragment" bit is set). Causes: throughput collapse, intermittent timeouts.

**SNAT (Source Network Address Translation)**
When a pod in a private subnet makes an outbound internet connection, the NAT Gateway rewrites the packet's source IP to the NAT Gateway's public IP. Each rewritten connection needs a unique port number to track it. This port is the "SNAT port." Each EC2 node shares 64,512 SNAT ports with all its pods.

**SNAT port exhaustion**
When all 64,512 SNAT ports on a NAT Gateway are in use, new outbound connections fail silently (connection reset or refused, no error message). Happens when: services open too many connections to the internet, connections are not being closed (pool leak), or one node hosts many high-connection-count pods.

**NAT Gateway**
AWS-managed component that allows pods in private subnets to make outbound internet connections. Uses SNAT to track connections. Has a per-node SNAT port limit. Cost: $0.045/GB of data processed. The project uses one NAT Gateway per AZ for redundancy.

**VPC (Virtual Private Cloud)**
Your private isolated network inside AWS. All EKS pods and nodes live inside the VPC. Traffic between resources inside the VPC is free (within the same AZ). Traffic crossing AZs costs $0.01/GB. Traffic going out to the internet through NAT costs $0.045/GB.

**VPC Flow Logs**
An AWS feature that logs all network traffic accepted or rejected by security groups in your VPC. Each record shows: source IP, destination IP, port, protocol, bytes, packets, and whether the traffic was ACCEPT or REJECT. Essential for diagnosing "why can't pod A reach pod B?" when the app just shows a timeout.

**Security group**
A stateful virtual firewall that controls traffic to/from AWS resources. Stateful means: if you allow an outbound connection, the response is automatically allowed back. Security groups only allow traffic you explicitly permit — everything else is silently rejected (no error returned to sender, just no response).

**NACL (Network Access Control List)**
A stateless firewall at the subnet level. Unlike security groups, NACLs evaluate inbound and outbound rules independently. If you block port 443 outbound on a NACL, the response packets are also blocked because NACLs are stateless. Usually left at default (allow all) and security groups handle the filtering.

**NetworkPolicy (Kubernetes)**
A Kubernetes resource that restricts which pods can talk to which other pods (and which external endpoints). By default in EKS, all pods can talk to all other pods. Adding a NetworkPolicy can accidentally block legitimate traffic — and the app sees silent timeouts (no error, just no response).

**CoreDNS**
The DNS server running inside Kubernetes. Every service-to-service call resolves a DNS name first (`payment-service.payment-ns.svc.cluster.local`). If CoreDNS is overloaded or crashing, ALL service calls fail with `UnknownHostException`. Runs as a 2-replica Deployment in `kube-system`.

**ndots:5 (Kubernetes DNS)**
A Kubernetes default setting in every pod's `/etc/resolv.conf`. It says: "if a DNS name has fewer than 5 dots, try appending the search domains before trying it as-is." So `payment.company.com` (2 dots) gets tried as `payment.company.com.payment-ns.svc.cluster.local` first (5 failed lookups), then `payment.company.com` (which resolves). This adds latency to external DNS lookups.

**DNS failure rate**
The percentage of DNS lookups that return an error (SERVFAIL, NXDOMAIN, timeout). Healthy value: near 0%. Any DNS failures cause connection failures in the application — Java throws `UnknownHostException` which looks identical to "server not found" even when the server is running fine.

**SERVFAIL**
A DNS response code meaning "I couldn't look this up due to a server-side error." Returned by CoreDNS when it can't reach upstream resolvers or has an internal error. From the application's perspective, identical to the service not existing.

**NXDOMAIN**
A DNS response code meaning "this domain does not exist." Returned when: a DNS record was deleted, a service name was misspelled, or a Kubernetes service was deleted. Application sees `UnknownHostException` or `Connection refused`.

**East-west traffic**
Network traffic between services inside the same cluster or network, as opposed to north-south (traffic from the internet coming in, or going out to the internet). `payment-service → order-service` is east-west traffic. Usually free (same AZ) or cheap ($0.01/GB cross-AZ).

**AZ (Availability Zone)**
A physically separate data center within an AWS region. Tokyo (`ap-northeast-1`) has three AZs: 1a, 1b, 1c. Traffic crossing AZ boundaries costs $0.01/GB. Pods spread across AZs improve resilience but increase cost if they communicate heavily with cross-AZ dependencies (like a DB in one AZ).

**Cross-AZ traffic**
Network traffic that travels from one AZ to another. Costs $0.01/GB in AWS. The project uses `one_nat_gateway_per_az = true` to keep NAT traffic within each AZ. But pod-to-pod traffic (payment in AZ-a → order in AZ-c) still crosses AZs if topologySpreadConstraints don't collocate communicating pods.

**topologySpreadConstraints**
Kubernetes pod scheduling configuration that controls how pods are spread across AZs or nodes. `DoNotSchedule` (production) is a hard rule: a pod would rather stay Pending than violate the spread. `ScheduleAnyway` (dev) is best-effort. Misconfigured spread can cause all pods of a service to land in one AZ, making all traffic cross-AZ.

**VPC CNI (Container Network Interface)**
AWS's Kubernetes networking plugin. Assigns each pod a real VPC IP address from the node's ENI. Enables pod-to-pod communication without NAT and enables ALB target-type=ip (direct routing to pods). Can have IP exhaustion issues on small /24 subnets — why the project uses /20 private subnets (4,096 IPs each).

**ENI (Elastic Network Interface)**
A virtual network card attached to an EC2 instance. The VPC CNI assigns secondary IPs from the node's ENI to pods. Each instance type supports a limited number of ENIs and secondary IPs (e.g., t3.medium: 3 ENIs × 6 IPs = 18 pods max). Relevant because: if a node runs out of ENI IPs, new pods get stuck `Pending` with "no IP available."

**TCP keep-alive**
A mechanism where TCP sends periodic "are you still there?" packets on idle connections to prevent the connection from being closed by a firewall or NAT timeout. HTTP keep-alive reuses the same TCP connection for multiple HTTP requests instead of opening a new one per request. Missing keep-alive = new TCP connection per request = high connection count = SNAT port exhaustion risk.

**Connection pool**
A pre-allocated set of database or HTTP connections that are reused across requests instead of creating a new connection for each request. Creating a TCP connection takes 1-3 round trips (SYN, SYN-ACK, ACK) and TLS handshake (~100ms). A pool amortizes this cost. A leaked pool (connections not returned) grows without bound → SNAT port exhaustion.

**Connection pool leak**
When code takes a connection from the pool but fails to return it (due to a bug, exception, or forgotten `finally` block). The pool grows until it hits its configured maximum. New connection requests wait or fail. Visible in network metrics as growing `builtin:process.network.connections` per process.

**OTLP (OpenTelemetry Protocol)**
The wire protocol for sending telemetry (metrics, traces, logs) from applications to backends. Dynatrace ActiveGate accepts OTLP on port 4318. Used in this project via `OTEL_EXPORTER_OTLP_ENDPOINT` to send custom application metrics to Dynatrace alongside auto-instrumented data.

**Dynatrace Metrics Ingest API**
A Dynatrace API endpoint (`/api/v2/metrics/ingest`) that accepts custom metrics in a simple text format. Used by the VPC Flow Logs Lambda to push AWS-native network data (reject counts) into Dynatrace as custom metrics. Format: `metric.name,dimension=value count`.

**Lambda (AWS)**
A serverless compute service. Code runs in response to events (CloudWatch Logs subscription, API call, S3 upload) without managing servers. Used here to process VPC Flow Logs and push reject counts to the Dynatrace Metrics Ingest API. Billed per invocation and per 100ms of execution.

**CloudWatch Logs subscription filter**
An AWS feature that streams log data from CloudWatch Logs to another destination (Lambda, Kinesis, OpenSearch) in real time. Used to pipe VPC Flow Log records to the Lambda that parses REJECT records and pushes counts to Dynatrace.

**`ext:kubernetes.*` metrics**
Dynatrace metric keys prefixed with `ext:` that come from Kubernetes scraping rather than OneAgent. ActiveGate scrapes the Kubernetes API server and Prometheus endpoints on pods (like CoreDNS) and stores them under `ext:kubernetes.*`. `ext:kubernetes.coredns.dns_responses_total` is the total DNS responses metric from CoreDNS's built-in Prometheus endpoint.

**`custom.*` metrics**
User-defined metrics pushed to Dynatrace via the Metrics Ingest API. `custom.network.vpc_flow_rejects` is created by the Lambda. These are fully queryable and alertable in DT, same as built-in metrics. Must be given a meaningful name because there is no built-in documentation for them.

**builtin:host.net.retransmission**
A Dynatrace built-in metric key for the TCP retransmission rate at the host (EC2 node) level. OneAgent reads this from the OS network stack (`/proc/net/snmp`). Collected automatically at 1-minute intervals. No configuration required.

**builtin:process.network.dnsFailureRate**
A Dynatrace built-in metric key for DNS lookup failures at the JVM process level. OneAgent intercepts DNS calls from the JVM. Value = percentage of failed lookups. When this metric is non-zero, service-to-service calls are failing at the DNS resolution step.

**builtin:process.network.connections**
A Dynatrace built-in metric key for the number of active TCP connections of a specific JVM process. Collected from OS-level `ss` or `/proc/net/tcp`. High values indicate potential SNAT port exhaustion risk or connection pool leaks.

**Prometheus**
An open-source monitoring system that scrapes metrics from HTTP endpoints in a text format. Many Kubernetes components (CoreDNS, kube-state-metrics, Ingress controllers) expose Prometheus `/metrics` endpoints. Dynatrace ActiveGate can scrape these and store them as `ext:` metrics.

**NIC saturation**
When a network interface card (NIC) is running at or near its bandwidth limit. EC2 t3.medium supports up to 5Gbps network bandwidth. If all pods on a node collectively send/receive close to 5Gbps, packet queues fill → packets are dropped → TCP retransmissions start. Appears in DT as `builtin:host.net.throughput` near limit + `builtin:host.net.retransmission` rising.

**`nicolaka/netshoot`**
A Docker image with a full suite of network debugging tools pre-installed: `curl`, `dig`, `nslookup`, `tcpdump`, `ss`, `ping`, `traceroute`, `netstat`, `wget`, `nc`. Useful as a debug pod in Kubernetes: `kubectl run netdebug --image=nicolaka/netshoot --rm -it`. Does not require any installation.

**`ss -s` (socket statistics)**
Linux command that shows a summary of socket states. Output includes: total number of TCP connections, established connections, closed connections, retransmitted segments. Useful for quickly assessing a pod's or node's connection health without needing root.

**JDBC (Java Database Connectivity)**
The Java API for connecting to relational databases. Spring Boot uses JDBC (or JPA on top of it) to talk to PostgreSQL/MySQL. OneAgent instruments JDBC calls — capturing SQL text, execution time, connection pool metrics. When the DB is unreachable via network, JDBC throws `SQLException: Connection refused` or times out.

**`UnknownHostException` (Java)**
An exception thrown when a DNS lookup fails. Exact message: `java.net.UnknownHostException: order-service.order-ns.svc.cluster.local`. In Kubernetes, this means CoreDNS couldn't resolve the name — either the service doesn't exist, CoreDNS is down, or DNS is overloaded.

**MTTR (Mean Time To Resolution)**
Average time to resolve an incident. Network monitoring reduces MTTR by naming the specific infrastructure layer (TCP retransmission on node X) instead of leaving the SRE to guess from application-level symptoms alone. The difference: 4 minutes with network root-cause evidence vs. 20+ minutes investigating the wrong layer.
