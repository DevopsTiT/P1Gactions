# Dynatrace Network Monitoring — SRE Deep Dive

> Grounded in the real project: 3 Java Spring Boot services (payment, order, notification) on EKS in 3 environments. Network monitoring is "good to have" — it doesn't block deployments but catches a class of problems that application-layer monitoring misses entirely.

---

## Why Network Monitoring Is a Separate Layer

Application monitoring tells you WHAT is broken.
Network monitoring tells you WHY at the infrastructure level.

```
Application alert fires: "payment-service error rate > 0.1%"
                    ↓
You look at traces: DB queries timeout
                    ↓
Is it slow DB? Or is the NETWORK between payment-service and RDS broken?

Without network monitoring: you check DB metrics, find nothing wrong, waste 30 minutes
With network monitoring:    DT shows TCP retransmission rate spiked on the EKS nodes
                            Root cause: MTU mismatch after a node replacement
                            Fix in 5 minutes
```

Network problems manifest as application errors but cannot be diagnosed from application data alone. Network monitoring closes this gap.

---

## The Network Problem Space for This Project

```
Traffic flows to monitor:

Internet → ALB → payment-service pods        (ingress path)
payment-service → order-service              (east-west / service mesh)
payment-service → RDS (PostgreSQL)           (DB connectivity)
order-service   → notification-service       (east-west)
notification-service → SQS                  (AWS service endpoint)
Any pod → ECR (image pulls)                  (control path)
Any pod → Secrets Manager                    (control path)
EKS nodes → EKS API server                  (control path)

Problem categories:
  Packet loss       → TCP retransmissions → slower requests, timeouts
  Latency spikes    → network congestion, AZ cross-talk, NAT saturation
  MTU mismatch      → large packets fragmented → throughput collapse
  DNS failures      → name resolution timeouts → connection refused
  Security group    → blocked port → connection refused immediately
  NAT saturation    → SNAT port exhaustion → new connections drop
  VPC CNI issues    → pod IP allocation failures → pod stuck Pending
```

---

## PART 1: What Dynatrace Captures Automatically (Zero Config)

OneAgent already runs as a DaemonSet. Without any extra configuration it collects:

### 1.1 Host-Level Network Metrics (per EKS node)

```
Metric key: builtin:host.net.throughput.rx          (bytes received/sec)
Metric key: builtin:host.net.throughput.tx          (bytes sent/sec)
Metric key: builtin:host.net.errorRate              ← already alerted in Signal 8
Metric key: builtin:host.net.packetLoss             (% of packets dropped)
Metric key: builtin:host.net.retransmission         (TCP retransmit rate)
```

**Already in the project:** Signal 8 (`builtin:host.net.errorRate`) alerts at > 0.5% for production. But the project does not yet add dashboards or additional metrics for the others. These are the enhancements below.

### 1.2 Process-Level Network (per JVM)

```
Metric key: builtin:process.network.bytesReceived   (bytes in per process)
Metric key: builtin:process.network.bytesSent       (bytes out per process)
Metric key: builtin:process.network.connections     (active TCP connections)
```

OneAgent captures these at the process group level (i.e., per service). You can see "payment-service sends 50MB/min to the DB, 3MB/min to order-service."

### 1.3 Service-Level Connection Metrics (from OneAgent tracing)

From the same JVMTI instrumentation that captures HTTP latency, OneAgent also captures:

```
builtin:service.dbcalls.count          → DB call rate per service
builtin:service.dbcalls.successRate    → DB call success rate
builtin:service.requestCount.client    → outbound HTTP calls
builtin:service.failureRate.client     → outbound call failure rate
```

These expose: "payment-service is failing 5% of its DB calls" — which could be a network issue (TCP timeout to RDS) or an application issue (wrong query).

---

## PART 2: Terraform — Adding Network Metric Events

These extend the existing `terraform/modules/dynatrace/main.tf` with 4 new signals.

### Signal A: TCP Retransmission Rate (per node)

```hcl
# Add to terraform/modules/dynatrace/main.tf

resource "dynatrace_metric_events" "tcp_retransmission" {
  for_each                   = var.services
  enabled                    = true
  event_entity_dimension_key = "dt.entity.host"
  event_type                 = "RESOURCE_CONTENTION_EVENT"
  summary     = "[${upper(var.environment)}] ${each.key}: TCP retransmission spike (>2%)"
  description = "High TCP retransmission on nodes running ${each.key}. Indicates packet loss or network congestion between pods and their dependencies. Team: ${each.value.team}"

  metadata { configuration_versions = [1] }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    threshold          = 2.0           # % retransmissions. Normal: < 0.5%
    violating_samples  = 3
    dealerting_samples = 3
    samples            = 5
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:host.net.retransmission"
    resolution = "1m"
    entity_filter {
      conditions {
        type     = "DIMENSION"
        rollup   = "NONE"
        operator = "EQUALS"
        value    = var.environment
        key      = "environment"
      }
    }
  }
}
```

**Why 2% threshold?**
Normal LAN/VPC environments have < 0.1% retransmissions. At 1-2%, TCP slows down (congestion avoidance kicks in). At >5%, throughput can collapse to 10% of nominal. Alerting at 2% catches the problem before users feel it.

**When this fires:**
- MTU mismatch after a VPC change (Jumbo frames vs. 1500 byte MTU)
- Node NIC saturation (t3.medium has 5Gbps limit — unusual but possible during batch jobs)
- AZ cross-traffic congestion (pod on AZ-a calling DB in AZ-b under high load)
- ENI attachment issues after node replacement

---

### Signal B: DNS Resolution Failure Rate

```hcl
resource "dynatrace_metric_events" "dns_failures" {
  for_each                   = var.services
  enabled                    = true
  event_entity_dimension_key = "dt.entity.process_group_instance"
  event_type                 = "ERROR_EVENT"
  summary     = "[${upper(var.environment)}] ${each.key}: DNS resolution failures detected"
  description = "DNS lookup failures in ${each.key}. Check CoreDNS pod health, ndots config, and search domain list. Team: ${each.value.team}"

  metadata { configuration_versions = [1] }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    threshold          = 0.5          # % of DNS lookups failing. Healthy: 0%
    violating_samples  = 2
    dealerting_samples = 3
    samples            = 3
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:process.network.dnsFailureRate"
    resolution = "1m"
    entity_filter {
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = each.key key = "process.group.name"
      }
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = var.environment key = "environment"
      }
    }
  }
}
```

**Why DNS failures are critical for Kubernetes:**
Every service-to-service call resolves a DNS name first (`order-service.order-ns.svc.cluster.local`). If CoreDNS is overloaded or misconfigured:
- Every pod → every service call → DNS lookup fails
- Services appear to time out with `java.net.UnknownHostException`
- Looks like a network problem but is actually a CoreDNS capacity issue

Default Kubernetes `ndots:5` setting means even `payment.company.com` gets tried as `payment.company.com.payment-ns.svc.cluster.local` first → 5 failed DNS lookups before the correct one. Each adds latency.

**When this fires:**
- CoreDNS pods OOMKilled (too many queries for their memory limit)
- CoreDNS pods evicted during node drain
- NDots misconfiguration causing query storms
- External DNS provider (Route53) returning NXDOMAIN after DNS record deleted

---

### Signal C: Outbound Connection Saturation (SNAT Port Exhaustion)

```hcl
resource "dynatrace_metric_events" "connection_saturation" {
  for_each                   = var.services
  enabled                    = true
  event_entity_dimension_key = "dt.entity.process_group_instance"
  event_type                 = "RESOURCE_CONTENTION_EVENT"
  summary     = "[${upper(var.environment)}] ${each.key}: High outbound connection count (>800)"
  description = "${each.key} has unusually high active TCP connections. Risk of SNAT port exhaustion on NAT Gateway. Each EKS node has 64,512 SNAT ports shared across all pods. Team: ${each.value.team}"

  metadata { configuration_versions = [1] }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    threshold          = 800          # connections per process instance
    violating_samples  = 5
    dealerting_samples = 3
    samples            = 5
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:process.network.connections"
    resolution = "1m"
    entity_filter {
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = each.key key = "process.group.name"
      }
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = var.environment key = "environment"
      }
    }
  }
}
```

**The SNAT port exhaustion problem (critical for EKS):**
```
EKS pods in private subnets → outbound internet traffic → NAT Gateway
NAT Gateway uses SNAT (Source NAT) to track connections
Each EC2 node gets 64,512 SNAT ports on the NAT Gateway
64,512 ports ÷ multiple pods on one node = limited connections per pod

Example:
  node with 10 pods, each pod has 800 active connections
  = 8,000 connections going through NAT
  At peak: 64,512 - 8,000 = 56,512 remaining (fine)

  But: notification-service opens 5,000 connections to SQS
  + payment-service opens 3,000 connections to Secrets Manager
  = 8,000 from just 2 pods on the same node
  New connections fail silently with "connection reset"
```

**When this fires:**
- notification-service opening too many SQS connections (connection pool misconfiguration)
- HTTP client not reusing connections (missing `Connection: keep-alive`, creating new connection per request)
- DB connection pool leak (connections not returned to pool → new ones created)
- Missing connection timeout (idle connections never closed)

---

### Signal D: Cross-AZ Traffic Spike

```hcl
resource "dynatrace_metric_events" "cross_az_traffic" {
  for_each                   = var.services
  enabled                    = true
  event_entity_dimension_key = "dt.entity.host"
  event_type                 = "RESOURCE_CONTENTION_EVENT"
  summary     = "[${upper(var.environment)}] ${each.key}: Cross-AZ network throughput spike (>100MB/s per node)"
  description = "High network throughput on nodes running ${each.key}. Potential cross-AZ traffic generating data transfer costs ($0.01/GB). Review topology spread and DB read replica placement. Team: ${each.value.team}"

  metadata { configuration_versions = [1] }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    threshold          = 104857600    # 100MB/s in bytes/sec (DT uses bytes)
    violating_samples  = 10
    dealerting_samples = 5
    samples            = 10
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:host.net.throughput.tx"   # outbound bytes per sec per node
    resolution = "1m"
    entity_filter {
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = var.environment key = "environment"
      }
    }
  }
}
```

**Why cross-AZ traffic matters:**
AWS charges $0.01/GB for traffic crossing AZ boundaries. In the VPC with `one_nat_gateway_per_az = true`, pods stay in their own AZ for NAT. BUT pod-to-pod traffic can still cross AZs if topologySpreadConstraints aren't working correctly.

```
payment-service pod (AZ-a) → DB read replica (AZ-b)  → $0.01/GB
payment-service pod (AZ-a) → order-service pod (AZ-c) → $0.01/GB

At 100MB/s cross-AZ for 1 hour = 360GB × $0.01 = $3.60/hour = $2,592/month
                                  for just this one service

This signal is more about cost alerting than reliability
```

---

## PART 3: Network Monitoring Dashboard (Dynatrace Terraform)

### Adding a dedicated network dashboard:

```hcl
# Add to terraform/modules/dynatrace/main.tf

resource "dynatrace_dashboard" "network_overview" {
  name           = "Network Health — ${var.environment}"
  sharing_details {
    shared = true
    link_sharing_active = true
  }
  dashboard_metadata {
    name            = "Network Health — ${var.environment}"
    shared          = true
    tags            = ["network", "sre", var.environment]
    preset          = false
  }

  tile {
    name = "TCP Retransmission Rate — All Nodes"
    tile_type = "DATA_EXPLORER"
    bounds { top = 0; left = 0; height = 152; width = 494 }
    visualization_config {
      type = "GRAPH_CHART"
    }
    queries {
      id         = "A"
      metric     = "builtin:host.net.retransmission"
      spaceAggregation = "MAX"
      timeAggregation  = "DEFAULT"
      splitBy    = ["dt.entity.host"]
      filterBy {
        nestedFilters {
          filter {
            criteria { value = var.environment evaluator = "EQ" }
            dimensionName = "environment"
          }
        }
      }
    }
  }

  tile {
    name = "DNS Failure Rate — All Services"
    tile_type = "DATA_EXPLORER"
    bounds { top = 0; left = 494; height = 152; width = 494 }
    queries {
      id     = "A"
      metric = "builtin:process.network.dnsFailureRate"
      spaceAggregation = "AVG"
      splitBy    = ["dt.entity.process_group"]
      filterBy {
        nestedFilters {
          filter {
            criteria { value = var.environment evaluator = "EQ" }
            dimensionName = "environment"
          }
        }
      }
    }
  }

  tile {
    name = "Active TCP Connections — Per Service"
    tile_type = "DATA_EXPLORER"
    bounds { top = 152; left = 0; height = 152; width = 494 }
    queries {
      id     = "A"
      metric = "builtin:process.network.connections"
      spaceAggregation = "SUM"
      splitBy    = ["process.group.name"]
      filterBy {
        nestedFilters {
          filter {
            criteria { value = var.environment evaluator = "EQ" }
            dimensionName = "environment"
          }
        }
      }
    }
  }

  tile {
    name = "Node Outbound Throughput (MB/s)"
    tile_type = "DATA_EXPLORER"
    bounds { top = 152; left = 494; height = 152; width = 494 }
    queries {
      id     = "A"
      metric = "builtin:host.net.throughput.tx"
      spaceAggregation = "MAX"
      splitBy    = ["dt.entity.host"]
      filterBy {
        nestedFilters {
          filter {
            criteria { value = var.environment evaluator = "EQ" }
            dimensionName = "environment"
          }
        }
      }
    }
  }
}
```

---

## PART 4: Kubernetes-Native Network Monitoring

### 4.1 CoreDNS Metric Events (the DNS server inside K8s)

CoreDNS exposes Prometheus metrics. ActiveGate (with `kubernetes-api-monitoring` capability) scrapes them:

```hcl
# Add to terraform/modules/dynatrace/main.tf

resource "dynatrace_metric_events" "coredns_errors" {
  enabled                    = true
  event_entity_dimension_key = "dt.entity.cloud_application"
  event_type                 = "ERROR_EVENT"
  summary     = "[${upper(var.environment)}] CoreDNS error rate elevated"
  description = "CoreDNS is returning SERVFAIL or NXDOMAIN at high rate. All service-to-service calls will be affected. Immediately check: pod health, memory, upstream resolvers."

  metadata { configuration_versions = [1] }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    threshold          = 10           # errors per minute. Healthy: 0
    violating_samples  = 2
    dealerting_samples = 3
    samples            = 3
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "ext:kubernetes.coredns.dns_responses_total"
    resolution = "1m"
    entity_filter {
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = "SERVFAIL" key = "rcode"
      }
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = var.environment key = "environment"
      }
    }
  }
}
```

### 4.2 Kubernetes Network Policy Rejection Monitoring

When network policies block traffic, the packets are dropped silently (no error message to the app — just timeout). The EKS VPC CNI can expose rejection metrics:

```hcl
resource "dynatrace_metric_events" "netpol_drops" {
  enabled                    = true
  event_entity_dimension_key = "dt.entity.host"
  event_type                 = "ERROR_EVENT"
  summary     = "[${upper(var.environment)}] Network policy: packets dropped (possible misconfiguration)"
  description = "EKS VPC CNI is dropping packets. Check NetworkPolicy resources for recently added deny rules. Services may appear to timeout with no error in app logs."

  metadata { configuration_versions = [1] }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    threshold          = 0
    violating_samples  = 1
    dealerting_samples = 3
    samples            = 2
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "ext:kubernetes.network.policy.droppedPackets"
    resolution = "1m"
    entity_filter {
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = var.environment key = "environment"
      }
    }
  }
}
```

**Why any dropped packet is alert-worthy:**
In a correctly configured cluster, the network policy should have been reviewed before applying. Any drop that wasn't expected is either:
- A misconfigured NetworkPolicy (team accidentally denied egress to the DB)
- An attacker probing network paths that shouldn't be accessible
Either way, it deserves immediate investigation.

---

## PART 5: ALB Network Monitoring via Synthetic

The existing synthetic checks HTTP response time. Extend it with a network-layer check:

```hcl
# Extend the existing dynatrace_http_monitor in main.tf
# Add a second request step that specifically tests cross-service connectivity

resource "dynatrace_http_monitor" "connectivity_chain" {
  for_each  = var.services
  name      = "${each.key} Connectivity Chain [${var.environment}]"
  enabled   = true
  frequency = 5
  locations = var.synthetic_locations

  script {
    # Step 1: ALB → service (tests external network path)
    request {
      description = "ALB → ${each.key} health"
      method      = "GET"
      url         = each.value.health_check_url
      configuration {
        accept_any_certificate = false
        follow_redirects       = true
      }
      validation {
        rule { type = "httpStatusesList"; value = "2xx"; pass_if_found = true }
        rule { type = "patternConstraint"; value = "\"status\":\"UP\""; pass_if_found = true }
      }
      response_time_limit = each.value.latency_p99_ms * 3
    }

    # Step 2: service readiness endpoint (tests DB connectivity via Spring Actuator)
    request {
      description = "DB connectivity check via readiness"
      method      = "GET"
      url         = replace(each.value.health_check_url, "/health", "/health/readiness")
      validation {
        rule { type = "httpStatusesList"; value = "2xx"; pass_if_found = true }
        rule { type = "patternConstraint"; value = "\"db\":{\"status\":\"UP\"}"; pass_if_found = true }
      }
      response_time_limit = each.value.latency_p99_ms * 2
    }
  }

  tags {
    tag { key = "team";          value = each.value.team }
    tag { key = "environment";   value = var.environment }
    tag { key = "service";       value = each.key }
    tag { key = "monitor-type";  value = "connectivity-chain" }
  }
}
```

**Step 2 validates the DB network path:**
`/actuator/health/readiness` in Spring Boot checks all datasources. If the DB is unreachable (network failure between EKS and RDS), the readiness endpoint returns:
```json
{
  "status": "DOWN",
  "components": {
    "db": { "status": "DOWN", "details": { "error": "JDBC connection refused" } }
  }
}
```
The synthetic body validation fails → AVAILABILITY alert → immediate investigation.

---

## PART 6: AWS-Side Network Monitoring Integration

Dynatrace alone cannot see inside AWS networking primitives (VPC Flow Logs, ALB access logs). The pattern is: push AWS network data INTO Dynatrace via API.

### 6.1 VPC Flow Logs → Dynatrace via Lambda

Architecture:
```
VPC Flow Logs → CloudWatch Logs
                → CloudWatch Logs subscription filter
                → Lambda function
                → Dynatrace Metrics Ingest API (v2)
```

The Lambda parses flow log records and pushes reject counts to Dynatrace:

```python
# Lambda: vpc-flow-to-dynatrace/handler.py
import boto3, json, base64, gzip, re, urllib.request, os

DT_URL   = os.environ["DT_URL"]      # https://abc.live.dynatrace.com
DT_TOKEN = os.environ["DT_TOKEN"]    # api token with metrics.write scope

def handler(event, context):
    payload = gzip.decompress(base64.b64decode(event["awslogs"]["data"]))
    log_data = json.loads(payload)

    reject_count = 0
    for log_event in log_data["logEvents"]:
        fields = log_event["message"].split()
        # VPC Flow Log format: version account-id interface-id srcaddr dstaddr srcport dstport protocol packets bytes start end action log-status
        if len(fields) >= 13 and fields[12] == "REJECT":
            reject_count += 1

    if reject_count > 0:
        metric_line = f"custom.network.vpc_flow_rejects,environment={os.environ['ENVIRONMENT']} {reject_count}"

        req = urllib.request.Request(
            f"{DT_URL}/api/v2/metrics/ingest",
            data=metric_line.encode(),
            headers={
                "Content-Type": "text/plain",
                "Authorization": f"Api-Token {DT_TOKEN}"
            },
            method="POST"
        )
        urllib.request.urlopen(req)
```

Then add a Terraform metric event for this custom metric:
```hcl
resource "dynatrace_metric_events" "vpc_flow_rejects" {
  enabled    = true
  event_type = "ERROR_EVENT"
  summary    = "[${upper(var.environment)}] VPC Flow: REJECT traffic detected"
  description = "Security group or NACL is blocking traffic. Check for recently changed security group rules or new NetworkPolicy. Could explain connection timeouts in application logs."

  model_properties {
    type              = "STATIC_THRESHOLD"
    alert_condition   = "ABOVE"
    alert_on_no_data  = false
    threshold         = 5              # 5 rejects/min
    violating_samples = 2
    dealerting_samples = 3
    samples           = 3
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "custom.network.vpc_flow_rejects"
    resolution = "1m"
  }
}
```

**What VPC Flow REJECT records tell you:**
- Source IP trying to reach destination port that is blocked by security group
- Correlate with app logs: `Connection refused at 14:32` + VPC reject at `14:32 from 10.0.5.23 to 10.0.10.45 port 5432` = security group blocking DB port

### 6.2 ALB Access Logs → Dynatrace (connection tracking)

```bash
# CloudWatch Logs Insights query to find ALB timeout patterns
# (run in AWS console, then push interesting metrics to DT)
fields @timestamp, elb_status_code, target_status_code, request_processing_time,
       target_processing_time, response_processing_time, target_ip
| filter elb_status_code = 504 or target_status_code = "-"
| stats count() as timeout_count by bin(1min)
| sort @timestamp desc
```

---

## PART 7: Variables Extension for Network Thresholds

Add network-specific thresholds to the module's variable definition:

```hcl
# Extend terraform/modules/dynatrace/variables.tf

variable "network_thresholds" {
  description = "Per-environment network alert thresholds"
  type = object({
    tcp_retransmission_pct   = number   # % — alert if above this
    dns_failure_rate_pct     = number   # % — alert if above
    max_connections_per_proc = number   # count — alert if above
    node_throughput_bytes    = number   # bytes/sec — alert if above
  })
  default = {
    tcp_retransmission_pct   = 2.0
    dns_failure_rate_pct     = 0.5
    max_connections_per_proc = 800
    node_throughput_bytes    = 104857600   # 100MB/s
  }
}
```

Then per-environment overrides in `environments/production/main.tf`:
```hcl
module "dynatrace" {
  # ... existing config ...

  network_thresholds = {
    tcp_retransmission_pct   = 1.0      # stricter: prod traffic is customer-impacting
    dns_failure_rate_pct     = 0.1      # near-zero tolerance in production
    max_connections_per_proc = 500      # tighter: payment-service must manage connections well
    node_throughput_bytes    = 52428800 # 50MB/s — flag earlier in production
  }
}
```

---

## PART 8: How Network Issues Surface in the Full Picture

### Network signal → Davis AI root cause chain:

```
Scenario: EKS node NIC saturation (t3.medium hitting 5Gbps limit)

t=0:00  Node outbound throughput: 4.9Gbps (crosses 100MB/s threshold → DT INFO)
t=0:30  TCP retransmission: 4.2% (crosses 2% threshold → DT WARNING)
t=1:00  DNS failure rate on pods: 1.1% (DNS queries timing out)
t=1:30  payment-service error rate: 0.8% (exceeds 0.1% → HIGH)
t=2:00  payment-service P99: 1.8s (exceeds 300ms → WARNING)

Without network monitoring:
  On-call sees: error rate HIGH alert
  Looks at: traces, DB performance, JVM metrics — nothing obvious
  Time lost: 20 minutes

With network monitoring:
  Davis opens ONE Problem:
    Root cause: Host throughput saturation → TCP retransmissions
    → DNS failures on pods sharing node
    → payment-service connection timeouts
    → error rate increase
  On-call action: move payment-service pods to less-loaded node
    kubectl cordon <node>
    kubectl delete pod <payment-pod-on-saturated-node>
  Time to fix: 4 minutes
```

### Signal correlation summary:

| Network signal | Application symptom | Root cause to check |
|---------------|--------------------|--------------------|
| TCP retransmission > 2% | P99 spike, intermittent timeouts | MTU mismatch, NIC saturation, AZ congestion |
| DNS failure > 0.5% | `UnknownHostException`, random 503s | CoreDNS overloaded, pod evicted |
| Connection count > 800 | SNAT errors, connection refused | Connection pool leak, missing keep-alive |
| Node throughput > 100MB/s | All services on node slow | Batch job, misconfigured connection, data exfil |
| VPC Flow REJECT > 5/min | Connection refused, timeout | Security group change, NACL update |
| Network policy drop > 0 | Silent timeout (no error in app) | New NetworkPolicy deny rule |

---

## PART 9: Verification Commands

```bash
# ── Verify OneAgent is collecting network metrics ─────────────────────────────
# In Dynatrace UI: Infrastructure → Hosts → <node-name> → Network tab
# Should show: throughput, error rate, retransmissions in real time

# ── Check current network metrics via DT API ─────────────────────────────────
export DT_URL="https://TENANT.live.dynatrace.com"
export DT_TOKEN="dt0c01.xxxx"

# Get TCP retransmission for all hosts in production
curl -s -G "${DT_URL}/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  --data-urlencode "metricSelector=builtin:host.net.retransmission:max:splitBy(dt.entity.host)" \
  --data-urlencode "from=now-30m" \
  --data-urlencode "resolution=1m" \
  | jq '.resolution.results[] | {host: .dimensionMap["dt.entity.host"], max: (.values[-1].value // 0)}'

# Get DNS failure rate per service
curl -s -G "${DT_URL}/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  --data-urlencode "metricSelector=builtin:process.network.dnsFailureRate:avg:splitBy(process.group.name)" \
  --data-urlencode "from=now-1h" \
  | jq '.resolution.results[]'

# Get active connections per service
curl -s -G "${DT_URL}/api/v2/metrics/query" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  --data-urlencode "metricSelector=builtin:process.network.connections:sum:splitBy(process.group.name)" \
  --data-urlencode "from=now-30m" \
  | jq '.resolution.results[] | {service: .dimensionMap["process.group.name"], connections: .values[-1].value}'

# ── Verify synthetic connectivity chain tests are passing ────────────────────
curl -s -G "${DT_URL}/api/v1/synthetic/monitors" \
  -H "Authorization: Api-Token ${DT_TOKEN}" \
  | jq '.monitors[] | select(.name | contains("Connectivity Chain")) | {name, status: .enabled}'

# ── Kubernetes-side network checks ──────────────────────────────────────────
# CoreDNS health
kubectl get pods -n kube-system -l k8s-app=kube-dns
kubectl top pod -n kube-system -l k8s-app=kube-dns
# If CoreDNS memory > 80% of limit → likely DNS query overload

# Check for any NetworkPolicy in the namespace
kubectl get networkpolicy -n payment-ns
kubectl get networkpolicy -n order-ns
kubectl get networkpolicy -n notification-ns

# Check node network interface stats (from inside a debug pod)
kubectl run netdebug --image=nicolaka/netshoot --rm -it --restart=Never -- \
  ss -s
# Summary shows: TCP connections, retransmits, failed connections

# Check SNAT port usage (approximate, from CloudWatch)
aws cloudwatch get-metric-statistics \
  --namespace AWS/NATGateway \
  --metric-name PortAllocationErrorCount \
  --dimensions Name=NatGatewayId,Value=<nat-gw-id> \
  --start-time $(date -u -v-1H +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ) \
  --period 60 \
  --statistics Sum \
  --region ap-northeast-1

# ── Terraform apply for network signals ──────────────────────────────────────
cd terraform/environments/production
terraform plan -target=module.dynatrace   # preview the new metric events
terraform apply -target=module.dynatrace  # apply after production approval gate
```

---

## Quick Reference: Network Signals Added to the Module

| Signal | Metric key | Threshold | Alert type |
|--------|-----------|-----------|-----------|
| A: TCP retransmission | `builtin:host.net.retransmission` | > 2% | RESOURCE_CONTENTION |
| B: DNS failure rate | `builtin:process.network.dnsFailureRate` | > 0.5% | ERROR |
| C: Connection saturation | `builtin:process.network.connections` | > 800 | RESOURCE_CONTENTION |
| D: Cross-AZ throughput | `builtin:host.net.throughput.tx` | > 100MB/s | RESOURCE_CONTENTION |
| E: CoreDNS errors | `ext:kubernetes.coredns.dns_responses_total` | > 10/min | ERROR |
| F: Network policy drops | `ext:kubernetes.network.policy.droppedPackets` | > 0 | ERROR |
| G: VPC Flow rejects | `custom.network.vpc_flow_rejects` | > 5/min | ERROR |

Signal 8 (already in project): `builtin:host.net.errorRate` > 0.5%

Total after additions: **8 signals → network**, on top of the existing 8 application signals per service.
