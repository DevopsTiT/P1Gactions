# Glossary — All Files Deep Dive

Every term, tool, and concept from main.md. One entry per term, plain language for an SRE beginner.

---

**GitHub Actions**
CI/CD automation built into GitHub. YAML files in `.github/workflows/` define automated jobs that run when you push code, open a PR, or on a schedule. Each job runs on a fresh cloud VM. Why it matters: automates everything between "engineer pushes code" and "users get the feature."

**`on.paths` (GitHub Actions trigger filter)**
Only runs the workflow when the listed file paths change in a push or PR. If nothing under `services/payment-service/**` changed, the payment-service pipeline is completely skipped. Why it matters: prevents unrelated commits from triggering expensive build pipelines.

**`needs:` (GitHub Actions job dependency)**
Makes one job wait for another to succeed before running. `needs: test` = don't build the Docker image unless tests pass. Why it matters: the only mechanism that enforces test-before-deploy ordering.

**`environment: production` (GitHub Actions)**
A named deployment environment in GitHub that can require REQUIRED REVIEWERS. The pipeline pauses at this job and waits for a human to click Approve. Why it matters: the only human gate before any production change takes effect.

**`fail-fast: false` (matrix strategy)**
When using a matrix (parallel jobs for dev/staging/prod), prevents GitHub from cancelling the other jobs if one fails. Why it matters: you can see all 3 environment plan outputs even when one environment has an error.

**`github.sha`**
A GitHub Actions built-in variable — the 40-character git commit SHA of the triggering push. Used as the Docker image tag. Why it matters: every build gets a unique, immutable, traceable tag. Running `git show abc1234` shows exactly what code is in that image.

**`[skip ci]`**
A string in a git commit message that tells GitHub Actions not to trigger any workflows for that commit. Why it matters: CI writes updated image tags to gitops YAML files — without this, that commit re-triggers CI, causing an infinite build loop.

**`fetch-depth: 0` (actions/checkout)**
Clones the full git history instead of just the latest commit (default shallow). Why it matters: the auto-rollback script uses `git log` to find the PREVIOUS image tag — impossible with shallow clone.

**`PIPESTATUS[0]`**
Bash variable that holds the exit code of the first command in a pipe. When you do `terraform plan | tee file.txt`, `$?` gives tee's exit code (always 0). `${PIPESTATUS[0]}` gives terraform's actual exit code. Why it matters: needed for drift detection to know if terraform found drift (exit 2) vs succeeded with no changes (exit 0).

**`set +e`**
Bash command that disables automatic exit on non-zero exit codes. Why it matters: in drift detection, terraform exits with code 2 when drift is found — this is not an error, it's the expected signal. Without `set +e`, the script would abort before capturing the exit code.

**ECR (Elastic Container Registry)**
AWS's managed Docker image registry — a place to store and retrieve Docker images. Each environment (dev/staging/production) has its own ECR in a separate AWS account. Why it matters: production ECR can only be written by the production CI role — dev engineers cannot push directly to production.

**Cross-account ECR promotion**
Copying a Docker image from one AWS account's ECR to another. Requires two separate AWS credential steps (one to pull, one to push). Why it matters: the same git SHA tag travels through all 3 ECRs, proving the identical bits reach production.

**Trivy**
Open-source Docker image vulnerability scanner by Aqua Security. Checks images against CVE databases for known vulnerabilities. `exit-code: 1` = fail CI if CRITICAL or HIGH CVEs found. Why it matters: vulnerable images never reach any environment.

**`ignore-unfixed: true` (Trivy)**
Skip CVEs that have no available fix yet. Why it matters: without this, Trivy fails the build for vulnerabilities in base OS packages that cannot be patched — those are not actionable and would block all deployments.

**k6**
Open-source load testing tool. Runs a JavaScript test script with configurable concurrent users (VUs) for a set duration. `--vus 50 --duration 3m` = 50 users sending requests for 3 minutes. Why it matters: validates staging can handle real concurrent load before production promotion.

**Auto-rollback**
Logic in `verify-production`: if smoke tests fail after a deploy, a script finds the previous image tag from `git log`, reverts the gitops YAML, commits, and pushes. ArgoCD redeploys the old version. Why it matters: bad deploys are automatically undone within ~5 minutes without manual intervention.

**Terraform**
Infrastructure-as-Code tool. You describe what AWS resources you want in `.tf` files; Terraform creates/modifies/destroys them via AWS APIs. `terraform plan` shows what would change; `terraform apply` makes it real. Why it matters: infrastructure changes are version-controlled, reviewable, and reproducible.

**Terraform module**
A reusable directory of `.tf` files that can be called multiple times with different input values. The dynatrace module is called once for dev, once for staging, once for production — same logic, different thresholds. Why it matters: fix the module once → all 3 environments get the fix.

**Terraform state**
A JSON file recording every AWS/DT resource Terraform manages. Stored in S3 for team collaboration. Why it matters: without state, Terraform doesn't know what already exists and would try to create everything from scratch on every apply.

**DynamoDB state lock**
A DynamoDB record Terraform writes before any apply to prevent two simultaneous applies from corrupting state. Why it matters: two engineers applying at the same time could create conflicting resources or corrupt the state file.

**`sensitive = true` (Terraform variable)**
Prevents Terraform from printing the variable's value in plan output, logs, or `terraform show`. Why it matters: API tokens and passwords would otherwise appear in CI logs visible to all repo members.

**`for_each = {}` (zero resources pattern)**
When `for_each` receives an empty map, Terraform creates zero resources of that type. Why it matters: passing `pagerduty_integration_keys = {}` in dev creates zero PD notification resources — no `if` statements needed.

**`data` source (Terraform)**
Reads existing infrastructure without managing it. `data "aws_secretsmanager_secret_version"` reads a secret's value from Secrets Manager but does NOT create or own it. Why it matters: credentials can be read at apply time without ever being written to `.tf` files or Git.

**`jsondecode()` (Terraform)**
Parses a JSON string into a Terraform map or list. Used to read all Slack webhooks from one JSON secret (`{"payments":"https://...","orders":"https://..."}`) and convert it to a map. Why it matters: adding a new team only requires updating the JSON in Secrets Manager — no code change.

**`plan -refresh-only` (Terraform)**
Only checks what changed in real AWS vs. Terraform state — without planning config changes. Why it matters: drift detection needs to show "someone changed EKS manually" without also showing "apply my .tf files."

**`plan -detailed-exitcode` (Terraform)**
Changes exit codes: 0 = no changes, 1 = error, 2 = changes pending. Why it matters: scripts can distinguish "no drift" (0) from "drift found" (2) — a normal plan always exits 0.

**ArgoCD**
A GitOps controller for Kubernetes. Watches a Git repo and automatically applies Kubernetes YAML changes to the cluster. `selfHeal: true` reverts manual `kubectl` changes. Why it matters: the cluster always matches what's in Git — no manual `kubectl apply` needed after initial bootstrap.

**ArgoCD Application**
A Kubernetes custom resource (kind: Application) that defines what to deploy (Git path, Helm chart) and where (namespace, cluster). One Application per service per environment. Why it matters: ArgoCD manages the lifecycle of each service deployment.

**App of Apps pattern**
One root ArgoCD Application watches a folder containing other Application YAMLs. One `kubectl apply` bootstraps an entire environment. Why it matters: reduces the manual bootstrap of a full environment to a single command.

**sync-wave**
An ArgoCD annotation that controls deploy order. Lower numbers deploy first: wave -1 (namespaces) → wave 1 (networking) → wave 2 (secrets) → wave 3 (monitoring) → wave 8 (apps). Why it matters: namespaces must exist before apps; ESO must be running before DynaKube tries to fetch tokens.

**`prune: true` (ArgoCD)**
Deletes Kubernetes resources when their YAML is removed from Git. Why it matters: without prune, deleted YAMLs leave orphaned pods and secrets running forever.

**`selfHeal: true` (ArgoCD)**
Reverts manual `kubectl` changes back to what Git says within ~3 minutes. Why it matters: makes Git the enforced single source of truth — no "snowflake" cluster configurations that drift from what's in the repo.

**`ignoreDifferences` (ArgoCD)**
Tells ArgoCD to ignore specific fields when comparing cluster state to Git. Used for `spec.replicas` — HPA continuously changes it. Why it matters: without this, ArgoCD and HPA fight in an infinite loop.

**`finalizers: resources-finalizer.argocd.argoproj.io`**
Makes ArgoCD clean up all managed K8s resources before deleting the Application itself. Why it matters: without it, deleting the Application leaves all the service pods, services, and secrets running as orphans.

**Helm**
Package manager for Kubernetes. A "chart" is templates + `values.yaml`. Helm renders templates into Kubernetes YAML by substituting values. Why it matters: one chart deploys to 3 environments with different values — same templates, different sizes and settings per env.

**Helm values merging**
ArgoCD loads `values.yaml` first (production base), then `values-dev.yaml` (dev overrides). Last file wins for each key. Why it matters: dev only needs to specify what's different from production — no full duplication.

**`commonLabels` (Helm pattern)**
A map of labels rendered onto both the Deployment metadata AND every pod. Why it matters: pod-level labels are what Dynatrace OneAgent reads for auto-tagging. If labels are only on the Deployment (not pods), OneAgent never sees them.

**ExternalSecret (ESO)**
A Kubernetes custom resource that reads from AWS Secrets Manager and creates a K8s Secret. `refreshInterval: 1h` picks up rotated credentials automatically. Why it matters: DB passwords never need to be stored in Git or Kubernetes — they stay in Secrets Manager and are fetched at runtime.

**ClusterSecretStore**
An ESO resource defining how to connect to Secrets Manager (region, auth). Referenced by all ExternalSecrets in any namespace. Why it matters: one connection configuration serves all services — don't repeat credentials setup per namespace.

**ESO (External Secrets Operator)**
Controller that processes ExternalSecret resources and creates K8s Secrets. Must be running before any ExternalSecret can work. Why it matters: without ESO, ExternalSecret CRDs are just inert YAML — nothing reads them.

**IRSA (IAM Roles for Service Accounts)**
Links a Kubernetes ServiceAccount to an AWS IAM role. The pod automatically gets temporary credentials for that role. Why it matters: no AWS access keys stored in Kubernetes — credentials are automatically rotated, and each service only has the permissions it needs.

**DynaKube**
A Kubernetes custom resource defined by the Dynatrace Operator. Configures how Dynatrace is deployed in the cluster. Why it matters: the single configuration object that controls OneAgent, ActiveGate, and all DT features for the entire cluster.

**OneAgent (Dynatrace)**
A DaemonSet pod on every node that auto-instruments all JVM processes via JVMTI. Captures HTTP requests, DB queries, JVM heap, GC pauses — zero code changes. Why it matters: full application performance monitoring with no developer effort.

**JVMTI (Java Tool Interface)**
A C API that lets external agents hook into a running JVM at the bytecode level. How OneAgent instruments Spring Boot apps without any code changes. Why it matters: enables Dynatrace to capture detailed method-level performance data invisibly.

**ActiveGate (Dynatrace)**
A proxy/gateway Deployment inside the cluster. OneAgent sends data here; ActiveGate batches and forwards to the DT tenant. Also collects Kubernetes API metrics and handles log analytics. Why it matters: reduces outbound connections and handles K8s cluster monitoring.

**Dynatrace management zone**
A named filter in DT that scopes the UI and alerts to specific tagged entities. `payments-production` zone shows only services tagged `team:payments AND environment:production`. Why it matters: teams only see their own services; alerts only go to the responsible team.

**Dynatrace alerting profile**
Maps a DT problem severity to a notification channel with a delay. CRITICAL (0 min) → PagerDuty phone call. ERROR (2 min) → PagerDuty push. SLOWDOWN (5 min) → Slack. Why it matters: the right people get paged at the right urgency for the right problems.

**Dynatrace metric event**
A rule that fires an alert when a metric crosses a threshold for N minutes. 8 signals per service: traffic drop, error rate, latency P99, CPU, memory, JVM heap, pod restarts, network errors. Why it matters: proactive alerting before users complain.

**`alert_on_no_data = true`**
Fires the alert even when DT receives zero data points. Why it matters: if the service is so broken it can't send metrics at all, every other signal shows green (no data). Only this catches "silent outages."

**Traffic drop signal**
Fires when request count falls below a minimum for 3 consecutive minutes. The most important signal. Why it matters: error rate, latency, CPU, and memory all show green when traffic is zero. Only traffic drop catches DNS failures, Ingress misconfiguration, or complete service crashes.

**Latency P99**
The response time value that 99% of requests are faster than. Why it matters: average latency hides slow outliers. P99 reflects the worst experience most users have.

**µs (microseconds) vs ms (milliseconds)**
Dynatrace stores latency internally in microseconds. 1ms = 1000µs. The module multiplies all `latency_p99_ms` values by 1000. Why it matters: setting `threshold = 300` thinking "300ms" sets 300µs = 0.3ms — the alert fires on every request. The `* 1000` conversion prevents this common mistake.

**SLO (Service Level Objective)**
A measurable target like "99.9% of requests must succeed in 30 days." Why it matters: a formal contract between the service and its users — when it's met, there's no incident; when it's burning, there's urgency.

**Error budget**
The allowed failures before the SLO is missed. For 99.9%: 0.1% of requests. When the budget is burning too fast, burn rate alerts fire. Why it matters: quantifies "how much can go wrong before we breach our SLA."

**Burn rate (DT SLO)**
How fast the error budget is being consumed vs. normal. 14.4× = exhausts monthly budget in ~2 days → page immediately. 3.0× = exhausts in ~10 days → Slack warning. Why it matters: alerts you before the SLO is breached, not after.

**HTTP Synthetic monitor**
DT sends external health checks from monitoring nodes (Tokyo, Singapore) every 5 minutes. Validates HTTP 2xx AND `"status":"UP"` in the response body. Why it matters: catches "200 but DOWN" (Spring reports DOWN health but HTTP layer is fine) — pure HTTP monitoring misses this.

**JIT (Just-In-Time compiler)**
Java compiles hot methods to native machine code at runtime. Cold JVM: slow interpreted bytecode. After ~60 seconds of traffic: fast compiled code. Why it matters: explains why dev latency thresholds (2000ms) are 5-7× higher than production (300ms) — JIT needs time to warm up.

**G1GC (Garbage First Garbage Collector)**
JVM garbage collector designed for low latency. Runs incrementally to avoid long stop-the-world pauses. Pause times increase non-linearly above ~70% heap. Why it matters: the `jvm_heap_pct = 70` production alert threshold fires before G1GC degradation affects users.

**`-XX:+UseContainerSupport`**
JVM flag that reads cgroup memory limits instead of host RAM. Without it: JVM on a 64GB host sets heap to 48GB → immediately exceeds the 1Gi container limit → OOMKilled. Why it matters: without this flag, every Java pod on EKS is immediately killed.

**`-Xms` / `-Xmx`**
JVM minimum and maximum heap size. Setting Xms close to Xmx avoids heap expansion overhead during startup. Dev: Xms128m/Xmx256m. Prod: Xms512m/Xmx1024m. Why it matters: prevents latency spikes during startup as the heap grows from a tiny initial size.

**jdwp (Java Debug Wire Protocol)**
Opens a TCP port for a remote debugger to attach to a running JVM. `suspend=n` = don't wait for a debugger before running. Why it matters: allows IntelliJ/VSCode to debug a live pod via `kubectl port-forward`. `suspend=n` prevents CrashLoopBackOff (JVM won't start without it if a debugger never connects).

**startupProbe**
Kubernetes probe only active during pod startup. If it keeps failing, K8s kills and restarts the pod. Long `failureThreshold` (60-120) gives Spring Boot time to start. Why it matters: without it, the livenessProbe would kill a healthy but slow-starting JVM → endless restart loop.

**readinessProbe**
Kubernetes probe that runs continuously. When it fails, K8s removes the pod from the load balancer (no traffic). Pod is NOT restarted. Why it matters: if the DB is down, pods report not-ready → ALB stops routing to them → no 500 errors from broken pods.

**livenessProbe**
Kubernetes probe that kills and restarts the container when it fails repeatedly. Why it matters: catches truly deadlocked or frozen processes that can't be fixed without a restart.

**preStop lifecycle hook**
A command run inside the container before K8s sends the SIGTERM kill signal. `sleep 15` = wait 15 seconds. Why it matters: the ALB takes 10-15 seconds to deregister the pod — without this sleep, the pod starts shutting down while the ALB still routes traffic to it → connection resets.

**Graceful shutdown (Spring Boot)**
`server.shutdown: graceful` = when Spring receives SIGTERM, it stops accepting new requests but waits up to 30 seconds for in-flight requests to finish. Why it matters: combined with preStop sleep, ensures zero dropped requests during pod shutdown.

**PDB (PodDisruptionBudget)**
Limits how many pods can be voluntarily disrupted simultaneously. `minAvailable: 2` = at least 2 pods must survive any drain operation. Why it matters: without PDB, all 3 pods could be evicted at once during a node upgrade → outage.

**HPA (HorizontalPodAutoscaler)**
Automatically scales pod count based on CPU and memory metrics. Why it matters: handles traffic spikes automatically without manual intervention. Slow scale-down (5-minute window) prevents oscillation.

**topologySpreadConstraints**
Spreads pods across AZs. `DoNotSchedule` (hard) = pod waits in Pending rather than schedule in a crowded AZ. `ScheduleAnyway` (soft) = best-effort spread. Why it matters: without zone spread, all 3 pods could be on nodes in one AZ — an AZ failure takes down all pods.

**`readOnlyRootFilesystem: true`**
Container filesystem is read-only. Why it matters: prevents malware from writing backdoors or modifying config files. Any writable path (like `/tmp`) must be explicitly mounted as a volume.

**`capabilities.drop: [ALL]`**
Removes all Linux capabilities from the container. Why it matters: no raw sockets, no kernel modification, no privilege escalation — eliminates an entire attack surface class.

**Pod Security Standards (restricted)**
Kubernetes built-in policy enforced via namespace label. Blocks pods that run as root, use host networking, or request extra capabilities. Why it matters: even if a Helm template accidentally removes security settings, the namespace policy rejects the pod at admission.

**NAT Gateway (one per AZ)**
Allows private subnet pods to make outbound internet connections. One per AZ = if one AZ fails, other AZs keep their internet access. Why it matters: a single NAT = AZ failure cuts ALL pods in ALL AZs from the internet → deployments fail, Secrets Manager unreachable.

**S3 VPC Gateway Endpoint**
Routes S3 traffic through AWS's internal network instead of NAT Gateway — for free. Why it matters: ECR image layers are stored in S3 — every Docker pull goes through S3. Without the endpoint, pulls cost NAT Gateway data processing fees.

**IMDSv2 (`http_tokens = required`)**
Requires a session token to query EC2 instance metadata. Why it matters: without it, any process in any pod can call `http://169.254.169.254` to steal the node's IAM role credentials.

**`http_put_response_hop_limit = 2`**
Allows pods inside an EC2 instance (one network hop) to get IMDSv2 tokens for IRSA. Why it matters: if this is 1 (default), IRSA doesn't work — pods can't get AWS credentials through their ServiceAccount.

**KMS encryption (`cluster_encryption_config`)**
Encrypts Kubernetes Secrets at rest in etcd using an AWS KMS key. Why it matters: without this, Secrets are base64-encoded JSON in etcd — readable in plain text by anyone with etcd access.

**EKS subnet discovery tags**
AWS tags on subnets that EKS, ALB Controller, and Karpenter use to find the right subnets. Why it matters: without `kubernetes.io/role/internal-elb`, the ALB controller can't create internal load balancers. Without `karpenter.sh/discovery`, Karpenter can't provision new nodes.

**`domainFilters` (ExternalDNS)**
Restricts ExternalDNS to only create/modify DNS records within specific domains. Why it matters: without this, a misconfigured dev Ingress with `host: payment.company.com` would overwrite production DNS.

**`txtOwnerId` (ExternalDNS)**
A unique identifier per cluster written to TXT records alongside each DNS record to mark ownership. Why it matters: without unique IDs, one cluster's ExternalDNS might delete another cluster's DNS records, causing outages.

**SQS DLQ (Dead Letter Queue)**
A queue that receives messages that failed to process after N retries. Why it matters: notification-service smoke tests check DLQ depth — a non-empty DLQ reveals silent async failures that synchronous API checks would miss.

**`target-type: ip` (ALB Ingress annotation)**
Routes ALB directly to pod IPs, bypassing the Kubernetes ClusterIP Service. Why it matters: slightly lower latency and avoids double NAT through the Service proxy.

**Two-stage Docker build**
Build stage uses JDK (full Java development kit + Gradle to compile). Runtime stage uses JRE (runtime only — no compiler). Why it matters: final image is ~300MB smaller, no build tools in production = smaller attack surface.

**`ENTRYPOINT ["sh", "-c", "java $JVM_OPTS -jar app.jar"]`**
Shell form of ENTRYPOINT that allows environment variable expansion. Why it matters: exec form `["java", "$JVM_OPTS", "..."]` does NOT expand variables — `$JVM_OPTS` is passed literally as one argument to Java, which fails.

**eclipse-temurin:21-jdk-alpine**
The base Docker image for Java services. Temurin = production-ready OpenJDK from Eclipse Adoptium. `21` = Java LTS. `alpine` = minimal Linux. Why it matters: ~230MB base vs ~500MB for full Ubuntu JDK — smaller images pull faster and have fewer potential vulnerabilities.
