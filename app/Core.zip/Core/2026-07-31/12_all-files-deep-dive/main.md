# Every File in 8_java-3envs-dynatrace-complete — Deep Dive

> **How to read this:** Each section = one file. For each file: what it IS, what every line/block DOES, and why it EXISTS (what breaks without it). Files that are identical across environments are explained once with differences called out.

---

## Project Map — Who Reads What and When

```
Developer pushes code
        │
        ├── changed services/payment-service/** or charts/payment-service/**
        │        └── .github/workflows/payment-service-ci.yaml
        │               test → build → dev ECR → gitops/dev/ commit → ArgoCD rolling update
        │               → smoke test → staging ECR → gitops/staging/ → k6 load test
        │               → [MANUAL APPROVAL] → prod ECR → gitops/production/ → verify+rollback
        │
        ├── changed terraform/environments/** or terraform/modules/eks|vpc/**
        │        └── .github/workflows/terraform-infra.yaml
        │               plan all 3 envs in parallel on PR
        │               apply dev→staging→production sequentially on merge
        │               daily drift detection → GitHub Issue if real AWS ≠ Terraform state
        │
        ├── changed terraform/environments/dev/** or terraform/modules/dynatrace/**
        │        └── .github/workflows/terraform-dynatrace-dev.yaml
        │               plan on PR → apply on merge → DT management zones/alerts/SLOs updated
        │
        └── changed gitops/** → NOTHING (ArgoCD watches this directly, no CI needed)

Bootstrap (one-time per environment):
  kubectl apply -f gitops/<env>/bootstrap/root-app-<env>.yaml
        │
        ▼ ArgoCD syncs gitops/<env>/ recursively, in wave order:
  wave -1  gitops/<env>/namespaces/namespaces.yaml
  wave  1  gitops/<env>/networking/aws-load-balancer-controller.yaml
           gitops/<env>/networking/external-dns.yaml
  wave  2  gitops/<env>/secrets/cluster-secret-store.yaml
  wave  3  gitops/<env>/monitoring/dynatrace/dynatrace-operator.yaml
  wave  8  gitops/<env>/app/*/
```

---

## `.github/workflows/terraform-dynatrace-dev.yaml`
*(staging and production variants follow the same structure — differences noted inline)*

**What it is:** CI/CD pipeline for Dynatrace Terraform configuration. Plan on PR, apply on merge. Each environment has its own file so a dev threshold change only triggers the dev pipeline, not staging or production.

### `on:` trigger

```yaml
paths:
  - 'terraform/environments/dev/**'
  - 'terraform/modules/dynatrace/**'   ← BOTH paths listed
```

**Why both paths:**
The module (`terraform/modules/dynatrace/main.tf`) is shared by all 3 environments. If you fix a bug in the module but only trigger on `environments/dev/**`, the bug fix never reaches staging or production unless you also touch their config files. Listing both paths means: any module change triggers all 3 env pipelines simultaneously — all 3 environments pick up the fix on their next apply.

### `env:` block

```yaml
TF_VERSION:   "1.8.0"   ← pinned version — same behavior on every runner
AWS_REGION:   ap-northeast-1
WORKING_DIR:  terraform/environments/dev
```

`WORKING_DIR` is used in every step as `working-directory: ${{ env.WORKING_DIR }}`. Defined once here so it never drifts between steps.

### `plan` job

```yaml
if: github.event_name == 'pull_request'
permissions:
  id-token: write      ← required for OIDC AWS authentication
  pull-requests: write ← required to post the plan as a PR comment
```

```yaml
role-to-assume: arn:aws:iam::123456789010:role/github-actions-dynatrace-plan
```
The `plan` role has only read permissions: Secrets Manager GetSecretValue, S3 GetObject for state, DynamoDB read for lock. It cannot create, modify, or destroy anything. Even if the pipeline is compromised, `plan` jobs can't change real infrastructure.

```yaml
run: terraform plan -no-color 2>&1 | tee plan.txt
```
`2>&1` redirects stderr to stdout so error messages also appear in `plan.txt`. `tee` writes to stdout AND to the file simultaneously. `-no-color` removes ANSI escape codes that render as garbage in GitHub Actions logs.

```yaml
body: `## Dynatrace Dev Plan\n\`\`\`\n${plan.substring(0,65000)}\n\`\`\``
```
GitHub PR comments have a character limit. `substring(0,65000)` truncates to prevent the API call from failing silently for very large plans.

### `apply` job

```yaml
if: github.event_name == 'push'   ← only on merge to main, never on PRs
role-to-assume: arn:aws:iam::123456789010:role/github-actions-dynatrace-apply
```
The `apply` role has write permissions. It is only assumed on push events — a fork PR cannot trigger an apply. The plan role and apply role are separate IAM roles with different permissions.

```yaml
run: terraform apply -auto-approve -no-color
```
`-auto-approve` skips the interactive yes/no prompt (required in CI — no terminal). `-no-color` for clean logs.

**Production difference:**
```yaml
apply:
  environment: production   ← only this one line is added
```
The GitHub `environment: production` setting requires REQUIRED REVIEWERS. The pipeline pauses after merge and waits for a human to approve before `terraform apply` runs. Any Dynatrace config change in production requires explicit human sign-off.

---

## `.github/workflows/terraform-infra.yaml`

**What it is:** CI/CD for EKS + VPC + IAM Terraform — all 3 environments in ONE file. Uses a matrix strategy for parallel plans and a sequential chain for applies.

**Why one file (not 3 like Dynatrace):**
Infrastructure changes usually affect all 3 environments together (EKS version upgrade, VPC CIDR change, IAM policy update). You want to see ALL 3 plan outputs on one PR before merging. A matrix in one file achieves this. Dynatrace config changes are often environment-specific (adjust dev thresholds only) so separate files give independent triggers.

### Trigger paths

```yaml
paths:
  - 'terraform/environments/**'
  - 'terraform/modules/eks/**'
  - 'terraform/modules/vpc/**'
```
Deliberately does NOT include `terraform/modules/dynatrace/**`. If it did, every Dynatrace threshold change would trigger an EKS infrastructure plan — wasted compute, confusing PR comments showing "no infra changes" alongside a DT config change.

### Schedule trigger

```yaml
schedule:
  - cron: '0 17 * * *'   # 02:00 JST daily
```
Runs drift detection every night. 17:00 UTC = 02:00 JST — during low-traffic hours. Engineers see the GitHub Issue at the start of their workday.

### `plan` job — matrix strategy

```yaml
strategy:
  fail-fast: false   ← all 3 envs plan even if one fails
  matrix:
    env:
      - { name: dev,        account_id: "123456789010", working_dir: terraform/environments/dev }
      - { name: staging,    account_id: "123456789011", working_dir: terraform/environments/staging }
      - { name: production, account_id: "123456789012", working_dir: terraform/environments/production }
```
`fail-fast: false`: if dev plan fails, GitHub doesn't cancel staging and production plans. The reviewer can see all 3 plan outputs even when one has an error — useful for "this change breaks dev but not prod."

```yaml
- name: Terraform Validate
  run: terraform validate -no-color
```
Validates HCL syntax BEFORE running plan. Catches typos and missing required variables without making any AWS API calls. Fast fail.

```yaml
- name: Terraform Plan
  run: terraform plan -no-color -detailed-exitcode 2>&1 | tee plan.txt
```
`-detailed-exitcode`: exit code 0 = no changes, 1 = error, 2 = changes pending. Used downstream by drift detection. In the plan job it's informational only.

```yaml
const emoji = plan.includes('No changes') ? '✅' : '⚠️';
body: `## ${emoji} Infra Plan — ${env.toUpperCase()}`
```
✅ = no infrastructure changes (safe to merge). ⚠️ = something will change (reviewer must read the plan carefully).

### `apply-dev`, `apply-staging`, `apply-production` — sequential chain

```yaml
apply-staging:
  needs: apply-dev      ← only runs after dev succeeds

apply-production:
  needs: apply-staging  ← only runs after staging succeeds
  environment: production   ← manual approval gate
```
If dev apply fails (e.g., EKS version isn't available in dev), staging and production are blocked automatically. You can't accidentally apply a broken change to production when dev is broken. Production additionally requires manual approval.

### `drift-detect` job

```yaml
if: github.event_name == 'schedule'
permissions:
  issues: write   ← needed to create GitHub Issues
```

```yaml
- name: Drift Detection
  run: |
    set +e
    terraform plan -refresh-only -detailed-exitcode -no-color 2>&1 | tee drift.txt
    EXIT_CODE=${PIPESTATUS[0]}
    echo "has_drift=$([ $EXIT_CODE -eq 2 ] && echo 'true' || echo 'false')" >> $GITHUB_OUTPUT
```
`set +e`: don't exit on non-zero exit code (exit code 2 is expected when drift exists). `${PIPESTATUS[0]}` captures terraform's exit code, not tee's (which is always 0).

`-refresh-only`: only checks what changed in real AWS vs Terraform state — does NOT plan any config changes. Shows: "someone changed the EKS node group manually" without also showing "apply my .tf file changes."

```yaml
- name: Create GitHub Issue on Drift
  if: steps.drift.outputs.has_drift == 'true'
  with:
    script: |
      await github.rest.issues.create({
        title: `[DRIFT] Terraform infra drift detected in ${env}`,
        labels: ['terraform-drift', 'infrastructure', env]
      });
```
Creates a labeled GitHub Issue with the full diff in the body. Labels allow filtering: `label:terraform-drift` shows all open drift issues across all environments.

**What breaks without drift detection:** Someone modifies an EKS node group in the AWS Console — adds a node type or changes disk size. Terraform state is now wrong. Next `terraform apply` overwrites their change without warning. Drift detection catches this within 24 hours and creates an actionable issue before the next apply.

---

## `.github/workflows/payment-service-ci.yaml`
*(order-service and notification-service follow the same structure — differences noted per job)*

**What it is:** The complete deploy pipeline for payment-service — 7 jobs from code commit to production with auto-rollback.

### `env:` block

```yaml
IMAGE_TAG:      ${{ github.sha }}
ECR_DEV:        123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
ECR_STAGING:    123456789011.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
ECR_PRODUCTION: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
```

`github.sha` = the 40-character git commit SHA. Used as the image tag because:
- **Unique**: every commit produces a unique tag, never collides
- **Traceable**: `git show abc1234` shows exactly what code is running in production
- **Immutable**: the tag never changes; `:latest-dev` is also pushed as a convenience alias
- **Same bits flow through all 3 ECRs**: promoting means copying the same SHA tag from dev ECR → staging ECR → prod ECR, proving the identical image reaches production

Three separate ECR repositories in three separate AWS accounts. A dev engineer with dev account access cannot push to prod ECR — they'd need the prod IAM role which only CI has.

### Job 1: `test`

```yaml
- uses: actions/cache@v4
  with:
    path: services/payment-service/.gradle
    key: ${{ runner.os }}-gradle-payment-${{ hashFiles('services/payment-service/build.gradle') }}
    restore-keys: ${{ runner.os }}-gradle-payment-
```
Gradle dependency cache. Key includes the hash of `build.gradle` — if dependencies change, cache is invalidated and re-downloaded. `restore-keys` provides a fallback to any previous cache with the same prefix (partial hit is better than no cache).

```yaml
- name: Run tests + coverage
  run: ./gradlew test jacocoTestReport jacocoTestCoverageVerification --no-daemon
```
Three tasks in sequence:
1. `test`: run all JUnit tests
2. `jacocoTestReport`: generate XML coverage report
3. `jacocoTestCoverageVerification`: fail if line coverage < 70%

`--no-daemon`: disables the Gradle daemon (which persists between builds). Safe in CI where runners are ephemeral — a persisted daemon from a previous build could have stale state.

```yaml
- uses: mikepenz/action-junit-report@v4
  if: always()
```
`if: always()` runs this step even when tests fail. Purpose: annotate the PR diff with exactly which lines have test failures directly in the Files Changed view. Engineers see failures inline without opening build logs.

### Job 2: `build-and-deploy-dev`

```yaml
needs: test
if: github.event_name == 'push'   ← never runs on PRs
environment: dev
permissions:
  id-token: write    ← OIDC AWS auth
  contents: write    ← git push for gitops YAML update
```

```yaml
- uses: docker/build-push-action@v5
  with:
    platforms: linux/amd64,linux/arm64
    tags: |
      ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
      ${{ env.ECR_DEV }}:latest-dev
    cache-from: type=gha
    cache-to: type=gha,mode=max
```
`linux/arm64`: EKS nodes can be Graviton (ARM) for ~20% cost savings. Multi-arch = one image works on both Intel and Graviton nodes. `cache-from/cache-to: type=gha`: GitHub Actions cache for Docker layers. Unchanged layers (base JRE, dependencies) are pulled from cache instead of rebuilt — reduces build time from 5-8 min to 60-90 sec.

```yaml
- name: Trivy vulnerability scan
  uses: aquasecurity/trivy-action@master
  with:
    severity: 'CRITICAL,HIGH'
    exit-code: '1'
    ignore-unfixed: true
```
Scans the just-pushed image against CVE databases. `exit-code: 1` = fail CI if CRITICAL or HIGH CVEs found. `ignore-unfixed: true` = skip CVEs with no available fix (those are not actionable). Image never reaches any environment if it has exploitable vulnerabilities.

```yaml
- name: Update dev gitops tag
  run: |
    sed -i "s|tag: \".*\"|tag: \"${{ env.IMAGE_TAG }}\"|" \
      gitops/dev/app/payment-service/payment-service.yaml
    git config user.email "github-actions[bot]@users.noreply.github.com"
    git config user.name  "github-actions[bot]"
    git add gitops/dev/app/payment-service/payment-service.yaml
    git diff --staged --quiet || \
      git commit -m "chore(deploy-dev): payment-service=${{ env.IMAGE_TAG }} [skip ci]"
    git push
```
`sed -i "s|tag: \".*\"|tag: \"new-sha\"|"`: replaces ANY existing tag value with the new SHA. Works for both `"PLACEHOLDER"` (first deploy) and any previous SHA.

`git diff --staged --quiet || git commit`: guards against empty commits. If the tag is already the same SHA (re-running CI on the same commit), `diff` exits 0 and the `||` skips the commit. Without this guard, an empty commit would fail.

`[skip ci]`: tells GitHub Actions to NOT trigger workflows for this commit. Without it: CI commits a new tag → triggers CI again → CI commits a new tag → infinite loop.

```yaml
- name: Wait for dev rollout
  run: |
    sleep 30
    aws eks update-kubeconfig --name company-dev --alias dev
    kubectl rollout status deployment/payment-service -n payment-ns --context dev --timeout=8m
```
`sleep 30`: gives ArgoCD time to detect the gitops commit and start the rollout (ArgoCD polls every 3 minutes). `kubectl rollout status` blocks until all pods are updated or 8 minutes pass (longer = CI job would timeout). If ArgoCD fails to apply (e.g., Helm rendering error), this step fails and the smoke test never runs.

### Job 3: `smoke-test-dev`

```yaml
run: |
  curl -sf https://payment.dev.company.com/actuator/health/liveness  || exit 1
  curl -sf https://payment.dev.company.com/actuator/health/readiness || exit 1
  RESPONSE=$(curl -sf -X POST \
    -H 'Content-Type: application/json' \
    -d '{"amount":100,"currency":"JPY","userId":"smoke-test"}' \
    https://payment.dev.company.com/api/v1/payments)
  echo "$RESPONSE" | python3 -c "
  import json, sys
  d = json.load(sys.stdin)
  assert d.get('status') == 'created', f'Expected status=created, got: {d}'
  "
```
Tests two things independently:
1. **Infrastructure layer**: liveness + readiness probes via the ALB. Confirms the pod is running, the ALB is routing, ExternalDNS registered the hostname, and the cert is valid.
2. **Application layer**: a real business API call. Confirms Spring Boot started correctly, the DB connection works (payment creation hits the DB), and the business logic returns the expected response.

A deploy that breaks the DB connection would pass health checks but fail the POST assertion.

**notification-service smoke test difference:**
```yaml
# notification-service smoke test checks SQS DLQ instead of business API
DLQ_DEPTH=$(aws sqs get-queue-attributes \
  --queue-url .../notification-dlq \
  --attribute-names ApproximateNumberOfMessages \
  --query 'Attributes.ApproximateNumberOfMessages' --output text)
if [ "$DLQ_DEPTH" != "0" ]; then exit 1; fi
```
notification-service is async — `POST /api/v1/notifications` returns `{"status":"queued"}` immediately regardless of success. A non-empty DLQ means previous notifications failed silently. This catches silent async failures that a synchronous API check would miss entirely.

### Job 4: `promote-to-staging` — cross-account image copy

```yaml
# Two configure-aws-credentials steps:
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789010:role/github-actions-ecr-read  ← dev account
- uses: aws-actions/amazon-ecr-login@v2
  with: { registries: "123456789010" }

- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789011:role/github-actions-ecr-push  ← staging account
- uses: aws-actions/amazon-ecr-login@v2
  with: { registries: "123456789011" }

- name: Promote image dev → staging
  run: |
    docker pull ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
    docker tag  ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }} ${{ env.ECR_STAGING }}:${{ env.IMAGE_TAG }}
    docker push ${{ env.ECR_STAGING }}:${{ env.IMAGE_TAG }}
```
Two separate AWS credential configurations because dev and staging are in different AWS accounts. Step 1 authenticates to dev account to pull. Step 2 switches to staging account to push. The SAME SHA tag is applied — staging ECR now has the identical image that passed smoke tests in dev. No rebuild.

### Job 5: `test-staging` — k6 load test

```yaml
k6 run --vus 50 --duration 3m \
  --env BASE_URL=https://payment.staging.company.com \
  services/payment-service/tests/load/load-test.js
```
50 virtual users simultaneously sending requests for 3 minutes. The k6 script (in the repo) defines error rate and P95 latency thresholds. If either is violated, k6 exits non-zero → CI fails → production promotion is blocked.

**notification-service k6 difference:**
```yaml
k6 run --vus 20 --duration 2m   ← fewer VUs, shorter duration
```
notification-service is async — its API bottleneck is SQS throughput, not the HTTP layer. 20 VUs for 2 minutes is sufficient to validate the async pipeline works under load without over-testing an async queue.

### Job 6: `promote-to-production`

```yaml
environment: production   ← pipeline PAUSES here for human approval
```
After staging k6 passes, the pipeline stops. A senior engineer reviews the k6 results, the staging behavior, and any monitoring during the test. They click Approve in the GitHub UI. Only then does the staging→production cross-account image copy run.

### Job 7: `verify-production + auto-rollback`

```yaml
- uses: actions/checkout@v4
  with: { fetch-depth: 0 }   ← full git history needed for rollback

- name: Production smoke tests
  id: smoke
  run: |
    sleep 60   ← wait for pods to be fully ready
    curl -sf https://payment.company.com/actuator/health/liveness  || exit 1
    curl -sf https://payment.company.com/actuator/health/readiness || exit 1

- name: Auto-rollback on failure
  if: failure() && steps.smoke.outcome == 'failure'
  run: |
    git pull origin main
    PREV_TAG=$(git log --oneline -- \
        gitops/production/app/payment-service/payment-service.yaml | \
        awk 'NR==2{print $1}' | xargs git show | grep 'tag:' | head -1 | awk -F'"' '{print $2}')
    if [ -n "$PREV_TAG" ]; then
      sed -i "s|tag: \".*\"|tag: \"$PREV_TAG\"|" \
        gitops/production/app/payment-service/payment-service.yaml
      git add gitops/production/app/payment-service/payment-service.yaml
      git commit -m "chore(rollback-prod): payment-service=$PREV_TAG [skip ci]"
      git push
    fi
    exit 1
```
`if: failure() && steps.smoke.outcome == 'failure'`: only rollback if THIS SPECIFIC step failed — not if a git push earlier in the job failed (which would have a different root cause).

`git log --oneline -- <file>`: shows only commits that changed this specific file. `NR==2{print $1}`: gets the SECOND line = the commit BEFORE the current deploy. `xargs git show | grep 'tag:'`: extracts the image tag from that commit's diff. The rollback writes that previous tag back to the gitops YAML and pushes — ArgoCD detects the commit and redeploys the old version within ~3 minutes.

`exit 1` at the end: marks the job as failed even after successful rollback. The deploy failed — CI must show red, even if rollback succeeded.

**`fetch-depth: 0` explains why:** Default checkout is shallow (only latest commit). `git log` on a shallow clone only shows 1 commit. The rollback needs to find the PREVIOUS commit on that file. Full history (`fetch-depth: 0`) is required.

---

## `terraform/modules/dynatrace/variables.tf`

**What it is:** The typed contract between the module and its callers. Every value that differs per environment must be declared here. Terraform validates all inputs against these types at `terraform plan` time — before any API call.

```hcl
variable "environment" {
  type = string   # "dev" | "staging" | "production"
}
```
Used throughout `main.tf` in:
- Resource names: `"${each.value}-${var.environment}-critical"`
- Conditional resource creation: `var.environment == "production" ? local.teams : toset([])`
- DT metric event filters: `value = var.environment  key = "environment"`

```hcl
variable "dt_env_url" {
  sensitive = true
}
variable "dt_api_token" {
  sensitive = true
}
```
`sensitive = true`: Terraform never prints these values in `terraform plan` output, `terraform show`, or CI logs. Values still exist in the S3 state file (encrypted at rest by `encrypt = true` in the backend config), but are redacted from all human-readable output.

```hcl
variable "pagerduty_integration_keys" {
  type    = map(string)
  default = {}   ← dev passes this default → 0 PD resources created
}
```
The `default = {}` means if a caller doesn't pass this variable, it defaults to an empty map. But here it's used explicitly: dev/main.tf passes `pagerduty_integration_keys = {}`. Inside the module, `for_each = var.pagerduty_integration_keys` with an empty map creates **zero** PagerDuty notification resources. No `if` statements needed — empty data eliminates the resources.

```hcl
variable "services" {
  type = map(object({
    team             = string
    slo_target       = number
    health_check_url = string
    traffic_min_rps        = number
    error_rate_alert       = number
    latency_p99_ms         = number
    cpu_saturation_pct     = number
    memory_usage_pct       = number
    jvm_heap_pct           = number
    pod_restart_threshold  = number
    network_error_rate_pct = number
  }))
}
```
This typed object declaration enforces that every service entry must have ALL 11 fields. If you add a new service to `dev/main.tf` but forget `jvm_heap_pct`, Terraform validates and fails at `terraform plan` — before making any API calls. You can't ship a half-configured service.

---

## `terraform/modules/dynatrace/main.tf`

**What it is:** The single source of truth for all Dynatrace observability logic. Called once per environment with different threshold values — the module code itself never changes between environments.

### Provider + locals

```hcl
provider "dynatrace" {
  dt_env_url   = var.dt_env_url
  dt_api_token = var.dt_api_token
}

locals {
  teams = toset([for svc in values(var.services) : svc.team])
}
```

`locals.teams` deduplication: `values(var.services)` extracts the service objects. The for expression extracts each `team` field. `toset()` removes duplicates — if payment-service and payments-audit both have `team = "payments"`, you still get one management zone. This local is used by `for_each` in management zones and alerting profiles.

### Management Zones — `dynatrace_management_zone_v2`

```hcl
resource "dynatrace_management_zone_v2" "team" {
  for_each = local.teams   ← one zone per unique team
  name     = "${each.value}-${var.environment}"
```

Three rules per zone (SERVICE, PROCESS_GROUP, HOST), each with TWO conditions:
```hcl
attribute_conditions { attribute = "SERVICE_TAGS"; tag_value = "team:${each.value}" }
attribute_conditions { attribute = "SERVICE_TAGS"; tag_value = "environment:${var.environment}" }
```
Both conditions must match (AND logic). Without the `environment` condition, the "payments-production" zone would include dev payment-service pods also tagged `team:payments`. Dev noise would appear in the production zone. Both tags together ensure each zone is strictly environment-scoped.

### Alerting Profiles — 4 tiers, conditionally created

```hcl
resource "dynatrace_alerting" "critical" {
  for_each = var.environment == "production" ? local.teams : toset([])
```
Ternary: if environment is "production", iterate over teams (create 3 profiles). Otherwise iterate over empty set (create 0 profiles). No explicit `if` block needed — the data controls resource existence.

```hcl
resource "dynatrace_alerting" "high" {
  for_each = contains(["production", "staging"], var.environment) ? local.teams : toset([])
```
HIGH profiles exist in staging AND production. Staging oncall gets paged for errors so they can fix them before reaching production.

Delay rationale:
- CRITICAL: 0 min — availability loss (service completely down) is never transient
- HIGH: 2 min — filters brief error spikes during rolling deploys (new pod health checks fail for ~60-90s)
- WARNING: 5 min — confirms sustained latency, not a brief GC pause
- INFO: 15 min — CPU/heap trends take time to distinguish real pressure from bursts

### Metric Events — 8 signals

**Signal 1 — Traffic Drop:**
```hcl
locals {
  services_with_traffic = {
    for name, svc in var.services : name => svc
    if svc.traffic_min_rps > 0   ← dev sets 0 → filtered out → no traffic alert in dev
  }
}
resource "dynatrace_metric_events" "traffic_drop" {
  for_each = local.services_with_traffic
```
`traffic_min_rps = 0` in dev/main.tf → the `if` filter removes all dev services → zero traffic drop metric events created in dev. Dev services have no real users; alerting on zero traffic would fire 24/7.

```hcl
alert_on_no_data = true   ← fires even when DT receives ZERO data points
```
This is what makes traffic drop the most important signal. If the service is so broken it can't send any metrics at all (OneAgent died, network partition, Ingress misconfigured), all OTHER signals show green (no data = no bad values). Only `alert_on_no_data = true` catches this silent outage. Used only on traffic drop — other signals legitimately have no data when traffic is zero.

**Signal 3 — Latency P99:**
```hcl
threshold = each.value.latency_p99_ms * 1000   # DT uses microseconds internally
```
The most common Dynatrace mistake: Dynatrace stores all latency in microseconds (µs). If you set `threshold = 300` thinking "300ms", DT interprets it as 300µs = 0.3ms — the alert fires on every single request. The `* 1000` conversion is in the module so human-readable milliseconds can be used in the caller's `services` map.

**Signal 7 — Pod Restarts:**
```hcl
resolution = "5m"      ← 5-minute window
samples           = 1  ← only needs 1 sample
violating_samples = 1  ← fires immediately
```
A pod restart is never a transient blip — it means a crash, OOM kill, or failed readiness probe. `samples: 1, violating_samples: 1` means: as soon as one 5-minute window shows restarts above threshold, alert immediately. No waiting for confirmation.

### SLOs

```hcl
resource "dynatrace_slo_v2" "availability" {
  target_success    = each.value.slo_target       # 99.9 (prod), 95.0 (staging)
  target_warning    = each.value.slo_target - 0.1 # starts alerting 0.1% before breach
  evaluation_window = "-1M"    # rolling 30-day window
  metric_expression = <<-EOT
    100*(total_requests - error_requests) / total_requests
  EOT
  error_budget_burn_rate {
    fast_burn_threshold = 14.4   # 14.4× normal burn rate → exhausts budget in ~2 days
    slow_burn_threshold = 3.0    # 3× normal → exhausts in ~10 days
  }
}
```
Fast burn (14.4×): consuming 2% of monthly budget per hour. DT fires: "at this rate, your monthly budget is gone in 2 days." Requires immediate response. Slow burn (3.0×): consuming 10% of budget per day. Slack warning, investigate within a day. These are the Google SRE workbook standard burn rates.

### HTTP Synthetic Monitors

```hcl
validation {
  rule { type = "httpStatusesList"; value = "2xx"; pass_if_found = true }
  rule { type = "patternConstraint"; value = "\"status\":\"UP\""; pass_if_found = true }
}
```
Both rules must pass. Why validate the body too:
- Case: Spring Boot returns HTTP 200 with body `{"status":"DOWN"}` (DB is unreachable but the HTTP layer works)
- HTTP check: PASS (200 = 2xx)
- Body check: FAIL ("DOWN" ≠ "UP")
- Synthetic fails → alert fires
HTTP-only monitoring would show green. The double check catches "200 but broken."

```hcl
response_time_limit = each.value.latency_p99_ms * 3
```
If the health endpoint takes > 3× the P99 SLO to respond, the synthetic fails. Catches severe performance degradation (service is technically alive but extremely slow) even before error rates rise.

### Notifications

```hcl
resource "dynatrace_pagerduty_notification" "critical" {
  for_each = var.pagerduty_integration_keys   # {} in dev → 0 PD resources
```
Dev passes `pagerduty_integration_keys = {}` → `for_each = {}` → zero PagerDuty notification resources created in dev. Engineers never get paged for dev issues. Same empty-map pattern as alerting profiles — data controls existence, no conditional logic.

```hcl
message = "[${upper(var.environment)}] {State} | {ProblemSeverity} | {ProblemTitle} | {ProblemURL}"
```
`{State}` = OPEN or RESOLVED — resolution appears in Slack without checking DT.
`{ProblemURL}` = direct link to the DT problem. One click from Slack to full incident view.
`upper(var.environment)` = `[PRODUCTION]` vs `[dev]` — instant visual priority signal.

---

## `terraform/environments/dev/main.tf`
*(staging and production have the same structure with different values)*

**What it is:** The Terraform entry point for the dev environment. Declares state storage, authenticates to AWS, reads secrets from Secrets Manager, and calls the shared Dynatrace module with dev-specific thresholds.

### Backend — state isolation

```hcl
backend "s3" {
  bucket         = "company-terraform-state-dev"   ← dev-only bucket
  key            = "dev/terraform.tfstate"
  encrypt        = true
  dynamodb_table = "terraform-state-lock"
}
```
Separate S3 bucket per environment. Even if CI is misconfigured to run dev Terraform with wrong credentials, it cannot access the production state file — it's in a physically different bucket in a different AWS account. `dynamodb_table` locks prevent two simultaneous applies from corrupting state.

### Secrets — never hardcoded

```hcl
data "aws_secretsmanager_secret_version" "dt_api_token" {
  secret_id = "dev/dynatrace/api-token"   ← env-scoped path
}
data "aws_secretsmanager_secret_version" "slack_webhooks" {
  secret_id = "dev/dynatrace/slack-webhooks"
}
```
`data` = read-only; Terraform reads these at plan/apply time but does NOT manage them. The IAM role for dev (`github-actions-dynatrace-plan/apply`) has permission to read `dev/*` secrets only — it cannot read `production/*` secrets even in an accident.

```hcl
slack_webhook_urls = jsondecode(data.aws_secretsmanager_secret_version.slack_webhooks.secret_string)
```
The slack secret is stored as JSON: `{"payments":"https://hooks.slack.com/XXX","orders":"https://..."}`. `jsondecode()` converts it to a Terraform `map(string)`. The module's `for_each = var.slack_webhook_urls` then creates one Slack notification per team. Adding a new team only requires updating the JSON in Secrets Manager — no Terraform code change needed.

### Dev services map — why these specific values

```hcl
"payment-service" = {
  traffic_min_rps        = 0       # → module creates 0 traffic drop metric events in dev
  error_rate_alert       = 10.0    # 10%: only catastrophic failures alert
  latency_p99_ms         = 2000    # JIT not warmed on t3.medium
  jvm_heap_pct           = 85      # Xmx=256m; Spring idle fills ~70% → alert only near exhaustion
  pod_restart_threshold  = 5       # dev pods restart during active development
}
```

`traffic_min_rps = 0`: The module's `services_with_traffic` local filters out services with 0 → zero traffic drop events created. Dev has no real users; traffic alert would fire 24/7.

`latency_p99_ms = 2000`: Production payment-service on warmed m7g.xlarge: ~150ms P99. Dev on cold t3.medium: up to 2000ms on first requests (JIT interpreting bytecode). The 7× difference reflects real hardware and JIT warmup behavior, not slack.

`jvm_heap_pct = 85`: Dev Xmx=256m (from `values-dev.yaml`). Spring Boot loads at startup: security context, JPA metadata, Hibernate schema validation, auto-configuration — all in heap. Idle heap after full context load: ~180MB = 70% of 256m. Threshold at 70% would fire before writing a single line of code. 85% only fires near true exhaustion (>218MB).

**notification-service latency difference:**
```hcl
"notification-service" = {
  latency_p99_ms = 3000   # vs 2000 for payment/order
}
```
notification-service publishes to SQS. The SQS SDK client on a cold JVM requires: HTTPS connection setup + IAM credential fetch via IRSA + SQS endpoint resolution. First call on a cold t3.medium: 2-4 seconds. 3000ms threshold prevents false alerts on every pod restart in dev.

---

## `terraform/modules/eks/main.tf`

**What it is:** Creates the EKS cluster — private API endpoint, encrypted secrets, system node group with security hardening, managed add-ons.

### Private endpoint

```hcl
cluster_endpoint_private_access = true
cluster_endpoint_public_access  = false
```
The Kubernetes API server is NOT on the internet. All `kubectl` commands must come from within the VPC (via bastion host, VPN, or SSM). This eliminates brute-force attacks, credential stuffing, and public API exploits for the cluster control plane.

### System node taint

```hcl
taints = {
  dedicated = { key = "dedicated"; value = "system"; effect = "NO_SCHEDULE" }
}
labels = { "node-type" = "system" }
```
System nodes are reserved for platform pods (CoreDNS, kube-proxy, DT Operator, ESO). Application pods (payment-service) don't have the matching toleration → they cannot schedule on system nodes. Without this isolation: a payment-service memory leak could OOM the node running CoreDNS → DNS stops working → ALL services in the cluster break, not just payment-service.

### IMDSv2

```hcl
metadata_options = {
  http_tokens                 = "required"   ← IMDSv2 only
  http_put_response_hop_limit = 2
}
```
`http_tokens = "required"`: any call to EC2 instance metadata must include a session token. Without it: any process in any pod can call `http://169.254.254.169/latest/meta-data/iam/security-credentials/` and steal the node's IAM credentials.

`http_put_response_hop_limit = 2`: default is 1 (only the instance can get IMDSv2 tokens). Setting 2 allows pods inside the instance (one network hop) to get tokens for IRSA. If this is set to 1: IRSA doesn't work — pods can't get AWS credentials through their ServiceAccount.

### KMS encryption

```hcl
cluster_encryption_config = { resources = ["secrets"] }
```
Encrypts Kubernetes Secrets at rest in etcd using AWS KMS. Without this: Secrets are base64-encoded JSON in etcd — anyone with etcd read access can decode them in plain text.

---

## `terraform/modules/vpc/main.tf`

**What it is:** Creates a production-grade 3-AZ VPC for EKS — one NAT Gateway per AZ, large private subnets for pod IPs, S3 VPC endpoint, required EKS discovery tags.

### Subnet sizing

```hcl
private_subnets  = [for i, az in var.azs : cidrsubnet(var.vpc_cidr, 4, i + 16)]  # /20 → 4094 IPs
public_subnets   = [for i, az in var.azs : cidrsubnet(var.vpc_cidr, 8, i + 1)]   # /24 → 254 IPs
database_subnets = [for i, az in var.azs : cidrsubnet(var.vpc_cidr, 8, i + 100)] # /24 → 254 IPs
```
Private subnets are `/20` (4094 IPs per AZ). EKS with AWS VPC CNI assigns each pod its own VPC IP. With 3 services × 3 environments × 20 replicas max = 180 pod IPs at peak, plus Kubernetes pre-allocated ENI IPs on each node. A `/20` prevents IP exhaustion. Public subnets only need ~10 IPs (NAT Gateway, ALB) so `/24` is fine.

### One NAT per AZ

```hcl
single_nat_gateway     = false
one_nat_gateway_per_az = true
```
Cost: ~$32/month per NAT × 3 AZs = ~$96/month vs $32 for a single NAT.

**Why it's worth it:** With a single NAT in AZ-a, private subnets in AZ-b and AZ-c route all outbound traffic through AZ-a's NAT. If AZ-a fails: ALL pods in ALL AZs lose internet access → cannot pull Docker images from ECR → deployments fail → cannot reach Secrets Manager → services break. With one NAT per AZ: AZ-a failure only affects AZ-a pods. AZ-b and AZ-c continue normally.

### EKS discovery tags

```hcl
private_subnet_tags = {
  "kubernetes.io/role/internal-elb"           = "1"
  "kubernetes.io/cluster/${var.cluster_name}" = "shared"
  "karpenter.sh/discovery"                    = var.cluster_name
}
```
These tags are mandatory for EKS to function:
- `kubernetes.io/role/internal-elb`: ALB Controller reads this to find which subnets to create internal ALBs in
- `kubernetes.io/cluster/NAME: shared`: EKS control plane reads this to find worker node subnets
- `karpenter.sh/discovery`: Karpenter reads this to know which subnets to launch new nodes in

Without these tags: Ingress resources never get ALBs, and Karpenter cannot provision new nodes.

### S3 VPC Endpoint

```hcl
resource "aws_vpc_endpoint" "s3" {
  vpc_endpoint_type = "Gateway"   ← free (Gateway endpoints have no hourly charge)
  route_table_ids   = module.vpc.private_route_table_ids
}
```
Routes S3 traffic through AWS's internal network instead of NAT Gateway. ECR stores Docker image layers in S3 — all image pulls go through S3. Without this endpoint: every `docker pull` goes through NAT Gateway at $0.045/GB data processing. A 500MB image × 100 node starts/month = $2.25. At scale with many services and frequent deploys, this adds up significantly. The endpoint costs nothing.

---

## `gitops/<env>/bootstrap/root-app-<env>.yaml`

**What it is:** The ONE file you apply manually to bootstrap an entire environment. After this single `kubectl apply`, ArgoCD manages everything else automatically.

```yaml
spec:
  source:
    path: gitops/dev          ← watches this ENTIRE folder recursively
    directory:
      recurse: true
  syncPolicy:
    automated:
      prune: true             ← delete K8s resources when YAML is removed from Git
      selfHeal: true          ← revert manual kubectl changes within ~3 minutes
```

**How the App of Apps pattern works:**
```
kubectl apply -f gitops/dev/bootstrap/root-app-dev.yaml
  → Creates ONE ArgoCD Application called "root-app-dev"
  → ArgoCD scans gitops/dev/ recursively
  → Finds: namespaces.yaml, aws-load-balancer-controller.yaml, external-dns.yaml,
           cluster-secret-store.yaml, dynatrace-operator.yaml,
           payment-service.yaml, order-service.yaml, notification-service.yaml
  → Deploys ALL of them in sync-wave order
  → Any future git push to gitops/dev/ is auto-deployed
```

`prune: true`: if you delete `gitops/dev/app/payment-service/payment-service.yaml` from Git, ArgoCD deletes all Kubernetes resources that Application managed. Without prune: deleted YAMLs leave orphaned pods, services, and secrets running indefinitely (wasted cost, potential security risk).

`selfHeal: true`: if an engineer runs `kubectl edit deployment payment-service` and changes the replica count, ArgoCD reverts it back to what Git says within ~3 minutes. Git is the ONLY source of truth. This is what makes GitOps real — manual changes don't stick.

`finalizers: resources-finalizer.argocd.argoproj.io`: when you delete the Application itself, ArgoCD first deletes all K8s resources it managed, then removes the finalizer. Without this: deleting the Application leaves all resources running as orphans.

**Difference between environments:** Only the `name`, `path`, and destination cluster differ between root-app-dev, root-app-staging, and root-app-production. All use `prune: true` and `selfHeal: true`.

---

## `gitops/<env>/namespaces/namespaces.yaml`

**What it is:** An ArgoCD Application (sync-wave -1) that deploys the `charts/namespaces` Helm chart, creating all Kubernetes namespaces with the labels Dynatrace needs for auto-tagging.

```yaml
annotations:
  argocd.argoproj.io/sync-wave: "-1"   ← deploys BEFORE everything else
```
Wave -1 is the first thing ArgoCD deploys. Every other resource is deployed INTO a namespace. If namespaces were in wave 1 (same as ALB controller), they might race and the ALB controller would fail with "namespace kube-system not found" or "namespace dynatrace not found."

```yaml
helm:
  values: |
    environment: dev
    namespaces:
      - name: payment-ns
        labels: { team: payments, environment: dev }
      - name: order-ns
        labels: { team: orders, environment: dev }
```

**Why these labels are the most critical part of the entire monitoring setup:**
```
1. Pod starts in payment-ns
2. OneAgent (DaemonSet on the node) reads Kubernetes metadata for the pod
3. OneAgent sees: namespace has labels team=payments, environment=dev
4. DT auto-tagging rule (configured once in DT UI):
     "if Kubernetes namespace label 'team' exists → apply tag team:<value> to entity"
     "if Kubernetes namespace label 'environment' exists → apply tag environment:<value>"
5. payment-service entity in DT gets tags: team:payments, environment:dev
6. Management zone "payments-dev" rule: SERVICE where tag team:payments AND environment:dev
7. payment-service appears in the payments team's dev zone
8. Alerting profiles scoped to this zone → Slack #alerts-payments gets the alert

If labels are missing:
  → auto-tagging doesn't fire
  → entity appears in NO zone
  → NO alerts fire for this service (silent monitoring gap)
This is the #1 silent failure mode in Dynatrace + Kubernetes setups.
```

**`pod-security.kubernetes.io/enforce: restricted` (on the application namespaces):**
Kubernetes built-in policy. Rejects any pod that runs as root, uses host networking, or requests extra Linux capabilities. The Deployment's `runAsNonRoot: true`, `allowPrivilegeEscalation: false`, and `capabilities.drop: [ALL]` exist to satisfy this policy — without them the pod is rejected at admission by the API server.

---

## `gitops/<env>/networking/aws-load-balancer-controller.yaml`

**What it is:** ArgoCD Application (sync-wave 1) that installs the AWS Load Balancer Controller from its official Helm chart.

```yaml
annotations:
  argocd.argoproj.io/sync-wave: "1"   ← after namespaces, before apps
```
Must be deployed before wave 8 (applications). When ArgoCD applies the payment-service Ingress at wave 8, the ALB controller must already be running to process it. Without the controller: Ingress resources are applied but the controller sees nothing to act on — no ALB is ever created, service is unreachable.

```yaml
helm:
  values: |
    clusterName: company-dev
    serviceAccount:
      annotations:
        eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-aws-load-balancer-controller
    replicaCount: 1   # dev: 1 replica
```
IRSA annotation: the ALB controller pod has an IAM role that allows it to call `ec2:CreateLoadBalancer`, `elasticloadbalancing:*`, etc. Without this role, the controller can't call AWS APIs → Ingress stays Pending forever.

**Production difference:** `replicaCount: 2` for HA. ALB controller restart takes ~30 seconds — during that window, no new Ingresses are processed (existing ALBs keep working, but Ingress changes don't take effect). Two replicas eliminate this window.

---

## `gitops/<env>/networking/external-dns.yaml`

**What it is:** ArgoCD Application (sync-wave 1, parallel with ALB controller) that installs ExternalDNS — watches Ingress resources and automatically creates/deletes Route53 DNS records.

```yaml
domainFilters:
  - dev.company.com   # dev
  # staging: staging.company.com
  # production: company.com
```
**Critical safety setting.** ExternalDNS only modifies Route53 records within this domain. Without `domainFilters`: a misconfigured dev Ingress with `host: payment.company.com` would overwrite the production DNS record. With the filter: dev ExternalDNS can only create `*.dev.company.com` — it is physically unable to touch production DNS.

```yaml
txtOwnerId: "company-dev"   # staging: "company-staging", prod: "company-prod"
```
ExternalDNS creates TXT records alongside each A record to mark ownership. If staging ExternalDNS sees a Route53 A record without a matching TXT `company-staging` ownership record, it leaves it alone — it's owned by a different cluster. Without unique `txtOwnerId` per cluster: one cluster's ExternalDNS might delete another cluster's DNS records, causing outages.

```yaml
policy: sync   # creates AND deletes DNS records
```
`sync` means: when you delete an Ingress, ExternalDNS also deletes the Route53 record. Alternative `upsert-only` only creates/updates — safer but leaves orphan DNS records after service deletion. `sync` + `domainFilters` is the correct safe combination: full lifecycle management within its own domain, touching nothing outside.

---

## `gitops/<env>/secrets/cluster-secret-store.yaml`

**What it is:** Two resources in one file — the ESO Helm installation (ArgoCD Application) AND the ClusterSecretStore configuration (how ESO connects to Secrets Manager).

### Resource 1: ESO ArgoCD Application

```yaml
annotations:
  argocd.argoproj.io/sync-wave: "2"   ← after namespaces, before DynaKube
```
Wave 2 is critical. The DynaKube ExternalSecret (wave 3) needs ESO running to process it. If ESO were wave 3 or later: the DynaKube ExternalSecret is applied but nothing reads it → the K8s Secret "dynakube" is never created → DT Operator can't authenticate → OneAgent never starts.

```yaml
serviceAccount:
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-eso
```
ESO uses IRSA — the ESO pod's ServiceAccount is annotated with an IAM role. When ESO calls Secrets Manager, AWS automatically provides temporary credentials for that role. No AWS credentials stored in Kubernetes anywhere.

### Resource 2: ClusterSecretStore

```yaml
apiVersion: external-secrets.io/v1beta1
kind: ClusterSecretStore
metadata:
  name: aws-secrets-manager   ← this name is referenced by every ExternalSecret
spec:
  provider:
    aws:
      service: SecretsManager
      region: ap-northeast-1
      auth:
        jwt:
          serviceAccountRef:
            name: external-secrets
            namespace: external-secrets
```
This tells ESO: "to fetch secrets, connect to AWS Secrets Manager in ap-northeast-1, and authenticate using the IRSA credentials of the `external-secrets` ServiceAccount." Every ExternalSecret in any namespace references this store by name (`secretStoreRef: name: aws-secrets-manager`). ClusterSecretStore is cluster-scoped — one store serves all namespaces. A namespace-scoped SecretStore would require one per namespace.

---

## `gitops/<env>/monitoring/dynatrace/dynatrace-operator.yaml`

**What it is:** Three Kubernetes resources in one file — the DT Operator Helm installation, the ExternalSecret that fetches DT API tokens, and the DynaKube configuration. All in sync-wave 3.

### Resource 1: DT Operator ArgoCD Application

```yaml
annotations:
  argocd.argoproj.io/sync-wave: "3"
helm:
  values: |
    installCRD: true   ← installs DynaKube CRD definition
```
`installCRD: true`: the DynaKube custom resource (third resource in this file) can only be applied after its CRD is installed. ArgoCD applies resources in wave 3 simultaneously, but Kubernetes processes CRD creation before CR creation within the same wave. Without `installCRD: true`: "no kind 'DynaKube' is registered" error.

### Resource 2: ExternalSecret for DT tokens

```yaml
spec:
  target:
    name: dynakube          ← creates K8s Secret with THIS exact name
    creationPolicy: Owner   ← deletes Secret when ExternalSecret is deleted
  data:
    - secretKey: apiToken
      remoteRef: { key: dev/dynatrace/api-token }
    - secretKey: dataIngestToken
      remoteRef: { key: dev/dynatrace/paas-token }
```
**Why two tokens (not one):**
```
apiToken:        DT REST API access. Used by the Operator to register the cluster,
                 create ActiveGate tokens, read entity metadata.
                 Scopes: activeGateTokenManagement.create, entities.read, settings.write
                 
dataIngestToken: Data ingestion. Used by OneAgent to push metrics, traces, logs.
                 Scopes: dataIngest, metrics.ingest, logs.ingest
                 
Separation matters: if `dataIngestToken` is compromised (e.g., extracted from a pod),
  the attacker can push fake metrics but CANNOT read entity data or change DT settings.
  `apiToken` exposure is much more dangerous — keep them separate and scope minimally.
```

`creationPolicy: Owner`: when the ExternalSecret is deleted (e.g., via ArgoCD prune), the K8s Secret "dynakube" is also deleted automatically. No stale credentials persisting after the monitoring stack is removed.

### Resource 3: DynaKube

```yaml
spec:
  apiUrl: https://PLACEHOLDER.live.dynatrace.com/api   ← replace with real tenant URL
  tokens: dynakube     ← points to the K8s Secret created by ExternalSecret above
  
  classicFullStack:
    enabled: true
    tolerations:
      - key: node-role.kubernetes.io/control-plane
        operator: Exists
        effect: NoSchedule
```
`classicFullStack: enabled: true`: deploys OneAgent as a **DaemonSet** — one pod per node. The toleration allows OneAgent to run on control-plane nodes (which normally repel workloads via taint). Without the toleration: control-plane nodes are not monitored.

**What OneAgent does on each node:**
```
1. Hooks into every JVM process via JVMTI (Java Tool Interface — C API into the JVM)
   → auto-instruments: HTTP request count/duration, DB query time, JVM heap, GC pauses
   → zero application code changes required

2. Reads /proc/<pid>/... for process-level CPU and memory RSS

3. Reads container logs from /var/lib/docker/containers/*.log
   → sent to DT log analytics (because logMonitoring.enabled: true)

4. Sends everything to ActiveGate (not directly to DT tenant)
   → reduces outbound connections from N (one per node) to 1-2 (one per ActiveGate)
```

**ActiveGate — dev vs production:**
```yaml
# dev:
activeGate:
  replicas: 1
  
# production:
activeGate:
  replicas: 2
  topologySpreadConstraints:
    - maxSkew: 1
      topologyKey: topology.kubernetes.io/zone
      whenUnsatisfiable: DoNotSchedule   ← HARD: never put both ActiveGates in same AZ
```
Dev: 1 ActiveGate replica. If it dies, DT loses metrics for ~2-3 minutes (pod restart time). Acceptable in dev — no SLA.

Production: 2 ActiveGate replicas spread across 2 different AZs. If AZ-a fails: AZ-b's ActiveGate continues forwarding metrics to DT. No monitoring gap during AZ failure. Without this: an AZ failure causes a complete monitoring blackout — all SLO burn rates show flat (no data = no bad data = false green).

**`capabilities: [routing, kubernetes-api-monitoring, log-analytics]`:**
- `routing`: ActiveGate proxies data from OneAgent to DT tenant. Reduces outbound connections.
- `kubernetes-api-monitoring`: ActiveGate calls the K8s API to collect pod counts, deployment health, namespace quotas → populates K8s workloads view in DT.
- `log-analytics`: receives container logs from OneAgent and ships to DT. Required for log monitoring to actually work even when `logMonitoring.enabled: true` is set.

---

## `gitops/<env>/app/<service>/<service>.yaml`

**What it is:** The ArgoCD Application for each service in each environment. CI updates the `tag:` field in this file on every deploy.

```yaml
annotations:
  argocd.argoproj.io/sync-wave: "8"   ← last — all infra must be ready first
```
Wave 8 ensures: namespaces exist, ALB controller is running, ExternalDNS is running, ESO is running (so ExternalSecret can create DB credentials), DynaKube is running (so OneAgent instruments the pod immediately on start).

```yaml
spec:
  project: payments   ← ArgoCD Project scoping
  source:
    path: charts/payment-service
    helm:
      valueFiles:
        - values.yaml         ← base (production defaults)
        - values-dev.yaml     ← dev overrides (only in dev)
      values: |
        image:
          repository: 123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
          tag: "PLACEHOLDER"   ← CI replaces this with github.sha
        serviceAccount:
          annotations:
            eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-payment-service
```

**How CI updates the tag:**
```bash
sed -i "s|tag: \".*\"|tag: \"${{ env.IMAGE_TAG }}\"|" \
  gitops/dev/app/payment-service/payment-service.yaml
git commit -m "chore(deploy-dev): payment-service=abc1234 [skip ci]"
git push
```
ArgoCD polls the repo every 3 minutes. When it detects the commit: re-renders the Helm chart with the new tag → creates a rolling update → new pod starts → passes probes → old pod terminates.

**Production difference — `valueFiles: [values.yaml]` only:**
Production IS the base values file. No override file needed. The inline `values:` block overrides just ECR repository, IRSA role, hostname, and ACM cert ARN — things that differ per environment but aren't in any values file.

**`ignoreDifferences` — the HPA fight prevention:**
```yaml
ignoreDifferences:
  - group: apps
    kind: Deployment
    jsonPointers: [/spec/replicas]
```
HPA continuously changes `spec.replicas` based on CPU load. Without this: ArgoCD sees "Git says 3 replicas, cluster has 7 (HPA scaled up)" → reverts to 3 → HPA scales back to 7 → reverts to 3 → infinite fight. `ignoreDifferences` tells ArgoCD: replicas are managed by HPA, don't touch them. All other fields are still enforced by ArgoCD.

---

## `charts/namespaces/templates/namespace.yaml`

**What it is:** A Helm template that creates one Kubernetes Namespace resource per entry in the `namespaces` list.

```yaml
{{- range .Values.namespaces }}
apiVersion: v1
kind: Namespace
metadata:
  name: {{ .name }}
  labels:
    {{- toYaml .labels | nindent 4 }}
---
{{- end }}
```
The `---` separator between manifests is required — without it, Kubernetes YAML parsing combines all namespaces into one invalid document. `{{- range }}` loops. `toYaml .labels | nindent 4` converts the labels map to YAML and indents it 4 spaces to match the `metadata:` block structure.

This template is called differently per environment via the ArgoCD Application's inline `values:` — dev passes `environment: dev` and labels with `environment: dev`. Production passes `environment: production`. Same template, different input data.

---

## `charts/<service>/Chart.yaml`

**What it is:** Helm metadata — chart name, version, description, maintainers. Required for Helm to recognize the directory as a chart.

```yaml
apiVersion: v2
name: payment-service
version: 1.0.0     ← chart version (not application version)
appVersion: "1.0.0"  ← informational only — actual app version is the image tag
```
The chart `version` should be incremented when the chart templates themselves change (breaking Helm changes). `appVersion` is cosmetic — the actual deployed version is always tracked by the Docker image tag in the ArgoCD Application YAML.

---

## `charts/<service>/values.yaml` (production defaults)

**What it is:** The base Helm values — production-grade defaults that all environments start from.

```yaml
replicaCount: 3    ← 1 pod per AZ across 3 AZs
```
With `topologySpreadConstraints.whenUnsatisfiable: DoNotSchedule` (production), pods MUST spread across 3 AZs. If one AZ has no healthy nodes, the third pod stays Pending until Karpenter provisions a new node. Trade-off: maximum AZ resilience at the cost of scheduling flexibility during AZ issues.

```yaml
image:
  tag: "PLACEHOLDER"   ← CI replaces this, ArgoCD uses the inline values override
  pullPolicy: IfNotPresent   ← use cached image if already present on node
```
`IfNotPresent` in production because the tag is a unique git SHA — if the image is already on the node, there's no reason to re-pull the same bits. Dev uses `Always` because `:latest-dev` always points to the newest build.

```yaml
- name: JVM_OPTS
  value: >-
    -Xms512m -Xmx1024m
    -XX:+UseContainerSupport
    -XX:MaxGCPauseMillis=200
    -XX:+UseG1GC
```
`-Xms512m`: JVM starts with 512MB heap pre-allocated. Without this, JVM starts at ~64MB and must grow to 1024MB through multiple GC cycles → latency spikes during startup as the heap expands. Setting Xms close to Xmx eliminates heap expansion overhead.

`-XX:MaxGCPauseMillis=200`: G1GC hint — try to keep pauses under 200ms. G1GC adjusts region sizes and GC frequency to meet this. Direct impact on P99 latency.

`-XX:+UseContainerSupport`: reads cgroup memory limits (the container limit) instead of host RAM. Without it: JVM on a 64GB host sets heap to 48GB → immediately exceeds the 1Gi container limit → OOMKilled before serving a single request.

```yaml
pdb:
  enabled: true
  minAvailable: 2   ← at least 2 pods must survive any voluntary disruption
```
PDB prevents Kubernetes from evicting all pods simultaneously during node drains. With `minAvailable: 2` and 3 replicas: at most 1 pod can be disrupted at a time. Karpenter node consolidation and `kubectl drain` both respect this — no downtime during infrastructure maintenance.

```yaml
topologySpreadConstraints:
  - whenUnsatisfiable: DoNotSchedule   ← HARD in production
```
Hard zone spread: pod waits in Pending rather than schedule in a zone that already has too many pods. This enforces the 3-AZ HA guarantee at the cost of potential Pending pods during AZ issues.

```yaml
lifecycle:
  preStop:
    exec:
      command: ["/bin/sh", "-c", "sleep 15"]
terminationGracePeriodSeconds: 60
```
Shutdown sequence:
1. K8s removes pod from Service endpoints (ALB stops routing here) — takes 10-15 seconds
2. `preStop` runs: sleep 15s (in-flight requests from before ALB deregistered can finish)
3. SIGTERM sent: Spring Boot starts graceful shutdown (stops accepting new requests, waits up to 30s for in-flight)
4. Container terminates

Without `preStop`: ALB may still route requests to the pod for 10-15 seconds after SIGTERM → connection resets on those in-flight requests.

---

## `charts/<service>/values-dev.yaml` (dev overrides)

```yaml
replicaCount: 1
image:
  pullPolicy: Always   ← always pull; latest-dev tag always points to newest build
```
`pullPolicy: Always`: dev image tag is often `:latest-dev` — `IfNotPresent` would serve a cached old image even when a new one was pushed (the tag name hasn't changed). `Always` forces a pull on every pod start, ensuring dev always runs the latest code.

```yaml
- name: JVM_OPTS
  value: >-
    -Xms128m -Xmx256m
    -XX:+UseContainerSupport
    -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005
```
`-Xmx256m`: t3.medium has 4GB RAM total. With 3 services × 1 pod each, each pod gets a 512Mi memory limit. 256m heap + JVM non-heap (~120MB) + OS = within limits.

`jdwp` remote debugger: opens TCP port 5005 for IntelliJ/VSCode to attach a remote Java debugger to the running pod (`kubectl port-forward` to reach it). `suspend=n` is critical — without it, the JVM waits indefinitely for a debugger before running ANY code → pod never passes `startupProbe` → CrashLoopBackOff.

```yaml
startupProbe:
  failureThreshold: 120   # 20 min (dev) vs 60 (10 min in production)
```
Dev t3.medium + expired Docker layer cache = image pull (~200MB) + Spring Boot start (~90 seconds). 10 minutes is not enough. 20 minutes gives a realistic worst-case buffer.

```yaml
pdb:
  enabled: false   ← 1 replica + PDB = node drain blocked forever
```
With only 1 pod and `minAvailable: 2`, Kubernetes can never drain the node (draining would leave 0 pods = below `minAvailable: 2`). The drain would block forever. Dev has no SLA, no need for disruption protection — `pdb: enabled: false` prevents this deadlock.

```yaml
topologySpreadConstraints:
  - whenUnsatisfiable: ScheduleAnyway   ← SOFT in dev/staging
```
Dev clusters may have only 1-2 nodes. A hard zone constraint would prevent ALL pods from scheduling if the cluster doesn't have nodes in all 3 AZs. `ScheduleAnyway` schedules even if zone spread can't be achieved — dev functionality over resilience.

---

## `charts/<service>/values-staging.yaml` (staging overrides)

```yaml
replicaCount: 2
- name: JVM_OPTS
  value: >-
    -Xms256m -Xmx512m   ← medium between dev (256m) and prod (1024m)
```
Must survive k6 load test (50 VUs). 512m heap: at peak k6 load, heap fills to ~78% = ~400MB. The Dynatrace `jvm_heap_pct = 78` threshold in `terraform/environments/staging/main.tf` is calibrated to this — fires if k6 causes more than normal heap usage (potential memory leak).

```yaml
hpa:
  minReplicas: 2
  maxReplicas: 8   ← k6 50 VUs may trigger scale-out
pdb:
  enabled: true
  minAvailable: 1   ← 2 replicas: at most 1 disrupted
```
PDB is enabled in staging (unlike dev) because staging must simulate production behavior. But `minAvailable: 1` vs production's `minAvailable: 2` — staging can tolerate more disruption.

---

## `charts/<service>/templates/deployment.yaml`

**What it is:** The Kubernetes Deployment — the most detailed template. Renders differently per environment based on values.

```yaml
spec:
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 0   ← never terminate old pod before replacement is Ready
      maxSurge: 1         ← allow 1 extra pod temporarily during update
```
`maxUnavailable: 0` = zero-downtime deployments. The sequence: new pod created → passes startupProbe → passes readinessProbe (K8s knows it's ready) → added to Service endpoints → old pod removed from Service → old pod receives SIGTERM. At no point are there fewer than N ready pods serving traffic.

### Security contexts

```yaml
spec.securityContext:
  runAsNonRoot: true    ← K8s rejects the pod if image tries to run as root
  runAsUser: 1000       ← matches appuser created in the Dockerfile
  fsGroup: 1000         ← files in mounted volumes owned by this GID

container.securityContext:
  readOnlyRootFilesystem: true    ← container filesystem is read-only
  allowPrivilegeEscalation: false ← sudo/setuid impossible inside container
  capabilities:
    drop: ["ALL"]                 ← no raw sockets, no kernel modification
```
These settings satisfy the `pod-security.kubernetes.io/enforce: restricted` namespace policy. If ANY of these are missing, the pod is rejected by Kubernetes before it even starts. The namespace policy acts as a backstop — even if someone removes the security context from the Helm template, the policy blocks it.

`readOnlyRootFilesystem: true` + the `/tmp` emptyDir volume:
```yaml
volumes:
  - name: tmp
    emptyDir: {}   # not shown in this project but required if JVM writes heap dumps
```
The JVM needs `/tmp` for heap dumps (`-XX:+HeapDumpOnOutOfMemoryError`). `readOnlyRootFilesystem: true` would block this without an explicit writable volume mount.

### Probes

```yaml
startupProbe:
  httpGet: { path: /actuator/health/liveness, port: 8080 }
  failureThreshold: 60    # 600 seconds = 10 minutes (production)
  periodSeconds: 10
```
Only runs during startup. If it keeps failing for 10 minutes, K8s kills and restarts the pod. Gives Spring Boot (slow JVM startup + DB connection pool warmup) time to fully start before the liveness probe kicks in. Without startupProbe: the liveness probe would kill a healthy pod that's simply taking longer to start → endless restart loop.

```yaml
readinessProbe:
  httpGet: { path: /actuator/health/readiness, port: 8080 }
  periodSeconds: 5
  failureThreshold: 3   # 15 seconds of failures → remove from load balancer
```
When this fails: K8s removes the pod from Service endpoints (ALB stops routing to it). The pod is NOT restarted. When it passes again, traffic resumes. Checks `/actuator/health/readiness` — Spring Boot reports DOWN if DB is unreachable. During a DB outage: all pods go "not ready" → ALB returns 503 with no backends → no individual 500 errors from broken pods.

```yaml
livenessProbe:
  httpGet: { path: /actuator/health/liveness, port: 8080 }
  periodSeconds: 15
  failureThreshold: 3   # 45 seconds of failures → kill and restart
```
Kills truly deadlocked/stuck processes. Higher threshold than readiness (45s vs 15s) so transient GC pauses or momentary DB blips don't cause pod restarts.

### The `commonLabels` pattern

```yaml
metadata:
  labels:
    app: payment-service
    {{- range $k, $v := .Values.commonLabels }}
    {{ $k }}: {{ $v }}
    {{- end }}
spec:
  template:
    metadata:
      labels:
        app: payment-service
        {{- range $k, $v := .Values.commonLabels }}
        {{ $k }}: {{ $v }}    ← SAME labels on pods too
        {{- end }}
```
`commonLabels` in dev values: `{ team: payments, environment: dev, app: payment-service }`. These labels appear on BOTH the Deployment metadata AND every pod. Only pod-level labels are visible to:
- OneAgent (for DT auto-tagging → management zones)
- Service selectors
- NetworkPolicy selectors
- HPA label matchers
The same `range` block in both places ensures they never drift.

---

## `charts/<service>/templates/external-secret.yaml`

**What it is:** An ESO ExternalSecret that reads DB credentials from AWS Secrets Manager and creates a Kubernetes Secret. The Deployment mounts it via `envFrom.secretRef`.

```yaml
spec:
  refreshInterval: 1h   ← re-reads from Secrets Manager every hour
  secretStoreRef:
    name: aws-secrets-manager   ← references the ClusterSecretStore
  target:
    name: payment-service-db-credentials   ← name of the K8s Secret to create
    creationPolicy: Owner
  data:
    - secretKey: DB_HOST
      remoteRef:
        key: {{ .Values.commonLabels.environment }}/payment-service/db-credentials
        property: host
```

**The environment-scoped secret path:**
`{{ .Values.commonLabels.environment }}` = "dev" / "staging" / "production". The secret path becomes:
- dev: `dev/payment-service/db-credentials`
- staging: `staging/payment-service/db-credentials`
- production: `production/payment-service/db-credentials`

Each environment reads from its OWN Secrets Manager secret in its OWN AWS account. Dev pods cannot accidentally use production DB credentials — even if the IRSA role allowed access across accounts (it doesn't), the path is different.

`refreshInterval: 1h`: AWS Secrets Manager supports automatic credential rotation. When the DB password rotates, ESO re-reads from Secrets Manager within 1 hour and updates the K8s Secret. HikariCP (Spring Boot's connection pool) validates connections on next use and reconnects with new credentials. No pod restart needed for credential rotation.

**notification-service difference:**
```yaml
data:
  - secretKey: SMTP_HOST
    remoteRef: { key: .../notification-service/credentials; property: smtp_host }
  - secretKey: SNS_TOPIC_ARN
    remoteRef: { key: .../notification-service/credentials; property: sns_topic_arn }
```
notification-service uses SMTP + SNS credentials, not DB credentials. Different secret path, different keys — but same ExternalSecret mechanism.

---

## `charts/<service>/templates/hpa.yaml`

```yaml
metrics:
  - type: Resource
    resource:
      name: cpu
      target: { type: Utilization, averageUtilization: {{ .Values.hpa.targetCPUUtilizationPercentage }} }
  - type: Resource
    resource:
      name: memory
      target: { type: Utilization, averageUtilization: 80 }
```
Both CPU and memory drive scaling. Memory target is hardcoded at 80% — useful for Java where heap pressure can cause slowdowns before CPU rises.

```yaml
behavior:
  scaleDown:
    stabilizationWindowSeconds: 300   ← wait 5 min before scaling down
    policies:
      - type: Pods; value: 1; periodSeconds: 60   ← remove at most 1 pod per minute
  scaleUp:
    policies:
      - type: Pods; value: 3; periodSeconds: 60   ← add up to 3 pods per minute
```
Asymmetric scaling: scale up fast (3 pods/min), scale down slow (1 pod/min, 5-minute window). This prevents oscillation during traffic spikes — you don't want to scale down immediately after a burst only to need to scale back up 60 seconds later. The slow scale-down trades slightly higher cost for stability.

---

## `charts/<service>/templates/pdb.yaml`

```yaml
{{- if .Values.pdb.enabled }}   ← conditional — dev sets enabled: false
apiVersion: policy/v1
kind: PodDisruptionBudget
spec:
  minAvailable: {{ .Values.pdb.minAvailable }}   # 2 (prod), 1 (staging)
  selector:
    matchLabels:
      app: payment-service
{{- end }}
```
The `{{- if .Values.pdb.enabled }}` means: dev passes `pdb.enabled: false` → this entire template renders as nothing → no PDB resource is created. With 1 replica in dev, a PDB of `minAvailable: 2` would block node drains forever.

**When PDB matters in production:**
```
EKS node upgrade (kubectl drain):
  Without PDB: Kubernetes evicts all 3 pods on the node simultaneously → downtime
  With PDB(min=2): Can evict 1 pod at a time; waits for replacement before evicting next

Karpenter consolidation (replace 3 m5.large with 1 m5.xlarge for cost):
  Without PDB: Karpenter evicts all 3 pods at once → downtime
  With PDB(min=2): Karpenter drains one node, waits for pod reschedule → zero downtime
```

---

## `charts/<service>/templates/ingress.yaml`

```yaml
{{- if .Values.ingress.enabled }}
metadata:
  annotations:
    alb.ingress.kubernetes.io/scheme: internet-facing
    alb.ingress.kubernetes.io/target-type: ip
    alb.ingress.kubernetes.io/certificate-arn: {{ .Values.ingress.certArn }}
    alb.ingress.kubernetes.io/ssl-redirect: "443"
    alb.ingress.kubernetes.io/healthcheck-path: /actuator/health/readiness
    alb.ingress.kubernetes.io/healthcheck-interval-seconds: "15"
spec:
  ingressClassName: alb
```
These annotations are read by the AWS Load Balancer Controller (wave 1). When ArgoCD applies this Ingress, the controller calls AWS APIs to create an ALB with:
- `internet-facing`: public ALB reachable from the internet
- `target-type: ip`: routes directly to pod IPs (bypasses the ClusterIP Service for slightly lower latency)
- `certificate-arn`: TLS cert from ACM — the ALB terminates HTTPS
- `ssl-redirect: 443`: HTTP → HTTPS redirect on the ALB (before reaching pods)
- `healthcheck-path: /actuator/health/readiness`: ALB sends health checks to this path every 15 seconds; unhealthy targets are removed from routing

`healthcheck-path` uses `readiness` (not `liveness`): ALB should stop routing to pods that aren't ready to serve traffic (e.g., DB disconnected), but should not deregister pods that are alive but temporarily unready.

---

## `charts/<service>/templates/service.yaml`

```yaml
apiVersion: v1
kind: Service
spec:
  type: ClusterIP   ← only reachable inside the cluster
  selector:
    app: payment-service
  ports:
    - port: 80           ← what the ALB target group and other pods call
      targetPort: 8080   ← what the Spring Boot app listens on
```
ClusterIP creates a stable virtual IP inside the cluster. Other pods and the ALB target group use the Service name (`payment-service.payment-ns.svc.cluster.local`) to reach pods. Individual pod IPs change on every restart — the Service IP is stable. The ALB controller registers pod IPs directly (because `target-type: ip`), but the Service is still needed for pod-to-pod communication.

---

## `charts/<service>/templates/serviceaccount.yaml`

```yaml
{{- if .Values.serviceAccount.create }}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .Values.serviceAccount.name }}
  annotations:
    {{- toYaml .Values.serviceAccount.annotations | nindent 4 }}
{{- end }}
```
The IRSA annotation is set via the ArgoCD Application's inline `values:` block:
```yaml
serviceAccount:
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-payment-service
```
This annotation links the K8s ServiceAccount to an AWS IAM role. When the pod starts with this ServiceAccount, the AWS SDK automatically gets temporary STS credentials for that IAM role. The payment-service IAM role has only the permissions it needs (Secrets Manager read for its DB credentials). No AWS access keys are stored anywhere in Kubernetes.

---

## `services/<service>/Dockerfile`

```dockerfile
FROM eclipse-temurin:21-jdk-alpine AS builder
WORKDIR /app
COPY build.gradle settings.gradle ./
COPY src ./src
RUN ./gradlew bootJar --no-daemon

FROM eclipse-temurin:21-jre-alpine
WORKDIR /app
COPY --from=builder /app/build/libs/*.jar app.jar
EXPOSE 8080
ENTRYPOINT ["sh", "-c", "java $JVM_OPTS -jar app.jar"]
```

**Two-stage build:**
Stage 1 (`jdk-alpine`): full JDK with Gradle to compile source and build the fat jar.
Stage 2 (`jre-alpine`): JRE only (no JDK compiler, no javac, no gradle) for the final image.
```
Stage 1 image: ~500MB (JDK + Gradle + all build tools)
Stage 2 image: ~200MB (JRE + app.jar only)
No gcc, no javac, no build tools in production image → smaller attack surface
```

**`ENTRYPOINT ["sh", "-c", "java $JVM_OPTS -jar app.jar"]`:**
`$JVM_OPTS` is an environment variable injected by the Helm values file:
- dev: `-Xms128m -Xmx256m ... -agentlib:jdwp...`
- staging: `-Xms256m -Xmx512m ...`
- production: `-Xms512m -Xmx1024m ... -XX:MaxGCPauseMillis=200`

Using `sh -c` (shell form) allows environment variable expansion. Using `ENTRYPOINT ["java", "$JVM_OPTS", "-jar", "app.jar"]` (exec form) would NOT expand the variable — `$JVM_OPTS` would be passed literally as an argument.

**Why `eclipse-temurin:21-jdk-alpine`:**
Temurin = the production-ready OpenJDK distribution from the Eclipse Adoptium project. Alpine = minimal Linux base image. `21` = Java LTS version. This combination: ~230MB base image vs ~500MB for full Ubuntu-based JDK images. Alpine uses musl libc instead of glibc — fewer pre-installed packages = smaller attack surface.

---

## What Breaks Without Each File

| File | What breaks |
|---|---|
| `root-app-<env>.yaml` | ArgoCD knows nothing about this environment — nothing deploys automatically |
| `namespaces/namespaces.yaml` | All service deployments fail: namespace not found. Dynatrace auto-tagging misses all pods → no alerts |
| `aws-load-balancer-controller.yaml` | All Ingress resources stay Pending — no ALBs created — services unreachable |
| `external-dns.yaml` | No Route53 DNS records created — service hostnames don't resolve |
| `cluster-secret-store.yaml` (ESO) | DynaKube ExternalSecret can't create its Secret — OneAgent never starts. App ExternalSecrets can't create DB creds — pods crash on start |
| `dynatrace-operator.yaml` | No OneAgent → no metrics/traces/logs in DT. No alerting. Blind monitoring |
| `values-dev.yaml` | Dev deploys with 3 replicas, Xmx 1024m, WARN logs, prod JVM flags — dev cluster OOMs |
| `values-staging.yaml` | Staging uses prod settings: 20 max replicas, prod ECR, production Spring profile |
| `pdb.yaml` (production) | Node upgrades evict all 3 pods simultaneously → downtime |
| `preStop: sleep 15` | In-flight requests get connection resets during pod shutdown |
| `ignoreDifferences` (ArgoCD Application) | ArgoCD fights HPA → infinite revert loop on replica count |
| `[skip ci]` in gitops commit | Infinite CI pipeline loop |
| `alert_on_no_data = true` on traffic drop | Silent outages produce no alerts (service down, metrics stop flowing, alert stays green) |
| `latency_p99_ms * 1000` conversion | Threshold = 300µs (0.3ms) → fires on literally every request → alert fatigue → alerts ignored |
| `jdwp suspend=n` (dev) | JVM waits indefinitely for debugger → pod never passes startupProbe → CrashLoopBackOff |
| `fetch-depth: 0` in verify-production | Auto-rollback can't find previous image tag → rollback fails |
