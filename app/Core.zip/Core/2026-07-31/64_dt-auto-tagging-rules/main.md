# DT Auto-Tagging Rules: Kubernetes Namespace Labels → Dynatrace Entity Tags

---

## What We Are Doing and Why

### The Goal

You have Kubernetes namespaces with labels like:
```yaml
labels:
  team: payments
  environment: production
```

You want Dynatrace to automatically add these tags to every entity (pod, service, process group) running in that namespace:
```
team:payments
environment:production
```

So that in Dynatrace you can:
- Filter dashboards by `team:payments`
- Scope Management Zones to `environment:production`
- Set alerting profiles per `team:X`
- Run DQL queries filtered by `team:payments`

### How Auto-Tagging Works (Mental Model)

```
Kubernetes Namespace Label
  team=payments
      │
      ▼
DT OneAgent reads namespace metadata via Kubernetes API
      │
      ▼
DT Auto-Tagging Rule evaluates:
  "Does this entity have a property matching the rule condition?"
      │
      ▼
DT adds tag to the entity automatically:
  Process Group: my-service → tagged [team:payments]
  Service:       my-service → tagged [team:payments]
  Pod:           my-service-abc → tagged [team:payments]
```

The tag flows from the namespace label → through the DT metadata pipeline → onto every entity in that namespace.

---

## Decision Tree: Which Method to Use?

```
Do you need this for one environment only (quick test)?
  YES → Method 1: DT UI (manual, no code)

Do you need this repeatable, version-controlled, and deployable via CI/CD?
  YES → Method 2: DT API + shell script (or Method 3: Terraform)

Do you already use Terraform for DT config?
  YES → Method 3: Terraform dynatrace provider (cleanest for IaC teams)

Are you in a large org with many teams and need a template pattern?
  YES → Method 2 API (scriptable, parameterized per team)
```

---

## Part 1 — Understand: What Metadata DT Sees From Kubernetes

Before writing rules, you need to know what properties DT can see on each entity.

### What Properties DT Exposes From Kubernetes

When DT OneAgent is installed in Kubernetes, it automatically pulls metadata for each entity. The property paths you use in auto-tagging rules are:

```
For a Process Group / Service running in a namespace:

  Kubernetes namespace label:
    Property path: {KubernetesNamespaceLabel:team}
    Property path: {KubernetesNamespaceLabel:environment}

  Kubernetes pod label:
    Property path: {KubernetesPodLabel:app}
    Property path: {KubernetesPodLabel:version}

  Kubernetes namespace name:
    Property path: {KubernetesNamespace}

  Kubernetes deployment name:
    Property path: {KubernetesDeploymentName}

  Kubernetes cluster name:
    Property path: {KubernetesCluster}
```

The key insight: `{KubernetesNamespaceLabel:team}` means "read the value of the `team` label from the Kubernetes namespace that this entity belongs to."

### Verify DT Can See Your Namespace Labels

Before building rules, confirm DT sees the labels:

```bash
# 1. Check your namespace has the labels you expect
kubectl get namespace production -o jsonpath='{.metadata.labels}' | jq .

# Expected output:
# {
#   "team": "payments",
#   "environment": "production",
#   "kubernetes.io/metadata.name": "production"
# }

# 2. If labels are missing, add them
kubectl label namespace production team=payments
kubectl label namespace production environment=production

# 3. Verify all your namespaces have consistent labels
kubectl get namespaces --show-labels

# 4. In DT UI: confirm entity metadata
# Navigate to: Infrastructure → Kubernetes → your cluster → namespace
# Open any Process Group in that namespace
# Click "Properties and tags" tab
# Look for "Kubernetes namespace labels" section
# You should see team=payments listed
```

---

## Part 2 — Method 1: DT UI (Step-by-Step)

This is the manual approach. Best for: learning, testing, or one-off environments.

### Step 1: Navigate to Auto-Tagging

```
DT UI path:
  Settings → Tags → Automatically applied tags → Create tag
  
  OR via the new Settings UI:
  Settings (gear icon) → Observability & AI → Automatically applied tags
```

### Step 2: Create the `team` Tag Rule

```
Screen: "Create automatically applied tag"

1. Tag name field:
   Enter: team
   
   This creates the tag KEY. The VALUE will come from the namespace label.

2. Click "Add a new rule"

3. Rule configuration:
   
   Rule applies to: [dropdown] → select "Process groups"
   (also add separate rules for "Services" if needed — see note below)
   
   Conditions section:
   Click "Add condition"
   
   Condition 1:
     Property:   [dropdown] → scroll to Kubernetes section
                              select "Kubernetes namespace label"
     Key:        team
                 (this is the label name in your Kubernetes namespace)
     Condition:  exists
                 (fires for any entity in a namespace that HAS the team label)
   
4. Tag value section:
   
   Check: "Apply to all services of entity type"
   
   Dynamic value toggle: ON (enabled)
   
   Source: Kubernetes namespace label
   Key:    team
   
   Preview shows: tag will be applied as "team:{value_of_label}"
   Example:       team:payments

5. Click "Save"
```

### Step 3: Create the `environment` Tag Rule

Repeat Step 2 with:
```
Tag name:  environment

Condition:
  Property:  Kubernetes namespace label
  Key:       environment
  Condition: exists

Dynamic value:
  Source: Kubernetes namespace label
  Key:    environment
```

### Step 4: Verify Tags Are Applying

```
Wait 2–5 minutes for DT to process and apply tags.

Verify:
  1. Go to: Infrastructure → Process groups
  2. Filter by tag: team:payments
  3. You should see all process groups in your "payments" namespace
  
  OR:
  1. Open any process group in the "production" namespace
  2. Click "Properties and tags"
  3. Under "Tags" section, you should see:
     [team:payments] [environment:production]
     with label "Auto-tag rule" next to them
```

### Note: Rule Applies To — Which Entity Types to Cover

Auto-tagging rules are written per entity type. To tag everything, you need rules for each:

```
Entity types to create rules for:
  ✓ Process groups          (the container/JVM process)
  ✓ Services                (the logical service DT detects)
  ✓ Hosts (optional)        (the Kubernetes node)
  
Best practice: Create one tag rule with the same name but apply it to 
multiple entity types by adding multiple sub-rules within one tag definition.

In the UI: After creating rule for "Process groups", click "Add a new rule" 
again within the same tag and repeat for "Services".
```

---

## Part 3 — Method 2: DT API (Repeatable, Scriptable)

This is the recommended approach for teams that want:
- Version-controlled tag rules
- CI/CD-deployed configuration
- Consistent rules across multiple DT environments (dev/staging/prod)

### Prerequisites

```bash
# You need:
# 1. DT environment URL (e.g., https://abc12345.live.dynatrace.com)
# 2. DT API token with scope: WriteConfig, ReadConfig

# Store securely (never hardcode in scripts):
export DT_ENV_URL="https://abc12345.live.dynatrace.com"
export DT_API_TOKEN="dt0c01.XXXXXXXXXXXXXXXXXXXXXXXX"

# Test connectivity
curl -sf \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  "${DT_ENV_URL}/api/v1/config/autoTags" \
  | jq '.values[] | {id, name}'
```

### Read Existing Auto-Tag Rules (Always Read Before Write)

```bash
# List all existing auto-tag rules
curl -s \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  "${DT_ENV_URL}/api/v1/config/autoTags" \
  | jq '.values[] | {id: .id, name: .name}'

# Get the full detail of a specific tag rule by ID
TAG_ID="your-rule-id-here"
curl -s \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  "${DT_ENV_URL}/api/v1/config/autoTags/${TAG_ID}" \
  | jq .
```

### Create the `team` Auto-Tag Rule via API

```bash
# Create auto-tag rule: "team" from Kubernetes namespace label
curl -s -X POST \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  -H "Content-Type: application/json" \
  "${DT_ENV_URL}/api/v1/config/autoTags" \
  -d '{
    "name": "team",
    "rules": [
      {
        "type": "PROCESS_GROUP",
        "enabled": true,
        "valueFormat": "{KubernetesNamespaceLabel:team}",
        "propagationTypes": ["PROCESS_GROUP_TO_SERVICE"],
        "conditions": [
          {
            "key": {
              "attribute": "PROCESS_GROUP_PREDEFINED_METADATA",
              "dynamicKey": "KUBERNETES_NAMESPACE_LABELS",
              "dynamicKeySource": "PREDEFINED",
              "type": "PROCESS_PREDEFINED_METADATA_KEY"
            },
            "comparisonInfo": {
              "type": "STRING",
              "operator": "EXISTS",
              "value": null,
              "negate": false,
              "caseSensitive": false
            }
          }
        ]
      },
      {
        "type": "SERVICE",
        "enabled": true,
        "valueFormat": "{KubernetesNamespaceLabel:team}",
        "propagationTypes": [],
        "conditions": [
          {
            "key": {
              "attribute": "SERVICE_TAGS",
              "type": "STATIC_ATTRIBUTE"
            },
            "comparisonInfo": {
              "type": "TAG",
              "operator": "TAG_KEY_EQUALS",
              "value": {
                "context": "CONTEXTLESS",
                "key": "team"
              },
              "negate": false
            }
          }
        ]
      }
    ]
  }' \
  | jq '{id: .id, name: .name}'
```

### Simpler API Payload (Process Groups Only — Easiest Starting Point)

The full payload above can be complex. Here is the minimal working version for process groups that propagates to services automatically:

```bash
# Minimal: tag process groups from namespace label, propagate to services
curl -s -X POST \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  -H "Content-Type: application/json" \
  "${DT_ENV_URL}/api/v1/config/autoTags" \
  -d '{
    "name": "team",
    "rules": [
      {
        "type": "PROCESS_GROUP",
        "enabled": true,
        "valueFormat": "{KubernetesNamespaceLabel:team}",
        "propagationTypes": [
          "PROCESS_GROUP_TO_SERVICE",
          "PROCESS_GROUP_TO_HOST"
        ],
        "conditions": [
          {
            "key": {
              "attribute": "PROCESS_GROUP_KUBERNETES_NAMESPACE",
              "type": "STATIC_ATTRIBUTE"
            },
            "comparisonInfo": {
              "type": "STRING",
              "operator": "EXISTS",
              "value": null,
              "negate": false,
              "caseSensitive": false
            }
          }
        ]
      }
    ]
  }' \
  | jq .
```

### Create the `environment` Auto-Tag Rule via API

```bash
# Create auto-tag rule: "environment" from Kubernetes namespace label
curl -s -X POST \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  -H "Content-Type: application/json" \
  "${DT_ENV_URL}/api/v1/config/autoTags" \
  -d '{
    "name": "environment",
    "rules": [
      {
        "type": "PROCESS_GROUP",
        "enabled": true,
        "valueFormat": "{KubernetesNamespaceLabel:environment}",
        "propagationTypes": [
          "PROCESS_GROUP_TO_SERVICE"
        ],
        "conditions": [
          {
            "key": {
              "attribute": "PROCESS_GROUP_KUBERNETES_NAMESPACE",
              "type": "STATIC_ATTRIBUTE"
            },
            "comparisonInfo": {
              "type": "STRING",
              "operator": "EXISTS",
              "value": null,
              "negate": false,
              "caseSensitive": false
            }
          }
        ]
      }
    ]
  }' \
  | jq .
```

### Shell Script: Deploy Both Rules at Once

```bash
#!/usr/bin/env bash
# Usage: DT_ENV_URL=https://xxx.live.dynatrace.com DT_API_TOKEN=dt0c01.xxx bash deploy-tags.sh

set -euo pipefail

DT_ENV_URL="${DT_ENV_URL:?DT_ENV_URL required}"
DT_API_TOKEN="${DT_API_TOKEN:?DT_API_TOKEN required}"
API_BASE="${DT_ENV_URL}/api/v1/config/autoTags"

create_tag_rule() {
  local tag_name="$1"
  local label_key="$2"

  echo "Creating auto-tag rule: ${tag_name} from namespace label ${label_key}"

  local response
  response=$(curl -s -X POST \
    -H "Authorization: Api-Token ${DT_API_TOKEN}" \
    -H "Content-Type: application/json" \
    "${API_BASE}" \
    -d "{
      \"name\": \"${tag_name}\",
      \"rules\": [
        {
          \"type\": \"PROCESS_GROUP\",
          \"enabled\": true,
          \"valueFormat\": \"{KubernetesNamespaceLabel:${label_key}}\",
          \"propagationTypes\": [\"PROCESS_GROUP_TO_SERVICE\"],
          \"conditions\": [
            {
              \"key\": {
                \"attribute\": \"PROCESS_GROUP_KUBERNETES_NAMESPACE\",
                \"type\": \"STATIC_ATTRIBUTE\"
              },
              \"comparisonInfo\": {
                \"type\": \"STRING\",
                \"operator\": \"EXISTS\",
                \"value\": null,
                \"negate\": false,
                \"caseSensitive\": false
              }
            }
          ]
        }
      ]
    }")

  local rule_id
  rule_id=$(echo "$response" | jq -r '.id // empty')

  if [[ -n "$rule_id" ]]; then
    echo "  ✓ Created: ${tag_name} (ID: ${rule_id})"
  else
    echo "  ✗ Failed: $(echo "$response" | jq -r '.error.message // .message // "unknown error"')"
    exit 1
  fi
}

# Check if rule already exists (avoid duplicates)
existing_names=$(curl -s \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  "${API_BASE}" | jq -r '.values[].name')

for tag_name in "team" "environment"; do
  if echo "$existing_names" | grep -qx "${tag_name}"; then
    echo "SKIP: auto-tag rule '${tag_name}' already exists"
  else
    label_key="${tag_name}"
    create_tag_rule "${tag_name}" "${label_key}"
  fi
done

echo ""
echo "Done. Verify in DT UI: Settings → Tags → Automatically applied tags"
```

---

## Part 4 — Method 3: Terraform (Infrastructure as Code)

Best for teams that already use Terraform for Dynatrace config management.

### Required Provider

```hcl
# terraform/versions.tf
terraform {
  required_providers {
    dynatrace = {
      source  = "dynatrace-oss/dynatrace"
      version = ">= 1.0"
    }
  }
}

provider "dynatrace" {
  dt_env_url   = var.dt_env_url    # https://abc12345.live.dynatrace.com
  dt_api_token = var.dt_api_token  # stored in secrets manager, never hardcoded
}
```

### Auto-Tag Rules in Terraform

```hcl
# terraform/auto_tagging.tf

# Auto-tag: team (from Kubernetes namespace label)
resource "dynatrace_autotag" "team" {
  name = "team"

  rules {
    type    = "PROCESS_GROUP"
    enabled = true

    value_format = "{KubernetesNamespaceLabel:team}"

    propagation_types = ["PROCESS_GROUP_TO_SERVICE"]

    attribute_rule {
      entity_type               = "PROCESS_GROUP"
      pg_to_host_propagation    = false
      pg_to_service_propagation = true

      attribute_conditions {
        key      = "PROCESS_GROUP_KUBERNETES_NAMESPACE"
        operator = "EXISTS"
      }
    }
  }
}

# Auto-tag: environment (from Kubernetes namespace label)
resource "dynatrace_autotag" "environment" {
  name = "environment"

  rules {
    type    = "PROCESS_GROUP"
    enabled = true

    value_format = "{KubernetesNamespaceLabel:environment}"

    propagation_types = ["PROCESS_GROUP_TO_SERVICE"]

    attribute_rule {
      entity_type               = "PROCESS_GROUP"
      pg_to_host_propagation    = false
      pg_to_service_propagation = true

      attribute_conditions {
        key      = "PROCESS_GROUP_KUBERNETES_NAMESPACE"
        operator = "EXISTS"
      }
    }
  }
}
```

```bash
# Deploy
terraform init
terraform plan   # review what will be created
terraform apply
```

---

## Part 5 — Verify Tags Are Working

### Step 1: Check Namespace Labels Are Present in Kubernetes

```bash
# View labels on all namespaces at once
kubectl get namespaces --show-labels | grep -E "team|environment"

# View specific namespace labels in detail
kubectl get namespace production -o json \
  | jq '.metadata.labels | with_entries(select(.key | test("team|environment")))'
```

### Step 2: Check DT UI — Entity Properties

```
Navigate to:
  Infrastructure → Kubernetes → [your cluster] → Namespaces → [your namespace]

Click on any Process Group in that namespace.
Click "Properties and tags" tab.

You should see under "Tags":
  [team:payments]         (source: Auto-tag rule)
  [environment:production] (source: Auto-tag rule)

If tags are missing after 5 minutes: see troubleshooting below.
```

### Step 3: Check Via DT API

```bash
# Search for entities tagged with team:payments
curl -s \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  "${DT_ENV_URL}/api/v2/entities?entitySelector=tag(team:payments)&fields=displayName,tags" \
  | jq '.entities[] | {name: .displayName, tags: [.tags[].value]}'

# Count entities per team tag (confirm distribution makes sense)
curl -s \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  "${DT_ENV_URL}/api/v2/entities?entitySelector=tag(team:payments)&fields=entityId" \
  | jq '.totalCount'
```

### Step 4: DQL Query to Verify in Grail (DT 2.0)

```dql
-- List all services tagged with team:payments
fetch dt.entity.service
| filter in(tags, "team:payments")
| fields entity.name, tags, entity.detected_name

-- Count entities per team tag
fetch dt.entity.process_group
| filter isNotNull(tags)
| expand tag = tags
| filter startsWith(tag, "team:")
| summarize count = count(), by: {tag}
| sort count desc
```

---

## Part 6 — Troubleshooting

### Problem 1: Tags Not Appearing After 5+ Minutes

```bash
# Check 1: Are namespace labels actually present?
kubectl get namespace <your-namespace> --show-labels
# If team/environment labels missing → add them:
kubectl label namespace production team=payments environment=production

# Check 2: Is DT OneAgent running in the cluster?
kubectl get pods -n dynatrace | grep -E "oneagent|operator"
# All should be Running

# Check 3: Does DT have Kubernetes API access?
# In DT UI: Settings → Cloud and virtualization → Kubernetes → [your connection]
# Status should be: "Connected"
# If disconnected: check the DT operator pod logs
kubectl logs -n dynatrace -l app.kubernetes.io/name=dynatrace-operator --tail=50

# Check 4: Is the auto-tag rule enabled?
curl -s \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  "${DT_ENV_URL}/api/v1/config/autoTags" \
  | jq '.values[] | select(.name=="team") | {id, name}'
# If empty: rule doesn't exist — create it
# If present: get the ID and check if enabled:
RULE_ID="your-id"
curl -s \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  "${DT_ENV_URL}/api/v1/config/autoTags/${RULE_ID}" \
  | jq '.rules[].enabled'
# Should be: true
```

### Problem 2: Tag Key Appears But Value Is Empty (`team:`)

```bash
# This means DT found the rule matched the entity BUT
# the namespace label value is not being read correctly.

# Check: Does the namespace actually have the label with the right key name?
kubectl get namespace production -o jsonpath='{.metadata.labels.team}'
# Should print: payments
# If blank: label key is different (maybe "Team" with capital T?)

# Auto-tagging rule keys ARE case-sensitive.
# "team" ≠ "Team" ≠ "TEAM"

# Fix: ensure label key case matches exactly what's in the rule
kubectl label namespace production team=payments --overwrite
```

### Problem 3: Tags on Process Groups But Not on Services

```bash
# The propagationTypes setting controls this.
# If services are NOT tagged, the rule is missing PROCESS_GROUP_TO_SERVICE propagation.

# Fix via API: update the existing rule to add propagation
RULE_ID="your-rule-id"

# First GET the current rule
curl -s \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  "${DT_ENV_URL}/api/v1/config/autoTags/${RULE_ID}" > /tmp/current-rule.json

# Edit: ensure propagationTypes includes "PROCESS_GROUP_TO_SERVICE"
jq '.rules[0].propagationTypes += ["PROCESS_GROUP_TO_SERVICE"]' \
  /tmp/current-rule.json > /tmp/updated-rule.json

# PUT the updated rule back
curl -s -X PUT \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  -H "Content-Type: application/json" \
  "${DT_ENV_URL}/api/v1/config/autoTags/${RULE_ID}" \
  -d @/tmp/updated-rule.json \
  | jq '{id: .id, name: .name}'
```

### Problem 4: Rule Already Exists — Want to Update It

```bash
# Use PUT (update) instead of POST (create)
# First find the existing rule ID:
RULE_NAME="team"
RULE_ID=$(curl -s \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  "${DT_ENV_URL}/api/v1/config/autoTags" \
  | jq -r --arg name "$RULE_NAME" '.values[] | select(.name==$name) | .id')

echo "Existing rule ID for '${RULE_NAME}': ${RULE_ID}"

# Now PUT the updated definition
curl -s -X PUT \
  -H "Authorization: Api-Token ${DT_API_TOKEN}" \
  -H "Content-Type: application/json" \
  "${DT_ENV_URL}/api/v1/config/autoTags/${RULE_ID}" \
  -d '{
    "name": "team",
    "rules": [
      {
        "type": "PROCESS_GROUP",
        "enabled": true,
        "valueFormat": "{KubernetesNamespaceLabel:team}",
        "propagationTypes": ["PROCESS_GROUP_TO_SERVICE"],
        "conditions": [
          {
            "key": {
              "attribute": "PROCESS_GROUP_KUBERNETES_NAMESPACE",
              "type": "STATIC_ATTRIBUTE"
            },
            "comparisonInfo": {
              "type": "STRING",
              "operator": "EXISTS",
              "value": null,
              "negate": false,
              "caseSensitive": false
            }
          }
        ]
      }
    ]
  }' | jq .
```

---

## Part 7 — What to Build Next After Tags Work

Once `team:X` and `environment:Y` tags are on all entities, these become unblocked:

### Management Zones (Scope DT Access by Team)

```
DT UI: Settings → Management zones → Add management zone

Name: Team Payments

Rule:
  Entity type: Process groups
  Condition: tag    |    team    |    equals    |    payments

Effect:
  Payments team members see ONLY their services, dashboards, alerts
  No cross-team noise
  SRE sees all (no management zone restriction)
```

### Alerting Profile (Route Alerts by Team)

```
DT UI: Settings → Alerting → Alerting profiles → Add alerting profile

Name: payments-team-alerts

Filter:
  Tag: team:payments

Notification integration: PagerDuty payments team service key
Effect: All alerts for team:payments entities → payments team PagerDuty
```

### Dashboard Variable Filter

```
In any Grafana-style DT dashboard:
  Add filter: tag = team:payments
  
  OR in DQL-based dashboards:
    fetch dt.entity.service
    | filter in(tags, "team:${team_variable}")
```

### DQL Queries Scoped by Tag

```dql
-- All errors for the payments team
fetch logs
| filter dt.entity.service.tags contains "team:payments"
| filter loglevel == "ERROR"
| summarize count = count(), by: {dt.entity.service.name}

-- P99 latency for production environment
fetch metrics, metric: "dt.service.request.duration"
| filter dt.entity.service.tags contains "environment:production"
| summarize p99 = percentile(value, 99), by: {dt.entity.service.name}
```
