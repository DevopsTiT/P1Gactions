# Glossary: DT Auto-Tagging Rules

Every term from the main guide explained for an SRE beginner.

---

**Auto-Tagging Rule (Dynatrace)**
A configuration in Dynatrace that automatically adds tags to entities based on their properties. You write the rule once and DT applies the tag to every matching entity — now and in the future. You never manually tag individual services.

**Tag (Dynatrace)**
A key:value label attached to a Dynatrace entity (service, process group, host). Tags are used to filter dashboards, scope management zones, route alerts, and run DQL queries. Example: `team:payments`, `environment:production`.

**Entity (Dynatrace)**
Any thing DT monitors: a Service, Process Group, Pod, Host, Kubernetes namespace, database. Auto-tagging rules apply tags to entities automatically.

**Process Group (Dynatrace)**
DT's representation of a running application process (e.g., your Java payment service). DT groups multiple pods running the same process into one Process Group. Auto-tagging on Process Groups is the most common starting point.

**Service (Dynatrace)**
The logical service DT detects from observed network traffic. For example, `payment-service` is a Service in DT. Tags on Process Groups propagate to Services via `PROCESS_GROUP_TO_SERVICE` propagation.

**Kubernetes Namespace Label**
A key-value metadata field you apply to a Kubernetes namespace. Example: `kubectl label namespace production team=payments`. DT OneAgent reads these labels and exposes them as entity properties for use in auto-tagging rules.

**`{KubernetesNamespaceLabel:team}`**
The DT placeholder syntax for reading a namespace label value at tag evaluation time. `{KubernetesNamespaceLabel:team}` means: "whatever value the `team` label has on the namespace this entity belongs to." This is what makes the tag dynamic instead of hardcoded.

**`valueFormat`**
The field in a DT auto-tagging rule that defines the TAG VALUE. Set to `{KubernetesNamespaceLabel:team}` to make the value dynamic (pulled from the namespace label). Without this, the tag would have no value.

**`propagationTypes`**
Controls whether a tag applied to a Process Group is automatically copied to related entities. `PROCESS_GROUP_TO_SERVICE` means: when a Process Group is tagged `team:payments`, all Services it backs are also tagged `team:payments` automatically.

**DT API v1 (Config API)**
The older Dynatrace REST API for managing configuration objects like auto-tagging rules, alerting profiles, and management zones. Base path: `/api/v1/config/`. Used with HTTP POST to create and PUT to update.

**DT API v2 (Entities API)**
The newer Dynatrace REST API for querying monitored entities and their metadata. Base path: `/api/v2/entities`. Used to verify that tags are applied correctly after creating auto-tagging rules.

**DT API Token**
A credential (string starting with `dt0c01.`) used to authenticate API requests to Dynatrace. Must have `WriteConfig` scope to create auto-tagging rules and `ReadConfig` to read them. Never hardcode in scripts — use environment variables or secrets.

**WriteConfig (API token scope)**
The Dynatrace API token permission that allows creating and modifying configuration objects (auto-tagging rules, management zones, alerting profiles). Required for all POST and PUT requests to `/api/v1/config/`.

**ReadConfig (API token scope)**
The Dynatrace API token permission that allows reading existing configuration. Required for GET requests to `/api/v1/config/`.

**`PROCESS_GROUP_KUBERNETES_NAMESPACE` (attribute)**
A Dynatrace entity attribute that holds the name of the Kubernetes namespace a process group runs in. Used as the condition in auto-tagging rules to say "this rule applies to any entity running inside a Kubernetes namespace."

**`operator: EXISTS`**
A rule condition that matches any entity that HAS the specified attribute — regardless of its value. Using `EXISTS` on the namespace attribute means: "apply this tag to every entity running in ANY Kubernetes namespace." The tag value is then filled by the `valueFormat` field.

**Dynatrace Operator**
A Kubernetes operator that manages DT OneAgent deployment and configuration in a cluster. Runs in the `dynatrace` namespace. Responsible for collecting Kubernetes metadata (including namespace labels) and sending it to the DT backend.

**OneAgent**
The DT monitoring agent deployed as a DaemonSet on every Kubernetes node. Collects metrics, traces, logs, and entity metadata (including Kubernetes namespace labels). Required for auto-tagging from namespace labels to work.

**Management Zone (Dynatrace)**
A scoped view of DT that filters entities, dashboards, and alerts to a subset (e.g., one team's services). Typically defined by tag conditions. `team:payments` tag → payments Management Zone. Team members only see their own services.

**Alerting Profile (Dynatrace)**
A configuration that filters which DT alerts are sent to a specific notification target (PagerDuty, Slack, email). Filtered by tag conditions. `team:payments` alerting profile → route alerts for payments entities to the payments on-call.

**DQL (Dynatrace Query Language)**
The SQL-like query language used in Dynatrace Grail (DT 2.0 log and metrics analytics platform). Supports filtering by tags: `fetch dt.entity.service | filter in(tags, "team:payments")`.

**Terraform dynatrace provider**
A Terraform plugin (`dynatrace-oss/dynatrace`) that lets you manage Dynatrace configuration as code. Resources like `dynatrace_autotag` create auto-tagging rules declaratively. Changes go through git → PR review → `terraform apply`.

**`jq`**
A command-line JSON processor. Used throughout this guide to parse DT API responses — extract tag rule IDs, check enabled status, filter entity lists.

**`kubectl label namespace`**
The Kubernetes command to add or update a label on a namespace. Example: `kubectl label namespace production team=payments`. The label must be present on the namespace for the DT auto-tagging rule to pick it up.

**`--show-labels` (kubectl flag)**
Adds a LABELS column to `kubectl get` output showing all labels on each resource. `kubectl get namespaces --show-labels` is how you verify namespace labels are applied correctly.

**PUT vs POST (REST API)**
POST creates a new resource; PUT updates an existing one. In the DT Config API: POST `/api/v1/config/autoTags` creates a new rule; PUT `/api/v1/config/autoTags/{id}` updates an existing rule. Always GET first to find the ID before PUTting.

**Case-Sensitive Label Keys**
Kubernetes label keys and DT property references are case-sensitive. `team` ≠ `Team` ≠ `TEAM`. If the namespace has `team=payments` but the auto-tagging rule references `Team`, no match occurs and the tag is not applied.

**`propagation` (tag propagation)**
The automatic copying of a tag from one entity to a related entity. `PROCESS_GROUP_TO_SERVICE` means a tag on the process group flows to the service DT associates with it. Without propagation, you would need separate rules for every entity type.

**Status Page (Kubernetes connection in DT)**
The DT UI page at `Settings → Cloud and virtualization → Kubernetes → [your connection]` that shows whether DT has a live, working connection to the Kubernetes API. If "Disconnected," namespace labels will not be available for auto-tagging.
