# Glossary — Confluence Must-Know
Every term from main.md. One entry per term. SRE beginner level.

---

**Confluence**
Atlassian's wiki and documentation platform. Where teams write and store knowledge: runbooks, architecture docs, postmortems, onboarding guides. Why it matters: Confluence is where "how does this work?" gets answered without asking a senior engineer every time.

**Atlassian**
The company that makes Confluence, Jira, and Bitbucket — all integrated with each other. Why it matters: a Confluence page can show live Jira ticket statuses, and a Jira ticket can link to its Confluence spec.

**Space**
The top-level container in Confluence. Every page lives in exactly one Space. Each team or project usually has its own Space. Why it matters: Spaces scope search and permissions — "search in the SRE Space" finds only SRE docs, not all company docs.

**Space Key**
A short uppercase identifier for a Space, like `SRE`, `ENG`, or `PLAT`. Used in URLs and CQL queries. Why it matters: you use the Space Key to filter search results: `space = "SRE"`.

**Personal Space**
A private Space (`~your-username`) that only you can see by default. Used for drafts, personal notes, scratchpads. Why it matters: safe place to draft a document before making it public to the team.

**Page**
A single document inside a Space. Pages have a title, content, labels, comments, and a version history. Why it matters: the primary unit of knowledge in Confluence — runbooks, ADRs, meeting notes are all pages.

**Page Tree**
The parent-child hierarchy of pages within a Space. A page can have child pages, which can have their own children. Why it matters: good page tree structure makes navigation fast — engineers find runbooks by drilling down (Space → Runbooks → Service Name), not by searching every time.

**Child Page**
A page nested under a parent page. Created by clicking "+" next to the parent. Why it matters: keeps related content together — all payment-service runbooks are children of the "payment-service" page.

**Page History / Version History**
Every edit to a page creates a new numbered version. You can view any past version or compare two versions to see what changed. Why it matters: nothing is ever truly deleted — if someone accidentally overwrites a runbook, the previous version is always recoverable.

**Diff / Compare versions**
Side-by-side view of two page versions showing what was added (green), removed (red), or changed. Why it matters: lets you understand exactly what changed in a runbook without reading the whole thing.

**Editor**
The in-page editing interface. Accessed by clicking "Edit" or pressing `e`. Why it matters: Confluence's editor supports slash commands, @mentions, Jira embeds, and structured content — it's much more powerful than a plain text editor.

**Slash Command (`/`)**
Typing `/` inside the Confluence editor opens a menu of content blocks to insert: tables, code blocks, panels, Jira macros, etc. Why it matters: the primary way to add structured content — faster than hunting through menus.

**Code Block**
A formatted block for displaying code, commands, or config files with syntax highlighting. Inserted via `/code`. Why it matters: runbooks must put all bash commands in code blocks — plain text commands get reformatted and break when engineers try to copy-paste them.

**Info Panel**
A blue highlighted box for important notes. Inserted via `/info`. Warning panels are yellow (`/warning`). Why it matters: visually separates "important notices" from body text — engineers scan for these during incidents.

**Status Lozenge**
A colored badge showing a status label like `IN PROGRESS`, `DONE`, `BLOCKED`. Inserted via `/status`. Why it matters: visible at a glance in a table of action items or ADRs — no need to read the full text.

**Table of Contents (TOC)**
A macro (inserted via `/toc`) that auto-generates a linked list of all headings on the page. Appears at the top. Why it matters: essential for long runbooks — engineers jump directly to "Resolution Steps" during an incident without scrolling.

**Runbook**
A step-by-step operational guide for responding to a specific alert or performing a specific operational task. Why it matters: during an incident at 3am, you don't think clearly — a good runbook tells you exactly what to run in what order.

**Postmortem (Post-incident Review / Incident Report)**
A document written after an incident describing what happened, why, and what will be done to prevent recurrence. Written within 48 hours. Why it matters: organizations learn from incidents only if they're documented — a postmortem turns a painful event into a reusable lesson.

**5-Whys**
A root cause analysis technique: ask "why did this happen?" 5 times to find the underlying system failure, not just the surface symptom. Why it matters: the root cause of most incidents is NOT "engineer did the wrong thing" — it's a system design flaw. 5-Whys finds the real fix.

**Blameless postmortem**
A postmortem culture where the goal is to fix the SYSTEM, not punish the person. Uses language like "the system allowed X" not "engineer X made a mistake." Why it matters: if engineers fear blame, they won't report incidents honestly → the organization doesn't learn → the same incident happens again.

**Architecture Decision Record (ADR)**
A page documenting a significant technical decision: what was decided, why, what alternatives were considered, and what the consequences are. Why it matters: 6 months later, a new engineer asks "why is ArgoCD used instead of Flux?" — the ADR answers that without needing to find the original decision-maker.

**ADR Status**
A field on an ADR page: PROPOSED (being discussed), ACCEPTED (agreed), SUPERSEDED (replaced by a newer ADR), DEPRECATED. Why it matters: lets you know whether this decision is still current without reading the whole document.

**Onboarding Guide**
A page (or set of pages) for new team members explaining access, tools, architecture, and first tasks. Why it matters: good onboarding docs reduce the time a new engineer needs to ask questions before being productive — from weeks to days.

**Meeting Notes**
A page created for each meeting recording attendees, discussion, decisions, and action items. Titled with the date. Why it matters: creates a searchable record of what was decided and who committed to what action items.

**Action Item**
A task with an owner and due date, created inline in Confluence using `/action item`. Can also be tracked in Jira. Why it matters: postmortem action items without owners and due dates never get done.

**Label**
A tag added to a page to categorize it. Examples: `runbook`, `postmortem`, `architecture`, `draft`, `deprecated`. Why it matters: labels enable filtered search (`label = "runbook" AND space = "SRE"`) and building index pages that auto-list all runbooks.

**CQL (Confluence Query Language)**
A SQL-like syntax for searching Confluence content. Example: `space = "SRE" AND label = "postmortem" AND lastModified >= startOfMonth()`. Why it matters: advanced searches that keyword search can't do — "all unfinished postmortem action items from the last quarter."

**Macro**
A special Confluence element that shows dynamic content: Jira issue tables, roadmaps, status lozenges, TOC, etc. Inserted via `/` commands. Why it matters: macros turn Confluence pages from static text into live dashboards — a Jira macro on a postmortem page shows whether action items are still open.

**Jira macro**
A Confluence macro that embeds Jira data inline. You provide a JQL query; Confluence renders a live table of matching issues. Why it matters: keeps postmortem action items visible on the postmortem page without manually copying ticket statuses.

**JQL (Jira Query Language)**
A query syntax for filtering Jira issues. Used inside the Jira macro in Confluence. Example: `project = PLAT AND label = "postmortem-action" AND status != Done`. Why it matters: powers live action-item tables embedded in Confluence postmortem pages.

**@mention**
Typing `@name` in Confluence editor to reference a person. They receive a notification. Why it matters: turns "someone should fix this" into "@shuge.kui should fix this by Friday" — creates accountability and notifies the person immediately.

**Page Restriction**
A setting on a page (not the whole Space) controlling who can view or edit it. Why it matters: lets you draft a page privately before sharing, or restrict sensitive docs (HR policies, executive postmortems) to specific people.

**Space Admin**
A user with full control over a Space: can change permissions, rename the Space, manage templates, delete pages. Why it matters: if you can't create pages or change the page tree, you need to ask the Space Admin.

**Watch**
Subscribing to notifications for a page or Space. When watched content changes, you get an email or in-app notification. Why it matters: watching your team's Runbooks section notifies you when runbooks are updated — important for on-call engineers to know the latest procedures.

**Daily Digest**
A notification setting that batches all Confluence changes into one daily email instead of immediate notifications. Why it matters: if you watch many pages, immediate notifications become noise. Daily digest keeps you informed without constant interruption.

**Inline Comment**
A comment attached to a specific piece of text on a page (highlight text → click comment). Different from page-level comments at the bottom. Why it matters: essential for ADR reviews — you can comment on a specific paragraph saying "this assumption is wrong" without writing a long page-level comment.

**Page Template**
A pre-defined page structure for common page types (runbook, postmortem, meeting notes, ADR). Selected when creating a new page. Why it matters: templates enforce consistency — every postmortem has the same sections, every runbook has escalation steps — so engineers know where to look during an incident.

**Deprecated page**
A page that is no longer accurate but is kept for historical reference. Convention: add "DEPRECATED" to the title, add `deprecated` label, add a banner linking to the replacement. Why it matters: never delete — old pages may be linked from Jira tickets, Slack messages, other Confluence pages. Deleting them breaks those links.

**Recently Updated**
A sidebar widget showing pages that were recently edited in a Space. Why it matters: quick way to see what your teammates changed overnight or during an incident without checking every page individually.

**Confluence vs Jira — the distinction**
Confluence = documentation, knowledge, decisions (persistent reference material). Jira = tasks, bugs, sprints, status tracking (work management). Why it matters: a common mistake is tracking work in Confluence (creating a page of TODO items) instead of Jira tickets — then nothing gets done because there's no assignment or sprint tracking.
