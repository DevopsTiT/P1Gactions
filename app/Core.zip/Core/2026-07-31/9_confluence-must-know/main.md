# Confluence — Everything You Must Know

> Confluence is Atlassian's wiki / documentation platform.
> Used by engineering teams to write runbooks, architecture docs, postmortems, onboarding guides,
> meeting notes, and project specs — all searchable and linked to Jira tickets.

---

## Decision Tree — How to Navigate Confluence

```
I need to find something:
  → Use the search bar (/) — fastest way
  → Filter by Space → Page title

I need to write something:
  → Is it about a project?   → Create inside the project's Space
  → Is it a meeting note?    → Create under the team's Meeting Notes page
  → Is it a runbook?         → Create under your team's Runbooks section
  → Is it a postmortem?      → Create under Incident Reports

I need to update something:
  → Edit the existing page (don't create a new one)
  → Use Page Restrictions if the page is not ready to share

I need to track work:
  → That's Jira, not Confluence
  → Confluence = documentation and knowledge
  → Jira = tasks, bugs, sprints, status tracking

Confluence and Jira link together:
  → In Confluence: paste a Jira issue URL → becomes a live status chip
  → In Jira: "Link to Confluence page" on any issue
```

---

## Part 1 — Core Concepts You Must Understand

### Spaces

A Space is the top-level container. Every page lives inside exactly one Space.

```
Common Space types:

~Personal Space     → your own notes, drafts, scratchpad
                      URL: /wiki/~your-username
                      Nobody sees this unless you share it

Team Space          → one per team (SRE, Platform, Backend, Mobile)
                      URL: /wiki/spaces/SRE
                      All team docs, runbooks, onboarding

Project Space       → one per project or product
                      URL: /wiki/spaces/PROJ
                      Architecture, specs, decisions for that project

Company-wide Space  → policies, company handbook, HR docs
                      URL: /wiki/spaces/COMPANY
```

**The Space Key** is the short identifier (like `SRE`, `ENG`, `PLAT`). Used in search CQL queries and URLs.

```
How to find your team's Space:
  → Top navigation → "Spaces" → "View all spaces"
  → Or search: type "SRE" in the search bar → filter by Space
```

### Pages and Page Trees

Every page can have child pages — forming a tree structure:

```
SRE Space
├── Runbooks
│   ├── EKS Node Drain Runbook
│   ├── Database Failover Runbook
│   └── Dynatrace Alert Response Guide
├── Postmortems
│   ├── 2026-07 Payment Service Outage
│   └── 2026-06 DNS Failure Incident
├── Architecture
│   ├── EKS Platform Overview
│   └── GitOps Workflow Design
└── Onboarding
    ├── New SRE Checklist
    └── Tool Access Guide
```

**Rule:** always create pages as children of a relevant parent — never at the top level of a Space unless it's a major section. A flat list of hundreds of pages is impossible to navigate.

### Page Versions (History)

Every edit creates a new version. You can see WHO changed WHAT and WHEN.

```
How to see page history:
  → Open any page
  → "..." menu (top right) → "Page history"
  → Click any version to see that snapshot
  → Click "Compare" to see a diff between two versions

This means: never be afraid to edit a page.
Everything is reversible. The old version is always there.
```

---

## Part 2 — Creating and Editing Pages

### Creating a page

```
Method 1 (fastest): 
  → Navigate to the parent page where you want the child to live
  → Click "Create" button (top nav) or "+" next to the parent in the tree
  → New page is automatically a child of the current page

Method 2 (from scratch):
  → "Create" button → search for a template → fill in

Keyboard shortcut:
  → Press "c" anywhere → opens new page creation (no modal, instant)
```

### The Editor — Slash Commands

Type `/` anywhere in a page to open the content block menu:

```
/table          → insert a table
/code           → insert a code block (specify language: bash, python, yaml, etc.)
/info           → insert a blue info panel
/warning        → insert a yellow warning panel
/note           → insert a note panel
/status         → insert a colored status lozenge (e.g., IN PROGRESS, DONE)
/toc            → Table of Contents (auto-generated from headings — use on long pages)
/image          → insert an image
/jira           → embed a Jira issue or JQL query result table
/page link      → link to another Confluence page
/expand         → collapsible section (good for long content you want hidden by default)
/date           → insert a date with @date-picker
/mention        → @mention a person (they get notified)
/decision       → Decision record template (who decided, why, alternatives)
/action item    → inline task with owner + due date
```

### Code Blocks — the most important for SREs

```
/code → choose language → paste your command

Languages that give you syntax highlighting:
  bash, shell, yaml, json, hcl (Terraform), python, java, sql, dockerfile

Example — always use code blocks for:
  Commands engineers must run (never put these in plain text)
  Config file contents
  Error messages to search for
  API request/response examples
```

### Headings and formatting

```
H1  = use for page title only (one per page)
H2  = major sections
H3  = subsections
H4  = rarely needed

Bold    = **key term** or Ctrl+B
Italic  = *emphasis* or Ctrl+I
Inline code = `command` (backticks)

Rule: use headings consistently — they power the Table of Contents (/toc)
and make the page searchable by section.
```

---

## Part 3 — The 5 Most Important Page Types for SREs

### 1. Runbook

A step-by-step guide for responding to a specific alert or operational task.

```
Required sections (template):
  ## Overview
  What alert triggers this runbook. What the impact is.

  ## Symptoms
  What does the alert look like? What do you see in DT/logs?

  ## Immediate Actions (first 5 minutes)
  Numbered steps. Commands to run immediately.

  ## Investigation Steps
  How to find root cause. Specific DT dashboards, kubectl commands.

  ## Resolution Steps
  How to fix the most common causes.

  ## Escalation
  Who to call if you can't resolve in X minutes.

  ## Related Links
  - Jira project
  - Dynatrace dashboard URL
  - Architecture doc
  - Previous postmortems for this service
```

### 2. Postmortem (Incident Report)

Written after an incident. Used to learn, not to blame.

```
Required sections:
  ## Summary
  One paragraph: what broke, when, how long, customer impact.

  ## Timeline
  | Time (JST) | Event |
  |-----------|-------|
  | 14:32     | Alert fired: payment-service availability SLO breach |
  | 14:35     | On-call engineer acknowledged |
  | 14:48     | Root cause identified: DB connection pool exhausted |
  | 15:02     | Fix deployed, traffic recovered |

  ## Root Cause
  The REAL reason (not the symptom). "Why did the DB pool exhaust?"
  Use 5-Whys technique.

  ## Impact
  - Duration: 30 minutes
  - Users affected: ~5,000
  - Revenue impact: ~¥500,000 in failed payments

  ## What Went Well
  Things that worked: good alerts, fast response, good runbook.

  ## What Went Badly
  Things that didn't work: alert fired too late, runbook was wrong.

  ## Action Items
  | Action | Owner | Due Date | Jira ticket |
  |--------|-------|----------|-------------|
  | Increase DB connection pool size | @sre-engineer | 2026-08-07 | PLAT-1234 |

  Rules:
  - Written within 48 hours of incident resolution
  - No blame — name the system failure, not the person
  - Every action item must have a Jira ticket
```

### 3. Architecture Decision Record (ADR)

Documents WHY a technical decision was made — so future engineers don't have to re-litigate it.

```
Required sections:
  ## Status
  [status: ACCEPTED] or [status: SUPERSEDED by ADR-045]

  ## Context
  What problem were you solving? What constraints existed?

  ## Decision
  What we decided. One clear statement.

  ## Alternatives Considered
  | Option | Pros | Cons | Why rejected |
  |--------|------|------|-------------|
  | ArgoCD | GitOps native, good UI | Extra component | NOT rejected — this is what we chose |
  | Flux   | Lighter weight | Worse UI, less community | Chosen UX > component count |

  ## Consequences
  What changes now that we made this decision?
  What new problems does this create?

  ## Related
  Links to other ADRs, Jira epics, architecture diagrams.
```

### 4. Onboarding Guide

Written for new team members. Must be self-contained.

```
Required sections:
  ## Day 1 Checklist
  [ ] Get added to GitHub org
  [ ] Get PagerDuty access
  [ ] Get AWS console access (dev account first)
  [ ] Join Slack channels: #sre-alerts, #sre-team, #platform

  ## Tools and Access
  Table: tool name, how to request access, link to docs.

  ## Architecture Overview
  High-level diagram. Links to architecture ADRs.
  "Read these pages first" list.

  ## First Tasks
  Two or three small, well-defined tasks that help a new person
  learn the codebase by doing.

  ## Who to Ask
  What topic → who is the expert → how to reach them.
```

### 5. Meeting Notes

```
Page title format: YYYY-MM-DD Team Name — Meeting Type
Example: "2026-07-31 SRE Weekly — Sprint Review"

Required sections:
  ## Attendees
  @person1, @person2 (use @mention so they're notified)

  ## Agenda
  1. SLO review
  2. Incident review
  3. Sprint planning

  ## Notes
  What was discussed, decisions made.

  ## Action Items
  Use /action item blocks — assigns tasks with due dates directly in Confluence.
  Alternatively, link to Jira tickets created during the meeting.
```

---

## Part 4 — Search

### Basic search

```
Press / or click the search bar at top
Type keywords → results appear instantly

Filter by:
  Space          → narrows to one team's docs
  Contributor    → find pages written or edited by a person
  Last modified  → find recently changed pages
  Page / Blog    → blogs are team announcements; pages are persistent docs
```

### CQL (Confluence Query Language)

For advanced searches — the same idea as SQL but for Confluence content.

```
Find all pages in the SRE space modified this month:
  space = "SRE" AND lastModified >= startOfMonth()

Find runbooks for payment-service:
  title ~ "payment" AND space = "SRE" AND label = "runbook"

Find pages by a specific person:
  creator = "shuge.kui" AND space = "ENG"

Find all postmortems:
  label = "postmortem" ORDER BY lastModified DESC

Find pages containing a specific Jira ticket:
  text ~ "PLAT-1234"
```

**How to run CQL:**
```
Search bar → type your query → click "Advanced search" → paste CQL
```

---

## Part 5 — Labels

Labels are tags you add to a page to make it searchable by category.

```
How to add a label:
  → Open a page → click the "Label" area at the bottom → type label name → Enter

Common SRE labels:
  runbook          → all runbooks
  postmortem       → all incident reports
  architecture     → architecture docs and ADRs
  onboarding       → new hire guides
  draft            → not ready to share
  deprecated       → outdated, kept for history

Search by label:
  label = "runbook" AND space = "SRE"

Why labels matter:
  Labels let you build "content indexes" — a single page that lists
  all runbooks via a Jira/Confluence macro that queries by label.
  Engineers bookmark that index page instead of searching every time.
```

---

## Part 6 — Permissions and Restrictions

```
Space-level permissions (set by Space Admin):
  Can View     → can read but not edit
  Can Edit     → can create and edit pages
  Admin        → can change Space settings and permissions

Page-level restrictions (set by anyone with edit access):
  Viewing restriction  → only specific people/groups can see this page
  Editing restriction  → only specific people/groups can edit this page

How to set page restriction:
  → Open page → "..." menu → "Restrictions" → set who can view/edit

Common use cases:
  Draft pages      → restrict to yourself until ready
  HR documents     → restrict to HR team
  Sensitive postmortems → view restricted to team + management
```

---

## Part 7 — Watching and Notifications

```
Watch a page:
  → "..." menu → "Watch" → you get emailed/notified on every change

Watch a Space:
  → Space Settings → "Watch this space" → notified when ANY page changes

When you @mention someone:
  → They get a notification immediately

When you add someone as a Page Watcher:
  → They get notified of all future edits

Turn off email notifications:
  → Profile icon → Settings → Email → configure notification frequency
  (Default: immediate. Change to Daily Digest if too noisy.)
```

---

## Part 8 — Linking Confluence ↔ Jira

### From Confluence → Jira

```
In a Confluence page:
  → Paste a Jira issue URL (e.g., https://company.atlassian.net/browse/PLAT-1234)
  → It automatically renders as a status chip:
     [PLAT-1234] Payment DB Connection Pool — IN PROGRESS

  → Use /jira macro to embed a full JQL query table:
     project = PLAT AND label = "postmortem-action" AND status != Done
     → renders a live table of open action items from all postmortems
```

### From Jira → Confluence

```
On any Jira issue:
  → "Link" button → "Confluence Page" → search by title
  → The issue now shows the linked Confluence page in its sidebar

Common patterns:
  Jira Epic ↔ linked to Architecture doc in Confluence
  Jira Bug   ↔ linked to Postmortem in Confluence
  Jira Story ↔ linked to Feature spec in Confluence
```

---

## Part 9 — Confluence for SREs: Daily Workflow

```
Morning:
  → Check "Recent" pages (left sidebar) — see what teammates updated overnight
  → Check watched spaces for new postmortems or architecture changes

During on-call:
  → Alert fires → open runbook from DT alert link (link your DT alerts to runbooks)
  → If no runbook exists → create one after the incident

After an incident:
  → Within 24h: write a postmortem draft (use the template)
  → Within 48h: finalize and share with the team
  → Create Jira tickets for all action items
  → Link the Jira tickets back to the postmortem page

During architecture design:
  → Create an ADR page BEFORE writing code
  → Share with team → collect comments (use inline comments: select text → add comment)
  → Set status to ACCEPTED once agreed → link from the code repo README

Weekly:
  → Review your Space's "Recently Updated" list
  → Update any outdated runbooks or architecture docs
  → Archive (or label "deprecated") pages that are no longer accurate
```

---

## Part 10 — The 10 Rules of Good Confluence Pages

```
1. One page = one topic. Don't cram everything into one giant page.

2. Use headings. H2 for major sections. /toc at the top for long pages.

3. Put commands in code blocks. Never paste bash commands in plain text.

4. Always use page templates. Don't start from a blank page for runbooks/postmortems.

5. Link to related pages. Confluence power comes from connected knowledge.

6. Use @mentions for action items. Not "someone should do this" — @name should do this.

7. Date your pages. Especially runbooks: "Last verified: 2026-07-31 by @shuge.kui"
   Outdated runbooks are dangerous — engineers follow them during incidents.

8. Label everything. At minimum: label as "runbook", "postmortem", "architecture", or "draft".

9. Never delete — deprecate. Add "DEPRECATED" to the title, add label "deprecated",
   add a banner linking to the replacement page. Old pages may be linked from many places.

10. Keep the tree shallow. Max 3–4 levels deep. Deep nesting = nobody finds anything.
```

---

## Keyboard Shortcuts (Must Know)

| Shortcut | Action |
|----------|--------|
| `/` | Open content block menu (in editor) |
| `c` | Create new page (anywhere on site) |
| `g` then `g` | Go to a Space |
| `g` then `d` | Go to Dashboard (home) |
| `e` | Edit current page |
| `Ctrl+S` / `Cmd+S` | Save page |
| `Ctrl+Z` / `Cmd+Z` | Undo |
| `[` | Insert page link (in editor) |
| `@` | Mention a person (in editor) |
| `?` | Show all keyboard shortcuts |
