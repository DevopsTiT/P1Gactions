# Roadmap: java-3envs-dynatrace — Step by Step, Deep Dive

> This is YOUR project in `8_java-3envs-dynatrace-complete/`.
> Reading this roadmap tells you: what to do, in what order, WHY each step must come before the next, and what breaks if you skip it.

---

## The Big Picture — Why This Order?

```
PHASE 0: Prerequisites (accounts, secrets, tools)
         ↓  can't run Terraform without AWS creds + state bucket
PHASE 1: Terraform — VPC + EKS (infra layer)
         ↓  can't install ArgoCD without a Kubernetes cluster
PHASE 2: ArgoCD bootstrap (bootstrap the bootstrapper)
         ↓  can't deploy apps until GitOps controller is running
PHASE 3: ArgoCD manages everything else via waves
         │
         ├── wave -1: Namespaces   ← must exist before anything else
         ├── wave  1: Networking   ← ALB + DNS (need namespaces first)
         ├── wave  2: Secrets      ← ESO (needs IRSA from Phase 1)
         ├── wave  3: Dynatrace    ← OneAgent (needs namespace + secret)
         └── wave  8: Apps         ← services (need all of the above)
         ↓
PHASE 4: Terraform — Dynatrace config (alerts, SLOs, synthetics)
         ↓  can't configure alerts until services emit metrics (wave 8 done)
PHASE 5: CI/CD pipelines — GitHub Actions go live
         ↓  can't promote images to prod without manual approval gate
PHASE 6: Verify & validate end-to-end
```

---

## PHASE 0 — Prerequisites
### WHY FIRST: everything else depends on these existing

### Step 0.1 — AWS accounts (3 separate accounts)
**Why:** dev/staging/production each get their own AWS account.
This means a Terraform mistake in dev CANNOT accidentally delete production infrastructure.
IAM permissions are completely separate. Blast radius is contained.

```
Accounts needed:
  company-dev         (ID: 123456789010)  → ap-northeast-1
  company-staging     (ID: 123456789011)  → ap-northeast-1
  company-production  (ID: 123456789012)  → ap-northeast-1
```

**What you create in each account before Terraform can run:**

| Resource | Purpose |
|----------|---------|
| S3 bucket `company-terraform-state-<env>` | Stores Terraform state file — without this `terraform init` fails |
| DynamoDB table `terraform-state-lock` | Prevents two people running `terraform apply` at the same time → state corruption |
| IAM role for CI | GitHub Actions assumes this role to run Terraform |
| IAM role for EKS nodes | IRSA foundation — EKS nodes need permissions to call AWS APIs |

```bash
# Create state bucket (run in each account)
aws s3api create-bucket \
  --bucket company-terraform-state-dev \
  --region ap-northeast-1 \
  --create-bucket-configuration LocationConstraint=ap-northeast-1

# Enable versioning (lets you recover from bad terraform applies)
aws s3api put-bucket-versioning \
  --bucket company-terraform-state-dev \
  --versioning-configuration Status=Enabled

# Create DynamoDB lock table
aws dynamodb create-table \
  --table-name terraform-state-lock \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region ap-northeast-1
```

### Step 0.2 — Secrets in AWS Secrets Manager
**Why:** Terraform reads Dynatrace credentials from Secrets Manager. If these don't exist, `terraform plan` fails immediately with `ResourceNotFoundException`.
Also: NEVER store API tokens in git files — Secrets Manager is the secure store.

```bash
# Create Dynatrace secrets (run in each account separately)
aws secretsmanager create-secret \
  --name dev/dynatrace/api-token \
  --secret-string "dt0c01.XXXX..." \
  --region ap-northeast-1

aws secretsmanager create-secret \
  --name dev/dynatrace/tenant-url \
  --secret-string "https://abc12345.live.dynatrace.com" \
  --region ap-northeast-1

aws secretsmanager create-secret \
  --name dev/dynatrace/slack-webhooks \
  --secret-string '{"payments":"https://hooks.slack.com/...","orders":"https://hooks.slack.com/...","notifications":"https://hooks.slack.com/..."}' \
  --region ap-northeast-1

# For staging/prod also add PagerDuty keys
aws secretsmanager create-secret \
  --name production/dynatrace/pagerduty-keys \
  --secret-string '{"payments":"pdkey-xxx","orders":"pdkey-yyy","notifications":"pdkey-zzz"}' \
  --region ap-northeast-1
```

### Step 0.3 — GitHub repository secrets
**Why:** GitHub Actions workflows need AWS credentials and Dynatrace token to run.
These go in GitHub Settings → Secrets, not in `.github/workflows/*.yaml` files.

```
GitHub Secrets to create:
  AWS_ROLE_ARN_DEV          → IAM role ARN CI can assume for dev account
  AWS_ROLE_ARN_STAGING      → same for staging
  AWS_ROLE_ARN_PRODUCTION   → same for production
  DEV_ECR_REGISTRY          → 123456789010.dkr.ecr.ap-northeast-1.amazonaws.com
  STAGING_ECR_REGISTRY      → 123456789011.dkr.ecr.ap-northeast-1.amazonaws.com
  PRODUCTION_ECR_REGISTRY   → 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com
```

### Step 0.4 — GitHub Environment: "production" with required reviewers
**Why:** The payment-service-ci.yaml pipeline has `environment: production`. GitHub will pause the pipeline and require human approval before ANY production job runs. Without setting up reviewers, it auto-approves — dangerous.

```
GitHub → Settings → Environments → New Environment: "production"
  → Required reviewers: add your team leads
  → Protection rules: prevent self-approval
```

### Step 0.5 — ECR repositories (one per service per account)
**Why:** Docker images are pushed to ECR. If the repository doesn't exist, `docker push` fails.

```bash
# In each account, create 3 repositories
for svc in payment-service order-service notification-service; do
  aws ecr create-repository \
    --repository-name company/${svc} \
    --image-scanning-configuration scanOnPush=true \
    --encryption-configuration encryptionType=AES256 \
    --region ap-northeast-1
done
```

---

## PHASE 1 — Terraform: VPC + EKS
### WHY: Build the physical infrastructure before anything Kubernetes runs on

**File:** `terraform/environments/dev/main.tf` calls modules `vpc`, `eks`, `dynatrace`.

### Step 1.1 — Run Terraform for DEV first

```bash
cd terraform/environments/dev

# Download all providers (AWS ~300MB first time)
terraform init

# See what will be created — READ THIS OUTPUT carefully
# You'll see: VPC, 3 subnets per AZ, NAT gateways, EKS cluster, node group
terraform plan -out=dev.tfplan

# Create everything (takes ~15-20 minutes for EKS cluster)
terraform apply dev.tfplan
```

**What gets created and why:**

```
VPC (terraform/modules/vpc/main.tf):
  ├── 3 public subnets (one per AZ)  → NAT gateways, ALB sit here
  ├── 3 private subnets (one per AZ) → EKS pods run here (internet-invisible)
  ├── 3 NAT gateways (one per AZ)    → pods can call internet, internet can't reach pods
  │     WHY one per AZ: if AZ-a fails, pods in AZ-b still have outbound internet
  └── S3 VPC endpoint                → ECR image pulls skip NAT → saves $ + faster

EKS (terraform/modules/eks/main.tf):
  ├── EKS control plane               → Kubernetes API server (managed by AWS)
  ├── Private endpoint only           → kubectl only works inside VPC → no public attack surface
  ├── KMS encryption for Secrets      → K8s Secrets encrypted at rest in etcd
  ├── Audit + API logging             → CloudTrail catches "who deleted that pod?"
  ├── System node group (t3.medium)   → nodes that run system pods (CoreDNS, ALB controller)
  ├── IMDSv2 required                 → blocks SSRF attacks that steal node IAM credentials
  └── EBS CSI add-on                  → required for PersistentVolumes on EKS 1.23+
```

**Why dev BEFORE staging BEFORE production:**
- Practice the Terraform workflow where mistakes have no user impact
- Verify the module works before stamping it out to all 3 envs
- Catch account-permission issues in dev first

### Step 1.2 — Connect kubectl to the new cluster

```bash
# Update your local ~/.kube/config to point at the new EKS cluster
aws eks update-kubeconfig \
  --name company-dev \
  --region ap-northeast-1

# Verify connection
kubectl get nodes
# Should show your system nodes (status: Ready)
```

**Why this step:** All ArgoCD bootstrap commands require `kubectl` to be pointing at the right cluster. If you skip this, you'll accidentally bootstrap ArgoCD into the wrong cluster.

### Step 1.3 — Repeat for staging, then production

```bash
# Staging
cd terraform/environments/staging && terraform init && terraform apply

# Production
cd terraform/environments/production && terraform init && terraform apply
```

---

## PHASE 2 — Install ArgoCD (the GitOps Engine)
### WHY: ArgoCD is the system that will manage all other Kubernetes resources. It must exist before it can manage anything.

### Step 2.1 — Install ArgoCD into the dev cluster

```bash
# Switch kubectl context to dev cluster
aws eks update-kubeconfig --name company-dev --region ap-northeast-1

# Create the namespace ArgoCD lives in
kubectl create namespace argocd

# Apply the official ArgoCD manifest (all controllers, CRDs, RBAC)
kubectl apply -n argocd \
  -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# Wait until ArgoCD server is running (takes ~2 min)
kubectl wait \
  --for=condition=available \
  deployment/argocd-server \
  -n argocd \
  --timeout=300s
```

**What you just installed:**
- `argocd-server` — the API/UI server
- `argocd-application-controller` — watches Git, compares to cluster, applies diffs
- `argocd-repo-server` — clones your Git repo and renders Helm charts
- All the CRDs: `Application`, `AppProject`, `ApplicationSet`

### Step 2.2 — Configure ArgoCD to access your Git repo

```bash
# If repo is private, add credentials
argocd repo add https://github.com/company/java-3envs-dynatrace.git \
  --username git \
  --password <github-token>
```

### Step 2.3 — Bootstrap: apply the ONE root application

```bash
# This is the ONLY manual kubectl apply you'll ever need
# After this, ArgoCD manages everything in gitops/dev/ automatically
kubectl apply -f gitops/dev/bootstrap/root-app-dev.yaml
```

**What this file does (root-app-dev.yaml):**
```yaml
spec:
  source:
    path: gitops/dev          ← watches this entire folder
    directory:
      recurse: true           ← finds ALL yaml files recursively
  syncPolicy:
    automated:
      prune: true             ← deletes resources when yaml is removed from git
      selfHeal: true          ← reverts manual kubectl changes
```

This is the **App of Apps** pattern. One apply → ArgoCD discovers and creates ALL other Applications.

### Step 2.4 — Repeat ArgoCD install + bootstrap for staging and production

```bash
# Staging
aws eks update-kubeconfig --name company-staging --region ap-northeast-1
kubectl create namespace argocd
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
kubectl wait --for=condition=available deployment/argocd-server -n argocd --timeout=300s
kubectl apply -f gitops/staging/bootstrap/root-app-staging.yaml

# Production
aws eks update-kubeconfig --name company-prod --region ap-northeast-1
kubectl create namespace argocd
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
kubectl wait --for=condition=available deployment/argocd-server -n argocd --timeout=300s
kubectl apply -f gitops/production/bootstrap/root-app-production.yaml
```

---

## PHASE 3 — ArgoCD Sync Waves (automatic after bootstrap)
### WHY: ArgoCD now manages these. You do NOT manually apply them. But you must understand the order because debugging requires it.

Once the root app is applied, ArgoCD reconciles every 3 minutes (or immediately on a git push). It deploys resources in wave order:

### Wave -1 — Namespaces (gitops/dev/namespaces/namespaces.yaml)
**Why first:** Every other resource needs a namespace to live in.
K8s rejects any resource that references a non-existent namespace with `namespace "X" not found`.

**What it does:**
- Creates namespaces: `payment-ns`, `order-ns`, `notification-ns`, `dynatrace`, `external-secrets`
- Adds labels: `team=payments`, `environment=dev` on each namespace
- These labels are what Dynatrace OneAgent reads to auto-tag services → management zone filtering

```bash
# Verify wave -1 completed
kubectl get namespaces | grep -E "payment|order|notification|dynatrace|external-secrets"
kubectl get namespace payment-ns -o jsonpath='{.metadata.labels}' | jq
# Should show: team=payments, environment=dev
```

### Wave 1 — Networking (ALB Controller + ExternalDNS)
**Why after namespaces:** These controllers run as pods — they need their namespaces to exist first.

**ALB Controller** (`aws-load-balancer-controller.yaml`):
- Watches for `kind: Ingress` resources
- When it sees one, creates an actual AWS Application Load Balancer
- Why it needs IRSA: it calls AWS APIs (CreateLoadBalancer, etc.) → needs IAM permissions

**ExternalDNS** (`external-dns.yaml`):
- Watches for `kind: Ingress` resources
- When it sees one, creates a Route53 DNS record pointing to the ALB
- `domainFilters: [dev.company.com]` prevents it from touching staging/prod DNS

```bash
# Verify wave 1 completed
kubectl get pods -n kube-system | grep aws-load-balancer-controller
kubectl get pods -n kube-system | grep external-dns
```

### Wave 2 — Secrets (External Secrets Operator)
**Why after wave 1:** ESO pods need the namespace and IRSA from Phase 1.
**Why before wave 3:** Dynatrace Operator needs to pull DT API token from Secrets Manager. If ESO isn't running, the ExternalSecret for DT tokens will stay in `SecretSyncError` state.

**What ESO does:**
1. `ClusterSecretStore` — defines HOW to connect to AWS Secrets Manager (region + IRSA)
2. For each `ExternalSecret` (one per service + one for DT tokens):
   - Reads the value from AWS Secrets Manager
   - Creates a native Kubernetes `Secret`
   - Refreshes every 1 hour (picks up rotated credentials automatically)

```bash
# Verify wave 2 completed
kubectl get clustersecretstore
# STATUS should be: Valid

kubectl get externalsecrets -A
# All should show: READY=True, SYNCED=True
```

### Wave 3 — Dynatrace Operator + DynaKube
**Why after wave 2:** The DynaKube resource needs a Kubernetes Secret with the DT API token.
That Secret is created by the ExternalSecret from wave 2. If wave 2 failed, wave 3 gets `secret not found`.

**What happens in wave 3:**
1. DT Operator is deployed (watches for DynaKube resources)
2. DynaKube is applied → Operator reads it and:
   - Deploys `OneAgent` as a DaemonSet (one pod per node)
   - Deploys `ActiveGate` as a Deployment (1 replica in dev, 2 in prod)
3. OneAgent hooks into every JVM process via JVMTI
4. Metrics start flowing to Dynatrace tenant within ~2 minutes

```bash
# Verify wave 3 completed
kubectl get pods -n dynatrace
# Should show: oneagent-XXXXX (one per node), activegate-XXXXX

# Check DynaKube status
kubectl get dynakube -n dynatrace
# PHASE should be: Running
```

### Wave 8 — Applications (payment-service, order-service, notification-service)
**Why last (wave 8):** Apps need EVERYTHING else to be ready:
- Namespace must exist (wave -1) ✓
- ALB must exist to route traffic (wave 1) ✓
- DNS must resolve (wave 1) ✓
- DB credentials must exist as K8s Secrets (wave 2) ✓
- OneAgent must be running to instrument the JVM (wave 3) ✓

**What each app ArgoCD Application does:**
- Renders the Helm chart at `charts/payment-service/`
- Merges `values.yaml` (base/production) + `values-dev.yaml` (dev overrides)
- Applies: Deployment, Service, Ingress, HPA, PDB, ExternalSecret, ServiceAccount

```bash
# Verify wave 8 completed
kubectl get pods -n payment-ns
# Should show 1 running pod (dev has replicas=1)

kubectl get ingress -n payment-ns
# Should show ALB address

# Test the service
curl https://payment.dev.company.com/actuator/health
# {"status":"UP"}
```

---

## PHASE 4 — Terraform: Dynatrace Configuration
### WHY: The Dynatrace module creates management zones, alerts, SLOs, synthetics. You want services running FIRST so Dynatrace has entities to match.

**IMPORTANT ORDER:** Apply Dynatrace Terraform AFTER apps are deployed (wave 8 done).
Reason: management zone rules match by tag `service.name=payment-service`. If the service doesn't exist in Dynatrace yet, the zone is created but has nothing in it — which is fine but wastes a validation step.

```bash
# Dev (already runs from Phase 1 because same terraform/environments/dev/main.tf)
# The dynatrace module block runs together with VPC+EKS
# BUT you can re-apply to update thresholds anytime:
cd terraform/environments/dev
terraform apply -target=module.dynatrace

# Staging
cd terraform/environments/staging
terraform apply -target=module.dynatrace

# Production
cd terraform/environments/production
terraform apply -target=module.dynatrace
```

**What the Dynatrace module creates (8 signal types × 3 services = 24 metric events):**

| Resource | Count (per env) | Purpose |
|----------|----------------|---------|
| Management zones | 3 (one per team) | Scopes UI/alerts to one team's services |
| Alerting profiles | 4 tiers × 3 teams = 12 | Maps severity → notification channel + delay |
| Metric events | 8 signals × 3 services = 24 | Fires alert when signal crosses threshold |
| SLOs | 2 (availability + latency) × 3 = 6 | 30-day rolling SLO compliance |
| HTTP Synthetics | 3 health checks | External probe every 5 min from Tokyo/Singapore |
| PagerDuty notifications | 0 dev / 2 staging / 6 production | Pages on-call for real problems |
| Slack notifications | 6 (2 channels × 3 teams) | Warning/info alerts to team channels |

---

## PHASE 5 — CI/CD Pipelines Go Live
### WHY: Now that all 3 environments are running, the pipelines can promote code through them.

**Nothing to configure** — the `.github/workflows/` files are already in git. They activate automatically when you push code.

### What happens on a code push (payment-service example):

```
git push to main
    │
    ▼
Job 1: test
  ./gradlew test jacocoTestReport
  Requires ≥70% line coverage
  WHY: catch bugs before they leave developer's machine
    │
    ▼
Job 2: build-and-deploy-dev (needs: test)
  docker buildx build --platform linux/amd64,linux/arm64
  push to DEV ECR
  Trivy scan — CRITICAL/HIGH → fail
  sed image tag in gitops/dev/app/payment-service/payment-service.yaml
  git commit [skip ci] + push
  kubectl rollout status --timeout=8m
  WHY sequential to test: no point building if tests fail
    │
    ▼
Job 3: smoke-test-dev (needs: build-and-deploy-dev)
  curl https://payment.dev.company.com/actuator/health
  POST /api/v1/payments — assert status="created"
  WHY: proves the image actually WORKS in the real cluster, not just in unit tests
    │
    ▼
Job 4: deploy-staging (needs: smoke-test-dev)
  docker pull from DEV ECR, push to STAGING ECR (same SHA tag)
  update gitops/staging/ → rollout 10m
  WHY: same bits that passed dev now run in staging — no rebuild
    │
    ▼
Job 5: load-test-staging (needs: deploy-staging)
  k6 run --vus 50 --duration 3m staging_load_test.js
  Fails if error rate >1% OR P99 >800ms
  WHY: validates performance under realistic load before production
    │
    ▼
Job 6: deploy-production (needs: load-test-staging)
  ⚠️  PAUSES HERE — environment: production requires human approval in GitHub UI
  After approval:
    promote STAGING ECR → PRODUCTION ECR
    update gitops/production/ → rollout 12m
  WHY manual gate: irreversible action, real users affected
    │
    ▼
Job 7: verify-production (needs: deploy-production)
  sleep 60 (let the app warm up — JIT compilation takes time)
  curl https://payment.company.com/actuator/health
  POST /api/v1/payments
  If FAIL:
    git log --follow gitops/production/.../payment-service.yaml
    extract previous image tag
    revert file + git commit + push → ArgoCD re-deploys old version in ~3 min
  WHY: production smoke test is your last safety net; auto-rollback limits blast radius
```

---

## PHASE 6 — Verify End-to-End
### WHY: Each layer must be validated before declaring success

### 6.1 — Verify Kubernetes layer

```bash
# All pods running across all namespaces
kubectl get pods -A | grep -v Running | grep -v Completed
# Should be empty — nothing in Error/Pending/CrashLoopBackOff

# Check HPA is scaling correctly
kubectl get hpa -A

# Check PDB is in place for staging/production
kubectl get pdb -n payment-ns

# Check ExternalSecret sync
kubectl get externalsecrets -A
```

### 6.2 — Verify Dynatrace layer

```bash
# In Dynatrace UI:
# 1. Services → payment-service should appear with:
#    - Tags: team:payments, environment:dev
#    - Response time, request count graphs
#    - Management zone: payments-dev

# 2. Synthetic monitors → payment-service Health Check [dev]
#    Should show green checks from Tokyo

# 3. SLOs → payment-service Availability [dev]
#    Should show current compliance % vs 90% target

# 4. Problems → any open alerts?
```

### 6.3 — Verify CI/CD layer

```bash
# Make a small code change, push, watch the pipeline:
# GitHub → Actions → payment-service-ci
# Each job should go: ✓ test → ✓ build → ✓ smoke → ✓ staging → pause → approve → ✓ production → ✓ verify
```

### 6.4 — Verify drift detection (Terraform)

```bash
# Runs daily at 02:00 JST via cron: '0 17 * * *'
# To test manually:
terraform plan -refresh-only -detailed-exitcode
# Exit 0 = no drift (good)
# Exit 2 = drift found → check GitHub Issues for auto-created issue
```

---

## Common Mistakes and How to Avoid Them

| Mistake | Symptom | Fix |
|---------|---------|-----|
| Skipping state bucket creation | `terraform init` fails: `NoSuchBucket` | Create S3 bucket first (Step 0.1) |
| Wrong kubectl context | `kubectl apply` runs against wrong cluster | `kubectl config current-context` before any command |
| Missing DT secrets in Secrets Manager | `terraform plan` fails: `ResourceNotFoundException` | Create secrets in Step 0.2 |
| Wave 2 ESO not ready when wave 3 runs | DynaKube can't get DT token → `SecretSyncError` | Wait for `kubectl get externalsecrets -A` to show SYNCED=True |
| `[skip ci]` missing from gitops commit | CI triggers again, infinite loop of builds | Check CI workflow gitops commit step has `[skip ci]` |
| No GitHub required reviewers on `production` env | Pipeline auto-approves production deploy | Set up reviewers in GitHub Settings (Step 0.4) |
| Dynatrace Terraform applied before apps exist | Management zones match nothing initially | Fine to fix later — re-apply once services are running |
| jdwp `suspend=n` missing | Dev pod stuck at startup waiting for debugger → never passes startupProbe → CrashLoopBackOff | values-dev.yaml: `jvmOpts: "-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005"` |
| ArgoCD ignoring HPA replica count | ArgoCD fights HPA — sets back to 3, HPA scales to 7, repeat | `ignoreDifferences` on `spec.replicas` must be in ArgoCD Application yaml |
