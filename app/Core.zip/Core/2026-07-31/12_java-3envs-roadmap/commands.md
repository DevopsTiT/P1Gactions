# Roadmap Commands — java-3envs-dynatrace

## Phase 0 — Prerequisites

```bash
# ── 0.1 State bucket (run in each AWS account) ──────────────────────────────
aws s3api create-bucket \
  --bucket company-terraform-state-dev \
  --region ap-northeast-1 \
  --create-bucket-configuration LocationConstraint=ap-northeast-1

aws s3api put-bucket-versioning \
  --bucket company-terraform-state-dev \
  --versioning-configuration Status=Enabled

aws dynamodb create-table \
  --table-name terraform-state-lock \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region ap-northeast-1

# ── 0.2 Dynatrace secrets in Secrets Manager ────────────────────────────────
aws secretsmanager create-secret \
  --name dev/dynatrace/api-token \
  --secret-string "dt0c01.REPLACE_ME" \
  --region ap-northeast-1

aws secretsmanager create-secret \
  --name dev/dynatrace/tenant-url \
  --secret-string "https://REPLACE.live.dynatrace.com" \
  --region ap-northeast-1

aws secretsmanager create-secret \
  --name dev/dynatrace/slack-webhooks \
  --secret-string '{"payments":"https://hooks.slack.com/X","orders":"https://hooks.slack.com/Y","notifications":"https://hooks.slack.com/Z"}' \
  --region ap-northeast-1

# ── 0.3 ECR repositories (3 services × 3 accounts) ─────────────────────────
for svc in payment-service order-service notification-service; do
  aws ecr create-repository \
    --repository-name company/${svc} \
    --image-scanning-configuration scanOnPush=true \
    --region ap-northeast-1
done
```

## Phase 1 — Terraform VPC + EKS

```bash
# ── DEV ─────────────────────────────────────────────────────────────────────
cd terraform/environments/dev
terraform init
terraform plan -out=dev.tfplan
terraform apply dev.tfplan          # ~15-20 min

# Connect kubectl to new cluster
aws eks update-kubeconfig --name company-dev --region ap-northeast-1
kubectl get nodes                    # verify nodes are Ready

# ── STAGING ──────────────────────────────────────────────────────────────────
cd ../staging
terraform init && terraform apply
aws eks update-kubeconfig --name company-staging --region ap-northeast-1
kubectl get nodes

# ── PRODUCTION ───────────────────────────────────────────────────────────────
cd ../production
terraform init && terraform apply
aws eks update-kubeconfig --name company-prod --region ap-northeast-1
kubectl get nodes
```

## Phase 2 — ArgoCD Bootstrap

```bash
# ── DEV ─────────────────────────────────────────────────────────────────────
aws eks update-kubeconfig --name company-dev --region ap-northeast-1

kubectl create namespace argocd

kubectl apply -n argocd \
  -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

kubectl wait \
  --for=condition=available \
  deployment/argocd-server \
  -n argocd \
  --timeout=300s

# Bootstrap — ONE command that starts everything
kubectl apply -f gitops/dev/bootstrap/root-app-dev.yaml

# Watch ArgoCD discover and sync all apps
kubectl get applications -n argocd -w

# ── STAGING ──────────────────────────────────────────────────────────────────
aws eks update-kubeconfig --name company-staging --region ap-northeast-1
kubectl create namespace argocd
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
kubectl wait --for=condition=available deployment/argocd-server -n argocd --timeout=300s
kubectl apply -f gitops/staging/bootstrap/root-app-staging.yaml

# ── PRODUCTION ───────────────────────────────────────────────────────────────
aws eks update-kubeconfig --name company-prod --region ap-northeast-1
kubectl create namespace argocd
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
kubectl wait --for=condition=available deployment/argocd-server -n argocd --timeout=300s
kubectl apply -f gitops/production/bootstrap/root-app-production.yaml
```

## Phase 3 — Verify Wave Progression

```bash
# ── Wave -1: Namespaces ───────────────────────────────────────────────────────
kubectl get namespaces | grep -E "payment|order|notification|dynatrace|external-secrets"
kubectl get namespace payment-ns -o jsonpath='{.metadata.labels}' | jq

# ── Wave 1: Networking ────────────────────────────────────────────────────────
kubectl get pods -n kube-system | grep -E "aws-load-balancer|external-dns"
kubectl get pods -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller

# ── Wave 2: Secrets ───────────────────────────────────────────────────────────
kubectl get clustersecretstore
kubectl get externalsecrets -A
# Look for READY=True SYNCED=True on all rows

# ── Wave 3: Dynatrace ─────────────────────────────────────────────────────────
kubectl get pods -n dynatrace
kubectl get dynakube -n dynatrace
# PHASE should be: Running

# ── Wave 8: Applications ──────────────────────────────────────────────────────
kubectl get pods -n payment-ns
kubectl get pods -n order-ns
kubectl get pods -n notification-ns
kubectl get ingress -A

# Test services are up
curl -s https://payment.dev.company.com/actuator/health | jq
curl -s https://orders.dev.company.com/actuator/health | jq
curl -s https://notify.dev.company.com/actuator/health | jq
```

## Phase 4 — Dynatrace Terraform

```bash
# Already applied in Phase 1 (same main.tf)
# To re-apply ONLY Dynatrace config (e.g. after updating thresholds):
cd terraform/environments/dev
terraform apply -target=module.dynatrace

cd terraform/environments/staging
terraform apply -target=module.dynatrace

cd terraform/environments/production
terraform apply -target=module.dynatrace

# Verify Dynatrace drift
terraform plan -refresh-only -detailed-exitcode
# 0 = no drift, 2 = drift exists
```

## Phase 6 — Full Verification

```bash
# ── Kubernetes health ─────────────────────────────────────────────────────────
kubectl get pods -A | grep -v "Running\|Completed"   # should be empty
kubectl get hpa -A
kubectl get pdb -A
kubectl get externalsecrets -A

# ── Specific pod logs (last 50 lines) ─────────────────────────────────────────
kubectl logs -n payment-ns \
  $(kubectl get pod -n payment-ns -l app=payment-service -o jsonpath='{.items[0].metadata.name}') \
  --tail=50

# ── Probe status ──────────────────────────────────────────────────────────────
kubectl describe pod -n payment-ns \
  $(kubectl get pod -n payment-ns -l app=payment-service -o jsonpath='{.items[0].metadata.name}') \
  | grep -A 5 "Liveness\|Readiness\|Startup"

# ── End-to-end smoke test ──────────────────────────────────────────────────────
curl -s -o /dev/null -w "%{http_code}" https://payment.dev.company.com/actuator/health
# Expected: 200

curl -s -X POST https://payment.dev.company.com/api/v1/payments \
  -H "Content-Type: application/json" \
  -d '{"amount": 100, "currency": "JPY"}' | jq '.status'
# Expected: "created"

# ── ArgoCD sync status ────────────────────────────────────────────────────────
kubectl get applications -n argocd
# All should show: SYNC=Synced  HEALTH=Healthy

# ── Drift detection test ──────────────────────────────────────────────────────
cd terraform/environments/dev
terraform plan -refresh-only -detailed-exitcode
echo "Exit code: $?"   # 0=no drift, 2=drift
```
