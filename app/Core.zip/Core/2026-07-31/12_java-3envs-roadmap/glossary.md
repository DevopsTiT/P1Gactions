# Roadmap Glossary — java-3envs-dynatrace

Every term used in main.md, explained for an SRE beginner.

---

**Phase**
A numbered stage in the deployment roadmap. Phases are ordered because each one depends on the previous: you cannot install ArgoCD (Phase 2) before the EKS cluster exists (Phase 1).

**AWS account (separate per environment)**
An isolated AWS environment with its own IAM, billing, and resource limits. Using three separate accounts (dev/staging/production) means a mistake in dev — like accidentally deleting a VPC — physically cannot affect production. The accounts don't share resources.

**S3 state bucket**
An S3 bucket where Terraform stores its state file (`terraform.tfstate`). This file is Terraform's memory of what it created. Without it, every `terraform apply` would try to create everything from scratch, duplicating resources or failing.

**DynamoDB lock table**
A DynamoDB table that acts as a mutex (lock) for Terraform. When someone runs `terraform apply`, it writes a lock record. If a second person tries to apply at the same time, Terraform sees the lock and refuses. Prevents two people corrupting the state file simultaneously.

**AWS Secrets Manager**
AWS's managed service for storing sensitive values like API tokens and database passwords. Values are encrypted at rest. Terraform reads them at runtime — the secrets are never written into `.tf` files or git history.

**ECR (Elastic Container Registry)**
AWS's Docker image registry. Like Docker Hub but private to your AWS account. Each service's Docker image is pushed here after CI builds it. EKS pulls images from ECR when starting pods.

**`terraform init`**
The first Terraform command, run once per new environment. Downloads the provider plugins (e.g. the AWS provider, the Dynatrace provider) and configures the S3 backend for state storage. Like `npm install` before you can run a Node project.

**`terraform plan`**
Reads your `.tf` files and current state, then shows a diff: what would be CREATED (+), MODIFIED (~), or DESTROYED (-). It changes nothing. Think of it as a dry run. Always read the plan before applying.

**`terraform apply`**
Actually executes the changes shown in `terraform plan`. Creates/modifies/destroys real AWS resources. Irreversible for some operations (deleted resources are gone). The `-target` flag limits apply to only one module.

**VPC (Virtual Private Cloud)**
Your private network inside AWS. EKS pods run inside the VPC. Nothing outside (public internet) can reach pods directly. The VPC defines IP address ranges (CIDRs), routing tables, and which subnets are public vs. private.

**Public subnet**
A subnet that has a route to the Internet Gateway. Resources here can be reached from the internet. Used for: NAT Gateways, AWS Load Balancers. EKS pods do NOT run here.

**Private subnet**
A subnet with no direct route to the internet. EKS pods run here — they cannot be reached directly from the internet. Outbound internet access goes through the NAT Gateway.

**NAT Gateway**
Allows pods in private subnets to initiate outbound connections (e.g. calling an external API, pulling Docker images) while remaining unreachable inbound. One per AZ means each AZ is independent — if AZ-a loses its NAT, pods in AZ-b are unaffected.

**AZ (Availability Zone)**
A physically separate data center within an AWS region. `ap-northeast-1` (Tokyo) has 3 AZs: `1a`, `1b`, `1c`. Spreading resources across AZs means one physical failure doesn't take down your service.

**EKS (Elastic Kubernetes Service)**
AWS's managed Kubernetes. AWS runs the control plane (API server, etcd, scheduler) for you. You only manage the worker nodes and what runs on them.

**EKS control plane**
The Kubernetes API server and its supporting components (etcd, scheduler, controller-manager). Managed entirely by AWS — you never SSH into it. You interact with it via `kubectl`.

**Private endpoint (EKS)**
`cluster_endpoint_public_access = false` means the Kubernetes API server is only reachable from inside the VPC. No one on the internet can attempt to connect to it, even with stolen credentials.

**IMDSv2**
EC2 Instance Metadata Service v2. A security hardening of the metadata endpoint that EC2 nodes expose. Requires a session token to query, which blocks a class of attack (SSRF) where a malicious pod could steal the node's IAM credentials.

**KMS encryption (etcd)**
Kubernetes Secrets are stored in etcd. Without KMS encryption, they are base64-encoded — readable by anyone with etcd access. KMS encrypts them at rest with a key managed by AWS Key Management Service.

**ArgoCD**
A GitOps tool that runs inside Kubernetes. It watches a Git repository and automatically applies any Kubernetes YAML it finds to the cluster. The cluster's state always matches what's in Git.

**GitOps**
A practice where Git is the single source of truth for infrastructure and application configuration. To change anything in the cluster, you change a file in Git. ArgoCD then applies that change. You never run `kubectl apply` manually in day-to-day operations.

**App of Apps pattern**
A design where one ArgoCD Application watches a folder containing more ArgoCD Application YAMLs. The root app discovers and manages all child apps. One `kubectl apply` bootstraps an entire environment.

**Sync wave**
An ArgoCD mechanism to control deployment order. Resources with lower wave numbers deploy first. Wave -1 (namespaces) → wave 1 (networking) → wave 2 (secrets) → wave 3 (monitoring) → wave 8 (apps). ArgoCD will not start wave N+1 until wave N is healthy.

**`selfHeal: true`**
ArgoCD setting that automatically reverts manual `kubectl edit` or `kubectl patch` changes. Within ~3 minutes, ArgoCD notices the cluster state diverged from Git and re-applies the Git version. Git wins.

**`prune: true`**
ArgoCD setting that deletes Kubernetes resources when their YAML is removed from Git. Without it, deleting a file from Git leaves the orphaned resource running forever.

**ExternalSecret**
A Kubernetes custom resource (CRD) that says "fetch this value from AWS Secrets Manager and put it in a Kubernetes Secret." The ESO controller does the actual fetching and keeps it refreshed.

**ESO (External Secrets Operator)**
The Kubernetes controller that processes ExternalSecret resources. It runs as a pod in the cluster and calls AWS Secrets Manager (via IRSA) to fetch secrets.

**ClusterSecretStore**
An ESO resource that defines the connection details for AWS Secrets Manager: which region, which IAM role to use. Cluster-scoped, meaning all namespaces can use it.

**IRSA (IAM Roles for Service Accounts)**
The mechanism that gives a Kubernetes pod AWS IAM permissions without putting any credentials into the pod or Git. The pod's ServiceAccount is annotated with an IAM role ARN. When the pod starts, the AWS SDK automatically gets temporary credentials.

**DynaKube**
A Kubernetes custom resource defined by the Dynatrace Operator. It's the configuration for how Dynatrace is deployed in the cluster: OneAgent DaemonSet, ActiveGate replicas, which features to enable.

**Dynatrace Operator**
A Kubernetes controller that watches for DynaKube resources and deploys the Dynatrace monitoring stack accordingly. When you apply a DynaKube, the Operator creates the OneAgent DaemonSet and ActiveGate Deployment automatically.

**OneAgent DaemonSet**
A DaemonSet means one pod runs on every node. Each OneAgent pod hooks into every JVM process on its node via JVMTI, giving Dynatrace full visibility into Spring Boot services — response times, error rates, heap usage — with zero code changes.

**ActiveGate**
A Dynatrace component that acts as a local relay. OneAgent pods send data to ActiveGate (one TCP connection per cluster), and ActiveGate batches and forwards it to the Dynatrace SaaS tenant. Also handles Kubernetes API monitoring.

**Management zone**
A Dynatrace filter that scopes what you see in the UI and what alerts you receive. `payments-production` zone shows only services tagged `team:payments AND environment:production`. Each team only sees their own services.

**Metric event**
A Dynatrace configuration that fires a problem when a metric crosses a threshold. "If `error_rate > 0.1%` for 3 consecutive minutes, create a problem." This project creates 8 per service (traffic, errors, latency, CPU, memory, JVM heap, pod restarts, network errors).

**SLO (Service Level Objective)**
A numeric target for reliability. "99.9% of requests must succeed over a rolling 30-day window." Dynatrace tracks actual compliance and the error budget (how many failures are allowed before the target is missed).

**Error budget burn rate**
How fast you're consuming your SLO error budget. At `14.4×` burn rate, you'll exhaust the monthly budget in 2 days. Dynatrace fires alerts at fast-burn (14.4×) and slow-burn (3.0×) rates so you can act before the SLO is breached.

**HTTP Synthetic monitor**
An active probe that Dynatrace's external nodes (Tokyo, Singapore) run every 5 minutes. It sends a real HTTP request to your service's health endpoint and validates the response. Catches outages that internal monitoring might miss (e.g. DNS failure, firewall misconfiguration).

**GitHub Actions**
CI/CD built into GitHub. YAML files in `.github/workflows/` define automated jobs that run when code is pushed, PRs are opened, or on a schedule.

**CI pipeline (payment-service-ci.yaml)**
The 7-job automation that takes a code push all the way to production: test → build → dev deploy → dev smoke test → staging deploy → load test → production gate → production deploy → verify → auto-rollback if broken.

**`environment: production` (GitHub)**
A GitHub Actions feature that creates an approval gate. The pipeline pauses at any job with this setting and waits for a designated reviewer to click Approve. Without this, code would auto-deploy to production on every push.

**Trivy**
An open-source Docker image scanner. Scans images against CVE databases. If a CRITICAL or HIGH vulnerability is found, the CI step fails and the image is never pushed to any environment.

**k6**
A load testing tool. Sends configurable numbers of concurrent users (VUs) to your service for a set duration. Validates that error rate and latency stay within acceptable bounds under real-world traffic patterns.

**Auto-rollback**
The logic at the end of `verify-production`: if production smoke tests fail after a deploy, the CI script finds the previous working image tag from git log, reverts the gitops YAML to that tag, and pushes. ArgoCD then re-deploys the old version.

**`[skip ci]`**
A special string in a git commit message that tells GitHub Actions NOT to run any workflows for that commit. Required when CI writes image tag updates back to the gitops repo — otherwise that commit triggers CI again, causing infinite loops.

**Drift detection**
A daily scheduled Terraform job that checks whether real AWS infrastructure matches what Terraform expects. If someone manually changed a resource in the AWS console, this job detects the difference and creates a GitHub Issue.

**`-detailed-exitcode`**
A Terraform plan flag that changes exit code 0 to mean "no changes" and exit code 2 to mean "changes exist." Required for drift detection scripts to distinguish "plan ran cleanly with no diff" from "plan ran cleanly but found differences."

**PDB (PodDisruptionBudget)**
A Kubernetes resource that limits how many pods can be taken offline at once during voluntary disruptions (node drains, upgrades). `minAvailable: 2` on a 3-replica deployment means at most 1 pod can be evicted at a time.

**HPA (HorizontalPodAutoscaler)**
Automatically adjusts the number of pod replicas based on CPU and memory usage. When traffic spikes, HPA scales up. When traffic drops, HPA scales down (slowly, to avoid oscillation).

**Helm chart**
A package for Kubernetes applications. A directory of YAML templates plus a `values.yaml`. Helm fills in the templates with values at render time. Per-environment differences (replicas, resource limits) are in `values-dev.yaml` and `values-staging.yaml` overlays.

**`topologySpreadConstraints`**
Kubernetes configuration that distributes pods across AZs. In production, `DoNotSchedule` means a pod stays Pending rather than schedule in an already-overloaded zone. Prevents all pods clustering in one AZ and making the service AZ-dependent.

**readinessProbe**
Kubernetes checks this endpoint continuously. If it returns unhealthy, Kubernetes stops routing traffic to the pod (removes it from the Service). The pod is NOT restarted — it just receives no traffic until it recovers.

**livenessProbe**
Kubernetes checks this endpoint continuously. If it fails repeatedly, Kubernetes kills and restarts the container. Reserved for truly stuck/deadlocked processes that can't recover on their own.

**startupProbe**
Only runs during pod startup. Gives slow-starting JVM applications time to initialize before readiness/liveness checks begin. Dev uses a high `failureThreshold` because cold-start image pulls on t3.medium take longer.

**preStop lifecycle hook**
A command run inside the container before Kubernetes sends the shutdown signal (SIGTERM). `sleep 15` gives the AWS ALB time to deregister the pod from its target group before the app starts shutting down. Prevents in-flight requests from being dropped.

**Graceful shutdown**
Spring Boot's `server.shutdown: graceful` makes the app finish all in-flight requests before exiting after receiving SIGTERM. Combined with preStop sleep: zero dropped requests during rolling updates.
