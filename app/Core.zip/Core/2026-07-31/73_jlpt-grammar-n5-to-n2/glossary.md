# JLPT Grammar N5–N2: Glossary

Every grammatical term and concept used in main.md, explained in plain language.

---

## Core Grammatical Terms

**Particle (助詞 じょし)**
A short word attached after a noun, verb, or adjective that shows the grammatical role of that word in the sentence. Japanese uses particles instead of word order to show who is doing what. Examples: は、が、を、に、で、へ、と、も、の、か.

**Topic marker は (wa)**
Marks what the sentence is "about." Not always the subject. は tells the listener "I'm now talking about THIS." 私は学生です = As for me, I am a student. The topic can be the object, place, or time — not just the actor.

**Subject marker が (ga)**
Marks the grammatical subject — the thing doing or being. Used when something new is introduced, with adjectives of emotion/ability (好き、できる), and in subordinate clauses. 猫が好き = I like cats (cats are the focus).

**Transitive verb (他動詞 たどうし)**
A verb that takes a direct object — it acts ON something. 食べる (eat), 飲む (drink), 書く (write). The object is marked with を.

**Intransitive verb (自動詞 じどうし)**
A verb that describes a state or event without acting on an object. 起きる (get up), 始まる (begin), 落ちる (fall). No を needed.

**Volitional verb (意志動詞 いしどうし)**
An action the subject consciously chooses to do. 行く (go), 勉強する (study). Used with ために for purpose.

**Non-volitional verb / adjective**
Something that happens naturally or is a state beyond the speaker's control. 雨が降る (it rains), 疲れる (get tired). Used with ように for purpose/hope.

**て-form**
The conjunctive form of verbs and adjectives used to connect clauses, make requests (〜てください), express ongoing actions (〜ている), and compound verb patterns (〜てしまう、〜ておく、〜てある、〜てみる). Every Japanese verb has a て-form.

**Plain form (普通形 ふつうけい)**
The casual, dictionary form of verbs and adjectives. Used before と思う、らしい、はずだ、わけだ、のに、ものの, and many grammar patterns. 行く、食べる、高い、静かだ.

**Stem form (ます-stem)**
The verb form before ます. 食べ (eat)、行き (go)、起き (wake up). Used for compound verbs, 〜ながら, 〜に行く/来る, 〜たい.

**Potential form**
Expresses ability: can do / be able to do. 食べられる (can eat), 話せる (can speak). Different from passive (which looks the same for ichidan verbs).

**Causative form (使役形 しえきけい)**
Expresses making or letting someone do something. 食べさせる = make/let someone eat. 行かせる = make/let someone go.

**Causative-passive (使役受身 しえきうけみ)**
The passive form of the causative. "I was made to do X." 食べさせられる = I was made to eat. Often expresses being forced against one's will.

**Passive form (受身形 うけみけい)**
Expresses receiving an action. Two main types: direct passive (something is done to you) and adversative passive (you are inconvenienced by an action).

**Adversative passive (迷惑受身 めいわくうけみ)**
Japanese passive where the subject is inconvenienced by someone's action. 雨に降られた = I was caught in the rain (the rain inconvenienced me).

**Indirect passive (間接受身 かんせつうけみ)**
The subject is negatively affected by an action done to something they possess. 財布を盗まれた = My wallet was stolen (I was the one harmed).

**Conditional form (条件形)**
A verb or adjective form that sets up an "if/when" condition. Japanese has four main conditionals: たら、ば、と、なら — each with different nuance.

**Subordinate clause (従属節 じゅうぞくせつ)**
A clause that functions inside a larger sentence. の that, こと that, と思う (I think that...). In Japanese, the subordinate clause always comes BEFORE the main verb.

---

## Grammar Pattern Concepts

**Concession (逆接 ぎゃくせつ)**
"Even though / although / despite." Acknowledges a fact but shows that the expected result did NOT happen. Key patterns: のに、ても、ながらも、にもかかわらず、ものの、とはいえ.

**Expectation (予期 よき)**
What the speaker expects to be true based on logic or knowledge. Key patterns: はずだ (should be), にちがいない (must be), でしょう (probably).

**Conjecture (推量 すいりょう)**
The speaker's guess about something uncertain. Key patterns: かもしれない (maybe), でしょう (probably), らしい (seems like), ようだ (appears), そうだ (looks like).

**Hearsay (伝聞 でんぶん)**
Information the speaker received from someone else — not personally witnessed. そうです (I heard that...), らしい (apparently), によると (according to).

**Purpose (目的 もくてき)**
Why the speaker does something. ために (in order to — volitional), ように (so that a state results — non-volitional).

**Result (結果 けっか)**
What comes out of an action or process. 〜結果 (as a result of), 〜末に (after a long process), 〜あげくに (after all that effort, often negative).

**Scope / Limit (範囲・限定 はんい・げんてい)**
How much, how far, or restricted to what. だけ (only, neutral), しか〜ない (only, implies insufficiency), 〜に過ぎない (nothing more than), 〜限り (as long as / as far as).

**Degree (程度 ていど)**
How much or to what extent. ほど〜ない (not as... as), ほど〜 (to the extent that), だけあって (as expected of), だけに (all the more).

**Addition (添加 てんか)**
Adding information on top. うえに (in addition, same direction), に加えて (in addition to), ばかりか (not only... but also), はもちろん (needless to say).

**Contrast (対比 たいひ)**
Showing two things are different. 一方で (on the other hand), に対して (in contrast to), にもかかわらず (despite).

---

## Pattern-Specific Explanations

**〜は vs 〜が**
The most fundamental distinction. は = topic (what the sentence is about). が = subject (who/what is doing or being). In short sentences they often look interchangeable, but は implies contrast or topic shift, while が marks new information or emphasizes the subject.

**〜から vs 〜ので**
Both mean "because." から sounds more personal, assertive, and casual. ので sounds more objective, polite, and formal. In formal writing and speech, ので is preferred. After a casual plain form, から feels more natural.

**〜たら vs 〜ば vs 〜と vs 〜なら (four conditionals)**
All mean "if/when" but differ in nuance:
- たら: most versatile — completed action → result. Works for past, future, requests.
- ば: ideal/hypothetical condition — often implies the speaker wishes reality were different.
- と: automatic natural result — laws of nature, directions, instructions.
- なら: given that / based on new information just received.

**〜ている (continuous vs state)**
The most important double meaning in Japanese. With action verbs: ongoing action (currently eating). With change-of-state verbs: the resulting state (is married = got married and remains so). 死んでいる = is dead. 死んでいる does NOT mean "is dying."

**〜てある vs 〜ている vs 〜ておく**
Three て+補助動詞 (auxiliary verb) patterns.
- てある: someone did it intentionally, result is still visible. 窓が開けてある = the window was opened (and is still open).
- ている: currently happening OR current state.
- ておく: done in advance for a future purpose. 準備しておく = prepare in advance.

**〜てしまう (completion vs regret)**
Two uses. When describing completing something: 宿題をやってしまった = I've finished my homework. When expressing regret or unintended consequence: 忘れてしまった = I ended up forgetting (regret).

**〜はずだ vs 〜わけだ**
はずだ = I expect X to be true because of logic. 彼は知っているはずだ = He should know (based on my reasoning).
わけだ = Now I understand why / it makes sense. 彼は10年いたわけだから詳しい = Since he was there 10 years, it makes sense he knows it well.

**〜わけにはいかない vs 〜わけではない**
わけにはいかない = I cannot afford to / I must not (social/moral obligation prevents it).
わけではない = It doesn't mean that / it's not necessarily the case (denying a natural assumption).

**〜らしい vs 〜ようだ vs 〜そうだ**
Three "seems like" patterns, each from different evidence.
- らしい: indirect evidence, hearsay, or characteristic. 彼は転職するらしい = apparently he's changing jobs (I heard).
- ようだ: direct observation and inference. 彼は疲れているようだ = he appears tired (I can see it).
- そうだ (appearance): visual appearance, about to happen. 雨が降りそうだ = it looks like it's going to rain (sky is dark).
- そうだ (hearsay): something you heard from someone. 明日は休みだそうだ = I heard tomorrow is a holiday.

**〜のに vs 〜ても**
Both are concessive "even though / even if" but differ in tone.
のに: the speaker expected a specific result and is DISAPPOINTED or SURPRISED that it didn't happen. たくさん食べたのに、まだ腹が減る = I ate a lot and yet I'm still hungry (complaint).
ても: neutral — even if X happens, Y is still the case. 雨が降っても行きます = Even if it rains, I will go (no emotional nuance).

**〜うちに vs 〜あいだに**
Both mean "while / during." うちに implies urgency — the opportunity or state may end. 忘れないうちに書いておく = write it before you forget. あいだに is more neutral: 彼が寝ているあいだに帰った = I went home while he was sleeping (just a time frame).

**〜ながら (simultaneous) vs 〜ながら(も) (contrast)**
Same word, two meanings depending on context.
- Simultaneous: 音楽を聴きながら勉強する = study while listening to music.
- Contrast (ながらも): 忙しいながらも笑顔だった = Even though (she was) busy, she was smiling.

**〜ざるを得ない vs 〜ずにはいられない vs 〜かねない**
Three "cannot help" patterns.
- ざるを得ない: forced to do it by external circumstances. 規則だから従わざるを得ない = I have no choice but to follow the rules.
- ずにはいられない: internal uncontrollable urge. 笑わずにはいられない = I can't help laughing.
- かねない: there's a risk it might happen (negative). 失敗しかねない = there's a risk of failure.

**〜に過ぎない (にすぎない)**
"Nothing more than / merely." Downplays or limits. これは推測に過ぎない = this is nothing more than speculation. Shows the speaker is being modest or precise about the scope of a claim.

**〜ばかりか vs 〜だけでなく**
Both mean "not only... but also." ばかりか is stronger and often implies the second item is more surprising. だけでなく is more neutral.

**〜うえに (on top of / in addition)**
Adds a second fact that goes in the SAME direction as the first. Both positive or both negative. 高いうえにまずい = It's expensive AND on top of that, it tastes bad (both negative). Not used when the two facts contrast.

**〜をはじめ(として)**
"Starting with / beginning with." Introduces an important representative example before listing others. 社長をはじめ全員が出席 = starting with the president, everyone attended (the president is the main example; others follow).

**〜をめぐって**
"Over / centering around." Used for controversies, debates, disputes. その問題をめぐって議論が続く = debate continues over that issue. Implies the topic is contested.

**〜に際して (にさいして)**
"On the occasion of / at the time of (a formal event)." More formal than 〜とき. Used for significant occasions: 卒業に際して = on the occasion of graduation. Implies the moment deserves special attention.

**〜に基づいて (にもとづいて)**
"Based on / in accordance with." Used with data, rules, evidence, laws. データに基づいて = based on data. More formal than をもとに.

**〜をもとに(して)**
"Based on / using as a starting point." Used with stories, experiences, facts that were used as material. 実話をもとにした映画 = a film based on a true story. Slightly less formal than に基づいて.

**〜をとおして / 〜をとおじて (through)**
Two senses: (1) via/through a medium (インターネットを通じて = through the internet), (2) throughout a period (一年を通じて = throughout the year).

**〜にわたって (spanning)**
Covers a range of time or space. 3日間にわたって = spanning 3 days. 全国にわたる = spanning the whole country. Emphasizes the breadth or duration.

**〜からこそ**
"It's precisely because / exactly because." Emphasizes that X is the exact and specific reason for Y. More emphatic than から alone. 信頼しているからこそ言うんだ = It's precisely BECAUSE I trust you that I'm saying this.

**〜だけあって**
"As expected of / it makes sense because." Used when someone or something lives up to their reputation. さすが専門家だけあって詳しい = As expected of an expert, they know it in detail. The merit justifies the result.

**〜だけに**
"All the more because / precisely because (so the impact is stronger)." 期待が大きかっただけに失望も大きかった = All the more because expectations were high, the disappointment was great. The first clause amplifies the second.

**〜あまり (あまりに〜、〜のあまり)**
"So much that / due to excess of." Too much emotion or degree → an unexpected result. 嬉しさのあまり泣いた = I was so happy I cried. 緊張のあまり言葉が出なかった = I was so nervous I couldn't speak.

**〜かねる**
"Cannot bring oneself to / find it difficult to." Used as a formal, polite way to refuse or decline. お答えしかねます = I'm afraid I cannot answer that. Very common in business Japanese for polite refusals.

**〜てでも**
"Even if I have to / by any means necessary." Shows strong determination. 借金してでもやりたい = Even if I have to borrow money, I want to do it.

---

## Formality Levels

**Casual / Conversational (口語 こうご)**
Used with friends, family, in diary writing. Plain form verbs. Short contractions. から over ので. のに over にもかかわらず.

**Polite / Standard (丁寧語 ていねいご)**
です/ます forms. Appropriate for most daily situations, classroom, strangers. ので preferred over から.

**Formal / Written (書き言葉 かきことば)**
Used in news articles, academic essays, business documents. において、ゆえに、のみ、およびappear. Longer, more complex sentences.

**Keigo (敬語)**
The full honorific system. Sonkeigo (尊敬語) honors the listener/third party's actions. Kenjōgo (謙譲語) humbles your own actions. Teineigo (丁寧語) is basic politeness. N2 requires understanding and using all three correctly.

---

## Study Terms

**SRS (Spaced Repetition System)**
A study method that shows you a flashcard more often when you struggle with it. The optimal method for grammar pattern memorization alongside vocabulary.

**Output practice**
Using grammar patterns in your own sentences (writing or speaking), not just recognizing them in reading/listening. Critical for JLPT 問題8 (sentence composition) which requires you to actively construct sentences.

**Pattern substitution drill**
Taking one grammar pattern and making 5+ sentences with different vocabulary. The fastest way to internalize patterns so they become automatic.
