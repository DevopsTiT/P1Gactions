# JLPT Grammar Patterns: N5 → N2 Complete Reference

> **How to read this file:**
> Each entry shows: pattern → meaning → formation → example (Japanese + English translation)
> Patterns are organized level by level, then grouped by function within each level.
> N5 builds the foundation. Each level adds complexity on top of what came before.

---

## Decision Tree — Which Level Am I At?

```
Can you build a basic sentence with は/が/を/に/で?
  NO  → Start at N5
  YES → Can you explain reasons, give conditions with ば/たら/なら?
          NO  → N4
          YES → Can you express concession (のに), expectation (はず), hearsay (らしい)?
                  NO  → N3
                  YES → Can you handle formal written style (において、にもかかわらず)?
                          NO  → N2
                          YES → N1 territory
```

---

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# N5 — Foundation Grammar
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## N5-1 — Core Particles

**は (topic marker)**
Marks the topic of the sentence. Not necessarily the grammatical subject.
```
私は学生です。
I am a student.
```

**が (subject marker)**
Marks the grammatical subject, especially with adjectives of feeling/ability, and in relative clauses.
```
猫が好きです。      (I like cats — が marks what is liked)
雨が降っています。   (It is raining — が marks the subject)
```

**を (object marker)**
Marks the direct object of a transitive verb.
```
水を飲みます。
I drink water.
```

**に (direction / time / location of existence)**
Direction of movement, point in time, or location where something exists.
```
東京に行きます。      (direction: going to Tokyo)
3時に起きます。       (time: wake up at 3)
部屋に猫がいます。    (existence: a cat is in the room)
```

**で (location of action / means / cause)**
Where an action takes place, the means/tool used, or cause.
```
図書館で勉強します。  (action location: study at the library)
バスで来ました。      (means: came by bus)
病気で休みました。    (cause: took off due to illness)
```

**へ (direction — softer than に)**
Direction of movement (interchangeable with に for direction, but more literary).
```
学校へ行きます。
Going to school.
```

**の (possession / noun modification)**
Possession, or linking two nouns (the first modifies the second).
```
私の本       (my book)
日本語の先生  (Japanese language teacher)
```

**と (and / with)**
Connecting nouns (and), or doing something together with.
```
パンとバターを食べます。   (bread and butter)
友達と映画を見ます。       (watch a movie with a friend)
```

**も (also / too)**
Replaces は、が、を to mean "also" or "too."
```
私も行きます。   (I will also go.)
```

**か (question marker)**
Added to the end of a sentence to form a question.
```
これは本ですか？
Is this a book?
```

---

## N5-2 — Verb Forms

**〜ます / 〜ません / 〜ました / 〜ませんでした**
Polite present/future affirmative / negative / past affirmative / past negative.
```
食べます       I eat / will eat
食べません     I don't eat / won't eat
食べました     I ate
食べませんでした I didn't eat
```

**〜て form (connecting actions)**
Connect sequential actions, or make requests.
```
起きて、顔を洗って、朝ごはんを食べます。
I wake up, wash my face, and eat breakfast.
```

**〜ている**
Ongoing action (continuous) OR resulting state.
```
食べています。     (currently eating — action ongoing)
結婚しています。   (is married — resulting state)
```

**〜たい**
Want to do. Attach to verb stem.
```
日本に行きたいです。
I want to go to Japan.
```

**〜てください**
Please do (polite request).
```
ここに名前を書いてください。
Please write your name here.
```

**〜てもいいですか**
May I / Is it okay if I?
```
写真を撮ってもいいですか？
May I take a photo?
```

**〜てはいけません**
Must not / not allowed to.
```
ここでタバコを吸ってはいけません。
You must not smoke here.
```

---

## N5-3 — Adjectives

**い-adjective + です**
```
この本は面白いです。    This book is interesting.
```

**な-adjective + です**
```
彼女はきれいです。      She is beautiful/clean.
```

**い-adjective past → かった + です**
```
昨日は寒かったです。    Yesterday was cold.
```

**な-adjective past → じゃなかった / ではなかった**
```
元気じゃなかったです。  I wasn't well.
```

**い-adjective + て form (connecting)**
Remove い, add くて.
```
この部屋は広くて、明るいです。
This room is spacious and bright.
```

---

## N5-4 — Core Sentence Patterns

**〜は〜です (A is B)**
```
私は日本人です。
I am Japanese.
```

**〜は〜がいます / あります (existence)**
いる = animate (people/animals), ある = inanimate (things/places).
```
公園に子供がいます。   There are children in the park.
机の上に本があります。  There is a book on the desk.
```

**〜から〜まで (from〜to〜)**
```
東京から大阪まで新幹線で2時間です。
It takes 2 hours by Shinkansen from Tokyo to Osaka.
```

**〜より〜のほうが (A is more 〜 than B)**
```
犬より猫のほうが好きです。
I like cats more than dogs.
```

**〜どのくらい / どのぐらい (how long / how much)**
```
東京までどのくらいかかりますか？
How long does it take to get to Tokyo?
```

**〜ましょう / 〜ましょうか (let's / shall we)**
```
一緒に行きましょう。    Let's go together.
何を食べましょうか？    What shall we eat?
```

---

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# N4 — Expanding Expression
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## N4-1 — Conditionals

**〜たら (after/if — general conditional)**
When X happens → Y. Covers: if, when, after. Most versatile conditional.
```
駅に着いたら、電話してください。
When you arrive at the station, please call me.

もっとお金があったら、旅行したい。
If I had more money, I would want to travel.
```

**〜ば (if — hypothetical / ideal condition)**
Hypothetical. The speaker often implies the result is different from reality.
Formation: u-verb → e + ば. Adj → remove い + ければ.
```
もっと練習すれば、上手になれる。
If you practice more, you can get good.

安ければ買います。
If it's cheap, I'll buy it.
```

**〜と (natural result / habitual result)**
When X → Y always / naturally happens. Also used for instructions/directions.
```
この道を行くと、駅があります。
If you go down this road, there is a station.

春になると、桜が咲きます。
When spring comes, the cherry blossoms bloom.
```

**〜なら (if it's the case that / given that)**
Based on what I've just heard or what the situation is. Often responds to information.
```
日本に行くなら、京都も訪ねてみて。
If you're going to Japan, try visiting Kyoto too.
（前提: I just heard you're going to Japan）
```

---

## N4-2 — Giving and Receiving

**あげる / もらう / くれる (basic give/receive)**
```
友達にプレゼントをあげた。     (I gave a present to a friend.)
先生にほめてもらった。        (I was praised by the teacher — received the action.)
友達がケーキをくれた。        (A friend gave me cake.)
```

**〜てあげる / 〜てもらう / 〜てくれる (action giving/receiving)**
```
荷物を持ってあげた。          (I carried the luggage for them.)
先生に説明してもらった。      (I had the teacher explain to me.)
友達が助けてくれた。          (A friend helped me.)
```

---

## N4-3 — Permission and Obligation

**〜てもいい (it's okay to / may)**
```
ここで食べてもいいですか？
Is it okay to eat here?
```

**〜なければならない / 〜なければいけない (must / have to)**
```
もっと勉強しなければならない。
I must study more.
```

**〜なくてもいい (don't have to / not necessary)**
```
今日は来なくてもいいですよ。
You don't have to come today.
```

**〜てはいけない (must not)**
```
授業中にスマホを使ってはいけません。
You must not use smartphones during class.
```

---

## N4-4 — Ability and Potential

**〜ことができる (can / be able to)**
Formal potential expression.
```
私は泳ぐことができます。
I am able to swim.
```

**Potential form (〜られる / 〜える)**
Conjugated potential.
```
日本語が話せます。          (can speak Japanese)
漢字が読めますか？          (can you read kanji?)
```

---

## N4-5 — Experience and Trying

**〜たことがある (have done before — experience)**
```
富士山に登ったことがあります。
I have climbed Mt. Fuji before.
```

**〜てみる (try doing)**
```
この料理を作ってみます。
I'll try making this dish.
```

---

## N4-6 — Explanations and Reasons

**〜から (because — casual reason)**
```
疲れているから、早く寝ます。
Because I'm tired, I'll go to bed early.
```

**〜ので (because — polite/objective reason)**
More objective, less assertive than から. Preferred in formal contexts.
```
電車が遅れたので、遅刻しました。
Because the train was delayed, I was late.
```

**〜のに (even though — expectation violated)**
Expresses disappointment, surprise, or complaint that reality contradicts expectation.
```
たくさん勉強したのに、試験に落ちた。
Even though I studied a lot, I failed the exam.
```

---

## N4-7 — Expressing Purpose and Movement

**〜に行く / 〜に来る (go/come to do)**
```
本を借りに図書館に行きます。
I'm going to the library to borrow a book.
```

**〜ために (in order to — purpose)**
```
健康のために毎日運動しています。
I exercise every day for my health.
```

---

## N4-8 — Quoting and Indirect Speech

**〜と言う / 〜と思う**
Quoting speech or thoughts.
```
田中さんは「明日来る」と言っていた。
Tanaka said, "I'll come tomorrow."

彼は来ないと思います。
I think he won't come.
```

**〜そうです (hearsay — I heard that)**
Reporting what you heard from someone else.
```
明日は雪が降るそうです。
I heard that it will snow tomorrow.
```

---

## N4-9 — Appearance and Conjecture

**〜そうです (looks like — visual)**
Based on current appearance; something seems about to happen.
```
この料理は美味しそうです。
This food looks delicious.

雨が降りそうです。
It looks like it's going to rain.
```

**〜ようです (seems / appears — based on observation)**
```
彼は疲れているようです。
He appears to be tired.
```

---

## N4-10 — Change and Becoming

**〜になる (become — noun/な-adj)**
```
医者になりたい。
I want to become a doctor.
```

**〜くなる (become — い-adj)**
```
だんだん寒くなってきた。
It has gradually become colder.
```

**〜ようになる (come to be able to / reach the point where)**
```
日本語が話せるようになった。
I've come to be able to speak Japanese.
```

**〜なくなる (stop doing / cease to be)**
```
最近、肉を食べなくなった。
I've stopped eating meat lately.
```

---

## N4-11 — Frequency and Degree

**〜回 / 〜度 (times — frequency)**
```
週に3回ジムに行きます。
I go to the gym 3 times a week.
```

**もう / まだ (already / still / not yet)**
```
もう食べましたか？       Have you eaten already?
まだ食べていません。     I haven't eaten yet.
まだ食べています。       I'm still eating.
```

**ぜんぜん〜ない (not at all)**
```
ぜんぜんわかりません。
I don't understand at all.
```

**あまり〜ない (not very / not much)**
```
あまり好きじゃないです。
I don't like it very much.
```

---

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# N3 — Intermediate Expression
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## N3-1 — Expressing Reasons (Advanced)

**〜ために (because of / due to — cause, not purpose)**
When the preceding verb/noun is non-volitional, ために = because.
```
病気のために会社を休んだ。
I took the day off work because of illness.
```

**〜おかげで (thanks to — positive cause)**
```
先生のおかげで合格できた。
Thanks to my teacher, I was able to pass.
```

**〜せいで (because of — negative cause, blame)**
```
雨のせいで試合が中止になった。
Because of the rain, the game was cancelled.
```

**〜おかげか / 〜せいか (maybe because)**
Uncertainty about the cause.
```
薬を飲んだおかげか、熱が下がった。
Maybe thanks to taking the medicine, my fever went down.
```

---

## N3-2 — Concession and Contrast

**〜ても (even if / even though)**
```
雨が降っても、試合をします。
Even if it rains, we will have the match.
```

**〜のに (even though — see N4 for disappointment use)**
Also used as "in order to" (but that's rare at N3; mainly concession).

**〜くせに (even though — critical nuance)**
The speaker is critical of the subject. Not neutral.
```
知っているくせに、何も言わない。
Even though he knows, he says nothing. (annoying)
```

**〜にもかかわらず (despite / in spite of — formal)**
```
雨にもかかわらず、大勢の人が来た。
Despite the rain, a large crowd came.
```

**〜ながら(も) (while / although — contrast)**
```
忙しいながらも、毎日運動している。
Although busy, I exercise every day.
```

---

## N3-3 — Expectation and Conjecture

**〜はずだ (should be / expected to be)**
Strong logical expectation.
```
彼はもう着いているはずだ。
He should have arrived already.
```

**〜はずがない (there's no way / impossible)**
```
彼が嘘をつくはずがない。
There's no way he would lie.
```

**〜にちがいない (must be — strong conviction)**
```
あの音は地震に違いない。
That sound must be an earthquake.
```

**〜かもしれない (might / maybe)**
50/50 possibility.
```
明日は雨かもしれない。
It might rain tomorrow.
```

**〜でしょう / 〜だろう (probably)**
Softer than にちがいない.
```
明日は晴れるでしょう。
It will probably be sunny tomorrow.
```

---

## N3-4 — Defining and Explaining (〜こと / 〜の)

**〜ことがある (sometimes happens)**
```
授業中に寝ることがある。
I sometimes fall asleep during class.
```

**〜ことにする (decide to do)**
Personal decision.
```
毎日日記を書くことにした。
I decided to write in my diary every day.
```

**〜ことになる (it has been decided / it turns out that)**
External decision or natural result.
```
来月から新しい仕事をすることになった。
It has been decided that I'll start a new job next month.
```

**〜ことにしている (have made it a rule / practice)**
A habit you've committed to.
```
毎朝ジョギングすることにしている。
I make it a practice to jog every morning.
```

**〜ことになっている (is supposed to / there's a rule that)**
Existing rule or schedule set by others.
```
9時に集合することになっています。
We are supposed to gather at 9.
```

---

## N3-5 — State and Result

**〜てある (done and the result remains)**
Someone did it, and the state is still present. Object marked with が or を.
```
窓が開けてある。
The window has been opened (and is still open).
```

**〜ておく (do in advance / do for future use)**
```
パーティーの前に料理を作っておく。
I'll make food in advance before the party.
```

**〜てしまう (end up doing / do completely — often with regret)**
```
財布を忘れてしまった。
I ended up forgetting my wallet. (regret)

宿題を全部やってしまった。
I finished all my homework completely. (completion)
```

**〜てくる (action moves toward / comes into being)**
Change approaching the present or returning.
```
だんだん暗くなってきた。     (It's gradually gotten dark — approaching now)
買い物してきます。            (I'll go shopping and come back)
```

**〜ていく (action moves away / continues into future)**
```
これからも頑張っていきます。
I will continue to do my best from now on.
```

---

## N3-6 — Listing and Adding

**〜し〜し (and also / what's more — listing reasons/facts)**
Lists multiple reasons or facts, implying "and there are more."
```
この店は安いし、おいしいし、雰囲気もいい。
This restaurant is cheap, tasty, and the atmosphere is nice too.
```

**〜だけでなく〜も (not only... but also)**
```
英語だけでなく、フランス語も話せる。
She speaks not only English but also French.
```

**〜ばかりでなく〜も (not only... but also — stronger)**
```
彼は勉強ばかりでなく、スポーツも得意だ。
He is good not only at studying but also at sports.
```

---

## N3-7 — Scope and Limit

**〜だけ (only / just)**
```
一つだけください。
Please give me just one.
```

**〜しか〜ない (only — emphasizes smallness, with negative verb)**
```
100円しか持っていない。
I only have 100 yen. (implies "and that's not enough")
```

**〜さえ (even — emphasizes extremes)**
```
子供でさえわかる問題だ。
Even a child can understand this problem.
```

**〜ほど〜ない (not as… as / less than)**
```
思ったほど難しくなかった。
It wasn't as difficult as I thought.
```

**〜ほど (to the extent that / so much that)**
```
泣きたいほど嬉しい。
I'm so happy I want to cry.
```

---

## N3-8 — Expressing "Without Doing"

**〜ないで (without doing / instead of)**
```
朝ごはんを食べないで学校に行った。
I went to school without eating breakfast.
```

**〜ずに (without doing — more formal)**
```
傘を持たずに出かけた。
I went out without taking an umbrella.
```

---

## N3-9 — Showing Contrast Between Two Things

**〜一方(で) (while / on the other hand)**
```
日本の人口が減っている一方で、外国人は増えている。
While Japan's population is declining, foreigners are increasing.
```

**〜に対して (in contrast to / toward)**
```
兄は背が高いのに対して、弟は低い。
In contrast to the older brother who is tall, the younger is short.
```

---

## N3-10 — Quoting Thoughts and Definitions

**〜と思っていた (I was thinking / used to think)**
```
彼は来ないと思っていた。
I was thinking he wouldn't come.
```

**〜というのは〜ことだ (defining what X means)**
```
「ホームシック」というのは、故郷が恋しくなることだ。
"Homesickness" means the feeling of missing your hometown.
```

**〜によると / 〜によれば (according to)**
```
天気予報によると、明日は大雨だそうだ。
According to the weather forecast, tomorrow will have heavy rain.
```

---

## N3-11 — Telling Someone Not to Do / Prohibition

**〜ないでください (please don't)**
```
廊下で走らないでください。
Please don't run in the hallway.
```

**〜てはいけない / 〜てはだめ (must not)**
```
嘘をついてはいけません。
You must not lie.
```

---

## N3-12 — Verbs of Giving/Receiving (Keigo Intro)

**〜てもらえませんか / 〜ていただけませんか (polite request)**
```
ちょっと手伝ってもらえませんか？
Could you help me for a moment?

書類を確認していただけませんか？
Could you check the documents for me? (formal)
```

---

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# N2 — Upper-Intermediate / Pre-Advanced
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## N2-1 — Concession (Despite / Even Though)

**〜にもかかわらず (despite — formal, already in N3 but deeper at N2)**
```
大雪にもかかわらず、全員が出勤した。
Despite the heavy snow, everyone came to work.
```

**〜ものの (although / even though — soft concession)**
Result didn't meet expectation.
```
試験に合格したものの、就職は難しかった。
Although I passed the exam, finding work was difficult.
```

**〜とはいえ (that said / even though it may be)**
Acknowledges truth then adds limitation.
```
春とはいえ、まだ朝は寒い。
That said, it's spring, but mornings are still cold.
```

**〜くせに (even though — critical)**
Already in N3; N2 expects accurate usage in complex sentences.
```
できないくせに、口だけは一人前だ。
Even though he can't do it, he talks a big game.
```

**〜からといって (just because... doesn't mean)**
```
忙しいからといって、食事を抜いてはいけない。
Just because you're busy doesn't mean you should skip meals.
```

---

## N2-2 — Expectation and Logical Conclusion

**〜わけだ (which means / that makes sense / naturally)**
```
10年も住んでいたわけだから、詳しいのは当然だ。
Since he lived there for 10 years, it makes sense he knows it well.
```

**〜わけではない (it doesn't mean that / not necessarily)**
```
嫌いなわけではないが、得意でもない。
It's not that I dislike it, but I'm not good at it either.
```

**〜わけにはいかない (cannot / must not — social obligation)**
```
病気でも、今日だけは休むわけにはいかない。
Even if I'm sick, I simply cannot take today off.
```

**〜はずだった (was supposed to — but didn't happen)**
```
彼は来るはずだったが、来なかった。
He was supposed to come, but he didn't.
```

**〜かねない (might well — negative possibility)**
```
このまま続けると、失敗しかねない。
If we continue like this, there's a risk of failure.
```

**〜かねる (cannot bring oneself to / difficult to)**
```
その件についてはお答えしかねます。
I'm afraid I cannot answer that matter. (polite refusal)
```

---

## N2-3 — Conditions (Advanced)

**〜さえ〜ば (if only / as long as)**
Single sufficient condition.
```
君さえいれば、何もいらない。
As long as I have you, I need nothing else.
```

**〜ないことには〜ない (unless / without first doing)**
```
実際に使ってみないことには、いいかどうかわからない。
Unless you actually try using it, you won't know if it's good.
```

**〜にしたら / 〜にすれば / 〜にしてみれば (from X's perspective)**
```
子供にしてみれば、それは大問題だ。
From the child's perspective, that's a huge problem.
```

**〜としたら / 〜とすれば (supposing that / if it were the case)**
```
宝くじが当たったとしたら、何に使いますか？
If you were to win the lottery, what would you use it for?
```

---

## N2-4 — Degree and Extent

**〜に過ぎない (nothing more than / merely)**
```
これは私の個人的な意見に過ぎない。
This is nothing more than my personal opinion.
```

**〜ばかり (just / only / all the time — exaggeration)**
```
彼は遊んでばかりいる。
He does nothing but play all the time.
```

**〜ばかりか〜も (not only... but also — strong addition)**
```
彼は遅刻するばかりか、謝りもしない。
Not only was he late, he didn't even apologize.
```

**〜あまり (so much that / due to excess of)**
Too much emotion → unexpected result.
```
嬉しさのあまり、泣いてしまった。
I was so happy that I ended up crying.
```

**〜だけあって (as expected — justified by merit)**
```
さすが医者だけあって、判断が的確だ。
As expected of a doctor, the judgment is precise.
```

**〜だけに (all the more because)**
```
信頼していただけに、裏切られたのはショックだった。
All the more because I trusted him, being betrayed was a shock.
```

---

## N2-5 — Time Relationships

**〜て以来 (since — continuing state)**
```
大学を卒業して以来、ずっと東京で働いている。
Since graduating from university, I've been working in Tokyo.
```

**〜たとたんに (the moment / just as)**
Immediate consequence.
```
バスに乗ったとたんに、雨が降り始めた。
The moment I got on the bus, it started to rain.
```

**〜うちに (while / before the situation changes)**
```
若いうちに、色々な経験をしたほうがいい。
While you're young, it's better to have various experiences.
```

**〜次第 (しだい) — as soon as**
```
準備ができ次第、出発します。
We will depart as soon as preparations are complete.
```

**〜末に (すえに) — after a long process**
```
長い議論の末に、合意に達した。
After a long discussion, we reached an agreement.
```

**〜あげくに (after all that — often negative outcome)**
```
迷いに迷ったあげくに、結局やめた。
After a great deal of indecision, I ultimately quit.
```

---

## N2-6 — Purpose and Result

**〜ように (so that / request/hope for state)**
```
忘れないように、メモしておきます。
I'll take notes so I don't forget.
```

**〜ために (in order to — volitional purpose)**
```
夢を実現するために、毎日努力している。
I work hard every day in order to realize my dream.
```

**〜結果 (けっか) — as a result of**
```
長年の研究の結果、新しい薬が開発された。
As a result of years of research, a new medicine was developed.
```

---

## N2-7 — Formal Written Patterns

**〜において / 〜における (in / at — formal)**
```
現代社会において、情報リテラシーは重要だ。
In modern society, information literacy is important.
```

**〜に関して / 〜に関する (concerning / regarding — formal)**
```
この件に関しては、後日ご連絡します。
Regarding this matter, I will contact you at a later date.
```

**〜に基づいて (based on)**
```
科学的データに基づいて判断する。
Make judgments based on scientific data.
```

**〜にわたって / 〜にわたる (spanning / over a range)**
```
3日間にわたって会議が行われた。
The meeting was held over a span of 3 days.
```

**〜を通じて / 〜を通して (through / throughout)**
```
音楽を通じて、世界中の人と繋がれる。
Through music, you can connect with people all over the world.
```

**〜をめぐって (centering around / over — contested issue)**
```
その法案をめぐって、激しい議論が起きた。
A fierce debate arose over that bill.
```

**〜に際して (on the occasion of / at the time of)**
```
卒業に際して、一言ご挨拶申し上げます。
On the occasion of graduation, I would like to say a few words.
```

**〜をはじめ(として) (starting with / including)**
```
社長をはじめとして、全社員が参加した。
Starting with the president, all employees participated.
```

**〜に反して (contrary to)**
```
予想に反して、試験は簡単だった。
Contrary to expectations, the exam was easy.
```

**〜をもとに(して) (based on / using as a basis)**
```
このドラマは実際の事件をもとにしている。
This drama is based on actual incidents.
```

---

## N2-8 — Adding and Listing (Advanced)

**〜うえに (in addition to / on top of)**
Both items go in the same direction (both positive or both negative).
```
彼は頭がいいうえに、努力家でもある。
In addition to being smart, he is also hardworking.
```

**〜に加えて (in addition to)**
```
技術力に加えて、コミュニケーション力も大切だ。
In addition to technical skills, communication ability is also important.
```

**〜はもちろん / 〜はもとより (needless to say / of course)**
```
料理の味はもちろん、見た目も大切だ。
Needless to say the taste, appearance is also important.
```

---

## N2-9 — Expressing Obligation and Inevitability

**〜ざるを得ない (cannot help but / have no choice but to)**
Forced to do something against one's will.
```
規則だから、従わざるを得ない。
Because it's the rule, I have no choice but to follow it.
```

**〜てでも (even if I have to / by any means)**
Strong determination, willing to do something difficult.
```
借金してでも、この機会を生かしたい。
Even if I have to borrow money, I want to make use of this opportunity.
```

**〜ずにはいられない (cannot help but)**
Uncontrollable urge.
```
この映画を見ると、泣かずにはいられない。
When I watch this film, I can't help but cry.
```

---

## N2-10 — Expressing Cause (Strong/Formal)

**〜からこそ (precisely because — strong emphasis)**
```
あなたを信頼しているからこそ、厳しく言うんだ。
It's precisely because I trust you that I say it harshly.
```

**〜ゆえに (therefore / because of — very formal/literary)**
```
無知ゆえに、間違いを犯してしまった。
Because of ignorance, I made a mistake.
```

---

## N2-11 — Resemblance and Typicality

**〜らしい (typical of / that's very X)**
```
今日は日本らしい天気だ。
Today has very Japanese-like weather.

さすが先生らしい答えだ。
That's a very teacher-like answer.
```

**〜っぽい (has a tendency to / sort of like)**
Informal. Often slightly critical.
```
彼は子供っぽいところがある。
He has a somewhat childish side.

この服は安っぽく見える。
These clothes look cheap.
```

---

## N2-12 — Passive and Causative (Advanced Use)

**〜させられる (causative-passive — forced to)**
I was made/forced to do something.
```
上司に残業させられた。
I was forced to work overtime by my boss.
```

**〜させてもらう / 〜させていただく (humbly do with permission)**
```
一言発言させていただきます。
Please allow me to say a word. (humble)
```

---

## Master Comparison Table — Most Confused Pairs

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ PAIR                  │ DIFFERENCE                                          │
├───────────────────────┼─────────────────────────────────────────────────────┤
│ ため (purpose)         │ I chose this goal (volitional)                     │
│ ように (purpose)       │ I want a state to result (non-volitional/request)  │
├───────────────────────┼─────────────────────────────────────────────────────┤
│ から (reason)          │ Casual, personal, assertive                        │
│ ので (reason)          │ Objective, polite, less forceful                   │
├───────────────────────┼─────────────────────────────────────────────────────┤
│ しか〜ない (only)       │ Only with negative verb — implies insufficiency   │
│ だけ (only)            │ Neutral — just states the limit                    │
├───────────────────────┼─────────────────────────────────────────────────────┤
│ はずだ (expectation)   │ Logic-based expectation: should be true            │
│ わけだ (conclusion)    │ Explains why something makes sense: no wonder      │
├───────────────────────┼─────────────────────────────────────────────────────┤
│ らしい (hearsay)       │ Indirect evidence / hearsay / typical of           │
│ ようだ (observation)   │ Based on direct observation / seems                │
│ そうだ (appearance)    │ Visual appearance (looks like it's about to...)    │
│ そうだ (hearsay)       │ I heard that (from someone)                        │
├───────────────────────┼─────────────────────────────────────────────────────┤
│ たら (conditional)     │ Most versatile: after, when, if                    │
│ ば (conditional)       │ Hypothetical ideal / general truth                 │
│ と (conditional)       │ Natural/automatic result, directions               │
│ なら (conditional)     │ Given that / based on what I just heard            │
├───────────────────────┼─────────────────────────────────────────────────────┤
│ のに (concession)      │ Disappointment / complaint: even though            │
│ ても (concession)      │ Neutral: even if / even when                       │
├───────────────────────┼─────────────────────────────────────────────────────┤
│ ものの (concession)    │ Soft: although (result didn't meet expectation)    │
│ にもかかわらず(despite) │ Formal: despite X, Y still happened               │
├───────────────────────┼─────────────────────────────────────────────────────┤
│ ながら (simultaneous)  │ While doing (two actions at the same time)         │
│ ながら(も) (contrast)  │ Although / even though (contrast)                  │
├───────────────────────┼─────────────────────────────────────────────────────┤
│ わけにはいかない        │ Social obligation prevents action: cannot afford to│
│ わけではない           │ Denial of assumption: it doesn't mean that         │
├───────────────────────┼─────────────────────────────────────────────────────┤
│ てある (result state)  │ Someone did it intentionally; result remains       │
│ ている (ongoing/state) │ Currently happening OR resulting state (neutral)   │
│ ておく (preparation)   │ Do in advance for future use                       │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Formality Scale

```
Most casual ←──────────────────────────────────────→ Most formal

REASON:
  〜から  →  〜ので  →  〜ため(に)  →  〜ゆえに

CONCESSION:
  〜ても  →  〜のに  →  〜ながらも  →  〜にもかかわらず  →  〜とはいえ

SCOPE:
  〜だけ  →  〜のみ  (のみ is the formal written version of だけ)

LOCATION/CONTEXT:
  〜で  →  〜において  (において is formal written)

CONJUNCTION "and" (nouns):
  〜と  →  〜や  →  〜および  (および is formal written)

PURPOSE:
  〜ために  →  〜に際して  →  〜にあたって  (more formal, for occasions)
```
