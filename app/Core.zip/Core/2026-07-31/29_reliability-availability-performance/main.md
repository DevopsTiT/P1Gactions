# SRE Deep Dive: System Reliability, Availability & Performance — Proactive Monitoring & Incident Response

---

## Decision Tree: What Are You Doing Right Now?

```
START
  │
  ├─ System is DOWN right now ──────────────────→ Jump to Part 5 (Incident Response)
  │
  ├─ System is slow right now ─────────────────→ Part 5 Step 2 (triage) → Part 3 (performance)
  │
  ├─ Setting up monitoring for a new service ──→ Part 1 → Part 2 → Part 3 → Part 4
  │
  ├─ Reviewing existing reliability posture ───→ Part 2 (SLOs) → Part 6 (toil/post-incident)
  │
  └─ Preparing for high-traffic event ─────────→ Part 4 (capacity) → Part 5 (runbooks ready)
```

---

## E2E Flow: How Reliability, Monitoring & Incident Response Connect

```
[Production System]
      │
      ▼
[Telemetry Layer]
  Metrics (Prometheus)  Logs (Loki/ELK)  Traces (Tempo/Jaeger)
      │
      ▼
[Proactive Monitoring]
  SLO burn rate checks    Synthetic tests    Capacity trends
  Anomaly detection       Dependency health  Change detection
      │
      ├── Everything OK ──→ [Continue operating; tune thresholds; review SLOs]
      │
      └── Signal detected ─→ [Alert fires]
                                   │
                                   ▼
                          [Incident Response]
                          Detect → Triage → Mitigate → Resolve → Post-mortem
                                   │
                                   ▼
                          [Reliability Improvements]
                          Fix root cause → Reduce toil → Update runbooks → Update alerts
                                   │
                                   ▼
                          [Back to Production — more reliable than before]
```

The cycle never ends. Each incident makes the system more reliable if you close the loop.

---

## Part 1 — Reliability Foundations: What Does "Reliable" Mean?

### 1.1 The Three Pillars

```
AVAILABILITY  — Is the system reachable and responding?
                Measured as: successful requests / total requests
                Example: 99.9% availability = up to 43.8 min downtime/month

RELIABILITY   — Does the system do what it promises, consistently?
                Measured as: correct responses / total responses
                A system can be available but unreliable (returns wrong data)

PERFORMANCE   — Does the system respond fast enough to be useful?
                Measured as: latency percentiles (p50, p95, p99)
                A system can be available and reliable but too slow to use
```

All three must be true simultaneously. Monitoring each separately misses failure modes.

### 1.2 The Reliability Hierarchy

```
Level 1 — Basic Availability
  "Is the service up?" — HTTP 200, process running, port open

Level 2 — Functional Correctness
  "Does it return correct results?" — Synthetic transactions, data validation

Level 3 — Performance SLOs
  "Is it fast enough?" — Latency percentiles within agreed targets

Level 4 — Dependency Reliability
  "Are its dependencies healthy?" — Database, message queue, downstream APIs

Level 5 — Resilience Under Failure
  "Does it degrade gracefully?" — Circuit breakers, retries, fallbacks
```

You cannot achieve Level 5 if Level 1 is broken. Build bottom-up.

### 1.3 SRE's Core Contract with the Business

```
Business wants: Maximum features, fast delivery
SRE wants:      Stability, reliability, manageable risk

The contract:
  - Define an SLO (e.g. 99.9% availability)
  - Error budget = 100% - SLO = 0.1%
  - If budget is healthy → development can move fast (deploy often, take risks)
  - If budget is burning fast → slow down, focus on reliability
  - SRE enforces the budget; development team respects it
```

This is the mechanism that turns "reliability" from a vague value into a measurable, actionable number.

---

## Part 2 — SLOs, SLIs, SLAs: The Measurement Framework

### 2.1 Definitions

| Term | Full Name | What It Is | Example |
|---|---|---|---|
| SLI | Service Level Indicator | The actual metric you measure | Error rate = 0.05% |
| SLO | Service Level Objective | Your internal reliability target | Error rate < 0.1% |
| SLA | Service Level Agreement | Legal contract with customers | "We guarantee 99.9% or you get a refund" |
| Error Budget | — | How much failure is allowed per SLO period | 0.1% of requests can fail per month |

SLI is reality. SLO is the target. SLA is the business commitment. Never confuse them.

### 2.2 Choosing Good SLIs

Not every metric is a good SLI. A good SLI:
- Directly reflects user experience (not internal implementation detail)
- Measurable at high precision
- Correlated with user happiness

```
Service Type       Good SLI                              Bad SLI
──────────────────────────────────────────────────────────────────
Web API            Request success rate, p99 latency     CPU usage
Database           Query success rate, query latency     Disk IOPS (internal)
Batch job          % jobs completing within SLO window   Job start time
Data pipeline      % records processed correctly         Kafka consumer lag alone
CDN / Static       Cache hit rate, TTFB p95              Server-side CPU
```

### 2.3 SLO Math Every SRE Must Know

```
SLO: 99.9% availability over 30 days

Error budget:
  0.1% of requests can fail
  OR: 43.8 minutes of downtime per month
  OR: 0.1% × 30days × 24h × 60min = 43.2 minutes

Burn rate formula:
  burn_rate = actual_error_rate / error_budget_rate
  burn_rate = 0.5% / 0.1% = 5x  (burning 5x faster than allowed)

Time to exhaust budget at burn rate 5x:
  43.2 min × (1 / 5) = 8.64 minutes until budget gone

Multi-window burn-rate alert thresholds:
  Critical (1h + 5m windows): burn_rate > 14.4
  Warning  (6h + 30m windows): burn_rate > 6
  Ticket   (3d + 6h windows):  burn_rate > 1
```

### 2.4 SLO Prometheus Rules (Full Example)

```yaml
# prometheus/rules/slo-rules.yaml
groups:
  - name: slo.my-service
    rules:

      # SLI: 5m error rate
      - record: sli:error_rate:5m
        expr: |
          sum(rate(http_requests_total{service="my-service",status=~"5.."}[5m]))
          /
          sum(rate(http_requests_total{service="my-service"}[5m]))

      # SLI: 1h error rate
      - record: sli:error_rate:1h
        expr: |
          sum(rate(http_requests_total{service="my-service",status=~"5.."}[1h]))
          /
          sum(rate(http_requests_total{service="my-service"}[1h]))

      # Alert: Fast burn (Critical — page now)
      - alert: SLOFastBurn
        expr: |
          sli:error_rate:1h > (14.4 * 0.001)
          and
          sli:error_rate:5m > (14.4 * 0.001)
        for: 2m
        labels:
          severity: critical
          service: my-service
        annotations:
          summary: "SLO fast burn: my-service error budget depleting rapidly"
          description: "Burn rate {{ $value | humanizePercentage }} — budget will exhaust in < 1h"
          runbook_url: "https://wiki/runbooks/slo-fast-burn"

      # Alert: Slow burn (Warning — investigate in business hours)
      - alert: SLOSlowBurn
        expr: |
          sli:error_rate:6h > (6 * 0.001)
          and
          sli:error_rate:30m > (6 * 0.001)
        for: 15m
        labels:
          severity: warning
          service: my-service
        annotations:
          summary: "SLO slow burn: my-service steadily consuming error budget"
```

---

## Part 3 — Proactive Performance Monitoring

### 3.1 The Proactive vs Reactive Distinction

```
REACTIVE (bad default):
  User reports slowness → SRE investigates → finds DB index missing → fixes it
  Impact: Users suffered for hours before SRE knew

PROACTIVE (good SRE practice):
  Trend alert fires: p99 query time rising over 7 days → SRE investigates → finds index before users notice
  Impact: Users never feel it
```

Proactive monitoring requires looking at TRENDS, not just current state.

### 3.2 Performance Monitoring Stack

```
Layer                   Tool                    What It Catches
─────────────────────────────────────────────────────────────────
Real User Monitoring    Dynatrace RUM / DataDog  Actual browser/app experience
Synthetic Testing       Dynatrace / Grafana      Baseline health from outside
Application (APM)       Dynatrace / Jaeger       Code-level performance
Infrastructure          Prometheus + node_exp    CPU, memory, disk, network
Database                pg_exporter / slow log   Query performance
Network                 Dynatrace / Cilium        Packet loss, RTT, DNS
```

### 3.3 Key Performance Metrics by Layer

**Application Layer:**
```promql
# p99 latency (always histogram_quantile, never average)
histogram_quantile(0.99,
  sum(rate(http_request_duration_seconds_bucket{service="my-svc"}[5m])) by (le)
)

# Request rate (RPS)
sum(rate(http_requests_total{service="my-svc"}[5m]))

# Error rate
sum(rate(http_requests_total{service="my-svc",status=~"5.."}[5m]))
/ sum(rate(http_requests_total{service="my-svc"}[5m]))
```

**Infrastructure Layer:**
```promql
# CPU throttling (indicates CPU limits too tight)
rate(container_cpu_throttled_seconds_total[5m])
/ rate(container_cpu_usage_seconds_total[5m])

# Memory pressure (OOMKill risk)
container_memory_working_set_bytes / container_spec_memory_limit_bytes

# Disk IOPS saturation
rate(node_disk_io_time_seconds_total[5m])

# Network retransmits (packet loss indicator)
rate(node_network_transmit_errs_total[5m])
```

**Database Layer:**
```promql
# PostgreSQL active connections
pg_stat_activity_count{state="active"}

# Slow queries (requires pg_stat_statements exporter)
rate(pg_stat_statements_total_time_seconds[5m]) / rate(pg_stat_statements_calls_total[5m])

# Connection pool saturation
pgbouncer_pools_sv_active / pgbouncer_pools_sv_maxwait
```

### 3.4 Synthetic Monitoring — Testing From the Outside

Synthetic tests simulate user behavior on a schedule, 24/7, from multiple regions.

Why they matter:
- Catch failures before real users do
- Test the entire stack end-to-end (DNS, load balancer, app, DB, CDN)
- Establish performance baselines for SLO thresholds
- Monitor from external locations (catches CDN/DNS issues internal monitoring misses)

```yaml
# Dynatrace Synthetic HTTP Monitor (example config)
apiVersion: v1
kind: ConfigMap
metadata:
  name: synthetic-monitor-config
data:
  monitor.json: |
    {
      "name": "my-service-health-check",
      "type": "HTTP",
      "frequencyMin": 5,
      "locations": ["aws:us-east-1", "aws:eu-west-1", "aws:ap-southeast-1"],
      "script": {
        "requests": [
          {
            "url": "https://my-service.internal/health",
            "method": "GET",
            "validation": {
              "statusCode": 200,
              "bodyContains": "\"status\":\"ok\"",
              "maxResponseTime": 2000
            }
          },
          {
            "url": "https://my-service.internal/api/v1/items",
            "method": "GET",
            "validation": {
              "statusCode": 200,
              "maxResponseTime": 500
            }
          }
        ]
      }
    }
```

### 3.5 Capacity Planning and Trend Alerting

Proactive = alerting on WHERE YOU ARE GOING, not just where you are now.

```promql
# Predict disk full time using linear regression (Prometheus predict_linear)
# Alert: disk will be full in < 4 hours
predict_linear(node_filesystem_avail_bytes[6h], 4 * 3600) < 0

# Trend: memory usage growing faster than expected (week-over-week)
container_memory_working_set_bytes
/ container_memory_working_set_bytes offset 7d
# If ratio > 1.3, memory grew 30% this week — investigate before OOMKill

# CPU request utilization trending toward limit
sum(rate(container_cpu_usage_seconds_total[5m])) by (pod)
/ sum(container_spec_cpu_quota / container_spec_cpu_period) by (pod)
# If > 0.8, pod is at 80% of its CPU limit — risk of throttling
```

---

## Part 4 — Proactive Reliability Practices

### 4.1 Change Management (Most Incidents Are Self-Inflicted)

80% of incidents are caused by changes: deployments, config changes, scaling events, dependency upgrades.

```
Change Risk Checklist (before every deploy):
  □ Is there a rollback plan? (kubectl rollout undo, feature flag off)
  □ Is there a canary or staged rollout? (not 100% at once)
  □ Are SLO dashboards open and visible during deploy?
  □ Is the on-call engineer aware this deploy is happening?
  □ Has this been tested in staging under production-like load?
  □ Is there a post-deploy monitoring window? (watch for 30 min after)
```

### 4.2 Canary Deployments (Limit Blast Radius)

```
Step 1: Deploy new version to 5% of pods
Step 2: Compare error rate and latency between v1 (95%) and v2 (5%)
Step 3: If v2 metrics match v1 → proceed to 25% → 50% → 100%
Step 4: If v2 is worse → roll back immediately (only 5% of users affected)

In Kubernetes with Argo Rollouts:
  canarySteps:
    - setWeight: 5
    - pause: {duration: 10m}   # watch metrics
    - setWeight: 25
    - pause: {duration: 10m}
    - setWeight: 50
    - pause: {duration: 10m}
    - setWeight: 100
```

### 4.3 Circuit Breakers (Prevent Cascade Failures)

```
Without circuit breaker:
  Service A → Service B (slow) → Service A hangs waiting → A's threads exhaust → A fails
  → Service C → Service A fails → C fails → Cascade

With circuit breaker:
  Service A → Service B (slow) → Circuit breaker trips after 5 failures
  → Service A gets immediate error response → Fails fast → Returns fallback
  → Users get degraded experience (not outage)
  → Circuit resets after 30s, tries again

States: CLOSED (normal) → OPEN (failing fast) → HALF-OPEN (testing recovery)
```

### 4.4 Health Checks and Readiness Probes

```yaml
# Kubernetes deployment with proper health checks
# kubernetes/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: my-service
spec:
  template:
    spec:
      containers:
        - name: my-service
          # Liveness: is this container alive? If not → kill and restart
          livenessProbe:
            httpGet:
              path: /health/live
              port: 8080
            initialDelaySeconds: 30
            periodSeconds: 10
            failureThreshold: 3    # fail 3 times → restart container

          # Readiness: is this container ready to serve traffic?
          # If not → remove from load balancer (don't kill, just stop sending traffic)
          readinessProbe:
            httpGet:
              path: /health/ready
              port: 8080
            initialDelaySeconds: 10
            periodSeconds: 5
            failureThreshold: 2    # fail 2 times → remove from service

          # Startup: give slow-starting apps time to initialize
          startupProbe:
            httpGet:
              path: /health/live
              port: 8080
            failureThreshold: 30   # 30 × 10s = 5 minutes to start
            periodSeconds: 10
```

Health check endpoint logic:
- `/health/live` → only check if process is not deadlocked (never check DB here)
- `/health/ready` → check DB connection, cache connection, required config loaded
- If `/health/ready` checks DB and DB is down → pod goes unready → traffic stops → DB gets no more traffic → DB can recover

### 4.5 Dependency Mapping and Upstream/Downstream Health

```
My Service depends on:
  → PostgreSQL (critical — service fails without it)
  → Redis cache (degradable — service works slower without it)
  → Payment API (partial — only payment flows fail)
  → Email service (non-critical — emails queue, don't fail requests)

SRE action:
  For each dependency, decide:
    1. Is it critical? → Alert if it goes down
    2. Can we degrade gracefully? → Implement fallback + different alert
    3. Who owns it? → Know who to call

Dashboard must show dependency health alongside service health.
Every alert for my service should include: "Is it MY code or a DEPENDENCY?"
```

---

## Part 5 — Incident Response: The Full Lifecycle

### 5.1 Incident Severity Levels

```
SEV 1 — Critical / All-Hands
  - Production down, all users affected, revenue impacted
  - Response time: 5 minutes
  - Example: Payment service 100% errors

SEV 2 — Major
  - Significant degradation, significant % of users affected
  - Response time: 15 minutes
  - Example: p99 latency > 10x baseline, 20% error rate

SEV 3 — Minor
  - Partial degradation, limited user impact
  - Response time: 1 hour (business hours)
  - Example: One region slower than others, non-critical feature failing

SEV 4 — Low
  - Cosmetic or low-impact, no user-facing degradation
  - Response time: Next business day
  - Example: Logging pipeline delayed, non-critical batch job failed
```

### 5.2 The Incident Response Workflow (Step by Step)

```
PHASE 1: DETECT (0–5 min)
  ├─ Alert fires in PagerDuty / Slack
  ├─ On-call acknowledges within SLA (e.g. 5 min for SEV1)
  └─ Incident channel created: #incident-YYYY-MM-DD-service-name

PHASE 2: ASSEMBLE (5–10 min)
  ├─ Incident Commander (IC) takes lead
  ├─ Communications Lead joins (updates stakeholders)
  ├─ Subject Matter Experts (SMEs) joined as needed
  └─ Roles clearly assigned — only IC makes decisions

PHASE 3: TRIAGE (10–20 min)
  ├─ What is broken? (symptoms — error rate, latency, which endpoints)
  ├─ Who is affected? (all users? one region? one customer?)
  ├─ When did it start? (correlate with deploys, config changes, external events)
  ├─ Is it getting worse, stable, or recovering?
  └─ Set severity level based on answers above

PHASE 4: MITIGATE (20–60 min)
  ├─ Goal: STOP USER PAIN, not find root cause
  ├─ Options (in order of preference):
  │    1. Rollback last deployment
  │    2. Enable feature flag to disable broken feature
  │    3. Redirect traffic away from broken region
  │    4. Scale up to absorb load
  │    5. Failover to backup DB / standby
  ├─ Communicate: "We have identified the issue and are mitigating"
  └─ Track: every action taken + timestamp in incident timeline

PHASE 5: RESOLVE
  ├─ User impact ended (SLO metrics back to normal for 30+ min)
  ├─ Monitoring confirms recovery
  ├─ Communicate: "Issue resolved at HH:MM UTC. Monitoring continues."
  └─ Close incident in PagerDuty

PHASE 6: POST-INCIDENT
  ├─ Post-mortem written within 48–72 hours
  ├─ Root cause identified
  ├─ Action items assigned with owners + deadlines
  └─ Runbook updated so next time is faster
```

### 5.3 The Incident Commander Role

The IC is not the person fixing the problem. The IC:
- Controls the pace and direction of the response
- Assigns tasks and ensures they don't duplicate
- Makes the call on mitigation strategy
- Calls for help or escalates when needed
- Keeps the communication clear and calm

Without an IC, everyone investigates everything simultaneously, no one communicates, and mitigation takes 3x longer.

### 5.4 Communication Templates

**Initial status update (within 10 min):**
```
[SEV2 INCIDENT] my-service elevated error rate
Status: INVESTIGATING
Impact: ~15% of API requests failing since 14:32 UTC
Last change: Deployment v2.3.1 at 14:25 UTC
IC: @alice | Comms: @bob
Updates every 15 min in #incident-2026-07-31-my-service
```

**Mitigation update:**
```
[SEV2 UPDATE] my-service
Status: MITIGATING
Action taken: Rolling back to v2.3.0 (started 14:48 UTC)
Error rate dropping: 15% → 8% → 3%
ETA to full recovery: ~5 min
```

**Resolution:**
```
[SEV2 RESOLVED] my-service
Resolved at: 14:53 UTC (21 min total)
Impact: ~15% error rate for 21 minutes
Cause: Bug in v2.3.1 payment validation logic
Mitigation: Rollback to v2.3.0
Post-mortem: [link] (due 2026-08-02)
```

### 5.5 Triage Decision Tree (During an Incident)

```
Alert fires: "High error rate on my-service"
  │
  ├─ Check: Was there a recent deploy?
  │    YES → Rollback first, investigate second
  │    NO  → Continue triage
  │
  ├─ Check: Is a dependency down?
  │    YES → Escalate to dependency owner; add circuit breaker if missing
  │    NO  → Continue triage
  │
  ├─ Check: Is it all pods or specific pods?
  │    Specific pods → Cordon bad pods; check node health
  │    All pods → Application or config issue
  │
  ├─ Check: Is it all endpoints or one endpoint?
  │    One endpoint → Specific code path; check recent changes to that handler
  │    All endpoints → Shared dependency (DB, auth, config)
  │
  ├─ Check: Is error rate spiking or gradually rising?
  │    Spike → Likely change/deploy related
  │    Gradual → Resource exhaustion (memory leak, disk filling, connection pool)
  │
  └─ Check error messages in logs
       5xx → Application error (check stack traces)
       504 Gateway Timeout → Downstream slow or down
       503 Service Unavailable → Pod unready or overloaded
       OOMKilled → Memory limit too low or memory leak
```

---

## Part 6 — Post-Incident: Closing the Reliability Loop

### 6.1 Blameless Post-Mortem Structure

```markdown
# Post-Mortem: [Service] [Brief Description] — [Date]

## Impact
- Duration: 21 minutes (14:32–14:53 UTC)
- Users affected: ~15% of API users
- Requests failed: ~47,000 requests
- Revenue impact: $2,300 (estimated)

## Timeline
14:25 — Deployment v2.3.1 rolled out (100% of pods in 8 min)
14:32 — Alertmanager fired HighErrorRateFastBurn
14:34 — On-call acknowledged (2 min response time ✓)
14:40 — Root cause identified: new payment validation rejects valid cards
14:48 — Rollback to v2.3.0 initiated
14:53 — Error rate returned to baseline

## Root Cause
A regex change in PaymentValidator.validate() rejected card numbers with spaces,
which is valid in some card networks. Staging tests used only sanitized inputs;
production receives raw user input.

## Contributing Factors
- Staging test data does not reflect production input diversity
- No integration test covering raw card number formats
- Canary was skipped ("low-risk" text change judgment)

## What Went Well
- Alert fired within 2 min of issue start
- Rollback completed in 5 min
- IC role clearly assigned; no confusion

## Action Items
| Action | Owner | Due Date |
|---|---|---|
| Add raw card number test cases to staging data | @dev-team | 2026-08-07 |
| Enforce canary for ALL payment service changes | @platform | 2026-08-05 |
| Add integration test: PaymentValidator with raw user input | @alice | 2026-08-10 |
| Update runbook: add payment service rollback steps | @bob | 2026-08-03 |

## Lessons Learned
Never skip canary for "low-risk" changes to payment code paths.
Staging data quality is a reliability risk, not just a testing concern.
```

### 6.2 Toil Reduction (Turning Incidents into Less Work)

Toil = manual, repetitive operational work that could be automated.

```
Example toil patterns SREs should eliminate:

Toil: Manually restarting pods when they OOMKill
Fix:  Tune memory limits based on actual usage data; add VPA (Vertical Pod Autoscaler)

Toil: Manually acknowledging "DiskSpaceWarning" and running disk cleanup script
Fix:  Automate log rotation; extend PVC; alert only when < 24h before full

Toil: Manually checking if a deploy is healthy by watching Grafana for 30 min
Fix:  Implement automated progressive delivery with Argo Rollouts + metric analysis

Toil: Manually checking which service caused a cascade after every incident
Fix:  Build dependency graph dashboard; use Dynatrace Davis/tracing for auto root cause

Rule: If you do the same manual response 3 times, automate it or eliminate it.
Google SRE target: < 50% of SRE time on toil; > 50% on engineering work
```

### 6.3 Error Budget Policy

```
Error Budget Status → Action
────────────────────────────────────────────────────────────────
> 50% remaining     → Full velocity: deploys, experiments, risky changes OK

25–50% remaining    → Caution: no risky changes; canary all deploys;
                       review top error sources

10–25% remaining    → Slowdown: freeze non-critical deploys;
                       all hands on reliability improvements

< 10% remaining     → Reliability freeze: ONLY bug fixes and rollbacks;
                       no feature work until budget recovers

0% (exhausted)      → SLA breach risk; executive escalation;
                       SRE team can block all releases until SLO met again
```

---

## Common Mistakes

| Mistake | What Happens | Fix |
|---|---|---|
| Monitoring only infrastructure (CPU, disk) | Users affected before SRE knows | Monitor user-facing SLIs first |
| No incident commander role | 5 people investigate same thing; no one communicates | Assign IC within first 2 min |
| Mitigation delayed by root cause hunt | Users suffer while SRE debugs | Mitigate first (rollback), debug second |
| Post-mortem action items with no owner | Actions never completed; same incident repeats | Every action: owner + due date |
| Synthetic tests in same region as service | CDN/DNS failures not caught | Test from 3+ external regions |
| SLO target set at 100% | Zero error budget; everything blocks deploys | Set realistic SLOs based on baseline data |
| `predict_linear` not used for capacity | Disk fills up; DB runs out of connections | Add trend-based alerts for all finite resources |
| Health checks too strict (check DB in liveness) | DB blip kills all pods (restart storm) | Liveness = only deadlock; Readiness = dependencies |
| No runbooks | 30 min of on-call research per incident | Every alert links to runbook before going to prod |
