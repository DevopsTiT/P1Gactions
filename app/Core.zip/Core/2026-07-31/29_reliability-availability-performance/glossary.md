# Glossary: Reliability, Availability & Performance

Every term from the main guide explained for an SRE beginner.

---

**Alertmanager**
The component that receives fired alerts from Prometheus, groups duplicates, applies silences, and routes them to the right destination (Slack, PagerDuty). Prometheus creates alerts; Alertmanager decides what to do with them.

**amtool**
Command-line interface for Alertmanager. Lets you list active alerts, create silences, and send test alerts without opening a browser.

**APM (Application Performance Monitoring)**
Monitoring focused on the code level — which functions are slow, which database queries take the most time, which external calls fail. Tools: Dynatrace, New Relic, Jaeger.

**Argo Rollouts**
A Kubernetes controller that extends standard deployments with canary, blue/green, and progressive delivery strategies. Integrates with Prometheus to auto-rollback if metrics degrade.

**Availability**
The fraction of time a system successfully responds to requests. Measured as: `successful requests / total requests`. Expressed as a percentage: 99.9%, 99.99%, etc.

**Blameless Post-Mortem**
An incident review document that focuses on WHAT failed and WHY, not WHO made a mistake. Goal: fix systems, not punish people. Blameless culture is required for honest post-mortems.

**Burn Rate**
How fast you're consuming your error budget relative to the allowed rate. Burn rate 1x = you'll use exactly 100% over the SLO period. Burn rate 14.4x = you'll exhaust a monthly budget in 50 hours.

**Canary Deployment**
Releasing a new version to a small percentage of traffic first (e.g. 5%) before rolling out to everyone. If the canary has worse metrics than the old version, it's rolled back automatically.

**Capacity Planning**
Predicting future resource needs before you run out. Uses trend data (e.g. disk growing 10GB/week) to schedule upgrades before they become incidents.

**Circuit Breaker**
A reliability pattern that automatically stops sending requests to a failing downstream service after N failures. Returns an immediate error instead of waiting for a timeout. Prevents cascade failures.

**Circuit Breaker States**
CLOSED = normal operation. OPEN = failing fast (not sending requests). HALF-OPEN = testing if the downstream recovered (sending a few requests to check).

**Communications Lead**
The person in an incident responsible for keeping stakeholders (management, customers) informed. Separate from the technical responders so they can focus on fixing, not explaining.

**Cordon (Kubernetes)**
Mark a node as unschedulable — no new pods will be placed on it, but existing pods keep running. Used when a node is misbehaving and you want to investigate without disrupting running workloads.

**Davis AI**
Dynatrace's AI engine that automatically detects anomalies, identifies root causes, and groups related symptoms into a single "problem" event — without you writing thresholds.

**Drain (Kubernetes)**
Safely evict all pods from a node (move them elsewhere) before taking the node down for maintenance. Use with `--ignore-daemonsets` to avoid trying to move system-level pods.

**Error Budget**
The allowed amount of failure per SLO period. For a 99.9% SLO over 30 days, the error budget = 0.1% = 43.8 minutes of allowed downtime. Alerts fire when this is consumed too fast.

**Error Budget Policy**
A written agreement about what engineering teams do when error budget is at different levels. Low budget → slow down features; exhausted budget → reliability freeze. Turns SLOs into a governance mechanism.

**Escalation Policy**
A PagerDuty configuration that defines who gets paged if the primary on-call doesn't acknowledge within N minutes, and who gets paged after them. Ensures no alert is silently ignored.

**`failureThreshold` (Kubernetes probe)**
How many consecutive failures before Kubernetes acts. For liveness: restart the container. For readiness: remove it from the load balancer. Prevents single-blip restarts.

**Four Golden Signals**
Google SRE's framework for what matters most to monitor: Latency, Traffic, Errors, Saturation. Every good alert maps to at least one of these.

**Graceful Degradation**
When a system loses a non-critical dependency, it continues operating with reduced functionality instead of failing completely. Example: if Redis cache is down, serve requests from DB (slower, not broken).

**Health Check**
An HTTP endpoint your service exposes to report its own status. Kubernetes calls it automatically to decide whether to keep sending traffic (`/health/ready`) or restart the container (`/health/live`).

**HPA (Horizontal Pod Autoscaler)**
Kubernetes component that automatically adds or removes pods based on CPU usage, memory, or custom metrics. Handles traffic spikes without manual intervention.

**Incident Commander (IC)**
The single person in charge during an incident. Does NOT fix the problem directly — assigns tasks, makes decisions, controls the pace of response. Having a clear IC is the #1 factor in fast incident resolution.

**`initialDelaySeconds` (Kubernetes probe)**
How long Kubernetes waits after a container starts before checking its health. Needed for slow-starting applications (Java services, ML models). Set too low → container killed before it finishes starting.

**`iostat`**
Linux command that shows disk I/O statistics: reads/writes per second, utilization, wait time. `iostat -x 2 5` runs it every 2 seconds for 5 iterations.

**JMX Exporter**
A Java agent that exposes JVM metrics (heap, GC, threads) in Prometheus format. Required for monitoring Java applications at the code level.

**kubectl**
The command-line tool for interacting with Kubernetes. Use it to view pods, check logs, scale deployments, rollback, and investigate incidents.

**Liveness Probe**
A Kubernetes health check that answers: "Is this container alive (not deadlocked/frozen)?" If it fails, Kubernetes kills and restarts the container. Only check for deadlocks — never check DB connections here.

**Memory Leak**
A bug where a running process keeps allocating memory and never freeing it. Over time the pod's memory usage grows until it hits the limit and is killed (OOMKill). Detected by trending memory over 7+ days.

**MTTR (Mean Time to Resolve)**
The average time from when an incident starts until it is fully resolved. A key SRE metric. Lower MTTR = better incident response processes and runbooks.

**MTTA (Mean Time to Acknowledge)**
The average time from alert firing to an on-call engineer acknowledging it. Measures the effectiveness of on-call rotations and notification settings.

**Multi-window Multi-burn-rate Alerting**
The Google-recommended SLO alerting strategy using two time windows simultaneously (e.g. 1h + 5m). Catches both fast spikes and slow drains while minimizing false positives.

**`nslookup`**
DNS lookup tool. Used to verify that a hostname resolves correctly and to measure how long DNS resolution takes. Slow DNS = slow first byte for all requests.

**OOMKill**
"Out of Memory Kill" — when Kubernetes kills a container because it exceeded its memory limit. Appears in events as `OOMKilling`. Fix by increasing memory limits or finding the memory leak.

**`pg_stat_statements`**
A PostgreSQL extension that tracks query execution statistics (calls, mean time, total time). Essential for finding slow queries during performance investigations.

**`predict_linear` (Prometheus)**
A Prometheus function that uses linear regression to predict where a metric will be N seconds in the future. Used to alert "disk will be full in 4 hours" before it actually happens.

**Proactive Monitoring**
Monitoring designed to catch problems before users notice — trend alerts, capacity warnings, synthetic tests, anomaly detection. Opposite of reactive monitoring (users report the problem first).

**`promtool`**
CLI tool for validating Prometheus rule files (`promtool check rules`) and running unit tests against alert rules without a live Prometheus server.

**Readiness Probe**
A Kubernetes health check that answers: "Is this container ready to receive traffic?" If it fails, Kubernetes removes the pod from the load balancer (but doesn't restart it). Check DB and cache connections here.

**Real User Monitoring (RUM)**
Telemetry collected from actual browsers or mobile apps — page load times, JavaScript errors, user journeys. Reflects true end-user experience including CDN and device performance.

**Reliability**
The system does what it promises consistently and correctly. A system can be available (responding) but unreliable (returning wrong data). Both must be monitored separately.

**Restart Storm**
When many pods restart simultaneously, overloading the cluster or the downstream systems they depend on. Caused by overly sensitive liveness probes or DB connection failures.

**Rolling Restart**
Restarting pods one at a time instead of all at once. `kubectl rollout restart deployment/my-service` does this automatically, ensuring the service stays available throughout.

**Runbook**
A step-by-step document telling on-call engineers what to do when a specific alert fires. Every alert must link to a runbook — not having one multiplies investigation time.

**SEV (Severity) Level**
A classification of how serious an incident is (SEV1 = critical, SEV4 = low). Determines response time, who gets paged, and escalation path. Every team should define their own SEV criteria.

**SLA (Service Level Agreement)**
A legal/contractual commitment to customers about reliability. "We guarantee 99.9% availability or you get a refund." Breaching an SLA has business consequences.

**SLI (Service Level Indicator)**
The actual metric you measure to assess reliability. Good SLIs reflect user experience directly: error rate, p99 latency, % jobs completing on time.

**SLO (Service Level Objective)**
Your internal reliability target. "Error rate < 0.1%." Not a legal contract (that's the SLA), but a commitment between SRE and the development team. Defines the error budget.

**Startup Probe**
A Kubernetes health check that runs only during container startup. Prevents liveness probes from killing slow-starting containers before they've had a chance to finish initializing.

**Synthetic Monitoring**
Automated tests that simulate user behavior on a schedule from external locations. Detects failures before real users do. Runs 24/7 from multiple regions to catch geographic issues.

**Throttling (CPU)**
When a container uses more CPU than its limit allows, Kubernetes throttles it — the process is paused until the next scheduling window. High throttling = CPU limit too low; manifests as increased latency.

**Timeline (Incident)**
A chronological log of every action taken during an incident with timestamps. Used in post-mortems to understand the sequence of events and identify where time was lost.

**Toil**
Manual, repetitive operational work that grows with system scale but has no lasting value. Google SRE sets a target: < 50% of time on toil. Toil should be automated or eliminated.

**VPA (Vertical Pod Autoscaler)**
Kubernetes component that recommends or automatically adjusts CPU/memory requests and limits for pods based on actual usage. Prevents OOMKills and over-provisioning.

**Working Set Memory**
The memory a container is actively using (not counting OS-managed page cache, which is evictable). `container_memory_working_set_bytes` is the correct metric to alert on for OOMKill risk.
