# Commands: Reliability, Availability & Performance

---

## Phase 0 — Baseline: What Does "Normal" Look Like Right Now?

```bash
# Current error rate (Prometheus query — run in Grafana Explore or via API)
curl -s "http://localhost:9090/api/v1/query" \
  --data-urlencode 'query=sum(rate(http_requests_total{status=~"5.."}[5m])) / sum(rate(http_requests_total[5m]))' \
  | jq '.data.result[0].value[1]'

# p99 latency right now
curl -s "http://localhost:9090/api/v1/query" \
  --data-urlencode 'query=histogram_quantile(0.99, sum(rate(http_request_duration_seconds_bucket[5m])) by (le))' \
  | jq '.data.result[0].value[1]'

# Current request rate (RPS)
curl -s "http://localhost:9090/api/v1/query" \
  --data-urlencode 'query=sum(rate(http_requests_total[5m]))' \
  | jq '.data.result[0].value[1]'

# CPU throttling across all pods
kubectl top pods --all-namespaces | sort -k3 -rn | head -20

# Memory usage vs limits
kubectl get pods --all-namespaces -o json \
  | jq '.items[] | {pod: .metadata.name, ns: .metadata.namespace, containers: [.spec.containers[] | {name: .name, memLimit: .resources.limits.memory}]}'

# Check which pods have been OOMKilled recently
kubectl get events --all-namespaces --field-selector reason=OOMKilling | sort --key=1 -r

# Check pod restart counts (high restarts = instability)
kubectl get pods --all-namespaces | awk '$5 > 5 {print $0}' | sort -k5 -rn
```

---

## Phase 1 — SLO Monitoring Queries

```bash
# Error budget remaining (last 30 days)
# In Prometheus (run in Grafana Explore):
# 1 - (sum_over_time(sli:error_rate:5m[30d]) / (30 * 24 * 60 / 5))
# vs error budget rate 0.001 (99.9% SLO)

# Calculate burn rate manually right now
curl -s "http://localhost:9090/api/v1/query" \
  --data-urlencode 'query=(sum(rate(http_requests_total{status=~"5.."}[1h])) / sum(rate(http_requests_total[1h]))) / 0.001' \
  | jq '.data.result[0].value[1]'
# Result > 14.4 = critical; > 6 = warning; > 1 = burning budget

# Check if SLO alerts are correctly loaded
curl -s http://localhost:9090/api/v1/rules \
  | jq '.data.groups[] | select(.name | contains("slo")) | .rules[].name'

# Validate SLO rule file syntax
promtool check rules prometheus/rules/slo-rules.yaml

# Test SLO recording rules evaluate correctly (no live Prometheus needed)
promtool test rules prometheus/rules/slo-rules-test.yaml
```

---

## Phase 2 — Incident Detection and Triage

```bash
# Check all currently FIRING alerts
curl -s http://localhost:9090/api/v1/alerts \
  | jq '.data.alerts[] | select(.state=="firing") | {name: .labels.alertname, severity: .labels.severity, service: .labels.service}'

# Check Alertmanager active incidents
curl -s http://localhost:9093/api/v2/alerts \
  | jq '.[] | {name: .labels.alertname, status: .status.state, startsAt: .startsAt}'

# Identify which pods have errors (namespace-level triage)
kubectl get pods -n production | grep -v Running

# Check recent events for a specific namespace
kubectl get events -n production --sort-by='.lastTimestamp' | tail -30

# Check logs for a specific failing pod
kubectl logs -n production deploy/my-service --tail=100 | grep -E "ERROR|FATAL|Exception"

# Check logs across all pods for a service (using label selector)
kubectl logs -n production -l app=my-service --tail=50 | grep ERROR

# Check if there was a recent deployment (common incident cause)
kubectl rollout history deployment/my-service -n production

# Check what changed in the last deploy
kubectl describe deployment/my-service -n production | grep -A 10 "Events:"

# Check pod startup/readiness timeline (understand when it went bad)
kubectl describe pod <pod-name> -n production | grep -A 5 "Conditions:"
```

---

## Phase 3 — Incident Mitigation

```bash
# ROLLBACK: undo the last deployment immediately
kubectl rollout undo deployment/my-service -n production

# Watch rollback progress
kubectl rollout status deployment/my-service -n production -w

# Verify rollback is complete and pods are healthy
kubectl get pods -n production -l app=my-service

# SCALE UP: add more replicas if overloaded
kubectl scale deployment/my-service --replicas=10 -n production

# REMOVE A BAD NODE from scheduling (cordon it, don't delete)
kubectl cordon <node-name>

# DRAIN a node (move all pods off it)
kubectl drain <node-name> --ignore-daemonsets --delete-emptydir-data

# RESTART specific pods (not all at once — rolling)
kubectl rollout restart deployment/my-service -n production

# REDIRECT TRAFFIC away from a broken region (if using ingress weights)
kubectl annotate ingress my-service-ingress nginx.ingress.kubernetes.io/canary-weight="0"

# SILENCE an alert during known maintenance (amtool)
amtool silence add \
  alertname="HighErrorRate" \
  service="my-service" \
  --duration=1h \
  --comment="Incident mitigation in progress - SEV2" \
  --alertmanager.url http://localhost:9093

# Check that rollback restored correct image version
kubectl get deployment/my-service -n production \
  -o jsonpath='{.spec.template.spec.containers[0].image}'
```

---

## Phase 4 — Performance Investigation

```bash
# Find the slowest endpoints in the last 15 min (Prometheus)
# Run this in Grafana Explore:
# topk(10, histogram_quantile(0.99, sum(rate(http_request_duration_seconds_bucket[15m])) by (le, handler)))

# Check for CPU throttling on specific pod
kubectl exec -n production <pod-name> -- cat /sys/fs/cgroup/cpu/cpu.stat
# Look for: throttled_time — high values mean CPU limit is too low

# Check JVM heap if Java service (requires JMX exporter)
curl -s "http://localhost:9090/api/v1/query" \
  --data-urlencode 'query=jvm_memory_used_bytes{area="heap"} / jvm_memory_max_bytes{area="heap"}' \
  | jq '.data.result[] | {pod: .metric.pod, usage: .value[1]}'

# Check database connection pool saturation
curl -s "http://localhost:9090/api/v1/query" \
  --data-urlencode 'query=hikaricp_connections_active / hikaricp_connections_max' \
  | jq '.data.result[] | {pod: .metric.pod, saturation: .value[1]}'

# Find slow database queries (PostgreSQL)
kubectl exec -n production <postgres-pod> -- psql -U postgres -c \
  "SELECT query, mean_exec_time, calls FROM pg_stat_statements ORDER BY mean_exec_time DESC LIMIT 10;"

# Check network packet loss between pods
kubectl exec -n production <pod-name> -- ping -c 20 <other-service-ip>

# Check DNS resolution time (slow DNS = all requests slow)
kubectl exec -n production <pod-name> -- time nslookup my-service.production.svc.cluster.local

# Disk I/O saturation on node
iostat -x 2 5   # or via kubectl on node
```

---

## Phase 5 — Capacity Planning

```bash
# Predict disk full time (run in Grafana Explore or Prometheus API)
# predict_linear(node_filesystem_avail_bytes{mountpoint="/"}[6h], 4*3600) < 0

# Check disk usage trends
curl -s "http://localhost:9090/api/v1/query_range" \
  --data-urlencode 'query=node_filesystem_avail_bytes{mountpoint="/"}' \
  --data-urlencode 'start=2026-07-24T00:00:00Z' \
  --data-urlencode 'end=2026-07-31T00:00:00Z' \
  --data-urlencode 'step=3600' \
  | jq '.data.result[0].values[-5:]'

# Check memory trends (are pods growing over time = memory leak?)
curl -s "http://localhost:9090/api/v1/query" \
  --data-urlencode 'query=container_memory_working_set_bytes / container_memory_working_set_bytes offset 7d' \
  | jq '.data.result[] | select(.value[1] | tonumber > 1.2) | .metric.pod'
# Any pod with ratio > 1.2 grew 20% in 7 days — memory leak candidate

# Check HPA (Horizontal Pod Autoscaler) status
kubectl get hpa --all-namespaces

# Check VPA (Vertical Pod Autoscaler) recommendations
kubectl get vpa --all-namespaces -o json \
  | jq '.items[] | {name: .metadata.name, recommendation: .status.recommendation}'

# Current resource requests vs actual usage (right-sizing)
kubectl resource-capacity --pods --util
# (requires kubectl-resource-capacity plugin)

# Node capacity overview
kubectl describe nodes | grep -A 5 "Allocated resources"
```

---

## Phase 6 — Health Check Validation

```bash
# Test liveness endpoint directly
curl -s http://my-service:8080/health/live | jq .

# Test readiness endpoint directly
curl -s http://my-service:8080/health/ready | jq .

# Check Kubernetes probe status for a pod
kubectl describe pod <pod-name> -n production \
  | grep -A 10 "Liveness\|Readiness\|Startup"

# Check if readiness is causing pods to be removed from endpoints
kubectl get endpoints my-service -n production

# Compare pods running vs endpoints (if different, some pods are not ready)
PODS=$(kubectl get pods -n production -l app=my-service --no-headers | wc -l)
ENDPOINTS=$(kubectl get endpoints my-service -n production -o json | jq '.subsets[0].addresses | length')
echo "Pods: $PODS, Ready Endpoints: $ENDPOINTS"

# Simulate OOMKill risk: check memory working set vs limit
kubectl get pods -n production -l app=my-service -o json \
  | jq '.items[] | {
      pod: .metadata.name,
      limit: .spec.containers[0].resources.limits.memory,
      oomScore: .spec.containers[0].resources.limits.memory
    }'
```

---

## Phase 7 — Post-Incident Analysis

```bash
# Pull logs for the exact incident window
kubectl logs -n production deploy/my-service \
  --since-time="2026-07-31T14:32:00Z" \
  --until-time="2026-07-31T14:53:00Z" \
  | grep -E "ERROR|FATAL|Exception" > /tmp/incident-logs.txt

# Count error types (help identify root cause pattern)
kubectl logs -n production deploy/my-service --since=24h \
  | grep ERROR | awk '{print $5}' | sort | uniq -c | sort -rn | head -20

# Check Prometheus for error rate during incident window
curl -s "http://localhost:9090/api/v1/query_range" \
  --data-urlencode 'query=sum(rate(http_requests_total{status=~"5.."}[5m])) / sum(rate(http_requests_total[5m]))' \
  --data-urlencode 'start=2026-07-31T14:00:00Z' \
  --data-urlencode 'end=2026-07-31T15:00:00Z' \
  --data-urlencode 'step=60' \
  | jq '.data.result[0].values'

# Check all events in namespace during incident window
kubectl get events -n production \
  --field-selector type=Warning \
  | grep "14:3\|14:4\|14:5"

# Check audit log for config changes before incident
kubectl get events -n production --sort-by='.lastTimestamp' \
  | grep -E "ScalingReplicaSet|Pulling|Started|Killing"
```
