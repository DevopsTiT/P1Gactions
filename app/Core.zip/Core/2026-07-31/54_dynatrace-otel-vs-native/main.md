# Dynatrace: OTEL vs Native OneAgent Instrumentation — SRE Deep Dive

> **The question:** Can you skip `OTEL_EXPORTER_OTLP_ENDPOINT` + `OTEL_SERVICE_NAME` in Helm values.yaml and rely purely on OneAgent (DT native) for distributed traces?
>
> **Short answer:** Yes — but understanding the exact difference between the two approaches determines which one (or both) you should use.

---

## Decision Tree — Which Approach for Your Situation?

```
Do you need distributed traces across services?
  YES →
    Are ALL services running on DT-monitored Kubernetes nodes?
      YES → OneAgent native (classicFullStack) handles traces automatically
            OTEL env vars are OPTIONAL but add service naming control
      NO  → Some services outside DT cluster → OTEL needed for cross-boundary traces
  
  Do you need traces to work with non-DT systems (Jaeger, Zipkin, other vendors)?
    YES → Use OTEL (W3C traceparent standard = portable)
    NO  → OneAgent native is sufficient
  
  Do you care that OTEL_SERVICE_NAME controls the exact name in Terraform services map?
    YES → Keep OTEL_SERVICE_NAME
    NO  → OneAgent will infer a name but it may not match your Terraform config key
  
  Are you using classicFullStack mode?
    YES → OneAgent auto-instruments everything, OTEL is additive
    Using cloudNativeFullStack/applicationOnly? → OTEL more important (no host-level injection)
```

---

## Part 1 — The Four Layers Revisited

```
Layer 1: INSTALLATION
  DynaKube CR (classicFullStack: enabled: true)
  → Dynatrace Operator deploys OneAgent as DaemonSet (one pod per node)
  → OneAgent hooks into EVERY process on the node via OS-level injection

Layer 2: AUTO-DETECTED (zero config, always on with Layer 1)
  Services, response time, error rate, throughput, DB calls,
  JVM heap/GC, process restarts, CPU/memory, K8s workload state
  ALL captured automatically via JVMTI + /proc + cgroup reads
  ↑ This layer gives you DISTRIBUTED TRACES natively — no OTEL needed

Layer 3: CONFIGURED BY SRE (Terraform)
  Management zones, alerting profiles, metric events,
  SLOs, synthetics, notifications
  ↑ This works the same regardless of OTEL vs native

Layer 4: APPLICATION INSTRUMENTATION (optional when using classicFullStack)
  OTEL_EXPORTER_OTLP_ENDPOINT + OTEL_SERVICE_NAME in Helm values.yaml
  → Sends traces via OTLP protocol (W3C standard)
  → Adds service name control and cross-system portability
```

---

## Part 2 — How OneAgent Native Tracing Works (Without OTEL)

### The JVMTI injection mechanism

When `classicFullStack: enabled: true`, OneAgent on each node:

```
1. Detects: "a JVM process started on this node"
2. Attaches to the JVM via JVMTI (before application code runs)
3. In-memory bytecode instrumentation:
   - Wraps @RestController methods → measures HTTP request entry/exit time
   - Wraps RestTemplate/WebClient → measures outgoing HTTP calls
   - Wraps JDBC execute() → measures DB query time
   
4. For OUTGOING HTTP calls (e.g., order-service calls payment-service):
   OneAgent automatically injects its proprietary header:
   
   x-dynatrace: FW4;3;x;0;0;0;0;4;abcdef123456;0;1
   
   (DT's own trace context format — not W3C, not B3)
   
5. For INCOMING HTTP calls (payment-service receives from order-service):
   OneAgent reads the x-dynatrace header
   → Recognizes it as a DT trace context
   → Creates a child span linked to the incoming trace ID
   
6. Result: distributed trace is stitched together in DT tenant:
   order-service [120ms]
     └── HTTP call → payment-service [80ms]
           └── JDBC INSERT          [35ms]
   
   No code changes. No OTEL. Pure OneAgent.
```

### What DT natively captures about the service

Without any OTEL configuration, DT creates a **Service entity** by detecting:
- Process name (e.g., `java` running `payment-service-0.0.1-SNAPSHOT.jar`)
- Listening port (8080)
- Framework detected (Spring Boot via classpath detection)
- Technology: Java, Spring MVC

The service entity name in DT will be something like:
```
payment-service-0.0.1-SNAPSHOT (on company-dev)
```
or depending on DT's inference:
```
payment-service (Spring Boot)
```

DT is quite good at inferring a clean service name from the jar name, but it may not be the exact string you want — and it may NOT match `"payment-service"` in your Terraform `services = { "payment-service" = {...} }` map.

---

## Part 3 — How OTEL Tracing Works (The Optional Layer 4)

### The Helm values configuration

```yaml
# charts/payment-service/values.yaml
env:
  - name: OTEL_EXPORTER_OTLP_ENDPOINT
    value: "http://dynatrace-activegate.dynatrace.svc:4318"
  - name: OTEL_SERVICE_NAME
    value: "payment-service"
```

### What this adds on top of OneAgent

```
build.gradle dependencies:
  micrometer-tracing-bridge-otel    → bridges Spring Boot's Micrometer tracing to OTEL
  opentelemetry-exporter-otlp       → sends spans via OTLP protocol

When order-service calls payment-service (OTEL path):

1. order-service Spring Boot creates a span via Micrometer
2. Injects W3C traceparent header:
   traceparent: 00-abc123def456...-9876543210...-01
   (standard: version-traceId-parentSpanId-flags)
   
3. Sends the span to: http://dynatrace-activegate.dynatrace.svc:4318
   (ActiveGate OTLP ingest endpoint)
   
4. payment-service receives the traceparent header
   Creates child span linked to the same trace ID
   Sends its span to ActiveGate
   
5. DT receives both spans via OTLP
   Stitches them together: same trace ID = same distributed trace
   
6. OTEL_SERVICE_NAME = "payment-service"
   → The service entity in DT is named EXACTLY "payment-service"
   → Matches your Terraform: services = { "payment-service" = { ... } }
   → Metric event filter: value = "payment-service" key = "service.name" ✅
```

---

## Part 4 — Side-by-Side Comparison

| Aspect | OneAgent Native (no OTEL) | OTEL Layer 4 Added |
|---|---|---|
| Distributed traces | ✅ Yes (DT proprietary header) | ✅ Yes (W3C traceparent) |
| Requires code/config changes | ❌ None | Env vars in Helm values.yaml |
| Requires extra dependencies | ❌ None | micrometer-tracing-bridge-otel + opentelemetry-exporter-otlp in build.gradle |
| Trace header format | DT proprietary `x-dynatrace` | W3C `traceparent` standard |
| Service name in DT | Inferred from jar/process name | Controlled by OTEL_SERVICE_NAME |
| Matches Terraform services map key | ⚠️ Maybe (depends on inference) | ✅ Guaranteed |
| Works with non-DT systems | ❌ Proprietary format | ✅ W3C standard (portable) |
| Works across DT-unmonitored boundaries | ❌ No (must go node→node) | ✅ Yes (headers travel any distance) |
| Sampling rate control | DT auto-adapts | `management.tracing.sampling.probability: 1.0` |
| Port/network requirement | None (in-process) | Port 4318 to ActiveGate must be open |
| Works in classicFullStack | ✅ Full support | ✅ Additive |
| Works without OneAgent | ❌ No | ✅ Yes (OTEL-only setup) |

---

## Part 5 — The Critical Dependency: Service Name Matching

This is the most important practical difference for SREs managing this project.

### The Terraform services map key

```hcl
# terraform/environments/production/main.tf
services = {
  "payment-service" = {   ← THIS KEY
    team             = "payments"
    ...
  }
}
```

### The DT metric event entity filter

```hcl
# terraform/modules/dynatrace/main.tf
query_definition {
  entity_filter {
    conditions {
      type  = "DIMENSION"
      operator = "EQUALS"
      value = each.key        ← "payment-service"
      key   = "service.name"  ← matches against DT entity's service.name attribute
    }
  }
}
```

### What `service.name` resolves to

**Without OTEL (OneAgent native):**
```
DT infers service.name from:
  Option A: jar filename → "payment-service-0.0.1-SNAPSHOT"
  Option B: spring.application.name property → "payment-service" ✅
  Option C: class name → "PaymentApplication"
  
If application.yaml has:
  spring:
    application:
      name: payment-service    ← DT reads this
  
Then: service.name = "payment-service" ✅ matches the Terraform key!

If spring.application.name is NOT set or is set to something different:
  DT guesses from jar name → may not match
  Metric events: entity filter finds nothing → alerts never fire
  SLO: no matching service → SLO is always 100% (no data = not measured)
```

**With OTEL (OTEL_SERVICE_NAME set):**
```
OTEL_SERVICE_NAME = "payment-service"
→ All OTEL spans tagged with: service.name = "payment-service"
→ DT creates/uses entity with: service.name = "payment-service"
→ Metric event filter: "payment-service" matches exactly ✅
→ Alerts fire correctly ✅
```

### The safe approach

If you want to drop OTEL env vars and rely on DT native, you MUST ensure `spring.application.name` matches the Terraform key:

```yaml
# services/<service>/app/src/main/resources/application.yaml
spring:
  application:
    name: payment-service   ← must match "payment-service" in Terraform services map
```

This is already set in this project's `application.yaml`. So OneAgent native WOULD match. But `OTEL_SERVICE_NAME` is an explicit, configuration-visible guarantee — you can see it in the Helm values. `spring.application.name` is buried in application.yaml. OTEL_SERVICE_NAME removes ambiguity.

---

## Part 6 — When You MUST Use OTEL (OneAgent Native Is Not Enough)

### Scenario 1: Service outside the DT-monitored cluster

```
Your microservice architecture includes:
  EKS cluster (DT monitored) → payment-service, order-service
  External payment gateway (not on your cluster)
  Mobile app (definitely not on your cluster)

Native OneAgent:
  payment-service → injects x-dynatrace header → payment-gateway
  Payment gateway doesn't have OneAgent → header is ignored → trace ends here
  
  Mobile app → injects x-dynatrace header → order-service
  DT sees the order-service span but doesn't know it came from mobile
  
OTEL (W3C traceparent):
  payment-service → injects traceparent → payment-gateway
  If payment-gateway supports W3C (most modern APIs do) → trace continues
  
  Mobile SDK sends traceparent → order-service
  DT sees the full trace from mobile → through all services
```

### Scenario 2: Multi-vendor observability

```
You use: Dynatrace for production, Jaeger for dev/staging
  
Native OneAgent:
  x-dynatrace header → only DT understands this format
  Cannot send traces to Jaeger
  
OTEL:
  traceparent header → W3C standard
  Configure OTLP exporter endpoint:
    Production: → Dynatrace ActiveGate (port 4318)
    Dev/Staging: → Jaeger OTLP endpoint
  
  Same application code, different exporter endpoint per environment.
  This project does this via Helm values:
    values.yaml (prod):    OTEL_EXPORTER_OTLP_ENDPOINT → DT ActiveGate
    values-dev.yaml (dev): could point to Jaeger instead
```

### Scenario 3: cloudNativeFullStack or applicationOnly mode

```
DynaKube modes:
  classicFullStack:    OneAgent DaemonSet on each NODE (strong auto-instrumentation)
  cloudNativeFullStack: OneAgent injected as sidecar via webhook (per-pod)
  applicationOnly:     No OneAgent; OTEL only
  
For cloudNativeFullStack:
  Webhook injects OneAgent as init container
  Works but injection timing can miss some startup instrumentation
  OTEL provides a reliable supplement
  
For applicationOnly:
  No OneAgent at all
  MUST use OTEL — there is no other instrumentation
```

### Scenario 4: Explicit trace sampling control

```
OneAgent native:
  DT auto-adapts sampling rate based on traffic volume
  You cannot set "always sample 100%" without DT settings
  
OTEL:
  application.yaml:
    management:
      tracing:
        sampling.probability: 1.0   ← 100% of requests traced
        
  At high traffic (100 req/s), 100% sampling = 100 traces/sec stored in DT
  At very high traffic (10,000 req/s), reduce to 0.1 (1% sample)
  
  Full control per service and per environment.
```

---

## Part 7 — What Happens If You Remove OTEL Env Vars from This Project

### Step-by-step impact analysis

**Remove from `values.yaml`:**
```yaml
# REMOVE these:
- { name: OTEL_EXPORTER_OTLP_ENDPOINT, value: "http://dynatrace-activegate.dynatrace.svc:4318" }
- { name: OTEL_SERVICE_NAME,           value: "payment-service" }
```

**Also remove from `build.gradle`:**
```gradle
# REMOVE these dependencies:
implementation 'io.micrometer:micrometer-tracing-bridge-otel'
implementation 'io.opentelemetry:opentelemetry-exporter-otlp'
```

**What still works (OneAgent handles it):**
```
✅ All Layer 2 auto-detection: response time, error rate, throughput, DB calls, JVM heap, GC
✅ Distributed traces between services (via x-dynatrace header)
✅ Process-level CPU/memory metrics
✅ Kubernetes workload state
✅ Container logs (logMonitoring: true in DynaKube)
✅ All Layer 3 Terraform config: zones, alerts, SLOs, synthetics, notifications
```

**What changes or risks:**
```
⚠️ Service name in DT: controlled by spring.application.name (in application.yaml)
   If spring.application.name = "payment-service" → still matches Terraform key ✅
   If spring.application.name is absent/different → metric events filter misses → no alerts 🚨
   
⚠️ Trace format: x-dynatrace (DT proprietary) instead of traceparent (W3C)
   Impact: only within DT-monitored services (fine for this project)
   
⚠️ Trace sampling: DT auto-adapts (not explicitly controlled)
   Usually fine; DT is smart about this
   
⚠️ OTEL dependencies removed from build.gradle
   Smaller jar (~2MB smaller)
   No OTEL SDK startup overhead
   
❌ No longer works: distributed traces to non-DT-monitored services
   Fine for this project (all 3 services are on DT-monitored cluster)
```

### The safest "drop OTEL" configuration for this project

If you want to remove OTEL and rely on OneAgent native, the minimum required is:

```yaml
# application.yaml — REQUIRED: name must match Terraform services map key
spring:
  application:
    name: payment-service   # "payment-service" not "PaymentService" not "payment_service"
```

```hcl
# terraform/modules/dynatrace/main.tf — must match spring.application.name exactly
services = {
  "payment-service" = { ... }   # exact match required
}
```

```hcl
# DynaKube — classicFullStack must remain enabled
classicFullStack:
  enabled: true   # this is what enables JVMTI instrumentation
```

---

## Part 8 — Using Both (This Project's Current Approach)

### Why the project uses BOTH OneAgent native AND OTEL

```
OneAgent (classicFullStack): 
  Auto-instruments everything at the host/process level
  Captures: DB calls, JVM heap, GC, process CPU/memory, container logs
  Distributed traces: via x-dynatrace header (DT proprietary)

OTEL (env vars in Helm):
  Sends additional traces via OTLP → W3C traceparent standard
  OTEL_SERVICE_NAME: explicit, visible service name guarantee
  Enables future portability (if you add Jaeger, Grafana Tempo, etc.)
  
Both run simultaneously:
  DT receives traces via TWO paths for the same request:
    1. OneAgent path: x-dynatrace header → JVMTI instrumentation → DT
    2. OTEL path: traceparent header → micrometer → OTLP → ActiveGate port 4318 → DT
  
  DT is smart enough to correlate and deduplicate — you don't see double traces.
  DT merges them into one unified view.
```

### How DT handles dual instrumentation

```
OneAgent captures:
  - Complete method-level traces (via JVMTI bytecode injection)
  - DB call timings
  - JVM internals
  
OTEL adds:
  - W3C trace context (for interoperability)
  - Explicit service.name from OTEL_SERVICE_NAME
  - Any custom spans your code adds (if you annotate methods)
  
DT merges: same trace ID → same unified trace
The OTEL service.name becomes the canonical service name in DT.
OneAgent's richer instrumentation data enriches that trace.

This is the recommended Dynatrace approach: deploy OneAgent for broad coverage,
add OTEL selectively for explicit control and portability.
```

---

## Part 9 — Practical SRE Decision Guide

### Should you keep or remove OTEL env vars?

**Keep both (current project approach) when:**
```
✅ You want explicit, auditable service naming (OTEL_SERVICE_NAME visible in Helm values)
✅ You might add non-DT observability tools in the future (Jaeger, Grafana Tempo)
✅ Some services will eventually be outside the DT-monitored cluster
✅ You want W3C standard trace headers (interoperability with external APIs)
✅ You want explicit sampling rate control per service
```

**Remove OTEL, rely on OneAgent native when:**
```
✅ All services are on DT-monitored cluster now AND in future
✅ spring.application.name is set and matches Terraform services map key exactly
✅ You want simpler Helm values (fewer env vars)
✅ You want smaller Docker images (remove 2 Gradle dependencies)
✅ You don't need W3C trace header portability
✅ DT is your only observability vendor and will remain so
```

**Minimum config to make pure OneAgent work correctly with this project's Terraform:**
```yaml
# application.yaml MUST have:
spring:
  application:
    name: payment-service   ← exact match with Terraform services map key

# DynaKube MUST have:
classicFullStack:
  enabled: true

# Remove from Helm values.yaml:
# OTEL_EXPORTER_OTLP_ENDPOINT and OTEL_SERVICE_NAME

# Remove from build.gradle:
# micrometer-tracing-bridge-otel
# opentelemetry-exporter-otlp
```

**Verify OneAgent is correctly naming the service:**
```bash
# Check what service name DT inferred for a pod:
# DT UI → Applications & Microservices → Services
# Search for "payment-service"
# If you see "payment-service-0.0.1-SNAPSHOT" instead → spring.application.name not picked up
# If you see "payment-service" → matches Terraform key → alerts will fire correctly

# Also verify via kubectl (check what env vars the pod sees):
kubectl exec -it $(kubectl get pods -n payment-ns -l app=payment-service -o jsonpath='{.items[0].metadata.name}') \
  -n payment-ns -- env | grep -E 'SPRING_APPLICATION|OTEL'
```

---

## Summary: The Four Layers + Recommended Choices

```
Layer 1: INSTALLATION — ALWAYS REQUIRED
  DynaKube classicFullStack: enabled: true
  → No choice: this is what makes monitoring work at all

Layer 2: AUTO-DETECTED — ALWAYS PRESENT with Layer 1
  OneAgent captures everything automatically
  Response time, error rate, DB calls, JVM metrics, K8s state
  Distributed traces via x-dynatrace header
  → No action needed. It just works.

Layer 3: SRE CONFIGURED (Terraform) — ALWAYS RECOMMENDED
  Management zones, alerting profiles, metric events, SLOs, synthetics, notifications
  → You MUST configure these. DT doesn't alert without them.

Layer 4: APPLICATION INSTRUMENTATION — OPTIONAL with classicFullStack
  OTEL_EXPORTER_OTLP_ENDPOINT + OTEL_SERVICE_NAME

  KEEP if:
    → Multiple observability vendors or future vendor flexibility
    → Services span DT/non-DT boundaries
    → Explicit service name control is important
    → W3C standard trace headers needed

  REMOVE SAFELY if:
    → All services on DT-monitored cluster
    → spring.application.name matches Terraform key exactly
    → DT-only observability (no migration planned)
    → Simpler Helm values are a priority
```
