# Glossary — Dynatrace OTEL vs Native Instrumentation

Every term used in main.md. Plain language for an SRE beginner.

---

**classicFullStack**
A DynaKube mode that deploys OneAgent as a DaemonSet (one pod per node) with full host-level and process-level access. Provides the strongest automatic instrumentation. Why it matters: enables JVMTI injection into every JVM on the node — the foundation of zero-code-change monitoring.

**JVMTI (Java Tool Interface)**
A C API built into every JVM that lets external agents attach and modify bytecode at runtime. OneAgent uses this to wrap Spring Boot methods and capture timings without touching source code. Why it matters: the mechanism that makes "zero code changes required" possible for Java monitoring.

**Bytecode instrumentation**
Modifying compiled Java bytecode (`.class` files) at runtime to add timing measurements around methods. OneAgent does this in-memory when attaching to a JVM. Why it matters: lets OneAgent measure HTTP request duration and DB call time without any changes to the application.

**DaemonSet**
A Kubernetes resource that ensures exactly one pod runs on every node in the cluster, including new nodes as they're added. OneAgent is deployed as a DaemonSet. Why it matters: guarantees every node is monitored — you can't miss a node.

**DynaKube**
A Kubernetes custom resource that configures how Dynatrace is deployed in the cluster (OneAgent mode, ActiveGate settings, token references). Why it matters: the single configuration object controlling the entire DT monitoring deployment.

**OneAgent**
Dynatrace's monitoring agent. In classicFullStack mode, runs as a DaemonSet pod on every node, hooks into all processes via OS-level mechanisms. Why it matters: the component that actually captures all the metrics, traces, and logs automatically.

**x-dynatrace header**
Dynatrace's proprietary HTTP trace context header. OneAgent injects this on outgoing requests and reads it on incoming requests to stitch distributed traces together. Why it matters: this is how OneAgent creates distributed traces natively — without any OTEL libraries.

**Distributed trace**
A record of a single user request as it flows through multiple services. Each service creates a "span" linked by a shared trace ID. Why it matters: shows exactly where time is spent across service boundaries — "is payment slow or is order-service slow calling payment?"

**Span**
One unit of work in a distributed trace — e.g., "payment-service handled this HTTP request" or "JDBC query ran for 35ms." Why it matters: the building block of distributed tracing. Multiple linked spans form a complete trace.

**W3C traceparent**
The internet standard HTTP header format for distributed trace context: `traceparent: 00-traceId-parentSpanId-flags`. Supported by virtually all observability vendors. Why it matters: vendor-neutral — a traceparent from your service can be read by Jaeger, Zipkin, Datadog, or Dynatrace.

**OTEL (OpenTelemetry)**
A vendor-neutral open standard and set of SDKs for collecting and exporting telemetry data (traces, metrics, logs). Why it matters: write once, export to any observability backend — Dynatrace, Jaeger, Grafana Tempo, etc.

**OTLP (OpenTelemetry Protocol)**
The wire protocol for sending OpenTelemetry data from application to backend. This project uses OTLP/HTTP on port 4318. Why it matters: the actual transport mechanism — how spans travel from Spring Boot to Dynatrace ActiveGate.

**OTEL_EXPORTER_OTLP_ENDPOINT**
An environment variable that tells the OTEL SDK where to send spans. In this project: `http://dynatrace-activegate.dynatrace.svc:4318` — the DT ActiveGate inside the cluster. Why it matters: without this, OTEL SDK has nowhere to send data.

**OTEL_SERVICE_NAME**
An environment variable that sets the `service.name` attribute on all spans from this application. Controls what name Dynatrace uses for the service entity. Why it matters: must match exactly the key in the Terraform `services = { "payment-service" = {...} }` map for metric events and SLOs to fire correctly.

**`service.name` attribute**
A span attribute that DT uses to identify which service entity the spans belong to. Sources in priority order: OTEL_SERVICE_NAME env var → `spring.application.name` property → inferred from jar filename. Why it matters: all DT metric event filters, SLO queries, and management zone rules are scoped to this exact value.

**`spring.application.name`**
A Spring Boot property in `application.yaml` that sets the application's name. DT OneAgent reads this to infer the service entity name when OTEL is not configured. Why it matters: if this doesn't match the Terraform services map key, DT metric events filter finds no matching entity → alerts never fire.

**micrometer-tracing-bridge-otel**
A Java library that bridges Spring Boot's Micrometer tracing API to OpenTelemetry. Allows Spring Boot to automatically create OTEL spans without code changes. Why it matters: the glue between Spring Boot and the OTEL SDK.

**opentelemetry-exporter-otlp**
A Java library that exports OTEL spans via the OTLP protocol to the configured endpoint. Why it matters: without this, spans are created but never sent anywhere.

**Micrometer**
Spring Boot's built-in metrics and tracing abstraction layer. Supports multiple backends via bridge libraries (OTEL, Brave/Zipkin, etc.). Why it matters: you write one set of instrumentation code; Micrometer sends it to whichever backend is configured.

**`sampling.probability: 1.0`**
OTEL setting that controls what fraction of requests get traced. 1.0 = 100% of requests. 0.1 = 10%. Why it matters: at high traffic, 100% sampling generates many spans → storage cost. Reduce for high-traffic production services.

**ActiveGate port 4318**
The OTLP/HTTP ingest port on the Dynatrace ActiveGate. Application pods send OTEL spans here. Why it matters: the network endpoint that must be reachable from application pods for OTEL to work.

**`cloudNativeFullStack` (DynaKube mode)**
A DynaKube mode where OneAgent is injected as a sidecar container via a Kubernetes admission webhook, rather than as a DaemonSet. Per-pod injection instead of per-node. Why it matters: less host-level access than classicFullStack; OTEL becomes more important as a supplement.

**`applicationOnly` (DynaKube mode)**
A DynaKube mode with no OneAgent — instrumentation is purely via OTEL SDK in the application. Why it matters: requires explicit OTEL configuration (OTEL_EXPORTER_OTLP_ENDPOINT, OTEL_SERVICE_NAME) — there's no automatic instrumentation without OneAgent.

**Proprietary header format**
A vendor-specific HTTP header (like DT's `x-dynatrace`) that only works with that vendor's tools. Contrast with W3C standard `traceparent`. Why it matters: a proprietary header trace from DT can't be read by Jaeger; a W3C traceparent header can be read by any vendor.

**Dual instrumentation**
Running both OneAgent native tracing AND OTEL simultaneously. DT correlates traces from both paths by matching trace IDs. Why it matters: gets the best of both worlds — OneAgent's deep JVM data + OTEL's portability and explicit service naming.

**Trace deduplication**
DT's ability to merge traces arriving via two paths (OneAgent x-dynatrace + OTEL traceparent) into one unified trace view. Why it matters: prevents seeing "double" traces when both instrumentation paths are active.

**Terraform services map key**
The string key in `services = { "payment-service" = {...} }` in the environment's `main.tf`. Used as the DT entity filter in all metric events, SLOs, and synthetic names. Why it matters: must exactly match the DT service entity name — if they differ, all alerts are silent.

**Entity filter (DT metric event)**
A condition that narrows a metric event to a specific DT service entity. `value = "payment-service" key = "service.name"`. Why it matters: without entity filters, one metric event would aggregate all services and fire incorrectly.

**Trunk-based observability**
The principle that all telemetry (traces, metrics, logs) should flow to one platform so you can correlate across them. Why it matters: "metric spike + log error + slow trace" — seeing all three together immediately reveals root cause.

**Jaeger**
An open-source distributed tracing backend (CNCF project). Accepts W3C traceparent and OTLP data. Alternative to Dynatrace for tracing. Why it matters: a reason to use OTEL (W3C) instead of DT native — if you ever want to send traces to Jaeger, OTEL works; x-dynatrace header does not.

**Grafana Tempo**
An open-source distributed traces storage backend from Grafana Labs. Accepts OTLP. Why it matters: another reason to use OTEL — Tempo is a common choice for teams using Grafana stack alongside or instead of Dynatrace.

**`spring.application.name`**
Covered above, but worth repeating: this single property in `application.yaml` is the fallback service name that DT uses when OTEL_SERVICE_NAME is not set. Why it matters: the only thing standing between "metrics alerts work" and "alerts never fire" when removing OTEL env vars.

**`kubectl exec -it ... -- env | grep`**
A kubectl command that runs a command inside a running container. `env | grep OTEL` shows which OTEL environment variables the pod actually received (vs what you think you configured). Why it matters: verifies that Helm values actually injected the expected env vars into the container.
