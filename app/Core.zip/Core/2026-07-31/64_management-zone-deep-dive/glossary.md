# 64 — Management Zone Rule (Terraform): Glossary

Every term from main.md explained for an SRE beginner. One entry per term.

---

**Management Zone (Dynatrace)**
A named filter in Dynatrace that groups entities (services, hosts, processes) that share something in common — typically belonging to the same team and environment. Think of it as a "team-specific view" of Dynatrace. Without zones, all teams see all services mixed together.

**`dynatrace_management_zone_v2` (Terraform resource)**
The Terraform resource type for creating a Dynatrace management zone. The `_v2` suffix means it uses the newer Dynatrace Settings API (v2), not the older Configuration API (v1). Calling this resource triggers a Dynatrace REST API call to create or update a zone.

**`for_each` (Terraform)**
A Terraform meta-argument that creates multiple copies of a resource from a map or set. Instead of writing 9 separate `dynatrace_management_zone_v2` blocks for 9 zones, `for_each` on a map of 9 items creates all 9 automatically. Adding a new team means adding one entry to the map.

**Entity (Dynatrace)**
Any monitored component that Dynatrace tracks: a service (HTTP endpoint), a host (server/VM/EC2 node), a process group (JVM running payment-service), a database, a Kubernetes namespace. Each entity has an ID and a set of tags.

**Tag (Dynatrace)**
A key-value label attached to a Dynatrace entity. Format: `key:value` (e.g., `team:payments`, `environment:production`). Used by management zone rules to decide which entities belong in which zone. Tags are NOT the same as Kubernetes labels, but Kubernetes labels can be converted to DT tags via auto-tagging rules.

**Auto-Tagging Rule (Dynatrace)**
A DT configuration that automatically assigns tags to entities based on metadata (Kubernetes labels, host names, process names). Without auto-tagging, tags must be set manually. In this system: K8s namespace labels (`team: payments`) are automatically converted to DT tags (`team:payments`).

**`rules {}` block (management zone)**
A container for one matching rule within the management zone. Multiple `rules {}` blocks create OR logic: an entity is included if it matches ANY of the rules. A single `rules {}` block with multiple `attribute_conditions` creates AND logic.

**`rule {}` block (management zone)**
Defines one set of conditions that an entity must satisfy to be included in the zone. `type = "ME"` means the rule evaluates Monitored Entities (services, hosts, etc.).

**`type = "ME"` (management zone rule)**
Specifies that this rule evaluates Monitored Entities (the actual services, hosts, processes in your infrastructure). The alternative type `"DIMENSION"` evaluates metrics and log dimensions. For team-based access control, always use `"ME"`.

**`attribute_conditions {}` block**
Defines one condition within a rule. Multiple `attribute_conditions` in the same rule are combined with AND logic (all must be true). Specifies which attribute of the entity to check, how to compare it (`operator`), and what value to match against.

**`attribute = "SERVICE_TAGS"`**
Tells DT to look at the tags on SERVICE entities when evaluating this condition. Different attributes check different entity types: `HOST_TAGS` checks host tags, `PROCESS_GROUP_TAGS` checks process group tags. Using the wrong attribute means the rule evaluates the wrong entity type and may return unexpected results.

**`operator = "TAG_KEY_VALUE_MATCH"`**
The comparison operator that requires both the tag key AND tag value to match exactly. `team:payments` matches only if key=`team` AND value=`payments`. The most specific and safest operator for team-based zone rules. Prevents accidental over-inclusion.

**`TAG_KEY_MATCH` (operator)**
An alternative operator that only checks whether the tag KEY exists, ignoring the value. `attribute = "SERVICE_TAGS"`, `operator = "TAG_KEY_MATCH"`, `tag_value = "team"` matches any service with any `team` tag (payments, orders, notifications). Used for "does this entity have a team assignment at all?" checks.

**`tag_value = "team:payments"`**
The full tag string in `key:value` format used for matching. The colon separates key from value. Case-sensitive. Must match exactly what Dynatrace stores: no extra spaces, correct capitalization. A typo here (`"team: payments"` with a space) means zero entities match.

**AND logic (multiple `attribute_conditions` in one rule)**
When two or more `attribute_conditions` appear inside a single `rule {}`, ALL conditions must be true for an entity to match. Used to say: "entity must be tagged team:payments AND environment:production." An entity tagged only `team:payments` (without `environment:production`) would NOT match.

**OR logic (multiple `rules {}` blocks)**
When two or more `rules {}` blocks appear in the management zone definition, an entity is included if it matches ANY of the rules. Used to say: "entity must be tagged team:payments OR team:orders." Each rule is an independent matching criterion.

**`mzName()` (DT filter expression)**
A Dynatrace filter function used in SLO metric expressions and entity queries to scope data to a specific management zone. Example: `filter = "type(\"SERVICE\"),mzName(\"payments-production\")"` limits the SLO to only services in the payments-production zone.

**Namespace Labels (Kubernetes)**
Key-value metadata attached to a Kubernetes namespace in its YAML manifest. Example: `labels: {team: payments, environment: production}`. In this system, namespace labels are the starting point for the entire tagging chain: labels → auto-tagging rule → DT tags → management zone match.

**JVMTI (Java Virtual Machine Tool Interface)**
A low-level Java API that allows external agents (like OneAgent) to attach to a running JVM and inspect or modify its behavior. OneAgent uses JVMTI to instrument Java methods (HTTP handlers, JDBC calls) without modifying application code.

**DaemonSet (Kubernetes)**
A Kubernetes resource that ensures exactly one pod runs on each node in the cluster. OneAgent is deployed as a DaemonSet so every node has a monitoring agent. When new nodes are added, Kubernetes automatically creates a new DaemonSet pod on them.

**`schemaId: "builtin:management-zones"` (DT Settings API)**
The Dynatrace API identifier for the management zones schema. When Terraform applies a `dynatrace_management_zone_v2` resource, it calls `POST /api/v2/settings/objects` with this schema ID. The v2 API is the modern way to manage DT configuration.

**Terraform Resource Label**
The second name in a resource declaration: `resource "type" "label"`. In `resource "dynatrace_management_zone_v2" "team_env"`, `team_env` is the label. It is used within Terraform to reference this resource (e.g., `dynatrace_management_zone_v2.team_env.id`). It is NOT the name that appears in the Dynatrace UI — that comes from the `name` argument inside the block.

**Alerting Profile (Dynatrace)**
A DT configuration that routes Problems to notification channels (PagerDuty, Slack) with optional delays and severity filters. Alerting profiles reference a management zone to ensure they only fire for Problems affecting entities in that zone. Without the zone reference, a profile would fire for ALL services in the tenant.

**`management_zone` (alerting profile field)**
The Terraform argument that links an alerting profile to a specific management zone. `management_zone = dynatrace_management_zone_v2.team_env["payments-production"].id` means "only fire this alerting profile for Problems where the affected entity is in the payments-production zone."

**Context (DT tag)**
An optional qualifier on a DT tag that indicates where the tag came from. `context = "CONTEXTLESS"` means the tag was set without a specific context (either manually or via auto-tagging). Tags from Kubernetes labels also appear as `CONTEXTLESS` after the auto-tagging rule processes them.

**Entity Selector (DT API)**
A query language for filtering Dynatrace entities by type, tags, management zone membership, and other attributes. Example: `type(SERVICE),mzName("payments-production")` finds all SERVICE entities in the payments-production zone. Used in API calls and SLO metric expressions.

**`terraform plan` output (+ ~ -)**
The three symbols in Terraform plan output: `+` means a new resource will be created, `~` means an existing resource will be updated (some attributes change), `-` means an existing resource will be deleted. For management zones: you want to see `~` for tag value changes and `+` for new zones, never `-` accidentally.

**`settings/objects` (DT API v2)**
The Dynatrace API endpoint that manages all "Settings 2.0" resources — including management zones, metric events, alerting profiles, and SLOs. Terraform's `dynatrace` provider uses this endpoint to create, read, update, and delete these resources. The object ID returned by the API becomes the Terraform resource ID stored in the state file.

**`CONTEXTLESS` (DT tag context)**
The default context for tags that are not associated with a specific external system. K8s namespace labels converted via auto-tagging rules land in CONTEXTLESS context. When writing management zone rules with `TAG_KEY_VALUE_MATCH`, the context is implicit — you match `team:payments` regardless of context.

**`kubectl rollout restart`**
A Kubernetes command that restarts all pods in a deployment by triggering a rolling update with the same image. Used to force pods to restart after a change (like adding labels to a namespace) so that OneAgent re-reads the metadata on pod startup. Safe: follows rolling update strategy, no downtime.

**`jq`**
A command-line JSON processor used to parse and filter responses from the Dynatrace API. Example: `| jq '.entities[] | {entityId, displayName}'` extracts the ID and name from each entity in an API response. Essential for verifying management zone membership from the terminal.

**`type(SERVICE)` (DT entity selector)**
An entity selector filter that restricts results to SERVICE-type entities only (HTTP services, message queues, databases). Combining it with `mzName(...)` gives you all services in a specific management zone. Other type values: `HOST`, `PROCESS_GROUP`, `KUBERNETES_CLUSTER`.

**Silent Failure (monitoring context)**
When a monitoring misconfiguration causes a real problem to go undetected — no alert fires, no SLO violation recorded, no dashboard shows anything wrong. In the management zone context: if a service has no tags, it's in no zone, no alerting profile matches it, and production failures never page anyone.
