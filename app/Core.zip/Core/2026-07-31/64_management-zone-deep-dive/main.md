# 64 — Dynatrace Management Zone Rule (Terraform): Deep Dive

> **What this covers:** The exact Terraform block `dynatrace_management_zone_v2` — every field,
> every concept, how the tag matching works, where the tags come from, what breaks when it's
> misconfigured, and how it connects to alerting, SLOs, and dashboards.

---

## Decision Tree — Where Does This Fit in the Overall System?

```
Kubernetes namespace has labels:
  team: payments
  environment: production
          │
          ▼
OneAgent reads namespace labels on pod startup
          │
          ▼
OneAgent sends tags to DT tenant:
  tag "team:payments"
  tag "environment:production"
          │
          ▼
DT entity (SERVICE "payment-service") is tagged
          │
          ▼
Management zone rule evaluates every entity:
  Does this entity have tag "team:payments"?    → YES
  Does this entity have tag "environment:production"? → YES
  Both conditions met → entity INCLUDED in this zone
          │
          ▼
Management zone "payments-production" now contains "payment-service"
          │
          ├── Alerting profiles filter by this zone → right team gets paged
          ├── SLOs scoped to this zone → correct team's SLO
          └── Dashboards filtered to this zone → team sees only their services
```

---

## Part 1 — What a Management Zone IS (Before Looking at the Code)

### The Analogy

Imagine Dynatrace as a hospital with hundreds of patients (entities: services, hosts, databases).
Every doctor (team) should only see their own patients — not everyone else's.

A **Management Zone** is the patient list for one doctor-team combination.
"All services belonging to the payments team in production" = one zone.
"All services belonging to the orders team in staging" = another zone.

Without management zones:
- The payments team opens DT and sees 50 services (all teams, all environments)
- They can't find their service quickly
- Alerts fire with no team context — who should respond?
- SLO dashboards show all services mixed together

With management zones:
- The payments team logs in and selects "payments-production" zone
- They see only their own services
- Alerts are automatically scoped to their zone → their PagerDuty
- Their SLOs show only their services' data

### One Zone = One Combination of Team + Environment

This system creates a zone per team per environment:

```
payments-dev        → services tagged team:payments   AND environment:dev
payments-staging    → services tagged team:payments   AND environment:staging
payments-production → services tagged team:payments   AND environment:production
orders-dev          → services tagged team:orders     AND environment:dev
orders-staging      → services tagged team:orders     AND environment:staging
orders-production   → services tagged team:orders     AND environment:production
notifications-dev   → services tagged team:notifications AND environment:dev
...
```

9 zones total (3 teams × 3 environments). Each isolates exactly the right services
for that team in that environment.

---

## Part 2 — The Full Terraform Block: Every Line Explained

```hcl
resource "dynatrace_management_zone_v2" "team" {
  # ──────────────────────────────────────────────────────────────────
  # WHAT IS THIS RESOURCE?
  #
  # dynatrace_management_zone_v2 = the Terraform resource type
  #   → Calls Dynatrace API: POST /api/v2/settings/objects
  #     with schemaId: "builtin:management-zones"
  #
  # "team" = the Terraform resource label (local name within this file)
  #   → Referenced as: dynatrace_management_zone_v2.team
  #   → NOT the name shown in Dynatrace UI (that comes from name = below)
  # ──────────────────────────────────────────────────────────────────

  name = "payments-production"
  # ──────────────────────────────────────────────────────────────────
  # This is what appears in the Dynatrace UI dropdown
  # Convention: <team>-<environment> (e.g., payments-production)
  # Used in alerting profiles to scope: which zone do alerts target?
  # ──────────────────────────────────────────────────────────────────

  rules {
    # ──────────────────────────────────────────────────────────────────
    # A "rules" block = one matching rule.
    # Multiple rules blocks = OR logic (entity matches rule A OR rule B).
    # We only have one rule here → entity must match THIS one rule.
    # ──────────────────────────────────────────────────────────────────

    rule {
      type    = "ME"
      enabled = true
      # ──────────────────────────────────────────────────────────────────
      # type = "ME" means Monitored Entity.
      # This tells DT: evaluate this rule against service/host/process entities.
      # Alternative type: "DIMENSION" (for metrics and log dimensions).
      # For our use case (scoping services to a team), always use "ME".
      # ──────────────────────────────────────────────────────────────────

      attribute_conditions {
        attribute  = "SERVICE_TAGS"
        operator   = "TAG_KEY_VALUE_MATCH"
        tag_value  = "team:payments"
        # ──────────────────────────────────────────────────────────────────
        # attribute = "SERVICE_TAGS"
        #   → Look at the "tags" attribute of SERVICE entities.
        #   → Not HOST_TAGS, not PROCESS_GROUP_TAGS.
        #   → Specifically service-level tags.
        #
        # operator = "TAG_KEY_VALUE_MATCH"
        #   → The tag must match BOTH the key AND the value.
        #   → "team:payments" means key=team, value=payments.
        #   → If a service has tag "team:orders", it does NOT match.
        #   → If a service has tag "team" (no value), it does NOT match.
        #   → Only exact key:value pair matches.
        #
        # tag_value = "team:payments"
        #   → The full tag string in "key:value" format.
        #   → The colon (:) separates key from value.
        # ──────────────────────────────────────────────────────────────────
      }

      attribute_conditions {
        attribute  = "SERVICE_TAGS"
        operator   = "TAG_KEY_VALUE_MATCH"
        tag_value  = "environment:production"
        # ──────────────────────────────────────────────────────────────────
        # SECOND condition on the SAME rule.
        # Two attribute_conditions blocks within one rule = AND logic.
        #
        # This entity must ALSO have tag "environment:production".
        # A payment-service in DEV has tag "environment:dev" → does NOT match.
        # A payment-service in PRODUCTION has "environment:production" → MATCHES.
        # ──────────────────────────────────────────────────────────────────
      }
    }
  }
}
```

---

## Part 3 — AND vs OR Logic: How Multiple Conditions Work

This is the most commonly misunderstood part of management zone rules.

### Two `attribute_conditions` Inside ONE `rule {}` = AND

```hcl
rule {
  attribute_conditions { tag_value = "team:payments" }       # condition A
  attribute_conditions { tag_value = "environment:production" }  # condition B
}
```

**Logic:** Entity must have `team:payments` **AND** `environment:production`

```
payment-service (tags: team:payments, environment:production)  → INCLUDED ✓
payment-service (tags: team:payments, environment:dev)          → EXCLUDED ✗
order-service   (tags: team:orders,   environment:production)   → EXCLUDED ✗
```

### Two Separate `rule {}` Blocks = OR

```hcl
rules { rule { attribute_conditions { tag_value = "team:payments" } } }
rules { rule { attribute_conditions { tag_value = "team:orders"   } } }
```

**Logic:** Entity must have `team:payments` **OR** `team:orders`

```
payment-service (tags: team:payments) → INCLUDED ✓ (matches rule 1)
order-service   (tags: team:orders)   → INCLUDED ✓ (matches rule 2)
notification-service (tags: team:notifications) → EXCLUDED ✗ (matches neither)
```

### In Practice: Each Team Gets Its Own Zone (AND logic)

The correct pattern for team isolation is AND:
"Include entities that belong to THIS team AND are in THIS environment."

Using OR would be wrong:
"Include entities tagged team:payments OR environment:production" would include
ALL services in production (even other teams') because they have the `environment:production` tag.

---

## Part 4 — Where Do the Tags Come From? The Full Chain

The tags on DT entities do not appear by magic. There is a precise chain:

### Step 1: Kubernetes Namespace Labels (Set in gitops/)

```yaml
# gitops/dev/namespaces/namespaces.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: payment
  labels:
    team: payments           # ← KEY label
    environment: production  # ← KEY label
```

These labels are set when ArgoCD applies the namespace during wave -1 bootstrap.

### Step 2: OneAgent Reads Namespace Labels

When a payment-service pod starts in the `payment` namespace:
1. OneAgent (already running on the node via DaemonSet) instruments the JVM
2. OneAgent queries the Kubernetes API:
   `GET /api/v1/namespaces/payment`
   Response includes: `labels: {team: payments, environment: production}`
3. OneAgent includes these in the metadata sent to the DT tenant

### Step 3: DT Auto-Tagging Rule Converts Labels to Tags

In the DT tenant, an auto-tagging rule (also Terraform-managed) converts
Kubernetes metadata into DT tags:

```hcl
# terraform/modules/dynatrace/tagging.tf
resource "dynatrace_autotag_v2" "k8s_labels" {
  name = "K8s Namespace Labels"

  rules {
    type    = "ME"
    enabled = true

    value_format = "{Label:team}"      # reads K8s label "team" from namespace
    attribute_conditions {
      attribute = "KUBERNETES_NAMESPACE_LABELS"
      key       = "team"
      operator  = "EXISTS"
    }
  }
}
```

Result: DT creates tag `team:payments` on the payment-service entity.
Same rule for `environment:production`.

### Step 4: Management Zone Rule Matches the Tag

Now that the payment-service entity has tags `team:payments` and
`environment:production`, the management zone rule matches:

```
Evaluate management zone rule for payment-service entity:
  condition 1: SERVICE_TAGS contains "team:payments"       → FOUND ✓
  condition 2: SERVICE_TAGS contains "environment:production" → FOUND ✓
  Both conditions met → entity is IN the "payments-production" zone
```

### Step 5: Entity Appears in the Zone

From this moment:
- DT UI → Management Zones → payments-production → lists payment-service
- Alerting profiles scoped to "payments-production" → fire when payment-service has issues
- SLOs with `filter: mzName("payments-production")` → measure only payment-service

---

## Part 5 — The Full Terraform Module: Creating All Zones Dynamically

In the actual codebase, we don't write one Terraform block per zone.
We use `for_each` to generate all zones from a variable:

```hcl
# terraform/modules/dynatrace/management_zones.tf

locals {
  # All combinations of team × environment
  zone_definitions = {
    "payments-dev"           = { team = "payments",      environment = "dev"        }
    "payments-staging"       = { team = "payments",      environment = "staging"    }
    "payments-production"    = { team = "payments",      environment = "production" }
    "orders-dev"             = { team = "orders",        environment = "dev"        }
    "orders-staging"         = { team = "orders",        environment = "staging"    }
    "orders-production"      = { team = "orders",        environment = "production" }
    "notifications-dev"      = { team = "notifications", environment = "dev"        }
    "notifications-staging"  = { team = "notifications", environment = "staging"    }
    "notifications-production" = { team = "notifications", environment = "production" }
  }
}

resource "dynatrace_management_zone_v2" "team_env" {
  for_each = local.zone_definitions

  name = each.key   # e.g., "payments-production"

  rules {
    rule {
      type    = "ME"
      enabled = true

      attribute_conditions {
        attribute  = "SERVICE_TAGS"
        operator   = "TAG_KEY_VALUE_MATCH"
        tag_value  = "team:${each.value.team}"          # e.g., "team:payments"
      }

      attribute_conditions {
        attribute  = "SERVICE_TAGS"
        operator   = "TAG_KEY_VALUE_MATCH"
        tag_value  = "environment:${each.value.environment}"  # e.g., "environment:production"
      }
    }
  }
}
```

**What `for_each` produces:**
Terraform creates 9 separate `dynatrace_management_zone_v2` resources,
one for each key in `zone_definitions`. Each resource gets the interpolated
team and environment values. Adding a new team requires only adding an entry
to `zone_definitions` — no new Terraform blocks needed.

---

## Part 6 — What the Rule Matches and What It Doesn't

### Entity Types That `SERVICE_TAGS` Applies To

The attribute `SERVICE_TAGS` only evaluates **service entities** (HTTP services, databases,
message queues). It does NOT evaluate:
- Host entities → use `HOST_TAGS`
- Process group entities → use `PROCESS_GROUP_TAGS`
- Kubernetes cluster/namespace entities → use `KUBERNETES_*` attributes

In this system, because we tag at the **service** level (from namespace labels
propagated to services), `SERVICE_TAGS` is correct.

### What an Entity Needs to Match

```
To be included in "payments-production" zone, an entity must be a SERVICE entity
(not a host or process) AND have BOTH tags:

Matches:
  payment-service  (SERVICE, tags: team:payments, environment:production)       ✓
  payment-service-v2 (SERVICE, tags: team:payments, environment:production)     ✓
  payment-db-pool (PROCESS_GROUP → service created from it, inherits tags)      ✓

Does NOT match:
  payment-service (SERVICE, tags: team:payments, environment:dev)               ✗  (wrong env)
  order-service   (SERVICE, tags: team:orders,   environment:production)        ✗  (wrong team)
  payment-node-01 (HOST, tags: team:payments, environment:production)           ✗  (HOST, not SERVICE)
```

### What If a Tag Is Missing?

```
Scenario: developer forgets to add team label to a new namespace
  New namespace "invoice" has NO labels
  invoice-service entity has NO tags in DT

  Management zone evaluation:
    condition 1: SERVICE_TAGS contains "team:payments" → NOT FOUND ✗
    → Entity NOT included in any zone

  Result:
    - invoice-service is not in any management zone
    - No alerting profile matches it (all profiles filter by zone)
    - No SLO measures it
    - It is "dark" to all monitoring
    
  This is a silent failure. The service appears to run fine
  but if it breaks, no alert fires. SREs must audit for unzoned entities.
```

---

## Part 7 — How Management Zones Connect to Alerting Profiles

The management zone name is referenced in alerting profiles:

```hcl
# terraform/modules/dynatrace/alerting.tf
resource "dynatrace_alerting" "payments_production_high" {
  name = "payments-production-high"

  rules {
    rule {
      delay_in_minutes = 2
      severity_level   = "ERROR"
      include_mode     = "INCLUDE_ALL"

      tag_filter {
        include_mode = "INCLUDE_ALL"
      }
    }
  }

  # THE KEY LINK: this profile only processes Problems from this zone
  management_zone = dynatrace_management_zone_v2.team_env["payments-production"].id
}
```

**What this means end-to-end:**
1. payment-service error rate spikes
2. DT creates a Problem for payment-service
3. DT evaluates all alerting profiles to find which ones fire
4. `payments-production-high` profile has `management_zone = "payments-production"`
5. Is payment-service IN the payments-production zone? YES (tags match)
6. Does the Problem severity match? YES (ERROR)
7. Profile fires → PagerDuty notification → payments team on-call is paged

If the management zone rule were broken (wrong tag name, wrong operator):
- payment-service would NOT be in the zone
- The alerting profile would NOT fire for payment-service
- The payments team is NEVER paged
- Silent failures in production

---

## Part 8 — How Management Zones Connect to SLOs

```hcl
# terraform/modules/dynatrace/slos.tf
resource "dynatrace_slo_v2" "availability" {
  for_each = var.services

  name        = "[${var.environment}] ${each.key} availability"
  enabled     = true
  target      = var.availability_target
  timeframe   = "-30d"

  metric_expression = "100*(builtin:service.requestCount.server:splitBy():sum)..."

  # Scope this SLO to only the entities in this management zone
  filter = "type(\"SERVICE\"),mzName(\"${each.value.team}-${var.environment}\")"
}
```

`mzName("payments-production")` in the filter means:
"Only measure availability for services that are members of the payments-production zone."

If payment-service is removed from the zone (tag deleted), the SLO stops measuring it.
The SLO shows 100% compliance — but only because it has no data, not because the service is healthy.
This is another silent failure mode.

---

## Part 9 — `attribute` Values Reference

Different entity types use different `attribute` values in `attribute_conditions`:

```
For SERVICE entities:
  SERVICE_TAGS              → tags on the service entity
  SERVICE_NAME              → the service name (e.g., "payment-service")
  SERVICE_TYPE              → Web Service, Database Service, etc.
  SERVICE_TECHNOLOGY        → Java, .NET, Node.js, etc.

For HOST entities:
  HOST_TAGS                 → tags on the host entity
  HOST_NAME                 → hostname
  HOST_OS_TYPE              → Linux, Windows
  AWS_REGION                → e.g., "ap-northeast-1"

For PROCESS_GROUP entities:
  PROCESS_GROUP_TAGS        → tags on the process group
  PROCESS_GROUP_TECHNOLOGY  → Java, .NET, etc.

For Kubernetes entities:
  KUBERNETES_CLUSTER_NAME   → EKS cluster name
  KUBERNETES_NAMESPACE_LABELS → K8s namespace label key/value
  KUBERNETES_NODE_NAME      → EC2 node name
```

### Common Mistake: Using Wrong Attribute Type

```hcl
# WRONG: HOST_TAGS on a service rule — this will never match
attribute_conditions {
  attribute = "HOST_TAGS"      # ← this checks HOST entities, not SERVICE entities
  tag_value = "team:payments"
}

# The service entity might be running on a host tagged team:payments
# but SERVICE_TAGS and HOST_TAGS are evaluated on DIFFERENT entity types.
# A rule checking HOST_TAGS would match the HOST entity, not the service entity.
```

---

## Part 10 — `operator` Values Reference

The `operator` field determines HOW the tag is matched:

```
TAG_KEY_VALUE_MATCH  → both key AND value must match exactly
  "team:payments" matches a service with tag key="team", value="payments"
  Does NOT match: "team:orders", "team" (no value), "payments" (no key)

TAG_KEY_MATCH        → only the tag KEY must exist (any value is acceptable)
  operator = "TAG_KEY_MATCH"
  attribute = "SERVICE_TAGS"
  tag_value = "team"          ← key only, no colon, no value
  Matches any service that has ANY "team" tag (team:payments, team:orders, etc.)
  Use case: "include all services that have a team assignment" regardless of which team

EQUALS               → exact string match on non-tag attributes
  Used for: SERVICE_NAME, HOST_NAME, etc.
  attribute = "SERVICE_NAME"
  operator  = "EQUALS"
  value     = "payment-service"

CONTAINS             → substring match
  attribute = "SERVICE_NAME"
  operator  = "CONTAINS"
  value     = "payment"
  Matches: payment-service, payment-api, payment-gateway

EXISTS               → attribute is present (any value)
  attribute = "SERVICE_TAGS"
  operator  = "EXISTS"
  Matches any service that has at least one tag
```

---

## Part 11 — Validation: How to Verify the Zone Is Working

### Check 1: What Entities Are in the Zone?

```bash
# Query DT API for entities in the management zone
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/entities\
?entitySelector=type(SERVICE),mzName(\"payments-production\")" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.entities[] | {entityId, displayName}'
```

Expected output:
```json
[
  {"entityId": "SERVICE-abc123", "displayName": "payment-service"},
  {"entityId": "SERVICE-def456", "displayName": "payment-service-v2"}
]
```

If this returns empty: the management zone rule is not matching anything.
Possible causes: tags missing from the service entity, wrong attribute name,
wrong operator, auto-tagging rule not applied yet.

### Check 2: What Tags Does the Service Entity Have?

```bash
# Check what tags DT has assigned to the payment-service entity
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/entities/SERVICE-abc123" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.tags'
```

Expected output:
```json
[
  {"context": "CONTEXTLESS", "key": "team", "value": "payments"},
  {"context": "CONTEXTLESS", "key": "environment", "value": "production"},
  {"context": "CONTEXTLESS", "key": "app.kubernetes.io/name", "value": "payment-service"}
]
```

If `team:payments` or `environment:production` tags are missing:
→ Check the K8s namespace labels
→ Check the DT auto-tagging rule
→ Check that OneAgent is running on the node

### Check 3: Verify in DT UI

```
DT UI → Management Zones → payments-production
  → Should list: payment-service, payment-service-v2
  → Click each entity: should show tags team:payments, environment:production

If entity is absent:
  DT UI → Technologies → Services → payment-service
  → Check "Tags" section
  → If tags missing: check K8s namespace labels via kubectl
```

### Check 4: Verify Tags on the Kubernetes Side

```bash
# Check the namespace labels that feed the tags
kubectl get namespace payment -o jsonpath='{.metadata.labels}'
# Expected: {"environment":"production","team":"payments"}

# Check OneAgent is running on the node where the service pod is
kubectl get pods -n dynatrace -l app.kubernetes.io/name=oneagent -o wide
```

---

## Part 12 — Common Mistakes and Their Exact Symptoms

### Mistake 1: Tag Typo (Extra Space, Wrong Case)

```hcl
# WRONG
tag_value = "team: payments"   # space after colon — DT stores "team:payments" (no space)
tag_value = "Team:Payments"    # wrong case — DT tags are case-sensitive
tag_value = "team:payment"     # missing 's' — "payments" not "payment"
```

**Symptom:** Zone is empty. No entities match. No alerts fire.

### Mistake 2: Missing `operator` (Uses Wrong Default)

```hcl
# WRONG: no operator specified — may default to EXISTS (matches any tag on the entity)
attribute_conditions {
  attribute = "SERVICE_TAGS"
  # no operator line
  tag_value = "team:payments"
}

# CORRECT: always specify TAG_KEY_VALUE_MATCH for exact key:value matching
attribute_conditions {
  attribute  = "SERVICE_TAGS"
  operator   = "TAG_KEY_VALUE_MATCH"
  tag_value  = "team:payments"
}
```

**Symptom:** Zone includes unexpected entities (too broad), or matches nothing (wrong default).

### Mistake 3: Wrong `attribute` for the Entity Type

```hcl
# WRONG: checking HOST_TAGS on what should be a service zone
attribute_conditions {
  attribute = "HOST_TAGS"        # ← evaluates HOST entities, not SERVICE entities
  tag_value = "team:payments"
}
```

**Symptom:** Zone matches hosts (if you have hosts tagged team:payments) instead of services.
Service-based alerting profiles won't fire because the SERVICE entity is not in the zone —
only the HOST entity is.

### Mistake 4: Using One Rule with OR Intent

```hcl
# WRONG: trying to include both payments and orders teams
# This actually means: tag is team:payments AND team:orders → impossible to match both
rule {
  attribute_conditions { tag_value = "team:payments" }     # AND
  attribute_conditions { tag_value = "team:orders"   }     # AND (same rule = AND)
}
```

**Symptom:** Zone is empty (no entity can have BOTH tags simultaneously).

```hcl
# CORRECT for OR: separate rules blocks
rules { rule { attribute_conditions { tag_value = "team:payments" } } }
rules { rule { attribute_conditions { tag_value = "team:orders"   } } }
```

### Mistake 5: Namespace Labels Not Applied Before Service Starts

If the service pod starts before the namespace has labels (e.g., someone deploys
the service manually before ArgoCD runs wave -1):
- OneAgent instruments the JVM but reads no labels from the namespace
- DT entity is created with NO auto-tags
- Management zone never matches the entity
- Fix: delete and recreate the pod so OneAgent re-reads the labels:
  `kubectl rollout restart deployment/payment-service -n payment`

---

## Part 13 — The Complete Terraform terraform plan Output for This Resource

When you add a new zone or change a tag value, `terraform plan` shows:

```
# New zone being created:
+ resource "dynatrace_management_zone_v2" "team_env" {
    + name = "payments-production"
    + rules {
        + rule {
            + type    = "ME"
            + enabled = true
            + attribute_conditions {
                + attribute  = "SERVICE_TAGS"
                + operator   = "TAG_KEY_VALUE_MATCH"
                + tag_value  = "team:payments"
              }
            + attribute_conditions {
                + attribute  = "SERVICE_TAGS"
                + operator   = "TAG_KEY_VALUE_MATCH"
                + tag_value  = "environment:production"
              }
          }
      }
  }

Plan: 1 to add, 0 to change, 0 to destroy.
```

When a tag value is changed (e.g., environment name changes):
```
~ resource "dynatrace_management_zone_v2" "team_env" {
    ~ rules {
        ~ rule {
            ~ attribute_conditions {
                ~ tag_value = "environment:staging" → "environment:production"
              }
          }
      }
  }

Plan: 0 to add, 1 to change, 0 to destroy.
```

Terraform calls the DT API to update the management zone setting in-place.
Existing entities that were in the old zone are immediately re-evaluated
against the new rule. DT takes 1–2 minutes to re-evaluate all entity memberships.
