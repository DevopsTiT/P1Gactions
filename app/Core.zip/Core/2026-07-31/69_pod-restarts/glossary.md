# Pod Restarts Glossary — SRE Beginner Reference

Every term from main.md explained in plain language.

---

**Pod Restart**
When Kubernetes stops a container and starts a new one inside the same Pod. Visible in `kubectl get pods` as an increasing number in the RESTARTS column. Always has a cause — never ignore restarts.

**RESTARTS column**
The field in `kubectl get pods` output showing how many times the containers in a pod have been restarted. A value of 0 is normal. Any number > 0 means something killed the container at least once.

**OOMKilled**
"Out Of Memory Killed." The Linux kernel forcibly terminated the container process because it used more memory than the configured limit. Exit code is always 137. No warning, no graceful shutdown — instant death.

**Exit Code 137**
The exit code that indicates the process was killed by the OS via SIGKILL signal. The math: 128 (base for signal exits) + 9 (SIGKILL signal number) = 137. Always means the process was force-killed, usually by the OOM killer.

**OOM Killer**
The Linux kernel subsystem that monitors memory usage in control groups (cgroups). When a container exceeds its memory limit, the OOM killer fires and sends SIGKILL to the process. There is no warning signal — it's immediate.

**CrashLoopBackOff**
A Kubernetes pod state meaning: the application is repeatedly crashing on startup, and Kubernetes is applying an exponential backoff delay between restart attempts. "BackOff" = the increasing wait time (10s, 20s, 40s, 80s...). Not a crash type itself — a description of the restart pattern.

**Exponential Backoff**
A strategy where each retry waits twice as long as the previous one. In CrashLoopBackOff: 10s → 20s → 40s → 80s → 160s → max 5 minutes. Prevents a crashing pod from using 100% of CPU just restarting constantly.

**Liveness Probe**
A periodic health check Kubernetes runs against a running container to ask "is this application still alive and functional?" If it fails N consecutive times, Kubernetes kills and restarts the pod. Unlike CrashLoopBackOff, the app process is RUNNING but not responding.

**Readiness Probe**
A periodic health check that asks "is this application ready to serve traffic?" If it fails, the pod is removed from the Service's endpoint list (no traffic sent to it), but the pod is NOT restarted. Used for temporary unreadiness.

**Startup Probe**
A one-time health check that runs when a container first starts. Until it passes, liveness and readiness probes are disabled. Once it passes once, it's never run again. Prevents liveness probes from killing a slow-starting application.

**`failureThreshold`**
How many consecutive probe failures are allowed before Kubernetes acts. `failureThreshold: 3` with `periodSeconds: 10` means the application has 30 seconds of consecutive failures before being restarted.

**`initialDelaySeconds`**
How many seconds to wait after a container starts before running the first liveness/readiness probe. Set this long enough for your application to fully start. Too short = probes kill the app before it's ready.

**`timeoutSeconds`**
How many seconds a probe is allowed to take before it's considered a failure. If your health endpoint takes longer than this to respond, the probe fails even though the app is running. Tune this for GC-heavy JVM apps.

**Deadlock**
A situation where two or more threads are each waiting for a resource held by the other, so none can ever proceed. Thread A holds lock X and wants lock Y; Thread B holds lock Y and wants lock X. Both wait forever. Causes liveness probe failures because the health endpoint's thread can't run.

**Thread Dump**
A snapshot of all threads in a JVM process, showing what each thread is doing, what locks it holds, and what it's waiting for. `jstack <pid>` produces one. Used to diagnose deadlocks (look for "BLOCKED" threads and "Found 1 deadlock" at the bottom).

**Thread Pool Exhaustion**
When all threads in a thread pool are busy and no new requests can be handled. The health check endpoint's request queues up waiting for a thread — eventually times out — liveness probe fails — pod restarts. Doesn't fix the underlying overload.

**GC Pause**
A period when the Java garbage collector stops all application threads ("stop the world") to perform memory cleanup. During a long GC pause (e.g., full GC taking 5+ seconds), the health endpoint cannot respond — can trigger liveness probe failures.

**`jstack`**
A JVM command-line tool that prints a thread dump to stdout. `jstack 1` (PID 1 is the main process in a container) dumps all thread states. Used inside a pod to diagnose deadlocks and thread pool exhaustion.

**`jmap`**
A JVM tool that generates a heap dump (snapshot of all objects in memory). `jmap -dump:format=b,file=/tmp/heap.hprof 1` creates a binary heap dump you can analyze with Eclipse MAT or IntelliJ. Used to find memory leaks.

**`jcmd`**
A JVM diagnostic tool that sends commands to a running JVM. More powerful than jstack/jmap. `jcmd 1 Thread.print` = thread dump. `jcmd 1 GC.run` = force garbage collection. `jcmd 1 VM.native_memory` = full memory breakdown.

**`jstat`**
A JVM tool for monitoring JVM statistics in real time. `jstat -gcutil 1 5000 10` = print GC stats every 5 seconds, 10 times. Shows heap utilization, GC counts, and cumulative GC time. Used to detect GC pressure causing liveness failures.

**Heap Dump**
A file containing a complete snapshot of all objects in JVM heap memory at a moment in time. Analyzed with tools like Eclipse MAT to find which objects are consuming memory and whether objects are leaking (growing unboundedly).

**Eclipse MAT (Memory Analyzer Tool)**
A free Java heap dump analysis tool. Opens a `.hprof` file and shows: which objects consume the most memory, object retention chains (why objects can't be GC'd), and potential memory leak suspects.

**Memory Leak**
A programming bug where objects accumulate in memory over time because they are kept referenced (not garbage collectible) even though they're no longer needed. Manifests as: memory growing steadily over hours/days, eventually causing OOMKilled.

**VPA (Vertical Pod Autoscaler)**
A Kubernetes component that analyzes historical resource usage of pods and recommends (or automatically applies) better CPU/memory requests and limits. Helps prevent OOMKilled by recommending the right memory limit based on actual usage data.

**`updateMode: "Off"` (VPA)**
VPA configuration that puts it in recommendation-only mode. It observes and recommends but never changes anything. Safe to run in production — you review the recommendations and apply manually. `"Auto"` = automatic restart with new limits.

**`kubectl top pod`**
Command that shows current CPU and memory usage of pods. Requires metrics-server to be installed. Output: `NAME | CPU(cores) | MEMORY(bytes)`. Used to see how close a pod is to its memory limit.

**metrics-server**
A Kubernetes add-on that collects resource usage metrics (CPU, memory) from kubelets and exposes them via the Kubernetes metrics API. Required for `kubectl top` and for HPA/VPA to work.

**`-XX:+UseContainerSupport`**
A JVM flag that tells the JVM to read its memory limits from the Linux cgroup (container limit) rather than the host machine's total RAM. Without this, a JVM in a 1GB container on a 64GB host thinks it has 64GB and sizes its heap accordingly — causing OOMKilled.

**`-XX:MaxRAMPercentage`**
A JVM flag that sets the maximum heap size as a percentage of the available RAM (as seen by the JVM after UseContainerSupport). `-XX:MaxRAMPercentage=75.0` = use 75% of the container limit for heap, leaving 25% for off-heap memory.

**`-XX:+ExitOnOutOfMemoryError`**
A JVM flag that causes the JVM to exit immediately when an OutOfMemoryError occurs instead of continuing in a degraded state. Allows Kubernetes to restart the pod cleanly rather than letting it limp along with OOM errors.

**`-XX:+HeapDumpOnOutOfMemoryError`**
A JVM flag that automatically writes a heap dump file when an OOM occurs. Combined with `-XX:HeapDumpPath=/tmp/heap.hprof`, captures a memory snapshot exactly when the OOM happened — invaluable for diagnosing memory leaks.

**`kubectl logs --previous`**
Flag that shows logs from the PREVIOUS container instance (the one that just crashed/restarted), not the currently running one. Critical for diagnosing CrashLoopBackOff — without it you often get empty logs from the freshly started container.

**Init Container**
A special container that runs and completes BEFORE the main application containers start. Used to: wait for dependencies (database, message queue), run database migrations, download configuration. If an initContainer fails, the pod stays in Init state.

**`kubectl describe pod`**
The most important diagnosis command for pod problems. Shows: current state, last state (with exit code), events (what happened and when), volume mounts, resource limits, probe configuration. Always run this first when debugging a pod.

**Pod Events**
Timestamped records of significant things that happened to a pod: when it was scheduled, when images were pulled, when containers started, when probes failed, when containers were killed. Visible in `kubectl describe pod` output under "Events:".

**`kubectl get events`**
Lists Kubernetes events for a namespace. More queryable than `kubectl describe pod` — can filter by reason, involved object, sort by time. `--field-selector reason=OOMKilling` shows only OOM events.

**ConfigMap**
A Kubernetes object that stores non-sensitive configuration data as key-value pairs. Referenced in pods as environment variables or mounted as files. Unlike Secrets, not base64-encoded (plaintext). Example: log level, feature flags, API URLs.

**Secret (Kubernetes)**
A Kubernetes object that stores sensitive data (passwords, API keys, TLS certificates) as base64-encoded key-value pairs. Referenced in pods as environment variables or mounted as files. Base64 is encoding, not encryption — use encryption at rest for real security.

**`secretKeyRef`**
A way to populate an environment variable from a specific key in a Kubernetes Secret. `secretKeyRef: {name: myapp-secret, key: DB_PASSWORD}` sets the env var to the value of `DB_PASSWORD` in the `myapp-secret` Secret.

**`configMapKeyRef`**
Like `secretKeyRef` but for ConfigMaps. Populates an env var from a ConfigMap key.

**`envFrom`**
A shortcut in pod spec that imports ALL keys from a Secret or ConfigMap as environment variables. `envFrom: [{secretRef: {name: myapp-secret}}]` — every key in the secret becomes an environment variable.

**`optional: false`**
Default behavior for secretKeyRef/configMapKeyRef — if the referenced secret/configmap or key doesn't exist, the pod fails to start with an error. Setting `optional: true` allows the pod to start even without the referenced resource.

**Namespace (Kubernetes)**
A logical isolation boundary within a Kubernetes cluster. Secrets, ConfigMaps, and Services are scoped to a namespace — a pod in `production` namespace CANNOT reference a Secret in `staging` namespace.

**`kubectl scale --replicas=0`**
Immediately stops all pods of a deployment by scaling it to zero replicas. Used as an emergency stop when pods are stuck in a crash loop and causing cascading issues. Causes service downtime — use only in emergencies.

**`kubectl patch`**
A command that applies a partial update to a Kubernetes resource without replacing it entirely. Used to quickly change specific fields (resource limits, command, environment variables) without editing the full YAML.

**`kubectl debug`**
A command that creates a debug container in an existing pod's process namespace. Allows you to run debugging tools (strace, lsof, netstat) even when the main container's image doesn't have them installed.

**`sleep infinity`**
A shell command that does nothing forever. Used as an override command in debug scenarios — patches the deployment to run `sleep infinity` instead of the application, keeping the pod alive so you can exec into it.

**SIGKILL (signal 9)**
A Unix signal that immediately and unconditionally terminates a process. Cannot be caught, blocked, or ignored by the application. The kernel's "force quit" for processes. Used by the OOM killer and `kill -9`.

**SIGTERM (signal 15)**
A Unix signal that requests a process to gracefully terminate. Applications can catch this and perform cleanup (close connections, flush buffers) before exiting. `kubectl delete pod` sends SIGTERM first, then SIGKILL after `terminationGracePeriodSeconds`.

**`terminationGracePeriodSeconds`**
How long Kubernetes waits between sending SIGTERM and sending SIGKILL when stopping a pod. Default: 30 seconds. During this window, the app should shut down gracefully. Increase if your app needs more time for cleanup.

**cgroup (Control Group)**
A Linux kernel feature that limits resource usage (CPU, memory) for groups of processes. Kubernetes uses cgroups to enforce container resource limits. `container_memory_working_set_bytes` in Prometheus reads directly from cgroup stats.

**`container_memory_working_set_bytes`**
A Prometheus metric (exposed by cAdvisor/kubelet) that shows how much memory a container is actually using. This is the value compared against the memory limit to trigger OOMKill. Different from "resident set size" — more accurate for container limits.

**`jstack`**
Command to get a Java thread dump. Run as: `jstack <pid>` where PID 1 is typical for the main process in a container. Output shows every thread, its current state, and its full stack trace. Deadlocks appear at the bottom as "Found N deadlock(s)."

**Resident Set Size (RSS)**
The amount of physical RAM a process is currently using. Includes both heap and off-heap memory. Visible in `/proc/<pid>/status` as `VmRSS`. For containers, the cgroup memory stat is more accurate.

**Working Set Memory**
The memory that cannot be reclaimed under memory pressure — the "real" memory usage of a container. This is what Kubernetes compares against the memory limit. Excludes file system cache that can be evicted.
