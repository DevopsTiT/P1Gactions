# Pod Restarts — Deep Dive Diagnosis and Fix

---

## E2E Flow Summary

```
Pod restarts
      │
      ▼
kubectl get pods   →  RESTARTS column > 0
      │
      ▼
kubectl describe pod <name>   →  check Events + Last State
      │
      ├── OOMKilled          → memory limit too low OR memory leak
      ├── CrashLoopBackOff   → app crashing on startup OR runtime
      ├── Liveness failure   → app alive but unresponsive (deadlock, hung thread)
      └── Config error       → missing env var / secret / wrong value
```

**One-line goal:** Every pod restart has a root cause visible in Events, logs, or metrics. Find it in under 5 minutes.

---

## Decision Tree — Which Restart Type Am I Dealing With?

```
kubectl get pods → RESTARTS > 0
      │
      ▼
kubectl describe pod <name>
      │
      ├── Last State: Exit Code 137 or reason "OOMKilled"
      │         → Part 1: OOMKilled
      │
      ├── STATUS = CrashLoopBackOff
      │   and Last State: Exit Code ≠ 0 (non-zero = app crashed)
      │         → Part 2: CrashLoopBackOff
      │
      ├── Events: "Liveness probe failed" or "Readiness probe failed"
      │         → Part 3: Liveness/Readiness Failure
      │
      └── Events: "Error: secret not found" / "env var undefined"
              or Exit Code 1 with "Config" in logs
                    → Part 4: Config Error
```

---

## Part 1 — OOMKilled: Deep Dive

### What OOMKilled Means

The Linux kernel killed the process because it exceeded its memory limit. The exit code is always **137** (128 + 9, where 9 = SIGKILL signal).

```
Container memory limit: 512Mi
App actual usage:       540Mi  ← exceeded limit by 28Mi

Linux kernel OOM killer fires → kills the process immediately
No graceful shutdown, no warning, no stack trace
Pod restarts immediately
```

### Diagnosing OOMKilled Step by Step

```bash
# Step 1: Confirm it IS OOMKilled
kubectl describe pod <pod-name> -n <namespace>

# Look for this in output:
# Last State:
#   Reason:       OOMKilled
#   Exit Code:    137
#   Started:      Thu, 31 Jul 2026 09:00:00 +0000
#   Finished:     Thu, 31 Jul 2026 09:00:42 +0000

# Step 2: Check current resource limits
kubectl get pod <pod-name> -n <namespace> -o json | \
  jq '.spec.containers[] | {name: .name, resources: .resources}'

# Step 3: Check how much memory the app is ACTUALLY using
# (requires metrics-server)
kubectl top pod <pod-name> -n <namespace>
# NAME              CPU(cores)   MEMORY(bytes)
# checkout-abc123   45m          498Mi    ← close to limit = about to OOM again

kubectl top pod -n <namespace> --sort-by=memory

# Step 4: Historical memory usage in Prometheus
# Run this PromQL in Grafana or Prometheus UI:
# container_memory_working_set_bytes{pod="checkout-abc123", container="checkout"}
# Look for: steady climb (leak) or spike (burst)

# Step 5: Check if it's happening repeatedly
kubectl get events -n <namespace> \
  --field-selector reason=OOMKilling \
  --sort-by='.lastTimestamp'

# Step 6: Get memory usage trend over time
kubectl exec -it <pod-name> -n <namespace> -- \
  cat /proc/meminfo | grep -E "MemTotal|MemFree|MemAvailable"

# Step 7: For Java — check heap vs off-heap usage
kubectl exec -it <pod-name> -n <namespace> -- \
  jcmd 1 VM.native_memory summary
# Shows: heap, class, thread, stack, code, GC metadata usage
```

### Two Types of OOMKilled

**Type A: Limit Too Low (Simple Fix)**

```
Evidence:
  - Memory usage was near limit from the start (not growing)
  - App works fine in staging with more memory
  - No heap dump or GC pressure visible

Fix:
  Increase the memory limit
```

```yaml
# deployment.yaml — increase memory limit
resources:
  requests:
    memory: "512Mi"    # what the scheduler reserves on the node
    cpu: "250m"
  limits:
    memory: "1Gi"      # what the container is allowed to use
    cpu: "1000m"
```

```bash
# Apply without redeploying (patch in place)
kubectl set resources deployment checkout \
  -n production \
  --limits=memory=1Gi \
  --requests=memory=512Mi
```

**Type B: Memory Leak (Complex Fix)**

```
Evidence:
  - Memory grows steadily over hours/days
  - App starts fine, OOMs after N hours
  - GC metrics: GC runs but memory doesn't decrease
  - Heap dump shows accumulating objects

Diagnosis for Java:
```

```bash
# Get a heap dump BEFORE the app OOMs (while it's running)
kubectl exec -it <pod-name> -n <namespace> -- \
  jmap -dump:format=b,file=/tmp/heap.hprof 1

# Copy heap dump to local machine
kubectl cp <namespace>/<pod-name>:/tmp/heap.hprof ./heap.hprof

# Analyze with Eclipse MAT or IntelliJ
# Look for: growing collections, unclosed connections, static caches

# Alternative: trigger GC and check if memory drops
kubectl exec -it <pod-name> -n <namespace> -- \
  jcmd 1 GC.run
kubectl top pod <pod-name> -n <namespace>
# If memory doesn't drop after GC → objects are strongly referenced → leak
```

### Java-Specific: JVM Memory Tuning

```bash
# The JVM doesn't just use heap — it also uses:
# - Metaspace (class metadata)
# - Direct ByteBuffers (off-heap)
# - Thread stacks
# - Code cache

# Container limit must cover ALL of these, not just heap

# Current JVM flags on running pod
kubectl exec -it <pod-name> -n <namespace> -- \
  jcmd 1 VM.flags | grep -E "Xmx|MaxRAM|UseContainerSupport"

# Recommended JVM flags for containers
# In your Dockerfile or deployment env:
# -XX:+UseContainerSupport          (read cgroups limits, not host RAM)
# -XX:MaxRAMPercentage=75.0         (use 75% of container limit for heap)
# -XX:+ExitOnOutOfMemoryError       (crash on OOM instead of limping along)
# -XX:+HeapDumpOnOutOfMemoryError   (dump heap when OOM occurs)
# -XX:HeapDumpPath=/tmp/heap.hprof
```

### Preventing OOMKilled: Vertical Pod Autoscaler (VPA)

```bash
# VPA recommends memory/CPU values based on actual usage
kubectl apply -f - <<'EOF'
apiVersion: autoscaling.k8s.io/v1
kind: VerticalPodAutoscaler
metadata:
  name: checkout-vpa
  namespace: production
spec:
  targetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: checkout
  updatePolicy:
    updateMode: "Off"      # "Off" = only recommend, don't auto-apply
                           # "Auto" = automatically update and restart pods
EOF

# Check VPA recommendations (after running for a few hours/days)
kubectl describe vpa checkout-vpa -n production
# Recommendation:
#   Container Recommendations:
#     Container Name: checkout
#       Lower Bound:
#         Memory: 256Mi
#       Target:
#         Memory: 512Mi      ← set your request here
#       Upper Bound:
#         Memory: 1Gi        ← set your limit here
```

---

## Part 2 — CrashLoopBackOff: Deep Dive

### What CrashLoopBackOff Means

```
The application starts, then crashes (exit code ≠ 0).
Kubernetes tries to restart it.
It crashes again.
Kubernetes waits (10s, 20s, 40s, 80s... up to 5 min between restarts).
This exponential backoff is the "BackOff" in CrashLoopBackOff.
```

```
Timeline of a CrashLoopBackOff:
  T+0s:   Pod starts → app crashes (exit code 1) → restart
  T+10s:  Pod starts → app crashes → restart (wait 10s)
  T+30s:  Pod starts → app crashes → restart (wait 20s)
  T+70s:  Pod starts → app crashes → restart (wait 40s)
  T+150s: Pod starts → app crashes → restart (wait 80s)
  T+310s: Pod starts → app crashes → restart (wait 160s)
  ...     Eventually: wait up to 5 minutes between each restart
```

### Diagnosing CrashLoopBackOff Step by Step

```bash
# Step 1: Confirm it's CrashLoopBackOff and get exit code
kubectl describe pod <pod-name> -n <namespace>
# Look for:
# State:          Waiting
#   Reason:       CrashLoopBackOff
# Last State:     Terminated
#   Reason:       Error
#   Exit Code:    1            ← non-zero = app exited with error
#   Started:      Thu, 31 Jul 2026 10:00:00
#   Finished:     Thu, 31 Jul 2026 10:00:03   ← only ran 3 seconds!

# Step 2: Get logs from the CRASHED container (not the current one)
kubectl logs <pod-name> -n <namespace> --previous
# --previous is CRITICAL: shows logs from the container that JUST died
# Without --previous, you may get empty logs (current container barely started)

# Step 3: If multiple containers, specify which one
kubectl logs <pod-name> -n <namespace> -c checkout --previous

# Step 4: Follow logs in real time to see the crash as it happens
kubectl logs <pod-name> -n <namespace> -f
# Watch for: stack traces, "Application failed to start", connection refused

# Step 5: Get events for more context
kubectl get events -n <namespace> \
  --field-selector involvedObject.name=<pod-name> \
  --sort-by='.lastTimestamp'
```

### CrashLoopBackOff Causes and Fixes

**Cause 1: Application startup failure**

```
Symptoms in logs:
  java.net.ConnectException: Connection refused (database not reachable)
  Error: ECONNREFUSED (Node.js cannot connect to Redis)
  "Failed to connect to Kafka broker"

Root cause:
  App tries to connect to a dependency at startup
  Dependency isn't ready yet OR wrong hostname/port

Fix A: Add startup probe (give app more time to connect)
```

```yaml
# deployment.yaml — startup probe
spec:
  containers:
    - name: checkout
      startupProbe:
        httpGet:
          path: /health
          port: 8080
        failureThreshold: 30    # allow 30 × 10s = 5 minutes to start
        periodSeconds: 10
      livenessProbe:
        httpGet:
          path: /health
          port: 8080
        # liveness only kicks in AFTER startup probe passes
```

```yaml
# Fix B: Make application resilient to dependency unavailability at startup
# Add retry logic in application code (retry with exponential backoff)
# OR: use initContainers to wait for dependencies

spec:
  initContainers:
    - name: wait-for-db
      image: busybox:1.36
      command: ['sh', '-c', |
        until nc -z postgres 5432;
          do echo "Waiting for postgres..."; sleep 2;
        done;
        echo "postgres is up"
      ]
  containers:
    - name: checkout
      # ... main container only starts after initContainer succeeds
```

**Cause 2: Out of memory on startup (OOM before metrics available)**

```
Symptoms:
  Exit Code: 137
  App crash within seconds of starting
  "OutOfMemoryError: Java heap space" in logs

Fix: Increase memory limit (same as Part 1)
```

**Cause 3: Port conflict (address already in use)**

```
Symptoms in logs:
  java.net.BindException: Address already in use: 8080
  Error: listen EADDRINUSE :::8080

Root cause:
  Previous container didn't terminate cleanly
  OR two containers in same pod using same port

Fix:
```

```bash
# Check if port is in use inside the pod
kubectl exec -it <pod-name> -n <namespace> -- \
  ss -tlnp | grep 8080

# Check for multiple containers competing
kubectl get pod <pod-name> -n <namespace> -o json | \
  jq '.spec.containers[].ports'
```

**Cause 4: Panic / unhandled exception at startup**

```bash
# Get the stack trace from last crash
kubectl logs <pod-name> -n <namespace> --previous | \
  grep -A 30 -E "Exception|Error|panic|FATAL"

# Save full logs for analysis
kubectl logs <pod-name> -n <namespace> --previous > /tmp/crash-logs.txt

# For Go panics: full goroutine dump usually in logs
kubectl logs <pod-name> -n <namespace> --previous | \
  grep -A 50 "goroutine 1"
```

### Stopping CrashLoopBackOff for Debugging

When a pod is CrashLoopBackOff, you often can't exec into it because it keeps dying.

```bash
# Method 1: Override the command to keep it alive for debugging
kubectl patch deployment checkout -n production \
  --patch '{"spec":{"template":{"spec":{"containers":[{"name":"checkout","command":["sleep","infinity"]}]}}}}'
# Pod now stays running (sleeping) instead of running the app
# You can exec in and manually start the app to see the error

kubectl exec -it <pod-name> -n <namespace> -- bash
# Inside the pod, manually run the app:
# java -jar app.jar
# Watch the output directly

# IMPORTANT: Revert after debugging
kubectl rollout undo deployment/checkout -n production

# Method 2: Copy & modify — run a debug version of the image
kubectl debug <pod-name> -n <namespace> \
  --image=eclipse-temurin:17-jdk \
  --target=checkout \
  -it -- bash
# Opens a shell in the same container process namespace

# Method 3: Increase terminationGracePeriodSeconds for more log capture time
kubectl patch deployment checkout -n production \
  --patch '{"spec":{"template":{"spec":{"terminationGracePeriodSeconds":120}}}}'
```

---

## Part 3 — Liveness Probe Failure: Deep Dive

### What Liveness Probe Failure Means

```
Liveness probe: "Is the application ALIVE (not deadlocked/hung)?"

Unlike CrashLoopBackOff (app crashed), liveness failure means:
  - The app process IS running (it hasn't exited)
  - BUT it's not responding to health checks
  - Kubernetes concludes it's deadlocked or hung
  - Kubernetes KILLS the pod and restarts it (even though app didn't crash)

Common causes:
  - Thread deadlock (two threads waiting for each other forever)
  - Thread pool exhaustion (all threads busy, health endpoint can't respond)
  - Infinite loop (one thread spinning at 100% CPU)
  - GC pause too long (JVM paused for full GC > probe timeout)
  - Slow external dependency blocking health check response
```

### Diagnosing Liveness Probe Failure

```bash
# Step 1: Confirm it's a liveness probe failure
kubectl describe pod <pod-name> -n <namespace>
# Look for in Events:
# Warning  Unhealthy  2m    kubelet  Liveness probe failed:
#   HTTP probe failed with statuscode: 503
# OR:
#   Get "http://10.0.1.15:8080/health": context deadline exceeded (Client.Timeout exceeded)
# Normal   Killing    2m    kubelet  Container checkout failed liveness probe,
#                                   will be restarted

# Step 2: Check restart count and timing
kubectl get pod <pod-name> -n <namespace>
# RESTARTS column = 8  → restarting every N minutes

# Step 3: Get thread dump (WHILE APP IS STILL RUNNING, before next restart)
# You have a window between restarts — act fast
kubectl exec -it <pod-name> -n <namespace> -- \
  jstack 1 > /tmp/thread-dump.txt 2>&1

# Copy to local
kubectl cp <namespace>/<pod-name>:/tmp/thread-dump.txt ./thread-dump.txt

# Look for BLOCKED threads
grep -A 10 "BLOCKED" thread-dump.txt | head -100

# Look for deadlock summary at bottom
grep -A 20 "Found.*deadlock" thread-dump.txt

# Step 4: Check thread pool utilization
kubectl exec -it <pod-name> -n <namespace> -- \
  jcmd 1 Thread.print | grep "State:" | sort | uniq -c
# Shows: how many threads in each state (RUNNABLE, BLOCKED, WAITING, TIMED_WAITING)

# Step 5: Check for GC pauses causing timeouts
kubectl exec -it <pod-name> -n <namespace> -- \
  jstat -gcutil 1 5000 10
# GCT column = cumulative GC time
# If GCT grows fast → frequent/long GC pauses → may cause health check timeouts

# Step 6: Check CPU (a deadlocked app might show 0% or 100% CPU)
kubectl top pod <pod-name> -n <namespace>
# 0 millicores CPU: threads all BLOCKED (deadlock)
# Very high CPU: one thread in infinite loop
```

### Liveness Probe Configuration Tuning

```yaml
livenessProbe:
  httpGet:
    path: /health/liveness    # separate from readiness! don't share
    port: 8080
  
  initialDelaySeconds: 30     # wait 30s before first probe (startup time)
  periodSeconds: 10           # check every 10 seconds
  timeoutSeconds: 5           # probe must respond within 5 seconds
  failureThreshold: 3         # 3 consecutive failures = restart
                              # = 3 × 10s = 30 seconds to declare dead
  successThreshold: 1         # 1 success = alive (default)
```

**Tuning for JVM applications:**
```yaml
# JVM apps have longer startup and GC pauses
livenessProbe:
  httpGet:
    path: /actuator/health/liveness
    port: 8080
  initialDelaySeconds: 60     # wait 60s (Spring Boot startup)
  periodSeconds: 15           # check every 15s
  timeoutSeconds: 10          # allow 10s for response
  failureThreshold: 4         # 4 × 15s = 60 seconds tolerance
                              # covers most GC pause scenarios
```

**Liveness vs Readiness vs Startup probes:**
```
startupProbe:   "Has the app finished starting?"
                Runs FIRST. While failing: no traffic, no liveness.
                Once passes ONCE: disabled forever. Liveness takes over.
                Use for: slow-starting apps (Spring Boot, fat JARs)

livenessProbe:  "Is the app alive (not frozen)?"
                Runs continuously AFTER startup.
                If fails N times: pod RESTARTED.
                Use for: detecting deadlocks, hung processes

readinessProbe: "Is the app ready to receive traffic?"
                Runs continuously AFTER startup.
                If fails: pod REMOVED from Service endpoints (no traffic).
                Pod NOT restarted.
                Use for: temporary unreadiness (warming up caches, high load)
```

### Fixing Deadlocks

```bash
# Analyze the thread dump for deadlock pattern
cat thread-dump.txt | grep -A 30 "BLOCKED"

# Typical deadlock in logs:
# Thread A: waiting to lock <0x00000000c0001234> (ResourceA)
#           holding <0x00000000c0005678> (ResourceB)
#
# Thread B: waiting to lock <0x00000000c0005678> (ResourceB)
#           holding <0x00000000c0001234> (ResourceA)
#
# = classic deadlock: A waits for B, B waits for A

# Find which code creates this:
# Look at: stack frames of the BLOCKED threads
# Identify: the synchronized block or lock acquisition order

# Short-term fix: increase liveness threshold (reduce restart frequency)
# Long-term fix: fix the deadlock in code (consistent lock ordering)
```

### Thread Pool Exhaustion

```bash
# Symptom: all threads busy, health endpoint can't respond
# Liveness probe times out, pod restarts, same issue immediately

# Check thread pool metrics (Spring Boot Actuator)
kubectl exec -it <pod-name> -n <namespace> -- \
  curl -s localhost:8080/actuator/metrics/executor.pool.size | jq '.measurements'

# In Prometheus:
# http_server_requests_seconds_count → if requests growing but no completions
# executor_pool_size vs executor_active_count

# Fix: use a DEDICATED thread pool for the health endpoint
# In Spring Boot application.properties:
# management.server.port=8081    # health on separate port (separate thread pool)
```

```yaml
# Configure liveness probe to use management port
livenessProbe:
  httpGet:
    path: /actuator/health/liveness
    port: 8081    # dedicated management port — never thread-starved
```

---

## Part 4 — Config Error: Deep Dive

### What Config Errors Look Like

```
Pod starts → immediately exits with code 1 or 2
Logs show:
  "Required property 'DB_URL' is not set"
  "Error: secret 'checkout-db-secret' not found"
  "java.lang.IllegalArgumentException: Could not resolve placeholder 'DB_PASSWORD'"

OR pod never starts at all:
  Status: Pending → keeps showing Pending, never Running
  OR: Init containers fail
```

### Diagnosing Config Errors Step by Step

```bash
# Step 1: Check Events — these show config errors BEFORE pod even starts
kubectl describe pod <pod-name> -n <namespace>

# Config errors appear as Events like:
# Warning  Failed     30s   kubelet  Error: secret "checkout-db-secret" not found
# Warning  Failed     30s   kubelet  Error: configmap "checkout-config" not found
# Warning  Failed     30s   kubelet  
#   Error: couldn't find key DB_URL in Secret checkout-db-secret

# Step 2: Check if referenced Secrets exist
kubectl get secret checkout-db-secret -n <namespace>
# Error from server (NotFound) → secret doesn't exist at all

# Check what keys are in a secret
kubectl get secret checkout-db-secret -n <namespace> -o json | \
  jq '.data | keys'
# ["DB_HOST", "DB_PORT"]  ← missing DB_URL that the pod expects

# Step 3: Check if ConfigMaps exist
kubectl get configmap checkout-config -n <namespace>
kubectl describe configmap checkout-config -n <namespace>

# Step 4: Verify env vars the pod expects vs what's configured
kubectl get deployment checkout -n <namespace> -o json | \
  jq '.spec.template.spec.containers[].env'
# Shows all expected env vars and their sources

# Step 5: Check actual env vars in a running pod
kubectl exec -it <pod-name> -n <namespace> -- env | sort
# Check: is DB_URL set? What is its value?
# CAREFUL: this prints secrets in plaintext — don't share this output

# Step 6: Check logs for the specific missing var
kubectl logs <pod-name> -n <namespace> --previous | \
  grep -iE "error|missing|not found|undefined|required"

# Step 7: Validate secret content is correctly base64 encoded
kubectl get secret checkout-db-secret -n <namespace> -o json | \
  jq '.data.DB_PASSWORD' | tr -d '"' | base64 -d
# If garbled → secret was created with wrong encoding
```

### Creating Missing Secrets and ConfigMaps

```bash
# Create a missing secret (if it was never created)
kubectl create secret generic checkout-db-secret \
  --namespace=production \
  --from-literal=DB_HOST=postgres.production.svc.cluster.local \
  --from-literal=DB_PORT=5432 \
  --from-literal=DB_NAME=checkout \
  --from-literal=DB_USERNAME=checkout_app \
  --from-literal=DB_PASSWORD="$(cat /tmp/db-password.txt)"

# Create from a file (multi-line values like TLS certs)
kubectl create secret generic checkout-tls \
  --namespace=production \
  --from-file=tls.crt=/path/to/cert.pem \
  --from-file=tls.key=/path/to/key.pem

# Verify all keys are present
kubectl get secret checkout-db-secret -n production -o json | \
  jq '.data | keys'
# Should show: ["DB_HOST", "DB_NAME", "DB_PASSWORD", "DB_PORT", "DB_USERNAME"]

# Add a missing key to an existing secret
kubectl patch secret checkout-db-secret -n production \
  --type='json' \
  -p='[{"op":"add","path":"/data/DB_URL","value":"'"$(echo -n 'jdbc:postgresql://postgres:5432/checkout' | base64)"'"}]'
```

### Verifying Deployment Env Var Configuration

```yaml
# deployment.yaml — correct way to reference secrets
spec:
  containers:
    - name: checkout
      env:
        # Direct value (for non-sensitive config)
        - name: APP_ENV
          value: "production"
        
        # From ConfigMap
        - name: LOG_LEVEL
          valueFrom:
            configMapKeyRef:
              name: checkout-config        # ConfigMap name
              key: LOG_LEVEL               # key within ConfigMap
              optional: false              # fail if missing (default)
        
        # From Secret
        - name: DB_PASSWORD
          valueFrom:
            secretKeyRef:
              name: checkout-db-secret     # Secret name
              key: DB_PASSWORD             # key within Secret
              optional: false              # fail if missing
        
        # Inject entire Secret as env vars (all keys become env vars)
        envFrom:
          - secretRef:
              name: checkout-db-secret
          - configMapRef:
              name: checkout-config
```

```bash
# Verify the deployment references correct secret/configmap names
kubectl get deployment checkout -n production -o json | \
  jq '.spec.template.spec.containers[].envFrom'

# Check if the referenced secret names actually exist
kubectl get secrets -n production
# If expected secret isn't in the list → that's your config error
```

### Missing Secret in a Different Namespace

```bash
# Secrets are namespace-scoped — can't reference a secret from another namespace

# WRONG: production pod trying to use secret from default namespace
# Fix: create the secret in the right namespace

# Check which namespace the pod is in
kubectl get pod <pod-name> -n <namespace> -o jsonpath='{.metadata.namespace}'

# Check which namespaces the secret exists in
kubectl get secrets --all-namespaces | grep checkout-db-secret

# Copy secret from one namespace to another
kubectl get secret checkout-db-secret -n default -o json | \
  jq 'del(.metadata.namespace, .metadata.resourceVersion, .metadata.uid, .metadata.creationTimestamp)' | \
  kubectl apply -n production -f -
```

---

## Part 5 — Stopping Restart Loops (Practical Actions)

### Emergency: Pod Won't Stop Restarting

```bash
# Scale deployment to 0 (stops all pods immediately)
kubectl scale deployment checkout -n production --replicas=0
# Service now returns 503 — use this ONLY in emergencies

# Check root cause while pods are stopped
kubectl logs <old-pod-name> -n production --previous

# Fix the issue (change config, update secret, fix resource limits)

# Scale back up
kubectl scale deployment checkout -n production --replicas=3

# ──────────────────────────────────────────────────────────────

# Alternative: keep some pods running (old version) while debugging
# Scale down but don't go to 0
kubectl scale deployment checkout -n production --replicas=1
# 1 pod keeps serving traffic (even if it restarts occasionally)
# while you investigate

# ──────────────────────────────────────────────────────────────

# For CrashLoopBackOff: override command to prevent crashing
kubectl patch deployment checkout -n production \
  --type='json' \
  -p='[{"op":"replace","path":"/spec/template/spec/containers/0/command","value":["sleep","3600"]}]'
# Pod now stays running for 1 hour without executing the app
# Exec into it and debug
kubectl exec -it <new-pod-name> -n production -- bash
# Manually test: java -jar app.jar → see the error directly
```

### Annotate the Restart for Audit Trail

```bash
# After fixing: document what happened
kubectl annotate deployment checkout -n production \
  kubernetes.io/change-cause="Fix: increased memory limit 512Mi→1Gi for OOMKilled (incident-2026-0731)"

kubectl rollout history deployment/checkout -n production
# REVISION  CHANGE-CAUSE
# 5         Fix: increased memory limit 512Mi→1Gi for OOMKilled (incident-2026-0731)
```

---

## Quick Reference: Exit Codes

| Exit Code | Meaning | Likely Cause |
|---|---|---|
| 0 | Clean exit (success) | App intentionally stopped |
| 1 | General error | App crash, startup failure |
| 2 | Misuse of shell / arg error | Wrong command or flags |
| 137 | Killed by SIGKILL | OOMKilled OR `kubectl delete pod` |
| 139 | Segmentation fault | Memory corruption, C library bug |
| 143 | Killed by SIGTERM | Pod gracefully terminated (expected) |
| 255 | Exit(-1) | App explicitly called exit(-1) |

---

## Common Mistakes and Fixes

| Mistake | Symptom | Fix |
|---|---|---|
| Memory limit = Memory request | OOMKilled on burst traffic | Set limit 2× the request |
| No startup probe on slow apps | Liveness kills app during startup | Add startupProbe with high failureThreshold |
| Liveness probe hits slow endpoint | False liveness failures during load | Liveness path must be fast/local, not call DBs |
| No `--previous` flag on logs | See empty logs for crashed pod | Always use `kubectl logs --previous` for crashed pods |
| Secret in wrong namespace | Pod pending / Error from startup | Secrets are namespace-scoped — create in same namespace |
| Missing `-XX:+UseContainerSupport` | JVM ignores cgroup limits, OOMs | Always set this JVM flag in containers |
| GC pause > liveness timeout | Repeated restarts under load | Increase `timeoutSeconds` or switch GC algorithm |
| Checking running pod logs | Miss the crash cause | Use `--previous` to see logs from last crashed instance |
