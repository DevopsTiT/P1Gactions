# Jira Must-Know for SREs

---

## E2E Flow Summary

```
Incident/Work Identified
        │
        ▼
   Create Issue  ──────────────────────────────────────────────►  Project
   (Bug / Task / Story / Incident)                                  Board
        │
        ▼
   Set Priority + Labels + Components
        │
        ▼
   Assign to Sprint  ──► Backlog (if not urgent)
        │
        ▼
   Status Transitions:
   To Do → In Progress → In Review → Done
        │
        ▼
   Link Issues (blocks / is blocked by / relates to)
        │
        ▼
   Close + Post-Mortem (for Incidents)
```

---

## Decision Tree — What Issue Type to Use?

```
Is it something broken in production?
  YES → Bug (or Incident if severity >= P1)
  NO  →
    Is it a user-facing feature request?
      YES → Story
      NO  →
        Is it internal work / infra / SRE task?
          YES → Task
          NO  →
            Is it a container for multiple tasks?
              YES → Epic
              NO  → Sub-task (child of Task/Story)
```

---

## Tool Map

| What you want to do              | Jira concept        |
|----------------------------------|---------------------|
| Track an outage / incident       | Bug or Incident issue type |
| Group related work under 1 theme | Epic                |
| Plan a 2-week work block         | Sprint              |
| See team's current work          | Board (Kanban/Scrum)|
| Find all issues for a service    | JQL query           |
| Report status to management      | Dashboard           |
| Auto-link Jira to code PRs       | Smart Commits / PR integration |

---

## Part 1 — Core Concepts

### Projects
A **Project** is a container for all issues related to one team or product.
- Every issue lives inside exactly one project.
- Projects have a **Key** (e.g. `SRE`, `INFRA`, `PLAT`) — used as a prefix on every issue ID: `SRE-123`.
- Two project types: **Scrum** (sprints) and **Kanban** (continuous flow — common for SRE ops work).

### Issue Types
| Type | When SREs use it |
|------|-----------------|
| **Epic** | Large initiative (e.g. "Migrate all services to K8s") spanning weeks/months |
| **Story** | User-visible improvement ("As an engineer I want alerting on p99 latency") |
| **Task** | Internal work item with no user story ("Update Terraform state backend") |
| **Bug** | Something broken that needs fixing |
| **Sub-task** | Child of any issue; use to split big tasks into parallel steps |
| **Incident** (custom) | Many SRE teams add this type for production incidents |

### Priority Levels
| Label | Meaning for SRE |
|-------|----------------|
| **P1 / Critical** | Production down, data loss — page on-call NOW |
| **P2 / High** | Degraded service, SLO breach risk — fix today |
| **P3 / Medium** | Non-critical bug, fix this sprint |
| **P4 / Low** | Nice to have, no urgency |

---

## Part 2 — Issue Anatomy (Fields Every SRE Should Fill)

```
Title         → Short, action-oriented: "[Service] - symptom - environment"
Description   → What broke, impact, steps to reproduce / evidence
Priority      → P1–P4
Assignee      → Who owns it RIGHT NOW
Reporter      → Who filed it
Labels        → Free-form tags: "on-call", "infra", "monitoring", "toil"
Components    → Logical subsystems: "database", "networking", "auth"
Sprint        → Which sprint cycle this is planned for
Epic Link     → Parent epic if applicable
Due Date      → For SLO-driven deadlines
Story Points  → Effort estimate (Fibonacci: 1, 2, 3, 5, 8, 13)
Linked Issues → "blocks" / "is blocked by" / "duplicates" / "relates to"
```

**SRE pro tip:** Always fill `Labels` with service name + environment so JQL searches work:
`labels = "payments-service" AND labels = "production"`

---

## Part 3 — Workflows & Status Transitions

A **workflow** is the set of statuses an issue moves through. Default Scrum workflow:

```
To Do  →  In Progress  →  In Review  →  Done
  ↑_______________(reopen)________________________↑
```

For SRE incident response, teams often customize:
```
Open → Investigating → Mitigating → Resolved → Post-Mortem Done
```

**Transitions are triggered manually** (drag on board, or click "Move" in the issue).
Automations can trigger transitions too (e.g. PR merged → auto-move to "In Review").

---

## Part 4 — JQL (Jira Query Language)

JQL is SQL for Jira. Every SRE must know basic JQL to find issues fast.

### Syntax
```
FIELD OPERATOR VALUE [AND/OR FIELD OPERATOR VALUE]
```

### Essential JQL Queries for SREs

```jql
-- All open incidents in SRE project
project = SRE AND issuetype = Bug AND status != Done ORDER BY priority ASC

-- Everything assigned to me right now
assignee = currentUser() AND status != Done

-- Unresolved issues in current sprint
project = SRE AND sprint in openSprints() AND status != Done

-- Everything blocking another issue
issue in linkedIssues("SRE-100", "blocks")

-- Issues created in the last 24h (incident watch)
project = SRE AND created >= -1d ORDER BY created DESC

-- SLO breach related issues
project = SRE AND labels = "slo-breach" AND status != Done

-- All P1s across all projects
priority = Highest AND status != Done ORDER BY created ASC

-- Issues updated in last hour (live incident tracking)
updated >= -1h AND project = SRE ORDER BY updated DESC
```

### JQL in Filters & Dashboards
1. Jira top bar → **Filters** → **Advanced issue search** → paste JQL
2. Save the filter → add it to a **Dashboard gadget** for always-on visibility

---

## Part 5 — Boards

A **Board** shows your team's issues as cards in columns (one column per status).

| Board Type | Best for |
|-----------|---------|
| **Scrum** | Planned sprints, story-point velocity, predictable delivery |
| **Kanban** | SRE ops / on-call work — continuous pull, no sprints needed |

**Kanban board columns** a typical SRE team uses:
```
Backlog | To Do | In Progress | Waiting/Blocked | In Review | Done
```

**Swimlanes** — horizontal rows on the board to group by:
- Assignee (who owns what)
- Priority (P1 row always at top)
- Epic (work stream view)

---

## Part 6 — Sprints (Scrum Teams)

A **Sprint** is a time-boxed work period (usually 2 weeks).

```
Sprint lifecycle:
  Plan → Sprint Active → Sprint Review → Sprint Retro → Close Sprint
```

- **Sprint Planning**: pull issues from Backlog into Sprint, estimate story points
- **Sprint Goal**: one sentence describing what the team will ship
- **Velocity**: average story points completed per sprint — used to forecast
- **Burndown chart**: shows remaining work over the sprint's days

SRE teams often run **Kanban** instead of Scrum because incidents are not plannable — but many still use sprints for project/toil work.

---

## Part 7 — Epics

An **Epic** is a large body of work that contains multiple stories/tasks.

Example SRE epics:
- "Observability: Migrate to OpenTelemetry" → contains 12 tasks
- "Reliability: Reduce MTTR by 30%" → contains stories across teams
- "Toil Reduction Q3" → contains all automation tasks

**Epic link** field on a task/story points it to its parent epic.
The **Roadmap view** (Timeline) shows all epics as a Gantt chart.

---

## Part 8 — Linking Issues

Issue links express relationships between work items:

| Link type | Meaning |
|-----------|---------|
| **blocks** | Issue A cannot proceed until Issue B is done |
| **is blocked by** | Mirror of "blocks" |
| **relates to** | Loosely connected, no hard dependency |
| **duplicates** | Same problem filed twice — close one, link to the other |
| **clones** | Copy of another issue (different project/team) |
| **causes / is caused by** | For incident root-cause chains |

**In JQL:** `issue in linkedIssues("SRE-100", "is blocked by")`

---

## Part 9 — Dashboards & Gadgets

A **Dashboard** is a page of **Gadgets** (widgets). SREs use dashboards for:
- On-call situation room (P1/P2 open issues)
- Sprint health
- SLO-breach tracker

Useful gadgets:
| Gadget | Shows |
|--------|-------|
| **Issue Statistics** | Count of issues by priority / status |
| **Filter Results** | Table of issues from a saved JQL filter |
| **Two-Dimensional Filter** | Issues grouped by two fields (e.g. priority × assignee) |
| **Sprint Health** | Burndown, velocity, remaining points |
| **Activity Stream** | Recent changes across a project |

---

## Part 10 — Automation Rules

Jira Automation lets you trigger actions without manual steps.

**Common SRE automations:**
```
Trigger: Issue priority set to P1
Action:  Send Slack notification to #incidents channel

Trigger: PR merged in Bitbucket
Action:  Transition linked issue to "In Review"

Trigger: Issue unresolved for > 30 minutes AND priority = P1
Action:  Escalate — add label "escalated", assign to manager

Trigger: Sprint ends
Action:  Move unfinished issues to next sprint
```

Location: **Project Settings → Automation**

---

## Part 11 — Integrations SREs Care About

| Integration | What it does |
|-------------|-------------|
| **Bitbucket / GitHub** | Smart commits: write `SRE-123 #done` in commit message to auto-close issue |
| **PagerDuty** | Auto-create Jira issue when PD alert fires |
| **Opsgenie** | Same as PagerDuty |
| **Slack** | Post issue updates to channel; create issues from Slack |
| **Confluence** | Link Jira issues to Confluence runbooks / post-mortem pages |
| **Grafana / Datadog** | Some plugins create Jira issues from alert annotations |
| **CI/CD** | Pipeline failure → auto-create Bug issue |

**Smart Commit syntax (in git commit messages):**
```
git commit -m "fix payment timeout SRE-456 #in-progress #comment Fixed the pool size"
```

---

## Part 12 — SRE-Specific Workflows

### Incident Lifecycle in Jira
```
1. On-call detects alert → Create Bug issue: title "[P1] Payments API 500s - production"
2. Fill: Priority=P1, Labels=incident production payments-service, Component=API
3. Start investigating → transition to "In Progress"
4. Link to related issues (recent deploys, config changes)
5. Mitigated → transition to "Resolved"
6. Write post-mortem → Confluence page → link from Jira issue
7. Create follow-up Tasks for action items with due dates
8. Close issue only after all action items have parent tasks created
```

### Toil Tracking
- Create a recurring Task template for toil work
- Label with `toil` and `service-name`
- Track time with **Log Work** (hours spent)
- Monthly: JQL `labels = toil AND created >= -30d` → count hours → feed into SRE toil report

### SLO Breach Issues
- Label: `slo-breach`
- Component: the affected service
- Link to the SLO definition Confluence page
- Set due date = SLO window end date
- Assign to service owner team

---

## Common Mistakes

| Mistake | Why it hurts | Fix |
|---------|-------------|-----|
| Not filling Labels/Components | JQL searches return nothing | Always fill both fields |
| Leaving issues "In Progress" forever | Board noise, sprint reports wrong | Daily standup hygiene — move or block |
| Creating duplicate issues | Splits comments and history | Search before creating: `summary ~ "your title"` |
| No Epic link on tasks | Roadmap is broken, no rollup | Always link tasks to an Epic |
| Closing incidents without post-mortem link | Loses institutional knowledge | Add Confluence link before closing |
| Using priority P3 for everything | Means nothing — P1 drowns in noise | Respect the P1-P4 definitions strictly |
| Generic issue titles | "API broken" tells nobody anything | Format: `[Service] symptom environment` |
