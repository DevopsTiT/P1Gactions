# Jira Must-Know — Commands & JQL Reference

## Phase 0 — Find Issues Fast (JQL)

```bash
# These are run in Jira UI: Filters → Advanced issue search
# Or via CLI tools like `jira` (go-jira) or `jira-cli`

# Install jira-cli (optional, for terminal access)
brew install ankitpokhrel/jira/jira

# Auth (run once)
jira init
# prompts for: server URL, username, API token
```

## Phase 1 — JQL Cheat Sheet

```jql
-- Open P1s right now
priority = Highest AND status != Done ORDER BY created ASC

-- My open issues
assignee = currentUser() AND status != Done

-- Current sprint issues
project = SRE AND sprint in openSprints()

-- Incidents last 24h
project = SRE AND issuetype = Bug AND created >= -1d ORDER BY created DESC

-- Blocking issues
issue in linkedIssues("SRE-123", "blocks")

-- SLO breaches
labels = "slo-breach" AND status != Done

-- Toil issues this month
labels = toil AND created >= -30d

-- Updated in last hour (live incident)
updated >= -1h AND project = SRE ORDER BY updated DESC

-- Unresolved issues with no assignee
project = SRE AND assignee is EMPTY AND status != Done

-- Issues in a specific component
component = "payments-service" AND status != Done
```

## Phase 2 — jira-cli Common Commands

```bash
# List open issues assigned to me
jira issue list --assignee$(jira me) --status "In Progress"

# Create a new task
jira issue create \
  --type Task \
  --summary "[SRE] Fix flaky health-check probe on payments-api" \
  --priority High \
  --label "toil" \
  --label "payments-service"

# Create a bug
jira issue create \
  --type Bug \
  --summary "[payments-api] 500s on /checkout - production" \
  --priority Highest \
  --label "incident" \
  --label "production"

# View an issue
jira issue view SRE-456

# Transition an issue (move status)
jira issue move SRE-456 "In Progress"
jira issue move SRE-456 "Done"

# Assign an issue to yourself
jira issue assign SRE-456 $(jira me)

# Add a comment
jira issue comment add SRE-456 "Mitigation in place. Monitoring for 15 min."

# Link two issues
jira issue link SRE-456 SRE-100 "blocks"

# List sprints in a board
jira sprint list --board "SRE Board"

# Add issue to current sprint
jira sprint add <sprint-id> SRE-456

# Log work on an issue
jira issue worklog add SRE-456 --time-spent 2h --comment "Investigating root cause"
```

## Phase 3 — Smart Commits (git integration)

```bash
# Transition issue to In Progress via commit message
git commit -m "SRE-456 #in-progress starting DB connection fix"

# Transition to Done via commit message
git commit -m "SRE-456 #done fix connection pool exhaustion"

# Add a comment via commit
git commit -m "SRE-456 #comment root cause was missing connection timeout"

# Multiple actions in one commit
git commit -m "SRE-456 #in-progress #comment deploying hotfix to production"
```

## Phase 4 — REST API (when you need scripting)

```bash
# Set these env vars first
export JIRA_URL="https://your-org.atlassian.net"
export JIRA_USER="your@email.com"
export JIRA_TOKEN="your-api-token"   # from id.atlassian.com/manage/api-tokens

# Get an issue
curl -s \
  -u "${JIRA_USER}:${JIRA_TOKEN}" \
  -H "Content-Type: application/json" \
  "${JIRA_URL}/rest/api/3/issue/SRE-456" | jq .

# Create an issue via API
curl -s -X POST \
  -u "${JIRA_USER}:${JIRA_TOKEN}" \
  -H "Content-Type: application/json" \
  "${JIRA_URL}/rest/api/3/issue" \
  -d '{
    "fields": {
      "project": { "key": "SRE" },
      "summary": "[payments-api] High error rate - production",
      "issuetype": { "name": "Bug" },
      "priority": { "name": "Highest" },
      "labels": ["incident", "production", "payments-service"]
    }
  }' | jq '.key'

# Transition an issue (get transition IDs first)
curl -s \
  -u "${JIRA_USER}:${JIRA_TOKEN}" \
  "${JIRA_URL}/rest/api/3/issue/SRE-456/transitions" | jq '.transitions[] | {id, name}'

# Apply a transition (use the id from above)
curl -s -X POST \
  -u "${JIRA_USER}:${JIRA_TOKEN}" \
  -H "Content-Type: application/json" \
  "${JIRA_URL}/rest/api/3/issue/SRE-456/transitions" \
  -d '{"transition": {"id": "31"}}'

# Search with JQL via API
curl -s \
  -u "${JIRA_USER}:${JIRA_TOKEN}" \
  -G "${JIRA_URL}/rest/api/3/search" \
  --data-urlencode "jql=project=SRE AND priority=Highest AND status!=Done" \
  --data-urlencode "fields=summary,status,assignee,priority" | jq '.issues[] | {key, summary: .fields.summary, status: .fields.status.name}'

# Add a comment
curl -s -X POST \
  -u "${JIRA_USER}:${JIRA_TOKEN}" \
  -H "Content-Type: application/json" \
  "${JIRA_URL}/rest/api/3/issue/SRE-456/comment" \
  -d '{"body": {"type": "doc", "version": 1, "content": [{"type": "paragraph", "content": [{"type": "text", "text": "Incident mitigated. Monitoring."}]}]}}'
```

## Phase 5 — Incident Response Quick Commands

```bash
# Create P1 incident issue fast
jira issue create \
  --type Bug \
  --priority Highest \
  --summary "[payments-api] INCIDENT - 500s on checkout - $(date -u +%Y-%m-%dT%H:%MZ)" \
  --label incident \
  --label production \
  --label payments-service

# Watch for new P1s (poll every 60s)
while true; do
  echo "=== $(date) ==="
  jira issue list \
    --jql "priority = Highest AND status != Done AND updated >= -2m" \
    --columns KEY,SUMMARY,STATUS,ASSIGNEE
  sleep 60
done
```
