# Jira Must-Know — Glossary for SRE Beginners

Every term used in main.md, explained in plain language.

---

**Jira**
A project and issue tracking tool made by Atlassian. Think of it as a database of work items — bugs, tasks, incidents — with workflows, dashboards, and search. Most engineering teams use it to track what needs to be done and who is doing it.

**Project**
A container in Jira that holds all issues for one team or product. Like a folder. Has a short key (e.g. `SRE`) that prefixes every issue ID in it (`SRE-1`, `SRE-2`, ...).

**Issue**
The basic unit of work in Jira. Every bug, task, story, or incident is an issue. Has a unique ID like `SRE-123`.

**Issue Type**
The category of an issue. Common types: Bug, Task, Story, Epic, Sub-task. Each type signals the kind of work and may have different fields or workflows.

**Epic**
A large, multi-week body of work that groups many tasks/stories. Think of it as a theme or initiative. Example: "Migrate all services to Kubernetes." Tasks are linked to an Epic to show progress.

**Story (User Story)**
A description of a feature from a user's perspective. Format: "As a [user], I want [X] so that [Y]." SREs use them for improvements that affect engineers who use internal platforms.

**Task**
A generic work item with no user-story framing. SREs use Tasks for internal work: "Update Terraform module," "Add alert rule for memory."

**Bug**
An issue that tracks something broken. For SREs this covers production incidents, broken monitors, misbehaving deployments.

**Sub-task**
A child issue under a Task, Story, or Bug. Used to split one issue into smaller parallel steps. Cannot exist without a parent.

**Priority**
How urgently an issue needs to be addressed. Standard levels: P1 (Critical/Highest) down to P4 (Low). SRE teams map these to on-call severity levels.

**Assignee**
The person currently responsible for an issue. Only one assignee at a time — the person who owns it RIGHT NOW (not necessarily forever).

**Reporter**
The person who filed the issue. Often the one who discovered the problem.

**Labels**
Free-text tags you add to an issue. Unlike Components, labels are not pre-defined — anyone can create them. SREs use them to tag service names, environments, and issue themes (`production`, `payments-service`, `toil`).

**Components**
Pre-defined logical subsystems or categories within a project (e.g. `networking`, `auth`, `database`). Admins define them. Used to filter and assign issues to sub-teams.

**Sprint**
A fixed-length time box (usually 2 weeks) during which a team commits to completing a set of issues. Comes from Scrum methodology. At the end, unfinished issues are moved to the next sprint.

**Backlog**
The list of all issues that are not yet in a sprint. This is the queue of future work. During Sprint Planning, the team pulls issues from the Backlog into the upcoming Sprint.

**Sprint Planning**
A meeting at the start of each sprint where the team picks issues from the Backlog, estimates them in story points, and commits to completing them.

**Velocity**
The average number of story points a team completes per sprint. Used to forecast how much the team can take on in the next sprint.

**Burndown Chart**
A graph showing remaining story points (or issues) over the days of a sprint. A healthy burndown slopes steadily downward. Flat lines mean work isn't moving.

**Story Points**
A unit of effort estimation (not time). Uses Fibonacci numbers: 1, 2, 3, 5, 8, 13. A 1 is trivial; a 13 is huge and usually should be broken up. The exact hours don't matter — the relative sizing does.

**Board**
A visual representation of a project's issues as cards in columns. Each column = a status (To Do, In Progress, Done). Two types: Scrum board (sprint-based) and Kanban board (continuous flow).

**Kanban**
A workflow method where work is pulled continuously as capacity allows — no sprints. Ideal for SRE ops/on-call work because incidents are not plannable. The board shows all in-flight work at a glance.

**Scrum**
A framework that uses fixed sprints, sprint planning, daily standups, and retrospectives. Better for product teams with planned feature delivery. Some SRE teams use Scrum for project/toil work.

**Swimlane**
A horizontal row on a Kanban or Scrum board that groups issues by a field (assignee, priority, epic). Makes it easy to see all P1s in one row, for example.

**Workflow**
The defined set of statuses an issue type moves through, and the allowed transitions between them. Default: To Do → In Progress → Done. Teams customize workflows for incident response, code review, etc.

**Status**
Where an issue currently sits in the workflow. Examples: `To Do`, `In Progress`, `In Review`, `Done`, `Investigating`, `Resolved`.

**Transition**
The act of moving an issue from one status to another. Can be done manually (drag on board) or automatically via Automation rules.

**JQL (Jira Query Language)**
A query language for searching issues. Like SQL but for Jira fields. Used in Filters, Dashboards, and Automation conditions. Example: `project = SRE AND priority = Highest AND status != Done`.

**Filter**
A saved JQL query. You save a filter once and reuse it in dashboards or share it with teammates.

**Dashboard**
A configurable page of Gadgets (widgets). SREs build dashboards for incident visibility, sprint health, and SLO breach tracking.

**Gadget**
A single widget on a Dashboard. Examples: Issue Statistics, Filter Results, Activity Stream, Sprint Health.

**Epic Link**
A field on a Task/Story that links it to its parent Epic. Without this, the Epic's progress rollup is broken and the Roadmap is incomplete.

**Roadmap (Timeline)**
A Gantt-style view of all Epics over time. Shows start/end dates and how Epics relate. Requires Epics to have date fields set.

**Issue Link**
An explicit relationship between two issues. Types: blocks, is blocked by, relates to, duplicates, clones, causes.

**blocks / is blocked by**
A link type meaning one issue cannot proceed until another is done. Used to surface dependencies. `SRE-100 blocks SRE-200` means 200 can't start until 100 is done.

**Post-Mortem**
A blameless document written after an incident to explain what happened, why, and what action items will prevent recurrence. In Jira workflows, issues should be linked to the post-mortem Confluence page before closing.

**Toil**
Repetitive, manual, automatable work that SREs do to keep services running. Jira helps track toil by labeling issues — then you can measure how much engineer time is spent on it vs. project work.

**Smart Commits**
A Jira + Bitbucket/GitHub integration that lets you control Jira issues from git commit messages. Writing `SRE-123 #done` in a commit automatically transitions the issue to Done.

**Automation Rule**
A configured trigger → action pair in Jira. "When issue priority is set to P1, post to #incidents Slack channel." Runs without human intervention.

**API Token**
A password substitute for the Jira REST API. You generate one at id.atlassian.com and use it instead of your real password in scripts and CLI tools. Never share or commit to git.

**REST API**
The programmatic interface to Jira. Lets you create, read, update, and transition issues from scripts. All operations your browser does on Jira can be done via the API.

**jira-cli**
An open-source command-line tool (`ankitpokhrel/jira`) that wraps the Jira REST API. Lets you manage Jira from the terminal without opening a browser.

**Log Work**
A Jira feature that records how many hours you spent on an issue. Useful for SRE toil reporting — log work on toil issues to build a data trail of time spent on non-project work.

**Confluence**
Atlassian's wiki tool, used alongside Jira. SREs write runbooks, architecture docs, and post-mortems in Confluence, then link them from Jira issues.

**PagerDuty / Opsgenie**
Alerting and on-call management tools. Integrate with Jira to auto-create incident issues when alerts fire, so on-call engineers have a Jira ticket to track the incident from the start.

**SLO (Service Level Objective)**
A target for how reliable a service should be (e.g. 99.9% uptime). SREs create Jira issues labeled `slo-breach` when a service falls below its SLO to track remediation work.

**MTTR (Mean Time To Resolution)**
The average time it takes to resolve an incident from the moment it starts. Tracked per incident in Jira — incident create time to Done transition time.
