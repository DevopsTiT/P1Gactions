# Tuning Alerting Mechanisms — Deep Dive for SREs

---

## E2E Flow Summary

```
Raw Metric/Event
      │
      ▼
[Threshold / Condition Check]  ← poorly tuned = alert storm
      │ fires
      ▼
[Evaluation Window]            ← too short = flapping; too long = slow detection
      │ sustained breach
      ▼
[Alert Routing / Grouping]     ← without grouping = 100 pages for 1 incident
      │
      ▼
[Deduplication / Inhibition]   ← without these = duplicate wake-up calls
      │
      ▼
[On-Call Engineer]             ← the human you are trying to protect
```

**One-line goal:** Every alert that pages a human must be: (1) actionable, (2) urgent, (3) real — anything else is noise that degrades on-call quality and causes alert fatigue.

---

## Decision Tree — What Type of Problem Is This Alert?

```
What is this alert measuring?
│
├── Is it ALREADY broken for users right now?
│       └── Use: SYMPTOM alert (user-facing SLI breach)
│           Example: "error rate > 1% for 5 min"
│
├── Is it a WARNING SIGN that MIGHT cause problems?
│       └── Use: CAUSE alert (infra/saturation)
│           Example: "disk > 85%"  → page BEFORE disk is full
│           But: lower severity, longer window, no PagerDuty
│
├── Does it flip between firing/ok every few minutes?
│       └── Problem: flapping — increase evaluation window or add hysteresis
│
├── Does it fire alongside 20 other alerts for the same incident?
│       └── Problem: alert storm — add grouping + inhibition rules
│
├── Does it fire but oncall can't DO anything about it right now?
│       └── Wrong severity — downgrade to warning ticket, not page
│
└── Does it fire during known maintenance/deploy windows?
        └── Add silence rules or maintenance window suppression
```

---

## Tool Map

| Tool | Role in alerting |
|---|---|
| Prometheus | Evaluates PromQL alert rules, fires alerts |
| Alertmanager | Routes, groups, deduplicates, silences, inhibits alerts |
| PagerDuty / OpsGenie | Receives routed alerts, manages on-call schedules |
| Grafana | Visualizes alert state; also has its own alert engine |
| Dynatrace | AI-assisted alerting with Davis engine; anomaly detection |
| SLO burn rate alerts | Fires based on error budget consumption rate |

---

## Part 1 — The Alerting Problem: Alert Fatigue

### What Alert Fatigue Is

Alert fatigue happens when on-call engineers receive so many alerts that they:
1. Start ignoring alerts ("probably another false positive")
2. Miss the one real critical alert buried in the noise
3. Get burned out and leave

**This is the #1 operational risk in SRE.** A system with 500 weekly alerts where 480 are false positives trains engineers to ignore everything.

### The Two Types of Bad Alerts

```
FALSE POSITIVE: Alert fires, but nothing is actually broken
  → Wastes oncall time, erodes trust in alerting system
  → Example: "CPU > 70%" fires every deploy even though p99 latency is fine

FALSE NEGATIVE: Something IS broken, but no alert fires
  → Silent failure — the worst kind
  → Example: payment service silently returning errors but no alert on error rate
```

**The goal of tuning:** Push false positives to near-zero while keeping false negatives near-zero too.

---

## Part 2 — Anatomy of a Well-Tuned Alert

### Required Properties of Every Page-Worthy Alert

```
1. ACTIONABLE     → The oncall can DO something about it right now
2. URGENT         → Waiting until business hours would cause harm
3. NOVEL          → Not already known / being worked on
4. REAL           → Represents actual user impact, not a blip
```

If an alert fails ANY of these four, it should NOT page a human at 3am.

### Alert Fields That Matter

```yaml
# Prometheus alert rule — annotated
groups:
  - name: checkout-service
    rules:
      - alert: CheckoutHighErrorRate       # Name: clear, service-scoped
        expr: |
          rate(http_requests_total{
            service="checkout",
            status=~"5.."
          }[5m])
          /
          rate(http_requests_total{
            service="checkout"
          }[5m])
          > 0.01                           # Threshold: 1% error rate
        for: 5m                            # Must be true for 5 CONSECUTIVE minutes
                                           # (prevents flapping on blips)
        labels:
          severity: critical               # Drives routing in Alertmanager
          team: payments                   # Drives routing to right oncall
          env: production                  # Prevents staging alerts waking people
        annotations:
          summary: "Checkout error rate {{ $value | humanizePercentage }}"
          description: |
            Service checkout has error rate {{ $value | humanizePercentage }}
            above 1% for 5 minutes.
          runbook_url: "https://wiki/runbooks/checkout-high-error-rate"
          dashboard_url: "https://grafana/d/checkout"
```

**The `for:` field is the single most important tuning parameter.** It prevents brief spikes from paging anyone.

---

## Part 3 — Threshold Tuning

### Strategy 1: Symptom-Based vs Cause-Based

```
SYMPTOM (preferred for pages):
  "Users are experiencing errors right now"
  → Alert on: error_rate > 1%, latency_p99 > 2s, availability < 99.9%
  → ALWAYS page

CAUSE (preferred for tickets/warnings):
  "Something might break in the future"
  → Alert on: CPU > 85%, disk > 80%, memory > 90%
  → Usually ticket/Slack, not page
```

**Why symptoms > causes:** A server can be at 95% CPU and users feel nothing. A server at 50% CPU with a bad query can have p99 latency of 30 seconds. Alert on what users feel, not what machines feel.

### Strategy 2: Percentile Thresholds (Not Averages)

```
BAD:  avg(latency) > 500ms
      Problem: one request taking 10s + 999 requests at 10ms = avg 20ms
               Users at 10s are invisible

GOOD: histogram_quantile(0.99, rate(latency_bucket[5m])) > 500ms
      Problem: catches the worst 1% of users
```

**Rule:** For latency alerts, always alert on p99 (or p999 for critical paths). Average latency lies.

### Strategy 3: Rate vs Raw Count

```
BAD:  http_errors_total > 100
      Problem: at 2am with 10 req/s, 100 errors = 10 seconds of full outage
               At noon with 10,000 req/s, 100 errors = normal background noise

GOOD: rate(http_errors_total[5m]) / rate(http_requests_total[5m]) > 0.01
      Uses error RATE (percentage) — works at any traffic level
```

### Strategy 4: Use Baselines (Not Static Thresholds)

Static threshold problem:
```
CPU > 70% alerts all day during peak traffic (business hours)
Same 70% CPU at 3am = something is very wrong
```

Better approach — compare against moving average:
```promql
# Alert if CPU is 2x its 24h average
(
  rate(cpu_usage[5m])
  /
  avg_over_time(rate(cpu_usage[5m])[24h:5m])
) > 2
```

Dynatrace Davis engine does this automatically (it learns baselines).

### Strategy 5: Multi-Condition Alerts

Reduce false positives by requiring MULTIPLE conditions to be true:

```yaml
# Don't alert on high latency alone — it might be low traffic with 1 slow req
# Require: high latency AND significant traffic
expr: |
  histogram_quantile(0.99, rate(request_duration_seconds_bucket[5m])) > 0.5
  AND
  rate(request_duration_seconds_count[5m]) > 10
```

---

## Part 4 — Evaluation Window Tuning (`for:` duration)

The `for:` field controls how long a condition must be true before firing.

### Choosing the Right Window

```
for: 0m   → Fires immediately on first evaluation
            Risk: any 15-second spike pages someone
            Use: almost never (maybe disk full = 100%)

for: 1m   → Must be true for 1 minute
            Risk: still catches short spikes (deploys, GC pauses)
            Use: very fast-moving metrics (error rate during incident)

for: 5m   → Most common production default
            Filters out: deploy blips, GC pauses, brief network hiccups
            Use: latency, error rate, availability

for: 15m  → Conservative — definitely a sustained problem
            Risk: slow to fire (15 min of user impact before alert)
            Use: slow-moving metrics (disk growth, memory leak)

for: 30m+ → Warning-level only, not pages
            Use: capacity planning alerts (disk > 70%)
```

### Hysteresis — Different Thresholds for Fire vs Resolve

Without hysteresis: alert flaps if metric bounces around the threshold

```
Metric: 1.1% → FIRE → 0.9% → RESOLVE → 1.1% → FIRE → 0.9% → RESOLVE
Result: oncall gets pages every 2 minutes
```

With hysteresis (Prometheus doesn't do this natively — use separate rules):
```yaml
# Fire at 1% error rate
- alert: HighErrorRate
  expr: error_rate > 0.01
  for: 5m

# This resolves only when error rate drops below 0.5%
# (Trick: use 'absent' or separate threshold in Alertmanager)
```

Better: in Grafana alerts, you can set separate thresholds for "alerting" and "ok" states.

---

## Part 5 — Alertmanager: Routing, Grouping, Inhibition

Alertmanager sits between Prometheus and your pager. It handles the "who gets this alert and how" questions.

### Grouping — Prevent Alert Storms

Without grouping: 50 pods restart → 50 separate pages to oncall

```yaml
# alertmanager.yml
route:
  group_by: ['alertname', 'service', 'cluster']
  group_wait: 30s        # wait 30s for more alerts to arrive before sending
  group_interval: 5m     # how long to wait before sending new alerts for same group
  repeat_interval: 4h    # resend if still firing after 4h (reminders)
```

With this config: 50 pod-restart alerts → ONE notification saying "50 pods restarted"

**`group_by` selection is critical:**
```
Too broad: ['cluster']
→ All alerts in the cluster become ONE message — you lose granularity

Too narrow: ['alertname', 'pod', 'instance']
→ 50 pods = 50 separate pages (defeats the purpose)

Just right: ['alertname', 'service', 'severity']
→ One page per alert type per service
```

### Routing — Send Alerts to the Right Team

```yaml
route:
  receiver: 'default-pagerduty'
  routes:
    # Database alerts → DBA oncall
    - match:
        team: database
      receiver: 'dba-oncall'

    # Payments critical → payments oncall + PagerDuty
    - match:
        team: payments
        severity: critical
      receiver: 'payments-pagerduty'
      continue: false        # stop checking other routes

    # Low severity → Slack only, not pager
    - match:
        severity: warning
      receiver: 'slack-warnings'
      continue: false

    # Staging → Slack only, never page
    - match:
        env: staging
      receiver: 'slack-staging'
      continue: false

receivers:
  - name: 'payments-pagerduty'
    pagerduty_configs:
      - routing_key: 'YOUR_INTEGRATION_KEY'
        severity: '{{ .CommonLabels.severity }}'

  - name: 'slack-warnings'
    slack_configs:
      - channel: '#alerts-warnings'
        text: '{{ .CommonAnnotations.description }}'
```

### Inhibition — Suppress Child Alerts During Parent Incidents

Inhibition suppresses lower-level alerts when a higher-level alert is already firing.

**The most important use case:**
```
Problem without inhibition:
  Kubernetes node goes down →
  → NodeDown alert fires
  → 20 PodCrashLooping alerts fire (pods on that node)
  → 5 ServiceUnavailable alerts fire
  → 2 HighErrorRate alerts fire
  = 28 pages for 1 incident

With inhibition:
  NodeDown fires → all child alerts suppressed
  = 1 page for 1 incident
```

```yaml
inhibit_rules:
  # If NodeDown is firing, suppress pod/service alerts on the same node
  - source_match:
      alertname: NodeDown
    target_match_re:
      alertname: 'PodCrashLooping|ServiceUnavailable|HighErrorRate'
    equal: ['cluster', 'node']   # only suppress if same node label matches

  # If cluster is completely down, suppress individual service alerts
  - source_match:
      alertname: ClusterUnreachable
    target_match_re:
      alertname: '.*'
    equal: ['cluster']

  # If there's a known deployment in progress, suppress latency alerts
  - source_match:
      alertname: DeploymentInProgress
    target_match:
      alertname: HighLatency
    equal: ['service', 'env']
```

### Silences — Planned Maintenance

During planned maintenance, silence alerts rather than disable them:

```bash
# Via Alertmanager UI or amtool CLI

# Silence checkout-service alerts for 2 hours during maintenance
amtool silence add \
  --alertmanager.url=http://alertmanager:9093 \
  --duration=2h \
  --comment="Planned DB maintenance 2026-07-31" \
  service="checkout" severity=~"critical|warning"

# List active silences
amtool silence query --alertmanager.url=http://alertmanager:9093

# Expire a silence early
amtool silence expire --alertmanager.url=http://alertmanager:9093 <silence-id>
```

---

## Part 6 — SLO-Based Alerting (Best Practice)

SLO burn rate alerting is the most principled approach to alert tuning. Instead of arbitrary thresholds, you alert based on how fast you're consuming your error budget.

### Concept: Error Budget Burn Rate

```
SLO: 99.9% availability over 30 days
Error budget: 0.1% = 43.2 minutes/month of downtime allowed

Burn rate 1x = consuming budget at exactly SLO pace
             = you'll use all budget in exactly 30 days

Burn rate 2x = consuming budget 2x faster than allowed
             = you'll use all budget in 15 days

Burn rate 14x = extremely fast consumption
              = you'll exhaust 1 hour of budget in 5 minutes
              = PAGE NOW
```

### Multi-Window Multi-Burn-Rate Alerting

This is the Google SRE Book recommendation:

```yaml
# Fast burn: 14x burn rate over 1h AND 5m windows → critical page
- alert: SLOBurnRateCritical
  expr: |
    (
      job:slo_error_rate:rate1h{job="checkout"} > (14 * 0.001)
      AND
      job:slo_error_rate:rate5m{job="checkout"} > (14 * 0.001)
    )
  for: 2m
  labels:
    severity: critical
  annotations:
    summary: "Checkout burning error budget at 14x rate"
    description: |
      At current rate, error budget will be exhausted in
      {{ div 60 14 | int }} hours.

# Slow burn: 3x burn rate over 6h AND 30m → warning
- alert: SLOBurnRateWarning
  expr: |
    (
      job:slo_error_rate:rate6h{job="checkout"} > (3 * 0.001)
      AND
      job:slo_error_rate:rate30m{job="checkout"} > (3 * 0.001)
    )
  for: 15m
  labels:
    severity: warning
```

**Why two windows?** The short window (5m) catches fast incidents. The long window (1h) confirms it's sustained, not a blip. Both must be true to fire.

**Why this beats threshold alerts:**
- Self-calibrates to your actual SLO
- Automatically scales with traffic
- Tells you the BUSINESS IMPACT (budget burn rate), not just a number

---

## Part 7 — Noise Reduction Techniques

### Technique 1: Dead Man's Switch (Watchdog Alert)

A "watchdog" alert proves your alerting pipeline is alive.

```yaml
# This alert fires when everything is NORMAL
# If it STOPS firing → your alerting pipeline is broken
- alert: Watchdog
  expr: vector(1)
  labels:
    severity: none
  annotations:
    summary: "Alerting pipeline is working"
```

Configure PagerDuty/OpsGenie to page you if the Watchdog alert DISAPPEARS (heartbeat monitoring).

### Technique 2: Alert Deduplication

Alertmanager deduplicates automatically — if 10 identical alerts arrive in a `group_interval` window, only 1 notification is sent.

But for deduplication to work, alert labels must be CONSISTENT:
```yaml
# Bad: timestamp in label = never deduplicates
labels:
  alert_time: "{{ now }}"    # DON'T DO THIS

# Good: stable labels only
labels:
  service: checkout
  severity: critical
```

### Technique 3: Aggregation Before Alerting

Don't alert on individual instances — aggregate first:

```promql
# Bad: alerts once per pod (50 pods = 50 alerts)
rate(http_errors_total{pod=~"checkout-.*"}[5m]) > 0.01

# Good: aggregate across all pods, then alert
sum(rate(http_errors_total{service="checkout"}[5m]))
/
sum(rate(http_requests_total{service="checkout"}[5m]))
> 0.01
```

### Technique 4: Absent/Missing Metric Alerts

Alert when metrics STOP coming (service died without sending errors):

```yaml
- alert: CheckoutMetricsMissing
  expr: absent(rate(http_requests_total{service="checkout"}[5m]))
  for: 5m
  labels:
    severity: critical
  annotations:
    summary: "No metrics from checkout-service for 5 minutes"
    description: "Service may be down or monitoring broken"
```

### Technique 5: Time-of-Day Routing

Different people handle alerts differently during business hours vs nights:

```yaml
# Alertmanager time-based routing
routes:
  - match:
      severity: warning
    receiver: 'business-hours-slack'
    active_time_intervals:
      - business-hours

  - match:
      severity: warning
    receiver: 'dev/null'   # warnings don't wake anyone at 3am
    mute_time_intervals:
      - business-hours

time_intervals:
  - name: business-hours
    time_intervals:
      - weekdays: ['monday:friday']
        times:
          - start_time: '09:00'
            end_time:   '18:00'
```

---

## Part 8 — Dynatrace Alerting Tuning

Dynatrace uses its Davis AI engine for anomaly detection — different from Prometheus rule-based alerting.

### Davis AI Baselines

Davis automatically learns:
- What is "normal" CPU/memory/latency for each service
- Seasonal patterns (higher traffic Monday mornings)
- Deployment-correlated changes

So instead of `CPU > 70%`, Davis fires: "CPU is 3x above its normal baseline for this time of day."

### Custom Anomaly Detection Thresholds

```
Dynatrace UI: Settings → Anomaly Detection → Services

Per-service overrides:
  Response time: alert if p90 > 2000ms for 5 minutes
  Error rate: alert if > 0.5% for 5 minutes
  Request throughput drop: alert if drops > 50% vs baseline
```

### Alert Profile Tuning in Dynatrace

```
Settings → Alerting → Alerting profiles

Profile: Critical Production
  Severity: Availability, Error, Performance
  Management zone: Production only
  Delay: 0 minutes (immediate)
  → Sends to PagerDuty

Profile: Warning
  Severity: Resource, Custom
  Management zone: Production
  Delay: 5 minutes (must persist)
  → Sends to Slack only

Profile: Staging/Dev
  All severities
  → Sends to email only, no pages
```

### Problem Correlation (Dynatrace's Inhibition Equivalent)

Dynatrace automatically correlates related anomalies into one "Problem" card:
- 5 services degraded because of a DB issue → ONE problem, not 5 alerts
- Root cause identified: "Database connection pool exhausted"

This is Davis doing what Alertmanager inhibition rules do manually.

---

## Part 9 — Alert Review Process (Ongoing Maintenance)

Alerting is never "done." You must continuously review and tune.

### Weekly Alert Review

```
Every Monday:
1. Pull last week's alert history
2. For each alert that fired:
   - Was it actionable? (could oncall fix it?)
   - Was it a duplicate? (same issue, multiple alerts)
   - Was it a false positive? (no real user impact)
   - Was there a runbook?
3. For each false positive: raise threshold or increase `for:` window
4. For each duplicate: add inhibition rule
5. For each missing runbook: write one
```

### Alert Scoring Matrix

Score each alert: 1 (bad) to 5 (good):

| Dimension | 1 | 3 | 5 |
|---|---|---|---|
| Actionable | Nothing to do | Partial action | Clear action |
| Urgent | Can wait days | Can wait hours | Must fix in <30min |
| Signal quality | Always noise | Sometimes real | Always real |
| Runbook exists | No | Partial | Yes, with steps |
| User impact | None | Indirect | Direct |

Alerts scoring < 3 average should be downgraded (warning → ticket) or deleted.

### Alert Tiering

```
TIER 1 — PAGE (critical, 24/7)
  Criteria: user-facing impact, revenue impact, SLO breach imminent
  Examples: error_rate > 1%, p99 > 2s, service down
  Response SLA: acknowledge in 5 min, resolve in 30 min

TIER 2 — NOTIFY (warning, business hours)
  Criteria: degradation trending toward Tier 1, no current user impact
  Examples: disk > 80%, memory leak trend, latency increase
  Response SLA: acknowledge in 4h, resolve in 24h

TIER 3 — TICKET (info, no notification)
  Criteria: good-to-know, capacity planning, cleanup needed
  Examples: disk > 60%, deprecated API usage, certificate expiry in 30d
  Response SLA: next sprint
```

---

## Part 10 — Common Mistakes and Fixes

| Mistake | Symptom | Fix |
|---|---|---|
| Alert on raw counters | Fires at every restart (counter resets to 0) | Use `rate()` or `increase()` over a window |
| No `for:` duration | Flapping on every deploy or GC pause | Add `for: 5m` minimum |
| Alert on average latency | Misses tail latency suffering | Use `histogram_quantile(0.99, ...)` |
| Same alert for staging and prod | Staging noise wakes oncall | Add `env="production"` label filter |
| No inhibition rules | Alert storms (1 incident = 30 pages) | Add parent→child inhibition |
| No grouping | Alert storms (50 pods = 50 pages) | Group by service + alertname |
| Never review/prune alerts | Alert graveyard grows | Weekly review, delete stale alerts |
| Runbook links broken/missing | Oncall opens alert with no guidance | Audit runbook URLs quarterly |
| Alert name too generic | "HighLatency" — which service?! | Always scope: "CheckoutHighLatency" |
| `repeat_interval` too short | Same alert pages every 15 min all night | Set `repeat_interval: 4h` minimum |
| Alert on ALL 5xx | Includes client errors (502 from LB) | Filter to application 5xx only |
| Threshold too tight | CPU > 50% alerts constantly | Use 80%+ and confirm with latency impact |
