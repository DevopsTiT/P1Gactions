# Alert Tuning Glossary — SRE Beginner Reference

Every term from main.md explained in plain language. One entry per term.

---

**Alert Fatigue**
When on-call engineers receive so many alerts — mostly false or unimportant — that they start ignoring all of them. Dangerous because the one real critical alert gets ignored too. The root cause of most major outages that "nobody noticed in time."

**False Positive**
An alert that fires when nothing is actually wrong for users. Like a smoke detector that goes off every time you make toast. Wastes engineer time and trains people to ignore alerts.

**False Negative**
A real problem that happens but NO alert fires. The worst kind — silent failure. Users are impacted but oncall doesn't know. Happens when thresholds are too high or coverage gaps exist.

**Actionable Alert**
An alert where the on-call engineer can actually DO something right now to fix it. "Disk full" is actionable (delete files, expand disk). "Request count increased" is not actionable (what do I do about that?).

**Oncall / On-Call Engineer**
The engineer who is "on rotation" to respond to production alerts during nights/weekends/holidays. They carry a pager (or phone). Alert tuning directly protects this person's sleep and sanity.

**Prometheus**
An open-source monitoring system that scrapes metrics from your services and evaluates alert rules. When a rule's condition is met, Prometheus sends the alert to Alertmanager. Think of it as the watchman who notices problems and radios them in.

**Alertmanager**
The component that receives alerts FROM Prometheus and decides: who to notify, how to group similar alerts, when to silence them, and which alerts to suppress. The dispatcher that routes the watchman's radio calls.

**PromQL**
Prometheus Query Language. The language used to write alert expressions. Example: `rate(http_errors[5m]) > 0.01` means "if the 5-minute error rate exceeds 1%, fire this alert."

**`for:` duration**
A field in Prometheus alert rules that says "only fire this alert if the condition has been TRUE continuously for this long." `for: 5m` means the condition must be breaching for 5 full minutes before paging anyone. Prevents false positives from brief spikes.

**Flapping**
When an alert rapidly alternates between firing and resolved — often because the metric bounces around the threshold. Like a fire alarm that goes off and stops every 2 minutes. Extremely annoying and signals a badly tuned threshold or too-short `for:` window.

**Hysteresis**
Using DIFFERENT thresholds to FIRE an alert vs to RESOLVE it. Fire at 80%, resolve only when back below 60%. This gap prevents flapping near the threshold. Named after the physics concept where a system's behavior depends on its history.

**Threshold**
The numeric value at which an alert fires. "Alert if error rate > 1%" — the 1% is the threshold. Setting it too low = too many false positives. Too high = miss real problems (false negatives).

**Alert Storm**
When a single incident (e.g., one node dies) causes dozens or hundreds of separate alerts to fire simultaneously. Overwhelms oncall and hides the root cause in noise. Prevented by grouping and inhibition rules.

**Grouping**
Alertmanager feature that bundles multiple related alerts into ONE notification. Example: 50 pods crashing on the same service → one Slack message saying "50 pods crashing" instead of 50 separate messages.

**`group_by`**
The Alertmanager config field that defines WHICH labels make alerts "the same group." Alerts with matching values for `group_by` labels get bundled together into one notification.

**`group_wait`**
How long Alertmanager waits after the FIRST alert in a group before sending the notification. During this window, more alerts can join the group. Typical value: 30 seconds.

**`group_interval`**
After the initial grouped notification is sent, how long to wait before sending a new notification for NEW alerts added to the same group. Typical value: 5 minutes.

**`repeat_interval`**
How long to wait before re-sending a notification for an alert that is STILL firing (a reminder). Set this too short (15 min) and oncall gets woken repeatedly all night. Typical value: 4 hours.

**Routing**
The Alertmanager process of deciding which receiver (PagerDuty, Slack, email) gets each alert, based on labels like `team`, `severity`, `env`. Like a postal sorting office — each letter (alert) goes to a different address.

**Receiver**
An Alertmanager destination for notifications. Examples: a PagerDuty integration, a Slack channel, an email address, a webhook. Each receiver has its own config.

**Inhibition**
An Alertmanager rule that suppresses (mutes) certain alerts when a more important alert is already firing. Example: suppress all pod crash alerts when a NodeDown alert is firing for the same node. Prevents alert storms.

**Source Alert (Inhibition)**
The alert that CAUSES the inhibition. When this fires, it suppresses the target alerts. Example: `NodeDown` is the source.

**Target Alert (Inhibition)**
The alert that gets SUPPRESSED by the inhibition rule. Example: `PodCrashLooping` is the target when `NodeDown` is the source.

**Silence**
A manual, time-limited suppression of alerts in Alertmanager. Used during planned maintenance to prevent noise. You set start time, end time, and which labels to match. Does NOT disable monitoring — alerts still evaluate, they're just not notified.

**amtool**
The command-line tool for interacting with Alertmanager. Used to add/remove silences, test routing, and inspect current alert state. Like the CLI remote control for Alertmanager.

**Symptom-Based Alert**
An alert that fires when USERS are experiencing a problem right now. Example: "error rate > 1%." Preferred for pages because it directly measures user impact, not internal state.

**Cause-Based Alert**
An alert that fires when something MIGHT cause a problem in the future. Example: "disk > 80%." Better suited for warnings/tickets, not 3am pages, because users may not be impacted yet.

**Rate vs Count**
Rate measures events PER SECOND over a time window. Count is the raw total. For alerts, rate is almost always better because it scales with traffic: 100 errors/hour means something different at 100 req/s vs 10,000 req/s.

**`rate()` (PromQL)**
A PromQL function that calculates the per-second average rate of increase of a counter over a time window. `rate(http_errors_total[5m])` = average errors per second over the last 5 minutes.

**`histogram_quantile()` (PromQL)**
A PromQL function that calculates a percentile from a histogram metric. `histogram_quantile(0.99, rate(duration_bucket[5m]))` = p99 latency over last 5 minutes.

**p99 Latency**
The latency value that 99% of requests are FASTER than. If p99 = 500ms, 99% of users see responses in under 500ms, but 1% may wait much longer. SREs alert on p99 because averages hide tail suffering.

**SLO (Service Level Objective)**
A target reliability commitment. Example: "checkout must succeed 99.9% of the time." SLO-based alerting fires based on how fast you're CONSUMING your allowed failure budget, not on raw thresholds.

**Error Budget**
The allowable amount of failures within an SLO period. If SLO = 99.9% uptime over 30 days, error budget = 0.1% = 43.2 minutes of acceptable downtime per month.

**Burn Rate**
How fast you're consuming your error budget compared to the allowed pace. Burn rate 1x = exactly on pace. Burn rate 14x = exhausting 14x faster than allowed — will run out of budget in 1/14 of the period.

**Multi-Window Alerting**
Using two time windows (e.g., 5 minutes AND 1 hour) in the same alert expression. The short window catches fast incidents. The long window confirms the problem is sustained. Both must be true to fire — prevents false positives from brief spikes.

**Recording Rule**
A Prometheus feature that pre-computes an expensive PromQL expression and stores the result as a new metric. Used to make SLO burn-rate alerts evaluate faster. Without recording rules, computing 6-hour rates in every alert evaluation is slow.

**Dead Man's Switch / Watchdog Alert**
An alert that fires when everything is WORKING NORMALLY. You configure your pager tool to notify you if this "heartbeat" alert DISAPPEARS — meaning your alerting pipeline itself has broken. Ensures you always know if monitoring is down.

**`absent()` (PromQL)**
A PromQL function that returns a value only when NO time series match the selector. Used to alert when metrics STOP coming — the service crashed and stopped sending data.

**PagerDuty**
A commercial on-call management platform. Receives alerts from Alertmanager/Dynatrace, manages on-call schedules, escalation policies, and acknowledgment workflows. The tool that actually calls or texts the on-call engineer.

**OpsGenie**
Similar to PagerDuty — an on-call alerting and incident management platform, now owned by Atlassian.

**Alerting Profile (Dynatrace)**
A Dynatrace configuration object that filters which problems get sent to which notification channel. You can have different profiles for different management zones (prod vs staging) with different severities and delays.

**Davis AI (Dynatrace)**
Dynatrace's built-in AI/ML engine for anomaly detection. Instead of static thresholds, Davis learns what "normal" looks like for each service and alerts when it deviates significantly. It also correlates related anomalies into one "Problem" card.

**Management Zone (Dynatrace)**
A logical grouping of monitored entities in Dynatrace (e.g., "Production," "Staging," "Team-Payments"). Alerting profiles and permissions are applied per management zone, preventing staging alerts from paging production oncall.

**Problem Card (Dynatrace)**
Dynatrace's representation of an incident — groups all related anomalies together with root cause analysis. One Problem card = one notification, even if 10 services are affected. Equivalent to Alertmanager's grouping + inhibition combined.

**Maintenance Window (Dynatrace)**
A scheduled time period where Dynatrace suppresses alerts for specific entities. Used during planned deployments or maintenance. Similar to Alertmanager silences.

**Runbook**
A documented set of steps for handling a specific alert. "When CheckoutHighErrorRate fires, do steps 1, 2, 3." The absence of a runbook means oncall must figure out the fix from scratch at 3am — a failure mode in itself.

**Alert Tiering**
Categorizing alerts by urgency/severity into tiers (Critical → page, Warning → Slack, Info → ticket). Each tier has different routing and response SLAs. Prevents every problem from being treated as equally urgent.

**Deduplication**
Alertmanager's ability to recognize that multiple incoming alerts are "the same" and only send one notification. Relies on consistent label values — if labels change every alert, deduplication breaks.

**Cardinality (Metric)**
The number of unique label value combinations for a metric. High-cardinality labels (like `user_id`) create millions of time series and can crash Prometheus. Keep alert labels low-cardinality: `service`, `method`, `status`, `env`.

**`promtool`**
The command-line tool bundled with Prometheus for validating rule files (`promtool check rules`), running unit tests against alert rules, and debugging PromQL queries. Use it before applying new alert rules to production.

**SIGHUP**
A Unix signal sent to a process to tell it to reload its configuration file without restarting. `kill -HUP <pid>` tells Alertmanager or Prometheus to re-read their config. Safer than a full restart because there's no downtime.

**Alert Noise Report**
A regular (weekly/monthly) review of which alerts fired, how often, how long they lasted, and whether they were actionable. The data-driven input for tuning decisions. Without this, alert tuning is guesswork.
