# Alert Tuning — Commands Reference

---

## Phase 0 — Audit Current Alert State

```bash
# List all firing alerts in Prometheus
curl -s http://prometheus:9090/api/v1/alerts | jq '.data.alerts[] | {name: .labels.alertname, state: .state, severity: .labels.severity}'

# Count alerts by state
curl -s http://prometheus:9090/api/v1/alerts | jq '[.data.alerts[] | .state] | group_by(.) | map({state: .[0], count: length})'

# List alerts that have been firing for more than 1 hour (chronic noise)
curl -s http://prometheus:9090/api/v1/alerts | \
  jq --argjson cutoff $(date -v-1H +%s) \
  '.data.alerts[] | select(.state == "firing") | select((.activeAt | fromdateiso8601) < $cutoff) | .labels.alertname'

# List all defined alert rules
curl -s http://prometheus:9090/api/v1/rules | jq '.data.groups[].rules[] | select(.type=="alerting") | {name: .name, state: .state}'

# Check Alertmanager current alerts
curl -s http://alertmanager:9093/api/v2/alerts | jq '.[] | {name: .labels.alertname, severity: .labels.severity, startsAt: .startsAt}'

# List active silences
curl -s http://alertmanager:9093/api/v2/silences | jq '.[] | select(.status.state=="active") | {id: .id, comment: .comment, endsAt: .endsAt}'
```

---

## Phase 1 — Check Alert Firing History (Noise Identification)

```bash
# Query Prometheus: how many times did this alert fire in the last 7 days?
# (requires Prometheus recording rules or Thanos/Mimir long-term storage)
curl -s "http://prometheus:9090/api/v1/query_range" \
  --data-urlencode 'query=ALERTS{alertname="HighErrorRate",alertstate="firing"}' \
  --data-urlencode 'start=2026-07-24T00:00:00Z' \
  --data-urlencode 'end=2026-07-31T00:00:00Z' \
  --data-urlencode 'step=1h' | jq '.data.result | length'

# Check how often an alert flaps (changes state)
# Look at Alertmanager logs for alert transitions
kubectl logs -n monitoring deployment/alertmanager | grep -E "Firing|Resolved" | grep "HighErrorRate" | wc -l

# Check alert evaluation errors
curl -s http://prometheus:9090/api/v1/rules | \
  jq '.data.groups[].rules[] | select(.type=="alerting") | select(.lastError != null) | {name: .name, error: .lastError}'
```

---

## Phase 2 — Test Alert Rules Without Firing

```bash
# Install promtool (comes with Prometheus binary)
which promtool || brew install prometheus

# Validate alert rule syntax
promtool check rules /path/to/alert-rules.yaml

# Unit test your alert rules (requires test file)
promtool test rules /path/to/alert-rules-test.yaml

# Manually evaluate a PromQL expression to see current value
curl -s "http://prometheus:9090/api/v1/query" \
  --data-urlencode 'query=rate(http_requests_total{service="checkout", status=~"5.."}[5m]) / rate(http_requests_total{service="checkout"}[5m])' | \
  jq '.data.result[] | {metric: .metric, value: .value[1]}'

# Check what the alert threshold would fire on
curl -s "http://prometheus:9090/api/v1/query" \
  --data-urlencode 'query=rate(http_requests_total{service="checkout", status=~"5.."}[5m]) / rate(http_requests_total{service="checkout"}[5m]) > 0.01' | \
  jq '.data.result'
```

---

## Phase 3 — Write and Apply Alert Rule Unit Tests

```bash
# Create a test file for alert rules
cat > /tmp/alert-rules-test.yaml << 'EOF'
rule_files:
  - alert-rules.yaml

evaluation_interval: 1m

tests:
  - interval: 1m
    input_series:
      # Simulate high error rate
      - series: 'http_requests_total{service="checkout", status="500"}'
        values: '0 10 20 30 40 50 60 70'
      - series: 'http_requests_total{service="checkout", status="200"}'
        values: '0 100 200 300 400 500 600 700'

    alert_rule_test:
      # Alert should NOT fire in first 5 minutes (for: 5m)
      - eval_time: 3m
        alertname: CheckoutHighErrorRate
        exp_alerts: []

      # Alert SHOULD fire after 5 minutes of sustained breach
      - eval_time: 8m
        alertname: CheckoutHighErrorRate
        exp_alerts:
          - exp_labels:
              severity: critical
              service: checkout
EOF

promtool test rules /tmp/alert-rules-test.yaml
```

---

## Phase 4 — Manage Silences via amtool

```bash
# Install amtool
brew install alertmanager  # or download from GitHub releases

# Configure amtool
cat > ~/.amtool/config.yml << 'EOF'
alertmanager.url: http://alertmanager:9093
author: your-name
EOF

# Create a silence for planned maintenance (2 hours)
amtool silence add \
  --alertmanager.url=http://alertmanager:9093 \
  --duration=2h \
  --comment="DB maintenance window 2026-07-31 by your-name" \
  service="checkout" env="production"

# Create silence for specific alert during deploy
amtool silence add \
  --alertmanager.url=http://alertmanager:9093 \
  --duration=30m \
  --comment="Deploy v1.5.0 checkout service" \
  alertname="CheckoutHighLatency" service="checkout"

# List all active silences
amtool silence query --alertmanager.url=http://alertmanager:9093

# Query silence for specific matcher
amtool silence query service="checkout"

# Expire (delete) a silence before it ends
amtool silence expire --alertmanager.url=http://alertmanager:9093 <silence-id>

# List silences expiring in the next hour
amtool silence query --alertmanager.url=http://alertmanager:9093 | grep "$(date -v+1H '+%Y-%m-%d')"
```

---

## Phase 5 — Reload Alertmanager Config Without Restart

```bash
# Send SIGHUP to reload config
kubectl exec -n monitoring deployment/alertmanager -- \
  kill -HUP 1

# OR via HTTP API
curl -X POST http://alertmanager:9093/-/reload

# Verify config was loaded without errors
curl -s http://alertmanager:9093/-/ready
curl -s http://alertmanager:9093/api/v1/status | jq '.data.configJSON' | head -20

# Reload Prometheus rules without restart
curl -X POST http://prometheus:9090/-/reload

# Verify rules reloaded
curl -s http://prometheus:9090/api/v1/rules | jq '.data.groups | length'
```

---

## Phase 6 — Check Alertmanager Routing

```bash
# Test where an alert would be routed (dry-run)
amtool config routes test \
  --alertmanager.url=http://alertmanager:9093 \
  --config.file=/etc/alertmanager/alertmanager.yml \
  alertname="CheckoutHighErrorRate" service="checkout" severity="critical"

# Show full routing tree
amtool config routes show --alertmanager.url=http://alertmanager:9093

# Test a set of labels against routing config
curl -X POST http://alertmanager:9093/api/v1/alerts \
  -H "Content-Type: application/json" \
  -d '[{
    "labels": {
      "alertname": "TestAlert",
      "service": "checkout",
      "severity": "critical",
      "env": "production"
    },
    "annotations": {
      "summary": "Test alert for routing validation"
    }
  }]'

# Then immediately check who received it
curl -s http://alertmanager:9093/api/v2/alerts | jq '.[] | select(.labels.alertname=="TestAlert")'
```

---

## Phase 7 — SLO Burn Rate Alert Setup

```bash
# Create recording rules for SLO calculations (faster than raw PromQL in alerts)
cat > /tmp/slo-recording-rules.yaml << 'EOF'
groups:
  - name: slo-checkout
    interval: 30s
    rules:
      # 5-minute error rate
      - record: job:slo_error_rate:rate5m
        expr: |
          sum(rate(http_requests_total{service="checkout", status=~"5.."}[5m]))
          /
          sum(rate(http_requests_total{service="checkout"}[5m]))
        labels:
          job: checkout

      # 1-hour error rate
      - record: job:slo_error_rate:rate1h
        expr: |
          sum(rate(http_requests_total{service="checkout", status=~"5.."}[1h]))
          /
          sum(rate(http_requests_total{service="checkout"}[1h]))
        labels:
          job: checkout

      # 6-hour error rate
      - record: job:slo_error_rate:rate6h
        expr: |
          sum(rate(http_requests_total{service="checkout", status=~"5.."}[6h]))
          /
          sum(rate(http_requests_total{service="checkout"}[6h]))
        labels:
          job: checkout
EOF

# Validate
promtool check rules /tmp/slo-recording-rules.yaml

# Apply in Kubernetes
kubectl create configmap slo-rules --from-file=/tmp/slo-recording-rules.yaml -n monitoring
kubectl rollout restart deployment/prometheus -n monitoring
```

---

## Phase 8 — Query Alert History from PagerDuty API

```bash
# Requires PAGERDUTY_TOKEN env var
export PAGERDUTY_TOKEN="your_token"

# List incidents from last 7 days
curl -s "https://api.pagerduty.com/incidents?since=2026-07-24T00:00:00Z&until=2026-07-31T00:00:00Z&limit=100" \
  -H "Authorization: Token token=$PAGERDUTY_TOKEN" \
  -H "Accept: application/vnd.pagerduty+json;version=2" | \
  jq '.incidents[] | {title: .title, created: .created_at, urgency: .urgency, service: .service.name}'

# Count incidents per service
curl -s "https://api.pagerduty.com/incidents?since=2026-07-24T00:00:00Z&limit=100" \
  -H "Authorization: Token token=$PAGERDUTY_TOKEN" \
  -H "Accept: application/vnd.pagerduty+json;version=2" | \
  jq '[.incidents[].service.name] | group_by(.) | map({service: .[0], count: length}) | sort_by(.count) | reverse'

# Find alerts that auto-resolved quickly (likely false positives)
curl -s "https://api.pagerduty.com/incidents?since=2026-07-24T00:00:00Z&limit=100&statuses[]=resolved" \
  -H "Authorization: Token token=$PAGERDUTY_TOKEN" \
  -H "Accept: application/vnd.pagerduty+json;version=2" | \
  jq '.incidents[] | select((.resolved_at | fromdateiso8601) - (.created_at | fromdateiso8601) < 300) | {title: .title, duration_seconds: ((.resolved_at | fromdateiso8601) - (.created_at | fromdateiso8601))}'
```

---

## Phase 9 — Dynatrace Alert Tuning via API

```bash
export DT_URL="https://TENANT.live.dynatrace.com"
export DT_TOKEN="your_api_token"

# List all anomaly detection configurations for services
curl -s "$DT_URL/api/config/v1/anomalyDetection/services" \
  -H "Authorization: Api-Token $DT_TOKEN" | jq '.'

# Get alerting profiles
curl -s "$DT_URL/api/config/v1/alertingProfiles" \
  -H "Authorization: Api-Token $DT_TOKEN" | jq '.values[] | {id: .id, name: .name}'

# Get a specific alerting profile
curl -s "$DT_URL/api/config/v1/alertingProfiles/<profile-id>" \
  -H "Authorization: Api-Token $DT_TOKEN" | jq '.'

# List maintenance windows
curl -s "$DT_URL/api/config/v1/maintenanceWindows" \
  -H "Authorization: Api-Token $DT_TOKEN" | jq '.values[] | {id: .id, name: .name}'

# Create maintenance window (suppress alerts during deploy)
curl -X POST "$DT_URL/api/config/v1/maintenanceWindows" \
  -H "Authorization: Api-Token $DT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Checkout deploy 2026-07-31",
    "description": "Deploying v1.5.0",
    "type": "PLANNED",
    "suppression": "DETECT_PROBLEMS_AND_ALERT",
    "suppressionType": "DONT_ALERT_ON_AFFECTED_ENTITIES_PROBLEMS",
    "schedule": {
      "recurrenceType": "ONCE",
      "start": "2026-07-31 22:00",
      "end": "2026-07-31 23:00",
      "zoneId": "Asia/Tokyo"
    },
    "scope": {
      "entities": ["SERVICE-checkout-id"],
      "matches": []
    }
  }'
```

---

## Phase 10 — Generate Alert Noise Report

```bash
# Count total alerts fired per alertname last 24h in Alertmanager logs
kubectl logs -n monitoring deployment/alertmanager --since=24h | \
  grep "Firing" | \
  grep -oP 'alertname="[^"]+"' | \
  sort | uniq -c | sort -rn | head -20

# Find which services generate most alert volume
kubectl logs -n monitoring deployment/alertmanager --since=168h | \
  grep "Firing" | \
  grep -oP 'service="[^"]+"' | \
  sort | uniq -c | sort -rn

# Check flapping alerts (fired AND resolved more than 5 times in 24h)
kubectl logs -n monitoring deployment/alertmanager --since=24h | \
  grep -E "Firing|Resolved" | \
  grep -oP 'alertname="[^"]+"' | \
  sort | uniq -c | sort -rn | awk '$1 > 10'
```
