# Dynatrace — SRE Deep Dive

> **Who this is for:** An SRE who has the system running but wants to understand what Dynatrace actually does, how each piece connects, what to look at during an incident, and how all the Terraform config in this project translates into real monitoring behavior.

---

## Decision Tree — When to Use Which DT Feature

```
Something is wrong. Where do I start?
         │
         ├── I got a PagerDuty alert
         │         └── → Open the Problem Event → Root Cause Analysis section → linked traces
         │
         ├── Service is slow (latency P99 spiked)
         │         ├── → Service view → Response time breakdown
         │         └── → Distributed traces → find the slow span (DB? External call? GC?)
         │
         ├── Error rate is high
         │         ├── → Service view → Failure rate → which endpoint fails?
         │         └── → Log Analytics → filter level=ERROR → find the exception
         │
         ├── I want to know if the deploy broke anything
         │         └── → Deployments view → automatic baseline comparison (before vs after)
         │
         ├── CPU / memory is high
         │         └── → Process Group view → JVM heap trend → G1GC pause time
         │
         ├── I want to check our SLO status
         │         └── → SLOs → error budget remaining → burn rate chart
         │
         └── I want to confirm the service is up from user perspective
                   └── → Synthetic Monitors → last check status per location
```

---

## Part 1 — Dynatrace Architecture (What is running where)

```
┌─────────────────────────────────────────────────────────────────────┐
│  EKS CLUSTER (one per environment)                                  │
│                                                                     │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ← application pods      │
│  │payment   │  │order     │  │notif     │                           │
│  │-service  │  │-service  │  │-service  │                           │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘                          │
│       │              │              │  ← metrics + traces via OTLP   │
│       └──────────────┴──────────────┤                               │
│                                     ▼                               │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │  OneAgent DaemonSet (one pod per NODE)                      │    │
│  │  • hooks into JVM via JVMTI (auto-instruments Spring Boot)  │    │
│  │  • reads /proc/<pid>/... for CPU/memory                     │    │
│  │  • reads container logs from /var/lib/docker/containers/    │    │
│  │  • collects host-level network stats                        │    │
│  └─────────────────────────────┬───────────────────────────────┘    │
│                                 │ sends to ActiveGate               │
│  ┌──────────────────────────────▼──────────────────────────────┐    │
│  │  ActiveGate (2 replicas in prod, spread across AZs)         │    │
│  │  • proxies all OneAgent data to DT tenant                   │    │
│  │  • polls K8s API for pod counts, deployment health          │    │
│  │  • receives OTLP traces from application pods               │    │
│  │  • ships container logs to DT log analytics                 │    │
│  └─────────────────────────────┬───────────────────────────────┘    │
└─────────────────────────────────┼───────────────────────────────────┘
                                  │ HTTPS to DT tenant
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│  DYNATRACE TENANT (SaaS, managed by Dynatrace Inc.)                 │
│                                                                     │
│  Receives:  metrics, traces, logs, K8s metadata                     │
│  Creates:   Problems (when metric events fire)                      │
│  Evaluates: SLOs (rolling 30-day windows)                           │
│  Runs:      Synthetics (HTTP checks from Tokyo/Singapore)           │
│  Fires:     Notifications (PagerDuty, Slack)                        │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Part 2 — OneAgent (The Invisible Instrumentation Layer)

### What it is

OneAgent is a Linux process running on every EKS node as a Kubernetes DaemonSet. It is not a sidecar (not per-pod) — it runs once per node and monitors ALL pods on that node simultaneously.

### How it instruments Java without code changes

OneAgent uses the Java Tool Interface (JVMTI) — a C API built into every JVM. When a JVM starts, the OS can attach a JVMTI agent to it. OneAgent:

```
1. Detects the java process starting on the node
2. Attaches its JVMTI agent to the JVM
3. The agent instruments methods by modifying bytecode in-memory:
   - HTTP request entry/exit: wraps every @RestController method
   - DB calls: wraps every JDBC execute() call
   - External HTTP calls: wraps every RestTemplate / WebClient call
   - JVM heap: reads from JVM memory management API
   - GC events: hooks into GC notification listeners
   - Thread pool: monitors Tomcat/Netty thread pool metrics

This happens IN the running JVM — no code changes, no annotations, no SDK.
```

**What DT captures automatically from Spring Boot:**
```
HTTP requests:
  - URL, method, status code
  - Response time (from request entry to response flush)
  - Error rate (4xx is "application error", 5xx is "server error")
  - Throughput (requests per minute)

Database (JDBC / JPA / Hibernate):
  - SQL statement (parameterized — no actual values for security)
  - Execution time
  - Number of rows fetched
  - Connection pool wait time

JVM internals:
  - Heap used (bytes) vs Xmx
  - GC pause duration (G1GC minor + major)
  - Thread count (total, runnable, blocked)
  - Class loading

Spring Boot process:
  - Process CPU % (this JVM's share of the host CPU)
  - RSS memory (total RAM used by the JVM process)
```

### The OpenTelemetry path (distributed traces)

OneAgent auto-instruments within a single service. For cross-service traces (order-service calls payment-service), the application also sends OTLP spans:

```yaml
# In Helm values.yaml for all services:
env:
  - name: OTEL_EXPORTER_OTLP_ENDPOINT
    value: "http://dynatrace-activegate.dynatrace.svc:4318"
  - name: OTEL_SERVICE_NAME
    value: "payment-service"
```

```
What happens when order-service calls payment-service:

1. order-service Spring Boot app (via micrometer-tracing-bridge-otel):
   - Creates a trace span for the outgoing HTTP call
   - Injects trace context into request headers:
     traceparent: 00-abc123...-def456...-01

2. payment-service receives the request:
   - Spring reads the traceparent header
   - Creates a child span linked to the same trace ID

3. Both services export spans to ActiveGate via OTLP (port 4318)

4. Dynatrace stitches them together into one distributed trace:
   order-service: POST /api/v1/orders   [120ms]
     └── HTTP call to payment-service  [85ms]
           └── payment-service: POST /api/v1/payments  [80ms]
                 └── JDBC INSERT payments               [35ms]

Result: you can see the FULL call chain with timing for each step.
This shows you WHERE the latency is — DB, external call, or this service.
```

### Log monitoring (no Fluent Bit needed)

```yaml
# DynaKube:
logMonitoring:
  enabled: true
```

OneAgent reads container stdout/stderr directly from the container runtime (the same logs you see in `kubectl logs`). It ships them to Dynatrace via ActiveGate (`capabilities: [log-analytics]`).

**Why this matters for SREs:**
All logs, metrics, and traces are in ONE place (Dynatrace). You can click from a Problem event directly to the relevant log lines without switching to a separate log system.

**The JSON logging pattern in this project:**
```java
// PaymentController.java:
log.info("{\"event\":\"payment_created\",\"payment_id\":\"{}\",\"amount\":{},\"currency\":\"{}\"}",
    paymentId, req.amount(), req.currency());
```

In DT log analytics, you can query:
```
filter event = "payment_created" AND currency = "JPY"
| summarize count() by bin(timestamp, 1m)
```
Works because log lines are JSON → DT parses them as structured fields automatically.

---

## Part 3 — Management Zones (Who Sees What)

### Why management zones exist

Dynatrace is a multi-tenant observability system. In this project, there are 3 teams:
- payments team (owns payment-service)
- orders team (owns order-service)
- notifications team (owns notification-service)

Without management zones: every team sees every other team's services, metrics, and alerts. A payments engineer investigating a latency spike must filter through orders and notifications noise. A notification team alert page might show payment-service problems that aren't their responsibility.

### How zones are created (from the Terraform module)

```hcl
# terraform/modules/dynatrace/main.tf:
resource "dynatrace_management_zone_v2" "team" {
  for_each = local.teams   # {"notifications", "orders", "payments"}
  name     = "${each.value}-${var.environment}"  # e.g., "payments-production"

  rules {
    rule { type = "SERVICE" ...
      attribute_conditions {
        attribute = "SERVICE_TAGS"
        tag_value = "team:${each.value}"        # team:payments
      }
      attribute_conditions {
        attribute = "SERVICE_TAGS"
        tag_value = "environment:${var.environment}"  # environment:production
      }
    }
    rule { type = "PROCESS_GROUP" ... }  # same conditions, for the JVM process
    rule { type = "HOST" ... }           # same conditions, for the EKS node
  }
}
```

### How the tags get on the entities (the full chain)

```
Step 1: Namespace labels (gitops/<env>/namespaces/namespaces.yaml)
  payment-ns has labels:
    team: payments
    environment: production

Step 2: Pod inherits labels via commonLabels in Helm values:
  pod.metadata.labels:
    team: payments
    environment: production
    app: payment-service

Step 3: OneAgent reads pod + namespace Kubernetes metadata
  OneAgent knows: this Spring Boot process is in namespace payment-ns
                  which has labels team=payments, environment=production

Step 4: DT auto-tagging rule (configured once in DT UI Settings > Tags > Auto-tagging):
  Rule: "If Kubernetes namespace label 'team' exists on any entity,
         apply DT tag team:<label value>"
  Result: payment-service service entity gets DT tag: team:payments
          payment-service process gets DT tag: team:payments
          The EKS node running it gets DT tag: team:payments

Step 5: Management zone rule matches:
  "SERVICE where tag team:payments AND environment:production"
  → payment-service entity is included in "payments-production" zone

Step 6: Alerting profiles scoped to this zone:
  → Slack #alerts-payments only gets payment-service alerts
  → Orders team never sees payment alerts
```

**What the zone controls:**
- Which entities appear in the DT UI when scoped to the zone
- Which Problems are included in the zone's alerting profiles
- Which Synthetic monitors are associated with the zone
- Dashboard default filter

---

## Part 4 — Alerting Profiles (The Four Tiers)

### The four severity levels and their delays

```
┌─────────────────┬─────────────────────┬──────────┬───────────────────────┐
│ Profile         │ DT Severity         │ Delay    │ Environments           │
├─────────────────┼─────────────────────┼──────────┼───────────────────────┤
│ CRITICAL        │ AVAILABILITY        │ 0 min    │ production only        │
│ HIGH            │ ERROR               │ 2 min    │ production + staging   │
│ WARNING         │ SLOWDOWN            │ 5 min    │ all                    │
│ INFO            │ RESOURCE_CONTENTION │ 15 min   │ all                    │
└─────────────────┴─────────────────────┴──────────┴───────────────────────┘
```

### What each severity means in Dynatrace

**AVAILABILITY** = service is unreachable or completely down. DT detects this via:
- Traffic drop to zero
- All synthetics failing simultaneously
- Service entity shows no availability

**ERROR** = elevated failure rate. DT detects via:
- HTTP 5xx error rate above threshold
- Failed requests metric event

**SLOWDOWN** = latency degradation. DT detects via:
- P99 response time above threshold
- Synthetic response time above threshold

**RESOURCE_CONTENTION** = resource pressure trending toward failure. DT detects via:
- CPU above threshold
- Memory/heap above threshold
- Network errors above threshold

### Why delays exist (and why the lengths are specific)

```
CRITICAL (0 min delay):
  "Service is down" is never transient. If DT says AVAILABILITY problem, 
  the service is down. No point waiting — page immediately.
  
HIGH (2 min delay):
  Rolling deploys create brief error spikes:
    - New pod starts, readiness probe fails for ~60 seconds
    - This shows as brief 5xx error rate
    - After 2 minutes: either the probe passes (deploy succeeding) or it didn't
    - If still failing at 2 min: something is actually wrong
    Without delay: every deploy pages oncall.
  
WARNING (5 min delay):
  A single GC pause or momentary DB hiccup shows as a P99 spike.
  At 5 min: either it resolved (transient) or it's sustained (real problem).
  Sustained latency = user experience is degraded = Slack warning.
  
INFO (15 min delay):
  CPU/heap trending up:
    - "CPU just spiked for 30 seconds" = normal workload burst
    - "CPU has been above 70% for 15 minutes" = investigate for capacity
    You need 15 minutes to distinguish burst from trend.
```

### Notification routing

```
payments-production-critical  → dynatrace_pagerduty_notification.critical["payments"]
  → PagerDuty service key: payments-oncall
  → phone call + push notification to on-call engineer

payments-production-warning  → dynatrace_slack_notification.warning["payments"]
  → Slack webhook: payments team webhook
  → channel: #alerts-payments
  → message: "[PRODUCTION] OPEN | SLOWDOWN | P99 latency >300ms | <DT link>"

payments-production-info     → dynatrace_slack_notification.info["payments"]
  → channel: #monitoring (shared, all teams)
  → message: "[INFO][PRODUCTION] OPEN | payments | JVM heap >70% | <DT link>"
```

When the problem resolves, DT automatically sends a RESOLVED notification through the same channel. Engineers in Slack see `[PRODUCTION] RESOLVED | ...` without needing to check DT.

---

## Part 5 — Metric Events (The 8 Signals)

Each metric event defines: WHAT to measure, HOW to evaluate it, and WHAT TYPE of problem to create.

### Signal 1: Traffic Drop — the silent outage detector

```hcl
metric_key = "builtin:service.requestCount.server"
alert_condition = "BELOW"
alert_on_no_data = true
threshold = 10   # prod payment-service: 10 req/min minimum
violating_samples = 3   # must be below threshold for 3 consecutive minutes
```

**Why this is the most important signal:**
```
Scenario: the ALB target group was misconfigured during a deploy.
  All traffic stops reaching payment-service.

  error_rate:     0% (no requests → no errors)
  latency_p99:    no data (no requests to measure)
  cpu:            very low (no work to do)
  memory:         normal
  jvm_heap:       normal

ALL OTHER SIGNALS SHOW GREEN. The service is completely unreachable
and every other signal is lying to you.

Only traffic drop fires: "payment-service received 0 req/min
for 3 consecutive minutes."

alert_on_no_data = true: fires even when DT receives ZERO data points
(not just when value drops below threshold). This catches:
  - Service so broken metrics can't even flow out
  - OneAgent crashed
  - Network partition between cluster and DT tenant
```

**Why `violating_samples = 3` (not 1):**
A maintenance window or a planned drain of all pods momentarily drops traffic to zero. 3 consecutive minutes filters out these brief intentional gaps.

### Signal 2: Error Rate

```hcl
metric_key = "builtin:service.errors.server.rate"
alert_condition = "ABOVE"
threshold = 0.1   # prod payment-service: 0.1%
```

**Per-environment calibration:**
```
Dev:        10.0%  — integration tests exercise error paths intentionally
Staging:     1.0%  — k6 load test reveals real regressions
Production:  0.1%  — any payment error is a real user impact
  notification-service prod: 1.0% (async delivery: 1% failure acceptable)
```

**What DT counts as an error:**
- HTTP 5xx responses (server errors)
- Uncaught exceptions that terminate request processing
- Explicitly marked errors (if using DT Java SDK, but not in this project)

**What it does NOT count:**
- HTTP 4xx (client errors — wrong input, not a server problem)
- Exceptions that are caught and handled within the method

### Signal 3: Latency P99

```hcl
metric_key = "builtin:service.response.time:percentile(99)"
threshold = latency_p99_ms * 1000   # DT uses MICROSECONDS internally
```

**The critical unit conversion (most common DT mistake):**
```
Human-readable: 300ms
Dynatrace API:  300,000µs

If you set threshold = 300 thinking "300ms":
  DT interprets as 300µs = 0.3ms
  Alert fires on literally every single request
  (all requests take more than 0.3ms)
  
The Terraform module does: threshold = each.value.latency_p99_ms * 1000
So you write latency_p99_ms = 300 in main.tf and get 300,000 in DT.
```

**Why P99, not P50 (average) or P95:**
```
P50 (median): 50% of requests are faster. Does not reflect worst-case experience.
  Example: 100ms P50, 2000ms P99 → median looks great, 1 in 100 users waits 2 seconds.

P95: 5% of requests are slower. Still misses the tail.

P99: only the slowest 1% exceed this. Catches outliers that users will notice.
  A payment that takes 2 seconds = user thinks it failed = they click again = double charge.

For payment services: P99 is the minimum threshold to use.
For internal tools: P95 may be acceptable.
```

**`dealerting_samples = 3`:**
```
Prevents alert flapping.

Without: P99 spikes to 400ms (1 data point) → alert fires → clears → spikes → fires → clears
This is alert noise, not signal.

With dealerting_samples = 3:
  Alert only CLEARS after 3 consecutive data points show P99 below threshold.
  "I am confident the problem is truly resolved."
```

### Signal 4: CPU Saturation

```hcl
metric_key = "builtin:process.cpu.usage"
event_entity_dimension_key = "dt.entity.process_group_instance"  # the JVM process
threshold = 70   # prod payment-service
violating_samples = 5   # 5 consecutive minutes
```

**Why Java needs headroom (prod threshold is 70%, not 90%):**
```
G1GC runs in BACKGROUND THREADS that also consume CPU.
These GC threads compete with application threads for CPU time.

At 70% CPU total: GC threads can use 20-30% remaining → GC runs smoothly
At 90% CPU total: GC threads starve → GC pauses lengthen → P99 latency spikes

Pattern:
  Traffic spike → CPU rises → at 70% alert fires → scale out via HPA
  By the time CPU reaches 90%, GC is already causing latency issues
  Alerting at 70% gives time to scale before users feel it
  
Prod: 70% (payment-service, tight because it handles money)
      80% (order-service, notification-service, slightly more tolerant)
Dev:  90% (bursts are normal: test runs, pod restarts, JIT compilation)
```

### Signal 5: Memory Usage (RSS)

```hcl
metric_key = "builtin:process.memory.usage"
# This is RSS (Resident Set Size) — total RAM used by the JVM process
# Includes heap + non-heap (metaspace, code cache, threads, OS buffers)
threshold = 75   # prod payment-service: 75% of container memory limit
```

**RSS vs JVM heap (different metrics, both important):**
```
JVM heap (-Xmx):
  Objects allocated by your Java code live here.
  Garbage collected by G1GC.
  Limit: -Xmx1024m in production.

RSS (Resident Set Size):
  Heap + non-heap memory.
  Non-heap includes:
    - Metaspace (~150-200MB): class metadata, JIT compiled code cache
    - Thread stacks (~1MB per thread × 200 threads = 200MB)
    - Direct buffers (used by Netty/NIO)
    - OS overhead

Container memory limit: 1Gi
-Xmx: 1024m
RSS at peak: heap(768MB) + non-heap(200MB) + OS(50MB) ≈ 1018MB
This is very close to the limit.

75% RSS threshold fires at 768MB RSS — before you hit the 1Gi limit.
Getting close to the limit → K8s OOMKills the pod → immediate outage.
```

### Signal 6: JVM Heap

```hcl
metric_key = "builtin:process.memory.jvm.heapUtilization"
# Heap used / Xmx, as a percentage
threshold = 70   # prod: alert when using 70% of Xmx
```

**Why heap has its own alert separate from RSS:**
```
RSS = total memory. Can be high even when heap is healthy (metaspace leak).
Heap = just the Java object space. This is what G1GC manages.

At 70% heap:
  G1GC must work harder to keep heap below Xmx
  GC minor collections become more frequent
  G1GC pause times start increasing
  P99 latency begins to be affected

At 85% heap:
  G1GC may trigger full GC (stop-the-world for hundreds of ms)
  P99 latency spike visible to users

At 95%+ heap:
  OOM likely → pod OOMKills or crashes with OutOfMemoryError

70% threshold: alert BEFORE G1GC degradation becomes user-visible.
```

**Per-environment heap threshold tied to Xmx size:**
```
Dev:     Xmx=256m. Spring Boot idle context = ~180MB = 70% of Xmx at startup.
         Threshold at 70% = alert fires before writing a line of code.
         Threshold at 85% = only fires when genuinely near OOM.

Staging: Xmx=512m. k6 load test fills heap to ~78% at peak.
         Threshold at 78% = fires if staging load test causes abnormal growth.

Prod:    Xmx=1024m. Normal load = 30-50% heap. Peak = 60-65%.
         Threshold at 70% = early warning before G1GC impact.

Rule: if you change Xmx, recalibrate jvm_heap_pct.
```

### Signal 7: Pod Restarts

```hcl
metric_key = "builtin:kubernetes.workload.pods.restarts"
resolution = "5m"         # 5-minute window
samples = 1
violating_samples = 1     # fires immediately on first detection
```

**Why 1/1 (immediate, no delay):**
```
A pod restart is NEVER transient.
  - OOMKill: pod used more RAM than its container limit → killed by K8s
  - CrashLoopBackOff: application crashes on startup (DB connection, config error)
  - Liveness probe failure: application deadlocked or hung

These are always real problems that need investigation.
Unlike CPU or latency which can spike briefly, a pod restart is a discrete event.
It either happened or it didn't. No need to confirm over multiple minutes.
```

**Per-environment threshold:**
```
Dev:     5 restarts / 5 min
  Developers actively iterate: push broken code → crash → fix → push → crash
  This is normal. Alert only when restart loop is out of control.

Staging: 3 restarts / 5 min
  Rolling deploys expect brief restarts. But not loops.

Prod:    2 restarts / 5 min
  In production, there should be ZERO restarts under normal operation.
  Even 2 restarts = investigate immediately.
  Could mean: OOM (memory sizing issue), DB down (connection pool failure),
              config error in new deploy, or application bug.
```

### Signal 8: Network Error Rate

```hcl
metric_key = "builtin:host.net.errorRate"
# Packet-level errors on the node's network interface
# NOT HTTP errors — this is layer 3/4 (NIC, driver, physical host)
threshold = 0.5   # prod payment-service: 0.5%
```

**What this measures (not what you might think):**
```
This is NOT HTTP error rate (that's Signal 2).
This is network PACKET errors on the EC2 instance's ENI:
  - Packet retransmits (TCP layer)
  - Checksum errors
  - Dropped packets at NIC level
  - Interface errors

These indicate:
  - Bad ENI (AWS network hardware issue)
  - NIC driver problem
  - Physical host network degradation
  - EC2 "noisy neighbor" affecting network quality

If this fires: check AWS health events, consider replacing the node.
Not application code — this is infrastructure-level.
```

---

## Part 6 — SLOs (Service Level Objectives)

### What an SLO is vs what it isn't

```
SLO is NOT:
  - An internal metric threshold (that's metric events)
  - A per-request alert (that's alerting profiles)
  - A measure of any single incident

SLO IS:
  - A rolling 30-day agreement: "99.9% of requests must succeed"
  - A measure of cumulative reliability over time
  - The basis for prioritizing reliability work
```

### The availability SLO formula

```
SLO = 100 × (good_requests / total_requests) over 30 days

good_requests = total_requests - error_requests

For payment-service production:
  target = 99.9%
  1 - 0.999 = 0.001 = 0.1% error budget
  
  At 100 req/s for 30 days:
    total = 100 × 86400 × 30 = 259,200,000 requests
    error budget = 259,200 allowed errors
    = 43.2 minutes of complete downtime OR 2,592 errors/day

  An outage that returns 5xx for 5 minutes:
    100 req/s × 300s = 30,000 errors
    30,000 / 259,200 = 11.6% of monthly error budget burned in 5 minutes
```

### The latency SLO formula

```
SLO = 100 × (requests_within_threshold / total_requests)

For payment-service production:
  target = 99.4% (slo_target - 0.5 = 99.9 - 0.5)
  latency_p99_ms = 300 → DT threshold in µs: 300,000

  Expression: "what % of requests completed in under 300ms?"
  
  If 1% of requests take >300ms AND your threshold is 99.4%:
    → You're at 99% compliance, below the 99.4% target
    → SLO is burning
```

### Burn rates explained (the most important SLO concept)

```
Burn rate = how fast you're consuming error budget relative to normal pace.

Normal burn rate = 1.0
  Budget depletes at exactly the right pace: used up on day 30.
  At this rate: 0.003% of requests fail per minute.

Fast burn rate = 14.4×
  You're consuming budget 14.4× faster than normal.
  Budget exhausted in: 30 days / 14.4 = 2.08 days
  
  DT fires: "At this rate, your monthly error budget is gone in 2 days."
  What this looks like: 100% error rate for 1 hour (14.4×) or
                        ~0.5% error rate for 24 hours (also 14.4×)

Slow burn rate = 3.0×
  Budget exhausted in: 30 days / 3 = 10 days
  
  DT fires: "At this rate, your monthly error budget is gone in 10 days."
  What this looks like: 0.3% error rate for an extended period.
  
The numbers 14.4 and 3.0 come from Google SRE workbook:
  14.4 is chosen so 2% of monthly budget is consumed in 1 hour.
  At that rate, immediate action is needed.
  3.0 is chosen so 10% of budget is consumed per day — investigate within a day.
```

**How to read the SLO dashboard:**
```
SLO tile shows:
  Current value:    99.94%  ← actual % over last 30 days
  Target:           99.9%   ← what we promised
  Warning:          99.8%   ← where Dynatrace starts warning you
  Status:           MET ✅  or  BREACHED ❌
  
  Error budget remaining: 60% (of monthly budget still available)
  Burn rate (7d):    0.3×   ← slower than normal → healthy
  
  If burn rate shows: 8.5× → you have ~3.5 days before breaching
  → Investigate now, don't wait for an alert
```

---

## Part 7 — HTTP Synthetic Monitors

### What synthetics are and why they're different from OneAgent monitoring

```
OneAgent:     passive monitoring — captures real user traffic as it happens
              Can only detect problems when users are sending requests
              
Synthetic:    active monitoring — DT sends test traffic from external nodes
              Detects problems proactively, even at 3am with zero real users
              Tests from the exact same perspective as a real user (through the internet)
```

### The two-validation check

```yaml
validation:
  rule { type = "httpStatusesList";  value = "2xx" }      # HTTP layer
  rule { type = "patternConstraint"; value = '"status":"UP"' }  # App layer
```

**Why both are needed:**
```
Scenario A: DB is down, Spring Boot responds with:
  HTTP status: 200 (the Spring app itself is running)
  Body: {"status":"DOWN","components":{"db":{"status":"DOWN"}}}
  
  HTTP-only check: PASSES (200 = 2xx) — reports service as healthy
  DT synthetic: FAILS (body doesn't contain "status":"UP") — correct!
  
Scenario B: Service completely down:
  HTTP status: 503
  
  HTTP check: FAILS (503 ≠ 2xx) — correct
  Body check: not even evaluated (step 1 already failed)
  
Scenario C: Everything working:
  HTTP status: 200
  Body: {"status":"UP","components":{...all UP...}}
  
  Both checks: PASS
```

**The Spring Boot Actuator health response format:**
```json
{
  "status": "UP",
  "components": {
    "db": {
      "status": "UP",
      "details": {
        "database": "PostgreSQL",
        "validationQuery": "isValid()"
      }
    },
    "diskSpace": {
      "status": "UP"
    },
    "ping": {
      "status": "UP"
    }
  }
}
```
`management.endpoint.health.show-details: always` in `application.yaml` enables this full view. Spring Boot automatically checks all configured components (DB, message brokers, caches) and aggregates into a top-level `"status"`. OneAgent `/actuator/health/readiness` endpoint reports DOWN if ANY dependency is unhealthy.

### Tokyo + Singapore (why two locations)

```
Tokyo only:
  Synthetic fails
  Question: Is the service down? Or is DT's Tokyo node having a network issue?
  You can't tell. → You page oncall unnecessarily.
  
Tokyo + Singapore, both fail:
  Both DT nodes are in different regions, different internet exchanges.
  Both failing simultaneously → service is genuinely down.
  DT fires: global_outage → PagerDuty immediately.
  
Tokyo fails, Singapore passes:
  The service is up. DT's Tokyo node has a routing issue, or
  there's a Tokyo-region DNS/network problem (not your fault).
  DT fires: local_outage → Slack warning (investigate, but probably not your service).
  
This is why production uses 2 locations.
Dev uses only Tokyo (DDU cost saving — dev has no SLA, one location is sufficient).
```

```hcl
anomaly_detection {
  outage_handling {
    global_consecutive_outage_count_threshold = 1   # 1 failure from all locations = alert
    local_consecutive_outage_count_threshold  = 3   # 3 consecutive failures from 1 location = alert
  }
}
```
Local threshold is 3 (not 1) because DT monitoring nodes occasionally have brief network hiccups. 3 consecutive local failures = not transient.

### Response time limit

```hcl
response_time_limit = each.value.latency_p99_ms * 3
```
If `latency_p99_ms = 300`, the synthetic fails if the health endpoint takes more than 900ms. This catches "extremely slow but technically returning 200" — the service is severely degraded even if health checks technically pass.

---

## Part 8 — What Happens During an Incident (SRE Workflow)

### Step 1: Alert arrives

```
PagerDuty notification:
  "[PRODUCTION] OPEN | AVAILABILITY | payment-service: Traffic drop (<10 req/min) | <DT URL>"
```

### Step 2: Open the Problem Event in DT

The URL takes you to the **Problem detail page** which shows:
```
Problem: Payment-service Traffic Drop
Severity: AVAILABILITY
Started: 14:23:07 JST
Affected entities: payment-service (production), 3 service instances

Root cause analysis (DT's Davis AI):
  "Kubernetes workload 'payment-service' has 0 running pods"
  (linked to: recent deployment event 14:22:45 JST)

Evidence:
  - Traffic chart: flat line at 0 from 14:22:50
  - Kubernetes events: 3 pods in CrashLoopBackOff
  - Recent changes: image tag updated to "abc123" at 14:22:45
```

DT's **Davis AI** correlates events automatically:
- The traffic drop started 20 seconds after the gitops commit
- DT flags the deploy as the likely root cause

### Step 3: Investigate using DT tools

**If CrashLoopBackOff (startup failure):**
```
DT → Log Analytics → filter: service = payment-service AND level = ERROR
→ See: "Failed to connect to database: Connection refused"
→ Root cause: wrong DB_HOST in the new image's config
```

**If latency spike (service running but slow):**
```
DT → payment-service → Response time analysis
→ Click on "Response time breakdown"
→ Shows: JDBC layer = 85% of response time
→ Click on the DB calls → see: specific SQL query taking 800ms
→ Root cause: missing DB index on a new query in the deploy
```

**If memory leak (heap growing over time):**
```
DT → payment-service process → JVM heap chart
→ Heap trending upward over 2 hours (sawtooth pattern gets higher over time)
→ G1GC runs but doesn't fully reclaim
→ Root cause: cached payment objects not being evicted (code bug)
```

### Step 4: Rollback or fix

**Rollback via gitops:**
```bash
# CI auto-rollback runs automatically if verify-production smoke test fails.
# If CI already passed but problems appear later, manual rollback:

git log --oneline -- gitops/production/app/payment-service/payment-service.yaml
# abc1234 chore(deploy-prod): payment-service=new-sha
# def5678 chore(deploy-prod): payment-service=old-sha ← the good version

sed -i 's|tag: "new-sha"|tag: "old-sha"|' \
  gitops/production/app/payment-service/payment-service.yaml
git commit -m "chore(rollback-prod): payment-service=old-sha [skip ci]"
git push
# ArgoCD detects → rolling update to old image → traffic recovers
```

### Step 5: Verify recovery in DT

```
DT → payment-service → Response time chart
  → P99 latency returns to baseline (~150ms)
  
DT → traffic drop metric event
  → Status: RESOLVED (traffic above 10 req/min again)
  
DT → SLO
  → Availability: 99.87% (budget burned but not breached)
  → Burn rate recovering toward 1.0×
  
PagerDuty / Slack: RESOLVED notification sent automatically
```

---

## Part 9 — Reading the DT UI (Where to Find Things)

### Navigating to your service

```
DT → Applications & Microservices → Services
  → Filter by management zone: "payments-production"
  → Click: payment-service
  → You see:

Service overview:
  Response time:  P50=45ms, P90=120ms, P99=185ms  ← current 2 hours
  Failure rate:   0.02%
  Throughput:     1,247 req/min
  
  Tabs:
    Overview     ← current summary
    Service flow ← calls this service makes to other services / DBs
    Backtrace    ← which services call THIS service
    Dynamic requests ← breakdown by endpoint
    Events       ← recent deploys, config changes, problems
    Traces       ← individual distributed traces
```

### Finding the slow endpoint

```
DT → payment-service → Dynamic requests tab
  Shows breakdown by URL path:
  
  /api/v1/payments (POST)  | 2,847 req | P99: 185ms | 0.01% errors
  /actuator/health/liveness | 1,200 req | P99: 12ms  | 0% errors
  /actuator/health/readiness| 1,200 req | P99: 15ms  | 0% errors
  
  Click /api/v1/payments:
    → Breakdown: Service 45ms | JDBC 135ms | Other 5ms
    → JDBC is the bottleneck → click JDBC
    → Top SQL statements by time:
        INSERT INTO payments (id, amount, currency) ... → 135ms avg
        → Click: "View in database service" → see DB-level metrics
```

### Reading a distributed trace

```
DT → payment-service → Traces
  → Filter: Response time > 500ms  (to find slow requests)
  → Click on a trace:

Trace view:
  order-service              [523ms total]
  ├── HTTP POST /api/v1/orders  [523ms]
  │   ├── payment-service      [485ms]
  │   │   ├── JDBC SELECT ...  [12ms]
  │   │   ├── External HTTP call: payment-gateway.api.com  [460ms] ← SLOW
  │   │   └── JDBC INSERT ...  [13ms]
  │   └── notification-service [38ms]
  │       └── SQS publish      [33ms]

Conclusion: the slow trace is caused by an external payment gateway API call,
not by our code or DB. Action: alert the payment gateway vendor.
```

### Reading the K8s workloads view

```
DT → Infrastructure → Kubernetes → your cluster
  → Workloads tab → payment-service

  Pods: 3/3 running
  CPU requests: 250m used / 750m requested
  Memory requests: 512Mi used / 2,304Mi requested (3 pods × 768Mi)
  
  Pod restarts: 0 in last 24h
  Failed pods:  0
  
  Events section:
    14:22:45 Normal  Pulled      "Successfully pulled image payment-service:abc123"
    14:22:48 Normal  Created     "Created container payment-service"
    14:22:52 Normal  Started     "Started container payment-service"
    14:22:58 Normal  Unhealthy   "Readiness probe failed: HTTP probe failed" ← startup
    14:23:28 Normal  Unhealthy   "Readiness probe failed" (still starting...)
    14:24:12 Normal  Unhealthy   "Readiness probe failed" (still starting...)
    ← if this keeps going, CrashLoopBackOff. If it stops, pod is ready.
```

---

## Part 10 — Dynatrace Terraform Config Reference (What Each Resource Does)

### Complete mapping: Terraform resource → DT UI location

| Terraform resource | DT UI location | What you see |
|---|---|---|
| `dynatrace_management_zone_v2` | Settings → Management zones | Zone filter at top of DT |
| `dynatrace_alerting` | Settings → Alerting → Alerting profiles | Delay + severity filter |
| `dynatrace_metric_events` | Settings → Anomaly detection → Metric events | Custom alert rules |
| `dynatrace_slo_v2` | Service Level Objectives | SLO dashboard tiles |
| `dynatrace_http_monitor` | Synthetic → HTTP monitors | Active uptime checks |
| `dynatrace_pagerduty_notification` | Settings → Integrations → Problem notifications | PD integration |
| `dynatrace_slack_notification` | Settings → Integrations → Problem notifications | Slack webhook |

### How a metric event creates a Dynatrace Problem

```
1. DT evaluates metric_key every `resolution` (1 minute or 5 minutes)
2. Checks: is the value above/below `threshold`?
3. If yes for `violating_samples` consecutive evaluations:
   → DT creates a "Problem"
   → Problem has: severity, title, description, affected entity
   → Problem is assigned to the entity's management zone
   → Alerting profiles check: does this problem match my severity+zone?
   → If yes AND delay has elapsed: fire notification (PagerDuty/Slack)

4. DT continues evaluating after the Problem is created
5. When `dealerting_samples` consecutive evaluations show normal:
   → Problem is automatically resolved
   → Resolution notification sent
```

### The entity dimension key — which entity owns the metric

```hcl
event_entity_dimension_key = "dt.entity.service"              # for HTTP metrics
event_entity_dimension_key = "dt.entity.process_group_instance" # for JVM/CPU/memory
event_entity_dimension_key = "dt.entity.cloud_application"    # for pod restarts
event_entity_dimension_key = "dt.entity.host"                 # for network metrics
```

This controls WHERE in DT the problem appears. `dt.entity.service` = the problem shows on the Service entity page. `dt.entity.cloud_application` = the problem shows on the Kubernetes workload page.

---

## Part 11 — Per-Environment Threshold Reference

### Why thresholds MUST differ between environments

```
If you use production thresholds in dev:

latency threshold = 300ms
Dev JVM on t3.medium, JIT not warmed, first request after restart: 2000ms
→ Alert fires immediately on every pod restart
→ Engineers see 5-10 alerts per day just from pod restarts
→ After 1 week: engineers train themselves to ignore ALL alerts
→ Real production problem fires → engineers ignore it (same noise pattern)

This is "alert fatigue" — the most dangerous failure mode in monitoring.
A monitoring system that cries wolf loses all value.
```

### Complete threshold table

| Signal | Dev | Staging | Prod (payment) | Prod (order) | Prod (notif) |
|---|---|---|---|---|---|
| SLO target | 90% | 95% | 99.9% | 99.5% | 99.0% |
| Traffic min (req/min) | 0 (off) | 2 | 10 | 5 | 3 |
| Error rate | 10% | 1% | 0.1% | 0.5% | 1.0% |
| Latency P99 | 2000ms | 800ms | 300ms | 500ms | 1000ms |
| CPU | 90% | 85% | 70% | 80% | 80% |
| Memory RSS | 85% | 80% | 75% | 80% | 80% |
| JVM heap | 85% | 78% | 70% | 75% | 75% |
| Pod restarts | 5 | 3 | 2 | 2 | 2 |
| Network errors | 5% | 2% | 0.5% | 1% | 1% |
| PagerDuty CRITICAL | ❌ | ❌ | ✅ | ✅ | ✅ |
| PagerDuty HIGH | ❌ | ✅ | ✅ | ✅ | ✅ |
| Synthetic locations | Tokyo | Tokyo+SG | Tokyo+SG | Tokyo+SG | Tokyo+SG |

**notification-service has looser thresholds because it is async:**
```
Latency P99 = 1000ms (prod) vs 300ms for payment-service:
  notification-service returns {"status":"queued"} immediately.
  But "immediately" includes: Spring processing + SQS publish.
  SQS API call: ~50-100ms in steady state, up to 500ms on cold path.
  1000ms P99 is realistic for an async API with SQS in the hot path.
  
Error rate = 1% (prod) vs 0.1% for payment-service:
  SQS delivery failures (downstream: email provider, SMS gateway) are
  sometimes unavoidable. The important metric is DLQ depth, not this rate.
  1% threshold covers rare delivery failures without flooding Slack.
```
