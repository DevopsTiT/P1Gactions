# Glossary — Dynatrace SRE Deep Dive

Every term used in main.md. One entry per term, plain language for an SRE beginner.

---

**OneAgent**
A Dynatrace monitoring agent deployed as a Kubernetes DaemonSet — one pod per node. It monitors ALL pods on that node without any code changes in your application. Why it matters: zero-effort full-stack monitoring. You don't need to add libraries, annotations, or SDK calls to your Java code.

**DaemonSet**
A Kubernetes resource that ensures exactly one pod runs on every node in the cluster. OneAgent uses this pattern so every node is always monitored, including newly added nodes. Why it matters: automatic coverage — no manual configuration when you add nodes.

**JVMTI (Java Tool Interface)**
A C API built into every JVM that lets external agents hook into a running Java process and modify its bytecode at runtime. This is how OneAgent instruments Spring Boot methods without changing source code. Why it matters: the core technology that enables zero-code-change Java monitoring.

**ActiveGate**
A Dynatrace proxy component (Kubernetes Deployment) running inside the cluster. OneAgent pods send all data to ActiveGate, which batches and forwards to the Dynatrace SaaS tenant. Also collects Kubernetes API metrics and handles log analytics. Why it matters: reduces outbound connections (N nodes → 1-2 ActiveGates → DT tenant) and is required for log analytics.

**OTLP (OpenTelemetry Protocol)**
The standard protocol for sending distributed traces, metrics, and logs from an application to an observability backend. The Java apps in this project send traces to `http://dynatrace-activegate.dynatrace.svc:4318` via OTLP. Why it matters: cross-service traces (order-service → payment-service) require both services to send spans to the same backend using this protocol.

**Distributed trace**
A record of a single user request as it flows through multiple services. Each service creates a "span" (timed unit of work). Spans are linked by a trace ID in HTTP headers. Why it matters: shows WHERE latency comes from — is the payment slow because of our code, our DB, or the external payment gateway?

**Trace span**
One unit of work within a distributed trace — e.g., "payment-service handled this HTTP request" or "JDBC query took 35ms." Spans have a start time, duration, and status (success/failure). Why it matters: the building block of distributed tracing — click into a slow span to see exactly where time was spent.

**`traceparent` header**
An HTTP header that carries the distributed trace context across service calls. When order-service calls payment-service, it injects this header so payment-service knows it's part of the same trace. Why it matters: without this, traces are broken — you only see single-service spans, not the full call chain.

**Management zone**
A Dynatrace filter that scopes the UI, dashboards, and alerts to a specific group of entities (services, hosts, processes). "payments-production" shows only payment team entities tagged `team:payments AND environment:production`. Why it matters: teams only see their own services; prevents alert noise from other teams.

**DT auto-tagging**
A Dynatrace setting (configured once in DT UI) that automatically applies tags to entities based on Kubernetes metadata. "If namespace label 'team' exists, apply tag team:<value>." Why it matters: links the namespace labels in your gitops YAML to Dynatrace management zones automatically.

**DT entity**
An object in Dynatrace that represents a monitored thing: a service, a process, a host, a Kubernetes pod, etc. Entities have types (`dt.entity.service`, `dt.entity.process_group_instance`). Why it matters: metric events must specify which entity type they apply to — this controls where the Problem appears in the DT UI.

**Problem (Dynatrace)**
A DT event created when a metric event fires. Contains: severity, title, description, affected entities, and links to root cause analysis. A Problem is the "incident" in Dynatrace — it triggers notifications and is what engineers investigate. Why it matters: the central object that links an alert to all relevant data (logs, traces, metrics, K8s events).

**Davis AI**
Dynatrace's built-in AI engine that correlates events, metrics, and topology to identify root causes for Problems. It looks for: recent deployments, topology changes, and correlated metric anomalies. Why it matters: often tells you "the problem started 20 seconds after this deployment" before you even start investigating.

**Alerting profile**
A Dynatrace configuration that maps a Problem severity to a notification channel with an optional delay. "AVAILABILITY, 0 min delay → PagerDuty phone call." Why it matters: the routing rule that decides who gets paged, through which channel, and how urgently.

**AVAILABILITY (DT severity)**
The most severe Dynatrace problem type — the service is completely down or unreachable. Maps to the CRITICAL alerting profile with 0-minute delay. Why it matters: requires immediate response; every minute of unavailability burns error budget fast.

**ERROR (DT severity)**
Dynatrace problem type for elevated failure rates. Maps to the HIGH alerting profile with 2-minute delay. Why it matters: indicates real user-facing failures, but the 2-minute delay filters brief spikes during rolling deploys.

**SLOWDOWN (DT severity)**
Dynatrace problem type for latency degradation. Maps to the WARNING alerting profile with 5-minute delay. Why it matters: users are having a degraded experience but the service is still functional — investigate within hours, not minutes.

**RESOURCE_CONTENTION (DT severity)**
Dynatrace problem type for resource pressure (CPU, memory, heap). Maps to the INFO alerting profile with 15-minute delay. Why it matters: early warning that capacity limits are being approached — act before it becomes an outage.

**Metric event**
A Dynatrace configuration rule that creates a Problem when a specific metric crosses a threshold for N consecutive minutes. This project creates 8 per service (traffic drop, error rate, latency, CPU, memory, heap, pod restarts, network errors). Why it matters: the actual alert definition — these are the tripwires that detect problems.

**`alert_on_no_data`**
A metric event setting that fires the alert even when Dynatrace receives zero data points (no metrics at all). Why it matters: if the service is so broken it can't send metrics, all other signals show green (no data = no bad values). Only `alert_on_no_data` catches this "silent outage."

**`violating_samples`**
How many consecutive evaluation windows (minutes) must exceed the threshold before the alert fires. Prevents single-point spikes from triggering pages. Why it matters: a 1-minute CPU spike during a batch job is not an incident; 5 consecutive minutes above 70% means investigate.

**`dealerting_samples`**
How many consecutive windows must show normal values before the alert CLEARS. Prevents alert flapping (fires/clears/fires/clears every minute). Why it matters: an alert should only clear when the problem is genuinely resolved, not on a brief dip below threshold.

**SLO (Service Level Objective)**
A measurable reliability target over a rolling time window: "99.9% of payment requests must succeed in any 30-day period." Why it matters: converts vague "the service should be reliable" into a specific, measurable contract that drives prioritization.

**SLA (Service Level Agreement)**
A contractual commitment to customers with financial penalties if breached. The SLO is the internal target that gives buffer before breaching the SLA. Why it matters: SLO breach = reliability debt; SLA breach = refunds or contract termination.

**Error budget**
The amount of failures allowed in a period while still meeting the SLO. For 99.9%: 0.1% of requests can fail per month = 43.2 minutes of complete downtime. Why it matters: quantifies "how much reliability work is needed" — a nearly-depleted error budget means freeze feature work and fix reliability.

**Burn rate**
How fast the error budget is being consumed relative to the normal pace. Burn rate 1.0 = budget used up exactly over 30 days. Burn rate 14.4× = budget exhausted in 2 days. Why it matters: tells you urgency — 14.4× requires immediate action; 3.0× requires investigation today.

**Fast burn threshold (14.4×)**
The Google SRE workbook standard for immediate alerting. At 14.4×, 2% of the monthly error budget is consumed in 1 hour. Why it matters: at this rate, the monthly SLO will be breached in ~2 days — page oncall now.

**Slow burn threshold (3.0×)**
The Google SRE workbook standard for early warning. At 3.0×, 10% of the monthly error budget is consumed per day. Why it matters: budget exhausted in ~10 days — investigate and fix within a day before it escalates.

**HTTP Synthetic monitor**
An active health check that Dynatrace sends from external monitoring nodes (Tokyo, Singapore) to your service's URL on a schedule (every 5 minutes). Why it matters: detects outages even at 3am with zero real users, and tests from the user's perspective (through the internet, not from inside the cluster).

**Global outage vs local outage (synthetic)**
Global: all monitoring locations fail simultaneously → service is genuinely down → PagerDuty. Local: only one location fails → that location has a network issue, not your service → Slack warning. Why it matters: distinguishes real outages from DT infrastructure blips, reducing false pages.

**DDU (Dynatrace Data Units)**
Dynatrace's billing unit for synthetic monitors. More locations × more frequency = more DDUs. Why it matters: dev uses 1 location (Tokyo only) to save DDUs since dev has no SLA; production uses 2 (Tokyo + Singapore) for reliable outage detection.

**P99 (99th percentile latency)**
The response time that 99% of requests are faster than. If P99 = 300ms: 99 out of 100 requests finish under 300ms. Why it matters: average latency hides slow outliers. P99 reflects the worst experience most users have — a payment taking 2 seconds makes users think it failed.

**µs (microseconds)**
Dynatrace stores all latency metrics internally in microseconds. 1ms = 1,000µs. The Terraform module converts: `threshold = latency_p99_ms * 1000`. Why it matters: setting `threshold = 300` thinking "300ms" actually means 300µs = 0.3ms → alert fires on every single request.

**RSS (Resident Set Size)**
The total physical RAM a process is using right now. For Java: heap + metaspace + code cache + thread stacks + OS buffers. Why it matters: this is what Kubernetes counts against the container memory limit. When RSS exceeds the limit, Kubernetes OOMKills the pod.

**JVM heap**
The memory region where Java objects live, managed by garbage collection. Size is controlled by `-Xmx`. Heap used / Xmx = heap utilization percentage. Why it matters: G1GC pause times increase non-linearly above 70% heap — alerting at 70% gives time to act before users feel GC impact.

**G1GC (Garbage First Garbage Collector)**
Java's low-latency garbage collector. Runs incrementally across small heap regions. Aims to meet a configurable pause time target (`-XX:MaxGCPauseMillis`). Why it matters: G1GC pause times affect P99 latency directly — long GC pauses = slow P99 = SLO at risk.

**OOMKill**
When Kubernetes terminates a container because its RSS memory exceeded the container's `limits.memory`. The pod shows `reason: OOMKilled` in `kubectl describe pod`. Why it matters: an OOMKill = pod restart → brief service disruption → pod restart count alert fires.

**CrashLoopBackOff**
Kubernetes state when a pod keeps crashing (failing to start) and is being restarted with exponential backoff delay. Why it matters: the pod never becomes Ready → taken out of the load balancer → service capacity reduced → eventually traffic can't be served.

**DT log analytics**
Dynatrace's feature for searching, filtering, and analyzing container logs shipped by OneAgent. Supports structured JSON log queries. Why it matters: all logs, metrics, and traces in one place — during an incident, you can click from a Problem event directly to the relevant log lines.

**Structured JSON logging**
Writing application logs as JSON objects (`{"event":"payment_created","amount":100}`) instead of plain text. Why it matters: DT log analytics can query individual JSON fields directly — `filter event = "payment_created"` — without needing to parse text patterns.

**Service flow (DT)**
A view in DT that shows what downstream services and databases a service calls, with latency and error rate for each dependency. Why it matters: during a latency incident, shows whether YOUR code is slow or a downstream dependency is slow.

**Backtrace (DT)**
A view showing which upstream services call YOUR service. Why it matters: when your service has a problem, shows which callers (and which users) are affected.

**Dynamic requests (DT)**
A breakdown of a service's performance by individual API endpoint. Why it matters: a high P99 for the whole service might be caused by ONE slow endpoint. Dynamic requests shows you which endpoint is slow.

**Problem notification**
A Dynatrace configuration that sends a message to an external system (PagerDuty, Slack) when a Problem matches a specific alerting profile. Why it matters: the bridge between DT detecting a problem and a human being notified.

**PagerDuty**
An on-call management platform that sends phone calls, push notifications, and SMS to on-call engineers. In this project, CRITICAL and HIGH problems page via PagerDuty. Why it matters: ensures someone is woken up immediately for production outages.

**Alert fatigue**
When alerts fire so frequently (false positives, over-sensitive thresholds) that engineers start ignoring them. Why it matters: the most dangerous failure mode in monitoring — a real incident fires and the on-call engineer assumes it's another false alarm.

**`dt.entity.service`**
The Dynatrace entity type representing an instrumented service (a running application). A metric event with this dimension key creates a Problem on the service entity page. Why it matters: determines where in the DT UI the Problem appears.

**`dt.entity.process_group_instance`**
The DT entity type for a specific running process instance (one JVM). CPU and memory metrics belong to this entity type. Why it matters: JVM heap and CPU problems appear on the Process page, not the Service page.

**`dt.entity.cloud_application`**
The DT entity type for a Kubernetes workload (Deployment). Pod restart metrics belong here. Why it matters: pod restart Problems appear in the Kubernetes workloads view in DT.

**Entity filter (metric event)**
Narrows a metric event to a specific service+environment combination. `service.name = "payment-service" AND environment = "production"`. Why it matters: without filtering, one metric event would aggregate all services across all environments and fire incorrectly.

**Rollout status**
`kubectl rollout status deployment/payment-service --timeout=8m` — blocks CI until all pods in the deployment are updated and passing health checks, or fails if timeout is reached. Why it matters: ensures CI doesn't run smoke tests against old pods before the new ones are ready.

**JDBC (Java Database Connectivity)**
Java's standard API for connecting to relational databases (PostgreSQL, MySQL, etc.). OneAgent auto-instruments JDBC calls to capture SQL execution time and statements. Why it matters: often the bottleneck in Java microservices — DT shows you exactly which SQL is slow.

**HikariCP**
Spring Boot's default JDBC connection pool. Maintains a pool of database connections that threads borrow and return. `maximum-pool-size: 10` = at most 10 simultaneous DB queries per pod. Why it matters: "connection pool exhaustion" (all 10 connections busy) → new requests queue up → latency spike.

**SNS (Simple Notification Service)**
AWS managed pub/sub messaging service. notification-service publishes notification messages to SNS topics for delivery via email, SMS, push. Why it matters: the async backbone of notification-service — API returns "queued" immediately, SNS delivers asynchronously.

**SQS DLQ (Dead Letter Queue)**
A queue that receives messages that failed to process after N retries. The notification-service smoke test checks DLQ depth. Why it matters: a non-zero DLQ = silent delivery failures — messages the service tried to process but couldn't.

**Kubernetes events**
Records of state changes in the cluster: pod scheduled, image pulled, container started, readiness probe failed, OOMKilled, etc. Visible in DT's Kubernetes workload view and via `kubectl describe pod`. Why it matters: the timeline of what happened to a pod during a deploy — crucial for debugging CrashLoopBackOff.
