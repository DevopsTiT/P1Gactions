# OpenTelemetry Distributed Traces — Deep Explanation

> The screenshot shows two env vars (`OTEL_EXPORTER_OTLP_ENDPOINT` and `OTEL_SERVICE_NAME`) and a 3-step explanation of how a cross-service trace is built. This doc explains every piece — what happens inside the code, what travels over the network, and how Dynatrace stitches it all into one view.

---

## Decision Tree — What to look at when

```
Q: Why does the trace show all 3 services as one chain?
   → Trace context propagation (W3C traceparent header)

Q: Where does the trace data go after leaving the Java app?
   → OTEL_EXPORTER_OTLP_ENDPOINT → Dynatrace ActiveGate (port 4318)

Q: How does DT know which service sent which span?
   → OTEL_SERVICE_NAME env var → service.name attribute on every span

Q: Does the Java code need to be changed to emit traces?
   → No. Spring Boot + OTEL Java agent auto-instruments all HTTP + DB calls

Q: What is a "span" vs a "trace"?
   → Span = one operation (one HTTP call, one DB query)
   → Trace = the full tree of spans for one request from start to finish

Q: Why port 4318 and not 4317?
   → 4318 = OTLP/HTTP (plain HTTP). 4317 = OTLP/gRPC. DT ActiveGate accepts both.
```

---

## E2E Flow — What actually happens when order-service calls payment-service

```
User sends:  POST /api/v1/orders  →  order-service

INSIDE order-service JVM (OTEL Java agent intercepts):
  1. Agent starts a ROOT SPAN:
       trace_id  = "abc123..."  (random, unique for this request)
       span_id   = "aaa111"
       operation = "POST /api/v1/orders"
       start_time = T+0ms

  2. order-service calls payment-service HTTP:
       Agent creates a CHILD SPAN:
         trace_id  = "abc123..."  (SAME trace ID — links to parent)
         span_id   = "bbb222"
         parent_span_id = "aaa111"
         operation = "HTTP POST payment-service"
         start_time = T+40ms

       Agent INJECTS into the HTTP request headers:
         traceparent: 00-abc123...-bbb222-01
         ↑ This header travels with the HTTP call to payment-service

INSIDE payment-service JVM (OTEL Java agent intercepts incoming request):
  3. Agent reads the traceparent header from the incoming HTTP request
  4. Agent creates a CHILD SPAN:
       trace_id       = "abc123..."  (EXTRACTED from header — SAME trace ID)
       span_id        = "ccc333"
       parent_span_id = "bbb222"    (the span that made this HTTP call)
       operation      = "POST /api/v1/payments"
       start_time     = T+40ms

  5. payment-service queries PostgreSQL:
       Agent creates ANOTHER CHILD SPAN:
         trace_id       = "abc123..."
         span_id        = "ddd444"
         parent_span_id = "ccc333"
         operation      = "SELECT payments"
         start_time     = T+50ms
         end_time       = T+80ms  → duration = 30ms

  6. payment-service returns response:
       span "ccc333" ends at T+120ms → duration = 80ms

order-service receives response:
  7. span "bbb222" ends at T+120ms
  8. order-service finishes its own work:
       span "aaa111" ends at T+160ms → duration = 120ms (total request time including wait)

EACH SERVICE exports its own spans to DT ActiveGate independently:
  order-service  → POST http://dynatrace-activegate.dynatrace.svc:4318/v1/traces
  payment-service → POST http://dynatrace-activegate.dynatrace.svc:4318/v1/traces

DT receives all spans, sees they share trace_id "abc123..." → STITCHES into one trace:
  order-service [160ms]
    └── HTTP POST payment-service [80ms]
          └── POST /api/v1/payments [80ms]
                └── SELECT payments [30ms]
```

---

## Part 1 — The Two Env Vars

### `OTEL_EXPORTER_OTLP_ENDPOINT`

```yaml
- name: OTEL_EXPORTER_OTLP_ENDPOINT
  value: "http://dynatrace-activegate.dynatrace.svc:4318"
```

**What it controls:**
```
This env var tells the OTEL SDK where to SEND spans after they are recorded.
Without it: spans are recorded in memory but thrown away (no export).

Breaking it apart:
  http://                                    → OTLP/HTTP protocol (not gRPC)
  dynatrace-activegate                       → K8s Service name in the dynatrace namespace
  .dynatrace                                 → K8s namespace
  .svc                                       → K8s internal DNS suffix (means: cluster-internal)
  :4318                                      → OTLP/HTTP port

Full DNS resolution inside the cluster:
  dynatrace-activegate.dynatrace.svc.cluster.local:4318
  (K8s appends .cluster.local automatically)

Why use the ActiveGate's K8s Service (not the DT tenant URL directly)?
  DT tenant URL: https://abc12345.live.dynatrace.com  → internet, HTTPS, auth token required
  ActiveGate: runs INSIDE the cluster, accepts OTLP → forwards to DT tenant
  
  Benefits of going through ActiveGate:
    1. No internet egress per span (keeps all trace data inside the cluster network)
    2. No DT API token needed in app pods (the ActiveGate handles authentication)
    3. Lower latency (same cluster → microseconds vs internet → milliseconds)
    4. Works even if the DT tenant is temporarily unreachable (ActiveGate buffers)

Why HTTP (4318) not gRPC (4317)?
  Both work. HTTP is simpler to configure and easier to debug with curl.
  gRPC needs HTTP/2 support in load balancers; HTTP works everywhere.
  For production volume: gRPC is more efficient (binary encoding).
  This project uses HTTP for simplicity.
```

### `OTEL_SERVICE_NAME`

```yaml
- name: OTEL_SERVICE_NAME
  value: "payment-service"
```

**What it controls:**
```
Every span emitted by this JVM gets the attribute:
  service.name = "payment-service"

DT uses service.name to:
  1. Group spans into a service entity ("payment-service" service in DT UI)
  2. Route spans to the correct management zone (tag team:payments comes from namespace labels)
  3. Render the service name in the distributed trace view
  4. Link spans to SLOs (the SLO metric filter: eq(service.name,"payment-service"))

Without OTEL_SERVICE_NAME:
  DT receives spans with service.name = "unknown_service"
  All services look like one unnamed blob in DT
  Management zones cannot scope them correctly
  SLO metric filters don't match → SLOs always show 0 data

Each service MUST have a unique OTEL_SERVICE_NAME.
The value MUST match what you put in the DT metric event filter (eq(service.name,"...")).
```

---

## Part 2 — W3C traceparent Header (How Context Travels)

The header that glues spans across services into one trace:

```
traceparent: 00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01
             ↑   ↑                                ↑                 ↑
             │   trace-id (32 hex chars = 128 bit) │                 flags
             │                                     span-id (16 hex = 64 bit)
             version (always "00")

Meaning of each part:
  version: 00        → W3C Trace Context spec version 1
  trace-id           → unique ID for the ENTIRE distributed trace (all services share this)
  parent-span-id     → ID of the CALLING span (the span that made this HTTP request)
  flags: 01          → "sampled" bit = 1 = record this trace, 0 = drop it
```

**What happens at each service boundary:**
```
order-service creates root span:
  trace_id    = "4bf92f3577b34da6a3ce929d0e0e4736"  (new, random)
  span_id     = "aaa111aaa111aaa1"

order-service → payment-service HTTP call:
  OTEL SDK injects header:
    traceparent: 00-4bf92f3577b34da6a3ce929d0e0e4736-aaa111aaa111aaa1-01
                                                      ↑ this is order-service's current span_id

payment-service RECEIVES the HTTP request:
  OTEL SDK extracts trace_id = "4bf92f3577b34da6a3ce929d0e0e4736"  ← from header
  OTEL SDK extracts parent_span_id = "aaa111aaa111aaa1"             ← from header
  OTEL SDK creates NEW span_id = "bbb222bbb222bbb2" (random, new for payment-service)
  
  New span created:
    trace_id       = "4bf92f3577b34da6a3ce929d0e0e4736"  ← SAME
    span_id        = "bbb222bbb222bbb2"                  ← NEW (payment-service's own ID)
    parent_span_id = "aaa111aaa111aaa1"                  ← order-service's span

DT receives both spans (from separate export calls):
  Span 1: trace_id=4bf92... span_id=aaa111... (order-service)
  Span 2: trace_id=4bf92... span_id=bbb222... parent=aaa111... (payment-service)

DT groups by trace_id → builds parent-child tree from parent_span_id references → one trace.
```

---

## Part 3 — What "No Code Change" Actually Means

The screenshot says "works without any code change to the business logic." Here's how:

```
NORMAL Java code (what the developer writes):
  @RestController
  public class OrderController {
    @Autowired PaymentClient paymentClient;

    @PostMapping("/api/v1/orders")
    public Order createOrder(@RequestBody OrderRequest req) {
      Payment p = paymentClient.charge(req.getAmount());  // ← just a normal method call
      return orderRepo.save(new Order(req, p));
    }
  }

NO OTEL SDK calls. NO span creation. NO header injection. Just business logic.

WHAT THE OTEL JAVA AGENT DOES (attaches at JVM startup via -javaagent):
  It uses Java bytecode instrumentation to "wrap" known frameworks:
  
  When Spring MVC receives an HTTP request:
    → Agent starts a span automatically
    → span.setAttribute("http.method", "POST")
    → span.setAttribute("http.url", "/api/v1/orders")
    → span.setAttribute("service.name", "order-service")  ← from OTEL_SERVICE_NAME env var
  
  When RestTemplate / WebClient / Feign makes an HTTP call:
    → Agent starts a child span automatically
    → Agent injects traceparent header into the outgoing request automatically
    → No code change to PaymentClient needed
  
  When JDBC executes a SQL query:
    → Agent starts a child span automatically
    → span.setAttribute("db.statement", "SELECT * FROM payments WHERE ...")
    → span.setAttribute("db.system", "postgresql")
  
  When the method returns / exception is thrown:
    → Agent ends the span, records duration
    → Agent exports the span to OTEL_EXPORTER_OTLP_ENDPOINT

The developer sees none of this. Their code runs unchanged.
The OTEL agent is added only in the Dockerfile:
  ENTRYPOINT ["java", "-javaagent:/otel-javaagent.jar", "-jar", "app.jar"]
  (or via JVM_OPTS: -javaagent:/otel-javaagent.jar)
```

---

## Part 4 — What DT Does with the Spans

```
Each span arrives at DT ActiveGate as an OTLP/HTTP POST:
  POST http://dynatrace-activegate.dynatrace.svc:4318/v1/traces
  Content-Type: application/x-protobuf
  Body: { resourceSpans: [ { spans: [ {...}, {...} ] } ] }

ActiveGate:
  1. Validates the OTLP payload
  2. Enriches with K8s metadata (pod name, namespace, node)
  3. Forwards to DT SaaS tenant

DT tenant receives spans and:
  1. GROUPS by trace_id → all spans with same trace_id = one distributed trace
  2. BUILDS the tree using parent_span_id references
  3. CALCULATES:
       - Total trace duration (root span end - root span start)
       - Exclusive time per service (its span duration minus child span durations)
       - Error rate (any span with error=true)
  4. LINKS to:
       - The service entity (identified by service.name attribute)
       - The Kubernetes workload (identified by k8s.pod.name, k8s.namespace.name)
       - The management zone (via entity tags from namespace labels)

What you see in the DT trace waterfall view:
  order-service         ████████████████████ 160ms
    └── HTTP POST       ░░░░░░░████████████  80ms  (starts at T+40ms, 80ms long)
          payment-service  ░░░░░████████████ 80ms  (same time range)
            └── SELECT      ░░░░░░░░░███████ 30ms  (starts at T+50ms, 30ms long)

What this tells you:
  - 40ms spent in order-service BEFORE calling payment (business logic, validation)
  - 80ms in payment-service (30ms DB + 50ms application logic)
  - 40ms in order-service AFTER payment returned (writing to order DB)
  - PostgreSQL SELECT took 30ms → if this suddenly becomes 300ms, you see it here
```

---

## Part 5 — How ActiveGate Fits In

```
The full path of a span:

Java app pod (JVM)
    │
    │  OTEL Java agent collects spans in a buffer
    │  Every 5 seconds (default): flush buffer
    │
    ▼
POST http://dynatrace-activegate.dynatrace.svc:4318/v1/traces
    │
    │  K8s DNS resolves: dynatrace-activegate → ClusterIP of the ActiveGate Service
    │  Traffic stays INSIDE the cluster (no internet egress)
    │
    ▼
Dynatrace ActiveGate pod (in dynatrace namespace)
    │  Deployed by DynaKube → activeGate section
    │  capabilities: [routing, kubernetes-api-monitoring, log-analytics]
    │
    │  Receives OTLP spans → enriches with K8s metadata → batches
    │
    ▼
HTTPS POST https://abc12345.live.dynatrace.com/api/v2/otlp/v1/traces
    │
    │  One connection from ActiveGate to DT tenant (not one per pod)
    │  Authentication: token stored in the dynakube K8s Secret
    │
    ▼
Dynatrace SaaS tenant → stores, indexes, visualises
```

---

## Part 6 — Common Mistakes

| Mistake | What you see in DT | Fix |
|---------|-------------------|-----|
| `OTEL_SERVICE_NAME` not set | All services appear as `unknown_service` in traces | Set `OTEL_SERVICE_NAME` per service in Helm values.yaml |
| Different `OTEL_SERVICE_NAME` in DT metric filter vs actual name | SLO shows 0 data, metric events never fire | Exact string match required: `eq(service.name,"payment-service")` |
| `OTEL_EXPORTER_OTLP_ENDPOINT` uses HTTPS with wrong port | Spans silently dropped (TLS handshake fails) | Use `http://` for ActiveGate port 4318, or `https://` with port 4317 and correct cert |
| OTEL Java agent not in JVM_OPTS | No spans emitted at all | Add `-javaagent:/otel-javaagent.jar` to JVM_OPTS in values.yaml |
| Two services use same `OTEL_SERVICE_NAME` | Spans from both services appear under one service in DT | Each service must have a unique name |
| ActiveGate not running (DynaKube not applied) | Spans exported but never reach DT — lost in network | Check: `kubectl get pods -n dynatrace` → ActiveGate must be Running |
| `traceparent` header stripped by API gateway / load balancer | Each service appears as isolated spans, no chain | Configure ALB/gateway to pass-through W3C trace headers |

---

## Part 7 — Sampling (Why Not Every Request Is Traced)

```
The flags byte in traceparent controls sampling:
  traceparent: 00-trace_id-span_id-01   ← 01 = sampled (record this)
  traceparent: 00-trace_id-span_id-00   ← 00 = not sampled (drop this)

At high traffic (10,000 req/min), storing every span is expensive.
Sampling = record only a fraction of traces, discard the rest.

Types of sampling:

HEAD-BASED (decided at the start, before the request completes):
  order-service decides: sample this request? yes/no.
  Sets flag in traceparent = 01 or 00.
  payment-service RESPECTS the flag — records if 01, drops if 00.
  Pro: simple, consistent (whole trace recorded or whole trace dropped).
  Con: can't preferentially sample slow/errored requests (decision made upfront).

TAIL-BASED (decided after the full trace completes):
  All spans recorded in memory. After trace completes: was it slow or errored? 
  If yes → keep. If normal → drop.
  Pro: always keeps interesting traces.
  Con: requires holding all spans in memory until trace completes → higher memory use.

WHAT THIS PROJECT USES (implicit, via Dynatrace):
  DT ActiveGate does adaptive sampling automatically.
  Default: 100% of errored traces + a sample of successful traces.
  You don't configure this — DT manages it.

Implication for SRE:
  If you see "trace not found" for a specific request, it may have been sampled out.
  To guarantee a trace is captured: add a baggage header:
    X-DT-TraceState: sampling=1
  Or: in Java code, use OpenTelemetry API to force-sample:
    Span.current().setAttribute("sampling.priority", 1);
```
