# Glossary — OpenTelemetry Distributed Traces

Every term from main.md. One entry per term.

---

**OpenTelemetry (OTEL)**
An open-source standard (and SDK) for collecting traces, metrics, and logs from applications. Why it matters: it is vendor-neutral — the same Java agent sends data to Dynatrace, Jaeger, Zipkin, or any other backend.

**Distributed trace**
A record of a single user request as it flows through multiple services, showing every step and how long each took. Why it matters: without it, you see that order-service is slow but cannot tell if the slowness is inside order-service or caused by payment-service or the database.

**Span**
One unit of work inside a trace — represents a single operation (an HTTP request, a DB query, a method call) with a start time and duration. Why it matters: a trace is a tree of spans; each span records one hop in the request chain.

**Root span**
The first span in a trace — created by the first service that receives the user's request. Why it matters: its duration equals the total end-to-end time the user experienced. All other spans are descendants of the root.

**Child span**
A span created inside another span's operation — for example, the HTTP call payment-service makes to PostgreSQL. Why it matters: child spans show you exactly where time was spent within each service.

**trace_id**
A 128-bit random ID shared by ALL spans in one distributed trace. Why it matters: this is how Dynatrace knows that order-service span and payment-service span belong to the same request — they have the same trace_id.

**span_id**
A 64-bit ID unique to ONE span. Why it matters: `parent_span_id` on a child span points to the parent's `span_id`, building the parent-child tree.

**parent_span_id**
The span_id of the span that created this span. Why it matters: DT uses this field to reconstruct the call tree — "this payment-service span was called by that order-service span."

**W3C traceparent header**
An HTTP header (`traceparent: 00-<trace_id>-<parent_span_id>-<flags>`) that carries trace context from one service to another. Why it matters: this is the mechanism that links spans across service boundaries — without it, each service would see isolated unconnected spans.

**Context propagation**
The act of injecting trace context (trace_id, span_id) into outgoing HTTP headers so downstream services can create child spans linked to the same trace. Why it matters: this is what makes a distributed trace possible — context "propagates" across the network.

**OTLP (OpenTelemetry Protocol)**
The standard wire protocol for sending span data. Two variants: OTLP/HTTP (port 4318) and OTLP/gRPC (port 4317). Why it matters: `OTEL_EXPORTER_OTLP_ENDPOINT` tells the OTEL SDK which OTLP endpoint to send spans to.

**`OTEL_EXPORTER_OTLP_ENDPOINT`**
An environment variable that tells the OTEL SDK where to export spans. Set to the Dynatrace ActiveGate's internal cluster address. Why it matters: without this, spans are recorded in memory and then discarded — nothing reaches Dynatrace.

**`OTEL_SERVICE_NAME`**
An environment variable that sets the `service.name` attribute on every span emitted by this JVM. Why it matters: Dynatrace uses this to group spans into a named service entity; it must exactly match the string used in DT metric filters and SLO expressions.

**OTEL Java agent (`-javaagent`)**
A JAR file attached to the JVM at startup via `-javaagent:/otel-javaagent.jar` that automatically instruments Spring MVC, JDBC, RestTemplate, and other frameworks — no code changes needed. Why it matters: this is what enables "no code change" distributed tracing.

**Bytecode instrumentation**
The technique the OTEL Java agent uses to intercept method calls by rewriting Java bytecode at load time — similar to how a plumber installs meters in pipes without replacing the pipes. Why it matters: explains why business logic code doesn't need to call any OTEL API.

**JVMTI (Java Virtual Machine Tool Interface)**
The Java API that allows external agents (like the OTEL Java agent or Dynatrace OneAgent) to hook into a running JVM and modify its behavior. Why it matters: JVMTI is the mechanism that makes `-javaagent` work without source code access.

**Dynatrace ActiveGate**
A component that runs inside the Kubernetes cluster, accepts OTLP spans from application pods, enriches them with K8s metadata, and forwards them to the Dynatrace SaaS tenant. Why it matters: keeps trace data inside the cluster network (no internet egress per span), buffers data during DT tenant outages, and handles authentication centrally.

**Port 4318 (OTLP/HTTP)**
The standard port for sending OTLP spans over plain HTTP. Why it matters: `http://dynatrace-activegate.dynatrace.svc:4318` is the internal address app pods use to send traces to the ActiveGate.

**Port 4317 (OTLP/gRPC)**
Alternative OTLP port using gRPC (binary, more efficient). Why it matters: for high-throughput production systems, gRPC is more efficient than HTTP; both are supported by Dynatrace ActiveGate.

**`dynatrace-activegate.dynatrace.svc`**
The Kubernetes internal DNS name for the ActiveGate Service: `<service-name>.<namespace>.svc`. Why it matters: this resolves to the ClusterIP of the ActiveGate Service without leaving the cluster — all trace data stays on the internal network.

**ClusterIP**
A Kubernetes Service type that gives a stable internal IP address reachable only within the cluster. Why it matters: the ActiveGate Service has a ClusterIP — app pods can reliably send spans to `dynatrace-activegate.dynatrace.svc:4318` regardless of which node the ActiveGate pod is on.

**Span export / flush**
The OTEL SDK collects spans in memory and sends them in batches to the exporter endpoint every 5 seconds (default). Why it matters: spans are not sent one-by-one (too much overhead); they are batched. If the process dies before a flush, buffered spans are lost.

**Trace stitching**
The process where Dynatrace receives spans from multiple services and links them into one trace tree using the shared trace_id and parent_span_id fields. Why it matters: this is how the "order-service → payment-service → PostgreSQL" waterfall is built from separate span reports.

**Waterfall view**
A timeline visualization in Dynatrace showing each span as a horizontal bar, positioned at its start time and sized by its duration, with child spans indented under their parent. Why it matters: lets you visually see where time was spent in a request chain.

**Exclusive time**
How long a span ran excluding the time its child spans were running — the "own work" time of a service. Why it matters: if order-service total span = 160ms and the payment-service child span = 80ms, then order-service's exclusive time = 80ms (the time it spent on its own logic).

**Sampling**
Recording only a fraction of traces (e.g., 1 in 100) to reduce storage cost. Why it matters: at 10,000 req/min, storing every span is expensive; sampling keeps representative traces while cutting storage.

**Head-based sampling**
The decision to sample a trace is made at the START of the request, before any processing happens. The decision propagates via the `flags` byte in `traceparent`. Why it matters: simple and consistent — either the whole trace is recorded or none of it.

**Tail-based sampling**
The decision to sample is made AFTER the trace completes, so slow or errored traces can always be kept. Why it matters: ensures interesting (slow, failed) requests are always captured even if sampling rate is low.

**`flags` byte (traceparent)**
The last part of the `traceparent` header (`01` = sampled, `00` = not sampled). Why it matters: downstream services respect this flag — if `00`, they skip recording their spans, saving CPU and memory.

**`service.name` attribute**
An OTEL span attribute set by `OTEL_SERVICE_NAME` that identifies which service emitted the span. Why it matters: Dynatrace uses this to create named service entities and to match spans to SLOs and metric event filters.

**SLO metric expression filter**
In the DT SLO Terraform resource, `eq(service.name,"payment-service")` filters the SLI metric to only count requests from that specific service. Why it matters: must exactly match `OTEL_SERVICE_NAME` or the SLO will show no data.

**K8s metadata enrichment**
The ActiveGate adds Kubernetes context to each span: pod name, namespace, node name, deployment name. Why it matters: in DT you can filter traces by namespace or pod, and traces are automatically linked to the Kubernetes workload entity.

**`dynakube` Kubernetes Secret**
The K8s Secret containing the Dynatrace API token and PaaS token, created by ExternalSecret from AWS Secrets Manager. Why it matters: the ActiveGate uses this token to authenticate when forwarding spans to the DT SaaS tenant — app pods never need DT credentials.

**`traceparent` header stripping**
Some API gateways or load balancers remove unknown HTTP headers by default. Why it matters: if the ALB strips `traceparent`, payment-service never receives the trace context → it creates a NEW trace_id → the chain is broken → DT shows two unrelated traces instead of one.

**`unknown_service` (default service name)**
What DT shows when `OTEL_SERVICE_NAME` is not set. Why it matters: all services appear as the same unnamed service — impossible to distinguish order-service spans from payment-service spans in DT.

**OTLP payload**
The binary (protobuf-encoded) HTTP body sent to `/v1/traces`. Contains: resource attributes (service.name, k8s.pod.name), scope (instrumentation library), and the array of spans. Why it matters: understanding the format helps when debugging why spans aren't appearing in DT (use `-v` flag on curl to see the payload).
