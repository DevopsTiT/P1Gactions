# 25 — Synthetic Monitoring: Glossary

Every term and tool used in main.md, explained for an SRE beginner.

---

**Synthetic Monitoring**
A technique where a robot (not a real user) runs scripted checks against your app on a schedule. It simulates what a user would do (visit a page, call an API) and measures if it works and how fast. Contrast with Real-User Monitoring (RUM) which only records what actual users do.

**Real-User Monitoring (RUM)**
Collects performance and error data from real users as they use your app. Reactive — you only see data when users visit. Synthetic is proactive — you check even at 3 AM with zero real users.

**Browser Monitor**
A synthetic check that opens a real browser (Chromium) and navigates your website. Can click buttons, fill forms, scroll, and assert what the page shows. Catches JavaScript errors, rendering issues, and broken UI flows that a simple HTTP check would miss.

**HTTP Monitor**
A synthetic check that sends an HTTP request (GET, POST, etc.) to an API endpoint and checks the response code and body. Lighter than a browser check — no rendering, just raw HTTP. Used for API health checks and backend services.

**Multi-Step HTTP Monitor**
A sequence of HTTP requests where the output of one step (e.g., a JWT token from login) feeds into the next step. Used to test flows that require authentication before accessing data.

**Scripted Browser Monitor**
A browser monitor where you write JavaScript code that drives the browser step-by-step: "click this button, type in that field, assert this text appears." More powerful than a single-URL check. Used for login flows, checkout flows, multi-page journeys.

**Network Monitor (Ping / Port check)**
The simplest synthetic check — just verifies that a host is reachable over TCP/ICMP. "Is port 443 open on this server?" Useful for infrastructure checks where you don't care about HTTP content.

**Assertion**
A rule that must be true for a synthetic check to pass. Examples: "HTTP status must be 200", "response body must contain 'ok'", "page must contain text 'Welcome'". Without assertions, a check just measures speed — it won't detect returning wrong data.

**Threshold**
A performance limit. If the check takes longer than the threshold (e.g., 2000ms), the check is marked as a performance failure. Different from an assertion — a threshold is about speed, an assertion is about correctness.

**Synthetic Location**
The geographic place where the synthetic agent runs your check from. Public locations are run by Dynatrace from their cloud (Tokyo, Frankfurt, US-East, etc.). Running from multiple locations detects regional outages.

**Private Synthetic Location**
A synthetic agent you deploy inside your own network (e.g., on Kubernetes in your data center). Required when the service being checked is not publicly accessible (internal APIs, services behind VPN). The agent phones home to Dynatrace but runs checks locally.

**ActiveGate**
Dynatrace's on-premises agent that bridges your private network to the Dynatrace SaaS platform. A Private Synthetic Location runs on top of an ActiveGate. Also used for routing OneAgent data from isolated networks.

**Frequency / Schedule**
How often the synthetic check runs. Common values: 1 minute (aggressive, high cost), 5 minutes (good for APIs), 15 minutes (good for browser flows). More frequent = more sensitive to outages but more Dynatrace DEM units consumed.

**DEM Units (Digital Experience Monitoring Units)**
Dynatrace's billing unit for synthetic checks. Browser monitors cost more DEM units per run than HTTP monitors. Private location checks cost fewer units than public location checks.

**SLO (Service Level Objective)**
A target for a metric: "this API should be available 99.9% of the time." Synthetic checks are a clean input to SLO calculations because they run at fixed intervals — giving uniform, unbiased availability samples.

**Availability**
Whether a service responded successfully (status 200 + assertions passed). Expressed as a percentage over time. Synthetic availability = (successful runs / total runs) × 100.

**HAR File (HTTP Archive)**
A JSON recording of all network requests made during a browser session — URLs, timings, headers, sizes. Dynatrace Browser Monitor generates a HAR for each run. When a check fails, you open the HAR to see exactly which request failed and why.

**Waterfall Chart**
A visual timeline of all the network requests in a page load, stacked left-to-right in time order. Each bar shows how long one resource (HTML, JS, CSS, image) took to load. Instantly shows which resource is the bottleneck.

**Credential Vault**
Dynatrace's secure storage for synthetic test credentials (usernames, passwords, tokens). Scripts reference credentials by name instead of hard-coding values. Prevents secrets from appearing in logs, screenshots, or the Dynatrace UI.

**Dynamic Variable**
A value extracted from one HTTP response and injected into the next request in a multi-step monitor. Example: extract the JWT token from the /login response, then use it as the Authorization header in the next request.

**Dynatrace Terraform Provider**
A Terraform plugin (`dynatrace-oss/dynatrace`) that lets you create and manage Dynatrace resources (monitors, alert policies, dashboards, SLOs) as code instead of clicking in the UI. Enables version-controlled, reproducible synthetic monitoring config.

**Alert Policy (Alerting Profile)**
A Dynatrace rule that defines WHEN to generate a problem notification: which severity levels, which entities, with what delay. Think of it as a filter on top of Dynatrace's problem detection — "only alert me if synthetic availability drops and the problem lasts more than 0 minutes."

**Alert Delay**
A buffer before an alert fires. A 5-minute delay on performance alerts means: "only page me if latency is still bad after 5 minutes." Prevents waking someone up for a 10-second spike.

**PagerDuty**
An incident management platform. Dynatrace sends alert notifications to PagerDuty, which then routes them to the right on-call engineer via phone call, SMS, or app push. Manages escalations if the primary on-call doesn't respond.

**k6**
An open-source load and performance testing tool from Grafana. Write tests in JavaScript. Used here for synthetic checks that run in CI pipelines and in k6 Cloud for scheduled execution. Supports HTTP, browser (via k6 Browser / Playwright), WebSockets, and more.

**k6 Cloud**
Grafana's hosted version of k6 — runs your k6 scripts on a schedule from cloud locations, stores results, and shows dashboards. Alternative to Dynatrace Synthetic for teams already using k6.

**Playwright**
A browser automation library from Microsoft. Controls real Chromium/Firefox/WebKit browsers with JavaScript/TypeScript. k6 Browser wraps Playwright under the hood. Used in CI to test UIs like a real user.

**Checkly**
A third-party synthetic monitoring SaaS that uses Playwright for browser checks and native HTTP for API checks. Popular in the "monitoring-as-code" space — tests are defined in JavaScript files committed to your repo.

**Selenium**
The original browser automation framework. Dynatrace's older Browser Monitor scripting used a Selenium-style API. Modern tooling (Playwright, k6 Browser) is generally preferred for new tests but Selenium scripts remain common in existing Dynatrace setups.

**Global Outage**
In Dynatrace: when all synthetic locations for a monitor are failing. Triggers an immediate alert regardless of delay settings. Indicates a full service outage, not a regional network blip.

**Local Outage**
When only some locations fail. Could mean a regional CDN issue or network problem in one geography, not a full outage. Typically alerting is delayed or requires multiple consecutive failures from the same location.

**Certificate Monitor / SSL Expiry Check**
A synthetic check that verifies your HTTPS certificate is valid and not expiring soon (e.g., within 14 days). Certificates that expire silently take down HTTPS for all users — this check catches it before it happens.

**`data-test` Attribute**
An HTML attribute added by frontend developers specifically for automated tests: `<button data-test="submit-order">`. Using this instead of CSS classes or IDs makes synthetic browser scripts stable — even if the UI redesigns change class names, the data-test attribute stays. Best practice for browser automation.

**`jq`**
A command-line JSON processor. Used in shell commands to parse and filter JSON responses from the Dynatrace API. Example: `| jq '.monitors[] | {name, enabled}'` extracts just the name and enabled fields from each monitor in the JSON array.

**`terraform plan`**
A Terraform command that shows you what changes Terraform WOULD make (create, update, destroy) without actually making them. Always run before `terraform apply` to verify you're not accidentally deleting something.

**`terraform apply -target`**
Applies Terraform changes to ONE specific resource instead of everything. Safe for making isolated changes to one synthetic monitor without touching other infrastructure in the same Terraform state.
