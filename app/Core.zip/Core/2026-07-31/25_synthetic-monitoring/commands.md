# 25 — Synthetic Monitoring: Commands

---

## Phase 0 — Verify Dynatrace API connectivity

```bash
# Check tenant is reachable
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.monitors | length'

# List all existing synthetic monitors
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.monitors[] | {monitorId, name, type, enabled}'

# List available public locations
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/locations" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.locations[] | {entityId, name, type}'
```

---

## Phase 1 — Terraform init and plan (synthetic monitors)

```bash
# Navigate to synthetic infra directory
cd infra/synthetic

# Init Terraform with Dynatrace provider
terraform init

# Preview what will be created
terraform plan

# Apply HTTP monitor + multi-step monitor
terraform apply -target=dynatrace_http_monitor.api_health
terraform apply -target=dynatrace_http_monitor.order_api_flow

# Apply browser monitor
terraform apply -target=dynatrace_browser_monitor.checkout_flow
```

---

## Phase 2 — Verify monitors were created

```bash
# List monitors and confirm new ones appear
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.monitors[] | select(.name | contains("API Health"))'

# Get full config of one monitor
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq .
```

---

## Phase 3 — Check results and performance

```bash
# Get results for last 1 hour
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-1h&to=now" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.results[] | {timestamp, status, responseTime}'

# Get detailed step-by-step results (multi-step monitor)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-1h" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.results[] | .stepResults'

# Check availability summary (last 7d)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query?metricSelector=ext:synthetic.http.availability.location.total&resolution=1d&from=now-7d" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.resolution.data'
```

---

## Phase 4 — Private Location deployment (Kubernetes)

```bash
# Apply namespace first
kubectl apply -f infra/synthetic/private-location/namespace.yaml

# Create secret for Dynatrace token
kubectl apply -f infra/synthetic/private-location/secret.yaml

# Deploy the private location agent
kubectl apply -f infra/synthetic/private-location/deployment.yaml

# Confirm pods are running
kubectl get pods -n dynatrace-synthetic

# Watch logs to confirm agent registered
kubectl logs -f deployment/synthetic-private-location -n dynatrace-synthetic

# Confirm location appears in Dynatrace
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/locations?type=PRIVATE" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.locations[] | {entityId, name, status}'
```

---

## Phase 5 — k6 local synthetic test run

```bash
# Install k6 (macOS)
brew install k6

# Run browser synthetic test locally
k6 run tests/synthetic/homepage.spec.js

# Run with output to Dynatrace
K6_DYNATRACE_URL="https://YOUR_TENANT.live.dynatrace.com" \
K6_DYNATRACE_APITOKEN="$DT_API_TOKEN" \
k6 run --out dynatrace tests/synthetic/homepage.spec.js

# Run API synthetic test with assertions report
k6 run --summary-trend-stats="avg,min,med,max,p(95),p(99)" tests/synthetic/api-health.js
```

---

## Phase 6 — Operations and maintenance

```bash
# Pause a monitor (maintenance window)
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/pause" \
  -H "Authorization: Api-Token $DT_API_TOKEN"

# Resume a monitor
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/resume" \
  -H "Authorization: Api-Token $DT_API_TOKEN"

# Delete a monitor (Terraform preferred — but direct API if needed)
curl -X DELETE "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}" \
  -H "Authorization: Api-Token $DT_API_TOKEN"

# Rotate synthetic credentials (Terraform)
terraform apply -var="synth_user_password=$NEW_SYNTH_PASSWORD" \
  -target=dynatrace_credentials.synth_user_creds

# Check SLO status
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/slo?from=now-7d" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.slo[] | {name, status, evaluatedPercentage, target}'
```

---

## Phase 7 — Debugging a failing synthetic check

```bash
# Get the last failure details including error message
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-30m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.results[] | select(.status == "FAILED") | {timestamp, errorCode, errorMessage, responseTime}'

# Check if all locations are failing (global outage) vs one location (regional issue)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-1h" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.results[] | {location, status}' | sort

# Manually trigger a monitor execution (on-demand run)
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/execute" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"locations": ["GEOLOCATION-980DF339B0114B47"]}'
```
