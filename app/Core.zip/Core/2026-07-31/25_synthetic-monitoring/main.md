# 25 — Synthetic Monitoring: Implement and Manage

---

## Decision Tree — "What kind of synthetic check do I need?"

```
Is the path user-facing (browser/UI)?
├── YES → Browser / Selenium-style check (Dynatrace Browser Monitor, Playwright)
│         └── Multi-step login / checkout / search? → Scripted Browser
│         └── Just "is the page up and rendered?" → Single-URL Browser
└── NO → Is it an API / microservice?
          ├── YES → HTTP API check (Dynatrace HTTP Monitor / Postman / k6 Cloud)
          │         └── Need to chain token → call → assert? → Multi-step API Monitor
          │         └── Single endpoint health? → Simple HTTP check
          └── NO → Is it TCP / DNS / ICMP?
                    └── YES → Port / Ping check (Dynatrace Network Monitor)
```

---

## E2E Flow Summary

```
[You write a script / test definition]
        │
        ▼
[Synthetic agent runs on a schedule from N locations]
        │
        ├─ SUCCESS → metrics stored → SLO feeds → dashboard green
        │
        └─ FAILURE → alert fires → PagerDuty/Slack → on-call notified
                          │
                          └─ Waterfall / HAR / screenshot attached → RCA
```

---

## Tool Map

| Goal                           | Tool / Product                  |
|--------------------------------|---------------------------------|
| Browser check (Dynatrace)      | Dynatrace Browser Monitor       |
| HTTP API check (Dynatrace)     | Dynatrace HTTP Monitor          |
| Code-driven browser test       | Playwright + k6 Browser         |
| API performance testing        | k6 Cloud / Grafana Cloud k6     |
| Multi-location ping/port       | Dynatrace Network Monitor       |
| Open-source all-in-one         | Checkly                         |
| Terraform provisioning         | Dynatrace Terraform Provider    |
| Alert routing                  | PagerDuty / OpsGenie / Slack    |

---

## Part 1 — What Synthetic Monitoring Is (and Why It Matters)

**Real-user monitoring (RUM)** tells you what happened to real users.  
**Synthetic monitoring** tells you what WOULD happen — before users hit a bug.

A synthetic check is a **robot that pretends to be a user** and runs on a clock:
- It navigates to your URL / calls your API / pings your host
- It measures how long each step takes
- It asserts that the response is correct (status 200, specific text on page, JSON field value)
- It reports success/failure and performance metrics

**Why SREs care:**
1. Detect outages in regions where no real user is currently active (off-peak hours, new markets)
2. Feed SLO availability metrics with deterministic, continuous data — not noisy RUM samples
3. Catch certificate expiry, DNS failures, and CDN edge regressions silently before users do
4. Replay critical business flows (login → add-to-cart → checkout) on a schedule

---

## Part 2 — Anatomy of a Synthetic Check

Every check has six components:

```
┌─────────────────────────────────────────────────────┐
│  1. Script / Definition                             │
│     What to do: URL, steps, assertions              │
├─────────────────────────────────────────────────────┤
│  2. Schedule                                        │
│     How often: every 1m / 5m / 15m                 │
├─────────────────────────────────────────────────────┤
│  3. Locations                                       │
│     Where from: Tokyo, Frankfurt, US-East, Private  │
├─────────────────────────────────────────────────────┤
│  4. Thresholds / Assertions                         │
│     Pass/fail criteria: status=200, latency<2s      │
├─────────────────────────────────────────────────────┤
│  5. Alert Policy                                    │
│     Who gets paged and when (X failures → alert)   │
├─────────────────────────────────────────────────────┤
│  6. Results Storage                                 │
│     Metrics, screenshots, HAR files, waterfall      │
└─────────────────────────────────────────────────────┘
```

---

## Part 3 — Dynatrace Synthetic Monitors (Detailed)

### 3.1 HTTP Monitor (API / endpoint check)

**Use case:** Every 5 minutes, hit `GET /api/health` from 3 locations. Assert HTTP 200 and `"status":"ok"` in body.

**Create via Dynatrace UI:**
```
Synthetics → Create monitor → HTTP monitor
  → URL: https://your-app.example.com/api/health
  → Frequency: 5m
  → Locations: Tokyo, Frankfurt, N.Virginia
  → Add assertion: Response code = 200
  → Add assertion: Response body contains {"status":"ok"}
  → Alert policy: alert after 1 failure from any location
```

**Create via Dynatrace Terraform Provider:**
```hcl
# infra/synthetic/http-health-check.tf

resource "dynatrace_http_monitor" "api_health" {
  name      = "API Health Check – /api/health"
  enabled   = true
  frequency = 5          # minutes

  locations = [
    "GEOLOCATION-980DF339B0114B47",   # Tokyo
    "GEOLOCATION-9C4B318DA36C40F9",   # Frankfurt
    "GEOLOCATION-DDE0540079D14F2E",   # N. Virginia
  ]

  script {
    request {
      url         = "https://your-app.example.com/api/health"
      method      = "GET"
      description = "Health endpoint"

      validation {
        type  = "httpStatusesList"
        value = "200"
      }
      validation {
        type  = "bodyContains"
        value = "\"status\":\"ok\""
      }
    }
  }

  anomaly_detection {
    outage_handling {
      global_outage       = true
      global_outage_policy {
        consecutive_runs = 1
      }
    }
    loading_time_thresholds {
      enabled = true
      threshold {
        type           = "TOTAL"
        value_ms       = 2000
        request_index  = 0
      }
    }
  }
}
```

---

### 3.2 Multi-Step HTTP Monitor (API chain — auth → action → assert)

**Use case:** Obtain a JWT, then call a protected endpoint, assert the response.

```hcl
# infra/synthetic/multi-step-api.tf

resource "dynatrace_http_monitor" "order_api_flow" {
  name      = "Order API – Auth + Create Order"
  enabled   = true
  frequency = 10

  locations = [
    "GEOLOCATION-980DF339B0114B47",
    "GEOLOCATION-DDE0540079D14F2E",
  ]

  script {
    # Step 1: authenticate
    request {
      url         = "https://auth.example.com/oauth/token"
      method      = "POST"
      description = "Get JWT"
      post_data   = "client_id=synth&client_secret={{.env.SYNTH_SECRET}}&grant_type=client_credentials"

      # Store the token from the response
      dynamic_variables {
        name   = "auth_token"
        source = "RESPONSE_JSON_BODY"
        path   = "$.access_token"
      }

      validation {
        type  = "httpStatusesList"
        value = "200"
      }
    }

    # Step 2: call protected endpoint using token
    request {
      url         = "https://api.example.com/v1/orders"
      method      = "POST"
      description = "Create test order"

      headers = {
        "Authorization" = "Bearer {{auth_token}}"
        "Content-Type"  = "application/json"
      }

      post_data = jsonencode({
        item     = "synthetic-test-item"
        quantity = 1
        test     = true
      })

      validation {
        type  = "httpStatusesList"
        value = "201"
      }
      validation {
        type  = "bodyContains"
        value = "\"orderId\""
      }
    }
  }
}
```

---

### 3.3 Browser Monitor (Scripted — Selenium/DevTools protocol)

**Use case:** Every 15 minutes, log in as a synthetic user, search for a product, add to cart — assert success.

```javascript
// scripts/browser/checkout-flow.js
// Used in Dynatrace Browser Monitor "Script" field

// Step 1: Navigate and assert title
click('a[href="/login"]');
waitForElement('#email-input');
type('#email-input', 'synth-user@example.com');
type('#password-input', '{{.env.SYNTH_PASSWORD}}');
click('#login-btn');

// Step 2: Assert logged in
waitForElement('.user-dashboard', { timeout: 5000 });
assertText('.welcome-msg', 'Welcome, Synth');

// Step 3: Search
type('#search-box', 'laptop');
click('#search-btn');
waitForElement('.product-card');

// Step 4: Add first result to cart
click('.product-card:first-child .add-to-cart');
waitForElement('.cart-count');
assertText('.cart-count', '1');
```

**Terraform for Browser Monitor:**
```hcl
# infra/synthetic/browser-checkout.tf

resource "dynatrace_browser_monitor" "checkout_flow" {
  name      = "Browser – Checkout Flow E2E"
  enabled   = true
  frequency = 15
  type      = "MULTI_PROTOCOL"   # scripted

  locations = [
    "GEOLOCATION-980DF339B0114B47",
  ]

  script {
    type    = "javascript"
    version = "1.0"
    # reference to the JS script above loaded via Dynatrace
    events  = file("${path.module}/scripts/browser/checkout-flow.js")
  }

  key_performance_metrics {
    load_action_kpm    = "VISUALLY_COMPLETE"
    xhr_action_kpm     = "RESPONSE_END"
  }
}
```

---

## Part 4 — Playwright + k6 Browser (Code-First Approach)

When you want **synthetic checks in your CI pipeline** (not just Dynatrace):

```javascript
// tests/synthetic/homepage.spec.js  — runs in CI and as k6 Cloud scheduled test

import { browser } from 'k6/experimental/browser';
import { check } from 'k6';

export const options = {
  scenarios: {
    browser_test: {
      executor: 'constant-vus',
      exec:     'browserTest',
      vus:      1,
      duration: '30s',
    },
  },
};

export async function browserTest() {
  const page = browser.newPage();
  try {
    await page.goto('https://your-app.example.com');

    // Assert title
    check(page, {
      'title is correct': (p) => p.title() === 'My App – Home',
    });

    // Assert CTA button exists
    const btn = page.locator('text=Get Started');
    check(btn, {
      'CTA button visible': (b) => b.isVisible(),
    });

    // Measure time to interactive
    const navigationTiming = await page.evaluate(() => JSON.stringify(window.performance.timing));
    console.log('Nav timing:', navigationTiming);

  } finally {
    page.close();
  }
}
```

**Run locally:**
```bash
k6 run tests/synthetic/homepage.spec.js
```

**Run in CI (GitHub Actions):**
```yaml
# .github/workflows/synthetic.yml

name: Synthetic Smoke Tests

on:
  schedule:
    - cron: '*/15 * * * *'   # every 15 minutes
  push:
    branches: [main]

jobs:
  synthetic:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Run k6 synthetic check
        uses: grafana/k6-action@v0.3.0
        with:
          filename: tests/synthetic/homepage.spec.js
        env:
          K6_CLOUD_TOKEN: ${{ secrets.K6_CLOUD_TOKEN }}
```

---

## Part 5 — Private Synthetic Locations (Internal Services)

Public synthetic agents run from Dynatrace's cloud — they **cannot reach internal services** behind a VPN or firewall. You deploy a **Private Synthetic Location** inside your network:

```
[Dynatrace SaaS] ──────► [Private Location Agent on K8s]
                              │  (inside your VPN/cluster)
                              ▼
                    [Internal service: api.internal.example.com]
```

**Deploy Private Location Agent on Kubernetes:**
```yaml
# infra/synthetic/private-location/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: dynatrace-synthetic
```

```yaml
# infra/synthetic/private-location/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: synthetic-private-location
  namespace: dynatrace-synthetic
spec:
  replicas: 2
  selector:
    matchLabels:
      app: dt-synthetic
  template:
    metadata:
      labels:
        app: dt-synthetic
    spec:
      containers:
        - name: synthetic-agent
          image: dynatrace/synthetic-activegate:latest
          env:
            - name: DT_SERVER
              value: "https://YOUR_TENANT.live.dynatrace.com/communication"
            - name: DT_TENANT
              value: "YOUR_TENANT_ID"
            - name: DT_CAPABILITIES
              value: "synthetic"
          resources:
            requests:
              cpu: "500m"
              memory: "1Gi"
            limits:
              cpu: "2"
              memory: "2Gi"
```

```yaml
# infra/synthetic/private-location/secret.yaml
apiVersion: v1
kind: Secret
metadata:
  name: dt-synthetic-token
  namespace: dynatrace-synthetic
type: Opaque
stringData:
  DT_TOKEN: "<dynatrace-synthetic-activegate-token>"
```

**Register via Terraform:**
```hcl
# infra/synthetic/private-location.tf

resource "dynatrace_synthetic_location" "internal_k8s" {
  type           = "PRIVATE"
  name           = "Internal K8s – Tokyo DC"
  latitude       = 35.6762
  longitude      = 139.6503
  availability_location_outage = false
}
```

---

## Part 6 — Alert Policies and Notification Routing

### 6.1 Dynatrace Alert Policy (Terraform)
```hcl
# infra/alerting/synthetic-alert-policy.tf

resource "dynatrace_alerting" "synthetic_alerts" {
  name = "Synthetic Monitor Failures"

  rules {
    rule {
      delay_in_minutes = 0
      include_mode     = "INCLUDE_ALL"
      severity_level   = "AVAILABILITY"   # outage alerts
      tag_filter {
        include_mode = "INCLUDE_ALL"
      }
    }
    rule {
      delay_in_minutes = 5
      include_mode     = "INCLUDE_ALL"
      severity_level   = "PERFORMANCE"    # slow responses
      tag_filter {
        include_mode = "INCLUDE_ALL"
      }
    }
  }
}

resource "dynatrace_notification" "pagerduty_synthetic" {
  name    = "PagerDuty – Synthetic Failures"
  alerting_profile = dynatrace_alerting.synthetic_alerts.id
  type    = "PAGERDUTY"

  pagerduty {
    service_api_key = var.pagerduty_integration_key
    account         = "your-org"
    service_name    = "Synthetic Monitors"
  }
}
```

### 6.2 Alert Logic — When to fire

| Condition                  | Alert immediately? | Recommended setting        |
|----------------------------|--------------------|----------------------------|
| Single location failure    | No                 | Wait for 2 locations or 2 consecutive runs |
| All locations failing      | Yes                | Immediate (global outage)  |
| Latency > threshold        | No                 | 5-minute delay (avoid flap)|
| SSL cert expires < 14 days | Yes                | Certificate monitor alert  |

---

## Part 7 — SLO Integration

Synthetic checks are **ideal SLO data sources** — they run on a fixed schedule so you get uniform sampling.

```hcl
# infra/slo/api-availability-slo.tf

resource "dynatrace_slo_v2" "api_availability" {
  name        = "API Availability – /api/health"
  enabled     = true
  description = "99.9% availability measured by synthetic HTTP monitor"

  evaluation_type   = "AGGREGATE"
  metric_expression = "100*(ext:synthetic.http.availability.location.total)/(ext:synthetic.http.availability.location.total)"

  target    = 99.9
  warning   = 99.95
  timeframe = "-1w"

  filter = "type(\"SYNTHETIC_TEST\"),entityName.startsWith(\"API Health Check\")"
}
```

---

## Part 8 — Managing Credentials Securely

Never hard-code passwords in synthetic scripts. Use:

**Dynatrace Credential Vault:**
```hcl
# infra/synthetic/credentials.tf

resource "dynatrace_credentials" "synth_user_creds" {
  name            = "Synthetic Test User Password"
  type            = "USERNAME_PASSWORD"
  scope           = "SYNTHETIC"
  username        = "synth-user@example.com"
  password        = var.synth_user_password   # from TF_VAR_ env var
}
```

**Reference in script:**
```javascript
// In Browser Monitor JS script
type('#password-input', '{{.credentials.Synthetic Test User Password.password}}');
```

**In Terraform variables:**
```hcl
# infra/synthetic/variables.tf
variable "synth_user_password" {
  type      = string
  sensitive = true
}
```

---

## Part 9 — Operational Runbook (Day-2 SRE Tasks)

### Silence a flapping check during maintenance
```bash
# Disable a monitor for 30 minutes via Dynatrace API
curl -X POST "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/pause" \
  -H "Authorization: Api-Token $DT_API_TOKEN"
```

### Query recent results
```bash
# Get last 20 results for a monitor
curl "https://YOUR_TENANT.live.dynatrace.com/api/v1/synthetic/monitors/{monitorId}/results?from=now-1h" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.results[] | {timestamp, status, responseTime}'
```

### Add a new location to existing monitor
```bash
# In Terraform: add the new location ID to the locations list, then:
terraform plan -target=dynatrace_http_monitor.api_health
terraform apply -target=dynatrace_http_monitor.api_health
```

### Rotate synthetic credentials
```bash
# Update the Dynatrace Credential Vault secret
terraform apply -var="synth_user_password=$NEW_PASSWORD" \
  -target=dynatrace_credentials.synth_user_creds
```

---

## Part 10 — Common Mistakes

| Mistake                               | What goes wrong                                | Fix                                      |
|---------------------------------------|------------------------------------------------|------------------------------------------|
| Only 1 synthetic location             | Single point of failure; false positives       | Use ≥ 3 locations                        |
| Alert on first failure                | Noisy alerts from transient network blips      | Alert after 2+ consecutive failures      |
| Hard-coded credentials in script      | Secret leaks in UI / logs                      | Use Credential Vault                     |
| No assertions on response body        | Check passes even if app returns error page    | Always assert body content               |
| Check runs every 1 min unnecessarily  | High cost; SaaS limits hit                     | 5m for APIs, 15m for browser flows       |
| Public location checks internal URLs  | Timeouts that look like outages                | Deploy Private Synthetic Location        |
| Synthetic SLO uses wrong metric       | SLO data incorrect                             | Verify `ext:synthetic.*` metric name     |
| Browser script not updated after UI   | Script fails on renamed selectors              | Tag synthetic selectors with `data-test` attributes |
