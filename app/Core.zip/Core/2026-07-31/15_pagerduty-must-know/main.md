# PagerDuty — Everything an SRE Must Know

> PagerDuty is the on-call alerting and incident management platform.
> When Dynatrace (or any monitoring tool) detects a problem, it sends an alert to PagerDuty.
> PagerDuty decides WHO to wake up, HOW (phone/SMS/push), and WHEN to escalate if nobody responds.

---

## Decision Tree — The Lifecycle of Every Alert

```
Monitoring tool (Dynatrace / CloudWatch / Prometheus) fires
         │
         ▼
PagerDuty receives the alert → creates an INCIDENT
         │
         ▼
Is there a Service configured for this alert source?
  NO  → alert drops silently (misconfiguration — this is bad)
  YES → Escalation Policy is evaluated
         │
         ▼
Who is currently ON-CALL for this Escalation Policy?
  → Finds the current on-call engineer from the Schedule
  → Notifies them via: push notification → phone call → SMS (in order)
         │
         ▼
Did the on-call engineer ACKNOWLEDGE within the timeout (e.g., 30 min)?
  NO  → ESCALATE to Level 2 (senior engineer / manager)
  YES → Incident moves to ACKNOWLEDGED state
         │
         ▼
Is the incident RESOLVED?
  NO  → Engineer works the incident, adds notes
  YES → Engineer clicks RESOLVE → incident closed
         │
         ▼
Post-incident: write postmortem in Confluence
               link postmortem to the PagerDuty incident
```

---

## Part 1 — The 5 Core Concepts

### 1. Service

A PagerDuty Service maps to a monitored system. Examples:
```
payment-service-production
order-service-production
notification-service-production
eks-cluster-company-prod
aws-rds-production
```

Each Service has:
- An **integration key** (the webhook endpoint that monitoring tools POST alerts to)
- An **Escalation Policy** (who gets paged for this service)
- **Alert grouping rules** (prevent duplicate alerts from becoming 10 separate incidents)

**Why Services matter:**
```
payment-service-production → payments team on-call
eks-cluster-company-prod   → platform SRE team on-call

Without Services: EVERY alert goes to ONE person.
With Services:    the right team gets paged for their own service.
```

### 2. Escalation Policy

Defines the rules for WHO gets notified and in what ORDER if nobody responds.

```
Example: payment-service-production Escalation Policy

Level 1 (fires immediately):
  → payments-oncall Schedule (current on-call engineer)
  → timeout: 30 minutes

Level 2 (fires after 30 min if L1 doesn't acknowledge):
  → payments-senior-oncall Schedule (senior engineer / tech lead)
  → timeout: 30 minutes

Level 3 (fires after 60 min if L2 doesn't acknowledge):
  → sre-manager (always notified, no timeout)
```

**Key rule:** if you are on-call, YOU are Level 1. Not acknowledging means the manager gets woken up too. Acknowledge quickly — even if you haven't fixed anything yet.

### 3. Schedule

A calendar that defines who is on-call at any given moment.

```
Weekly rotation (most common):
  Week of 2026-07-28 → @engineer-A
  Week of 2026-08-04 → @engineer-B
  Week of 2026-08-11 → @engineer-C

Follow-the-sun rotation (for global teams):
  09:00–18:00 JST (Tokyo)   → @engineer-japan
  09:00–18:00 GMT (London)  → @engineer-london
  09:00–18:00 EST (NYC)     → @engineer-newyork
```

**Override:** temporarily replace the on-call person.
```
Use case: engineer-A is sick, engineer-B covers from 2pm–6pm today.
  → Schedule → Add Override → select engineer-B → set time range
  → Engineer-A's name disappears from the schedule for that window
  → All alerts during that window go to engineer-B
```

### 4. Incident

An incident is created when an alert arrives. States:

```
TRIGGERED   → alert received, nobody has acknowledged yet
ACKNOWLEDGED → on-call engineer saw it and is actively working it
RESOLVED    → problem fixed, incident closed

Substates:
  ACKNOWLEDGED + Snoozed → "I know, I'm working on it, stop re-paging me for 2 hours"
```

**Incident priority:**
```
P1 (Critical)  → production is down, revenue impact, wake up immediately
P2 (High)      → degraded service, users impacted, needs same-day resolution
P3 (Medium)    → issue confirmed, no immediate user impact, fix in business hours
P4 (Low)       → informational, schedule a fix
P5 (Informational) → FYI, no action needed
```

### 5. Notification Rules (Personal)

Each engineer configures HOW PagerDuty reaches them:

```
Recommended personal notification rules:
  Immediately:
    → PagerDuty mobile app push notification
    → SMS to mobile

  After 5 minutes (if no acknowledgement):
    → Phone call to mobile

  After 10 minutes:
    → Phone call again

Why have redundant rules?
  3am: phone is on silent.
  Push notification: probably missed.
  SMS: slightly more intrusive.
  Phone call: loud ringtone, wakes you up.
  Second phone call: in case you slept through the first.
```

**How to configure:**
```
PagerDuty UI → Profile icon → My Profile → Notification Rules
```

---

## Part 2 — What You Do When Paged

### The 3-step response — always in this order

```
Step 1: ACKNOWLEDGE (within 5 minutes)
  Mobile app: tap the notification → "Acknowledge"
  OR Web: go to pagerduty.com → Incidents → Acknowledge
  OR Phone: press "4" when the automated call asks

  Why acknowledge FAST:
    - Stops PagerDuty from escalating to your manager
    - Signals to the system: "a human is working this"
    - Does NOT mean you've fixed it — just that you're aware

Step 2: ADD A NOTE immediately
  "Investigating payment-service availability drop. Checking DT dashboard."
  Why: if you get stuck and someone else joins, they know where you started.

Step 3: WORK THE INCIDENT
  Open the relevant runbook in Confluence.
  Check Dynatrace for the alert details.
  Fix or escalate.
```

### When to SNOOZE vs RESOLVE

```
SNOOZE:
  The problem is real but you're working on a slow fix (e.g., waiting for a deploy).
  PagerDuty will re-open the incident after the snooze time if not resolved.
  Use: "Snooze for 2 hours" while a database restore is running.

RESOLVE:
  The problem is fixed. Metrics returned to normal. Users unaffected.
  ONLY click Resolve when the issue is actually gone.
  If you Resolve too early → problem comes back → new incident fires → on-call gets paged again.
```

### When to ESCALATE manually

```
You've been working the incident for 20 minutes with no progress.
You don't have access to fix it (e.g., need DBA for a database issue).
You identified root cause but the fix requires someone else.

How to escalate:
  Incident page → "Escalate" → select the next level / specific person → Add note explaining why
```

### Running an incident — the PACE framework

```
P — Problem: what exactly is broken? (use DT to quantify: error rate X%, latency Yms)
A — Action: what are you doing right now? (post in Slack #incidents channel)
C — Cause: do you know why? (checking DT root cause analysis, logs)
E — ETA: when will this be resolved? (give a rough estimate, update it)

Post a PACE update every 15 minutes in the incident's Slack thread.
Even if you have nothing new: "Still investigating. No new findings. ETA unknown."
Silence is the worst response during an incident.
```

---

## Part 3 — Integrations (How Alerts Arrive)

### Dynatrace → PagerDuty (what we already have)

```
In Terraform (terraform/modules/dynatrace/main.tf):

resource "dynatrace_pagerduty_notification" "critical" {
  alerting_profile = dynatrace_alerting.critical[each.key].id
  service_api_key  = var.pagerduty_integration_keys[each.key]
  # ↑ This is the Integration Key from the PagerDuty Service
}

Flow:
  Dynatrace detects: payment-service availability drops below SLO
  → Dynatrace fires webhook to PagerDuty integration URL
  → PagerDuty creates incident on "payment-service-production" Service
  → Escalation policy fires → on-call engineer gets paged
```

**Integration Key** = a unique URL that PagerDuty generates for each Service. It's the "email address" of that Service. Monitoring tools POST JSON payloads to this URL.

```
Format: https://events.pagerduty.com/v2/enqueue
Payload contains:
  - routing_key: <integration-key>    ← which Service this goes to
  - event_action: trigger/resolve/acknowledge
  - payload.summary: "payment-service P99 latency > 300ms"
  - payload.severity: critical/error/warning/info
```

### Other common integrations

```
AWS CloudWatch → PagerDuty
  CloudWatch alarm → SNS topic → PagerDuty webhook

Prometheus + Alertmanager → PagerDuty
  Alertmanager routes groups of alerts → PagerDuty receiver

GitHub Actions → PagerDuty
  Failed production deploy → trigger PagerDuty incident programmatically
  (useful for auto-rollback notification)

Slack → PagerDuty
  PagerDuty posts incident updates to #incidents Slack channel
  Engineers can acknowledge from Slack without opening PagerDuty
```

---

## Part 4 — On-Call Scheduling

### How a rotation works

```
Team: SRE (4 engineers: A, B, C, D)
Rotation: weekly
Schedule:
  Week 1: A on-call (Mon 09:00 – Mon 09:00 next week)
  Week 2: B on-call
  Week 3: C on-call
  Week 4: D on-call
  Week 5: A on-call again (repeats)
```

### Handling overrides

```
Scenario: Engineer A is going on holiday next week (normally A's week).

Option 1: Engineer A finds their own cover:
  → Agree with B that B will cover
  → Schedule → Create Override → select B → set A's entire week
  → PagerDuty confirms B is now on-call for that week

Option 2: Manager creates the override:
  → Same process, manager does it

Best practice:
  Set override BEFORE the week starts (not day-of).
  Confirm with the cover person they know they're on-call.
  Check PagerDuty "My On-Call" section to verify.
```

### How to check who is currently on-call

```
PagerDuty UI:
  → "Teams" → select your team → "On-Call Now" tab
  → Shows: who is on-call, for which schedule, until when

Mobile app:
  → "On-Call" tab → shows your own upcoming on-call shifts

CLI (for scripts/runbooks):
  curl -s -H "Authorization: Token token=<API_KEY>" \
    "https://api.pagerduty.com/oncalls?schedule_ids[]=<SCHEDULE_ID>&earliest=true"
```

---

## Part 5 — Incident Management (Beyond the Alert)

### Adding notes and timeline entries

```
Every significant action during an incident should be logged:
  "14:32 - Acknowledged. Checking DT."
  "14:38 - Root cause: DB connection pool exhausted. Restarting payment-service pods."
  "14:45 - Pods restarted, traffic recovering. Error rate: 0.5% → 0.02%."
  "14:52 - Resolved. Payment-service healthy. Error rate: 0.01%."

Why log every step?
  1. Postmortem: the timeline is built from these notes (no need to reconstruct from memory)
  2. Handoff: if you escalate, the next engineer reads these notes to catch up instantly
  3. Audit: management / SRE managers review incident timelines for quality
```

### Merging incidents

```
Scenario:
  payment-service fires 3 alerts at the same time:
    - Incident 1: availability SLO breach
    - Incident 2: latency P99 > 300ms
    - Incident 3: error rate > 0.1%

  These are all the SAME underlying problem (DB outage).
  Working 3 separate incidents = confusing.

  Solution: merge incidents.
  → Select all 3 incidents → "Merge" → pick the "parent" incident
  → Now you have 1 incident with all 3 alerts as sub-alerts
  → Resolving the parent resolves all merged sub-incidents
```

### Responders

```
You can add other engineers to an incident even if they're not on-call.
Use when:
  - You need a DBA and you're not a DBA
  - You need the product team to communicate with customers
  - You need a manager to make a business decision (e.g., roll back a release)

How to add:
  Incident page → "Add Responders" → search by name or team
  → They get paged immediately with the incident context
```

### Conference bridge

```
For major incidents (P1/P2): start a conference bridge.
  Incident page → "Add Conference Bridge" → paste Zoom/Meet link
  All responders see the link and can join.

Why a bridge?
  Typing in Slack during a P1 = too slow for coordinating 5 people.
  Voice call = faster, clearer, fewer misunderstandings.
  Bridge is logged in the incident timeline.
```

---

## Part 6 — Status Page

PagerDuty can drive a public or internal status page (PagerDuty Status Pages or connected to Atlassian Statuspage).

```
During an incident:
  → Update the status page manually OR configure auto-update from PagerDuty incidents
  → Customers see: "payment-service — Investigating" (not your internal incident details)

Status page components map to PagerDuty Services:
  "Payment Processing" component → payment-service-production PagerDuty Service
  When a P1 incident fires on that Service → component status changes to "Degraded"
  When resolved → component status returns to "Operational"
```

---

## Part 7 — Analytics and Postmortem

### PagerDuty Analytics (what to review)

```
Weekly/monthly review — look at:

  Mean Time to Acknowledge (MTTA):
    Average time from alert firing to engineer acknowledging.
    Target: < 5 minutes for P1, < 15 min for P2.
    If MTTA is high: notification rules are too slow, or on-call load is too high.

  Mean Time to Resolve (MTTR):
    Average time from alert firing to incident resolved.
    Target depends on SLO. P1 payment: < 30 min.
    If MTTR is high: runbooks are missing, or root causes are recurring.

  Incident volume by service:
    Which service fires the most alerts?
    High volume = noisy thresholds OR genuine reliability problem.
    Fix the thresholds first. Then fix the service.

  Alert fatigue score:
    How many incidents were resolved with no action (acknowledged + immediately resolved)?
    High count = false positives → tighten thresholds → reduce noise.
```

### Linking postmortem to incident

```
After you write the postmortem in Confluence:
  PagerDuty incident → "Postmortem" tab → "Link to page" → paste Confluence URL

Why link them?
  When this alert fires again 6 months later:
  → On-call engineer opens the incident
  → Sees "Postmortem from 2026-07 incident" linked
  → Reads it → knows what happened before → resolves faster
```

---

## Part 8 — Mobile App (Critical for On-Call)

```
Download: PagerDuty for iOS / Android

Configure:
  → Log in → go to Profile → Notification Rules
  → Set high-urgency override: override phone's Do Not Disturb for PagerDuty
    (iOS: Settings → PagerDuty → Notifications → Critical Alerts → ON)
    This means PagerDuty calls get through even when your phone is on silent.

Must-have settings:
  ✓ Critical Alerts enabled (overrides silent mode)
  ✓ PagerDuty ringtone set to loud/distinct (different from regular calls)
  ✓ High urgency: phone call after 5 min of no acknowledgement
  ✓ Face ID / biometrics enabled (so you can unlock phone half-asleep at 3am)

Test your setup:
  Before your first on-call week:
    PagerDuty → My Profile → "Send Test Notification"
    → Verify all notification methods work
    → Verify your phone wakes up even on silent
```

---

## Part 9 — On-Call Best Practices for SREs

```
BEFORE your on-call week starts:
  [ ] Check the schedule: confirm you're on-call and know the exact start/end time
  [ ] Check for overrides: someone else covering any part of your week?
  [ ] Test your notifications: PagerDuty → Send Test Notification
  [ ] Read new runbooks added since your last rotation
  [ ] Make sure your laptop is charged / accessible at all times
  [ ] Tell your team/family: you may be interrupted evenings/nights

DURING your on-call week:
  [ ] Keep PagerDuty app open
  [ ] Keep laptop nearby after business hours
  [ ] For every alert:
      - Acknowledge within 5 min
      - Add notes as you work
      - Resolve only when truly fixed
      - Link runbook to the incident
  [ ] If you can't respond (brief unavailability): set an override for that window

AFTER your on-call week:
  [ ] Review your incidents: were thresholds causing noise? File a ticket to fix it.
  [ ] Write/update runbooks for any alert that had no runbook
  [ ] Write postmortems for any P1/P2 that don't have one yet
  [ ] File tickets for recurring issues (same alert firing 3+ times = systemic problem)
```

---

## Part 10 — Escalation Etiquette

```
When you escalate to Level 2:
  BEFORE you click Escalate, post a Slack message:
  "@senior-engineer I'm escalating PLAT-INC-1234 to you.
   Summary: payment-service DB pool exhausted.
   What I tried: restarted pods, pool recovered temporarily but issue returned.
   I need: DBA to increase pool size in RDS parameter group.
   Incident: <link>"

  Never escalate silently. The person receiving the escalation needs context.

When you're Level 2 and get escalated to:
  Acknowledge the PagerDuty incident.
  Read the notes the L1 engineer left.
  DM them: "I got the escalation. What's the current status?"
  Work together or take over — communicate clearly.

When the on-call engineer is you AND you are the incident commander:
  Separate roles:
    Incident Commander: coordinates, communicates, makes decisions
    Engineers:          investigate, fix

  For P1 incidents: if possible, have ONE person as IC (not fixing)
  and ONE person as the fixer. IC talks to Slack/stakeholders,
  fixer talks to the terminal.
```

---

## Keyboard Shortcuts (PagerDuty Web)

| Shortcut | Action |
|----------|--------|
| `a` | Acknowledge selected incident |
| `r` | Resolve selected incident |
| `n` | Add note to incident |
| `e` | Escalate incident |
| `m` | Merge incidents |
| `/` | Search |
| `?` | Show all shortcuts |
