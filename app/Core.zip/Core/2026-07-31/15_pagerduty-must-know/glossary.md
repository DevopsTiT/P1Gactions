# Glossary — PagerDuty Must-Know for SREs
Every term from main.md. One entry per term. SRE beginner level.

---

**PagerDuty**
An on-call alerting and incident management platform. When monitoring detects a problem, PagerDuty decides who to wake up, how (push/SMS/phone), and when to escalate if nobody responds. Why it matters: the bridge between "monitoring detected a problem" and "the right human is working on it."

**On-call**
A rotation where one engineer per team is designated as the primary responder for all alerts during a specific time window (usually one week). If an alert fires at 3am, the on-call engineer's phone rings. Why it matters: production never sleeps — someone must always be reachable for critical incidents.

**Incident**
A PagerDuty object created when an alert arrives. Has states: TRIGGERED → ACKNOWLEDGED → RESOLVED. Contains all notes, timeline, linked alerts, and responders. Why it matters: the central record of everything that happened during a production problem.

**TRIGGERED**
The state of a new incident that nobody has acknowledged yet. PagerDuty is actively notifying people. Escalation clock is ticking. Why it matters: every second in TRIGGERED state means the problem may be growing with no human awareness.

**ACKNOWLEDGED**
An engineer has seen the incident and is actively working it. Escalation to L2 stops. Why it matters: tells PagerDuty "a human is on this — stop paging the manager." Does NOT mean the problem is fixed.

**RESOLVED**
The incident is closed. Problem is confirmed fixed, metrics returned to normal. Why it matters: only mark resolved when truly fixed — premature resolution means the problem comes back and pages the on-call engineer AGAIN with a NEW incident.

**SNOOZED**
A temporary pause on re-notification for a set duration (e.g., 2 hours). Used when you're actively working a slow fix. Why it matters: prevents PagerDuty from repeatedly notifying you about an issue you're already handling (e.g., waiting for a database restore to complete).

**Service (PagerDuty)**
A logical entity in PagerDuty representing a monitored system (e.g., `payment-service-production`). Each Service has an integration key, an escalation policy, and alert routing rules. Why it matters: routes alerts to the right team — payment alerts go to payments team, EKS alerts go to platform SRE.

**Integration Key**
A unique secret token (URL) that PagerDuty generates per Service. Monitoring tools POST alerts to this endpoint. Like an email address for a PagerDuty Service. Why it matters: this is what goes into Terraform as `service_api_key` for the `dynatrace_pagerduty_notification` resource.

**Escalation Policy**
A rule set defining: who gets notified at Level 1, how long to wait before escalating to Level 2, who Level 2 is, and so on. Why it matters: ensures that if the on-call engineer doesn't respond (asleep, sick, distracted), the incident automatically reaches a senior engineer or manager.

**Escalation Level**
A numbered tier in the escalation policy. Level 1 = on-call engineer. Level 2 = senior engineer or team lead. Level 3 = manager. Each level has a timeout — if nobody at L1 acknowledges in 30 minutes, L2 gets paged. Why it matters: every incident eventually reaches a human who can act, even if multiple people are unavailable.

**Schedule**
A PagerDuty calendar showing which engineer is on-call at any given time. Defines rotations (who is on-call and when). Why it matters: the source of truth for "who do I call right now?" — escalation policies pull from schedules to know who to notify.

**Rotation**
A repeating on-call pattern. Weekly rotation: engineer A → B → C → D → A again. Follow-the-sun: different engineers by timezone across 24 hours. Why it matters: spreads the on-call burden fairly across the team — no single engineer is always on-call.

**Override**
A temporary replacement in the schedule. "Engineer A is sick; engineer B covers from 2pm–6pm today." Why it matters: the override replaces A's name on the schedule for that window — all alerts during that window go to B, not A.

**Notification Rules (personal)**
Per-engineer settings controlling HOW PagerDuty reaches you: push notification immediately, SMS after 2 min, phone call after 5 min, second call after 10 min. Why it matters: customizable per-person — configure so that a 3am page actually wakes you up (most people need a phone call, not just a push notification).

**High-Urgency vs Low-Urgency**
High-urgency = production alerts that need immediate response (phone call override). Low-urgency = informational alerts that can wait for business hours (only email). Why it matters: not every alert needs to wake someone up — low-urgency prevents noise; high-urgency ensures real problems are addressed.

**Critical Alerts (iOS/Android setting)**
A phone OS setting that allows specific apps (like PagerDuty) to bypass Do Not Disturb and silent mode. Why it matters: if this is not enabled, a P1 at 3am with your phone on silent = you sleep through it = escalation to your manager.

**MTTA (Mean Time to Acknowledge)**
The average time from when an alert fires to when an engineer acknowledges it. Measured in minutes. Target: under 5 minutes for P1. Why it matters: high MTTA means incidents go unattended — either notification rules are too slow, on-call is overloaded, or paging is noisy and engineers are ignoring it.

**MTTR (Mean Time to Resolve)**
The average time from when an alert fires to when the incident is resolved. Measured in minutes/hours. Why it matters: MTTR directly measures your team's incident response effectiveness. High MTTR = bad runbooks, hard-to-diagnose systems, or systemic recurring problems.

**P1 / P2 / P3 / P4 / P5 (Incident Priority)**
Priority levels: P1 = critical, production down, revenue impact. P2 = degraded, users affected. P3 = issue confirmed, no immediate user impact. P4 = low priority, scheduled fix. P5 = informational. Why it matters: determines urgency of response — P1 wakes you up at 3am, P4 gets filed in the backlog.

**Alert Fatigue**
When too many false or low-value alerts fire, engineers start ignoring all alerts — including real ones. Why it matters: the number one reason monitoring setups fail in practice. Fix noisy thresholds immediately — a team that cries wolf eventually gets eaten by the wolf.

**Alert Grouping**
A PagerDuty setting that merges related alerts (multiple DT alerts for the same outage) into a single incident instead of creating 10 separate incidents. Why it matters: during a DB outage, 5 services all fire errors simultaneously — 5 separate incidents = chaos. 1 grouped incident = clarity.

**Merging Incidents**
Manually combining multiple open incidents into one parent incident when they share the same root cause. Why it matters: working 3 separate incidents for the same problem is confusing and creates duplicate notes and resolution steps.

**Responders**
Additional engineers added to an incident beyond the on-call engineer. Added when you need a specialist (DBA, network engineer, product manager). Why it matters: some incidents require skills the on-call engineer doesn't have — adding a responder pages the right expert immediately.

**Conference Bridge**
A shared call link (Zoom, Meet) added to a PagerDuty incident for voice coordination during major incidents. Why it matters: typing in Slack is too slow for coordinating 5 engineers during a P1. Voice = faster decisions, fewer misunderstandings.

**Incident Commander (IC)**
During a major incident, one person takes the IC role: coordinates people, communicates status, makes decisions. They do NOT fix the problem — that's for the engineers. Why it matters: without an IC, everyone is investigating and nobody is communicating — chaos. With an IC: clear decisions, regular updates, no duplication.

**PACE framework**
A structure for incident communication: Problem (what broke), Action (what you're doing), Cause (root cause if known), ETA (when it'll be fixed). Post updates every 15 minutes. Why it matters: stakeholders and other engineers need regular, structured updates — not silence for 45 minutes then "fixed."

**Timeline (PagerDuty incident)**
An ordered log of every note, state change, and responder addition during an incident. Generated from the notes engineers add during the incident. Why it matters: the postmortem timeline is built directly from this — if you add good notes during the incident, the postmortem writes itself.

**Postmortem (PagerDuty link)**
PagerDuty incidents have a "Postmortem" tab where you link the Confluence postmortem page. Why it matters: when the same alert fires again 6 months later, the next on-call engineer can read the previous postmortem directly from the PagerDuty incident.

**Status Page**
A public or internal page showing the health of your services. Connected to PagerDuty so that when a P1 fires, the status page automatically shows "Investigating" to customers. Why it matters: keeps customers informed without engineers having to manually post updates — reduces customer support load during incidents.

**Follow-the-Sun rotation**
An on-call schedule where different engineers in different timezones cover different parts of the 24-hour day (Tokyo covers Asia hours, London covers Europe hours, NYC covers Americas hours). Why it matters: engineers are never paged outside their local business hours — better wellbeing, faster response (awake person responds faster).

**PagerDuty API / Integration key**
The integration key is used in API payloads to route alerts to the correct Service. The PagerDuty REST API allows reading schedules, creating/resolving incidents programmatically. Why it matters: used in Terraform (`service_api_key`) to wire Dynatrace notifications to the right PagerDuty Service.

**Dynatrace → PagerDuty integration**
Configured in Terraform via `dynatrace_pagerduty_notification` resource. The `service_api_key` is the PagerDuty integration key stored in AWS Secrets Manager. Why it matters: this is the wiring that makes Dynatrace alerts become PagerDuty incidents — without it, DT alerts fire silently with no human notification.

**Oncall burnout**
The mental and physical fatigue from too many on-call nights, noisy alerts, or an unfair rotation. Why it matters: high on-call burden is a top reason senior engineers leave. Fixing noisy thresholds and rotating fairly directly impacts team retention.

**Send Test Notification**
A PagerDuty feature (My Profile → Send Test Notification) that fires a real notification to all your configured channels. Why it matters: must run before your first on-call shift to verify your phone actually rings — discovering broken notification rules at 3am is too late.
