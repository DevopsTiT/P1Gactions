# Design, Implement, and Manage Monitoring Solutions with Dynatrace
## SRE Deep Dive

> Context: 3 Java Spring Boot microservices (payment, order, notification) on AWS EKS,
> 3 environments (dev/staging/production), Dynatrace as the primary observability platform.
>
> This guide covers the FULL lifecycle: design decisions → implementation → day-to-day management.

---

## E2E Flow — How Monitoring Gets Built

```
DESIGN PHASE
  Step 1: Define what "healthy" means per service
          → SLOs, alert thresholds, notification routing
  Step 2: Choose monitoring layers
          → Infrastructure, JVM, application, business, synthetic
  Step 3: Plan the data model
          → What tags, management zones, alerting profiles are needed?

IMPLEMENTATION PHASE
  Step 4: Deploy OneAgent via DynaKube (GitOps + ArgoCD)
          → Auto-instruments Java: metrics, traces, logs — zero code change
  Step 5: Configure Dynatrace resources via Terraform
          → Management zones, metric events, SLOs, synthetics, notifications
  Step 6: Add custom OTEL metrics in the app (for business SLOs)
          → MeterRegistry counters for payments success, message processing
  Step 7: CI/CD sends deployment events to DT
          → Vertical markers on metric charts for every deploy

MANAGEMENT PHASE
  Step 8: Weekly SLO review
          → Is error budget healthy? Any burn rate alerts?
  Step 9: Threshold tuning (ongoing)
          → Too many false alerts? Tighten or relax thresholds.
  Step 10: Quarterly observability review
           → Are we monitoring the right things? What gaps?
```

---

## Decision Tree — Design Decisions Before You Write Any Terraform

```
For each service, answer these questions FIRST:

Q1: Is this service user-facing (synchronous)?
  YES → SLO targets: 99.9% availability, strict latency (300ms)
         Alert tier: CRITICAL (PagerDuty phone call) for availability breach
  NO  → SLO targets: 99.0–99.5%, relaxed latency (1000ms)
         Alert tier: HIGH (PagerDuty push) — not phone call

Q2: Does this service handle money / irreversible operations?
  YES → Add business transaction SLO (HTTP 200 ≠ payment succeeded)
         Add extra synthetic from 3+ locations
         P1 incident if error rate > 0.1% (not 1%)
  NO  → Standard thresholds apply

Q3: Does this service call a database?
  YES → Add DB error rate SLO + DB latency SLO
  NO  → Skip DB SLOs

Q4: Does this service consume a message queue?
  YES → Add message processing SLO (custom OTEL metric)
  NO  → Skip

Q5: What environments exist?
  → Dev:     relaxed thresholds, Slack only, no PagerDuty
  → Staging: medium thresholds, PagerDuty for HIGH+
  → Prod:    strict thresholds, PagerDuty for CRITICAL + HIGH

Q6: Who should receive alerts?
  → Per service, per team:
    payment-service → payments team PagerDuty + #alerts-payments Slack
    order-service   → orders team PagerDuty + #alerts-orders Slack
    platform infra  → SRE team PagerDuty + #alerts-platform Slack
```

---

## Part 1 — The Monitoring Layers

### Layer 1: Infrastructure (EKS Nodes, Pods)

**What DT collects automatically (OneAgent):**
```
Node-level metrics:
  builtin:host.cpu.usage           ← node CPU %
  builtin:host.mem.usage           ← node memory %
  builtin:host.disk.usedPct        ← disk space %
  builtin:host.net.errorRate       ← packet error rate

Pod/Container metrics:
  builtin:kubernetes.workload.pods.runningCount   ← pods up vs expected
  builtin:kubernetes.workload.pods.restarts       ← crash/restart count
  builtin:container.cpu.usage                     ← container CPU (not node)
  builtin:container.memory.usage                  ← container memory vs limit

Why this matters:
  A node running at 95% CPU → ALL pods on that node slow
  A pod restarting → in-flight requests fail → users see errors
  Disk full → log writes fail → logging stops → blind to future incidents
```

**How it gets configured:**
```yaml
# gitops/dev/monitoring/dynatrace/dynatrace-operator.yaml
spec:
  kubernetesMonitoring:
    enabled: true   ← this single flag enables ALL Kubernetes metrics
  classicFullStack:
    enabled: true   ← deploys OneAgent DaemonSet on every node
```

**Alert we add for pods:**
```hcl
# terraform/modules/dynatrace/main.tf
resource "dynatrace_metric_events" "pod_restarts" {
  metric_key = "builtin:kubernetes.workload.pods.restarts"
  threshold  = each.value.pod_restart_threshold  # prod: 2, staging: 3, dev: 5
  # fires when N restarts in 5 minutes — catches crash loops early
}
```

---

### Layer 2: JVM Process (Java-Specific)

**What DT collects automatically (JVMTI injection via OneAgent):**
```
Heap metrics:
  builtin:process.memory.jvm.heapUtilization   ← % of -Xmx used
  builtin:process.memory.jvm.garbageCollectionTime ← ms/min in GC pause

Process metrics:
  builtin:process.cpu.usage        ← process-level CPU (not container-level)
  builtin:process.memory.usage     ← RSS as % of container limit
  builtin:process.jvmThreadCount   ← active JVM threads

How OneAgent gets JVMTI access:
  classicFullStack mode → OneAgent pod runs with hostPID: true
  → Scans all JVM processes on the node
  → Injects Java agent via JVMTI (no code change, no -javaagent flag needed)
  → Captures everything automatically
```

**The JVM monitoring alert chain:**
```
EARLY WARNING (set threshold at heap 70%):
  jvm_heap_pct fires → "heap is high, investigate"
  Engineer checks: is it a memory leak (ramp) or heavy load (sawtooth)?

DANGER ZONE (set threshold at GC time 200ms/min):
  garbageCollectionTime fires → "GC is consuming significant CPU time"
  At this point: latency P99 will start rising in 5–10 minutes

IMMINENT FAILURE (if nothing done):
  memory_usage_pct fires → "RSS approaching container limit"
  OOM kill is 5–10 minutes away without intervention

The three alerts form a PROGRESSIVE WARNING SYSTEM.
Each gives you more time to act before the pod dies.
```

---

### Layer 3: Service / Application (HTTP Requests)

**What DT collects automatically:**
```
Request flow metrics (per service, per endpoint):
  builtin:service.requestCount.server           ← requests received per minute
  builtin:service.errors.server.rate            ← % returning 5xx
  builtin:service.errors.server.count           ← count of 5xx errors
  builtin:service.response.time                 ← latency (supports :percentile(99))

Client call metrics (outbound calls TO other services):
  builtin:service.requestCount.client           ← requests MADE per minute
  builtin:service.errors.client.count           ← failed outbound calls

DB connection metrics:
  builtin:service.dbconnectioncount             ← DB calls per minute
  builtin:service.dbconnectionlatency           ← DB call duration
  builtin:service.dbconnectionfailcount         ← failed DB calls
```

**The 8 metric events we implement:**
```
Signal 1: Traffic drop    → catches silent outages (no traffic = all other metrics lie)
Signal 2: Error rate      → catches 5xx spikes
Signal 3: Latency P99     → catches slow responses
Signal 4: CPU saturation  → catches resource exhaustion before it causes errors
Signal 5: Memory usage    → catches OOM approach before pod death
Signal 6: JVM heap        → catches Java-specific memory pressure
Signal 7: Pod restarts    → catches crash loops
Signal 8: Network errors  → catches infrastructure-level packet loss
```

**Why 8 and not just error rate + latency:**
```
Error rate = 0% when traffic = 0  (silent outage → Signal 1 catches it)
Latency = N/A when no traffic     (Signal 1 catches it)
Error rate OK but pods restarting  (Signal 7 catches it — restart doesn't always show errors)
All metrics OK but heap filling    (Signal 6 gives early warning before it affects users)
All metrics OK but network flapping (Signal 8 catches intermittent packet loss)
```

---

### Layer 4: Distributed Tracing (Request Journeys)

**How traces flow through the system:**
```
order-service → payment-service → PostgreSQL
      ↓
      → notification-service → SQS

Each service emits OTEL spans to DT ActiveGate:
  env var: OTEL_EXPORTER_OTLP_ENDPOINT = http://dynatrace-activegate.dynatrace.svc:4318
  env var: OTEL_SERVICE_NAME = "payment-service"

DT stitches spans together using trace IDs in HTTP headers:
  order-service: creates trace ID "abc123", passes it in X-B3-TraceId header
  payment-service: reads trace ID "abc123", creates child span under it
  DT: both spans share "abc123" → rendered as one connected trace
```

**What traces enable (beyond metrics):**
```
1. Which ENDPOINT is slow? (not just "payment-service is slow")
   → POST /api/v1/payments P99 = 820ms
   → GET /api/v1/payments/{id} P99 = 45ms (fast)
   → Only POST is the problem → query in POST handler, not GET handler

2. Where in the call chain? (not just "payment-service is slow")
   → payment-service total: 820ms
   → auth: 2ms, business logic: 5ms, DB SELECT: 813ms
   → DB call is the bottleneck

3. What is the exact DB query?
   → DT captures the SQL statement: "SELECT * FROM payments WHERE user_id = ?"
   → 813ms for this query → missing index on user_id

4. How many DB calls per request?
   → Normal: 2 DB calls per request
   → After deploy: 52 DB calls per request (N+1 query bug introduced)
   → Immediately visible in trace waterfall
```

**Configuring trace retention:**
```
In DT tenant settings (not in Terraform — done via DT UI or API):
  Transaction Tracing → Sample rate:
    Production: 100% for errors, 10% for normal requests (reduces storage cost)
    Staging: 100% always (full visibility for testing)
    Dev: 100% (small traffic volume, affordable)

  Retention:
    Errors: 30 days
    Normal: 7 days

This means:
  Every failed request in production is kept for 30 days for RCA.
  Normal requests: 10% sample → still statistically representative for performance analysis.
```

---

### Layer 5: Logs (Application Output)

**How logs flow:**
```
Java app writes to stdout (container log)
  → Docker/containerd writes to /var/log/containers/<pod>.log on the node
  → OneAgent reads /var/log/containers/*.log (logMonitoring: enabled: true in DynaKube)
  → Sends to DT Grail (log analytics engine)
  → Searchable in DT Logs view with full-text search and structured fields

Benefits over traditional logging (CloudWatch / Elasticsearch):
  1. Automatic correlation: log entries automatically linked to DT entities (service, process, pod)
  2. Trace correlation: logs tied to trace IDs → jump from log to trace instantly
  3. No log agent needed: OneAgent handles it (no Fluent Bit, no sidecar)
  4. AI log anomaly detection: DT learns "normal" log patterns → alerts on unusual log patterns
```

**Log structure for easy DT querying:**
```java
// Use structured JSON logging (logback configuration)
// log message format:
{
  "timestamp": "2026-07-31T14:32:15Z",
  "level": "ERROR",
  "service": "payment-service",
  "traceId": "abc123def456",   // ← DT picks this up for log-trace correlation
  "spanId": "789xyz",
  "message": "DB connection pool exhausted",
  "pool.active": 20,
  "pool.waiting": 23,
  "exception": "com.zaxxer.hikari.pool.HikariPool$PoolInitializationException"
}
```

**Log-based metric (when you need a metric from log content):**
```
Use case: you want an alert when log contains "OutOfMemoryError"

DT UI → Metrics → "Create metric from log"
  Query: content = "*OutOfMemoryError*" AND dt.entity.process_group: "payment-service"
  Metric name: log:payment_service.oom_count
  Aggregation: count

→ Now this becomes a metric you can alert on:
  If log:payment_service.oom_count > 0 in 5 min → fire CRITICAL alert
  (OOM means pod death is imminent)
```

---

### Layer 6: Synthetic Monitoring (Outside-In)

**What it does:**
```
DT runs real HTTP requests from global locations EVERY 5 MINUTES.
This simulates what a real user experiences — not what internal monitoring sees.

Two perspectives:
  Internal monitoring (OneAgent):
    "Is the pod running? Is the JVM healthy? Are internal calls succeeding?"
    CAN'T detect: DNS failures, ALB misconfiguration, TLS certificate expiry, CDN issues

  Synthetic monitoring (from outside):
    "Can I actually reach this URL and get a valid response?"
    CATCHES: DNS broken, ALB target group empty, cert expired, routing misconfigured

These are COMPLEMENTARY — you need both.
```

**Our synthetic configuration:**
```hcl
resource "dynatrace_http_monitor" "health_check" {
  for_each  = var.services
  frequency = 5          # every 5 minutes
  locations = var.synthetic_locations  # Tokyo + Singapore

  script {
    request {
      method = "GET"
      url    = each.value.health_check_url  # https://payment.company.com/actuator/health

      validation {
        rule { type = "httpStatusesList"; value = "2xx" }
        rule { type = "patternConstraint"; value = "\"status\":\"UP\"" }
        # TWO checks: HTTP 200 AND body contains "status":"UP"
        # Why two? A misconfigured app can return 200 with {"status":"DOWN"}
      }
    }
  }

  anomaly_detection {
    outage_handling {
      global_consecutive_outage_count_threshold = 1  # 1 failure from ALL locations = global outage
      local_consecutive_outage_count_threshold  = 3  # 3 failures from ONE location = local outage
      # Why different? 1 failure globally = real outage. 1 failure regionally = network blip.
    }
  }
}
```

**Synthetic locations explanation:**
```
Tokyo (GEOLOCATION-6F55B7E4B5E7A52F):
  Tests from the primary user location (Asia-Pacific users)

Singapore (GEOLOCATION-D15FBAABA11A2D7D):
  Tests from a second Asia-Pacific location

Why 2 locations?
  If Tokyo fails + Singapore fails = GLOBAL outage (real problem, page immediately)
  If only Tokyo fails = LOCAL outage (Tokyo-specific network issue, less urgent)

For production: consider adding a 3rd location (EU or US West) to detect geo-specific issues.
```

---

### Layer 7: Business Metrics (Custom OTEL)

**What DT can't automatically measure:**
```
DT auto-captures: HTTP status codes, latency, JVM metrics, DB calls.
DT CANNOT automatically capture: "did the payment actually succeed?"

HTTP 200 from POST /payments could mean:
  a) Payment succeeded → customer charged → good
  b) Payment declined → customer not charged → bad (but HTTP is 200)
  c) Fraud flag → payment held → not charged yet → HTTP is 200

None of these look different in standard metrics.
Business transaction SLO + custom OTEL metrics expose the difference.
```

**Implementation in the Java app:**
```java
// PaymentController.java
@RestController
@RequiredArgsConstructor
public class PaymentController {

    private final MeterRegistry meterRegistry;

    @Value("${spring.profiles.active:unknown}")
    private String environment;

    @PostMapping("/api/v1/payments")
    public ResponseEntity<PaymentResult> processPayment(@RequestBody PaymentRequest req) {

        // Always count total attempts
        meterRegistry.counter("business.transaction.total.count",
            "service",     "payment-service",
            "environment", environment,
            "type",        "payment"
        ).increment();

        PaymentResult result = paymentService.process(req);

        // Only count on real business success
        if (result.getStatus() == PaymentStatus.COMPLETED) {
            meterRegistry.counter("business.transaction.success.count",
                "service",     "payment-service",
                "environment", environment,
                "type",        "payment"
            ).increment();
        }

        // Tag failed payments by reason (useful for analysis)
        if (result.getStatus() != PaymentStatus.COMPLETED) {
            meterRegistry.counter("business.transaction.failure.count",
                "service",     "payment-service",
                "environment", environment,
                "type",        "payment",
                "reason",      result.getStatus().name()  // DECLINED, FRAUD_HOLD, ERROR
            ).increment();
        }

        return ResponseEntity.ok(result);
    }
}
```

**Helm chart configuration to send metrics to DT:**
```yaml
# charts/payment-service/values.yaml
env:
  - name: OTEL_EXPORTER_OTLP_ENDPOINT
    value: "http://dynatrace-activegate.dynatrace.svc:4318"
  - name: OTEL_SERVICE_NAME
    value: "payment-service"
  - name: MANAGEMENT_METRICS_EXPORT_OTLP_ENABLED
    value: "true"
  - name: MANAGEMENT_OTLP_METRICS_EXPORT_URL
    value: "http://dynatrace-activegate.dynatrace.svc:4318/api/v2/otlp/v1/metrics"
```

---

## Part 2 — The Tag and Management Zone Model

### Why tagging matters — the routing chain

```
Kubernetes namespace label →  DT auto-tag  → Management zone → Alerting profile → Notification

namespace: payment-ns
  labels: { team: payments, environment: production }
      ↓ (OneAgent reads namespace labels)
DT auto-tagging rule:
  "if Kubernetes label team=payments → tag entity team:payments"
  "if Kubernetes label environment=production → tag entity environment:production"
      ↓
Management zone "payments-production":
  rule: include entities tagged team:payments AND environment:production
      ↓
Alerting profile "payments-production-critical":
  scope: management zone "payments-production"
  tier: AVAILABILITY (0 min delay)
      ↓
Notification "payments-production-critical-pd":
  alerting_profile: above
  PagerDuty key: payments team integration key
```

**Without this tagging chain:**
```
ALL alerts go to everyone (noise)
OR alerts go to nobody (silent failures)
```

**The 3-level tag hierarchy we use:**
```
Level 1: team tag
  values: payments, orders, notifications, platform
  purpose: routes alerts to the right team

Level 2: environment tag
  values: dev, staging, production
  purpose: separates thresholds and notification destinations

Level 3: service tag (optional, fine-grained)
  values: payment-service, order-service, notification-service
  purpose: for dashboard filtering and DT API queries

Example management zone filter:
  team:payments AND environment:production
  → Only payment-service in production is in scope
  → Orders team doesn't see payment alerts (and vice versa)
```

---

## Part 3 — The Alerting Tier Architecture

### Why 4 tiers (not just critical + non-critical)

```
TIER 1: CRITICAL — AVAILABILITY (0 min delay) → PagerDuty phone call
  What fires it: service is completely down (traffic = 0, availability SLO = 0%)
  Who gets it: on-call engineer (phone rings)
  Production only: dev/staging services going down is expected, not a phone-call incident
  Why 0 min delay: availability loss is NEVER transient. A service that's down is down.

TIER 2: HIGH — ERROR (2 min delay) → PagerDuty push notification
  What fires it: error rate above threshold, SLO burn rate fast-burn
  Who gets it: on-call engineer (push notification, no phone call)
  Staging + production: staging errors during k6 should page (real problem)
  Why 2 min delay: brief error spikes during rolling deploys → filter them out
    A 2-min delay means: if the error resolves itself in < 2 min (deploy completes), no page.

TIER 3: WARNING — SLOWDOWN (5 min delay) → Slack channel
  What fires it: latency P99 above threshold, slow burn rate SLO
  Who gets it: Slack #alerts-<team> (business hours attention)
  All environments
  Why 5 min delay: latency can spike briefly during deploys, traffic spikes, GC cycles.
    5 min sustained = real degradation worth investigating.

TIER 4: INFO — RESOURCE_CONTENTION (15 min delay) → Slack #monitoring
  What fires it: CPU, memory, JVM heap above threshold
  Who gets it: Slack #monitoring (shared channel, general awareness)
  All environments
  Why 15 min delay: resource metrics trend slowly. 15 min confirms it's real, not a burst.
    An immediate alert on CPU spike would fire during every Java app startup.
```

### The delay calculation logic

```
The question for each tier: "What is the minimum sustained duration that represents a real problem?"

AVAILABILITY:   0 seconds. The service is either up or down. No transient availability loss.
ERROR:          2 minutes. Long enough to survive a 30-pod rolling deploy (each pod takes ~60s).
SLOWDOWN:       5 minutes. Long enough to survive JIT warmup and a brief traffic spike.
RESOURCE:      15 minutes. Resource trends need time to confirm they're not one-time bursts.
```

---

## Part 4 — SLO Design and Error Budget Management

### SLO design principles

```
Principle 1: SLOs measure USER EXPERIENCE, not system health.
  Wrong: "CPU < 70%" (user doesn't care about CPU)
  Right: "99.9% of payment requests return 2xx within 300ms" (user cares about this)

Principle 2: Fewer, better SLOs beat many mediocre ones.
  Start with: availability + latency (2 SLOs per service)
  Add: only when you have evidence a metric matters to users

Principle 3: SLO targets must be achievable AND meaningful.
  Too tight: 99.99% on a service running on single-AZ → unreachable, constant breach
  Too loose: 90% when reality is 99.95% → never alerts, gives false confidence

Principle 4: Targets differ by environment.
  Production: 99.9% (real users, real SLA)
  Staging: 95% (k6 test traffic, no SLA)
  Dev: 90% (nobody is using it, see the chart work)
```

### Error budget management — the weekly review

```
Every Monday: review SLO dashboards

For each service, check:
  1. Current SLO %: are we above target?
  2. Error budget remaining: how much do we have left for the month?
  3. Burn rate: are we consuming budget fast or slow?

Error budget math example (payment-service, production):
  SLO target: 99.9%
  30-day window = 43,200 minutes
  Error budget = 0.1% × 43,200 = 43.2 minutes

  If at day 15 we've used 40 minutes of budget:
    → We've used 93% of the budget in 50% of the time
    → Burn rate: 1.86× (almost 2× faster than the window allows)
    → Action: freeze non-critical changes until budget recovers

  If at day 15 we've used 2 minutes:
    → We have 41 minutes remaining
    → Healthy budget → engineers can do risky deploys safely

Error budget policy (written in Confluence):
  > 50% budget remaining: normal operations, feature deployments allowed
  20–50% remaining: caution, limit risky changes
  < 20% remaining: freeze non-critical deployments, focus on reliability
  0% (breach): incident review required before any new features
```

### Burn rate alerts — how they work

```
Fast burn threshold (14.4×):
  If you're consuming budget 14.4× faster than normal:
  14.4 × 2 days = 30 days (your full budget would be gone in 2 days)
  → URGENT: fix this now or SLO breaches by end of week

Slow burn threshold (3.0×):
  Consuming budget 3× faster:
  3 × 10 days = 30 days (budget gone in 10 days)
  → WORTH INVESTIGATING: not urgent but needs attention this week

These alerts fire in ADDITION to metric event alerts:
  Metric event: "right now, P99 > 300ms" (instantaneous)
  Burn rate alert: "over the last 2 hours, you've consumed 5% of your monthly budget" (trend)
```

---

## Part 5 — Implementation Order (How to Build This From Scratch)

### Phase 1: Deploy OneAgent (Day 1)

```bash
# 1. Create ArgoCD application for Dynatrace Operator (gitops/dev/monitoring/dynatrace/)
kubectl apply -f gitops/dev/bootstrap/root-app-dev.yaml
# ArgoCD automatically deploys in wave order:
#   wave -1: namespaces (with team/env labels)
#   wave  2: ESO + ClusterSecretStore
#   wave  3: dynatrace-operator → ExternalSecret pulls tokens → DynaKube
#            → OneAgent DaemonSet starts on every node
#            → JVM auto-instrumentation active within 2 minutes

# Verify OneAgent is running on all nodes:
kubectl get pods -n dynatrace
# Expected: dynatrace-oneagent-<hash> Running on each node

# Verify DT is receiving data:
# DT UI → "Hosts" → should see your EKS nodes appear within 5 minutes
```

**What you have after Phase 1:**
```
✓ Node metrics (CPU, memory, disk, network)
✓ Container metrics (per-pod CPU, memory)
✓ JVM metrics (heap, GC, threads) for all Java pods
✓ HTTP metrics (request count, error rate, response time) for all services
✓ Distributed traces (OTEL export to ActiveGate)
✓ Container logs ingested into DT Grail

Not yet:
✗ SLOs (not configured)
✗ Alerts / notifications (not configured)
✗ Management zones (not configured)
✗ Synthetic monitors (not configured)
```

### Phase 2: Auto-Tagging Rules (Day 1–2)

```
Done via Terraform OR DT UI.
Must be done BEFORE management zones (zones depend on tags).

Auto-tagging rules read Kubernetes labels:
  Rule 1: Kubernetes namespace label "team" → DT tag "team:{value}"
  Rule 2: Kubernetes namespace label "environment" → DT tag "environment:{value}"

These rules apply to ALL entities in that namespace:
  pods, services, process groups, all automatically tagged.

Terraform resource (if managing via Terraform):
  resource "dynatrace_auto_tag_v2" "team" {
    name = "team"
    rules {
      type = "SERVICE"
      attribute_conditions {
        key      = "KUBERNETES_NAMESPACE_LABELS"
        operator = "EQUALS"
        value    = "team"
      }
    }
  }
```

### Phase 3: Management Zones (Day 2)

```hcl
# Already in terraform/modules/dynatrace/main.tf
resource "dynatrace_management_zone_v2" "team" {
  for_each = local.teams  # {"payments", "orders", "notifications"}
  name     = "${each.value}-${var.environment}"  # "payments-production"

  rules {
    rule {
      type = "SERVICE"
      attribute_conditions {
        attribute = "SERVICE_TAGS"
        tag_value = "team:${each.value}"
      }
      attribute_conditions {
        attribute = "SERVICE_TAGS"
        tag_value = "environment:${var.environment}"
      }
    }
    # Also covers PROCESS_GROUP and HOST with same logic
  }
}
```

**After Phase 3:**
```
✓ Each team only sees their own service in DT dashboards
✓ Alerting profiles can be scoped to a management zone
```

### Phase 4: Alerting Profiles + Notifications (Day 2–3)

```hcl
# Alerting profiles (4 tiers per team per environment)
resource "dynatrace_alerting" "critical" {
  for_each        = var.environment == "production" ? local.teams : toset([])
  management_zone = dynatrace_management_zone_v2.team[each.value].id
  rules { rule {
    severity_level   = "AVAILABILITY"
    delay_in_minutes = 0
  }}
}

# PagerDuty notification wired to critical profile
resource "dynatrace_pagerduty_notification" "critical" {
  alerting_profile = dynatrace_alerting.critical[each.key].id
  service_api_key  = var.pagerduty_integration_keys[each.key]
  # Integration key comes from AWS Secrets Manager (never hardcoded)
}
```

**After Phase 4:**
```
✓ Correct teams get paged for their own services
✓ 4 severity tiers with appropriate notification channels
✓ PagerDuty wired for critical + high
✓ Slack wired for warning + info
```

### Phase 5: Metric Events (Day 3–4)

```
Configure all 8 signal metric events per service:
  - traffic_drop (alert_on_no_data = true for this one)
  - error_rate
  - latency_p99
  - cpu_saturation
  - memory_usage
  - jvm_heap
  - pod_restarts
  - network_error_rate

Deploy to dev first, observe for 1 week:
  Are any alerts firing that shouldn't? → thresholds too tight → relax
  Are any real problems NOT alerting? → thresholds too loose → tighten

After 1 week in dev, deploy to staging.
After 1 week in staging, deploy to production.
```

### Phase 6: SLOs (Day 4–5)

```
Deploy 2 SLOs per service initially:
  1. Availability
  2. Latency P99

Verify in DT UI:
  Settings → Service Level Objectives
  Each SLO should show:
    - Current % (should be above target)
    - Error budget remaining
    - Burn rate visualization

After 2 weeks: add remaining 6 SLOs (DB, dependency, message processing, etc.)
```

### Phase 7: Synthetic Monitors (Day 5)

```
1 HTTP synthetic per service:
  health_check_url → /actuator/health
  frequency: 5 min
  locations: Tokyo + Singapore (production), Tokyo only (staging/dev)
  validation: 2xx status AND "status":"UP" in body

After deployment, verify:
  DT UI → Synthetic → your monitor → should show green from both locations
  DT UI → Synthetic → Events → confirm first successful checks
```

### Phase 8: Custom Business Metrics (Week 2)

```
Add to Java apps:
  PaymentController: business.transaction.total.count + success.count
  NotificationService: messages.processed.count + failed.count
  OrderService: business.transaction.total.count + success.count

Add to Helm values.yaml:
  OTEL_EXPORTER_OTLP_ENDPOINT = http://dynatrace-activegate.dynatrace.svc:4318

Verify in DT:
  Metrics Explorer → search "ext:custom.business.transaction" → should appear

Add business SLOs:
  Add to Terraform after metrics are confirmed working (don't add SLO before metric exists)
```

---

## Part 6 — Day-to-Day Management

### Weekly monitoring health review

```
Every Monday — 30 minutes review:

1. SLO Dashboard (5 min):
   For each service: availability %, latency %, error budget remaining
   Action if < 50% budget: investigate + add Jira ticket

2. Alert noise audit (10 min):
   "How many alert instances fired this week?"
   "Which alerts fired most frequently?"
   "Were they all real incidents or noise?"
   Action: alerts firing > 5x/week without real incidents → tune thresholds

3. Synthetic monitor uptime (5 min):
   "Any synthetic failures this week?"
   "Any timeout warnings?"
   Action: synthetic failures without user-visible impact → check if DT false positive

4. Anomaly count (10 min):
   "Did Davis AI find anything we didn't alert on?"
   DT → Problems → Closed Problems last 7 days
   Action: if Davis found a real issue we didn't page on → add missing metric event
```

### Threshold tuning process

```
RULE: never tune thresholds reactively during an incident.
     Wait until the incident is resolved, then tune.

Process:
  1. Collect: how many times did this alert fire this month?
  2. Classify: of those, how many were real incidents vs noise?
     Real = led to a fix. Noise = acknowledged + resolved with no action.
  3. Calculate noise ratio: noise / total firings
     > 50% noise → threshold too tight → increase threshold by 20%
     100% real but users complained before alert → threshold too loose → decrease 20%
  4. Change in Terraform:
     environments/production/main.tf → update threshold value
     PR review → approve → merge → terraform-dynatrace-production.yaml applies it
  5. Monitor for 2 weeks: did the tuning help?
```

### Adding a new service to monitoring

```
Checklist for onboarding a new 4th service:

Step 1: Add namespace with labels to gitops/dev/namespaces/namespaces.yaml
  - name: new-service-ns
    labels: { team: new-team, environment: dev }

Step 2: Add service to services map in environments/dev/main.tf
  "new-service" = {
    team = "new-team"
    slo_target = 99.5   # start conservative
    # use safe starting defaults for all thresholds
    # tune after 2 weeks of observing real metrics
    ...
  }

Step 3: Add OTEL env vars to new service's Helm chart
  OTEL_EXPORTER_OTLP_ENDPOINT
  OTEL_SERVICE_NAME

Step 4: Create PagerDuty service for new-team
  → Add integration key to AWS Secrets Manager
  → Add to pagerduty_integration_keys map in environments/production/main.tf

Step 5: Create Slack webhook for new-team's alerts channel
  → #alerts-new-team channel
  → Add webhook to slack_webhook_urls map

Step 6: Deploy to dev, observe for 1 week, tune, then promote to staging/prod
```

### Deprecating monitoring for a retired service

```
When a service is decommissioned:

1. Remove from services map in all 3 environments/*/main.tf
   → terraform apply destroys: metric events, SLOs, synthetics, notifications for this service
   → Does NOT affect other services (Terraform manages them independently)

2. Remove gitops/*/app/<service>/ → ArgoCD prune: true deletes the Deployment
   → OneAgent stops seeing the JVM process → DT entity becomes "offline"

3. Archive DT dashboards for this service (don't delete — useful for history)
   DT UI → Dashboards → tag with "archived" → remove from team's default view

4. Remove PagerDuty Service for this service
   → Prevents stale integration key from receiving phantom alerts
```

---

## Part 7 — Common Monitoring Design Mistakes

| Mistake | Symptom | Correct Design |
|---------|---------|----------------|
| No traffic drop alert | Silent outage: service unreachable, all SLOs show green | Always add `traffic_min_rps` alert with `alert_on_no_data = true` |
| Same thresholds in all environments | Dev alert fires every JVM cold start → alert fatigue | 3× multiplier for staging, relaxed defaults for dev |
| Alerting on averages not P99 | Slow users not detected — average looks fine | Always use `latency P99` for user-facing latency |
| Management zones not scoped by environment | Payment team gets paged for dev alerts | Management zone filter MUST include environment tag |
| SLO before metric event | SLO breach pages nobody (no alerting profile for SLO) | Alerting profiles must be configured to catch SLO burn rate alerts |
| No deploy events sent to DT | Metric chart has no context for when latency started | Always send custom deploy events from CI/CD pipeline |
| Monitoring only HTTP — no business metrics | Payment declined counts look like success | Add OTEL counters for business outcomes |
| Synthetics only from one location | Single-location failure floods alerts during regional blip | Tokyo + Singapore minimum; 3 locations preferred |
| Unused DT entities not removed | DT shows old decommissioned services as "offline" — confusing | Remove services from Terraform when decommissioned |
