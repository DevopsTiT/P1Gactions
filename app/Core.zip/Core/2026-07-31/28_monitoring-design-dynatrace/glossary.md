# Glossary — Design, Implement & Manage Monitoring with Dynatrace
Every term from main.md. One entry per term. SRE beginner level.

---

**Observability**
The ability to understand the internal state of a system from its external outputs (metrics, traces, logs). A system is "observable" when you can answer "why is it behaving this way?" from the data it produces. Why it matters: monitoring tells you THAT something is wrong; observability tells you WHY.

**Monitoring**
Collecting, storing, and alerting on system metrics over time. A subset of observability. Why it matters: without monitoring, you learn about production problems from users, not from dashboards.

**OneAgent**
Dynatrace's all-in-one agent deployed as a DaemonSet (one pod per EKS node). Automatically instruments Java processes via JVMTI, reads container logs, collects node metrics, and exports distributed traces. Why it matters: replaces Prometheus exporters, Fluent Bit log agents, and a Java APM agent — one component does all three.

**JVMTI (Java Virtual Machine Tool Interface)**
A Java API that lets external agents hook into a running JVM at startup to capture method timings, object allocations, thread state, and memory. OneAgent uses this to auto-instrument Spring Boot without any code changes. Why it matters: zero annotation, zero SDK — OneAgent injects itself via JVMTI and captures HTTP requests, DB queries, JVM heap automatically.

**DynaKube**
A Kubernetes custom resource (installed by the Dynatrace Operator) that describes the desired DT monitoring configuration: which modes to enable (classicFullStack, logMonitoring, activeGate), and resource limits. Why it matters: the single YAML file that controls everything DT monitors in the cluster. Change one field → operator reconfigures OneAgent across all nodes.

**Dynatrace Operator**
A Kubernetes operator (a controller + CRD) that watches DynaKube resources and ensures the desired monitoring state (OneAgent DaemonSets, ActiveGate Deployments) matches the cluster reality. Why it matters: operators handle upgrades, health, and configuration automatically — you don't manually deploy or update OneAgent.

**classicFullStack mode**
The DynaKube mode that deploys OneAgent as a DaemonSet on EVERY node, giving full visibility into all JVMs and containers. Alternative: "application-only" mode (limited, just the app). Why it matters: full-stack is required for JVM heap monitoring, GC pause tracking, and log ingestion — essential for Java microservice monitoring.

**ActiveGate**
A Dynatrace component running in the cluster (as a Deployment) that acts as a relay between OneAgent instances and the DT SaaS tenant. Also handles OTEL data ingestion. Why it matters: EKS pods can't directly reach the DT cloud. ActiveGate proxies all metrics, traces, and logs to DT over a single HTTPS connection.

**logMonitoring (DynaKube)**
A DynaKube setting that enables OneAgent to read container log files from `/var/log/containers/*.log` on each node and send them to DT Grail log analytics. Why it matters: eliminates the need for Fluent Bit or any other log shipper — OneAgent handles log collection as part of its normal operation.

**DT Grail**
Dynatrace's log analytics and data lakehouse engine. Stores structured and unstructured logs, searchable with DQL (Dynatrace Query Language). Why it matters: logs are automatically correlated with metrics and traces (shared entity IDs) — you can jump from a slow trace directly to the logs emitted by that request.

**Tag (Dynatrace)**
A key-value label attached to a DT entity (service, host, process group). Tags can be auto-applied from Kubernetes namespace labels via auto-tagging rules. Why it matters: tags are the foundation of management zone routing — alerts reach the right team because entities are tagged with `team:payments, environment:production`.

**Auto-tagging rule**
A DT setting that automatically applies tags to entities based on their Kubernetes labels, process names, or URL patterns. Why it matters: without auto-tagging, every entity would need to be manually tagged. Auto-tagging ensures every new pod is tagged correctly the moment it starts.

**Management Zone**
A logical grouping in DT that scopes which entities a team can see and which alerts they receive. Example: `payments-production` contains only payment-service entities in production. Why it matters: prevents cross-team noise — orders team doesn't see payment alerts; payments team doesn't see notification alerts.

**Alerting Profile**
A DT configuration that defines which problem types trigger alerts, with what delay, scoped to which management zone. Example: `payments-production-critical` catches AVAILABILITY problems with 0-minute delay for the payments team. Why it matters: connects the right alerts to the right notification channels (PagerDuty, Slack) for the right team.

**Notification rule**
A DT configuration that sends alerts to a specific destination (PagerDuty, Slack, email) based on an alerting profile. Why it matters: the final link in the chain: problem → alerting profile → notification rule → PagerDuty page or Slack message.

**Delay in minutes (alerting profile)**
How long a problem must persist before DT sends a notification. AVAILABILITY: 0 min (instant). ERROR: 2 min. SLOWDOWN: 5 min. RESOURCE_CONTENTION: 15 min. Why it matters: filters transient blips from real problems. A 2-min delay means deploy-induced error spikes (which resolve in 60–90s) don't page the on-call engineer.

**AVAILABILITY severity**
DT problem severity level indicating a service is completely unavailable (0 traffic, SLO breach = 100%). Always fires immediately (0 min delay). Only configured for production (availability loss in dev is expected). Why it matters: the most urgent alert — service is down for users.

**ERROR severity**
DT problem severity level for error rate spikes, failed health checks, and SLO error budget fast burns. Typically triggers PagerDuty push notification with 2-min delay. Why it matters: service is erroring but not completely down — needs same-day resolution but not a 3am phone call (unless production).

**SLOWDOWN severity**
DT problem severity for latency degradation, slow requests, and slow burn SLO alerts. Routed to Slack with 5-min delay. Why it matters: service is slower than normal but not broken — investigate during business hours.

**RESOURCE_CONTENTION severity**
DT problem severity for CPU, memory, JVM heap, and network resource pressure. 15-min delay to Slack. Why it matters: resource pressure trends slowly — 15 min confirms it's real and sustained, not a momentary spike.

**alert_on_no_data**
A metric event setting that fires the alert even when DT receives ZERO data points (not just when the metric crosses a threshold). Used on the traffic drop signal only. Why it matters: if a service is so broken it can't send any metrics, `alert_on_no_data = true` still fires the alert — catching complete blackouts.

**Metric event**
A DT resource that watches a specific metric key and creates a Problem when the metric crosses a threshold. 8 metric events per service in this project. Why it matters: metric events ARE the alerting mechanism — without them, metric data is collected but nothing pages you when it's abnormal.

**SLO (Service Level Objective)**
A measurable reliability target: "99.9% of payment requests must return 2xx within 300ms." Evaluated over a rolling 30-day window. Why it matters: SLOs translate abstract "reliability" into a trackable number with a budget — drives engineering priorities.

**Error budget**
The amount of failure allowed within an SLO window. For 99.9% monthly: 43.2 minutes of downtime allowed. Why it matters: when the budget runs low, it signals "stop shipping features, focus on reliability" — prevents the org from trading reliability for velocity indefinitely.

**Burn rate**
How fast the error budget is being consumed relative to the normal pace. 1× = on track. 14.4× = budget exhausted in 2 days. Why it matters: burn rate alerts fire BEFORE the SLO is actually breached — gives time to act while there's still budget.

**Synthetic monitor**
A DT monitor that sends real HTTP requests from global locations on a schedule and validates the response. Simulates real user access from OUTSIDE the cluster. Why it matters: catches failures invisible to OneAgent: DNS broken, ALB misconfigured, TLS expired, CDN routing broken. Internal monitoring says green; synthetic monitor catches the real outage.

**Synthetic location**
A geographic DT location from which synthetic checks are sent (Tokyo = `GEOLOCATION-6F55B7E4B5E7A52F`, Singapore = `GEOLOCATION-D15FBAABA11A2D7D`). Why it matters: 2+ locations distinguish global outages (both fail) from regional blips (one fails) — avoids false pages from a single regional network hiccup.

**patternConstraint (synthetic validation)**
A synthetic check rule that validates the response body contains a specific string. Example: `"status":"UP"` ensures Spring Boot Actuator reports healthy (not just HTTP 200). Why it matters: a misconfigured Spring app can return HTTP 200 with body `{"status":"DOWN"}` — the HTTP check passes but the app is unhealthy. Body validation catches this.

**Davis AI**
DT's built-in AI engine that automatically correlates events, groups related alerts into one Problem, and suggests root causes. Named after the founder's dog. Why it matters: Davis does the first layer of RCA automatically — it often points to the deployment event or failing dependency within seconds of the alert firing.

**OTEL (OpenTelemetry)**
An open standard for distributed tracing, metrics, and logs. Java Spring Boot uses the OpenTelemetry SDK and `OTEL_EXPORTER_OTLP_ENDPOINT` env var to send data to DT ActiveGate. Why it matters: standard protocol means DT, Prometheus, Jaeger all speak the same language — no vendor lock-in for instrumentation.

**`OTEL_SERVICE_NAME`**
Environment variable that tells the OTEL agent which service name to report. DT uses this to identify the service in distributed traces. Why it matters: without this, all your services appear as "unknown" in DT traces — can't correlate spans to services.

**`OTEL_EXPORTER_OTLP_ENDPOINT`**
Environment variable pointing to the OTLP receiver (DT ActiveGate's OTLP port). Value: `http://dynatrace-activegate.dynatrace.svc:4318`. Why it matters: tells the OTEL SDK where to send trace and metric data. Without this, traces stay in memory and are never exported.

**MeterRegistry (Spring Boot / Micrometer)**
Spring Boot's metrics facade. `meterRegistry.counter("name", "tag", "value").increment()` records a counter that Micrometer exports via OTEL. Why it matters: the Java API for emitting custom business metrics (payment success count, message processing count) that feed custom SLOs.

**`ext:custom.*` metric namespace**
DT metric prefix for app-emitted custom metrics (vs `builtin:*` for auto-captured). Custom metrics arrive via OTEL and are prefixed `ext:custom.`. Why it matters: business transaction SLOs and message processing SLOs depend on custom metrics — the app must emit them; DT doesn't auto-capture business outcomes.

**Deployment event (DT)**
A DT event type (`CUSTOM_DEPLOYMENT`) posted by CI/CD pipelines to mark when a deployment happened. Appears as a vertical line on DT metric charts. Why it matters: visually links "P99 latency spike started here" with "deploy happened 12 minutes earlier" — the most reliable evidence for deployment-caused incidents.

**Error budget policy**
A written team agreement on what to do when error budget drops below thresholds: >50% = normal operations; 20–50% = limit risky changes; <20% = freeze non-critical deploys; 0% = incident review required. Why it matters: without a policy, error budgets are just numbers — the policy turns them into engineering decisions.

**Terraform Dynatrace provider**
`dynatrace-oss/dynatrace` Terraform provider that manages DT resources (management zones, metric events, SLOs, synthetics, notifications) as code. Why it matters: infrastructure-as-code for monitoring means changes go through PR review, get applied consistently across environments, and are auditable in git history.

**`for_each` (Terraform)**
A meta-argument that creates one resource instance per item in a map or set. `for_each = var.services` creates one metric event per service. Why it matters: 3 services × 8 metric events = 24 resources created from one resource block — no copy-paste.

**Noise ratio**
The proportion of alert firings that were false positives (acknowledged + resolved with no action). Formula: `false positives / total firings`. Why it matters: >50% noise ratio = threshold too tight → alert fatigue → real incidents get ignored.

**Threshold tuning**
The ongoing process of adjusting metric event thresholds to minimize false positives while catching all real incidents. Done after observing 2+ weeks of data. Why it matters: initial thresholds are guesses; production thresholds should be derived from measured baselines + headroom.

**Safe starting defaults**
Conservative threshold values for a new service with no historical data. Intentionally relaxed to avoid immediate alert fatigue. Tuned after observing real baseline metrics for 2 weeks. Why it matters: better to start loose and tighten than to flood on-call with false alerts on day one.

**N+1 query**
A bug where code fetches N items (1 query), then for each item makes another DB query = N+1 total queries. Visible in DT traces as many small identical DB calls in one trace waterfall. Why it matters: a page showing 100 orders = 101 DB queries → DB latency × 100 → P99 spike → SLO breach.
