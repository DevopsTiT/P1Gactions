# Dynatrace Grail — Log Management and Analytics
## SRE Deep Dive

> Grail is Dynatrace's data lakehouse for storing and querying logs, metrics, traces, and events. This doc covers everything an SRE needs: how logs flow into Grail, how to write DQL queries, how to build log-based alerts, and how to use logs during an incident.

---

## Decision Tree — What to do when

```
                        "I need to investigate a problem"
                                      │
            ┌─────────────────────────┼────────────────────────┐
            ▼                         ▼                        ▼
    "Show me errors in         "Why is payment-         "How many OOM
     payment-service            service slow?"           errors happened
     last 30 min"                    │                   this week?"
            │                        │                        │
    DQL query:                 DQL + link to               DQL aggregate:
    fetch logs                 distributed trace            count(), group by
    | filter ...               from the same               time series
    | filter                   request (trace_id)
    status="ERROR"                    │
            │                  DT → Traces → click
    See exact                  span → "Logs" tab
    stack trace                → same trace_id
                               links log lines to
                               the slow DB call

            "I want to alert on a specific log pattern"
                                      │
                               Create a Log Metric:
                               DQL → count lines matching pattern
                               → Metric key: log.payment.oom
                               → Threshold: ≥ 1 → alert fires
```

---

## E2E Flow — How Logs Get Into Grail

```
1. Java Spring Boot pod writes to stdout:
   System.out.println(...)  or  logger.error("DB connection failed", e)
   ↓
   Container runtime (containerd) writes to file:
   /var/log/containers/payment-service-<pod-id>_payment-ns_payment-service-<hash>.log

2. OneAgent DaemonSet on the same node reads the file continuously
   (enabled by logMonitoring: enabled: true in DynaKube)
   OneAgent enriches each log line with metadata:
     - k8s.namespace.name: payment-ns
     - k8s.pod.name: payment-service-7d9f8b-abc12
     - k8s.container.name: payment-service
     - k8s.deployment.name: payment-service
     - dt.entity.process_group_instance: PROCESS_GROUP_INSTANCE-xyz
     - service.name: payment-service (from OTEL_SERVICE_NAME env var)
   
3. OneAgent → ActiveGate → DT SaaS tenant → stored in Grail
   Retention: typically 35 days (configurable)
   
4. SRE queries in DT UI → Logs → using DQL (Dynatrace Query Language)
   or writes DQL in dashboards / notebooks / alert rules

WHAT ENRICHMENT MEANS:
  Without enrichment: one log line = one text blob
    "ERROR DB connection refused"
  
  With enrichment (OneAgent adds K8s metadata):
    {
      "timestamp": "2024-01-15T10:30:00Z",
      "content":   "ERROR DB connection refused",
      "status":    "ERROR",
      "service.name":         "payment-service",
      "k8s.namespace.name":   "payment-ns",
      "k8s.pod.name":         "payment-service-7d9f8b-abc12",
      "k8s.node.name":        "ip-10-12-34-56.ap-northeast-1.compute.internal",
      "dt.trace_id":          "4bf92f3577b34da6a3ce929d0e0e4736",
      "dt.span_id":           "00f067aa0ba902b7"
    }
  
  Now you can filter: all ERROR logs from payment-service in payment-ns on node X.
  And click the trace_id to jump directly to the distributed trace.
```

---

## Part 1 — DQL (Dynatrace Query Language)

DQL is a pipeline language: each `|` passes results to the next stage.

### Basic structure

```
fetch logs                          ← data source
| filter ...                        ← filter rows
| filter ...                        ← another filter (AND)
| sort timestamp desc               ← order
| limit 100                         ← cap results
| fields timestamp, content, status ← project columns
```

### Time range

```dql
fetch logs, from: now()-1h, to: now()
| filter service.name == "payment-service"

# Common time shortcuts:
# now()-15m   last 15 minutes
# now()-1h    last 1 hour
# now()-24h   last 24 hours
# now()-7d    last 7 days
```

### Filter by status / level

```dql
fetch logs
| filter service.name == "payment-service"
| filter status == "ERROR"
| sort timestamp desc
| limit 200
```

```
status values in DT (mapped automatically from log level):
  "ERROR"   ← log4j ERROR, logback ERROR, Java exception stack trace
  "WARN"    ← log4j WARN, logback WARN
  "INFO"    ← log4j INFO, logback INFO
  "DEBUG"   ← log4j DEBUG, logback DEBUG
  "NONE"    ← no level detected (plain stdout)
```

### Filter by content (text search)

```dql
fetch logs
| filter service.name == "payment-service"
| filter matchesPhrase(content, "OutOfMemoryError")
# matchesPhrase: full-text search (fast, indexed)
# Best for: searching for exception class names, error messages

fetch logs
| filter service.name == "payment-service"
| filter matchesValue(content, "*connection refused*")
# matchesValue with wildcard: glob pattern match
# Best for: partial string matching

fetch logs
| filter service.name == "payment-service"
| filter content matches ".*NullPointerException.*"
# matches: regular expression
# Slowest (full scan), use only when matchesPhrase/matchesValue won't work
```

### Aggregate: count errors over time

```dql
fetch logs
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize count = count(), by: { bin(timestamp, 5m) }
| sort timestamp asc

# bin(timestamp, 5m): group timestamps into 5-minute buckets
# Result: timestamp + count of errors per 5-minute window
# Use in dashboard: line chart of error count over time
```

### Aggregate: top error messages

```dql
fetch logs
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize count = count(), by: { content }
| sort count desc
| limit 20

# Result: the 20 most common error messages in order
# Use this to: prioritize which errors to fix first
```

### Aggregate: errors per service

```dql
fetch logs
| filter k8s.namespace.name =~ ".*-ns"
| filter status == "ERROR"
| summarize count = count(), by: { service.name }
| sort count desc

# =~ is regex match: matches any namespace ending in "-ns"
# Result: which service is producing the most errors
```

### Extract fields from JSON logs

```dql
fetch logs
| filter service.name == "payment-service"
| filter status == "ERROR"
| parse content, "JSON:parsed"
| fields timestamp, parsed.userId, parsed.errorCode, parsed.amount, content

# parse ... JSON:parsed: parses content as JSON into a map called "parsed"
# Then access fields: parsed.userId, parsed.errorCode
# Works if your Spring Boot app writes JSON-structured logs
```

### Example: JSON log line from payment-service

```json
{
  "timestamp": "2024-01-15T10:30:00Z",
  "level": "ERROR",
  "service": "payment-service",
  "userId": "user-abc123",
  "paymentId": "pay-xyz789",
  "amount": 5000,
  "currency": "JPY",
  "errorCode": "DB_TIMEOUT",
  "message": "Database query timed out after 5000ms",
  "exception": "org.springframework.dao.QueryTimeoutException",
  "trace_id": "4bf92f3577b34da6a3ce929d0e0e4736"
}
```

DQL to extract and analyze:
```dql
fetch logs
| filter service.name == "payment-service"
| filter status == "ERROR"
| parse content, "JSON:j"
| filter j.errorCode == "DB_TIMEOUT"
| summarize count = count(), by: { bin(timestamp, 10m), j.errorCode }
| sort timestamp asc

# Shows: how many DB_TIMEOUT errors per 10-minute window
# Useful during an incident to see if DB timeouts are increasing or stabilizing
```

### Link logs to distributed traces

```dql
fetch logs
| filter service.name == "payment-service"
| filter status == "ERROR"
| filter isNotNull(dt.trace_id)
| fields timestamp, content, dt.trace_id, k8s.pod.name
| sort timestamp desc

# dt.trace_id: the OpenTelemetry trace ID injected by OneAgent/OTEL SDK
# Click the trace_id in DT UI → jumps to the distributed trace
# Shows: which SQL query failed, in which span, at what point in the call chain
```

---

## Part 2 — Log Ingestion Setup (What SRE Configures)

### Step 1: Enable log ingestion in DynaKube

```yaml
# gitops/<env>/monitoring/dynatrace/dynatrace-operator.yaml
apiVersion: dynatrace.com/v1beta1
kind: DynaKube
spec:
  logMonitoring:
    enabled: true      # ← this is the only required change
```

```
What this enables:
  OneAgent on each node reads /var/log/containers/*.log
  Enriches with K8s metadata
  Sends to ActiveGate → DT Grail
  
What it does NOT do:
  Parse JSON fields automatically (DT does basic level detection)
  Filter which logs to ingest (all stdout is ingested by default)
  Rate limit or sample (all log lines are sent)
```

### Step 2: Configure log ingestion rules (DT UI or API)

```
DT UI: Settings → Log Monitoring → Log ingest rules

Default behavior: ALL container logs ingested.
Problem: debug logs at high volume → Grail costs increase, query noise.

Best practice: filter in DT, not at the application level.

Rule 1: Include ERROR + WARN for all namespaces (keep these always)
  Matcher: status IN ("ERROR", "WARN")
  Action: INCLUDE

Rule 2: Include INFO for application namespaces
  Matcher: k8s.namespace.name IN ("payment-ns", "order-ns", "notification-ns")
           AND status == "INFO"
  Action: INCLUDE

Rule 3: Exclude DEBUG (never needed in prod Grail)
  Matcher: status == "DEBUG"
  Action: EXCLUDE

Rule 4: Exclude verbose system component logs (kube-proxy, coredns)
  Matcher: k8s.namespace.name IN ("kube-system") AND status == "INFO"
  Action: EXCLUDE

Result: ~80% reduction in log volume → lower cost + faster queries.
```

### Step 3: Configure log processing rules (parse structured fields)

```
DT UI: Settings → Log Monitoring → Log processing

Log processing rules run on ingestion — extract fields from log content
before storing in Grail. Faster queries later because fields are indexed.

Example: parse Spring Boot JSON logs

Rule name: Parse payment-service JSON logs
Matcher:   service.name == "payment-service" AND matchesPhrase(content, "userId")
Processor: | parse content, "JSON:j"
           | fieldsAdd userId = j.userId
           | fieldsAdd paymentId = j.paymentId
           | fieldsAdd errorCode = j.errorCode
           | fieldsAdd traceId = j.trace_id

After this rule: every payment-service log line has individual fields
userId, paymentId, errorCode extractable WITHOUT parsing in every query.
```

---

## Part 3 — Log-Based Metric Events (Alert on Log Patterns)

### When to use log-based alerts vs metric-based alerts

```
Use METRIC-BASED alerts (builtin:service.errors.server.rate) when:
  → You want to alert on HTTP-level error rates
  → You want percentage-based thresholds
  → Alert should fire on aggregate rate, not individual occurrences

Use LOG-BASED alerts when:
  → A specific exception/error message indicates a critical condition
  → The condition is binary (happened or didn't happen), not a rate
  → Example: OutOfMemoryError, database corruption detected, security breach attempt
  → Example: any payment declined by fraud detection (business metric)
```

### Creating a log metric in Terraform/DT API

```
Step 1: Create Log Metric in DT UI
  DT → Metrics → Log metrics → Create log metric
  
  Name:       log.payment.oom_error
  Description: Count of OutOfMemoryError log lines in payment-service
  
  Query (DQL):
    fetch logs
    | filter service.name == "payment-service"
    | filter matchesPhrase(content, "OutOfMemoryError")
    | summarize count()
  
  Dimensions: service.name, k8s.pod.name
  (allows filtering in alerts and dashboards by service and pod)

Step 2: Create Metric Event on that log metric
  resource "dynatrace_metric_events" "payment_oom" {
    enabled    = true
    event_type = "ERROR_EVENT"   → PagerDuty HIGH tier
    summary    = "[PROD] payment-service: OutOfMemoryError detected"
    description = "JVM ran out of heap. Pod will restart. Investigate heap usage."
    
    model_properties {
      type               = "STATIC_THRESHOLD"
      alert_condition    = "ABOVE"
      alert_on_no_data   = false
      threshold          = 0      # fire on ANY occurrence (count > 0)
      violating_samples  = 1      # one occurrence = alert immediately
      dealerting_samples = 1
    }
    
    query_definition {
      type       = "METRIC_KEY"
      metric_key = "log.payment.oom_error"
      resolution = "1m"
    }
  }

Result: one OOM log line → log metric count = 1 → threshold 0 exceeded →
        ERROR_EVENT created → HIGH alerting profile → PagerDuty push notification
        
Faster than waiting for pod restart to appear in pod_restarts metric
(pod may take 2-3 minutes to restart; log metric fires in <1 minute).
```

### Common log-based alert patterns

```
Pattern 1: Alert on database connection errors
  DQL: filter matchesPhrase(content, "Connection refused") AND service.name == "payment-service"
  Threshold: > 5 per minute (some noise expected, sustained = real problem)

Pattern 2: Alert on security events
  DQL: filter matchesPhrase(content, "authentication failed") AND status == "ERROR"
       AND k8s.namespace.name == "payment-ns"
  Threshold: > 10 per 5 minutes (brute force detection)

Pattern 3: Alert on payment processing errors
  DQL: filter matchesPhrase(content, "Payment declined") AND service.name == "payment-service"
  Threshold: > 50 per minute (business metric — too many declines = fraud spike or config error)

Pattern 4: Alert on slow DB queries (from log content)
  DQL: filter service.name == "payment-service"
       | parse content, "JSON:j"
       | filter j.queryDurationMs > 1000
  Threshold: > 10 per minute (more than 10 slow queries/min = DB issue)
```

---

## Part 4 — Log Analytics for Incident Investigation

### Incident workflow: "payment-service high error rate"

```
STEP 1: Get the time range of the incident
  DT Problem view → "started 14:23, still open"
  Use time range: 14:15 to 14:40 (5 min before + 10 min after start)

STEP 2: Find the first error occurrence
  fetch logs, from: 2024-01-15T14:15:00Z, to: 2024-01-15T14:40:00Z
  | filter service.name == "payment-service"
  | filter status == "ERROR"
  | sort timestamp asc    ← ASC to find the FIRST error, not latest
  | limit 50

  Look at the FIRST few errors:
  - What time exactly? (14:23:07 → right after a deploy at 14:22?)
  - What is the error message? (DB connection refused → DB issue, not app code)
  - Which pod? (payment-service-7d9f8b-abc12 → only this pod? or all pods?)

STEP 3: Check if it's one pod or all pods
  fetch logs, from: 2024-01-15T14:15:00Z, to: 2024-01-15T14:40:00Z
  | filter service.name == "payment-service"
  | filter status == "ERROR"
  | summarize count = count(), by: { k8s.pod.name }
  | sort count desc

  If one pod has 1000 errors and others have 0 → node-specific issue
  If all pods have equal errors → application bug or shared dependency (DB)

STEP 4: Trace the error to root cause
  fetch logs, from: 2024-01-15T14:23:00Z, to: 2024-01-15T14:24:00Z
  | filter service.name == "payment-service"
  | filter status == "ERROR"
  | fields timestamp, content, dt.trace_id, k8s.pod.name
  | limit 10

  Click a dt.trace_id → see the distributed trace:
    order-service → payment-service → PostgreSQL
                                      ↑ 
                              This span is RED (failed)
                              "Connection to database refused"
  
  Root cause: PostgreSQL connection, not payment-service code.

STEP 5: Check if it happened before (recurrence)
  fetch logs, from: now()-7d
  | filter service.name == "payment-service"
  | filter matchesPhrase(content, "Connection refused")
  | summarize count = count(), by: { bin(timestamp, 1h) }
  | sort timestamp asc

  If this happens every day at 14:00 → scheduled task on DB server
  If this is first time → investigate recent DB changes
```

### Incident workflow: "payment-service memory leak investigation"

```
STEP 1: See when heap started growing
  DT → Metrics → builtin:process.memory.jvm.heapUtilization
  → filter: process.group.name = "payment-service"
  → time range: last 7 days
  → Look for: gradual upward slope (leak) vs sudden jump (config change)

STEP 2: Correlate heap growth with log patterns
  # Find GC warnings that appear when heap was high
  fetch logs, from: now()-7d
  | filter service.name == "payment-service"
  | filter matchesPhrase(content, "GC overhead limit exceeded")
       OR matchesPhrase(content, "OutOfMemoryError")
       OR matchesPhrase(content, "Allocation Failure")
  | summarize count = count(), by: { bin(timestamp, 1h) }
  | sort timestamp asc

  Pattern: if GC warnings start appearing at the same time heap began growing
  → confirms memory pressure, not a one-off spike

STEP 3: Find what requests were running when memory was high
  # Cross-reference: at the time heap hit 90%, what was being processed?
  fetch logs, from: "2024-01-15T09:00:00Z", to: "2024-01-15T11:00:00Z"
  | filter service.name == "payment-service"
  | filter status == "INFO"
  | filter matchesPhrase(content, "Processing payment")
  | parse content, "JSON:j"
  | summarize count = count(), by: { bin(timestamp, 5m), j.paymentType }
  | sort timestamp asc

  If "BATCH" paymentType spikes exactly when heap grows → batch job is the leak source

STEP 4: Get thread dump context
  # Spring Boot thread names appear in logs (with proper log config)
  fetch logs, from: "2024-01-15T10:00:00Z", to: "2024-01-15T10:05:00Z"
  | filter service.name == "payment-service"
  | filter matchesPhrase(content, "payment-batch-thread")
  | fields timestamp, content, k8s.pod.name
  | sort timestamp asc

  Combine with: kubectl exec -it <pod> -- jstack 1 > thread-dump.txt
  Cross-reference: DT logs show which thread was active + thread dump shows stack
```

---

## Part 5 — Log Dashboards

### Key panels for an SRE log dashboard

```
Panel 1: Error rate over time (line chart)
  DQL:
    fetch logs
    | filter service.name == "payment-service"
    | summarize
        errors = countIf(status == "ERROR"),
        total  = count(),
        by: { bin(timestamp, 5m) }
    | fieldsAdd error_rate = errors * 100.0 / total
    | sort timestamp asc

Panel 2: Top error messages (table)
  DQL:
    fetch logs
    | filter service.name == "payment-service"
    | filter status == "ERROR"
    | summarize count = count(), by: { content }
    | sort count desc
    | limit 15

Panel 3: Log volume by service (stacked bar)
  DQL:
    fetch logs
    | filter k8s.namespace.name =~ ".*-ns"
    | summarize count = count(), by: { bin(timestamp, 15m), service.name }
    | sort timestamp asc

Panel 4: Recent errors (log viewer tile)
  DQL:
    fetch logs
    | filter status == "ERROR"
    | sort timestamp desc
    | limit 50
    | fields timestamp, service.name, k8s.pod.name, content

Panel 5: Log volume trend (anomaly detection)
  DQL:
    fetch logs
    | filter service.name == "payment-service"
    | summarize count = count(), by: { bin(timestamp, 1h) }
    | sort timestamp asc
  
  Sudden spike in log volume at 14:00 → someone deployed verbose logging
  Sudden drop to zero → log ingestion broken or service stopped
```

---

## Part 6 — DQL Advanced Patterns

### Parse multi-line Java stack traces

```
Java stack traces are multi-line. DT ingests each line separately.
To find all lines of a single exception:

fetch logs
| filter service.name == "payment-service"
| filter matchesPhrase(content, "QueryTimeoutException")
| sort timestamp asc
| limit 1
| fields timestamp, content, k8s.pod.name

# From the result: note the timestamp and pod name
# Then query for all lines from that pod around that timestamp:

fetch logs, from: "2024-01-15T10:30:00Z", to: "2024-01-15T10:30:10Z"
| filter k8s.pod.name == "payment-service-7d9f8b-abc12"
| sort timestamp asc
| fields timestamp, content

# This shows the full stack trace (usually within a 5-10 second window)
```

### Calculate error budget from logs

```dql
fetch logs, from: now()-30d
| filter service.name == "payment-service"
| summarize
    total_requests  = countIf(matchesPhrase(content, "Processing payment")),
    failed_payments = countIf(status == "ERROR" AND matchesPhrase(content, "Payment failed"))
| fieldsAdd success_rate = (total_requests - failed_payments) * 100.0 / total_requests
| fieldsAdd error_budget_used_pct = (100.0 - success_rate) / (100.0 - 99.9) * 100
# 99.9 = SLO target
# error_budget_used_pct: how much of the monthly error budget has been consumed
```

### Detect log storms (log volume anomaly)

```dql
fetch logs, from: now()-2h
| filter service.name == "payment-service"
| summarize count = count(), by: { bin(timestamp, 1m) }
| sort timestamp desc
| limit 120  # last 2 hours at 1-minute resolution

# If count in last 5 minutes is 10× the previous hour average → log storm
# Cause: verbose logging turned on, exception being thrown in a tight loop
# Fix: check for "while(true)" logging, exception being swallowed and re-thrown
```

### Find which deploy caused errors

```dql
# Step 1: find the exact time errors started
fetch logs, from: now()-4h
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize count = count(), by: { bin(timestamp, 1m) }
| sort timestamp asc

# Step 2: check gitops git log for deploys around that time
# (outside DT: git log -- gitops/production/app/payment-service/payment-service.yaml)

# Step 3: in DT, check for deployment events near that time
# DT → Events → filter: event.type == "CUSTOM_DEPLOYMENT"
#              AND entity.name == "payment-service"
# → shows: which image tag was deployed and when
```

---

## Part 7 — Log Retention and Cost Management

### Retention tiers in Grail

```
Default Grail log retention: 35 days
Cost: charged per GB stored + per GB scanned in queries

Retention strategy by log type:

HIGH VALUE (retain 35 days):
  - ERROR logs (all services)
  - WARN logs (all services)
  - Security audit logs
  - Payment transaction logs (compliance)
  Why: incident investigation window is typically 2-4 weeks

MEDIUM VALUE (retain 14 days):
  - INFO logs (application namespaces)
  Why: performance investigation rarely needs > 2 weeks

LOW VALUE (retain 7 days):
  - DEBUG logs (if you keep them at all)
  - Verbose system component logs

EXCLUDE ENTIRELY (don't ingest):
  - Health check logs (/actuator/health called every 5s × 3 replicas = 1M lines/day for nothing)
  - Metrics scrape logs (Prometheus scraping every 15s)
```

### Filter health check logs out of ingestion

```yaml
# DT ingest rule to exclude noisy health check logs
# DT UI: Settings → Log Monitoring → Log ingest rules

Rule name: Exclude health check logs
Matcher:   matchesPhrase(content, "/actuator/health") 
           OR matchesPhrase(content, "GET /health")
Action:    EXCLUDE

# Effect: eliminates ~30-40% of INFO log volume at no monitoring cost
# Health is monitored by Synthetic monitors, not logs
```

### Query cost optimization

```
Expensive queries (avoid):
  fetch logs                              ← no time range → scans all 35 days
  | filter matchesValue(content, "*error*")  ← wildcard at start = full scan

Cheap queries (prefer):
  fetch logs, from: now()-1h, to: now()   ← bounded time range (scans 1/840 of total)
  | filter status == "ERROR"              ← uses indexed field (status is indexed)
  | filter service.name == "payment-service"  ← indexed field

Rule: always specify `from:` and `to:`. Never let DT default to "all time."
Rule: filter on indexed fields FIRST (status, service.name, k8s.namespace.name).
Rule: use `matchesPhrase` (indexed) before `matchesValue` (semi-indexed) before `matches` (regex, full scan).
```

---

## Part 8 — Integration: Logs + Traces + Metrics

### The unified investigation flow

```
ALERT FIRES: "payment-service error rate > 0.1%"
                        │
                        ▼
STEP 1: DT Problem view → shows affected entity: payment-service
        Shows: start time 14:23, affected users: ~500
        Shows: related events (deploy at 14:22 — likely cause!)
                        │
                        ▼
STEP 2: Services → payment-service → Error analysis
        Shows: which endpoint has errors → POST /api/v1/payments
        Shows: error count by time (rising since 14:23)
                        │
                        ▼
STEP 3: Click a failed request → Distributed trace
        order-service [120ms]
          └── payment-service [80ms] ← ERROR
                └── PostgreSQL SELECT [70ms] ← TIMEOUT
        Root cause visible: DB query taking 70ms (normal: 5ms)
                        │
                        ▼
STEP 4: Click "Logs" tab on the payment-service span
        Shows: log lines emitted during THIS request
        "ERROR: Database query timed out after 70ms for query: SELECT..."
        "WARN: Connection pool exhausted, waiting for available connection"
                        │
                        ▼
STEP 5: DQL to see scope of the problem
        fetch logs, from: 14:20, to: 14:40
        | filter service.name == "payment-service"
        | filter matchesPhrase(content, "Connection pool exhausted")
        | summarize count = count(), by: { bin(timestamp, 1m) }
        
        Result: 0 per minute until 14:22, then 150/min → started with deploy
                        │
                        ▼
STEP 6: Cross-reference with JVM metrics
        DT → payment-service → JVM → connection pool metrics
        HikariCP "pending connections" metric jumped at 14:22
        HikariCP pool size = 10, but new code version opens 15 threads → pool exhausted
        
ROOT CAUSE: New deploy doubled thread count, pool size unchanged → DB connection exhaustion
FIX: Either increase HikariCP pool size or reduce thread count in new version
```

### Linking log lines to infrastructure events

```dql
# Find: did any K8s events (pod restarts, OOM kills) correlate with log errors?

fetch logs, from: now()-2h
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize error_count = count(), by: { bin(timestamp, 5m), k8s.pod.name }
| sort timestamp asc

# Then: DT → Kubernetes → payment-service Deployment → Events
# Compare timestamps: pod restart at 14:22 + first errors at 14:23 = same pod restart caused errors
# During pod restart: 1/3 of requests routed to a pod that isn't ready yet → errors
# Fix: startupProbe or readinessProbe not working correctly
```

---

## Part 9 — Log-Based SLIs (Service Level Indicators)

```
Traditional SLI: based on HTTP error rate (DT service metrics)
  (good requests / total requests) × 100

Log-based SLI: based on application-level success/failure
  (successful payments / attempted payments) × 100
  
Why log-based SLIs are MORE ACCURATE:
  HTTP 200 with body {"status":"failed","reason":"insufficient_funds"}
  → HTTP metric: success (200 OK)
  → Business metric: failed payment
  
  HTTP SLI says: 100% success rate
  Log-based SLI says: 23% of payments failed (from application logs)
  
  For a payment service, the business SLI matters more.
```

```dql
# Calculate 30-day payment success rate from logs
fetch logs, from: now()-30d
| filter service.name == "payment-service"
| filter matchesPhrase(content, '"event":"payment_attempt"')
| parse content, "JSON:j"
| summarize
    total   = count(),
    success = countIf(j.result == "SUCCESS"),
    failed  = countIf(j.result == "FAILED")
| fieldsAdd success_rate = success * 100.0 / total

# If Spring Boot writes structured JSON with event fields,
# this gives the true business SLI — not just HTTP response codes.
```

---

## Part 10 — SRE Operational Log Queries (Daily Use)

```bash
# ── MORNING HEALTH CHECK (run these first thing) ──────────────────────────

# 1. Any critical errors overnight?
fetch logs, from: now()-8h
| filter k8s.namespace.name =~ "(payment|order|notification)-ns"
| filter status == "ERROR"
| summarize count = count(), by: { service.name, bin(timestamp, 1h) }
| sort timestamp asc

# 2. Any pod restarts overnight?
fetch logs, from: now()-8h
| filter matchesPhrase(content, "Started") AND matchesPhrase(content, "Application")
# Spring Boot logs "Started PaymentApplication in 8.3 seconds" on startup
# Multiple occurrences per pod = restarts

# 3. Any OOM events?
fetch logs, from: now()-8h
| filter matchesPhrase(content, "OutOfMemoryError")
      OR matchesPhrase(content, "OOMKilled")
| fields timestamp, service.name, k8s.pod.name, content

# ── DEPLOY VERIFICATION (run after every production deploy) ──────────────

# 4. Any new errors introduced?
fetch logs, from: now()-10m
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize count = count(), by: { bin(timestamp, 1m) }
| sort timestamp asc
# Spike in last 5 minutes vs previous 5 minutes = deploy introduced errors

# 5. Startup logs confirm new pods are healthy?
fetch logs, from: now()-10m
| filter service.name == "payment-service"
| filter matchesPhrase(content, "Started PaymentApplication")
| fields timestamp, content, k8s.pod.name
# Should see one entry per new pod started

# ── INCIDENT TRIAGE (when alert fires) ───────────────────────────────────

# 6. What exactly is failing?
fetch logs, from: now()-30m
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize count = count(), by: { content }
| sort count desc
| limit 10

# 7. Is it all pods or one pod?
fetch logs, from: now()-30m
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize count = count(), by: { k8s.pod.name }
| sort count desc

# 8. When exactly did it start?
fetch logs, from: now()-2h
| filter service.name == "payment-service"
| filter status == "ERROR"
| summarize count = count(), by: { bin(timestamp, 1m) }
| sort timestamp asc
```
