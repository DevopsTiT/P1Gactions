# Glossary — Dynatrace Grail Log Management and Analytics

Every term from main.md. One entry per term.

---

**Grail**
Dynatrace's internal data lakehouse that stores all observability data: logs, metrics, traces, and events with a unified query interface. Why it matters: the storage and query layer behind every DT log search, dashboard metric, and SLO calculation.

**Data lakehouse**
A storage architecture that combines the flexibility of a data lake (store any format) with the query performance of a data warehouse (indexed, fast queries). Why it matters: Grail stores raw logs AND pre-indexed fields, giving you both flexible full-text search and fast structured queries.

**DQL (Dynatrace Query Language)**
A pipeline query language for Grail: each `|` passes results to the next stage (like Unix pipes). Why it matters: the only way to query logs, create dashboards, and build log-based metrics in Dynatrace.

**Pipeline (DQL)**
The DQL execution model: `fetch logs | filter ... | summarize ... | sort ... | limit ...`. Each stage transforms the data before passing it on. Why it matters: understanding the pipeline helps you write efficient queries — put the most restrictive filters first to reduce data scanned by later stages.

**`fetch logs`**
The DQL command that retrieves log records from Grail. Can be scoped with `from:` and `to:` time parameters. Why it matters: every DQL log query starts here; always add time bounds to avoid full-history scans.

**`filter` (DQL)**
A DQL stage that keeps only rows matching a condition. Multiple filters are applied as AND. Why it matters: the primary way to narrow log queries; filter on indexed fields (status, service.name) first for best performance.

**`summarize` (DQL)**
A DQL stage that aggregates rows: `count()`, `sum()`, `avg()`, `min()`, `max()`, grouped by fields. Why it matters: turns raw log lines into time-series counts for dashboards and trend analysis.

**`bin(timestamp, 5m)`**
A DQL function that rounds timestamps into fixed-size buckets (e.g., 5-minute windows). Why it matters: used with `summarize by: { bin(timestamp, 5m) }` to create time-series charts of log counts or error rates.

**`parse content, "JSON:j"`**
A DQL command that parses the `content` field as JSON into a variable `j`, making each JSON field accessible as `j.fieldName`. Why it matters: enables structured queries on JSON-formatted application logs (e.g., `j.userId`, `j.errorCode`).

**`matchesPhrase`**
A DQL text search function that does a fast indexed full-text search for an exact phrase. Why it matters: fastest text search in DQL — use it for exception class names and specific error strings.

**`matchesValue`**
A DQL text search function that supports glob wildcards (e.g., `"*connection refused*"`). Why it matters: useful for partial string matching when you don't know the exact phrase; slower than `matchesPhrase`.

**`matches` (regex)**
A DQL text search function that applies a regular expression. Why it matters: most flexible but slowest — triggers a full scan; only use when `matchesPhrase`/`matchesValue` won't work.

**`=~` operator (DQL)**
Regex match operator for non-content fields (e.g., `k8s.namespace.name =~ ".*-ns"`). Why it matters: filters entities by pattern when you don't know the exact value.

**`countIf`**
A DQL aggregate function that counts rows matching a condition: `countIf(status == "ERROR")`. Why it matters: allows calculating both total count and conditional count in a single `summarize` stage.

**`fieldsAdd`**
A DQL command that adds a calculated field: `fieldsAdd error_rate = errors * 100.0 / total`. Why it matters: used for derived metrics like error rate % or error budget consumed % directly in a query.

**`fields`**
A DQL command that projects (keeps) only the specified columns, dropping all others. Why it matters: reduces output size for faster display and cleaner results.

**`isNotNull`**
A DQL function that filters out rows where a field is absent. Why it matters: `filter isNotNull(dt.trace_id)` ensures only log lines linked to a distributed trace are returned.

**Log enrichment**
The process where OneAgent adds Kubernetes metadata to each log line before sending to Grail: pod name, namespace, node, service name, trace ID. Why it matters: without enrichment, a log line is just text — enrichment makes it filterable by pod, service, or linked to a trace.

**Log ingest rules**
DT configuration rules that INCLUDE or EXCLUDE log lines before they are stored in Grail. Why it matters: excluding high-volume low-value logs (health checks, DEBUG) reduces Grail storage costs by 50-80%.

**Log processing rules**
DT configuration rules that run DQL transformations on log lines AT INGESTION TIME to extract and index fields. Why it matters: pre-parsing JSON fields at ingestion means queries don't need to parse at query time — faster queries and lower scan costs.

**Log metric**
A custom metric created by counting DQL-matched log lines. Stored as a time-series metric in Grail. Why it matters: enables metric events (alerts) on log patterns — e.g., "alert when OutOfMemoryError log line count > 0."

**Log-based alert**
A Dynatrace metric event that fires when a log metric crosses a threshold. Why it matters: catches specific application-level failures (OOM, DB corruption, security breach) faster than waiting for downstream symptoms to appear in service metrics.

**`dt.trace_id`**
A Grail log field containing the OpenTelemetry trace ID associated with the request that generated this log line. Why it matters: clicking this in DT UI jumps directly to the distributed trace — the fastest way to find which SQL query or downstream call caused an error.

**`dt.span_id`**
A Grail log field containing the OpenTelemetry span ID of the specific operation that generated this log line. Why it matters: narrows the distributed trace to the exact span (single operation) linked to the log.

**Structured logging (JSON)**
Formatting application log output as JSON objects instead of plain text. Why it matters: DQL can parse individual fields from JSON logs, enabling queries like "count payment failures by error code" instead of string searching.

**Log storm**
A sudden spike in log volume, usually caused by a bug logging repeatedly in a tight loop or verbose logging accidentally enabled in production. Why it matters: log storms can exhaust Grail ingest rate limits, push costs up sharply, and drown real errors in noise.

**Health check log exclusion**
An ingest rule that drops log lines containing `/actuator/health` or similar health probe paths. Why it matters: every Kubernetes readiness probe call (every 5 seconds × 3 replicas) generates a log line — 1 million+ health check log lines per day that contain no useful information.

**Log retention**
How long log data is kept in Grail before being automatically deleted. Default: 35 days. Why it matters: longer retention = higher cost; tune retention per log type (ERROR logs need 35 days, DEBUG logs need 7 days at most).

**Query cost optimization**
Writing DQL queries that scan as little data as possible by using time bounds, indexed fields, and efficient operators. Why it matters: Grail charges per GB scanned — an unbounded query over 35 days of logs costs 35× more than a 1-day query.

**Indexed field**
A Grail log field that has a pre-built search index, making filters on it fast without full scans. Indexed fields include: `status`, `service.name`, `k8s.namespace.name`, `k8s.pod.name`. Why it matters: always filter on indexed fields first to make queries fast and cheap.

**Log-based SLI (Service Level Indicator)**
An SLI calculated from application log events (e.g., `successful payments / attempted payments`) rather than HTTP response codes. Why it matters: HTTP 200 doesn't mean a payment succeeded — only application-level logs know the business outcome.

**`countIf` for SLI calculation**
Using `countIf(j.result == "SUCCESS")` and `countIf(j.result == "FAILED")` in a single `summarize` to calculate a business success rate. Why it matters: combines total count and conditional count in one query pass — efficient for 30-day SLI calculations.

**HikariCP**
The default JDBC connection pool in Spring Boot. Maintains a pool of ready-to-use database connections. Why it matters: "Connection pool exhausted" log entries from HikariCP are a common cause of database-related payment failures — recognizable in logs by HikariCP class names.

**Connection pool exhaustion**
When all connections in the pool are in use and new requests must wait. Why it matters: a common root cause of cascading failures — one slow DB query holds a connection, new requests queue up, response time rises, then errors start.

**Log volume trend**
The week-over-week change in number of log lines per service per hour. Why it matters: a log volume spike (10× normal) with no traffic spike = log storm. A log volume drop to zero = log ingestion broken or service stopped.

**Morning health check (log queries)**
A set of standard DQL queries run each morning to check for overnight errors, pod restarts, OOM events. Why it matters: catching overnight issues at the start of business hours instead of when a customer complains.

**Deploy verification (log queries)**
DQL queries run immediately after a production deploy to confirm no new errors were introduced. Why it matters: deploy-caused errors typically appear within 2-5 minutes; catching them early allows immediate rollback before widespread impact.

**Incident triage (log queries)**
Structured DQL queries to answer: what is failing, which pods, when did it start, what is the error message. Why it matters: following this sequence during an incident gives root cause in minutes instead of hours of ad-hoc searching.

**`bin` time resolution**
The granularity of time buckets in a `summarize by: { bin(timestamp, N) }` query. `1m` for recent incidents, `1h` for daily trends, `1d` for weekly patterns. Why it matters: too fine (1s) = too many data points for a chart. Too coarse (1d) = misses intra-day patterns.

**`sort timestamp asc` vs `desc`**
`asc`: shows oldest first — used to find the FIRST occurrence of an error. `desc`: shows newest first — used to see the LATEST errors. Why it matters: during incident investigation, `asc` helps you find the exact moment something started; `desc` shows what's happening right now.

**Spring Boot startup log**
The log line Spring Boot writes on successful startup: `Started PaymentApplication in 8.3 seconds (JVM running for 9.1)`. Why it matters: multiple occurrences per pod = pod restarted; zero occurrences for a new deploy = pod never reached healthy state.

**Grail retention cost**
Grail storage charges per GB stored × days retained. Why it matters: tuning retention (ERROR=35 days, INFO=14 days, DEBUG=7 days) can reduce log storage costs by 40-60% without losing any incident investigation capability.
