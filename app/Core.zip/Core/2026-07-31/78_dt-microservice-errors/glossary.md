# 78 — Dynatrace Microservice Errors: Glossary

Every term from main.md and troubleshooting-deep-dive.md explained for an SRE beginner.

---

**Dynatrace Problem**
A Dynatrace event that represents a detected issue. Created automatically when metrics cross thresholds or when AI detects anomalies. Has a severity level (AVAILABILITY, ERROR, PERFORMANCE), affected entities, start time, related changes, and a root cause analysis. This is what triggers PagerDuty notifications.

**Problem Severity Levels (Dynatrace)**
Four levels that determine urgency: AVAILABILITY (service completely down — highest), ERROR (high error rate or exceptions), PERFORMANCE (slow responses), RESOURCE (CPU/memory saturation). Each maps to different alerting profiles and different PagerDuty urgency.

**`builtin:service.errors.server.rate`**
A Dynatrace built-in metric measuring the percentage of HTTP requests to a service that return 5xx status codes (server errors). Collected by OneAgent by instrumenting the HTTP framework at the bytecode level. The primary metric for "is this service returning errors?"

**`builtin:service.response.time`**
A Dynatrace built-in metric measuring how long HTTP requests take to complete. Available at multiple percentiles (p50, p75, p95, p99). p99 being high while p50 is normal means some requests are very slow but most are fine — usually indicates connection pool exhaustion or a specific slow query.

**`builtin:service.dbcalls.errors.rate`**
A Dynatrace metric measuring the percentage of database calls that fail. OneAgent instruments JDBC at the bytecode level, so every DB call is captured automatically without application code changes.

**`builtin:container.cpu.throttling_time`**
A Dynatrace metric measuring how many milliseconds per minute a container was throttled by Kubernetes CPU limits. Throttling = the container wanted to use more CPU but K8s slowed it down. High throttling directly causes request latency increases.

**Distributed Trace (Distributed Tracing)**
A record of a request as it flows across multiple services. Each service adds a "span" to the trace with timing, status, and error information. In Dynatrace, the trace shows the full journey: browser → API gateway → payment-service → DB → order-service. The red span tells you exactly where in the chain the failure happened.

**Span**
One segment of a distributed trace representing a single operation within one service (an HTTP handler, a DB call, an external API call). Each span has: service name, operation name, duration, status (success/error), and exception details if failed. Spans are nested to show call relationships.

**Service Map (Dynatrace)**
A visual diagram showing all services and their connections. Red lines between services indicate active failures. The service with red INBOUND arrows from multiple sources is the root cause of a cascading failure. Found under: Services → [service] → Dependencies.

**Cascading Failure**
When one service fails and causes other services that depend on it to fail as well. Example: notification-service goes down → order-service can't notify → order-service returns errors → payment-service can't complete orders → payment-service shows errors. The root cause is notification-service even though the PagerDuty alert shows payment-service.

**Circuit Breaker (Resilience4j)**
A software pattern that "opens" (stops sending requests) when a downstream service is failing. Like a fuse — it trips when too many failures occur, preventing your service from wasting resources calling a service that is down. Returns to normal automatically after the downstream service recovers.

**NullPointerException (NPE)**
`java.lang.NullPointerException` — thrown when Java code tries to call a method or access a field on an object that is `null` (doesn't exist). The most common Java exception. The stack trace shows the exact line number in your code where it happened.

**Connection Pool Exhaustion**
When all database connections in the pool are in use (busy with queries) and new requests must wait. If waiting longer than the timeout (typically 30 seconds), the connection request fails with `HikariPool-1 - Connection is not available, request timed out after 30000ms`. Symptom: DB call latency = exactly 30000ms.

**HikariCP**
The default JDBC connection pool in Spring Boot. Manages a pool of pre-opened database connections. Configured with: `spring.datasource.hikari.maximum-pool-size` (max connections). When the pool is exhausted, new requests queue until a connection is freed or the timeout is reached.

**`/actuator/metrics/hikaricp.connections.active`**
A Spring Boot Actuator endpoint that shows how many database connections are currently in use. If this equals `maximum-pool-size`, the pool is at capacity. Accessible from inside the pod via `localhost:8080/actuator/metrics/hikaricp.connections.active`.

**`/actuator/metrics/hikaricp.connections.pending`**
Shows how many requests are WAITING for a connection from the pool. If > 0, the pool is exhausted and requests are queuing. These pending requests will fail after `connection-timeout` milliseconds.

**EXPLAIN ANALYZE (PostgreSQL/MySQL)**
A database command that shows the execution plan for a SQL query plus actual timing and row counts. `EXPLAIN ANALYZE SELECT * FROM orders WHERE user_id = 12345` reveals if there is a "Seq Scan" (full table scan — missing index) or "Index Scan" (fast — index exists). Essential for diagnosing slow queries.

**Sequential Scan (Seq Scan)**
A database operation that reads every row in a table to find matching records. Very slow on large tables (millions of rows). Appears in EXPLAIN output when there is no index on the WHERE clause column. Fix: create an index.

**N+1 Query Problem**
An ORM anti-pattern where one request causes N+1 database queries: 1 query to get a list of items, then 1 additional query FOR EACH item to get related data. Example: fetch 100 orders, then fetch customer details for each order = 101 queries instead of 1 joined query. DT shows hundreds of identical SQL statements in a single trace.

**`jmap -dump`**
A Java command-line tool that creates a heap dump — a snapshot of all objects in the JVM heap at a point in time. Used to analyze memory leaks. `jmap -dump:live,format=b,file=/tmp/heap.hprof 1` creates a dump of only live objects for PID 1. Analyzed with tools like Eclipse MAT.

**Eclipse MAT (Memory Analyzer Tool)**
A free tool for analyzing Java heap dumps. The "Leak Suspects Report" automatically identifies what is consuming the most memory. Shows which object type is accumulating (the leak) and what is holding references to it.

**Heap Dump**
A binary file containing a snapshot of all objects in the JVM heap memory at a specific moment. Used to find memory leaks by identifying which objects are accumulating. Generated with `jmap` or when OOM occurs with `-XX:+HeapDumpOnOutOfMemoryError` JVM flag.

**`jstack`**
A Java command-line tool that prints a thread dump — a snapshot of all threads and what they are currently doing. Used to diagnose CPU-spinning threads (RUNNABLE state), deadlocks, and thread pool saturation. `jstack 1` prints the thread dump for PID 1.

**Thread Dump**
A text snapshot of all threads in a JVM, showing each thread's state (RUNNABLE, WAITING, BLOCKED) and stack trace. RUNNABLE threads are actively using CPU. Multiple BLOCKED threads waiting for the same lock indicates a deadlock. Analyzed with fastThread.io or similar tools.

**G1GC (Garbage First Garbage Collector)**
A JVM garbage collector designed for large heaps with predictable pause times. Configured with `-XX:+UseG1GC`. Better than the older CMS collector for most microservices. Target max pause: `-XX:MaxGCPauseMillis=200` tells G1GC to try to keep pauses under 200ms.

**ZGC (Z Garbage Collector)**
A modern JVM GC (Java 15+) designed for very low pause times (typically < 10ms). Suitable for services where latency SLOs are very tight. Configured with `-XX:+UseZGC`. Trades slightly higher CPU usage for dramatically lower GC pauses.

**GC Overhead Limit Exceeded**
`java.lang.OutOfMemoryError: GC overhead limit exceeded` — thrown when the JVM has spent more than 98% of its time doing garbage collection but recovered less than 2% of heap space. Means the memory leak has progressed to the point where GC cannot keep up.

**Metaspace**
The area of JVM memory that stores class metadata (class definitions, method signatures). `OutOfMemoryError: Metaspace` means this area is full — too many classes are loaded. Common causes: hot code reloading, Groovy scripts, classloader leaks. Configured with `-XX:MaxMetaspaceSize`.

**CrashLoopBackOff**
A Kubernetes pod status meaning the container keeps crashing and Kubernetes keeps restarting it with exponential backoff (waits longer between each restart attempt). The pod shows STATUS=CrashLoopBackOff in `kubectl get pods`. Read the previous crash logs with `kubectl logs --previous`.

**ImagePullBackOff**
A Kubernetes pod status meaning the container runtime cannot pull the Docker image from the registry (ECR, Docker Hub). Causes: wrong image tag, expired ECR credentials, network connectivity issue, image doesn't exist. Check pod events with `kubectl describe pod`.

**OOMKilled**
When Kubernetes terminates a container because it exceeded its memory limit. Different from a Java OutOfMemoryError (JVM-level) — OOMKilled is Kubernetes-level. Exit code 137. Pod's `kubectl describe` output shows "Last State: Terminated (OOMKilled)". Fix: increase `resources.limits.memory` in Helm values.

**Liveness Probe**
A Kubernetes health check that restarts a pod when it fails. If `/actuator/health` returns non-200, Kubernetes kills and restarts the pod. A liveness probe that fails because the DB is down will cause the pod to restart repeatedly — making a DB problem worse by also crashing the app.

**Readiness Probe**
A Kubernetes health check that removes a pod from load balancer routing when it fails. Does NOT restart the pod — just stops traffic to it until it recovers. Used during startup (pod not ready yet) and when a pod enters a degraded but recoverable state.

**`kubectl rollout undo`**
Reverts a Kubernetes deployment to the previously deployed version. `kubectl rollout undo deployment/payment-service -n payment-ns`. Fast (pre-existing image is already cached) and the safest first action when a bad deploy caused the incident.

**`kubectl rollout status`**
Blocks and waits for a rolling update to complete. Shows progress and confirms when all new pods are ready. Always run after a rollout undo or rollout restart to confirm the change was applied successfully.

**`kubectl logs --previous`**
Shows the logs from the LAST TERMINATED container of a pod (before the current one). Essential for CrashLoopBackOff diagnosis — the current container may not have logged anything yet, but the previous crash's logs are still available.

**`kubectl describe pod`**
Shows detailed information about a pod including: container image, resource limits, environment variables, events (recent actions Kubernetes took), and probe configurations. The Events section is the most useful — it shows exactly why a pod failed to start.

**`kubectl set env`**
A kubectl command that updates environment variables on a running deployment, triggering a rolling restart with the new values. `kubectl set env deployment/payment-service -n payment-ns JAVA_OPTS="-Xmx2g"`. Useful for quick configuration changes during an incident.

**`kubectl top pods`**
Shows current CPU and memory usage for all pods in a namespace. Requires the Metrics Server to be installed. Shows actual usage (not limits). Compare usage vs limits from `kubectl describe pod` to determine if a pod is near its limits.

**Method Hotspots (Dynatrace)**
A DT feature that shows which Java methods are consuming the most CPU time across requests. Found under Services → [service] → Method hotspots. Identifies the specific method (class + method name) that is the CPU bottleneck, enabling targeted optimization.

**Error Budget**
The allowed amount of SLO non-compliance. 99.9% availability = 43.2 minutes of downtime per 30 days. Each incident consumes a portion of this budget. After a major incident, the remaining budget may be near zero, which restricts new risky deployments.

**`CREATE INDEX CONCURRENTLY`**
A PostgreSQL command that builds an index on a table without locking it for reads or writes. Normal `CREATE INDEX` locks the table for the duration (blocks all queries). `CONCURRENTLY` takes longer but allows the application to keep running during index creation. Always use `CONCURRENTLY` in production.

**`fastThread.io`**
A free online tool for analyzing Java thread dumps. Paste the output of `jstack` and it produces a visual report showing: thread states, deadlocks, and which threads are consuming CPU. Much easier to read than raw jstack output.
