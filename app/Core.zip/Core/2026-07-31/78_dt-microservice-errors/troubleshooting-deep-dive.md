# 78 — Troubleshooting Deep Dive: Every Error Type Step by Step

> **How to use this file:** Pick the error category from the DT Problem title.
> Follow the steps in order. Every step tells you WHAT to run, WHAT to look for,
> and WHAT it means. Never skip to the fix without completing diagnosis.

---

## Universal First Steps (Run These for EVERY Incident)

```bash
# Step 1: What changed in the last 2 hours?
git log --oneline --since="2 hours ago" -- gitops/production/

# Step 2: Are pods healthy?
kubectl get pods -n payment-ns -o wide
# Look for: STATUS ≠ Running, RESTARTS > 0, AGE < 10 min (recent restart)

# Step 3: Any K8s events?
kubectl get events -n payment-ns --sort-by=.metadata.creationTimestamp | tail -20

# Step 4: What do DT Problems say right now?
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/problems?status=open" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.problems[] | {title, severity, affectedEntities: .impactedEntities[].name}'
```

---

## Error 1 — High Failure Rate / HTTP 5xx

### Step-by-Step Troubleshooting

**Step 1: Confirm scope in DT**
```
DT → Services → payment-service → Failure rate
  → Is it all endpoints or one specific endpoint?
  → ALL endpoints failing: likely a systemic issue (DB down, bad deploy, OOM)
  → ONE endpoint failing: likely a code bug on that specific path
```

**Step 2: Look at a failing trace**
```
DT → Distributed Tracing → Filter: service=payment-service, error=true
→ Click the most recent failing trace
→ Find the RED span (the one that failed)
→ Expand it: read Exception class + message

Questions to answer from the trace:
  - Which service has the red span? (payment-service itself, or a downstream?)
  - What is the exception class?
  - What line number in what class?
  - Was a downstream call (DB, HTTP) involved?
```

**Step 3: Correlate with deployment**
```
DT → Services → payment-service → Events tab
  → Is there a "Deployment changed" event within 5 minutes before the failure started?
  → YES → rollback is your fastest mitigation
  → NO → something else changed (config, data, external service)
```

**Step 4: Check logs for the full stack trace**
```bash
kubectl logs -n payment-ns -l app=payment-service --since=5m \
  | grep -A 30 "ERROR\|Exception"
# Read the full stack trace — find the first line that is YOUR code (com.company.*)
# That is where the bug is
```

**Step 5: Mitigation decision**
```
If cause = bad deploy:
  kubectl rollout undo deployment/payment-service -n payment-ns
  kubectl rollout status deployment/payment-service -n payment-ns --timeout=5m

If cause = DB failure:
  → See Error 2 troubleshooting below

If cause = downstream service:
  → See Error 9 (Cascading Failures) below

If cause = unknown NPE/bug in code:
  → Cannot fix immediately without a code change
  → Rollback to last known-good version
  → Investigate with heap dump or enhanced logging in dev/staging
```

**Step 6: Verify fix**
```bash
# Watch error rate return to 0
watch -n 15 "curl -s 'https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=builtin:service.errors.server.rate\
&entitySelector=type(SERVICE),entityName(payment-service)\
&resolution=1m&from=now-5m' \
  -H 'Authorization: Api-Token $DT_API_TOKEN' | jq '.resolution.data[].values[-1]'"
```

---

## Error 2 — Database Errors / Connection Pool Exhaustion

### Step-by-Step Troubleshooting

**Step 1: Confirm it's a DB issue in DT**
```
DT → Services → payment-service → Database calls tab
  → Failed calls: is it > 0?
  → Avg response time: is it at 30000ms? (= connection wait timeout — pool exhausted)
  → Which DB statement is failing? (shown in "Top database statements" list)
```

**Step 2: Check pool configuration and current state**
```bash
# What is the pool max currently?
kubectl exec -it \
  $(kubectl get pod -n payment-ns -l app=payment-service -o name | head -1) \
  -n payment-ns -- env | grep -iE "pool|db_max|hikari"

# Check HikariCP pool metrics from Spring Boot actuator
kubectl exec -it \
  $(kubectl get pod -n payment-ns -l app=payment-service -o name | head -1) \
  -n payment-ns -- wget -qO- localhost:8080/actuator/metrics/hikaricp.connections.active
# Active = connections currently in use

kubectl exec -it \
  $(kubectl get pod -n payment-ns -l app=payment-service -o name | head -1) \
  -n payment-ns -- wget -qO- localhost:8080/actuator/metrics/hikaricp.connections.pending
# Pending = requests WAITING for a connection (if > 0 → pool exhausted)
```

**Step 3: Find the slow query causing pool exhaustion**
```
DT → Services → payment-service → Database calls tab → Top DB statements
  → Sort by: Max duration
  → Look for: one statement with duration 8000ms+ while others are 50ms
  → That slow statement holds connections open → pool exhausts → other requests queue

Then in DT Traces:
  → Find a trace where the slow statement appears
  → Read the full SQL (DT shows it)
  → Identify which code path calls it
```

**Step 4: Immediate mitigation (if pool exhausted)**
```bash
# Increase pool size to relieve pressure immediately
kubectl set env deployment/payment-service -n payment-ns \
  SPRING_DATASOURCE_HIKARI_MAXIMUM_POOL_SIZE=100
kubectl rollout status deployment/payment-service -n payment-ns

# Verify pool size took effect
kubectl exec -it \
  $(kubectl get pod -n payment-ns -l app=payment-service -o name | head -1) \
  -n payment-ns -- env | grep HIKARI
```

**Step 5: Fix the slow query (post-incident)**
```bash
# Connect to the DB and run EXPLAIN on the slow query
# (get the SQL from the DT trace first)
kubectl exec -it [db-pod] -n db-ns -- psql -U app_user -d payments \
  -c "EXPLAIN ANALYZE SELECT * FROM orders WHERE user_id = 12345;"
# If you see "Seq Scan" → missing index
# If you see "Rows=1000000" → full table scan

# Add the index (PostgreSQL — CONCURRENTLY = no table lock)
kubectl exec -it [db-pod] -n db-ns -- psql -U app_user -d payments \
  -c "CREATE INDEX CONCURRENTLY idx_orders_user_id ON orders(user_id);"
```

**Step 6: Verify DB is healthy after fix**
```bash
# Check DT DB metrics
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=builtin:service.dbcalls.errors.rate\
&entitySelector=type(SERVICE),entityName(payment-service)\
&resolution=1m&from=now-10m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.resolution.data[].values'
# Should be 0 or near 0
```

---

## Error 3 — JVM Exceptions (NullPointerException, ClassCastException, etc.)

### Step-by-Step Troubleshooting

**Step 1: Identify the exact exception from DT**
```
DT → Distributed Tracing → Failed traces → expand exception section
  OR
DT → Services → payment-service → Events → Exceptions tab
  → DT groups exceptions by type — click the most common one
  → Read: exception class, message, first YOUR code line in stack trace
```

**Step 2: Read the full stack trace**
```bash
# Get the full stack trace from logs
kubectl logs -n payment-ns -l app=payment-service --since=5m \
  | grep -A 50 "NullPointerException"
# Find: at com.company.YourClass.yourMethod(YourClass.java:LINE_NUMBER)
# That is the exact location of the bug
```

**Step 3: Understand what was null/wrong**
```
For NullPointerException:
  Line 47: String value = request.getPaymentDetails().getAmount();
  → getPaymentDetails() returned null
  → WHY? Was request valid? Was the input data malformed?
  → Check: what input data caused this trace to fail?
  → DT Trace → Request attributes → see the request body/params

For ClassCastException:
  → Something is casting an object to the wrong type
  → Common: JSON deserialization mismatch (API changed its response format)
  → Check: is a downstream API returning a different schema now?
```

**Step 4: Determine if it's affecting ALL requests or SOME**
```
DT → Services → payment-service → Top endpoints
  → Is the exception happening on all endpoints or one specific one?
  → If specific: that endpoint has a code path bug, other flows are fine
  → If all: something fundamental is broken (bad deploy, shared component)
```

**Step 5: Mitigation**
```bash
# If it started after a deploy → rollback immediately
kubectl rollout history deployment/payment-service -n payment-ns
kubectl rollout undo deployment/payment-service -n payment-ns

# If it's a data issue (specific requests cause it):
# → Cannot rollback (code is fine, data is the problem)
# → Add input validation to catch the bad data gracefully
# → This requires a code fix and re-deploy
```

**Step 6: Root cause analysis after recovery**
```
In the code, find the exact line from the stack trace:
  at com.company.PaymentService.processPayment(PaymentService.java:47)

Add defensive check:
  BEFORE: String amount = request.getPaymentDetails().getAmount();
  AFTER:  if (request.getPaymentDetails() == null) {
            throw new InvalidRequestException("paymentDetails is required");
          }
          String amount = request.getPaymentDetails().getAmount();

This converts an unhandled NPE (500 Internal Server Error) into a 
handled validation error (400 Bad Request) — much better for users.
```

---

## Error 4 — OutOfMemoryError (OOM)

### Step-by-Step Troubleshooting

**Step 1: Confirm OOM and which type**
```bash
# Check if any pod was OOMKilled
kubectl describe pod -n payment-ns -l app=payment-service \
  | grep -A 5 "Last State\|OOM\|Exit Code"
# Exit Code 137 = OOMKilled by Kubernetes (container limit hit)
# Exit Code 1 with OutOfMemoryError in logs = JVM heap exhausted

# Read the last crash log
kubectl logs -n payment-ns [pod-name] --previous | grep -i "OutOfMemory" | head -5
# java.lang.OutOfMemoryError: Java heap space → heap exhausted
# java.lang.OutOfMemoryError: GC overhead limit exceeded → GC can't keep up
# java.lang.OutOfMemoryError: Metaspace → class metadata area full
```

**Step 2: Check heap trend in DT (memory leak detection)**
```
DT → Technologies → JVM → [payment-service process] → Memory tab
  → Heap usage over time (look at hours of history)
  
Normal sawtooth: ________/\/\/\/\/\_______
  → Heap goes up → GC cleans it → drops back to same level → healthy

Memory leak sawtooth: ___/\__/\___/\____/\___
  → Each GC cycle drops back a little HIGHER than before
  → The baseline keeps rising → eventual OOM

If you see the memory leak pattern:
  → Need a heap dump to find what is accumulating
```

**Step 3: Take a heap dump for analysis**
```bash
# Find the JVM PID inside the container (usually PID 1 for Spring Boot)
kubectl exec -it [pod-name] -n payment-ns -- ps aux | grep java

# Take a live heap dump (only live objects — excludes already-garbage objects)
kubectl exec -it [pod-name] -n payment-ns -- \
  jmap -dump:live,format=b,file=/tmp/heap.hprof 1

# Copy the heap dump out of the pod
kubectl cp payment-ns/[pod-name]:/tmp/heap.hprof ./heap-$(date +%Y%m%d-%H%M).hprof

# Analyze with Eclipse MAT or VisualVM on your laptop
# Look for: objects with the highest retained heap size
# → That object type is what is accumulating (the leak)
```

**Step 4: Immediate mitigation**
```bash
# Option A: Increase JVM heap size (buys time, doesn't fix a leak)
# Edit Helm values: add JVM flags
# values-production.yaml:
#   env:
#     - name: JAVA_OPTS
#       value: "-Xms512m -Xmx2g -XX:+UseG1GC"
kubectl set env deployment/payment-service -n payment-ns \
  JAVA_OPTS="-Xms512m -Xmx2g -XX:+UseG1GC"

# Option B: Increase Kubernetes memory limit (so K8s doesn't OOMKill before JVM crashes)
# Edit resources.limits.memory in Helm values → re-deploy
# resources:
#   limits:
#     memory: "4Gi"   # was 2Gi

# Option C (fastest): Rollback if OOM started after a deploy
kubectl rollout undo deployment/payment-service -n payment-ns
```

**Step 5: After recovery — identify the leak source**
```
In Eclipse MAT → Leak Suspects report:
  Common culprits:
  - Static Map/List that grows indefinitely (unbounded cache)
  - Event listener not unregistered (EventBus, Spring events)
  - ThreadLocal variable not cleared
  - Large response objects cached in memory
  - Session data accumulating (no TTL)
  
Fix: eliminate the unbounded collection or add eviction/TTL
```

---

## Error 5 — Pod Crash / Service Unavailable

### Step-by-Step Troubleshooting

**Step 1: Get pod status**
```bash
kubectl get pods -n payment-ns -o wide
# Look for:
#   STATUS = CrashLoopBackOff → pod crashes repeatedly → K8s keeps restarting
#   STATUS = ImagePullBackOff → can't pull Docker image
#   STATUS = OOMKilled → memory limit hit
#   STATUS = Error → single crash (check why)
#   RESTARTS > 3 → crashing repeatedly
```

**Step 2: Get the crash reason**
```bash
# For CrashLoopBackOff — read the LAST crash log
kubectl logs -n payment-ns [pod-name] --previous
# This shows what the container printed BEFORE it crashed last time
# Read the last 50 lines → find the exception or error message

# For ImagePullBackOff — check the image details
kubectl describe pod -n payment-ns [pod-name] | grep -A 5 "Events:"
# Events will say: Failed to pull image "ECR_URL:tag" due to: unauthorized
# OR: no such image (wrong tag)

# For OOMKilled
kubectl describe pod -n payment-ns [pod-name] | grep -B 5 -A 5 "OOMKilled\|Exit Code"
```

**Step 3: Check what the pod was trying to do on startup**
```bash
# Get the full startup log (even if pod is currently crashing)
kubectl logs -n payment-ns [pod-name]
# Spring Boot startup errors appear here:
#   APPLICATION FAILED TO START → missing config, failed bean initialization
#   "Failed to obtain JDBC Connection" → DB unreachable on startup
#   "Property 'X' must not be null" → required env var missing

# Check the deployment configuration for missing env vars
kubectl get deployment payment-service -n payment-ns -o yaml \
  | grep -A 5 "env:"
```

**Step 4: Check liveness probe configuration**
```bash
kubectl describe deployment payment-service -n payment-ns \
  | grep -A 10 "Liveness\|Readiness"
# If liveness probe is failing: the probe endpoint (/actuator/health) returns non-200
# Common causes:
#   - App not started yet (startupProbe failureThreshold too low)
#   - App in bad state (downstream DB failed → health check fails → liveness kills it)
```

**Step 5: Fix based on cause**
```bash
# CrashLoopBackOff from bad deploy:
kubectl rollout undo deployment/payment-service -n payment-ns

# CrashLoopBackOff from missing env var:
kubectl set env deployment/payment-service -n payment-ns DB_HOST=postgres.payment-ns.svc
kubectl rollout status deployment/payment-service -n payment-ns

# ImagePullBackOff — wrong image tag:
# Check what tag is in gitops/ and what exists in ECR
kubectl get deployment payment-service -n payment-ns \
  -o jsonpath='{.spec.template.spec.containers[0].image}'
# If tag doesn't exist in ECR → update gitops/ with a valid tag

# OOMKilled — increase memory limit:
# Edit Helm values → resources.limits.memory: "4Gi"
# Then push to gitops/ → ArgoCD applies
```

---

## Error 6 — Slow Response Time (Latency Degradation)

### Step-by-Step Troubleshooting

**Step 1: Find where in the call chain the slowness is**
```
DT → Distributed Tracing → Filter: service=payment-service, duration > 2s
  → Click a slow trace
  → Expand the span tree — which span is taking longest?
  
  If the slow span is a DB call → go to Error 8 (slow queries)
  If the slow span is an external HTTP call → go to Error 9 (downstream)
  If the slow span is within payment-service itself → it's a code/CPU issue
```

**Step 2: Check CPU throttling**
```bash
# Is the pod being throttled by K8s CPU limit?
kubectl top pods -n payment-ns
# CPU usage close to limit? → throttling is slowing every thread

# DT: Infrastructure → Containers → payment-service → CPU throttling
# If throttling_time > 0 → CPU is the bottleneck

# Fix immediately:
kubectl set resources deployment/payment-service -n payment-ns \
  --requests=cpu=500m --limits=cpu=2
```

**Step 3: Check GC pauses (if latency spikes are periodic)**
```
DT → Technologies → JVM → [payment-service process] → Garbage collection tab
  → GC pause duration: if spikes match the latency spikes → GC is the cause
  → GC count: if very high → GC running too frequently → heap too small

Fix: Add JVM flags to reduce GC pauses:
  -XX:+UseG1GC -XX:MaxGCPauseMillis=200 -XX:G1HeapRegionSize=16m
```

**Step 4: Find slow code paths using DT Method Hotspots**
```
DT → Services → payment-service → Method hotspots (if enabled)
  → Shows which JAVA METHODS consume the most CPU time
  → If a specific method uses 80% of CPU → that's your bottleneck

DT → Distributed Tracing → Slow traces → Method-level breakdown
  → Shows time spent in each Java method call within a span
```

**Step 5: Check if slowness is on a specific endpoint**
```
DT → Services → payment-service → Top endpoints
  → Sort by response time
  → Is ONE endpoint slow while others are fast?
  → YES: that endpoint has a bug/slow query unique to its code path
  → Filter traces by that endpoint URL → find the slow span → diagnose specifically
```

---

## Error 7 — Cascading Failures (Downstream Service Down)

### Step-by-Step Troubleshooting

**Step 1: Use DT Service Map to find the real root cause**
```
DT → Applications & Microservices → Services → [any red service]
  → Click "View service map" or "Dependencies"
  → Look for the service with multiple red INBOUND arrows
  → The service being called BY multiple others AND failing = root cause

Pattern:
  payment-service (red) ←── order-service (red) ←── notification-service (RED ← ROOT)
  → Fix notification-service first, others will recover
```

**Step 2: Confirm with a distributed trace**
```
DT → Distributed Tracing → Failed trace
  → Expand the full trace tree
  → The span that failed DEEPEST in the tree = the actual origin of the failure
  → Everything above it failed because of it (cascading)
```

**Step 3: Check if it's an external dependency**
```bash
# Is the failing service yours or external?
kubectl get services -n payment-ns   # is the failing service in your cluster?

# If external (Stripe, Twilio, Auth0, etc.):
# Check their status page: status.stripe.com, status.twilio.com, etc.
# DT → Services → payment-service → Outgoing dependencies
#   → Find the external URL that is failing
#   → HTTP 429 = rate limited, HTTP 503 = external service down

# If internal service in your cluster:
# Go to that service's DT view and troubleshoot it directly
```

**Step 4: Immediate mitigation**
```
If it's an external service that is down:
  → Add a fallback in the payment-service code (return a default response or error 503 gracefully)
  → The fix is in the code — deploy a version that handles the downstream error gracefully

If it's an internal service (order-service):
  → Troubleshoot order-service directly (apply the relevant error type steps above)
  → payment-service will recover automatically once order-service is fixed

If there is a circuit breaker already configured:
  → Check if it is OPEN (not allowing calls through)
  → If OPEN: downstream is down → wait for downstream to recover → circuit will close
  → If NOT open: the circuit breaker may be misconfigured or not present
```

**Step 5: Add circuit breakers if they don't exist (post-incident action)**
```java
// Spring Boot + Resilience4j example
@CircuitBreaker(name = "order-service", fallbackMethod = "orderServiceFallback")
@TimeLimiter(name = "order-service")
public CompletableFuture<OrderResponse> callOrderService(String orderId) {
    return orderServiceClient.getOrder(orderId);
}

public CompletableFuture<OrderResponse> orderServiceFallback(String orderId, Exception e) {
    // Return a safe default or cached response
    return CompletableFuture.completedFuture(OrderResponse.unavailable());
}
```

---

## Error 8 — CPU / Memory Resource Saturation

### Step-by-Step Troubleshooting

**Step 1: Confirm which resource is saturated**
```bash
# Current resource usage vs limits
kubectl top pods -n payment-ns
kubectl describe pod -n payment-ns -l app=payment-service | grep -A 8 "Limits:\|Requests:"

# Are we near the limit?
# CPU: usage ≈ limit → throttling is happening
# Memory: usage > 90% of limit → OOMKill risk
```

**Step 2: For CPU — find what is consuming CPU**
```
DT → Technologies → JVM → [process] → CPU tab
  → Thread CPU breakdown: which thread is using the most CPU?

DT → Services → payment-service → Method hotspots
  → Which Java method is consuming the most CPU time?
  → Common causes: regex compilation in hot path, JSON serialization of huge objects,
    encryption of every request, inefficient loops

kubectl exec -it [pod-name] -n payment-ns -- \
  jstack 1 > /tmp/thread-dump.txt
# Read: which threads are RUNNABLE (actively computing)?
# Copy the thread dump → analyze with fastThread.io
```

**Step 3: For Memory — check what is growing**
```
DT → Technologies → JVM → [process] → Memory tab
  → Heap allocated: is it growing continuously? → leak
  → Survivor space full: objects not dying young → accumulating in old gen
  → Metaspace growing: class loader leak

kubectl top pods -n payment-ns -w
# Watch memory usage in real time
```

**Step 4: Fix — increase limits first, then optimize**
```bash
# IMMEDIATE: increase limits to stop the bleeding
# Edit Helm values:
# resources:
#   requests:
#     cpu: "500m"
#     memory: "1Gi"
#   limits:
#     cpu: "2"        ← increase CPU limit
#     memory: "4Gi"   ← increase memory limit

# Then push to gitops/ → ArgoCD applies automatically

# LONG TERM: profile the code
# CPU: identify the hot method → optimize the algorithm
# Memory: take heap dump → find the leak → fix the code
```

---

## Post-Incident Checklist (After Every Error Type)

```
After resolving any incident, always do these:

□ Verify the fix: watch metrics return to baseline for 10+ minutes
□ Write a brief incident summary in the Slack #incident channel
□ Create Jira tickets for:
    □ Root cause fix (P1 if it will recur without fix)
    □ Improved alerting (if detection was slow)
    □ Runbook update (if these steps are not already documented)
□ Update the DT synthetic monitor if needed (was the check covering the broken path?)
□ Check error budget: how much did this incident consume?
□ Schedule postmortem if SEV1/SEV2
```
