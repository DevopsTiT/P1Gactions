# 78 — Common Errors Visible in Dynatrace for Microservices

> **What this covers:** Every category of error Dynatrace surfaces for Java microservices
> on Kubernetes — what it looks like, what caused it, how to diagnose it, and how to fix it.
> Organized by where in the stack the error appears.

---

## Decision Tree — "What is Dynatrace Showing Me?"

```
Is there an open Problem in DT?
    │
    ├── ERROR severity Problem
    │   ├── "High failure rate" / "Service failure rate" → HTTP 5xx errors (Part 1)
    │   ├── "Database query failure" → DB errors (Part 2)
    │   ├── "Exception detected" → JVM exceptions (Part 3)
    │   └── "OutOfMemoryError" / log-based → JVM OOM (Part 4)
    │
    ├── AVAILABILITY severity Problem
    │   ├── "Service unavailable" → Pod crash / all pods down (Part 5)
    │   └── "Synthetic check failed" → Endpoint unreachable (Part 6)
    │
    ├── PERFORMANCE severity Problem
    │   ├── "Response time degradation" → Slow endpoints (Part 7)
    │   ├── "Database slow query" → DB latency (Part 8)
    │   └── "External service degraded" → Downstream dependency slow (Part 9)
    │
    └── RESOURCE severity Problem
        ├── "CPU saturation" → Pod CPU throttled (Part 10)
        ├── "Memory saturation" → Pod near OOM (Part 11)
        └── "GC overhead" → JVM garbage collection (Part 12)
```

---

## Part 1 — HTTP 5xx Error Rate (Service Failure Rate)

### What Dynatrace Shows

```
Problem title:  "payment-service: High failure rate"
Metric:         builtin:service.errors.server.rate
Typical value:  > 1–5% (depending on threshold setting)
DT location:    Services → payment-service → Failure rate graph
                Distributed Traces → filter: status=ERROR
```

### Common Root Causes and What You See

```
Root Cause 1: NullPointerException in request handler
  Trace view shows:  500 Internal Server Error on POST /api/v1/payments
  Span detail:       Exception: java.lang.NullPointerException
                     at PaymentService.processPayment(PaymentService.java:47)
  Log line:          ERROR PaymentService - Unexpected null value in payment request

Root Cause 2: Database connection failure
  Trace view shows:  500 on all endpoints that touch the DB
  Span detail:       Exception: org.springframework.dao.DataAccessException
                     Caused by: java.sql.SQLTransientConnectionException
  Log line:          WARN HikariPool - Timeout waiting for connection from pool

Root Cause 3: Downstream service returning 500
  Trace view shows:  payment-service → order-service call → 500
  DT service map:    Red line from payment-service to order-service
  The payment-service failure is CAUSED BY order-service failing

Root Cause 4: Bad deploy (new code has a bug)
  DT shows:          "Related change: deployment detected 3 minutes ago"
  Immediate fix:     kubectl rollout undo deployment/payment-service -n payment-ns
```

### How to Diagnose in Dynatrace

```
Step 1: Services → payment-service → Failure rate graph
  → Note when the spike started (correlate with deployment events)

Step 2: Distributed Traces → Filter: service=payment-service, error=true
  → Click a failed trace
  → Read the span that is red/failing
  → Expand the exception detail (class + message + stack trace)

Step 3: Logs → Filter: service=payment-service, level=ERROR, time=incident window
  → Read the log lines to get the full stack trace

Step 4: DT automatically shows "Related deployments"
  → If a deploy happened just before → rollback is the fastest mitigation
```

### Dynatrace API Query

```bash
# Get current failure rate
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=builtin:service.errors.server.rate\
:filter(and(eq(dt.entity.service,SERVICE-abc123)))\
&resolution=1m&from=now-15m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.resolution.data[].values'
```

---

## Part 2 — Database Errors

### What Dynatrace Shows

```
Problem title:  "payment-service: Database query failure rate increase"
Metric:         builtin:service.dbcalls.errors.rate
DT location:    Services → payment-service → Database calls
                Technologies → Databases → [db name]
```

### Common Root Causes

```
Error Type 1: Connection Pool Exhaustion
  DT shows:    DB call latency spikes to 30s (= connection wait timeout)
               Exception in traces: HikariPool-1 - Connection is not available,
               request timed out after 30000ms
  Cause:       Pool max size too small, or slow queries holding connections too long
  Fix:         Increase DB_POOL_MAX env var OR kill the slow query

Error Type 2: Deadlock
  DT shows:    Intermittent DB errors, short spikes
               Exception: com.mysql.jdbc.exceptions.jdbc4.MySQLTransactionRollbackException
               Deadlock found when trying to get lock
  Cause:       Two transactions locking rows in opposite order
  Fix:         Review transaction isolation level, add retry logic

Error Type 3: Query Syntax Error (bad deploy)
  DT shows:    100% DB error rate immediately after deploy
               Exception: org.hibernate.exception.SQLGrammarException
               could not execute statement
  Cause:       ORM migration mismatch, new column doesn't exist yet
  Fix:         Rollback OR run pending migration

Error Type 4: DB Host Unreachable
  DT shows:    All DB calls fail simultaneously
               Exception: com.mysql.jdbc.exceptions.jdbc4.CommunicationsException
               Communications link failure
  Cause:       DB host crash, network partition, wrong DB_HOST env var in new deploy
  Fix:         Check DB host health, check env vars in the deployment

Error Type 5: Duplicate Key / Constraint Violation
  DT shows:    Specific insert operations fail
               Exception: org.springframework.dao.DataIntegrityViolationException
               Duplicate entry for key 'PRIMARY'
  Cause:       Race condition in concurrent writes, idempotency issue
  Fix:         Add upsert logic or check-before-insert
```

### Dynatrace DB View: What to Look For

```
Services → payment-service → scroll to "Database calls"
  → Total calls/min: is it lower than normal? (fewer calls = app failing before reaching DB)
  → Failed calls/min: how many per minute are erroring?
  → Response time: is it at exactly 30000ms? (= timeout, not a real slow query)

Technologies → Databases → [your DB]
  → Top failing statements: which specific SQL is failing?
  → Response time distribution: is there a bimodal split? (fast queries + timed-out queries)
```

---

## Part 3 — JVM Exceptions (Unhandled / Detected)

### What Dynatrace Shows

```
Problem title:  "payment-service: Exception count increase"
Metric:         builtin:service.errors.exceptions.rate
DT location:    Services → payment-service → Events tab → Exceptions
                Distributed Traces → span with exception icon
```

### Most Common Java Exceptions in Microservices

```
Exception 1: NullPointerException (NPE)
  DT shows:   Exception: java.lang.NullPointerException
              at com.company.PaymentService.process(PaymentService.java:47)
  Meaning:    Code tried to use an object that was null
  Pattern:    Specific endpoint only fails → specific code path has NPE
  Fix:        Add null checks, fix the logic that should have provided the object

Exception 2: ClassNotFoundException / NoSuchMethodException
  DT shows:   java.lang.ClassNotFoundException: com.company.SomeClass
  Meaning:    A required class is missing — usually a bad deploy with missing dependency
  Pattern:    All requests fail immediately after deploy
  Fix:        Rollback → check pom.xml / build.gradle for missing dependency

Exception 3: StackOverflowError
  DT shows:   java.lang.StackOverflowError
              at com.company.RecursiveMethod.call(...)
  Meaning:    Infinite recursion — a method calls itself endlessly
  Pattern:    Specific requests fail, not all
  Fix:        Find the recursive call chain, add a base case

Exception 4: ArrayIndexOutOfBoundsException
  DT shows:   java.lang.ArrayIndexOutOfBoundsException: Index 5 out of bounds for length 3
  Meaning:    Code accessed array position that doesn't exist
  Pattern:    Specific input triggers it — usually edge case in data handling
  Fix:        Add bounds checking before array access

Exception 5: ClassCastException
  DT shows:   java.lang.ClassCastException: class A cannot be cast to class B
  Meaning:    Incorrect type assumption — often from JSON deserialization
  Pattern:    Specific data shapes trigger it
  Fix:        Fix the deserialization logic or add type checking

Exception 6: NumberFormatException
  DT shows:   java.lang.NumberFormatException: For input string: "abc"
  Meaning:    Tried to parse non-numeric string as a number
  Pattern:    User input or external API response contains unexpected format
  Fix:        Validate input before parsing, handle ParseException
```

### How to See Exception Details in DT

```
Method 1: Distributed Traces
  Distributed Tracing → filter: service=payment-service, error=true
  → Click a trace → find red span → expand "Exception" section
  → See: exception class, message, full stack trace, file:line number

Method 2: Services Event Feed
  Services → payment-service → Events tab
  → Filter: type=Exception
  → DT groups exceptions by class and message — shows top exception types
  → Click a group → see individual occurrences with timestamps

Method 3: Logs (if log ingestion enabled)
  Logs → filter: level=ERROR, service=payment-service
  → Full stack traces in log lines
```

---

## Part 4 — OutOfMemoryError (JVM Heap Exhaustion)

### What Dynatrace Shows

```
Problem title (if log-based metric event configured):
  "payment-service: OutOfMemoryError detected"

OR visible in:
  Services → payment-service → JVM metrics → Heap usage
  Problems → pod restart spike
  Logs → level=ERROR, content contains "OutOfMemoryError"
```

### OOM Subtypes and What They Mean

```
OOM Type 1: Java heap space
  Log:    java.lang.OutOfMemoryError: Java heap space
  Cause:  Application is creating too many objects without releasing them
          (memory leak) OR heap size is too small for the workload
  DT:     Heap usage graph shows linear growth until crash (sawtooth pattern stops → crash)
  Fix:    Increase -Xmx OR find the memory leak with heap dump analysis

OOM Type 2: GC overhead limit exceeded
  Log:    java.lang.OutOfMemoryError: GC overhead limit exceeded
  Cause:  JVM is spending > 98% of time doing GC and recovering < 2% of heap
          Effectively: memory leak has progressed to the point GC can't help
  DT:     GC time % metric spikes to near 100%
  Fix:    Same as heap space — increase memory OR fix the leak

OOM Type 3: Metaspace
  Log:    java.lang.OutOfMemoryError: Metaspace
  Cause:  Class metadata area is full — too many dynamically loaded classes
          (common with: Groovy scripts, heavy reflection, classloader leaks)
  DT:     Metaspace usage graph grows steadily
  Fix:    Add -XX:MaxMetaspaceSize flag OR fix the classloader leak

OOM Type 4: Direct buffer memory
  Log:    java.lang.OutOfMemoryError: Direct buffer memory
  Cause:  Off-heap memory for NIO operations exhausted
          (common with: Netty, heavy file I/O, Kafka clients)
  DT:     Direct memory metric increases; heap may look normal
  Fix:    Add -XX:MaxDirectMemorySize OR reduce buffer allocation
```

### Dynatrace JVM Memory View

```
Navigate: Technologies → JVM → [your JVM process] → Memory tab
  → Heap usage over time: should be sawtooth (GC cleans it periodically)
  → If sawtooth amplitude grows each cycle → memory leak
  → If heap hits Xmx and stays there → OOM imminent

Navigate: Services → payment-service → JVM metrics
  → GC time %: should be < 5% normally
  → If > 20%: GC struggling → near OOM
  → If > 80%: OOM likely within minutes
```

---

## Part 5 — Service Unavailability (Pod Crash / All Pods Down)

### What Dynatrace Shows

```
Problem title:  "payment-service: Service unavailable"
Metric:         builtin:service.availability.rate = 0%
                OR synthetic check failure (all locations)
DT location:    Services → payment-service → Availability tab
                Problems → AVAILABILITY severity (highest severity)
```

### Root Causes

```
Cause 1: All pods in CrashLoopBackOff
  DT shows:   Availability drops to 0%
              Infrastructure → Kubernetes → pod status = CrashLoopBackOff
  kubectl:    kubectl get pods -n payment-ns → STATUS: CrashLoopBackOff
              kubectl logs payment-service-xxx --previous → last crash reason
  Fix:        Read the crash log → fix the startup error → redeploy

Cause 2: Deployment rolled out broken image
  DT shows:   Availability drops exactly at deploy event
              "Related change: deployment updated image tag"
  kubectl:    kubectl describe pod payment-service-xxx → image pull error OR startup crash
  Fix:        kubectl rollout undo deployment/payment-service -n payment-ns

Cause 3: ImagePullBackOff (can't pull Docker image)
  DT shows:   Service unavailable + Kubernetes events show ImagePullBackOff
  kubectl:    kubectl describe pod → "Failed to pull image... unauthorized"
  Cause:      ECR token expired, wrong image tag, image not found
  Fix:        Check ECR permissions, verify image tag exists

Cause 4: Liveness Probe Failing Continuously
  DT shows:   Pod restart count increasing in DT Infrastructure view
              Service availability low (pods restarting = brief unavailability)
  kubectl:    kubectl describe pod → "Liveness probe failed: HTTP probe..."
  Cause:      /actuator/health returns non-200 (app in bad state, misconfigured)
  Fix:        Check app startup logs, increase failureThreshold if startup is slow

Cause 5: OOMKilled by Kubernetes
  DT shows:   Pod restart count spikes, OOM log events
  kubectl:    kubectl describe pod → Last State: OOMKilled
  Cause:      Container memory limit too low
  Fix:        Increase resources.limits.memory in Helm values
```

---

## Part 6 — Synthetic Check Failures (Endpoint Unreachable)

### What Dynatrace Shows

```
Problem title:  "payment-service /api/health: Synthetic check failed"
DT location:    Synthetics → [monitor name] → Results
                Shows: which locations failed, error code, response time
```

### Error Codes and Meanings

```
DNS_ERROR
  Meaning:  Domain name doesn't resolve from that location
  Cause:    DNS misconfiguration, CDN edge issue, ExternalDNS not updated
  Check:    kubectl get ingress -n payment-ns → verify hostname is configured

CONNECTION_REFUSED
  Meaning:  TCP connection rejected — port not open or server not listening
  Cause:    Service is down, wrong port in synthetic config, firewall rule
  Check:    kubectl get svc -n payment-ns, test from inside cluster

CONNECTION_TIMEOUT
  Meaning:  TCP connection opened but no response within timeout
  Cause:    Application overloaded, pod blocked, network partition
  Check:    kubectl top pods -n payment-ns (CPU/memory saturation?)

READ_TIMEOUT
  Meaning:  Response started arriving but didn't complete within timeout
  Cause:    Application extremely slow, large response body, GC pause
  Check:    DT latency metrics for that endpoint, JVM GC metrics

STATUS_CODE_ERROR
  Meaning:  HTTP response code doesn't match assertion (e.g., got 503 instead of 200)
  Cause:    Application returning error code, check the HTTP status in the result detail

SSL_ERROR / CERTIFICATE_ERROR
  Meaning:  TLS handshake failed or certificate expired/invalid
  Cause:    cert-manager failed to renew, wrong certificate served, chain broken
  Check:    kubectl get certificate -n payment-ns, check cert-manager logs

SCRIPT_ERROR (browser monitors)
  Meaning:  JavaScript element not found, assertion failed, DOM structure changed
  Cause:    UI change broke the selector, JavaScript error on page
  Check:    Screenshot from failed run, update selector to use data-test attribute
```

---

## Part 7 — Response Time Degradation (Slow Endpoints)

### What Dynatrace Shows

```
Problem title:  "payment-service: Response time degradation"
Metric:         builtin:service.response.time
DT location:    Services → payment-service → Response time graph
                Shows p50, p75, p90, p95, p99 percentiles
```

### Root Causes by Pattern

```
Pattern 1: p99 elevated, p50 normal → some requests are extremely slow
  Cause:    Connection pool exhaustion: fast requests succeed, slow ones queue
            DB slow query affecting a percentage of requests
  DT:       DB call response time breakdown → one statement type takes 8s
  Fix:      Identify the slow query (DT shows top DB statements by duration)

Pattern 2: All percentiles elevated equally → whole service is slow
  Cause:    CPU throttling (resource limits hit), GC pause, downstream service slow
  DT:       Check CPU usage (Infrastructure → pod), check GC time
  Fix:      Increase CPU limit or fix the GC issue

Pattern 3: Latency spikes then recovers → periodic slowdown
  Cause:    GC pause (JVM stops the world for GC), periodic batch job
  DT:       JVM metrics → GC duration shows periodic spikes matching latency
  Fix:      Tune GC parameters, switch to G1GC or ZGC

Pattern 4: Latency increases after deploy → new code introduced slowness
  DT shows:  "Related change: deployment updated 5 minutes before degradation"
  Cause:     New code has N+1 query, missing index, inefficient algorithm
  Fix:       Rollback → then profile the specific endpoint

Pattern 5: Latency only on specific endpoint → that endpoint has a problem
  DT:       Services → payment-service → Top endpoints by response time
            Filter traces by that endpoint URL → find the slow span
  Fix:      Identify which downstream call (DB, external API) is slow
```

---

## Part 8 — Database Slow Queries

### What Dynatrace Shows

```
Problem title:  "payment-service: Database response time increase"
Metric:         builtin:service.dbcalls.response_time
DT location:    Services → payment-service → Database calls tab
                Technologies → Databases → Top slow statements
```

### How Dynatrace Captures DB Calls

OneAgent instruments JDBC at the bytecode level. Every DB call produces a span with:
```
  SQL statement text (or parameterized form)
  Duration
  Row count returned
  Whether it failed
  Which service called it
```

### Common Slow Query Patterns

```
Pattern 1: Full table scan (missing index)
  DT shows:   One specific SELECT statement: avg 8000ms (others: 50ms)
  Evidence:   High row count returned (millions) with long duration
  Fix:        Add index on the WHERE clause column
              CREATE INDEX CONCURRENTLY idx_orders_user_id ON orders(user_id);

Pattern 2: N+1 query (ORM anti-pattern)
  DT shows:   Thousands of identical SELECT statements in one trace
              e.g., SELECT * FROM products WHERE id=? called 500 times per request
  Evidence:   Trace span count is extremely high, each span is fast but total = slow
  Fix:        Change ORM to eager-load with JOIN, use batch loading

Pattern 3: Lock wait (contention)
  DT shows:   Intermittent slow DB calls at exactly the same time
              Duration spikes: 0ms normally, 5000ms during spikes
  Evidence:   Multiple services writing to same table simultaneously
  Fix:        Add optimistic locking, partition writes, review transaction scope

Pattern 4: Connection pool timeout
  DT shows:   DB call duration = exactly 30000ms (= pool timeout value)
              Many calls failing at the same time
  Evidence:   Pool exhausted — calls are WAITING for a connection, not executing
  Fix:        Increase pool size, find what is holding connections open
```

---

## Part 9 — External/Downstream Service Errors (Cascading Failures)

### What Dynatrace Shows

```
DT Service Map: payment-service → [arrow turns red] → order-service
Problem title:  "payment-service: High failure rate"
               BUT root cause entity shows: order-service
DT location:    Services → payment-service → Outgoing dependencies
                Distributed Traces → spans showing calls to order-service
```

### How to Identify Cascading Failures in DT

```
Step 1: Open the Problem
  → DT usually shows "Root cause: [downstream-service]" automatically
  → Click the root cause service link

Step 2: Service Map
  → Services → payment-service → Service flow / Dependencies
  → Look for red connections between services
  → The SERVICE with red connections TO IT is the root cause

Step 3: Distributed Trace
  → Find a failed trace for payment-service
  → Expand the trace tree
  → Find the red span — which service is it calling?
  → The call depth tells you where the chain breaks

Step 4: Check if downstream is in your control
  → Internal service (order-service): fix it directly
  → External API (payment gateway, SMS provider): check their status page
```

### Common Cascading Failure Patterns

```
Pattern 1: No circuit breaker → one slow service takes down the whole chain
  DT shows:   payment-service slow → payment-service is calling order-service (slow)
              → order-service is calling notification-service (down)
  Fix:        Add circuit breaker (Resilience4j), add timeout on all external calls

Pattern 2: External API rate-limited (HTTP 429)
  DT shows:   Outgoing calls to external URL → HTTP 429 response
  Fix:        Implement retry with backoff, implement rate limiting on client side

Pattern 3: External API SSL expired
  DT shows:   External call failing with SSL error
  Fix:        Contact the external provider, use their backup endpoint if available
```

---

## Part 10 — CPU Saturation (Pod Throttling)

### What Dynatrace Shows

```
Problem title:  "payment-service: CPU saturation"
Metric:         builtin:container.cpu.throttling_time
                builtin:host.cpu.usage
DT location:    Infrastructure → Kubernetes → [cluster] → Workloads
                Technologies → Containers → payment-service
```

### What CPU Throttling Means

```
K8s CPU limits work differently from memory limits:
  Memory limit exceeded → OOMKilled (hard kill)
  CPU limit exceeded → THROTTLED (slowed down, not killed)

When a container is throttled:
  - The JVM keeps running
  - All threads slow down proportionally
  - Request latency increases (often 2–10× normal)
  - No error in logs — just slowness

DT shows:
  builtin:container.cpu.throttling_time = X ms/min
  → High throttling time = service is being slowed down by K8s
  → correlates exactly with latency spikes
```

### Diagnose and Fix

```
DT: Infrastructure → Containers → payment-service → CPU throttling graph
  → Is throttling > 0? If yes, the service is CPU-limited

kubectl:
  kubectl top pods -n payment-ns   (shows actual CPU usage)
  kubectl describe pod payment-service-xxx | grep -A5 "Limits:"
  → Compare current usage vs limit — if usage ≈ limit → throttled

Fix options:
  1. Increase CPU limit in Helm values:
     resources:
       limits:
         cpu: "2"       # was "500m" → increase to "2" (2 vCPU)

  2. Optimize code (find CPU-intensive loops, inefficient regex, etc.)
     → DT Method Hotspots: Services → payment-service → Method hotspots tab
     → Shows which JAVA METHODS are consuming the most CPU time
```

---

## Part 11 — Memory Saturation (Near OOM)

### What Dynatrace Shows

```
Problem title:  "payment-service: Memory saturation"
Metric:         builtin:container.memory.usage
                builtin:jvm.memory.heap (DT JVM monitoring)
DT location:    Technologies → JVM → memory metrics
                Infrastructure → Kubernetes → pod memory
```

### Warning Signs Before OOM

```
Sign 1: Heap sawtooth grows each GC cycle
  Normal:   Heap goes up → GC fires → drops back to same baseline each time
  Warning:  Heap goes up → GC fires → baseline is higher each time → memory leak
  DT:       JVM heap usage graph shows upward trend over hours

Sign 2: GC time increases
  Normal:   GC time < 5% of CPU time
  Warning:  GC time 15–30% → JVM struggling to reclaim enough memory
  Critical: GC time > 50% → GC overhead limit exceeded is coming

Sign 3: Survivor space always full
  DT:       JVM Old Gen usage growing (short-lived objects promoted to old gen)
  Cause:    Memory leak — objects that should die young are surviving GC

Sign 4: Container memory near limit
  DT:       Container memory > 90% of limit
  Risk:     K8s will OOMKill the pod when it hits 100%
  Fix:      Increase memory limit OR investigate heap dump for leaks
```

---

## Part 12 — JVM Garbage Collection Problems

### What Dynatrace Shows

```
DT location:    Technologies → JVM → [process] → Garbage collection tab
Metrics:        builtin:jvm.gc.time
                builtin:jvm.gc.count
                builtin:jvm.memory.heap.committed
```

### GC Problem Patterns

```
Pattern 1: Frequent full GC (stop-the-world pauses)
  DT shows:   GC count very high, long GC durations
              Latency spikes correlate exactly with GC events
  Cause:      Heap too small, GC algorithm not tuned for workload
  Fix:        Increase -Xmx, switch to G1GC (-XX:+UseG1GC)
              or ZGC (-XX:+UseZGC) for low-pause requirements

Pattern 2: GC working but heap still growing
  DT shows:   GC firing frequently (count high) but heap usage stays high
  Cause:      Memory leak — objects are being created faster than GC can collect them
  Fix:        Take a heap dump during high-memory period, analyze with Eclipse MAT
              kubectl exec -it [pod] -- jmap -dump:live,format=b,file=/tmp/heap.hprof 1

Pattern 3: GC pauses causing latency spikes
  DT shows:   Periodic latency spikes on ALL requests simultaneously
              GC pause duration matches the latency spike duration
  Cause:      G1GC pauses or old CMS full GC
  Fix:        Switch to ZGC for Java 15+, tune -XX:MaxGCPauseMillis
```

---

## Quick Reference: DT Error → Probable Cause → First Action

```
┌──────────────────────────────────┬────────────────────────────────┬──────────────────────────────────┐
│ DT Problem / Metric              │ Most Probable Cause            │ First Action                     │
├──────────────────────────────────┼────────────────────────────────┼──────────────────────────────────┤
│ High failure rate (5xx)          │ Bad deploy / NPE / DB failure  │ Check "related deployment" → rollback│
│ DB query failure rate            │ Connection pool / query bug    │ Check DB connection pool metrics │
│ Exception count increase         │ NPE / input validation         │ Distributed Traces → exception   │
│ OutOfMemoryError                 │ Memory leak / heap too small   │ Heap dump or increase -Xmx       │
│ Service unavailable              │ CrashLoopBackOff / bad deploy  │ kubectl get pods, kubectl logs   │
│ Synthetic check failed           │ DNS / SSL / app down           │ Check error code in synthetic run│
│ Response time degradation        │ DB slow query / CPU throttle   │ DT DB call breakdown + CPU chart │
│ DB slow queries                  │ Missing index / N+1 / lock     │ Top DB statements by duration    │
│ Downstream error                 │ Cascading failure              │ Service map → find root cause    │
│ CPU saturation                   │ Hitting CPU limit              │ Increase limit OR method hotspot │
│ Memory saturation                │ Memory leak / limit too low    │ Heap sawtooth trend in JVM view  │
│ GC overhead                      │ Heap too small / memory leak   │ GC metrics + heap dump           │
└──────────────────────────────────┴────────────────────────────────┴──────────────────────────────────┘
```

---

## SRE Investigation Commands for Each Error Type

```bash
# ── Error Rate spike ──────────────────────────────────────────────────────────
# Check recent pods and events
kubectl get pods -n payment-ns
kubectl describe pod -n payment-ns -l app=payment-service | grep -A 5 Events

# Check what changed recently
git log --oneline -5 -- gitops/production/app/payment-service/

# ── DB connection pool exhaustion ────────────────────────────────────────────
kubectl exec -it $(kubectl get pod -n payment-ns -l app=payment-service -o name | head -1) \
  -n payment-ns -- env | grep -i pool

# ── OOM / Memory pressure ─────────────────────────────────────────────────────
kubectl top pods -n payment-ns
kubectl describe pod -n payment-ns -l app=payment-service | grep -i "oom\|memory\|killed"

# Check last OOM event in logs
kubectl logs -n payment-ns -l app=payment-service --previous | grep -i "OutOfMemory"

# ── CPU throttling ────────────────────────────────────────────────────────────
kubectl top pods -n payment-ns
kubectl describe pod -n payment-ns -l app=payment-service | grep -A 5 "Limits:"

# ── CrashLoopBackOff ──────────────────────────────────────────────────────────
kubectl get pods -n payment-ns
kubectl logs -n payment-ns [pod-name] --previous   # last crash reason
kubectl describe pod -n payment-ns [pod-name] | grep -A 10 "Last State:"

# ── Synthetic check failure investigation ────────────────────────────────────
# Verify DNS resolution
kubectl run -it --rm debug --image=alpine --restart=Never -n payment-ns \
  -- nslookup payment.example.com

# Check certificate expiry
kubectl get certificate -n payment-ns
kubectl describe certificate -n payment-ns [cert-name] | grep -i "expiry\|ready\|condition"

# ── DT API: get open problems ─────────────────────────────────────────────────
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/problems?status=open" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.problems[] | {title, severity, status, startTime}'
```
