# Part 4 — Environment Promotion: Deep Dive

---

## What Environment Promotion Is

Environment promotion is the process of moving a validated artifact through a chain of increasingly production-like environments before it reaches real users.

```
Artifact built: ghcr.io/myorg/checkout:sha-abc123
      │
      ▼
DEV environment
  → Automatic deploy
  → Smoke tests: does it start?
  → If pass: promote
      │
      ▼
STAGING environment
  → Automatic deploy
  → Full E2E tests, performance check
  → If pass: promote (with human approval for prod)
      │
      ▼
PRODUCTION environment
  → Canary: 10% traffic
  → Observe metrics for 10 minutes
  → If healthy: full rollout
  → If bad: automatic rollback
```

**Key rule:** The SAME artifact (same Docker digest) is promoted through environments. You NEVER rebuild for each environment. Rebuilding would mean testing one thing and deploying another.

---

## The Three Environments Explained

### DEV Environment

```
Purpose:     Fastest feedback for developers
Users:       Internal developers only
Data:        Synthetic / seeded test data (reset daily)
Infra:       Minimal — 1 replica, small resource limits
Deploy when: Every green CI build (automatic)
Tests:       Smoke tests only (does it boot? does /health return 200?)
Failure:     Affects nobody except the team → acceptable instability

Kubernetes config for dev:
  replicas: 1
  resources.requests.cpu: 100m
  resources.requests.memory: 256Mi
  resources.limits.cpu: 500m
  resources.limits.memory: 512Mi
```

**Why DEV is separate from your laptop:**
- Your laptop has local config, different OS, different Java version
- DEV mimics the Kubernetes deployment environment
- Catches "works on my machine" before staging

### STAGING Environment

```
Purpose:     Production mirror — final validation gate
Users:       QA team, product managers, manual testing
Data:        Anonymized copy of production data OR production-like synthetic data
Infra:       Same spec as production (important! different specs hide issues)
Deploy when: Automatic after DEV passes
Tests:       Full E2E, performance regression, security scan
Failure:     Affects internal users only → low risk

Kubernetes config for staging:
  replicas: 3           (same pattern as prod, different count)
  resources:            (same spec as prod)
  ingress: staging.checkout.internal
  env: PAYMENT_GATEWAY_URL=https://sandbox.stripe.com   (sandbox, not real)
```

**Staging must mirror production:**
```
If staging has 1 replica but prod has 10:
  Load balancing bugs (session affinity) won't appear in staging
  Resource pressure at scale won't appear in staging
  
If staging uses different database version:
  SQL behavior differences won't be caught

The more staging differs from prod, the less valuable it is.
```

### PRODUCTION Environment

```
Purpose:     Serves real users, generates revenue
Users:       All customers
Data:        Real user data (GDPR applies!)
Infra:       Full scale — many replicas, autoscaling
Deploy when: Manual approval (Delivery) OR automatic with canary (Deployment)
Tests:       Smoke tests, canary metric analysis
Failure:     Revenue impact, SLA breach, potential data loss → highest risk

Kubernetes config for production:
  replicas: 10
  autoscaling: HPA (min: 5, max: 30)
  resources.requests.cpu: 500m
  resources.requests.memory: 512Mi
  podDisruptionBudget: minAvailable=8   (keep at least 8 pods up)
  ingress: checkout.mycompany.com
  env: PAYMENT_GATEWAY_URL=https://api.stripe.com   (REAL payments)
```

---

## GitHub Environments: Gating Deployments

GitHub Environments add approval workflows, secret scoping, and deployment history to your pipeline.

### Setting Up Environment Protection Rules

```
GitHub UI: Settings → Environments → New environment

Environment: production
  Protection rules:
    ✓ Required reviewers: [alice, bob]   (one of these must approve)
    ✓ Wait timer: 0 minutes             (0 = immediate; set 5-10 for pause to review)
    ✓ Deployment branches: main only    (prevent deploying feature branches to prod)
  
  Environment secrets:
    PROD_KUBECONFIG: <base64 encoded kubeconfig>
    PROD_DB_PASSWORD: <redacted>
    DATADOG_API_KEY: <redacted>
  
  Environment variables:
    ENVIRONMENT: production
    REPLICA_COUNT: 10
    LOG_LEVEL: warn
```

```yaml
# Workflow uses the environment
jobs:
  deploy-production:
    runs-on: ubuntu-latest
    environment: production           # ← activates protection rules

    # Job PAUSES here until a required reviewer approves in GitHub UI
    # The reviewer sees: what commit, who triggered, workflow details
    # They click Approve or Reject

    steps:
      - name: Deploy
        env:
          # Secrets only available because environment: production
          KUBECONFIG: ${{ secrets.PROD_KUBECONFIG }}
          REPLICA_COUNT: ${{ vars.REPLICA_COUNT }}
        run: |
          helm upgrade --install checkout ./charts \
            --namespace production \
            --set replicaCount=$REPLICA_COUNT \
            --set image.tag=${{ github.sha }}
```

### Environment Deployment History

GitHub automatically tracks every deployment to every environment:
```
checkout-service / production deployments:
  sha-abc123  ← current  deployed by alice, 2026-07-31 10:00
  sha-def456             deployed by bob,   2026-07-30 14:30
  sha-ghi789             deployed by alice, 2026-07-29 11:00
  ...
```

This gives you: who deployed what, when, from which commit.

---

## Promotion Gates: What Must Pass Before Promoting

### Gate 1: DEV → STAGING

```yaml
staging-gate:
  needs: [deploy-dev, smoke-test-dev]
  runs-on: ubuntu-latest
  steps:
    - name: Check smoke test results
      run: |
        # Verify all smoke tests passed
        STATUS="${{ needs.smoke-test-dev.result }}"
        if [ "$STATUS" != "success" ]; then
          echo "DEV smoke tests failed. Not promoting to staging."
          exit 1
        fi

    - name: Check no open P0 bugs
      run: |
        # Query Jira for P0 bugs against this commit (optional)
        OPEN_BUGS=$(curl -s "https://jira.internal/rest/api/2/search" \
          --header "Authorization: Bearer ${{ secrets.JIRA_TOKEN }}" \
          --data-urlencode "jql=project=CHECKOUT AND priority=P0 AND fixVersion=${{ github.sha }}" \
          | jq '.total')
        if [ "$OPEN_BUGS" -gt 0 ]; then
          echo "Open P0 bugs found — blocking promotion"
          exit 1
        fi
```

### Gate 2: STAGING → PRODUCTION

```yaml
production-gate:
  needs: [deploy-staging, e2e-tests, performance-test]
  runs-on: ubuntu-latest
  environment: pre-production-check   # separate environment for gate review
  steps:
    - name: Verify E2E test results
      run: |
        E2E_RESULT="${{ needs.e2e-tests.result }}"
        PERF_RESULT="${{ needs.performance-test.result }}"
        
        if [ "$E2E_RESULT" != "success" ]; then
          echo "E2E tests failed in staging. Cannot promote to production."
          exit 1
        fi
        if [ "$PERF_RESULT" != "success" ]; then
          echo "Performance regression detected. Cannot promote to production."
          exit 1
        fi

    - name: Check error rate in staging
      run: |
        # Query Prometheus for staging error rate over last 30 minutes
        STAGING_ERROR_RATE=$(curl -s "http://prometheus:9090/api/v1/query" \
          --data-urlencode 'query=
            sum(rate(http_requests_total{env="staging",status=~"5.."}[30m]))
            /
            sum(rate(http_requests_total{env="staging"}[30m]))
          ' | jq -r '.data.result[0].value[1]')
        
        if python3 -c "exit(0 if float('$STAGING_ERROR_RATE') < 0.01 else 1)"; then
          echo "Staging error rate OK: $STAGING_ERROR_RATE"
        else
          echo "Staging error rate too high: $STAGING_ERROR_RATE"
          exit 1
        fi
```

---

## Environment-Specific Configuration Management

The SAME artifact runs in DEV, STAGING, and PROD. The ONLY difference is configuration (which DB to connect to, which API URLs, which log level, etc.).

### Configuration Hierarchy

```
Priority (highest first):
  1. Kubernetes Secret (passwords, API keys)
  2. Kubernetes ConfigMap (non-secret env-specific config)
  3. Helm values.yaml per environment
  4. Application default properties (lowest, in the JAR)
```

### Kustomize-Based Environment Config

```yaml
# base/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: checkout-config
data:
  LOG_LEVEL: "info"
  MAX_CONNECTIONS: "10"
  PAYMENT_GATEWAY: "https://api.payment.com"
```

```yaml
# overlays/dev/patch-config.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: checkout-config
data:
  LOG_LEVEL: "debug"            # verbose in dev
  MAX_CONNECTIONS: "2"          # low in dev (small footprint)
  PAYMENT_GATEWAY: "https://sandbox.payment.com"  # sandbox in dev
```

```yaml
# overlays/production/patch-config.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: checkout-config
data:
  LOG_LEVEL: "warn"             # minimal logging in prod
  MAX_CONNECTIONS: "50"         # high in prod
  PAYMENT_GATEWAY: "https://api.payment.com"  # real gateway in prod
```

### Preventing Config Drift Between Environments

The most dangerous production incidents often come from "this config works in staging but is wrong in prod."

```bash
# Detect config differences between staging and production
diff \
  <(kubectl get configmap checkout-config -n staging -o json | jq '.data') \
  <(kubectl get configmap checkout-config -n production -o json | jq '.data')

# Or better: validate all environment configs against a schema
cat > config-schema.json << 'EOF'
{
  "required": ["LOG_LEVEL", "MAX_CONNECTIONS", "PAYMENT_GATEWAY"],
  "properties": {
    "LOG_LEVEL": { "enum": ["debug", "info", "warn", "error"] },
    "MAX_CONNECTIONS": { "type": "string", "pattern": "^[0-9]+$" }
  }
}
EOF

# Check each environment config validates against the schema
for env in dev staging production; do
  kubectl get configmap checkout-config -n $env -o json | \
    jq '.data' | \
    python3 -c "import sys, json, jsonschema; \
      data = json.load(sys.stdin); \
      schema = json.load(open('config-schema.json')); \
      jsonschema.validate(data, schema); \
      print(f'$env: VALID')"
done
```

---

## Blue/Green Environment Promotion (Advanced)

Instead of in-place canary, use environment-level blue/green where entire environments swap:

```
BLUE stack:   checkout-v1 in production-blue namespace
GREEN stack:  checkout-v2 in production-green namespace

Load balancer: currently pointing to production-blue

Test green fully internally → switch LB → green becomes production
```

```yaml
# In CI: test green, then switch
- name: Deploy to green
  run: |
    helm upgrade --install checkout ./charts \
      --namespace production-green \
      --set image.tag=${{ github.sha }}

- name: Smoke test green
  run: |
    curl -f https://checkout-green.internal/health

- name: Run green-specific tests
  run: |
    API_URL=https://checkout-green.internal \
      mvn test -Psmoke-tests --batch-mode

- name: Switch traffic to green
  run: |
    # Update Kubernetes Service or Istio VirtualService
    kubectl patch service checkout-external \
      -n production \
      -p '{"spec":{"selector":{"stack":"green"}}}'

- name: Verify production after switch
  run: |
    sleep 30    # wait for connection drain
    # Check error rate in Datadog/Prometheus
    ERROR_RATE=$(./scripts/check-error-rate.sh production 5m)
    if [ "$ERROR_RATE" > "0.01" ]; then
      echo "Switching back to blue"
      kubectl patch service checkout-external \
        -n production \
        -p '{"spec":{"selector":{"stack":"blue"}}}'
      exit 1
    fi

- name: Cleanup blue after successful switch
  run: |
    # Keep blue running for 1 hour as fallback
    sleep 3600
    helm uninstall checkout -n production-blue
```

---

## Database Migrations in Environment Promotion

Database changes are the hardest part of promoting across environments. A migration that runs on staging and then on production MUST be backward compatible during the rollout window.

### The Expand-Contract Pattern

```
Problem:
  Database has column "user_name"
  New code uses column "username" (renamed)
  
  Rolling deploy = v1 and v2 run simultaneously
  v1 reads "user_name" → v2 renamed it → v1 breaks
  
  Naive approach: rename column in migration before deploy
  Result: v1 code running during rollout fails with "column not found"
```

```
Expand-Contract Solution:

PHASE 1 — EXPAND (deploy with this migration first):
  Add new column "username"
  Application writes to BOTH "user_name" AND "username"
  Application reads from "username" with fallback to "user_name"
  Deploy this version everywhere

PHASE 2 — CONTRACT (next release, after phase 1 is fully deployed):
  Migrate any remaining "user_name"-only data to "username"
  Drop old column "user_name"
  Application now only reads/writes "username"
  Deploy this version everywhere
```

```yaml
# Migration job runs BEFORE deployment
jobs:
  run-migration:
    runs-on: ubuntu-latest
    environment: production
    steps:
      - name: Run migration
        run: |
          # Use Flyway or Liquibase
          flyway \
            -url=${{ secrets.PROD_DB_URL }} \
            -user=${{ secrets.PROD_DB_USER }} \
            -password=${{ secrets.PROD_DB_PASSWORD }} \
            migrate
      
      - name: Verify migration
        run: |
          # Check migration table shows expected version
          psql ${{ secrets.PROD_DB_URL }} \
            -c "SELECT version, success FROM flyway_schema_history ORDER BY installed_on DESC LIMIT 5;"

  deploy:
    needs: run-migration    # deploy AFTER migration succeeds
    ...
```
