# Part 7 — Pipeline Notifications and Observability: Deep Dive

---

## Why Pipeline Observability Matters

Most teams can tell you their application's p99 latency. Almost none can tell you:
- What % of their CI builds succeed?
- What is the average deploy duration?
- Which microservice has the highest deploy failure rate?
- How long does it take from commit to production? (lead time)

Without measuring the pipeline, you manage it by intuition. When a pipeline is slow, you don't know WHERE the time goes. When builds start failing more, you don't know when the trend started.

```
Pipeline observability answers:
  "Our p95 build time was 8 min last month — it's now 15 min"
  → Docker cache hit rate dropped (investigate caching)
  
  "Checkout-service has 40% deploy failure rate this week"
  → Flaky integration test or environment issue
  
  "Lead time for this quarter: avg 4.2 hours"
  → Code review wait is 3.8 hours of that — automate approvals for low-risk changes
```

---

## Slack Notifications: Right Information at the Right Time

### The Problem With Too Much Notification

```
Over-notified channel:
  10:00 — ✅ Checkout service CI passed
  10:01 — ✅ Payment service CI passed
  10:02 — ✅ Auth service CI passed
  10:03 — ✅ Checkout deploy to dev passed
  10:04 — ✅ Payment deploy to dev passed
  ...150 messages per day...

Result: Engineers stop reading #deploys channel
        The one ❌ message is lost in the noise
        Alert fatigue for the delivery pipeline
```

### Right Strategy: Notify on State CHANGE, Not Every Event

```
Notify when:
  ✓ Build FAILS on main branch        (was passing, now failing)
  ✓ Build recovers from failure       (was failing, now passing — team can relax)
  ✓ Deploy to production succeeds     (milestone worth knowing)
  ✓ Deploy to production fails        (urgent — rollback may be needed)
  ✓ Automated rollback triggered      (very urgent — oncall should know)
  ✗ Every build pass on PR branches   (noise — developers see this on their PR)
  ✗ Every dev/staging deploy          (too frequent, low signal)
```

### Slack Notification Implementation

```yaml
# At end of every workflow:
- name: Notify Slack on failure
  if: failure() && github.ref == 'refs/heads/main'
  uses: slackapi/slack-github-action@v1.26.0
  with:
    channel-id: 'C1234567890'   # use channel ID, not name (stable if renamed)
    payload: |
      {
        "attachments": [{
          "color": "#FF0000",
          "blocks": [
            {
              "type": "section",
              "text": {
                "type": "mrkdwn",
                "text": "❌ *Build Failed*: `${{ github.repository }}`"
              }
            },
            {
              "type": "section",
              "fields": [
                {"type": "mrkdwn", "text": "*Branch:*\n`${{ github.ref_name }}`"},
                {"type": "mrkdwn", "text": "*Commit:*\n`${{ github.sha }}`"},
                {"type": "mrkdwn", "text": "*Triggered by:*\n${{ github.actor }}"},
                {"type": "mrkdwn", "text": "*Failed step:*\nSee run for details"}
              ]
            },
            {
              "type": "actions",
              "elements": [{
                "type": "button",
                "text": {"type": "plain_text", "text": "View Run"},
                "url": "${{ github.server_url }}/${{ github.repository }}/actions/runs/${{ github.run_id }}"
              }]
            }
          ]
        }]
      }
  env:
    SLACK_BOT_TOKEN: ${{ secrets.SLACK_BOT_TOKEN }}

- name: Notify Slack on production deploy success
  if: success() && github.ref == 'refs/heads/main'
  uses: slackapi/slack-github-action@v1.26.0
  with:
    channel-id: 'C1234567890'
    payload: |
      {
        "text": "✅ *${{ github.repository }}* deployed to production",
        "attachments": [{
          "color": "#36A64F",
          "fields": [
            {"title": "Version", "value": "`${{ github.sha }}`", "short": true},
            {"title": "Deployed by", "value": "${{ github.actor }}", "short": true},
            {"title": "Commit", "value": "${{ github.event.head_commit.message }}", "short": false}
          ]
        }]
      }
  env:
    SLACK_BOT_TOKEN: ${{ secrets.SLACK_BOT_TOKEN }}
```

### Build Status Badge in README

```markdown
<!-- README.md -->
![CI Status](https://github.com/myorg/checkout/actions/workflows/ci.yml/badge.svg?branch=main)
![Latest Deploy](https://img.shields.io/github/deployments/myorg/checkout/production?label=production)
```

---

## Pipeline Metrics Collection

Push pipeline metrics to Prometheus for dashboards and alerting.

### Pushgateway Pattern for CI Jobs

```yaml
- name: Record pipeline metrics
  if: always()                    # record even on failure
  run: |
    # Calculate duration
    WORKFLOW_START="${{ github.event.head_commit.timestamp }}"
    NOW_EPOCH=$(date +%s)
    START_EPOCH=$(date -d "$WORKFLOW_START" +%s 2>/dev/null || date -jf '%Y-%m-%dT%H:%M:%SZ' "$WORKFLOW_START" +%s)
    DURATION=$((NOW_EPOCH - START_EPOCH))
    
    # Map job result to numeric (1=success, 0=failure)
    RESULT=$([ "${{ job.status }}" = "success" ] && echo 1 || echo 0)
    
    # Push metrics to Prometheus Pushgateway
    cat <<METRICS | curl --silent --data-binary @- \
      http://pushgateway.monitoring.svc:9091/metrics/job/cicd/workflow/${{ github.workflow }}/branch/${{ github.ref_name }}
    # HELP cicd_pipeline_duration_seconds Total CI/CD pipeline duration
    # TYPE cicd_pipeline_duration_seconds gauge
    cicd_pipeline_duration_seconds{
      repo="${{ github.repository }}",
      workflow="${{ github.workflow }}",
      branch="${{ github.ref_name }}",
      conclusion="${{ job.status }}"
    } ${DURATION}

    # HELP cicd_pipeline_success Whether pipeline succeeded
    # TYPE cicd_pipeline_success gauge
    cicd_pipeline_success{
      repo="${{ github.repository }}",
      workflow="${{ github.workflow }}"
    } ${RESULT}

    # HELP cicd_deploy_timestamp Unix timestamp of last deploy
    # TYPE cicd_deploy_timestamp gauge
    cicd_deploy_timestamp{
      repo="${{ github.repository }}",
      environment="production"
    } ${NOW_EPOCH}
    METRICS
```

### Per-Job Timing

```yaml
- name: Record start time
  id: start
  run: echo "time=$(date +%s)" >> $GITHUB_OUTPUT

# ... actual job steps ...

- name: Record job timing
  if: always()
  run: |
    END=$(date +%s)
    START=${{ steps.start.outputs.time }}
    DURATION=$((END - START))
    JOB_STATUS="${{ job.status }}"
    
    # Push to Pushgateway
    echo "cicd_job_duration_seconds{job=\"${{ github.job }}\",status=\"$JOB_STATUS\"} $DURATION" | \
      curl --silent --data-binary @- \
      http://pushgateway.monitoring.svc:9091/metrics/job/cicd_jobs
```

---

## Prometheus Rules for Pipeline Alerting

```yaml
# prometheus-pipeline-rules.yaml
groups:
  - name: cicd-pipeline
    rules:
      # Alert: main branch build has been failing for > 30 minutes
      - alert: MainBranchBuildFailing
        expr: |
          cicd_pipeline_success{
            branch="main",
            workflow="ci-cd"
          } == 0
        for: 30m
        labels:
          severity: warning
          team: platform
        annotations:
          summary: "Main branch build failing for 30+ minutes"
          description: "{{ $labels.repo }} main branch CI has been failing since last success"
          runbook_url: "https://wiki/runbooks/broken-main-branch"

      # Alert: no successful production deploy in 7 days (unexpected quiet)
      - alert: NoRecentProductionDeploy
        expr: |
          (time() - cicd_deploy_timestamp{environment="production"}) > 604800
        labels:
          severity: info
          team: platform
        annotations:
          summary: "No production deploy in 7 days"
          description: "{{ $labels.repo }} hasn't been deployed to production in over 7 days"

      # Alert: pipeline duration has doubled vs 7-day average
      - alert: PipelineSlowdown
        expr: |
          cicd_pipeline_duration_seconds{workflow="ci-cd"}
          >
          2 * avg_over_time(cicd_pipeline_duration_seconds{workflow="ci-cd"}[7d])
        for: 3
        labels:
          severity: warning
        annotations:
          summary: "CI pipeline 2x slower than usual"
          description: "Pipeline taking {{ $value }}s vs 7d avg"
```

---

## Grafana Dashboard for Pipeline

```json
// Dashboard panels:

// Panel 1: Build Success Rate (7-day rolling)
{
  "title": "Build Success Rate (7d)",
  "type": "stat",
  "query": "avg_over_time(cicd_pipeline_success{branch='main'}[7d]) * 100",
  "thresholds": [
    {"value": 90, "color": "green"},
    {"value": 80, "color": "yellow"},
    {"value": 0,  "color": "red"}
  ],
  "unit": "percent"
}

// Panel 2: P95 Build Duration trend
{
  "title": "P95 Build Duration (last 30 days)",
  "type": "timeseries",
  "query": "histogram_quantile(0.95, rate(cicd_pipeline_duration_seconds_bucket[1h]))",
  "unit": "s",
  "alert": {
    "threshold": 600,  // 10 minutes
    "message": "P95 build time exceeds 10 minute SLO"
  }
}

// Panel 3: Deployments per Day
{
  "title": "Production Deployments per Day",
  "type": "bar",
  "query": "count_over_time(cicd_deploy_timestamp{environment='production'}[1d])"
}

// Panel 4: DORA Lead Time
{
  "title": "Lead Time (commit to production, hours)",
  "type": "stat",
  "query": "histogram_quantile(0.50, cicd_lead_time_hours_bucket)"
}
```

---

## Deployment Audit Trail

Every production deployment must be traceable: who deployed what, when, from which commit, with what test results.

### GitHub Deployment API

GitHub Actions automatically creates deployment records when you use `environment:`:
```
https://github.com/myorg/checkout/deployments

Shows:
  2026-07-31 10:00  production  active    sha-abc123  deployed by alice
  2026-07-30 14:30  production  inactive  sha-def456  deployed by bob
  2026-07-29 11:00  production  inactive  sha-ghi789  deployed by alice
```

### Custom Audit Log

```yaml
- name: Write to audit log
  run: |
    # Write deployment record to centralized audit system
    curl -X POST https://audit.internal/api/events \
      -H "Authorization: Bearer ${{ secrets.AUDIT_TOKEN }}" \
      -H "Content-Type: application/json" \
      -d '{
        "event_type": "deployment",
        "timestamp": "'$(date -u +%Y-%m-%dT%H:%M:%SZ)'",
        "service": "${{ github.repository }}",
        "environment": "production",
        "version": "${{ github.sha }}",
        "deployed_by": "${{ github.actor }}",
        "pipeline_run": "${{ github.run_id }}",
        "commit_message": "${{ github.event.head_commit.message }}",
        "pr_number": "${{ github.event.pull_request.number }}",
        "approver": "${{ github.event.deployment.actor.login }}"
      }'
```

---

## Pipeline Debug Mode

When a pipeline fails and you can't reproduce it locally:

```yaml
- name: Enable debug logging
  run: |
    # Outputs ALL commands and their output
    echo "ACTIONS_STEP_DEBUG=true" >> $GITHUB_ENV
    echo "ACTIONS_RUNNER_DEBUG=true" >> $GITHUB_ENV

# OR: trigger debug mode manually
# Create a repository secret: ACTIONS_STEP_DEBUG = true
# Then re-run the failed job
```

```yaml
# Keep the runner alive for SSH debugging (tmate)
- name: Setup tmate session for debugging
  if: ${{ failure() && runner.debug == '1' }}
  uses: mxschmitt/action-tmate@v3
  with:
    limit-access-to-actor: true   # only the workflow actor can SSH in
    timeout-minutes: 30           # auto-close after 30 min
```

When this step runs, the pipeline pauses and prints an SSH command. You can SSH into the exact runner environment and interactively debug.
