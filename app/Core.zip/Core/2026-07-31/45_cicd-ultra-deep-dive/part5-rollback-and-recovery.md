# Part 5 — Rollback and Recovery: Deep Dive

---

## Why Rollback Is the Most Important SRE Skill in Deployments

The goal of a deployment is to ship new value. The goal of a ROLLBACK STRATEGY is to ensure that when a deployment goes wrong, you can return to a known-good state fast enough to minimize user impact.

```
Incident timeline without fast rollback:
  10:00 — Deploy v2 starts
  10:08 — Deploy finishes (rolling update complete)
  10:10 — First alert: error rate 5%
  10:12 — Oncall investigates: it's the new deploy
  10:15 — Decision: roll back
  10:18 — Manual helm rollback initiated
  10:28 — Rollback rolling update completes
  10:30 — System restored
  
  Total downtime: 22 minutes
  MTTR: 22 minutes

Incident timeline WITH automated rollback:
  10:00 — Deploy v2 starts with post-deploy verification
  10:08 — Deploy finishes
  10:13 — Health check gate detects error rate > 1%
  10:13 — Automated helm rollback initiated
  10:15 — Rollback rolling update completes
  10:15 — System restored
  
  Total downtime: 7 minutes
  MTTR: 7 minutes
  Oncall never even paged (within error budget)
```

---

## The Rollback Decision Tree

```
Deployment completes
      │
      ▼
Post-deploy health check (5-15 minutes)
      │
      ├── PASS: error rate OK, latency OK, pods healthy
      │         → Mark deployment SUCCESS, continue
      │
      └── FAIL: one of the following:
            │
            ├── Smoke test fails (HTTP non-200)
            │         → Rollback immediately, no delay
            │
            ├── Error rate > threshold (1% for critical, 5% for non-critical)
            │         → Rollback immediately
            │
            ├── P99 latency > threshold (2x baseline)
            │         → Rollback immediately
            │
            ├── Pods CrashLooping (OOMKilled, startup failure)
            │         → Rollback immediately
            │
            └── Slow degradation (15-30 min post-deploy):
                      → Investigate first: is it the deploy or something else?
                      → Check: "did error rate increase IMMEDIATELY after deploy?"
                      → Yes: rollback
                      → No: may not be deploy-related, investigate further
```

---

## Rollback Methods: Complete Reference

### Method 1: Helm Rollback (Most Common)

```bash
# List rollout history
helm history checkout -n production
# REVISION  UPDATED       STATUS    CHART          APP VERSION  DESCRIPTION
# 1         2026-07-30    deployed  checkout-1.2.0  sha-abc123  Install complete
# 2         2026-07-31    failed    checkout-1.3.0  sha-def456  Upgrade "checkout" failed
# 3         2026-07-31    deployed  checkout-1.3.1  sha-ghi789  Upgrade complete

# Rollback to immediately previous revision
helm rollback checkout -n production

# Rollback to specific revision
helm rollback checkout 1 -n production

# Rollback and wait for all pods to be healthy
helm rollback checkout -n production \
  --wait \
  --timeout=10m \
  --cleanup-on-fail   # remove new pods that failed to start

# Verify rollback completed
helm status checkout -n production
kubectl rollout status deployment/checkout -n production
```

**What `helm rollback` does internally:**
```
Stores: Helm stores each release revision as a Kubernetes Secret
        (not in a database — it's all in Kubernetes)

Rollback:
  1. Reads the target revision's manifest from the Secret
  2. Applies those manifests to Kubernetes
  3. Kubernetes performs a rolling update back to the old version
  4. Helm waits for all pods to be healthy (if --wait)
  5. Marks the new revision as deployed
```

### Method 2: Kubectl Rollout Undo (Kubernetes-Native)

```bash
# List rollout history
kubectl rollout history deployment/checkout -n production
# REVISION  CHANGE-CAUSE
# 1         sha-abc123 deployed by alice
# 2         sha-def456 deployed by bob
# 3         sha-ghi789 deployed by charlie

# Undo to previous version
kubectl rollout undo deployment/checkout -n production

# Undo to specific revision
kubectl rollout undo deployment/checkout -n production --to-revision=1

# Watch the rollback progress
kubectl rollout status deployment/checkout -n production

# Annotate deployments with change cause (for the history)
kubectl annotate deployment checkout kubernetes.io/change-cause="sha-ghi789 deployed by charlie"
```

**Kubernetes revision storage:**
Kubernetes stores the last `revisionHistoryLimit` ReplicaSets (default: 10). Rollout undo works by scaling the old ReplicaSet back up and the new one down — much faster than a full re-deploy.

```yaml
# Increase history for more rollback options
spec:
  revisionHistoryLimit: 10    # keep last 10 versions (default)
```

### Method 3: ArgoCD Rollback (GitOps)

In GitOps, "rollback" = revert the Git commit that changed the image tag.

```bash
# Option A: ArgoCD-specific rollback (to a previous sync)
argocd app history checkout-production
# ID  DATE                           REVISION
# 1   2026-07-30 10:00:00 +0000 UTC  main (abc123)
# 2   2026-07-31 09:00:00 +0000 UTC  main (def456)
# 3   2026-07-31 10:30:00 +0000 UTC  main (ghi789)

argocd app rollback checkout-production 2
# Rolls back to the state when sync #2 ran

# Option B: Git revert (preferred — creates audit trail)
cd k8s-configs
git log --oneline apps/checkout/overlays/production/kustomization.yaml
# abc123 chore: deploy sha-ghi789
# def456 chore: deploy sha-def456
# ghi789 chore: deploy sha-abc123 (original good version)

git revert abc123 --no-edit
# Creates new commit: "Revert 'chore: deploy sha-ghi789'"
git push
# ArgoCD detects the new commit and syncs automatically
```

**Why Git revert is preferred over ArgoCD rollback:**
```
ArgoCD rollback: bypasses Git — the config repo still shows new version
                 Next sync would re-apply the bad version!
                 Breaks the "Git is truth" principle

Git revert:      creates a new commit in Git
                 Git history shows exactly what happened and when
                 ArgoCD syncs naturally from the reverted commit
                 No risk of re-applying bad version on next sync
```

### Method 4: Feature Flag Toggle (Fastest Rollback)

If the breaking change is behind a feature flag:

```bash
# Rollback without any deployment
curl -X PATCH https://launchdarkly.com/api/v2/flags/default/new-checkout-flow \
  -H "Authorization: $LD_API_KEY" \
  -H "Content-Type: application/json; domain-model=launchdarkly.semanticpatch" \
  -d '{
    "environmentKey": "production",
    "instructions": [{"kind": "turnFlagOff"}]
  }'

# Feature goes from on to off for 100% of users in < 1 second
# No deploy required
# No rolling update — change is instantaneous
```

This is the fastest possible rollback. The code is still in production, but users stop hitting the new code path.

---

## Automated Rollback in Pipelines

### Method 1: Post-Deploy Verification Script

```yaml
- name: Deploy
  id: deploy
  run: |
    helm upgrade --install checkout ./charts \
      --namespace production \
      --set image.tag=${{ github.sha }} \
      --wait --timeout=10m

- name: Post-deploy verification
  id: verify
  run: |
    set +e   # don't fail immediately on error — we want to rollback properly
    
    DEPLOYMENT_SUCCESS=true
    
    # Check 1: Pod health
    echo "=== Checking pod health ==="
    if ! kubectl rollout status deployment/checkout -n production --timeout=2m; then
      echo "FAIL: Pods not healthy"
      DEPLOYMENT_SUCCESS=false
    fi
    
    # Check 2: Smoke test (retry 5 times, 10 second intervals)
    echo "=== Running smoke test ==="
    for i in {1..5}; do
      STATUS=$(curl -s -o /dev/null -w "%{http_code}" \
        --max-time 10 \
        https://checkout.prod.internal/health)
      if [ "$STATUS" = "200" ]; then
        echo "Smoke test passed (attempt $i)"
        break
      fi
      if [ $i -eq 5 ]; then
        echo "FAIL: Smoke test failed after 5 attempts (last status: $STATUS)"
        DEPLOYMENT_SUCCESS=false
      fi
      sleep 10
    done
    
    # Check 3: Error rate (2 minutes post-deploy)
    echo "=== Waiting 2 minutes to measure error rate ==="
    sleep 120
    
    ERROR_RATE=$(curl -s "http://prometheus:9090/api/v1/query" \
      --data-urlencode 'query=
        sum(rate(http_requests_total{service="checkout",status=~"5.."}[2m]))
        /
        sum(rate(http_requests_total{service="checkout"}[2m]))
      ' | jq -r '.data.result[0].value[1] // "0"')
    
    if python3 -c "exit(0 if float('$ERROR_RATE') < 0.01 else 1)"; then
      echo "Error rate OK: $(printf '%.2f%%' $(python3 -c "print($ERROR_RATE * 100)"))"
    else
      echo "FAIL: Error rate too high: $(printf '%.2f%%' $(python3 -c "print($ERROR_RATE * 100)"))"
      DEPLOYMENT_SUCCESS=false
    fi
    
    # Rollback if any check failed
    if [ "$DEPLOYMENT_SUCCESS" = "false" ]; then
      echo "=== DEPLOYMENT FAILED — ROLLING BACK ==="
      
      # Get previous revision
      PREVIOUS_REVISION=$(helm history checkout -n production | \
        grep -v "failed\|pending" | tail -2 | head -1 | awk '{print $1}')
      
      helm rollback checkout $PREVIOUS_REVISION -n production \
        --wait --timeout=10m
      
      echo "Rollback complete to revision $PREVIOUS_REVISION"
      
      # Notify Slack
      curl -X POST ${{ secrets.SLACK_WEBHOOK }} \
        -H "Content-Type: application/json" \
        -d "{
          \"text\": \"🚨 AUTOMATED ROLLBACK: checkout-service in production.\\n*Reason:* Post-deploy verification failed\\n*Commit:* ${{ github.sha }}\\n*Rolled back to:* revision $PREVIOUS_REVISION\"
        }"
      
      exit 1   # fail the pipeline so PR/commit shows red
    fi
    
    echo "=== DEPLOYMENT VERIFIED SUCCESSFULLY ==="

- name: Notify success
  if: success()
  run: |
    curl -X POST ${{ secrets.SLACK_WEBHOOK }} \
      -H "Content-Type: application/json" \
      -d "{\"text\": \"✅ checkout-service deployed and verified: ${{ github.sha }}\"}"
```

### Method 2: Argo Rollouts Automatic Rollback

```yaml
# The Rollout resource handles promotion and rollback automatically
apiVersion: argoproj.io/v1alpha1
kind: Rollout
spec:
  strategy:
    canary:
      analysis:
        templates:
          - templateName: success-rate
        args:
          - name: service: checkout
        startingStep: 1

      steps:
        - setWeight: 20
        - pause: {duration: 5m}
        - setWeight: 60
        - pause: {duration: 5m}
        - setWeight: 100

# If AnalysisRun shows failure at ANY step:
# → Argo Rollouts automatically sets weight back to 0
# → Terminates new ReplicaSet
# → Marks rollout as Degraded
# → Sends notification via its notification system
```

```yaml
# Notification when rollback happens
apiVersion: v1
kind: ConfigMap
metadata:
  name: argo-rollouts-notification-configmap
data:
  trigger.on-rollback: |
    - send: [slack-rollback]
    when: rollout.status.phase == 'Degraded'
  
  template.slack-rollback: |
    message: |
      🚨 Rollback triggered for {{.rollout.metadata.name}}
      Reason: Analysis failed
      Stable revision: {{.rollout.status.stableRS}}
  
  service.slack: |
    token: $slack-token
    channel: '#deploys'
```

---

## Rollback Testing: Practice Your Rollbacks

Most teams only discover rollback problems during an actual incident. Practice rollbacks in staging regularly.

```yaml
# .github/workflows/rollback-drill.yml
# Run weekly to verify rollback works
on:
  schedule:
    - cron: '0 10 * * 3'    # every Wednesday 10am

jobs:
  rollback-drill:
    runs-on: ubuntu-latest
    environment: staging
    steps:
      - name: Deploy known-good version
        run: |
          helm upgrade --install checkout ./charts \
            --namespace staging \
            --set image.tag=sha-knownGood123 \
            --wait

      - name: Record current revision
        run: |
          GOOD_REV=$(helm history checkout -n staging | grep deployed | tail -1 | awk '{print $1}')
          echo "GOOD_REVISION=$GOOD_REV" >> $GITHUB_ENV

      - name: Deploy a "bad" version
        run: |
          helm upgrade checkout ./charts \
            --namespace staging \
            --set image.tag=sha-badVersion456 \
            --set env.FORCE_ERROR_RATE=0.5 \   # force 50% errors
            --wait

      - name: Measure bad error rate
        run: |
          sleep 60
          ERROR_RATE=$(./scripts/measure-error-rate.sh staging 1m)
          echo "Error rate after bad deploy: $ERROR_RATE"

      - name: Execute rollback
        run: |
          START_TIME=$(date +%s)
          helm rollback checkout ${{ env.GOOD_REVISION }} \
            -n staging --wait --timeout=5m
          END_TIME=$(date +%s)
          ROLLBACK_DURATION=$((END_TIME - START_TIME))
          echo "Rollback took ${ROLLBACK_DURATION} seconds"
          
          # Assert rollback was fast enough
          if [ $ROLLBACK_DURATION -gt 300 ]; then
            echo "DRILL FAILED: Rollback took too long (${ROLLBACK_DURATION}s > 300s SLO)"
            exit 1
          fi

      - name: Verify recovery
        run: |
          sleep 60
          ERROR_RATE=$(./scripts/measure-error-rate.sh staging 1m)
          if python3 -c "exit(0 if float('$ERROR_RATE') < 0.01 else 1)"; then
            echo "DRILL PASSED: System recovered, error rate: $ERROR_RATE"
          else
            echo "DRILL FAILED: System not recovered, error rate: $ERROR_RATE"
            exit 1
          fi
```

---

## Post-Incident: Preventing the Same Deploy Problem

After any rollback, the pipeline should block re-deployment of the same bad commit:

```yaml
# After rollback incident: create a block file
- name: Block bad commit from re-deploying
  if: failure()
  run: |
    # Add commit to blocklist in config repo
    echo "${{ github.sha }}" >> deploy-blocklist.txt
    git add deploy-blocklist.txt
    git commit -m "block: ${{ github.sha }} caused production incident"
    git push

# In deploy workflow: check blocklist
- name: Check deploy blocklist
  run: |
    if grep -q "${{ github.sha }}" deploy-blocklist.txt; then
      echo "BLOCKED: commit ${{ github.sha }} is on the deploy blocklist"
      echo "This commit was previously rolled back from production."
      echo "Fix the issue and create a new commit before deploying."
      exit 1
    fi
```
