# CI/CD Ultra Deep Dive Glossary — SRE Beginner Reference

All terms across all 7 parts, explained from first principles.

---

## Part 1 Terms — Triggers and Runners

**Webhook**
A notification sent by GitHub to the CI/CD system when an event happens (push, PR, tag). It's an HTTP POST with event details. The CI system listens for these webhooks and starts pipeline runs in response. Like a doorbell that GitHub rings when code changes.

**`on: push`**
GitHub Actions trigger that fires when code is pushed to any matching branch. Runs in the context of the pushed branch — has full access to repository secrets.

**`on: pull_request`**
GitHub Actions trigger that fires when a PR is opened or updated. Runs in the context of the MERGED result (what the code would look like if the PR were merged). Importantly: limited secret access to prevent forks from stealing secrets.

**`paths:` filter**
A trigger filter that only fires the workflow if specific files were changed. `paths: ['src/**']` means the pipeline only runs when something in `src/` changes — docs-only commits skip CI entirely. Saves compute minutes.

**`paths-ignore:`**
Opposite of `paths:`. List files/patterns that should NEVER trigger the pipeline. Example: `['**.md', '.github/CODEOWNERS']` — documentation changes don't need CI.

**Cron Expression**
A 5-field time specification for scheduled jobs: `minute hour day-of-month month day-of-week`. `0 2 * * *` = 2:00am every day. Used to schedule nightly test runs, weekly security scans, etc.

**Workflow Dispatch**
A manual trigger that allows running a workflow from the GitHub UI or API. Can define input parameters (environment, image tag, etc.) that users fill in before running. Essential for on-demand deploys.

**`workflow_call`**
A trigger that allows a workflow to be called as a subroutine by another workflow. The called workflow defines inputs/secrets it needs; the caller passes them. Enables DRY (Don't Repeat Yourself) pipeline design across many repos.

**Reusable Workflow**
A GitHub Actions workflow designed to be called by other workflows via `workflow_call`. Used to centralize shared pipeline logic (deploy template, security scan template) in one place.

**GitHub-Hosted Runner**
A virtual machine provisioned and managed by GitHub that executes pipeline jobs. Starts fresh for every job. Ubuntu ($0.008/min), Windows ($0.016/min), macOS ($0.08/min). No infrastructure to manage.

**Self-Hosted Runner**
A machine you own and manage that runs the GitHub Actions runner agent. Connects to GitHub to receive and execute jobs. Useful for: private network access, more RAM/CPU, compliance requirements, cost savings at scale.

**Ephemeral Runner**
A self-hosted runner that starts fresh for every job (new container/VM) and is destroyed after the job completes. Prevents state leakage between jobs and improves security. Managed by Actions Runner Controller on Kubernetes.

**Actions Runner Controller (ARC)**
A Kubernetes operator that manages a fleet of self-hosted GitHub Actions runners. Auto-scales runner pods based on queue depth — more queued jobs = more runner pods created.

**`runs-on:`**
The field in a GitHub Actions job that specifies which runner to use. `ubuntu-latest` = GitHub-hosted Linux. `[self-hosted, large-runner]` = self-hosted runner with specific labels.

**Runner Labels**
Tags assigned to self-hosted runners that jobs use to select them. `large-runner` might mean "8 CPU, 32GB RAM." Allows routing specific jobs to specific machine types.

**Concurrent Jobs Limit**
The maximum number of jobs that can run simultaneously. GitHub Free: 20. Team: 60. Enterprise: 180 per org. Exceeding the limit causes jobs to queue. Self-hosted: limited only by number of runner machines.

**`GITHUB_ENV`**
A file on the runner where you can write environment variables that persist across STEPS in the same job. `echo "VAR=value" >> $GITHUB_ENV`. Without this, each `run:` step is a new shell process with no memory of previous steps.

**`GITHUB_OUTPUT`**
A file where a step writes output values that can be referenced by SUBSEQUENT steps in the same job, or by dependent JOBS. `echo "tag=sha-abc" >> $GITHUB_OUTPUT`. Referenced as `${{ steps.step-id.outputs.tag }}`.

---

## Part 2 Terms — Testing Strategy

**Test Pyramid**
A model showing how many of each test type you should have: many unit tests (fast, cheap), fewer integration tests (slower, needs infra), very few E2E tests (slow, expensive). Inverted pyramid = slow, flaky CI.

**Unit Test**
Tests a single class or function in complete isolation using mocks for all dependencies. No network, no database, no filesystem. Should run in milliseconds. Catches logic errors cheaply.

**Mock**
A fake object that substitutes for a real dependency in unit tests. `when(userRepo.findById(1)).thenReturn(user)` makes the test not need a real database. Mockito (Java), Jest mocks (JS), unittest.mock (Python).

**Integration Test**
Tests multiple components working together with real infrastructure (real database, real message queue). Slower than unit tests. Catches interface mismatches and configuration errors that unit tests can't.

**E2E (End-to-End) Test**
Tests the complete system from user-facing interface through all backend services. Slowest and most expensive. Uses real browsers (Selenium, Playwright) or real API clients.

**Service Container (GitHub Actions)**
A Docker container that runs alongside a job to provide infrastructure (database, cache, message queue). GitHub starts it before job steps and stops it after. Automatically has a health check — job waits for healthy before running.

**Test Sharding**
Splitting a large test suite across multiple parallel runners to reduce total wall-clock time. 1000 tests × 100ms each = 100s total. With 4-way sharding = 25 seconds. Each runner executes 25% of the tests.

**`--splits` / `--group` (pytest)**
Pytest-split plugin flags for test sharding. `--splits 4 --group 2` means "split the test suite into 4 equal parts and run part 2." Balances by test duration (not count) using stored timing data.

**Contract Testing**
Testing the "contract" (API shape) between two services. Consumer writes expected request/response. Provider verifies it honors the contract. Catches API breaking changes between services without requiring both to be deployed.

**Pact**
A consumer-driven contract testing framework. Consumer writes a Pact file (expected API interactions). Pact Broker stores contracts. Provider tests verify they honor all consumer contracts. Catches integration bugs at the unit test level.

**Pact Broker**
A central server that stores Pact contract files and verification results. Allows contracts to be shared between consumer and provider teams without direct coordination. Enables "can I deploy" queries.

**Mutation Testing**
A testing technique that makes small "mutations" to your code (flip a `>` to `>=`, change `+` to `-`) and checks if your tests catch the mutation. A test suite that doesn't catch mutations isn't actually verifying behavior.

**PIT (PITest)**
The standard mutation testing tool for Java. Generates hundreds of mutations, runs your test suite against each, and reports what % of mutations were "killed" (caught by a test).

**Mutation Score**
Percentage of code mutations detected by the test suite. `killed mutations / total mutations × 100`. Target: >75-80%. Low mutation score means your tests execute code but don't verify the results.

**k6**
An open-source load testing tool. Scripts written in JavaScript, runs load from the command line or in Kubernetes. Defines "virtual users" (VUs) and duration. Reports p50/p95/p99 latency, error rate, throughput.

**Virtual Users (VUs)**
Simulated concurrent users in a load test. Each VU runs the test script in a loop. `--vus 100` means 100 concurrent fake users hitting your endpoint simultaneously.

**Threshold (k6)**
A pass/fail criterion for a load test. `http_req_duration{p(99)<500}` means the test FAILS if p99 latency exceeds 500ms. Used to create a performance gate in CI.

**Branch Coverage**
A more rigorous form of code coverage that requires BOTH branches of every `if/else` to be exercised by tests. Better than line coverage — verifies the code works for both the true and false path.

---

## Part 3 Terms — Artifact Management

**Artifact (Build)**
The output of a build process — the thing you deploy. Could be: JAR file, Docker image, npm package, Helm chart, Terraform plan file.

**"Build Once, Deploy Many"**
The principle that an artifact should be built a single time and that exact artifact promoted through all environments. Prevents the scenario where rebuilding for production produces a different binary than what was tested.

**Semantic Versioning (SemVer)**
A versioning scheme: `MAJOR.MINOR.PATCH`. Major = breaking change. Minor = new feature, backward compatible. Patch = bug fix, backward compatible. Enables dependency management tools to understand compatibility.

**Conventional Commits**
A commit message format that encodes the type of change: `feat:` (minor bump), `fix:` (patch bump), `feat!:` (major bump). Enables automated versioning tools (Semantic Release) to calculate the next version.

**Semantic Release**
A tool that automatically determines the next version number, generates a changelog, creates a GitHub release, and publishes the artifact — based on Conventional Commit messages since the last release.

**Dependabot**
GitHub's automated dependency update service. Creates PRs that bump outdated dependencies in `pom.xml`, `package.json`, `Dockerfile`, etc. CI runs on the PR to verify the update doesn't break anything.

**Auto-Merge (Dependabot)**
Automatically merging Dependabot PRs that pass CI and update only patch versions of development dependencies. Keeps dependencies fresh without manual review burden for low-risk updates.

**Reproducible Build**
A build where the same source code always produces the same binary output. Eliminates "works in dev but not prod" and allows security verification (rebuild from source and compare hash with deployed artifact).

**Image Digest**
A `sha256:` hash of a Docker image's complete content. Immutable — changing the image changes the hash. Used in production deployments to guarantee exactly which image bytes are deployed.

**Image Tag**
A human-readable label attached to a Docker image. Mutable — the same tag can be pushed with different content. Tags like `latest` should never be used in production deployments.

**Lifecycle Policy (ECR)**
An AWS ECR configuration that automatically deletes old images based on rules (keep last N images, delete untagged images after N days). Prevents storage costs from accumulating indefinitely.

**SBOM (Software Bill of Materials)**
A machine-readable inventory of every software component in an artifact. Enables: "which of our services use log4j 2.14?" instantly. Required by some regulations (US Executive Order on Cybersecurity).

**Artifactory**
A commercial artifact repository manager (by JFrog). Stores Maven JARs, Docker images, npm packages, Helm charts in one place. Provides access control, replication, and lifecycle management.

---

## Part 4 Terms — Environment Promotion

**Environment Promotion**
Moving the SAME artifact through a sequence of environments (dev → staging → production) as it passes more rigorous checks at each stage.

**Synthetic Data**
Fake, generated test data that mimics the structure of real data without containing real user information. Used in dev/staging databases. Allows testing with realistic data volumes without GDPR concerns.

**Anonymized Data**
Real production data with personally identifiable information (PII) replaced with fake values. User "John Smith" becomes "User_4829." Allows realistic staging testing without exposing user data.

**`revisionHistoryLimit`**
A Kubernetes Deployment field that controls how many old ReplicaSets are kept (for rollback). Default: 10. Each old ReplicaSet enables `kubectl rollout undo --to-revision=N`. More history = more rollback options.

**Pod Disruption Budget (PDB)**
A Kubernetes object that limits how many pods of a Deployment can be unavailable simultaneously. `minAvailable: 8` (with 10 replicas) means at most 2 pods can be down at once — prevents deploys or node drains from taking down too many pods.

**Expand-Contract Migration**
A database schema migration pattern for zero-downtime changes. Phase 1 (expand): add new structure alongside old. Both versions of the app work. Phase 2 (contract): remove old structure after all app instances use new.

**Flyway**
A database migration tool for Java. Stores versioned SQL migration scripts (`V1__add_users_table.sql`, `V2__add_email_column.sql`). Tracks which migrations have run in a metadata table. `flyway migrate` runs any new migrations.

**Liquibase**
Similar to Flyway — a database migration tool. Uses XML/YAML/SQL changeset files. More flexible than Flyway but more complex. Can generate migration scripts from database diffs.

**Config Drift**
When environment configurations diverge from what they should be — someone manually changed a ConfigMap, or the config repo wasn't updated for an environment. Can cause "works in staging, fails in production" incidents.

**`jsonschema.validate()`**
Python function that validates a JSON object against a JSON Schema definition. Used in CI to verify all environment configs have the required fields with valid values — catches config drift before deploy.

**Protection Rule (GitHub Environment)**
A safeguard on a GitHub environment that can require: specific reviewer approval, a wait timer before deploy, or deployment only from specific branches. Prevents unauthorized or accidental production deploys.

---

## Part 5 Terms — Rollback and Recovery

**MTTR (Mean Time to Restore)**
The average time from when an incident starts until the service is fully restored. A core DORA metric. Fast pipelines and automated rollback directly reduce MTTR.

**Helm Revision**
A numbered snapshot of a Helm release's state, stored as a Kubernetes Secret. Every `helm upgrade` creates a new revision. `helm rollback 3` re-applies revision 3's exact configuration.

**`helm history`**
Command that lists all revisions of a Helm release with their status (deployed, failed), timestamp, chart version, and app version. Used to select which revision to roll back to.

**`kubectl rollout undo`**
Kubernetes command that reverts a Deployment to the previous ReplicaSet. Works by scaling the old ReplicaSet up and the new one down — faster than a new deployment because the old pods are already pulled.

**`kubectl rollout history`**
Lists the revision history for a Kubernetes Deployment. Shows revision number and change-cause annotation (if set). Used to identify which revision to roll back to.

**`change-cause` annotation**
A Kubernetes annotation (`kubernetes.io/change-cause`) on a Deployment that documents why the deployment happened. Appears in `kubectl rollout history`. Best practice: set to "sha-abc123 deployed by alice via PR #456".

**Automated Rollback**
A pipeline step that automatically runs `helm rollback` if post-deploy health checks fail. Eliminates the delay between "someone notices the deploy is bad" and "rollback is initiated."

**Rollback Drill**
A planned, scheduled practice exercise where the team intentionally deploys a bad version and then executes a rollback, measuring how long it takes. Like a fire drill for deployments. Exposes problems with rollback procedures before a real incident.

**`--cleanup-on-fail` (Helm)**
Flag that removes new resources created during a failed Helm upgrade (before rollback). Prevents leaving orphaned resources (ConfigMaps, Services) that were partially created by the failed upgrade.

**Deploy Blocklist**
A list of commit SHAs that should never be re-deployed. A commit is added after it causes a production incident and is rolled back. Prevents the same broken commit from accidentally being deployed again.

**Feature Flag Rollback**
Turning off a feature flag to instantly disable a feature without any code deployment. The fastest possible rollback — takes effect in < 1 second for all users simultaneously.

---

## Part 6 Terms — IaC Pipeline

**IaC (Infrastructure as Code)**
Managing cloud infrastructure (VMs, networks, databases) through code files rather than clicking in a web console. Enables version control, code review, automated testing, and reproducible environments for infrastructure.

**Terraform**
The most popular IaC tool. Uses HCL (HashiCorp Configuration Language) to declare what infrastructure should exist. `terraform apply` creates/modifies/destroys resources to match declarations. State-based: compares desired vs actual.

**`terraform plan`**
Shows what Terraform WOULD do if you ran `terraform apply` — without actually changing anything. Output shows: resources to add (green `+`), modify (yellow `~`), or destroy (red `-`). Must be reviewed before applying in production.

**`-detailed-exitcode`**
A `terraform plan` flag that changes exit codes: 0 = no changes, 1 = error, 2 = changes detected. Allows CI pipelines to skip the `apply` step when there are no changes (`if: exitcode == '2'`).

**`terraform apply`**
Actually makes the infrastructure changes planned by `terraform plan`. In CI: always uses a saved plan file (`terraform apply tfplan`) to apply EXACTLY what was reviewed, preventing surprises if infrastructure changed during the review period.

**Terraform State**
A JSON file that records what Terraform-managed resources exist and their current configuration. Without state, Terraform can't know what it already created. Losing state = Terraform thinks nothing exists → tries to recreate everything.

**Remote State Backend**
Storing Terraform state in a shared location (S3, Terraform Cloud, GCS) rather than locally. Required for teams — everyone uses the same state. Prevents "works on my machine but breaks CI" caused by state divergence.

**State Locking (DynamoDB)**
A mechanism that prevents two Terraform runs from applying simultaneously. When `terraform apply` starts, it writes a lock to DynamoDB. Other runs that try to start will wait or fail until the lock is released. Prevents state corruption.

**`terraform fmt`**
Formats Terraform code to the canonical style (consistent indentation, alignment). `terraform fmt -check` in CI fails if code isn't already formatted. Run `terraform fmt -recursive` locally to fix.

**`terraform validate`**
Checks Terraform configuration for syntax errors and invalid references (e.g., referencing a resource that doesn't exist in the config). Fast — doesn't contact the cloud provider.

**tflint**
A Terraform linter that checks for more issues than `terraform validate`: deprecated syntax, provider-specific rule violations (e.g., AWS instance types that don't exist), naming conventions.

**Checkov**
An open-source IaC security scanner (by Bridgecrew). Checks Terraform, CloudFormation, Kubernetes YAML for security misconfigurations: S3 buckets without encryption, security groups allowing 0.0.0.0/0, missing resource tags.

**tfsec**
Another IaC security scanner, now merged into Trivy. Checks Terraform for security issues. Can run `trivy config .` to scan Terraform files.

**Infracost**
A tool that estimates the monthly AWS/GCP/Azure cost of a Terraform plan. Integrates with CI to post cost differences as a PR comment: "This change will increase monthly costs by $143."

**Terratest**
A Go library for testing Terraform modules. Provisions real cloud resources, runs assertions, then destroys everything. The only way to truly test that a Terraform module works correctly.

**Drift Detection**
Running `terraform plan -refresh-only` on a schedule to detect if the actual cloud state has diverged from the Terraform code. Alerts when manual changes were made that bypass the IaC pipeline.

**`-refresh-only`**
A `terraform plan` mode that only compares the current cloud state to the Terraform state file, without comparing to the code. Used for drift detection — "has the real infrastructure drifted from what we last deployed?"

**`terraform output`**
Prints the output values defined in Terraform code (e.g., `vpc_id`, `alb_dns_name`). Used in post-apply validation to verify expected resources were created and to pass values to other pipeline steps.

**HCL (HashiCorp Configuration Language)**
The declarative language used for Terraform configuration files. Looks like JSON but with comments, functions, and expressions. Files end in `.tf`. Describes WHAT should exist, not HOW to create it.

---

## Part 7 Terms — Notifications and Observability

**Pushgateway (Prometheus)**
A Prometheus component that accepts metric pushes from short-lived processes (CI jobs) that can't be scraped. Pipeline jobs push build duration/result; Prometheus scrapes Pushgateway. The bridge between ephemeral jobs and time-series metrics.

**Channel ID (Slack)**
The stable internal identifier for a Slack channel (e.g., `C1234567890`). Unlike channel names (which can be renamed), channel IDs never change. Always use channel IDs in API calls so notifications don't break when channels are renamed.

**Slack Attachment**
A Slack message component that provides structured, colored formatting. A green attachment with fields = nice "success" notification. A red attachment = failure notification with details. More visually clear than plain text.

**`if: failure()`**
A GitHub Actions condition that makes a step run ONLY when the job has failed. Used to send failure notifications. Combined with `if: success()` and `if: always()` to control what runs when.

**`if: always()`**
A GitHub Actions condition that makes a step run regardless of whether previous steps succeeded or failed. Used for cleanup steps, artifact uploads, and metric recording — things that should always happen.

**Build Status Badge**
An image served by GitHub (or a badge service) that shows the current CI status of a branch. Embedded in README.md. Shows green "passing" or red "failing" to anyone viewing the repository page.

**Deployment Record**
A structured entry in an audit log recording: what was deployed, to which environment, by whom, at what time, from which source commit. Created by every production deployment. Used in incident investigations ("what changed?").

**`tmate`**
A tool that creates an SSH session into a running GitHub Actions runner for interactive debugging. A failing job can be paused at a breakpoint and the engineer SSH's in to investigate the environment state directly.

**`ACTIONS_STEP_DEBUG`**
A GitHub Actions secret/variable that enables verbose debug logging for all steps in a workflow. When set to `true`, every command and its output is printed to the logs. Useful for debugging mysterious pipeline failures.

**State Change Notification**
Notifying only when a pipeline CHANGES state (was passing, now failing OR was failing, now passing) rather than every run. Dramatically reduces notification noise — a team gets one failure notification, not 20 for the same broken build.

**Audit Trail**
A chronological record of all changes to a system, who made them, and when. For deployments: commit SHA + deployer + timestamp + approval records. Required for security compliance (SOC2, ISO27001) and incident investigations.

**`cicd_pipeline_success`**
A custom Prometheus gauge metric that equals 1 when a pipeline succeeded and 0 when it failed. Used to track build success rate over time and alert when the main branch has been failing for too long.

**`cicd_deploy_timestamp`**
A custom Prometheus gauge metric recording the Unix timestamp of the last successful production deployment. Used to detect when no deploy has happened in an unexpectedly long time (possible process blockage).
