# Part 2 — Testing Strategy in CI Pipelines: Deep Dive

---

## The Test Pyramid: What to Run and When

The test pyramid describes how many of each test type to have, how fast each type is, and where in the pipeline each type belongs.

```
                    ╱▔▔▔▔▔▔▔╲
                   ╱  E2E/UI  ╲         Few (5-10)
                  ╱  tests     ╲        Slow (minutes each)
                 ╱─────────────╲        Expensive
                ╱  Integration  ╲       Medium (100-500)
               ╱    tests        ╲      Minutes total
              ╱──────────────────╲      Need real infra
             ╱     Unit tests      ╲    Many (1000s)
            ╱────────────────────── ╲  Seconds total
                                       In-memory only

Pyramid rule:
  More tests at bottom (cheap, fast, many)
  Fewer tests at top (expensive, slow, few)

Inverted pyramid (anti-pattern):
  Few unit tests, many E2E tests
  Result: CI takes 1 hour, tests are flaky, feedback is slow
```

---

## Unit Tests: Every Commit

Unit tests verify a single class/function in complete isolation. No network, no database, no filesystem — everything is in memory.

### What Makes a Good Unit Test

```java
// BAD unit test — hits the database (not a unit test!)
@Test
void testGetUser_returnUserFromDB() {
    User user = userService.getUser(1L);   // calls real DB
    assertEquals("Alice", user.getName());
}

// GOOD unit test — mocks the dependency
@Test
void testGetUser_returnsUserWhenFound() {
    // Arrange: set up mock behavior
    when(userRepository.findById(1L))
        .thenReturn(Optional.of(new User(1L, "Alice")));
    
    // Act: call the actual method under test
    User result = userService.getUser(1L);
    
    // Assert: verify behavior
    assertEquals("Alice", result.getName());
    
    // Verify: ensure correct interaction with dependency
    verify(userRepository, times(1)).findById(1L);
}
```

**Unit test rules:**
```
FAST:        < 100ms per test
ISOLATED:    no I/O, no network, no shared state between tests
REPEATABLE:  same result every time
SELF-CHECKING: no manual verification needed
SMALL:       test ONE behavior, one assertion per test
```

### Running Unit Tests in CI

```yaml
- name: Run unit tests
  run: |
    mvn test \
      --batch-mode \
      -Dtest="**/*Test,**/*Tests,**/*Spec" \
      -DexcludedGroups="integration,e2e" \
      -Dsurefire.failIfNoSpecifiedTests=false
  
- name: Publish test results
  uses: dorny/test-reporter@v1
  if: always()          # show results even when tests fail
  with:
    name: Unit Test Results
    path: target/surefire-reports/*.xml
    reporter: java-junit
    fail-on-error: true

- name: Upload coverage report
  uses: codecov/codecov-action@v3
  with:
    files: target/site/jacoco/jacoco.xml
    fail_ci_if_error: true
    threshold: 80        # fail if coverage drops below 80%
```

### Code Coverage: What It Means and What It Doesn't

```
80% line coverage means:
  80% of code LINES are executed during tests
  
What it DOESN'T mean:
  ✗ The tests are good (they might assert nothing)
  ✗ Edge cases are tested (might miss null, empty, boundary cases)
  ✗ The system works end-to-end

What it DOES tell you:
  ✓ 20% of code has ZERO test coverage (definitely untested)
  ✓ Trend: if coverage drops from 85% to 70%, tests aren't keeping up with code

Branch coverage is better:
  Measures that BOTH branches of every if/else are tested
  Line coverage: if (x > 0) { doSomething(); } — tests x=1 → 100% line coverage
  Branch coverage: tests x=1 AND x=-1 → tests both branches → 100% branch coverage
```

---

## Integration Tests: On Merge to Main

Integration tests verify that multiple components work together. They use real databases, real message queues, sometimes real network calls.

### Running Services with Docker Compose in CI

```yaml
- name: Start test infrastructure
  run: |
    docker-compose -f docker-compose.test.yml up -d
    
    # Wait for services to be ready (don't just sleep)
    until docker exec test-postgres pg_isready -U testuser; do
      echo "Waiting for PostgreSQL..."
      sleep 2
    done
    until curl -sf http://localhost:9200/_cluster/health | grep -q '"status":"green"'; do
      echo "Waiting for Elasticsearch..."
      sleep 2
    done
    echo "All services ready"

- name: Run integration tests
  run: |
    mvn verify \
      -Pintegration-tests \
      -Dspring.datasource.url=jdbc:postgresql://localhost:5432/testdb \
      -Dspring.elasticsearch.uris=http://localhost:9200 \
      --batch-mode

- name: Stop test infrastructure
  if: always()       # clean up even if tests fail
  run: docker-compose -f docker-compose.test.yml down -v
```

```yaml
# docker-compose.test.yml
version: '3.8'
services:
  postgres:
    image: postgres:15-alpine
    container_name: test-postgres
    environment:
      POSTGRES_DB: testdb
      POSTGRES_USER: testuser
      POSTGRES_PASSWORD: testpass
    ports:
      - "5432:5432"
    tmpfs: /var/lib/postgresql/data    # in-memory = faster, no persistent state

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  kafka:
    image: confluentinc/cp-kafka:7.5.0
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://localhost:9092
    ports:
      - "9092:9092"
    depends_on: [zookeeper]
```

### GitHub Actions Service Containers (Better Than Docker Compose)

```yaml
# Services run as Docker containers alongside the job
jobs:
  integration-test:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:15-alpine
        env:
          POSTGRES_DB: testdb
          POSTGRES_USER: testuser
          POSTGRES_PASSWORD: testpass
        ports:
          - 5432:5432
        options: >-
          --health-cmd "pg_isready -U testuser"
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5           # job waits for health to pass before steps run

      redis:
        image: redis:7-alpine
        ports:
          - 6379:6379
        options: >-
          --health-cmd "redis-cli ping"
          --health-interval 10s
          --health-retries 5

    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { java-version: '17', distribution: temurin, cache: maven }
      
      - name: Run integration tests
        env:
          SPRING_DATASOURCE_URL: jdbc:postgresql://localhost:5432/testdb
          SPRING_DATASOURCE_USERNAME: testuser
          SPRING_DATASOURCE_PASSWORD: testpass
          SPRING_REDIS_HOST: localhost
          SPRING_REDIS_PORT: 6379
        run: mvn verify -Pintegration-tests --batch-mode
```

**Advantage over docker-compose:** GitHub manages the service lifecycle — starts before the job, stops after. No cleanup step needed. Health checks block job start until services are ready.

---

## Test Sharding: Parallelizing a Large Test Suite

A 500-test suite taking 20 minutes becomes 4 × 5 minutes with 4-way sharding.

### Method 1: Tag-Based Sharding

```java
// Tag tests with shard groups
@Tag("shard1")
class UserServiceTest { ... }

@Tag("shard2")
class PaymentServiceTest { ... }

@Tag("shard3")
class CheckoutServiceTest { ... }
```

```yaml
strategy:
  matrix:
    shard: [1, 2, 3, 4]

steps:
  - run: mvn test -Dgroups="shard${{ matrix.shard }}" --batch-mode
```

### Method 2: Split Plugin (No Manual Tagging)

```yaml
strategy:
  matrix:
    shard-index: [0, 1, 2, 3]    # 0-based
    shard-total: [4]

steps:
  # pytest example:
  - run: |
      pytest \
        --splits ${{ matrix.shard-total }} \
        --group $(( ${{ matrix.shard-index }} + 1 )) \
        --store-durations \   # remember how long each test takes
        tests/               # distribute by duration (not count)

  # JUnit Platform example with shard support:
  - run: |
      mvn test \
        -Dsurefire.useFile=true \
        -Dsurefire.forkCount=1 \
        -Dsurefire.splitGroups="shard:${{ matrix.shard-index }}/${{ matrix.shard-total }}"
```

### Method 3: File-Based Sharding (Shell Script)

```yaml
strategy:
  matrix:
    shard: [1, 2, 3, 4]

steps:
  - name: Run test shard ${{ matrix.shard }} of 4
    run: |
      # Get all test files, sorted alphabetically
      ALL_TESTS=$(find src/test -name "*Test.java" | sort)
      TOTAL=$(echo "$ALL_TESTS" | wc -l)
      SHARD_SIZE=$(( (TOTAL + 3) / 4 ))  # ceiling division
      
      # Calculate start/end for this shard
      START=$(( (${{ matrix.shard }} - 1) * SHARD_SIZE + 1 ))
      END=$(( ${{ matrix.shard }} * SHARD_SIZE ))
      
      # Get this shard's test files
      SHARD_TESTS=$(echo "$ALL_TESTS" | sed -n "${START},${END}p" | \
        sed 's|src/test/java/||; s|\.java||; s|/|.|g' | tr '\n' ',')
      
      mvn test -Dtest="$SHARD_TESTS" --batch-mode
```

### Merging Sharded Test Results

```yaml
# After all shards complete, merge JUnit XML reports
- name: Merge test results
  if: always()
  run: |
    mkdir -p merged-results
    # Download artifacts from all shards
    
- name: Download shard 1 results
  uses: actions/download-artifact@v4
  with:
    name: test-results-shard-1
    path: merged-results/shard-1/

# Then publish merged results
- name: Publish merged test results
  uses: dorny/test-reporter@v1
  with:
    name: All Test Results
    path: merged-results/**/*.xml
    reporter: java-junit
```

---

## Contract Testing: API Compatibility Between Services

When Service A calls Service B, you need to verify:
- A sends what B expects
- B returns what A expects

Without contract tests, this is only caught in expensive integration tests or worse, in production.

### Pact Framework (Consumer-Driven Contract Testing)

```java
// Consumer (Service A — the caller) writes the contract
@ExtendWith(PactConsumerTestExt.class)
class CheckoutServiceContractTest {
  
  @Pact(consumer = "checkout-service", provider = "payment-service")
  public RequestResponsePact createPact(PactDslWithProvider builder) {
    return builder
      .given("user 123 exists")
      .uponReceiving("a charge request")
        .method("POST")
        .path("/charge")
        .body(new PactDslJsonBody()
          .stringValue("userId", "123")
          .numberValue("amount", 99.99)
          .stringValue("currency", "JPY"))
      .willRespondWith()
        .status(200)
        .body(new PactDslJsonBody()
          .stringValue("transactionId", "txn-abc123")
          .stringValue("status", "SUCCESS"))
      .toPact();
  }
  
  @Test
  @PactTestFor(pactMethod = "createPact")
  void testChargeRequest(MockServer mockServer) {
    // Test runs against Pact mock server
    PaymentResponse response = paymentClient.charge(
      new ChargeRequest("123", 99.99, "JPY"),
      mockServer.getUrl()
    );
    assertEquals("SUCCESS", response.getStatus());
  }
}
```

```yaml
# In CI: publish consumer contract to Pact Broker
- name: Publish Pact contracts
  run: |
    mvn pact:publish \
      -Dpact.broker.url=https://pactbroker.internal \
      -Dpact.broker.token=${{ secrets.PACT_BROKER_TOKEN }} \
      -Dpact.consumer.version=${{ github.sha }}

# Provider verifies against all consumer contracts
- name: Verify Pact contracts (payment-service CI)
  run: |
    mvn pact:verify \
      -Dpact.broker.url=https://pactbroker.internal \
      -Dpact.broker.token=${{ secrets.PACT_BROKER_TOKEN }} \
      -Dpact.provider.version=${{ github.sha }}
```

**What this prevents:** "Service A was updated to send `amount` as a string but Service B expects a number" — caught immediately in CI without requiring both services to be deployed together.

---

## Performance Tests in CI

Performance tests belong in the pipeline but need careful scoping — full load tests in CI are overkill.

### Light Performance Gate (Every PR)

```yaml
- name: Response time gate
  run: |
    # Install k6
    sudo apt-get install -y k6
    
    # Start app
    java -jar target/app.jar &
    sleep 10
    
    # Run brief performance check (30 sec)
    k6 run \
      --vus 10 \
      --duration 30s \
      --threshold 'http_req_duration{p(99)<500}'  \  # p99 must be < 500ms
      --threshold 'http_req_failed<0.01' \           # < 1% errors
      performance/smoke-load.js
```

```javascript
// performance/smoke-load.js
import http from 'k6/http';
import { check } from 'k6';

export const options = {
  vus: 10,
  duration: '30s',
  thresholds: {
    http_req_duration: ['p(99)<500'],
    http_req_failed: ['rate<0.01'],
  },
};

export default function () {
  const res = http.post('http://localhost:8080/checkout', JSON.stringify({
    userId: '123',
    items: [{ id: 'item-1', quantity: 2 }],
  }), { headers: { 'Content-Type': 'application/json' } });
  
  check(res, {
    'status is 200': (r) => r.status === 200,
    'response time < 500ms': (r) => r.timings.duration < 500,
  });
}
```

### Full Load Test (Nightly, Not Every PR)

```yaml
# .github/workflows/nightly-perf.yml
on:
  schedule:
    - cron: '0 1 * * *'    # 1am UTC nightly

jobs:
  load-test:
    runs-on: ubuntu-latest
    steps:
      - name: Full load test (10 min, 500 VUs)
        run: |
          k6 run \
            --vus 500 \
            --duration 10m \
            --out json=results.json \
            performance/full-load.js
      
      - name: Analyze regression vs yesterday
        run: |
          python3 scripts/compare-perf.py \
            --current results.json \
            --baseline gs://perf-results/baseline.json \
            --threshold 10     # fail if p99 regressed > 10%
```

---

## Mutation Testing: Verify Test Quality

Regular code coverage tells you lines were executed. Mutation testing tells you if your assertions would catch bugs.

```
How mutation testing works:
  1. Take your code
  2. Make a "mutation" (change + to -, flip an if condition, etc.)
  3. Run your test suite
  4. If tests PASS → tests don't catch this class of bug → bad!
  5. If tests FAIL → tests caught the mutation → good!

Mutation score = (killed mutations / total mutations) × 100
Target: > 80% mutation score
```

```yaml
# Run PIT (PITest) mutation testing - Java
- name: Mutation testing
  run: |
    mvn test-compile org.pitest:pitest-maven:mutationCoverage \
      -Dpit.targetClasses="com.myorg.checkout.*" \
      -Dpit.targetTests="com.myorg.checkout.*Test" \
      -Dpit.mutators="ALL" \
      -Dpit.timeoutConstant=10000 \
      -Dpit.threads=4

- name: Check mutation score threshold
  run: |
    MUTATION_SCORE=$(grep -oP 'Line Coverage.*?(\d+)%' target/pit-reports/*/index.html | tail -1 | grep -oP '\d+')
    if [ "$MUTATION_SCORE" -lt "75" ]; then
      echo "Mutation score $MUTATION_SCORE% is below 75% threshold"
      exit 1
    fi
```

Mutation testing is SLOW (can take 10-30 minutes). Run nightly or on merge to main only.
