# Part 6 — Infrastructure as Code Pipeline (Terraform): Deep Dive

---

## Why IaC Needs Its Own Pipeline

Infrastructure code is different from application code:
- Running it wrong can destroy databases and lose data
- There is no "unit test" that is completely safe (you must interact with real cloud)
- Changes can have dependencies (VPC must exist before subnet)
- The "deploy" is potentially irreversible (deleted S3 bucket = gone)

```
IaC pipeline requirements:
  ✓ Plan BEFORE apply (see what will change before changing it)
  ✓ Human approval for any production apply
  ✓ State locking (prevent concurrent applies that conflict)
  ✓ Cost estimation before applying (know the bill impact)
  ✓ Security scanning of IaC code (Checkov, tfsec)
  ✓ Module testing (validate reusable modules work correctly)
```

---

## Terraform Pipeline: Full Structure

```
Code push
    │
    ▼
terraform fmt -check     (style check — 10 seconds)
    │
    ▼
terraform validate       (syntax check — 5 seconds)
    │
    ▼
tflint                   (linting — additional rules)
    │
    ▼
checkov / tfsec          (security scanning)
    │
    ▼
terraform plan           (show what WOULD change — no cloud changes yet)
    │
    ▼
Post plan to PR          (human reviews the plan diff)
    │
    ▼
[MANUAL APPROVAL for production]
    │
    ▼
terraform apply          (actually make the changes)
    │
    ▼
Post-apply validation    (verify expected resources exist)
```

---

## Complete Terraform GitHub Actions Workflow

```yaml
# .github/workflows/terraform.yml
name: Terraform

on:
  push:
    branches: [main]
    paths: ['infra/**']
  pull_request:
    branches: [main]
    paths: ['infra/**']

permissions:
  id-token: write       # OIDC for AWS
  contents: read
  pull-requests: write  # post plan to PR

jobs:
  # ── STAGE 1: Validate ──────────────────────────────────
  validate:
    runs-on: ubuntu-latest
    defaults:
      run:
        working-directory: infra/

    steps:
      - uses: actions/checkout@v4

      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: '1.7.0'

      # Format check: fail if code isn't formatted
      - name: Terraform Format Check
        run: terraform fmt -check -recursive
        # Fix locally with: terraform fmt -recursive

      # Syntax validation
      - name: Terraform Init (for validation only)
        run: terraform init -backend=false    # skip backend for fast validation
        env:
          TF_CLI_ARGS_init: "-upgrade=false"

      - name: Terraform Validate
        run: terraform validate

      # Linting: additional rule checks
      - uses: terraform-linters/setup-tflint@v4
      - name: TFLint
        run: |
          tflint --init
          tflint --format=compact

  # ── STAGE 2: Security Scan ─────────────────────────────
  security:
    needs: validate
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Run Checkov (security and compliance scan)
        uses: bridgecrewio/checkov-action@master
        with:
          directory: infra/
          framework: terraform
          soft_fail: false         # hard fail on CRITICAL findings
          output_format: sarif
          output_file_path: checkov-results.sarif
          skip_check: |
            CKV_AWS_18,CKV_AWS_20  # skip specific checks with justification

      - name: Upload Checkov results
        uses: github/codeql-action/upload-sarif@v2
        if: always()
        with:
          sarif_file: checkov-results.sarif

  # ── STAGE 3: Plan ──────────────────────────────────────
  plan:
    needs: [validate, security]
    runs-on: ubuntu-latest
    outputs:
      plan-exit-code: ${{ steps.plan.outputs.exitcode }}

    steps:
      - uses: actions/checkout@v4

      - name: Configure AWS credentials (OIDC)
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/TerraformRole
          aws-region: ap-northeast-1

      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: '1.7.0'

      - name: Terraform Init
        working-directory: infra/
        run: |
          terraform init \
            -backend-config="bucket=my-tfstate-bucket" \
            -backend-config="key=production/terraform.tfstate" \
            -backend-config="region=ap-northeast-1"

      - name: Terraform Plan
        id: plan
        working-directory: infra/
        run: |
          terraform plan \
            -detailed-exitcode \
            -out=tfplan \
            -var-file=environments/production.tfvars \
            2>&1 | tee plan-output.txt
          
          # Exit codes:
          # 0 = no changes
          # 1 = error
          # 2 = changes detected (success with changes)
          echo "exitcode=$?" >> $GITHUB_OUTPUT
        continue-on-error: true    # capture exit code, don't fail immediately

      - name: Save plan file
        uses: actions/upload-artifact@v4
        with:
          name: tfplan
          path: infra/tfplan
          retention-days: 1        # plan is only valid for today's apply

      # Post plan output to the PR as a comment
      - name: Post Plan to PR
        uses: actions/github-script@v7
        if: github.event_name == 'pull_request'
        with:
          script: |
            const fs = require('fs');
            const planOutput = fs.readFileSync('infra/plan-output.txt', 'utf8');
            
            // Truncate if too long for PR comment
            const truncated = planOutput.length > 65000
              ? planOutput.substring(0, 65000) + '\n\n... (truncated)'
              : planOutput;
            
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: `## Terraform Plan
              \`\`\`terraform
              ${truncated}
              \`\`\`
              *Triggered by: ${{ github.actor }}*`
            });

      - name: Fail if plan errored
        if: steps.plan.outputs.exitcode == '1'
        run: exit 1

  # ── STAGE 4: Cost Estimation ───────────────────────────
  cost:
    needs: plan
    runs-on: ubuntu-latest
    if: github.event_name == 'pull_request'
    steps:
      - uses: actions/checkout@v4

      - uses: actions/download-artifact@v4
        with:
          name: tfplan
          path: infra/

      - name: Estimate cost with Infracost
        uses: infracost/actions/setup@v2
        with:
          api-key: ${{ secrets.INFRACOST_API_KEY }}

      - name: Run Infracost
        working-directory: infra/
        run: |
          infracost diff \
            --path=tfplan \
            --format=json \
            --out-file=/tmp/infracost.json

      - name: Post cost estimate to PR
        run: |
          infracost comment github \
            --path=/tmp/infracost.json \
            --repo=${{ github.repository }} \
            --pull-request=${{ github.event.pull_request.number }} \
            --github-token=${{ secrets.GITHUB_TOKEN }}

  # ── STAGE 5: Apply (production, requires approval) ─────
  apply:
    needs: plan
    runs-on: ubuntu-latest
    environment: production-terraform   # requires manual approval
    if: github.ref == 'refs/heads/main' && needs.plan.outputs.plan-exit-code == '2'
    # Only apply if: on main AND there are actual changes (exitcode=2)

    steps:
      - uses: actions/checkout@v4

      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/TerraformRole
          aws-region: ap-northeast-1

      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: '1.7.0'

      - uses: actions/download-artifact@v4
        with:
          name: tfplan
          path: infra/

      - name: Terraform Init
        working-directory: infra/
        run: |
          terraform init \
            -backend-config="bucket=my-tfstate-bucket" \
            -backend-config="key=production/terraform.tfstate" \
            -backend-config="region=ap-northeast-1"

      - name: Terraform Apply
        working-directory: infra/
        run: |
          terraform apply \
            -auto-approve \
            tfplan
        # Uses the saved plan — applies EXACTLY what was reviewed
        # No surprises from infrastructure changes during review period

      - name: Post-apply validation
        working-directory: infra/
        run: |
          terraform output -json | \
            python3 -c "
            import sys, json
            outputs = json.load(sys.stdin)
            required = ['vpc_id', 'subnet_ids', 'alb_dns_name']
            for key in required:
              if key not in outputs:
                print(f'MISSING OUTPUT: {key}')
                sys.exit(1)
              print(f'OK: {key} = {outputs[key][\"value\"]}')
            "
```

---

## Terraform State: The Source of Truth

Terraform state is a JSON file that records what resources Terraform manages and their current configuration. It's critical — lose it and Terraform can't manage existing resources.

### Remote State Backend (Required for Teams)

```hcl
# infra/backend.tf
terraform {
  backend "s3" {
    bucket         = "my-company-tfstate"    # S3 bucket (must exist already)
    key            = "production/terraform.tfstate"
    region         = "ap-northeast-1"
    encrypt        = true                    # encrypt at rest
    
    dynamodb_table = "terraform-state-lock"  # DynamoDB table for locking
    # CRITICAL: prevents two pipelines from running terraform apply simultaneously
    # Without this: two pipelines could conflict and corrupt state
  }
}
```

```bash
# Create the DynamoDB lock table (once)
aws dynamodb create-table \
  --table-name terraform-state-lock \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST \
  --region ap-northeast-1

# Check if state is currently locked (someone is applying)
aws dynamodb get-item \
  --table-name terraform-state-lock \
  --key '{"LockID": {"S": "my-company-tfstate/production/terraform.tfstate"}}' \
  --region ap-northeast-1
```

### State Locking: Preventing Concurrent Applies

```
Without state locking:
  Pipeline A: reads state → plans → starts applying (adds 2 EC2 instances)
  Pipeline B: reads same old state → plans → starts applying (deletes and re-adds VPC)
  
  Result: RACE CONDITION
  Pipeline A's apply may fail (VPC being deleted while it's creating instances)
  OR: both apply partial changes and state becomes inconsistent
  OR worst case: resources are deleted that shouldn't be

With DynamoDB locking:
  Pipeline A: acquires lock → applies → releases lock
  Pipeline B: tries to acquire lock → BLOCKED until A finishes
              → then proceeds safely with latest state
```

---

## Terraform Module Pipeline

Large organizations use reusable Terraform modules. These need their own pipeline.

```hcl
# modules/networking/main.tf
variable "vpc_cidr" { type = string }
variable "availability_zones" { type = list(string) }

resource "aws_vpc" "main" {
  cidr_block = var.vpc_cidr
  tags = { Name = "main-vpc", ManagedBy = "terraform" }
}

output "vpc_id" { value = aws_vpc.main.id }
```

```yaml
# .github/workflows/module-test.yml
jobs:
  test-networking-module:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/TerraformTestRole
          aws-region: ap-northeast-1

      - name: Run Terratest
        working-directory: modules/networking/test/
        run: |
          go test -v -run TestNetworkingModule \
            -timeout=30m          # module tests create real resources

      # Terratest provisions real AWS resources, tests them, destroys them
```

```go
// modules/networking/test/networking_test.go
func TestNetworkingModule(t *testing.T) {
    options := &terraform.Options{
        TerraformDir: "../",
        Vars: map[string]interface{}{
            "vpc_cidr":           "10.0.0.0/16",
            "availability_zones": []string{"ap-northeast-1a", "ap-northeast-1c"},
        },
    }
    
    defer terraform.Destroy(t, options)    // always cleanup
    terraform.InitAndApply(t, options)
    
    vpcID := terraform.Output(t, options, "vpc_id")
    assert.NotEmpty(t, vpcID)
    
    // Verify VPC exists in AWS
    vpc := aws.GetVpcById(t, vpcID, "ap-northeast-1")
    assert.Equal(t, "10.0.0.0/16", vpc.CidrBlock)
}
```

---

## Drift Detection: IaC vs Reality

Over time, infrastructure drifts from the Terraform code — someone manually changed something in the AWS console.

```yaml
# .github/workflows/drift-detection.yml
on:
  schedule:
    - cron: '0 8 * * *'    # daily drift check

jobs:
  detect-drift:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/TerraformReadRole
          aws-region: ap-northeast-1

      - uses: hashicorp/setup-terraform@v3
        with:
          terraform_version: '1.7.0'

      - name: Terraform Init
        working-directory: infra/
        run: terraform init

      - name: Check for drift
        working-directory: infra/
        id: drift
        run: |
          terraform plan \
            -detailed-exitcode \
            -refresh-only \    # ONLY check if state matches reality
            -out=/dev/null \   # don't save plan (read-only check)
            2>&1
          echo "exitcode=$?" >> $GITHUB_OUTPUT
        continue-on-error: true

      - name: Alert on drift
        if: steps.drift.outputs.exitcode == '2'
        run: |
          curl -X POST ${{ secrets.SLACK_WEBHOOK }} \
            -H "Content-Type: application/json" \
            -d '{
              "text": "⚠️ Terraform drift detected in production!\nSomeone manually changed infrastructure.\nRun `terraform apply` to reconcile or investigate manual changes.",
              "channel": "#sre-alerts"
            }'
```
