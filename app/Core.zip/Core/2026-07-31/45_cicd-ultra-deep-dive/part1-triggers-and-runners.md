# Part 1 — Triggers and Runners: Deep Dive

---

## What a Trigger Really Is

A trigger is the event that tells the CI/CD system: "Start a pipeline run NOW for this specific commit."

Without a trigger, nothing happens. Code can sit in a repo forever untested. The trigger is the doorbell that starts the assembly line.

```
Every CI/CD system listens for events from Git hosting:

GitHub pushes a webhook payload to GitHub Actions when:
  - Someone does `git push`
  - A PR is opened, updated, or closed
  - A tag is created
  - A release is published
  - A scheduled cron fires
  - A human clicks "Run workflow"
  - Another workflow finishes
```

---

## Complete Trigger Reference

### Push Trigger — Most Common

```yaml
on:
  push:
    branches:
      - main                    # exact branch name
      - 'release/**'            # glob: release/1.0, release/2.0, etc.
      - 'hotfix/*'              # glob: hotfix/fix-login
    tags:
      - 'v*.*.*'                # semver tags: v1.2.3
    paths:
      - 'src/**'                # only trigger if src/ changes
      - 'pom.xml'               # or if pom.xml changes
    paths-ignore:
      - '**.md'                 # never trigger on docs-only changes
      - '.github/CODEOWNERS'
```

**`paths` vs no `paths`:**
```
Without paths filter:
  Change README.md → full CI pipeline runs (4 min for docs change = waste)

With paths filter:
  Change README.md → pipeline skips entirely
  Change src/App.java → pipeline runs
```

### Pull Request Trigger

```yaml
on:
  pull_request:
    branches:
      - main                    # only PRs targeting main
    types:
      - opened                  # PR created
      - synchronize             # new commit pushed to PR branch
      - reopened                # PR reopened after closing
      # NOT: closed (would run pipeline on PR close without merge)
    paths:
      - 'src/**'
      - 'pom.xml'
```

**PR vs Push — which to use when:**
```
pull_request trigger:
  ✓ Tests run against the MERGED state (PR branch + target branch combined)
  ✓ Results appear as check on the PR
  ✓ Can block merge if checks fail
  ✗ Has read-only access to secrets by default (security: forks can't steal secrets)

push trigger (to main):
  ✓ Full access to secrets
  ✓ Can deploy artifacts, push to registry
  ✗ Tests run after merge — too late to block a bad merge
```

**Correct pattern: use BOTH**
```yaml
on:
  pull_request:        # test the merge result before merging
    branches: [main]
  push:
    branches: [main]   # build/publish artifact after merging
```

### Schedule Trigger — Nightly Jobs

```yaml
on:
  schedule:
    - cron: '0 2 * * *'        # every day at 2:00am UTC
    - cron: '0 9 * * 1'        # every Monday at 9:00am UTC
```

**Reading cron syntax:**
```
 ┌── minute (0-59)
 │   ┌── hour (0-23, UTC)
 │   │   ┌── day of month (1-31)
 │   │   │   ┌── month (1-12)
 │   │   │   │   ┌── day of week (0=Sunday, 1=Monday...6=Saturday)
 │   │   │   │   │
 0   2   *   *   *    → 2:00am every day
 0   9   *   *   1    → 9:00am every Monday
 */15 *  *   *   *    → every 15 minutes
 0   0   1   *   *    → midnight on 1st of every month
```

**Use cases for scheduled pipelines:**
- Nightly integration tests (too slow for every PR)
- Weekly security scans (full CVE database refresh)
- Monthly dependency updates (`mvn versions:update`)
- Daily canary health checks against production

### Workflow Call — Reusable Pipelines

```yaml
# Called workflow (.github/workflows/deploy-template.yml)
on:
  workflow_call:
    inputs:
      environment:
        required: true
        type: string
      image-tag:
        required: true
        type: string
    secrets:
      KUBECONFIG:
        required: true

# Calling workflow
jobs:
  deploy:
    uses: ./.github/workflows/deploy-template.yml
    with:
      environment: production
      image-tag: sha-abc123
    secrets:
      KUBECONFIG: ${{ secrets.PROD_KUBECONFIG }}
```

**Why reusable workflows:** 5 microservices all deploy the same way. Write the deploy logic ONCE in a template workflow. Each service calls the template with different parameters. Change the deploy logic in one place.

---

## Runners: The Machines That Execute Jobs

A runner is a machine (virtual or physical) that picks up a job from the queue and executes it.

### GitHub-Hosted Runners

```
ubuntu-latest   → Ubuntu 24.04 LTS, 4 vCPU, 16GB RAM, 14GB SSD
ubuntu-22.04    → Ubuntu 22.04 LTS (pinned version, more stable)
ubuntu-20.04    → Ubuntu 20.04 LTS (legacy support)
windows-latest  → Windows Server 2022, 4 vCPU, 16GB RAM
macos-latest    → macOS 14 (Sonoma), 3 vCPU, 14GB RAM, Apple Silicon
macos-13        → macOS 13 (Ventura), Intel
```

**Pre-installed on ubuntu-latest:**
```
Languages:   Java (8,11,17,21), Python (3.x), Node.js, Go, Ruby, PHP
Tools:       Docker, kubectl, helm, terraform, git, AWS CLI, GCP CLI
Build tools: Maven, Gradle, npm, pip, cargo
```

**GitHub-hosted runner cost (GitHub Free/Pro/Teams):**
```
ubuntu-latest:   $0.008 per minute
windows-latest:  $0.016 per minute  (2x more expensive)
macos-latest:    $0.08 per minute   (10x more expensive)

10-minute pipeline:
  Linux:   $0.08 per run
  Windows: $0.16 per run
  macOS:   $0.80 per run

50 runs/day for 20 days:
  Linux:   $80/month
  macOS:   $800/month
```

**Tip:** Only use macOS runners when testing macOS-specific behavior (iOS apps, macOS tools). Use Linux for everything else.

### Self-Hosted Runners

You run the runner agent on your own infrastructure. It registers with GitHub and picks up jobs from the queue.

```
When to use self-hosted runners:
  ✓ Need more RAM/CPU than GitHub provides (e.g., 64GB for large builds)
  ✓ Need persistent disk (large Docker layer cache)
  ✓ Need to reach private network resources (internal registries, DBs)
  ✓ Compliance: code must not leave your network
  ✓ Cost: very high build volume makes self-hosted cheaper
  ✗ You manage availability, updates, scaling
  ✗ Security: malicious PRs can run code on your runner
```

```bash
# Register a self-hosted runner on a Linux machine
mkdir actions-runner && cd actions-runner
curl -o actions-runner-linux-x64-2.310.2.tar.gz -L \
  https://github.com/actions/runner/releases/download/v2.310.2/actions-runner-linux-x64-2.310.2.tar.gz
tar xzf ./actions-runner-linux-x64-2.310.2.tar.gz

# Configure (token from GitHub: Settings → Actions → Runners → New self-hosted runner)
./config.sh \
  --url https://github.com/myorg/myrepo \
  --token YOUR_REGISTRATION_TOKEN \
  --name my-runner-1 \
  --labels large-runner,docker-capable \
  --runnergroup default

# Run as service (auto-start on reboot)
sudo ./svc.sh install
sudo ./svc.sh start
```

```yaml
# Use self-hosted runner in workflow
jobs:
  build:
    runs-on: [self-hosted, large-runner]   # match your labels
```

**Self-hosted runner security for public repos:**
```
DANGER: Anyone can open a PR targeting your repo.
If you use self-hosted runners on PR triggers,
a malicious PR can run: rm -rf / or exfiltrate files.

Mitigations:
  1. Never use self-hosted runners for pull_request trigger on public repos
  2. Use: pull_request_target (runs in context of base branch, not PR branch)
  3. Require approval for first-time contributors
  4. Run runners in isolated containers/VMs (ephemeral runners)
```

### Ephemeral Self-Hosted Runners (Best Practice)

Persistent runners accumulate state across jobs: stale caches, leftover files from previous jobs, security artifacts. Ephemeral runners start fresh for every job.

```yaml
# Actions Runner Controller (ARC) on Kubernetes
# Each job gets a fresh pod, pod is deleted after job completes

apiVersion: actions.summerwind.dev/v1alpha1
kind: RunnerDeployment
metadata:
  name: checkout-runner
spec:
  template:
    spec:
      repository: myorg/checkout
      labels:
        - checkout-runner
      ephemeral: true              # ← fresh container per job
      image: summerwind/actions-runner:latest
      resources:
        requests:
          cpu: "2"
          memory: "4Gi"
        limits:
          cpu: "4"
          memory: "8Gi"
```

### Larger GitHub-Hosted Runners (Paid)

For heavy builds, GitHub offers larger hosted runners:

```yaml
runs-on: ubuntu-latest-8-cores    # 8 vCPU, 32GB RAM
runs-on: ubuntu-latest-16-cores   # 16 vCPU, 64GB RAM
runs-on: ubuntu-latest-32-cores   # 32 vCPU, 128GB RAM
```

Cost scales with core count. Often worth it for build times > 15 minutes.

---

## Runner Pools and Concurrency

```
GitHub Free plan:    20 concurrent jobs (GitHub-hosted)
GitHub Team plan:    60 concurrent jobs
GitHub Enterprise:  180 concurrent jobs per organization

Self-hosted:         as many concurrent jobs as you have runners
```

**Concurrency management:**
```yaml
# Limit how many deploys run at once (prevent race conditions)
concurrency:
  group: deploy-${{ inputs.environment }}
  cancel-in-progress: false    # for deployments: don't cancel in-progress deploy!
                               # (mid-deploy cancellation = broken state)

# For builds/tests: cancel stale runs
concurrency:
  group: ci-${{ github.ref }}
  cancel-in-progress: true    # always use latest commit
```

---

## The Job Execution Environment

What happens on a runner when a job starts:

```
1. Runner receives job assignment from GitHub API
2. Runner downloads the workflow YAML from GitHub
3. Runner clones the repo at the specific SHA
   (or: uses actions/checkout to do this as a step)
4. Runner creates a temporary workspace directory
5. Steps execute in ORDER:
   - Each `uses:` step downloads the action from GitHub marketplace
   - Each `run:` step executes in a new shell process
     (shell state does NOT persist between run: steps by default)
6. On job completion:
   - Artifacts are uploaded to GitHub
   - Cache is saved
   - Workspace is cleaned up
   - Runner marks itself available for next job
```

**Critical: shell state between steps**
```yaml
# WRONG: variable set in one step is gone in the next
steps:
  - run: MY_VAR="hello"
  - run: echo $MY_VAR    # prints nothing — new shell process

# RIGHT: use GITHUB_ENV for cross-step env vars
steps:
  - run: echo "MY_VAR=hello" >> $GITHUB_ENV
  - run: echo $MY_VAR    # prints "hello"

# RIGHT: use GITHUB_OUTPUT for job outputs
steps:
  - id: compute
    run: echo "result=42" >> $GITHUB_OUTPUT
  - run: echo ${{ steps.compute.outputs.result }}   # prints 42
```
