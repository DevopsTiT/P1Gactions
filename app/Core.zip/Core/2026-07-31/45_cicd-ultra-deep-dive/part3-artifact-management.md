# Part 3 — Artifact Management: Deep Dive

---

## What Is an Artifact and Why It Matters

An artifact is the OUTPUT of a build process — the deployable thing your pipeline produces.

```
Source Code (input)
      │
      ▼ compile, package, containerize
      │
Artifact (output): one of:
  - Java:     target/myapp-1.0.0.jar     (executable JAR)
  - Docker:   ghcr.io/myorg/myapp:sha-abc123  (container image)
  - npm:      @myorg/shared-lib@1.0.0    (npm package)
  - Python:   myapp-1.0.0.tar.gz         (wheel/sdist)
  - Helm:     myapp-1.0.0.tgz            (Helm chart)
  - Terraform: plan.tfplan               (plan file)
```

**Key principle:** Build the artifact ONCE, deploy it MANY times.

```
WRONG:
  Build for DEV → test in DEV
  Build AGAIN for staging → test in staging
  Build AGAIN for prod → deploy to prod
  
  Problem: each build could produce slightly different output
           if a dependency version changed between builds
           "It worked in staging!" but staging artifact ≠ prod artifact

CORRECT:
  Build ONCE → produces artifact with ID: sha-abc123
  Test sha-abc123 in DEV
  Test sha-abc123 in staging
  Deploy sha-abc123 to prod
  
  Guarantee: exactly the same bytes that passed all tests go to prod
```

---

## Container Images: The Universal Artifact

For microservices, Docker images are the de-facto artifact format. They bundle: code + runtime + OS libraries + config. "Works on my machine" becomes "works anywhere Docker runs."

### Image Tagging Strategy

Every image needs a tag (human-readable name) AND a digest (immutable hash).

```
Tag formats and when to use each:

sha-{commit}:     ghcr.io/myorg/checkout:sha-a1b2c3d4
  → Points to exact commit that built this image
  → IMMUTABLE: once built from commit a1b2c3d, always the same
  → USE FOR: production deployments (always know what's deployed)

{branch}:         ghcr.io/myorg/checkout:main
  → Points to latest build from this branch
  → MUTABLE: changes every push to main
  → USE FOR: staging environments (always latest main)

{semver}:         ghcr.io/myorg/checkout:v1.2.3
  → Semantic version tag
  → Conventionally immutable (don't overwrite released versions)
  → USE FOR: versioned releases, Helm chart dependencies

latest:           ghcr.io/myorg/checkout:latest
  → Mutable, always the most recent build
  → USE FOR: local development only
  → NEVER USE IN PRODUCTION: "latest" today ≠ "latest" tomorrow
```

### Image Digest: The Immutable Truth

```
Tag:    ghcr.io/myorg/checkout:sha-abc123
        ↑ can be overwritten (someone could push a different image with same tag)

Digest: ghcr.io/myorg/checkout@sha256:8f4b5a3c2d1e9f7a6b8c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a
        ↑ cryptographic hash of the image content
        ↑ CANNOT be overwritten — changing the image changes the hash
        ↑ ALWAYS refers to exactly the same image bytes
```

```yaml
# In pipelines: use digest for security-critical deployments
- name: Build and push
  id: build
  uses: docker/build-push-action@v5
  with:
    push: true
    tags: ghcr.io/myorg/checkout:sha-${{ github.sha }}

# Deploy by digest, not tag
- name: Deploy
  run: |
    DIGEST="${{ steps.build.outputs.digest }}"
    helm upgrade --install checkout ./charts \
      --set image.repository=ghcr.io/myorg/checkout \
      --set image.digest=$DIGEST
    # Kubernetes manifest will have:
    # image: ghcr.io/myorg/checkout@sha256:abc123...
    # This CANNOT be tampered with after signing
```

---

## Artifact Registry Deep Dive

### GitHub Container Registry (ghcr.io)

```yaml
# Login to ghcr.io using GITHUB_TOKEN (no separate secret needed)
- name: Login to GitHub Container Registry
  uses: docker/login-action@v3
  with:
    registry: ghcr.io
    username: ${{ github.actor }}
    password: ${{ secrets.GITHUB_TOKEN }}

# Push image
- name: Build and push
  uses: docker/build-push-action@v5
  with:
    context: .
    push: true
    tags: |
      ghcr.io/${{ github.repository }}:sha-${{ github.sha }}
      ghcr.io/${{ github.repository }}:latest

# Pull image (authenticated)
docker pull ghcr.io/myorg/checkout:sha-abc123
```

**GHCR visibility:**
```
Private repo → image is private by default
Public repo  → image is public by default

Change visibility:
  Package settings → Change visibility
  Or set in workflow:
  LABEL org.opencontainers.image.source=https://github.com/myorg/checkout
```

### AWS ECR (Elastic Container Registry)

```yaml
- name: Configure AWS credentials
  uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789012:role/GitHubActionsRole
    aws-region: ap-northeast-1

- name: Login to ECR
  id: login-ecr
  uses: aws-actions/amazon-ecr-login@v2

- name: Build and push to ECR
  env:
    REGISTRY: ${{ steps.login-ecr.outputs.registry }}
    REPO: checkout-service
    TAG: ${{ github.sha }}
  run: |
    docker build -t $REGISTRY/$REPO:$TAG .
    docker push $REGISTRY/$REPO:$TAG
    # ECR URL format: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/checkout-service:abc123
```

**ECR lifecycle policy (auto-cleanup old images):**
```json
{
  "rules": [{
    "rulePriority": 1,
    "description": "Keep only last 20 images",
    "selection": {
      "tagStatus": "tagged",
      "tagPrefixList": ["sha-"],
      "countType": "imageCountMoreThan",
      "countNumber": 20
    },
    "action": { "type": "expire" }
  }, {
    "rulePriority": 2,
    "description": "Remove untagged images after 1 day",
    "selection": {
      "tagStatus": "untagged",
      "countType": "sinceImagePushed",
      "countUnit": "days",
      "countNumber": 1
    },
    "action": { "type": "expire" }
  }]
}
```

**Why lifecycle policies matter:** Without them, ECR fills up with thousands of old images. At $0.10/GB/month, 100 images × 500MB = $5/month in storage. After 2 years, 2000+ images = $100+/month for images nobody uses.

---

## GitHub Actions Artifacts: Passing Files Between Jobs

GitHub Actions artifacts are files stored temporarily (up to 90 days) by GitHub. Used to:
1. Pass files between jobs (jobs run on different machines)
2. Download for debugging failed builds
3. Archive test reports, security scan results

```yaml
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - run: mvn package -DskipTests
      
      - name: Upload JAR artifact
        uses: actions/upload-artifact@v4
        with:
          name: app-jar                    # artifact name
          path: target/myapp-*.jar         # what to upload
          retention-days: 5               # auto-delete after 5 days
          if-no-files-found: error        # fail if JAR wasn't built

  integration-test:
    needs: build
    runs-on: ubuntu-latest
    steps:
      - name: Download JAR
        uses: actions/download-artifact@v4
        with:
          name: app-jar
          path: target/                    # download to this directory
      
      - run: java -jar target/myapp-*.jar &
      - run: mvn verify -Pintegration-tests
  
  publish-test-results:
    needs: [integration-test]
    runs-on: ubuntu-latest
    if: always()    # run even if tests failed (to see results)
    steps:
      - uses: actions/download-artifact@v4
        with:
          name: test-results
          path: test-results/
      - uses: dorny/test-reporter@v1
        with:
          path: test-results/**/*.xml
          reporter: java-junit
```

---

## Artifact Versioning: Semantic Versioning

For libraries and versioned releases, artifacts need predictable version numbers.

### Semantic Versioning (SemVer)

```
Format: MAJOR.MINOR.PATCH   example: 2.4.1

MAJOR: breaking change (old clients WILL break)
MINOR: new feature, backward compatible (old clients still work)
PATCH: bug fix, backward compatible

Pre-release: 2.4.1-alpha.1, 2.4.1-rc.2
Build metadata: 2.4.1+build.42 (not comparable, informational)
```

### Automated Version Bumping

```yaml
# Semantic Release: analyzes commit messages to determine version bump
# Commit message format (Conventional Commits):
# feat: add payment retry logic        → bumps MINOR (1.0.0 → 1.1.0)
# fix: handle null user in checkout    → bumps PATCH  (1.1.0 → 1.1.1)
# feat!: redesign checkout API         → bumps MAJOR  (1.1.1 → 2.0.0)

- name: Release
  uses: cycjimmy/semantic-release-action@v4
  env:
    GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
    NPM_TOKEN: ${{ secrets.NPM_TOKEN }}
  with:
    branches: |
      ["main"]
    extra_plugins: |
      @semantic-release/changelog
      @semantic-release/git
```

**What Semantic Release does automatically:**
1. Reads all commits since last release
2. Determines version bump type from commit messages
3. Updates version in `pom.xml` / `package.json`
4. Generates `CHANGELOG.md`
5. Creates GitHub Release
6. Tags the commit (`v2.4.1`)
7. Publishes to npm/Maven

---

## Dependency Management: Keeping Dependencies Fresh

### Automated Updates with Dependabot

```yaml
# .github/dependabot.yml
version: 2
updates:
  # Update Maven dependencies
  - package-ecosystem: maven
    directory: "/"
    schedule:
      interval: weekly
      day: monday
      time: "09:00"
    open-pull-requests-limit: 10
    labels:
      - "dependencies"
    ignore:
      - dependency-name: "org.springframework.boot"
        versions: ["3.x"]    # only update patch versions of Spring Boot

  # Update Docker base images
  - package-ecosystem: docker
    directory: "/"
    schedule:
      interval: weekly
    labels:
      - "dependencies"
      - "docker"

  # Update GitHub Actions
  - package-ecosystem: github-actions
    directory: "/"
    schedule:
      interval: weekly
```

**What Dependabot does:**
```
Monday morning:
  → Scans pom.xml for outdated dependencies
  → Opens a PR: "Bump spring-core from 6.0.11 to 6.0.14"
  → CI runs on the PR automatically
  → If CI passes: you review and merge
  → If CI fails: new version broke something
```

**Auto-merge safe dependencies:**
```yaml
# .github/workflows/auto-merge-dependabot.yml
on:
  pull_request:
    types: [opened, synchronize]

jobs:
  auto-merge:
    runs-on: ubuntu-latest
    if: github.actor == 'dependabot[bot]'
    permissions:
      contents: write
      pull-requests: write
    steps:
      - name: Get Dependabot metadata
        id: metadata
        uses: dependabot/fetch-metadata@v1

      - name: Auto-merge patch updates
        if: |
          steps.metadata.outputs.update-type == 'version-update:semver-patch'
          && steps.metadata.outputs.dependency-type == 'direct:development'
        run: gh pr merge --auto --squash "$PR_URL"
        env:
          PR_URL: ${{ github.event.pull_request.html_url }}
          GH_TOKEN: ${{ secrets.GITHUB_TOKEN }}
```

Auto-merge PATCH updates for dev dependencies (test libraries, linters) — these are low risk. Always review MINOR and MAJOR updates manually.

---

## Build Reproducibility: Same Input → Same Output

Reproducible builds ensure that building the same source code twice produces identical artifacts.

```
Why it matters:
  Audit: "What EXACTLY is in the binary running in production?"
  Security: If someone compromised your build, you can detect it
            by rebuilding from source and comparing digests
  Debugging: Eliminates "the build is different from dev to CI"

Common sources of non-reproducibility:
  1. Timestamp in jar/metadata:  SNAPSHOT-20260731.jar (changes each build)
  2. Non-deterministic Map iteration in generated code
  3. Random build order of parallel tasks
  4. Dependency version ranges: <version>[1.0,2.0)</version> → picks latest
  5. External resource fetched at build time (latest = different tomorrow)
```

```yaml
# Pin ALL dependency versions (no ranges, no LATEST)
# pom.xml:
<dependency>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-web</artifactId>
  <version>3.1.5</version>    <!-- exact version, never a range -->
</dependency>

# Lock dependency resolution:
mvn dependency:resolve     # records exact transitive deps
mvn versions:lock-snapshots # replace SNAPSHOT with timestamped version

# Verify reproducibility:
mvn clean package           # build once
cp target/myapp.jar /tmp/build1.jar
mvn clean package           # build again
sha256sum target/myapp.jar /tmp/build1.jar
# Both hashes should be identical
```
