# Common Terraform Errors with Microservices — Deep Dive
## Every Error, Why It Happens, How to Fix It

> Context: Java Spring Boot microservices on AWS EKS, using Terraform for:
> EKS cluster, VPC, IAM roles, Dynatrace monitoring config, and secrets management.
> Errors are grouped by category with exact error messages, root causes, and fixes.

---

## Decision Tree — First Steps When Terraform Errors

```
terraform plan or apply fails:
         │
         ▼
Is it a SYNTAX error? (HCL parsing failed)
  → Error appears BEFORE any API calls
  → Fix: check variable types, missing quotes, wrong block structure
         │
         ▼
Is it a PROVIDER error? (API call failed)
  → Error appears DURING plan or apply
  → Check: credentials, permissions, provider version, API limits
         │
         ▼
Is it a STATE error? (state file mismatch)
  → "Resource already exists" or "Resource not found in state"
  → Fix: terraform import OR terraform state rm
         │
         ▼
Is it a DEPENDENCY error? (resources created in wrong order)
  → "X depends on Y which doesn't exist yet"
  → Fix: add depends_on or restructure resource references
         │
         ▼
Is it a LOCK error? (concurrent apply)
  → "Error acquiring the state lock"
  → Fix: wait for the other apply to finish OR force-unlock (with care)
```

---

## Category 1 — State File Errors

### Error 1.1: "Error acquiring the state lock"

```
Error: Error acquiring the state lock

Error message: ConditionalCheckFailedException: The conditional request failed
Lock Info:
  ID:        3d3c8f4a-1234-abcd-5678-abc123def456
  Path:      company-terraform-state-prod/production/terraform.tfstate
  Operation: OperationTypeApply
  Who:       github-actions@runner-123
  Created:   2026-07-31 14:32:05
```

**Why it happens:**
```
Terraform uses a DynamoDB table (terraform-state-lock) to prevent two simultaneous applies.
If a previous terraform apply:
  a) Crashed mid-run (CI runner timed out)
  b) Was force-killed
  c) Lost network connectivity

The lock was never released. DynamoDB still has the lock entry.
Any subsequent apply sees the lock and refuses to start.
```

**Fix:**
```bash
# Step 1: Verify the lock is actually stale (the previous run is NOT still running)
# Check CI: is there actually a running job that holds the lock?
# If YES: wait for it to finish. Do NOT force-unlock a live apply.

# Step 2: If the previous run is genuinely dead, force-unlock:
terraform force-unlock 3d3c8f4a-1234-abcd-5678-abc123def456
# The ID comes from the error message above.

# Step 3: Verify the state is not corrupted before applying again:
terraform plan
```

**Prevention:**
```hcl
# In backend config: ensure DynamoDB table exists
backend "s3" {
  bucket         = "company-terraform-state-prod"
  key            = "production/terraform.tfstate"
  region         = "ap-northeast-1"
  encrypt        = true
  dynamodb_table = "terraform-state-lock"  ← this table must exist
}
```

---

### Error 1.2: "Resource already exists"

```
Error: creating EKS Cluster (company-prod): ResourceInUseException:
Cluster already exists with name: company-prod
```

**Why it happens:**
```
Terraform has NO record of this resource in its state file,
but the resource ALREADY EXISTS in AWS.

This happens when:
  a) Someone created the resource manually (AWS console/CLI)
  b) A previous terraform apply created it but the state file was lost
  c) You recreated the state file from scratch (terraform init on a new backend)
  d) The resource was created by a different Terraform workspace
```

**Fix:**
```bash
# Import the existing resource into Terraform state:
terraform import aws_eks_cluster.main company-prod

# After import: run terraform plan
# Terraform will show the diff between its config and the real resource.
# If the diff shows Terraform wants to CHANGE something:
#   → Adjust your .tf file to match the real resource's current config
#   → Run terraform plan again until you see "No changes."
# If no diff: the import is clean.

# General import syntax:
terraform import <resource_type>.<resource_name> <real_resource_id>

# Examples:
terraform import aws_s3_bucket.state_bucket company-terraform-state-prod
terraform import aws_iam_role.eso_role company-dev-eso
terraform import aws_vpc.main vpc-0abc1234def56789
```

**Prevention:**
```
NEVER create resources manually in AWS if Terraform manages them.
If you must create something manually in an emergency:
  1. Create it manually (to fix the incident)
  2. Immediately run terraform import to add it to state
  3. Update the .tf file to match what you created
  4. Never create manually again without importing
```

---

### Error 1.3: "Resource not found" during destroy

```
Error: deleting IAM Role (company-dev-payment-service):
NoSuchEntityException: The role with name company-dev-payment-service cannot be found.
```

**Why it happens:**
```
Terraform's state file says this IAM role exists.
The real AWS account does NOT have it (someone deleted it manually).
Terraform tries to delete it → AWS says "doesn't exist" → error.
```

**Fix:**
```bash
# Remove the stale state entry (tells Terraform to "forget" this resource):
terraform state rm aws_iam_role.payment_service

# After removing from state: terraform plan shows "+ create" for this resource.
# Decide: do you want to recreate it? If yes: terraform apply.
# If not: remove it from your .tf file too.

# List all resources in state (useful to audit):
terraform state list

# Show full state for a specific resource:
terraform state show aws_iam_role.payment_service
```

---

### Error 1.4: State file corruption / outdated state

```
Error: Provider produced inconsistent result after apply.
When applying changes to aws_eks_node_group.system,
provider "hashicorp/aws" produced an unexpected new value.
```

**Why it happens:**
```
The provider returned a different value than Terraform expected.
Often caused by:
  a) AWS API returned extra/different fields than the Terraform provider version expects
  b) State file was manually edited incorrectly
  c) Provider version was upgraded with breaking changes
```

**Fix:**
```bash
# Step 1: Refresh state (re-reads current real state from AWS):
terraform apply -refresh-only

# Step 2: If still broken, check provider version constraint:
# In your .tf file:
terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.50"  # ← check this matches your actual provider version
    }
  }
}

# Step 3: Check provider changelog for breaking changes between versions.
# Downgrade provider if needed:
# In .terraform.lock.hcl — pin to a specific known-good version.
```

---

## Category 2 — Authentication / Permission Errors

### Error 2.1: "No valid credential sources found"

```
Error: No valid credential sources found for AWS Provider.
Please see https://www.terraform.io/docs/providers/aws/index.html for more information.
```

**Why it happens:**
```
Terraform cannot find AWS credentials. Checks in order:
  1. Environment variables: AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY
  2. ~/.aws/credentials file
  3. IAM role on the EC2/ECS/Lambda instance
  4. Web Identity Token (OIDC — used in GitHub Actions)

In CI (GitHub Actions): OIDC is configured but:
  - permissions: id-token: write is missing from the job
  - aws-actions/configure-aws-credentials step is missing
  - Role trust policy doesn't allow this GitHub repo/branch
```

**Fix for GitHub Actions:**
```yaml
jobs:
  apply:
    permissions:
      id-token: write    ← REQUIRED for OIDC
      contents: read
    steps:
      - uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/github-actions-terraform-apply
          aws-region: ap-northeast-1
```

**Fix for local development:**
```bash
# Configure AWS CLI profile:
aws configure --profile company-dev
# Enter: Access Key ID, Secret Access Key, region

# Use the profile in Terraform:
export AWS_PROFILE=company-dev
terraform plan

# OR set env vars directly:
export AWS_ACCESS_KEY_ID=AKIA...
export AWS_SECRET_ACCESS_KEY=...
export AWS_DEFAULT_REGION=ap-northeast-1
```

---

### Error 2.2: "AccessDenied" / insufficient permissions

```
Error: creating EKS Node Group (company-prod:system):
AccessDeniedException: User: arn:aws:sts::123456789012:assumed-role/
github-actions-terraform-plan/session is not authorized to perform:
eks:CreateNodegroup on resource: arn:aws:eks:ap-northeast-1:123456789012:cluster/company-prod
```

**Why it happens:**
```
The IAM role being used (github-actions-terraform-plan) does NOT have
permission to call eks:CreateNodegroup.

Common microservices Terraform causes:
  - Plan role used instead of apply role (plan role is read-only)
  - Missing permissions in the IAM policy attached to the role
  - Resource ARN in the IAM policy doesn't match (wrong region, wrong account)
  - Service Control Policy (SCP) at the AWS Organization level blocks it
```

**Fix:**
```bash
# Step 1: Identify which role is being used:
aws sts get-caller-identity

# Step 2: Check what the role's policies allow:
aws iam list-attached-role-policies --role-name github-actions-terraform-apply
aws iam get-policy-document --policy-arn <arn>

# Step 3: Add the missing permission to the IAM policy.
# Example Terraform IAM policy fix:
```

```hcl
resource "aws_iam_policy" "terraform_apply" {
  name = "github-actions-terraform-apply-policy"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = [
          "eks:CreateCluster",
          "eks:CreateNodegroup",     # ← was missing
          "eks:DescribeCluster",
          "eks:UpdateNodegroupConfig",
          # ... other required eks: actions
        ]
        Resource = "*"
      }
    ]
  })
}
```

---

### Error 2.3: "Error assuming IAM role" (OIDC)

```
Error: error configuring Terraform AWS Provider:
error validating provider credentials: error calling sts:GetCallerIdentity:
operation error STS: GetCallerIdentity: https response error StatusCode: 403
```

**Why it happens:**
```
The GitHub Actions OIDC token was rejected by AWS STS.
Root causes:
  a) The role's trust policy has the wrong GitHub repo or branch
  b) The role's trust policy uses the wrong OIDC provider ARN
  c) The OIDC provider is not registered in this AWS account
```

**Fix:**
```hcl
# Correct trust policy for GitHub Actions OIDC:
resource "aws_iam_role" "github_actions_apply" {
  name = "github-actions-terraform-apply"
  
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Federated = "arn:aws:iam::123456789012:oidc-provider/token.actions.githubusercontent.com"
        #                ↑ must be YOUR account ID
      }
      Action = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "token.actions.githubusercontent.com:aud" = "sts.amazonaws.com"
        }
        StringLike = {
          "token.actions.githubusercontent.com:sub" = 
            "repo:company/java-3envs-dynatrace:ref:refs/heads/main"
            #        ↑ exact repo name   ↑ exact branch
        }
      }
    }]
  })
}
```

```bash
# Check if OIDC provider is registered in the account:
aws iam list-open-id-connect-providers

# If missing, create it:
aws iam create-open-id-connect-provider \
  --url https://token.actions.githubusercontent.com \
  --thumbprint-list "6938fd4d98bab03faadb97b34396831e3780aea1" \
  --client-id-list sts.amazonaws.com
```

---

## Category 3 — Provider and API Errors

### Error 3.1: "Provider version constraint" mismatch

```
Error: Failed to query available provider packages

Could not retrieve the list of available versions for provider
dynatrace-oss/dynatrace: no available releases match the given
constraints ~> 1.55; latest is 1.54.0
```

**Why it happens:**
```
Your version constraint (~> 1.55) requires version 1.55 or higher.
But the provider registry only has up to 1.54.0.

OR: the constraint is too strict and doesn't allow the available version.
```

**Fix:**
```hcl
# Option A: Relax the constraint to match what's available:
terraform {
  required_providers {
    dynatrace = {
      source  = "dynatrace-oss/dynatrace"
      version = "~> 1.54"  # now allows 1.54.x
    }
  }
}

# Option B: Wait for the new version to be released, or pin to exact:
version = "= 1.54.0"  # exact pin

# After changing: re-initialize:
terraform init -upgrade
```

---

### Error 3.2: "API rate limiting"

```
Error: creating Dynatrace MetricEvents (payment-service-traffic):
error: 429 Too Many Requests: API rate limit exceeded.
Retry after: 60 seconds
```

**Why it happens:**
```
When creating many resources simultaneously (e.g., 8 metric events × 3 services = 24 resources),
Terraform sends all API calls in parallel. The DT API has a rate limit.
Also common with AWS APIs during large-scale EKS + IAM + VPC creation.
```

**Fix:**
```hcl
# Option A: Add parallelism limit to terraform apply:
# terraform apply -parallelism=5
# (default is 10 — lower means fewer concurrent API calls)

# Option B: Add explicit retry logic in provider config (Dynatrace example):
provider "dynatrace" {
  dt_env_url   = var.dt_env_url
  dt_api_token = var.dt_api_token
  # Some providers support retry settings — check provider docs
}

# Option C: Split resources into smaller apply batches using -target:
terraform apply -target='dynatrace_metric_events.traffic_drop'
terraform apply -target='dynatrace_metric_events.error_rate'
# (not recommended for production — use -target only for debugging)
```

**For AWS specifically:**
```bash
# AWS API errors: usually self-resolve. Retry the apply:
terraform apply

# If persistent: check AWS Service Health Dashboard for ongoing issues.
# Some resources (VPC, EKS) have eventual consistency delays — wait and retry.
```

---

### Error 3.3: "Provider not initialized"

```
Error: Could not load plugin

Plugin reinitialization required. Please run "terraform init".

Reason: Recorded legacy provider addresses were removed from .terraform/providers
```

**Why it happens:**
```
.terraform/providers directory is missing or was deleted.
The .terraform.lock.hcl file references provider versions not downloaded yet.
Happens when:
  a) Running terraform plan/apply in a fresh environment (CI without cache)
  b) Someone deleted the .terraform directory
  c) Running after git clone without running terraform init first
```

**Fix:**
```bash
# Always run init before plan/apply:
terraform init

# In CI: cache the .terraform/providers directory between runs:
# GitHub Actions example:
- uses: actions/cache@v4
  with:
    path: |
      .terraform/providers
      .terraform.lock.hcl
    key: terraform-${{ hashFiles('**/.terraform.lock.hcl') }}
```

---

## Category 4 — Resource Configuration Errors

### Error 4.1: "Invalid value for variable" — type mismatch

```
Error: Invalid value for input variable

The argument "services" has a type error: object({...}) does not match
expected type: attribute "latency_p99_ms" is required but not set
```

**Why it happens:**
```
The services map in environments/production/main.tf is missing a required field.
The module's variables.tf defines a strict object type — ALL fields are required.

Example: You added a new field (gc_pause_slo) to variables.tf but forgot to add it
to one of the environment callers.
```

**Fix:**
```hcl
# variables.tf defines:
variable "services" {
  type = map(object({
    team            = string
    slo_target      = number
    latency_p99_ms  = number
    gc_pause_slo    = number   # ← NEW field added here
  }))
}

# environments/production/main.tf must have ALL fields:
services = {
  "payment-service" = {
    team           = "payments"
    slo_target     = 99.9
    latency_p99_ms = 300
    gc_pause_slo   = 99.5   # ← must add this too
  }
}

# If field is optional, use default in variables.tf:
variable "services" {
  type = map(object({
    latency_p99_ms = number
    gc_pause_slo   = optional(number, 99.5)   # optional with default
  }))
}
```

---

### Error 4.2: "for_each set cannot contain null values"

```
Error: Invalid for_each argument

The "for_each" map includes keys derived from resource attributes that
cannot be determined until apply: pagerduty_integration_keys.
```

**Why it happens:**
```
for_each must know all its keys at PLAN time.
If the keys come from a resource that doesn't exist yet,
Terraform can't enumerate them during planning.

In our project: if pagerduty_integration_keys comes from a data source
that hasn't been applied yet, for_each can't resolve it at plan time.
```

**Fix:**
```hcl
# Option A: Use a hardcoded map (keys known at plan time):
pagerduty_integration_keys = {
  "payments"      = var.pd_key_payments
  "orders"        = var.pd_key_orders
  "notifications" = var.pd_key_notifications
}

# Option B: Use -target to apply the dependency first:
terraform apply -target=aws_secretsmanager_secret_version.pagerduty_keys
terraform apply  # full apply after the secret exists

# Option C: Use locals to ensure the map is fully resolved:
locals {
  pd_keys = jsondecode(
    data.aws_secretsmanager_secret_version.pagerduty_keys.secret_string
  )
}
# Then reference locals.pd_keys in for_each
```

---

### Error 4.3: "Cycle error" — circular dependency

```
Error: Cycle: aws_iam_role.eso, aws_iam_role_policy_attachment.eso_policy,
aws_eks_cluster.main
```

**Why it happens:**
```
Resource A depends on B, and B depends on A.
Example:
  EKS cluster needs the IAM role ARN to create.
  IAM role policy references the EKS cluster ARN.
  → A needs B, B needs A → cycle.
```

**Fix:**
```hcl
# Break the cycle by splitting resources.
# IAM role creation (no EKS reference needed here):
resource "aws_iam_role" "eso" {
  name = "company-dev-eso"
  assume_role_policy = data.aws_iam_policy_document.eso_assume.json
  # ← do NOT reference eks cluster here
}

# Attach policy AFTER cluster exists (separate resource):
resource "aws_iam_role_policy_attachment" "eso_policy" {
  role       = aws_iam_role.eso.name
  policy_arn = aws_iam_policy.eso.arn
  # depends_on implicitly created via reference
}

# EKS cluster references role (not the other way around):
resource "aws_eks_cluster" "main" {
  role_arn = aws_iam_role.cluster.arn  # ← cluster role, not eso role
}
```

---

### Error 4.4: "Error: Invalid template interpolation"

```
Error: Invalid template interpolation value

The operator "${each.value.latency_p99_ms * 1000}" is not valid.
Arithmetic in string templates requires explicit tostring().
```

**Why it happens:**
```
Terraform HCL doesn't support arithmetic inside "${...}" string templates.
${each.value.latency_p99_ms * 1000} is trying to multiply inside interpolation.
```

**Fix:**
```hcl
# Wrong:
threshold = "${each.value.latency_p99_ms * 1000}"

# Correct: arithmetic outside the string, in a numeric context:
threshold = each.value.latency_p99_ms * 1000

# If you need it as a string inside another string:
summary = "[PROD] ${each.key}: P99 latency >${each.value.latency_p99_ms}ms"
# The * 1000 conversion is done in the threshold NUMBER field, not the string
```

---

### Error 4.5: "known after apply" in count/for_each

```
Error: Invalid count argument

The "count" value depends on resource attributes that cannot be determined
until apply. If you want to suppress this error, use the -target option to
create the dependency first.

  on main.tf line 23, in resource "aws_iam_role_policy_attachment" "payments":
  23:   count = length(aws_eks_cluster.main.vpc_config)
```

**Why it happens:**
```
count and for_each must be computable at PLAN time.
Using a value from another resource that doesn't exist yet = "known after apply" error.

In microservices: often happens when using an EKS cluster's output
(like OIDC issuer URL) in count or for_each for IAM resources.
```

**Fix:**
```hcl
# Wrong — uses a resource attribute in count/for_each:
resource "aws_iam_openid_connect_provider" "eks" {
  count = length(aws_eks_cluster.main.identity)  # ← unknown at plan time
}

# Correct — use a fixed value or locals:
resource "aws_iam_openid_connect_provider" "eks" {
  # Remove count entirely — it's always 1:
  url             = aws_eks_cluster.main.identity[0].oidc[0].issuer
  thumbprint_list = ["6938fd4d98bab03faadb97b34396831e3780aea1"]
  client_id_list  = ["sts.amazonaws.com"]
}

# Or: use a local that's computable from variables (not resource outputs):
locals {
  service_accounts = toset(keys(var.services))  # var.services is known at plan time
}
resource "aws_iam_role" "service" {
  for_each = local.service_accounts  # ← this works: derived from a variable
}
```

---

## Category 5 — Kubernetes / EKS-Specific Errors

### Error 5.1: "Unauthorized" when applying Kubernetes resources

```
Error: Unauthorized

with kubernetes_namespace.payment,
on main.tf line 45, in resource "kubernetes_namespace" "payment":

error: Unauthorized — the server requires authentication
```

**Why it happens:**
```
Terraform's Kubernetes provider cannot authenticate to the EKS cluster.
The kubeconfig being used is stale or the EKS cluster was just created
(the Kubernetes provider config referencing the EKS cluster isn't ready yet).
```

**Fix:**
```hcl
# Option A: Add depends_on so the cluster exists before K8s resources:
provider "kubernetes" {
  host                   = aws_eks_cluster.main.endpoint
  cluster_ca_certificate = base64decode(aws_eks_cluster.main.certificate_authority[0].data)
  token                  = data.aws_eks_cluster_auth.main.token
}

data "aws_eks_cluster_auth" "main" {
  name = aws_eks_cluster.main.name
}

# All Kubernetes resources implicitly depend on the cluster via provider config.

# Option B: Use exec for authentication (works with IRSA):
provider "kubernetes" {
  host                   = aws_eks_cluster.main.endpoint
  cluster_ca_certificate = base64decode(aws_eks_cluster.main.certificate_authority[0].data)
  exec {
    api_version = "client.authentication.k8s.io/v1beta1"
    args        = ["eks", "get-token", "--cluster-name", aws_eks_cluster.main.name]
    command     = "aws"
  }
}
```

---

### Error 5.2: EKS node group fails — "No capacity"

```
Error: error creating EKS Node Group (company-prod:system):
InvalidParameterException: Node group doesn't have a launch template
with the specified instance type. Details: No capacity for instance type
m7g.xlarge in availability zone ap-northeast-1b.
```

**Why it happens:**
```
AWS has insufficient capacity for the requested instance type in one AZ.
This is an AWS-side capacity issue, not a Terraform bug.
```

**Fix:**
```hcl
# Option A: Allow multiple instance types (Terraform selects available):
eks_managed_node_groups = {
  system = {
    instance_types = ["m7g.xlarge", "m6g.xlarge", "m5.xlarge"]
    # EKS picks the first one with available capacity
  }
}

# Option B: Change the specific AZ:
subnet_ids = [
  aws_subnet.private_a.id,  # ap-northeast-1a
  # aws_subnet.private_b.id,  # remove 1b if it has no capacity
  aws_subnet.private_c.id,  # ap-northeast-1c
]

# Option C: Use Karpenter instead of managed node groups
# (Karpenter handles instance-type fallback automatically)
```

---

### Error 5.3: "aws-auth ConfigMap" update failure

```
Error: error updating ConfigMap "aws-auth" in namespace "kube-system":
Operation cannot be fulfilled on configmaps "aws-auth":
the object has been modified; please apply your changes to the latest version
```

**Why it happens:**
```
The EKS aws-auth ConfigMap is being updated by multiple sources simultaneously:
  - Terraform (manage_aws_auth_configmap = true in EKS module)
  - Another Terraform apply running in parallel
  - kubectl apply by a developer
  - EKS itself (when adding a new node group)

This is a Kubernetes optimistic concurrency conflict.
```

**Fix:**
```bash
# Step 1: Check current state of aws-auth:
kubectl get configmap aws-auth -n kube-system -o yaml

# Step 2: Refresh Terraform state:
terraform refresh

# Step 3: Re-run apply (usually works on second attempt):
terraform apply

# Prevention: NEVER manually edit aws-auth if Terraform manages it.
# If you must add a role manually, do it via Terraform:
```

```hcl
module "eks" {
  # ...
  manage_aws_auth_configmap = true
  aws_auth_roles = [
    {
      rolearn  = "arn:aws:iam::123456789012:role/developer-role"
      username = "developer"
      groups   = ["system:masters"]
    }
  ]
}
```

---

## Category 6 — Module and Variable Errors

### Error 6.1: "Module not found"

```
Error: Module not found

No module call named "dynatrace" is defined in the root module.
```

**Why it happens:**
```
The module source path is wrong, OR terraform init was not run after
adding/changing a module source.
```

**Fix:**
```hcl
# Check module source path is correct (relative path):
module "dynatrace" {
  source = "../../modules/dynatrace"   # ← must be correct relative path
  # from: terraform/environments/dev/main.tf
  # to:   terraform/modules/dynatrace/
  # path: ../../modules/dynatrace   ← correct: up two levels, then into modules/dynatrace
}

# After fixing: always re-run init:
terraform init
```

---

### Error 6.2: "Variable not defined"

```
Error: Reference to undeclared input variable

  on main.tf line 44, in resource "dynatrace_metric_events" "traffic_drop":
  44:   threshold = var.services[each.key].latency_p99_ms

A variable named "latency_p99_ms" has not been declared in the root module.
```

**Why it happens:**
```
The services variable object type in variables.tf doesn't include this field.
You added latency_p99_ms to the environment caller (main.tf)
but forgot to declare it in the module's variables.tf.
```

**Fix:**
```hcl
# variables.tf — add the missing field to the object type:
variable "services" {
  type = map(object({
    team             = string
    slo_target       = number
    health_check_url = string
    latency_p99_ms   = number   # ← add this
    # ... all other fields
  }))
}
```

---

### Error 6.3: Sensitive value in output

```
Error: Output refers to sensitive values

  on main.tf line 89, in output "dt_api_token":
  89:   value = var.dt_api_token

To reduce the risk of accidentally exposing this value, Terraform requires
outputs that can be sensitive to be marked with sensitive = true.
```

**Fix:**
```hcl
output "dt_api_token" {
  value     = var.dt_api_token
  sensitive = true   # ← add this
}

# NOTE: Even with sensitive = true, the value IS in the state file.
# Ensure your S3 state bucket has:
#   - encryption enabled (encrypt = true in backend config)
#   - bucket policy blocking public access
#   - CloudTrail logging enabled
```

---

## Category 7 — The Most Dangerous Errors (Accidental Destruction)

### Error 7.1: Accidental resource replacement

```
Terraform will perform the following actions:

  # aws_eks_cluster.main must be replaced
-/+ resource "aws_eks_cluster" "main" {
      ~ name    = "company-prod"  # forces replacement
      ~ version = "1.28" -> "1.30"
    }

Plan: 1 to add, 0 to change, 1 to destroy.
```

**Why it happens:**
```
Changing certain EKS fields (like the Kubernetes version in some cases,
or the cluster name, or encryption config) FORCES a REPLACEMENT.
Replace = destroy the old resource FIRST, then create new one.
For an EKS cluster: this means destroying the entire cluster.
All workloads are deleted. The operation is IRREVERSIBLE.
```

**Prevention and fix:**
```hcl
# Step 1: Check terraform plan CAREFULLY before applying.
# Look for "-/+" lines — these mean replacement (destroy + create).
# "~" means in-place update (safe).
# "-/+" means replacement (DANGEROUS for stateful resources).

# Step 2: Use lifecycle to prevent accidental replacement:
resource "aws_eks_cluster" "main" {
  name    = var.cluster_name
  version = var.cluster_version

  lifecycle {
    prevent_destroy = true   # ← terraform apply will FAIL if Terraform tries to destroy this
  }
}

# Step 3: If you NEED to replace (intentional upgrade):
#   a) Remove prevent_destroy temporarily
#   b) Plan carefully
#   c) Drain all workloads first
#   d) Apply
#   e) Re-add prevent_destroy

# Step 4: For version upgrades that don't require replacement:
# EKS supports in-place version upgrades: change version = "1.30" → "~" not "-/+"
```

---

### Error 7.2: `terraform destroy` in the wrong environment

```
# Someone ran this in the wrong directory:
cd terraform/environments/production
terraform destroy

Destroy complete! Resources: 847 destroyed.
```

**Prevention:**
```hcl
# Add prevent_destroy to ALL critical resources in production:
resource "aws_eks_cluster" "main" {
  lifecycle { prevent_destroy = true }
}

resource "aws_vpc" "main" {
  lifecycle { prevent_destroy = true }
}

resource "aws_db_instance" "main" {
  lifecycle { prevent_destroy = true }
}
```

```yaml
# In GitHub Actions: production workflow requires manual approval:
jobs:
  apply:
    environment: production   # ← PAUSES for human approval
```

```bash
# Defensive practice: ALWAYS check which environment you're in:
cat backend.tf | grep key   # shows: key = "production/terraform.tfstate"
terraform workspace show    # shows: production

# BEFORE any destructive operation:
terraform plan -destroy    # shows what WOULD be destroyed without actually destroying
```

---

## Category 8 — Common Microservices-Specific Pattern Errors

### Error 8.1: Per-service resources colliding (duplicate names)

```
Error: creating IAM Role (company-dev-payment-service):
EntityAlreadyExists: Role with name company-dev-payment-service already exists.
```

**Why it happens:**
```
When creating per-service resources (IAM roles, SGs, etc.) using for_each,
if two services have the same team OR same name in different environments,
the generated resource name collides.
```

**Fix:**
```hcl
# Always include BOTH service name AND environment in resource names:
resource "aws_iam_role" "service" {
  for_each = var.services
  name     = "${var.environment}-${each.key}"   # "dev-payment-service"
  # NOT: name = each.key  ← same name in dev and production = collision
}
```

---

### Error 8.2: Environment variable not passed to module

```
Error: Unsupported argument

  on modules/dynatrace/main.tf line 40:
  40:   name = "${each.value}-${var.environment}"

An argument named "environment" is not expected here.
```

**Why it happens:**
```
The module uses var.environment but the caller (environment/dev/main.tf)
doesn't pass the environment variable to the module.
```

**Fix:**
```hcl
# environments/dev/main.tf — must pass environment:
module "dynatrace" {
  source      = "../../modules/dynatrace"
  environment = "dev"   # ← this must be here
  dt_env_url  = ...
  # ...
}
```

---

## Quick Diagnosis Cheat Sheet

```
ERROR MESSAGE                          → CATEGORY          → FIRST ACTION
─────────────────────────────────────────────────────────────────────────
"acquiring the state lock"             → State             → Check if CI job running; force-unlock if dead
"Resource already exists"              → State             → terraform import <resource> <id>
"Resource not found" (during destroy)  → State             → terraform state rm <resource>
"No valid credential sources"          → Auth              → Set AWS env vars or check OIDC config
"AccessDeniedException"                → Permissions       → Check IAM role policy for missing action
"Provider version constraint"          → Provider          → Change version constraint, terraform init -upgrade
"Invalid value for variable"           → Config            → Add missing field to variables.tf or caller
"for_each set cannot contain null"     → Config            → Hardcode keys or -target the dependency first
"Cycle"                                → Config            → Split the circular resources
"known after apply" in count/for_each  → Config            → Move from resource attribute to variable
"Unauthorized" (Kubernetes)            → EKS               → Fix provider auth config, check depends_on
"-/+ resource must be replaced"        → Destruction risk  → STOP: check if replacement is intentional
"prevent_destroy" blocks destroy       → Lifecycle guard   → Intentional: review before removing
```
