# Glossary + Troubleshooting Deep Dive — Terraform Microservices Errors

---

## PART A — Troubleshooting Deep Dive (Step-by-Step for Every Error Category)

---

### How to Troubleshoot ANY Terraform Error — The Universal Process

```
Step 1: READ THE FULL ERROR (not just the first line)
  Terraform errors have 3 parts:
    a) The error TYPE (line 1): "Error: AccessDeniedException"
    b) The LOCATION (line 2-3): "on main.tf line 44, resource X"
    c) The DETAIL (rest): the actual AWS/DT API error message

  Most engineers stop at the error type. The DETAIL is what tells you HOW to fix it.

Step 2: Add TF_LOG for more detail
  export TF_LOG=DEBUG
  terraform plan 2>&1 | tee /tmp/tf-debug.log
  grep "Error\|Warning\|Request\|Response" /tmp/tf-debug.log
  
  TF_LOG levels: ERROR < WARN < INFO < DEBUG < TRACE
  DEBUG: shows every API request/response (verbose but very useful)
  TRACE: shows everything including HTTP headers (overwhelming — use only for deep issues)

Step 3: Isolate the failing resource
  terraform plan -target=aws_eks_cluster.main
  # Plans ONLY that one resource — faster iteration

Step 4: Check state vs reality
  terraform plan -refresh-only
  # Compares what Terraform THINKS exists vs what AWS ACTUALLY has
  # If this shows changes: state is out of sync with reality

Step 5: Verify credentials independently
  aws sts get-caller-identity    # confirms which role/user Terraform is using
  aws eks describe-cluster --name company-prod   # direct AWS API call to verify access
```

---

### Troubleshooting: State Lock Errors

```bash
# STEP 1: Confirm the lock is real (not a false alarm):
aws dynamodb get-item \
  --table-name terraform-state-lock \
  --key '{"LockID": {"S": "company-terraform-state-prod/production/terraform.tfstate-md5"}}'

# Output: if Item is returned → lock exists in DynamoDB
# If no output → DynamoDB has no lock (state backend misconfigured)

# STEP 2: Check who holds the lock:
# The error message shows: Who: github-actions@runner-123
# Go to GitHub Actions → check if that run is still active.
# If active: WAIT. Do not force-unlock an active apply.
# If the job is done/failed/cancelled: the lock is stale → safe to unlock.

# STEP 3: Force-unlock (stale lock only):
terraform force-unlock <LOCK_ID>
# Lock ID is in the error message.

# STEP 4: Verify the state file is not corrupted:
aws s3 cp s3://company-terraform-state-prod/production/terraform.tfstate /tmp/state.json
cat /tmp/state.json | python3 -m json.tool > /dev/null && echo "valid JSON" || echo "CORRUPTED"

# STEP 5: If state is corrupted, restore from S3 versioning:
aws s3api list-object-versions \
  --bucket company-terraform-state-prod \
  --prefix production/terraform.tfstate \
  --query 'Versions[?!DeleteMarker].[VersionId,LastModified]' \
  --output table

# Restore a previous version:
aws s3api copy-object \
  --copy-source company-terraform-state-prod/production/terraform.tfstate?versionId=<VERSION_ID> \
  --bucket company-terraform-state-prod \
  --key production/terraform.tfstate
```

---

### Troubleshooting: Permission (AccessDenied) Errors

```bash
# STEP 1: Get the exact failing action from the error message:
# Error: User: arn:aws:sts::123456789012:assumed-role/role-name is not authorized
#         to perform: eks:CreateNodegroup on resource: arn:...

# Failing action = eks:CreateNodegroup
# Acting role = role-name

# STEP 2: Check what policies the role has:
aws iam list-attached-role-policies --role-name role-name
aws iam list-role-policies --role-name role-name   # inline policies

# STEP 3: Check each policy document for the missing action:
aws iam get-policy --policy-arn <arn>
aws iam get-policy-version --policy-arn <arn> --version-id v1

# STEP 4: Check for Service Control Policies (SCPs) blocking it:
# SCPs apply to the whole AWS account or OU — they override IAM policies.
aws organizations list-policies-for-target \
  --target-id <account-id> \
  --filter SERVICE_CONTROL_POLICY

# STEP 5: Use IAM Policy Simulator to test before changing:
aws iam simulate-principal-policy \
  --policy-source-arn arn:aws:iam::123456789012:role/role-name \
  --action-names eks:CreateNodegroup \
  --resource-arns arn:aws:eks:ap-northeast-1:123456789012:cluster/company-prod

# Output: "ALLOWED" or "IMPLICITLY_DENIED" or "EXPLICITLY_DENIED"
# EXPLICITLY_DENIED = SCP is blocking it (IAM policy alone won't fix it)

# STEP 6: Add the missing permission (in Terraform):
# Edit the IAM policy resource → add eks:CreateNodegroup → terraform apply
```

---

### Troubleshooting: "Resource Already Exists" (Import Workflow)

```bash
# STEP 1: Find the existing resource's ID in AWS:
# For EKS cluster:
aws eks list-clusters --region ap-northeast-1
# Output: {"clusters": ["company-prod"]}
# Resource ID = "company-prod"

# For IAM role:
aws iam get-role --role-name company-dev-payment-service
# Resource ID = "company-dev-payment-service"

# For VPC:
aws ec2 describe-vpcs --filters "Name=tag:Name,Values=company-dev"
# Resource ID = "vpc-0abc1234def56789"

# For S3 bucket:
aws s3api list-buckets | grep company
# Resource ID = "company-terraform-state-dev"

# STEP 2: Import the resource:
terraform import <resource_address> <resource_id>

# Examples:
terraform import aws_eks_cluster.main company-prod
terraform import aws_iam_role.eso company-dev-eso
terraform import aws_vpc.main vpc-0abc1234def56789
terraform import aws_s3_bucket.state company-terraform-state-dev
terraform import aws_dynamodb_table.lock terraform-state-lock

# For resources inside a module:
terraform import module.eks.aws_eks_cluster.main company-prod
#                 ↑ module prefix

# STEP 3: After import — check the diff:
terraform plan
# If changes shown: update your .tf config to match the real resource.
# If "No changes": import was clean.

# STEP 4: Commit the updated state (happens automatically — state file updated in S3).
```

---

### Troubleshooting: Module Variable Errors

```bash
# STEP 1: Validate syntax without connecting to APIs:
terraform validate
# This catches: type mismatches, undefined variables, syntax errors
# Does NOT need AWS credentials.

# STEP 2: Find which variable is causing the issue:
# The error message shows the line number in main.tf.
# Example: "on main.tf line 44, in resource ... : var.services[each.key].latency_p99_ms"

# Check what fields variables.tf declares:
grep -A 20 "variable \"services\"" variables.tf

# Check what fields the caller provides:
grep -A 50 '"payment-service"' environments/production/main.tf

# Find the missing field (in variables.tf but not in caller, or vice versa):
diff <(grep "= " variables.tf | grep -v "default\|description\|type" | sort) \
     <(grep "=" environments/production/main.tf | grep -v "module\|source" | sort)

# STEP 3: Fix by ensuring ALL fields in variables.tf object type
# are also provided in every service's map in every environment's main.tf.
```

---

### Troubleshooting: EKS / Kubernetes Provider Errors

```bash
# STEP 1: Verify EKS cluster is accessible:
aws eks update-kubeconfig --name company-prod --region ap-northeast-1
kubectl get nodes   # should show nodes if cluster is accessible

# STEP 2: Check the Kubernetes provider config in Terraform:
cat main.tf | grep -A 10 "provider \"kubernetes\""
# Verify: endpoint, cluster_ca_certificate, and token are all set correctly.

# STEP 3: Check if the aws-auth ConfigMap allows the Terraform role:
kubectl get configmap aws-auth -n kube-system -o yaml
# Look for the Terraform role ARN in mapRoles.

# STEP 4: If the Terraform role is NOT in aws-auth, add it:
# Option A: Run this one-time manually to bootstrap:
kubectl edit configmap aws-auth -n kube-system
# Add:
# - rolearn: arn:aws:iam::123456789012:role/github-actions-terraform-apply
#   username: terraform
#   groups:
#     - system:masters

# Option B: Use the EKS module's aws_auth_roles configuration in Terraform.

# STEP 5: Verify OIDC provider is set up for IRSA:
aws eks describe-cluster --name company-prod --query 'cluster.identity.oidc.issuer'
aws iam list-open-id-connect-providers
# The OIDC issuer from the cluster must exist as an IAM OIDC provider.
```

---

### Troubleshooting: Accidental Destroy Prevention

```bash
# STEP 1: BEFORE ANY APPLY — always check the plan for destroy:
terraform plan | grep -E "destroy|replace|must be replaced|-/\+"
# If output shows any of these: STOP and review carefully.

# STEP 2: To see ONLY what would be destroyed:
terraform plan -destroy | grep "will be destroyed\|must be replaced"

# STEP 3: Check if prevent_destroy is set on critical resources:
grep -r "prevent_destroy" terraform/
# If NOT set on EKS cluster, VPC, RDS: this is a risk.

# STEP 4: If you accidentally ran terraform destroy and resources are gone:
# a) For EKS cluster: recreate from Terraform (will be empty — workloads gone)
#    kubectl commands will NOT work until cluster recreated.
#    Run: terraform apply -target=module.eks
#    Then: kubectl apply -f gitops/production/bootstrap/root-app-production.yaml
#    ArgoCD will re-sync all resources from git.

# b) For S3 state bucket (worst case):
#    If S3 versioning was enabled: restore from previous version.
#    If not: state is gone. Must either manually import everything OR
#    rebuild from scratch using the .tf files.

# STEP 5: Post-incident — add protections:
# Enable S3 versioning for state buckets:
resource "aws_s3_bucket_versioning" "state" {
  bucket = aws_s3_bucket.terraform_state.id
  versioning_configuration { status = "Enabled" }
}

# Enable S3 MFA delete:
resource "aws_s3_bucket_versioning" "state" {
  versioning_configuration {
    status     = "Enabled"
    mfa_delete = "Enabled"   # requires MFA to delete versions
  }
}
```

---

### Troubleshooting: Drift Detection

```bash
# Drift = real AWS state differs from Terraform state.
# Detection command:
terraform plan -refresh-only -detailed-exitcode
# Exit code 0: no drift (state matches reality)
# Exit code 2: drift detected (state differs from reality)

# What causes drift in microservices:
# 1. Manual kubectl edit of a namespace or configmap
# 2. AWS Console change to a security group
# 3. AWS auto-scaling changed a node group min/max
# 4. EKS automatically updated an addon version

# When drift is detected:
terraform plan -refresh-only
# Shows: what CHANGED in reality vs what Terraform expects
# Decision: do you want to:
#   a) Accept the real state (terraform apply -refresh-only → updates state file)
#   b) Revert to Terraform config (terraform apply → applies your config over reality)

# For ongoing drift detection (automated):
# See the terraform-infra.yaml GitHub Actions workflow:
# schedule: cron: '0 2 * * *' → runs terraform plan -refresh-only every night
# If exit code 2: creates a GitHub Issue automatically
```

---

### Troubleshooting: CI/CD Pipeline Terraform Failures

```bash
# Common CI failure pattern: works locally, fails in CI.

# STEP 1: Check if terraform init was run in CI:
# GitHub Actions log: look for "Initializing the backend..."
# If missing: the init step failed or was skipped.

# STEP 2: Check if provider versions are locked:
cat .terraform.lock.hcl
# This file should be committed to git.
# If missing from the repo: CI always downloads random latest versions.

# STEP 3: Check AWS credential setup in CI:
# GitHub Actions log: look for "Assuming role..."
# If missing: the aws-actions/configure-aws-credentials step failed.

# STEP 4: Check working directory:
# Common mistake: forgetting working-directory in the workflow step.
- name: Terraform Plan
  working-directory: terraform/environments/production   # ← must be set
  run: terraform plan

# STEP 5: Check environment variables passed to Terraform:
# Terraform picks up env vars prefixed with TF_VAR_:
# TF_VAR_environment=production → var.environment = "production" in .tf files

# STEP 6: Read the full plan output in the PR comment.
# CI posts the plan as a PR comment.
# The full error is in the comment, not just the job log title.
```

---

## PART B — Glossary

---

**Terraform state file**
A JSON file (`terraform.tfstate`) that records what resources Terraform has created and their current configuration. Stored in S3 for team use. Why it matters: Terraform's "memory" — without it, Terraform doesn't know what resources exist and would try to recreate everything.

**State lock (DynamoDB)**
A DynamoDB item that prevents two simultaneous `terraform apply` runs from corrupting the same state file. Created at the start of apply, deleted at the end. Why it matters: prevents race conditions where two applies interfere with each other.

**`terraform force-unlock`**
Manually removes a stale state lock from DynamoDB. Use ONLY when the apply that set the lock is confirmed dead. Why it matters: a stale lock blocks all future applies until removed.

**`terraform import`**
Adds an existing real resource into Terraform's state file without creating it. `terraform import aws_eks_cluster.main company-prod`. Why it matters: the only way to bring manually-created resources under Terraform management.

**`terraform state rm`**
Removes a resource from the state file without deleting the real resource. Why it matters: used when a resource was deleted outside of Terraform and Terraform is now confused about its existence.

**`terraform state list`**
Lists all resources currently tracked in the state file. Why it matters: lets you audit what Terraform knows about and find orphaned or stale state entries.

**`terraform validate`**
Checks HCL syntax and variable type correctness without connecting to any API. Runs instantly. Why it matters: catches syntax errors and type mismatches before wasting time on a full plan.

**`terraform plan -refresh-only`**
Reads the current real state from AWS and updates the state file to match, without changing any real resources. Why it matters: the correct way to sync state when drift is detected.

**`terraform plan -destroy`**
Shows what would be destroyed by `terraform destroy` without actually destroying anything. Why it matters: always run this before destroy to understand the impact.

**`TF_LOG=DEBUG`**
Environment variable that makes Terraform print every API request and response. Why it matters: when an error message is cryptic, DEBUG mode shows the raw API call that failed, including the exact request body and error response.

**`-target` flag**
`terraform apply -target=aws_eks_cluster.main` — applies only the specified resource and its dependencies, ignoring everything else. Why it matters: useful for debugging one specific resource without touching the whole infrastructure.

**`-parallelism` flag**
`terraform apply -parallelism=5` — limits how many resources Terraform creates simultaneously (default: 10). Why it matters: prevents API rate limiting when creating many resources at once (DT API, AWS API).

**`prevent_destroy` lifecycle**
A Terraform lifecycle rule: `lifecycle { prevent_destroy = true }`. Makes `terraform apply` fail if Terraform tries to destroy this resource. Why it matters: safety net preventing accidental deletion of critical resources like EKS clusters, VPCs, RDS instances.

**`lifecycle` block**
A Terraform configuration block that controls resource behavior: `prevent_destroy`, `create_before_destroy`, `ignore_changes`. Why it matters: `create_before_destroy` on EKS node groups ensures the new group is healthy before the old one is removed.

**`ignore_changes`**
`lifecycle { ignore_changes = [version] }` — tells Terraform to ignore changes to specific attributes. Why it matters: for EKS node groups managed by Karpenter (auto-scaling changes instance counts), Terraform should ignore the count field to avoid fights with Karpenter.

**`-/+` in terraform plan**
"Must be replaced" — Terraform will DESTROY the resource and CREATE a new one. Different from `~` (in-place update). Why it matters: replacement of a stateful resource (EKS cluster, RDS) = data loss risk. Always review `-/+` lines carefully before applying.

**`~` in terraform plan**
In-place update — Terraform modifies the existing resource without destroying it. Safe for most operations. Why it matters: generally safe, but some in-place updates cause downtime (changing EKS cluster settings requires a control plane update).

**OIDC (GitHub Actions to AWS)**
GitHub generates a JWT token, AWS STS exchanges it for temporary IAM credentials. No static keys stored in GitHub Secrets. Why it matters: secure, auditable, auto-rotating credentials for CI/CD pipelines.

**Trust policy**
The IAM role configuration that says "who can assume this role." For GitHub Actions OIDC: allows `token.actions.githubusercontent.com` as the principal, scoped to a specific repo and branch. Why it matters: wrong trust policy = 403 when CI tries to assume the role.

**`aws sts get-caller-identity`**
AWS CLI command that shows which IAM user or role is currently authenticated. Why it matters: the first diagnostic step for any permission error — confirms Terraform is using the role you expect.

**`aws iam simulate-principal-policy`**
Tests whether a specific IAM role has permission to perform a specific action on a specific resource. Returns ALLOWED/DENIED. Why it matters: diagnose permission errors without needing to actually try the operation.

**Service Control Policy (SCP)**
An AWS Organizations policy that restricts what actions are allowed in an entire AWS account, regardless of IAM policies. SCPs override IAM — even if IAM allows it, an SCP can deny it. Why it matters: `EXPLICITLY_DENIED` in IAM simulator = SCP is blocking it, not the IAM policy.

**Drift**
When real AWS infrastructure diverges from what Terraform's state file expects. Caused by: manual changes, auto-scaling, AWS-managed upgrades, other tools. Why it matters: undetected drift means Terraform's next apply might overwrite a manual change you needed.

**`terraform plan -detailed-exitcode`**
Makes terraform plan return exit code 2 when changes are detected (vs 0 = no changes, 1 = error). Why it matters: used in CI/CD for automated drift detection: `if exit_code == 2: create_github_issue()`.

**`aws-auth` ConfigMap**
A Kubernetes ConfigMap in `kube-system` namespace that maps IAM roles/users to Kubernetes RBAC groups. Managed by EKS and optionally by Terraform. Why it matters: if the Terraform role isn't in aws-auth, Terraform can't create/manage Kubernetes resources even if it has EKS IAM permissions.

**`map(object({...}))` (Terraform type)**
A Terraform variable type requiring every map value to have exactly the specified fields. Adding a new field = every caller must provide it. Why it matters: enforces completeness — forgetting a threshold field causes a clear error at plan time, not a silent bug at runtime.

**`optional()` (Terraform type)**
`optional(number, 99.5)` inside an object type marks a field as not required, with a default value. Why it matters: allows adding new fields to the services map without breaking existing callers immediately.

**`for_each` vs `count`**
`for_each` creates named instances (addressable by key). `count` creates indexed instances. Why it matters: `for_each` is preferred for maps/sets — adding/removing a middle item doesn't renumber everything (which `count` would do, potentially destroying and recreating resources).

**`depends_on`**
Explicitly declares a dependency between resources when Terraform can't infer it from references. Why it matters: Kubernetes resources depend on the EKS cluster being ready — without `depends_on`, Terraform might try to create K8s namespaces before the cluster API is available.

**Circular dependency (cycle)**
Resource A references B, and B references A. Terraform cannot determine creation order. Why it matters: must be broken by separating the resources so the dependency flows in one direction only.

**`known after apply`**
A value that Terraform cannot determine at plan time because it depends on a resource that doesn't exist yet (its output is only known after creation). Why it matters: `count` and `for_each` cannot use "known after apply" values — they must be computable at plan time.

**S3 versioning (state backup)**
Keeping multiple versions of the state file in S3. Allows restoring a previous state if the current one is corrupted or a bad apply was run. Why it matters: the last resort when state is corrupted — you can restore to before the bad apply.

**`terraform init -upgrade`**
Re-initializes and upgrades provider versions to the latest that match constraints. Why it matters: after changing a version constraint in `required_providers`, you must run this to download the new version.
