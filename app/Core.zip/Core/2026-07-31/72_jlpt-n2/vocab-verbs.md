# JLPT N2 — Verbs (動詞)

---

## Group 1 — Action Verbs (High Frequency)

| Word | Reading | Meaning |
|---|---|---|
| 諦める | あきらめる | to give up, to abandon |
| 憧れる | あこがれる | to yearn for, to long for |
| 与える | あたえる | to give, to grant |
| 集める | あつめる | to collect, to gather |
| 当たる | あたる | to hit, to be correct |
| 扱う | あつかう | to handle, to deal with |
| 表れる | あらわれる | to appear, to show up |
| 表す | あらわす | to express, to show |
| 生かす | いかす | to make use of, to put to good use |
| 急ぐ | いそぐ | to hurry, to rush |
| 痛む | いたむ | to ache, to hurt |
| 祈る | いのる | to pray, to wish |
| 祝う | いわう | to celebrate |
| 植える | うえる | to plant |
| 失う | うしなう | to lose (something) |
| 疑う | うたがう | to doubt, to suspect |
| 移る | うつる | to move, to shift |
| 訴える | うったえる | to appeal, to sue |
| 産む | うむ | to give birth |
| 裏切る | うらぎる | to betray |
| 売り切れる | うりきれる | to sell out |
| 運ぶ | はこぶ | to carry, to transport |
| 得る | える | to get, to obtain |
| 選ぶ | えらぶ | to choose, to select |
| 送る | おくる | to send, to see off |
| 行う | おこなう | to perform, to carry out |
| 怒る | おこる | to get angry |
| 起こす | おこす | to wake up, to cause |
| 押さえる | おさえる | to hold down, to suppress |
| 治める | おさめる | to govern, to subdue |
| 収める | おさめる | to store, to put away |
| 落とす | おとす | to drop, to lose |
| 驚く | おどろく | to be surprised |
| 踊る | おどる | to dance |
| 思い出す | おもいだす | to recall, to remember |
| 終わらせる | おわらせる | to finish, to end (something) |
| 泳ぐ | およぐ | to swim |
| 折る | おる | to fold, to break |

---

## Group 2 — か行 Verbs

| Word | Reading | Meaning |
|---|---|---|
| 返す | かえす | to return (something) |
| 限る | かぎる | to limit, to restrict |
| 欠ける | かける | to lack, to be missing |
| 重なる | かさなる | to overlap, to pile up |
| 貸す | かす | to lend |
| 勝つ | かつ | to win |
| 悲しむ | かなしむ | to grieve, to be sad |
| 構う | かまう | to mind, to care about |
| 通う | かよう | to commute, to attend |
| 絡む | からむ | to be entangled with |
| 変わる | かわる | to change |
| 考える | かんがえる | to think, to consider |
| 感じる | かんじる | to feel, to sense |
| 関係する | かんけいする | to be related to |
| 頑張る | がんばる | to do one's best, to persist |
| 消える | きえる | to disappear |
| 聞こえる | きこえる | to be audible, to be heard |
| 傷つく | きずつく | to get hurt, to be wounded |
| 気づく | きづく | to notice, to realize |
| 決まる | きまる | to be decided |
| 決める | きめる | to decide |
| 断る | ことわる | to refuse, to decline |
| 困る | こまる | to be troubled, to have difficulty |
| 込む | こむ | to be crowded |
| 壊れる | こわれる | to break, to be broken |
| 壊す | こわす | to break, to destroy |

---

## Group 3 — さ行 Verbs

| Word | Reading | Meaning |
|---|---|---|
| 逆らう | さからう | to go against, to defy |
| 探す | さがす | to search for, to look for |
| 下がる | さがる | to fall, to drop, to go down |
| 避ける | さける | to avoid |
| 刺さる | ささる | to pierce, to stick into |
| 支える | ささえる | to support |
| 指す | さす | to point at |
| 叫ぶ | さけぶ | to shout, to scream |
| 触る | さわる | to touch |
| 似合う | にあう | to suit, to look good on |
| 沈む | しずむ | to sink, to set (sun) |
| 従う | したがう | to follow, to obey |
| 知らせる | しらせる | to inform, to notify |
| 調べる | しらべる | to investigate, to check |
| 信じる | しんじる | to believe |
| 捨てる | すてる | to throw away, to abandon |
| 過ぎる | すぎる | to pass, to exceed |
| 済む | すむ | to be completed, to finish |
| 進む | すすむ | to advance, to progress |
| 勧める | すすめる | to recommend, to encourage |
| 育てる | そだてる | to raise, to bring up |
| 揃える | そろえる | to arrange, to complete a set |
| 揃う | そろう | to be complete, to be in order |
| 存在する | そんざいする | to exist |

---

## Group 4 — た・な行 Verbs

| Word | Reading | Meaning |
|---|---|---|
| 倒れる | たおれる | to fall down, to collapse |
| 助ける | たすける | to help, to rescue |
| 頼む | たのむ | to request, to ask |
| 足りる | たりる | to be sufficient |
| 違う | ちがう | to differ, to be wrong |
| 近づく | ちかづく | to approach, to get close |
| 続く | つづく | to continue |
| 続ける | つづける | to continue (something) |
| 伝える | つたえる | to convey, to communicate |
| 努める | つとめる | to endeavour, to strive |
| 捕まえる | つかまえる | to catch, to seize |
| 積む | つむ | to pile up, to load |
| 釣る | つる | to fish, to catch fish |
| 溶ける | とける | to melt, to dissolve |
| 届く | とどく | to reach, to arrive |
| 取り替える | とりかえる | to replace, to exchange |
| 取り組む | とりくむ | to tackle, to work on |
| 成り立つ | なりたつ | to come into being, to consist of |
| 慣れる | なれる | to get used to |
| 認める | みとめる | to recognize, to admit |
| 逃げる | にげる | to flee, to escape |
| 握る | にぎる | to grasp, to hold |
| 似る | にる | to resemble |
| 縫う | ぬう | to sew |
| 盗む | ぬすむ | to steal |
| 眠る | ねむる | to sleep |
| 狙う | ねらう | to aim at, to target |

---

## Group 5 — は・ま行 Verbs

| Word | Reading | Meaning |
|---|---|---|
| 省く | はぶく | to omit, to save (effort) |
| 励ます | はげます | to encourage |
| 外れる | はずれる | to miss, to be off target |
| 始まる | はじまる | to begin |
| 離れる | はなれる | to separate, to move away |
| 払う | はらう | to pay, to sweep away |
| 反省する | はんせいする | to reflect on, to reconsider |
| 比較する | ひかくする | to compare |
| 引き受ける | ひきうける | to undertake, to take on |
| 引っ越す | ひっこす | to move (residence) |
| 増やす | ふやす | to increase |
| 増える | ふえる | to increase (intransitive) |
| 含む | ふくむ | to include, to contain |
| 触れる | ふれる | to touch, to mention |
| 保つ | たもつ | to maintain, to keep |
| 磨く | みがく | to polish, to brush |
| 迷う | まよう | to be lost, to hesitate |
| 守る | まもる | to protect, to keep (a promise) |
| 向かう | むかう | to face, to head towards |
| 向ける | むける | to direct, to turn towards |
| 求める | もとめる | to seek, to request |
| 持ち上げる | もちあげる | to lift up |
| 戻す | もどす | to return, to restore |
| 戻る | もどる | to return, to go back |
| 申し訳ない | もうしわけない | to have no excuse (sorry) |
| 申し込む | もうしこむ | to apply for, to request |

---

## Group 6 — や・ら・わ行 Verbs

| Word | Reading | Meaning |
|---|---|---|
| 破る | やぶる | to tear, to break (rules) |
| 止む | やむ | to stop, to cease |
| 辞める | やめる | to quit, to resign |
| 許す | ゆるす | to forgive, to permit |
| 揺れる | ゆれる | to shake, to sway |
| 喜ぶ | よろこぶ | to be delighted |
| 読み取る | よみとる | to read, to interpret |
| 予測する | よそくする | to predict, to forecast |
| 利用する | りようする | to use, to utilize |
| 理解する | りかいする | to understand |
| 連絡する | れんらくする | to contact, to communicate |
| 論じる | ろんじる | to discuss, to argue |
| 割れる | われる | to break, to crack |
| 忘れる | わすれる | to forget |
| 笑う | わらう | to laugh, to smile |
| 分かれる | わかれる | to separate, to branch |
