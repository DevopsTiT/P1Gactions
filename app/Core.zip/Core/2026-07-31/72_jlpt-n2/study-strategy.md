# JLPT N5 → N2 Study Strategy & Quick Reference

---

## Level Comparison Table

| Level | Vocab | Kanji | Grammar Patterns | Study Hours | Equivalent |
|---|---|---|---|---|---|
| N5 | ~800 | ~100 | ~50 | 150 hrs | Beginner |
| N4 | ~1,500 | ~300 | ~100 | 300 hrs | Elementary |
| N3 | ~3,750 | ~650 | ~150 | 450 hrs | Intermediate |
| N2 | ~6,000 | ~1,000 | ~200 | 600 hrs | Upper-Intermediate |
| N1 | ~10,000 | ~2,000 | ~300 | 900 hrs | Advanced |

---

## What's Tested at Each Level

### N5 Test
- Hiragana + Katakana recognition
- ~100 kanji
- Basic grammar: て-form, ます-form, particles は が を に で へ
- Greetings, numbers, time, family, daily life vocabulary

### N4 Test
- ~300 kanji
- Grammar: て-form requests, potential form, causative, passive
- Conditionals: たら、ば、と、なら
- Daily life, travel, school, work vocabulary

### N3 Test
- ~650 kanji
- Grammar: て-form + various endings (てしまう、ておく、てみる advanced uses)
- Conjunctions and connectors (ものの、にもかかわらず、など)
- News-level vocabulary, social topics

### N2 Test
- ~1,000 kanji
- Grammar: complex sentence patterns (grammar categories 1-10 in n2-grammar-patterns.md)
- Formal/written register
- Business, academic, newspaper reading

---

## High-Priority Study Order

### Kanji Learning Priority (N5 → N2)

Learn kanji in this order for fastest reading progress:
1. N5 kanji (100) — numbers, basic verbs, body parts, nature, school
2. Time-related kanji (時、分、年、月、日、週、間)
3. Action kanji (行、来、食、飲、見、聞、話、書、読)
4. Relationship kanji (人、子、父、母、友、先、生)
5. N4 kanji — build on N5, add workplace/society words
6. N3 kanji — add abstract concepts (感、想、態、状、況)
7. N2 kanji — fine-tune with formal/academic vocabulary

### Vocabulary Learning Priority

**Core 1000 words (N5+N4) — learn these first:**
```
Pronouns:    私、あなた、彼、彼女、これ、それ、あれ
Time:        今、昨日、今日、明日、今週、来週、毎日
People:      人、子供、学生、先生、友達、家族
Places:      家、学校、会社、駅、店、病院
Actions:     する、くる、いく、みる、きく、はなす
Adjectives:  いい、悪い、大きい、小さい、高い、安い
Numbers:     1-10,000 + counters
```

**N3 words to prioritize (1000 most useful):**
```
Abstract:    気持ち、影響、状況、関係、意見
Verbs:       調べる、説明する、確認する、伝える、認める
Society:     問題、社会、文化、変化、成功、努力
```

**N2 words to prioritize:**
```
Formal nouns:   議論、提案、判断、評価、根拠
Adverbs:        むしろ、かえって、あくまで、いずれ
Compound verbs: 取り組む、申し込む、引き受ける
```

---

## Common N2 Test Trap Words (同音異義語 / Similar Meanings)

### Words That Sound the Same
| Word 1 | Reading | Word 2 | Reading | Difference |
|---|---|---|---|---|
| 以外 | いがい | 意外 | いがい | 以外=except; 意外=unexpected |
| 以降 | いこう | 意向 | いこう | 以降=after; 意向=intention |
| 機械 | きかい | 機会 | きかい | 機械=machine; 機会=opportunity |
| 対照 | たいしょう | 対称 | たいしょう | 対照=contrast; 対称=symmetry |
| 感心 | かんしん | 関心 | かんしん | 感心=admiration; 関心=interest |
| 適当 | てきとう | 適切 | てきせつ | 適当=suitable/sloppy; 適切=appropriate |
| 発展 | はってん | 発見 | はっけん | 発展=development; 発見=discovery |

### Kanji With Multiple Readings
| Kanji | Reading 1 | Meaning 1 | Reading 2 | Meaning 2 |
|---|---|---|---|---|
| 上 | うえ | above | じょう | upper (in compounds) |
| 下 | した | below | か/げ | lower (in compounds) |
| 生 | せい | life, student | なま | raw, live |
| 大 | おお | big (adj) | だい | large (in compounds) |
| 日 | ひ | day, sun | にち/じつ | day (in compounds) |
| 間 | あいだ | between | かん | period, interval |
| 体 | からだ | body | たい | body (in compounds) |
| 手 | て | hand | しゅ | hand (in compounds) |

---

## N2 Vocabulary: Tricky Word Pairs

### Similar Meanings — Choose Correctly
| Word A | Word B | Difference |
|---|---|---|
| 増える (ふえる) | 増す (ます) | ふえる = quantity increases naturally; ます = amount/degree increases |
| 渡す (わたす) | 渡る (わたる) | わたす = give to someone; わたる = cross over |
| 起こす (おこす) | 起きる (おきる) | おこす = cause/wake (transitive); おきる = happen/wake (intransitive) |
| 変える (かえる) | 変わる (かわる) | かえる = change (transitive); かわる = change (intransitive) |
| 続ける (つづける) | 続く (つづく) | つづける = continue (transitive); つづく = continue (intransitive) |
| 直す (なおす) | 直る (なおる) | なおす = fix (transitive); なおる = get better (intransitive) |

### Polite vs Plain Register
| Plain | Polite/Formal | Context |
|---|---|---|
| もらう | いただく | receive (humble) |
| あげる | さしあげる | give (humble) |
| くれる | くださる | give (respectful) |
| する | いたす | do (humble) |
| いる | おる | exist (humble) |
| 言う | おっしゃる | say (respectful) |
| 食べる | めしあがる | eat (respectful) |
| 知っている | ご存知 | know (respectful) |

---

## 100 Most Important N2 Compound Words

| Word | Reading | Meaning |
|---|---|---|
| 一般的 | いっぱんてき | general, common |
| 印象的 | いんしょうてき | impressive |
| 合理的 | ごうりてき | rational, logical |
| 画期的 | かっきてき | epoch-making, innovative |
| 効果的 | こうかてき | effective |
| 積極的 | せっきょくてき | proactive, positive |
| 消極的 | しょうきょくてき | passive, negative |
| 具体的 | ぐたいてき | concrete, specific |
| 抽象的 | ちゅうしょうてき | abstract |
| 現実的 | げんじつてき | realistic |
| 理想的 | りそうてき | ideal |
| 国際的 | こくさいてき | international |
| 社会的 | しゃかいてき | social |
| 文化的 | ぶんかてき | cultural |
| 経済的 | けいざいてき | economic |
| 政治的 | せいじてき | political |
| 個人的 | こじんてき | personal, individual |
| 精神的 | せいしんてき | mental, psychological |
| 肉体的 | にくたいてき | physical |
| 感情的 | かんじょうてき | emotional |
| 論理的 | ろんりてき | logical |
| 批判的 | ひはんてき | critical |
| 否定的 | ひていてき | negative (denying) |
| 肯定的 | こうていてき | positive (affirming) |
| 客観的 | きゃっかんてき | objective |
| 主観的 | しゅかんてき | subjective |
| 組織的 | そしきてき | systematic, organized |
| 計画的 | けいかくてき | planned, systematic |
| 継続的 | けいぞくてき | continuous |
| 定期的 | ていきてき | regular, periodic |

---

## Reading Comprehension Tips for N2

### Signal Words to Know
| Signal | What It Signals |
|---|---|
| まず / 第一に | First point coming |
| また / さらに / そして | Additional point |
| しかし / ところが / だが | Contrast coming |
| つまり / すなわち / 要するに | Summary/conclusion |
| たとえば / 例えば | Example following |
| 一方 / 反対に | Another perspective |
| 結局 / 最終的に | Final conclusion |
| 〜からこそ | Precisely because (emphasis) |
| 確かに〜が | Admittedly... but (concession before main point) |

### N2 Reading Strategy
1. Read title and first/last sentence of each paragraph first
2. Identify the 主張 (main claim) — usually stated in the first or last paragraph
3. Track 接続詞 (conjunctions) — they signal the text structure
4. Watch for 〜は〜が pattern: "X is Y, but [main point]"
5. In multiple-choice: eliminate answers with extreme/absolute language
6. "筆者は〜と考えている" questions = author's opinion (not a fact)
