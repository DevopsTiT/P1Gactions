# JLPT N2 — Nouns (名詞)

---

## Everyday Life & Society

| Word | Reading | Meaning |
|---|---|---|
| 合図 | あいず | signal, sign |
| 相手 | あいて | partner, opponent |
| 挨拶 | あいさつ | greeting |
| 当たり前 | あたりまえ | natural, obvious |
| 跡 | あと | trace, mark, ruins |
| 穴 | あな | hole |
| 案内 | あんない | guidance, information |
| 意外 | いがい | unexpected, surprising |
| 意見 | いけん | opinion |
| 以上 | いじょう | more than, above, that is all |
| 以下 | いか | less than, below |
| 一方 | いっぽう | one side, on the other hand |
| 意味 | いみ | meaning |
| 印象 | いんしょう | impression |
| 内 | うち | inside, home |
| 運 | うん | luck, fortune |
| 縁 | えん | fate, connection, edge |
| 温度 | おんど | temperature |
| 思い | おもい | feeling, thought |
| 親 | おや | parent |
| 音 | おと | sound, noise |
| 音楽 | おんがく | music |
| 改善 | かいぜん | improvement |
| 過去 | かこ | the past |
| 環境 | かんきょう | environment |
| 感情 | かんじょう | emotion, feeling |
| 関係 | かんけい | relationship, connection |
| 関心 | かんしん | interest, concern |
| 機会 | きかい | opportunity, chance |
| 記憶 | きおく | memory |
| 規則 | きそく | rule, regulation |
| 気持ち | きもち | feeling, mood |
| 境界 | きょうかい | boundary, border |
| 競争 | きょうそう | competition |
| 共通 | きょうつう | common, shared |
| 偶然 | ぐうぜん | coincidence, chance |
| 計画 | けいかく | plan |
| 経験 | けいけん | experience |
| 結果 | けっか | result, outcome |
| 結論 | けつろん | conclusion |
| 限界 | げんかい | limit, boundary |
| 現在 | げんざい | present, now |
| 現実 | げんじつ | reality |
| 原因 | げんいん | cause, reason |
| 効果 | こうか | effect, result |
| 考え | かんがえ | thought, idea |
| 行動 | こうどう | action, behaviour |
| 誤解 | ごかい | misunderstanding |
| 個人 | こじん | individual, personal |
| 言葉 | ことば | word, language |
| 根拠 | こんきょ | basis, grounds |

---

## People & Relationships

| Word | Reading | Meaning |
|---|---|---|
| 上司 | じょうし | boss, superior |
| 後輩 | こうはい | junior (at school/work) |
| 先輩 | せんぱい | senior (at school/work) |
| 部下 | ぶか | subordinate |
| 同僚 | どうりょう | colleague |
| 仲間 | なかま | companion, member |
| 友人 | ゆうじん | friend |
| 恋人 | こいびと | lover, partner |
| 夫婦 | ふうふ | married couple, husband and wife |
| 兄弟 | きょうだい | siblings |
| 祖父 | そふ | grandfather |
| 祖母 | そぼ | grandmother |
| 息子 | むすこ | son |
| 娘 | むすめ | daughter |
| 人物 | じんぶつ | person, figure, character |
| 人類 | じんるい | humanity, mankind |
| 住民 | じゅうみん | resident, inhabitant |
| 市民 | しみん | citizen |
| 世代 | せだい | generation |
| 他人 | たにん | others, stranger |

---

## Work & Education

| Word | Reading | Meaning |
|---|---|---|
| 課題 | かだい | task, assignment, issue |
| 活動 | かつどう | activity |
| 技術 | ぎじゅつ | technology, skill |
| 業務 | ぎょうむ | business, work duties |
| 訓練 | くんれん | training, drill |
| 研究 | けんきゅう | research |
| 試験 | しけん | exam, test |
| 資料 | しりょう | materials, data |
| 授業 | じゅぎょう | class, lesson |
| 職業 | しょくぎょう | occupation, profession |
| 成果 | せいか | result, achievement |
| 専門 | せんもん | specialty, expertise |
| 担当 | たんとう | person in charge |
| 提案 | ていあん | proposal, suggestion |
| 手順 | てじゅん | procedure, steps |
| 内容 | ないよう | content, details |
| 能力 | のうりょく | ability, capability |
| 報告 | ほうこく | report |
| 目標 | もくひょう | goal, target |
| 役割 | やくわり | role, function |
| 要求 | ようきゅう | demand, request |

---

## Abstract Concepts

| Word | Reading | Meaning |
|---|---|---|
| 影響 | えいきょう | influence, effect |
| 状況 | じょうきょう | situation, circumstances |
| 状態 | じょうたい | state, condition |
| 条件 | じょうけん | condition, requirement |
| 性格 | せいかく | personality, character |
| 性質 | せいしつ | nature, quality |
| 責任 | せきにん | responsibility |
| 理由 | りゆう | reason |
| 理解 | りかい | understanding |
| 利点 | りてん | advantage, merit |
| 欠点 | けってん | fault, shortcoming |
| 特徴 | とくちょう | feature, characteristic |
| 問題 | もんだい | problem, question |
| 目的 | もくてき | purpose, aim |
| 意識 | いしき | consciousness, awareness |
| 立場 | たちば | position, standpoint |
| 割合 | わりあい | ratio, proportion |
| 様子 | ようす | appearance, situation |
| 余裕 | よゆう | room, margin, ease |
| 基準 | きじゅん | standard, criterion |

---

## Time & Space

| Word | Reading | Meaning |
|---|---|---|
| 以前 | いぜん | before, formerly |
| 以後 | いご | after, since |
| 当時 | とうじ | at that time |
| 将来 | しょうらい | future |
| 現代 | げんだい | modern times, present age |
| 近代 | きんだい | modern era |
| 時代 | じだい | era, age, period |
| 周辺 | しゅうへん | surroundings, vicinity |
| 中心 | ちゅうしん | centre, core |
| 地域 | ちいき | area, region |
| 範囲 | はんい | range, scope |
| 方向 | ほうこう | direction |
| 場合 | ばあい | case, situation |
| 場所 | ばしょ | place, location |
