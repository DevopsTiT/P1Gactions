# JLPT N5 — Complete Vocabulary & Kanji

N5 is the entry level. About 800 vocabulary words and 100 kanji.

---

## N5 Core Kanji (100 Characters)

| Kanji | On | Kun | Meaning | Example |
|---|---|---|---|---|
| 一 | イチ | ひと- | one | 一つ (ひとつ) one thing |
| 二 | ニ | ふた- | two | 二つ (ふたつ) two things |
| 三 | サン | みっ- | three | 三日 (みっか) 3rd day |
| 四 | シ | よっ- | four | 四月 (しがつ) April |
| 五 | ゴ | いつ- | five | 五時 (ごじ) 5 o'clock |
| 六 | ロク | むっ- | six | 六月 (ろくがつ) June |
| 七 | シチ | なな- | seven | 七日 (なのか) 7th day |
| 八 | ハチ | やっ- | eight | 八月 (はちがつ) August |
| 九 | キュウ | ここの- | nine | 九時 (くじ) 9 o'clock |
| 十 | ジュウ | とお | ten | 十分 (じゅっぷん) 10 minutes |
| 百 | ヒャク | — | hundred | 三百 (さんびゃく) 300 |
| 千 | セン | ち | thousand | 千円 (せんえん) ¥1000 |
| 万 | マン | — | ten-thousand | 一万 (いちまん) 10,000 |
| 円 | エン | まる | yen, circle | 円 (えん) yen |
| 年 | ネン | とし | year | 今年 (ことし) this year |
| 月 | ゲツ | つき | month, moon | 月曜日 (げつようび) Monday |
| 日 | ニチ | ひ | day, sun | 日本 (にほん) Japan |
| 時 | ジ | とき | time, hour | 何時 (なんじ) what time |
| 分 | フン | わ-ける | minute, divide | 五分 (ごふん) 5 minutes |
| 間 | カン | あいだ | between, while | 時間 (じかん) time |
| 人 | ジン | ひと | person | 日本人 (にほんじん) Japanese person |
| 子 | シ | こ | child | 子供 (こども) child |
| 女 | ジョ | おんな | woman | 女性 (じょせい) female |
| 男 | ダン | おとこ | man | 男性 (だんせい) male |
| 父 | フ | ちち | father | お父さん (おとうさん) dad |
| 母 | ボ | はは | mother | お母さん (おかあさん) mom |
| 友 | ユウ | とも | friend | 友達 (ともだち) friend |
| 先 | セン | さき | ahead, previous | 先生 (せんせい) teacher |
| 生 | セイ | い-きる | life, birth | 学生 (がくせい) student |
| 学 | ガク | まな-ぶ | study, school | 学校 (がっこう) school |
| 校 | コウ | — | school | 高校 (こうこう) high school |
| 語 | ゴ | かた-る | language, speak | 日本語 (にほんご) Japanese |
| 書 | ショ | か-く | write, book | 教科書 (きょうかしょ) textbook |
| 読 | ドク | よ-む | read | 読書 (どくしょ) reading |
| 聞 | ブン | き-く | listen, ask | 新聞 (しんぶん) newspaper |
| 見 | ケン | み-る | see, look | 見物 (けんぶつ) sightseeing |
| 話 | ワ | はな-す | speak, story | 電話 (でんわ) telephone |
| 言 | ゲン | い-う | say | 言葉 (ことば) word |
| 食 | ショク | た-べる | eat, food | 食事 (しょくじ) meal |
| 飲 | イン | の-む | drink | 飲み物 (のみもの) drink |
| 行 | コウ | い-く | go | 旅行 (りょこう) travel |
| 来 | ライ | く-る | come | 未来 (みらい) future |
| 帰 | キ | かえ-る | return | 帰宅 (きたく) returning home |
| 出 | シュツ | で-る | exit, put out | 出口 (でぐち) exit |
| 入 | ニュウ | はい-る | enter | 入口 (いりぐち) entrance |
| 上 | ジョウ | うえ | above | 上手 (じょうず) skilled |
| 下 | カ | した | below | 地下 (ちか) underground |
| 中 | チュウ | なか | middle, inside | 中学校 (ちゅうがっこう) middle school |
| 右 | ウ | みぎ | right | 右手 (みぎて) right hand |
| 左 | サ | ひだり | left | 左手 (ひだりて) left hand |
| 大 | ダイ | おお-きい | big | 大学 (だいがく) university |
| 小 | ショウ | ちい-さい | small | 小学校 (しょうがっこう) elementary school |
| 高 | コウ | たか-い | high, expensive | 高校 (こうこう) high school |
| 安 | アン | やす-い | cheap, safe | 安全 (あんぜん) safety |
| 白 | ハク | しろ | white | 白い (しろい) white |
| 黒 | コク | くろ | black | 黒い (くろい) black |
| 赤 | セキ | あか | red | 赤ちゃん (あかちゃん) baby |
| 青 | セイ | あお | blue | 青空 (あおぞら) blue sky |
| 水 | スイ | みず | water | 水曜日 (すいようび) Wednesday |
| 火 | カ | ひ | fire | 火曜日 (かようび) Tuesday |
| 山 | サン | やま | mountain | 富士山 (ふじさん) Mt Fuji |
| 川 | セン | かわ | river | 川 (かわ) river |
| 木 | モク | き | tree, wood | 木曜日 (もくようび) Thursday |
| 金 | キン | かね | gold, money | 金曜日 (きんようび) Friday |
| 土 | ド | つち | earth, soil | 土曜日 (どようび) Saturday |
| 花 | カ | はな | flower | 花見 (はなみ) flower viewing |
| 犬 | ケン | いぬ | dog | 犬 (いぬ) dog |
| 猫 | ビョウ | ねこ | cat | 猫 (ねこ) cat |
| 魚 | ギョ | さかな | fish | 魚 (さかな) fish |
| 肉 | ニク | — | meat | 牛肉 (ぎゅうにく) beef |
| 米 | マイ | こめ | rice | お米 (おこめ) rice |
| 茶 | チャ | — | tea | お茶 (おちゃ) tea |
| 電 | デン | — | electricity | 電車 (でんしゃ) train |
| 車 | シャ | くるま | car | 電車 (でんしゃ) train |
| 駅 | エキ | — | station | 駅 (えき) station |
| 家 | カ | いえ | house, home | 家族 (かぞく) family |
| 部 | ブ | — | section, room | 部屋 (へや) room |
| 口 | コウ | くち | mouth | 入口 (いりぐち) entrance |
| 目 | モク | め | eye | 目 (め) eye |
| 手 | シュ | て | hand | 手紙 (てがみ) letter |
| 足 | ソク | あし | foot, leg | 足 (あし) foot |
| 気 | キ | — | spirit, energy | 天気 (てんき) weather |
| 天 | テン | あめ | sky, heaven | 天気 (てんき) weather |
| 空 | クウ | そら | sky, empty | 空港 (くうこう) airport |
| 雨 | ウ | あめ | rain | 雨 (あめ) rain |
| 風 | フウ | かぜ | wind | 台風 (たいふう) typhoon |
| 道 | ドウ | みち | road, way | 道 (みち) road |
| 店 | テン | みせ | shop | お店 (おみせ) shop |
| 国 | コク | くに | country | 外国 (がいこく) foreign country |
| 外 | ガイ | そと | outside | 外国語 (がいこくご) foreign language |
| 東 | トウ | ひがし | east | 東京 (とうきょう) Tokyo |
| 西 | セイ | にし | west | 関西 (かんさい) Kansai |
| 南 | ナン | みなみ | south | 南口 (みなみぐち) south exit |
| 北 | ホク | きた | north | 北口 (きたぐち) north exit |
| 何 | カ | なに | what | 何時 (なんじ) what time |
| 今 | コン | いま | now | 今日 (きょう) today |
| 毎 | マイ | — | every | 毎日 (まいにち) every day |
| 半 | ハン | なか-ば | half | 半分 (はんぶん) half |
| 長 | チョウ | なが-い | long, chief | 長い (ながい) long |
| 新 | シン | あたら-しい | new | 新聞 (しんぶん) newspaper |
| 古 | コ | ふる-い | old | 古い (ふるい) old |
| 多 | タ | おお-い | many | 多い (おおい) many |
| 少 | ショウ | すく-ない | few | 少し (すこし) a little |

---

## N5 Key Vocabulary by Category

### Greetings & Basic Expressions
| Word | Reading | Meaning |
|---|---|---|
| おはようございます | — | Good morning |
| こんにちは | — | Hello / Good afternoon |
| こんばんは | — | Good evening |
| おやすみなさい | — | Good night |
| ありがとうございます | — | Thank you |
| すみません | — | Excuse me / Sorry |
| ごめんなさい | — | I'm sorry |
| はじめまして | — | Nice to meet you |
| よろしくお願いします | よろしくおねがいします | Please treat me well |
| さようなら | — | Goodbye |

### Numbers & Counters
| Word | Reading | Meaning |
|---|---|---|
| ひとつ / 一つ | ひとつ | one (thing) |
| ふたつ / 二つ | ふたつ | two (things) |
| みっつ / 三つ | みっつ | three (things) |
| よっつ / 四つ | よっつ | four (things) |
| いつつ / 五つ | いつつ | five (things) |
| いくつ | いくつ | how many / how old |
| ～枚 | ～まい | counter for flat things |
| ～本 | ～ほん | counter for long things |
| ～冊 | ～さつ | counter for books |
| ～匹 | ～ひき | counter for small animals |
| ～台 | ～だい | counter for machines |
| ～杯 | ～はい | counter for drinks |

### Time
| Word | Reading | Meaning |
|---|---|---|
| 今日 | きょう | today |
| 明日 | あした | tomorrow |
| 昨日 | きのう | yesterday |
| 今週 | こんしゅう | this week |
| 来週 | らいしゅう | next week |
| 先週 | せんしゅう | last week |
| 今月 | こんげつ | this month |
| 来月 | らいげつ | next month |
| 今年 | ことし | this year |
| 来年 | らいねん | next year |
| 朝 | あさ | morning |
| 昼 | ひる | noon, daytime |
| 夜 | よる | night |
| 午前 | ごぜん | AM |
| 午後 | ごご | PM |
| 週末 | しゅうまつ | weekend |

### Adjectives (N5)
| Word | Reading | Meaning |
|---|---|---|
| いい / よい | — | good |
| 悪い | わるい | bad |
| 大きい | おおきい | big |
| 小さい | ちいさい | small |
| 長い | ながい | long |
| 短い | みじかい | short |
| 高い | たかい | tall, expensive |
| 低い | ひくい | low |
| 安い | やすい | cheap |
| 新しい | あたらしい | new |
| 古い | ふるい | old |
| 速い・早い | はやい | fast, early |
| 遅い | おそい | slow, late |
| 暑い | あつい | hot (weather) |
| 寒い | さむい | cold (weather) |
| 熱い | あつい | hot (objects) |
| 冷たい | つめたい | cold (objects) |
| 面白い | おもしろい | interesting |
| 楽しい | たのしい | fun, enjoyable |
| 難しい | むずかしい | difficult |
| 易しい | やさしい | easy |
| 忙しい | いそがしい | busy |
| 元気 | げんき | healthy, energetic |
| 好き | すき | like, fond of |
| 嫌い | きらい | dislike |
| 有名 | ゆうめい | famous |
| 大切 | たいせつ | important |
| 大丈夫 | だいじょうぶ | OK, all right |
| 親切 | しんせつ | kind |
| 便利 | べんり | convenient |
| 不便 | ふべん | inconvenient |
| 賑やか | にぎやか | lively, busy (place) |
| 静か | しずか | quiet |

### N5 Core Verbs (dictionary form)
| Word | Reading | Meaning |
|---|---|---|
| ある | — | to exist (non-living) |
| いる | — | to exist (living) |
| する | — | to do |
| くる | — | to come |
| いく | — | to go |
| かえる | — | to return |
| たべる | — | to eat |
| のむ | — | to drink |
| みる | — | to see, watch |
| きく | — | to listen, ask |
| はなす | — | to speak |
| かく | — | to write |
| よむ | — | to read |
| かう | — | to buy |
| うる | — | to sell |
| もらう | — | to receive |
| あげる | — | to give (to others) |
| もつ | — | to hold, have |
| つかう | — | to use |
| あく | — | to open (intransitive) |
| あける | — | to open (transitive) |
| しまる | — | to close (intransitive) |
| しめる | — | to close (transitive) |
| おきる | — | to wake up, get up |
| ねる | — | to sleep |
| はじめる | — | to begin |
| おわる | — | to end |
| あるく | — | to walk |
| はしる | — | to run |
| のる | — | to ride |
| おりる | — | to get off |
| かける | — | to hang, make a call |
| おす | — | to push |
| ひく | — | to pull |
| まつ | — | to wait |
| わかる | — | to understand |
| おもう | — | to think |
| しる | — | to know |
| みえる | — | to be visible |
