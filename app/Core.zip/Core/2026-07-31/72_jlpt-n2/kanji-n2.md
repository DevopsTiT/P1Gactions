# JLPT N2 — Essential Kanji (漢字) — 370 Characters

Format: Kanji | On-yomi | Kun-yomi | Key Meanings | Example Word

---

## Frequency Group A (Most Common)

| Kanji | On | Kun | Meaning | Example |
|---|---|---|---|---|
| 改 | カイ | あらた-める | reform, change | 改善 (かいぜん) improvement |
| 革 | カク | かわ | leather, reform | 革命 (かくめい) revolution |
| 拡 | カク | ひろ-げる | expand | 拡大 (かくだい) expansion |
| 確 | カク | たし-か | certain, confirm | 確認 (かくにん) confirmation |
| 額 | ガク | ひたい | amount, forehead | 金額 (きんがく) amount of money |
| 慣 | カン | な-れる | accustom | 習慣 (しゅうかん) habit |
| 感 | カン | — | feel | 感情 (かんじょう) emotion |
| 環 | カン | — | ring, circle, environment | 環境 (かんきょう) environment |
| 観 | カン | み-る | observe, view | 観察 (かんさつ) observation |
| 完 | カン | — | complete | 完成 (かんせい) completion |
| 関 | カン | せき | relate, barrier | 関係 (かんけい) relationship |
| 基 | キ | もと | basis, foundation | 基本 (きほん) basics |
| 記 | キ | しる-す | record, write | 記録 (きろく) record |
| 機 | キ | はた | machine, opportunity | 機会 (きかい) opportunity |
| 季 | キ | — | season | 季節 (きせつ) season |
| 規 | キ | — | rule, standard | 規則 (きそく) rule |
| 技 | ギ | わざ | skill, technique | 技術 (ぎじゅつ) technology |
| 義 | ギ | — | righteousness | 義務 (ぎむ) duty |
| 疑 | ギ | うたが-う | doubt | 疑問 (ぎもん) question, doubt |
| 議 | ギ | — | discuss | 議論 (ぎろん) argument |
| 境 | キョウ | さかい | boundary | 環境 (かんきょう) environment |
| 況 | キョウ | — | condition | 状況 (じょうきょう) situation |
| 競 | キョウ | きそ-う | compete | 競争 (きょうそう) competition |
| 共 | キョウ | とも | together, share | 共通 (きょうつう) common |
| 極 | キョク | きわ-める | extreme, pole | 積極的 (せっきょくてき) positive |
| 禁 | キン | — | prohibit | 禁止 (きんし) prohibition |
| 均 | キン | — | equal | 平均 (へいきん) average |
| 具 | グ | そな-える | tool, furnish | 具体的 (ぐたいてき) concrete |

---

## Frequency Group B

| Kanji | On | Kun | Meaning | Example |
|---|---|---|---|---|
| 係 | ケイ | かか-る | relate, staff | 係員 (かかりいん) person in charge |
| 経 | ケイ | へ-る | pass, manage | 経験 (けいけん) experience |
| 軽 | ケイ | かる-い | light, slight | 軽量 (けいりょう) light weight |
| 継 | ケイ | つ-ぐ | succeed, continue | 継続 (けいぞく) continuation |
| 型 | ケイ | かた | type, mould | 典型 (てんけい) typical example |
| 激 | ゲキ | はげ-しい | intense, violent | 激変 (げきへん) dramatic change |
| 欠 | ケツ | か-ける | lack, absence | 欠点 (けってん) weakness |
| 結 | ケツ | むす-ぶ | tie, result | 結果 (けっか) result |
| 件 | ケン | — | matter, case | 条件 (じょうけん) condition |
| 険 | ケン | けわ-しい | dangerous | 危険 (きけん) danger |
| 検 | ケン | — | inspect, examine | 検査 (けんさ) inspection |
| 限 | ゲン | かぎ-る | limit | 制限 (せいげん) restriction |
| 現 | ゲン | あらわ-れる | present, appear | 現在 (げんざい) present time |
| 原 | ゲン | はら | origin, field | 原因 (げんいん) cause |
| 効 | コウ | き-く | effect, efficient | 効果 (こうか) effect |
| 構 | コウ | かま-える | structure, prepare | 構造 (こうぞう) structure |
| 交 | コウ | まじ-わる | mix, exchange | 交流 (こうりゅう) exchange |
| 合 | ゴウ | あ-う | combine, suit | 合計 (ごうけい) total |
| 告 | コク | つ-げる | tell, announce | 報告 (ほうこく) report |
| 困 | コン | こま-る | troubled | 困難 (こんなん) difficulty |
| 混 | コン | こ-む | mix | 混乱 (こんらん) confusion |
| 根 | コン | ね | root, basis | 根拠 (こんきょ) basis, grounds |
| 査 | サ | — | investigate | 調査 (ちょうさ) investigation |
| 際 | サイ | きわ | occasion, edge | 国際 (こくさい) international |
| 差 | サ | さ-す | difference | 差別 (さべつ) discrimination |
| 再 | サイ | ふたた-び | again, re- | 再確認 (さいかくにん) reconfirmation |
| 採 | サイ | と-る | adopt, collect | 採用 (さいよう) adoption, hiring |
| 策 | サク | — | plan, measure | 対策 (たいさく) countermeasure |
| 察 | サツ | — | guess, observe | 観察 (かんさつ) observation |
| 散 | サン | ち-る | scatter | 散歩 (さんぽ) walk |

---

## Frequency Group C

| Kanji | On | Kun | Meaning | Example |
|---|---|---|---|---|
| 示 | ジ | しめ-す | show, indicate | 指示 (しじ) instruction |
| 識 | シキ | — | know, distinguish | 意識 (いしき) consciousness |
| 資 | シ | — | resource, capital | 資料 (しりょう) materials |
| 支 | シ | ささ-える | support, branch | 支持 (しじ) support |
| 実 | ジツ | みの-る | reality, fruit | 実現 (じつげん) realization |
| 質 | シツ | — | quality, substance | 性質 (せいしつ) nature |
| 主 | シュ | ぬし | main, master | 主張 (しゅちょう) assertion |
| 種 | シュ | たね | seed, type, kind | 種類 (しゅるい) type, variety |
| 術 | ジュツ | — | art, technique | 技術 (ぎじゅつ) technology |
| 従 | ジュウ | したが-う | follow, obey | 従来 (じゅうらい) traditional |
| 状 | ジョウ | — | state, letter | 状況 (じょうきょう) situation |
| 象 | ショウ | — | elephant, symbol | 印象 (いんしょう) impression |
| 商 | ショウ | — | trade, merchant | 商品 (しょうひん) product |
| 上 | ジョウ | うえ | above, upper | 向上 (こうじょう) improvement |
| 情 | ジョウ | なさ-け | feeling, information | 感情 (かんじょう) emotion |
| 場 | ジョウ | ば | place, field | 場合 (ばあい) case |
| 障 | ショウ | さわ-る | obstruct, hinder | 障害 (しょうがい) obstacle |
| 除 | ジョ | のぞ-く | remove, exclude | 除外 (じょがい) exclusion |
| 触 | ショク | ふ-れる | touch | 接触 (せっしょく) contact |
| 深 | シン | ふか-い | deep | 深刻 (しんこく) serious |
| 信 | シン | — | trust, believe | 信頼 (しんらい) trust |
| 察 | サツ | — | perceive | 推察 (すいさつ) guess |
| 性 | セイ | — | nature, gender | 個性 (こせい) individuality |
| 精 | セイ | — | spirit, energy | 精神 (せいしん) spirit, mind |
| 制 | セイ | — | system, control | 制度 (せいど) system |
| 省 | セイ | はぶ-く | save, ministry | 反省 (はんせい) reflection |
| 積 | セキ | つ-む | pile up | 積極 (せっきょく) positive |
| 責 | セキ | せ-める | blame, responsibility | 責任 (せきにん) responsibility |
| 節 | セツ | — | joint, season, save | 季節 (きせつ) season |
| 絶 | ゼツ | た-える | extinct, absolute | 絶対 (ぜったい) absolute |

---

## Frequency Group D

| Kanji | On | Kun | Meaning | Example |
|---|---|---|---|---|
| 設 | セツ | もう-ける | set up, establish | 設定 (せってい) setting |
| 存 | ソン | — | exist | 存在 (そんざい) existence |
| 族 | ゾク | — | family, tribe | 家族 (かぞく) family |
| 続 | ゾク | つづ-く | continue | 継続 (けいぞく) continuation |
| 損 | ソン | そこ-なう | loss, damage | 損害 (そんがい) damage |
| 体 | タイ | からだ | body, form | 体験 (たいけん) personal experience |
| 態 | タイ | — | attitude, state | 状態 (じょうたい) condition |
| 対 | タイ | むか-う | opposite, pair | 対策 (たいさく) countermeasure |
| 達 | タツ | — | reach, plural | 達成 (たっせい) achievement |
| 担 | タン | にな-う | carry, bear | 担当 (たんとう) person in charge |
| 段 | ダン | — | step, grade | 手段 (しゅだん) means, method |
| 断 | ダン | ことわ-る | cut, refuse | 判断 (はんだん) judgement |
| 知 | チ | し-る | know | 知識 (ちしき) knowledge |
| 注 | チュウ | そそ-ぐ | pour, attention | 注目 (ちゅうもく) attention |
| 著 | チョ | いちじる-しい | remarkable, author | 著者 (ちょしゃ) author |
| 提 | テイ | さ-げる | present, propose | 提案 (ていあん) proposal |
| 適 | テキ | — | suitable, fit | 適切 (てきせつ) appropriate |
| 点 | テン | — | point, dot | 観点 (かんてん) viewpoint |
| 転 | テン | ころ-がる | roll, turn, fall | 転換 (てんかん) conversion |
| 統 | トウ | す-べる | govern, unify | 統合 (とうごう) unification |
| 導 | ドウ | みちび-く | lead, guide | 指導 (しどう) guidance |
| 動 | ドウ | うご-く | move | 行動 (こうどう) action |
| 得 | トク | え-る | gain, obtain | 説得 (せっとく) persuasion |
| 独 | ドク | ひと-り | alone, Germany | 独立 (どくりつ) independence |
| 内 | ナイ | うち | inside, within | 内容 (ないよう) content |
| 認 | ニン | みと-める | recognize, admit | 認識 (にんしき) recognition |
| 能 | ノウ | — | ability, talent | 能力 (のうりょく) ability |
| 判 | ハン | — | judge | 批判 (ひはん) criticism |
| 費 | ヒ | つい-やす | expense, spend | 費用 (ひよう) cost |
| 非 | ヒ | — | non-, fault | 非常 (ひじょう) extraordinary |
| 比 | ヒ | くら-べる | compare | 比較 (ひかく) comparison |

---

## Frequency Group E

| Kanji | On | Kun | Meaning | Example |
|---|---|---|---|---|
| 表 | ヒョウ | あらわ-す | express, table | 表現 (ひょうげん) expression |
| 評 | ヒョウ | — | evaluate, comment | 評価 (ひょうか) evaluation |
| 複 | フク | — | double, complex | 複雑 (ふくざつ) complicated |
| 報 | ホウ | むく-いる | report, reward | 報告 (ほうこく) report |
| 望 | ボウ | のぞ-む | desire, hope | 希望 (きぼう) hope |
| 本 | ホン | もと | origin, book | 基本 (きほん) basics |
| 満 | マン | み-ちる | full, satisfy | 満足 (まんぞく) satisfaction |
| 務 | ム | つと-める | duty, work | 義務 (ぎむ) duty |
| 明 | メイ | あか-るい | bright, clear | 明確 (めいかく) clear |
| 目 | モク | め | eye, aim | 目標 (もくひょう) target |
| 問 | モン | と-う | question, problem | 問題 (もんだい) problem |
| 約 | ヤク | — | promise, about | 約束 (やくそく) promise |
| 要 | ヨウ | い-る | need, important | 必要 (ひつよう) necessary |
| 欲 | ヨク | ほ-しい | desire, want | 欲求 (よっきゅう) desire |
| 利 | リ | き-く | profit, benefit | 利用 (りよう) utilization |
| 理 | リ | — | reason, logic | 理解 (りかい) understanding |
| 流 | リュウ | なが-れる | flow, style | 交流 (こうりゅう) exchange |
| 略 | リャク | — | abbreviate, strategy | 省略 (しょうりゃく) omission |
| 率 | リツ | ひき-いる | rate, lead | 割合 (わりあい) ratio |
| 論 | ロン | — | discuss, theory | 議論 (ぎろん) discussion |
| 割 | カツ | わ-る | divide, proportion | 割合 (わりあい) ratio |
| 和 | ワ | やわ-らぐ | peace, Japan | 調和 (ちょうわ) harmony |
| 与 | ヨ | あた-える | give | 与える (あたえる) to give |
| 容 | ヨウ | い-れる | contain, allow | 内容 (ないよう) content |
| 養 | ヨウ | やしな-う | raise, nourish | 養育 (よういく) upbringing |
| 余 | ヨ | あま-る | surplus, besides | 余裕 (よゆう) room, margin |
| 用 | ヨウ | もち-いる | use | 利用 (りよう) use |
| 様 | ヨウ | さま | manner, Mr/Ms | 様子 (ようす) appearance |
| 預 | ヨ | あず-ける | deposit, entrust | 預金 (よきん) deposit |
| 訳 | ヤク | わけ | translate, reason | 翻訳 (ほんやく) translation |
