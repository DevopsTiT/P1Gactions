# JLPT N2 — Adjectives & Adverbs (形容詞・副詞)

---

## い-Adjectives (い形容詞)

| Word | Reading | Meaning |
|---|---|---|
| 怪しい | あやしい | suspicious, strange |
| 著しい | いちじるしい | remarkable, striking |
| 忙しい | いそがしい | busy |
| 痛い | いたい | painful |
| 薄い | うすい | thin, pale, weak (flavour) |
| 羨ましい | うらやましい | envious, jealous |
| 嬉しい | うれしい | happy, glad |
| 偉い | えらい | great, admirable |
| 大人しい | おとなしい | quiet, well-behaved |
| 惜しい | おしい | regrettable, a pity |
| 遅い | おそい | slow, late |
| 思わしい | おもわしい | satisfactory |
| 重い | おもい | heavy |
| 固い・硬い | かたい | hard, firm, stiff |
| 悲しい | かなしい | sad |
| 辛い | からい | spicy; painful, difficult |
| 軽い | かるい | light (weight) |
| 汚い | きたない | dirty |
| 厳しい | きびしい | strict, severe |
| 臭い | くさい | smelly |
| 暗い | くらい | dark |
| 苦しい | くるしい | painful, suffering |
| 激しい | はげしい | intense, fierce |
| 寂しい | さびしい | lonely |
| 鋭い | するどい | sharp, keen |
| 素晴らしい | すばらしい | wonderful, magnificent |
| 涼しい | すずしい | cool (temperature) |
| 恥ずかしい | はずかしい | embarrassing, ashamed |
| 激しい | はげしい | violent, intense |
| 珍しい | めずらしい | rare, unusual |
| 難しい | むずかしい | difficult |
| 怖い | こわい | scary, frightening |
| 眠い | ねむい | sleepy |
| 懐かしい | なつかしい | nostalgic, dear |
| 憎い | にくい | hateful, spiteful |
| 柔らかい | やわらかい | soft, tender |
| 優しい | やさしい | gentle, kind |
| 若い | わかい | young |
| 悪い | わるい | bad, wrong |
| 親しい | したしい | close, intimate |
| 正しい | ただしい | correct, right |
| 近い | ちかい | near, close |
| 遠い | とおい | far, distant |
| 長い | ながい | long |
| 短い | みじかい | short |

---

## な-Adjectives (な形容詞)

| Word | Reading | Meaning |
|---|---|---|
| 安易 | あんい | easy-going, simplistic |
| 一般的 | いっぱんてき | general, common |
| 意外 | いがい | unexpected |
| 印象的 | いんしょうてき | impressive |
| 確実 | かくじつ | certain, sure |
| 活発 | かっぱつ | active, lively |
| 勝手 | かって | selfish, arbitrary |
| 完全 | かんぜん | complete, perfect |
| 簡単 | かんたん | simple, easy |
| 危険 | きけん | dangerous |
| 急 | きゅう | sudden, steep |
| 共通 | きょうつう | common, shared |
| 具体的 | ぐたいてき | concrete, specific |
| 公平 | こうへい | fair, impartial |
| 個人的 | こじんてき | personal, individual |
| 残念 | ざんねん | unfortunate, regrettable |
| 慎重 | しんちょう | careful, cautious |
| 自由 | じゆう | free, liberal |
| 重要 | じゅうよう | important |
| 柔軟 | じゅうなん | flexible |
| 正確 | せいかく | accurate, precise |
| 積極的 | せっきょくてき | positive, active, aggressive |
| 素直 | すなお | honest, obedient, gentle |
| 大切 | たいせつ | important, precious |
| 大変 | たいへん | difficult; very |
| 丁寧 | ていねい | polite, careful |
| 適切 | てきせつ | appropriate, suitable |
| 特別 | とくべつ | special |
| 得意 | とくい | good at, proud |
| 苦手 | にがて | not good at, weak point |
| 必要 | ひつよう | necessary |
| 不思議 | ふしぎ | strange, mysterious |
| 不安 | ふあん | uneasy, anxious |
| 複雑 | ふくざつ | complicated, complex |
| 不満 | ふまん | dissatisfied, discontent |
| 豊か | ゆたか | rich, abundant |
| 有効 | ゆうこう | valid, effective |
| 余分 | よぶん | extra, surplus |
| 理想的 | りそうてき | ideal |
| 冷静 | れいせい | calm, composed |
| 論理的 | ろんりてき | logical |
| 無駄 | むだ | wasteful, useless |
| 夢中 | むちゅう | absorbed, crazy about |
| 無理 | むり | impossible, unreasonable |
| 明確 | めいかく | clear, definite |
| 有名 | ゆうめい | famous |

---

## Adverbs (副詞) — N2 Core

| Word | Reading | Meaning |
|---|---|---|
| あいにく | あいにく | unfortunately |
| あえて | あえて | dare to, deliberately |
| あくまで | あくまで | to the end, persistently |
| あっという間に | あっというまに | in the blink of an eye |
| あらかじめ | あらかじめ | in advance, beforehand |
| あらゆる | あらゆる | every, all kinds of |
| いかに | いかに | how, in what way |
| いきなり | いきなり | suddenly, abruptly |
| いずれ | いずれ | soon, eventually |
| 一応 | いちおう | once, just to be sure |
| 一層 | いっそう | even more, all the more |
| 一般に | いっぱんに | generally, in general |
| いわば | いわば | so to speak |
| うっかり | うっかり | carelessly, accidentally |
| 大いに | おおいに | greatly, very much |
| おそらく | おそらく | probably, presumably |
| 思わず | おもわず | involuntarily, unintentionally |
| かえって | かえって | on the contrary, rather |
| かつて | かつて | once, formerly |
| かなり | かなり | considerably, fairly |
| きっちり | きっちり | exactly, neatly |
| きっと | きっと | surely, certainly |
| ぐっと | ぐっと | firmly, with a jerk |
| こっそり | こっそり | secretly, stealthily |
| 結局 | けっきょく | after all, in the end |
| さっさと | さっさと | quickly, promptly |
| さっそく | さっそく | immediately, right away |
| しかも | しかも | moreover, furthermore |
| しばらく | しばらく | for a while |
| すっかり | すっかり | completely, entirely |
| せっかく | せっかく | with much effort, specially |
| せめて | せめて | at least |
| そのまま | そのまま | as it is, unchanged |
| たいてい | たいてい | usually, mostly |
| たとえ〜でも | たとえ〜でも | even if |
| ちゃんと | ちゃんと | properly, neatly |
| つまり | つまり | in other words, that is |
| できるだけ | できるだけ | as much as possible |
| どうせ | どうせ | anyway, after all |
| どうにか | どうにか | somehow, manage to |
| どうも | どうも | somehow; thank you |
| 突然 | とつぜん | suddenly |
| なかなか | なかなか | quite, rather; (not) easily |
| 何とか | なんとか | somehow, manage |
| むしろ | むしろ | rather, instead |
| もし | もし | if |
| もはや | もはや | no longer, already |
| もともと | もともと | originally, from the start |
| やがて | やがて | soon, before long |
| ようやく | ようやく | finally, at last |
| よほど | よほど | very, greatly |
| わざと | わざと | on purpose, deliberately |
| わずか | わずか | only, just a little |
