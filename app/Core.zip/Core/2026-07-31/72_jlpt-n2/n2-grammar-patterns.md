# JLPT N2 — Grammar Patterns (文法) — Complete Reference

N2 grammar is the key differentiator. These patterns appear constantly in native-level reading and conversation.

---

## Category 1 — Expressing Reason / Cause (理由・原因)

| Pattern | Meaning | Example |
|---|---|---|
| ～ため（に） | because of, for the purpose of | 雨のため試合が中止になった。 The game was cancelled because of rain. |
| ～ことから | from the fact that, because | 名前の漢字が同じことから、親戚だとわかった。 |
| ～おかげで | thanks to (positive result) | 先生のおかげで合格できた。 Thanks to my teacher I passed. |
| ～せいで | because of (negative result) | 騒音のせいで眠れなかった。 Couldn't sleep because of the noise. |
| ～もので / ～もんで | because, as (explaining/excuse) | 疲れているもので、早退させてください。 |
| ～だけに | precisely because, all the more | プロだけに、演技が上手い。 As expected of a pro, the acting is great. |
| ～ばかりに | simply because, just because (regret) | 一言言ったばかりに、関係が壊れた。 |
| ～ゆえに | because of, therefore (formal) | 無知ゆえに失敗した。 Failed due to ignorance. |

---

## Category 2 — Conditions & Suppositions (条件・仮定)

| Pattern | Meaning | Example |
|---|---|---|
| ～さえ～ば | if only, as long as | お金さえあれば買える。 If only I had money, I could buy it. |
| ～さえ | even, if only | 子供でさえできる。 Even a child can do it. |
| ～としたら / ～とすれば | if we assume, supposing | 君が社長だとしたら、どうする？ |
| ～とすると | if, supposing | 彼が来ないとすると、どうしよう？ |
| ～なら（ば） | if (based on what I know) | 東京に行くなら、新幹線が便利だ。 |
| ～にしたら | from the perspective of, if it were | 子供にしたら、怖かったと思う。 |
| ～次第で | depending on | やる気次第で結果が変わる。 Results change depending on motivation. |
| ～次第だ | it all depends on | 成功するかどうかは努力次第だ。 |
| ～にしては | for, considering (unexpectedly) | 子供にしては上手だ。 For a child, this is skilful. |

---

## Category 3 — Expressing Limits & Extent (限度・程度)

| Pattern | Meaning | Example |
|---|---|---|
| ～かぎり（は） | as long as, to the best of | 私が知るかぎり、問題はない。 As far as I know, no problem. |
| ～に限って | only in the case of, of all | よりによって大事な日に限って遅刻した。 |
| ～にかぎらず | not limited to, not only | 日本人にかぎらず外国人にも人気だ。 |
| ～をはじめ | starting with, not only | 東京をはじめ、大阪でも発売される。 |
| ～しか～ない | only (with negative verb) | 百円しかない。 I only have ¥100. |
| ～さえ～ない | not even | 名前さえ知らない。 I don't even know his name. |
| ～ほど | to the extent that, so much | 死ぬほど疲れた。 I'm dead tired (lit: tired enough to die). |
| ～ほど～はない | nothing is more… than | 健康ほど大切なものはない。 Nothing is more important than health. |
| ～くらい / ～ぐらい | about, approximately; to the extent | 泣きたいくらい悲しい。 So sad I could cry. |

---

## Category 4 — Contrasting & Conceding (逆接・譲歩)

| Pattern | Meaning | Example |
|---|---|---|
| ～ものの | although, even though | 分かったものの、まだ心配だ。 I understand, but I'm still worried. |
| ～にもかかわらず | despite, regardless of | 反対にもかかわらず計画を進めた。 |
| ～にしても | even if, even though | 失敗にしても、経験になる。 Even if it fails, it becomes experience. |
| ～としても | even if (hypothetical) | 雨だとしても行くつもりだ。 Even if it rains, I plan to go. |
| ～はともかく | apart from, leaving aside | 費用はともかく、時間が足りない。 |
| ～はさておき | setting aside, apart from | 冗談はさておき、真剣に考えよう。 |
| ～ながら（も） | while, although, even as | 忙しいながらも来てくれた。 |
| ～くせに | even though, despite (reproach) | 知っているくせに言わない。 Knows but won't say. |
| ～ところが | however, but (unexpected) | 行ったところが、休みだった。 I went, but it was closed. |
| ～反面 | on the other hand, while | 便利な反面、問題もある。 It's convenient, but there are also problems. |

---

## Category 5 — Time & Sequence (時間・順序)

| Pattern | Meaning | Example |
|---|---|---|
| ～たとたんに | the moment, just as | ドアを開けたとたんに、猫が逃げた。 The moment I opened the door, the cat escaped. |
| ～なり | as soon as (immediate action) | 帰るなり、電話してください。 Call me as soon as you get home. |
| ～次第 | as soon as (completion trigger) | 着き次第、連絡します。 I'll contact you as soon as I arrive. |
| ～てからでないと | not until after | 確認してからでないと返事できない。 |
| ～うちに | while, before (changes) | 若いうちに勉強しろ。 Study while you're young. |
| ～に先立って | prior to, before | 式に先立って準備をした。 Prepared before the ceremony. |
| ～を前に | before, facing | 発表を前に緊張している。 Nervous before the presentation. |
| ～に際して | upon the occasion of | 出発に際して一言申し上げます。 |
| ～を機に | taking the opportunity of | 転職を機に、引っ越した。 Moved upon the opportunity of changing jobs. |
| ～を境に | from the point of, since | その事故を境に生き方が変わった。 |

---

## Category 6 — Purpose & Method (目的・手段)

| Pattern | Meaning | Example |
|---|---|---|
| ～にもとづいて | based on | 法律にもとづいて処理する。 Process based on the law. |
| ～をもとに | based on, from | 経験をもとに話す。 Speak from experience. |
| ～を通じて / ～を通して | through, via | 友達を通じて知り合った。 Met through a friend. |
| ～に向けて | towards, aimed at | 目標に向けて頑張る。 Work hard towards the goal. |
| ～に沿って | along, in accordance with | 計画に沿って進める。 Proceed in accordance with the plan. |
| ～に応じて | according to, depending on | 需要に応じて生産量を変える。 |
| ～にしたがって | as, following, according to | 時代の変化にしたがって変わる。 |
| ～としては | as, in the capacity of | 上司としては言いにくい。 As a supervisor, it's hard to say. |
| ～に代わって | instead of, on behalf of | 社長に代わって挨拶する。 Greet on behalf of the president. |

---

## Category 7 — Expressing Addition (追加・付加)

| Pattern | Meaning | Example |
|---|---|---|
| ～に加えて | in addition to | 技術に加えて、経験も必要だ。 |
| ～のみならず | not only, but also (formal) | 国内のみならず海外でも有名だ。 |
| ～ばかりか / ～ばかりでなく | not only, but also | 彼は歌うばかりか踊りもうまい。 |
| ～うえに | moreover, in addition (same direction) | 頭がいい上に、努力家でもある。 |
| ～に伴って | accompanying, along with | 人口増加に伴って問題も増えた。 |
| ～に応じた | appropriate to, suited to | 能力に応じた仕事を与える。 |
| ～はおろか | let alone, needless to say | 漢字はおろか、ひらがなも読めない。 |
| ～どころか | far from, on the contrary | 助けるどころか邪魔をした。 Far from helping, they got in the way. |

---

## Category 8 — Assertion & Certainty (断定・確信)

| Pattern | Meaning | Example |
|---|---|---|
| ～に違いない | must be, no doubt | 彼が犯人に違いない。 He must be the culprit. |
| ～に決まっている | surely, definitely | そんな話、嘘に決まっている。 That story is definitely a lie. |
| ～わけだ | that is why, it makes sense | 彼は10年間練習したわけだ。 That's why he practiced for 10 years. |
| ～わけではない | it's not that | 嫌いなわけではないが、苦手だ。 It's not that I dislike it, but I'm not good at it. |
| ～わけにはいかない | cannot do (morally/logically) | 約束を破るわけにはいかない。 |
| ～ほかない / ～しかない | no choice but | 頑張るしかない。 There's nothing to do but try. |
| ～ずにはいられない | cannot help but | 笑わずにはいられない。 Can't help laughing. |
| ～ざるを得ない | cannot help but (formal) | 認めざるを得ない。 Cannot help but admit. |
| ～にほかならない | nothing but, is exactly | これは嘘にほかならない。 This is nothing but a lie. |

---

## Category 9 — Appearance & Hearsay (様子・伝聞)

| Pattern | Meaning | Example |
|---|---|---|
| ～らしい | seems, apparently, typical of | 雨らしい。 Seems like rain. / It's typical of rain. |
| ～ようだ | seems, it appears | 熱があるようだ。 Seems to have a fever. |
| ～そうだ | looks like (direct observation) / heard that | 美味しそう。 Looks delicious. |
| ～とのことだ | I heard that, they say (reported speech) | 明日来るとのことだ。 I heard they're coming tomorrow. |
| ～に見える | looks like, appears to be | 楽しそうに見える。 Appears to be enjoying themselves. |
| ～気味 | somewhat, slightly (often negative) | 風邪気味だ。 Feeling slightly sick. |

---

## Category 10 — Formal & Written Patterns

| Pattern | Meaning | Example |
|---|---|---|
| ～において | in, at (formal location/context) | 現代社会において重要な問題だ。 |
| ～に関して / ～に関する | regarding, concerning | 環境問題に関する報告書。 Report concerning environmental issues. |
| ～について | about, concerning | この件についてお話しします。 |
| ～に対して / ～に対する | towards, against | 意見に対して反論する。 Argue against an opinion. |
| ～によって / ～による | by, depending on | 人によって意見が異なる。 Opinions differ by person. |
| ～に際して | on the occasion of (formal) | ご入学に際してお祝い申し上げます。 |
| ～をもって | with, by means of; as of (formal) | これをもって終了とします。 |
| ～にわたって | over, spanning | 三年にわたって研究した。 Researched over three years. |
| ～とともに | together with, as | 社会の変化とともに価値観も変わる。 |
| ～いかんによって | depending on (very formal) | 結果いかんによって対応が変わる。 |
