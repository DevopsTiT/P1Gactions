# JLPT N4 — Vocabulary & Kanji

N4 expands to ~1500 vocabulary words and ~300 kanji total (including N5).

---

## N4 Essential Kanji (Additional ~170 from N5 base)

| Kanji | On | Kun | Meaning | Example |
|---|---|---|---|---|
| 悪 | アク | わる-い | bad, evil | 悪い (わるい) bad |
| 暗 | アン | くら-い | dark | 暗い (くらい) dark |
| 以 | イ | — | by means of | 以上 (いじょう) above |
| 医 | イ | — | medicine | 医者 (いしゃ) doctor |
| 意 | イ | — | intention | 意味 (いみ) meaning |
| 飲 | イン | の-む | drink | 飲み物 (のみもの) drink |
| 院 | イン | — | institution | 病院 (びょういん) hospital |
| 運 | ウン | はこ-ぶ | carry, luck | 運動 (うんどう) exercise |
| 英 | エイ | — | England, excellent | 英語 (えいご) English |
| 駅 | エキ | — | station | 駅 (えき) station |
| 屋 | オク | や | shop, roof | 本屋 (ほんや) bookstore |
| 音 | オン | おと | sound | 音楽 (おんがく) music |
| 化 | カ | — | change, -ize | 文化 (ぶんか) culture |
| 科 | カ | — | subject, section | 科学 (かがく) science |
| 夏 | カ | なつ | summer | 夏休み (なつやすみ) summer vacation |
| 家 | カ | いえ | house, family | 家族 (かぞく) family |
| 会 | カイ | あ-う | meet, society | 会社 (かいしゃ) company |
| 開 | カイ | ひら-く | open | 開始 (かいし) start |
| 界 | カイ | — | world, boundary | 世界 (せかい) world |
| 帰 | キ | かえ-る | return | 帰宅 (きたく) returning home |
| 記 | キ | しる-す | record | 日記 (にっき) diary |
| 急 | キュウ | いそ-ぐ | hurry, sudden | 急行 (きゅうこう) express train |
| 教 | キョウ | おし-える | teach | 教室 (きょうしつ) classroom |
| 強 | キョウ | つよ-い | strong | 強い (つよい) strong |
| 近 | キン | ちか-い | near | 近く (ちかく) nearby |
| 経 | ケイ | へ-る | pass through | 経験 (けいけん) experience |
| 決 | ケツ | き-める | decide | 決定 (けってい) decision |
| 建 | ケン | た-てる | build | 建物 (たてもの) building |
| 研 | ケン | と-ぐ | sharpen, research | 研究 (けんきゅう) research |
| 子 | シ | こ | child | 子供 (こども) child |
| 仕 | シ | つか-える | serve | 仕事 (しごと) work |
| 事 | ジ | こと | thing, matter | 仕事 (しごと) work |
| 試 | シ | こころ-みる | try, test | 試験 (しけん) exam |
| 借 | シャク | か-りる | borrow | 借りる (かりる) to borrow |
| 社 | シャ | — | company, shrine | 会社 (かいしゃ) company |
| 弱 | ジャク | よわ-い | weak | 弱い (よわい) weak |
| 主 | シュ | ぬし | master, main | 主人 (しゅじん) husband, master |
| 春 | シュン | はる | spring | 春 (はる) spring |
| 消 | ショウ | き-える | disappear, erase | 消す (けす) to erase |
| 乗 | ジョウ | の-る | ride | 乗り換え (のりかえ) transfer |
| 新 | シン | あたら-しい | new | 新聞 (しんぶん) newspaper |
| 親 | シン | おや | parent, intimate | 親切 (しんせつ) kind |
| 図 | ズ | はか-る | diagram, map | 図書館 (としょかん) library |
| 数 | スウ | かず | number | 数字 (すうじ) numeral |
| 正 | セイ | ただ-しい | correct | 正しい (ただしい) correct |
| 切 | セツ | き-る | cut | 大切 (たいせつ) important |
| 晴 | セイ | は-れる | clear (weather) | 晴れ (はれ) sunny |
| 専 | セン | — | specialty | 専門 (せんもん) specialty |
| 走 | ソウ | はし-る | run | 走る (はしる) to run |
| 待 | タイ | ま-つ | wait | 待つ (まつ) to wait |
| 代 | ダイ | か-わる | replace, generation | 時代 (じだい) era |
| 体 | タイ | からだ | body | 体 (からだ) body |
| 台 | ダイ | — | platform, counter | 台風 (たいふう) typhoon |
| 知 | チ | し-る | know | 知る (しる) to know |
| 着 | チャク | き-る | arrive, wear | 着く (つく) to arrive |
| 地 | チ | — | earth, ground | 地下鉄 (ちかてつ) subway |
| 通 | ツウ | とお-る | pass, commute | 通学 (つうがく) commuting to school |
| 転 | テン | ころ-がる | roll, fall, change | 自転車 (じてんしゃ) bicycle |
| 電 | デン | — | electricity | 電車 (でんしゃ) train |
| 度 | ド | たび | degree, time | 今度 (こんど) this time |
| 働 | ドウ | はたら-く | work | 働く (はたらく) to work |
| 特 | トク | — | special | 特別 (とくべつ) special |
| 肉 | ニク | — | meat | 牛肉 (ぎゅうにく) beef |
| 熱 | ネツ | あつ-い | heat, fever | 熱い (あつい) hot |
| 農 | ノウ | — | agriculture | 農業 (のうぎょう) agriculture |
| 配 | ハイ | くば-る | distribute, worry | 心配 (しんぱい) worry |
| 売 | バイ | う-る | sell | 売り場 (うりば) sales counter |
| 半 | ハン | なか-ば | half | 半分 (はんぶん) half |
| 番 | バン | — | number, turn | 番号 (ばんごう) number |
| 病 | ビョウ | やま-い | illness | 病気 (びょうき) illness |
| 品 | ヒン | しな | goods, quality | 商品 (しょうひん) product |
| 服 | フク | — | clothes | 洋服 (ようふく) Western clothes |
| 物 | ブツ | もの | thing | 食べ物 (たべもの) food |
| 文 | ブン | ふみ | writing, sentence | 文章 (ぶんしょう) text |
| 別 | ベツ | わか-れる | different, separate | 特別 (とくべつ) special |
| 勉 | ベン | — | endeavour | 勉強 (べんきょう) study |
| 歩 | ホ | ある-く | walk | 散歩 (さんぽ) walk |
| 方 | ホウ | かた | direction, person | 方法 (ほうほう) method |
| 野 | ヤ | の | field, wild | 野菜 (やさい) vegetables |
| 夜 | ヤ | よる | night | 夜 (よる) night |
| 用 | ヨウ | もち-いる | use, business | 用事 (ようじ) errand |
| 洋 | ヨウ | — | ocean, Western | 洋食 (ようしょく) Western food |
| 旅 | リョ | たび | travel | 旅行 (りょこう) travel |
| 力 | リョク | ちから | power | 努力 (どりょく) effort |
| 林 | リン | はやし | forest | 森林 (しんりん) forest |
| 冷 | レイ | さ-める | cold | 冷蔵庫 (れいぞうこ) refrigerator |
| 曜 | ヨウ | — | day of the week | 月曜日 (げつようび) Monday |

---

## N4 Vocabulary by Category

### Verbs (N4)
| Word | Reading | Meaning | Type |
|---|---|---|---|
| 上がる | あがる | to rise, to go up | U |
| 集まる | あつまる | to gather | U |
| 生きる | いきる | to live | RU |
| 動く | うごく | to move | U |
| 売れる | うれる | to sell well | RU |
| 選ぶ | えらぶ | to choose | U |
| 起きる | おきる | to wake up | RU |
| 思い出す | おもいだす | to recall | U |
| 折れる | おれる | to break, to fold | RU |
| 替える | かえる | to exchange | RU |
| 感じる | かんじる | to feel | RU |
| 消える | きえる | to disappear | RU |
| 決まる | きまる | to be decided | U |
| 比べる | くらべる | to compare | RU |
| 壊れる | こわれる | to break | RU |
| 捜す | さがす | to search for | U |
| 下がる | さがる | to fall, go down | U |
| 信じる | しんじる | to believe | RU |
| 続く | つづく | to continue | U |
| 手伝う | てつだう | to help | U |
| 届く | とどく | to reach, arrive | U |
| 止まる | とまる | to stop | U |
| 泊まる | とまる | to stay (overnight) | U |
| 直す | なおす | to fix, correct | U |
| 鳴る | なる | to ring, sound | U |
| 逃げる | にげる | to flee | RU |
| 脱ぐ | ぬぐ | to take off (clothes) | U |
| 盗む | ぬすむ | to steal | U |
| 眠る | ねむる | to sleep | U |
| 乗り換える | のりかえる | to transfer | RU |
| 生まれる | うまれる | to be born | RU |
| 始まる | はじまる | to begin | U |
| 払う | はらう | to pay | U |
| 増える | ふえる | to increase | RU |
| 別れる | わかれる | to separate | RU |
| 分かれる | わかれる | to branch, divide | RU |
| 忘れる | わすれる | to forget | RU |
| 渡る | わたる | to cross | U |
| 笑う | わらう | to laugh | U |

### Nouns (N4)
| Word | Reading | Meaning |
|---|---|---|
| 意味 | いみ | meaning |
| 運動 | うんどう | exercise, movement |
| 映画 | えいが | movie |
| 音楽 | おんがく | music |
| 会議 | かいぎ | meeting |
| 会社 | かいしゃ | company |
| 外国 | がいこく | foreign country |
| 風邪 | かぜ | cold (illness) |
| 家族 | かぞく | family |
| 環境 | かんきょう | environment |
| 気持ち | きもち | feeling |
| 空港 | くうこう | airport |
| 経験 | けいけん | experience |
| 研究 | けんきゅう | research |
| 公園 | こうえん | park |
| 交通 | こうつう | traffic, transport |
| 子供 | こども | child |
| 自転車 | じてんしゃ | bicycle |
| 社会 | しゃかい | society |
| 習慣 | しゅうかん | habit, custom |
| 授業 | じゅぎょう | class, lesson |
| 趣味 | しゅみ | hobby |
| 将来 | しょうらい | future |
| 食事 | しょくじ | meal |
| 新聞 | しんぶん | newspaper |
| 生活 | せいかつ | daily life |
| 専門 | せんもん | specialty |
| 地下鉄 | ちかてつ | subway |
| 図書館 | としょかん | library |
| 特別 | とくべつ | special |
| 友達 | ともだち | friend |
| 仲間 | なかま | companion |
| 荷物 | にもつ | baggage, luggage |
| 日記 | にっき | diary |
| 場所 | ばしょ | place |
| 病気 | びょうき | illness |
| 文化 | ぶんか | culture |
| 文章 | ぶんしょう | text, sentence |
| 約束 | やくそく | promise |
| 理由 | りゆう | reason |
| 旅行 | りょこう | travel |

### Expressions & Grammar Words (N4)
| Word | Reading | Meaning |
|---|---|---|
| ～ために | ～ために | in order to, because of |
| ～ながら | ～ながら | while doing |
| ～ようになる | ～ようになる | to come to / become able to |
| ～てみる | ～てみる | to try doing |
| ～てしまう | ～てしまう | to end up doing |
| ～てあげる | ～てあげる | to do (for someone) |
| ～てもらう | ～てもらう | to have someone do |
| ～てくれる | ～てくれる | to do for me |
| ～なければならない | — | must do |
| ～てはいけない | — | must not do |
| ～かもしれない | — | might, maybe |
| ～はずだ | — | supposed to be |
| ～らしい | — | seems like, apparently |
| ～そうだ | — | looks like / heard that |
| ～んです / ～のです | — | the thing is (explanation) |
| ～でしょう | — | probably, right? |
