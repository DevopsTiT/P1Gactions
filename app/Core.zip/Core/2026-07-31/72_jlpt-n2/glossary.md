# JLPT N5–N2 Study Glossary — Terms and Concepts Explained

---

**JLPT (Japanese Language Proficiency Test)**
日本語能力試験 (にほんごのうりょくしけん). A standardized test of Japanese language ability for non-native speakers. Five levels: N5 (easiest) to N1 (hardest). Recognized by Japanese companies and universities. Run twice a year (July and December).

**N5**
The entry-level JLPT. Tests basic hiragana, katakana, ~100 kanji, and simple everyday vocabulary and grammar. Equivalent to a few months of beginner study. Can handle simple greetings, numbers, and basic daily conversations.

**N4**
Elementary level. ~300 kanji, ~1,500 vocabulary words. Can understand basic Japanese in everyday situations. Required for some entry-level positions in Japan or university admission.

**N3**
Intermediate bridge level. ~650 kanji, ~3,750 words. Can understand Japanese used in everyday situations to a certain degree. The hardest level to reach for many learners — the jump from N4 to N3 is steep.

**N2**
Upper-intermediate. ~1,000 kanji, ~6,000 vocabulary words, complex grammar patterns. Can read newspapers, understand most TV dramas, and work in Japanese business environments. Requirement for many professional jobs in Japan.

**N1**
Advanced/near-native level. ~2,000 kanji, ~10,000 words. Can understand Japanese used in a wide variety of circumstances. Required for highly professional roles, academic study, and native-level work.

**Hiragana (ひらがな)**
The basic Japanese phonetic alphabet with 46 characters (+ voiced/combination variants). Every Japanese sound can be written in hiragana. Used for: native Japanese words, verb endings, particles, and words with no kanji. Must be mastered before N5.

**Katakana (カタカナ)**
A second phonetic alphabet with the same sounds as hiragana. Used for: foreign loanwords (コーヒー = coffee), foreign names, emphasis, onomatopoeia, and scientific terms. Must be mastered before N5.

**Kanji (漢字)**
Chinese-origin characters used in Japanese writing. Each can have multiple readings (on-yomi from Chinese, kun-yomi Japanese native reading). Essential for reading any native Japanese text. ~2,136 are officially designated for daily use (常用漢字).

**On-yomi (音読み)**
The Chinese-derived reading of a kanji. Usually used in compound words (熟語). Example: 山 = サン in 富士山 (ふじさん). Written in katakana in dictionaries to distinguish from kun-yomi.

**Kun-yomi (訓読み)**
The Japanese native reading of a kanji. Usually used when the kanji stands alone or with hiragana endings. Example: 山 = やま in 山 (やま) "mountain." Written in hiragana in dictionaries.

**Vocabulary (語彙 / ごい)**
The set of words known at each level. JLPT does not publish an official word list, but recognized study materials (like 日本語能力試験 公式問題集) define the expected range. Vocabulary appears in all four test sections.

**Grammar Pattern (文法 / ぶんぽう)**
A structural expression or construction used to convey a specific meaning. Example: ～にもかかわらず = "despite, regardless of." N2 has ~200 key patterns that appear in reading and in the grammar/expression test section.

**Particle (助詞 / じょし)**
Small function words that follow nouns to show grammatical role. は = topic marker, が = subject, を = object, に = direction/time/purpose, で = place/means, から = from, まで = until, と = with/and. Mastered in N5/N4, but nuances continue through N2.

**て-form (て形 / てけい)**
The connective form of a verb. Used to: connect actions (食べて飲んだ = ate and drank), make requests (食べてください), form compound structures (食べてみる = try eating). Foundation of Japanese grammar from N5 onward.

**Transitive verb (他動詞 / たどうし)**
A verb that takes a direct object (marked by を). Example: 開ける (あける) = to open [something]. The subject actively causes the action. Contrast with intransitive.

**Intransitive verb (自動詞 / じどうし)**
A verb that does NOT take a direct object — the subject undergoes the action. Example: 開く (あく) = to open [by itself]. Japanese has many transitive/intransitive pairs that N2 tests distinguish. Example: 消す (けす) vs 消える (きえる).

**Plain form (普通形 / ふつうけい)**
The dictionary/casual form of verbs and adjectives. Used in: informal speech, subordinate clauses, before のです, before から, after と思う. Contrast with polite form (ます/です).

**Polite form (丁寧形 / ていねいけい)**
The formal form ending in ます (verbs) or です (nouns/adjectives). Used in: formal situations, with strangers, in business. N2 tests both forms and the formal/written register extensively.

**Humble language (謙譲語 / けんじょうご)**
Polite speech where the speaker lowers themselves. いただく = receive (humble), いたす = do (humble), おる = be/exist (humble). Used when speaking about your own actions to someone above you in social status.

**Respectful language (尊敬語 / そんけいご)**
Polite speech where the speaker elevates the listener/person being discussed. いらっしゃる = be/go/come (respectful), おっしゃる = say (respectful), めしあがる = eat/drink (respectful). N2 tests this vocabulary.

**Conjunction (接続詞 / せつぞくし)**
Words that connect sentences or clauses. しかし = however, だから = therefore, そして = and then, ところが = but (unexpected). Critical for understanding text structure in N2 reading.

**Conditional form (条件形 / じょうけんけい)**
Verb forms expressing "if/when." ば-form (高ければ = if expensive), たら-form (雨が降ったら = if it rains), と-form (春になると = when spring comes), なら-form (行くなら = if you go). N4 introduces all four; N2/N3 test nuanced differences.

**Nominalization (名詞化 / めいしか)**
Turning a verb or adjective into a noun using こと or の. 勉強することが大切 = Studying is important. Allows verbs to serve as subjects or objects. Common in formal writing tested at N2/N3.

**Passive voice (受身形 / うけみけい)**
Expressing that the subject receives the action. 怒られた = was scolded. Verb stem + られる. Japanese passive often implies negative nuance (unwanted action done to the subject). N4 introduces; N2 uses extensively.

**Causative (使役形 / しえきけい)**
Making someone do something. 食べさせる = make/let eat. Verb stem + させる. Combined with passive = 使役受身 (させられる) = "was made to do." Very common in N2 reading texts.

**Potential form (可能形 / かのうけい)**
Expressing ability to do something. 食べられる = can eat. Alternative: 食べることができる. N4 introduces; used throughout N2 texts.

**Volitional form (意志形 / いしけい)**
Expressing intention or invitation: 行こう = let's go / I'll go. Used in ようとする (trying to do), ようとしない (refusing to do), まいとする (trying not to do). Appears in N3/N2 grammar.

**Compound verb (複合動詞 / ふくごうどうし)**
A verb formed by combining two verbs: 取り込む (take in), 申し込む (apply for), 引き受ける (undertake). Very common in N2 vocabulary. Front part is ます-stem; second part is another verb.

**Compound noun (複合名詞 / ふくごうめいし)**
A noun formed by combining two words: 日本語 (Japanese language), 電話番号 (phone number), 生活費 (living expenses). Most N2 vocabulary expansion comes through learning these patterns.

**～的 (-teki)**
Suffix meaning "-ic, -ish, -like, -al." Creates な-adjectives from nouns. 一般的 (general), 具体的 (concrete), 感情的 (emotional). Extremely productive at N2 — learn the base nouns and the pattern applies.

**Homophone (同音異義語 / どうおんいぎご)**
Words with the same pronunciation but different kanji and meanings. Common in Japanese due to limited sound combinations. JLPT N2 kanji sections test whether you know which kanji to use: 機会 (きかい = opportunity) vs 機械 (きかい = machine).

**Context (文脈 / ぶんみゃく)**
The surrounding text that determines meaning. Critical for N2 vocabulary questions that give a blank in a sentence — the correct word is determined by context, not just translation.

**Reading Comprehension (読解 / どっかい)**
The section of the JLPT that tests understanding of written texts. N2 includes: short passages, medium-length articles, and information retrieval from notices/charts. Tests vocabulary, grammar, and overall comprehension.

**Listening Comprehension (聴解 / ちょうかい)**
The JLPT section testing ability to understand spoken Japanese. N2 uses natural speech speed with overlapping conversations, announcements, and explanations. No written script — must understand from audio alone.

**Pitch accent (ピッチアクセント)**
Japanese uses pitch (high/low tone) rather than stress to distinguish words. 橋 (hashi = bridge) and 箸 (hashi = chopsticks) sound identical in isolation but differ in pitch pattern. Not directly tested in JLPT but affects speaking and listening comprehension.

**JLPT scoring**
The test uses scaled scoring (not percentage). Minimum passing score varies by section. For N2: total minimum is 90/180, and each section (language knowledge, reading, listening) has a minimum threshold. Failing one section = failing the test even if total is high.

**SRS (Spaced Repetition System)**
A study method where vocabulary flashcards are reviewed at increasing intervals based on how well you remember them. Tools: Anki, WaniKani (for kanji). Most efficient way to memorize large vocabulary sets for JLPT.

**Anki**
A free flashcard application using SRS. Available on desktop and mobile. The standard tool for serious JLPT students. Pre-made N2 decks available for download. Review 20-50 new cards per day.

**WaniKani**
A web service for learning Japanese kanji and vocabulary using SRS and mnemonics. Structured by levels (1-60), covering N5-N1 kanji progressively. Subscription-based but very systematic.

**Minna no Nihongo (みんなの日本語)**
A popular Japanese textbook series used worldwide. Books 1-2 roughly cover N5-N4 grammar. Common in Japanese language schools. Purely in Japanese from lesson 1 (no English in main text).

**Genki**
Another popular beginner-intermediate textbook (Volumes I and II). More learner-friendly layout with English explanations. Covers roughly N5-N4 level.

**JLPT N2 pass rate**
Approximately 35-45% of test-takers pass N2 globally. Considered a significant achievement that demonstrates real Japanese ability for work and daily life.
