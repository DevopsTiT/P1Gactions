# JLPT N3 — Vocabulary & Kanji

N3 is the intermediate bridge. ~3750 vocabulary words, ~650 kanji total.

---

## N3 Key Kanji (Additional ~300 from N4/N5 base)

| Kanji | On | Kun | Meaning | Example |
|---|---|---|---|---|
| 愛 | アイ | — | love | 愛情 (あいじょう) affection |
| 案 | アン | — | idea, plan | 提案 (ていあん) proposal |
| 位 | イ | くらい | rank, position | 地位 (ちい) social status |
| 委 | イ | — | entrust | 委員 (いいん) committee member |
| 囲 | イ | かこ-む | surround | 周囲 (しゅうい) surroundings |
| 印 | イン | しるし | stamp, mark | 印象 (いんしょう) impression |
| 宇 | ウ | — | space, eaves | 宇宙 (うちゅう) universe |
| 映 | エイ | うつ-る | reflect, project | 映画 (えいが) movie |
| 延 | エン | のば-す | extend, postpone | 延長 (えんちょう) extension |
| 演 | エン | — | perform | 演説 (えんぜつ) speech |
| 応 | オウ | こた-える | respond | 対応 (たいおう) correspondence |
| 温 | オン | あたた-かい | warm | 温度 (おんど) temperature |
| 確 | カク | たし-か | certain | 確認 (かくにん) confirmation |
| 活 | カツ | い-きる | lively, activity | 生活 (せいかつ) daily life |
| 感 | カン | — | feeling | 感謝 (かんしゃ) gratitude |
| 管 | カン | くだ | pipe, manage | 管理 (かんり) management |
| 観 | カン | み-る | view, observe | 観光 (かんこう) sightseeing |
| 願 | ガン | ねが-う | wish, request | 願い (ねがい) wish |
| 機 | キ | はた | machine, opportunity | 機会 (きかい) opportunity |
| 期 | キ | — | period, expect | 期待 (きたい) expectation |
| 逆 | ギャク | さか-らう | reverse | 逆に (ぎゃくに) on the contrary |
| 求 | キュウ | もと-める | seek, demand | 要求 (ようきゅう) demand |
| 許 | キョ | ゆる-す | permit, forgive | 許可 (きょか) permission |
| 況 | キョウ | — | state, situation | 状況 (じょうきょう) situation |
| 協 | キョウ | — | cooperate | 協力 (きょうりょく) cooperation |
| 胸 | キョウ | むね | chest, heart | 胸 (むね) chest |
| 驚 | キョウ | おどろ-く | surprise | 驚く (おどろく) to be surprised |
| 苦 | ク | くる-しい | suffering | 苦労 (くろう) hardship |
| 訓 | クン | おし-える | teach, Japanese reading | 訓練 (くんれん) training |
| 係 | ケイ | かか-る | connection, staff | 関係 (かんけい) relationship |
| 欠 | ケツ | か-ける | lack | 欠席 (けっせき) absence |
| 結 | ケツ | むす-ぶ | result, tie | 結婚 (けっこん) marriage |
| 険 | ケン | けわ-しい | steep, dangerous | 危険 (きけん) danger |
| 検 | ケン | — | examine | 検討 (けんとう) examination |
| 現 | ゲン | あらわ-れる | appear, present | 現在 (げんざい) present |
| 限 | ゲン | かぎ-る | limit | 限る (かぎる) to limit |
| 効 | コウ | き-く | effective | 効果 (こうか) effect |
| 功 | コウ | — | achievement | 成功 (せいこう) success |
| 港 | コウ | みなと | harbour, port | 空港 (くうこう) airport |
| 合 | ゴウ | あ-う | suit, combine | 合う (あう) to fit, match |
| 告 | コク | — | announce | 報告 (ほうこく) report |
| 採 | サイ | と-る | collect, adopt | 採用 (さいよう) hiring |
| 際 | サイ | きわ | edge, occasion | 国際 (こくさい) international |
| 様 | サマ | さま | state, manner | 様子 (ようす) situation |
| 産 | サン | う-む | produce, birth | 産業 (さんぎょう) industry |
| 残 | ザン | のこ-る | remain | 残念 (ざんねん) regret |
| 支 | シ | ささ-える | support | 支持 (しじ) support |
| 識 | シキ | — | knowledge | 常識 (じょうしき) common sense |
| 質 | シツ | — | quality | 品質 (ひんしつ) quality |
| 指 | シ | ゆび | finger, point | 指示 (しじ) instruction |
| 示 | ジ | しめ-す | show | 表示 (ひょうじ) display |
| 実 | ジツ | みの-る | reality, fruit | 実際 (じっさい) in reality |
| 守 | シュ | まも-る | protect | 守る (まもる) to protect |
| 受 | ジュ | う-ける | receive | 受ける (うける) to receive |
| 集 | シュウ | あつ-まる | gather | 集中 (しゅうちゅう) concentration |
| 従 | ジュウ | したが-う | follow | 従う (したがう) to follow |
| 重 | ジュウ | おも-い | heavy, important | 重要 (じゅうよう) important |
| 処 | ショ | — | deal with, place | 処理 (しょり) handling |
| 証 | ショウ | — | proof | 証明 (しょうめい) proof |
| 承 | ショウ | — | consent, inherit | 承認 (しょうにん) approval |
| 省 | ショウ | はぶ-く | omit, ministry | 省エネ (しょうエネ) energy saving |
| 招 | ショウ | まね-く | invite | 招待 (しょうたい) invitation |
| 象 | ショウ | — | phenomenon, symbol | 現象 (げんしょう) phenomenon |
| 信 | シン | — | trust | 信頼 (しんらい) trust |
| 進 | シン | すす-む | advance | 進歩 (しんぽ) progress |
| 心 | シン | こころ | heart, mind | 心配 (しんぱい) worry |
| 成 | セイ | な-る | become, achieve | 成功 (せいこう) success |
| 清 | セイ | きよ-い | clean, clear | 清潔 (せいけつ) cleanliness |
| 積 | セキ | つ-む | pile up | 積極的 (せっきょくてき) proactive |
| 接 | セツ | — | contact, connect | 接続 (せつぞく) connection |
| 想 | ソウ | おも-う | think, imagine | 想像 (そうぞう) imagination |
| 送 | ソウ | おく-る | send | 送る (おくる) to send |
| 達 | タツ | — | reach, pluralizer | 達成 (たっせい) achievement |
| 断 | ダン | ことわ-る | refuse, cut | 断る (ことわる) to refuse |
| 張 | チョウ | は-る | stretch, stick | 主張 (しゅちょう) assertion |
| 調 | チョウ | しら-べる | investigate, tune | 調査 (ちょうさ) survey |
| 提 | テイ | さ-げる | present | 提案 (ていあん) proposal |
| 的 | テキ | まと | target, -ic | 目的 (もくてき) purpose |
| 投 | トウ | な-げる | throw | 投票 (とうひょう) voting |
| 統 | トウ | す-べる | govern, unite | 統計 (とうけい) statistics |
| 得 | トク | え-る | gain | 得る (える) to gain |
| 難 | ナン | むずか-しい | difficult | 困難 (こんなん) difficulty |
| 認 | ニン | みと-める | recognize | 認める (みとめる) to admit |
| 任 | ニン | まか-せる | entrust, duty | 責任 (せきにん) responsibility |
| 念 | ネン | — | thought | 残念 (ざんねん) regret |
| 能 | ノウ | — | ability | 可能 (かのう) possible |
| 判 | ハン | — | judge | 判断 (はんだん) judgement |
| 否 | ヒ | — | negate, no | 否定 (ひてい) denial |
| 表 | ヒョウ | あらわ-す | express, list | 表現 (ひょうげん) expression |
| 評 | ヒョウ | — | evaluate | 評価 (ひょうか) evaluation |
| 複 | フク | — | double | 複雑 (ふくざつ) complex |
| 変 | ヘン | か-わる | change, strange | 変化 (へんか) change |
| 報 | ホウ | — | report, reward | 情報 (じょうほう) information |
| 末 | マツ | すえ | end | 週末 (しゅうまつ) weekend |
| 満 | マン | み-ちる | full | 満足 (まんぞく) satisfaction |
| 命 | メイ | いのち | life, order | 命令 (めいれい) command |
| 役 | ヤク | — | role, use | 役に立つ (やくにたつ) useful |
| 与 | ヨ | あた-える | give | 与える (あたえる) to give |
| 陽 | ヨウ | — | sun, positive | 太陽 (たいよう) sun |
| 様 | ヨウ | さま | manner, -like | 様子 (ようす) appearance |
| 落 | ラク | お-ちる | fall, drop | 落ちる (おちる) to fall |
| 利 | リ | き-く | profit, sharp | 利用 (りよう) use |
| 料 | リョウ | — | fee, material | 料金 (りょうきん) fee |
| 類 | ルイ | たぐい | kind, similar | 種類 (しゅるい) variety |
| 例 | レイ | たと-える | example | 例えば (たとえば) for example |
| 連 | レン | つら-なる | connect | 連絡 (れんらく) contact |

---

## N3 Core Vocabulary by Category

### Verbs (N3 — High Frequency)
| Word | Reading | Meaning |
|---|---|---|
| 諦める | あきらめる | to give up |
| 扱う | あつかう | to handle |
| 改める | あらためる | to reform, renew |
| 表れる | あらわれる | to appear |
| 生かす | いかす | to make use of |
| 祈る | いのる | to pray |
| 植える | うえる | to plant |
| 疑う | うたがう | to doubt |
| 移る | うつる | to move, shift |
| 訴える | うったえる | to appeal, sue |
| 思われる | おもわれる | to seem, appear |
| 落ち着く | おちつく | to calm down |
| 驚く | おどろく | to be surprised |
| 思い込む | おもいこむ | to be convinced |
| 返す | かえす | to return (something) |
| 限る | かぎる | to limit |
| 重なる | かさなる | to overlap |
| 考え直す | かんがえなおす | to reconsider |
| 気がつく | きがつく | to notice |
| 断る | ことわる | to refuse |
| 困る | こまる | to be troubled |
| 壊す | こわす | to destroy |
| 探す | さがす | to search |
| 避ける | さける | to avoid |
| 支える | ささえる | to support |
| 叫ぶ | さけぶ | to shout |
| 信じる | しんじる | to believe |
| 調べる | しらべる | to investigate |
| 勧める | すすめる | to recommend |
| 育てる | そだてる | to raise |
| 倒れる | たおれる | to collapse |
| 助ける | たすける | to help |
| 頼む | たのむ | to request |
| 通じる | つうじる | to communicate, connect |
| 伝える | つたえる | to convey |
| 努める | つとめる | to strive |
| 届ける | とどける | to deliver |
| 取り組む | とりくむ | to tackle |
| 慣れる | なれる | to get used to |
| 認める | みとめる | to admit |
| 逃げる | にげる | to escape |
| 悩む | なやむ | to be troubled |
| 眠る | ねむる | to sleep |
| 狙う | ねらう | to target |
| 励ます | はげます | to encourage |
| 外れる | はずれる | to miss |
| 守る | まもる | to protect |
| 求める | もとめる | to seek |
| 申し込む | もうしこむ | to apply |
| 戻る | もどる | to return |
| 許す | ゆるす | to forgive |
| 喜ぶ | よろこぶ | to rejoice |
| 別れる | わかれる | to separate |
| 笑う | わらう | to laugh |
| 割れる | われる | to break |

### Nouns (N3 — Most Common)
| Word | Reading | Meaning |
|---|---|---|
| 合図 | あいず | signal |
| 相手 | あいて | partner, opponent |
| 当たり前 | あたりまえ | obvious, natural |
| 影響 | えいきょう | influence |
| 大人 | おとな | adult |
| お互い | おたがい | each other, mutual |
| 記憶 | きおく | memory |
| 機会 | きかい | opportunity |
| 気分 | きぶん | mood, feeling |
| 行動 | こうどう | action, behaviour |
| 言葉 | ことば | word, language |
| 子育て | こそだて | child-rearing |
| 根拠 | こんきょ | basis, grounds |
| 状況 | じょうきょう | situation |
| 状態 | じょうたい | state, condition |
| 情報 | じょうほう | information |
| 人間 | にんげん | human being |
| 性格 | せいかく | personality |
| 成功 | せいこう | success |
| 責任 | せきにん | responsibility |
| 説明 | せつめい | explanation |
| 想像 | そうぞう | imagination |
| 態度 | たいど | attitude |
| 立場 | たちば | standpoint |
| 他人 | たにん | other people |
| 特徴 | とくちょう | characteristic |
| 努力 | どりょく | effort |
| 仲 | なか | relationship |
| 悩み | なやみ | worry, trouble |
| 能力 | のうりょく | ability |
| 場合 | ばあい | case, situation |
| 判断 | はんだん | judgement |
| 不安 | ふあん | anxiety |
| 変化 | へんか | change |
| 目的 | もくてき | purpose |
| 役に立つ | やくにたつ | to be useful |
| 余裕 | よゆう | margin, room |
| 理由 | りゆう | reason |
| 連絡 | れんらく | contact |
| 割合 | わりあい | ratio |

### N3 Expressions & Grammar Patterns
| Pattern | Meaning |
|---|---|
| ～によって | depending on, due to, by means of |
| ～に対して | towards, against, in contrast to |
| ～に関して | regarding, concerning |
| ～に従って | following, according to |
| ～にわたって | over, across (time/space) |
| ～を通して | through, via |
| ～をもとに | based on |
| ～について | about, concerning |
| ～上で | upon, in terms of |
| ～という | called, that says |
| ～ことになる | it has been decided that |
| ～ことにする | decide to |
| ～ようにする | try to, make sure to |
| ～ようになる | come to, become able to |
| ～わけだ | that is why, no wonder |
| ～わけではない | it's not that |
| ～だけでなく | not only |
| ～てもかまわない | it's OK even if |
| ～だろうと思う | I think it probably is |
| ～はずがない | there is no way |
| ～に違いない | must be, no doubt |
| ～に決まっている | surely, definitely |
| ～かねない | might, liable to |
| ～ざるを得ない | cannot help but |
| ～てはじめて | only after doing |
