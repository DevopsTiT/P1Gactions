# Dynatrace Namespace Label → Tag Injection (Without a Separate Namespace YAML)

---

## The Core Question

You want Dynatrace to automatically tag the `payment-service` entity with:
```
team:payments
environment:production
```

These labels live on the **Namespace** — not on the pod itself.
The question is: **what if you don't have (or don't want) a separate `namespace.yaml` file?**

You have 4 alternatives. Pick the one that matches how your project is structured.

---

## Decision Tree — Which Pattern to Use?

```
Do you already have a namespace defined somewhere?
        │
        YES ──► Add labels directly to that existing definition
        │       (inline in Helm values, Kustomize patch, or Terraform)
        │
        NO  ──► Is the namespace auto-created by a tool (Helm/ArgoCD)?
                        │
                        YES ──► Use Helm values OR patch it post-create
                        │
                        NO  ──► Inline the namespace into the same manifest
                                file as the deployment (multi-doc YAML)
```

---

## Option A — Inline Namespace in the Same Manifest File (Multi-Doc YAML)

If you want everything in ONE file (`payment.yaml`), separate Kubernetes objects
with `---` (three dashes). Kubernetes applies each document independently.

```yaml
# payment.yaml  ← ONE file, TWO documents

# ── Document 1: Namespace ──────────────────────────────────────────────
apiVersion: v1
kind: Namespace
metadata:
  name: payment-ns
  labels:
    team: payments
    environment: production
    dynatrace.com/inject: "true"     # ← tells OneAgent to inject into pods here

---
# ── Document 2: Deployment ────────────────────────────────────────────
apiVersion: apps/v1
kind: Deployment
metadata:
  name: payment-service
  namespace: payment-ns              # ← must reference the namespace above
  labels:
    app: payment-service
    team: payments
    environment: production
spec:
  replicas: 2
  selector:
    matchLabels:
      app: payment-service
  template:
    metadata:
      labels:
        app: payment-service
        team: payments               # ← pod labels (OneAgent reads these too)
        environment: production
    spec:
      containers:
        - name: payment-service
          image: my-registry/payment-service:latest
          ports:
            - containerPort: 8080
```

Apply with a single command:
```bash
kubectl apply -f payment.yaml
# namespace/payment-ns created
# deployment.apps/payment-service created
```

Verify labels are on the namespace:
```bash
kubectl get namespace payment-ns --show-labels
# NAME         STATUS   AGE   LABELS
# payment-ns   Active   5s    dynatrace.com/inject=true,environment=production,team=payments
```

---

## Option B — kubectl annotate/label (Patch an Existing Namespace Without YAML)

If the namespace already exists (created by someone else, by Helm, or by ArgoCD)
and you just need to add labels without touching any file:

```bash
# Add the team and environment labels to an existing namespace
kubectl label namespace payment-ns \
  team=payments \
  environment=production \
  dynatrace.com/inject=true

# Verify
kubectl get namespace payment-ns --show-labels

# Update a label (use --overwrite flag)
kubectl label namespace payment-ns environment=production --overwrite

# Remove a label (trailing dash removes it)
kubectl label namespace payment-ns environment-
```

When to use:
- Quick fix in an emergency
- The namespace is owned by another team and you can't change their YAML
- CI script that patches namespaces after a Helm release creates them

When NOT to use:
- Labels applied this way are not stored in Git → they get lost on namespace recreation
- Not GitOps-friendly — the real source of truth should be a file

---

## Option C — Kustomize Patch (Labels Without Separate Namespace File)

If you use Kustomize, you can inject namespace labels from `kustomization.yaml`
without creating a separate `namespace.yaml`:

```
payment-service/
├── kustomization.yaml   ← labels go here
├── deployment.yaml
└── service.yaml
```

```yaml
# kustomization.yaml
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

namespace: payment-ns   # applies to all resources in this kustomization

# ── Create the namespace with labels (no separate file needed) ──────────
resources:
  - deployment.yaml
  - service.yaml

# ── Define the namespace inline ─────────────────────────────────────────
patches:
  - patch: |-
      apiVersion: v1
      kind: Namespace
      metadata:
        name: payment-ns
        labels:
          team: payments
          environment: production
          dynatrace.com/inject: "true"
    target:
      kind: Namespace
      name: payment-ns

# ── CommonLabels: add these labels to ALL resources ─────────────────────
commonLabels:
  team: payments
  environment: production
```

Or use the `configMapGenerator` / `labels` field for simpler propagation:

```yaml
# kustomization.yaml — simpler approach
apiVersion: kustomize.config.k8s.io/v1beta1
kind: Kustomization

namespace: payment-ns

resources:
  - deployment.yaml
  - service.yaml

# These labels get added to ALL resources (deployment, pods, services)
labels:
  - pairs:
      team: payments
      environment: production
    includeSelectors: false   # don't add to matchLabels (avoids selector conflicts)
    includeTemplates: true    # add to pod template labels too
```

Apply:
```bash
kubectl apply -k payment-service/
```

For the namespace itself with Kustomize, create a minimal `namespace.yaml` but
keep labels in `kustomization.yaml`:

```yaml
# namespace.yaml (minimal — no labels here)
apiVersion: v1
kind: Namespace
metadata:
  name: payment-ns
```

```yaml
# kustomization.yaml
resources:
  - namespace.yaml    # include namespace
  - deployment.yaml

# Add labels to the namespace via patch
patches:
  - target:
      kind: Namespace
      name: payment-ns
    patch: |-
      - op: add
        path: /metadata/labels/team
        value: payments
      - op: add
        path: /metadata/labels/environment
        value: production
      - op: add
        path: /metadata/labels/dynatrace.com~1inject
        value: "true"
        # Note: ~1 is JSON Patch encoding for "/" in key names
```

---

## Option D — Helm: Namespace Labels in values.yaml

If you deploy via Helm and the chart creates the namespace:

```yaml
# values.yaml
namespaceLabels:
  team: payments
  environment: production
  "dynatrace.com/inject": "true"
```

```yaml
# templates/namespace.yaml (inside the chart)
{{- if .Values.createNamespace }}
apiVersion: v1
kind: Namespace
metadata:
  name: {{ .Release.Namespace }}
  labels:
    {{- range $key, $value := .Values.namespaceLabels }}
    {{ $key }}: {{ $value | quote }}
    {{- end }}
{{- end }}
```

Install:
```bash
helm install payment-service ./payment-chart \
  --namespace payment-ns \
  --create-namespace \
  --set namespaceLabels.team=payments \
  --set namespaceLabels.environment=production \
  --set "namespaceLabels.dynatrace\.com/inject=true"
```

For charts you DON'T control (third-party), use a Helm post-renderer or
a separate `helm upgrade --post-renderer` to inject labels after render.

Or simply patch after Helm creates the namespace:
```bash
helm install payment-service ./chart --namespace payment-ns --create-namespace
kubectl label namespace payment-ns team=payments environment=production dynatrace.com/inject=true
```

---

## How Dynatrace Reads the Labels → Creates Tags

### The Inheritance Chain

```
Namespace labels
  team: payments
  environment: production
        │
        │  OneAgent reads namespace metadata
        │  (via Kubernetes API — no agent on the namespace itself)
        ▼
Pod Labels (inherited + propagated by OneAgent)
  team: payments
  environment: production
        │
        ▼
DT Entity: PROCESS_GROUP_INSTANCE "payment-service"
  Tag: team:payments
  Tag: environment:production
        │
        ▼
DT Entity: SERVICE "payment-service"
  Tag: team:payments        ← used for dashboards, alerting, SLOs
  Tag: environment:production
```

### DynaKube: Enable Namespace Label Propagation

For namespace labels to flow into Dynatrace tags, the `DynaKube` resource
must have `namespaceSelector` configured (or cover all namespaces):

```yaml
# dynakube.yaml
apiVersion: dynatrace.com/v1beta1
kind: DynaKube
metadata:
  name: dynakube
  namespace: dynatrace
spec:
  apiUrl: https://<ENV_ID>.live.dynatrace.com/api

  oneAgent:
    cloudNativeFullStack:
      # Optional: only inject into namespaces matching this selector
      # Remove this block to inject into ALL labeled namespaces
      namespaceSelector:
        matchLabels:
          dynatrace.com/inject: "true"   # only namespaces with this label

  metadataEnrichment:
    enabled: true    # ← THIS is what propagates namespace labels to DT tags
    namespaceSelector:
      matchExpressions:
        - key: dynatrace.com/inject
          operator: In
          values: ["true"]
```

```bash
kubectl apply -f dynakube.yaml
```

### Auto-Tagging Rule in Dynatrace UI (Fallback / Extra Control)

If metadata enrichment doesn't pick up the labels automatically, create a
manual auto-tagging rule:

```
Settings → Tags → Automatically applied tags → Add new rule

Rule 1:
  Tag name: team
  Conditions:
    Source: Kubernetes label
    Key: team
    Operator: exists
  Apply to: Services, Process Groups, Process Group Instances

Rule 2:
  Tag name: environment
  Conditions:
    Source: Kubernetes label
    Key: environment
    Operator: exists
  Apply to: Services, Process Groups, Hosts
```

---

## Verification Checklist

```bash
# 1. Namespace has correct labels
kubectl get ns payment-ns --show-labels
# Must show: team=payments, environment=production, dynatrace.com/inject=true

# 2. Pods in the namespace are injected (OneAgent code module present)
kubectl get pods -n payment-ns -o jsonpath='{.items[*].metadata.name}' | xargs -I{} \
  kubectl exec -n payment-ns {} -- ls /opt/dynatrace/oneagent/ 2>/dev/null \
  && echo "INJECTED" || echo "NOT INJECTED"

# 3. Pod labels include team and environment
kubectl get pods -n payment-ns --show-labels
# Should show: team=payments,environment=production on each pod

# 4. Check DynaKube is healthy
kubectl describe dynakube dynakube -n dynatrace | grep -A5 "Phase\|Status\|Conditions"

# 5. In Dynatrace UI:
#    Applications & Microservices → Services → payment-service
#    → Properties → Tags should show: team:payments, environment:production
```

---

## Common Mistakes

| Mistake | What Happens | Fix |
|---|---|---|
| Namespace created but `dynatrace.com/inject=true` label missing | Pods get NO code injection — only infra metrics | Add the label to the namespace |
| Labels on namespace but `metadataEnrichment.enabled: false` in DynaKube | Tags never appear on DT entities | Enable `metadataEnrichment` in DynaKube |
| Labels applied with `kubectl label` (not in YAML) | Labels lost if namespace is recreated | Move labels into a committed YAML/Helm values file |
| Pods already running when labels were added to namespace | Existing pods not injected retroactively | Restart pods: `kubectl rollout restart deployment/payment-service -n payment-ns` |
| Multi-doc YAML: namespace declared AFTER deployment | kubectl applies in order — deployment may reference namespace before it exists | Always put Namespace document FIRST in multi-doc YAML |
