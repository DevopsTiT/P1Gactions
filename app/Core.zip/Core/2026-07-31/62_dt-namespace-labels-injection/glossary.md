# Dynatrace Namespace Label Injection — Glossary

Every term from main.md explained for an SRE beginner.

---

**Kubernetes Namespace**
A virtual partition inside a Kubernetes cluster that groups related pods, services, and other objects together. Like a folder — `payment-ns` holds everything for the payments team. Objects in different namespaces are isolated from each other by default.

**Namespace Label**
A key-value tag attached to a Kubernetes Namespace object itself (not to the pods inside it). Labels on the namespace are metadata about the namespace, not about individual workloads. Example: `team: payments` on the namespace tells Dynatrace which team owns everything running there.

**Pod Label**
A key-value tag attached to a Kubernetes Pod. OneAgent reads pod labels directly. If your pod has `environment: production`, Dynatrace can use that to create a tag on the service entity.

**Label Inheritance**
When a tool (like Dynatrace's metadata enrichment) reads labels from a parent object (the Namespace) and applies them to the monitoring entities of child objects (the pods/services running in that namespace). The pods themselves don't need to re-declare the labels.

**`dynatrace.com/inject: "true"`**
A special Kubernetes label you place on a Namespace to signal to the Dynatrace Operator that pods in this namespace should receive OneAgent code injection. Without this label (or if DynaKube's namespaceSelector requires it), pods only get infrastructure metrics — no distributed traces, no JVM metrics.

**Metadata Enrichment**
A DynaKube feature (`metadataEnrichment.enabled: true`) that tells Dynatrace to read Kubernetes metadata (namespace labels, pod labels, annotations) and automatically create tags on the corresponding Dynatrace entities (Services, Process Groups). This is what turns `team: payments` on a namespace into a `team:payments` tag on the Dynatrace service.

**Multi-Document YAML**
A single YAML file that contains multiple Kubernetes objects, each separated by `---` (three dashes). Kubernetes treats each section as a separate apply. Used when you want all related objects (Namespace + Deployment + Service) in one file without creating multiple files.

**`---` (YAML Document Separator)**
Three dashes on a line by themselves. Tells the YAML parser and `kubectl` that a new Kubernetes object definition starts here. Everything before the next `---` is one document; everything after is another.

**`kubectl apply -f`**
The command to create or update Kubernetes resources from a YAML file. If the resource doesn't exist, it creates it. If it does exist, it updates only the fields that changed. Works on both single-document and multi-document YAML files.

**`kubectl label`**
A command to add, update, or remove labels on an existing Kubernetes object without editing a YAML file. Example: `kubectl label namespace payment-ns team=payments`. Useful for quick patches but not GitOps-friendly because the change isn't stored in a file.

**`--overwrite` flag**
A flag for `kubectl label` that allows updating an existing label's value. Without it, trying to change a label that already exists produces an error.

**Trailing dash (label removal)**
In `kubectl label`, adding a `-` after a label key removes that label. Example: `kubectl label namespace payment-ns environment-` removes the `environment` label from the namespace.

**Kustomize**
A Kubernetes-native configuration tool built into `kubectl`. Lets you define a base set of YAML files and then apply patches, overlays, and transformations without modifying the original files. Used to customize the same base config for dev/staging/production.

**`kustomization.yaml`**
The central config file for a Kustomize directory. Lists which resource files to include and what transformations (patches, labels, namespace overrides) to apply to them.

**`commonLabels` (Kustomize)**
A Kustomize field that adds a set of labels to ALL resources in the kustomization — deployments, services, pods, etc. Convenient for ensuring team and environment labels appear everywhere.

**Kustomize Patch**
A modification to a Kubernetes object defined in `kustomization.yaml`. Can be a strategic merge patch (partial YAML that merges with the target) or a JSON Patch (array of operations like `add`, `replace`, `remove`). Used to add labels to objects without duplicating the entire object YAML.

**JSON Patch**
A standard format for describing changes to a JSON/YAML document as an array of operations (`add`, `remove`, `replace`, `move`). Used in Kustomize patches. Special characters like `/` in key names must be escaped as `~1` — so `dynatrace.com/inject` becomes `dynatrace.com~1inject` in a JSON Patch path.

**Helm**
A package manager for Kubernetes. A "chart" is a bundled, parameterized set of Kubernetes YAML templates. You install a chart with `helm install` and pass parameters via `--set` flags or a `values.yaml` file.

**`values.yaml` (Helm)**
The default configuration file for a Helm chart. Contains key-value pairs that the chart templates reference. You override these with `--set` on the command line or a custom values file. Where you put things like `namespaceLabels.team: payments`.

**`--create-namespace` (Helm)**
A Helm install flag that creates the release namespace if it doesn't already exist. Without it, you must create the namespace manually before `helm install`.

**`helm upgrade --post-renderer`**
A Helm feature that pipes the rendered YAML through an external program before applying it. Used to add labels, annotations, or other modifications to charts you don't control (third-party charts).

**DynaKube**
A Kubernetes Custom Resource (CRD) that the Dynatrace Operator watches. One DynaKube defines all Dynatrace behavior for one Kubernetes cluster — which namespaces to inject, ActiveGate settings, monitoring mode, metadata enrichment, etc.

**`namespaceSelector` (DynaKube)**
A Kubernetes label selector inside the DynaKube spec that controls which namespaces get OneAgent injection. If you set `matchLabels: { dynatrace.com/inject: "true" }`, only labeled namespaces get injected. If omitted, all namespaces get injected.

**`metadataEnrichment` (DynaKube)**
The DynaKube section that controls whether Kubernetes metadata (labels, annotations) is read and converted into Dynatrace tags. Must be `enabled: true` for namespace labels to appear as tags on DT service entities.

**`kubectl rollout restart`**
A command that gradually replaces all pods in a Deployment with fresh ones, without downtime. Used after adding the `dynatrace.com/inject: "true"` label to a namespace — existing pods were started before the label existed and are not injected, so they need to be recycled.

**Code Injection (OneAgent)**
The act of OneAgent inserting its monitoring code module into an application container. Injection happens at pod startup via the Dynatrace CSI driver. After injection, the pod gets full code-level tracing, JVM metrics, and distributed trace propagation — not just infrastructure metrics.

**CSI Driver (Dynatrace)**
Container Storage Interface driver used by Dynatrace to mount the OneAgent code module into application pods as a volume. Enables injection without baking the agent into the application container image. The `dynatrace.com/inject: "true"` namespace label triggers this driver.

**DT Entity**
Anything Dynatrace monitors and tracks as an object — a Host, Process Group, Service, Kubernetes Namespace, Kubernetes Workload, etc. Each entity has an ID (like `SERVICE-abc123`) and can have tags, properties, and relationships to other entities.

**Process Group Instance (PGI)**
The Dynatrace entity representing one running instance of a monitored process — one JVM, one Node.js process, one Go binary. Multiple PGIs running the same code are grouped into a Process Group. Tags on the namespace flow through to the PGI and its parent Service.

**Auto-Tagging Rule (Dynatrace)**
A configuration in Dynatrace UI (`Settings → Tags → Automatically applied tags`) that defines a rule: "whenever an entity has Kubernetes label `team`, create a Dynatrace tag `team:<value>`." Provides manual control over tag creation when automatic metadata enrichment doesn't cover your use case.

**`kubectl get pods --show-labels`**
A kubectl command that lists pods and includes their full label set in the output. Used to verify that team and environment labels are present on the pods (either directly declared or inherited through Kustomize/Helm commonLabels).

**GitOps**
A deployment practice where the desired state of infrastructure and Kubernetes manifests is stored in Git, and an automated tool (ArgoCD, Flux) continuously reconciles the cluster to match what's in Git. Labels stored only via `kubectl label` (not in files) are not GitOps-friendly — they'll be overwritten or lost on the next sync.
