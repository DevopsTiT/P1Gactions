# 83 — OTEL Env Vars Deep Dive: Glossary

Every term from main.md explained for an SRE beginner.

---

**OTEL (OpenTelemetry)**
An open-source observability framework that provides a standard way to collect traces, metrics, and logs from applications. Instead of using vendor-specific agents, you instrument once with OpenTelemetry and send data to any backend (Dynatrace, Jaeger, Prometheus, etc.).

**OTEL Java Agent (`opentelemetry-javaagent.jar`)**
A JAR file that attaches to a JVM at startup via `-javaagent` flag. It automatically instruments your code — without any changes to application source — by rewriting bytecode at load time. It intercepts HTTP calls, database calls, messaging, and more, creating spans for each.

**`JAVA_TOOL_OPTIONS`**
An environment variable that the JVM reads at startup and treats as additional command-line arguments. Setting `JAVA_TOOL_OPTIONS=-javaagent:/path/to/agent.jar` is equivalent to passing `-javaagent` on the command line, but works even in container environments where you can't modify the startup command directly.

**`-javaagent` flag**
A JVM command-line option that loads an instrumentation agent before the application starts. The agent can rewrite class bytecode as classes are loaded, enabling automatic instrumentation without touching source code.

**`OTEL_EXPORTER_OTLP_ENDPOINT`**
The environment variable that tells the OTEL SDK where to send telemetry data. The value is a URL in the form `http://host:port`. Everything about the destination lives here: protocol (http/grpc), hostname, port. Without this, the OTEL SDK doesn't know where to send spans.

**`OTEL_SERVICE_NAME`**
The environment variable that sets the name of the service as it will appear in your observability backend. In Dynatrace, this becomes the SERVICE entity name. Must exactly match any filter or rule in DT that references this service (metric events, management zones, SLOs).

**OTLP (OpenTelemetry Protocol)**
The wire protocol used to transmit OTEL telemetry data. Comes in two flavors: OTLP/gRPC (binary over HTTP/2, port 4317) and OTLP/HTTP (JSON or Protobuf over HTTP/1.1, port 4318). The Dynatrace ActiveGate supports both.

**OTLP/HTTP**
The HTTP/1.1 based variant of OTLP. Sends JSON (or Protobuf) payloads via standard HTTP POST requests to `/v1/traces`, `/v1/metrics`, or `/v1/logs`. Port 4318. Simpler than gRPC — works through proxies and is testable with `curl`.

**OTLP/gRPC**
The gRPC-based variant of OTLP. Binary protocol over HTTP/2. Port 4317. More efficient for high-volume tracing but requires HTTP/2 support and is harder to debug. Both OTLP/HTTP and gRPC carry identical data.

**Port 4318**
The standard port for OTLP/HTTP receivers. Any service wanting to receive OTEL traces via HTTP listens on this port. The ActiveGate opens port 4318 to accept spans from your services.

**Port 4317**
The standard port for OTLP/gRPC receivers. Used when sending spans via gRPC/HTTP/2 instead of HTTP/1.1.

**Span**
One unit of work in distributed tracing — a single operation with a start time, end time, name, status, and attributes. Example: "HTTP GET /api/health" or "SELECT * FROM orders". Spans are nested to form a trace tree showing the full request journey.

**Trace**
A collection of spans linked by a shared trace ID, representing the complete journey of one request through all services. A trace shows: which services were called, in what order, how long each took, and where errors occurred.

**Trace ID**
A 16-byte (128-bit) hex string that uniquely identifies a distributed trace. Every span belonging to the same request shares the same trace ID. Passed between services in the `traceparent` HTTP header.

**`traceparent` header**
The W3C standard HTTP header for passing trace context between services. Format: `00-{traceId}-{spanId}-{flags}`. When service A calls service B, A sends this header. Service B reads it and creates a span with A's span as the parent — linking the two into one trace.

**W3C Trace Context**
The W3C standard for propagating trace information in HTTP headers. Defined by the `traceparent` and `tracestate` headers. OTEL uses this by default (`OTEL_PROPAGATORS=tracecontext`). Dynatrace fully supports this standard.

**BatchSpanProcessor**
An OTEL component that buffers spans in memory and sends them in batches rather than one at a time. Flush triggers: time elapsed (default: 5000ms), batch size reached (default: 512 spans), or service shutting down. Makes exporting efficient — one HTTP POST per batch instead of one per span.

**OTEL SDK**
The OpenTelemetry Software Development Kit — libraries loaded into your application (or attached via Java agent) that create spans, manage context propagation, sample traces, and export data. The Java Agent bundles the SDK and auto-instrumentation into a single JAR.

**`service.name` (resource attribute)**
A standard OTEL resource attribute identifying which service produced a span. Set from `OTEL_SERVICE_NAME`. Attached to every span automatically by the SDK. Dynatrace reads this attribute to name the SERVICE entity.

**Resource Attributes**
Metadata about the process that produced telemetry — not about individual requests. Set at startup via `OTEL_RESOURCE_ATTRIBUTES` or `OTEL_SERVICE_NAME`. Examples: `service.name`, `service.version`, `deployment.environment`. Applied to all spans from that process.

**`OTEL_RESOURCE_ATTRIBUTES`**
An environment variable for setting multiple key=value resource attributes at once. Example: `"deployment.environment=production,service.version=1.2.0"`. These appear as tags on the Dynatrace entity and can be used for management zone filtering.

**`deployment.environment` (OTEL attribute)**
A standard OTEL resource attribute for the environment name (production, staging, dev). Dynatrace can use this for entity tagging and management zone rules. Set via `OTEL_RESOURCE_ATTRIBUTES=deployment.environment=production`.

**`OTEL_PROPAGATORS`**
Defines which context propagation format to use when passing trace context between services. `tracecontext,baggage` = use W3C standards. Must be the same across all services in the system — mismatched propagators break trace stitching (traces appear fragmented in DT).

**`OTEL_TRACES_SAMPLER`**
Controls which traces are recorded and exported. `always_on` = record every trace. `parentbased_always_on` = follow the upstream service's sampling decision (if upstream sampled, you sample too). `traceidratio` = sample a fixed percentage.

**Sampling**
The practice of only recording a fraction of traces to control cost and storage. For development: `always_on` (sample everything). For high-traffic production: `parentbased_always_on` or `traceidratio=0.1` (10% of traces).

**ActiveGate (Dynatrace)**
A Dynatrace relay deployed inside your Kubernetes cluster. Receives telemetry (OTLP, OneAgent data) from your services and forwards it to the DT SaaS tenant. It listens on ports 4317 (gRPC) and 4318 (HTTP) for OTLP data. Runs as a Kubernetes Deployment in the `dynatrace` namespace.

**`dynatrace-activegate` (Kubernetes Service)**
The Kubernetes Service resource that fronts the ActiveGate pods. Provides a stable DNS name and ClusterIP. Even if the ActiveGate pod restarts or scales to 2 replicas, the Service name stays the same. Your services send spans to this Service, not directly to a pod IP.

**Kubernetes Service DNS**
Kubernetes provides automatic DNS resolution for Services within the cluster. Format: `<service-name>.<namespace>.svc` or the full form `<service-name>.<namespace>.svc.cluster.local`. A pod in any namespace can reach any Service by this DNS name, subject to NetworkPolicy restrictions.

**ClusterIP (Kubernetes Service type)**
A virtual IP address assigned to a Kubernetes Service, reachable only from within the cluster. Traffic to a ClusterIP is load-balanced across all healthy pods that match the Service's selector. The ActiveGate Service is typically ClusterIP — not exposed outside the cluster.

**CoreDNS**
The Kubernetes-internal DNS server running in the `kube-system` namespace. Resolves Kubernetes Service DNS names to ClusterIP addresses. When your pod does `nslookup dynatrace-activegate.dynatrace.svc`, CoreDNS answers with the ActiveGate Service's ClusterIP.

**kube-proxy**
A Kubernetes component running on every node that maintains iptables/IPVS rules to route traffic to the correct pods. When your service sends a request to the ActiveGate ClusterIP, kube-proxy routes it to one of the actual ActiveGate pod IPs.

**Bytecode Instrumentation**
Modifying compiled Java class bytecode at load time (when the JVM loads a class) to add tracing code without touching source. The OTEL Java Agent uses this to wrap HTTP handlers, JDBC calls, etc. with span creation/completion code automatically.

**`/v1/traces` (OTLP endpoint path)**
The HTTP path the OTEL SDK posts spans to. The SDK automatically appends this to `OTEL_EXPORTER_OTLP_ENDPOINT`. Full URL: `http://dynatrace-activegate.dynatrace.svc:4318/v1/traces`. Similarly: `/v1/metrics` for metrics, `/v1/logs` for logs.

**`OTEL_BSP_SCHEDULE_DELAY`**
The BatchSpanProcessor's flush interval in milliseconds. Default: 5000ms (5 seconds). Spans are held in a buffer and sent every 5 seconds. Lowering this (e.g., 1000ms) means faster trace delivery but more HTTP requests to the ActiveGate.

**`OTEL_BSP_MAX_EXPORT_BATCH_SIZE`**
The maximum number of spans sent in a single OTLP POST request. Default: 512. If 512 spans accumulate before the time delay fires, an early flush happens. Increasing this reduces HTTP overhead for high-throughput services.

**`OTEL_EXPORTER_OTLP_HEADERS`**
Optional HTTP headers to include in every OTLP export request. Used when the receiver requires authentication. Example: `"Authorization=Bearer my-token"`. The Dynatrace ActiveGate inside the cluster typically doesn't require this — it's already behind cluster auth.

**NetworkPolicy (Kubernetes)**
A Kubernetes resource that controls which pods can communicate with which other pods or external endpoints. If a NetworkPolicy restricts egress from your service's namespace, it may block the OTLP requests to the ActiveGate. Symptom: DNS resolves fine but connection times out when sending spans.

**`SPRING_APPLICATION_NAME`**
A Spring Boot property that sets the application's name. Best practice: keep this in sync with `OTEL_SERVICE_NAME` so that Spring-DT correlation, logging, and OTEL all use the same name. Inconsistency causes confusion when DT shows two different entities for the same service.

**Entity (Dynatrace)**
A monitored component in Dynatrace — a service, host, process, database, or Kubernetes workload. When DT receives spans with `service.name = "new-service"`, it automatically creates a SERVICE entity named "new-service". Entities are what metric events, SLOs, management zones, and dashboards filter on.

**`unknown_service:java`**
The default `service.name` value used by the OTEL SDK when `OTEL_SERVICE_NAME` is NOT set. If you forget to set `OTEL_SERVICE_NAME`, your service appears in DT under this confusing name. Every service without the env var creates the same entity name, causing all their traces to be mixed together.

**`nslookup`**
A command-line DNS lookup tool. `nslookup dynatrace-activegate.dynatrace.svc` tests whether DNS resolution for the ActiveGate Service works from inside the pod. If it returns an IP address, DNS is working. If NXDOMAIN, the Service doesn't exist or has a different name.

**`ps aux`**
A Linux command that lists all running processes with their full command-line arguments. Used to verify the OTEL Java agent is attached: `ps aux | grep javaagent` should show `-javaagent:/otel-agent/opentelemetry-javaagent.jar` in the java process arguments.
