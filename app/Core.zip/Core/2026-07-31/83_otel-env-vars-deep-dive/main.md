# 83 — OTEL Env Vars in Helm values.yaml: Deep Dive

> **What this covers:** The two lines
> `OTEL_EXPORTER_OTLP_ENDPOINT` and `OTEL_SERVICE_NAME` — exactly what each word
> means, why this URL looks the way it does, how the trace actually travels from
> your Java pod to Dynatrace, and what breaks if any part is wrong.

---

## The Two Lines in Context

```yaml
# charts/new-service/values.yaml  (or values-production.yaml)
env:
  - name: OTEL_EXPORTER_OTLP_ENDPOINT
    value: "http://dynatrace-activegate.dynatrace.svc:4318"

  - name: OTEL_SERVICE_NAME
    value: "new-service"
```

These two lines are the only configuration needed to make traces appear in Dynatrace.
Everything else (sampling, batching, retry, timeout) has sensible defaults in the OTEL SDK.

---

## Decision Tree — What Happens When the Pod Starts

```
Pod starts
    │
    ▼
JVM starts, OTEL Java Agent (javaagent) initializes
    │
    ├── Reads OTEL_SERVICE_NAME         → "new-service"
    │   → Sets resource attribute: service.name = "new-service"
    │   → This becomes the entity name in Dynatrace
    │
    ├── Reads OTEL_EXPORTER_OTLP_ENDPOINT → "http://...activegate...:4318"
    │   → Knows where to send spans
    │   → Protocol: OTLP/HTTP (because port 4318, not 4317)
    │
    ▼
HTTP request arrives at new-service
    │
    ▼
OTEL Agent intercepts (bytecode instrumentation)
    → Creates a Span: {traceId, spanId, service.name="new-service", http.url=..., duration=...}
    │
    ▼
SpanProcessor batches spans (every 5s or 512 spans)
    │
    ▼
OTLP Exporter sends HTTP POST to:
    http://dynatrace-activegate.dynatrace.svc:4318/v1/traces
    │
    ▼
ActiveGate receives OTLP data
    │
    ▼
ActiveGate forwards to Dynatrace SaaS tenant
    │
    ▼
DT creates/updates service entity: "new-service"
    → Traces visible in DT UI within ~60 seconds of first span
```

---

## Part 1 — `OTEL_EXPORTER_OTLP_ENDPOINT` Dissected

### The full value: `http://dynatrace-activegate.dynatrace.svc:4318`

```
http://   dynatrace-activegate   .dynatrace   .svc   :4318
  │              │                    │          │       │
  │              │                    │          │       └─ Port
  │              │                    │          └─ Kubernetes DNS suffix
  │              │                    └─ Namespace where ActiveGate runs
  │              └─ Kubernetes Service name of the ActiveGate
  └─ Protocol (HTTP, not HTTPS — see note below)
```

### Breaking Down Each Component

#### `http://` — Protocol choice

```
OTEL supports two transport protocols for OTLP:
  http://   →  OTLP/HTTP  → port 4318   (JSON or Protobuf over HTTP/1.1)
  (grpc://) →  OTLP/gRPC  → port 4317   (Protobuf over HTTP/2 / gRPC)

Why HTTP (4318) over gRPC (4317)?
  - HTTP is simpler: works through most proxies, no HTTP/2 requirement
  - Dynatrace ActiveGate supports both, but HTTP is easier to debug (curl-testable)
  - Some Java frameworks have HTTP/2 restrictions → HTTP/1.1 is safer default

Why no TLS (https:// instead of http://)?
  - This is CLUSTER-INTERNAL traffic only
  - The request never leaves the Kubernetes cluster
  - Pod → ActiveGate pod-to-pod traffic stays inside the cluster network
  - Kubernetes network policies provide isolation
  - Adding TLS for intra-cluster traffic adds complexity without security benefit
  - If your security policy requires it: change to https:// AND mount the cert
```

#### `dynatrace-activegate` — The Kubernetes Service Name

```
This is the name of the Kubernetes Service resource for the ActiveGate.
It was created when you installed the DynaKube operator.

Verify it exists:
kubectl get svc -n dynatrace | grep activegate
# Output: dynatrace-activegate   ClusterIP   10.96.x.x   <none>   4317/TCP,4318/TCP

If the Service name is different in your cluster:
kubectl get svc -n dynatrace
# Use whatever name has ports 4317 and 4318
```

Why a Kubernetes Service (not a pod IP)?
```
Pod IPs change every restart.
A Kubernetes Service is a stable virtual IP + DNS name that load-balances across
the ActiveGate pods. Even if ActiveGate restarts or scales to 2 replicas,
"dynatrace-activegate.dynatrace.svc" always routes to a healthy pod.
```

#### `.dynatrace` — The Namespace

```
This is the Kubernetes namespace where the ActiveGate runs.
In this system: DynaKube CR deploys all DT components into the "dynatrace" namespace.

The DNS pattern for cross-namespace service resolution in Kubernetes:
  <service-name>.<namespace>.svc.<cluster-domain>

In practice, the cluster domain (.cluster.local) can be omitted:
  dynatrace-activegate.dynatrace.svc        ← works (short form)
  dynatrace-activegate.dynatrace.svc.cluster.local  ← also works (full form)

Why cross-namespace access works:
  Kubernetes DNS resolves service names across namespaces.
  A pod in namespace "payment-ns" can reach "dynatrace-activegate.dynatrace.svc"
  because DNS resolution is cluster-wide.
  (NetworkPolicy may restrict this — see troubleshooting below)
```

#### `:4318` — The Port

```
Port 4318 = OTLP/HTTP receiver

The full path that spans are sent to:
  http://dynatrace-activegate.dynatrace.svc:4318/v1/traces

OTLP well-known ports:
  4317 = OTLP/gRPC   (binary protocol, HTTP/2)
  4318 = OTLP/HTTP   (JSON or Protobuf, HTTP/1.1)

The ActiveGate opens BOTH ports.
Your Java service sends to 4318 because OTEL_EXPORTER_OTLP_ENDPOINT
uses HTTP (port 4318) by default when you specify http://.

The OTEL SDK automatically appends the signal path:
  /v1/traces   for distributed traces
  /v1/metrics  for metrics (if OTEL metrics exporter enabled)
  /v1/logs     for logs (if OTEL logs exporter enabled)
So the full URL for traces is: http://...activegate...:4318/v1/traces
```

---

## Part 2 — `OTEL_SERVICE_NAME` Dissected

### The value: `"new-service"`

```
OTEL_SERVICE_NAME = "new-service"
    │
    ▼ OTEL SDK reads this at startup
    │
    ▼ Sets resource attribute: service.name = "new-service"
    │
    ▼ This attribute is ATTACHED TO EVERY SPAN this process emits
    │
    ▼ When Dynatrace receives spans with service.name = "new-service":
        → It creates (or updates) a SERVICE entity named "new-service"
        → All traces, metrics, and errors are grouped under this entity
        → The entity appears in: Services view, Service Map, Distributed Tracing
```

### Why This Name Matters So Much

```
WRONG name: OTEL_SERVICE_NAME = "java-app"
  → DT creates a service entity named "java-app"
  → Your metric events filter by: entity name = "new-service"
  → MISMATCH → metric events never match this entity
  → Alerts never fire
  → Management zone rules never match
  → Synthetic SLO filter never matches

CORRECT name: OTEL_SERVICE_NAME = "new-service"
  → Must match EXACTLY what your Terraform metric events use:
      entity_filter { conditions { value = "new-service" } }
  → Must match the management zone tag filter
  → Must match the synthetic monitor's entity filter

Convention: use the same name as:
  - The Kubernetes Deployment name
  - The Helm chart name
  - The spring.application.name property
  All three should be identical for clean correlation.
```

### What OTEL SDK Does With It

```java
// What the OTEL SDK builds internally from OTEL_SERVICE_NAME:
Resource resource = Resource.getDefault()
    .merge(Resource.create(Attributes.of(
        ResourceAttributes.SERVICE_NAME, "new-service"   // from env var
    )));

// This resource is attached to every span:
Span span = tracer.spanBuilder("HTTP GET /api/health")
    .setAllAttributes(/* from instrumentation */)
    .build();
// span.resource.service.name = "new-service"  ← attached automatically
```

---

## Part 3 — The Full Journey: From HTTP Request to DT UI

### Step-by-step with exact data

```
1. HTTP request arrives at new-service:
   POST /api/v1/orders  with header  traceparent: 00-abc123...-def456...-01

2. OTEL Java Agent intercepts at the HTTP framework level (Spring MVC / Vert.x / etc.)
   Creates a SPAN:
   {
     "traceId": "abc123...",          ← from incoming traceparent header (continuation)
     "spanId":  "xyz789...",          ← new span ID for this service's work
     "parentSpanId": "def456...",     ← parent = upstream caller's span
     "name": "POST /api/v1/orders",
     "kind": "SERVER",
     "startTime": "2026-07-31T14:00:00.123Z",
     "endTime":   "2026-07-31T14:00:00.456Z",
     "duration":  333ms,
     "attributes": {
       "service.name": "new-service",       ← from OTEL_SERVICE_NAME
       "http.method": "POST",
       "http.url": "/api/v1/orders",
       "http.status_code": 201,
       "net.peer.ip": "10.x.x.x"
     }
   }

3. If new-service calls the DB:
   OTEL JDBC instrumentation creates a CHILD SPAN:
   {
     "name": "SELECT orders",
     "kind": "CLIENT",
     "parentSpanId": "xyz789...",     ← parent = the HTTP span above
     "attributes": {
       "db.system": "postgresql",
       "db.statement": "SELECT * FROM orders WHERE user_id = ?",
       "db.name": "payments"
     }
   }

4. SpanProcessor (BatchSpanProcessor):
   Accumulates spans in memory.
   Flushes when: 512 spans collected OR 5 seconds elapsed OR service shutting down.

5. OTLP Exporter sends:
   POST http://dynatrace-activegate.dynatrace.svc:4318/v1/traces
   Content-Type: application/json
   Body: {
     "resourceSpans": [{
       "resource": {
         "attributes": [{"key": "service.name", "value": "new-service"}]
       },
       "scopeSpans": [{
         "spans": [ { span data from step 2 }, { span data from step 3 } ]
       }]
     }]
   }

6. ActiveGate receives the HTTP POST.
   Validates the OTLP format.
   Translates to Dynatrace internal format.
   Forwards to DT SaaS tenant over HTTPS.

7. Dynatrace SaaS processes the data:
   → Sees service.name = "new-service"
   → Creates SERVICE entity "new-service" (if it doesn't exist)
   → Stores spans in the trace store (retention: 10 days by default)
   → Updates service metrics: request rate, error rate, response time
   → Evaluates metric events every 60 seconds
   → If error rate > threshold → creates Problem → alerts fire

8. DT UI shows:
   Services → new-service → Traces tab → your trace appears
   ~60 seconds after the first span was sent
```

---

## Part 4 — What Happens at Each Layer (With Kubernetes DNS)

### How `dynatrace-activegate.dynatrace.svc` Resolves

```
new-service pod (in payment-ns namespace)
    │
    │ DNS lookup: dynatrace-activegate.dynatrace.svc
    ▼
CoreDNS (Kubernetes DNS server, runs in kube-system namespace)
    │ Resolves: dynatrace-activegate Service in dynatrace namespace
    │ Returns: ClusterIP (e.g., 10.96.14.22)
    ▼
kube-proxy routes the TCP connection to:
    → One of the ActiveGate pod IPs (if 2 replicas: load-balanced)
    │
    ▼
ActiveGate pod receives the HTTP POST on port 4318
    │
    ▼
ActiveGate processes OTLP data and forwards to DT SaaS
```

### DNS Resolution Verification

```bash
# From inside a pod in your service's namespace:
kubectl exec -it \
  $(kubectl get pod -n payment-ns -l app=payment-service -o name | head -1) \
  -n payment-ns -- \
  nslookup dynatrace-activegate.dynatrace.svc
# Expected output: Address: 10.96.x.x (the ClusterIP of the ActiveGate Service)
# If NXDOMAIN: the ActiveGate Service doesn't exist or has a different name

# Verify the port is open:
kubectl exec -it \
  $(kubectl get pod -n payment-ns -l app=payment-service -o name | head -1) \
  -n payment-ns -- \
  wget -qO- --timeout=5 \
  http://dynatrace-activegate.dynatrace.svc:4318/v1/traces \
  --post-data='{}' --header='Content-Type: application/json'
# Expected: 400 Bad Request (bad payload but port IS open and responding)
# If connection refused: wrong port or ActiveGate not listening on 4318
# If connection timed out: NetworkPolicy blocking cross-namespace traffic
```

---

## Part 5 — The Complete values.yaml Context

Here is the full recommended env vars block for a Spring Boot service:

```yaml
# charts/new-service/values.yaml

env:
  # ── OTEL Core ─────────────────────────────────────────────────────────────
  - name: OTEL_EXPORTER_OTLP_ENDPOINT
    value: "http://dynatrace-activegate.dynatrace.svc:4318"
    # WHERE to send traces. Points to ActiveGate OTLP/HTTP port.

  - name: OTEL_SERVICE_NAME
    value: "new-service"
    # WHAT entity name appears in Dynatrace. Must match metric event entity filter.

  # ── OTEL Recommended Additions ────────────────────────────────────────────
  - name: OTEL_RESOURCE_ATTRIBUTES
    value: "deployment.environment=production,service.version=1.0.0"
    # Additional attributes on every span.
    # deployment.environment → DT uses this for management zone tagging
    # service.version → appears in DT entity details

  - name: OTEL_TRACES_SAMPLER
    value: "parentbased_always_on"
    # Sampling strategy:
    #   always_on            = send every span (good for low-traffic services)
    #   parentbased_always_on = follow upstream sampling decision (most common)
    #   traceidratio         = send X% of traces (e.g., 0.1 = 10%)

  - name: OTEL_PROPAGATORS
    value: "tracecontext,baggage"
    # How trace context is passed between services:
    #   tracecontext = W3C standard (traceparent header) — DT uses this
    #   baggage      = W3C baggage (key-value pairs across services)

  # ── Spring Boot specific ───────────────────────────────────────────────────
  - name: SPRING_APPLICATION_NAME
    value: "new-service"
    # Keep this in sync with OTEL_SERVICE_NAME for Spring-DT entity correlation

  # ── JVM agent flag (in JAVA_OPTS or JAVA_TOOL_OPTIONS) ──────────────────
  - name: JAVA_TOOL_OPTIONS
    value: "-javaagent:/otel-agent/opentelemetry-javaagent.jar"
    # The OTEL Java agent must be attached at JVM startup.
    # Without this, no instrumentation happens and no spans are created.
    # The JAR must exist in the container image at this path.
```

---

## Part 6 — Why Traces Appear in DT Within 1 Minute

```
Timeline after pod start:

T+0s    Pod starts, JVM initializes
T+1s    OTEL Java Agent reads env vars:
          OTEL_SERVICE_NAME = "new-service"
          OTEL_EXPORTER_OTLP_ENDPOINT = "http://...activegate...:4318"
        Agent initializes BatchSpanProcessor and OTLP exporter
        Agent instruments all loaded HTTP/DB/messaging frameworks (bytecode)

T+5s    First HTTP request arrives → first span created and buffered

T+10s   BatchSpanProcessor flush timer fires (default: 5s delay)
        OR 512 spans buffered (whichever comes first)
        OTLP exporter sends HTTP POST to ActiveGate

T+11s   ActiveGate receives spans, validates, forwards to DT SaaS

T+15–30s  DT SaaS processes spans:
           → Creates SERVICE entity "new-service"
           → Indexes spans in trace store
           → Updates service metrics (request rate, latency, error rate)

T+30–60s  DT UI refreshes:
           → Services list shows "new-service"
           → Traces tab shows the first trace
           → Service Map shows "new-service" connected to its dependencies
```

The "within 1 minute" claim is achievable because:
- OTLP over HTTP/1.1 is fast (no connection setup overhead like gRPC)
- BatchSpanProcessor default flush interval is 5 seconds
- DT SaaS processes OTLP ingestion in near-real-time
- No manual entity creation needed — DT auto-creates on first span

---

## Part 7 — Common Mistakes and What Breaks

### Mistake 1: Wrong port (4317 instead of 4318 for HTTP)

```yaml
# WRONG
value: "http://dynatrace-activegate.dynatrace.svc:4317"
# Port 4317 = gRPC. Sending HTTP/1.1 JSON to a gRPC port = connection error or garbage response.

# CORRECT
value: "http://dynatrace-activegate.dynatrace.svc:4318"
# Port 4318 = OTLP/HTTP. JSON payload sent here.

# ALSO CORRECT (gRPC)
value: "grpc://dynatrace-activegate.dynatrace.svc:4317"
# But requires setting OTEL_EXPORTER_OTLP_PROTOCOL=grpc
```

### Mistake 2: OTEL_SERVICE_NAME doesn't match metric event filter

```yaml
# In values.yaml:
- name: OTEL_SERVICE_NAME
  value: "new-svc"          ← "new-svc"

# In Terraform metric event:
entity_filter {
  conditions {
    value = "new-service"   ← "new-service" (different!)
  }
}
# Result: metric events NEVER match the entity → no alerts ever fire
# Rule: OTEL_SERVICE_NAME must exactly match every DT filter that references it
```

### Mistake 3: JAVA_TOOL_OPTIONS missing the -javaagent flag

```yaml
# WRONG: env vars set but no agent attached
- name: OTEL_SERVICE_NAME
  value: "new-service"
- name: OTEL_EXPORTER_OTLP_ENDPOINT
  value: "http://...activegate...:4318"
# No JAVA_TOOL_OPTIONS → no agent → no instrumentation → no spans → nothing in DT

# CORRECT: agent must be present
- name: JAVA_TOOL_OPTIONS
  value: "-javaagent:/otel-agent/opentelemetry-javaagent.jar"
```

### Mistake 4: Wrong namespace in the URL

```yaml
# WRONG: ActiveGate is in "dynatrace" namespace, not "monitoring"
value: "http://dynatrace-activegate.monitoring.svc:4318"
# DNS lookup fails → connection refused → no traces in DT

# CORRECT: use the actual namespace
value: "http://dynatrace-activegate.dynatrace.svc:4318"

# Find the right namespace:
# kubectl get svc -A | grep activegate
```

### Mistake 5: OTEL_SERVICE_NAME not set at all

```yaml
# WRONG: no OTEL_SERVICE_NAME
- name: OTEL_EXPORTER_OTLP_ENDPOINT
  value: "http://dynatrace-activegate.dynatrace.svc:4318"
# OTEL SDK defaults to service.name = "unknown_service:java"
# DT creates entity named "unknown_service:java"
# All your filters use "new-service" → nothing matches

# CORRECT: always set it explicitly
- name: OTEL_SERVICE_NAME
  value: "new-service"
```

### Mistake 6: NetworkPolicy blocking cross-namespace traffic

```yaml
# If a NetworkPolicy restricts egress from your service namespace:
# The pod cannot reach dynatrace-activegate.dynatrace.svc
# Symptom: spans are created (agent works) but never arrive in DT
# No error shown in logs unless OTEL_LOGS_EXPORTER is set

# Fix: add an egress rule to allow traffic to the dynatrace namespace
```

```yaml
# charts/new-service/templates/networkpolicy.yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: new-service-egress
  namespace: payment-ns
spec:
  podSelector:
    matchLabels:
      app: new-service
  policyTypes:
    - Egress
  egress:
    - ports:
        - port: 53          # DNS
          protocol: UDP
    - ports:
        - port: 4318        # OTLP/HTTP to ActiveGate
          protocol: TCP
      namespaceSelector:
        matchLabels:
          kubernetes.io/metadata.name: dynatrace
```

---

## Part 8 — Verifying Everything Works

```bash
# Step 1: Confirm env vars are set in the running pod
kubectl exec -it \
  $(kubectl get pod -n payment-ns -l app=new-service -o name | head -1) \
  -n payment-ns -- env | grep OTEL
# Expected:
# OTEL_EXPORTER_OTLP_ENDPOINT=http://dynatrace-activegate.dynatrace.svc:4318
# OTEL_SERVICE_NAME=new-service

# Step 2: Confirm the OTEL Java agent is attached
kubectl exec -it \
  $(kubectl get pod -n payment-ns -l app=new-service -o name | head -1) \
  -n payment-ns -- ps aux | grep javaagent
# Expected: -javaagent:/otel-agent/opentelemetry-javaagent.jar in the process args

# Step 3: Confirm ActiveGate is reachable from the pod
kubectl exec -it \
  $(kubectl get pod -n payment-ns -l app=new-service -o name | head -1) \
  -n payment-ns -- \
  wget -qO- --timeout=5 \
  http://dynatrace-activegate.dynatrace.svc:4318 2>&1
# Expected: "400 Bad Request" or any HTTP response (port is open and responding)
# Bad: "connection refused" or timeout (ActiveGate unreachable)

# Step 4: Send a test request to generate a trace
curl -s https://new-service.example.com/api/health
# Wait 60 seconds

# Step 5: Check DT for the entity
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/entities\
?entitySelector=type(SERVICE),entityName(new-service)" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.entities[] | {entityId, displayName}'
# If empty: no spans reached DT → check steps 1-3
# If shows entity: traces are flowing ✓

# Step 6: Check for recent traces
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/traces\
?serviceName=new-service&from=now-5m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.traces[0] | {traceId, duration, rootServiceName}'
```

---

## Part 9 — Additional OTEL Env Vars Reference

```yaml
# Full reference of commonly used OTEL env vars for Java microservices:

OTEL_EXPORTER_OTLP_ENDPOINT       Where to send all signals (traces + metrics + logs)
OTEL_EXPORTER_OTLP_TRACES_ENDPOINT  Override endpoint for traces only
OTEL_EXPORTER_OTLP_METRICS_ENDPOINT Override endpoint for metrics only

OTEL_SERVICE_NAME                  Service name shown in DT (MOST IMPORTANT)
OTEL_RESOURCE_ATTRIBUTES           Extra attributes: "env=prod,version=1.0"

OTEL_TRACES_SAMPLER               always_on | parentbased_always_on | traceidratio
OTEL_TRACES_SAMPLER_ARG           For traceidratio: the ratio (e.g., "0.1" = 10%)

OTEL_PROPAGATORS                  tracecontext,baggage (W3C standard — use this)

OTEL_EXPORTER_OTLP_PROTOCOL       http/protobuf | http/json | grpc
OTEL_EXPORTER_OTLP_TIMEOUT        Default: 10000 (10 seconds)
OTEL_EXPORTER_OTLP_HEADERS        "Authorization=Bearer TOKEN" (if DT requires auth)

OTEL_BSP_SCHEDULE_DELAY           BatchSpanProcessor flush interval (ms). Default: 5000
OTEL_BSP_MAX_EXPORT_BATCH_SIZE    Max spans per export batch. Default: 512
OTEL_BSP_MAX_QUEUE_SIZE           Max spans buffered before dropping. Default: 2048

OTEL_LOGS_EXPORTER                none | otlp (send logs via OTEL too — advanced)
OTEL_METRICS_EXPORTER             none | otlp (send metrics via OTEL too — advanced)

JAVA_TOOL_OPTIONS                  -javaagent:/path/to/opentelemetry-javaagent.jar
```
