# `dynatrace_metric_events.pod_restarts` — Line-by-Line Explanation

> This is Signal 7 of 8 in the Dynatrace Terraform module. It fires when a Kubernetes workload (payment-service, order-service, notification-service) restarts too many pods in a 5-minute window. Every field is explained from the ground up.

---

## The Full Block (from `terraform/modules/dynatrace/main.tf`)

```hcl
resource "dynatrace_metric_events" "pod_restarts" {
  for_each                   = var.services
  enabled                    = true
  event_entity_dimension_key = "dt.entity.cloud_application"
  event_type                 = "ERROR_EVENT"
  summary                    = "[${upper(var.environment)}] ${each.key}: Pod restarting (>${each.value.pod_restart_threshold} in 5 min)"
  description                = "${each.key} had >${each.value.pod_restart_threshold} pod restarts in 5 min. Check for OOM kills, failed readiness probes, or config errors. Team: ${each.value.team}"
  metadata { configuration_versions = [1] }

  model_properties {
    type               = "STATIC_THRESHOLD"
    alert_condition    = "ABOVE"
    alert_on_no_data   = false
    dealerting_samples = 3
    samples            = 1
    threshold          = each.value.pod_restart_threshold
    violating_samples  = 1
  }

  query_definition {
    type       = "METRIC_KEY"
    metric_key = "builtin:kubernetes.workload.pods.restarts"
    resolution = "5m"
    entity_filter {
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = each.key key = "workload.name"
      }
      conditions {
        type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
        value = var.environment key = "environment"
      }
    }
  }
}
```

---

## What This Resource Creates

```
One metric event alert in Dynatrace PER SERVICE PER ENVIRONMENT.

With for_each = var.services (3 services × 3 environments):
  dynatrace_metric_events.pod_restarts["payment-service"]      → dev
  dynatrace_metric_events.pod_restarts["order-service"]        → dev
  dynatrace_metric_events.pod_restarts["notification-service"] → dev
  (same 3 for staging, same 3 for production)
  Total: 9 metric event configurations
```

---

## Field-by-Field Explanation

### `for_each = var.services`

```hcl
for_each = var.services
```

`var.services` is the map passed in from the environment's `main.tf`:

```hcl
# environments/production/main.tf
services = {
  "payment-service"      = { pod_restart_threshold = 2, team = "payments", ... }
  "order-service"        = { pod_restart_threshold = 2, team = "orders",   ... }
  "notification-service" = { pod_restart_threshold = 2, team = "notifications", ... }
}
```

Inside the block, `each.key` = the service name (e.g., `"payment-service"`), and `each.value` = the full object for that service.

This is the standard Terraform pattern for "create one resource per service." If a 4th service is added to the map, a 4th alert is created automatically — no code changes needed.

---

### `enabled = true`

```hcl
enabled = true
```

This alert is active. Dynatrace evaluates it continuously. Setting `enabled = false` keeps the configuration in Terraform state but turns off evaluation — useful during extended outage recovery or testing without deleting the config.

---

### `event_entity_dimension_key = "dt.entity.cloud_application"`

```hcl
event_entity_dimension_key = "dt.entity.cloud_application"
```

**This is the most important field to understand.** It determines WHAT KIND of Dynatrace entity owns this alert.

```
dt.entity.cloud_application  = a Kubernetes Deployment (workload)
dt.entity.host               = an EC2 node
dt.entity.process_group_instance = a single JVM pod
dt.entity.service            = an auto-discovered service (HTTP traffic)
```

**Why `cloud_application` for pod restarts?**

Pod restarts are a property of the WORKLOAD (Deployment), not of individual pods. When Kubernetes reports restarts:
- It sums restarts across ALL pods belonging to a Deployment
- The metric belongs to the Deployment entity, not any single pod
- `builtin:kubernetes.workload.pods.restarts` is a workload-level metric

If you set this to `dt.entity.process_group_instance` (pod-level), Dynatrace would try to attach the alert to individual pod entities — but the metric doesn't exist at the pod level, so the alert would never match anything.

**What this means for alerts:**
When this alert fires in the Dynatrace UI, the Problem is created with `payment-service` (the Kubernetes Deployment) as the affected entity. You see: which Deployment is crashing, not which specific pod — which is the right level of abstraction for debugging.

**Comparison across the 8 signals in this project:**
```
Signal 1 (traffic drop)      → dt.entity.service            (HTTP service level)
Signal 2 (error rate)        → dt.entity.service            (HTTP service level)
Signal 3 (latency P99)       → dt.entity.service            (HTTP service level)
Signal 4 (CPU saturation)    → dt.entity.process_group_instance (per JVM pod)
Signal 5 (memory RSS)        → dt.entity.process_group_instance (per JVM pod)
Signal 6 (JVM heap)          → dt.entity.process_group_instance (per JVM pod)
Signal 7 (pod restarts) ← → dt.entity.cloud_application    (Kubernetes Deployment)
Signal 8 (network errors)    → dt.entity.host               (EC2 node)
```

The dimension key is chosen to match where the metric naturally lives — pod restarts are a Deployment-level concept in Kubernetes.

---

### `event_type = "ERROR_EVENT"`

```hcl
event_type = "ERROR_EVENT"
```

**The four event types and their severity tiers:**

```
AVAILABILITY_EVENT    → AVAILABILITY severity
                        → Alerting profile: CRITICAL tier (0 min delay)
                        → Use for: service down, synthetic failed

ERROR_EVENT           → ERROR severity          ← this signal uses ERROR_EVENT
                        → Alerting profile: HIGH tier (2 min delay in this project)
                        → Use for: errors, failures, crashes

PERFORMANCE_EVENT     → SLOWDOWN severity
                        → Alerting profile: WARNING tier (5 min delay)
                        → Use for: latency, slow responses

RESOURCE_CONTENTION_EVENT → RESOURCE_CONTENTION severity
                        → Alerting profile: INFO tier (15 min delay)
                        → Use for: CPU, memory, disk, network utilisation
```

**Why pod restarts are `ERROR_EVENT` (not `AVAILABILITY_EVENT`):**

```
AVAILABILITY_EVENT would mean:
  "payment-service is completely unreachable — fire PagerDuty immediately"

ERROR_EVENT means:
  "payment-service pods are restarting — this is a serious problem needing
   investigation, but the service is still running (some pods are healthy)"

The distinction matters:
  Crash-loop ≠ complete unavailability.
  During a crash loop, Kubernetes:
    1. Pod crashes → restart
    2. New pod starts → passes startupProbe (initially)
    3. Pod crashes again → restart
    4. Eventually: CrashLoopBackOff (increasing back-off delay)
  
  During steps 1-3, the service is degraded but not completely down.
  Traffic is partially served by healthy replicas (with PDB protecting minimum availability).
  This is an ERROR (serious, investigate now) not an AVAILABILITY (everything down, page immediately).
```

**Routing consequence:**
From `terraform/modules/dynatrace/main.tf`, ERROR_EVENT maps to the `high` alerting profile → routes to PagerDuty in staging+production, Slack in dev.

---

### `summary` and `description`

```hcl
summary = "[${upper(var.environment)}] ${each.key}: Pod restarting (>${each.value.pod_restart_threshold} in 5 min)"
```

**What the fired alert looks like in Slack/PagerDuty:**

```
For production, payment-service (threshold = 2):
  Summary:     "[PRODUCTION] payment-service: Pod restarting (>2 in 5 min)"
  Description: "payment-service had >2 pod restarts in 5 min. Check for OOM kills,
                failed readiness probes, or config errors. Team: payments"

For dev, notification-service (threshold = 5):
  Summary:     "[DEV] notification-service: Pod restarting (>5 in 5 min)"
```

**Why the format `[ENVIRONMENT] service: issue (threshold context)` matters:**

```
Good summary: "[PRODUCTION] payment-service: Pod restarting (>2 in 5 min)"
  On-call at 3am reads this and immediately knows:
    ✓ Which environment: PRODUCTION (real, urgent)
    ✓ Which service: payment-service
    ✓ What is happening: pod restarts
    ✓ How bad: more than 2 restarts in 5 minutes

Bad summary: "pod_restart_alert_fired"
  On-call must open Dynatrace to find out what, where, and how bad.
  Adds 2-3 minutes to MTTR — unacceptable at 3am.
```

The description contains the DIAGNOSIS starting point: "Check for OOM kills, failed readiness probes, or config errors." This is a first-responder hint that saves time.

---

### `model_properties` — The Alert Trigger Logic

```hcl
model_properties {
  type               = "STATIC_THRESHOLD"
  alert_condition    = "ABOVE"
  alert_on_no_data   = false
  dealerting_samples = 3
  samples            = 1
  threshold          = each.value.pod_restart_threshold   # 2 (prod), 5 (dev)
  violating_samples  = 1
}
```

#### `type = "STATIC_THRESHOLD"`

```
A fixed numeric threshold: fire when the metric value crosses this number.
Alternative: "SEASONAL_BASELINE" (dynamic threshold that learns normal patterns).

Why STATIC for pod restarts:
  ANY pod restart > 2 in 5 minutes is always abnormal.
  There is no "normal season" where 5 restarts is expected.
  Restarts don't have time-of-day patterns.
  STATIC is correct here.

SEASONAL_BASELINE would be appropriate for:
  Traffic-based metrics (request rate peaks at 10am, drops at 3am)
  When "normal" varies by hour/day/week
```

#### `alert_condition = "ABOVE"`

```
Fire when the metric value is ABOVE the threshold.
(vs "BELOW" which is used for traffic drop: fire when traffic drops below minimum)

Logic:
  metric_value > threshold → alert fires
  
For pod restarts:
  restarts_in_5min = 3 > 2 (threshold) → FIRES ✓
  restarts_in_5min = 1 ≤ 2 (threshold) → no alert ✓
```

#### `alert_on_no_data = false`

```
When Dynatrace receives NO data points for this metric:
  false → don't fire the alert (absence of data = no problem)
  true  → fire the alert (absence of data = assumed threshold violation)

Why false for pod restarts:
  If payment-service has 0 pod restarts in a 5-minute window:
    Dynatrace may receive a 0 value OR no data point (both are valid)
    0 restarts = healthy, not a problem
    Firing on no data would mean: "no pods restarted → alert" → nonsense

Compare with Signal 1 (traffic drop):
  alert_on_no_data = true
  WHY: if the service crashes completely, it stops sending metrics entirely
  Zero data = service is so broken it can't even emit metrics = silent outage
  That IS a problem → fire on no data

The rule:
  alert_on_no_data = true  → use when absence of data means something is DOWN
  alert_on_no_data = false → use when absence of data means things are NORMAL
```

#### `threshold = each.value.pod_restart_threshold`

```
Per-environment threshold values (from the project):

Environment | threshold | Why
──────────────────────────────────────────────────────
dev         |     5     | Dev pods restart often during development
                         (config changes, test restarts, new deployments)
                         5 restarts before alerting prevents constant noise
staging     |     3     | More stable than dev, less stable than production
                         Rolling updates and load tests may cause restarts
production  |     2     | ANY restart above 2 in 5 min = crash loop starting
                         With PDB (minAvailable:2, 3 replicas), even 2 restarts
                         means a pod is cycling faster than expected
                         Production must be strict — user impact is real
```

**What exactly is a "restart" in this metric?**

```
Kubernetes tracks restarts in:
  kubectl get pods -n payment-ns
  NAME                               READY   STATUS    RESTARTS   AGE
  payment-service-abc-def            1/1     Running   3          2h

The RESTARTS column increments every time the container exits and Kubernetes 
restarts it. The metric `builtin:kubernetes.workload.pods.restarts` is the 
RATE of new restarts per evaluation window (5 minutes here), not the cumulative count.

So threshold = 2 means:
  "alert if MORE THAN 2 NEW restarts occurred in the most recent 5-minute window"
  
NOT:
  "alert if the cumulative restart counter on any pod exceeds 2"
  (that would alert every pod that has ever restarted more than twice — useless)
```

#### `violating_samples = 1` and `samples = 1`

```
These two fields work together:

samples = 1         → evaluate the LAST 1 data point (most recent 5-minute window)
violating_samples = 1 → fire if AT LEAST 1 of those 1 samples violates the threshold

In plain language: "fire immediately when the CURRENT 5-minute window has >2 restarts"

Compare with other signals in this project:
  error_rate:    samples=5, violating_samples=3  → must be high for 3 of last 5 minutes (15 min sustained)
  latency P99:   samples=5, violating_samples=3  → must be slow for 3 of last 5 minutes (15 min sustained)
  pod restarts:  samples=1, violating_samples=1  → fires on the FIRST bad 5-minute window (instant)
  
WHY pod restarts get violating_samples=1 (no grace period)?

Reason 1: Restarts are DISCRETE events (not continuous degradation)
  A pod restart is a sudden, definitive event.
  There is no "gradual" crash loop — either pods are restarting or they're not.
  
Reason 2: Each restart means an error window that affected users
  Every pod restart = all in-flight requests to that pod are DROPPED.
  No gradual degradation — instant disruption to existing connections.
  Waiting 15 minutes to confirm "yes it's still restarting" adds 15 minutes of impact.

Reason 3: CrashLoopBackOff starts fast
  Pod crash → restart → crash → restart (growing backoff: 10s, 20s, 40s, 80s, 160s, 5min)
  If you wait 3×5min = 15 minutes to alert:
    By then: backoff is 5 minutes → one restart per 5 min → barely visible in the metric
    The worst of the crash loop has already passed, but the service is still degraded

Reason 4: pod restarts CAUSE other alerts anyway
  When pods restart, there's always a brief availability gap:
  → error rate spikes (dropped connections → 5xx)
  → P99 rises (new pod, cold JIT)
  → DT synthetic may fail (pod not yet passing readiness probe)
  Those alerts also fire with their own delays.
  The pod restart alert fires FIRST (no delay) → on-call knows the ROOT CAUSE
  before the cascading symptom alerts fire.
```

#### `dealerting_samples = 3`

```
dealerting_samples = 3 means:
  The alert stays OPEN until 3 consecutive 5-minute windows show ≤ threshold restarts.
  
  Why 3 (not 1)?

  Scenario:
    14:30: 3 restarts (fires alert)
    14:35: 0 restarts
    14:40: 4 restarts  ← still crashing
    14:45: 0 restarts
    14:50: 0 restarts
    14:55: 0 restarts  ← 3 consecutive clean windows → resolve
  
  With dealerting_samples=1 (resolve after first clean window):
    Alert resolves at 14:35 → re-fires at 14:40 → resolves at 14:45 → etc.
    On-call gets: "firing → resolved → firing → resolved" notifications
    Looks like a flapping alert → alert fatigue
    Actual problem: pods are still crashing intermittently

  With dealerting_samples=3:
    Alert stays OPEN from 14:30 through 14:55
    One persistent Problem in Dynatrace → one investigation thread
    Resolves only when stable for 3 × 5min = 15 minutes → genuine recovery

  The rule: dealerting_samples should be high enough to prevent flapping,
  but not so high that the alert stays open long after the problem resolved.
  3 × 5min = 15 minutes of stability required = reasonable for pod restarts.
```

---

### `query_definition` — Which Metric, From Where

```hcl
query_definition {
  type       = "METRIC_KEY"
  metric_key = "builtin:kubernetes.workload.pods.restarts"
  resolution = "5m"
  entity_filter {
    conditions {
      type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
      value = each.key key = "workload.name"   # e.g. "payment-service"
    }
    conditions {
      type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
      value = var.environment key = "environment"   # e.g. "production"
    }
  }
}
```

#### `metric_key = "builtin:kubernetes.workload.pods.restarts"`

```
This metric is provided by:
  Dynatrace ActiveGate → scrapes the Kubernetes API server
  Enabled by: feature.dynatrace.com/automatic-kubernetes-api-monitoring: "true"
  (in the DynaKube spec in gitops/*/monitoring/dynatrace/dynatrace-operator.yaml)

What the metric measures:
  The number of pod container restarts accumulated across all pods of a Deployment
  in a given time window.

Source in Kubernetes:
  The same data as: kubectl get pods -n payment-ns
  RESTARTS column → Dynatrace collects this and exposes as a time series

"builtin:" prefix means this is a Dynatrace-native metric (not user-defined).
"kubernetes.workload.pods" = Kubernetes workload entity type (Deployment)
".restarts" = the restart counter
```

**How the metric is collected (data flow):**
```
Kubernetes API server
  → Stores: pod container restart counts per workload
  ↓
ActiveGate (with kubernetes-api-monitoring capability)
  → Calls K8s API: GET /apis/apps/v1/namespaces/payment-ns/deployments
  → Reads restart counts from pod specs
  → Every ~60 seconds
  ↓
Dynatrace SaaS tenant
  → Stores as time series: builtin:kubernetes.workload.pods.restarts
  → Dimensions: workload.name, namespace, environment, cluster
  ↓
This metric event evaluates the metric every 5 minutes (resolution = "5m")
```

#### `resolution = "5m"`

```
The evaluation window for the metric.

resolution = "5m" means:
  Dynatrace looks at how many restarts occurred in the last 5 MINUTES.
  If > threshold → condition is true for that sample.

Why 5 minutes (not 1m or 1h)?

Too short (1m): 
  During a rolling deploy, a pod may restart once in 1 minute.
  A single pod restart during a legitimate rolling update would fire the alert.
  Too noisy.

5 minutes:
  A rolling deploy (maxUnavailable: 0, maxSurge: 1) takes 1-3 minutes.
  A crash loop produces multiple restarts in 5 minutes.
  5 minutes is the sweet spot: captures crash loops, ignores rolling updates.

Too long (1h):
  2 restarts spread across 1 hour (1 every 30 minutes) may not trigger.
  But a service that restarts every 30 minutes is clearly in trouble.
  1h resolution misses gradual crash loops.
  Also: an actual crash loop (10 restarts in 5 minutes) might count as only 2 in an hour
  if they're bunched at the start and then back-off takes over.
```

#### The two `entity_filter` conditions

```hcl
# Condition 1: which workload
conditions {
  type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
  value = each.key  # "payment-service" (the for_each map key)
  key   = "workload.name"
}
```

```
What "workload.name" means:
  In Kubernetes, the workload name is the Deployment name.
  In this project: "payment-service", "order-service", "notification-service"
  
  This condition scopes the metric to ONLY this Deployment.
  Without it: the threshold would be checked against ALL Deployments in all namespaces.
  
  With for_each = var.services, each alert instance scopes to its own service:
    pod_restarts["payment-service"]    → workload.name = "payment-service"
    pod_restarts["order-service"]      → workload.name = "order-service"
    pod_restarts["notification-service"] → workload.name = "notification-service"
  
  This is why for_each creates SERVICE-SPECIFIC alerts, not a cluster-wide alert.
```

```hcl
# Condition 2: which environment
conditions {
  type = "DIMENSION" rollup = "NONE" operator = "EQUALS"
  value = var.environment  # "production" | "staging" | "dev"
  key   = "environment"
}
```

```
What "environment" dimension means:
  OneAgent + ActiveGate read the Kubernetes namespace labels:
    namespace label: environment=production
  These propagate as dimensions on the metric.
  
  This condition ensures the production Terraform module's alerts ONLY
  evaluate production metrics — not staging metrics.
  
  Without it:
    Production alert (threshold=2) might evaluate dev metrics
    Dev payment-service restarts 5 times (normal in dev)
    Production alert fires for a dev event → false alarm
  
  With the environment filter:
    Each environment's Terraform module creates alerts scoped to that environment only.
    Completely isolated.
```

---

## What Actually Fires: A Real Crash Loop Scenario

```
Timeline: payment-service in production

14:30:00  deployment update pushed (new image with a config bug)
14:30:30  Kubernetes starts rolling update (maxUnavailable:0, maxSurge:1)
14:30:45  new pod starts → startupProbe fails → pod exits with code 1
14:30:46  Kubernetes restarts pod (restart #1)
14:31:16  pod exits again (restart #2) — 30s back-off
14:32:16  pod exits again (restart #3) — 60s back-off
14:34:16  pod exits again (restart #4) — 120s back-off
14:38:16  pod exits again (restart #5) — 300s back-off (CrashLoopBackOff)

Dynatrace evaluates the metric at 14:35:00:
  builtin:kubernetes.workload.pods.restarts{workload.name="payment-service", environment="production"}
  Value in the 14:30-14:35 window: 3 restarts

model_properties check:
  3 (observed) > 2 (threshold) → condition TRUE
  violating_samples=1 → only need 1 sample → FIRES IMMEDIATELY
  
Alert fires at 14:35:00:
  Summary: "[PRODUCTION] payment-service: Pod restarting (>2 in 5 min)"
  Description: "payment-service had >2 pod restarts in 5 min. Check for OOM kills..."
  event_type: ERROR_EVENT → HIGH severity alerting profile → PagerDuty

On-call Alice is paged at 14:35.
She sees in Dynatrace:
  - deployment event marker at 14:30 (from CI pushing DT deployment event)
  - pod restart spike starting at 14:31
  - Root cause: obviously the 14:30 deploy

Alice runs:
  kubectl rollout undo deployment/payment-service -n payment-ns
  OR CI auto-rollback has already triggered (verify-production job failed → rollback commit)

14:50:00: no new restarts for 3 × 5min windows → dealerting_samples=3 satisfied
Dynatrace resolves the Problem automatically.
Notification: "payment-service Pod restarting RESOLVED"
```

---

## Per-Environment Comparison

```
The same metric event block creates different behaviour per environment:

DEV (pod_restart_threshold = 5):
  Alert fires when: > 5 restarts in 5 minutes
  Routing: Slack #dev-alerts (no PagerDuty)
  WHY relaxed: devs frequently restart pods (test changes, config experiments)
               5 restarts before alerting = only catches actual crash loops
               Dev never pages on-call

STAGING (pod_restart_threshold = 3):
  Alert fires when: > 3 restarts in 5 minutes
  Routing: PagerDuty HIGH (staging validates production behaviour)
  WHY medium: staging should be more stable than dev
              k6 load tests might cause 1-2 restarts → 3 threshold avoids false alerts

PRODUCTION (pod_restart_threshold = 2):
  Alert fires when: > 2 restarts in 5 minutes
  Routing: PagerDuty CRITICAL+HIGH
  WHY strict: 
    - Any restart drops active connections → user-visible errors
    - With 3 replicas + PDB (minAvailable:2), even 2 restarts means
      the rolling restart pattern is broken → service degrading
    - Production never has "routine" restarts — every one needs investigation
```

---

## Common Root Causes When This Alert Fires

```
1. OOMKill (most common)
   Container exceeded its memory limit → kernel sends SIGKILL → pod restarts
   Check: kubectl describe pod <pod-name> -n payment-ns | grep "OOMKilled"
   Fix: increase memory limit in Helm values OR investigate memory leak

2. Failed liveness probe
   /actuator/health/liveness returns non-200 repeatedly → Kubernetes kills pod
   Check: kubectl describe pod <pod-name> | grep -A5 "Liveness"
   Fix: check application logs for startup errors, DB connection failures

3. Application crash (exit code != 0)
   Unhandled exception causes JVM to exit → pod restarts
   Check: kubectl logs <pod-name> -n payment-ns --previous (logs from crashed pod)
   Fix: find the exception in logs, fix the bug

4. Config error on startup
   Missing environment variable, wrong secret value → Spring Boot fails to start
   Check: kubectl logs <pod-name> --previous | grep "Error\|Exception\|Failed"
   Fix: verify ExternalSecret synced correctly, check secret values

5. Image pull failure after new deploy
   New image SHA doesn't exist in ECR → ImagePullBackOff → effectively "crash loop"
   Check: kubectl describe pod <pod-name> | grep "Failed to pull"
   Fix: verify the CI push to ECR succeeded before the gitops commit

6. Resource starvation (rarely)
   Node CPU/memory exhausted → pod can't start probes fast enough → killed
   Check: kubectl describe node <node-name> | grep -A10 "Allocated resources"
   Fix: scale cluster or redistribute pods
```

---

## Summary: Why Each Field Was Chosen

```
Field                          Value              WHY
─────────────────────────────────────────────────────────────────────────────────
event_entity_dimension_key     cloud_application  Pod restarts are a Deployment metric,
                                                  not a pod or service metric
event_type                     ERROR_EVENT        Restarts = serious error, but not
                                                  complete unavailability
threshold (prod)               2                  Any value > 2 in 5min = crash loop
                                                  starting; with PDB this is impactful
violating_samples              1                  Restarts are discrete; crash loops are
                                                  obvious immediately (no grace period)
samples                        1                  Evaluate the current 5-min window only
alert_on_no_data               false              No restarts = 0 data or 0 value = healthy
dealerting_samples             3                  15 min of stability prevents flapping
resolution                     5m                 Captures crash loops, ignores rolling
                                                  updates (which take 1-3 min)
metric_key                     kubernetes.workload Collected by ActiveGate from K8s API,
                               .pods.restarts      not OneAgent JVMTI
entity_filter workload.name    each.key           Scopes to specific service only
entity_filter environment      var.environment    Scopes to specific environment only
```
