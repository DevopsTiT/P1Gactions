# Pod Restarts Metric Event — Glossary for SRE Beginners

Every term used in main.md, one entry per term.

---

**`dynatrace_metric_events`**
A Terraform resource type (from the `dynatrace-oss/dynatrace` provider) that creates a Metric Event in Dynatrace. A Metric Event is a configuration that tells Dynatrace: "watch this metric, and when it crosses this threshold, open a Problem." This is how alert rules are defined as code.

**`for_each = var.services`**
A Terraform pattern that creates one copy of a resource block for each item in a map. If the map has 3 services, Terraform creates 3 separate resources — one per service. Each copy gets the service's specific values via `each.key` (the service name) and `each.value` (the service's configuration object).

**`event_entity_dimension_key`**
The field that tells Dynatrace which TYPE of entity (Kubernetes Deployment, JVM pod, EC2 node, HTTP service) to attach the Problem to when the alert fires. This determines what you see in the "Affected entities" section of the Problem card.

**`dt.entity.cloud_application`**
The Dynatrace entity type for a Kubernetes Deployment (or StatefulSet, DaemonSet). When an alert uses this entity key, the Problem is created at the Deployment level — not at the individual pod level. Pod restart metrics are naturally Deployment-level because Kubernetes aggregates restarts across all pods in a Deployment.

**`dt.entity.service`**
A Dynatrace entity type for an auto-discovered service — a group of processes that handle the same HTTP traffic. Used for HTTP-level signals like error rate and latency P99. Different from `cloud_application` which is the Kubernetes workload.

**`dt.entity.process_group_instance`**
A Dynatrace entity type for a single JVM process (one pod). Used for metrics that are per-process: CPU saturation, memory RSS, JVM heap. Different from `cloud_application` (which is the whole Deployment).

**`dt.entity.host`**
A Dynatrace entity type for an EC2 worker node. Used for metrics that apply to the entire node: network error rate, node CPU, node memory. One host hosts multiple pods.

**`event_type`**
The severity category of a Dynatrace metric event. Determines which alerting profile tier routes the notification. `ERROR_EVENT` = HIGH severity (routes to PagerDuty in staging/production). `AVAILABILITY_EVENT` = CRITICAL severity (routes to PagerDuty immediately). `PERFORMANCE_EVENT` = WARNING. `RESOURCE_CONTENTION_EVENT` = INFO.

**`ERROR_EVENT`**
The Dynatrace event type used for serious functional failures. Maps to the HIGH alerting profile tier. Routes to PagerDuty in production and staging, Slack only in dev. Used for pod restarts because crash loops are serious (user-impacting) but not necessarily full unavailability.

**`AVAILABILITY_EVENT`**
The Dynatrace event type for complete service unavailability. Maps to CRITICAL alerting profile (0 minute delay). Always pages on-call immediately in production. Used for: service down, synthetic monitor failed. NOT used for pod restarts because some pods may still be healthy during a crash loop.

**Alerting profile**
A Dynatrace configuration that maps a severity level to a notification channel with an optional delay. Four tiers in this project: CRITICAL (0 min, PagerDuty), HIGH (2 min, PagerDuty in staging+production), WARNING (5 min, Slack), INFO (15 min, Slack). Pod restarts go to HIGH tier.

**`STATIC_THRESHOLD`**
The alert evaluation type that fires when a metric value crosses a fixed number. Used when "normal" is well-defined (e.g., 0 pod restarts is always normal). The alternative, `SEASONAL_BASELINE`, learns normal patterns dynamically (used for metrics that vary by time of day).

**`alert_condition = "ABOVE"`**
The direction of the threshold comparison. `"ABOVE"` = fire when metric value exceeds the threshold. `"BELOW"` = fire when metric value drops below the threshold (used for traffic drop: fire when traffic falls below minimum RPS).

**`alert_on_no_data`**
Whether to fire the alert when Dynatrace receives zero data points for the metric. `false` = no data = treat as healthy (correct for restarts: no data means no restarts). `true` = no data = fire the alert (correct for traffic: no data means the service is too broken to emit metrics).

**`threshold`**
The numeric value the metric must exceed (or fall below, for BELOW alerts) for the alert condition to be true. For pod restarts: 2 in production (any crash loop = page), 5 in dev (only extreme crash loops = alert). The threshold is per-environment via `each.value.pod_restart_threshold`.

**`violating_samples`**
The number of consecutive evaluation windows that must show the threshold being violated before the alert fires. `violating_samples = 1` means fire on the first bad measurement — no grace period. Used for pod restarts because restarts are discrete events that need immediate attention.

**`samples`**
The total number of recent evaluation windows that Dynatrace considers when checking `violating_samples`. `samples = 1` = only look at the most recent window. `samples = 5` with `violating_samples = 3` = fire if 3 of the last 5 windows are bad (slower to fire, fewer false alarms).

**`dealerting_samples`**
The number of consecutive clean windows required before Dynatrace resolves the alert and closes the Problem. `dealerting_samples = 3` with `resolution = 5m` = requires 15 minutes of zero excess restarts before resolving. Prevents flapping (rapid open/close cycles that cause alert fatigue).

**Flapping alert**
When an alert rapidly alternates between firing and resolving — typically within minutes. Caused by a metric that hovers near the threshold. Flapping generates multiple PagerDuty pages for what is effectively one ongoing incident. `dealerting_samples > 1` prevents flapping.

**`resolution = "5m"`**
The time window Dynatrace uses when evaluating the metric. `"5m"` means: count restarts that occurred in the last 5 minutes. Chosen to be long enough to capture crash loop patterns (which produce multiple restarts in minutes) but short enough to not miss them.

**`metric_key = "builtin:kubernetes.workload.pods.restarts"`**
The unique identifier of the Dynatrace built-in metric that counts pod container restarts per Kubernetes workload. Collected by ActiveGate (not OneAgent) by calling the Kubernetes API server. The "builtin:" prefix means it's provided automatically by Dynatrace — no instrumentation needed.

**`builtin:` metric prefix**
Indicates a Dynatrace-provided metric collected automatically by OneAgent or ActiveGate. No configuration or code changes needed to start collecting it. Contrast with `custom.*` metrics which require explicit instrumentation.

**ActiveGate**
A Dynatrace component that runs as a Deployment inside Kubernetes. With `kubernetes-api-monitoring` capability, it calls the Kubernetes API server to collect workload-level metrics: pod counts, restart counts, deployment health. This is the source of `builtin:kubernetes.workload.pods.restarts`.

**Kubernetes API server scraping**
ActiveGate calls `GET /apis/apps/v1/namespaces/.../deployments` and related K8s API endpoints every ~60 seconds to collect workload metrics. This is how Dynatrace knows about pod restart counts — it reads from the same Kubernetes metadata that `kubectl get pods` reads.

**Pod restart**
When a container inside a Kubernetes pod exits (for any reason: crash, OOMKill, liveness probe failure) and Kubernetes starts it again. The `RESTARTS` column in `kubectl get pods` counts cumulative restarts. The Dynatrace metric measures NEW restarts per evaluation window, not cumulative total.

**CrashLoopBackOff**
A Kubernetes state where a pod keeps crashing and Kubernetes keeps restarting it with increasing delays: 10s, 20s, 40s, 80s, 160s, then capped at 5 minutes. The "BackOff" part means restarts happen less frequently over time. `kubectl get pods` shows `STATUS: CrashLoopBackOff`. The pod_restarts alert fires at the beginning (before backoff delays spread out the restarts).

**OOMKill (Out Of Memory Kill)**
When a container's RSS memory usage hits the container memory limit, the Linux kernel sends SIGKILL (unblockable kill) to the container process. This counts as a pod restart in Kubernetes. `kubectl describe pod <name> | grep OOMKilled` confirms it. Fix: increase memory limit in Helm values or investigate memory leak.

**Liveness probe**
A Kubernetes health check that runs continuously on a running pod. If it fails (repeatedly returns non-200 or times out), Kubernetes kills and restarts the container. Checking `/actuator/health/liveness`. A failing liveness probe causes restarts even when the application isn't crashing on its own.

**Readiness probe**
A Kubernetes health check that controls whether a pod receives traffic. If it fails, the pod is removed from the Service endpoints (no traffic) but NOT restarted. Different from liveness probe. A failing readiness probe on all pods causes a service outage without pod restarts.

**Startup probe**
A Kubernetes health check that only runs during pod startup. Gives slow-starting JVM applications time to initialize before liveness/readiness checks begin. In this project: `failureThreshold: 60` in production (10 minutes to start). A failing startup probe causes pod restarts before the app even finishes initializing.

**PDB (PodDisruptionBudget)**
A Kubernetes resource that limits how many pods can be unavailable simultaneously during voluntary disruptions (node drains, upgrades). `minAvailable: 2` with 3 replicas = at most 1 pod can be down at once. During a crash loop, PDB protects the minimum number of serving pods.

**Rolling update**
Kubernetes deployment strategy that replaces pods one at a time. With `maxUnavailable: 0, maxSurge: 1`: always has at least the configured replica count running. New pod must pass health checks before the old pod is removed. A crash during rolling update keeps the old (good) pod running until the new one stabilises.

**`workload.name` dimension**
A Dynatrace metric dimension that identifies the Kubernetes Deployment (or other workload) a metric belongs to. Used in `entity_filter` to scope the pod restart alert to a specific deployment (e.g., "payment-service") rather than all deployments in the cluster.

**`environment` dimension**
A Dynatrace metric dimension that identifies which environment (dev/staging/production) a metric came from. Set via namespace labels → pod labels → Dynatrace auto-tagging. Used in `entity_filter` to ensure the production alert only evaluates production metrics.

**`entity_filter`**
A set of conditions in a Dynatrace metric query that limits which entities' metrics are evaluated. Without it, the threshold would be checked against ALL matching workloads across all environments — one production alert might fire on dev data.

**`DIMENSION` filter type**
An `entity_filter` condition type that filters by a metric dimension (a label-like attribute on the metric data). `type = "DIMENSION"` with `operator = "EQUALS"` means: only include data points where the specified dimension has exactly the specified value.

**Summary annotation**
The short one-line description of a Dynatrace alert that appears in PagerDuty pages and Slack messages. Must contain: environment (so on-call knows severity), service name (so on-call knows what's affected), what is happening, and the threshold value. Read at 3am in half-asleep state — must be self-explanatory.

**Description annotation**
The longer explanation in a Dynatrace alert that provides diagnosis starting points. Tells the on-call engineer what to check first: "Check for OOM kills, failed readiness probes, or config errors." Reduces MTTR by pointing to the most common causes before the on-call even opens a dashboard.

**`configuration_versions`**
A Dynatrace metadata field that tracks the version of an alert's configuration. Useful for auditing: when was this alert last changed? Combined with Terraform, you can correlate a change in the alert configuration with the git commit that introduced it.

**MTTR (Mean Time To Resolution)**
Average time from when an incident starts to when it is resolved. Good alert design (clear summary, description with diagnosis hints, runbook link) directly reduces MTTR. The pod restart alert fires instantly (`violating_samples = 1`) to minimise the time from crash start to on-call notification.
