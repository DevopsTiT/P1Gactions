# JLPT N2 — Most Common Questions & Answers (Pass the Exam)

> Built from: `/Users/ts-shuge.kui/warp/Files/2026-07-31/65_jlpt-n2/main.md`
> Format: each section mirrors the real exam. Answer key at the end of each block.
> Use this file for timed self-testing — do NOT look at answers while answering.

---

## HOW TO USE THIS FILE

```
Quick drill (15 min):   Pick ONE section, do it timed, check answers immediately.
Full mock session:      Work through all sections in order (105 min + 50 min).
Weak-spot targeting:    If you keep getting Group X grammar wrong, drill ONLY that group.

Scoring guide:
  90%+:  Strong in this area. Maintain with weekly review.
  70–89%: Solid. Review wrong answers, drill again in 3 days.
  50–69%: Needs work. Re-read grammar notes, then redo.
  < 50%:  Study the grammar/vocab notes first, then return.
```

---

## SECTION 1 — 問題1: 漢字読み (Kanji Reading) — 10 Questions

**Read the underlined word. Choose the correct reading.**

---

**Q1.** 彼女は笑顔でみんなを迎えた。
笑顔 の読み方は？
```
1. わらいがお
2. えがお
3. えがた
4. しょうがん
```

**Q2.** 工事が原因で、渋滞が続いている。
渋滞 の読み方は？
```
1. じゅうたい
2. しぶたい
3. じゅったい
4. じゅうてい
```

**Q3.** 彼はいつも冷静な判断をする。
冷静 の読み方は？
```
1. れいじょう
2. れいせい
3. りょうせい
4. れいてい
```

**Q4.** このデザインは現代的で洗練されている。
洗練 の読み方は？
```
1. せんれん
2. あらいれん
3. せんれい
4. そうれん
```

**Q5.** 彼女の努力は目覚ましい成果をあげた。
目覚ましい の読み方は？
```
1. めさましい
2. めざましい
3. もくさましい
4. めざわしい
```

**Q6.** 今年度の予算を削減することになった。
削減 の読み方は？
```
1. そうげん
2. けずりへらし
3. さくげん
4. しょくげん
```

**Q7.** 彼は責任感が強く、頼もしい存在だ。
頼もしい の読み方は？
```
1. よろこばしい
2. たのもしい
3. なつかしい
4. かなしい
```

**Q8.** 環境汚染の問題は依然として解決されていない。
依然 の読み方は？
```
1. いぜん
2. えいぜん
3. いじょう
4. いんぜん
```

**Q9.** 会議では活発な議論が行われた。
議論 の読み方は？
```
1. きろん
2. ぎろん
3. かいろん
4. ぎほん
```

**Q10.** 社長の指示に従って行動した。
指示 の読み方は？
```
1. しじ
2. さしず
3. しめし
4. しさ
```

### ✅ 答え (Answers) — Section 1
```
Q1:  2. えがお
Q2:  1. じゅうたい
Q3:  2. れいせい
Q4:  1. せんれん
Q5:  2. めざましい
Q6:  3. さくげん
Q7:  2. たのもしい
Q8:  1. いぜん
Q9:  2. ぎろん
Q10: 1. しじ
```

---

## SECTION 2 — 問題2: 表記 (Kanji Writing) — 10 Questions

**Choose the correct kanji for the underlined hiragana.**

---

**Q1.** 仕事のけいかくを立てる。
```
1. 計画  2. 計確  3. 計格  4. 形画
```

**Q2.** みんなの前でスピーチをするのはきんちょうする。
```
1. 緊調  2. 緊長  3. 緊張  4. 勤張
```

**Q3.** 毎朝かならず新聞を読む。
```
1. 必ず  2. 必らず  3. 必す  4. 必ざ
```

**Q4.** 今月のうりあげが大幅に増加した。
```
1. 売上げ  2. 売揚げ  3. 売上  4. 壳上げ
```

**Q5.** このきかいを逃したら後悔する。
```
1. 機械  2. 器会  3. 機会  4. 気会
```

**Q6.** 彼は誰とでもすぐにしたしくなれる。
```
1. 懐しく  2. 親しく  3. 慣しく  4. 睦しく
```

**Q7.** 彼女はしんけんに話を聞いていた。
```
1. 真剣  2. 信件  3. 真権  4. 新健
```

**Q8.** 台風のひがいがひどかった。
```
1. 被害  2. 避害  3. 被外  4. 被界
```

**Q9.** その店は地域のじゅうみんに愛されている。
```
1. 住面  2. 住民  3. 住見  4. 重民
```

**Q10.** この問題はけんとうする必要がある。
```
1. 見当  2. 県統  3. 検討  4. 研統
```

### ✅ 答え — Section 2
```
Q1:  1. 計画
Q2:  3. 緊張
Q3:  1. 必ず
Q4:  3. 売上
Q5:  3. 機会
Q6:  2. 親しく
Q7:  1. 真剣
Q8:  1. 被害
Q9:  2. 住民
Q10: 3. 検討
```

---

## SECTION 3 — 問題4: 文脈規定 (Vocabulary in Context) — 12 Questions

**Choose the word that best fits the sentence.**

---

**Q1.** この映画は世界中で＿＿＿が高く、多くの賞を受賞している。
```
1. 見当  2. 評判  3. 感謝  4. 配慮
```

**Q2.** 彼女はいつも＿＿＿な態度で仕事に取り組む。
```
1. 積極的  2. 消極的  3. 具体的  4. 抽象的
```

**Q3.** 環境問題の＿＿＿として、工場の排水が挙げられる。
```
1. 手段  2. 過程  3. 要因  4. 目的
```

**Q4.** 新しい政策について様々な＿＿＿が行われた。
```
1. 議論  2. 誤解  3. 謝罪  4. 信頼
```

**Q5.** 彼は状況をすばやく＿＿＿し、適切に対応した。
```
1. 依頼  2. 提案  3. 判断  4. 維持
```

**Q6.** このレポートは具体的な＿＿＿が不足している。
```
1. 観点  2. 根拠  3. 背景  4. 影響
```

**Q7.** 計画を変更するには全員の＿＿＿が必要だ。
```
1. 承認  2. 批判  3. 主張  4. 措置
```

**Q8.** 彼女は3ヶ国語を＿＿＿に話すことができる。
```
1. 著しく  2. 流暢  3. わずか  4. かなり
```

**Q9.** 長時間の交渉の＿＿＿、ついに合意に達した。
```
1. 末  2. 結果  3. 以来  4. とたん
```

**Q10.** その映画は期待した＿＿＿ではなかった。
```
1. ほど  2. くらい  3. ほどのもの  4. ものの
```

**Q11.** 彼の説明は＿＿＿で、とても分かりやすかった。
```
1. 具体的  2. 抽象的  3. 消極的  4. 総合的
```

**Q12.** 問題の解決に向けて、早急な＿＿＿が必要だ。
```
1. 措置  2. 課題  3. 制度  4. 政策
```

### ✅ 答え — Section 3
```
Q1:  2. 評判
Q2:  1. 積極的
Q3:  3. 要因
Q4:  1. 議論
Q5:  3. 判断
Q6:  2. 根拠
Q7:  1. 承認
Q8:  2. 流暢
Q9:  1. 末
Q10: 1. ほど
Q11: 1. 具体的
Q12: 1. 措置
```

---

## SECTION 4 — 問題5: 言い換え類義 (Synonym) — 8 Questions

**Choose the word or phrase closest in meaning to the underlined part.**

---

**Q1.** 彼はいつも穏やかな話し方をする。
穏やかな と近い意味は？
```
1. 激しい  2. 静かで落ち着いている  3. 正確な  4. 明るい
```

**Q2.** その計画はただちに実行された。
ただちに と近い意味は？
```
1. 徐々に  2. すぐに  3. 慎重に  4. ゆっくりと
```

**Q3.** 彼の提案はもっともだと思う。
もっともだ と近い意味は？
```
1. 難しい  2. 理にかなっている  3. 面白い  4. 残念だ
```

**Q4.** 彼女はその件についてかたくなに拒否した。
かたくなに と近い意味は？
```
1. 強引に  2. 丁寧に  3. 頑固に  4. 素直に
```

**Q5.** この仕事はやむを得ない事情で断った。
やむを得ない と近い意味は？
```
1. 仕方がない  2. 意外な  3. 嬉しい  4. 簡単な
```

**Q6.** 彼はうながされてようやく席に着いた。
うながされて と近い意味は？
```
1. 誘われて  2. 急かされて  3. 褒められて  4. 叱られて
```

**Q7.** 新技術の開発が急速に進んでいる。
急速に と近い意味は？
```
1. 徐々に  2. 着実に  3. めざましく早く  4. たちまち
```

**Q8.** 彼女はわずかな手がかりから真実を見つけた。
わずかな と近い意味は？
```
1. 豊富な  2. ほんの少しの  3. 明確な  4. 複雑な
```

### ✅ 答え — Section 4
```
Q1: 2. 静かで落ち着いている
Q2: 2. すぐに
Q3: 2. 理にかなっている
Q4: 3. 頑固に
Q5: 1. 仕方がない
Q6: 2. 急かされて
Q7: 3. めざましく早く
Q8: 2. ほんの少しの
```

---

## SECTION 5 — 問題7: 文法 (Grammar Fill-in) — 20 Questions

**This is the highest-value grammar section. Choose the correct grammar pattern.**

---

**Q1.** もっと早く起きれば、電車に間に合った＿＿＿。
```
1. ものだ  2. のに  3. だけ  4. ほど
```

**Q2.** 彼に頼まれたので、断る＿＿＿。
```
1. はずだ  2. わけだ  3. わけにはいかない  4. ことになっている
```

**Q3.** 練習すれば＿＿＿、上手になる。
```
1. するほど  2. するのに  3. するたびに  4. するから
```

**Q4.** 先生の＿＿＿で、試験に合格できた。
```
1. せいで  2. おかげ  3. くせに  4. ために
```

**Q5.** このままでは失敗し＿＿＿。
```
1. かねない  2. かねる  3. きれない  4. にくい
```

**Q6.** 彼は10年間日本にいた＿＿＿だから、日本語が上手なのは当然だ。
```
1. はず  2. わけ  3. もの  4. こと
```

**Q7.** 嫌いな＿＿＿が、得意でもない。
```
1. わけではない  2. わけにはいかない  3. はずがない  4. ものだ
```

**Q8.** 雨に＿＿＿、試合は続いた。
```
1. かかわらず  2. もかかわらず  3. にもかかわらず  4. はもかかわらず
```

**Q9.** 忘れない＿＿＿メモした。
```
1. ために  2. ように  3. ものだ  4. わけで
```

**Q10.** 試験には合格した＿＿＿、就職には苦労した。
```
1. ものの  2. ものだ  3. ものか  4. ものとして
```

**Q11.** 天気予報に＿＿＿、明日は雨だそうだ。
```
1. よって  2. よると  3. ついて  4. おいて
```

**Q12.** 食べてみない＿＿＿、おいしいかどうかわからない。
```
1. ことには  2. ことになっては  3. ことがあれば  4. ことにすれば
```

**Q13.** これは推測に＿＿＿ない。
```
1. 過ぎ  2. すぎ  3. すぎて  4. すぎでは
```

**Q14.** 返事が来＿＿＿、連絡します。
```
1. 次第  2. ため  3. ように  4. たとたん
```

**Q15.** 若い＿＿＿に、いろいろな経験をしたほうがいい。
```
1. うちに  2. ために  3. うえに  4. ことに
```

**Q16.** 春＿＿＿、まだ寒い日もある。
```
1. にしては  2. とはいえ  3. だからこそ  4. にもかかわらず
```

**Q17.** お金がある＿＿＿、幸せになれるわけではない。
```
1. からこそ  2. だからといって  3. からといって  4. だからこそ
```

**Q18.** 社長を＿＿＿として、全員が出席した。
```
1. はじめ  2. もちろん  3. かわりに  4. ほかに
```

**Q19.** この点に＿＿＿、両者の意見が一致した。
```
1. ついて  2. おいて  3. とって  4. よって
```

**Q20.** 彼女は歌が上手な＿＿＿か、演技も素晴らしい。
```
1. だけ  2. ばかり  3. のみ  4. しか
```

### ✅ 答え — Section 5
```
Q1:  2. のに         (regret: "should have done but didn't")
Q2:  3. わけにはいかない (cannot afford to refuse — obligation)
Q3:  1. するほど      (the more... the more: 〜ば〜ほど)
Q4:  2. おかげ        (positive cause: thanks to)
Q5:  1. かねない      (risk/possibility: might well fail)
Q6:  2. わけ          (natural explanation/conclusion)
Q7:  1. わけではない  (it doesn't mean that)
Q8:  3. にもかかわらず (despite / in spite of)
Q9:  2. ように        (so that — non-volitional purpose)
Q10: 1. ものの        (although — unexpected result)
Q11: 2. よると        (according to: によると)
Q12: 1. ことには      (〜ないことには〜ない: unless)
Q13: 1. 過ぎ          (に過ぎない: nothing more than)
Q14: 1. 次第          (〜次第: as soon as)
Q15: 1. うちに        (〜うちに: while / before it changes)
Q16: 2. とはいえ      (that said / even so)
Q17: 3. からといって  (just because... doesn't mean)
Q18: 1. はじめ        (〜をはじめとして: starting with)
Q19: 2. おいて        (〜において: in / at — formal)
Q20: 2. ばかり        (〜ばかりか: not only but also)
```

---

## SECTION 6 — 問題7: 最頻出トラップ Grammar Trap Questions — 12 Questions

**These are the most commonly confused pairs on the N2 exam.**

---

**TRAP SET 1: ために vs ように**

**Q1.** 医者になる＿＿＿、一生懸命勉強した。
```
1. ために  2. ように
```

**Q2.** 忘れない＿＿＿、手帳に書いた。
```
1. ために  2. ように
```

**Q3.** 体を壊さない＿＿＿、無理をしないでください。
```
1. ために  2. ように
```

**Q4.** 早く帰れる＿＿＿、仕事を急いだ。
```
1. ために  2. ように
```

### ✅ 答え — Trap Set 1
```
Q1: 1. ために  (volitional: conscious goal — "I studied TO become a doctor")
Q2: 2. ように  (non-volitional state: "so that the state of not-forgetting results")
Q3: 2. ように  (negative verb + ように: please do X so that Y state results)
Q4: 2. ように  (potential verb: 帰れる is potential → use ように)

RULE: 
  ために → plain volitional verb + ために (食べる・勉強する・買う etc.)
  ように → negative verbs (〜ない), potential verbs (〜られる/〜れる), or non-volitional
```

---

**TRAP SET 2: はずだ vs わけだ vs にちがいない**

**Q5.** 彼は地図を持っているから、迷わない＿＿＿。
```
1. はずだ  2. わけだ  3. にちがいない
```

**Q6.** 彼が10年間日本に住んでいた。日本語が上手な＿＿＿だ。
```
1. はず  2. わけ  3. にちがいない
```

**Q7.** あの光は絶対に UFO だ。UFO に＿＿＿。
```
1. はずだ  2. わけだ  3. にちがいない
```

### ✅ 答え — Trap Set 2
```
Q5: 1. はずだ      (logical expectation based on a condition)
Q6: 2. わけだ      (explains/concludes from known facts: "naturally/that explains it")
Q7: 3. にちがいない (strong personal conviction, certainty)

RULE:
  はずだ    = should be (logic: IF condition THEN expected result)
  わけだ    = naturally / makes sense (conclusion drawn from a fact already stated)
  にちがいない = must be / certainly (speaker's strong belief/certainty)
```

---

**TRAP SET 3: らしい vs ようだ vs そうだ (様態)**

**Q8.** 空が暗くなって、雨が降り＿＿＿。
```
1. らしい  2. ようだ  3. そうだ
```

**Q9.** 彼女は転職する＿＿＿。（聞いた話として）
```
1. らしい  2. ようだ  3. そうだ（様態）
```

**Q10.** 外を見ると、雨が降っている＿＿＿。
```
1. らしい  2. ようだ  3. そうだ
```

### ✅ 答え — Trap Set 3
```
Q8: 3. そうだ (様態)  (visual: sky looks like it will rain — based on current appearance)
Q9: 1. らしい           (indirect evidence / hearsay — you heard from someone)
Q10: 2. ようだ          (direct observation: looking outside and seeing rain)

RULE:
  らしい   = hearsay (heard from someone else) OR typical of
  ようだ   = seems (based on direct, personal observation using your senses)
  そうだ(様態) = looks like (appearance — something is ABOUT to happen)
  そうだ(伝聞) = I heard that (someone told you) — different from 様態
```

---

**TRAP SET 4: わけにはいかない vs わけではない**

**Q11.** 嫌いな＿＿＿が、好きでもない。
```
1. わけにはいかない  2. わけではない
```

**Q12.** 彼に頼まれたので、断る＿＿＿。
```
1. わけにはいかない  2. わけではない
```

### ✅ 答え — Trap Set 4
```
Q11: 2. わけではない    (it's not that I dislike it — partial negation/clarification)
Q12: 1. わけにはいかない (I cannot afford to refuse — social obligation prevents it)

RULE:
  わけではない    = "it doesn't mean X" — denies an assumption
  わけにはいかない = "I cannot do X" — social/moral obligation prevents action
```

---

## SECTION 7 — 問題8: 文の組み立て (Sentence Rearrangement) — 8 Questions

**Put the four items in the correct order. The ★ position is marked in the sentence.**

---

**Q1.** 彼女は昨日から___★___している。
```
A: と  B: 体の  C: 調子が悪い  D: 言っ
```
Correct order: ＿★＿ = 3番目の語は何？

```
1. A  2. B  3. C  4. D
```

**Q2.** このドラマは___★___作られた。
```
A: に  B: 実話  C: もとに  D: を
```
★は3番目

```
1. A  2. C  3. B  4. D
```

**Q3.** 健康___★___毎日運動している。
```
A: ため  B: の  C: に  D: を守る
```
★は2番目

```
1. B  2. A  3. C  4. D
```

**Q4.** 彼は___★___たとたんに走り出した。
```
A: ドアが  B: 開い  C: を  D: 玄関の
```
★は3番目

```
1. B  2. A  3. C  4. D
```

### ✅ 答え — Section 7
```
Q1: 正しい順: B(体の) D(調子が悪い→"体の調子が悪い") ... 
    Full: 体の → 調子が悪い → と → 言っ → している
    ★3番目 = 3. C (調子が悪い)

Q2: Full order: B(実話) D(を) B→A(もとに)
    実話 → を → もとに → ★ = 2. C (もとに)
    
Q3: 健康 → B(の) ★A(ため) C(に) D(を守る)
    ★2番目 = 2. A (ため)

Q4: D(玄関の) A(ドアが) B(開い) ★C = 3. C
```

---

## SECTION 8 — 問題9: 文章の文法 (Passage Grammar) — Full Passage

**Read the passage and choose the best expression for each blank (①〜⑤).**

---

現代社会では、スマートフォンが急速に普及し、私たちの生活は大きく変わった。
スマートフォンは便利な①＿＿＿、その使い方によっては問題も生じる。
特に若者の間では、常にスマートフォンを見ている②＿＿＿が増えている。
これは勉強や仕事の③＿＿＿になることもある。
しかし、スマートフォンの機能を上手に④＿＿＿、生産性を高めることもできる。
使い方⑤＿＿＿で、良い面も悪い面も出てくるのだ。

**① :**
```
1. うえで  2. 一方で  3. にかかわらず  4. だからこそ
```

**② :**
```
1. 傾向  2. 規則  3. 可能性  4. 必要性
```

**③ :**
```
1. 促進  2. 妨げ  3. 根拠  4. 観点
```

**④ :**
```
1. 活用すれば  2. 活用するのに  3. 活用したところ  4. 活用するため
```

**⑤ :**
```
1. 次第  2. だけあって  3. にもかかわらず  4. ばかりか
```

### ✅ 答え — Section 8
```
①: 2. 一方で     (smartphones are convenient, but on the other hand — contrast)
②: 1. 傾向       (trend / tendency — "the trend of always looking at phones is increasing")
③: 2. 妨げ       (obstacle/hindrance — "this can also be a hindrance to study/work")
④: 1. 活用すれば (if you make good use of — conditional: use well → productivity rises)
⑤: 1. 次第       (depending on how you use it — 使い方次第 = "depending on usage")
```

---

## SECTION 9 — 問題10/11: 読解 (Reading Comprehension) — Full Passage

**Read the passage carefully, then answer the questions.**

---

### 文章：

　日本では近年、働き方改革が推進されている。その中心的な目標は、長時間労働の削減と、多様な働き方の実現だ。かつて日本では、長時間働くことが勤勉さの証とされ、残業をいとわない社員が評価される文化があった。しかし、これが過労死や精神疾患の原因になるとして、社会問題として注目されるようになった。

　政府は、法律を改正することで、企業に対して残業時間の上限を設けることを義務づけた。また、テレワークや時差出勤、フレックスタイム制の導入を推奨している。これらの制度は、特に育児や介護をしながら働く人々にとって、大きな助けとなっている。

　一方で、課題もある。中小企業の中には、制度を導入する余裕がないところも多い。また、テレワークに不向きな職種もある。改革が全ての働く人に平等に恩恵をもたらしているとは言えない状況だ。

　それでも、意識の変化は確実に起きている。若い世代を中心に、「仕事よりも生活を重視する」という価値観が広まりつつある。今後は、制度の整備だけでなく、職場の文化そのものを変えることが求められるだろう。

---

**Q1.** この文章のテーマは何ですか？
```
1. 日本の教育改革
2. 日本の労働環境の変化
3. 少子高齢化問題
4. テレワークの普及
```

**Q2.** かつての日本の職場文化はどのようなものでしたか？
```
1. 定時退社が当然とされていた
2. 長時間労働が勤勉さの証と見られていた
3. 多様な働き方が推奨されていた
4. 政府が労働時間を厳しく管理していた
```

**Q3.** 「働き方改革」として、政府が推進していることはどれですか？
```
1. 給与の引き上げ
2. 残業時間の上限設定とテレワークの導入推奨
3. 全ての企業への義務的な在宅勤務
4. 中小企業への補助金支給
```

**Q4.** 筆者が「課題がある」と述べている理由として正しいものはどれですか？
```
1. 法律の改正が遅れているから
2. 若者が仕事より生活を重視するようになったから
3. 改革の恩恵がすべての人に届いていないから
4. テレワークが普及しすぎているから
```

**Q5.** 筆者が最終段落で最も言いたいことは何ですか？
```
1. 若者の価値観の変化は問題だ
2. 制度を整えるだけでなく職場文化の変革も必要だ
3. 働き方改革は完成している
4. テレワークをもっと普及させるべきだ
```

### ✅ 答え — Section 9
```
Q1: 2. 日本の労働環境の変化
Q2: 2. 長時間労働が勤勉さの証と見られていた
Q3: 2. 残業時間の上限設定とテレワークの導入推奨
Q4: 3. 改革の恩恵がすべての人に届いていないから
Q5: 2. 制度を整えるだけでなく職場文化の変革も必要だ
```

---

## SECTION 10 — 問題12: 統合理解 (Comparative Reading) — 2 Texts

**Read both texts then answer which author says what.**

---

### 文章A：

　スマートフォンは現代生活に欠かせないツールとなった。情報へのアクセスが容易になり、コミュニケーションも便利になった。特に高齢者が家族と連絡を取りやすくなったことは、孤独感の軽減に役立っている。問題はあるにしても、スマートフォンが社会に与えたポジティブな影響は非常に大きい。

### 文章B：

　スマートフォンの普及は、人々の集中力を著しく低下させているという研究結果がある。若者の間では、対面でのコミュニケーション能力が低下しているとも指摘されている。便利さと引き換えに、私たちは大切なものを失ってしまっているのではないだろうか。

---

**Q1.** 文章Aと文章Bが共通して述べていることは何ですか？
```
1. スマートフォンは社会に問題をもたらしている
2. スマートフォンは現代社会に広く普及している
3. スマートフォンは高齢者に役立っている
4. スマートフォンは若者の能力を低下させている
```

**Q2.** 文章Aと文章Bの立場の違いはどこですか？
```
1. Aはスマートフォンを肯定的に、Bは否定的に論じている
2. Aは若者、Bは高齢者の問題を論じている
3. Aは日本国内、Bは世界全体の問題を論じている
4. Aは制度、Bは文化について論じている
```

### ✅ 答え — Section 10
```
Q1: 2. スマートフォンは現代社会に広く普及している
     (Both texts accept smartphones are widespread — A calls it 欠かせない, B says 普及)
Q2: 1. Aはスマートフォンを肯定的に、Bは否定的に論じている
```

---

## SECTION 11 — 問題14: 情報検索 (Information Retrieval) — Notice

**Read the notice and answer the questions.**

---

### お知らせ

**〇〇図書館 夏期特別貸出サービスのご案内**

期間：7月15日（月）〜8月31日（土）

通常の貸出冊数：1人につき5冊まで
特別期間中：1人につき10冊まで

返却期限：貸出日から21日以内

**ご注意：**
- 雑誌・参考図書・視聴覚資料は対象外です
- 延滞中の方は本サービスをご利用いただけません
- 中学生以下のお子様は保護者の同伴が必要です

予約受付：1人につき最大3冊まで予約可能（通常と同じ）
問い合わせ：図書館カウンターまで

---

**Q1.** 特別期間中、1人何冊まで本を借りられますか？
```
1. 5冊  2. 10冊  3. 3冊  4. 21冊
```

**Q2.** このサービスを利用できないのはどんな人ですか？
```
1. 中学生
2. 雑誌を借りたい人
3. 現在延滞している本がある人
4. 予約を入れたい人
```

**Q3.** 予約は1人につき最大何冊できますか？
```
1. 3冊  2. 5冊  3. 10冊  4. 変わらない（通常と同じ3冊）
```

### ✅ 答え — Section 11
```
Q1: 2. 10冊
Q2: 3. 現在延滞している本がある人
Q3: 4. 変わらない（通常と同じ3冊）
     → Notice says 予約は通常と同じ: same as normal = 3 books max
```

---

## SECTION 12 — 敬語 (Keigo) — 10 Questions

**Choose the correct keigo expression.**

---

**Q1.** 部長が「あとで説明する」と言っていた。→ 敬語で？
```
1. 説明します  2. おっしゃっていました  3. 申しておりました  4. 説明なさいます
```

**Q2.** 先生がいらっしゃいますか？
いらっしゃいます は何の動詞の敬語？
```
1. 行く  2. いる  3. 来る  4. いる/行く/来るすべて
```

**Q3.** 「私が説明します」の謙譲語は？
```
1. ご説明いたします  2. ご説明なさいます  3. 説明してあげます  4. 説明されます
```

**Q4.** 「もう食べましたか？」を尊敬語で言うと？
```
1. もうお食べになりましたか？
2. もう召し上がりましたか？
3. もういただきましたか？
4. もう食べていらっしゃいますか？
```

**Q5.** 「私は後で行きます」の謙譲語は？
```
1. あとでいらっしゃいます
2. あとでまいります
3. あとでいただきます
4. あとでなさいます
```

**Q6.** 「先生が本を持っています」→ 尊敬語で？
```
1. 先生が本をお持ちになっています
2. 先生が本を持たれています
3. 先生が本をいただいています
4. 先生が本をくださっています
```

**Q7.** 上司に: 「今日の会議を見学させてください」→ より丁寧に？
```
1. 見学してあげてください
2. 見学させていただけますか
3. 見学してもらえますか
4. 見学してやってください
```

**Q8.** 「私が資料を拝見します」—— この使い方は正しい？
```
1. 正しい（自分が見る → 謙譲語）
2. 間違い（目上の人に使う尊敬語）
3. どちらでもない
4. 古い表現で今は使わない
```

**Q9.** 「どうぞ、お座りください」の意味は？
```
1. 座らないでください
2. 座っていてください
3. どうぞ座ってください
4. 座ったほうがいいです
```

**Q10.** 「先生、明日のご予定はいかがでしょうか？」—— 正しい？
```
1. 間違い：先生のことは「ご予定」は使わない
2. 正しい：目上の人の予定には「ご〜」をつける
3. 間違い：「いかが」は使わない
4. 正しいが非常に古い表現
```

### ✅ 答え — Section 12
```
Q1:  2. おっしゃっていました   (言う → おっしゃる — 尊敬語)
Q2:  4. いる/行く/来るすべて   (いらっしゃる is used for all three)
Q3:  1. ご説明いたします        (する → いたす — 謙譲語)
Q4:  2. もう召し上がりましたか？ (食べる/飲む → 召し上がる — 尊敬語)
Q5:  2. あとでまいります         (行く → 参る — 謙譲語)
Q6:  1. 先生が本をお持ちになっています (持つ → お〜になる pattern)
Q7:  2. 見学させていただけますか  (〜させていただく — humble request)
Q8:  1. 正しい (拝見する = humble form of 見る — used for oneself viewing)
Q9:  3. どうぞ座ってください
Q10: 2. 正しい (ご〜 is the respectful prefix for superiors' actions/things)
```

---

## EXAM DAY STRATEGY CARD

```
VOCABULARY SECTION (105 min total with grammar + reading):
  問題1 (漢字読み):    ~2 min — read carefully, listen to the sound in your head
  問題2 (表記):        ~3 min — eliminate obviously wrong kanji, check radical
  問題3 (語形成):      ~2 min — think of words you know with that component
  問題4 (文脈):        ~6 min — read the full sentence for context, not just the blank
  問題5 (類義):        ~4 min — find what the word MEANS, not sounds like
  問題6 (用法):        ~5 min — test each option in the sentence

GRAMMAR SECTION:
  問題7 (文法1):       ~12 min — 1.5 min/question average
  問題8 (並べ替え):    ~10 min — build from anchor words you recognize
  問題9 (文章文法):    ~8 min — read the full passage first, then fill

READING SECTION:
  問題10 (中文):       ~12 min — read question first, find the answer in the text
  問題11 (長文):       ~18 min — skim structure, find main point of each paragraph
  問題12 (統合):       ~10 min — compare two texts' positions explicitly
  問題13 (長文):       ~15 min — information-dense: track facts carefully
  問題14 (情報検索):   ~5 min  — scan for specific data, don't read everything

IF YOU RUN OUT OF TIME:
  Mark the same answer (e.g., 2) for remaining questions.
  There is NO penalty for wrong answers (just no points).
  Never leave a blank — always mark something.

TOP 5 MISTAKES TO AVOID:
  1. ために vs ように confusion (see Section 6 Trap Set 1)
  2. はずだ vs わけだ confusion (see Section 6 Trap Set 2)
  3. らしい vs ようだ vs そうだ confusion (see Section 6 Trap Set 3)
  4. Threshold panic: you only need 50% (90/180) + subscores ≥ 19
  5. Not reading the question before the passage — always read Q first
```

---

## QUICK DRILL: 10 Must-Know Grammar Meanings

```
Pattern              Meaning in English               Example (key word)
────────────────────────────────────────────────────────────────────────
〜にもかかわらず    despite / in spite of            雨にもかかわらず
〜ものの            although (unexpected result)     合格したものの
〜とはいえ          that said / even so              春とはいえ
〜からといって      just because... doesn't mean    お金があるからといって
〜おかげで          thanks to (positive)             先生のおかげで
〜せいで            because of (negative blame)      彼のせいで
〜ばかりか          not only... but also             歌が上手なばかりか
〜次第              depending on / as soon as        返事が来次第
〜うちに            while / before it changes        若いうちに
〜かねない          might well / risk of (bad)       失敗しかねない
```
