# Glossary — JLPT N2 Q&A Terms
Key terms, grammar patterns, and concepts from the Q&A file explained for reference.

---

**JLPT N2**
日本語能力試験 N2. Second highest of 5 JLPT levels. Tests near-professional Japanese in reading, listening, grammar, and vocabulary. Pass requires 90/180 total AND both subscores ≥ 19.

**問題1 — 漢字読み**
Vocabulary section question type: given a kanji word underlined in a sentence, choose the correct hiragana reading from 4 options. Tests whether you can READ kanji.

**問題2 — 表記**
Given a hiragana word underlined in a sentence, choose the correct kanji from 4 options. Tests whether you know how to WRITE the word in kanji.

**問題4 — 文脈規定**
Contextual vocabulary: a sentence with a blank, choose the word that fits the meaning of the sentence. Tests reading comprehension + vocabulary range.

**問題5 — 言い換え類義**
Synonym/paraphrase: underlined word in a sentence, choose the option closest in meaning. Tests depth of vocabulary understanding.

**問題7 — 文法1**
Grammar fill-in: a sentence with one blank, choose the correct grammar pattern from 4 options. The highest-value grammar question type.

**問題8 — 並べ替え (文の組み立て)**
Sentence rearrangement: 4 items must be placed in the correct grammatical order inside a sentence. One position (★) is specified. Tests structural grammar knowledge.

**問題9 — 文章の文法**
Passage grammar: a short text with 5 blanks; choose the best word or expression for each. Tests grammar IN CONTEXT, not just isolated patterns.

**問題10/11 — 読解**
Reading comprehension: medium (500 chars) and long (800+ chars) passages followed by questions about meaning, content, and author's intent.

**問題12 — 統合理解**
Integrated comprehension: two short texts on a related topic. Questions ask you to compare the two authors' positions and identify similarities/differences.

**問題14 — 情報検索**
Information retrieval: a notice, advertisement, or schedule. Questions ask for specific data (dates, numbers, conditions). Scan don't read fully.

**〜ために (目的)**
Purpose: "in order to [do something]." Used with VOLITIONAL verbs (actions a person intentionally does). 医者になるために勉強した = "studied in order to become a doctor."

**〜ように (目的)**
Purpose: "so that [a state results]." Used with NEGATIVE verbs (〜ない) or POTENTIAL verbs (〜られる). 忘れないように書く = "wrote so as not to forget."

**〜にもかかわらず**
"Despite / in spite of / regardless of." Connects two clauses where the second is unexpected given the first. 雨にもかかわらず試合は続いた = "Despite the rain, the match continued."

**〜ものの**
"Although / even though" — the second clause is an unexpected or disappointing result. 合格したものの就職に苦労した = "Although I passed the exam, I struggled to find work."

**〜とはいえ**
"That said / even so / although it may be said." Acknowledges a fact but introduces a qualification. 春とはいえまだ寒い = "That said, it's still cold even though it's spring."

**〜からといって**
"Just because... doesn't mean..." お金があるからといって幸せとは限らない = "Just because you have money doesn't mean you're happy."

**〜はずだ**
"Should be / expected to be." Strong logical expectation based on facts or reasoning. 彼はもう着いているはずだ = "He should be here by now." (because he left early enough)

**〜わけだ**
"Naturally / that explains it / which means." A conclusion derived from a fact already mentioned. 10年住んでいたわけだから上手なのは当然 = "Since (naturally) he lived there 10 years, it makes sense he's fluent."

**〜にちがいない**
"Must certainly be / there's no doubt." Speaker's strong personal conviction. UFOにちがいない = "It must be a UFO."

**〜らしい (伝聞・推量)**
"Apparently / it seems / I heard that." Based on indirect evidence or hearsay — information from another source. 田中さんは転職するらしい = "Apparently Tanaka is changing jobs."

**〜らしい (典型)**
"Typical of / characteristic of." Describes something as representative of a category. 日本人らしい礼儀正しさ = "Characteristically Japanese politeness."

**〜ようだ**
"Seems / appears to be." Based on DIRECT personal observation (what you see/hear/sense yourself). 外は雨が降っているようだ = "It seems to be raining outside." (I'm observing it)

**〜そうだ (様態)**
"Looks like / seems about to." Visual/appearance-based judgment about something ABOUT TO happen. 雨が降りそうだ = "It looks like it's going to rain." (sky looks dark right now)

**〜そうだ (伝聞)**
"I heard that." Reporting information you received from someone else. 明日は雨だそうだ = "I heard it will rain tomorrow." This is different from 様態.

**〜わけにはいかない**
"Cannot afford to / must not." Social or moral obligation prevents the action. 断るわけにはいかない = "I cannot afford to refuse." (because it would be socially wrong)

**〜わけではない**
"It doesn't mean that / it's not that." Partially denies an assumption or expectation. 嫌いなわけではない = "It's not that I dislike it." (but I'm not enthusiastic either)

**〜かねない**
"Might well / there's a risk of." Expresses negative possibility — something bad could happen. 失敗しかねない = "There's a risk we might fail."

**〜かねる**
"Find it difficult to / cannot bring oneself to." Polite refusal or reluctance. お答えしかねます = "I find it difficult to answer that." (formal refusal)

**〜おかげで**
"Thanks to / owing to." Expresses a POSITIVE cause. 先生のおかげで合格できた = "Thanks to my teacher I passed."

**〜せいで**
"Because of (blame)." Expresses a NEGATIVE cause with blame. 彼のせいで失敗した = "It failed because of him."

**〜うちに**
"While / before [a situation changes]." 若いうちに経験を積む = "Accumulate experience while you are young." Implies the state will eventually change.

**〜次第**
Two uses: (1) "As soon as" — 返事が来次第連絡します = "I'll contact you as soon as a reply comes." (2) "Depending on" — 使い方次第 = "Depending on how you use it."

**〜ばかりか**
"Not only... but also" — stronger than だけでなく. 歌が上手なばかりか演技も素晴らしい = "Not only is she a good singer, but her acting is wonderful too."

**尊敬語 (Sonkeigo)**
Honorific language. Used to elevate the subject (the person you're speaking to or about). おっしゃる (say), 召し上がる (eat/drink), いらっしゃる (be/go/come), なさる (do).

**謙譲語 (Kenjōgo)**
Humble language. Used to lower yourself to show respect. 申す (say), いただく (eat/drink/receive), 参る (go/come), いたす (do), 拝見する (see/look).

**丁寧語 (Teineigo)**
Polite neutral language. です/ます/ございます. Does not involve elevation or lowering — simply polite.

**〜させていただく**
Humble request for permission to do something. 発表させていただきます = "I would humbly like to give a presentation (with your permission)." Common in business Japanese.

**いかがでしょうか**
Very polite form of "how is...?" / "would you like...?" Used when speaking to superiors. 明日のご予定はいかがでしょうか = "How does your schedule look for tomorrow?"

**統合理解 (Integrated comprehension)**
N2 reading problem type where you read two short texts on a related topic and answer questions comparing the two authors' positions. Common question: "What do both authors agree on?" or "How do the two authors differ?"

**情報検索 (Information retrieval)**
N2 reading problem type: a practical document (notice, schedule, advertisement) with specific questions. Strategy: scan for the specific fact asked about (dates, numbers, conditions) — don't read the whole document.

**Speed target**
問題14 (information retrieval) should take ~5 min. 問題10/11 combined ~30 min. Grammar section ~30 min. Always leave 5 min to review.

**No penalty rule**
JLPT has no penalty for wrong answers — every blank costs the same as a wrong answer. Always mark something, even if guessing.
