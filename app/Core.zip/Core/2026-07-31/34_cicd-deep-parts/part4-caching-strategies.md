# Part 4 — Caching Strategies: Deep Dive

---

## Why Caching Is the #1 Speed Lever

Before any other optimization, caching dependency downloads is the single highest-ROI change you can make to a pipeline.

```
Cold build (no cache):
  Maven dependency download:  3 min 20 sec   (300MB over network)
  Compilation:                45 sec
  Total:                      4 min 5 sec

Warm build (cached deps):
  Maven dependency restore:   8 sec          (from local SSD)
  Compilation:                45 sec
  Total:                      53 seconds

Savings per build:             3 min 12 sec  (78% faster)
Team of 10, 50 pushes/day:    160 minutes saved per day
Per month:                    ~80 hours of compute time
```

---

## The Cache Lifecycle in GitHub Actions

```
WRITE (first run or cache miss):
  1. Runner allocates a fresh machine
  2. No ~/.m2 exists → Maven downloads everything from internet
  3. After job completes: ~/.m2 is compressed and uploaded to GitHub cache
     Key stored: "maven-${{ hashFiles('pom.xml') }}" = "maven-abc123"

READ (subsequent runs, same pom.xml):
  1. Runner allocates fresh machine (still empty)
  2. Cache action looks up key "maven-abc123" → FOUND
  3. Downloads compressed ~/.m2 from GitHub cache (~2 seconds for 300MB)
  4. Extracts to ~/.m2
  5. Maven finds all deps already present → skips download

CACHE MISS (pom.xml changed):
  1. New key: "maven-def456" (pom.xml hash changed)
  2. No match → downloads everything fresh
  3. After job: new cache stored under "maven-def456"
  4. Old "maven-abc123" cache remains (until evicted by size limit)
```

---

## Cache Keys: The Most Critical Part

A cache key determines when you get a hit vs a miss. Bad keys = always miss OR always hit stale data.

### Structure of a Good Cache Key

```yaml
key: ${{ runner.os }}-${{ hashFiles('**/pom.xml') }}
```

Breaking this down:
- `runner.os` — separates Linux/Windows/Mac caches (different binary formats)
- `hashFiles('**/pom.xml')` — unique fingerprint of dependency file
- If pom.xml unchanged → same key → cache hit
- If pom.xml changes → new hash → cache miss → fresh download

### Restore Keys: Fallback for Partial Hits

```yaml
- uses: actions/cache@v4
  with:
    path: ~/.m2/repository
    key: ${{ runner.os }}-maven-${{ hashFiles('**/pom.xml') }}
    restore-keys: |
      ${{ runner.os }}-maven-    # ← fallback: use ANY maven cache for this OS
      ${{ runner.os }}-          # ← last resort: use ANY cache for this OS
```

**How restore-keys work:**
```
Exact match:   "linux-maven-abc123" → full cache hit (best)
Partial match: "linux-maven-"       → downloads old cache, updates it (good)
Last resort:   "linux-"             → downloads any linux cache (ok)
No match:      nothing              → cold build (worst)
```

The partial match means Maven only downloads the NEW or changed dependencies, not all 300MB.

---

## Language-Specific Caching Configurations

### Java / Maven

```yaml
- uses: actions/setup-java@v4
  with:
    java-version: '17'
    distribution: temurin
    cache: maven              # built-in maven caching

# What it caches: ~/.m2/repository
# Key: setup-java-${{ runner.os }}-maven-${{ hashFiles('**/pom.xml') }}
# Restores: yes, with partial match fallback

# Manual version (more control):
- uses: actions/cache@v4
  with:
    path: |
      ~/.m2/repository
      !~/.m2/repository/com/mycompany   # exclude your own artifacts (always fresh)
    key: maven-${{ runner.os }}-${{ hashFiles('**/pom.xml', '**/pom.xml') }}
    restore-keys: |
      maven-${{ runner.os }}-
```

### Java / Gradle

```yaml
- uses: actions/setup-java@v4
  with:
    java-version: '17'
    distribution: temurin
    cache: gradle

# What it caches:
#   ~/.gradle/caches        — downloaded dependencies
#   ~/.gradle/wrapper       — gradle wrapper binaries
# Key: based on build.gradle.kts and gradle-wrapper.properties hash
```

### Node.js / npm

```yaml
- uses: actions/setup-node@v4
  with:
    node-version: '20'
    cache: npm

# What it caches: ~/.npm (the npm cache, NOT node_modules)
# Why not node_modules? It contains native binaries — must be rebuilt per OS
# Key: based on package-lock.json hash

# But for speed, you can cache node_modules if you're careful:
- uses: actions/cache@v4
  id: node-modules-cache
  with:
    path: node_modules
    key: node-modules-${{ runner.os }}-${{ hashFiles('package-lock.json') }}

- name: Install dependencies
  if: steps.node-modules-cache.outputs.cache-hit != 'true'
  run: npm ci
# npm ci only runs if cache MISSED — 0 seconds on cache hit
```

### Python / pip

```yaml
- uses: actions/setup-python@v5
  with:
    python-version: '3.11'
    cache: pip

# What it caches: pip's http cache (~/.cache/pip)
# Key: based on requirements.txt / setup.py / pyproject.toml hash

# For venv caching (faster install):
- uses: actions/cache@v4
  id: venv-cache
  with:
    path: .venv
    key: venv-${{ runner.os }}-py3.11-${{ hashFiles('requirements*.txt') }}

- run: |
    if [ "${{ steps.venv-cache.outputs.cache-hit }}" != "true" ]; then
      python -m venv .venv
      .venv/bin/pip install -r requirements.txt
    fi
```

### Go

```yaml
- uses: actions/setup-go@v5
  with:
    go-version: '1.22'
    cache: true               # caches ~/go/pkg/mod and ~/.cache/go-build
    cache-dependency-path: go.sum   # key based on go.sum

# Go build cache is particularly valuable:
# go-build cache stores compiled packages — incremental compilation
# On cache hit: only changed packages recompile
```

---

## Tool Caching: Binary Tools

Helm, kubectl, Terraform, etc. are downloaded on every run without caching:

```yaml
# Manual caching for tools not natively supported
- name: Cache Terraform binary
  uses: actions/cache@v4
  id: terraform-cache
  with:
    path: /usr/local/bin/terraform
    key: terraform-1.7.0-linux

- name: Install Terraform
  if: steps.terraform-cache.outputs.cache-hit != 'true'
  run: |
    wget https://releases.hashicorp.com/terraform/1.7.0/terraform_1.7.0_linux_amd64.zip
    unzip terraform_1.7.0_linux_amd64.zip
    sudo mv terraform /usr/local/bin/
    rm terraform_1.7.0_linux_amd64.zip

# Use managed actions instead when available:
- uses: hashicorp/setup-terraform@v3
  with:
    terraform_version: '1.7.0'    # automatically cached by the action
```

---

## Test Result Caching: Skip Tests When Source Unchanged

This is an advanced technique: skip running tests if the relevant source hasn't changed.

```yaml
- name: Cache test results
  uses: actions/cache@v4
  id: test-cache
  with:
    path: |
      target/surefire-reports/
      .test-results-marker
    key: tests-${{ runner.os }}-${{ hashFiles('src/test/**', 'src/main/**', 'pom.xml') }}

- name: Run tests
  if: steps.test-cache.outputs.cache-hit != 'true'
  run: |
    mvn test -B
    touch .test-results-marker    # marker file shows tests ran successfully

- name: Tests skipped (cache hit)
  if: steps.test-cache.outputs.cache-hit == 'true'
  run: echo "Tests skipped — source unchanged since last run"
```

**When this is safe:** Only when the key includes ALL files that could affect test results: source, tests, AND dependencies (pom.xml).

**When this is NOT safe:** If tests are non-deterministic or depend on external state (time, external APIs). Use with caution.

---

## Cache Invalidation Debugging

When you suspect a cache is stale or not working:

```bash
# List all caches for a repo
gh api /repos/myorg/myapp/actions/caches | \
  jq '.actions_caches[] | {id, key, size_in_bytes: (.size_in_bytes / 1024 / 1024 | floor | tostring + "MB"), last_accessed_at}'

# Delete a specific cache (force fresh download on next run)
gh api --method DELETE /repos/myorg/myapp/actions/caches/<id>

# Delete all caches matching a key prefix
gh api /repos/myorg/myapp/actions/caches | \
  jq '.actions_caches[] | select(.key | startswith("maven-")) | .id' | \
  xargs -I{} gh api --method DELETE /repos/myorg/myapp/actions/caches/{}

# Check if a specific job used cache (look for "Cache restored" in logs)
gh run view <run-id> --log | grep -E "Cache (restored|not found|saved)"
```

---

## Cache Size Management

GitHub Actions cache limit: **10GB per repository**. Oldest caches evicted first.

**Common cache sizes:**
```
Maven full repo:         200-500MB
npm node_modules:        100-300MB
Docker layer cache:      500MB-5GB  ← biggest!
pip packages:            50-200MB
Go module cache:         100-500MB
Gradle cache:            100-400MB
```

**Strategy when approaching 10GB:**
1. Exclude large, rarely-changing caches (use restore-key fallback instead)
2. Use registry cache for Docker layers instead of GitHub Actions cache
3. Split big caches by module/workspace
4. Keep cache keys specific so old entries are evicted by the 10GB LRU policy

```yaml
# Exclude your own published artifacts from Maven cache
# (they change every build and shouldn't be cached)
- uses: actions/cache@v4
  with:
    path: |
      ~/.m2/repository
      !~/.m2/repository/com/mycompany/**    # don't cache your own artifacts
    key: maven-${{ hashFiles('**/pom.xml') }}
```
