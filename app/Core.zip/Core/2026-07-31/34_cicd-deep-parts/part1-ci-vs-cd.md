# Part 1 — CI vs CD: Deep Dive

---

## What Problem Are We Actually Solving?

Imagine 10 developers all working on the same codebase. Each one is making changes to overlapping files. They work for 2 weeks in isolation on their own branches. Then everyone tries to merge on Friday.

```
Developer A (2 weeks of work): changed auth.java, user.java
Developer B (2 weeks of work): changed auth.java, payment.java
Developer C (2 weeks of work): changed auth.java, api.java

Result Friday merge:
  - 3 people changed auth.java differently
  - Nobody knows whose version is right
  - Tests all fail in ways nobody can explain
  - Nobody goes home for the weekend
  → This is "Integration Hell"
```

**CI solves integration hell** by making everyone integrate DAILY (or on every commit), catching conflicts immediately when they're small and fresh in the developer's mind.

---

## CI — Continuous Integration: Full Detail

### The Contract of CI

CI makes a contract with the team:
> "Every push to the shared repository will be automatically validated within minutes. If it breaks anything, the author is notified immediately while the change is fresh in their memory."

### What Happens in CI (Step by Step)

```
1. Developer pushes a commit
        │
        ▼
2. Git webhook fires → CI server receives event
        │
        ▼
3. CI server allocates a CLEAN runner (fresh machine/container)
   Why clean? → No "works on my machine" — same environment every time
        │
        ▼
4. Checkout: clone the exact commit SHA
        │
        ▼
5. Restore cache: pull down Maven/npm dependencies
        │
        ▼
6. Install: any additional tools needed
        │
        ▼
7. Lint: check code style and formatting
        │  ← FAIL HERE = instant feedback, no wasted test time
        ▼
8. Compile / Build: turn source code into runnable artifact
        │  ← FAIL HERE = syntax or compilation errors caught
        ▼
9. Unit tests: run all fast, isolated tests
        │  ← FAIL HERE = logic errors caught
        ▼
10. Integration tests: test services talking to each other (with real DB)
        │  ← FAIL HERE = interface contract violations caught
        ▼
11. Code coverage check: fail if < 80% lines tested
        │
        ▼
12. Static analysis (SonarQube): detect code smells, security hotspots
        │
        ▼
13. Package artifact: JAR, Docker image, npm package
        │
        ▼
14. Publish artifact: push to Artifactory / ECR / npm
        │
        ▼
15. Report: Green ✓ or Red ✗ status on the PR/commit
```

### CI Principles (Why Each Rule Exists)

**Rule 1: Build on every commit, not just merges**
```
Why: A bug found 30 minutes after writing is fixed in 5 minutes.
     A bug found 2 weeks later takes hours and kills context.
```

**Rule 2: The build must be fast (under 10 minutes)**
```
Why: If CI takes 30 minutes, developers stop waiting for it.
     They push, go do other work, merge without checking results.
     Fast CI = developers actually wait = CI provides value.
```

**Rule 3: The build must be deterministic**
```
Why: A build that sometimes fails and sometimes passes ("flaky")
     trains developers to ignore failures.
     Treat flaky tests as P1 bugs.
```

**Rule 4: Fix broken builds immediately — nothing else takes priority**
```
Why: A broken main branch blocks EVERYONE else on the team.
     "Don't leave a broken build overnight" is a core CI discipline.
```

**Rule 5: Never commit directly to main**
```
Why: PRs let CI run BEFORE code hits main.
     Direct commits to main risk breaking the branch everyone works from.
```

---

## CD — Continuous Delivery: Full Detail

### The Gap Between "Works in CI" and "Works in Production"

CI proves the code compiles and unit tests pass. But it doesn't prove:
- The app boots correctly in a real Kubernetes cluster
- The database migration runs without error
- The app can handle real production traffic patterns
- The Docker image isn't rejected by container security policy

CD closes this gap by automatically deploying through progressively more realistic environments.

### CD Environments Chain

```
DEV environment
  ├── Purpose: immediate feedback for developers
  ├── Data: synthetic/fake data, reset daily
  ├── Deploy: automatic on every green CI build
  ├── Tests run: smoke tests, basic sanity
  └── Failure impact: zero — only affects one developer

STAGING environment
  ├── Purpose: pre-production validation
  ├── Data: production-like data (anonymized)
  ├── Deploy: automatic after DEV passes
  ├── Tests run: full E2E, performance, security
  └── Failure impact: low — no real users

PRODUCTION environment
  ├── Purpose: serves real users
  ├── Data: real user data
  ├── Deploy: manual approval (Delivery) OR automatic (Deployment)
  ├── Tests run: smoke tests, canary health checks
  └── Failure impact: high — real users affected
```

### Continuous Delivery vs Continuous Deployment: The Exact Difference

```
CONTINUOUS DELIVERY:
  ┌───────────────────────────────────────────────────┐
  │ CI  →  DEV  →  STAGING  →  [HUMAN CLICKS DEPLOY] │ → PROD
  └───────────────────────────────────────────────────┘
  The pipeline does everything EXCEPT the final prod deploy.
  A human decides WHEN to ship.
  Why: Regulatory compliance, business release windows,
       product marketing coordination, risk management.

CONTINUOUS DEPLOYMENT:
  ┌──────────────────────────────────────────────────────────┐
  │ CI  →  DEV  →  STAGING  →  CANARY  →  [AUTO] PROD 100% │
  └──────────────────────────────────────────────────────────┘
  Everything is automated including final production.
  Why: Teams with high test confidence and
       good canary/rollback automation can ship faster.
```

### When to Use Which

```
Use CONTINUOUS DELIVERY (manual gate) when:
  - Regulated industry (banking, healthcare, government)
  - Product releases must coordinate with marketing
  - Business has specific release windows
  - Team doesn't yet have confidence in automated tests
  - External dependency (partner API version sync)

Use CONTINUOUS DEPLOYMENT (fully automated) when:
  - Strong automated test coverage (>80%)
  - Canary deployments with automatic rollback in place
  - Small, frequent changes (microservices)
  - Team ships many times per day (feature flags for dark launches)
  - SRE team confident in observability and rollback speed
```

---

## The Four States of a Deployment Pipeline

```
State 1: PENDING
  Code pushed, waiting for runner allocation or queued behind other jobs.
  Normal if < 2 minutes. Problem if > 10 minutes (runner shortage).

State 2: RUNNING
  Jobs executing on runners.
  Expected duration: 5-15 minutes for a healthy pipeline.

State 3: SUCCESS (Green)
  All jobs passed. Artifact published. Ready to deploy.
  The team's goal: every commit reaches this state.

State 4: FAILED (Red)
  One or more jobs failed. Artifact NOT published. NOT safe to deploy.
  Team rule: fix immediately. Nothing else is higher priority.
```

---

## The Pipeline as a Production Service

SREs should treat the CI/CD pipeline itself as a production service with its own SLOs:

```
Pipeline SLOs:
  Build success rate:     > 90%    (90% of pushes produce a green build)
  P95 build duration:     < 10 min (95% of builds complete in under 10 minutes)
  Deploy success rate:    > 95%    (95% of deploys reach prod without rollback)
  Pipeline availability:  > 99.5%  (runner/CI platform uptime)
```

When the pipeline is slow or flaky, it's a developer experience incident — it blocks everyone on the team and costs the organization real money in lost productivity.
