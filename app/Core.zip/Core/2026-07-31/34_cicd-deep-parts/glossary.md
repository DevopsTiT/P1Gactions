# CI/CD Deep Dive Glossary — SRE Beginner Reference

All terms across all 8 parts, explained in plain language.

---

## Part 1 Terms — CI vs CD

**Integration Hell**
The painful situation where multiple developers work in isolation for weeks, then try to merge all their changes at once. The conflicts are enormous and mysterious. CI prevents this by integrating changes daily.

**Build (CI)**
The automated process triggered by a code push: checkout → install → compile → test → package. If any step fails, the build is "broken." A broken build is the highest priority to fix — it blocks everyone.

**Green Build / Red Build**
"Green" = all CI checks passed. "Red" = one or more checks failed. Teams aim to keep the main branch always green. A red main branch blocks all other developers from safely merging.

**Deterministic Build**
A build that produces the same result every time for the same inputs. If a build sometimes passes and sometimes fails without code changes, it's non-deterministic ("flaky") — a major reliability problem.

**Continuous Delivery**
Automating everything except the final production deployment, which requires a human click. "The code is always ready to deploy — we decide WHEN."

**Continuous Deployment**
Fully automated pipeline — every green build automatically deploys to production with no human gate. Requires very high test confidence and good rollback automation.

**Manual Gate / Approval**
A human step in the pipeline where a person must click "Approve" before the pipeline continues. Used before production deployments in Continuous Delivery. In GitHub Actions, set with `environment: production`.

**GitHub Environments**
Named deployment targets (dev, staging, production) in GitHub. Each environment can have protection rules: required reviewers, wait timers, branch restrictions. Scopes which secrets are available to which jobs.

---

## Part 2 Terms — Pipeline Structure

**DAG (Directed Acyclic Graph)**
A way to represent pipeline jobs where each job has defined dependencies (directed edges) and there are no circular dependencies (acyclic). Enables maximum parallelism — any job with no unmet dependencies runs immediately.

**`needs:` (GitHub Actions)**
The keyword that creates a dependency between jobs. `needs: [lint, test]` means "don't start this job until both lint and test complete." Forms the edges of the pipeline DAG.

**Stage**
A logical grouping of pipeline jobs. Jobs within a stage run in parallel. Stages run sequentially — stage 2 only starts when all stage 1 jobs pass. Enforces order while maximizing parallelism within each stage.

**Fail-Fast**
The principle of running cheapest, fastest checks first so the pipeline fails early with minimal wasted compute. Lint (10 seconds) before integration tests (15 minutes) is fail-fast design.

**Matrix Strategy**
A GitHub Actions feature that runs the same job multiple times with different parameter values simultaneously. E.g., test on Java 17 AND Java 21 at the same time. Useful for compatibility testing.

**`fail-fast: false` (Matrix)**
By default, if one matrix job fails, GitHub cancels all other matrix jobs. `fail-fast: false` lets all matrix jobs complete even if one fails — useful when you want to see results across all combinations.

**Concurrency Group**
A GitHub Actions feature that identifies "equivalent" pipeline runs for the same branch. Only one run per group at a time. New run cancels the in-progress old run. Prevents 10 queued builds from one developer's rapid commits.

**Job Output**
Data produced by one job that other jobs consume. Passed via `$GITHUB_OUTPUT` file and referenced with `${{ needs.job-name.outputs.variable-name }}`. The only way to share data between jobs (they run on different machines).

**`timeout-minutes`**
Maximum time a job or step can run before GitHub forcibly terminates it. Without timeouts, a hung network call can block a runner for hours. Every job and long-running step should have a timeout.

**Workflow Dispatch**
A GitHub Actions trigger that allows manually running a workflow from the GitHub UI or API. Often configured with input parameters (which environment, which image tag, etc.).

---

## Part 3 Terms — Docker Layer Caching

**Docker Layer**
One instruction in a Dockerfile (`RUN`, `COPY`, `ADD`) produces one layer. Each layer is a content-addressable hash of its inputs. Docker caches each layer independently.

**Cache Invalidation**
When a layer's inputs change, Docker must re-execute that layer and ALL layers after it. This is why order matters: `COPY . .` before `mvn dependency` means any file change invalidates the dep download.

**`COPY pom.xml .` before `COPY src/ .`**
The critical Docker optimization: copy the dependency manifest first, download deps (slow), THEN copy source code. Source changes only invalidate compilation, not dependency download.

**Multi-Stage Build**
A Dockerfile technique using multiple `FROM` statements. Builder stage uses full JDK/tools. Runtime stage starts fresh with only JRE + compiled artifact. Final image is small because it doesn't contain the build tools.

**BuildKit**
The modern Docker build engine. Supports: parallel stage building, better caching, secret injection without leaking to layers, cache export/import. Enabled with `DOCKER_BUILDKIT=1` (default since Docker 23).

**`cache-from` / `cache-to`**
Docker BuildKit parameters that import and export layer caches to/from external storage (GitHub Actions cache or container registry). Necessary for CI where runners are ephemeral.

**`type=gha` (Docker cache)**
Stores Docker build cache in GitHub Actions' cache service. Simple, no extra infrastructure. Limited to 10GB total per repo shared with all other caches.

**`type=registry` (Docker cache)**
Stores Docker build cache as a separate tag in your container registry (e.g., `ghcr.io/myorg/myapp:buildcache`). No size limit, works across CI platforms, faster for large images.

**`mode=max`**
Docker cache export mode that saves ALL intermediate layers, not just the final layer. More cache data stored, but much better cache hit rates for complex multi-stage builds.

**Distroless Image**
A container base image from Google that contains only the runtime (JRE, Python interpreter) and nothing else — no shell, no package manager, no debugging tools. Minimal attack surface, very small. `gcr.io/distroless/java17`.

**Alpine Linux**
An extremely small Linux distribution (5MB) used as a Docker base image. Includes busybox shell for basic debugging. The standard lightweight base image: `eclipse-temurin:17-jre-alpine`.

**`.dockerignore`**
A file that lists paths to exclude from the Docker build context (analogous to `.gitignore`). Without it, `COPY . .` includes `.git/` (huge), `.env` (secrets), `node_modules/` (shouldn't be there), etc.

**`USER` instruction (Dockerfile)**
Sets which user the container process runs as. Default is root (UID 0). Running as root = any exploit has full system access. Best practice: create and use a non-root user (`adduser appuser; USER appuser`).

**`dive`**
A command-line tool for exploring Docker image layers interactively. Shows what files each layer added/removed and flags efficiency issues. `brew install dive`.

---

## Part 4 Terms — Caching Strategies

**Cache Key**
A string that uniquely identifies a cache entry. Built from stable, deterministic inputs: `${{ runner.os }}-maven-${{ hashFiles('**/pom.xml') }}`. If key matches existing cache → hit. If no match → miss.

**`hashFiles()`**
A GitHub Actions function that produces a SHA256 hash of one or more files. If the file changes, the hash changes, the cache key changes, and the old cache is not used. The standard way to key dependency caches.

**Cache Hit**
When a cache lookup finds a matching key and restores the cached files. The job skips the slow download/build step. The goal of caching.

**Cache Miss**
When no matching cache key is found. The job runs the slow step from scratch, then saves the result as a new cache entry. Expected on first run or after dependency changes.

**Restore Keys**
Fallback cache keys tried in order if the primary key doesn't match. `${{ runner.os }}-maven-` matches any Maven cache for this OS, even from a different pom.xml state. Partial hit is better than cold build.

**`actions/cache@v4`**
The official GitHub Actions action for caching arbitrary files between workflow runs. You specify the path to cache and a key. Handles upload/download from GitHub's cache service automatically.

**`actions/setup-java@v4` with `cache: maven`**
The managed Java setup action with built-in caching. Automatically determines the cache path (`~/.m2/repository`) and key (`hashFiles('**/pom.xml')`). Simpler than manual `actions/cache` configuration.

**`mvn dependency:go-offline`**
A Maven command that downloads all declared dependencies to the local repository and verifies nothing needs the internet at runtime. The key step to put BEFORE `COPY src/` in a Dockerfile to maximize layer caching.

**`npm ci`**
Like `npm install` but: uses `package-lock.json` exactly (no updates), fails if lock file is out of sync with `package.json`, and is faster in CI environments. Always use `npm ci` in pipelines, not `npm install`.

**pip cache / `~/.cache/pip`**
Python's pip stores downloaded wheel files here. Caching this directory means pip reuses downloaded packages instead of re-downloading from PyPI. Key based on `requirements.txt` hash.

**Go build cache**
Go stores compiled packages in `~/.cache/go-build`. Incremental compilation: only recompiles packages whose source changed. Caching this makes Go builds 5-10x faster in CI.

**LRU eviction**
"Least Recently Used" — when the cache storage fills up, the oldest-accessed entries are deleted first to make room. GitHub Actions cache evicts entries starting with the least recently used when approaching the 10GB limit.

---

## Part 5 Terms — Deployment Strategies

**Recreate Strategy**
A Kubernetes deployment strategy that kills ALL old pods, then starts new ones. Causes downtime. Only appropriate when old and new versions absolutely cannot run simultaneously.

**Rolling Update**
The Kubernetes default deployment strategy. Replaces pods one-at-a-time: create one new pod, wait for it to be ready, then delete one old pod. No downtime, but both versions run simultaneously during the transition.

**`maxUnavailable`**
Rolling update setting: maximum number of pods that can be unavailable (not ready) at any point during the update. `maxUnavailable: 0` means capacity never drops below the desired replica count.

**`maxSurge`**
Rolling update setting: maximum number of EXTRA pods that can be created above the desired replica count during an update. `maxSurge: 2` means 2 extra pods are created at once, making the update faster.

**Readiness Probe**
A Kubernetes health check that determines if a pod is ready to receive traffic. Kubernetes waits for the readiness probe to pass before routing traffic to a new pod and before proceeding to the next rolling update step.

**Blue/Green Deployment**
Running two complete, identical environments simultaneously. Traffic points to one (blue = current). New version deployed to the other (green). Traffic switched instantly by updating the Service selector. Instant rollback = switch back.

**Service Selector (Kubernetes)**
The label matching rule in a Kubernetes Service that determines which pods receive traffic. In Blue/Green: changing `version: blue` to `version: green` in the selector switches all traffic instantly.

**Canary Deployment**
Sending a small percentage of real traffic (e.g., 10%) to a new version while most traffic stays on the stable version. Observe metrics. Gradually increase percentage. Abort and roll back if metrics degrade.

**Argo Rollouts**
A Kubernetes controller that adds advanced deployment strategies (canary, blue/green with traffic splitting) to Kubernetes. Uses `Rollout` resource instead of `Deployment`. Integrates with service meshes for traffic control.

**AnalysisTemplate (Argo Rollouts)**
A reusable definition of success/failure metrics for automated canary promotion decisions. Queries Prometheus (or other sources) and decides: is the canary healthy enough to proceed?

**Progressive Delivery**
The umbrella practice of releasing changes gradually to subsets of users. Includes canary deployments, feature flags, A/B testing. Reduces blast radius of bad releases.

**Feature Flag**
A configuration switch that enables/disables a feature at runtime without a code deploy. Decouples deployment (all servers get new code) from release (feature turned on for users). Instant rollback by flipping the flag.

**Expand-Contract Migration**
A database migration pattern for zero-downtime schema changes: Phase 1 (expand): add new column alongside old. Phase 2: migrate data, update app to use new column. Phase 3 (contract): remove old column. Allows both app versions to run during rolling update.

**Smoke Test**
A minimal test immediately after deployment that checks the application is basically alive and responding. Not comprehensive — just enough to detect "the app isn't starting" or "the health endpoint returns 500."

**`helm rollback`**
Reverts a Helm release to a previous revision by re-applying the old manifests. Kubernetes then performs a rolling update back to the old version. `--wait` makes the command block until all pods are healthy.

**`kubectl rollout undo`**
Immediately reverts a Kubernetes Deployment to the previous ReplicaSet (stored by Kubernetes). Fastest manual rollback mechanism. Takes effect in seconds.

---

## Part 6 Terms — GitOps / ArgoCD

**GitOps**
A deployment philosophy where Git is the single source of truth for cluster state. All production changes are Git commits. The cluster continuously syncs itself to match Git. No `kubectl apply` from CI pipelines.

**Pull-Based Deployment**
The GitOps model where the cluster agent (ArgoCD) PULLS configuration from Git. Opposite of push-based where CI pushes to the cluster. Pull model means CI doesn't need cluster credentials.

**ArgoCD**
A Kubernetes GitOps controller. Watches one or more Git repositories containing Kubernetes manifests. Automatically applies changes to the cluster when Git changes. Detects and corrects drift.

**Application CR (Custom Resource)**
An ArgoCD Kubernetes object that defines what to sync: which Git repo, which path, which cluster/namespace, and what sync policies to apply. Each Application manages one service's deployment.

**`syncPolicy.automated`**
ArgoCD configuration that enables automatic synchronization without manual `argocd app sync` clicks. `prune: true` deletes removed resources; `selfHeal: true` reverts manual cluster changes.

**Drift**
When the actual cluster state diverges from what Git says it should be. Causes: manual `kubectl edit`, failed partial sync, operator making changes. ArgoCD's `selfHeal` automatically corrects drift.

**`selfHeal: true`**
ArgoCD setting that automatically reverts manual changes to the cluster (e.g., someone does `kubectl scale --replicas=1` but Git says 10 → ArgoCD restores 10 replicas within minutes).

**`prune: true`**
ArgoCD setting that deletes Kubernetes resources that were removed from the Git manifests. Without this, deleted manifests leave orphaned resources in the cluster forever.

**Kustomize**
A Kubernetes configuration management tool. `kustomization.yaml` file lists base resources and overlays (patches). No templating language — uses strategic merge patches. Built into `kubectl`. Great for environment-specific overrides.

**Overlay (Kustomize)**
An environment-specific set of patches applied on top of a base configuration. `overlays/production/` might increase replicas to 10 and update the image tag, while `overlays/dev/` has 1 replica.

**`kustomize edit set image`**
A command that updates the image tag in `kustomization.yaml`. Used by CI pipelines to update the image tag as part of the GitOps deploy flow: CI builds image → updates tag in config repo → ArgoCD syncs.

**Two-Repo Model**
A GitOps pattern using separate repositories for application code and Kubernetes configuration. Code repo: source + CI workflows. Config repo: manifests, image tags. Allows different access controls and clean separation of concerns.

**Sync Wave**
An ArgoCD annotation (`argocd.argoproj.io/sync-wave: "N"`) that controls resource application order. Wave 0 applies first (namespaces, secrets), then wave 1 (deployments), then wave 2 (migrations). Ensures dependencies exist before consumers.

**Sealed Secrets**
A Bitnami tool for storing encrypted secrets in Git. A `SealedSecret` in Git is encrypted with the cluster's public key. The Sealed Secrets controller in the cluster decrypts it and creates a real Kubernetes Secret. Safe to commit to Git.

**External Secrets Operator**
A Kubernetes operator that creates Kubernetes Secrets by fetching values from external secret stores (AWS Secrets Manager, GCP Secret Manager, HashiCorp Vault). The `ExternalSecret` resource in Git references paths in the external store — no actual secret values in Git.

**ArgoCD Project**
A logical grouping of ArgoCD applications with shared access policies. Defines which Git repos are allowed, which clusters can be deployed to, and which Kubernetes resource types are permitted.

---

## Part 7 Terms — Security

**Supply Chain Attack**
An attack that compromises software by targeting the build process, dependencies, or CI/CD pipeline rather than the application itself. Examples: SolarWinds (malware injected during build), Codecov (CI script tampered to steal env vars).

**OIDC (OpenID Connect)**
An identity protocol that lets CI systems (GitHub Actions) prove their identity to cloud providers (AWS, GCP) using signed tokens instead of long-lived secret keys. GitHub generates a JWT; AWS validates it and returns temporary credentials.

**JWT (JSON Web Token)**
A signed, self-contained token that carries claims ("I am workflow X from repo Y on branch Z"). Used in OIDC. The cloud provider validates the signature using GitHub's public key without needing to store any secrets.

**`sts:AssumeRoleWithWebIdentity`**
The AWS API call that exchanges an OIDC JWT for temporary AWS credentials. The IAM trust policy controls which identities (which GitHub repos/branches) are allowed to assume which roles.

**IAM Trust Policy**
An AWS JSON policy on an IAM role that defines WHO can assume that role. In OIDC setup: allows GitHub Actions from a specific repo/branch to assume the role, and no one else.

**Trivy**
An open-source vulnerability scanner (Aqua Security) for container images, filesystems, and Kubernetes configs. Checks against CVE databases. Standard tool for container security in CI pipelines.

**CVE (Common Vulnerabilities and Exposures)**
A standardized identifier for publicly known security vulnerabilities. Format: `CVE-YYYY-NNNNN`. Severity rated by CVSS score: Critical (9-10), High (7-8.9), Medium (4-6.9), Low (0-3.9).

**CVSS Score**
"Common Vulnerability Scoring System" — a 0-10 numeric severity score for CVEs. 9-10 = Critical (drop everything, fix now). 7-8.9 = High (fix this sprint). Based on: is it remotely exploitable? Does an exploit exist? Does it require authentication?

**SBOM (Software Bill of Materials)**
A complete inventory of all components, libraries, dependencies, and their versions in a software artifact. Like a food ingredient label. Required by some regulations. Lets you quickly find which apps are affected when a new CVE is published.

**Cosign**
A tool for signing and verifying container images. Uses OIDC for keyless signing — no private keys to manage. Creates an attestation stored in the registry proving: this image was built from this source by this pipeline at this time.

**Image Provenance**
Metadata that records the chain of custody for a container image: which source commit it was built from, which CI pipeline built it, when, and what inputs were used. Enables verification that the image wasn't tampered with post-build.

**SLSA (Supply-chain Levels for Software Artifacts)**
A security framework (from Google/OpenSSF) that defines four levels of supply chain integrity. Level 1: have a CI pipeline. Level 2: use hosted CI with version control. Level 3: hermetic builds + signed provenance.

**Hermetic Build**
A build that is fully isolated from the internet and external state during execution. All inputs (source, deps) are pinned and fetched before building. The same inputs always produce the same output. Required for SLSA Level 3+.

**SAST (Static Application Security Testing)**
Analyzing source code for security vulnerabilities without running it. Tools: CodeQL (GitHub, free), Checkmarx, SonarQube. Finds: SQL injection patterns, XSS, command injection, hardcoded credentials.

**CodeQL**
GitHub's free SAST tool. Analyzes Java, Python, JavaScript, Go, and other languages for security vulnerabilities and code quality issues. Results appear in the GitHub Security tab as findings with severity and fix suggestions.

**Gitleaks**
A tool that scans git repositories and CI environments for accidentally committed secrets: API keys, passwords, tokens, private keys. Should run as the FIRST job in every pipeline before any build.

**Least Privilege**
The security principle that every component should have only the minimum permissions needed to do its job. Applied to CI: each job's `permissions:` block should only include what that job actually needs.

**Secret Masking**
GitHub Actions automatically replaces the value of any configured secret with `***` in log output. This prevents accidental exposure if a step prints environment variables. Only works for defined secrets — not for secrets loaded dynamically.

**`.trivyignore`**
A file listing CVE IDs that Trivy should ignore. Used for CVEs where there is no fix yet or where the vulnerability is not exploitable in your specific use case. Should include a comment explaining WHY each CVE is ignored.

---

## Part 8 Terms — Metrics / DORA

**DORA Metrics**
Four engineering metrics from the DevOps Research and Assessment program that measure software delivery performance: Deployment Frequency, Lead Time for Changes, Change Failure Rate, and Mean Time to Restore (MTTR).

**Deployment Frequency**
How often you deploy to production. Elite teams deploy multiple times per day. Counterintuitively, higher frequency = lower risk (smaller changes per deploy = easier to rollback and diagnose).

**Lead Time for Changes**
Time from code commit to code running in production. Includes: review wait, CI pipeline, staging validation, deployment. The human waits dominate — automation is rarely the bottleneck.

**Change Failure Rate**
Percentage of production deployments that cause an incident requiring rollback or hotfix. Elite: 0-15%. Measures how often deploying breaks things. High rate = insufficient testing or too-large deployments.

**MTTR (Mean Time to Restore)**
Average time to recover from a production incident. Elite: under 1 hour. CI/CD directly impacts this — a fast deploy pipeline means a hotfix can reach production quickly.

**Flaky Test**
A test that sometimes passes and sometimes fails without any code change. Caused by: timing dependencies, shared state, non-deterministic logic. Flaky tests destroy CI trust — engineers start ignoring red builds.

**Pushgateway (Prometheus)**
A Prometheus component that accepts metrics pushed from short-lived batch jobs (like CI pipelines) that can't be scraped. The pipeline pushes build duration/status; Prometheus scrapes Pushgateway.

**Pipeline SLO**
A reliability target for the CI/CD pipeline itself, treated as a production service. Example: "95% of builds complete in under 10 minutes." When violated, it's a developer experience incident.

**Build Success Rate**
Percentage of pipeline runs that succeed (all jobs pass). Target: >90%. Below 85% means either flaky tests, unstable infrastructure, or developers pushing broken code without local testing.

**`surefire.rerunFailingTestsCount`**
A Maven Surefire plugin option that retries failing tests N times before marking them as failed. If a test fails but passes on retry, it's flagged as potentially flaky. Useful for identifying unstable tests.
