# Part 5 — Deployment Strategies: Deep Dive

---

## Why Deployment Strategy Is an SRE Decision

The deployment strategy determines:
- How much user impact if the new version is bad
- How fast you can roll back
- How much infrastructure you need
- Whether your app must be backward compatible

Getting this wrong means: waking up at 3am to manually fix a broken production deployment that took down 100% of users with no quick rollback path.

---

## Strategy 1: Recreate (Simplest, Most Dangerous)

```
Phase 1: Kill ALL v1 pods
         → Service is DOWN (100% users impacted)

Phase 2: Start ALL v2 pods
         → Service recovers (but what if v2 is broken?)
```

```yaml
spec:
  strategy:
    type: Recreate
```

**When to use:** Only for stateful apps where two versions CANNOT run simultaneously (e.g., exclusive file lock, non-backward-compatible DB schema change). Almost never in production for stateless services.

**Risk:** 100% downtime during deploy. Rollback = another Recreate deploy (more downtime).

---

## Strategy 2: Rolling Update (Kubernetes Default)

Replace old pods gradually. At no point is the service down.

```
Configuration: 5 replicas, maxUnavailable=0, maxSurge=1

Before deploy: [v1-a][v1-b][v1-c][v1-d][v1-e]   → 5 pods, 100% traffic v1

Step 1: Create 1 v2 pod (maxSurge=1)
        [v1-a][v1-b][v1-c][v1-d][v1-e][v2-a]     → 6 pods total

Step 2: v2-a becomes Ready → kill v1-a
        [v1-b][v1-c][v1-d][v1-e][v2-a]           → 5 pods, 1 is v2

Step 3: Create another v2
        [v1-b][v1-c][v1-d][v1-e][v2-a][v2-b]     → 6 pods

Step 4: v2-b ready → kill v1-b
        [v1-c][v1-d][v1-e][v2-a][v2-b]           → 5 pods, 2 are v2

... repeat until ...

Final:  [v2-a][v2-b][v2-c][v2-d][v2-e]           → 5 pods, 100% v2
```

### Rolling Update Configuration Explained

```yaml
spec:
  replicas: 5
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxUnavailable: 0    # Never go below 5 pods serving traffic
                           # Prevents capacity drop during deploy
                           # Set to 1 if you're OK with temporary 20% capacity drop

      maxSurge: 1          # Create at most 1 extra pod during update
                           # Higher = faster deploy but more compute cost
                           # maxSurge: 2 runs 2 updates in parallel

  template:
    spec:
      containers:
        - name: checkout
          readinessProbe:          # CRITICAL: Kubernetes waits for this
            httpGet:               # before sending traffic to new pod
              path: /ready
              port: 8080
            initialDelaySeconds: 10
            periodSeconds: 5
            failureThreshold: 3    # 3 failures = pod NOT ready = rollout pauses
```

**Critical detail:** Kubernetes only proceeds to the next step AFTER the new pod passes its readiness probe. Without a readiness probe, Kubernetes sends traffic to the new pod immediately, even if it's still starting up.

### Rolling Update Limitations

```
Problem 1: API backward compatibility required
  v1 pods and v2 pods serve traffic SIMULTANEOUSLY during rollout.
  If v2 changes a response format → v1 clients break.
  Fix: always version APIs, add fields (don't rename/remove).

Problem 2: Database migrations tricky
  v1 reads column "user_name". v2 renames it to "username".
  During rollout: v1 pods fail (column missing), v2 pods work.
  Fix: expand-contract migration pattern (add new, keep old, then remove old).

Problem 3: Slow rollback
  Rolling back = another rolling update (goes through all N steps again).
  If deploy takes 10 minutes, rollback takes 10 minutes.
  Fix: use Blue/Green or Canary for faster rollback.
```

---

## Strategy 3: Blue/Green Deployment

Two full, identical environments. Traffic switches instantly between them.

```
BLUE environment (current production):
  Service: checkout-blue
  Pods:    [v1-a][v1-b][v1-c][v1-d][v1-e]
  Traffic: 100%

GREEN environment (new version, idle):
  Service: checkout-green
  Pods:    [v2-a][v2-b][v2-c][v2-d][v2-e]
  Traffic: 0%

─── Pre-switch: test green internally ─────────────
  QA team hits: https://checkout-green.internal
  Runs smoke tests: all pass

─── Switch: update load balancer ───────────────────
  kubectl patch service checkout-lb \
    -p '{"spec":{"selector":{"env":"green"}}}'
  
  Traffic now: Blue=0%, Green=100%

─── Post-switch ────────────────────────────────────
  Monitor for 30 minutes.
  
  If good:
    → Delete blue pods (or keep for 24h as rollback option)
  
  If bad (any point after switch):
    kubectl patch service checkout-lb \
      -p '{"spec":{"selector":{"env":"blue"}}}'
    → Back to blue in < 1 second
```

### Blue/Green Implementation in Kubernetes

```yaml
# blue-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: checkout-blue
spec:
  replicas: 5
  selector:
    matchLabels:
      app: checkout
      version: blue
  template:
    metadata:
      labels:
        app: checkout
        version: blue       # ← color label
    spec:
      containers:
        - name: checkout
          image: ghcr.io/myorg/checkout:v1.0.0
```

```yaml
# green-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: checkout-green
spec:
  replicas: 5
  selector:
    matchLabels:
      app: checkout
      version: green
  template:
    metadata:
      labels:
        app: checkout
        version: green      # ← different color label
    spec:
      containers:
        - name: checkout
          image: ghcr.io/myorg/checkout:v2.0.0
```

```yaml
# service.yaml — this is what you switch
apiVersion: v1
kind: Service
metadata:
  name: checkout
spec:
  selector:
    app: checkout
    version: blue          # ← change this to "green" to switch traffic
  ports:
    - port: 80
      targetPort: 8080
```

### Blue/Green Advantages and Costs

```
ADVANTAGES:
  ✓ Instant rollback (< 1 second to switch back)
  ✓ Zero downtime
  ✓ Full testing of new version before any real traffic
  ✓ Can maintain backward-compatible DB state in both environments

COSTS:
  ✗ 2x infrastructure cost during the switch window
  ✗ Need to manage database migrations across two versions
  ✗ Both environments must stay in sync (same DB, same config)
```

---

## Strategy 4: Canary Deployment (Production Best Practice)

Send a small percentage of real production traffic to the new version. Observe. Increment gradually.

```
Start:
  v1 (stable):   ████████████████████████████████████████  100%
  v2 (canary):   (none)

Step 1: 10% canary
  v1 (stable):   ████████████████████████████████████  90%
  v2 (canary):   ████  10%

  → Observe for 5 minutes:
    Error rate v2 = 0.1% (same as v1) ✓
    P99 latency v2 = 140ms (vs v1 = 145ms) ✓
    → PROMOTE

Step 2: 25% canary
  v1 (stable):   ██████████████████████████████  75%
  v2 (canary):   ██████████  25%
  → Observe for 5 minutes → PROMOTE

Step 3: 50%
Step 4: 100% → full cutover

OR at any step:
  Error rate v2 spikes to 5% → ABORT
  v1 (stable):   ████████████████████████████████████████  100%
  v2 (canary):   (terminated)
```

### Why Canary Is Better Than Rolling Update for Prod

```
Rolling Update: ALL users hit new version progressively
Canary:         Only 10% of users hit new version

Rolling update failure scenario:
  Deploy bad v2 with rolling update:
    Step 1: 20% traffic on v2 → some users broken
    Step 2: 40% traffic on v2 → more users broken
    Step 3: 60% traffic on v2 → majority broken
    You realize it's bad at step 3: too late
    Rollback takes 10 more minutes during which users are hurt

Canary failure scenario:
  Deploy bad v2 with canary:
    10% of users on v2 → errors spike
    Immediately abort: route 0% to v2
    90% of users were never affected
    Rollback is instant
```

### Canary with Argo Rollouts (Kubernetes)

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Rollout
metadata:
  name: checkout
spec:
  replicas: 10
  strategy:
    canary:
      # Traffic weight steps
      steps:
        - setWeight: 10          # 10% to canary
        - pause:                 # wait manually OR for analysis
            duration: 5m
        - setWeight: 25
        - pause:
            duration: 5m
        - setWeight: 50
        - pause:
            duration: 10m
        - setWeight: 100

      # Automatic analysis: check metrics before each promote
      analysis:
        templates:
          - templateName: success-rate-check
        startingStep: 1          # start analysis at step 1 (10%)
        args:
          - name: service-name
            value: checkout

      # Traffic management (uses Istio or NGINX ingress)
      trafficRouting:
        istio:
          virtualService:
            name: checkout-vsvc

  selector:
    matchLabels:
      app: checkout
  template:
    metadata:
      labels:
        app: checkout
    spec:
      containers:
        - name: checkout
          image: ghcr.io/myorg/checkout:latest
```

### AnalysisTemplate: Automated Pass/Fail Decision

```yaml
apiVersion: argoproj.io/v1alpha1
kind: AnalysisTemplate
metadata:
  name: success-rate-check
spec:
  args:
    - name: service-name
  metrics:
    # Metric 1: Error rate must be below 1%
    - name: error-rate
      interval: 1m
      count: 5                    # run 5 measurements
      successCondition: result[0] < 0.01   # pass if < 1% errors
      failureLimit: 1             # fail analysis if 1 measurement fails
      provider:
        prometheus:
          address: http://prometheus:9090
          query: |
            sum(rate(http_requests_total{
              service="{{args.service-name}}",
              status=~"5.."
            }[5m]))
            /
            sum(rate(http_requests_total{
              service="{{args.service-name}}"
            }[5m]))

    # Metric 2: P99 latency must be below 500ms
    - name: p99-latency
      interval: 1m
      count: 5
      successCondition: result[0] < 0.5
      failureLimit: 1
      provider:
        prometheus:
          address: http://prometheus:9090
          query: |
            histogram_quantile(0.99,
              sum(rate(request_duration_seconds_bucket{
                service="{{args.service-name}}"
              }[5m])) by (le)
            )
```

**When analysis FAILS:** Argo Rollouts automatically aborts the rollout and reverts to stable version.

---

## Strategy 5: Feature Flags (Deployment Without Release)

Feature flags decouple DEPLOYING code from RELEASING features.

```
DEPLOY: push new code to 100% of servers (no user impact)
RELEASE: turn on the feature for specific user segments

Timeline:
  Day 1: Deploy code with feature behind flag (flag=off → 0% of users see it)
  Day 5: Turn flag on for 1% of users (internal testing)
  Day 7: Turn flag on for 10% of users (limited beta)
  Day 14: Turn flag on for 100% of users (full release)
  Day 14+: Rollback if needed → turn flag off (instant, no deploy needed)
```

**Tools:** LaunchDarkly, Split.io, Unleash (open source), GrowthBook

**Why SREs love this:** You can turn off a bad feature in 10 seconds from a web UI, without a code deploy or on-call escalation.

---

## Post-Deploy Verification: The Most Important Step Nobody Does

Deploying is not done when `helm upgrade` returns successfully. Helm considers a deploy "done" when the pods exist. But pods can be crashlooping, health checks can be failing, or the app can serve 500s.

### Verification Steps After Every Deploy

```bash
# Step 1: Wait for rollout to truly complete
kubectl rollout status deployment/checkout -n production --timeout=5m
# Exit code 0 = all pods healthy
# Exit code 1 = timeout (pods not coming up) → rollback

# Step 2: Check pods are actually running (not CrashLooping)
kubectl get pods -n production -l app=checkout
# All should show STATUS=Running, READY=1/1

# Step 3: Run smoke test against deployed service
SMOKE_URL="https://checkout.prod.internal"
for i in {1..5}; do
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$SMOKE_URL/health")
  echo "Attempt $i: HTTP $STATUS"
  if [ "$STATUS" != "200" ]; then
    echo "SMOKE TEST FAILED — rolling back"
    helm rollback checkout -n production --wait
    exit 1
  fi
  sleep 3
done

# Step 4: Check error rate in Prometheus for 2 minutes post-deploy
ERROR_RATE=$(curl -s "http://prometheus:9090/api/v1/query" \
  --data-urlencode 'query=
    sum(rate(http_requests_total{service="checkout",status=~"5.."}[2m]))
    /
    sum(rate(http_requests_total{service="checkout"}[2m]))
  ' | jq '.data.result[0].value[1]' -r)

if (( $(echo "$ERROR_RATE > 0.01" | bc -l) )); then
  echo "Error rate $ERROR_RATE exceeds 1% — rolling back"
  helm rollback checkout -n production --wait
  exit 1
fi

echo "Deploy verified successfully"
```
