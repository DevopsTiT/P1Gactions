# Part 7 — Security in CI/CD Pipelines: Deep Dive

---

## Why CI/CD Is a High-Value Attack Target

```
Your CI/CD pipeline has:
  - Credentials to your production Kubernetes cluster
  - Access to your container registry
  - Access to your secrets manager
  - The ability to deploy arbitrary code to production

If an attacker compromises your CI/CD pipeline:
  → They can push malicious code to production
  → They can exfiltrate all your secrets
  → They can deploy backdoors to your infrastructure
  → This is called a "Supply Chain Attack"

Real examples:
  - SolarWinds (2020): CI/CD build process compromised, malware in software
  - Codecov (2021): CI script tampered, credentials harvested from CI envs
  - 3CX (2023): compromised upstream dependency in build pipeline
```

---

## Secret Management: The Foundation

### The Problem With Secrets in CI

```
WRONG approaches and why they fail:

1. Hardcoded in workflow file:
   run: docker login -u admin -p SuperSecret123
   Problem: Anyone with repo access sees it. Gets stored in git history.

2. Stored in environment variable (plaintext):
   env:
     DB_PASSWORD: "SuperSecret123"
   Problem: Printed in logs if you echo env. Visible in workflow YAML.

3. Passed as build argument:
   docker build --build-arg DB_PASS=SuperSecret123 .
   Problem: Stored in Docker image history (docker history shows it).

4. Written to a file and committed:
   credentials.json committed to repo
   Problem: Anyone who clones repo gets credentials.
```

### Right Approach: GitHub Secrets + Scoping

```yaml
# GitHub Secrets:
# - Stored encrypted at rest
# - Masked in all log output (printed as ***)
# - Available only to specific environments/branches
# - Never exposed in workflow YAML

- name: Login to registry
  run: |
    echo "${{ secrets.REGISTRY_PASSWORD }}" | \
      docker login ghcr.io \
        -u ${{ secrets.REGISTRY_USERNAME }} \
        --password-stdin
    # --password-stdin prevents password from appearing in process list
```

### Secret Scoping in GitHub

```yaml
# Repository secrets: available to all workflows
# Environment secrets: available only when targeting that environment

# This job can only access production secrets if:
# 1. It's in an environment named "production"
# 2. The user clicked "Approve" on the environment protection rule
jobs:
  deploy-production:
    environment: production          # ← scopes access to production secrets
    steps:
      - run: |
          # ${{ secrets.PROD_KUBECONFIG }} only available here
          # Not available in jobs without environment: production
          echo "${{ secrets.PROD_KUBECONFIG }}" > kubeconfig.yaml
```

---

## OIDC: Keyless Cloud Authentication

Traditional approach has a fundamental problem:
```
Store AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY as GitHub Secrets
Problems:
  - Long-lived credentials: if leaked, attacker has permanent access
  - Rotation is painful (must update everywhere simultaneously)
  - No way to limit which workflow can use them
  - Audit trail shows "CI key" not "which workflow from which repo"
```

OIDC solution:
```
GitHub generates a signed JWT (JSON Web Token) for each workflow run.
The JWT says: "This is workflow 'deploy.yml' from repo 'myorg/checkout',
              running on branch 'main', triggered by 'push'"

AWS IAM Role trusts GitHub's OIDC provider.
CI sends JWT → AWS validates it → AWS returns TEMPORARY credentials.
Credentials expire after 1 hour. No static keys stored anywhere.
```

### OIDC Setup: GitHub → AWS

```yaml
# GitHub Actions workflow
permissions:
  id-token: write      # allows requesting OIDC token
  contents: read

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - name: Configure AWS credentials via OIDC
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: arn:aws:iam::123456789012:role/GitHubActionsRole
          aws-region: ap-northeast-1
          role-session-name: GitHubActions-${{ github.run_id }}
          # NO access key or secret key — GitHub exchanges OIDC token for temp creds
      
      - name: Use AWS (temp credentials active)
        run: aws s3 ls   # works with the temporary credentials
```

```json
# AWS IAM Trust Policy on GitHubActionsRole
{
  "Version": "2012-10-17",
  "Statement": [{
    "Effect": "Allow",
    "Principal": {
      "Federated": "arn:aws:iam::123456789012:oidc-provider/token.actions.githubusercontent.com"
    },
    "Action": "sts:AssumeRoleWithWebIdentity",
    "Condition": {
      "StringEquals": {
        "token.actions.githubusercontent.com:aud": "sts.amazonaws.com"
      },
      "StringLike": {
        // Only allow from this specific repo AND main branch
        "token.actions.githubusercontent.com:sub": 
          "repo:myorg/checkout:ref:refs/heads/main"
      }
    }
  }]
}
```

**What you gain:** No static secrets stored ANYWHERE. Credentials auto-expire. IAM role can be limited to specific repos/branches. CloudTrail shows exactly which workflow run assumed the role.

---

## Container Image Security

### Trivy: Vulnerability Scanning

```yaml
- name: Scan image for vulnerabilities
  uses: aquasecurity/trivy-action@master
  with:
    image-ref: ghcr.io/myorg/checkout:${{ github.sha }}
    format: sarif              # GitHub Security tab format
    output: trivy-results.sarif
    severity: CRITICAL,HIGH    # only fail on serious issues
    exit-code: '1'             # fail the pipeline on CRITICAL or HIGH
    ignore-unfixed: true       # don't fail on vulnerabilities with no fix yet

- name: Upload to GitHub Security tab
  uses: github/codeql-action/upload-sarif@v2
  if: always()                 # upload even if scan found issues
  with:
    sarif_file: trivy-results.sarif
```

### Understanding CVE Severity

```
CRITICAL: Remotely exploitable, public exploit exists
          Action: Fix immediately. Do NOT deploy until fixed.
          Example: Log4Shell (CVE-2021-44228)

HIGH: Likely exploitable, may need specific conditions
     Action: Fix before next release cycle.
     Example: Arbitrary code execution in a dependency

MEDIUM: Limited impact or requires specific conditions
        Action: Fix in normal sprint cycle.

LOW: Minimal impact
     Action: Track and fix when convenient.
     
UNKNOWN: Scanner can't determine severity
         Action: Research individually.
```

### How to Fix CVEs

```bash
# CVE in base image (e.g., alpine has old openssl)
# Fix: update base image to latest patch version
FROM eclipse-temurin:17-jre-alpine@sha256:abc123   # pin to specific digest
# → Rebuild triggers when you update this digest

# CVE in application dependency (e.g., spring-core)
# Fix: update pom.xml to patched version
# Check: https://mvnrepository.com/artifact/org.springframework/spring-core

# CVE with no fix yet
# Fix: accept the risk, document why, suppress it
# In .trivyignore:
CVE-2023-12345   # no fix available, not exploitable in our use case
```

### Image Signing with Cosign

```yaml
- name: Sign image (proves it came from this pipeline)
  env:
    COSIGN_EXPERIMENTAL: '1'   # keyless signing via OIDC
  run: |
    cosign sign --yes \
      --rekor-url=https://rekor.sigstore.dev \
      ghcr.io/myorg/checkout@${{ steps.build.outputs.digest }}
    # Signature links: image digest + workflow URL + GitHub OIDC identity
```

```yaml
# In deployment pipeline: verify before deploying
- name: Verify image signature
  run: |
    cosign verify \
      --certificate-identity-regexp="https://github.com/myorg/checkout/.github/workflows/.*" \
      --certificate-oidc-issuer=https://token.actions.githubusercontent.com \
      ghcr.io/myorg/checkout:${{ needs.build.outputs.image-tag }}
    # If signature is invalid or missing: exits non-zero → pipeline fails
```

---

## Dependency Scanning

```yaml
# Scan dependencies for known CVEs BEFORE building
- name: Scan Maven dependencies
  uses: snyk/actions/maven@master
  continue-on-error: false           # hard fail on issues
  env:
    SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
  with:
    command: test
    args: >
      --severity-threshold=high
      --fail-on=all
      --sarif-file-output=snyk.sarif

# OR using OWASP Dependency Check (open source)
- name: OWASP Dependency Check
  uses: dependency-check/Dependency-Check_Action@main
  with:
    project: 'checkout-service'
    path: '.'
    format: 'SARIF'
    args: >
      --failOnCVSS 7
      --enableRetired
```

---

## SAST: Static Application Security Testing

```yaml
# CodeQL: GitHub's free SAST tool
- name: Initialize CodeQL
  uses: github/codeql-action/init@v2
  with:
    languages: java
    queries: security-and-quality    # include security queries

- name: Build for CodeQL analysis
  run: mvn compile -DskipTests

- name: Run CodeQL analysis
  uses: github/codeql-action/analyze@v2
  with:
    category: "/language:java"
    upload: true                     # upload to GitHub Security tab

# Finds: SQL injection, XSS, path traversal, command injection, etc.
```

---

## Least Privilege for Pipeline Permissions

```yaml
# Set minimal permissions for the ENTIRE workflow
permissions:
  contents: read           # can read repo files
  packages: write          # can push to GitHub Packages (registry)
  security-events: write   # can upload SARIF to Security tab
  id-token: write          # can request OIDC token
  # Everything else: none by default

# Override at job level for more specific scoping
jobs:
  test:
    permissions:
      contents: read       # only needs to read code
      # packages: none (test job doesn't push images)

  build:
    permissions:
      contents: read
      packages: write      # needs to push image
      id-token: write      # needs OIDC for ECR login
```

---

## Secret Scanning: Catch Accidental Commits

```yaml
# Scan for accidentally committed secrets BEFORE any build
- name: Run Gitleaks (secret scanner)
  uses: gitleaks/gitleaks-action@v2
  env:
    GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
  with:
    config-path: .gitleaks.toml    # custom rules

# .gitleaks.toml
[allowlist]
  description = "Global allowlist"
  regexes = [
    '''EXAMPLE_PASSWORD''',        # allow test fixtures
    '''test_secret_value'''
  ]
  paths = [
    '''.*_test.go''',
    '''.*\.test\.java'''
  ]
```

Also enable **GitHub Secret Scanning** at the repository level:
```
Settings → Security → Secret scanning → Enable
```

This automatically scans every push and PR for 200+ credential patterns (AWS keys, Stripe keys, GitHub tokens, etc.).

---

## Supply Chain Security: SLSA Framework

SLSA (Supply-chain Levels for Software Artifacts) is a security framework from Google that defines levels of supply chain integrity.

```
SLSA Level 1: Build process documented (basic)
  → Have a CI pipeline at all

SLSA Level 2: Hosted build service, version controlled
  → Use GitHub Actions (not local builds), source in Git

SLSA Level 3: Hardened build platform
  → Hermetic builds (no internet access during build)
  → Signed provenance (who built this, when, from what source)
  → Retention of build logs

SLSA Level 4: Two-person review, hermetic builds
  → Require PR approvals
  → Reproducible builds
```

### Generating SLSA Provenance

```yaml
- name: Generate SLSA provenance
  uses: slsa-framework/slsa-github-generator/.github/workflows/generator_container_slsa3.yml@v1.9.0
  with:
    image: ghcr.io/myorg/checkout
    digest: ${{ steps.build.outputs.digest }}
    registry-username: ${{ github.actor }}
    registry-password: ${{ secrets.GITHUB_TOKEN }}
```

This creates a signed attestation saying:
```json
{
  "buildType": "https://github.com/slsa-framework/slsa-github-generator",
  "builder": { "id": "https://github.com/slsa-framework/slsa-github-generator" },
  "invocation": {
    "configSource": {
      "uri": "git+https://github.com/myorg/checkout@refs/heads/main",
      "digest": { "sha1": "abc123def456" },
      "entryPoint": ".github/workflows/ci.yml"
    }
  },
  "metadata": {
    "buildStartedOn": "2026-07-31T10:00:00Z",
    "completeness": { "parameters": true, "environment": true, "materials": true }
  }
}
```

Anyone who downloads your image can verify it was built from your exact source commit using your exact workflow — not tampered with post-build.
