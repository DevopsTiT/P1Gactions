# Part 3 — Docker Layer Caching: Deep Dive

---

## Why Docker Builds Are Slow Without Optimization

A typical Java microservice build without optimization:
```
Step 1: FROM eclipse-temurin:17-jdk  →  30 seconds (image pull)
Step 2: COPY . /app                  →  2 seconds
Step 3: RUN mvn package              →  4 minutes (download 300MB of deps + compile)
Step 4: EXPOSE 8080                  →  instant
Step 5: CMD java -jar...             →  instant

TOTAL: ~4.5 minutes per build
Every single commit = 4.5 minutes
10 developers × 5 commits/day = 225 minutes of build time/day
```

With proper caching, Step 3 drops from 4 minutes to 15 seconds on repeat builds.

---

## How Docker Layer Caching Works

Docker builds images in layers. Each instruction in a Dockerfile (`FROM`, `COPY`, `RUN`) creates one layer. Docker stores each layer as a content-addressable hash.

```
Dockerfile:
  FROM java:17         → Layer A  (hash: abc123)
  COPY pom.xml .       → Layer B  (hash: def456)  depends on A
  RUN mvn dependency   → Layer C  (hash: ghi789)  depends on B
  COPY src/ .          → Layer D  (hash: jkl012)  depends on C
  RUN mvn package      → Layer E  (hash: mno345)  depends on D
```

**Cache invalidation rule:** If a layer's inputs change, that layer AND ALL LAYERS AFTER IT must be re-executed.

```
Change: developer edits src/main/java/App.java

Layer A: FROM java:17         → CACHED (unchanged)
Layer B: COPY pom.xml .       → CACHED (pom.xml unchanged)
Layer C: RUN mvn dependency   → CACHED (pom.xml unchanged = same deps)
Layer D: COPY src/ .          → CACHE MISS (src changed!)
Layer E: RUN mvn package      → RE-RUN (depends on D which changed)

Result: Only recompile, no re-download of dependencies
Build time: 15 seconds instead of 4.5 minutes
```

---

## The Golden Rule of Dockerfile Ordering

```
Put the things that change LEAST at the TOP.
Put the things that change MOST at the BOTTOM.
```

**Change frequency ranking (slowest-changing first):**
1. Base image (FROM) — almost never
2. System packages (apt-get install) — rarely
3. Dependency manifests (pom.xml, package.json) — when adding deps
4. Config files — occasionally
5. Source code — EVERY COMMIT

---

## Bad vs Good Dockerfile: Side-by-Side

### Bad Dockerfile

```dockerfile
FROM eclipse-temurin:17-jdk-alpine

WORKDIR /app

# ← PROBLEM: copies EVERYTHING including source code
COPY . .

# ← PROBLEM: runs AFTER the COPY, so any file change
#   invalidates this layer → re-downloads ALL 300MB of deps
RUN mvn dependency:resolve

RUN mvn package -DskipTests

EXPOSE 8080
CMD ["java", "-jar", "target/app.jar"]
```

```
Effect:
  Developer changes App.java →
  COPY . . layer invalidated →
  mvn dependency:resolve re-runs (300MB download, 3 min) →
  mvn package re-runs (compile, 1 min)
  Total: 4+ minutes every commit
```

### Good Dockerfile

```dockerfile
FROM eclipse-temurin:17-jdk-alpine AS builder

WORKDIR /app

# ─── Step 1: Copy ONLY the dependency manifest ───────────
# This layer only invalidates when pom.xml changes
COPY pom.xml .
COPY .mvn/ .mvn/        # Maven wrapper config
COPY mvnw .             # Maven wrapper script

# ─── Step 2: Download all dependencies ───────────────────
# This layer ONLY re-runs when pom.xml changes
# For 99% of commits (source code changes only), this is CACHED
RUN ./mvnw dependency:go-offline -B

# ─── Step 3: Copy source code ────────────────────────────
# This layer invalidates on EVERY source change
# But that's fine — it's just a file copy (instant)
COPY src/ src/

# ─── Step 4: Build ───────────────────────────────────────
# Only compilation re-runs, not dependency download
RUN ./mvnw package -DskipTests -B

# ─── Runtime stage: tiny, secure image ───────────────────
FROM eclipse-temurin:17-jre-alpine AS runtime

# Security: run as non-root user
RUN addgroup -S appgroup && adduser -S appuser -G appgroup

WORKDIR /app

# Copy ONLY the built artifact — no source code, no build tools
COPY --from=builder /app/target/*.jar app.jar

USER appuser
EXPOSE 8080
ENTRYPOINT ["java", \
  "-XX:+UseContainerSupport", \
  "-XX:MaxRAMPercentage=75.0", \
  "-jar", "app.jar"]
```

```
Effect with good Dockerfile:
  Developer changes App.java →
  COPY pom.xml → CACHED
  mvn dependency:go-offline → CACHED (pom.xml unchanged!)
  COPY src/ → invalidated (source changed)
  mvn package → re-runs compile only (15 sec)
  Total: 15-30 seconds per commit
```

---

## Multi-Stage Builds: Why and How

### The Problem With Single-Stage Builds

```
Single stage includes in final image:
  - JDK (full compiler toolkit): 400MB
  - Maven binary: 50MB
  - All test dependencies: 100MB
  - Source code: 10MB
  - .git folder: varies
  - Build intermediates: 50MB
  
  Total image: ~600MB

Problems:
  1. 600MB image takes 3 minutes to pull on deploy
  2. Full JDK has more CVEs than JRE
  3. Source code in production image = IP risk
  4. Maven in image = unused attack surface
```

### Multi-Stage Build Solution

```dockerfile
# ── STAGE 1: Builder ─────────────────────────────────────
# Large image with full build tools
FROM eclipse-temurin:17-jdk-alpine AS builder
# ... (all the build steps from above) ...
RUN ./mvnw package -DskipTests -B

# ── STAGE 2: Runtime ─────────────────────────────────────
# Fresh, minimal image — starts empty
FROM eclipse-temurin:17-jre-alpine AS runtime
# Copy ONLY the jar from the builder stage
COPY --from=builder /app/target/myapp.jar app.jar
# Nothing else from builder makes it in
ENTRYPOINT ["java", "-jar", "app.jar"]
```

```
Final image contains:
  - JRE (runtime only, no compiler): 80MB
  - app.jar: 15MB
  
  Total image: ~95MB  (vs 600MB single-stage)
  
  6x smaller = 6x faster pull = 6x faster deploy
  JRE has far fewer CVEs than full JDK
```

### Three-Stage Build (Testing Included)

```dockerfile
FROM eclipse-temurin:17-jdk-alpine AS dependencies
WORKDIR /app
COPY pom.xml mvnw .
COPY .mvn/ .mvn/
RUN ./mvnw dependency:go-offline -B

FROM dependencies AS test
COPY src/ src/
RUN ./mvnw test -B         # run tests in Docker build

FROM dependencies AS builder
COPY src/ src/
RUN ./mvnw package -DskipTests -B

FROM eclipse-temurin:17-jre-alpine AS runtime
COPY --from=builder /app/target/*.jar app.jar
ENTRYPOINT ["java", "-jar", "app.jar"]
```

You can now run just the test stage: `docker build --target test .`

---

## Docker Layer Cache in CI: The Cache Export Problem

Local builds use the local Docker cache. CI runners are ephemeral — they start fresh every time. Without external cache storage, CI never gets cache hits.

### Solution 1: GitHub Actions Cache (Easiest)

```yaml
- uses: docker/build-push-action@v5
  with:
    context: .
    push: true
    tags: ghcr.io/myorg/myapp:latest
    cache-from: type=gha          # read from GitHub Actions cache
    cache-to: type=gha,mode=max   # write to GitHub Actions cache
                                  # mode=max = cache intermediate layers too
```

**How it works:** BuildKit exports each layer as a blob to GitHub's cache storage. On next run, it downloads only the layers that changed.

**Limitation:** GitHub Actions cache has a 10GB limit per repo. Oldest entries are evicted first.

### Solution 2: Registry Cache (Better for Teams)

Store cache directly in the container registry (alongside the actual image):

```yaml
- uses: docker/build-push-action@v5
  with:
    cache-from: type=registry,ref=ghcr.io/myorg/myapp:buildcache
    cache-to: type=registry,ref=ghcr.io/myorg/myapp:buildcache,mode=max
```

**Advantages:** No size limit (or registry's own limit), works across different CI platforms, faster for large images.

### Solution 3: Inline Cache (Simplest, Less Efficient)

```yaml
- uses: docker/build-push-action@v5
  with:
    cache-from: ghcr.io/myorg/myapp:latest  # use previous release as cache source
    build-args: |
      BUILDKIT_INLINE_CACHE=1
```

Uses the previously pushed image as a cache source. Simple but only caches final layers, not intermediate build stages.

---

## BuildKit Advanced Features

Enable BuildKit with `DOCKER_BUILDKIT=1` (default in Docker 23+).

### Parallel Stage Building

```dockerfile
FROM base AS stage-a
RUN long-task-a

FROM base AS stage-b
RUN long-task-b

FROM stage-a AS final
COPY --from=stage-b /output /output
```

Without BuildKit: stage-a, then stage-b (sequential)
With BuildKit: stage-a AND stage-b simultaneously (parallel)

### Secret Injection (No Secret in Layers)

```dockerfile
# Mount a secret during build — it NEVER becomes part of a layer
RUN --mount=type=secret,id=npmrc,target=/root/.npmrc \
    npm install
```

```yaml
# In CI pipeline:
- run: |
    echo "${{ secrets.NPMRC }}" > /tmp/.npmrc
    docker buildx build \
      --secret id=npmrc,src=/tmp/.npmrc \
      -t myapp:latest .
```

### SSH Agent Forwarding (For Private Git Repos)

```dockerfile
RUN --mount=type=ssh \
    git clone git@github.com:myorg/private-lib.git
```

No SSH key baked into the image — the key exists only during the build step.

---

## Image Security: What Goes Into Your Image Matters

### .dockerignore: Prevent Accidental Inclusions

```
# .dockerignore
.git/              # git history — huge and not needed
.github/           # CI workflows — not needed in container
target/            # build outputs — will be rebuilt
*.md               # documentation
.env               # NEVER include .env files!
.env.local
secrets/
*.key
*.pem
node_modules/      # will be rebuilt inside container
coverage/          # test reports
logs/
```

Without `.dockerignore`, `COPY . .` copies your `.env` file, `.git` folder (hundreds of MB), and test artifacts into the image. This is a security risk and a size problem.

### Checking Image for Security Issues

```bash
# Scan for CVEs
trivy image myapp:latest

# Check what files are in each layer (look for accidental secrets)
docker history myapp:latest
dive myapp:latest    # interactive layer explorer (brew install dive)

# Check for running as root
docker inspect myapp:latest | jq '.[0].Config.User'
# Empty = running as root = bad
```
