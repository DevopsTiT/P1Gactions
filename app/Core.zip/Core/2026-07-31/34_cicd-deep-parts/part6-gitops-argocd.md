# Part 6 — GitOps with ArgoCD: Deep Dive

---

## The Problem GitOps Solves

### Traditional "Push" CD Pipeline

```
CI Pipeline (push model):
  1. Code merged to main
  2. Pipeline runs tests
  3. Pipeline builds Docker image
  4. Pipeline runs: kubectl apply -f k8s/ OR helm upgrade
  5. Cluster is updated

Problems:
  ✗ Pipeline needs cluster credentials (kubeconfig stored as CI secret)
  ✗ No audit trail: who ran which pipeline step that changed prod?
  ✗ If someone manually changes a Deployment (kubectl edit), pipeline doesn't know
  ✗ Drift: cluster state diverges from what's in Git
  ✗ Multiple pipelines for multiple clusters = credential sprawl
  ✗ Rollback = re-run old pipeline or manual kubectl
```

### GitOps "Pull" Model

```
GitOps:
  1. Pipeline updates Git (changes image tag in kustomization.yaml)
  2. ArgoCD (running IN the cluster) detects the Git change
  3. ArgoCD pulls the new manifests and applies them
  4. Cluster continuously reconciles to match Git

Benefits:
  ✓ Cluster pulls from Git — no inbound credentials needed in CI
  ✓ Every prod change IS a Git commit (full audit trail with author)
  ✓ Manual changes are automatically reverted (self-healing)
  ✓ Rollback = `git revert` + ArgoCD syncs (git history is the rollback mechanism)
  ✓ Multi-cluster from one Git repo
  ✓ PR review for production changes
```

---

## ArgoCD Architecture

```
GitHub Repo (k8s-configs)
      │
      │  ArgoCD polls every 3 minutes
      │  OR receives webhook on push
      ▼
┌──────────────────────────────────┐
│         ArgoCD (in cluster)      │
│                                  │
│  ┌────────────────┐              │
│  │ Application CR │ ← defines:   │
│  │ - source repo  │   what repo  │
│  │ - target path  │   what path  │
│  │ - destination  │   which cluster/ns │
│  └────────────────┘              │
│           │                      │
│           ▼                      │
│  ┌────────────────┐              │
│  │ Diff Engine    │ compares:    │
│  │ Desired (Git)  │   Git state  │
│  │   vs           │   vs         │
│  │ Actual (live)  │   cluster    │
│  └────────────────┘              │
│           │                      │
│           ▼ if diff detected     │
│  ┌────────────────┐              │
│  │ Sync Engine    │ applies:     │
│  │ kubectl apply  │   manifests  │
│  └────────────────┘              │
└──────────────────────────────────┘
```

---

## Repository Structure for GitOps

Two-repo model (recommended):

```
REPO 1: application-code (github.com/myorg/checkout)
  src/
  Dockerfile
  .github/workflows/ci.yml       ← CI lives here
  
  CI does:
    - build image
    - push to registry
    - update image tag in REPO 2

REPO 2: k8s-configs (github.com/myorg/k8s-configs)
  apps/
    checkout/
      base/
        deployment.yaml
        service.yaml
        kustomization.yaml
      overlays/
        dev/
          kustomization.yaml     ← image tag for dev
          patch-replicas.yaml    ← 1 replica in dev
        staging/
          kustomization.yaml
          patch-replicas.yaml    ← 3 replicas in staging
        production/
          kustomization.yaml     ← image tag updated by CI
          patch-replicas.yaml    ← 10 replicas in prod
  
  ArgoCD watches:
    apps/checkout/overlays/production/  → production cluster
    apps/checkout/overlays/staging/     → staging cluster
```

**Why separate repos?**
- Separation of concerns: code history vs deploy history
- Different access controls: all devs push to code repo, only CI pushes to config repo
- Config repo has clean, readable history of every production change

---

## Kustomize: How Environment Differences Work

```yaml
# apps/checkout/base/deployment.yaml (shared base)
apiVersion: apps/v1
kind: Deployment
metadata:
  name: checkout
spec:
  replicas: 1              # overridden per env
  template:
    spec:
      containers:
        - name: checkout
          image: ghcr.io/myorg/checkout  # tag added per env
          resources:
            requests:
              memory: "256Mi"
              cpu: "100m"
```

```yaml
# apps/checkout/base/kustomization.yaml
resources:
  - deployment.yaml
  - service.yaml
```

```yaml
# apps/checkout/overlays/production/kustomization.yaml
bases:
  - ../../base

replicas:
  - name: checkout
    count: 10              # override replicas for prod

images:
  - name: ghcr.io/myorg/checkout
    newTag: sha-abc123     # ← CI pipeline updates THIS line

patchesStrategicMerge:
  - patch-resources.yaml  # override resource limits for prod
```

```yaml
# apps/checkout/overlays/production/patch-resources.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: checkout
spec:
  template:
    spec:
      containers:
        - name: checkout
          resources:
            requests:
              memory: "512Mi"
              cpu: "500m"
            limits:
              memory: "1Gi"
              cpu: "2000m"
```

---

## ArgoCD Application: Every Field Explained

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: checkout-production          # ArgoCD application name
  namespace: argocd                  # MUST be in argocd namespace
  
  finalizers:
    - resources-finalizer.argocd.io  # delete all managed resources when app deleted
                                     # remove this if you want to delete the ArgoCD app
                                     # but keep the Kubernetes resources

spec:
  project: production                # ArgoCD project (for RBAC and policies)

  source:
    repoURL: https://github.com/myorg/k8s-configs
    targetRevision: main             # branch, tag, or commit SHA to track
    path: apps/checkout/overlays/production   # path within repo

    # Optional: if using Helm chart instead of kustomize
    # helm:
    #   valueFiles:
    #     - values-production.yaml
    #   parameters:
    #     - name: replicaCount
    #       value: "10"

  destination:
    server: https://kubernetes.default.svc   # in-cluster reference
    # OR for remote cluster:
    # server: https://my-prod-cluster.example.com
    namespace: production

  syncPolicy:
    automated:
      prune: true         # delete k8s resources that were removed from Git
                          # WITHOUT this: removed resources stay in cluster forever
      selfHeal: true      # revert manual changes (kubectl edit, kubectl scale)
                          # This is the "drift prevention" feature
      allowEmpty: false   # prevent syncing an empty app (safety)

    syncOptions:
      - CreateNamespace=true           # create namespace if it doesn't exist
      - PrunePropagationPolicy=foreground  # wait for pods to terminate before pruning
      - ApplyOutOfSyncOnly=true        # only apply resources that differ (faster)
      - ServerSideApply=true           # use server-side apply (better conflict handling)

    retry:
      limit: 3            # retry failed sync 3 times
      backoff:
        duration: 5s      # wait 5 sec before first retry
        factor: 2         # double wait time each retry: 5s, 10s, 20s
        maxDuration: 3m   # max wait between retries
```

---

## The CI Pipeline's Role in GitOps

CI does NOT deploy. CI updates Git. ArgoCD deploys.

```yaml
# .github/workflows/ci.yml
- name: Update image tag in config repo
  env:
    GIT_TOKEN: ${{ secrets.CONFIG_REPO_PAT }}
  run: |
    # Clone config repo
    git clone https://x-access-token:${GIT_TOKEN}@github.com/myorg/k8s-configs.git
    cd k8s-configs

    # Update the image tag using kustomize
    cd apps/checkout/overlays/production
    kustomize edit set image \
      ghcr.io/myorg/checkout=ghcr.io/myorg/checkout:sha-${{ github.sha }}

    # Commit and push
    git config user.email "ci@myorg.com"
    git config user.name "CI Pipeline [bot]"
    git add kustomization.yaml
    git commit -m "chore(checkout): deploy sha-${{ github.sha }}

    Triggered by: ${{ github.actor }}
    Commit: ${{ github.event.head_commit.message }}"
    
    git push

    echo "Config repo updated — ArgoCD will sync within 3 minutes"
    echo "Manual sync: argocd app sync checkout-production"
```

---

## ArgoCD Sync Waves: Ordering Resources

Some resources must exist before others. For example: namespace before deployment, ConfigMap before pod.

```yaml
# Apply ConfigMap BEFORE Deployment
apiVersion: v1
kind: ConfigMap
metadata:
  name: checkout-config
  annotations:
    argocd.argoproj.io/sync-wave: "0"    # wave 0 = first
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: checkout
  annotations:
    argocd.argoproj.io/sync-wave: "1"    # wave 1 = after wave 0 completes
---
apiVersion: batch/v1
kind: Job
metadata:
  name: db-migration
  annotations:
    argocd.argoproj.io/sync-wave: "2"    # wave 2 = after deployment is healthy
```

**Wave order:**
```
Wave 0: Namespace, RBAC, Secrets, ConfigMaps
Wave 1: Deployments, StatefulSets, Services
Wave 2: Jobs (migrations, seed data)
Wave 3: Ingress, HorizontalPodAutoscaler
```

---

## ArgoCD RBAC: Who Can Do What

```yaml
# argocd-rbac-cm.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: argocd-rbac-cm
  namespace: argocd
data:
  policy.csv: |
    # Developers can view all, sync only dev/staging
    p, role:developer, applications, get, */*, allow
    p, role:developer, applications, sync, dev/*, allow
    p, role:developer, applications, sync, staging/*, allow
    p, role:developer, applications, sync, production/*, deny
    
    # SREs can do everything
    p, role:sre, applications, *, */*, allow
    p, role:sre, clusters, *, *, allow
    
    # CI service account can sync only
    p, role:ci, applications, sync, */*, allow
    
    # Bind groups to roles
    g, myorg:developers, role:developer
    g, myorg:sre, role:sre
    
  policy.default: role:readonly
```

---

## Handling Secrets in GitOps (The Hard Part)

You cannot put secrets directly in Git. But ArgoCD syncs Git. How do you manage secrets?

### Solution 1: Sealed Secrets (Bitnami)

```bash
# Encrypt secret with cluster's public key → safe to store in Git
kubeseal --format yaml < secret.yaml > sealed-secret.yaml
# sealed-secret.yaml is encrypted → commit to Git
# Sealed Secrets controller in cluster decrypts it → creates real Secret
```

### Solution 2: External Secrets Operator

```yaml
# ExternalSecret fetches from AWS Secrets Manager / Vault / GCP SM
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: checkout-db-password
spec:
  refreshInterval: 1h
  secretStoreRef:
    name: aws-secrets-manager
    kind: SecretStore
  target:
    name: checkout-db-password     # creates this Kubernetes Secret
  data:
    - secretKey: password           # key in k8s secret
      remoteRef:
        key: production/checkout/db-password  # path in AWS SM
```

### Solution 3: ArgoCD Vault Plugin

```yaml
# Use placeholder syntax in manifests
apiVersion: v1
kind: Secret
metadata:
  name: db-credentials
stringData:
  password: <path:secret/data/checkout/db#password>
  # ArgoCD Vault Plugin replaces this at sync time
```

---

## Drift Detection and Self-Healing

Without `selfHeal: true`, someone can do `kubectl scale deployment checkout --replicas=1` and it persists until next sync. With `selfHeal: true`, ArgoCD reverts it within 3 minutes.

```
Drift scenario WITHOUT selfHeal:
  Git says: replicas: 10
  10:00 - System healthy, 10 pods
  10:05 - SRE does: kubectl scale deployment checkout --replicas=1 (debug)
  10:06 - Service degraded: only 1 pod serving traffic
  10:10 - SRE forgets to scale back up
  11:00 - Incident: traffic spike, 1 pod overwhelmed
  Root cause: manual change not reverted

Drift scenario WITH selfHeal:
  10:05 - SRE scales to 1
  10:08 - ArgoCD detects OutOfSync (Git=10, Actual=1)
  10:08 - ArgoCD applies: replicas=10
  10:09 - Back to normal automatically
  10:09 - ArgoCD sends Slack notification: "Drift detected and corrected"
```
