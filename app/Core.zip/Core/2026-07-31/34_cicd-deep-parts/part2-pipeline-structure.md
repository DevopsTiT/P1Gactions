# Part 2 — Pipeline Structure: Stages, Jobs, and DAGs

---

## The Fundamental Problem: Speed vs Correctness

Every check you add to a pipeline makes it MORE correct but SLOWER. A pipeline that takes 45 minutes gives developers no feedback. A pipeline that takes 3 minutes that skips security checks ships vulnerabilities.

**The art of pipeline design:** ordering and parallelizing checks so you get maximum correctness at minimum wall-clock time.

---

## Stages: Enforced Sequential Checkpoints

A **stage** is a group of jobs that all must complete before the next stage begins.

```
Why stages exist:
  - No point building a Docker image if tests fail
  - No point deploying if security scan finds a CRITICAL CVE
  - Stages enforce "don't waste expensive work if cheap work fails"
```

### Stage Ordering Principle: Cheapest First

```
WRONG order (wastes money and time):
  Stage 1: Integration tests   (15 min, needs DB, expensive)
  Stage 2: Docker build        (5 min)
  Stage 3: Lint                (10 sec, trivial)

  If lint fails: you wasted 20 minutes of compute before finding out

CORRECT order (fail fast):
  Stage 1: Lint + Unit tests   (2 min, fast, no infrastructure)
  Stage 2: Build               (3 min, only if stage 1 passes)
  Stage 3: Integration tests   (10 min, only if build succeeds)
  Stage 4: Security scan       (5 min)
  Stage 5: Deploy              (2 min, only if everything passes)

  If lint fails: notified in 30 seconds, nothing else ran
```

---

## Jobs: The Parallel Workhorses

Jobs within the SAME stage run in parallel (assuming enough runners).

```
Stage 1 — runs ALL of these simultaneously:
  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐
  │    lint     │  │ unit-tests  │  │ sec-analysis│
  │  (10 sec)   │  │  (2 min)    │  │  (1 min)    │
  └─────────────┘  └─────────────┘  └─────────────┘
  
  Wall-clock time = max(10s, 2min, 1min) = 2 minutes
  Without parallelism = 10s + 2min + 1min = 3.2 minutes
  
  (Small gain here, massive gain with large test suites)
```

### The `needs:` Keyword Creates a Dependency Graph

```yaml
jobs:
  lint:          # no needs → starts immediately
  unit-test:     # no needs → starts immediately (parallel with lint)
  build:
    needs: [lint, unit-test]     # waits for BOTH
  security-scan:
    needs: build                 # waits for build only
  integration-test:
    needs: build                 # waits for build only (parallel with security-scan)
  deploy-staging:
    needs: [security-scan, integration-test]   # waits for BOTH
```

This creates a **DAG** (Directed Acyclic Graph):

```
push
 │
 ├──► lint ──────────────────────┐
 │                               ├──► build ──► security-scan ──────────┐
 └──► unit-test ─────────────────┘         │                            ├──► deploy-staging
                                           └──► integration-test ───────┘
```

**Total wall-clock time** = longest path through the graph, NOT the sum of all jobs.
- lint: 30s
- unit-test: 2m  (lint finishes waiting)
- build: 3m
- security-scan: 5m  ─┐  (run in parallel)
- integration-test: 10m ─┘
- deploy-staging: 2m

**Wall-clock total = 30s + 2m + 3m + 10m + 2m = 17.5 minutes**
(security-scan runs DURING integration-test, saving 5 minutes)

---

## Fail-Fast in Detail

### The Three Tiers of Checks

```
TIER 1 — SYNTAX / STYLE (seconds, free)
  Lint, format check, compile check
  Cost if skipped: syntax errors reach later expensive stages
  Run on: every push, every PR
  Block merge: YES

TIER 2 — LOGIC (minutes, cheap compute)
  Unit tests, component tests
  Cost if skipped: logic bugs reach integration tests or worse, prod
  Run on: every push, every PR
  Block merge: YES

TIER 3 — SYSTEM (many minutes, expensive infra)
  Integration tests, E2E tests, performance tests, security scan
  Cost if skipped: systemic bugs reach production
  Run on: push to main, release tags
  Block merge: YES for integration tests, WARNING for performance
```

### Only Run Expensive Jobs When Needed

```yaml
# Only run integration tests on push to main, not every PR
integration-test:
  if: github.ref == 'refs/heads/main' || startsWith(github.ref, 'refs/tags/')
  needs: build
  runs-on: ubuntu-latest
  steps:
    - run: mvn verify -Pintegration-tests

# Only run security scan on PRs targeting main
security-scan:
  if: github.event_name == 'pull_request' && github.base_ref == 'main'
```

---

## Concurrency Control: Stop Wasting Runners

Without concurrency control:
```
10:00 - Developer pushes commit #1 → pipeline starts
10:01 - Developer pushes commit #2 → another pipeline starts
10:02 - Developer pushes commit #3 → another pipeline starts
...
Result: 10 pipelines running simultaneously for the SAME branch
        The first 9 are now pointless — only the latest matters
        Wastes runner minutes, queues other team's builds
```

With concurrency control:
```yaml
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true    # cancel older run when new one starts
```

```
10:00 - Commit #1 → pipeline starts (run A)
10:01 - Commit #2 → run A CANCELLED, run B starts
10:02 - Commit #3 → run B CANCELLED, run C starts
Result: Only the latest commit is being tested at any time
```

**Exception:** Don't cancel production deployments in progress. Use `cancel-in-progress: false` for deploy jobs.

---

## Job Outputs: Passing Data Between Jobs

Jobs run on different machines. To pass data between them, use outputs:

```yaml
jobs:
  build:
    runs-on: ubuntu-latest
    outputs:
      image-tag: ${{ steps.set-tag.outputs.tag }}      # expose as output
      image-digest: ${{ steps.docker-push.outputs.digest }}
    steps:
      - id: set-tag
        run: echo "tag=sha-${{ github.sha }}" >> $GITHUB_OUTPUT

  deploy:
    needs: build
    runs-on: ubuntu-latest
    steps:
      - run: |
          # Consume the output from the build job
          echo "Deploying image: ${{ needs.build.outputs.image-tag }}"
          helm upgrade --install myapp ./charts \
            --set image.tag=${{ needs.build.outputs.image-tag }}
```

---

## Matrix Strategy: Test Across Dimensions

Test your code against multiple Java versions, OSes, or configurations simultaneously:

```yaml
unit-test:
  strategy:
    matrix:
      java-version: [17, 21]
      os: [ubuntu-latest, windows-latest]
    fail-fast: false       # don't cancel other matrix jobs if one fails
    max-parallel: 4        # run at most 4 jobs simultaneously
  runs-on: ${{ matrix.os }}
  steps:
    - uses: actions/setup-java@v4
      with:
        java-version: ${{ matrix.java-version }}
    - run: mvn test

# This creates 4 jobs (2 java versions × 2 OSes), all run in parallel:
# java-17 + ubuntu
# java-17 + windows
# java-21 + ubuntu
# java-21 + windows
```

---

## Workflow Dispatch: Manual Trigger with Parameters

Sometimes you need a manual pipeline trigger — for hotfixes, special deployments, or testing:

```yaml
on:
  workflow_dispatch:
    inputs:
      environment:
        description: 'Target environment'
        required: true
        type: choice
        options: [staging, production]
        default: staging
      image-tag:
        description: 'Docker image tag to deploy'
        required: true
        type: string
      skip-tests:
        description: 'Skip integration tests (emergency only)'
        required: false
        type: boolean
        default: false

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - run: |
          echo "Deploying ${{ inputs.image-tag }} to ${{ inputs.environment }}"
          helm upgrade --install myapp ./charts \
            --namespace ${{ inputs.environment }} \
            --set image.tag=${{ inputs.image-tag }}
```

---

## Timeouts: Preventing Stuck Jobs

Without timeouts, a hung job blocks a runner indefinitely:

```yaml
jobs:
  integration-test:
    timeout-minutes: 30      # job-level timeout — entire job
    runs-on: ubuntu-latest
    steps:
      - name: Start database
        timeout-minutes: 5   # step-level timeout — this specific step
        run: |
          docker-compose up -d db
          until docker exec db pg_isready; do sleep 1; done
```

**Good timeout values:**
- Lint: 5 minutes
- Unit tests: 15 minutes
- Docker build: 20 minutes
- Integration tests: 30 minutes
- Deployment: 15 minutes
- Full pipeline: 45 minutes

If your pipeline regularly hits timeout limits, the timeout isn't the problem — performance is.
