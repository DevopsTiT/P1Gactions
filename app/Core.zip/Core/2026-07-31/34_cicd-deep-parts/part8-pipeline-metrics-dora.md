# Part 8 — Pipeline Metrics and DORA: Deep Dive

---

## Why SREs Measure CI/CD Pipelines

Most teams measure their applications (latency, error rate, availability). Few measure their DELIVERY process. This is a mistake.

```
A broken or slow pipeline causes:
  - Developers waiting → $30/hour engineer × 10 engineers × 10min wait = $50/commit
  - Delayed incident fixes → MTTR increases because deploy takes 45 min, not 5 min
  - Developer frustration → engineers start skipping CI, defeating its purpose
  - Slow feature delivery → business impact

The CI/CD pipeline IS a production system that serves developers.
It deserves the same SLO treatment as customer-facing services.
```

---

## DORA Metrics: The Research-Backed KPIs

The DORA (DevOps Research and Assessment) metrics are the industry standard for measuring software delivery performance. They come from 7+ years of research across thousands of organizations.

### Metric 1: Deployment Frequency

**What it measures:** How often you successfully deploy to production.

```
Elite:        Multiple times per day
High:         Once per day to once per week
Medium:       Once per week to once per month
Low:          Less than once per month

Why it matters:
  High deployment frequency = smaller deployments
  Smaller deployments = less risk per deploy
  Less risk = faster rollback when things go wrong
  
  Paradox: deploying MORE OFTEN is SAFER than deploying rarely
           because each deploy changes fewer things
```

**How to calculate:**
```bash
# Count successful production deploys in last 30 days
gh run list \
  --workflow=deploy-production.yml \
  --status=success \
  --limit=200 \
  --json createdAt \
  --jq '[.[] | select(.createdAt >= "2026-07-01")] | length'

# Then divide by days to get frequency
# E.g., 45 deploys in 30 days = 1.5 deploys per day (HIGH tier)
```

---

### Metric 2: Lead Time for Changes

**What it measures:** Time from code commit to code running in production.

```
Elite:        Less than 1 hour
High:         1 day to 1 week
Medium:       1 week to 1 month
Low:          1-6 months

Breaking it down (where does time go?):
  Code review wait:       2-48 hours (human bottleneck)
  CI pipeline:            5-30 minutes (automation)
  Staging validation:     15-60 minutes (automation + human)
  Deploy approval wait:   0 min (auto) to 24 hours (human gate)
  Deploy execution:       5-15 minutes (automation)
  
  To improve lead time: focus on the HUMAN waits, not automation
```

**How to calculate:**
```bash
# For each PR: time from first commit to production deploy
# GitHub CLI: time from PR creation to merge (proxy for lead time)
gh pr list --state=merged --limit=100 \
  --json mergedAt,createdAt,title | \
  jq '[.[] | {
    title: .title,
    lead_time_hours: (
      (.mergedAt | fromdateiso8601) - (.createdAt | fromdateiso8601)
    ) / 3600
  }] | sort_by(.lead_time_hours)'

# Full lead time requires tracking: commit time → production deploy time
# This needs custom instrumentation in your pipeline:
echo "LEAD_TIME_START=$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> $GITHUB_ENV
# ... at end of production deploy:
echo "Lead time: $(($(date +%s) - $(date -d $LEAD_TIME_START +%s))) seconds"
```

---

### Metric 3: Change Failure Rate

**What it measures:** Percentage of deployments that cause a production incident.

```
Elite:        0-15%
High:         16-30%
Medium:       16-30%
Low:          16-45% (with slower recovery)

A "failure" means:
  - Deploy caused an incident requiring rollback
  - Deploy caused a page/alert indicating user impact
  - Deploy required a hotfix within N hours

Change failure rate answers: "How often do we break prod when we deploy?"
```

**How to calculate:**
```bash
# Deploys that triggered a rollback within 1 hour
TOTAL_DEPLOYS=$(gh run list --workflow=deploy-production.yml --limit=100 --json conclusion | \
  jq '[.[] | select(.conclusion == "success")] | length')

# Count rollbacks (requires tracking — can look at helm rollback events or revert commits)
ROLLBACK_DEPLOYS=$(kubectl get events -n production --field-selector reason=RolledBack \
  --since=720h | wc -l)

echo "Change failure rate: $(echo "scale=2; $ROLLBACK_DEPLOYS / $TOTAL_DEPLOYS * 100" | bc)%"
```

---

### Metric 4: MTTR (Mean Time to Restore)

**What it measures:** Average time to recover from a production incident.

```
Elite:        Less than 1 hour
High:         Less than 1 day
Medium:       1 day to 1 week
Low:          More than 1 week

Why CI/CD affects MTTR:
  Slow deploy pipeline → slow fix delivery
  If your deploy takes 45 minutes, your minimum MTTR is 45 minutes
  
  Elite teams deploy fixes in < 15 minutes because:
    - Small, frequent changes = easy to identify what broke
    - Fast CI pipeline = fix reaches prod quickly
    - Automated rollback = immediate recovery while fix is prepared
    - Feature flags = turn off bad feature in seconds
```

**How to improve MTTR:**
```
Priority 1: Automate rollback (helm rollback on health check fail)
            → MTTR from "time to notice + time to fix + deploy" to "5 min"

Priority 2: Fast CI pipeline (under 10 min)
            → Hotfix can reach prod in 15 min

Priority 3: Small deploys (feature flags, small PRs)
            → Easy to identify what broke, easy to revert

Priority 4: Good observability (traces, metrics, logs)
            → Diagnose root cause in minutes, not hours
```

---

## Pipeline Internal Metrics

Beyond DORA, measure the pipeline itself:

### Build Duration Tracking

```yaml
# In every workflow: record timing metrics
jobs:
  record-metrics:
    runs-on: ubuntu-latest
    if: always()       # run even if pipeline failed
    needs: [build, test, deploy]
    steps:
      - name: Record pipeline metrics
        run: |
          # Calculate durations from GitHub context
          WORKFLOW_START="${{ github.event.head_commit.timestamp }}"
          NOW=$(date -u +%Y-%m-%dT%H:%M:%SZ)
          
          # Push to Prometheus Pushgateway
          cat <<EOF | curl --silent --data-binary @- \
            http://pushgateway:9091/metrics/job/cicd/instance/${{ github.run_id }}
          # HELP pipeline_duration_seconds Total pipeline duration
          # TYPE pipeline_duration_seconds gauge
          pipeline_duration_seconds{
            workflow="${{ github.workflow }}",
            branch="${{ github.ref_name }}",
            conclusion="${{ needs.build.result }}"
          } $DURATION

          # HELP pipeline_build_result Whether pipeline succeeded
          # TYPE pipeline_build_result gauge
          pipeline_build_result{
            workflow="${{ github.workflow }}",
            branch="${{ github.ref_name }}"
          } $([ "${{ needs.build.result }}" == "success" ] && echo 1 || echo 0)
          EOF
```

### Key Pipeline Metrics to Track

```
Build success rate:
  = successful builds / total builds
  SLO: > 90%
  Alert if: < 85% over rolling 24h window

P95 build duration:
  = 95th percentile of build times
  SLO: < 10 minutes
  Alert if: P95 > 15 minutes

Queue wait time:
  = time from trigger to runner allocation
  SLO: < 2 minutes
  Alert if: > 5 minutes (runner shortage)

Deploy success rate:
  = successful deploys / total deploy attempts
  SLO: > 95%
  Alert if: < 90%

Rollback rate:
  = rollbacks / successful deploys
  Target: < 5%
  Alert if: > 10% in 7-day window
```

---

## Flaky Test Detection

Flaky tests are tests that sometimes pass and sometimes fail without code changes. They are the #1 destroyer of CI/CD pipeline reliability.

```
Impact of flaky tests:
  10% of tests are flaky
  Test suite has 200 tests
  20 flaky tests each have 10% failure probability
  
  Probability of at least one flaky failure per run:
  = 1 - (0.9)^20 = 1 - 0.12 = 88%
  
  Result: 88% of CI runs fail due to flakiness, not real bugs
  Engineers learn to re-run CI instead of investigating
  Real failures get ignored → bugs reach production
```

### Detecting Flaky Tests

```bash
# Run the same test suite N times and identify non-deterministic results
for i in {1..10}; do
  mvn test --batch-mode 2>&1 | grep -E "Tests run:|FAILED|ERROR" >> test-run-$i.txt
done

# Compare results across runs
# Tests that appear in some FAILED files but not others = flaky

# Better: Use Maven Surefire rerun support
mvn test \
  -Dsurefire.rerunFailingTestsCount=3 \
  -Dsurefire.useFile=true
# If test fails but passes on retry → counts as flaky, not failed
# Reports flaky tests separately
```

### Tracking and Fixing Flaky Tests

```yaml
# In pipeline: retry failing tests once, report retried tests as flaky
- name: Run tests with flake detection
  run: |
    mvn test -B || {
      echo "First run failed, retrying to detect flakiness..."
      mvn test -B
      echo "::warning::Some tests may be flaky — check surefire reports"
    }

# Tag flaky tests with @Disabled or @Flaky annotation while fixing
@Disabled("FLAKY: fails intermittently due to timing - tracked in JIRA-123")
@Test
void testPaymentWithTimeout() { ... }
```

**Rule:** A flaky test is treated as a P2 bug. Fix it within one sprint or disable it with a tracking ticket.

---

## Pipeline Observability Dashboard

SREs should have a Grafana dashboard for the pipeline:

```
Row 1: Pipeline Health Summary
  - Build success rate (last 7d): 94%
  - Avg build duration: 8m 23s
  - Deployments today: 5
  - Rollbacks this week: 0

Row 2: Build Duration Trend (last 30d)
  - Time series: P50, P95, P99 build duration
  - Alerts: red line at 10-minute SLO

Row 3: Build Results by Branch
  - Table: branch | success rate | last build | last build time
  - Focus: main branch health

Row 4: DORA Metrics
  - Deployment frequency (bar chart per day)
  - Lead time histogram (distribution of lead times)
  - Change failure rate (30-day rolling)
  - MTTR (30-day rolling average)

Row 5: Failure Analysis
  - Most common failure reason (lint/test/build/deploy)
  - Failure rate by service
  - Test flakiness rate
```
