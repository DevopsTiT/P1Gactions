# Glossary — RCA with Dynatrace
Every term from main.md. One entry per term. SRE beginner level.

---

**RCA (Root Cause Analysis)**
The process of finding WHY an incident happened — not just WHAT happened. Goal: identify the specific change or failure that triggered the chain of events, so it can be permanently fixed. Why it matters: fixing symptoms without finding root cause means the same incident will happen again.

**Root cause**
The deepest, specific, actionable cause of a problem. "DB query is slow because it lacks an index on a 52M-row table after a data migration." NOT: "the DB is slow." Why it matters: root cause drives the fix. Symptom fixes are temporary; root cause fixes are permanent.

**Symptom**
What you observe in the alert — error rate high, latency high, traffic dropped. Symptoms tell you something is wrong; they do not tell you why. Why it matters: SREs frequently mistake symptoms for root causes. "Error rate is 2%" is a symptom. "Fraud-detection OOM killed" is a root cause.

**5-Why framework**
A technique: ask "why?" five times in sequence, each time going one level deeper, until you reach a systemic root cause. Why it matters: stops engineers from stopping at the first visible cause ("the DB is slow") and forces finding the actual trigger ("the query lacks an index because the data migration added 10M rows with no follow-up index creation").

**Davis AI**
Dynatrace's built-in AI engine that automatically correlates events, groups related alerts into one Problem, and suggests root causes by analyzing metric topology. Why it matters: Davis does the first layer of RCA automatically — it often points directly to the deployment event or failing dependency, saving 5–10 minutes of manual investigation.

**Problem (Dynatrace)**
A DT object that groups related alerts (metric events, SLO breaches, availability events) into one cohesive incident. Davis AI creates Problems automatically. Why it matters: instead of 5 separate alerts for the same DB outage, you get 1 Problem with all related signals in one place.

**Problems Feed**
The main DT screen showing all open Problems across all services. Starting point for every RCA. Why it matters: gives you the Davis AI root cause suggestion, impact count, and correlated events before you start investigating.

**Distributed Trace**
A record of ONE request flowing through ALL services it touched, showing timing for every step. Visualized as a waterfall diagram. Why it matters: tells you EXACTLY where a slow request spent its time — was it JWT auth, the DB query, a downstream service call? Traces answer "where" in milliseconds of precision.

**Trace waterfall diagram**
A visual representation of a distributed trace: each service/component is a bar, width = time taken, nesting = call hierarchy. Bars at the bottom are the deepest dependencies (DB, external APIs). Why it matters: the widest bar at the deepest level is almost always where the root cause is.

**Span**
One unit of work in a distributed trace — one service's contribution to a request. A trace = multiple spans stitched together by trace ID. Why it matters: each span shows: service name, operation name, duration, whether it errored. The slow span = the problem.

**Tail latency**
The latency experienced by the slowest requests (P99, P99.9). If P99 is much higher than P50 (median), it's a "tail latency issue" — most requests are fine, but a small percentage are very slow. Why it matters: tail latency issues often have different root causes from general slowness: GC pauses, connection pool exhaustion (only some threads are blocked), or specific slow query variants.

**Service Map**
A visual topology in DT showing which services call which, with real-time health indicators (green/yellow/red) on each service and connection. Why it matters: immediately answers "is the problem inside this service or coming from a dependency?" — saves 5–10 minutes of blind investigation.

**Smartscape**
DT's full-stack topology view showing everything: pods, processes, services, applications, and infrastructure, all interconnected. Why it matters: when multiple services are red simultaneously, Smartscape shows if they share a failing infrastructure component (same EKS node, same RDS instance).

**Metrics Explorer**
DT tool for querying and charting any metric for any service, time range, or dimension. Why it matters: lets you correlate metrics — "P99 latency chart + GC time chart on the same timeline" reveals that GC pauses are causing latency spikes.

**Split by (dimension)**
In Metrics Explorer: splitting a metric by a tag/attribute to get one line per value. Split `service.response.time` by `service.request.name` → one line per endpoint. Why it matters: immediately tells you if ALL endpoints are slow (infrastructure issue) or just one endpoint (code issue).

**Log Analytics**
DT's log search and analysis tool. Searches container logs ingested by OneAgent across all pods simultaneously. Why it matters: the exact exception message is in the logs. "HikariPool: Connection is not available, request timed out after 30000ms" tells you immediately: connection pool exhausted.

**Log-Trace correlation**
In DT Logs view: clicking a log line → "Show trace" opens the distributed trace for that exact request. Also works the other direction: trace → find related logs. Why it matters: you see the error message in logs AND the full call chain in the trace — pinpoints the exact line of code and the exact call path.

**HikariCP (HikariPool)**
The default Java database connection pool library used by Spring Boot. Manages a pool of reusable DB connections. When the pool is full and a new thread needs a DB connection, it waits up to `connectionTimeout` (default 30s), then throws. Why it matters: "HikariPool: Connection is not available" in logs = the most common Java DB-related incident pattern.

**Connection pool exhaustion**
When all DB connections in the pool are in use and new requests can't get a connection. Requests queue up, timeout, and return 5xx errors. Why it matters: looks like a DB performance problem (slow responses) but is actually a connection management problem. Fix: increase pool size OR find what's holding connections open (long transactions, missing connection.close()).

**Deployment event (DT)**
A marker on DT metric charts showing when a deployment happened. Appears as a vertical dashed line on the chart timeline. Why it matters: visually correlates "latency spike started here" with "deploy happened 12 minutes earlier" — the most reliable evidence for deployment-caused incidents.

**CUSTOM_DEPLOYMENT event**
A DT API event type posted by CI/CD pipelines to record deployments. JSON payload with service name, version, commit SHA. Why it matters: without this, DT can only detect Kubernetes rolling updates. Custom deployment events cover Terraform changes, config updates, feature flag toggles — anything that isn't a pod restart.

**OOM Kill (Out of Memory Kill)**
When a container exceeds its memory limit, the Linux kernel kills the process immediately — no graceful shutdown, all in-flight requests fail. Shows as `OOMKilled` in `kubectl describe pod`. Why it matters: causes sudden pod restarts, lost in-flight requests, and if repeated, CrashLoopBackOff. Root cause is always: heap too small for actual workload OR memory leak.

**Memory leak**
A bug where Java objects are retained in memory (referenced in a data structure) and the GC cannot collect them. Heap grows slowly over hours. Pattern: heap utilization rises steadily, never returns to baseline. Why it matters: gradually causes GC pressure → latency spikes → eventually OOM kill. Slow onset means it's often missed until it causes a P1.

**Heap growth pattern (sawtooth vs ramp)**
Normal: heap usage oscillates (sawtooth) — GC collects, heap drops, rises again, drops again. Bounded. Memory leak: heap rises steadily (ramp) — GC runs but baseline keeps climbing. Why it matters: looking at 24h heap chart immediately distinguishes "normal GC behavior" from "memory leak."

**G1GC (Garbage-First GC)**
Default JVM garbage collector since Java 9. Runs incrementally to avoid long pauses. When heap is too full, G1GC must run more frequent cycles and longer "mixed GC" collections → pause times increase → latency P99 spikes. Why it matters: the most common JVM performance issue on production services — heap above 70% = G1GC becomes the bottleneck.

**Full GC (stop-the-world)**
A GC phase where ALL JVM threads are paused while the collector works. Can last 2–10 seconds. Every request in-flight during this pause freezes completely. Why it matters: a 3-second Full GC on a service with a 300ms P99 SLO will breach the SLO for every concurrent request at that moment.

**`garbageCollectionTime` metric**
DT metric: total milliseconds the JVM spent in GC pause per minute. Normal: 10–30ms/min. Warning: 50–150ms/min. Critical: >200ms/min (GC is taking significant time away from request processing). Why it matters: rising GC time BEFORE latency spikes = early warning of heap pressure.

**Thread count metric**
DT metric tracking active JVM threads. Normally stable. A growing thread count = thread leak (threads are created but never terminated). A flat but high thread count = thread pool exhaustion. Why it matters: thread leaks eventually cause OutOfMemoryError (each thread consumes ~512KB stack). Thread pool exhaustion causes request queuing → latency spikes.

**Silent outage**
An outage where traffic drops to zero but error rate and latency look fine (nothing to measure). Caused by: DNS failure, ALB misconfiguration, Ingress change blocking traffic. Why it matters: ALL standard monitoring (error rate, latency, P99 SLO) shows green during a silent outage. Only the traffic drop alert (`traffic_min_rps`) catches it.

**ALB health check**
AWS Application Load Balancer periodically polls a health check path on each target (pod). If the check fails, ALB removes that target from rotation — no traffic is sent to it. Why it matters: a wrong health check path in an Ingress annotation causes ALB to mark all targets unhealthy → traffic drops to zero → silent outage.

**Dead Letter Queue (DLQ)**
A queue where messages go after repeatedly failing to process. Used by SQS with notification-service. DLQ fills silently — no HTTP errors, no standard metric events. Why it matters: the only way to detect DLQ-filling is custom application metrics (OTEL counters) and a custom SLO. Standard monitoring is completely blind to this failure mode.

**AWS SES (Simple Email Service)**
AWS managed email sending service. Requires sender email addresses to be verified in SES before use. Returns `MessageRejectedException` if unverified sender is used. Why it matters: a Terraform change to the sender email to an unverified address causes all email sends to fail silently — only caught by custom message processing SLO.

**ext:custom.* metrics**
Dynatrace metric namespace for application-emitted custom metrics via OTEL. The app code calls `meterRegistry.counter("messages.failed.count").increment()`. DT receives it as `ext:custom.messages.failed.count`. Why it matters: business logic failures (failed payments, unprocessed messages) are invisible to infrastructure monitoring — custom metrics expose them.

**Circuit breaker**
A design pattern: if a downstream service is repeatedly failing, stop calling it temporarily (circuit "opens"). Return a fallback response instead. After a timeout, try again ("half-open"). Why it matters: without a circuit breaker, payment-service keeps trying to call fraud-detection-service (which is OOM-killed), piling up timeout threads → payment-service itself becomes overloaded.

**Cascade failure**
When one service failure spreads to dependent services. fraud-detection OOM → payment-service times out → order-service errors. Why it matters: service map + trace analysis reveals cascade direction. Fix: circuit breakers, timeouts, bulkheads prevent cascades from spreading.

**P99 vs P50 comparison**
If P99 >> P50: tail latency problem — most requests are fine, a small percentage are very slow. Cause: GC pauses (pause affects all in-flight requests, then releases), connection pool contention (only some threads are blocked), or specific slow query variants. Why it matters: tail-only issues have different root causes and fixes than general slowness.

**N+1 query**
A bug where code fetches N items (1 query), then for each item makes another DB query (N additional queries) = N+1 total queries. Example: load 100 orders (1 query) then load each order's payment info (100 queries) = 101 queries instead of 2. Why it matters: adding 100 orders to a page = 101 DB queries instead of 2 → DB latency multiplied × 50 → P99 spike. Visible in traces: dozens of small identical DB calls in a single trace.

**OTEL (OpenTelemetry)**
Open standard for distributed tracing, metrics, and logs. Java Spring Boot app sends traces to DT ActiveGate via `OTEL_EXPORTER_OTLP_ENDPOINT`. Why it matters: enables cross-service distributed traces (order → payment → DB shown in one trace) and custom metric emission for business-level SLOs.

**Trace ID**
A unique identifier (e.g., `a1b2c3d4e5f6...`) that follows a request through every service it touches. All spans belonging to the same request share the same trace ID. Why it matters: copy a trace ID from a log → paste into DT trace search → instantly see the full request journey across all services.
