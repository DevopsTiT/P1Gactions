# Root Cause Analysis (RCA) with Dynatrace — SRE Deep Dive

> Context: production Java microservices (payment-service, order-service, notification-service)
> on EKS with OneAgent full-stack monitoring, OpenTelemetry traces, and Dynatrace alerting.
>
> This guide walks through: the RCA mindset, every Dynatrace tool you use, the exact
> click-path for each tool, and 5 real incident scenarios with step-by-step RCA.

---

## The RCA Mindset — Before You Open Dynatrace

```
Wrong approach: "The alert fired. Let me check the service."
Right approach: "The alert fired. What CHANGED just before it fired?"

The root cause of 90% of incidents is one of:
  1. A CODE CHANGE   (new deploy 15 minutes ago)
  2. A CONFIG CHANGE (Terraform, Helm values, feature flag)
  3. A TRAFFIC CHANGE (10× spike, traffic dropped to 0)
  4. A DEPENDENCY FAILURE (DB, downstream service, external API)
  5. A RESOURCE EXHAUSTION (JVM heap, DB connections, disk space)

Dynatrace tells you WHAT is broken.
YOU must figure out WHY using the timeline: "what changed just before this started?"
```

### The 5-Why Framework (applied to DT data)

```
Alert: payment-service P99 latency > 300ms

Why 1: Why is P99 high?
  → DT: service response time chart → latency spike started at 14:32
  → DT: top slow transactions → POST /api/v1/payments is slow

Why 2: Why is POST /payments slow?
  → DT: distributed trace → bottleneck is at the DB call (250ms of 310ms total)

Why 3: Why is the DB call slow?
  → DT: database statements → SELECT query on payments table taking 250ms (normally 5ms)

Why 4: Why is that query slow now?
  → DT: DB metrics → table size grew 10× in last 24h (a data load job ran)
  → OR: DT: JVM metrics → GC pause 200ms → threads blocked during GC → query appears slow

Why 5: Why did the table grow / why did GC pause?
  → Deployments tab → new version deployed at 14:20 (12 min before incident)
  → That version had a bug: duplicate INSERT in payment-service created duplicate rows

ROOT CAUSE: bad deploy at 14:20 → duplicate rows → table bloat → slow queries → P99 breach
FIX: roll back the deploy, clean up duplicate rows
```

---

## Part 1 — The 6 Dynatrace Tools for RCA

### Tool 1: Problems Feed (Start Here Always)

**What it is:** DT's automated problem detection. DT's Davis AI groups related alerts into one "Problem" — it already does some RCA for you.

**Navigation:**
```
DT UI → Left sidebar → "Problems"
OR: click directly from the PagerDuty alert link
```

**What to look at:**
```
Problem card shows:
  ┌────────────────────────────────────────────────────────┐
  │ [P-12345] Response time degradation                    │
  │ Affected: payment-service (production)                 │
  │ Started: 14:32 JST                                     │
  │ Impact: 847 users affected                             │
  │                                                        │
  │ Root cause suggestion (Davis AI):                      │
  │  "Response time increase in payment-service           │
  │   correlated with deployment event at 14:20"           │
  │                                                        │
  │ Related events:                                        │
  │  → Deployment: payment-service v2.3.1 at 14:20        │
  │  → Metric event: DB query latency increase at 14:32   │
  │  → SLO breach: Payment Latency P99 at 14:33           │
  └────────────────────────────────────────────────────────┘
```

**RCA action:**
```
1. Look at "Root cause suggestion" — Davis often gets it right
2. Note the EXACT start time of the problem (14:32)
3. Note what happened BEFORE the problem (deploy at 14:20)
4. Click into the problem to see all related events
5. Check "Impact" — how many users, which services
```

**Key insight — the "root cause" link:**
```
Problems feed has a "root cause" section that shows the FIRST event in the causal chain.
DT traces the chain:
  DB query slow → payment-service slow → SLO breach
and shows you the DB query as the root cause, not the SLO breach.

ALWAYS trust this chain over your intuition. DT has full topology visibility.
```

---

### Tool 2: Distributed Tracing (Trace a Single Request End-to-End)

**What it is:** A record of ONE request flowing through ALL services, showing exactly where time was spent.

**Navigation:**
```
DT UI → Left sidebar → "Distributed Traces"
OR: Service page → "Distributed Traces" tab
OR: from a Problem card → "View traces"
```

**How to find the slow traces:**
```
1. Go to Distributed Traces
2. Filter:
   Service: payment-service
   Time: last 30 min
   Sort by: Response time (descending)
3. Click the slowest trace
```

**Reading a trace:**
```
Trace waterfall diagram:
  order-service [320ms total]
  ├── HTTP POST /api/v1/payments → payment-service [310ms]
  │   ├── JWT validation [2ms]
  │   ├── SELECT FROM accounts WHERE id=? [5ms]   ← normal
  │   ├── SELECT FROM payments WHERE ... [248ms]  ← !! THIS IS THE PROBLEM
  │   └── INSERT INTO payments [12ms]
  └── return response [8ms overhead]

Reading the waterfall:
  Width of each bar = time taken
  Nesting = call hierarchy (who called whom)
  Red bars = errors
  Yellow bars = slow (above threshold)

What to look for:
  ① The WIDEST bar — this is where time was spent
  ② The DEEPEST level — external calls (DB, 3rd party API) are often at the bottom
  ③ Gaps between bars — time unaccounted for (could be GC pause, thread queue wait)
```

**Filtering traces for RCA:**
```
Filter by error: show only failed traces
  → Immediately see: what endpoint, what error, at what layer

Filter by time range: "14:30 to 14:35" (the 5 minutes the alert fired)
  → Compare with "14:20 to 14:25" (before the incident)
  → If latency doubled: DB calls went from 5ms to 250ms → DB is the issue

Filter by service: zoom into payment-service only
  → How many DB calls per request? (normally 2, now 8? → N+1 query bug in new deploy)
```

---

### Tool 3: Service Map (Understand Dependencies)

**What it is:** A visual topology showing which services call which, with real-time health indicators on each connection.

**Navigation:**
```
DT UI → Left sidebar → "Services" → click your service → "Service map" tab
OR: DT UI → "Smartscape" (full topology view)
```

**Reading the service map:**
```
       [order-service] ──→ [payment-service] ──→ [PostgreSQL: payments-db]
             │                    │                       ↑
             │                    └──→ [fraud-detection]  │
             └──→ [notification-service]                  │
                                                    [RDS: ap-northeast-1]

Color coding:
  Green  = healthy
  Yellow = degraded
  Red    = critical / error
  Grey   = no recent traffic

Lines / arrows:
  Solid line    = active traffic flowing
  Dashed line   = dependency, no recent calls
  Thick red line = high error rate on this connection
```

**RCA use:**
```
Scenario: payment-service shows red.

Check the service map:
  → Is PostgreSQL (downstream) also red?
     YES → DB problem causing payment-service to fail (dependency failure)
     NO  → payment-service itself is the problem (code/config issue)

  → Is order-service (upstream) showing high traffic?
     YES → traffic spike from order-service is overloading payment-service
     NO  → check payment-service internals

The map tells you direction:
  "Is the problem inside this service, or coming from outside?"
```

**Smartscape** (full infrastructure view):
```
Shows: pods → processes → services → applications → infrastructure
Hover over a node: see all connections
Highlight a service: all related infrastructure glows

Use case: "Is anything ELSE broken in the cluster right now?"
  If 3 services are all showing red at the same time → likely infrastructure issue
  If only payment-service is red → likely code/config issue
```

---

### Tool 4: Metrics Explorer (Drill Into Any Metric)

**What it is:** Query and chart any DT metric for any time range, any service, any granularity.

**Navigation:**
```
DT UI → Left sidebar → "Metrics" (under "Observe and Explore")
```

**Essential metrics for RCA:**

```
For a latency spike:
  builtin:service.response.time:percentile(99)    ← P99 response time
  builtin:service.response.time:percentile(50)    ← P50 (median) — compare with P99
                                                     If P99 >> P50: tail latency issue, not all requests

For an error spike:
  builtin:service.errors.server.rate             ← HTTP 5xx rate
  builtin:service.errors.server.count            ← count of errors
  (split by endpoint to see which URL is erroring)

For a DB investigation:
  builtin:service.dbconnectioncount              ← DB calls per minute
  builtin:service.dbconnectionlatency            ← DB call duration
  builtin:service.dbconnectionfailcount          ← failed DB calls
  (look for: is count normal but latency spiking? = slow queries)
  (look for: is count suddenly 0? = DB connection dropped)

For JVM investigation:
  builtin:process.memory.jvm.heapUtilization     ← heap % of Xmx
  builtin:process.memory.jvm.garbageCollectionTime ← ms in GC per minute
  builtin:process.jvmThreadCount                  ← thread count (deadlock = threads stuck)
  builtin:process.cpu.usage                       ← process CPU %

For Kubernetes:
  builtin:kubernetes.workload.pods.restarts       ← pod restart count
  builtin:kubernetes.workload.pods.runningCount   ← how many pods running
  (if pods < expected: some pods crashed → less capacity → overload on survivors)
```

**How to use Metrics Explorer for RCA:**

```
Step 1: Select the metric (e.g., builtin:service.response.time)
Step 2: Filter by:
  - service.name = "payment-service"
  - environment = "production"
Step 3: Set time range to cover the incident + 1 hour before
Step 4: Look for:
  - When did the metric change? (exact time)
  - Is the change correlated with another metric?

Example RCA workflow in Metrics Explorer:
  → P99 latency chart shows spike at 14:32
  → Add second metric: jvm.garbageCollectionTime → also spikes at 14:32
  → GC time from 10ms/min to 400ms/min at exactly 14:32
  → Add third metric: jvm.heapUtilization → was at 65%, jumped to 88% at 14:25
  
  Timeline: heap fills up at 14:25 → GC thrashing at 14:32 → P99 latency spikes
  ROOT CAUSE: memory leak or config change causing heap pressure
```

**Split-by (Dimensions):**
```
Split metric by: "dt.entity.service" → one line per service (compare all services at once)
Split metric by: "service.request.name" → one line per endpoint
  → Immediately see: is ALL endpoints slow, or just POST /payments?
  → "just POST /payments" → specific endpoint issue (bad query, new code path)
  → "ALL endpoints" → infrastructure/JVM issue (GC, CPU, memory)
```

---

### Tool 5: Logs (Find the Error Message)

**What it is:** Container logs from all pods, ingested by OneAgent's logMonitoring, searchable in DT.

**Navigation:**
```
DT UI → Left sidebar → "Logs" (under "Observe and Explore")
```

**RCA workflow:**

```
Step 1: Set time range to the incident window
Step 2: Filter:
  dt.entity.process_group_instance: payment-service
  log.level: ERROR  (or WARN to catch warnings too)
Step 3: Look at the error messages

Example log line:
  14:32:15 ERROR [payment-service] [Thread-47]
  com.zaxxer.hikari.pool.HikariPool: Connection is not available,
  request timed out after 30000ms
  Pool stats (total=20, active=20, idle=0, waiting=23)

Interpretation:
  HikariCP (Java DB connection pool) is full.
  20 connections = max, all active, 23 threads waiting.
  ROOT CAUSE: DB connection pool exhausted.
  FIX: increase pool size OR find what's holding connections open.
```

**Useful log queries:**
```
Find all ERRORS in payment-service last 30 min:
  log.level = "ERROR" AND dt.entity.process_group: "payment-service"

Find specific exception:
  content = "*NullPointerException*" AND dt.entity.process_group: "payment-service"

Find DB connection errors:
  content = "*HikariPool*" OR content = "*connection*refused*"

Find OOM kills:
  content = "*OutOfMemoryError*" OR content = "*java.lang.OutOfMemory*"

Find timeout errors:
  content = "*timeout*" AND log.level = "ERROR"

Correlate with trace ID:
  trace_id = "a1b2c3d4e5f6..."  ← paste trace ID from a slow trace to find its logs
```

**Log → Trace correlation:**
```
In the Logs view: click any log line → "Show trace"
→ DT opens the distributed trace for the request that generated this log entry.
This is extremely powerful:
  You see the error in the log → jump to the trace → see exactly where in the call chain it happened.
```

---

### Tool 6: Deployments and Events Feed (What Changed?)

**What it is:** A feed of all deployment events, configuration changes, and custom events — correlated with metric changes on the same timeline.

**Navigation:**
```
DT UI → Service page → "Events" tab
OR: DT UI → Left sidebar → "Releases" (for deployment tracking)
OR: Service page → "Properties and tags" → deployment history
```

**Why this is critical for RCA:**
```
80% of incidents are caused by recent changes.
DT shows deployments AS VERTICAL LINES on metric charts.

When you open a metric chart (e.g., P99 latency):
  → You see a vertical dashed line at 14:20
  → The tooltip says: "Deployment: payment-service v2.3.1"
  → P99 latency starts rising 12 minutes later at 14:32

This is visual proof that the deploy caused the incident.
No guessing. The timeline is right there.
```

**Event types DT tracks:**
```
Deployment events:
  → Kubernetes rolling update (detected by OneAgent watching container image changes)
  → Helm chart upgrades
  → ArgoCD sync events (if DT is connected to ArgoCD)

Configuration change events:
  → Kubernetes ConfigMap changes
  → Environment variable changes
  → Resource limit changes (CPU/memory)

Custom events:
  → Anything your CI/CD pipeline sends:
    curl -X POST "https://<DT-TENANT>/api/v1/events" \
      -H "Authorization: Api-Token <TOKEN>" \
      -d '{"eventType":"CUSTOM_DEPLOYMENT",
           "deploymentName":"payment-service v2.3.1",
           "deploymentVersion":"2.3.1",
           "deploymentProject":"payment-service"}'
  → CI pipeline sends this after every deploy → DT shows it on metric charts
```

---

## Part 2 — The RCA Click Path (Step by Step)

### The Universal 10-Step RCA Process in DT

```
Step 1: OPEN PROBLEMS FEED
  → Note: what service, what metric, when did it start?
  → Note: Davis AI root cause suggestion

Step 2: CHECK DEPLOYMENT EVENTS
  → Service page → Events tab
  → Was there a deploy in the last 30–60 minutes?
  → If YES: deployment is 80% likely the root cause → go to Step 8

Step 3: CHECK SERVICE HEALTH
  → Service page → Response time, Error rate, Throughput charts
  → Note: is this ALL endpoints or ONE endpoint?
  → Note: did traffic spike / drop at incident start?

Step 4: LOOK AT SERVICE MAP
  → Is the problem isolated to this service, or spreading from a dependency?
  → If dependency (DB, downstream service) is red → investigate there first

Step 5: DRILL INTO TRACES
  → Sort by response time descending
  → Open slowest trace
  → Find the widest bar → that layer is where time is spent

Step 6: CHECK JVM METRICS (for Java services)
  → Heap utilization: was it normal before the incident?
  → GC time: did GC time spike at incident start?
  → Thread count: any stuck/growing thread count?

Step 7: CHECK LOGS
  → Filter by ERROR level, incident time window
  → What exception appears most often?
  → Look for: connection pool, OOM, timeout, specific business exceptions

Step 8: CORRELATE TIMELINE
  → Open metric chart (P99 latency)
  → Are there deployment markers? → correlate
  → Did another metric change FIRST? (heap → GC → latency is a sequence)

Step 9: FORM ROOT CAUSE HYPOTHESIS
  → "The latency spike was caused by X because Y evidence shows Z"
  → Must be specific: not "DB is slow" but "DB query SELECT * FROM payments
     is slow because full table scan (missing index) on a table that grew 10×"

Step 10: VERIFY AND FIX
  → Apply the fix
  → Watch the metric chart in real time
  → If metric recovers → root cause confirmed
  → If not → back to Step 4 with new information
```

---

## Part 3 — 5 Real Incident Scenarios with Full RCA

### Scenario 1: Payment-Service P99 Latency Spike

**Alert:** `[PROD] payment-service: P99 latency >300ms`

**RCA walkthrough:**

```
Step 1 — Problems feed:
  Davis AI: "Response time degradation in payment-service.
  Correlated with: deployment event at 14:20 (payment-service v2.3.1)"

Step 2 — Check deployment:
  Service page → Events → YES: v2.3.1 deployed at 14:20
  Incident started at 14:32 (12 min after deploy)

Step 3 — Check service health:
  P99 chart: spike from 200ms → 850ms starting at 14:32
  Error rate: stable at 0.05% (not the problem — just latency)
  Throughput: normal (traffic didn't spike)

Step 4 — Service map:
  payment-service → PostgreSQL: both showing yellow
  Order-service → payment-service: connection still active
  → PostgreSQL is also degraded → look at DB

Step 5 — Traces:
  Slowest trace: 850ms total
  Waterfall:
    payment-service [850ms]
    ├── auth middleware [3ms]
    ├── SELECT FROM accounts [4ms]      ← normal
    ├── SELECT FROM payments [820ms]    ← !! THE PROBLEM
    └── INSERT [8ms]

  DB call "SELECT FROM payments" went from 5ms (before 14:20) to 820ms (after)

Step 6 — JVM:
  Heap: normal (50%), GC: normal → JVM is NOT the issue

Step 7 — Logs:
  No errors — latency only, no failures

Step 8 — Correlate:
  DT DB metrics: dbconnectionlatency for "SELECT FROM payments" spiked at 14:32
  DB size metric: payments table row count jumped from 5M to 52M at 14:25
  (a bulk data load happened)

  Wait — BUT the deploy was at 14:20. Check the new code in v2.3.1:
  → The new version added a feature: "payment history export"
  → On startup, it runs a data migration: INSERT INTO payments (SELECT ... from archive)
  → Migration ran at 14:25, bloated the table, made queries slow without an index

ROOT CAUSE: v2.3.1 data migration at startup added 47M rows to payments table.
  SELECT queries now doing full table scan (no index on the new rows' timestamp column).

FIX:
  1. Immediate: roll back to v2.3.2 (revert migration, or add index first)
  2. Short-term: CREATE INDEX CONCURRENTLY on payments(timestamp)
  3. Long-term: never run data migrations on startup; use a separate migration job

RESOLUTION TIME: 22 minutes
```

---

### Scenario 2: Order-Service Error Rate Spike

**Alert:** `[PROD] order-service: error rate >0.5%`

```
Step 1 — Problems:
  Davis AI: "Failure rate increase in order-service.
  Affected: POST /api/v1/orders (2.3% error rate)"
  Davis: "Root cause: dependency failure from payment-service"

Step 2 — Deploy check:
  No deployment in the last 2 hours.

Step 3 — Service health:
  order-service error rate: 0.01% → 2.3% at 15:10
  Throughput: normal
  P99 latency: normal for successful requests

Step 4 — Service map:
  order-service → payment-service: RED LINE (thick)
  payment-service: showing RED (critical)
  → The problem is in payment-service, not order-service

  Investigate payment-service:
  payment-service → PostgreSQL: GREEN (DB is fine)
  payment-service: error rate 8%
  → payment-service itself is erroring

Step 5 — Traces on payment-service:
  Failed traces: all fail at the same point:
    payment-service [45ms]
    ├── JWT validation [2ms]
    ├── SELECT FROM accounts [5ms]
    └── [ERROR] call to fraud-detection-service [timeout after 30s]

  fraud-detection-service: not showing on service map at all (grey = no traffic/down)

Step 6 — Check fraud-detection-service:
  Kubernetes: kubectl get pods -n payments
  fraud-detection: 0/3 pods Running (CrashLoopBackOff)

Step 7 — Logs for fraud-detection-service:
  "java.lang.OutOfMemoryError: Java heap space"
  → OOM killing all fraud-detection pods

  Dynatrace JVM metric: fraud-detection heap was at 95% at 15:05
  (5 minutes before incident — just above our 85% dev threshold)

ROOT CAUSE: fraud-detection-service OOM → pods crash → payment-service calls timeout
  → payment-service returns 5xx → order-service propagates the error

FIX:
  1. Immediate: kubectl rollout restart deployment/fraud-detection -n payments
  2. Short-term: increase fraud-detection Xmx from 512m to 1024m
  3. Long-term: add circuit breaker in payment-service for fraud-detection calls
     (if fraud-detection is down, allow payment with async fraud check later)

PATTERN LEARNED: dependency failures cascade upward.
  Service map shows the direction — always check downstream dependencies FIRST
  when Davis AI flags a dependency correlation.
```

---

### Scenario 3: Silent Outage — Traffic Drop to Zero

**Alert:** `[PROD] payment-service: Traffic drop (<10 req/min)`

```
This is the hardest alert to diagnose because:
  - Error rate: 0% (no errors — there's nothing to error)
  - Latency: looks fine (no requests to measure)
  - Service health: GREEN (DT sees the service is up)
  
Only the traffic drop metric catches this.

Step 1 — Problems:
  Davis AI: "Traffic drop detected. No requests reaching payment-service."
  No other correlated events.

Step 2 — Deploy check:
  ArgoCD synced payment-service at 16:45 (new version, Ingress config change)
  Incident started at 16:47.
  → Ingress change caused this.

Step 3 — Service map:
  payment-service: GREEN (healthy, running)
  ALB → payment-service: connection EXISTS but no traffic flowing
  External → ALB: no requests shown

Step 4 — Traces:
  0 traces. Nobody is sending requests.

Step 5 — Logs:
  payment-service logs: starting up, healthy, no errors
  AWS ALB access logs (via CloudWatch): 
    16:45: target health check UNHEALTHY for payment-service targets
    Reason: "Request timed out: failed to respond to health check"

  The new Ingress manifest changed the ALB health check path
  from /actuator/health to /health (doesn't exist in Spring Boot Actuator)
  → ALB marks all targets unhealthy → removes them from load balancer → no traffic

ROOT CAUSE: Helm chart Ingress change in ArgoCD sync at 16:45 changed
  ALB health check path from `/actuator/health` to `/health`.
  ALB marks targets unhealthy → zero traffic reaches service.

FIX:
  1. Immediate: update gitops Ingress annotation to restore correct health check path
  2. git commit → ArgoCD syncs → ALB health check passes → traffic resumes
  3. In Helm chart template: add validation that health check path includes "actuator"

LESSON: traffic drop alert catches what ALL other alerts miss.
  alert_on_no_data = true is critical — fires even when DT receives zero data points.
```

---

### Scenario 4: JVM Memory Leak

**Alert:** `[PROD] payment-service: JVM heap >70% of Xmx` (slow-burn alert, not immediate)

```
This alert fires over HOURS, not minutes. The burn rate is slow.

Step 1 — Problems:
  Davis AI: "Memory utilization increase on payment-service processes.
  Heap utilization trending upward over 4 hours."

Step 2 — Deploy check:
  Deploy 6 hours ago (v2.4.0) — suspect but 6 hours is a long gap.

Step 3 — JVM Metrics Explorer:
  heapUtilization over 24h:
    00:00: 42%
    04:00: 48%
    08:00: 54%
    12:00: 61%
    16:00: 71% ← alert fires
    
  This is a SAWTOOTH PATTERN for memory leaks:
  heap grows slowly → GC cannot collect all objects (some are retained) → baseline rises
  
  Normal JVM: heap fluctuates between 30–60% (GC keeps it bounded)
  Memory leak: heap baseline slowly climbs regardless of GC

Step 4 — GC metrics:
  garbageCollectionTime over 24h:
    Morning: 15ms/min (normal)
    Noon: 35ms/min (elevated)
    16:00: 120ms/min ← GC is working hard, failing to reclaim memory

Step 5 — Thread metrics:
  Thread count over 24h: stable (not a thread leak)

Step 6 — Traces (recent):
  No individual slow traces — all requests are normal P99 ~200ms
  But heap is full → GC pauses becoming frequent → P99 will spike soon

Step 7 — Logs:
  No errors yet — the OOM hasn't happened yet (we're at 71%)
  If we wait: heap → 95% → Full GC → pause → latency spike → 100% → OOM kill

ROOT CAUSE HYPOTHESIS:
  gradual heap growth over 6 hours → memory leak
  Correlates with v2.4.0 deploy (6h ago) — but slow onset

INVESTIGATION:
  DT → payment-service → "Process" → "Memory" → "Object Allocation"
    (requires DT Pro license: "Memory Allocation Analysis")
  Shows: which Java class is accumulating objects?
  Finding: "HashMap" objects in PaymentCacheManager growing unbounded
  New feature in v2.4.0: in-memory cache with no eviction policy

FIX:
  1. Immediate: kubectl rollout restart deployment/payment-service -n payment-ns
     (pod restart = JVM restart = heap cleared = buys time)
  2. Short-term: deploy v2.4.1 with cache eviction (LRU, max 10,000 entries)
  3. Monitor: watch heap chart after fix — should return to flat sawtooth pattern

LESSON: slow-growing metrics need different attention than spike alerts.
  Slow burn SLO alerts catch these BEFORE they become P1 incidents.
```

---

### Scenario 5: Notification Service — DLQ Filling Silently

**Alert:** `[PROD] notification-service: message processing rate <99%`

```
This uses the CUSTOM METRIC SLO (ext:custom.messages.failed.count).
No HTTP errors. Service is "healthy." But messages are failing silently.

Step 1 — Problems:
  Davis AI: "SLO breach: Notification Service Message Processing Rate"
  No standard metric events attached (because this is a custom SLO).
  Davis has no automatic root cause here — we must investigate manually.

Step 2 — Metrics Explorer:
  ext:custom.messages.processed.count: 450/min (normal)
  ext:custom.messages.failed.count: 18/min ← 4% failure rate (SLO target = 1%)

  This started at 19:15.

Step 3 — Deploy check:
  No deploy today.

Step 4 — Logs:
  Filter: notification-service, ERROR, last 30 min
  
  Most frequent error:
    "com.amazonaws.services.simpleemail.model.MessageRejectedException:
    Email address is not verified. The following identities failed:
    support@company.com"

  This appears 18 times per minute.

Step 5 — Context analysis:
  support@company.com is a sender email address.
  AWS SES (Simple Email Service) requires email verification.
  Error message: the sender email is not verified in SES.

  What changed?
  → Check Terraform history: terraform/environments/production/main.tf
  → 6 hours ago: someone changed `ses_from_email` from "noreply@company.com" (verified)
    to "support@company.com" (not verified in SES)
  → The change was in a completely different Terraform file (not DT-related)
  → DT didn't catch it as a "deployment event" because it's not a K8s change

ROOT CAUSE: Terraform change to SES sender email to an unverified address.
  notification-service SES calls fail → messages go to DLQ (18/min)
  No HTTP errors → no standard alert would catch this
  Only the custom message processing SLO detects it

FIX:
  1. Immediate: verify support@company.com in AWS SES (or revert to noreply@company.com)
  2. Process: add SES verified-identity check to Terraform → CI fails if unverified email used

LESSON: monitoring must extend beyond HTTP metrics.
  This entire incident was invisible to ALL standard SLOs (availability, latency, error rate).
  Only a custom application-level SLO (message processing rate) detected it.
```

---

## Part 4 — RCA Anti-Patterns (What NOT to Do)

```
❌ "The DB is slow" — not specific enough
✓  "The SELECT FROM payments WHERE user_id = ? query is slow because there is no
    index on user_id column, causing a full table scan on 52M rows"

❌ Starting with logs before checking the service map
✓  Always check service map first: is the problem in this service or coming from a dependency?

❌ "I fixed it" without verifying the metric recovered
✓  Watch the metric in real-time for 5 minutes after the fix.
    If P99 is still elevated: the fix didn't work. Don't close the incident yet.

❌ Confusing symptoms with root cause
✓  Symptom: "error rate is 2%"
   Root cause: "fraud-detection pods are OOM-killed because Xmx is too small"
   The symptom is what you observed. The root cause is what YOU CHANGE to fix it.

❌ Ignoring the deployment event because "the deploy was 2 hours ago, it can't be that"
✓  Memory leaks, gradual heap exhaustion, data migration side effects all appear hours later.
    Always check the last deployment, no matter how long ago it was.

❌ Working multiple symptoms as separate incidents
✓  Merge related incidents. One root cause, one fix, one resolution.
```

---

## RCA Time Budget (Production P1)

```
0–2 min:   Acknowledge PagerDuty. Open DT. Open Slack incident channel.
2–5 min:   Problems feed → Davis AI suggestion → note start time.
5–10 min:  Check deployments. Check service map. Is it isolated or a cascade?
10–15 min: Traces → find where time is spent. Metrics → correlate timeline.
15–20 min: Logs → find the exact exception. Form root cause hypothesis.
20–25 min: Apply fix (rollback, restart, config change). Watch metric chart.
25–30 min: Verify recovery. Resolve incident. Update stakeholders.

30 min total target for P1.
If not resolved in 30 min: escalate + keep working in parallel.
```
