# Missing GitHub Actions Workflows — Complete Set

> The project `38_java-3envs-dynatrace` currently has only 3 workflow files:
> terraform-dynatrace-dev, staging, production.
>
> A real 3-service, 3-environment Java project needs 8 workflows total.
> This document explains what's missing, WHY each workflow exists, and
> shows the complete final set.

---

## Decision Tree — Which Workflows Does This Project Need?

```
Do you have Terraform infrastructure (EKS, VPC, IAM)?
  YES → terraform-infra.yaml (plan all 3 envs on PR, apply on merge, drift detect daily)

Do you have Dynatrace Terraform (SLOs, alerts, synthetics)?
  YES, 3 environments → terraform-dynatrace-dev.yaml       ✓ EXISTS
                      → terraform-dynatrace-staging.yaml   ✓ EXISTS
                      → terraform-dynatrace-production.yaml ✓ EXISTS

Do you have Java application code to build and deploy?
  YES, 3 services →
    payment-service-ci.yaml     ← test → build → dev → smoke → staging → k6 → prod → verify
    order-service-ci.yaml       ← same pipeline pattern
    notification-service-ci.yaml ← same pipeline pattern

Do you have ArgoCD that needs bootstrapping?
  YES → already handled: kubectl apply -f root-app.yaml (one-time manual step, not a workflow)
```

---

## Complete Workflow Set (8 files)

```
.github/workflows/
│
├── terraform-infra.yaml              ← NEW: EKS/VPC/IAM for all 3 envs (one file, matrix)
│
├── terraform-dynatrace-dev.yaml          ← EXISTS
├── terraform-dynatrace-staging.yaml      ← EXISTS
├── terraform-dynatrace-production.yaml   ← EXISTS
│
├── payment-service-ci.yaml           ← NEW: test → build → dev → staging → prod
├── order-service-ci.yaml             ← NEW: same pipeline for order-service
└── notification-service-ci.yaml      ← NEW: same pipeline for notification-service
```

**What's missing = 4 files:**
1. `terraform-infra.yaml` — nobody has wired up CI for the EKS/VPC Terraform
2. `payment-service-ci.yaml` — no CI for the Java app code
3. `order-service-ci.yaml` — same
4. `notification-service-ci.yaml` — same

Without these 4 files:
- Changes to Terraform EKS config must be applied manually with `terraform apply`
- Changes to Java service code are never built, tested, or deployed automatically
- The entire "push code → users get new feature" loop is broken

---

## Part 1 — `terraform-infra.yaml` (NEW)

### What it does

One workflow file manages Terraform for all 3 environments using a matrix strategy.

```
on PR:   terraform plan runs for ALL 3 envs in parallel (matrix)
         → each plan posted as a PR comment
on merge: terraform apply runs for all 3 envs sequentially (max-parallel: 1)
          → dev applies first, then staging, then production
          → production has environment: production gate (manual approval)
on schedule (daily): drift detection runs plan -refresh-only
          → if exit code 2 (changes detected) → creates GitHub Issue automatically
```

### Why one file for 3 environments (not 3 separate files like Dynatrace)?

```
Dynatrace TF has separate files because:
  - Each DT env is independent (you may want to update only dev DT alerts)
  - Separate path triggers: dev DT changes don't trigger prod DT workflow

Infra TF uses a matrix because:
  - Infrastructure changes usually affect all 3 envs (e.g., EKS version upgrade)
  - You want to see ALL 3 plan outputs on one PR before merging
  - max-parallel: 1 ensures sequential apply (dev before prod)
  - One file is easier to maintain than 3 nearly-identical files
```

### Drift detection

```yaml
on:
  schedule:
    - cron: '0 2 * * *'   # runs every day at 2am Tokyo time
```

`terraform plan -refresh-only` compares the real AWS state to what Terraform expects.
If they differ (someone ran `kubectl edit`, manual console changes, etc.):
- Exit code 0 = no drift
- Exit code 2 = drift detected → GitHub Issue created automatically

Without drift detection: someone modifies EKS node group in AWS console → Terraform state is now wrong → next `terraform apply` overwrites their change without warning.

See: `.github/workflows/terraform-infra.yaml`

---

## Part 2 — `payment-service-ci.yaml` (NEW)

### What it does — 6 jobs in sequence

```
job 1: test
  Runs: ./gradlew test jacocoTestReport jacocoTestCoverageVerification
  Publishes: JUnit XML report to GitHub PR check
  Blocks: build-and-deploy-dev only runs if tests pass

job 2: build-and-deploy-dev  (push to main only)
  Builds:  Docker image (linux/amd64 + linux/arm64) via docker buildx
  Scans:   Trivy image scan → fails if CRITICAL or HIGH CVEs found
  Pushes:  to dev ECR (123456789010.dkr.ecr...)
  Updates: gitops/dev/app/payment-service/payment-service.yaml tag → git commit → git push
  Waits:   kubectl rollout status ... --timeout=8m

job 3: smoke-test-dev
  Hits:  /actuator/health/liveness, /actuator/health/readiness
  Hits:  POST /api/v1/payments with a test payload → asserts response.status == "created"
  Blocks: promote-to-staging only runs if smoke tests pass

job 4: promote-to-staging
  Pulls:   image from dev ECR
  Tags:    same IMAGE_TAG (git SHA) → pushes to staging ECR (123456789011.dkr.ecr...)
  Updates: gitops/staging/app/payment-service/payment-service.yaml
  Waits:   kubectl rollout status --timeout=10m

job 5: test-staging (load test)
  Runs:  k6 with 50 VUs for 3 minutes against staging URL
  Blocks: promote-to-production only runs if k6 passes

job 6: promote-to-production  (environment: production → manual approval gate)
  Pulls:   from staging ECR
  Pushes:  to prod ECR (123456789012.dkr.ecr...)
  Updates: gitops/production/app/payment-service/payment-service.yaml
  Waits:   kubectl rollout status --timeout=12m

job 7: verify-production
  Smoke tests production endpoints
  Auto-rollback: if smoke tests fail → reads previous tag from git log → reverts gitops YAML → pushes
```

### The IMAGE_TAG — why `github.sha`

```
env:
  IMAGE_TAG: ${{ github.sha }}

Every git commit has a unique 40-character SHA (e.g., "a1b2c3d4...").
Using it as the image tag means:
  - Every build produces a unique, traceable tag
  - "What code is running in production?" → read the tag → find the commit in git
  - No overwriting: "latest" tags are also pushed (ECR_DEV:latest-dev) as a convenience
    but the SHA tag is what ArgoCD actually uses

If you used "latest" only:
  - Two engineers push at the same time → one overwrites the other's image
  - "What's deployed in production?" → "latest"... which latest?
```

### Why separate ECR per account (not one shared ECR)

```
Dev pushes build to:  123456789010.dkr.ecr.../payment-service:a1b2c3
Staging promote to:   123456789011.dkr.ecr.../payment-service:a1b2c3
Prod promote to:      123456789012.dkr.ecr.../payment-service:a1b2c3

SAME SHA tag flows through all 3 ECRs.
prod ECR can only be written by the github-actions role in account 123456789012.
A dev engineer cannot push directly to prod ECR — they'd need the prod IAM role.

If one shared ECR:
  Any engineer could push any image tagged "latest" and it could be deployed to prod.
```

### Why `[skip ci]` in the gitops commit message

```
git commit -m "chore(deploy-dev): payment-service=a1b2c3 [skip ci]"

The workflow updates a gitops YAML file and commits it back to the repo.
That commit would normally trigger the workflow again (push → workflow starts → update → commit → trigger → loop).
[skip ci] tells GitHub Actions: do NOT trigger workflows from this commit.
Without it: infinite loop of CI runs.
```

See: `.github/workflows/payment-service-ci.yaml`

---

## Part 3 — `order-service-ci.yaml` and `notification-service-ci.yaml` (NEW)

Same pipeline structure as payment-service-ci.yaml. Key differences:

| | payment-service | order-service | notification-service |
|--|---|---|---|
| ECR_DEV | `.../payment-service` | `.../order-service` | `.../notification-service` |
| Smoke test endpoint | `POST /api/v1/payments` | `POST /api/v1/orders` | `GET /actuator/health` only |
| Load test script | `payment-load-test.js` | `order-load-test.js` | `notification-load-test.js` |
| k6 VUs | 50 for 3 min | 50 for 3 min | 20 for 2 min (async, lower) |
| Rollout timeout prod | 12 min | 10 min | 8 min |
| Namespace | `payment-ns` | `order-ns` | `notification-ns` |
| gitops path | `gitops/*/app/payment-service/` | `gitops/*/app/order-service/` | `gitops/*/app/notification-service/` |

notification-service smoke test is simpler — it's async so there's no synchronous API to assert against:
```bash
# notification-service smoke test — health only (no synchronous business assertion)
curl -sf https://notify.dev.company.com/actuator/health/liveness
curl -sf https://notify.dev.company.com/actuator/health/readiness
# Check DLQ is empty (indirect health check)
aws sqs get-queue-attributes \
  --queue-url https://sqs.ap-northeast-1.amazonaws.com/123456789010/notification-dlq \
  --attribute-names ApproximateNumberOfMessages \
  --query 'Attributes.ApproximateNumberOfMessages' | grep -q '"0"'
```

See: `.github/workflows/order-service-ci.yaml` and `notification-service-ci.yaml`

---

## Part 4 — How All 8 Workflows Connect

```
                    ┌─────────────────────────────────────────────┐
                    │              Git push to main               │
                    └──────────────────┬──────────────────────────┘
                                       │
          ┌────────────────────────────┼────────────────────────────┐
          │                            │                            │
          ▼                            ▼                            ▼
terraform/environments/**    services/payment-service/**   services/order-service/**
terraform/modules/**         charts/payment-service/**     charts/order-service/**
          │                            │                            │
          ▼                            ▼                            ▼
terraform-infra.yaml       payment-service-ci.yaml      order-service-ci.yaml
(EKS/VPC/IAM apply)        (test→build→dev→stg→prod)    (test→build→dev→stg→prod)
                                                    
services/notification-service/**       terraform/environments/dev/**
charts/notification-service/**         terraform/modules/dynatrace/**
          │                                         │
          ▼                                         ▼
notification-service-ci.yaml         terraform-dynatrace-dev.yaml
(test→build→dev→stg→prod)            terraform-dynatrace-staging.yaml
                                     terraform-dynatrace-production.yaml

ArgoCD (not a workflow):
  Watches gitops/<env>/app/<service>/
  When CI commits new image tag → ArgoCD detects → rolling update
```

### Which workflow runs on which path change

| File changed | Workflow triggered |
|---|---|
| `services/payment-service/**` | `payment-service-ci.yaml` |
| `charts/payment-service/**` | `payment-service-ci.yaml` |
| `services/order-service/**` | `order-service-ci.yaml` |
| `charts/order-service/**` | `order-service-ci.yaml` |
| `services/notification-service/**` | `notification-service-ci.yaml` |
| `charts/notification-service/**` | `notification-service-ci.yaml` |
| `terraform/environments/dev/**` | `terraform-dynatrace-dev.yaml` + `terraform-infra.yaml` |
| `terraform/modules/dynatrace/**` | all 3 `terraform-dynatrace-*.yaml` |
| `terraform/modules/eks/**` or `vpc/**` | `terraform-infra.yaml` |
| `gitops/**` | NOTHING — ArgoCD watches this directly, no CI needed |

Why `gitops/**` triggers no workflow: ArgoCD polls the repo every 3 minutes and handles all gitops changes itself. A GitHub Actions workflow for gitops would just be a slower, less reliable ArgoCD.

---

## Common Mistakes With This Workflow Setup

| Mistake | Symptom | Fix |
|---------|---------|-----|
| Missing `[skip ci]` in gitops commit | Infinite workflow loop (commit → trigger → commit → trigger) | Add `[skip ci]` to all bot git commits |
| Using `latest` as image tag | "What's deployed?" is unanswerable; concurrent pushes overwrite each other | Use `${{ github.sha }}` as the canonical tag |
| `paths:` not including chart changes | Helm values change (e.g., increase replica count) doesn't trigger a build | Include `charts/<service>/**` in paths |
| No Trivy scan before ECR push | Vulnerable image deployed to production | Add `aquasecurity/trivy-action` after build, before ECR push |
| No auto-rollback in verify-production | Bad deploy stays up until engineer manually rolls back | Add `if: failure()` step that reverts the gitops YAML tag |
| terraform-infra paths include dynatrace module | Every DT threshold change triggers EKS infrastructure plan | Use separate paths: `terraform/modules/eks/**` and `terraform/modules/vpc/**` |
| No drift detection | Manual AWS console change silently breaks Terraform state | Add `schedule: cron` job with `plan -refresh-only -detailed-exitcode` |
