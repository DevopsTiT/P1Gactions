# Glossary — Missing GitHub Actions Workflows
Every term from main.md and the workflow files. One entry per term. SRE beginner level.

---

**GitHub Actions**
A CI/CD system built into GitHub. You write YAML files in `.github/workflows/` that describe jobs to run automatically when code is pushed, a PR is opened, or on a schedule. Why it matters: this is the automation layer that turns "engineer pushes code" into "users get new feature."

**CI/CD (Continuous Integration / Continuous Delivery)**
CI = automatically test and build code on every change. CD = automatically deploy that tested code to environments. Why it matters: without CI/CD, deployments are manual, error-prone, and slow. With it: push to main → tests run → image builds → staging deploys → production deploys automatically.

**Workflow**
One YAML file in `.github/workflows/`. Defines: when to run (triggers), what to run (jobs), and in what order (needs:). Why it matters: each workflow handles one concern — infrastructure, service CI, etc. 8 workflows = 8 separate automation concerns.

**Job**
One named unit of work inside a workflow. Each job runs on its own fresh Ubuntu machine (runner). Jobs can run in parallel (default) or sequentially (using `needs:`). Why it matters: the pipeline jobs (test → build → dev → staging → prod) are sequential — each must pass before the next runs.

**`needs:`**
Declares that a job must wait for another job to succeed before starting. `needs: smoke-test-dev` means "only run this job if smoke-test-dev passed." Why it matters: prevents deploying to staging if smoke tests failed in dev.

**`paths:`**
A trigger filter that only activates the workflow if the pushed commit changed files matching these patterns. `paths: ['services/payment-service/**']` means: only run if a file inside `services/payment-service/` changed. Why it matters: changing notification-service code should not trigger payment-service CI.

**`on: push` vs `on: pull_request`**
`push` = workflow runs after the PR is MERGED to main (runs apply/deploy jobs). `pull_request` = runs while the PR is OPEN (runs plan/test jobs). Why it matters: you see the Terraform plan BEFORE merging, and apply AFTER merging.

**`on: schedule: cron`**
Runs the workflow on a time schedule, not triggered by code changes. `0 2 * * *` = every day at 2:00 UTC. Why it matters: drift detection must run regularly to catch manual changes made outside of Terraform.

**`workflow_dispatch`**
Lets engineers trigger a workflow manually from the GitHub UI (with optional inputs). Why it matters: lets you manually run `terraform apply` for a specific environment without needing to push a commit.

**Matrix strategy**
Runs the same job multiple times with different variable values. `matrix: environment: [dev, staging, production]` creates 3 parallel jobs, one per environment. Why it matters: one workflow file handles all 3 environments — no code duplication.

**`fail-fast: false`**
By default, if one matrix job fails, GitHub cancels the remaining jobs. `fail-fast: false` lets all matrix jobs complete even if one fails. Why it matters: you want to see ALL 3 Terraform plans even if the dev plan has an error.

**`max-parallel: 1`**
In a matrix, `max-parallel: 1` runs only one matrix job at a time (sequentially). Why it matters: Terraform apply must run dev before staging before production — you don't want prod to apply while dev is still applying.

**`environment: production`**
Tells GitHub Actions this job requires the "production" environment, which can have protection rules (required reviewers, wait timers). The job PAUSES until a human clicks Approve. Why it matters: prevents code from automatically reaching production without a human sign-off.

**GitHub Environment (not Kubernetes namespace)**
A GitHub concept (not related to Kubernetes) that groups deployment targets (dev, staging, production) with protection rules and secrets. Why it matters: `environment: production` in a job adds the manual approval gate and gives access to production-specific secrets.

**OIDC (OpenID Connect) role assumption**
`permissions: { id-token: write }` + `aws-actions/configure-aws-credentials@v4 role-to-assume: arn:...` lets a GitHub Actions job assume an AWS IAM role via a JWT token — no access keys stored as secrets. Why it matters: no static AWS credentials in GitHub Secrets, no credential rotation needed.

**`github.sha`**
A built-in GitHub Actions variable containing the 40-character git commit hash (SHA) of the current commit. Example: `a1b2c3d4e5f6...`. Why it matters: used as the Docker image tag — every build has a unique, traceable tag that maps exactly to a commit in git history.

**`IMAGE_TAG: ${{ github.sha }}`**
Sets the image tag to the git commit SHA for all ECR push/pull operations in the workflow. Why it matters: the same SHA flows through dev ECR → staging ECR → production ECR, ensuring the same binary is tested at every stage.

**ECR (Elastic Container Registry)**
AWS managed Docker image registry. Each AWS account (`123456789010` dev, `123456789011` staging, `123456789012` prod) has its own ECR. Why it matters: images must be explicitly promoted (pulled from dev ECR, pushed to staging ECR) — no accidental cross-environment deploys.

**Image promotion**
Pulling a Docker image from one ECR (dev) and re-tagging + pushing it to another ECR (staging/production). The image binary is identical — only the registry location changes. Why it matters: guarantees that exactly the image that passed tests in dev is what gets deployed to production.

**`docker buildx` / `linux/amd64,linux/arm64`**
Builds a multi-architecture Docker image. `amd64` = Intel/AMD CPUs (dev/CI runners). `arm64` = ARM/Graviton CPUs (staging/production EKS nodes use AWS Graviton for cost savings). Why it matters: without multi-arch build, an amd64 image would fail to run on Graviton arm64 production nodes.

**Trivy**
An open-source container security scanner. Scans a Docker image for known CVEs (Common Vulnerabilities and Exposures) in OS packages and Java dependencies. Why it matters: `exit-code: "1"` makes the workflow fail if CRITICAL or HIGH CVEs are found — prevents deploying vulnerable images to production.

**Trivy `exit-code: "1"`**
Makes the workflow step fail (and stop the pipeline) if vulnerabilities of the specified severity are found. `severity: CRITICAL,HIGH` + `exit-code: "1"` = pipeline blocked on serious CVEs. Why it matters: enforces that production images are scanned and clean before being deployed.

**`sed -i "s|tag: \".*\"|tag: \"$SHA\"|"`**
A shell command that finds the line `tag: "anything"` in a file and replaces it with `tag: "current-sha"`. Updates the gitops YAML with the new image tag. Why it matters: this is how CI tells ArgoCD "deploy this specific image version."

**`[skip ci]`**
A special string in a git commit message that tells GitHub Actions: "do NOT trigger any workflows from this commit." Why it matters: the workflow itself pushes a commit (the gitops tag update) — without `[skip ci]`, that commit would re-trigger the workflow → infinite loop.

**Smoke test**
A quick, basic test that checks whether the service is alive and able to handle a minimal request. Not a full test suite — just enough to confirm the deployment didn't break fundamental functionality. Why it matters: catches obviously broken deploys (crash on startup, wrong config) before they reach staging or production.

**`curl -sf`**
`-s` = silent (no progress output). `-f` = fail-fast: curl returns exit code 1 if HTTP response is 4xx or 5xx (instead of printing the error body and returning 0). Why it matters: without `-f`, `curl` would return exit code 0 even for a 404 or 503, hiding the problem.

**`/actuator/health/liveness`**
Spring Boot Actuator endpoint that returns 200 if the application is alive (JVM is running, basic startup complete). Used by Kubernetes liveness probes. Why it matters: a 200 here means the service started successfully — checked after every deploy.

**`/actuator/health/readiness`**
Spring Boot Actuator endpoint that returns 200 if the application is ready to serve traffic (all dependencies connected: DB, cache, message queue). Used by Kubernetes readiness probes. Why it matters: a 200 here means traffic can be sent to this pod — confirms the deploy is fully operational.

**`kubectl rollout status`**
Waits until a Kubernetes Deployment finishes its rolling update (all new pods are Running and Ready, all old pods are terminated). `--timeout=8m` gives up after 8 minutes. Why it matters: confirms the new image is actually deployed and healthy before running smoke tests against it.

**Rolling update**
Kubernetes replaces pods one at a time (or a few at a time) rather than all at once. New pods start, pass readiness checks, then old pods are terminated. Why it matters: zero-downtime deployment — traffic is always being served by at least some healthy pods during the update.

**k6**
An open-source load testing tool that runs JavaScript-based load test scripts. `k6 run --vus 50 --duration 3m` = 50 virtual users sending requests for 3 minutes. Why it matters: validates that the service can handle expected load levels before promoting to production.

**VUs (Virtual Users)**
k6 concept: concurrent simulated users each sending requests continuously. 50 VUs for 3 minutes = up to 50 simultaneous requests at any moment. Why it matters: validates throughput and latency under realistic concurrent load, not just single-request smoke test correctness.

**Auto-rollback**
When production smoke tests fail after a deploy, the workflow reads the PREVIOUS image tag from git history, reverts the gitops YAML to that tag, and commits + pushes. ArgoCD detects the revert commit and rolls the deployment back to the previous version. Why it matters: reduces the time a bad deploy is live in production from "until engineer wakes up and manually rolls back" to "within 2-3 minutes automatically."

**`git log --oneline -- path`**
Lists commits that touched a specific file, one commit per line. `awk 'NR==2'` takes the second line (the commit BEFORE the current deploy). Why it matters: the rollback logic reads the previous image tag from git history to know what version to revert to.

**`terraform plan -refresh-only -detailed-exitcode`**
A special Terraform mode that only checks whether real AWS state matches Terraform state, without proposing any changes to config. Exit code 0 = no drift, exit code 2 = drift found. Why it matters: catches manual changes to AWS infrastructure (console, CLI) that Terraform doesn't know about.

**Drift**
When real infrastructure state diverges from what Terraform believes (and has stored in state file). Example: someone manually increased the EKS node group from 3 to 5 in the AWS console. Terraform state still says 3. Why it matters: next `terraform apply` would reset it back to 3, undoing the manual change without warning.

**`GITHUB_OUTPUT`**
A file GitHub Actions uses to pass values between steps within a job. `echo "exit_code=2" >> "$GITHUB_OUTPUT"` makes `exit_code` accessible as `steps.drift.outputs.exit_code` in later steps. Why it matters: the drift detection step passes its exit code to the "create GitHub Issue" step, which only runs if exit code = 2.

**`jacocoTestCoverageVerification`**
A Gradle task that runs the JaCoCo code coverage check — fails if test coverage falls below the configured minimum (e.g., 80%). Why it matters: prevents merging code changes that aren't covered by tests, catching untested code paths before they become bugs in production.

**`actions/cache@v4`**
GitHub Actions step that saves and restores a directory between workflow runs. Used for Gradle build cache (`.gradle` folder). Why it matters: Gradle downloads dependencies and caches compiled classes — caching saves 1-3 minutes per workflow run by not re-downloading dependencies every time.

**DLQ (Dead Letter Queue)**
A separate SQS queue where messages go after failing to process N times. The notification-service smoke test checks this queue's approximate message count. Why it matters: a non-empty DLQ after a deploy means the new code broke message processing — caught by the smoke test before promoting to staging.
