# CI/CD Pipeline Implementation and Management — SRE Deep Dive

> **Who this is for:** An SRE who needs to understand how CI/CD pipelines are designed, implemented, operated, and debugged — using this project's 8 GitHub Actions workflows as the concrete reference.

---

## Decision Tree — What Triggers What

```
Engineer pushes code to main (or opens a PR)
         │
         ├── changed services/payment-service/** OR charts/payment-service/**
         │         └── payment-service-ci.yaml
         │               PR:  job 1 (test) only
         │               Push: job 1 → 2 → 3 → 4 → 5 → 6 (manual) → 7
         │
         ├── changed services/order-service/** OR charts/order-service/**
         │         └── order-service-ci.yaml (same structure)
         │
         ├── changed services/notification-service/** OR charts/notification-service/**
         │         └── notification-service-ci.yaml (async-aware differences)
         │
         ├── changed terraform/environments/** OR terraform/modules/eks|vpc/**
         │         └── terraform-infra.yaml
         │               PR:  parallel plan for all 3 envs (matrix)
         │               Push: sequential apply dev → staging → prod (manual gate)
         │               Daily 02:00 JST: drift detection
         │
         ├── changed terraform/environments/dev/** OR terraform/modules/dynatrace/**
         │         └── terraform-dynatrace-dev.yaml
         │
         ├── changed terraform/environments/staging/**
         │         └── terraform-dynatrace-staging.yaml
         │
         ├── changed terraform/environments/production/**
         │         └── terraform-dynatrace-production.yaml (+ manual gate)
         │
         └── changed gitops/**
                   └── NOTHING — ArgoCD watches Git directly, no CI needed
```

---

## Part 1 — CI/CD Philosophy in This Project

### The three guarantees

Every pipeline in this project enforces three non-negotiable guarantees:

```
1. NEVER deploy untested code
   Tests must pass before any Docker image is built.
   Coverage must be ≥70% before any image is built.
   If tests fail → pipeline stops. No exceptions.

2. NEVER deploy to production without staging validation
   Same image that passed dev smoke tests is promoted to staging.
   Staging must survive k6 load tests before production promotion.
   Manual approval required before production deploy.
   Identical bits flow dev → staging → production (cross-account copy).

3. NEVER leave production broken
   Smoke tests run after production deploy.
   If they fail: automatic rollback to previous version within minutes.
   No manual intervention required to recover.
```

### Why separate pipelines per service (not one mega-pipeline)

```
ONE PIPELINE for all services:
  Every code change triggers the full pipeline for ALL services
  Payment engineer fixes payment bug → order and notification also test/build/deploy
  Issues:
    - Wasted compute (building unchanged services)
    - Order deploy gates payment deploy (if order tests are flaky, payment can't deploy)
    - Longer cycle time (3× the work per engineer change)
    - No isolation: a broken notification pipeline blocks all deployments

SEPARATE PIPELINE per service:
  payment-service changes → only payment-service pipeline runs
  Each service is independently deployable
  One service's broken pipeline doesn't block others
  Engineers can work in parallel on different services
```

### Trunk-based development

All pipelines trigger on pushes/PRs to `main` only. There are no long-lived feature branches with separate pipelines. Engineers merge frequently (trunk-based) which means:
- Small diffs per deploy → easier rollback
- No "big bang" merges that break everything at once
- Pipeline feedback within minutes, not days

---

## Part 2 — Anatomy of a GitHub Actions Workflow File

### The trigger block

```yaml
on:
  push:
    branches: [main]
    paths:
      - 'services/payment-service/**'
      - 'charts/payment-service/**'
  pull_request:
    branches: [main]
    paths:
      - 'services/payment-service/**'
      - 'charts/payment-service/**'
```

**`paths:` filter:** GitHub evaluates this BEFORE starting any runners. If no files in the listed paths changed, the workflow is completely skipped — no runner is started, no cost. A commit that only changes `README.md` doesn't trigger payment-service CI.

**Why both `services/` and `charts/` paths:**
```
services/payment-service/** → Java source code changed → rebuild Docker image
charts/payment-service/**   → Helm values changed → redeploy without image rebuild

Example: Engineer raises replicaCount from 3 to 5 in values.yaml.
  No Java code changed. No new Docker image needed.
  BUT: the change must be deployed (ArgoCD must apply the new values).
  
  Without charts/ in paths: values change → no CI → ArgoCD deploys nothing
    (ArgoCD only deploys when gitops/ files change; values/ changes require CI to update gitops/)
  With charts/ in paths: values change → CI triggers → test → build (same image) → update gitops tag
    (actually: CI skips build if image already exists, but updates gitops to force re-render)
```

**`push` vs `pull_request` events:**
```yaml
push:
  → merge to main happened
  → Run ALL jobs including deploy (build-and-deploy-dev, promote-to-staging, etc.)
  
pull_request:
  → PR opened or updated
  → Run ONLY the test job (fast feedback on code quality)
  → Deploy jobs have: if: github.event_name == 'push'
  → They are SKIPPED on PRs
```

### The `env:` block — pipeline constants

```yaml
env:
  AWS_REGION:     ap-northeast-1
  IMAGE_TAG:      ${{ github.sha }}        ← unique per commit
  JAVA_VERSION:   '21'
  ECR_DEV:        123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  ECR_STAGING:    123456789011.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  ECR_PRODUCTION: 123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
```

`${{ github.sha }}`: the 40-character git commit SHA. Used as the Docker image tag because:
- **Unique**: every commit = unique tag. Two engineers pushing at the same time get different tags.
- **Traceable**: `git show abc1234` shows exactly what code is in that image. `git log --oneline` correlates deploys to commits.
- **Immutable**: a specific SHA tag never changes. `:latest` can be overwritten.
- **Same bits flow through all 3 ECRs**: the promotion steps copy the same SHA from dev → staging → prod ECR. The identical image reaches production — no rebuild.

### Job dependencies — `needs:`

```yaml
jobs:
  test:                    # no needs: runs immediately
  build-and-deploy-dev:
    needs: test            # waits for test to succeed
  smoke-test-dev:
    needs: build-and-deploy-dev
  promote-to-staging:
    needs: smoke-test-dev
  test-staging:
    needs: promote-to-staging
  promote-to-production:
    needs: test-staging
  verify-production:
    needs: promote-to-production
```

This creates a **sequential pipeline graph**:
```
test → build-dev → smoke-dev → promote-staging → k6-staging → [MANUAL] → promote-prod → verify-prod
```

If ANY job fails, ALL downstream jobs are automatically skipped. If `test` fails, no image is built. If `smoke-test-dev` fails, staging is never touched.

### Permissions — minimal by default

```yaml
permissions:
  id-token: write    # required for OIDC AWS authentication
  contents: write    # required for git push (gitops YAML update)
  pull-requests: write  # required for posting plan comments to PRs
```

GitHub Actions uses the principle of least privilege. Jobs only declare the permissions they need. `build-and-deploy-dev` needs `id-token: write` + `contents: write`. The `test` job needs neither — it only reads code.

Why this matters: if a malicious PR somehow runs the `test` job and exfiltrates the runner's token, that token has no write permissions — it can't push code or call AWS APIs.

---

## Part 3 — The Service CI Pipeline (7 Jobs)

### Job 1: `test` — quality gate

```yaml
test:
  name: Unit Tests + Coverage
  runs-on: ubuntu-latest
  steps:
    - uses: actions/checkout@v4

    - uses: actions/setup-java@v4
      with:
        java-version: '21'
        distribution: 'temurin'
        cache: 'gradle'          ← caches ~/.gradle/caches between runs

    - uses: actions/cache@v4
      with:
        path: services/payment-service/.gradle
        key: ${{ runner.os }}-gradle-payment-${{ hashFiles('services/payment-service/build.gradle') }}
        restore-keys: ${{ runner.os }}-gradle-payment-

    - name: Run tests + coverage
      working-directory: services/payment-service
      run: ./gradlew test jacocoTestReport jacocoTestCoverageVerification --no-daemon

    - uses: mikepenz/action-junit-report@v4
      if: always()
      with:
        report_paths: 'services/payment-service/build/test-results/test/*.xml'
        check_name: 'payment-service JUnit'
```

**Gradle cache strategy:**
```
Key: OS + "gradle-payment" + hash(build.gradle)
→ If build.gradle hasn't changed: exact cache hit → dependencies served from cache (~5 sec vs ~2 min download)
→ If build.gradle changed (new dependency): cache miss → re-download → new cache saved

restore-keys: ${{ runner.os }}-gradle-payment-
→ Fallback: use the most recent cache for this service regardless of build.gradle hash
→ Partial cache hit: downloads only what's new, not everything
```

**Three Gradle tasks in sequence:**
```
./gradlew test jacocoTestReport jacocoTestCoverageVerification --no-daemon

1. test
   → Runs all JUnit 5 tests
   → Uses Testcontainers for real PostgreSQL (not mocked)
   → Produces: build/test-results/test/*.xml (JUnit XML format)
   → If ANY test fails: Gradle task fails → CI step fails → pipeline stops

2. jacocoTestReport
   → Reads test execution data
   → Generates: build/reports/jacoco/test/jacocoTestReport.xml
   → This file shows which lines were and weren't executed

3. jacocoTestCoverageVerification
   → Reads the jacocoTestReport
   → Checks: line coverage >= 70%
   → If below 70%: Gradle task FAILS
   → CI step fails → pipeline stops → no Docker image is built
   
--no-daemon
   → Disables the Gradle daemon (persistent background process)
   → Safer in CI: each run is isolated, no state from previous builds
   → Slightly slower but more reliable
```

**`if: always()` on JUnit report:**
```
Default behavior: if previous step fails, ALL subsequent steps are skipped.
With if: always(): this step runs regardless of whether tests passed or failed.

Why: the JUnit XML report is MOST valuable when tests fail.
Engineers want to see which specific tests failed directly in the PR diff view,
not just "tests failed" in the log.
Without if: always(): test failure → no report posted → engineer must dig through logs.
```

### Job 2: `build-and-deploy-dev` — image creation and first deploy

```yaml
build-and-deploy-dev:
  needs: test
  if: github.event_name == 'push'   ← skipped on PRs
  environment: dev
  permissions:
    id-token: write
    contents: write
```

**OIDC Authentication flow:**
```
1. GitHub Actions requests an OIDC token from GitHub's OIDC provider
   Token claims: repository=company/java-3envs, ref=refs/heads/main, workflow=payment-service-ci
   
2. aws-actions/configure-aws-credentials@v4 exchanges this token for AWS STS credentials
   by calling: sts:AssumeRoleWithWebIdentity
   IAM role trust policy allows: token from repo=company/java-3envs AND ref=refs/heads/main
   
3. STS returns: temporary access key + secret key + session token
   Valid for: 15 minutes (default)
   Permissions: only what the IAM role has (ECR push, Secrets Manager read, etc.)
   
4. These credentials are set as environment variables for subsequent steps
   They expire automatically after the job ends

No stored secrets. No long-lived credentials. Nothing to rotate.
A stolen session token expires in 15 minutes.
```

**Multi-arch Docker build:**
```yaml
- uses: docker/setup-buildx-action@v3
- uses: docker/build-push-action@v5
  with:
    platforms: linux/amd64,linux/arm64
    tags: |
      ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
      ${{ env.ECR_DEV }}:latest-dev
    cache-from: type=gha
    cache-to: type=gha,mode=max
```

**`linux/amd64` + `linux/arm64`:**
```
EKS node types:
  m5.xlarge  → Intel/AMD (x86_64 = amd64)
  m7g.xlarge → AWS Graviton ARM (arm64)
  
  Graviton nodes are ~20% cheaper for the same workload.
  
Without multi-arch: image built for amd64 only.
  Graviton node tries to run amd64 image → "exec format error" → CrashLoopBackOff
  
With multi-arch: one image works on both node types.
  K8s scheduler can place pods on either type.
  Cost savings without any code changes.

docker/setup-buildx-action: sets up BuildKit with QEMU emulation.
  QEMU lets the amd64 runner cross-compile for arm64.
  Takes ~3-4 minutes for the arm64 build (emulation is slower than native).
```

**Docker layer caching:**
```yaml
cache-from: type=gha
cache-to: type=gha,mode=max
```
GitHub Actions Cache stores Docker image layers. On first build: all layers built fresh, cached. On subsequent builds: unchanged layers (base JRE ~150MB, dependencies ~80MB) served from cache. Only changed layers (application code ~2MB) rebuilt. Build time: 5-8 min → 60-90 sec.

**Trivy security scan:**
```yaml
- name: Trivy vulnerability scan
  uses: aquasecurity/trivy-action@master
  with:
    image-ref: ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
    severity: 'CRITICAL,HIGH'
    exit-code: '1'
    ignore-unfixed: true
```

The scan happens AFTER pushing to ECR but BEFORE updating gitops. If CRITICAL or HIGH CVEs are found: the step exits with code 1 → pipeline stops → gitops is never updated → ArgoCD never sees the new image → the vulnerable image is never deployed.

`ignore-unfixed: true`: CVEs with no available fix are skipped. These are not actionable — you can't patch a vulnerability that has no patch yet. Without this flag: every CVE (including unfixable ones in base OS) fails the build, blocking all deployments until the CVE has a fix.

**Gitops update — the GitOps delivery mechanism:**
```bash
sed -i "s|tag: \".*\"|tag: \"${{ env.IMAGE_TAG }}\"|" \
  gitops/dev/app/payment-service/payment-service.yaml
git config user.email "github-actions[bot]@users.noreply.github.com"
git config user.name  "github-actions[bot]"
git add gitops/dev/app/payment-service/payment-service.yaml
git diff --staged --quiet || \
  git commit -m "chore(deploy-dev): payment-service=${{ env.IMAGE_TAG }} [skip ci]"
git push
```

**`sed -i "s|tag: \".*\"|tag: \"$SHA\"|"`:**
Replaces any existing `tag: "anything"` with the new SHA. Works whether the file contains `"PLACEHOLDER"` (first deploy), a previous SHA, or the same SHA (idempotent).

**`git diff --staged --quiet || git commit`:**
If the tag is already the same SHA (re-running CI on the same commit — e.g., a retried pipeline), `git diff --staged --quiet` exits 0 (no staged changes) → `||` skips the commit. Without this guard: an empty commit would fail with "nothing to commit" → pipeline error on legitimate retries.

**`[skip ci]`:**
```
CI triggers on every push to main.
CI just pushed a new commit to main (the gitops tag update).
That push would re-trigger CI → CI pushes again → infinite loop.

[skip ci] in the commit message tells GitHub Actions:
  "Do NOT run any workflows for this commit."
  
Without [skip ci]: infinite loop consuming compute and time until manually cancelled.
With [skip ci]: loop broken. Only the original commit triggers CI.
```

**Wait for rollout:**
```bash
sleep 30   # give ArgoCD 3-minute poll cycle time to detect the commit
aws eks update-kubeconfig --name company-dev --alias dev --region ${{ env.AWS_REGION }}
kubectl rollout status deployment/payment-service \
  -n payment-ns --context dev --timeout=8m
```

`kubectl rollout status` blocks until:
- **Success**: all pods are updated (new image running and passing readiness probes)
- **Timeout**: 8 minutes elapsed → step fails → downstream jobs skip

Why wait: smoke tests must run against the NEW pods, not the old ones still running during a rolling update. Without waiting: smoke tests might hit the old version and pass → staging gets an untested version.

### Job 3: `smoke-test-dev` — functional validation

```bash
# Health layer:
curl -sf https://payment.dev.company.com/actuator/health/liveness  || exit 1
curl -sf https://payment.dev.company.com/actuator/health/readiness || exit 1

# Application layer:
RESPONSE=$(curl -sf -X POST \
  -H 'Content-Type: application/json' \
  -d '{"amount":100,"currency":"JPY","userId":"smoke-test"}' \
  https://payment.dev.company.com/api/v1/payments)

echo "$RESPONSE" | python3 -c "
import json, sys
d = json.load(sys.stdin)
assert d.get('status') == 'created', f'Expected status=created, got: {d}'
print('✅ payment-service smoke tests passed')
"
```

**Two independent test layers:**

Layer 1 — Infrastructure: `curl /actuator/health/liveness` + `readiness`
→ Tests: DNS resolves, ALB is routing, TLS cert is valid, pod is alive and ready

Layer 2 — Application: `POST /api/v1/payments`
→ Tests: Spring Boot started, DB connection pool is alive, business logic returns correct response

**A deploy that breaks the DB connection** passes layer 1 (pod is alive, health probe passes) but fails layer 2 (DB query fails → 500 → incorrect response). Without the application-layer check: this broken deploy would proceed to staging.

**`-sf` curl flags:**
- `-s` (silent): suppresses progress meter and error messages
- `-f` (fail): exits with code 22 if HTTP status ≥ 400
Combined: no output noise, and non-2xx responses fail the step.

**notification-service smoke test difference:**
```bash
# No synchronous business API test — notification is async
# Instead: check the SQS Dead Letter Queue
DLQ_DEPTH=$(aws sqs get-queue-attributes \
  --queue-url https://sqs.ap-northeast-1.amazonaws.com/123456789010/notification-dlq \
  --attribute-names ApproximateNumberOfMessages \
  --query 'Attributes.ApproximateNumberOfMessages' --output text)
if [ "$DLQ_DEPTH" != "0" ]; then exit 1; fi
```

`POST /api/v1/notifications` always returns `{"status":"queued"}` immediately. The response is correct even when SQS publish is broken — the API doesn't wait for SQS. A DLQ check catches silent async failures that a synchronous API check would miss entirely.

### Job 4: `promote-to-staging` — cross-account image copy

```yaml
# Step 1: Authenticate to DEV account (source)
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789010:role/github-actions-ecr-read
- uses: aws-actions/amazon-ecr-login@v2
  with: { registries: "123456789010" }

# Step 2: Authenticate to STAGING account (destination)
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789011:role/github-actions-ecr-push
- uses: aws-actions/amazon-ecr-login@v2
  with: { registries: "123456789011" }

# Copy the image
- run: |
    docker pull ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }}
    docker tag  ${{ env.ECR_DEV }}:${{ env.IMAGE_TAG }} ${{ env.ECR_STAGING }}:${{ env.IMAGE_TAG }}
    docker push ${{ env.ECR_STAGING }}:${{ env.IMAGE_TAG }}
```

**Why cross-account (not one shared ECR):**
```
Security boundary:
  Production ECR is in AWS account 123456789012.
  Writing to prod ECR requires: arn:aws:iam::123456789012:role/github-actions-ecr-push
  
  A dev engineer with dev account (123456789010) credentials:
    → Cannot assume a role in account 123456789012
    → Cannot push anything to prod ECR directly
    → The only path to prod ECR is through CI, which requires:
        a. Tests passing
        b. Smoke tests passing
        c. k6 load test passing
        d. Manual approval
  
  If one shared ECR:
    Any engineer with ECR push permission could push any image to any tag
    including ":production-latest" which bypasses all quality gates
```

**Why the same SHA tag flows through all three ECRs:**
```
Dev ECR:  payment-service:abc1234def5678...  ← built from source
Staging:  payment-service:abc1234def5678...  ← copied from dev (same bytes)
Prod ECR: payment-service:abc1234def5678...  ← copied from staging (same bytes)

The SHA proves the identical image reached production.
If you rebuilt the image at each stage: different environment variables,
different OS package versions, different base image caches → "works in dev
but fails in prod" mysteries.
```

**`git pull origin main` before gitops update:**
```bash
git pull origin main   # fetch latest before updating
sed -i ...
git commit ...
git push
```

Between the test job finishing and this job running, other pipelines (order-service, notification-service) may have committed gitops updates to the same repo. Without `git pull` first: git push fails with "rejected - non-fast-forward" because the local repo is behind main.

### Job 5: `test-staging` — load test

```yaml
- name: k6 load test
  run: |
    k6 run \
      --vus 50 \
      --duration 3m \
      --env BASE_URL=https://payment.staging.company.com \
      services/payment-service/tests/load/load-test.js
```

**What k6 does:**
- Runs `load-test.js` which defines: what requests to send, in what pattern, with what assertions
- 50 virtual users (goroutines) simultaneously sending requests for 3 minutes
- The script defines thresholds: `http_req_failed < 0.01` (error rate <1%), `http_req_duration{p(95)<500}` (P95 <500ms)
- If thresholds are violated: k6 exits with code 1 → CI fails → production promotion blocked

**Why load test in staging (not unit tests or just smoke tests):**
```
Unit tests: test business logic with mocked dependencies
Smoke tests: verify the service starts and basic paths work under zero load
Load test: verifies the service handles concurrent real traffic

Load test catches:
  - Connection pool exhaustion (HikariCP max-pool-size: 10, at 50 VUs with slow queries → all 10 connections busy → requests queue → timeout)
  - Thread pool exhaustion (Tomcat default 200 threads, 50 VUs × 10 concurrent req = fine, but wrong threadpool config could saturate)
  - Memory leaks (heap grows during the 3-minute test → after test it should GC back down; if it doesn't → leak)
  - Race conditions (50 VUs touching the same data simultaneously → concurrency bugs)
  - Cache stampede (all 50 VUs miss cache at once on first request → DB overload)
```

**notification-service k6 difference:**
```yaml
--vus 20 --duration 2m   ← fewer VUs, shorter
```
notification-service is async (queues to SQS). The bottleneck is SQS throughput, not the HTTP API. 20 VUs for 2 minutes validates the async pipeline without over-testing a queue.

### Job 6: `promote-to-production` — manual approval gate

```yaml
promote-to-production:
  needs: test-staging
  environment: production   ← THIS LINE pauses the pipeline
```

When the pipeline reaches this job, GitHub checks: does the `production` environment have required reviewers? If yes, the job is "pending" — it does not start. GitHub sends a notification to the required reviewers: "Workflow is waiting for your review."

A reviewer opens the GitHub UI, sees:
```
Deployment to production
Waiting for approval

Review the deployment and approve or reject it.
[Review deployments] button
```

They click "Review deployments", see which commit is being deployed, and click "Approve." The job then starts.

**This is NOT just code review:**
```
Code review (PR approval): "I agree this code is correct"
Production gate approval:  "I approve deploying THIS SPECIFIC VERSION
                            RIGHT NOW, having seen the test results"

Different people can fulfill each role.
Senior engineer approved the code 3 days ago.
On-call engineer approves the production deploy tonight.

Why both are needed:
  Code might be correct but deploy timing is wrong
  (e.g., "don't deploy tonight, we have a major sale starting in 2 hours")
```

### Job 7: `verify-production` + auto-rollback

```yaml
verify-production:
  needs: promote-to-production
  environment: production
  permissions:
    id-token: write
    contents: write   ← needed for rollback git push

steps:
  - uses: actions/checkout@v4
    with:
      token: '${{ secrets.GITHUB_TOKEN }}'
      fetch-depth: 0   ← FULL git history (needed for rollback)

  - name: Production smoke tests
    id: smoke
    run: |
      sleep 60   ← wait for pods to fully start (Spring Boot startup ~45-60s)
      curl -sf https://payment.company.com/actuator/health/liveness  || exit 1
      curl -sf https://payment.company.com/actuator/health/readiness || exit 1

  - name: Auto-rollback on failure
    if: failure() && steps.smoke.outcome == 'failure'
    run: |
      git pull origin main
      PREV_TAG=$(git log --oneline -- \
          gitops/production/app/payment-service/payment-service.yaml | \
          awk 'NR==2{print $1}' | \
          xargs git show | \
          grep 'tag:' | head -1 | \
          awk -F'"' '{print $2}')
      if [ -n "$PREV_TAG" ]; then
        sed -i "s|tag: \".*\"|tag: \"$PREV_TAG\"|" \
          gitops/production/app/payment-service/payment-service.yaml
        git add gitops/production/app/payment-service/payment-service.yaml
        git commit -m "chore(rollback-prod): payment-service=$PREV_TAG [skip ci]"
        git push
      fi
      exit 1   ← still mark the job as FAILED even after successful rollback
```

**`if: failure() && steps.smoke.outcome == 'failure'`:**
Two conditions joined with AND:
- `failure()`: the job is currently in a failed state (some step failed)
- `steps.smoke.outcome == 'failure'`: specifically the smoke test step failed (not a git push error or permissions issue)

Without both conditions: if `git pull` fails (network error), the rollback step would wrongly try to roll back a successful deploy.

**The rollback mechanism:**
```
git log --oneline -- gitops/production/app/payment-service/payment-service.yaml
  Shows: commits that changed this specific file
  
  abc1234 chore(deploy-prod): payment-service=new-sha [skip ci]  ← current (NR==1)
  def5678 chore(deploy-prod): payment-service=old-sha [skip ci]  ← previous (NR==2)
  
awk 'NR==2{print $1}'
  Extracts: "def5678"
  
xargs git show
  Shows the full diff of commit def5678
  
grep 'tag:' | head -1 | awk -F'"' '{print $2}'
  Extracts: "old-sha"
  
sed -i ... + git commit + git push:
  Updates gitops/production to point to old-sha
  ArgoCD detects the new commit → rolling update to old image
  Old version restored within ~3-5 minutes
```

**`fetch-depth: 0`:**
Default `actions/checkout` does a shallow clone (only the HEAD commit). `git log` on a shallow clone shows only 1 commit — you can't find the previous commit. `fetch-depth: 0` clones the full history so `git log` can find commit NR==2.

**`exit 1` after rollback:**
The deploy failed. Even though the rollback succeeded and the service is running the old version, the CI job MUST be marked as failed. This:
- Prevents the "production deploy succeeded" green check from appearing
- Alerts the engineer that the new version was bad and was rolled back
- Blocks any future auto-deploys of the same SHA (it's known-bad)

---

## Part 4 — The Terraform Infrastructure Pipeline

### Why matrix strategy (not sequential per env)

```yaml
strategy:
  fail-fast: false   ← all 3 envs plan even if one fails
  matrix:
    env:
      - { name: dev,        account_id: "123456789010", working_dir: terraform/environments/dev }
      - { name: staging,    account_id: "123456789011", working_dir: terraform/environments/staging }
      - { name: production, account_id: "123456789012", working_dir: terraform/environments/production }
```

**All 3 plans run in PARALLEL on a PR:**
```
Without matrix (sequential):
  dev plan: 3 minutes
  staging plan: 3 minutes
  production plan: 3 minutes
  Total: 9 minutes before reviewer can see all 3 plans
  
With matrix (parallel):
  dev plan:     3 minutes ┐
  staging plan: 3 minutes ├── all run simultaneously
  prod plan:    3 minutes ┘
  Total: 3 minutes before reviewer can see all 3 plans
  
3× faster feedback.
```

**`fail-fast: false`:**
```
Default matrix behavior: if one job fails, cancel all other in-progress jobs.

Problem: dev plan fails (syntax error in dev/main.tf).
  With fail-fast: true → staging and prod plans are cancelled.
  Reviewer can't see if staging and prod would have succeeded.
  
  "Is this a dev-only issue or does it affect all envs?"
  → Can't tell.
  
With fail-fast: false:
  Dev plan fails. Staging and prod plans continue.
  Reviewer sees: "dev: ERROR, staging: OK, prod: OK"
  → The issue is dev-specific. Safe to merge for staging/prod; fix dev separately.
```

**PR plan comment with emoji:**
```javascript
const emoji = plan.includes('No changes') ? '✅' : '⚠️';
body: `## ${emoji} Infra Plan — ${env.toUpperCase()}`
```
- ✅: reviewer sees at a glance "no infra changes for this env"
- ⚠️: "something will change here, read carefully"

### Sequential apply: dev → staging → production

```yaml
apply-dev:
  if: github.event_name == 'push'

apply-staging:
  needs: apply-dev         ← ONLY after dev succeeds

apply-production:
  needs: apply-staging     ← ONLY after staging succeeds
  environment: production  ← manual approval gate
```

**Why sequential (not parallel like plan):**
```
If EKS version upgrade is broken (bad AMI, wrong node type):
  Dev apply: FAILS (EKS upgrade broken)
  → apply-staging: SKIPPED (needs apply-dev failed)
  → apply-production: SKIPPED

  Without sequential (parallel applies):
    All 3 envs apply simultaneously
    All 3 fail or worse: some succeed in broken state
    Production cluster is now in an inconsistent state
    
With sequential: dev is the canary. If it fails, staging and prod are protected.
```

### Drift detection job

```yaml
drift-detect:
  if: github.event_name == 'schedule'
  schedule:
    - cron: '0 17 * * *'   # 02:00 JST daily
```

```bash
terraform plan -refresh-only -detailed-exitcode -no-color 2>&1 | tee drift.txt
EXIT_CODE=${PIPESTATUS[0]}
echo "has_drift=$([ $EXIT_CODE -eq 2 ] && echo 'true' || echo 'false')" >> $GITHUB_OUTPUT
```

**`-refresh-only`:** Only syncs state with real AWS — checks what changed in the real world vs what Terraform expects. Does NOT plan any config changes from `.tf` files. Shows: "EKS node group was manually changed" without also showing "apply my new .tf changes."

**`-detailed-exitcode`:**
- Exit 0: no drift
- Exit 1: error (plan failed)
- Exit 2: drift detected (real world differs from state)

**`${PIPESTATUS[0]}`:** When you pipe (`terraform plan | tee file.txt`), `$?` gives `tee`'s exit code (always 0). `${PIPESTATUS[0]}` gives the FIRST command's exit code (terraform's). Critical for detecting exit code 2.

**`set +e`:** Normally bash exits immediately on any non-zero exit code. Exit code 2 from terraform is expected (drift found) — we must NOT exit. `set +e` disables this behavior for this script.

---

## Part 5 — Security Patterns in CI/CD

### OIDC — no stored credentials

```
Traditional approach (BAD):
  GitHub Secrets: AWS_ACCESS_KEY_ID=AKIAIOSFODNN7...
                  AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/...
  
  Problems:
    - Keys never expire → if leaked, attacker has permanent access
    - Keys must be rotated manually → often forgotten
    - Keys are visible to all repo admins
    - GitHub stores them in its secrets database → another breach surface

OIDC approach (GOOD):
  No stored keys.
  Each job gets a 15-minute temporary token that expires automatically.
  Token can only be assumed by this specific repo, branch, and workflow.
  
  IAM role trust policy:
  {
    "Principal": {"Federated": "arn:aws:iam::123456789010:oidc-provider/token.actions.githubusercontent.com"},
    "Condition": {
      "StringEquals": {
        "token.actions.githubusercontent.com:aud": "sts.amazonaws.com",
        "token.actions.githubusercontent.com:sub": "repo:company/java-3envs-dynatrace:ref:refs/heads/main"
      }
    }
  }
  
  Only jobs running on main branch of this specific repo can assume this role.
  A fork PR cannot assume the role (different repo path in sub claim).
```

### Separate plan vs apply IAM roles

```
github-actions-ecr-push (apply/build role):
  ecr:BatchCheckLayerAvailability
  ecr:CompleteLayerUpload
  ecr:InitiateLayerUpload
  ecr:PutImage
  ecr:UploadLayerPart
  ecr:GetAuthorizationToken
  
github-actions-ecr-read (promote role):
  ecr:BatchGetImage
  ecr:GetDownloadUrlForLayer
  ecr:GetAuthorizationToken

No single role has BOTH push AND pull across accounts.
Promoting requires two separate role assumptions (one per account).
```

### `environment: production` as a security gate

```
Without environment gate:
  Anyone with merge permission to main can deploy to production
  Merge PR → CI auto-runs → 7 minutes later: production is updated
  
With environment gate:
  Merge PR → CI runs → pauses at promote-to-production
  Required reviewers must approve the DEPLOY (separate from code review)
  
  This separates two concerns:
    1. Is the code correct? (PR reviewer)
    2. Is now a good time to deploy? (deploy approver)
    
  Use case: "code is correct but we're in a code freeze for the release"
    → PR merged during freeze → deploy gate rejects → production unchanged
    → Unfreeze → deploy gate approved → production updated
```

### Secrets never in code

```
NEVER:  ECR_DEV: 123456789010.dkr.ecr.../payment-service  ← this is OK, just an address
NEVER:  DT_API_TOKEN: dt0c01.XXXX...                       ← this is a SECRET
NEVER:  PAGERDUTY_KEY: abc123...                            ← this is a SECRET

All secrets are in AWS Secrets Manager.
Terraform reads them via data sources.
CI reads them via aws-actions/configure-aws-credentials (OIDC) + aws secretsmanager.
GitHub Secrets only store: GITHUB_TOKEN (built-in, scoped to the repo).

If a secret is accidentally committed to git:
  git filter-branch or BFG Repo-Cleaner to purge from history
  Rotate the secret immediately (assume it's compromised)
```

---

## Part 6 — Pipeline Observability (Knowing When Things Break)

### Reading GitHub Actions logs effectively

```
Failed run URL: https://github.com/company/java-3envs-dynatrace/actions/runs/12345678

Step-by-step reading:
1. Click the failed job (red X)
2. Expand the failed step
3. Look for the first ERROR line (not just the last exit code)

Common failure patterns:

Pattern: "Process completed with exit code 1"
  → A command failed. Scroll up to see which command and why.

Pattern: "Error: could not find file plan.txt"
  → terraform plan failed silently (check Terraform Init step)

Pattern: "Error: refusing to allow a GitHub App to create or update workflow"
  → GITHUB_TOKEN doesn't have workflow write permission
  → Fix: add permissions: workflows: write OR use a PAT

Pattern: "InvalidClientTokenId: The security token included in the request is invalid"
  → OIDC role assumption failed
  → Check: branch name matches trust policy condition, IAM role exists, OIDC provider configured

Pattern: "Unable to locate credentials"
  → configure-aws-credentials step missing or failed silently
  → Check: permissions: id-token: write is set on the job
```

### Pipeline metrics to monitor

```
Metric: Pipeline duration (minutes)
  Healthy: test 3min, build 5min, total 25min
  Warning: >40 min total (something is slow — usually Docker build cache miss)
  Action: check if GHA cache is being evicted (cache size limit 10GB)

Metric: Pipeline success rate (per 7 days)
  Healthy: >90% (some failures are expected — flaky tests, race conditions)
  Warning: <80% (systematic problem — broken test, flaky infrastructure)
  Action: check what the failure reason is; fix flaky tests or infrastructure

Metric: Time from merge to production
  Healthy: 25-35 minutes (end-to-end automated)
  Warning: >1 hour (manual gate is slow, or pipeline queuing)
  Action: check if required reviewers are responding to gate approvals

Metric: Manual gate approval time
  Healthy: <30 minutes
  Warning: >2 hours
  Action: check notification setup, reviewer availability
```

### Debugging a failed rollout

```bash
# CI says "kubectl rollout status timed out"
# In CI logs: "error: deployment 'payment-service' exceeded its progress deadline"

# Step 1: Check pod status
kubectl get pods -n payment-ns --context dev

# Output:
# NAME                               READY   STATUS             RESTARTS   AGE
# payment-service-7d9f6b-abc12       0/1     CrashLoopBackOff   3          2m
# payment-service-7d9f6b-def34       1/1     Running            0          2m

# Step 2: Get crash reason
kubectl describe pod payment-service-7d9f6b-abc12 -n payment-ns --context dev
# Look for: Last State, Exit Code, Events section

# Common causes:
# Exit code 1:  Application crashed (Java exception, main class not found)
# Exit code 137: OOMKilled (JVM heap exceeded container limit)
# Exit code 143: SIGTERM timeout (took too long to shutdown)

# Step 3: Read crash logs
kubectl logs payment-service-7d9f6b-abc12 -n payment-ns --context dev --previous
# --previous: shows logs from the CRASHED container (before restart)

# Typical crash log (DB connection failure):
# org.springframework.beans.factory.BeanCreationException:
#   Error creating bean with name 'entityManagerFactory':
#   Failed to obtain JDBC Connection: Unable to acquire JDBC Connection
#   Caused by: org.postgresql.util.PSQLException: Connection to 10.10.20.5:5432 refused

# Step 4: Check if the ExternalSecret synced DB credentials
kubectl get externalsecret payment-service-db-credentials -n payment-ns --context dev
# STATUS: SecretSyncError → ESO couldn't read from Secrets Manager
# → Check IRSA role, Secrets Manager path, ClusterSecretStore
```

---

## Part 7 — Common Mistakes and How to Prevent Them

### Mistake 1: Missing `[skip ci]` → infinite loop

**Symptom:**
```
Run count for payment-service-ci.yaml: 47 in the last hour
All triggered by "github-actions[bot]"
All committing "chore(deploy-dev): payment-service=..."
```

**Root cause:** `[skip ci]` not included in the gitops commit message.

**Fix:**
```bash
# In build-and-deploy-dev step:
git commit -m "chore(deploy-dev): payment-service=${{ env.IMAGE_TAG }} [skip ci]"
#                                                                    ^^^^^^^^^^^
```

**Prevention:** Add a CI check that verifies bot commits always include `[skip ci]`.

### Mistake 2: Smoke test runs before rollout completes

**Symptom:** Smoke tests pass in CI, but monitoring shows errors after "successful" deploy. Users are hitting old pods.

**Root cause:** Missing `kubectl rollout status` wait, OR `sleep 30` is too short for large clusters.

**Fix:**
```bash
sleep 30   # minimal wait for ArgoCD to detect and start the rollout
aws eks update-kubeconfig --name company-dev --alias dev
kubectl rollout status deployment/payment-service -n payment-ns --timeout=8m
# THEN run smoke tests
```

**Detection:** Check pod ages after a deploy. If smoke tests ran and all pods still have "old" ages → waiting was insufficient.

### Mistake 3: `fetch-depth: 0` missing → rollback finds no previous tag

**Symptom:**
```
Auto-rollback on failure
PREV_TAG is empty — could not determine previous tag for rollback
```

**Root cause:** Default `actions/checkout` is shallow (depth 1). `git log` shows only 1 commit. `NR==2` (the previous commit) doesn't exist.

**Fix:**
```yaml
- uses: actions/checkout@v4
  with:
    fetch-depth: 0   ← ALWAYS for jobs that need git history
```

### Mistake 4: ECR image not found during promotion

**Symptom:**
```
promote-to-staging job fails:
Error response from daemon: manifest for 123456789010.dkr.ecr.../payment-service:abc1234 not found
```

**Root cause:** Image SHA in the promote job doesn't match what was pushed in the build job.

**Diagnosis:**
```bash
# Check if build job actually pushed the image
aws ecr describe-images \
  --repository-name payment-service \
  --region ap-northeast-1 \
  --query 'imageDetails[?contains(imageTags, `'$IMAGE_TAG'`)]'

# If empty: image was never pushed (Trivy scan failed after push? Push failed silently?)
```

**Fix:** Ensure `build-push-action` has `push: true`. Ensure Trivy scan happens AFTER push (needs the image in ECR to scan it). The pipeline: build → push to ECR → scan (pulls from ECR) → update gitops.

### Mistake 5: `git push` fails in promotion jobs

**Symptom:**
```
Update staging gitops tag
error: failed to push some refs to 'https://github.com/...'
hint: Updates were rejected because the remote contains work that you do not have locally.
```

**Root cause:** Multiple service pipelines (payment, order, notification) running simultaneously. All three try to push gitops updates to the same repo. Second push fails because the first already moved HEAD.

**Fix:**
```bash
git pull origin main   # ← pull BEFORE sed and commit
sed -i ...
git commit ...
git push
```

**Prevention:** Add `git pull --rebase origin main` before every gitops commit.

---

## Part 8 — Pipeline Design Principles

### Principle 1: Fail fast, fail early

```
Order of gates (cheapest first):

1. Lint/validate (seconds)      → syntax errors
2. Unit tests (3 min)           → logic errors
3. Coverage check (0 extra min) → untested code
4. Build (5 min)                → compilation errors, missing files
5. Security scan (2 min)        → vulnerabilities
6. Smoke test (2 min)           → integration errors
7. Load test (3 min)            → performance regressions
8. Manual approval              → timing/risk assessment
9. Production smoke test        → verify production

Each gate is only reached if ALL previous gates passed.
Moving a slow gate earlier wastes time on code that would have failed a fast gate.
Moving a fast gate later masks cheap-to-detect errors.
```

### Principle 2: Immutable artifacts

```
Build once, deploy everywhere.

BAD:
  build image for dev → deploy to dev
  rebuild image for staging → deploy to staging (different image!)
  rebuild image for prod → deploy to prod (different image!)
  
  "Why does it work in dev but fail in prod?"
  "Could be different build inputs, different base image, different time of build"
  
GOOD (this project):
  build image abc1234 → push to dev ECR
  copy abc1234 to staging ECR (no rebuild)
  copy abc1234 to prod ECR (no rebuild)
  
  "Why does it work in dev but fail in prod?"
  "Same image, so it's environment config (DB creds, IAM roles, network) not the app"
  Immediately narrows the problem space.
```

### Principle 3: Every deploy is reversible

```
GitOps enables reversibility:
  Every deploy = one git commit (the gitops YAML image tag update)
  
  Rollback = one git commit (revert the image tag to previous SHA)
  ArgoCD detects the revert commit → rolling update to old version
  
  Time to rollback: 3-5 minutes (ArgoCD poll + rolling update)
  Without gitops: rollback requires re-running the full pipeline with old code
  → potentially 25+ minutes to recover
  
  With auto-rollback in verify-production:
  Bad deploy detected + rolled back automatically in < 5 minutes
  No human intervention needed for basic deployment failures
```

### Principle 4: Separate concerns into separate pipelines

```
This project has 8 workflows, each with ONE clear purpose:

payment-service-ci.yaml     → deploy payment-service Java app
order-service-ci.yaml       → deploy order-service Java app
notification-service-ci.yaml → deploy notification-service Java app
terraform-infra.yaml        → manage AWS infrastructure
terraform-dynatrace-dev.yaml    → manage dev DT configuration
terraform-dynatrace-staging.yaml    → manage staging DT configuration
terraform-dynatrace-production.yaml → manage prod DT configuration

Each pipeline:
  - Has its own trigger (only fires on relevant file changes)
  - Has its own failure mode (one failing doesn't block others)
  - Can be debugged and improved independently
  - Has one clear owner (payment team owns payment-service-ci.yaml)

BAD: one mega-pipeline that deploys all 3 services + infra + DT config
  → Everything blocks everything
  → No clear ownership
  → A DT config change rebuilds all 3 Java services (wasted time)
```

### Principle 5: Human gates at critical boundaries

```
Gates in this project:

Gate 1: Code review (PR approval)
  What it controls: code quality, correctness, security review
  Who approves: any engineer with write access
  
Gate 2: Production DT config (environment: production in DT pipeline)
  What it controls: monitoring threshold changes in production
  Who approves: senior SRE or team lead
  
Gate 3: Production app deploy (environment: production in service pipeline)
  What it controls: new version reaching production users
  Who approves: on-call engineer or senior engineer
  
Gates are placed at BOUNDARIES:
  "dev → staging": no gate (automated via smoke tests)
  "staging → production": gate (manual approval)
  
  Rationale:
    Dev issues: caught by automated tests, low business impact
    Staging issues: caught by k6, medium impact (no real users)
    Production issues: real users affected → human judgment needed
```
