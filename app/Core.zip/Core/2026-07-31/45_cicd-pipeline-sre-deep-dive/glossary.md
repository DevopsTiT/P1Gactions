# Glossary — CI/CD Pipeline SRE Deep Dive

Every term used in main.md. Plain language for an SRE beginner.

---

**CI (Continuous Integration)**
The practice of automatically testing code every time it's pushed to a shared repository. Why it matters: catches bugs before they reach production — "does this code work?" answered in minutes, not days.

**CD (Continuous Delivery/Deployment)**
Continuous Delivery: every tested commit is automatically prepared to deploy (but a human approves production). Continuous Deployment: every tested commit deploys automatically including production. This project uses Continuous Delivery — human approval required before production. Why it matters: reduces manual work while keeping human judgment at critical boundaries.

**GitHub Actions**
A CI/CD system built into GitHub. YAML files in `.github/workflows/` define jobs that run automatically on events. Each job runs on a fresh cloud VM. Why it matters: the CI/CD engine that drives the entire deploy process in this project.

**Workflow file**
A YAML file in `.github/workflows/` that defines one automated pipeline. A repo can have many workflow files, each triggered by different events. Why it matters: each service has its own workflow — changes to one don't affect others.

**`on.paths` trigger filter**
Tells GitHub Actions to only run the workflow when specific file paths changed. If no matching files changed, the workflow is completely skipped. Why it matters: prevents unrelated code changes from triggering expensive build pipelines.

**`push` event**
GitHub Actions trigger that fires when commits are merged to a branch (or directly pushed). Deploy jobs only run on push events (after merge), not on PRs. Why it matters: ensures actual code reaches the cluster only after it's been reviewed and merged.

**`pull_request` event**
GitHub Actions trigger that fires when a PR is opened or updated. Only lightweight jobs (tests) run on PRs. Deploy jobs skip themselves using `if: github.event_name == 'push'`. Why it matters: gives engineers fast test feedback without any deployment risk.

**`needs:` (job dependency)**
Creates a sequential dependency between jobs. `needs: test` = this job only starts after `test` succeeds. If `test` fails, all downstream jobs are automatically skipped. Why it matters: the mechanism that enforces "test before build before deploy" ordering.

**`if: github.event_name == 'push'`**
A job-level condition. The job runs only when the event was a push (merge), not a PR. Why it matters: deploy jobs must not run on PRs — you should only deploy merged, approved code.

**`environment: production` (GitHub Actions)**
A named deployment environment with optional required reviewers. The pipeline pauses at this job and waits for human approval before running. Why it matters: the production gate — no deploy happens without explicit human sign-off.

**`matrix` strategy (GitHub Actions)**
Runs the same job definition multiple times with different inputs simultaneously. `matrix: env: [dev, staging, production]` creates 3 parallel plan jobs. Why it matters: 3× faster feedback — all 3 environment plans finish in the time it takes for one.

**`fail-fast: false` (matrix)**
Prevents GitHub from cancelling other matrix jobs when one fails. All jobs run to completion regardless. Why it matters: even if dev plan fails, you can still see if staging and prod plans succeed — useful for diagnosing environment-specific issues.

**`github.sha`**
A built-in GitHub Actions variable containing the 40-character git commit SHA. Used as the Docker image tag. Why it matters: every commit gets a unique, immutable, traceable tag — you can always find the exact code in any deployed image.

**`[skip ci]`**
A string in a git commit message that prevents GitHub Actions from triggering any workflows for that commit. Why it matters: CI writes gitops YAML updates back to git — without `[skip ci]`, that commit re-triggers CI, causing an infinite loop.

**OIDC (OpenID Connect) for AWS**
A way for GitHub Actions to authenticate to AWS without storing long-lived credentials. GitHub provides a short-lived token; AWS STS exchanges it for temporary credentials valid for ~15 minutes. Why it matters: no stored secrets to rotate, steal, or accidentally commit.

**STS (Security Token Service)**
AWS service that issues temporary credentials (access key + secret key + session token) in exchange for an OIDC token. Why it matters: makes short-lived, automatically-expiring AWS credentials possible.

**IAM role trust policy**
A policy on an AWS IAM role that specifies who can assume it. In this project: only workflows from `repo:company/java-3envs-dynatrace:ref:refs/heads/main` can assume the deploy role. Why it matters: fork PRs from untrusted contributors cannot assume the production deploy role.

**`plan` role vs `apply` role**
Two separate IAM roles. Plan role: read-only (can't create or destroy anything). Apply role: write permissions. Why it matters: even if CI credentials are leaked via a plan step, they can't be used to modify infrastructure.

**ECR (Elastic Container Registry)**
AWS's Docker image registry. Each environment has its own ECR in a separate AWS account. Why it matters: production ECR is in a separate account that only production CI credentials can write to — no engineer can bypass the pipeline.

**Cross-account ECR promotion**
Copying a Docker image from one AWS account's ECR to another by pulling from source and pushing to destination. Requires two separate credential steps. Why it matters: the same bits (same SHA) reach production, proving no rebuild happened between test and deploy.

**Multi-arch Docker build (`linux/amd64,linux/arm64`)**
Building one Docker image that contains binaries for both Intel/AMD and ARM CPU architectures. Why it matters: EKS can use cheaper Graviton (ARM) nodes. Without multi-arch: `exec format error` crash on ARM nodes.

**Docker BuildKit**
Docker's extended build engine (enabled by `docker/setup-buildx-action`). Required for multi-arch builds. Supports advanced caching. Why it matters: without BuildKit, you can only build for the runner's native CPU architecture.

**GitHub Actions cache (Docker layers)**
Stores Docker image layers between CI runs using `cache-from: type=gha`. Unchanged layers (base image, dependencies) are served from cache instead of rebuilt. Why it matters: reduces build time from 5-8 minutes to 60-90 seconds on most runs.

**Trivy**
Open-source Docker image vulnerability scanner. Checks images against CVE databases. Exits with code 1 if CRITICAL or HIGH vulnerabilities are found. Why it matters: prevents known-vulnerable images from reaching any environment.

**`ignore-unfixed: true` (Trivy)**
Skips CVEs that have no available fix. Why it matters: without this, Trivy fails the build for vulnerabilities in base OS packages that can't be patched, blocking all deployments indefinitely.

**`kubectl rollout status`**
A command that blocks until all pods in a Deployment are updated and passing health checks, or until a timeout. Why it matters: ensures smoke tests run against the NEW pods, not old ones still handling traffic during a rolling update.

**`--timeout=8m` (rollout status)**
The maximum time to wait for the rollout to complete. After 8 minutes, the command exits non-zero → CI step fails → downstream jobs skip. Why it matters: prevents CI from hanging forever if a pod is stuck starting.

**Rolling update**
A Kubernetes deployment strategy that replaces pods one at a time. New pod starts → passes readiness probe → old pod terminates. `maxUnavailable: 0` = zero downtime. Why it matters: users never experience a gap in service during a deploy.

**`maxUnavailable: 0`**
Rolling update setting meaning "never terminate an old pod before a replacement is Ready." Why it matters: at no point are there fewer than N healthy pods serving traffic — true zero-downtime deploys.

**`-sf` curl flags**
`-s` (silent): no progress output. `-f` (fail): exits non-zero if HTTP status ≥ 400. Why it matters: clean CI output, and non-2xx responses properly fail the smoke test.

**Smoke test**
A minimal set of checks that verify the deployed service is alive and handling basic requests correctly. Usually: health probes + one real API call. Why it matters: catches "starts but crashes" and "returns wrong responses" before the code reaches staging.

**SQS DLQ smoke test**
For async services: checking that the Dead Letter Queue is empty (no failed message deliveries) instead of testing a synchronous API. Why it matters: async services return "queued" even when delivery fails — only the DLQ reveals silent failures.

**k6 load test**
Open-source load testing tool that runs a JavaScript script with configurable concurrent users (VUs) for a duration. Exits non-zero if error rate or latency thresholds are exceeded. Why it matters: validates the service handles concurrent real traffic before production promotion.

**VU (Virtual User)**
A k6 concept — one goroutine continuously sending requests. `--vus 50` = 50 simultaneous users. Why it matters: simulates real concurrent load that smoke tests (one request at a time) don't catch.

**Auto-rollback**
Automatic reversal of a deploy when production smoke tests fail. CI reads the previous image tag from git history, reverts the gitops YAML, and pushes — ArgoCD deploys the old version. Why it matters: bad deploys are undone in ~5 minutes without human intervention.

**`fetch-depth: 0`**
A `actions/checkout` option that clones the full git history instead of just the latest commit. Why it matters: the auto-rollback script needs `git log` to find the previous image tag — impossible with a shallow clone.

**`if: failure() && steps.smoke.outcome == 'failure'`**
A step condition that runs only when the job is failing AND specifically because the smoke test step failed. Why it matters: prevents rollback from triggering when a different step fails (e.g., git push error) — which would incorrectly roll back a successful deploy.

**`git log --oneline -- <file>`**
Shows the commit history for a specific file. Used to find the previous gitops commit for rollback. Why it matters: allows rollback to precisely the last known-good image tag.

**`PIPESTATUS[0]`**
Bash variable holding the exit code of the first command in a pipe. `terraform plan | tee file.txt` → `${PIPESTATUS[0]}` is terraform's exit code. Why it matters: `$?` always shows tee's exit code (0) — you need `PIPESTATUS` to detect terraform's exit code 2 (drift detected).

**`set +e`**
Bash command disabling automatic exit on non-zero exit codes. Why it matters: terraform `-detailed-exitcode` exits 2 when drift is found — this is expected, not an error. Without `set +e`, the script aborts before capturing the drift result.

**`-refresh-only` (terraform plan)**
Checks what changed in real infrastructure vs Terraform state, without planning any config changes from `.tf` files. Why it matters: drift detection needs to show "someone changed something manually" separately from "what my code would change."

**`-detailed-exitcode` (terraform plan)**
Changes exit codes: 0 = success/no changes, 1 = error, 2 = success with changes. Why it matters: scripts need to distinguish "no drift" (0) from "drift found" (2) — without this flag, plan always exits 0 even when changes exist.

**Drift (infrastructure)**
When real infrastructure diverges from what Terraform expects. Caused by: manual UI changes, API calls outside Terraform, provider updates. Why it matters: undetected drift means the next `terraform apply` may make unexpected changes to correct the drift.

**Trunk-based development**
A git branching strategy where all engineers merge frequently to `main` (the trunk). No long-lived feature branches. Why it matters: small, frequent merges → smaller diffs → easier rollback → less integration conflict.

**Immutable artifact**
A Docker image built once with a fixed tag (git SHA) that never changes. The same image is promoted through environments without rebuilding. Why it matters: "it works in dev but not in prod" must be an environment config issue, not a code difference — immutable artifacts eliminate that ambiguity.

**Fail fast, fail early**
The principle of ordering pipeline gates cheapest-first: syntax check (seconds) → tests (minutes) → build (minutes) → security scan (minutes) → deploy. Why it matters: avoids running expensive steps on code that would have failed a cheap step.

**Separate concerns**
Each pipeline has one clear purpose (deploy payment-service, manage DT config, manage infra). Changes to one service don't trigger pipelines for other services. Why it matters: faster feedback, independent failure modes, clear ownership.

**`git pull origin main`**
Fetches latest remote commits before pushing. Why it matters: multiple pipelines running in parallel all update the same gitops repo — without pulling first, the push fails with "rejected: non-fast-forward."

**`--no-daemon` (Gradle)**
Disables the Gradle daemon (a long-running background process that speeds up builds). Why it matters: on CI, each run is isolated — a daemon from a previous build could have stale state. `--no-daemon` ensures clean, reproducible builds.

**JaCoCo**
Java code coverage tool. Measures what percentage of source code lines are executed by tests. `jacocoTestCoverageVerification` enforces minimum 70% line coverage. Why it matters: ensures at least 70% of code paths are tested before any image is built.

**Testcontainers**
A Java testing library that spins up real Docker containers (PostgreSQL, Redis) during tests. Why it matters: tests run against a real database, not a mock — catches SQL bugs and connection pool issues that mocked tests miss.

**`if: always()` (GitHub Actions step condition)**
The step runs regardless of whether previous steps succeeded or failed. Why it matters: the JUnit test report step should always run — the report is most valuable precisely when tests fail.

**`mikepenz/action-junit-report@v4`**
A GitHub Actions action that reads JUnit XML test results and annotates the PR with failure locations directly in the diff view. Why it matters: engineers see exactly which lines of code failed, without opening build logs.

**`actions/cache@v4`**
A GitHub Actions action that saves and restores files between CI runs using a cache key. Used for Gradle dependencies and Docker layers. Why it matters: avoids downloading 200MB of dependencies on every run — reduces build time by 60-70%.

**`restore-keys`**
A fallback list for `actions/cache`. If the exact cache key isn't found, try progressively more general keys. Why it matters: even a partial cache hit (downloading only new dependencies) is much faster than a full cache miss.

**`hashFiles()`**
A GitHub Actions expression that computes a hash of one or more files. `hashFiles('build.gradle')` changes whenever build.gradle changes. Used as part of the cache key. Why it matters: cache is invalidated when dependencies change, ensuring a fresh download.

**`working-directory`**
A GitHub Actions step setting that changes the shell's current directory for that step. Why it matters: `./gradlew test` must run from the directory containing `build.gradle` — this setting avoids `cd` commands and makes the path explicit.

**Blue-green deployment**
A deployment strategy where two identical production environments ("blue" and "green") are maintained. One serves traffic; the new version deploys to the other; traffic switches instantly. Why it matters: instant rollback by switching back — no rolling update delay. Not used in this project (rolling update is used instead), but worth knowing.

**Canary deployment**
A strategy where a small percentage of traffic (e.g., 5%) goes to the new version while the rest hits the old version. The canary is monitored; if healthy, traffic gradually shifts. Not used in this project, but the dev-before-prod promotion serves a similar "canary" purpose.

**GitOps**
A practice where the desired state of a system is stored in Git, and a controller (ArgoCD) automatically reconciles the system to match Git. Why it matters: every deploy is a git commit — auditable, reversible, and consistent.

**`GITHUB_TOKEN`**
A built-in GitHub Actions secret automatically available to every workflow. Scoped to the current repository. Used for: posting PR comments, pushing commits, triggering releases. Why it matters: no manual secret configuration needed for basic repo operations.
