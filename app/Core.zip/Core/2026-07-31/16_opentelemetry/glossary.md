# OpenTelemetry Glossary — SRE Beginner Reference

Every term from the main.md explained in plain language. One entry per term.

---

**OpenTelemetry (OTel)**
A free, open-source project under CNCF that provides a standard way to collect observability data (traces, metrics, logs) from your application. Think of it as a universal adapter — your app plugs into OTel once, and OTel connects to any monitoring tool you choose.

**CNCF (Cloud Native Computing Foundation)**
The non-profit that maintains open-source projects used in cloud/Kubernetes environments. Kubernetes, Prometheus, and Jaeger all live here. OTel lives here too. Like the "App Store" but for open-source infrastructure tools, vetted by the community.

**Observability**
The ability to understand what's happening INSIDE your system by looking at data coming OUT of it (logs, metrics, traces). If your app is a black box, observability is the window you cut into it. "I can observe it" means "I can diagnose it when it breaks."

**The Three Pillars of Observability**
Traces, Metrics, and Logs. The three types of data you need to fully understand a running system. Each answers a different question: traces = what path? metrics = how much/fast? logs = what happened?

**Trace**
The complete, end-to-end record of ONE request as it travels through your entire system. If a user clicks "checkout" and that request touches 5 services, the trace is the record of ALL 5 hops — with timing, success/failure, and context for each.

**Span**
One single operation within a trace. Like one line item on a receipt. A trace is made of many spans (e.g., "received HTTP request", "queried database", "called Stripe API"). Each span has a start time, end time, name, status, and attributes.

**Trace ID**
A unique identifier (a random hex string like `abc123def456...`) that is shared by ALL spans in one trace. This is how spans get stitched together into a single trace across different services — they all carry the same trace_id.

**Span ID**
A unique identifier for ONE specific span. Different from trace_id (which is shared). Used to build parent-child relationships: "this span was created inside that other span."

**Parent Span / Child Span**
When Service A calls Service B, the span in Service A is the "parent" and the span in Service B is the "child." This creates the tree structure you see in trace visualizations. Every span except the root has a parent_id.

**Metric**
A number measured at a point in time (or over time). Examples: CPU usage = 72%, request count = 1,042/sec, p99 latency = 340ms. Unlike traces (which describe individual events), metrics are aggregated numbers that describe overall system behavior.

**Counter**
A metric type that only ever goes UP. Once you count something, you never subtract. Examples: total HTTP requests received, total errors. You can calculate rates (requests/sec) from counters.

**Gauge**
A metric type that can go up OR down — it represents a current state. Examples: number of active connections right now, current memory usage, queue depth. Like a thermometer reading.

**Histogram**
A metric type that records how values are distributed across buckets. Instead of just "average latency = 50ms", a histogram tells you "80% of requests took <50ms, 18% took 50-200ms, 2% took >200ms." Essential for SLOs.

**Percentile (p50, p95, p99)**
A way to describe the distribution of values. p99 = "99% of requests were faster than this value." If p99 = 2000ms, 1% of your users wait more than 2 seconds. The average hides this pain; percentiles reveal it. SREs care deeply about p99 and p999.

**Log**
A text record of an event that happened, with a timestamp. The most familiar form of observability. OTel adds `trace_id` to logs so you can jump from a trace directly to the logs that happened during that trace.

**Structured Log**
A log written in a machine-readable format (like JSON) instead of free-form text. Structured logs are easier to query and correlate. OTel promotes structured logs with standard fields like `severity`, `trace_id`, `service.name`.

**OTel API**
The set of interfaces (contracts) that define HOW to instrument code, without containing the actual working code. Library authors use the API so their libraries work with any OTel implementation. Very lightweight — safe to include in shared libraries.

**OTel SDK**
The actual working implementation of the OTel API. This is what app developers and SREs use. The SDK contains real code: span creation, metric recording, exporters, samplers.

**TracerProvider**
The factory object inside the OTel SDK that creates Tracer instances. You configure it once at app startup (which exporters to use, which sampler, etc.) and it manages all tracing for your application.

**MeterProvider**
The factory for creating Meter instances (used for metrics). Configured once, used everywhere.

**Tracer**
An object you get from TracerProvider, scoped to a specific component/module. You call `tracer.startSpan("name")` to create spans. Each library or service component typically has its own Tracer.

**Meter**
An object you get from MeterProvider. You use it to create metric instruments (counters, histograms, gauges) for your component.

**Auto-Instrumentation**
A technique where an OTel agent automatically instruments your application without you changing any code. For Java, it's a JAR file you attach at startup. For Python, it's a wrapper command. It automatically intercepts HTTP calls, DB queries, etc.

**OTel Java Agent**
A JAR file (`opentelemetry-javaagent.jar`) that you attach to a Java application using the `-javaagent:` JVM flag. At startup, it hooks into the JVM and automatically instruments 100+ popular Java libraries (Spring, JDBC, Kafka, etc.).

**OTel Collector**
A standalone service (written in Go) that receives telemetry data, processes it, and sends it to one or more backends. Acts as a central hub. Your apps send data to the Collector, and the Collector handles routing to Datadog, Prometheus, Jaeger, etc. This way your apps never need to know about backend details.

**Receiver (Collector)**
The input side of the Collector. It listens for incoming data in various formats: OTLP, Jaeger, Zipkin, Prometheus scrape. Like the mail slot on the post office door.

**Processor (Collector)**
The middle stage of the Collector pipeline. Transforms, filters, or batches data before exporting. Common processors: `batch` (groups data for efficiency), `filter` (drops unwanted spans), `resource` (adds/modifies attributes), `tail_sampling` (decides which traces to keep).

**Exporter (Collector)**
The output side of the Collector. Sends processed data to a backend: Jaeger, Datadog, Dynatrace, Prometheus, S3, etc. You can have multiple exporters in one pipeline to send data to several backends simultaneously.

**OTLP (OpenTelemetry Line Protocol)**
The standard wire format that OTel uses to transmit traces, metrics, and logs. Two transport options: gRPC (port 4317, binary, faster) and HTTP/JSON (port 4318, easier to debug). When apps send to the Collector, they speak OTLP.

**Pipeline (Collector)**
A configured flow for one signal type (traces, metrics, or logs): Receiver → Processor(s) → Exporter(s). You define separate pipelines for traces, metrics, and logs in the Collector config.

**Context Propagation**
The mechanism that passes trace context (trace_id, span_id) from one service to the next, across network boundaries. Without propagation, each service would start a new independent trace instead of joining the existing one.

**traceparent header**
The W3C-standard HTTP header used to carry trace context between services. Format: `00-{trace_id}-{parent_span_id}-{flags}`. Every OTel-instrumented service reads this from incoming requests and writes it to outgoing requests.

**W3C TraceContext**
The official web standard (from the W3C organization) that defines the `traceparent` header format. OTel uses this by default. "W3C" is the same body that standardizes HTML and CSS.

**B3 Headers**
An older format for trace propagation, invented by Twitter's Zipkin project. Uses `X-B3-TraceId`, `X-B3-SpanId` headers. Some legacy services still use B3; OTel can speak both.

**Baggage**
A mechanism in OTel to pass custom key-value data along with a trace — e.g., `user.id=123` gets propagated to every downstream service automatically. Useful but use sparingly (it goes in every request header).

**Sampling**
The decision of which traces to actually record and store. At high traffic (1000 req/sec), storing 100% of traces is expensive. Sampling lets you keep a representative subset.

**Head-Based Sampling**
Sampling decision made at the START of a trace (when the first span begins). Simple but blind — you don't know yet if this trace will error or be slow when you decide.

**Tail-Based Sampling**
Sampling decision made at the END of a trace (after all spans are collected). Smarter — you can say "keep all errors, keep all slow traces, randomly sample 5% of the rest." Requires the Collector to buffer complete traces before deciding.

**Probabilistic Sampling**
The simplest sampling: keep X% of all traces at random. E.g., 10% sampling means 1 in 10 traces is recorded. Fast but crude — errors might be in the 90% you dropped.

**Resource Attributes**
Key-value pairs that describe the SOURCE of telemetry data — the service, machine, or environment that generated it. Examples: `service.name=checkout`, `deployment.environment=production`, `k8s.pod.name=checkout-7f9b-abc`. Every span and metric should have these so you know what generated the data.

**Semantic Conventions**
OTel's standard names for common attributes. Instead of everyone calling it `http_method` or `HTTPMethod` or `http.method`, OTel defines `http.request.method` as the standard name. This makes data from different apps compatible in the same backend.

**OpenTelemetry Operator**
A Kubernetes Operator that manages OTel components inside a Kubernetes cluster. It can auto-inject agents into pods using annotations (you just add `instrumentation.opentelemetry.io/inject-java: "true"` to your Deployment) without changing Dockerfiles.

**Instrumentation CR (Custom Resource)**
A Kubernetes object created by the OTel Operator that defines HOW to instrument pods (which exporter endpoint, which propagators, which language agents). One Instrumentation CR can apply to many Deployments.

**DaemonSet**
A Kubernetes workload type that runs one pod per node (not per replica). The OTel Collector is often deployed as a DaemonSet so every node has a local collector agent close to the apps it monitors.

**Sidecar**
A container running alongside your main app container in the same Kubernetes Pod. OTel Collector can run as a sidecar, receiving telemetry from the main app over localhost. Low latency, high isolation.

**APM (Application Performance Monitoring)**
A category of monitoring tools that focus on application behavior: response times, error rates, transaction traces. Dynatrace, Datadog, New Relic are APM tools. OTel is the instrumentation layer that feeds them.

**Dynatrace**
A commercial APM platform. Can receive OTel data (traces, metrics, logs) via its native OTLP endpoint. Has its own agent (OneAgent) that goes deeper but requires vendor lock-in.

**Jaeger**
An open-source distributed tracing backend (originally from Uber). Stores and visualizes traces. OTel can export traces to Jaeger via OTLP. Free to run yourself.

**Prometheus**
An open-source metrics database and alerting system. OTel can export metrics to Prometheus via remote write. The standard choice for Kubernetes metrics.

**Zipkin**
An older open-source distributed tracing system (originally from Twitter). Predecessor to Jaeger. OTel can export to Zipkin via the Zipkin exporter. Mostly legacy now.

**SPOF (Single Point of Failure)**
A component whose failure brings down the entire system. Running only one OTel Collector is a SPOF — if it crashes, all telemetry is lost. Always run 2+ collectors in production behind a load balancer.

**Cardinality**
The number of unique values a label/attribute can have. `http.method` has low cardinality (GET, POST, PUT...). `user.id` has HIGH cardinality (millions of values). High-cardinality labels explode metric storage costs and must be avoided on metrics (traces handle them better).

**Circuit Breaker**
A software pattern that stops calling a failing service after N failures, instead returning a fast error. Prevents cascading failures. Like a fuse in an electrical circuit — trips to protect the rest.

**p50 / p95 / p99 / p999**
Percentile shorthand. p50 = median. p95 = 95th percentile. p99 = 99th percentile. p999 = 99.9th percentile. SREs monitor p99 and p999 for latency SLOs — these represent the worst 1% and 0.1% of user experiences.

**SLO (Service Level Objective)**
A target for how reliable a service must be. Example: "99.9% of checkout requests must complete in under 500ms." OTel metrics provide the data to calculate whether you're meeting your SLO.

**SLI (Service Level Indicator)**
The actual measurement used to track an SLO. Example: "percentage of requests completing under 500ms" is the SLI for the SLO above. OTel histogram metrics are the source data for SLIs.

**Error Budget**
The amount of downtime/failures allowed before violating an SLO. If SLO = 99.9% availability, error budget = 0.1% = ~43 minutes/month. OTel metrics help you track how fast you're spending the error budget.

**Rolling Restart**
A Kubernetes operation that replaces pods one at a time (keeping the service available). Used after changing a Deployment's annotations so the new pods pick up the OTel instrumentation.
