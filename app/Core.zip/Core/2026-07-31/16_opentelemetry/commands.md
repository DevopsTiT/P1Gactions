# OpenTelemetry — Commands Reference

---

## Phase 0 — Verify OTel Collector is Running

```bash
# Check if collector pod is running in Kubernetes
kubectl get pods -n observability -l app=otel-collector

# Check collector logs for errors
kubectl logs -n observability deployment/otel-collector --tail=50

# Check collector metrics (it exposes its own health metrics on :8888)
kubectl port-forward -n observability svc/otel-collector 8888:8888
curl http://localhost:8888/metrics | grep otelcol_exporter

# Check collector config that's actually loaded
kubectl get configmap -n observability otel-collector-config -o yaml
```

---

## Phase 1 — Java Auto-Instrumentation (Manual / No Operator)

```bash
# Download latest OTel Java agent
OTEL_VERSION=$(curl -s https://api.github.com/repos/open-telemetry/opentelemetry-java-instrumentation/releases/latest | grep '"tag_name"' | cut -d'"' -f4)
wget "https://github.com/open-telemetry/opentelemetry-java-instrumentation/releases/download/${OTEL_VERSION}/opentelemetry-javaagent.jar"

# Run your Java app with the agent
java \
  -javaagent:./opentelemetry-javaagent.jar \
  -Dotel.service.name=my-service \
  -Dotel.exporter.otlp.endpoint=http://localhost:4317 \
  -Dotel.exporter.otlp.protocol=grpc \
  -Dotel.resource.attributes=deployment.environment=production,service.version=1.2.0 \
  -Dotel.traces.exporter=otlp \
  -Dotel.metrics.exporter=otlp \
  -Dotel.logs.exporter=otlp \
  -jar your-app.jar

# DEBUG: Print spans to console instead (for local testing)
java \
  -javaagent:./opentelemetry-javaagent.jar \
  -Dotel.service.name=my-service \
  -Dotel.traces.exporter=console \
  -Dotel.metrics.exporter=none \
  -jar your-app.jar
```

---

## Phase 2 — Python Auto-Instrumentation

```bash
# Install OTel Python packages
pip install opentelemetry-distro opentelemetry-exporter-otlp

# Auto-detect and install instrumentation for your dependencies
opentelemetry-bootstrap -a install

# Run with auto-instrumentation
OTEL_SERVICE_NAME=my-python-service \
OTEL_EXPORTER_OTLP_ENDPOINT=http://localhost:4317 \
OTEL_RESOURCE_ATTRIBUTES=deployment.environment=staging \
opentelemetry-instrument python app.py

# Check what libraries were auto-instrumented
opentelemetry-bootstrap
```

---

## Phase 3 — Run OTel Collector Locally (Docker)

```bash
# Create collector config file
cat > /tmp/otel-collector.yaml << 'EOF'
receivers:
  otlp:
    protocols:
      grpc:
        endpoint: 0.0.0.0:4317
      http:
        endpoint: 0.0.0.0:4318

processors:
  batch:
    timeout: 5s

exporters:
  logging:
    loglevel: debug
  otlp:
    endpoint: jaeger:4317
    tls:
      insecure: true

service:
  pipelines:
    traces:
      receivers: [otlp]
      processors: [batch]
      exporters: [logging, otlp]
    metrics:
      receivers: [otlp]
      processors: [batch]
      exporters: [logging]
EOF

# Run collector + Jaeger together
docker run -d --name jaeger \
  -p 16686:16686 \
  -p 4317:4317 \
  jaegertracing/all-in-one:latest

docker run -d --name otel-collector \
  --link jaeger:jaeger \
  -p 4317:4317 \
  -p 4318:4318 \
  -v /tmp/otel-collector.yaml:/etc/otel-collector-config.yaml \
  otel/opentelemetry-collector-contrib:latest \
  --config=/etc/otel-collector-config.yaml

# View Jaeger UI
open http://localhost:16686
```

---

## Phase 4 — Kubernetes OTel Operator

```bash
# Install cert-manager (OTel operator dependency)
kubectl apply -f https://github.com/cert-manager/cert-manager/releases/latest/download/cert-manager.yaml
kubectl wait --for=condition=ready pod -l app=cert-manager -n cert-manager --timeout=120s

# Install OTel Operator
kubectl apply -f https://github.com/open-telemetry/opentelemetry-operator/releases/latest/download/opentelemetry-operator.yaml
kubectl wait --for=condition=ready pod -l app.kubernetes.io/name=opentelemetry-operator -n opentelemetry-operator-system --timeout=120s

# Check operator is running
kubectl get pods -n opentelemetry-operator-system

# List CRDs installed by the operator
kubectl get crd | grep opentelemetry
```

---

## Phase 5 — Deploy OTel Collector in K8s

```bash
# Apply collector manifest
kubectl apply -f otelcollector.yaml

# Watch collector start up
kubectl get pods -n observability -w

# Tail collector logs (watch for exporter errors)
kubectl logs -n observability deployment/otel-collector -f

# Check collector's self-observability metrics
kubectl port-forward -n observability svc/otel-collector 8888:8888 &
curl -s http://localhost:8888/metrics | grep -E 'otelcol_(exporter|receiver|processor)'

# Check for dropped spans (bad sign!)
curl -s http://localhost:8888/metrics | grep otelcol_exporter_send_failed
```

---

## Phase 6 — Apply Auto-Instrumentation in K8s

```bash
# Apply the Instrumentation CR
kubectl apply -f instrumentation.yaml

# Verify it was created
kubectl get instrumentation -n default

# Annotate a deployment to inject OTel
kubectl annotate deployment checkout-service \
  instrumentation.opentelemetry.io/inject-java="true"

# Trigger rolling restart so annotation takes effect
kubectl rollout restart deployment/checkout-service

# Verify the javaagent was injected (look for -javaagent in env)
kubectl get pod -l app=checkout-service -o jsonpath='{.items[0].spec.containers[0].env}' | jq .

# Check for OTEL_* env vars
kubectl exec -it deployment/checkout-service -- env | grep OTEL
```

---

## Phase 7 — Verify Traces Are Flowing

```bash
# Port-forward to Jaeger
kubectl port-forward -n observability svc/jaeger-query 16686:16686 &

# Open Jaeger UI
open http://localhost:16686

# OR: query Jaeger API directly for recent traces
curl "http://localhost:16686/api/services"
curl "http://localhost:16686/api/traces?service=checkout-service&limit=10" | jq '.data[0].spans | length'

# Check trace counts via collector metrics
curl -s http://localhost:8888/metrics | grep otelcol_receiver_accepted_spans
```

---

## Phase 8 — Debug: Spans Not Appearing

```bash
# 1. Is the app sending to collector at all?
kubectl exec -it deployment/checkout-service -- \
  curl -v http://otel-collector:4317

# 2. Check for OTLP connection errors in app logs
kubectl logs deployment/checkout-service | grep -i "otel\|otlp\|telemetry"

# 3. Check collector received anything
curl -s http://localhost:8888/metrics | grep otelcol_receiver_accepted_spans

# 4. Check if exporter is failing
curl -s http://localhost:8888/metrics | grep otelcol_exporter_send_failed_spans

# 5. Verify traceparent header propagation
kubectl exec -it deployment/checkout-service -- \
  curl -v http://payment-service/charge -H "traceparent: 00-abc123-def456-01"
# Response should have traceparent header back

# 6. Check network policy isn't blocking port 4317
kubectl get networkpolicy -n default
```

---

## Phase 9 — Tail Sampling Config

```bash
# Check tail sampling processor stats
curl -s http://localhost:8888/metrics | grep tail_sampling

# How many traces kept vs dropped
curl -s http://localhost:8888/metrics | grep -E 'otelcol_processor_tail_sampling_(sampling_decision_timer_firing_period|sampled|not_sampled)'
```

---

## Phase 10 — OTel with Prometheus

```bash
# If using OTel metrics → Prometheus, check remote write
curl -s http://localhost:8888/metrics | grep prometheusremotewrite

# Query metrics from Prometheus
kubectl port-forward -n monitoring svc/prometheus 9090:9090 &

# Check OTel-sourced metrics in Prometheus
curl "http://localhost:9090/api/v1/label/service_name/values"
curl "http://localhost:9090/api/v1/query?query=rate(http_server_duration_milliseconds_count[5m])"
```
