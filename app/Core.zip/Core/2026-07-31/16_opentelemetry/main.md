# OpenTelemetry — Deep Dive for SREs

---

## E2E Flow Summary

```
Your App Code
    │
    ▼
[OTel SDK / Auto-Instrumentation]
    │  produces
    ▼
Traces  ──┐
Metrics ──┼──► [OTel Collector]  ──► Backend (Jaeger / Prometheus / Datadog / Dynatrace)
Logs    ──┘         │
                    └──► Multiple backends simultaneously
```

**One-line summary:** OpenTelemetry (OTel) is a vendor-neutral standard + SDK + Collector that lets you instrument your app ONCE and send observability data (traces, metrics, logs) to ANY backend without changing your code.

---

## Decision Tree — Which OTel Piece Do I Need?

```
Want to observe your app?
│
├── You want to know HOW LONG things take, WHAT path a request took
│       └── You need: TRACES (distributed tracing)
│
├── You want to know HOW MANY / HOW FAST / HOW MUCH
│       └── You need: METRICS (counters, gauges, histograms)
│
├── You want human-readable event records
│       └── You need: LOGS (structured log correlation)
│
├── Your app is Java/Python/Node (common)
│       └── Use: AUTO-INSTRUMENTATION (zero code change)
│
├── Your app is custom / needs specific spans
│       └── Use: MANUAL INSTRUMENTATION (OTel SDK)
│
└── You need to route / filter / batch signals
        └── Use: OTEL COLLECTOR
```

---

## Tool Map

| Component | What it is | Analogy |
|---|---|---|
| OTel API | Interfaces/contracts (no logic) | Blueprint |
| OTel SDK | Actual implementation of the API | The builder following the blueprint |
| Auto-Instrumentation | Agent attached at runtime, no code change | Spy camera installed without touching the wall |
| OTel Collector | Receives, processes, exports signals | A post office that accepts any parcel, sorts it, ships to any address |
| OTLP | The wire protocol (gRPC/HTTP) OTel uses | The language everything speaks |
| Trace | End-to-end record of ONE request journey | A receipt that records every store the package visited |
| Span | One operation within a trace | One row on that receipt |
| Metric | Numerical measurement over time | Your car's speedometer reading |
| Log | Timestamped text event | A diary entry |

---

## Part 1 — Why OpenTelemetry Exists (The Problem)

### Before OTel: The Observability Mess

Before OTel (pre-2019), every APM vendor had their own agent:

```
Your App
  ├── Datadog agent  →  Datadog only
  ├── Dynatrace agent → Dynatrace only
  ├── Jaeger client  → Jaeger only
  └── Custom logs    → ???
```

**Problems:**
- Switching vendors = rewriting ALL instrumentation code
- Each vendor's data format was incompatible
- Two CNCF projects (OpenTracing + OpenCensus) existed but couldn't agree
- Teams were locked in to vendors

### The Solution: OpenTelemetry (2019)

OpenTracing + OpenCensus **merged** into OpenTelemetry in 2019 under CNCF.

**OTel's promise:** Write instrumentation once → send to ANY vendor.

```
Your App  →  OTel SDK  →  OTel Collector  →  Vendor A
                                          →  Vendor B
                                          →  Vendor C (simultaneously)
```

---

## Part 2 — The Three Pillars of Observability

OTel handles all three signals (the "observability triangle"):

### Pillar 1: Traces

A **trace** is the complete journey of a single request across ALL services.

```
User clicks "Buy"
│
├─[Span: frontend /checkout]  200ms
│   ├─[Span: auth-service validate]  10ms
│   ├─[Span: cart-service get_items]  30ms
│   │   └─[Span: postgres query]  25ms
│   └─[Span: payment-service charge]  120ms
│       └─[Span: stripe API call]  110ms
```

Each box = one **Span**. All boxes together = one **Trace**.

**Key span fields:**
```
Span {
  trace_id:    "abc123"          # same for all spans in this trace
  span_id:     "def456"          # unique to THIS span
  parent_id:   "aaa111"          # who called me
  name:        "POST /checkout"
  start_time:  1722400000.000
  end_time:    1722400000.200
  status:      OK | ERROR
  attributes:  { http.method: "POST", http.status_code: 200 }
  events:      [ {name: "cache miss", timestamp: ...} ]
}
```

**Why it matters for SRE:** You can see EXACTLY which service is slow, which DB query is taking 10x longer than normal, and trace a 500 error back to its root cause — across 20 microservices.

---

### Pillar 2: Metrics

Metrics are **numerical measurements over time**.

OTel defines these metric types:

| Type | What it counts | Example |
|---|---|---|
| Counter | Monotonically increasing number | http_requests_total |
| UpDownCounter | Goes up AND down | active_connections |
| Gauge | Point-in-time value | memory_usage_bytes |
| Histogram | Distribution of values | request_duration_ms (buckets: <10ms, <50ms, <200ms) |

**Why Histogram matters most for SREs:**
```
request_duration_ms histogram tells you:
  - p50 (median): 12ms
  - p95:          180ms
  - p99:          2100ms   ← 1% of users wait 2+ seconds!

An average would just say: "avg = 25ms" — which hides the pain
```

**Metric attributes (labels):**
```
http_requests_total{
  service="checkout",
  method="POST",
  status="500",
  region="ap-northeast-1"
}  = 42
```

---

### Pillar 3: Logs

OTel's log support correlates logs with traces using `trace_id` and `span_id`.

**Before OTel logs:**
```
2026-07-31 10:00:01 ERROR Payment failed for user 999
# → No way to know which trace this belongs to
```

**With OTel logs:**
```json
{
  "timestamp": "2026-07-31T10:00:01Z",
  "severity": "ERROR",
  "body": "Payment failed for user 999",
  "trace_id": "abc123def456",
  "span_id": "789xyz",
  "service.name": "payment-service"
}
```

Now in Jaeger/Datadog/Dynatrace, you can: click a failing trace → jump straight to the exact log lines that happened during that span.

---

## Part 3 — OTel SDK Deep Dive

### API vs SDK

| | OTel API | OTel SDK |
|---|---|---|
| What | Interfaces only (no real code) | Full implementation |
| Used by | Library authors | App developers / SREs |
| Dependency | Lightweight, safe for libraries | Full feature set |

### SDK Components

```
OTel SDK
├── TracerProvider     ← creates Tracers (one per service)
│   └── Tracer         ← creates Spans
├── MeterProvider      ← creates Meters
│   └── Meter          ← creates instruments (counters, histograms)
├── LoggerProvider     ← creates Loggers
│   └── Logger         ← emits log records
├── Propagators        ← inject/extract context across network calls
└── Exporters          ← send data out (OTLP, Jaeger, Prometheus, console)
```

### Creating a Span (Java example)

```java
// Get a tracer
Tracer tracer = openTelemetry.getTracer("com.example.checkout");

// Create a span
Span span = tracer.spanBuilder("processOrder")
    .setAttribute("order.id", orderId)
    .setAttribute("user.id", userId)
    .startSpan();

try (Scope scope = span.makeCurrent()) {
    // your actual business logic
    processPayment(orderId);
    span.setStatus(StatusCode.OK);
} catch (Exception e) {
    span.setStatus(StatusCode.ERROR, e.getMessage());
    span.recordException(e);
} finally {
    span.end();  // ALWAYS end spans
}
```

### Creating a Metric (Python example)

```python
from opentelemetry import metrics

meter = metrics.get_meter("checkout-service")

# Counter: total orders
orders_counter = meter.create_counter(
    "orders.total",
    description="Total number of orders processed"
)

# Histogram: how long checkouts take
checkout_duration = meter.create_histogram(
    "checkout.duration",
    unit="ms",
    description="Checkout processing time"
)

# Usage
orders_counter.add(1, {"status": "success", "region": "apac"})
checkout_duration.record(142.5, {"payment_method": "card"})
```

---

## Part 4 — Auto-Instrumentation (Zero Code Change)

For Java, Python, Node.js — OTel provides agents that attach at startup and automatically instrument:
- HTTP clients/servers
- Database drivers (JDBC, pg, redis)
- Messaging (Kafka, RabbitMQ)
- gRPC calls

### Java Auto-Instrumentation

```bash
# Download the OTel Java agent
wget https://github.com/open-telemetry/opentelemetry-java-instrumentation/releases/latest/download/opentelemetry-javaagent.jar

# Run your app with the agent attached (no code change!)
java -javaagent:opentelemetry-javaagent.jar \
  -Dotel.service.name=checkout-service \
  -Dotel.exporter.otlp.endpoint=http://otel-collector:4317 \
  -Dotel.resource.attributes=deployment.environment=production \
  -jar your-app.jar
```

The agent:
1. Hooks into the JVM at startup
2. Instruments 100+ libraries automatically
3. Sends traces/metrics/logs to the collector

### Python Auto-Instrumentation

```bash
# Install
pip install opentelemetry-distro opentelemetry-exporter-otlp
opentelemetry-bootstrap -a install   # auto-detects and installs all needed libs

# Run
opentelemetry-instrument \
  --service_name=my-python-service \
  --exporter_otlp_endpoint=http://otel-collector:4317 \
  python app.py
```

---

## Part 5 — The OTel Collector (The Post Office)

The Collector is the most important infrastructure component of OTel.

### Why Use a Collector?

Without Collector:
```
App → directly → Datadog
# Problem: if you switch to Dynatrace, you change every app's config
```

With Collector:
```
App → Collector → Datadog
                → Dynatrace  (simultaneously)
                → Prometheus
                → S3 (archive)
# Only the Collector config changes — apps are untouched
```

### Collector Pipeline Architecture

```
RECEIVERS        PROCESSORS           EXPORTERS
─────────        ──────────           ─────────
otlp/grpc   →   batch          →   otlp (Jaeger/Tempo)
otlp/http   →   memory_limiter →   prometheusremotewrite
jaeger      →   resource       →   datadog
zipkin      →   filter         →   dynatrace
prometheus  →   transform      →   logging (debug)
             →   tail_sampling
```

**Every signal flows through:** Receiver → Processor → Exporter

### Collector Config (collector.yaml)

```yaml
receivers:
  otlp:
    protocols:
      grpc:
        endpoint: 0.0.0.0:4317
      http:
        endpoint: 0.0.0.0:4318

processors:
  batch:                    # batch data before exporting (efficiency)
    timeout: 10s
    send_batch_size: 1000

  memory_limiter:           # prevent OOM on high load
    limit_mib: 512
    spike_limit_mib: 128

  resource:                 # add/modify attributes on all signals
    attributes:
      - action: insert
        key: environment
        value: production

  filter/drop_health:       # drop noisy health-check spans
    traces:
      span:
        - 'attributes["http.target"] == "/health"'

exporters:
  otlp:
    endpoint: jaeger:4317
    tls:
      insecure: true

  prometheusremotewrite:
    endpoint: http://prometheus:9090/api/v1/write

  dynatrace:
    endpoint: https://TENANT.live.dynatrace.com/api/v2/otlp
    headers:
      Authorization: "Api-Token YOUR_TOKEN"

service:
  pipelines:
    traces:
      receivers:  [otlp]
      processors: [memory_limiter, batch, resource, filter/drop_health]
      exporters:  [otlp, dynatrace]

    metrics:
      receivers:  [otlp]
      processors: [memory_limiter, batch, resource]
      exporters:  [prometheusremotewrite, dynatrace]

    logs:
      receivers:  [otlp]
      processors: [memory_limiter, batch, resource]
      exporters:  [dynatrace]
```

### Collector Deployment Modes

**Mode 1: Agent (sidecar/daemonset)**
```
Each node runs a Collector agent → sends to central Collector
Good for: low latency, local processing
```

**Mode 2: Gateway (central)**
```
One (or a few) Collectors receive from all agents → fan-out to backends
Good for: centralized filtering, auth, routing
```

**Mode 3: Both (recommended for production)**
```
Pod sidecar → Node DaemonSet agent → Gateway Collector → Backends
```

---

## Part 6 — Context Propagation

This is how a trace stays connected across service boundaries.

### The Problem

```
Service A calls Service B over HTTP.
How does Service B know it's part of the SAME trace as Service A?
```

### The Solution: Propagation Headers

OTel injects trace context into HTTP headers:

```
GET /checkout HTTP/1.1
Host: checkout-service
traceparent: 00-abc123def456-789xyz-01
              │  │              │      └── flags (sampled=01)
              │  │              └── parent span id
              │  └── trace id (same across ALL services)
              └── version
```

Every OTel-instrumented service:
1. **Extracts** `traceparent` from incoming requests
2. Creates a child span with that trace_id as parent
3. **Injects** `traceparent` into all outgoing requests

Result: All spans across all services share the same `trace_id` → stitched together in the backend as one trace.

### Propagators

OTel supports multiple propagation formats:
| Format | Used by |
|---|---|
| W3C TraceContext (`traceparent`) | Default, modern |
| B3 (single/multi header) | Zipkin, legacy |
| Baggage | Custom key-value across services |
| AWS X-Ray | AWS services |

---

## Part 7 — Sampling

In high-traffic systems, you cannot store 100% of traces. Sampling controls which traces to keep.

### Head-Based Sampling (at start of trace)

Decision made when the FIRST span starts:
```yaml
# Collector config: keep 10% of all traces
sampler:
  type: probabilistic
  sampling_percentage: 10
```

**Problem:** You don't know yet if the trace will error or be slow.

### Tail-Based Sampling (at end of trace, better)

Wait until trace is complete, THEN decide:
```yaml
processors:
  tail_sampling:
    decision_wait: 10s
    policies:
      - name: errors-policy
        type: status_code
        status_code: {status_codes: [ERROR]}   # always keep errors

      - name: slow-traces
        type: latency
        latency: {threshold_ms: 1000}           # keep anything >1s

      - name: random-sample
        type: probabilistic
        probabilistic: {sampling_percentage: 5} # keep 5% of the rest
```

**This is what you want in production:** Keep 100% of errors, 100% of slow traces, 5% of normal traffic.

---

## Part 8 — OTel in Kubernetes

### Operator (recommended)

The OpenTelemetry Operator for Kubernetes automates agent injection:

```yaml
# Auto-inject OTel Java agent into any pod with this annotation
apiVersion: opentelemetry.io/v1alpha1
kind: Instrumentation
metadata:
  name: java-instrumentation
spec:
  exporter:
    endpoint: http://otel-collector:4317
  java:
    image: ghcr.io/open-telemetry/opentelemetry-operator/autoinstrumentation-java:latest
  propagators:
    - tracecontext
    - baggage
```

```yaml
# In your Deployment, just add this annotation:
apiVersion: apps/v1
kind: Deployment
metadata:
  name: checkout-service
spec:
  template:
    metadata:
      annotations:
        instrumentation.opentelemetry.io/inject-java: "true"  # ← that's it
```

The operator automatically injects the `-javaagent` JVM arg. No Dockerfile changes.

### Collector as DaemonSet

```yaml
apiVersion: opentelemetry.io/v1alpha1
kind: OpenTelemetryCollector
metadata:
  name: otel-agent
spec:
  mode: daemonset
  config: |
    receivers:
      otlp:
        protocols:
          grpc:
            endpoint: 0.0.0.0:4317
    exporters:
      otlp:
        endpoint: otel-gateway:4317
    service:
      pipelines:
        traces:
          receivers: [otlp]
          exporters: [otlp]
```

---

## Part 9 — OTel vs Other Tools

| | OpenTelemetry | Dynatrace OneAgent | Prometheus | Jaeger |
|---|---|---|---|---|
| What | Instrumentation standard | Full-stack APM agent | Metrics system | Distributed tracing UI |
| Vendor lock-in | None | Dynatrace only | None | None |
| Signals | Traces + Metrics + Logs | Traces + Metrics + Logs | Metrics only | Traces only |
| Auto-instrument | Yes (agent) | Yes (deeper) | No | No |
| Storage | No (needs backend) | Yes | Yes | Yes |
| Use together? | Yes | Yes (OTel → Dynatrace) | Yes (OTel → Prometheus) | Yes (OTel → Jaeger) |

**Key insight:** OTel is NOT a backend. It's the pipeline. You send OTel data TO Dynatrace/Prometheus/Jaeger.

---

## Part 10 — SRE Day-to-Day: OTel in Practice

### Investigating a 500 Error

```
1. Alert fires: checkout-service error rate > 1%

2. Open Jaeger/Datadog → filter traces by status=ERROR, service=checkout

3. Click a failing trace → see full span tree:
   checkout (200ms) ─► auth (5ms OK) ─► payment (195ms ERROR)
                                           └► stripe-api (190ms TIMEOUT)

4. Root cause: Stripe API timing out

5. Check metric: external_calls_duration{target="stripe"} → p99 = 8000ms
   (normally p99 = 200ms)

6. Check logs (correlated by trace_id): "Connection timeout after 5000ms"

7. Fix: circuit breaker or fallback, notify Stripe
```

### SLI/SLO with OTel Metrics

```yaml
# OTel metric: request_duration_milliseconds (histogram)
# SLO: 99% of requests complete in < 500ms

# PromQL for SLI calculation:
sum(rate(request_duration_milliseconds_bucket{
  service="checkout",
  le="500"
}[5m]))
/
sum(rate(request_duration_milliseconds_count{
  service="checkout"
}[5m]))
```

---

## Common Mistakes

| Mistake | Problem | Fix |
|---|---|---|
| Not ending spans | Memory leak, trace never exported | Always call `span.end()` in finally block |
| Too many attributes on spans | High cardinality, storage explosion | Use low-cardinality attributes (status, method), not user IDs |
| Sampling 100% in prod | Overwhelms backend, huge cost | Use tail-based sampling, keep errors + slow |
| Collector as SPOF | One collector goes down, all data lost | Run 2+ Collectors behind a load balancer |
| Missing propagation headers | Broken traces across services | Verify `traceparent` header passes through all proxies/LBs |
| Using console exporter in prod | Logs flooded with trace data | Console exporter = debug only |
| SDK without resource attributes | Can't tell which service sent what | Always set `service.name`, `deployment.environment` |
