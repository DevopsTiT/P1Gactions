# Glossary — GitOps Folder Deep-Dive
Every term from main.md, explained for an SRE beginner. One entry per term.

---

**GitOps**
A way of managing infrastructure where the desired state is stored in Git, and a tool (ArgoCD here) continuously makes the actual cluster match what Git says. Why it matters: you never manually apply YAML — you push to Git and ArgoCD does the rest. Audit trail, rollback, and review all come for free via Git history.

**ArgoCD**
A program that runs inside Kubernetes and watches a Git repository. When the repo changes, ArgoCD automatically applies those changes to the cluster. Why it matters: the "brain" of this entire GitOps setup — after the one bootstrap command, ArgoCD manages everything else.

**ArgoCD Application**
A YAML resource (`kind: Application`) that tells ArgoCD: "watch this folder in this repo, and apply everything you find there to this cluster." Why it matters: every YAML file in `gitops/` except the root-app IS an ArgoCD Application — they each manage one component.

**Root-app (App of Apps pattern)**
A single ArgoCD Application that points at a folder containing OTHER ArgoCD Applications. It "discovers" and manages all of them. Why it matters: `root-app-dev.yaml` is the ONLY file you apply manually — ArgoCD finds and manages all the other 9+ Applications automatically.

**`recurse: true` (ArgoCD)**
Tells ArgoCD to search ALL subdirectories under `path:`, not just the top level. Why it matters: without it, ArgoCD only reads `gitops/dev/*.yaml` — it would completely ignore `gitops/dev/app/payment-service/payment-service.yaml` and all nested files.

**`prune: true` (ArgoCD)**
When a file is deleted from Git, `prune: true` tells ArgoCD to also delete the corresponding resource from the cluster. Why it matters: without it, removing notification-service from Git still leaves its Deployment, Service, and Ingress running forever in the cluster (ghost resources).

**`selfHeal: true` (ArgoCD)**
ArgoCD reverts any manual change made with `kubectl edit` or `kubectl apply` within ~3 minutes. Why it matters: enforces the rule "all changes must go through Git" — nobody can quietly modify production config by hand without it appearing in Git history.

**Sync wave (`argocd.argoproj.io/sync-wave`)**
A number that controls deployment order. Lower numbers deploy first. Wave -1 runs before wave 0, which runs before wave 1, etc. Why it matters: namespaces must exist before services can be placed in them; ESO must run before DynaKube can pull its tokens.

**Wave order in this project**
wave -1 = namespaces → wave 1 = ALB Controller + ExternalDNS → wave 2 = ESO + ClusterSecretStore → wave 3 = Dynatrace Operator + DynaKube → wave 8 = payment/order/notification services. Why it matters: each wave depends on the previous one having completed successfully.

**`finalizers: resources-finalizer.argocd.argoproj.io`**
A Kubernetes finalizer that tells ArgoCD: "when this Application is deleted, first delete ALL resources it manages in the cluster, then remove the Application." Why it matters: without it, deleting the root-app leaves orphaned Deployments, Services, Namespaces in the cluster.

**Kubernetes Namespace**
A virtual partition inside a cluster that groups related resources. Like a folder in a filesystem. Why it matters: `payment-ns` contains all payment-service pods and services; `order-ns` contains order-service resources. Teams can be given access to their namespace only.

**Namespace labels**
Key-value pairs attached to a namespace that all pods inside it inherit. Like sticky notes on a room that apply to everything inside. Why it matters: `team=payments, environment=dev` labels are read by Dynatrace OneAgent to auto-tag every pod in that namespace.

**Dynatrace auto-tagging**
A Dynatrace feature that automatically assigns tags to monitored entities based on Kubernetes labels. Rule: "if namespace label `team=payments` → tag this entity `team:payments`." Why it matters: tags connect pods to management zones, which connect to alerting profiles, which connect to PagerDuty/Slack notifications.

**AWS Load Balancer Controller**
A program running in Kubernetes (deployed as a Deployment) that watches `Ingress` objects and calls AWS APIs to create Application Load Balancers (ALBs) in front of services. Why it matters: without it, creating an Ingress object does nothing — no ALB is ever created, no external traffic can reach your service.

**Ingress**
A Kubernetes resource that defines routing rules for external HTTP traffic: "requests to `payment.dev.company.com` go to the `payment-service` Service on port 8080." Why it matters: the Ingress is what connects the public internet to pods inside the cluster.

**ALB (Application Load Balancer)**
An AWS-managed layer-7 load balancer that distributes incoming HTTPS/HTTP traffic across pods. Why it matters: this is the public entry point for all three Java services — it handles TLS termination (HTTPS), health checks, and routing to healthy pods.

**ExternalDNS**
A program in Kubernetes that watches Ingress objects and automatically creates/updates DNS records in AWS Route53. Why it matters: when payment-service creates an Ingress with `host: payment.dev.company.com`, ExternalDNS creates the DNS A record pointing to the ALB — no manual DNS configuration needed.

**Route53**
AWS managed DNS service. Translates domain names (e.g. `payment.dev.company.com`) to IP addresses. Why it matters: ExternalDNS writes here; users' browsers read here. If Route53 is wrong, users can't reach the service even if it's running fine.

**`txtOwnerId`**
A unique string that ExternalDNS writes into Route53 TXT records to mark which DNS records it owns. Why it matters: prevents dev ExternalDNS from deleting production DNS records. Each environment has a different ID (`company-dev`, `company-staging`, `company-production`) so they don't conflict.

**`domainFilters`**
A list of DNS zones ExternalDNS is allowed to manage. Dev ExternalDNS only touches `dev.company.com`; production only touches `company.com`. Why it matters: safety boundary — if ExternalDNS has a bug, it can only affect its own zone.

**External Secrets Operator (ESO)**
A Kubernetes program that reads secrets from external stores (AWS Secrets Manager, Vault, etc.) and creates Kubernetes `Secret` objects. Why it matters: DT API tokens, DB passwords — none of them are stored in Git. ESO pulls them at deploy time and creates the K8s Secrets apps need.

**ClusterSecretStore**
An ESO resource that defines HOW to connect to a secret provider for the whole cluster. Like an address book entry: "to fetch secrets, connect to AWS Secrets Manager in region ap-northeast-1 using this IAM role." Why it matters: once created, any ExternalSecret in any namespace can use it without repeating the connection config.

**ExternalSecret**
An ESO resource that says "fetch the value at THIS path in Secrets Manager, and create a Kubernetes Secret named X with it." Why it matters: `ExternalSecret` for DynaKube pulls the DT tokens → creates K8s Secret named `dynakube` → DynaKube reads it to authenticate with Dynatrace.

**AWS Secrets Manager**
An AWS service that stores encrypted secrets (passwords, API keys, tokens). Why it matters: the ESO pattern means NO secrets are ever in Git. Git only contains paths like `dev/dynatrace/api-token` which ESO resolves at runtime.

**IRSA (IAM Roles for Service Accounts)**
AWS feature that lets a Kubernetes pod assume an IAM role using a JWT token, without any access keys. `eks.amazonaws.com/role-arn: arn:aws:iam::...` annotation on a ServiceAccount enables this. Why it matters: ESO can call Secrets Manager, ALB Controller can create load balancers, payment-service can access RDS — all without storing AWS credentials anywhere.

**Dynatrace Operator**
A Kubernetes Operator (a program + CRD combination) that manages the DynaKube lifecycle — installs OneAgent DaemonSets, manages ActiveGate deployments, handles upgrades. Why it matters: you don't manually deploy OneAgent. You create a DynaKube resource; the Operator figures out what to deploy.

**DynaKube**
A custom Kubernetes resource (not built-in) that describes the desired state of Dynatrace monitoring in this cluster. Sections: `classicFullStack` (OneAgent), `activeGate`, `logMonitoring`. Why it matters: the master switch — change one field here to enable/disable/resize any DT monitoring component.

**`classicFullStack: enabled: true`**
The DynaKube setting that deploys OneAgent as a DaemonSet (one pod per EKS node). Provides full JVM instrumentation of all Java processes on every node. Why it matters: this single flag is what enables zero-code Java monitoring. Without it, DT sees nothing about the Java services.

**DaemonSet**
A Kubernetes resource that ensures exactly one pod runs on EVERY node in the cluster. Used for node-level agents like OneAgent. Why it matters: if a new node is added (auto-scaling), Kubernetes automatically starts a OneAgent pod on it — no manual action needed.

**JVMTI (Java Virtual Machine Tool Interface)**
The Java API that allows external agents to hook into a running JVM at a low level. OneAgent uses this to inject monitoring without modifying application code. Why it matters: this is how DT captures HTTP metrics, DB query times, and heap stats from your Java app with zero code changes.

**ActiveGate**
A Dynatrace component (runs as a pod in the cluster) that collects data from OneAgent instances and routes it to the DT SaaS tenant over HTTPS. Think of it as a local relay station. Why it matters: EKS nodes can't directly send data to the DT cloud; ActiveGate acts as the gateway for all cluster monitoring data.

**`activeGate.replicas: 2` (production)**
Production runs 2 ActiveGate pods spread across 2 AWS Availability Zones. Why it matters: if one AZ has a problem (hardware failure, network issue), the other ActiveGate pod in the second AZ continues routing metrics and traces to Dynatrace — no monitoring gap.

**`topologySpreadConstraints`**
Kubernetes settings that control how pods are spread across zones/nodes. `DoNotSchedule` = hard rule (pod stays Pending rather than violate the spread). Why it matters: ensures the 2 ActiveGate pods are never both in the same AZ — guarantees HA even during AZ failures.

**`logMonitoring: enabled: true` (DynaKube)**
Enables OneAgent to read container log files from each node (`/var/log/containers/*.log`) and ingest them into Dynatrace's log analytics engine. Why it matters: replaces a separate Fluent Bit + OpenSearch log pipeline — one fewer moving part to operate.

**`kubernetesMonitoring: enabled: true` (DynaKube)**
Enables ActiveGate to call the Kubernetes API and collect cluster-level metrics: node CPU/memory, pod counts, deployment status, HPA metrics. Why it matters: DT can alert on "nodes are at 90% CPU" or "payment-service has 0 ready replicas" — cluster health, not just app health.

**Helm chart values files**
Files that contain configuration values injected into a Helm chart template. `values.yaml` = production defaults. `values-dev.yaml` = overrides specific to dev (cheaper resources, debug settings). Why it matters: one chart, multiple environments — only the diff is in the override file.

**`valueFiles: [values.yaml, values-dev.yaml]`**
ArgoCD applies both files; the second file wins on conflicts. So `replicaCount: 1` in `values-dev.yaml` overrides `replicaCount: 3` in `values.yaml`. Why it matters: the base file stays valid for production; dev only writes what it needs to change.

**`PLACEHOLDER` image tag**
The image tag written in the gitops YAML file before CI runs. CI replaces it with the real image digest/tag during the deploy pipeline step. Why it matters: the gitops repo is the source of truth for what's deployed — CI commits the actual tag to Git, and ArgoCD reads it from there.

**ECR (Elastic Container Registry)**
AWS managed Docker image registry. Dev account (`123456789010`) has its own ECR; production account (`123456789012`) has its own ECR. Why it matters: images can't accidentally cross environment boundaries — production can't pull a dev image because it doesn't have permission to access the dev ECR.

**`ignoreDifferences: jsonPointers: [/spec/replicas]`**
Tells ArgoCD to ignore the `spec.replicas` field when comparing desired vs actual state. Why it matters: HPA (Horizontal Pod Autoscaler) changes `spec.replicas` dynamically based on load. Without this, ArgoCD immediately reverts HPA's scaling decisions — service can't scale.

**HPA (Horizontal Pod Autoscaler)**
A Kubernetes controller that automatically changes `spec.replicas` on a Deployment based on CPU/memory/custom metrics. Why it matters: under load, HPA scales from 3 to 8 replicas; `ignoreDifferences` on `/spec/replicas` prevents ArgoCD from fighting HPA by resetting it back to 3.

**`Timeout=900` (ArgoCD syncOption)**
Tells ArgoCD to wait up to 900 seconds (15 minutes) for all resources to become healthy after a sync. Why it matters: Java Spring Boot with Dynatrace OneAgent takes 1-10 minutes to start on a cold JVM. Without this, ArgoCD marks the deploy as failed before the JVM even finishes loading.

**`ServerSideApply=true` (ArgoCD syncOption)**
Uses Kubernetes server-side apply (instead of client-side apply) when creating/updating resources. Why it matters: needed for large CRDs (like DynaKube) and resources managed by multiple controllers — avoids field ownership conflicts that cause "conflict: already owned by manager X" errors.

**`CreateNamespace=true` (ArgoCD syncOption)**
ArgoCD creates the destination namespace if it doesn't exist before applying resources. Why it matters: backup for the wave -1 namespace creation — if the namespace wasn't pre-created, ArgoCD creates it on the fly rather than failing.

**ACM (AWS Certificate Manager)**
AWS service that issues and manages TLS certificates. `certArn` in a production Ingress annotation tells the ALB Controller which certificate to attach to the ALB for HTTPS. Why it matters: production traffic is HTTPS; dev/staging may use HTTP. ACM cert = no certificate expiry management needed (AWS auto-renews).

**`project: payments` (ArgoCD project)**
An ArgoCD RBAC boundary. Only users/teams with access to the `payments` project can edit or sync the payment-service Application. Why it matters: prevents the orders team from accidentally deploying to payment-service's namespace, and vice versa.

**`project: platform` (ArgoCD project)**
The ArgoCD project for cluster-wide infrastructure components (ALB Controller, ExternalDNS, ESO, Dynatrace). Only the platform team has access. Why it matters: app teams can't accidentally delete or modify the load balancer controller.

**Ghost resources**
Kubernetes resources left running in a cluster after they were removed from the gitops repo, because `prune: false` was set (or never set). Like zombie processes — still consuming memory and CPU but no longer managed. Why it matters: avoided by `prune: true`, which cleans up cluster resources when the corresponding Git file is deleted.

**`policy: sync` (ExternalDNS)**
ExternalDNS both creates AND deletes Route53 records to match the current set of Ingress objects. Alternative `policy: upsert-only` only creates, never deletes. Why it matters: `sync` means if you remove an Ingress, ExternalDNS removes the DNS record too — no stale DNS entries pointing to gone services.
