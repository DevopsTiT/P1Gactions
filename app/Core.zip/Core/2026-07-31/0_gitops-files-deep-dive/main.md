# GitOps Folder — Every File Deep-Dive
> Project: `38_java-3envs-dynatrace`
> Folder: `gitops/` — the Git-based source of truth for what runs in each Kubernetes cluster

---

## Decision Tree — How This Folder Works

```
You push a file into gitops/<env>/...
         │
         ▼
ArgoCD detects the change (polls every 3 min or webhook)
         │
         ▼
Is this a new file?
  YES → ArgoCD creates the resource in Kubernetes
  NO  → Is the cluster state different from the file?
          YES → ArgoCD syncs (applies the file to the cluster)
          NO  → Nothing to do

Did you DELETE a file from gitops/?
  → prune: true → ArgoCD deletes the resource from the cluster too

Did someone do kubectl edit manually?
  → selfHeal: true → ArgoCD reverts it within ~3 min
```

```
BOOTSTRAP (one time per environment):
  kubectl apply -f gitops/dev/bootstrap/root-app-dev.yaml
         │
         ▼
  ArgoCD root-app reads gitops/dev/ with recurse: true
         │
         ▼
  Discovers ALL Application YAMLs inside → manages them
         │
         ▼
  Each Application deploys in sync-wave ORDER:
    wave -1: namespaces.yaml          (must exist before anything else)
    wave  1: ALB Controller, ExternalDNS  (networking layer)
    wave  2: cluster-secret-store.yaml    (secret provider)
    wave  3: dynatrace-operator.yaml      (observability)
    wave  8: payment/order/notification   (the actual apps)

Why order matters: DynaKube (wave 3) creates pods in the "dynatrace" namespace.
If namespaces (wave -1) hadn't run yet → namespace doesn't exist → DynaKube fails.
```

---

## File Tree (annotated)

```
gitops/
├── dev/
│   ├── bootstrap/
│   │   └── root-app-dev.yaml          ← APPLY THIS ONCE — manages everything below
│   ├── namespaces/
│   │   └── namespaces.yaml            ← wave -1: 5 namespaces with team/env labels
│   ├── networking/
│   │   ├── aws-load-balancer-controller.yaml  ← wave 1: creates AWS ALBs
│   │   └── external-dns.yaml                 ← wave 1: Route53 A records
│   ├── secrets/
│   │   └── cluster-secret-store.yaml  ← wave 2: ESO + ClusterSecretStore
│   ├── monitoring/
│   │   └── dynatrace/
│   │       └── dynatrace-operator.yaml ← wave 3: DT Operator + DynaKube + ExternalSecret
│   └── app/
│       ├── payment-service/
│       │   └── payment-service.yaml   ← wave 8: deploys payment-service via Helm
│       ├── order-service/
│       │   └── order-service.yaml     ← wave 8: deploys order-service via Helm
│       └── notification-service/
│           └── notification-service.yaml ← wave 8: deploys notification-service via Helm
│
├── staging/   (same structure, staging account/cluster)
└── production/ (same structure, production account/cluster)
```

---

## Part 1 — `bootstrap/root-app-dev.yaml`

### What it does

This is the ONLY file you apply manually. Once applied, ArgoCD manages everything else automatically.

```yaml
kind: Application          # ← ArgoCD resource type
metadata:
  name: root-app-dev
  namespace: argocd        # ← ArgoCD must live in its own namespace

spec:
  project: platform        # ← ArgoCD project (RBAC scope — platform team owns this)

  source:
    repoURL: https://github.com/company/java-3envs-dynatrace.git
    targetRevision: HEAD   # ← always track latest commit on default branch
    path: gitops/dev       # ← scan THIS folder for Application YAMLs
    directory:
      recurse: true        # ← scan ALL subdirectories (app/, monitoring/, etc.)

  destination:
    server: https://kubernetes.default.svc  # ← "this cluster" (not a remote cluster)
    namespace: argocd

  syncPolicy:
    automated:
      prune: true          # ← if file deleted from Git → delete from cluster
      selfHeal: true       # ← if kubectl edit changes something → revert within 3 min
    syncOptions:
      - CreateNamespace=true    # ← create argocd namespace if missing
      - ServerSideApply=true    # ← use server-side apply (handles large CRDs better)
```

### Why `recurse: true` is critical

Without it: ArgoCD only reads files at `gitops/dev/*.yaml` — the top level.
It would IGNORE `gitops/dev/app/payment-service/payment-service.yaml`, `gitops/dev/monitoring/...`, etc.

With `recurse: true`: ArgoCD walks every subdirectory and finds all Application YAMLs.
One command → all 9+ Applications discovered and managed.

### Why `finalizers` is there

```yaml
finalizers:
  - resources-finalizer.argocd.argoproj.io
```

When you delete the root-app ArgoCD Application, ArgoCD first cascades the deletion to ALL child Applications and their cluster resources — then removes the root-app. Without this finalizer: deleting root-app leaves all the Deployments, Services, Namespaces etc. as orphans in the cluster.

### Staging vs Production difference

- `root-app-staging.yaml`: `path: gitops/staging`, name: `root-app-staging`
- `root-app-production.yaml`: `path: gitops/production`, name: `root-app-production`
- Otherwise identical — same GitOps mechanic, different paths

---

## Part 2 — `namespaces/namespaces.yaml` (wave -1)

### What it does

Creates 5 Kubernetes namespaces with labels that Dynatrace reads for auto-tagging.

```yaml
metadata:
  annotations:
    argocd.argoproj.io/sync-wave: "-1"   # ← FIRST thing deployed
```

```yaml
helm:
  values: |
    environment: dev
    namespaces:
      - name: payment-ns
        labels: { team: payments, environment: dev }
      - name: order-ns
        labels: { team: orders, environment: dev }
      - name: notification-ns
        labels: { team: notifications, environment: dev }
      - name: dynatrace
        labels: { team: platform, environment: dev }
      - name: external-secrets
        labels: { team: platform, environment: dev }
```

### Why labels matter — the Dynatrace chain

```
Namespace label: team=payments, environment=dev
       │
       ▼ (OneAgent reads namespace labels from every pod in that namespace)
Dynatrace auto-tagging rule:
  "if Kubernetes namespace label team=payments → tag entity team:payments"
       │
       ▼ (Terraform management zone rule)
Management zone filter:
  "include entities with tag team:payments AND environment:dev"
       │
       ▼
Alerting profile scoped to this management zone
       │
       ▼
Slack #alerts-payments and PagerDuty for payments team — NOT orders team
```

If you forget the namespace labels → Dynatrace tags nothing → management zone is empty → NO alerts fire for that service. This is the most common "why am I not getting alerts" bug.

### Why wave -1 (minus 1)?

Kubernetes namespaces must exist before any resource inside them can be created. ArgoCD deploys in ascending wave order. Wave -1 is lower than wave 0, 1, 2, 3, 8 — so namespaces are always first.

If namespaces deployed at wave 8 (same as services):
- payment-service tries to create a Deployment in `payment-ns`
- `payment-ns` doesn't exist yet
- Error: "namespace payment-ns not found"

### Staging/Production difference

Same structure, only these values change:
- `environment: dev` → `environment: staging` / `environment: production`
- Label values: `{ team: payments, environment: staging }` etc.

---

## Part 3 — `networking/aws-load-balancer-controller.yaml` (wave 1)

### What it does

Deploys the AWS Load Balancer Controller — a program running in Kubernetes that watches for `Ingress` objects and creates AWS Application Load Balancers (ALBs) for them.

```yaml
argocd.argoproj.io/sync-wave: "1"  # ← right after namespaces

source:
  repoURL: https://aws.github.io/eks-charts   # ← AWS official Helm chart repo
  chart: aws-load-balancer-controller
  targetRevision: "1.7.2"
  helm:
    values: |
      clusterName: company-dev          # ← must match your EKS cluster name exactly
      serviceAccount:
        annotations:
          eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-aws-load-balancer-controller
          # ↑ IRSA: pod gets AWS permissions via this IAM role (no access keys)

destination:
  namespace: kube-system     # ← runs alongside other cluster-level controllers
```

### Why this must come before the apps (wave 1 vs wave 8)

When payment-service Helm chart creates an `Ingress` object:
- Kubernetes stores the Ingress
- ALB Controller WATCHES for new Ingress objects
- ALB Controller calls AWS API to create an ALB
- ALB gets a public DNS name → traffic can now reach the service

If ALB Controller wasn't running yet when payment-service deployed:
- Ingress created but nobody is watching it
- ALB never gets created
- `payment.dev.company.com` never resolves → health checks fail → 504 errors

### Dev vs Production difference

| Setting | Dev | Production |
|---------|-----|------------|
| `replicaCount` | 1 | 2 |
| CPU limit | 200m | 500m |
| Memory limit | 256Mi | 512Mi |

---

## Part 4 — `networking/external-dns.yaml` (wave 1)

### What it does

ExternalDNS watches Ingress objects and automatically creates/updates DNS records in AWS Route53.

```yaml
helm:
  values: |
    provider: aws              # ← Route53 as the DNS provider
    aws:
      region: ap-northeast-1
      zoneType: public         # ← public hosted zone (internet-facing DNS)
    domainFilters:
      - dev.company.com        # ← ONLY manage records under this domain (safety)
    policy: sync               # ← create AND delete records (not just create)
    txtOwnerId: "company-dev"  # ← ownership marker written to Route53
    sources: [ingress, service] # ← watch both Ingress and Service objects
    interval: 1m               # ← check for changes every 1 minute
```

### The `txtOwnerId` — why it prevents disasters

ExternalDNS writes a TXT record alongside every A record it creates:
```
payment.dev.company.com    A     1.2.3.4       ← the actual DNS record
_externaldns.payment.dev.company.com TXT "heritage=external-dns,owner=company-dev"
```

When `policy: sync` deletes stale records, it ONLY deletes records where the TXT owner matches `company-dev`. It will never delete `payment.staging.company.com` even though both clusters use the same Route53 hosted zone.

Without `txtOwnerId`: dev ExternalDNS could delete production DNS records. Production goes down.

### Dev vs Production difference

| Setting | Dev | Staging | Production |
|---------|-----|---------|------------|
| `domainFilters` | `dev.company.com` | `staging.company.com` | `company.com` |
| `txtOwnerId` | `company-dev` | `company-staging` | `company-production` |
| `interval` | 1m | 1m | 30s |

---

## Part 5 — `secrets/cluster-secret-store.yaml` (wave 2)

### What it does

Two resources in one file:
1. Installs External Secrets Operator (ESO) — the Helm chart
2. Creates a `ClusterSecretStore` — tells ESO WHERE to fetch secrets from (AWS Secrets Manager)

```yaml
# Resource 1: ESO Helm chart install
kind: Application
metadata:
  name: external-secrets-operator-dev
  annotations:
    argocd.argoproj.io/sync-wave: "2"
spec:
  source:
    repoURL: https://charts.external-secrets.io
    chart: external-secrets
    targetRevision: "0.9.0"
    helm:
      values: |
        serviceAccount:
          annotations:
            eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-eso
            # ↑ IRSA: ESO pod assumes this IAM role to call Secrets Manager API
```

```yaml
# Resource 2: ClusterSecretStore
apiVersion: external-secrets.io/v1beta1
kind: ClusterSecretStore
metadata:
  name: aws-secrets-manager
spec:
  provider:
    aws:
      service: SecretsManager   # ← not SSM Parameter Store, not Vault — specifically AWS SM
      region: ap-northeast-1
      auth:
        jwt:
          serviceAccountRef:
            name: external-secrets          # ← the ESO pod's ServiceAccount
            namespace: external-secrets     # ← in this namespace
```

### Why wave 2? Why not wave 1?

DynaKube (wave 3) needs a Kubernetes Secret named `dynakube` with the DT API tokens.
That Secret is created by an `ExternalSecret` resource (inside dynatrace-operator.yaml).
The `ExternalSecret` uses `ClusterSecretStore` to pull from Secrets Manager.
`ClusterSecretStore` only works after ESO is running.

Chain: ESO running (wave 2) → ClusterSecretStore exists → ExternalSecret can pull tokens → DynaKube can start.

If ESO was wave 3 (same as DynaKube):
- DynaKube's ExternalSecret might run before ESO is ready
- ExternalSecret fails: "ClusterSecretStore not found"
- DynaKube never gets its tokens → error: "secret dynakube not found"

### What secrets live in Secrets Manager

```
dev/dynatrace/api-token     ← DT API token for cluster monitoring
dev/dynatrace/paas-token    ← DT PaaS token for OneAgent download
dev/payment-service/db      ← DB connection string for payment-service
dev/order-service/db        ← DB connection string for order-service
dev/notification-service/db ← DB connection string for notification-service
```

The ESO pattern means: NO secrets ever stored in Git. Git only contains references.

---

## Part 6 — `monitoring/dynatrace/dynatrace-operator.yaml` (wave 3)

### What it does

Three resources in one file:
1. Installs Dynatrace Operator via Helm
2. Creates an `ExternalSecret` to pull DT API tokens from Secrets Manager
3. Creates the `DynaKube` custom resource — the master config for all DT monitoring

```yaml
# Resource 1: Dynatrace Operator Helm install
kind: Application
annotations:
  argocd.argoproj.io/sync-wave: "3"
source:
  repoURL: https://raw.githubusercontent.com/Dynatrace/helm-charts/master/repos/stable
  chart: dynatrace-operator
  targetRevision: "1.3.0"
  helm:
    values: |
      installCRD: true         # ← installs the DynaKube CRD (custom resource definition)
      resources:
        requests: { cpu: 50m, memory: 64Mi }
        limits:   { cpu: 200m, memory: 256Mi }   # ← dev: small (t3.medium nodes)
```

```yaml
# Resource 2: ExternalSecret
kind: ExternalSecret
spec:
  secretStoreRef:
    name: aws-secrets-manager    # ← references the ClusterSecretStore from wave 2
  target:
    name: dynakube              # ← creates K8s Secret NAMED "dynakube"
  data:
    - secretKey: apiToken
      remoteRef: { key: dev/dynatrace/api-token }    # ← path in Secrets Manager
    - secretKey: dataIngestToken
      remoteRef: { key: dev/dynatrace/paas-token }
```

```yaml
# Resource 3: DynaKube — the full monitoring config
apiVersion: dynatrace.com/v1beta1
kind: DynaKube
spec:
  apiUrl: https://PLACEHOLDER.live.dynatrace.com/api
  tokens: dynakube              # ← name of the K8s Secret created by ExternalSecret above

  classicFullStack:
    enabled: true               # ← OneAgent DaemonSet on EVERY EKS node
    tolerations:
      - key: node-role.kubernetes.io/control-plane
        operator: Exists
        effect: NoSchedule      # ← also run OneAgent on control-plane nodes

  logMonitoring:
    enabled: true               # ← OneAgent reads container logs → DT log analytics

  activeGate:
    capabilities:
      - routing                 # ← routes OneAgent → DT tenant (REQUIRED)
      - kubernetes-api-monitoring  # ← monitors K8s API server metrics
      - log-analytics           # ← processes logs before sending to DT
    replicas: 1                 # ← DEV: 1 (no HA needed in dev)

  kubernetesMonitoring:
    enabled: true               # ← monitors K8s cluster-level metrics (node CPU, pod counts)
```

### Dev vs Production — the critical difference

```
DEV DynaKube:
  activeGate:
    replicas: 1       ← if this pod dies, DT loses all metrics from dev cluster
                         Acceptable: no users, no SLA in dev

PRODUCTION DynaKube:
  activeGate:
    replicas: 2       ← always at least 1 replica alive during pod failures
    topologySpreadConstraints:
      - maxSkew: 1
        topologyKey: topology.kubernetes.io/zone
        whenUnsatisfiable: DoNotSchedule
        # ↑ Kubernetes REFUSES to schedule both replicas in the same AZ
        # If AZ goes down → 1 replica in the other AZ still routes metrics
```

```
DEV DynaKube resource limits:
  classicFullStack: limits { cpu: 300m, memory: 768Mi }   ← t3.medium node: 2 CPU / 4GB RAM

PRODUCTION DynaKube resource limits:
  classicFullStack: limits { cpu: 500m, memory: 1Gi }     ← m7g.xlarge node: 4 CPU / 16GB RAM
  activeGate:       limits { cpu: 1000m, memory: 1Gi }    ← handles higher metrics volume
```

### What `classicFullStack: enabled: true` actually deploys

```
After DynaKube creates, Dynatrace Operator creates:
  DaemonSet: dynatrace-oneagent
    → 1 OneAgent pod per node in your cluster (e.g. 3 nodes = 3 OneAgent pods)
    → Each pod has hostPID: true, privileged: true (required for JVMTI injection)
    → Mounts: /proc, /sys, /var/run/docker.sock

Each OneAgent pod:
  1. Scans ALL running containers on its node
  2. For each JVM process: injects JVMTI agent → starts capturing:
       - HTTP request count, duration, status codes PER ENDPOINT
       - Database query time, query count
       - JVM heap used / max, GC pause time
       - Thread pool active/queued/rejected
  3. Reads /var/log/containers/*.log → forwards to DT log analytics
  4. Reports node-level metrics: CPU, memory, disk, network
```

---

## Part 7 — `app/payment-service/payment-service.yaml` (wave 8)

### What it does

Tells ArgoCD to deploy the payment-service Helm chart from `charts/payment-service/` with environment-specific overrides.

```yaml
metadata:
  name: payment-service-dev
  annotations:
    argocd.argoproj.io/sync-wave: "8"    # ← LAST (all infra must be ready)
  finalizers:
    - resources-finalizer.argocd.argoproj.io   # ← cascade delete when this App is removed

spec:
  project: payments      # ← only teams in the "payments" ArgoCD project can edit this

  source:
    path: charts/payment-service     # ← Helm chart lives here in the same repo
    helm:
      valueFiles:
        - values.yaml          # ← base: production defaults (replicaCount: 3, Xmx: 1024m)
        - values-dev.yaml      # ← overrides: dev specific (replicaCount: 1, Xmx: 256m, jdwp)
      values: |
        image:
          repository: 123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
          #            ↑ dev account ECR (123456789010 = dev, 012 = prod)
          tag: "PLACEHOLDER"   # ← CI replaces this with actual image tag on every deploy
        serviceAccount:
          annotations:
            eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-payment-service
            # ↑ IRSA: payment-service pod can access dev AWS resources (RDS, SQS, etc.)
        ingress:
          host: payment.dev.company.com    # ← URL for dev (ExternalDNS creates Route53 record)
        envFromSecret: payment-service-db-credentials  # ← K8s Secret name for DB password

  destination:
    namespace: payment-ns    # ← deploys INTO this namespace (must exist — created in wave -1)

  syncPolicy:
    syncOptions:
      - Timeout=900            # ← wait up to 15 min for pods to become Ready
                               #   Spring Boot cold start can take 5-10 min on t3.medium

  ignoreDifferences:
    - group: apps
      kind: Deployment
      jsonPointers: [/spec/replicas]
      # ↑ HPA changes spec.replicas dynamically based on load
      # Without this: ArgoCD immediately reverts HPA's scaling decision
      # Result: service can't scale → latency spikes under load → prod incident
```

### Dev vs Production — key differences

```
DEV payment-service.yaml:
  valueFiles: [values.yaml, values-dev.yaml]   ← apply BOTH files (base + overrides)
  image.repository: 123456789010.dkr.ecr...    ← dev account ECR
  serviceAccount.role-arn: ...123456789010...  ← dev IAM role
  ingress.host: payment.dev.company.com        ← dev URL
  # No certArn — dev might use HTTP or self-signed cert

PRODUCTION payment-service.yaml:
  valueFiles: [values.yaml]                    ← ONLY base (production IS the base)
  image.repository: 123456789012.dkr.ecr...    ← prod account ECR (separate account)
  serviceAccount.role-arn: ...123456789012...  ← prod IAM role
  ingress.host: payment.company.com            ← production URL (no "dev." prefix)
  ingress.certArn: arn:aws:acm:...:certificate/prod-payment  ← HTTPS certificate (prod only)
```

### Why separate ECR per account?

```
Dev CI pushes: 123456789010.dkr.ecr.../payment-service:abc123
Prod CI pushes: 123456789012.dkr.ecr.../payment-service:xyz789

If both pointed to the same ECR:
  A dev engineer pushes a broken image → overwrites the prod image tag
  ArgoCD detects the change → deploys broken image to production
  
With separate ECR per account:
  Dev ECR is inaccessible from the prod EKS cluster (different IAM permissions)
  Prod images must be explicitly promoted via CI pipeline
  No accidental cross-environment contamination
```

### What `PLACEHOLDER` image tag means

```
payment-service.yaml (in Git):
  image.tag: "PLACEHOLDER"

What CI does on every code push:
  1. Build image: docker build -t payment-service:abc123 .
  2. Push to dev ECR: 123456789010.dkr.ecr.../payment-service:abc123
  3. Update the gitops file:
     sed -i 's/tag: "PLACEHOLDER"/tag: "abc123"/' gitops/dev/app/payment-service/payment-service.yaml
     git commit -m "deploy payment-service:abc123 to dev"
     git push
  4. ArgoCD detects the commit → syncs → rolling update with new image

ArgoCD never calls docker build. It only reads the tag from Git and applies it.
This is why the tag is "PLACEHOLDER" when you first look at the file — it gets replaced at deploy time.
```

---

## Part 8 — Staging vs Production Structural Differences

### Production has HTTPS; Dev/Staging do not

```
gitops/dev/app/payment-service/payment-service.yaml:
  ingress:
    host: payment.dev.company.com
    # no certArn → HTTP or self-signed

gitops/production/app/payment-service/payment-service.yaml:
  ingress:
    host: payment.company.com
    certArn: arn:aws:acm:ap-northeast-1:123456789012:certificate/prod-payment
    # → ALB terminates TLS with this ACM certificate → HTTPS
```

### Production has no values-dev.yaml or values-staging.yaml

```
DEV ArgoCD app:
  valueFiles: [values.yaml, values-dev.yaml]
  # values-dev.yaml overrides: replicaCount: 1, Xmx: 256m, jdwp debug port enabled

PRODUCTION ArgoCD app:
  valueFiles: [values.yaml]
  # values.yaml IS the production config: replicaCount: 3, Xmx: 1024m, no jdwp
```

This is intentional: `charts/payment-service/values.yaml` is designed to be production defaults. Dev and staging only override what they need to make things cheaper/easier to debug.

### Production has `prune: false` for apps (optional safer default)

Some teams set production applications to `prune: false` — so that removing a service file from Git does NOT immediately delete it from production. Instead it requires a manual `argocd app delete` command, adding a human checkpoint before production removals.

---

## Common Mistakes in This GitOps Folder

| Mistake | Symptom | Where to fix |
|---------|---------|-------------|
| Apply root-app to wrong cluster | Production services deployed in dev cluster | Check `kubectl config current-context` before applying |
| Forget `recurse: true` | Only top-level files synced; all app/ and monitoring/ files ignored | `root-app-dev.yaml` → `directory.recurse: true` |
| Missing namespace label `team=` | Dynatrace management zone empty, no alerts | `namespaces/namespaces.yaml` → add labels |
| Same ECR repo for dev and production | Dev push overwrites prod image | Separate accounts: `123456789010` vs `123456789012` |
| `activeGate.replicas: 1` in production | ActiveGate crash → DT blind to entire cluster | `dynatrace-operator.yaml` production → `replicas: 2` |
| `ignoreDifferences` missing for HPA | ArgoCD reverts HPA's scale-up during traffic spike | Add `jsonPointers: [/spec/replicas]` to app YAML |
| `Timeout=900` missing | ArgoCD marks Spring Boot service as "Degraded" before JVM finishes cold start | `syncOptions: [Timeout=900]` on all Java app Applications |
| `txtOwnerId` not unique per env | Dev ExternalDNS deletes production DNS records | Each env needs a unique ID: `company-dev`, `company-staging`, `company-production` |
