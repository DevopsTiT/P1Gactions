# Terraform Practical Expertise — SRE Deep Dive

> Grounded in the real project: `terraform/modules/` (vpc, eks, dynatrace) × 3 environments (dev/staging/production). Every concept is shown with the actual code, then explained from first principles.

---

## Mental Model: What Terraform Actually Is

```
Terraform is a RECONCILIATION ENGINE.

You write the DESIRED STATE in .tf files:
  "I want an EKS cluster named company-dev with 3 t3.medium nodes"

Terraform reads the CURRENT STATE from S3 (terraform.tfstate):
  "The cluster company-dev currently has 2 t3.medium nodes"

Terraform computes the DIFF:
  "I need to add 1 node to company-dev"

Terraform APPLIES the diff by calling AWS APIs:
  aws autoscaling update-auto-scaling-group --desired-capacity 3

The ONLY things you control: .tf files.
The ONLY things Terraform controls: whatever AWS/DT resources are in .tf files.
Everything else in AWS is invisible to Terraform.
```

---

## Part 1: Core Concepts — State, Plan, Apply

### 1.1 State File: Terraform's Memory

```hcl
# terraform/environments/dev/main.tf
backend "s3" {
  bucket         = "company-terraform-state-dev"
  key            = "dev/terraform.tfstate"
  region         = "ap-northeast-1"
  encrypt        = true
  dynamodb_table = "terraform-state-lock"
}
```

The state file is a JSON document that maps every resource in your `.tf` files to its real-world ID in AWS:

```json
{
  "resources": [
    {
      "type": "aws_eks_cluster",
      "name": "this",
      "instances": [
        {
          "attributes": {
            "name": "company-dev",
            "arn": "arn:aws:eks:ap-northeast-1:123456789010:cluster/company-dev",
            "endpoint": "https://ABCDEF.gr7.ap-northeast-1.eks.amazonaws.com",
            "version": "1.30"
          }
        }
      ]
    }
  ]
}
```

**Without state file:**
```
terraform apply → creates ANOTHER EKS cluster (doesn't know one already exists)
→ you now have two clusters, paying double
→ no way to clean up without manually deleting
```

**With state file:**
```
terraform apply → reads state: "company-dev already exists with ARN arn:..."
→ compares to .tf file: "desired version is 1.30, current is 1.30"
→ no changes needed → terraform does nothing
```

**The DynamoDB lock table:**
```
Without lock:
  Engineer A: terraform apply (reading state...)
  Engineer B: terraform apply (reading state... same version as A)
  A writes state with version 5 resource changes
  B writes state with different version 5 resource changes
  → State file is now corrupted: two conflicting versions written

With lock (DynamoDB):
  Engineer A: terraform apply → writes lock record → applies → deletes lock
  Engineer B: terraform apply → tries to write lock → "Already locked by A" → waits
  → Sequential, safe
```

### 1.2 Plan: The Diff Engine

```bash
terraform plan -out=plan.tfplan
```

Plan reads THREE sources, computes ONE output:

```
Source 1: .tf files (desired state — what YOU want)
Source 2: terraform.tfstate (last-known state — what Terraform last did)
Source 3: AWS APIs (real current state — what actually exists in AWS right now)

Process:
  For each resource in .tf:
    1. Does it exist in state? → no → CREATE (+)
    2. Does it exist in state AND real AWS? → both exist, compare fields
       → fields match → NO CHANGE
       → fields differ → UPDATE (~) or REPLACE (-)/(+)
    3. Exists in state but NOT in .tf? → DESTROY (-)
```

**Reading a plan output:**

```
Terraform will perform the following actions:

  # module.eks.module.eks.aws_eks_cluster.this will be updated in-place
  ~ resource "aws_eks_cluster" "this" {
        id              = "company-dev"
      ~ version         = "1.29" -> "1.30"    ← (~) = in-place update
    }

  # module.vpc.aws_subnet.private[0] will be replaced
  -/+ resource "aws_subnet" "private" {           ← (-/+) = destroy THEN recreate
      ~ cidr_block = "10.0.0.0/20" -> "10.0.48.0/20" (forces replacement)
    }

  # module.dynatrace.dynatrace_slo_v2.availability["payment-service"] will be created
  + resource "dynatrace_slo_v2" "availability" {  ← (+) = new resource
      + name = "payment-service Availability [dev]"
      + target_success = 90
    }

Plan: 1 to add, 1 to change, 0 to destroy.
```

**The danger of `forces replacement`:**
When a field is marked `forces replacement`, Terraform will DESTROY the existing resource and create a new one. For an EKS subnet this means: all pods in that subnet are evicted first. Always check the plan for `-/+` changes carefully before applying.

**`-detailed-exitcode` flag:**
```bash
terraform plan -detailed-exitcode
echo $?
# 0 = success, no changes
# 1 = error (plan failed)
# 2 = success, changes exist
```
Used in the CI pipeline for drift detection — distinguishes "plan ran fine, nothing changed" from "plan ran fine, found drift."

### 1.3 Apply: Making it Real

```bash
terraform apply plan.tfplan    # apply a saved plan (exact what was reviewed)
terraform apply                # plan + apply in one step (less safe — plan may differ)
terraform apply -auto-approve  # no confirmation prompt (only in CI)
```

**Why save the plan first (`-out=plan.tfplan`):**
```
Without saved plan:
  terraform plan → shows changes
  [teammate changes code between plan and apply]
  terraform apply → applies DIFFERENT changes than what was reviewed
  → plan review was useless

With saved plan:
  terraform plan -out=plan.tfplan → saves exact changes to file
  [code review of plan output]
  terraform apply plan.tfplan → applies EXACTLY what was reviewed
  → no surprises
```

**Parallelism (`-parallelism=N`):**
By default Terraform applies 10 resources in parallel. For large applies (VPC + EKS + Dynatrace = 100+ resources), increase this carefully:
```bash
terraform apply -parallelism=20   # faster but more AWS API calls per second
# Risk: AWS API rate limiting → throttling → plan fails partway through
# Safe default: keep at 10 for production, can go higher in dev
```

---

## Part 2: HCL Language Patterns

### 2.1 Resource, Data, Local, Variable — the four block types

```hcl
# RESOURCE: creates/manages a real-world object
resource "aws_s3_bucket" "state" {
  bucket = "company-terraform-state-dev"
}
# Reference: aws_s3_bucket.state.arn

# DATA: reads an existing object (does NOT create or manage it)
data "aws_secretsmanager_secret_version" "dt_token" {
  secret_id = "dev/dynatrace/api-token"
}
# Reference: data.aws_secretsmanager_secret_version.dt_token.secret_string
# Key difference: if the secret doesn't exist, terraform plan FAILS
# (data sources fail at plan time, resources fail at apply time)

# LOCAL: computed value used multiple times in the same file
locals {
  teams = toset([for svc in values(var.services) : svc.team])
  # computed once → referenced many times → stays consistent
}
# Reference: local.teams

# VARIABLE: input from the caller (environment/module)
variable "environment" {
  type        = string
  description = "dev | staging | production"
  validation {
    condition     = contains(["dev", "staging", "production"], var.environment)
    error_message = "environment must be dev, staging, or production"
  }
}
# Reference: var.environment
# Validation: Terraform checks this BEFORE creating any resources
```

### 2.2 The `for_each` pattern (the most important HCL pattern for SREs)

```hcl
# from terraform/modules/dynatrace/main.tf
resource "dynatrace_metric_events" "error_rate" {
  for_each = var.services
  # var.services is a map:
  # {
  #   "payment-service" = { team = "payments", error_rate_alert = 0.1, ... }
  #   "order-service"   = { team = "orders",   error_rate_alert = 0.5, ... }
  #   "notification-service" = { ... }
  # }
  #
  # for_each creates ONE resource per map KEY:
  #   dynatrace_metric_events.error_rate["payment-service"]
  #   dynatrace_metric_events.error_rate["order-service"]
  #   dynatrace_metric_events.error_rate["notification-service"]

  summary   = "[${upper(var.environment)}] ${each.key}: High error rate (>${each.value.error_rate_alert}%)"
  #                                                  ↑ map key         ↑ map value field

  threshold = each.value.error_rate_alert
}
```

**`for_each` vs `count`:**
```hcl
# count (index-based — FRAGILE):
resource "aws_subnet" "private" {
  count      = 3
  cidr_block = "10.0.${count.index}.0/24"
}
# Resources: aws_subnet.private[0], [1], [2]
# PROBLEM: if you remove index 1 (middle subnet), Terraform renumbers:
#   old [2] → new [1] → Terraform sees this as "subnet[1] changed" → DESTROYS and RECREATES
#   In production, this destroys a subnet containing running pods

# for_each (key-based — STABLE):
resource "aws_subnet" "private" {
  for_each   = { "az-a" = "10.0.0.0/20", "az-b" = "10.0.16.0/20", "az-c" = "10.0.32.0/20" }
  cidr_block = each.value
}
# Resources: aws_subnet.private["az-a"], ["az-b"], ["az-c"]
# SAFE: if you remove "az-b", only aws_subnet.private["az-b"] is destroyed
# "az-a" and "az-c" are untouched
```

**Always use `for_each` with maps/sets, never `count` for resources that can be removed from the middle.**

### 2.3 The `locals` + `for` expression pattern

```hcl
# from terraform/modules/dynatrace/main.tf
locals {
  teams = toset([for svc in values(var.services) : svc.team])
  # Step by step:
  # var.services = { "payment-service" = { team = "payments" }, "order-service" = { team = "orders" }, ... }
  # values(var.services) = [{ team="payments", ... }, { team="orders", ... }, { team="notifications", ... }]
  # [for svc in ... : svc.team] = ["payments", "orders", "notifications"]
  # toset(...) = {"notifications", "orders", "payments"}  ← deduplicated, stable set

  # services_with_traffic = only services where traffic_min_rps > 0
  services_with_traffic = {
    for name, svc in var.services : name => svc
    if svc.traffic_min_rps > 0
    # dev: all traffic_min_rps = 0 → empty map → zero traffic alerts in dev
    # production: all > 0 → full map → all services get traffic alerts
  }
}
```

**More `for` expression patterns:**
```hcl
# Transform a list into a map (key=value):
variable "az_list" { default = ["ap-northeast-1a", "ap-northeast-1b", "ap-northeast-1c"] }
locals {
  az_map = { for i, az in var.az_list : az => i }
  # { "ap-northeast-1a" = 0, "ap-northeast-1b" = 1, "ap-northeast-1c" = 2 }
}

# Filter a map:
locals {
  prod_only_keys = {
    for k, v in var.pagerduty_keys : k => v
    if var.environment == "production"
  }
  # In dev/staging: empty map → no PagerDuty resources created
  # In production: full map → PagerDuty notifications created
}

# Flatten nested structure:
locals {
  all_subnet_ids = flatten([
    for az, subnets in var.subnets_by_az : subnets.private_ids
  ])
}
```

### 2.4 Conditional `for_each` (on/off switch for resources)

```hcl
# from terraform/modules/dynatrace/main.tf

# CRITICAL alerts: production ONLY
resource "dynatrace_alerting" "critical" {
  for_each = var.environment == "production" ? local.teams : toset([])
  # When environment = "production": for_each = {"payments", "orders", "notifications"} → 3 resources
  # When environment = "dev":        for_each = {} (empty) → 0 resources created
  # When environment = "staging":    for_each = {} (empty) → 0 resources
}

# HIGH alerts: staging + production
resource "dynatrace_alerting" "high" {
  for_each = contains(["production", "staging"], var.environment) ? local.teams : toset([])
  # contains() returns true if var.environment is in the list
}

# This is the Terraform idiom for "create this resource IF condition":
# for_each = condition ? full_set : toset([])
# An empty set = zero iterations = zero resources
# NOT using `count = condition ? 1 : 0` because for_each with maps is safer
```

### 2.5 `sensitive` variables and outputs

```hcl
# terraform/modules/dynatrace/variables.tf
variable "dt_api_token" {
  type        = string
  sensitive   = true    # ← tells Terraform to redact this in logs and plan output
  description = "Dynatrace API token"
}

# Without sensitive = true:
# terraform plan output shows:
#   + dt_api_token = "dt0c01.ACTUALTOKEN_VISIBLE_IN_CI_LOGS"
#
# With sensitive = true:
# terraform plan output shows:
#   + dt_api_token = (sensitive value)
#
# Still stored in plaintext in terraform.tfstate!
# That's why S3 state bucket has: encrypt = true (server-side encryption)
```

**Critical: sensitive values ARE in the state file:**
```json
// terraform.tfstate (simplified)
{
  "resources": [{
    "type": "dynatrace_alerting",
    "instances": [{
      "attributes": {
        "dt_api_token": "dt0c01.ACTUAL_VALUE_HERE"  ← present in plaintext in state
      }
    }]
  }]
}
```
This is why state buckets must have:
- S3 SSE encryption (`encrypt = true` in backend config)
- S3 Block Public Access
- Restrictive IAM bucket policies
- No git commits of `.tfstate` files

---

## Part 3: Module Architecture

### 3.1 Module Structure in This Project

```
terraform/
├── modules/                    ← reusable building blocks
│   ├── vpc/
│   │   ├── main.tf             ← resource definitions
│   │   └── variables.tf        ← inputs (no outputs.tf needed if caller uses module.vpc.vpc_id)
│   ├── eks/
│   │   ├── main.tf
│   │   └── variables.tf
│   └── dynatrace/
│       ├── main.tf             ← the full observability stack
│       └── variables.tf
└── environments/               ← callers of modules, one per environment
    ├── dev/main.tf             ← calls modules with dev values
    ├── staging/main.tf         ← calls modules with staging values
    └── production/main.tf      ← calls modules with production values
```

**The philosophy:** modules contain LOGIC (how to create things). Environments contain DATA (what values to use). Changing a threshold only touches the environment file. Fixing a bug in EKS configuration only touches the module — all environments get the fix on next apply.

### 3.2 Module Calling — Every Parameter Explained

```hcl
# terraform/environments/production/main.tf
module "dynatrace" {
  source      = "../../modules/dynatrace"
  # Relative path from the calling file to the module directory.
  # ../.. = go up from production/ then up from environments/
  # → terraform/modules/dynatrace/
  # Alternative: "git::https://github.com/company/tf-modules.git//dynatrace?ref=v1.2.0"
  # (pinning to a git tag for versioned module releases)

  environment = "production"
  # Passes to var.environment in modules/dynatrace/variables.tf
  # Used to:
  #   - name resources: "payments-production"
  #   - conditionally create resources: critical alerts only in production
  #   - label resources: tag { environment = var.environment }

  dt_env_url   = data.aws_secretsmanager_secret_version.dt_tenant_url.secret_string
  dt_api_token = data.aws_secretsmanager_secret_version.dt_api_token.secret_string
  # Passes secrets read from Secrets Manager directly to the module.
  # The module never knows where these values came from — just that they exist.
  # This is the correct pattern: secrets come from Secrets Manager, not from
  # .tfvars files or environment variables.

  pagerduty_integration_keys = jsondecode(data.aws_secretsmanager_secret_version.pagerduty_keys.secret_string)
  # jsondecode: converts a JSON STRING to a Terraform map
  # Secret value: '{"payments":"pdkey-xxx","orders":"pdkey-yyy"}'
  # After jsondecode: { "payments" = "pdkey-xxx", "orders" = "pdkey-yyy" }
  # Used in module: for_each = var.pagerduty_integration_keys → one PD resource per team

  services = {
    "payment-service" = {
      team             = "payments"
      slo_target       = 99.9
      error_rate_alert = 0.1
      latency_p99_ms   = 300
      ...
    }
    # This map is the COMPLETE threshold configuration.
    # The module doesn't hardcode thresholds — it reads them from here.
    # This means: change production thresholds → edit this file → terraform apply
    # No code change in the module required.
  }
}
```

### 3.3 Module Outputs (consuming module results)

```hcl
# modules/eks/main.tf
output "cluster_name"            { value = module.eks.cluster_name }
output "cluster_endpoint"        { value = module.eks.cluster_endpoint }
output "cluster_ca_certificate"  { value = module.eks.cluster_certificate_authority_data }
output "cluster_oidc_issuer_url" { value = module.eks.cluster_oidc_issuer_url }

# Caller can use:
# module.eks.cluster_name
# module.eks.cluster_oidc_issuer_url  → used for IRSA role trust policies
```

**Why outputs matter for SREs:**
```hcl
# If eks module exposes cluster_oidc_issuer_url, the environment can create
# IRSA roles that reference it:
resource "aws_iam_role" "eso" {
  name = "company-dev-eso"
  assume_role_policy = jsonencode({
    Statement = [{
      Effect    = "Allow"
      Principal = { Federated = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:oidc-provider/${replace(module.eks.cluster_oidc_issuer_url, "https://", "")}" }
      Action    = "sts:AssumeRoleWithWebIdentity"
      Condition = {
        StringEquals = {
          "${replace(module.eks.cluster_oidc_issuer_url, "https://", "")}:sub" = "system:serviceaccount:external-secrets:external-secrets"
        }
      }
    }]
  })
}
# This IAM role trusts the ESO pod's Kubernetes ServiceAccount.
# The OIDC issuer URL comes from the EKS module output — not hardcoded.
```

---

## Part 4: The `terraform init` → `plan` → `apply` Lifecycle in Depth

### 4.1 `terraform init` — What It Does

```bash
terraform init
```

Three things happen:
```
1. BACKEND INITIALIZATION
   Reads the backend "s3" block.
   Connects to S3 to read/write terraform.tfstate.
   If this is the first run: creates the state file (empty).
   If state already exists: downloads it to local cache.

2. PROVIDER DOWNLOAD
   Reads "required_providers" blocks.
   Downloads provider plugins to .terraform/providers/:
     - hashicorp/aws v5.50.x (~50MB)
     - dynatrace-oss/dynatrace v1.55.x (~20MB)
   Locks versions in .terraform.lock.hcl (should be committed to git)

3. MODULE INSTALLATION
   Copies local module directories into .terraform/modules/
   (For remote modules: downloads from git/registry)
```

**The `.terraform.lock.hcl` file (MUST be committed to git):**
```hcl
# .terraform.lock.hcl
provider "registry.terraform.io/hashicorp/aws" {
  version     = "5.50.0"
  constraints = "~> 5.50"
  hashes = [
    "h1:abc123...",   # SHA256 hash of the downloaded binary
    "zh:def456...",
  ]
}
```

Without locking:
- Today: `~> 5.50` resolves to 5.50.0
- Next month: AWS releases 5.52.0 → `~> 5.50` might resolve to 5.52.0
- 5.52.0 has a bug → your plan fails in production
- You can't reproduce the issue (your lock resolves to 5.50.0)

With `.terraform.lock.hcl` committed: every `terraform init` on every machine, in CI, always downloads EXACTLY the same provider version.

### 4.2 `terraform validate` — Syntax and Reference Checking

```bash
terraform validate
```

Checks:
- HCL syntax (missing braces, wrong types)
- Variable references exist (no undefined `var.x`)
- Resource attribute names are valid
- Module source paths resolve to actual directories

Does NOT check:
- Whether AWS credentials work
- Whether referenced AWS resources exist
- Whether the values will actually work in AWS (e.g., a CIDR that overlaps with another subnet)

**Run validate in CI on every PR** (before plan) — it's fast (~1 second) and catches typos before an expensive plan runs.

### 4.3 `terraform plan` — The Lifecycle

```bash
terraform plan -out=plan.tfplan
```

```
Step 1: REFRESH (optional, -refresh=false to skip)
  For every resource in the state file, call the AWS API to get current state.
  Updates the in-memory state (but does NOT write to the state file yet).
  Purpose: detect drift (someone changed AWS config outside Terraform).

Step 2: DEPENDENCY GRAPH
  Build a directed acyclic graph (DAG) of all resources:
  VPC → Subnets → EKS → Node Groups → (all pods implicitly)
  Resources with no dependencies can be planned in parallel.
  Resources that reference each other are sequenced.

Step 3: DIFF
  For each resource:
    In .tf but not in state → CREATE
    In both .tf and state → compare all fields → UPDATE if different
    In state but not in .tf → DESTROY
  
  Special cases:
    Field changed but "forces replacement" → plan shows -/+ (destroy + create)
    Computed field → shows "(known after apply)" — can't know until resource exists
    Sensitive field → shows "(sensitive value)" in output

Step 4: OUTPUT
  Print the plan in human-readable format.
  Save to plan.tfplan (binary, can be passed to terraform apply).
```

### 4.4 `terraform apply` — The Lifecycle

```bash
terraform apply plan.tfplan
```

```
Step 1: LOCK
  Write a lock record to DynamoDB: { LockID: "state-bucket/state-key", Who: "alice", When: "2026-07-31T14:30:00Z" }
  If lock exists: wait (or fail with -lock-timeout=0)

Step 2: EXECUTE (following the dependency graph)
  For CREATE operations:
    Call provider API to create resource
    Wait for resource to reach "available" state (some APIs are async)
    Store the returned ID and all attributes in state
  
  For UPDATE operations:
    Call provider API with changed fields
    Some updates are in-place (e.g., change EKS cluster version)
    Some updates require destroy+recreate (Terraform handles automatically)
  
  For DESTROY operations:
    Call provider API to delete resource
    Remove from state

Step 3: STATE WRITE
  After each resource completes, write updated state to S3.
  This is done incrementally — if the apply fails partway, the state
  reflects what was actually created (not the full desired state).
  Next apply: only applies the remaining changes.

Step 4: UNLOCK
  Delete the lock record from DynamoDB.
```

**Partial failure handling:**
```
terraform apply starts:
  Creates VPC ✓ (written to state)
  Creates Subnets ✓ (written to state)
  Creates EKS cluster ✗ (fails due to IAM role not ready)

State after failure:
  VPC: present
  Subnets: present
  EKS: absent

Next terraform apply:
  VPC: no change (already in state)
  Subnets: no change
  EKS: will try to create again
```
This is safe — Terraform resumes from where it failed.

---

## Part 5: Targeting — The `-target` Flag

```bash
# Apply ONLY the dynatrace module (not VPC or EKS)
terraform apply -target=module.dynatrace

# Apply ONLY a specific resource
terraform apply -target="module.dynatrace.dynatrace_slo_v2.availability[\"payment-service\"]"

# Plan with target (see what ONLY that resource would change)
terraform plan -target=module.dynatrace -out=dt-only.plan
```

**When to use `-target`:**
```
LEGITIMATE USES:
  - After adding a new service to the services map: apply only the DT module
    (VPC and EKS are unchanged, no need to refresh their state)
  - Emergency: a specific resource is broken, fix it without touching others
  - Testing: apply one module at a time during initial setup

AVOID THESE ANTI-PATTERNS:
  - Using -target to "skip" a failing resource regularly
    → The skip becomes permanent → state diverges from reality
  - Using -target in production without documented reason
    → Partially applied state is hard to reason about
```

**Warning Terraform gives with `-target`:**
```
Warning: Resource targeting is in effect

  Terraform is currently working on a subset of your configuration.
  This mode is valid only when used for exceptional purposes, such as
  recovering from mistakes or working around Terraform limitations.
  Always use the full plan when planning and applying normal changes.
```

---

## Part 6: State Management Operations

### 6.1 `terraform state list` — What Terraform Knows About

```bash
terraform state list
# module.dynatrace.dynatrace_alerting.critical["notifications"]
# module.dynatrace.dynatrace_alerting.critical["orders"]
# module.dynatrace.dynatrace_alerting.critical["payments"]
# module.dynatrace.dynatrace_dashboard.network_overview
# module.dynatrace.dynatrace_http_monitor.health_check["notification-service"]
# ... (54+ resources in the dynatrace module alone)

terraform state list | wc -l
# 150+ resources for a full environment
```

### 6.2 `terraform state show` — Inspect One Resource

```bash
terraform state show 'module.dynatrace.dynatrace_slo_v2.availability["payment-service"]'
# resource "dynatrace_slo_v2" "availability" {
#     evaluation_window = "-1M"
#     id                = "12345678-abcd-..."
#     name              = "payment-service Availability [production]"
#     target_success    = 99.9
#     target_warning    = 99.8
#     ...
# }
```

**SRE use case:** A colleague changed the SLO target in the Dynatrace UI. You suspect it drifted. `state show` tells you what Terraform last set it to. `terraform plan` shows the diff.

### 6.3 `terraform state mv` — Rename a Resource Without Recreating

```bash
# Scenario: you renamed a resource in your .tf file
# Old name: module.dynatrace.dynatrace_alerting.critical["payments"]
# New name in .tf: module.dynatrace.dynatrace_alerting.crit["payments"]

# Without state mv:
# terraform plan would show:
#   - dynatrace_alerting.critical["payments"]  (DESTROY old)
#   + dynatrace_alerting.crit["payments"]      (CREATE new)
# This destroys and recreates the alert — causes a brief gap in alerting

# With state mv:
terraform state mv \
  'module.dynatrace.dynatrace_alerting.critical["payments"]' \
  'module.dynatrace.dynatrace_alerting.crit["payments"]'
# Renames in state only — no API call, no destroy/recreate
# Next terraform plan: sees "crit" in both state and .tf → no change
```

### 6.4 `terraform state rm` — Remove From Tracking (Without Deleting)

```bash
# Scenario: you want Terraform to stop managing a resource
# (transfer ownership to another team's Terraform workspace)
terraform state rm 'module.dynatrace.dynatrace_dashboard.network_overview'

# After state rm:
#   - Resource still exists in Dynatrace (not deleted from real world)
#   - Resource no longer in terraform.tfstate
#   - Next terraform plan: sees resource in .tf but not in state → tries to CREATE
#   - You must also remove the resource from .tf to prevent this
```

### 6.5 `terraform import` — Adopt an Existing Resource

```bash
# Scenario: someone created a DT management zone manually in the UI
# You want Terraform to manage it going forward

# Step 1: Add the resource block to .tf
# (must exist in .tf before import)
# resource "dynatrace_management_zone_v2" "team" {
#   name = "payments-production"
# }

# Step 2: Import the existing resource into state
terraform import \
  'module.dynatrace.dynatrace_management_zone_v2.team["payments"]' \
  "MANAGEMENT_ZONE_ID_FROM_DT_UI"

# After import:
#   - State now knows about this resource with its real attributes
#   - terraform plan may show diffs between the real config and your .tf code
#   - Update your .tf to match → no further changes
```

### 6.6 `terraform taint` / `terraform apply -replace` — Force Recreate

```bash
# Terraform 1.x recommended way:
terraform apply -replace="module.eks.aws_eks_node_group.system"

# Older way (deprecated):
terraform taint module.eks.aws_eks_node_group.system

# Both mark the resource for FORCED recreation on next apply.
# Even if no configuration changed, Terraform will destroy and recreate it.
# Use case: an EC2 node became unhealthy, you want a fresh one
```

---

## Part 7: Drift Detection

### 7.1 What Drift Is

```
Drift = real AWS state ≠ Terraform state file

How drift happens:
  - Someone clicks in AWS console and changes a setting
  - An AWS automated process changes a resource (e.g., AWS upgrades EKS addons)
  - A previous terraform apply failed partway through
  - A resource was deleted outside Terraform
  - A colleague ran a script that modified resources
```

### 7.2 Drift Detection in This Project (from `terraform-infra.yaml`)

```yaml
# .github/workflows/terraform-infra.yaml
drift-detect:
  if: github.event_name == 'schedule'
  schedule:
    - cron: '0 17 * * *'   # 02:00 JST daily
  steps:
    - name: Drift Detection
      run: |
        set +e
        terraform plan -refresh-only -detailed-exitcode -no-color 2>&1 | tee drift.txt
        EXIT_CODE=${PIPESTATUS[0]}
        echo "has_drift=$([ $EXIT_CODE -eq 2 ] && echo 'true' || echo 'false')" >> $GITHUB_OUTPUT
    - name: Create GitHub Issue on Drift
      if: steps.drift.outputs.has_drift == 'true'
      uses: actions/github-script@v7
      with:
        script: |
          github.rest.issues.create({
            title: `[DRIFT] Terraform infra drift detected in ${env}`,
            body: `Real AWS state differs...`,
            labels: ['terraform-drift', 'infrastructure', env]
          });
```

**`-refresh-only` flag:**
```
terraform plan               = "what changes would my .tf file make?"
terraform plan -refresh-only = "what changes did someone make OUTSIDE of Terraform?"

-refresh-only updates the plan to only show:
  ~ resource "aws_eks_cluster" "this" {
      ~ version = "1.30" -> "1.29"    ← AWS was manually downgraded
    }

It does NOT include changes from .tf files that differ from state.
Pure drift signal.
```

**`-detailed-exitcode` with `-refresh-only`:**
```
Exit 0: refresh completed, no drift found
Exit 1: terraform error (authentication, API failure, etc.)
Exit 2: refresh completed, DRIFT FOUND

Used in CI:
  EXIT_CODE=${PIPESTATUS[0]}
  if [ $EXIT_CODE -eq 2 ]; then
    create_github_issue()
  fi
```

### 7.3 Resolving Drift

Three options when drift is detected:

```
Option 1: Accept the manual change → update .tf to match
  Someone manually increased EKS node group to 5 nodes.
  Decision: this was intentional, keep it.
  Action: update var.node_desired_size = 5 in .tf, commit, apply.
  Result: plan shows no changes.

Option 2: Revert the manual change → apply Terraform
  Someone accidentally changed an SLO target to 50%.
  Decision: this was a mistake, revert.
  Action: terraform apply (no .tf changes needed)
  Result: Terraform sets SLO target back to what .tf says.

Option 3: Accept temporarily → document and fix properly
  An automated AWS process changed an EKS addon version.
  Decision: the new version is fine, but we want Terraform to manage it.
  Action: update .tf to specify the new version, apply.
  Result: no changes on apply, version is now tracked.
```

---

## Part 8: CI/CD Pipeline Integration

### 8.1 PR Flow: Plan on PR, Apply on Merge

```yaml
# terraform-infra.yaml (simplified)
on:
  pull_request:   → run: plan (read-only, shows what would change)
  push:           → run: apply (makes changes)
```

**On PR — parallel plan across all 3 environments:**
```yaml
strategy:
  fail-fast: false      # show ALL 3 plans even if one fails
  matrix:
    env:
      - { name: dev,        working_dir: terraform/environments/dev }
      - { name: staging,    working_dir: terraform/environments/staging }
      - { name: production, working_dir: terraform/environments/production }
steps:
  - run: terraform plan -no-color -detailed-exitcode 2>&1 | tee plan.txt
  - uses: actions/github-script@v7
    # Posts plan as a PR comment
    # Engineers review the plan BEFORE approving the merge
```

**On Push — sequential apply:**
```yaml
apply-dev:
  ...   # applies dev first
apply-staging:
  needs: apply-dev   # staging only if dev succeeded
  ...
apply-production:
  needs: apply-staging
  environment: production   # requires human approval gate
  ...
```

**Why sequential (not parallel)?**
If the VPC module has a bug and you apply dev in parallel with staging, BOTH environments get the bug simultaneously. Sequential: dev fails → staging never touched → find and fix the bug before it reaches staging.

### 8.2 OIDC Authentication (No Stored Credentials)

```yaml
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789010:role/github-actions-infra-apply
    aws-region: ap-northeast-1
```

Two IAM roles per environment:
```
github-actions-infra-plan   → read-only (can plan but not apply)
github-actions-infra-apply  → full access (can create/modify/delete)
```

PR jobs use `plan` role (read-only) → PRs can't accidentally modify infrastructure even if a workflow is misconfigured. Push jobs use `apply` role.

### 8.3 The Production Approval Gate

```yaml
apply-production:
  environment: production    # ← this is the gate
```

GitHub Environment `production` is configured with:
- Required reviewers: 2 senior engineers
- Reviewer list: platform team leads only
- Wait timer: 0 (can approve immediately, but button requires deliberate click)

**The approval workflow:**
```
1. apply-staging completes successfully
2. GitHub posts to required reviewers: "production apply awaiting approval"
3. Reviewer opens GitHub Actions → reviews the PLAN output (posted as PR comment)
4. Reviewer confirms: is this the right time? Is the plan what we expected?
5. Reviewer clicks "Approve deployment"
6. apply-production runs
```

This gate means: even if someone accidentally merges a PR that would delete the production VPC, the deletion will be blocked at the approval step.

---

## Part 9: Common Terraform Mistakes and How to Avoid Them

### Mistake 1: Committing .tfstate files to git

```bash
# .gitignore MUST contain:
*.tfstate
*.tfstate.*
.terraform/
*.tfplan

# If accidentally committed:
git filter-branch --force --index-filter \
  'git rm --cached --ignore-unmatch *.tfstate' \
  --prune-empty --tag-name-filter cat -- --all
# This rewrites history — sensitive values may be in git for collaborators who pulled
# Consider rotating all credentials that appeared in the state file
```

### Mistake 2: `terraform destroy` without `-target`

```bash
# This DESTROYS EVERYTHING in the environment:
terraform destroy

# Safe pattern: always use -target for partial destroys
terraform destroy -target='module.dynatrace.dynatrace_http_monitor.health_check["payment-service"]'

# For full environment teardown: require explicit confirmation phrase
terraform destroy   # Terraform prompts: "Enter 'yes' to confirm" — but this still destroys everything
# Better: use Terraform Cloud's destroy protection or manually type out each resource
```

### Mistake 3: Ignoring the plan output

```bash
# Bad pattern:
terraform apply -auto-approve   # skip review, apply blindly

# Good pattern:
terraform plan -out=reviewed.plan
# [READ THE OUTPUT — especially look for -/+ (destroy+create) lines]
# [Check which resources are being DESTROYED]
terraform apply reviewed.plan
```

### Mistake 4: Hardcoding secrets in .tf files

```hcl
# NEVER DO THIS:
resource "dynatrace_alerting" "critical" {
  dt_api_token = "dt0c01.HARDCODED_TOKEN"   # visible in git history forever
}

# Correct pattern: read from Secrets Manager
data "aws_secretsmanager_secret_version" "dt_token" {
  secret_id = "${var.environment}/dynatrace/api-token"
}
resource "dynatrace_alerting" "critical" {
  dt_api_token = data.aws_secretsmanager_secret_version.dt_token.secret_string
}
```

### Mistake 5: Not using version constraints

```hcl
# Dangerous (no version pin):
terraform {
  required_providers {
    aws = { source = "hashicorp/aws" }   # gets latest → breaking changes
  }
}

# Safe (pinned range):
terraform {
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.50" }
    # ~> 5.50 allows: 5.50.x, 5.51.x, 5.52.x
    # Blocks: 6.0.0 (major version — may have breaking changes)
    # Specific: "= 5.50.0" (exact — safest, but requires manual updates)
  }
}
```

### Mistake 6: Modifying state manually

```bash
# NEVER edit terraform.tfstate directly with a text editor
# The state file has checksums — manual edits corrupt it

# If you need to modify state: use Terraform commands
terraform state mv source target    # rename
terraform state rm address          # remove from tracking
terraform import address id         # add existing resource
```

### Mistake 7: `count` instead of `for_each` for ordered collections

```hcl
# Fragile with count:
variable "teams" { default = ["payments", "orders", "notifications"] }
resource "dynatrace_alerting" "team" {
  count = length(var.teams)
  name  = var.teams[count.index]
}
# If you remove "orders" (index 1):
#   Old state: [0]=payments, [1]=orders, [2]=notifications
#   New state: [0]=payments, [1]=notifications
#   Terraform sees [1] changed (orders → notifications) → MODIFIES orders alert
#   And [2] removed → DESTROYS notifications alert
#   Result: notifications destroyed, orders modified — not what you wanted

# Safe with for_each:
resource "dynatrace_alerting" "team" {
  for_each = toset(var.teams)
  name     = each.value
}
# Remove "orders":
#   Terraform destroys ONLY alerting.team["orders"]
#   ["payments"] and ["notifications"] are untouched
```

---

## Part 10: Practical Commands Reference

```bash
# ── INITIALIZATION ────────────────────────────────────────────────────────────
terraform init                        # download providers, configure backend
terraform init -upgrade               # update providers to latest allowed by constraints
terraform init -reconfigure           # force re-download (use after changing backend)
terraform init -backend=false         # initialize without backend (local state only)

# ── VALIDATION ───────────────────────────────────────────────────────────────
terraform validate                    # syntax + reference check (fast, no AWS calls)
terraform fmt -check                  # verify formatting (exit 1 if unformatted)
terraform fmt -recursive              # format all .tf files in place

# ── PLANNING ─────────────────────────────────────────────────────────────────
terraform plan                        # show plan, don't save
terraform plan -out=plan.tfplan       # save plan for reproducible apply
terraform plan -refresh-only          # show drift only (no config changes)
terraform plan -detailed-exitcode     # exit 0/1/2 for CI integration
terraform plan -target=module.X       # scope to one module
terraform plan -var="env=dev"         # pass variable from command line
terraform plan -var-file="dev.tfvars" # load variables from file

# ── APPLYING ─────────────────────────────────────────────────────────────────
terraform apply plan.tfplan           # apply saved plan
terraform apply -auto-approve         # skip confirmation (CI only)
terraform apply -target=module.X      # apply one module only
terraform apply -replace="addr"       # force recreate specific resource
terraform apply -parallelism=20       # increase concurrent operations

# ── STATE MANAGEMENT ─────────────────────────────────────────────────────────
terraform state list                  # all resources in state
terraform state show "addr"           # inspect one resource
terraform state mv "old" "new"        # rename without recreating
terraform state rm "addr"             # remove from tracking (keep real resource)
terraform import "addr" "real-id"     # adopt existing resource into Terraform
terraform force-unlock LOCK_ID        # release a stuck lock (careful!)

# ── INSPECTION ───────────────────────────────────────────────────────────────
terraform output                      # show all outputs
terraform output -raw cluster_name    # show one output as plain text
terraform graph | dot -Tpng > graph.png  # visualize dependency graph (needs graphviz)
terraform providers                   # show all providers used
terraform version                     # show Terraform and provider versions

# ── CLEANUP ──────────────────────────────────────────────────────────────────
terraform destroy -target=module.X    # destroy specific module
terraform destroy                     # destroy everything (dangerous!)
```

---

## Part 11: SRE Day-to-Day Terraform Workflows

### Adding a new service to the observability stack:

```bash
# 1. Edit terraform/environments/production/main.tf
#    Add "search-service" to the services map:
#    "search-service" = {
#      team = "search", slo_target = 99.5, error_rate_alert = 0.5, ...
#    }

# 2. Plan to see what will be created (24 new DT resources)
cd terraform/environments/production
terraform plan -target=module.dynatrace -out=search-svc.plan

# 3. Review plan output (should show 24+ creates, 0 destroys)
# Expected: management_zone, alerting × 4, metric_events × 8, slo × 2, synthetic × 1,
#           notifications (pagerduty+slack)

# 4. Apply after review
terraform apply search-svc.plan

# 5. Verify in Dynatrace UI: new management zone "search-production" visible
```

### Updating alert thresholds for production:

```bash
# 1. Edit terraform/environments/production/main.tf
#    Change payment-service error_rate_alert from 0.1 to 0.05

# 2. Plan (should show only the specific metric event updating)
terraform plan -target='module.dynatrace.dynatrace_metric_events.error_rate["payment-service"]'
# Expected output:
#   ~ resource "dynatrace_metric_events" "error_rate" {
#       ~ threshold = 0.1 -> 0.05
#     }

# 3. This requires production approval gate — open PR, get review, merge to main
# CI handles the apply after approval
```

### Emergency: manually fix a stuck state lock:

```bash
# Someone's Terraform apply crashed, left a lock in DynamoDB
aws dynamodb get-item \
  --table-name terraform-state-lock \
  --key '{"LockID":{"S":"company-terraform-state-prod/production/terraform.tfstate"}}' \
  --region ap-northeast-1
# Inspect: Who holds the lock? When did they start? Is the process still running?

# If the locking process is dead and won't release:
terraform force-unlock "LOCK_ID_FROM_DT_OUTPUT"
# WARNING: only force-unlock if you're CERTAIN no apply is running
# If you force-unlock while an apply is running: state corruption
```
