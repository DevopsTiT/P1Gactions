# Terraform Practical Expertise — Glossary for SRE Beginners

Every term used in main.md, one entry per term.

---

**Terraform**
An open-source Infrastructure-as-Code tool by HashiCorp. You describe the desired state of your infrastructure in `.tf` files; Terraform figures out the minimum set of API calls needed to make reality match that description. Manages cloud resources (AWS, GCP, Azure) and SaaS tools (Dynatrace, GitHub, PagerDuty) through provider plugins.

**Infrastructure-as-Code (IaC)**
The practice of managing infrastructure (servers, networks, databases) using code files instead of clicking in a web console. Benefits: version-controlled, reviewable, repeatable, auditable. The `.tf` files are the authoritative record of what should exist.

**Desired state**
What you declare you want in your `.tf` files. "I want an EKS cluster named company-dev running Kubernetes 1.30 with 3 nodes." Terraform's job is to make the real world match this declaration.

**Current state**
What actually exists right now in AWS (or Dynatrace, etc.), retrieved by Terraform calling the provider's APIs during a plan/apply. May differ from the desired state (drift) or from the state file.

**Reconciliation**
The process of comparing desired state to current state and computing the minimum changes to make them match. Terraform is a reconciliation engine — it only changes what needs changing, leaves everything else untouched.

**State file (`terraform.tfstate`)**
A JSON file that maps every resource in your `.tf` files to its real-world identifier (ARN, ID, etc.) and remembers its last-known configuration. Without it, Terraform doesn't know whether a resource already exists or needs to be created. Must be stored remotely (S3) for team use.

**S3 backend**
Storing the Terraform state file in an S3 bucket instead of locally. Makes the state accessible to all team members and CI/CD systems. Combined with DynamoDB locking, enables safe concurrent use. Configured in the `backend "s3" {}` block.

**DynamoDB lock table**
A DynamoDB table with a single item per Terraform workspace. When someone runs `terraform apply`, they write a lock record; others attempting to apply at the same time see the lock and wait. Prevents two simultaneous applies from corrupting the state file.

**`terraform init`**
The first command to run in any Terraform directory. Downloads provider plugins (AWS, Dynatrace), configures the S3 backend, and copies module sources. Must be re-run when providers, modules, or backend configuration change.

**`terraform plan`**
Reads `.tf` files, compares to the state file and current AWS state, outputs a human-readable diff of what would change. Changes nothing in the real world. The plan output should be reviewed before applying. Saved to a file with `-out=plan.tfplan` for reproducible applies.

**`terraform apply`**
Executes the changes described in a plan (or generates and executes a new plan). Calls AWS APIs to create, modify, or delete resources. Writes updated state to S3 after each resource completes. The production-changing command — should require review and approval.

**`terraform destroy`**
Deletes all resources managed by the current Terraform workspace. Dangerous — there is no undo. Should only be used intentionally and with `-target` to limit scope. In production, guarded by the approval gate.

**`terraform validate`**
Checks `.tf` files for syntax errors and invalid references (e.g., referencing a variable that doesn't exist). Fast, no AWS API calls. Run first in CI to catch typos before expensive plan operations.

**`terraform fmt`**
Formats `.tf` files according to canonical HCL style (consistent indentation, aligned `=` signs). `terraform fmt -check` exits non-zero if files are unformatted — used in CI to enforce style.

**HCL (HashiCorp Configuration Language)**
The language used to write Terraform configuration files. A declarative language — you describe what you want, not how to achieve it. Supports variables, functions, loops (`for_each`, `for`), and conditionals.

**Resource block**
The fundamental unit of Terraform configuration. Declares that a specific infrastructure object should exist. `resource "aws_s3_bucket" "state" { ... }` tells Terraform to create and manage an S3 bucket. Referenced elsewhere as `aws_s3_bucket.state.arn`.

**Data source block**
Reads information about an existing infrastructure object WITHOUT creating or managing it. `data "aws_secretsmanager_secret_version" "token" { ... }` reads a secret value. If the secret doesn't exist, `terraform plan` fails — data sources are validated at plan time.

**Variable block**
Declares an input that callers of the module (or the environment file) must provide. `variable "environment" { type = string }`. Accessed as `var.environment`. Can have validation rules, defaults, descriptions, and `sensitive = true`.

**Local block**
A computed value used multiple times within the same `.tf` file. `locals { teams = toset([...]) }`. Computed once, referenced many times as `local.teams`. Reduces repetition and ensures consistency — changing the logic in one `locals` block updates all usages.

**Output block**
Exposes a value from a module or root module to callers. `output "cluster_name" { value = module.eks.cluster_name }`. Callers use `module.eks.cluster_name`. Used to pass computed values (like an EKS cluster's OIDC issuer URL) between modules without hardcoding.

**Provider**
A plugin that understands how to communicate with a specific API (AWS, Dynatrace, GitHub). Downloads during `terraform init`. Translates resource blocks into API calls. `hashicorp/aws` knows how to call EC2, EKS, S3 APIs. `dynatrace-oss/dynatrace` knows how to call the Dynatrace API.

**`required_providers` block**
Declares which providers a Terraform configuration needs and their version constraints. `version = "~> 5.50"` means accept 5.50.x and 5.51.x but not 6.0.0. Essential for reproducibility — prevents unexpected provider upgrades that introduce breaking changes.

**`.terraform.lock.hcl`**
A lockfile that records the exact version and SHA256 hash of every downloaded provider. Should be committed to git. Ensures that every `terraform init` on every machine downloads the same provider binary. Without it, provider versions can change silently between runs.

**Module**
A reusable directory of `.tf` files called with different input variables to create similar infrastructure multiple times. `terraform/modules/dynatrace/` is called once for dev, once for staging, once for production — same logic, different thresholds. Modules reduce duplication and enforce consistency.

**`source` (module)**
The path or URL of a module's directory. `source = "../../modules/dynatrace"` is a relative local path. Can also be `source = "git::https://github.com/..."` for versioned remote modules, or `source = "hashicorp/eks/aws"` for Terraform Registry modules.

**`for_each`**
A meta-argument that creates one resource instance per item in a map or set. Creates stable, key-based resource addresses like `resource["key"]`. Safer than `count` because removing an item from the middle doesn't cause other items to be destroyed and recreated.

**`count`**
A meta-argument that creates N copies of a resource, addressed by index `resource[0]`, `resource[1]`. Fragile when items can be removed from the middle (removing item [1] renumbers [2] to [1], which Terraform sees as a change). Use `for_each` with maps/sets instead.

**`each.key` / `each.value`**
Built-in references inside a `for_each` resource block. `each.key` is the current map key (e.g., "payment-service"). `each.value` is the current map value (e.g., `{ team = "payments", error_rate_alert = 0.1, ... }`).

**`for` expression**
A HCL expression that transforms collections. `[for svc in var.services : svc.team]` iterates over a list and extracts a field. Can also filter with `if`: `{ for k, v in var.services : k => v if v.traffic_min_rps > 0 }`. Returns a list or map.

**`toset()`**
A built-in Terraform function that converts a list to a set. Sets have no duplicates and no ordering. Required for `for_each` when the input might have duplicates (e.g., two services with the same team name).

**`contains()`**
A built-in Terraform function. `contains(["production", "staging"], var.environment)` returns true if the list contains the value. Used for conditional resource creation: `for_each = contains([...], var.environment) ? local.teams : toset([])`.

**`jsondecode()`**
A built-in Terraform function that converts a JSON string to a Terraform value (map, list, etc.). Used to read JSON-formatted secrets: `jsondecode('{"payments":"pd-key-xxx"}')` returns `{ payments = "pd-key-xxx" }` which can be used with `for_each`.

**`sensitive = true`**
A variable or output attribute that tells Terraform to redact the value in plan output and logs. The value is still stored in plaintext in `terraform.tfstate` — the state file itself must be protected (encrypted S3 bucket, restrictive IAM).

**`-refresh-only`**
A Terraform plan flag that ONLY checks for drift (differences between real AWS state and the state file), ignoring any desired-state changes in `.tf` files. The output shows what changed outside of Terraform, not what your code wants to change. Used for daily drift detection.

**`-detailed-exitcode`**
A Terraform plan flag that changes exit codes: 0 = no changes, 1 = error, 2 = changes exist. Essential for CI scripts that need to distinguish "plan ran fine, nothing to do" (exit 0) from "plan ran fine, found drift or config changes" (exit 2).

**`-target`**
A Terraform apply/plan flag that limits the operation to a specific resource or module. `terraform apply -target=module.dynatrace` only applies the Dynatrace module, leaving VPC and EKS untouched. Use sparingly — routine use leads to partially applied states.

**Drift**
The difference between what Terraform's state file says should exist and what actually exists in AWS. Caused by: manual changes in the AWS console, automated AWS processes, failed applies. Detected by daily `terraform plan -refresh-only` runs.

**`terraform state list`**
Lists all resources tracked in the current state file. Shows every AWS and Dynatrace resource Terraform is managing. Used to verify a resource was created, find the exact address to use in other state commands, or audit what Terraform is managing.

**`terraform state show`**
Displays the full attributes of one specific resource from the state file. Used to inspect current values, compare with what's in the AWS console, or find resource IDs for use in other tools.

**`terraform state mv`**
Renames a resource address in the state file without making any real-world changes. Used when refactoring `.tf` code — renaming a resource block would otherwise cause Terraform to destroy and recreate it. `state mv` tells Terraform "old name and new name are the same real resource."

**`terraform state rm`**
Removes a resource from Terraform's state file without deleting the real resource. Useful when transferring management of a resource to another Terraform workspace, or when you want Terraform to "forget" about a resource.

**`terraform import`**
Brings an existing real-world resource under Terraform management by adding it to the state file. The resource block must already exist in `.tf`. Use case: someone created a resource manually in AWS console, you want Terraform to manage it going forward.

**`terraform force-unlock`**
Manually releases a DynamoDB lock that was not properly cleaned up (e.g., a Terraform apply process crashed). Dangerous — only use if you are certain no apply is currently running. Incorrect use can lead to state corruption if two applies run simultaneously.

**`-replace` flag**
`terraform apply -replace="resource_address"` forces Terraform to destroy and recreate a specific resource even if its configuration hasn't changed. Replaces the deprecated `terraform taint` command. Use case: an EC2 node is unhealthy and needs to be replaced with a fresh one.

**Version constraint (`~>`, `>=`, `=`)**
Rules for which provider versions are acceptable. `~> 5.50` (tilde-arrow) = allow patch and minor versions (5.50.x, 5.51.x) but not major (6.x). `>= 5.50` = any version 5.50 or newer. `= 5.50.0` = exact version only. The tilde-arrow is most common — allows bugfixes without accepting breaking changes.

**Dependency graph (DAG)**
Terraform builds a directed acyclic graph of all resources, where edges represent dependencies (resource A must exist before resource B). Used to: sequence operations (create VPC before subnets), parallelize independent operations (create 3 subnets simultaneously), and determine destroy order (delete EKS before VPC).

**`forces replacement`**
A plan annotation indicating that changing a particular field requires destroying the existing resource and creating a new one. Some resource attributes are immutable after creation in AWS (e.g., subnet CIDR blocks). Changing them triggers `-/+` in the plan output — a destroy followed by a create. Critical to review — can cause downtime.

**`(known after apply)`**
A plan annotation for computed fields that only exist after the resource is created. An EKS cluster's endpoint URL is unknown until AWS creates the cluster. The plan shows `endpoint = (known after apply)` — Terraform will populate it in the state file after apply completes.

**OIDC (OpenID Connect) for GitHub Actions**
An authentication mechanism that lets GitHub Actions prove its identity to AWS without storing AWS credentials as GitHub Secrets. GitHub gets a short-lived JWT token and exchanges it with AWS STS for temporary credentials. The credentials expire when the job ends — no long-lived secrets anywhere.

**IAM role trust policy**
An IAM policy attached to a role that defines WHO can assume the role. For OIDC: "allow GitHub Actions jobs from repo X to assume this role." For Kubernetes IRSA: "allow pods with ServiceAccount Y to assume this role." The trust policy is what makes `configure-aws-credentials@v4` work without stored credentials.

**`.terraform/` directory**
Created by `terraform init`. Contains downloaded provider plugins, module copies, and backend configuration. MUST be in `.gitignore` — contains large binaries (~70MB) and is machine-specific. Regenerated by `terraform init` on each new machine or CI runner.

**`-auto-approve`**
A Terraform apply flag that skips the interactive confirmation prompt ("Enter 'yes' to confirm"). Used in CI/CD where there's no human to type "yes". Should NEVER be used interactively in production — removes the last safety check before making changes.

**Partial failure (Terraform)**
When a Terraform apply completes some resources successfully but fails on others. The state file reflects what was actually created. Next `terraform apply` resumes from where it failed — already-created resources are not recreated. This is safe by design.

**Workspace (Terraform)**
A named instance of state within a single configuration directory. `terraform workspace new staging` creates a separate state file for staging. Alternative to the directory-per-environment pattern used in this project. This project uses directories (dev/, staging/, production/) rather than workspaces — both are valid, directories are more explicit.

**`default_tags` (AWS provider)**
A provider-level setting that adds tags to EVERY AWS resource created by Terraform in that configuration. `default_tags { tags = { environment = "production", managed-by = "terraform" } }` means every EC2 instance, security group, and EKS cluster automatically gets these tags. Eliminates the need to add tags to every individual resource block.

**`validate` (variable)**
An HCL block inside a `variable` block that enforces rules on variable values. `condition = contains(["dev","staging","production"], var.environment)` makes Terraform error at plan time if an invalid value is passed. Catches misconfiguration before any AWS API calls are made.
