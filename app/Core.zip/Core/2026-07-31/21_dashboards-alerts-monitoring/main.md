# SRE Deep Dive: Design, Create & Maintain Dashboards, Alerts, and Monitoring Configurations

---

## E2E Flow Summary

```
Production System
      │
      ▼
[Metrics / Logs / Traces emitted]
      │
      ▼
[Collection Layer] ← Prometheus scrapers, OTel collectors, Fluent Bit
      │
      ▼
[Storage Layer] ← Prometheus TSDB, Loki, Tempo, Elasticsearch
      │
      ▼
[Visualization Layer] ← Grafana Dashboards
      │
      ▼
[Alerting Layer] ← Alertmanager / Dynatrace / PagerDuty
      │
      ▼
[Notification Layer] ← Slack, Email, PagerDuty incidents
      │
      ▼
[On-call SRE responds → RCA → Fix]
```

---

## Decision Tree: What to Build First?

```
START
  │
  ├─ Do I know what normal looks like? ──NO──→ Phase 1: Baseline dashboards first
  │
  ├─ Do I have SLOs defined? ──NO──→ Define SLOs before writing alert thresholds
  │
  ├─ Is this a new service? ──YES──→ Build RED dashboard + basic alerts from day 1
  │
  ├─ Is this an existing service breaking? ──YES──→ Symptom-based alert → Cause-based drill-down dashboard
  │
  └─ Is this a review of existing monitoring? ──YES──→ Audit alert noise ratio, fix before adding more
```

---

## Tool Map

| Tool | Role | Used For |
|---|---|---|
| Prometheus | Metrics collection + alerting rules | Scrape targets, evaluate alert conditions |
| Grafana | Visualization | Build dashboards from Prometheus/Loki/Tempo data |
| Alertmanager | Alert routing + deduplication | Send alerts to Slack/PagerDuty |
| Loki | Log aggregation | Log-based dashboards and alerts |
| OTel Collector | Telemetry pipeline | Receive spans, metrics, logs; forward to backends |
| Dynatrace | APM + AI alerting | Auto-baseline anomaly detection, Davis AI |
| PagerDuty | On-call orchestration | Escalation policies, incident management |
| Terraform/Helm | Config as code | Version-controlled dashboard and alert definitions |

---

## Part 1 — The Four Golden Signals (Foundation of Everything)

Before writing a single dashboard panel, internalize Google SRE's four golden signals.
Every alert and dashboard you build maps back to at least one of these.

### 1. Latency
- How long does it take to serve a request?
- Track **percentiles**, not averages: p50, p90, p95, p99
- Why percentiles? Average hides the tail. If p99 = 10s, 1% of users wait 10 seconds — that matters.
- Metric example: `http_request_duration_seconds`

### 2. Traffic
- How much demand is hitting the system?
- Requests per second (RPS), messages per second, concurrent connections
- Metric example: `http_requests_total` (counter → use `rate()`)

### 3. Errors
- What fraction of requests fail?
- Count HTTP 5xx, application-level errors, timeout errors
- Metric example: `http_requests_total{status=~"5.."}`
- Error rate = errors / total requests

### 4. Saturation
- How full is the system?
- CPU%, memory%, disk%, queue depth, thread pool exhaustion
- Leading indicator — saturation rises BEFORE errors spike
- Metric example: `node_cpu_seconds_total`, `container_memory_working_set_bytes`

---

## Part 2 — Dashboard Design Principles

### 2.1 The Three Dashboard Layers (Drill-Down Hierarchy)

```
Layer 1 — Overview / Executive Dashboard
  ├─ One page, service-wide health at a glance
  ├─ SLO burn rate, error rate, p99 latency, request rate
  └─ Purpose: "Is everything OK right now?"

Layer 2 — Service / Team Dashboard
  ├─ Per-endpoint breakdown, per-pod breakdown
  ├─ Dependency health (DB latency, downstream API errors)
  └─ Purpose: "Which component is failing?"

Layer 3 — Debug / Investigation Dashboard
  ├─ JVM heap, GC pause time, thread pool stats, DB connection pool
  ├─ Correlated with logs and traces
  └─ Purpose: "Why is this component failing?"
```

Never put Layer 3 detail on Layer 1 — it creates noise and obscures signal.

### 2.2 Panel Types — When to Use Each

| Panel Type | Best For | Wrong Use |
|---|---|---|
| Time Series | Latency over time, RPS over time | Single current value |
| Stat / Big Number | Current error rate, SLO status | Trend visualization |
| Gauge | Saturation (CPU%, disk%) | Count of errors |
| Heatmap | Latency distribution (all percentiles at once) | Simple up/down |
| Table | List of slowest endpoints, top errors | Time-based trends |
| Logs Panel | Live log tail correlated with metrics | Replacing metrics |
| Alert List | Current firing alerts | Historical trend |

### 2.3 Dashboard Layout Rules

```
TOP ROW       → SLO status, overall error rate, overall availability (big stat panels)
SECOND ROW    → Latency (p50/p95/p99 time series) + Traffic (RPS time series)
THIRD ROW     → Error breakdown by type / endpoint
FOURTH ROW    → Saturation (CPU, memory, disk)
BOTTOM ROWS   → Debug detail (only when needed)
```

### 2.4 Variable Templates (Make Dashboards Reusable)

In Grafana, use Dashboard Variables to avoid hardcoding:
- `$namespace` → filter by Kubernetes namespace
- `$pod` → drill into specific pod
- `$env` → switch between dev/staging/prod
- `$interval` → dynamic time bucket for rate() calculations

```
Panel PromQL example using variables:
  rate(http_requests_total{namespace="$namespace", pod="$pod"}[$interval])
```

---

## Part 3 — Alert Design

### 3.1 Symptom-Based vs Cause-Based Alerts

| Type | Alert on | Example | When to use |
|---|---|---|---|
| Symptom-based | User-visible impact | Error rate > 1%, SLO burn too fast | PRIMARY — pages on-call |
| Cause-based | Infrastructure signals | CPU > 90%, disk > 85% | SECONDARY — informational / early warning |

Rule: **Page on symptoms, investigate causes.**
Never wake someone at 3am because a pod restarted once — wake them because users are failing.

### 3.2 SLO-Based Alerting (The Right Way)

SLO: 99.9% availability → Error budget = 0.1% = 43.8 min/month

**Multi-window, multi-burn-rate alerting** (Google recommendation):

```
Window 1: Fast burn (critical, page immediately)
  - 1h window + 5m window
  - Burn rate > 14.4x
  - Why 14.4x? At this rate, 1h consumes 14.4/720 = 2% of monthly budget
  - Severity: CRITICAL → page on-call now

Window 2: Slow burn (warning, investigate soon)
  - 6h window + 30m window
  - Burn rate > 6x
  - Severity: WARNING → Slack notification

Window 3: Slow budget drain (ticket, not a page)
  - 3d window + 6h window
  - Burn rate > 1x (consuming budget but not critically)
  - Severity: INFO → Jira ticket
```

Why multi-window? Single threshold produces too many false positives (short spikes) or misses slow drains (long problems at low rate).

### 3.3 Alert Anatomy — Prometheus AlertRule

```yaml
# prometheus/rules/sre-alerts.yaml

groups:
  - name: sre.availability
    interval: 30s
    rules:

      # SYMPTOM: High error rate (fast burn)
      - alert: HighErrorRateFastBurn
        expr: |
          (
            rate(http_requests_total{status=~"5.."}[1h])
            /
            rate(http_requests_total[1h])
          ) > 0.01
          and
          (
            rate(http_requests_total{status=~"5.."}[5m])
            /
            rate(http_requests_total[5m])
          ) > 0.01
        for: 2m                            # must be true for 2 mins before firing
        labels:
          severity: critical
          team: sre
        annotations:
          summary: "High error rate on {{ $labels.service }}"
          description: "Error rate {{ $value | humanizePercentage }} over 1h and 5m windows"
          runbook_url: "https://wiki/runbooks/high-error-rate"

      # SYMPTOM: High latency
      - alert: HighP99Latency
        expr: |
          histogram_quantile(0.99,
            sum(rate(http_request_duration_seconds_bucket[5m])) by (le, service)
          ) > 2.0
        for: 5m
        labels:
          severity: warning
          team: sre
        annotations:
          summary: "p99 latency > 2s on {{ $labels.service }}"

      # CAUSE: Disk filling up (early warning, not a page)
      - alert: DiskSpaceWarning
        expr: |
          (node_filesystem_avail_bytes / node_filesystem_size_bytes) < 0.15
        for: 10m
        labels:
          severity: warning
          team: platform
        annotations:
          summary: "Disk < 15% free on {{ $labels.instance }}"
```

### 3.4 Alertmanager Configuration (Routing + Deduplication)

```yaml
# alertmanager/alertmanager.yaml

global:
  resolve_timeout: 5m
  slack_api_url: 'https://hooks.slack.com/services/YOUR/WEBHOOK'

# Deduplication: group similar alerts so you get ONE notification, not 50
route:
  group_by: ['alertname', 'service', 'namespace']
  group_wait: 30s          # wait 30s before sending, to batch rapid fires
  group_interval: 5m       # send new additions to group every 5m
  repeat_interval: 4h      # re-notify if still firing after 4h

  # Default receiver
  receiver: 'slack-warnings'

  # Route critical alerts to PagerDuty
  routes:
    - match:
        severity: critical
      receiver: 'pagerduty-critical'
      continue: false       # stop routing here; don't also send to default

    - match:
        severity: warning
      receiver: 'slack-warnings'

    - match:
        severity: info
      receiver: 'slack-info'

receivers:
  - name: 'pagerduty-critical'
    pagerduty_configs:
      - service_key: '<PAGERDUTY_INTEGRATION_KEY>'
        description: '{{ range .Alerts }}{{ .Annotations.summary }}{{ end }}'

  - name: 'slack-warnings'
    slack_configs:
      - channel: '#alerts-warning'
        title: '[{{ .Status | toUpper }}] {{ .GroupLabels.alertname }}'
        text: '{{ range .Alerts }}{{ .Annotations.description }}{{ end }}'

  - name: 'slack-info'
    slack_configs:
      - channel: '#alerts-info'

# Inhibition: silence cause-based if symptom-based is already firing
inhibit_rules:
  - source_match:
      severity: 'critical'
    target_match:
      severity: 'warning'
    equal: ['service', 'namespace']
    # ↑ If critical fires for the same service, suppress warning — reduce noise
```

---

## Part 4 — Monitoring Configuration as Code

### 4.1 Why Config as Code?

- Reproducible: same config in dev, staging, prod
- Reviewable: changes go through PR review
- Auditable: git history shows who changed what threshold, and when
- Rollback: `git revert` if an alert config causes alert storm

### 4.2 Grafana Dashboard as JSON (Version Controlled)

Grafana stores dashboards as JSON. Export and commit them to git.

```bash
# Export dashboard via Grafana API
curl -H "Authorization: Bearer $GRAFANA_API_KEY" \
  https://grafana.internal/api/dashboards/uid/my-service \
  | jq '.dashboard' > dashboards/my-service.json

# Import dashboard via API (CI/CD)
curl -X POST \
  -H "Authorization: Bearer $GRAFANA_API_KEY" \
  -H "Content-Type: application/json" \
  -d "{\"dashboard\": $(cat dashboards/my-service.json), \"overwrite\": true}" \
  https://grafana.internal/api/dashboards/import
```

### 4.3 Grafana as Code with Grafonnet (Jsonnet)

For large orgs, write dashboards programmatically:

```jsonnet
// dashboards/my-service.jsonnet
local grafana = import 'grafonnet/grafana.libsonnet';
local dashboard = grafana.dashboard;
local graphPanel = grafana.graphPanel;
local prometheus = grafana.prometheus;

dashboard.new(
  'My Service - SRE Dashboard',
  time_from='now-1h',
  tags=['sre', 'my-service'],
)
.addPanel(
  graphPanel.new(
    'Request Rate',
    datasource='Prometheus',
  )
  .addTarget(
    prometheus.target(
      'rate(http_requests_total{service="my-service"}[5m])',
      legendFormat='RPS',
    )
  ),
  gridPos={ x: 0, y: 0, w: 12, h: 8 }
)
```

### 4.4 Terraform for Grafana Resources

```hcl
# terraform/monitoring/main.tf

resource "grafana_dashboard" "my_service" {
  config_json = file("${path.module}/dashboards/my-service.json")
  folder      = grafana_folder.sre.id
  overwrite   = true
}

resource "grafana_alert_rule" "high_error_rate" {
  name            = "HighErrorRate-MyService"
  folder_uid      = grafana_folder.sre.uid
  for             = "2m"
  condition       = "C"
  no_data_state   = "NoData"
  exec_err_state  = "Alerting"

  data {
    ref_id = "A"
    datasource_uid = "prometheus"
    relative_time_range {
      from = 600
      to   = 0
    }
    model = jsonencode({
      expr = "rate(http_requests_total{status=~\"5..\"}[5m]) / rate(http_requests_total[5m])"
    })
  }
}
```

---

## Part 5 — Maintaining Dashboards and Alerts Over Time

### 5.1 The Alert Quality Audit

Run this review monthly or after any major incident:

```
For each alert in the last 30 days, ask:

1. Did it fire? ──NO──→ Is it still needed? Consider removing or relaxing threshold
2. Was it actionable? ──NO──→ Rewrite or demote to INFO
3. Did it wake someone at night? ──YES──→ Was it real? If not, tune threshold
4. Was it a duplicate of another alert? ──YES──→ Use inhibition rules
5. Did the runbook help resolve it? ──NO──→ Update the runbook
```

**Healthy alert ratio target: < 5% noise (false positive) rate**

### 5.2 SLO Burn Rate Review (Monthly)

```bash
# Check how much error budget was consumed last 30 days
# In Prometheus:
sum_over_time(
  (rate(http_requests_total{status=~"5.."}[5m]) 
   / rate(http_requests_total[5m]))[30d:5m]
) / (30 * 24 * 12)
# Result: average error rate over 30d
# Compare to SLO target (e.g. 0.001 for 99.9%)
```

### 5.3 Dashboard Hygiene Rules

| Rule | Why |
|---|---|
| Every dashboard has an owner team label | Know who to ask when it's wrong |
| No dashboard older than 6 months without review | Data sources change, metrics get renamed |
| Every dashboard links to runbooks | Next person has context |
| Dashboards in git, not just Grafana UI | Avoid "snowflake" dashboards only one person knows |
| Prod dashboards tested in staging first | Avoid broken panels in an incident |

### 5.4 Runbook Template (Every Alert Needs One)

```markdown
# Runbook: HighErrorRateFastBurn

## What is this alert?
HTTP error rate exceeded 1% for both 1h and 5m windows. Users are experiencing failures.

## Severity: CRITICAL

## Immediate Steps (first 5 minutes)
1. Check Grafana dashboard: [link]
2. Identify which endpoint is erroring: `kubectl logs -l app=my-service | grep ERROR | tail -50`
3. Check for recent deployments: `kubectl rollout history deploy/my-service`
4. Check downstream dependencies: [link to dependency dashboard]

## If caused by bad deploy
- Rollback: `kubectl rollout undo deploy/my-service`

## If caused by database
- Check DB connection pool: [link to DB dashboard]
- Alert DBA on-call via PagerDuty escalation policy

## Escalation
- After 15 min unresolved: escalate to service owner
- After 30 min: escalate to VP Engineering
```

---

## Common Mistakes

| Mistake | Symptom | Fix |
|---|---|---|
| Alerting on averages | Misses tail latency; p99 hidden | Always use histogram_quantile + percentiles |
| No `for` duration on alerts | Alert storms from 1-second spikes | Add `for: 2m` to filter transient noise |
| Too many critical alerts | On-call ignores pages (alert fatigue) | 80% of pages should be symptom-based |
| Dashboards not in version control | "Snowflake" dashboards lost after Grafana upgrade | Export JSON to git, use Terraform/Jsonnet |
| No inhibition rules | Both cause and symptom alerts fire simultaneously, 10 Slack messages | Add inhibit_rules in Alertmanager |
| Static thresholds on seasonal traffic | Black Friday → everything pages | Use burn rate + SLO, not fixed RPS thresholds |
| No runbooks | On-call spends 20min figuring out what alert means | Every alert.annotations must have runbook_url |
| Alert without owner | No one knows who to ping | Always set `team` label on every alert |
