# Commands: Dashboards, Alerts & Monitoring

---

## Phase 0 — Verify What You Have

```bash
# List all Prometheus alert rules currently loaded
curl -s http://localhost:9090/api/v1/rules | jq '.data.groups[].rules[].name'

# Check which alerts are currently FIRING
curl -s http://localhost:9090/api/v1/alerts | jq '.data.alerts[] | select(.state=="firing")'

# Check Alertmanager active alerts
curl -s http://localhost:9093/api/v2/alerts | jq '.[] | {name: .labels.alertname, state: .status.state}'

# List Grafana dashboards via API
curl -H "Authorization: Bearer $GRAFANA_API_KEY" \
  https://grafana.internal/api/search?type=dash-db | jq '.[].title'

# Check Prometheus targets (what is being scraped)
curl -s http://localhost:9090/api/v1/targets | jq '.data.activeTargets[] | {job: .labels.job, health: .health}'
```

---

## Phase 1 — Write and Validate Alert Rules

```bash
# Lint Prometheus rules file before applying (catches syntax errors)
promtool check rules prometheus/rules/sre-alerts.yaml

# Test alert rules (unit test — no live Prometheus needed)
promtool test rules prometheus/rules/sre-alerts-test.yaml

# Hot-reload Prometheus rules (no restart needed)
curl -X POST http://localhost:9090/-/reload

# Verify rule loaded correctly
curl -s http://localhost:9090/api/v1/rules | jq '.data.groups[] | select(.name=="sre.availability")'

# Manually evaluate a PromQL expression (test your alert expr)
curl -s "http://localhost:9090/api/v1/query" \
  --data-urlencode 'query=rate(http_requests_total{status=~"5.."}[5m]) / rate(http_requests_total[5m])' \
  | jq '.data.result'
```

---

## Phase 2 — Test Alertmanager Routing

```bash
# Validate Alertmanager config syntax
amtool check-config alertmanager/alertmanager.yaml

# Send a test alert to Alertmanager (simulate a firing alert)
amtool alert add \
  alertname="TestAlert" \
  severity="critical" \
  service="my-service" \
  --annotation summary="This is a test alert" \
  --alertmanager.url http://localhost:9093

# List active alerts in Alertmanager
amtool alert query --alertmanager.url http://localhost:9093

# Silence an alert for 2 hours (during maintenance)
amtool silence add \
  alertname="DiskSpaceWarning" \
  --duration=2h \
  --comment="Scheduled disk expansion" \
  --alertmanager.url http://localhost:9093

# List all silences
amtool silence query --alertmanager.url http://localhost:9093

# Delete a silence by ID
amtool silence expire <SILENCE_ID> --alertmanager.url http://localhost:9093

# Hot-reload Alertmanager config
curl -X POST http://localhost:9093/-/reload
```

---

## Phase 3 — Grafana Dashboard Management

```bash
# Export a dashboard by UID (save to version control)
curl -s \
  -H "Authorization: Bearer $GRAFANA_API_KEY" \
  https://grafana.internal/api/dashboards/uid/abc123 \
  | jq '.dashboard' > dashboards/my-service.json

# Import a dashboard from JSON file
curl -s -X POST \
  -H "Authorization: Bearer $GRAFANA_API_KEY" \
  -H "Content-Type: application/json" \
  -d "{\"dashboard\": $(cat dashboards/my-service.json), \"overwrite\": true, \"folderId\": 0}" \
  https://grafana.internal/api/dashboards/import

# List all datasources
curl -H "Authorization: Bearer $GRAFANA_API_KEY" \
  https://grafana.internal/api/datasources | jq '.[].name'

# Test a datasource connection
curl -H "Authorization: Bearer $GRAFANA_API_KEY" \
  https://grafana.internal/api/datasources/1/health

# Search dashboards by tag
curl -H "Authorization: Bearer $GRAFANA_API_KEY" \
  "https://grafana.internal/api/search?tag=sre" | jq '.[].title'
```

---

## Phase 4 — PromQL Queries for Dashboard Panels

```bash
# Error rate (use in Grafana panel directly)
rate(http_requests_total{status=~"5.."}[5m])
/
rate(http_requests_total[5m])

# p99 latency (requires histogram metric)
histogram_quantile(0.99,
  sum(rate(http_request_duration_seconds_bucket[5m])) by (le, service)
)

# CPU usage per pod
rate(container_cpu_usage_seconds_total{container!=""}[5m])

# Memory usage per pod (working set, not cache)
container_memory_working_set_bytes{container!=""}

# Disk usage percentage
1 - (node_filesystem_avail_bytes / node_filesystem_size_bytes)

# SLO burn rate (1h window)
(
  rate(http_requests_total{status=~"5.."}[1h])
  /
  rate(http_requests_total[1h])
) / 0.001  # divide by error budget (0.1% for 99.9% SLO)
# Result > 1 means burning through budget; > 14.4 means critical burn
```

---

## Phase 5 — Kubernetes / Helm Deployment

```bash
# Deploy Prometheus + Alertmanager via kube-prometheus-stack Helm chart
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

helm install kube-prometheus \
  prometheus-community/kube-prometheus-stack \
  --namespace monitoring \
  --create-namespace \
  -f values/prometheus-values.yaml

# Check what's running in monitoring namespace
kubectl get pods -n monitoring

# Check PrometheusRule CRDs (Kubernetes-native alert rules)
kubectl get prometheusrules -n monitoring

# Apply a PrometheusRule manifest
kubectl apply -f prometheus/rules/sre-alerts-prometheusrule.yaml

# Check if Prometheus picked up the rule
kubectl logs -n monitoring deploy/kube-prometheus-prometheus -c prometheus | grep "Completed loading"

# Port-forward Prometheus UI locally
kubectl port-forward -n monitoring svc/kube-prometheus-kube-prometheus 9090:9090

# Port-forward Alertmanager UI locally
kubectl port-forward -n monitoring svc/kube-prometheus-alertmanager 9093:9093

# Port-forward Grafana UI locally
kubectl port-forward -n monitoring svc/kube-prometheus-grafana 3000:80
```

---

## Phase 6 — Audit and Maintenance

```bash
# Count how many alerts fired in the last 7 days (Prometheus query)
# Run in Grafana "Explore" or via API:
increase(ALERTS_FOR_STATE[7d])

# Find noisy alerts (fired > 10 times in 24h — candidates for tuning)
curl -s "http://localhost:9090/api/v1/query_range" \
  --data-urlencode 'query=count_over_time(ALERTS{alertstate="firing"}[24h])' \
  --data-urlencode 'start=2026-07-24T00:00:00Z' \
  --data-urlencode 'end=2026-07-31T00:00:00Z' \
  --data-urlencode 'step=3600' \
  | jq '.data.result[] | select(.values | length > 10) | .metric.alertname'

# List Grafana dashboards not updated in 6+ months
curl -H "Authorization: Bearer $GRAFANA_API_KEY" \
  https://grafana.internal/api/search?type=dash-db \
  | jq '.[] | select(.updated < "2026-01-31") | .title'

# Check Prometheus storage size (avoid disk fill)
du -sh /var/lib/prometheus/

# Check Prometheus WAL replay time (restart recovery indicator)
curl -s http://localhost:9090/api/v1/status/tsdb | jq '.data'
```
