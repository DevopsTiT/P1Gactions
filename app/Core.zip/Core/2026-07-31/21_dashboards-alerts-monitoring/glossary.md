# Glossary: Dashboards, Alerts & Monitoring

Every term from the main guide explained for an SRE beginner.

---

**Alert Fatigue**
When on-call engineers receive so many noisy or false-positive alerts that they start ignoring them. The most dangerous monitoring failure mode — a real incident gets missed because pages were "background noise."

**Alert Rule**
A condition written in PromQL that Prometheus checks on a schedule. When the condition is true for long enough (see: `for` duration), Prometheus fires an alert and hands it to Alertmanager.

**Alertmanager**
The component that receives fired alerts from Prometheus, deduplicates them, groups related ones together, applies silences, and routes them to the right destination (Slack, PagerDuty, email). Prometheus creates alerts; Alertmanager decides what to do with them.

**amtool**
CLI tool for interacting with Alertmanager from the terminal — send test alerts, view active alerts, create silences, and reload config.

**Annotation (Prometheus)**
Free-text fields attached to an alert rule. Used for `summary`, `description`, and `runbook_url`. Visible in Slack/PagerDuty notifications. Not used for routing — that's what labels are for.

**Baseline**
The normal, expected behavior of a system over time. You must know the baseline before you can detect anomalies. Without baseline, every threshold is a guess.

**Burn Rate**
How fast you are consuming your error budget relative to the allowed rate. A burn rate of 1x means you'll use exactly 100% of budget in the SLO period. A burn rate of 14.4x means you'll exhaust a monthly budget in 50 hours.

**Container**
A lightweight, isolated process package. In Kubernetes, pods contain one or more containers. Monitoring container metrics (CPU, memory) is different from node-level metrics.

**Counter (Prometheus metric type)**
A metric that only goes up (like an odometer). Always use `rate()` or `increase()` on counters — the raw number is meaningless without knowing the time window.

**Dashboard**
A visual page in Grafana showing graphs, numbers, and tables drawn from your metrics data. Like a car dashboard: you see speed, fuel, engine warnings all in one view.

**Dashboard Variables**
Dynamic dropdowns in Grafana that let you filter a dashboard by namespace, pod, environment, etc. Without variables, you'd need a separate dashboard per service/environment.

**Datasource (Grafana)**
A configured backend that Grafana reads data from. Common datasources: Prometheus (metrics), Loki (logs), Tempo (traces), Elasticsearch.

**Davis AI (Dynatrace)**
Dynatrace's AI engine that automatically detects anomalies, finds root causes, and groups related problems into a single "problem" event — without you writing any thresholds.

**Error Budget**
The allowed amount of downtime/errors within an SLO period. For 99.9% availability over 30 days, the error budget = 0.1% = 43.8 minutes. Alerts fire when you burn through this budget too fast.

**`for` duration (Prometheus)**
The minimum time an alert condition must be continuously true before the alert fires. Prevents alert storms from 1-second transient spikes. `for: 2m` means: "only fire if this has been true for 2 straight minutes."

**Four Golden Signals**
Google SRE's framework for what to monitor: Latency (how slow?), Traffic (how much?), Errors (how broken?), Saturation (how full?). Anything outside these is secondary.

**Gauge (Prometheus metric type)**
A metric that goes up and down (like a thermometer). Use directly — no need for `rate()`. Examples: current CPU%, memory in use, queue depth.

**Grafana**
Open-source visualization tool. Reads data from Prometheus, Loki, Tempo and turns it into interactive dashboards. Think of it as Excel charts but for live production systems.

**Grafonnet**
A library that lets you write Grafana dashboards in code (Jsonnet language) rather than clicking through the UI. Produces the same JSON Grafana uses internally.

**Histogram (Prometheus metric type)**
A metric that buckets observations by value range. Required for percentile calculations with `histogram_quantile()`. HTTP request duration is almost always a histogram.

**histogram_quantile()**
Prometheus function to calculate percentiles from histogram data. `histogram_quantile(0.99, ...)` gives you p99 latency — the value below which 99% of requests fall.

**Inhibition Rule (Alertmanager)**
A rule that suppresses "lower-level" alerts when a "higher-level" alert is already firing for the same service. Prevents alert flooding: if a service is down (critical), don't also send the "high CPU" warning for the same service.

**Jsonnet**
A data templating language (superset of JSON) used to generate Grafana dashboard JSON programmatically. Enables reusable dashboard components.

**kube-prometheus-stack**
A Helm chart that installs a complete Prometheus + Alertmanager + Grafana monitoring stack into Kubernetes in one command. The standard starting point for Kubernetes monitoring.

**Label (Prometheus)**
A key-value tag attached to a metric or alert. Used for filtering and routing. Example: `{service="my-service", namespace="production"}`. Alert routing in Alertmanager uses labels.

**Loki**
Log aggregation system from Grafana Labs. Stores logs in a compressed, indexed format. Designed to work alongside Prometheus — same label model, queryable from Grafana.

**Multi-window Multi-burn-rate Alerting**
The recommended SLO alerting strategy: use two time windows (e.g., 1h + 5m) at the same time. The long window detects slow burns; the short window confirms it's still happening. Reduces both false positives and false negatives.

**Node (Kubernetes)**
A physical or virtual machine in a Kubernetes cluster. Pods run on nodes. Node-level metrics (disk, CPU, network) come from `node_exporter`.

**NoData State (Grafana Alerting)**
What Grafana should do when a query returns no data points. Options: `NoData` (keep as-is), `Alerting` (treat as firing), `OK`. Choosing wrong causes phantom alerts when a service first starts.

**On-call**
The engineer (or rotation of engineers) responsible for responding to production alerts at any hour. A badly designed alerting system means unnecessary wake-ups; a well-designed one means pages are always actionable.

**PagerDuty**
Incident management platform. Receives critical alerts, manages on-call schedules and escalation policies, creates incident records, and tracks mean time to acknowledge/resolve.

**Percentile (p50, p95, p99)**
A statistical measure. p99 latency = 99% of requests were faster than this value. p50 = median. Monitoring p99 catches the worst-user-experience tail that averages hide.

**Prometheus**
Open-source metrics collection and alerting system. Scrapes metrics from your services on a schedule, stores them in a time-series database (TSDB), evaluates alert rules, and exposes a query API (PromQL).

**PrometheusRule (CRD)**
A Kubernetes Custom Resource that defines alert rules. When you create a PrometheusRule object in Kubernetes, the Prometheus operator automatically picks it up — no Prometheus restart needed.

**promtool**
CLI tool for working with Prometheus locally: validate rule files, run unit tests against alert rules, query TSDB data. Run `promtool check rules` before every alert config change.

**PromQL**
Prometheus Query Language. Used to write alert expressions and Grafana panel queries. Key functions: `rate()` (per-second rate of a counter), `sum()` (aggregate across labels), `histogram_quantile()` (percentiles).

**Runbook**
A step-by-step document that tells an on-call engineer exactly what to do when a specific alert fires. Every alert should link to its runbook. Without runbooks, institutional knowledge lives only in people's heads.

**Saturation**
One of the four golden signals. Measures how full a resource is: CPU%, memory%, disk%, thread pool size. High saturation is a leading indicator — it predicts future errors before users feel them.

**Scrape Interval**
How often Prometheus polls a target for metrics. Default: 15s or 30s. Shorter intervals = more data resolution but more storage and CPU cost.

**Silence (Alertmanager)**
A time-bounded suppression rule in Alertmanager. During a known maintenance window, create a silence to stop pages from firing. Has an expiry time — it always ends.

**SLO (Service Level Objective)**
A numerical target for service reliability. Example: "99.9% of requests succeed." The SLO defines your error budget. Alert thresholds should be derived from SLOs, not guessed.

**Symptom-based Alert**
An alert that fires when users are experiencing a problem (error rate high, latency high). The right kind of alert to page someone about at 3am — it's always actionable.

**Cause-based Alert**
An alert that fires when an infrastructure metric is high (CPU%, disk%). Useful for early warning but should almost never wake someone up — use for Slack warnings only.

**Tempo**
Distributed tracing backend from Grafana Labs. Stores spans from OpenTelemetry/Jaeger. Integrates with Grafana for trace visualization and correlation with metrics/logs.

**Terraform (for monitoring)**
Infrastructure-as-Code tool. The Grafana Terraform provider lets you manage dashboards, folders, alert rules, and data sources as versioned `.tf` files rather than clicking in the UI.

**TSDB (Time Series Database)**
A database optimized for storing and querying data points indexed by time. Prometheus uses its own embedded TSDB. Every metric is a series of (timestamp, value) pairs.

**WAL (Write-Ahead Log)**
Prometheus's crash recovery mechanism. Writes incoming metrics to a WAL before committing to disk — ensures data isn't lost on crash. "WAL replay time" at startup tells you how long recovery takes.

**Working Set Memory**
The memory a container is actually using (excluding OS-managed page cache). `container_memory_working_set_bytes` is the right metric for Kubernetes memory alerts — not `container_memory_usage_bytes`, which includes evictable cache.
