# Part 4 Deep Dive — Monitoring Configuration as Code

---

## Why "Config as Code" Is Non-Negotiable

Before explaining HOW, you need to deeply understand WHY. Many teams skip this and pay the price.

```
SCENARIO A: Dashboards and alerts configured in the Grafana/Alertmanager UI
  (the "clickops" approach)

Day 1: SRE Alice configures a beautiful dashboard for the payment service.
       She adds custom panels, thresholds, and alert rules directly in the UI.

Day 30: Grafana is upgraded. The dashboard data format changed.
        Alice's dashboard is broken. Nobody has the original config.
        Two days lost recreating it.

Day 45: New team member Bob edits a threshold on an alert.
        The threshold was wrong for 6 weeks before someone noticed.
        Nobody knows WHO changed it or WHY.

Day 60: Production incident. Team needs the dashboard.
        Bob accidentally deleted it while investigating.
        Dashboard gone. Incident takes 3x longer.

Day 90: Need to replicate setup for a new service.
        No template exists. Start from scratch.
        4 hours of clicking to create what should take 10 minutes.
```

```
SCENARIO B: Everything as code in git

Day 1: SRE Alice writes dashboard JSON + alert rules in YAML.
       Commits to git with PR review.
       "Add payment service monitoring" — reviewable, auditable.

Day 30: Grafana upgrade breaks dashboard format.
        alice runs: git revert abc123 (dashboard back in 2 minutes)

Day 45: Bob opens a PR to change a threshold.
        PR shows exactly what changed: "alert threshold 2.0 → 1.5 on HighP99Latency"
        Reviewer asks: "Why? Was there a user complaint?"
        Discussion happens. Correct threshold is agreed. Knowledge is documented.

Day 60: Incident. Dashboard deleted?
        git pull → CI/CD automatically restores it in 30 seconds.

Day 90: New service needs monitoring.
        cp -r dashboards/payment-service dashboards/new-service
        Update service name. Done in 5 minutes.
```

The difference: Configuration drift, knowledge loss, and unreviewed changes vs a living, auditable, recoverable system.

---

## The Four Layers of Monitoring Config as Code

```
Layer 1: Prometheus Rules (YAML files)
  What: Alert rules, recording rules
  Where: Git repo → Kubernetes ConfigMap or PrometheusRule CRD
  Review: PR before production

Layer 2: Alertmanager Config (YAML file)
  What: Routing, receivers, inhibition
  Where: Git repo → Kubernetes Secret/ConfigMap
  Review: PR before production

Layer 3: Grafana Dashboards (JSON files)
  What: Visual dashboards
  Where: Git repo → deployed via Grafana API or Terraform
  Review: PR before production

Layer 4: Infrastructure (Terraform/Helm)
  What: Prometheus deployment, scrape configs, Grafana datasources
  Where: Terraform modules in git
  Review: PR + plan review before apply
```

---

## Layer 1: Prometheus Rules as Code

### File Structure (Best Practice)

```
prometheus/
├── rules/
│   ├── slo-rules.yaml          ← SLO recording + alerting rules
│   ├── latency-rules.yaml      ← Latency alerts
│   ├── saturation-rules.yaml   ← CPU, memory, disk alerts
│   ├── dependency-rules.yaml   ← Downstream dependency alerts
│   ├── kubernetes-rules.yaml   ← Pod, deployment health alerts
│   └── tests/
│       ├── slo-rules-test.yaml
│       └── latency-rules-test.yaml
└── README.md
```

### PrometheusRule CRD (Kubernetes-Native Way)

Instead of loading rules via ConfigMap, use the Prometheus Operator's CRD:

```yaml
# prometheus/rules/slo-prometheusrule.yaml
apiVersion: monitoring.coreos.com/v1
kind: PrometheusRule
metadata:
  name: my-service-slo-rules
  namespace: monitoring
  labels:
    # This label tells the Prometheus Operator to load this rule
    app: kube-prometheus
    role: alert-rules
spec:
  groups:
    - name: my-service.slo
      interval: 30s
      rules:

        # Recording rule: pre-compute the SLI (makes alert evaluation cheaper)
        - record: job:sli_error_rate:5m
          expr: |
            sum(rate(http_requests_total{job="my-service", status=~"5.."}[5m]))
            / sum(rate(http_requests_total{job="my-service"}[5m]))

        - record: job:sli_error_rate:1h
          expr: |
            sum(rate(http_requests_total{job="my-service", status=~"5.."}[1h]))
            / sum(rate(http_requests_total{job="my-service"}[1h]))

        # Alert rule: uses the pre-computed recording rule (faster evaluation)
        - alert: MyService_SLOFastBurn
          expr: |
            job:sli_error_rate:1h > (14.4 * 0.001)
            and
            job:sli_error_rate:5m > (14.4 * 0.001)
          for: 2m
          labels:
            severity: critical
            service: my-service
          annotations:
            summary: "SLO fast burn on my-service"
            runbook_url: "https://wiki/runbooks/my-service-slo"
```

**Why use the CRD over a ConfigMap?**
```
ConfigMap approach:
  1. Change the file
  2. kubectl apply the ConfigMap
  3. Wait for Prometheus to auto-reload (or curl /-/reload)
  4. Verify rule loaded: kubectl logs prometheus-pod | grep "Loaded"
  5. 3–5 minutes total

PrometheusRule CRD approach:
  1. Change the file
  2. kubectl apply the PrometheusRule
  3. Prometheus Operator detects change → auto-updates Prometheus in ~5s
  No manual reload needed. Kubernetes-native.
```

### Alert Rule Unit Testing

Unit tests let you verify alert rules fire correctly WITHOUT a live Prometheus or production traffic:

```yaml
# prometheus/rules/tests/slo-rules-test.yaml
rule_files:
  - ../slo-rules.yaml

evaluation_interval: 1m

tests:
  # Test 1: Normal operation → NO alert should fire
  - interval: 1m
    input_series:
      - series: 'http_requests_total{job="my-service", status="200"}'
        values: '0+1000x60'   # 1000 requests/min for 60 minutes
      - series: 'http_requests_total{job="my-service", status="500"}'
        values: '0+0.5x60'    # 0.5 errors/min = 0.05% error rate (under budget)
    alert_rule_test:
      - eval_time: 65m
        alertname: MyService_SLOFastBurn
        exp_alerts: []         # expect NO alerts — normal operation

  # Test 2: 2% error rate → SHOULD trigger SLO fast burn
  - interval: 1m
    input_series:
      - series: 'http_requests_total{job="my-service", status="200"}'
        values: '0+980x60'   # 980 good
      - series: 'http_requests_total{job="my-service", status="500"}'
        values: '0+20x60'    # 20 errors = 2% error rate (20x budget rate)
    alert_rule_test:
      - eval_time: 65m
        alertname: MyService_SLOFastBurn
        exp_alerts:
          - exp_labels:
              severity: critical
              service: my-service
```

Run tests locally:
```bash
# Validate rule file syntax
promtool check rules prometheus/rules/slo-rules.yaml

# Run unit tests (no live Prometheus needed)
promtool test rules prometheus/rules/tests/slo-rules-test.yaml
# Output: OK (all tests passed) or detailed failure info
```

---

## Layer 3: Grafana Dashboards as Code

### Method A: JSON in Git (Simplest)

Export the dashboard JSON from Grafana's UI, commit it to git, and import via API in CI/CD:

```bash
# ── EXPORT (one-time, when dashboard is ready) ────────────────────────

# Get the dashboard UID from the URL: grafana.internal/d/ABC123/...
DASHBOARD_UID="ABC123"

# Export dashboard JSON (strips server-specific fields)
curl -s \
  -H "Authorization: Bearer ${GRAFANA_API_KEY}" \
  "https://grafana.internal/api/dashboards/uid/${DASHBOARD_UID}" \
  | jq '.dashboard | del(.id, .version)' \
  > dashboards/my-service-overview.json

# Commit to git
git add dashboards/my-service-overview.json
git commit -m "Add my-service overview dashboard"

# ── IMPORT (in CI/CD pipeline, runs on every merge to main) ──────────

# Import/update dashboard
curl -s -X POST \
  -H "Authorization: Bearer ${GRAFANA_API_KEY}" \
  -H "Content-Type: application/json" \
  -d "{
    \"dashboard\": $(cat dashboards/my-service-overview.json),
    \"folderId\": 5,
    \"overwrite\": true,
    \"message\": \"Deployed from git at $(git rev-parse --short HEAD)\"
  }" \
  "https://grafana.internal/api/dashboards/import"
```

### Method B: Grafonnet/Jsonnet (For Scale)

Jsonnet generates the JSON programmatically. Enables reusable components across dashboards:

```jsonnet
// dashboards/my-service.jsonnet
local grafana = import 'grafonnet/grafana.libsonnet';
local dashboard = grafana.dashboard;
local graphPanel = grafana.graphPanel;
local statPanel = grafana.statPanel;
local prometheus = grafana.prometheus;
local template = grafana.template;

// Reusable color thresholds (define once, use everywhere)
local errorRateThresholds = {
  mode: 'absolute',
  steps: [
    { color: 'green', value: null },
    { color: 'yellow', value: 0.001 },  // 0.1%
    { color: 'red', value: 0.01 },      // 1%
  ],
};

// Build the dashboard
dashboard.new(
  title='My Service — SRE Overview',
  uid='my-service-overview',
  time_from='now-3h',
  refresh='30s',
  tags=['sre', 'my-service', 'production'],
  editable=false,  // Prevent accidental UI edits (enforces code-only changes)
)

// Variable: namespace selector
.addTemplate(
  template.datasource('datasource', 'prometheus', 'Prometheus')
)
.addTemplate(
  template.new(
    name='namespace',
    datasource='$datasource',
    query='label_values(kube_pod_info, namespace)',
    current='production',
    refresh=2,
  )
)

// Row 1: Stat panels
.addPanel(
  statPanel.new(
    title='Error Rate',
    datasource='$datasource',
    reducerFunction='last',
    colorMode='background',
    thresholds=errorRateThresholds,
    unit='percentunit',
  ).addTarget(
    prometheus.target(
      expr='sum(rate(http_requests_total{job="my-service", status=~"5.."}[5m])) / sum(rate(http_requests_total{job="my-service"}[5m]))',
      instant=true,
    )
  ),
  gridPos={ x: 0, y: 0, w: 6, h: 4 }
)
```

Compile Jsonnet to JSON:
```bash
# Install jsonnet
brew install jsonnet

# Compile to JSON
jsonnet -J grafonnet-lib dashboards/my-service.jsonnet \
  -o dashboards/my-service.json

# Import to Grafana (same as Method A import)
```

### Method C: Terraform (For Large Teams)

When you manage Grafana through Terraform alongside your infrastructure:

```hcl
# terraform/monitoring/grafana.tf

# Create a folder for SRE dashboards
resource "grafana_folder" "sre" {
  title = "SRE Dashboards"
  uid   = "sre-dashboards"
}

# Deploy each dashboard from a JSON file
resource "grafana_dashboard" "my_service_overview" {
  folder      = grafana_folder.sre.id
  config_json = file("${path.module}/dashboards/my-service-overview.json")
  overwrite   = true

  # Track which git commit deployed this dashboard
  message = "Deployed by Terraform (commit: ${var.git_commit_sha})"
}

# Create the alert rule in Grafana (Grafana 9+ has its own alerting)
resource "grafana_rule_group" "my_service" {
  name             = "my-service-alerts"
  folder_uid       = grafana_folder.sre.uid
  interval_seconds = 60

  rule {
    name           = "HighErrorRate"
    condition      = "C"
    for            = "2m"
    no_data_state  = "NoData"
    exec_err_state = "Error"

    data {
      ref_id = "A"
      datasource_uid = "prometheus"
      relative_time_range {
        from = 300  # last 5 minutes
        to   = 0
      }
      model = jsonencode({
        expr = "sum(rate(http_requests_total{job=\"my-service\",status=~\"5..\"}[5m])) / sum(rate(http_requests_total{job=\"my-service\"}[5m]))"
      })
    }

    # Threshold condition: value of A > 0.01
    data {
      ref_id = "C"
      datasource_uid = "-100"  # expression datasource
      relative_time_range { from = 0; to = 0 }
      model = jsonencode({
        type       = "threshold"
        conditions = [{
          evaluator = { params = [0.01], type = "gt" }
          operator  = { type = "and" }
          query     = { params = ["A"] }
          reducer   = { params = [], type = "last" }
          type      = "query"
        }]
      })
    }

    annotations = {
      summary     = "Error rate > 1% on my-service"
      runbook_url = "https://wiki/runbooks/high-error-rate"
    }

    labels = {
      severity = "critical"
      team     = "platform"
    }
  }
}
```

---

## CI/CD Pipeline for Monitoring Config

### GitHub Actions Pipeline

```yaml
# .github/workflows/monitoring.yaml
name: Deploy Monitoring Config

on:
  push:
    branches: [main]
    paths:
      - 'prometheus/**'
      - 'alertmanager/**'
      - 'dashboards/**'
      - 'terraform/monitoring/**'

jobs:
  validate:
    name: Validate monitoring config
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Install promtool
        run: |
          PROMETHEUS_VERSION="2.48.0"
          wget -q https://github.com/prometheus/prometheus/releases/download/v${PROMETHEUS_VERSION}/prometheus-${PROMETHEUS_VERSION}.linux-amd64.tar.gz
          tar xf prometheus-*.tar.gz
          sudo mv prometheus-*/promtool /usr/local/bin/

      - name: Lint Prometheus rules
        run: |
          find prometheus/rules -name "*.yaml" -not -path "*/tests/*" | \
          xargs -I{} promtool check rules {}

      - name: Run alert unit tests
        run: |
          find prometheus/rules/tests -name "*-test.yaml" | \
          xargs -I{} promtool test rules {}

      - name: Validate Alertmanager config
        run: |
          docker run --rm \
            -v $(pwd)/alertmanager:/etc/alertmanager \
            prom/alertmanager:latest \
            amtool check-config /etc/alertmanager/alertmanager.yaml

      - name: Validate dashboard JSON syntax
        run: |
          for f in dashboards/*.json; do
            jq empty "$f" && echo "✓ $f" || (echo "✗ Invalid JSON: $f" && exit 1)
          done

  deploy:
    name: Deploy to production
    runs-on: ubuntu-latest
    needs: validate
    environment: production
    steps:
      - uses: actions/checkout@v3

      - name: Apply PrometheusRule CRDs
        run: |
          kubectl apply -f prometheus/rules/ --namespace monitoring
          # Wait for Prometheus to reload
          sleep 10
          # Verify rules loaded
          kubectl get prometheusrules -n monitoring

      - name: Reload Alertmanager
        run: |
          kubectl apply -f alertmanager/ --namespace monitoring
          kubectl rollout restart deployment/alertmanager -n monitoring
          kubectl rollout status deployment/alertmanager -n monitoring

      - name: Deploy Grafana dashboards
        env:
          GRAFANA_API_KEY: ${{ secrets.GRAFANA_API_KEY }}
          GRAFANA_URL: ${{ secrets.GRAFANA_URL }}
        run: |
          for dashboard in dashboards/*.json; do
            SERVICE_NAME=$(basename "$dashboard" .json)
            echo "Deploying dashboard: $SERVICE_NAME"
            curl -sf -X POST \
              -H "Authorization: Bearer ${GRAFANA_API_KEY}" \
              -H "Content-Type: application/json" \
              -d "{\"dashboard\": $(cat "$dashboard"), \"overwrite\": true}" \
              "${GRAFANA_URL}/api/dashboards/import"
          done
```

---

## Versioning Dashboards — Handling the "UI Edit" Problem

The hardest problem with dashboards as code: team members edit dashboards directly in the Grafana UI (because it's easy), bypassing git. The next CI/CD run overwrites their changes.

Solutions:

```
Option A: Lock dashboards (recommended)
  Set editable=false in dashboard JSON
  Prevents all UI edits
  Forces all changes through code
  Con: Slows iteration speed during development

Option B: Drift detection script
  Runs daily; compares git JSON with live Grafana JSON
  Sends Slack message if drift detected
  "Dashboard my-service-overview was edited outside of git by @charlie"
  Con: Reactive, not preventive

Option C: Separate "draft" and "production" folders
  Folder "SRE Drafts": fully editable in UI
  Folder "SRE Production": locked, git-only
  Workflow: Develop in Drafts → export JSON → PR → deploy to Production
  Con: Two places to look; easy to forget to promote

Option D: Grafana provisioning (filesystem-based)
  Mount dashboard JSON files directly into the Grafana pod via ConfigMap
  Grafana loads from filesystem on startup
  UI shows dashboards as read-only automatically
  Changes require updating the ConfigMap (which is in git)
  Con: Requires Grafana pod restart to pick up changes (or provisioning polling)
```

```yaml
# Grafana provisioning ConfigMap (Option D)
# kubernetes/grafana-dashboards-configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: grafana-dashboards
  namespace: monitoring
data:
  my-service-overview.json: |
    {
      "title": "My Service - Overview",
      "uid": "my-service-overview",
      "editable": false,
      ...
    }
---
# Grafana deployment mounts this ConfigMap
# The provisioning config tells Grafana where to find dashboards
apiVersion: v1
kind: ConfigMap
metadata:
  name: grafana-provisioning-dashboards
  namespace: monitoring
data:
  dashboards.yaml: |
    apiVersion: 1
    providers:
      - name: 'SRE Dashboards'
        orgId: 1
        folder: 'SRE'
        folderUid: 'sre-dashboards'
        type: file
        disableDeletion: true    # Don't delete dashboards removed from ConfigMap
        updateIntervalSeconds: 30
        allowUiUpdates: false    # Prevent UI edits
        options:
          path: /var/lib/grafana/dashboards
```
