# Part 5 Deep Dive — Maintaining Dashboards and Alerts Over Time

---

## Why Maintenance Is a Separate Discipline

Building dashboards and alerts is a one-time cost. Maintaining them is an ongoing investment.

Systems change. Code changes. Metrics get renamed. Services get split or merged. Traffic patterns shift with seasonal load. What was accurate 6 months ago may be wrong or misleading today.

The risk of ignoring maintenance:
```
Scenario: An alert threshold was correct at 50 requests/sec.
          Traffic grew to 500 requests/sec over 6 months.
          Nobody updated the threshold.
          
          Result: Alert fires every peak hour because absolute count exceeds threshold.
          On-call silences it every time ("false positive, ignore").
          One day: real incident. Alert fires. On-call silences it (habit).
          Incident goes undetected for 2 hours.
          This is how alert fatigue kills reliability.
```

Maintenance prevents the system from drifting into a state where it can't be trusted.

---

## The Alert Quality Audit — Monthly Cadence

Run this audit every 30 days. It takes 1–2 hours and prevents months of noise accumulation.

### The Five Questions for Every Alert

```
For every alert that fired in the last 30 days:

Q1: Did it fire at all?
  Never fired → Is it still needed?
    If the condition it guards against is still possible → keep
    If the system changed and this condition can't happen anymore → remove
    A dead alert is noise in your rule files and causes confusion

Q2: When it fired, was it actionable?
  Actionable = on-call had a clear action to take (rollback, restart, scale up)
  Not actionable = on-call looked at it, did nothing, it resolved itself
    NOT actionable → rewrite or remove
    Acceptable reasons to keep non-actionable: if it's a WARNING (Slack, not page)

Q3: Did it wake someone up outside business hours?
  Yes + it was actionable → check if threshold should be tightened
  Yes + it was NOT actionable → the threshold or `for` duration needs tuning
  No 3am pages from this alert → threshold is probably right

Q4: Was the alert a duplicate of another alert for the same incident?
  If yes, add an inhibition rule so the secondary doesn't fire
  Keep the root-cause alert; inhibit the symptom alerts

Q5: Was the runbook correct and helpful?
  If on-call spent > 5 min figuring out what to do → update the runbook
  If the runbook steps are wrong → fix them immediately
  An incident is the best time to identify runbook gaps; fix within 48h

Target: < 5% of alert fires are "noise" (non-actionable, false positive)
```

### The Alert Noise Score

Build a simple spreadsheet with this data:

```
Alert Name           | Fires/Month | Actionable | Night? | Duplicate | Score
─────────────────────────────────────────────────────────────────────────────
SLOFastBurn          |     3       |     3      |   1    |     0     |  100%
DiskWillFillIn4H     |     2       |     2      |   0    |     0     |  100%
HighP99Latency       |    15       |     8      |   5    |     7     |   53%  ← FIX
CPUHighUsage         |    30       |     0      |    12  |    30     |    0%  ← REMOVE
PodCrashLooping      |     1       |     1      |   1    |     0     |  100%

Score = actionable_fires / total_fires × 100

Action:
  Score < 50% + severity=critical → urgent fix (causing alert fatigue)
  Score < 50% + severity=warning  → fix this sprint
  Score = 0% → remove or demote to INFO
```

### How to Fix a Noisy Alert

```
Problem: CPUHighUsage fires 30 times/month, 0 actionable
  Current config: CPU > 80% for 1 minute → page on-call

Diagnosis:
  Step 1: Look at the 30 firings. What was CPU when it fired? Always ~82-85%.
  Step 2: Does high CPU correlate with any user-visible degradation? No.
  Step 3: Is there HPA to handle load? Yes — it scales up after 90s.

Fix options:
  Option A: Increase threshold to 90% (catches real saturation, not normal peaks)
  Option B: Increase `for` duration to 10m (filters HPA-resolved spikes)
  Option C: Change severity to INFO (don't page; just Slack)
  Option D: Change alert to: CPU > 90% AND throttling > 25% AND latency rising
            (compound condition: only fire when CPU is CAUSING user impact)

Best fix: Option D — make it a multi-condition alert that only fires when
CPU saturation is CAUSING a symptom, not just when it's high alone.

New alert:
  expr: |
    (container_cpu_usage_saturation > 0.90)
    and
    (container_cpu_throttled_seconds_total_rate > 0.30)
    and
    (http_request_duration_p99 > 1.5)
  for: 10m
  labels:
    severity: warning   # Downgraded from critical
  # Now only fires when CPU is actually hurting users
```

---

## SLO Burn Rate Review — Monthly

### What to Check

```
Monthly SLO review agenda (15 minutes):

1. How much error budget was consumed this month?
   Target: < 50% consumed
   Formula: 
     budget_consumed = sum of all error events / total_budget_for_period

2. Is the trend improving or worsening?
   Compare: this month vs last month vs 3 months ago
   Improving: budget consumption declining → reliability work is paying off
   Worsening: budget consumption rising → need reliability sprint

3. Which incidents consumed the most budget?
   Pull incident timeline: which incidents caused the largest error rate spikes?
   These are the highest-priority items for reliability investment

4. Are our SLO targets still appropriate?
   If budget consumption is consistently < 5% → SLO might be too loose
   If budget consumption is consistently > 80% → SLO might be too tight
   Review annually: adjust as architecture improves

5. Are our alert thresholds correct?
   Did the critical burn-rate alert fire for every real incident?
   Did it fire falsely? (false positive = threshold too sensitive)
```

### Calculating Budget Consumption from Prometheus

```bash
# Total error budget consumed last 30 days (as a fraction)
# Run in Grafana Explore panel:

# Step 1: Calculate the total error rate over 30 days
# (average of 5m error rate samples over 30 days)
avg_over_time(
  (
    sum(rate(http_requests_total{job="my-service", status=~"5.."}[5m]))
    / sum(rate(http_requests_total{job="my-service"}[5m]))
  )[30d:5m]
)

# Step 2: Divide by SLO error budget rate to get consumption fraction
# (0.001 = 0.1% error budget for 99.9% SLO)
avg_over_time(
  (
    sum(rate(http_requests_total{job="my-service", status=~"5.."}[5m]))
    / sum(rate(http_requests_total{job="my-service"}[5m]))
  )[30d:5m]
) / 0.001

# Result interpretation:
# 0.5 = 50% of budget consumed this month (healthy)
# 1.0 = 100% consumed (SLO barely met)
# 1.5 = 150% consumed (SLO breached this month)
```

---

## Dashboard Hygiene Rules — The Full Rulebook

### Rule 1: Every Dashboard Has an Owner Label

```json
{
  "tags": ["sre", "my-service", "team:platform", "owner:alice"],
  "annotations": {
    "list": [{
      "name": "Owner",
      "text": "Platform SRE team — #platform-sre in Slack"
    }]
  }
}
```

Why: When a dashboard shows wrong data or needs an update, someone must be responsible. "No owner" = nobody fixes it.

### Rule 2: No Dashboard Older Than 6 Months Without Review

```bash
# Find dashboards not updated in 6+ months via Grafana API
curl -s \
  -H "Authorization: Bearer ${GRAFANA_API_KEY}" \
  "https://grafana.internal/api/search?type=dash-db&limit=1000" \
  | jq --arg cutoff "$(date -d '6 months ago' --iso-8601)" \
    '.[] | select(.updated < $cutoff) | {title, updated, url}'
```

Review checklist for old dashboards:
```
□ Are all metric names still correct? (metrics get renamed in upgrades)
□ Are all variable templates still working? (label names change)
□ Does the dashboard cover the right service boundary?
  (service may have been split into microservices)
□ Are the SLO thresholds still correct?
□ Does each panel link to the correct deeper dashboard?
□ Is the runbook URL still valid?
```

### Rule 3: Every Dashboard Links to Runbooks

Every dashboard MUST have a link panel or annotation linking to the runbook for each service. When on-call opens the dashboard at 3am, the runbook should be one click away.

```json
{
  "links": [
    {
      "title": "Runbook",
      "type": "link",
      "url": "https://wiki/runbooks/my-service",
      "icon": "doc",
      "targetBlank": true
    },
    {
      "title": "Service README",
      "type": "link",
      "url": "https://github.com/org/my-service/blob/main/README.md",
      "icon": "external link"
    },
    {
      "title": "On-call Escalation",
      "type": "link",
      "url": "https://pagerduty.com/services/ABC123",
      "icon": "bell"
    }
  ]
}
```

### Rule 4: Production Dashboards Tested in Staging

Before deploying a new dashboard to production:

```bash
# Step 1: Deploy to staging Grafana (separate Grafana instance for staging)
curl -X POST \
  -H "Authorization: Bearer ${STAGING_GRAFANA_API_KEY}" \
  -H "Content-Type: application/json" \
  -d "{\"dashboard\": $(cat dashboards/my-service.json), \"overwrite\": true}" \
  "https://grafana-staging.internal/api/dashboards/import"

# Step 2: Verify all panels load without errors
# - No "No data" panels when data should exist
# - No PromQL errors (red panel header)
# - Variables populate correctly
# - Time range selections work

# Step 3: Merge PR → CI/CD deploys to production
```

### Rule 5: Git is Truth (Not the Grafana UI)

```
If a dashboard diverges between git and Grafana UI:
  GIT is correct.
  The UI version is overwritten on next CI/CD run.

If you make experimental changes in the UI:
  Export the JSON immediately
  Create a PR with the changes
  Get it merged before the next CI/CD run overwrites your work

Enforce this with a drift detection cron job:
```

```bash
#!/bin/bash
# drift-detection.sh — run daily via CronJob

GRAFANA_URL="https://grafana.internal"
GRAFANA_API_KEY="${GRAFANA_API_KEY}"

for dashboard_file in dashboards/*.json; do
  UID=$(jq -r '.uid' "$dashboard_file")
  
  # Get live version from Grafana
  LIVE=$(curl -s \
    -H "Authorization: Bearer ${GRAFANA_API_KEY}" \
    "${GRAFANA_URL}/api/dashboards/uid/${UID}" \
    | jq '.dashboard | del(.id, .version, .iteration)')
  
  # Get git version
  GIT=$(jq 'del(.id, .version, .iteration)' "$dashboard_file")
  
  if [ "$LIVE" != "$GIT" ]; then
    # Send Slack alert about drift
    curl -X POST "${SLACK_WEBHOOK}" \
      -d "{\"text\": \":warning: Dashboard drift detected: ${UID} differs from git. Someone edited it in the UI.\"}"
  fi
done
```

---

## Runbook Template — The Complete Standard

Every alert must link to a runbook. Every runbook must follow this structure:

```markdown
# Runbook: [AlertName]

## Quick Reference
| Field         | Value                              |
|---------------|------------------------------------|
| Alert name    | MyService_SLOFastBurn              |
| Severity      | Critical                           |
| Team          | Platform SRE                       |
| Escalation    | #platform-sre → @alice → @on-call-manager |
| Dashboard     | https://grafana.internal/d/...     |
| Service repo  | https://github.com/org/my-service  |

---

## What Is This Alert?

The SLO fast burn alert fires when the error budget for my-service is being
consumed at 14.4x the normal rate. At this rate, the monthly error budget
will be exhausted in less than 2 days.

This means: approximately 1–20% of user requests are currently failing.

---

## Immediate Actions (first 5 minutes)

1. **Check the dashboard** to understand the scope:
   - Which endpoints are erroring?
   - What error type (5xx code)?
   - When did it start?
   ```
   Dashboard: https://grafana.internal/d/my-service-overview
   ```

2. **Check for a recent deployment:**
   ```bash
   kubectl rollout history deployment/my-service -n production
   ```
   If deploy within last 30 min → **go to "If Recent Deploy" section**

3. **Check logs for error messages:**
   ```bash
   kubectl logs -n production deploy/my-service --tail=100 | grep -E "ERROR|FATAL|Exception"
   ```

---

## If Recent Deploy: Rollback Immediately

Do NOT investigate first. Rollback first, investigate after.

```bash
# Rollback to previous version
kubectl rollout undo deployment/my-service -n production

# Watch rollback progress (wait for all pods to switch)
kubectl rollout status deployment/my-service -n production -w

# Verify error rate is dropping (check dashboard or run):
kubectl logs -n production deploy/my-service --tail=20 | grep -c "ERROR"
```

After rollback, if error rate is still elevated → the problem was NOT the deployment.

---

## If No Recent Deploy: Dependency Investigation

### Check DB health
```bash
# Is DB responding?
kubectl exec -n production deploy/my-service -- pg_isready -h db-host -p 5432

# Check DB dashboard: https://grafana.internal/d/postgresql-overview
```

### Check downstream service health
```bash
# Test payment service from within the pod
kubectl exec -n production deploy/my-service -- \
  curl -s -o /dev/null -w "%{http_code}" http://payment-service/health
```

### Check for resource exhaustion
```bash
# Is any pod OOMKilling?
kubectl get events -n production --field-selector reason=OOMKilling

# Is any pod crash looping?
kubectl get pods -n production | grep -v Running
```

---

## Escalation

| Time | Action |
|------|--------|
| T+0  | Start investigation |
| T+15 | If not mitigated: escalate to @alice (service owner) |
| T+30 | If not mitigated: declare SEV1, open war room, escalate to @eng-manager |

---

## After Resolution

1. Declare incident resolved in PagerDuty
2. Post in #platform-incidents: brief summary of what happened and fix
3. Open post-mortem doc (if SEV1/SEV2): https://wiki/post-mortems/template
4. Update this runbook if steps were wrong or missing

Last reviewed: 2026-07-31 | Owner: @alice
```

---

## The Monitoring Health Score — A Single Metric for Your Monitoring System

Track this monthly to measure if your monitoring is improving:

```
Monitoring Health Score = average of:

  1. Alert precision rate
     = actionable_alert_fires / total_alert_fires (last 30 days)
     Target: > 95%

  2. Detection speed
     = alerts that fired before user report / total incidents (last 30 days)
     Target: > 99% (almost never should users report before alerting detects)

  3. Dashboard coverage
     = services with Layer 1 dashboard / total production services
     Target: 100%

  4. Runbook coverage
     = alerts with valid runbook URL / total alerts
     Target: 100%

  5. Dashboard freshness
     = dashboards reviewed in last 6 months / total dashboards
     Target: 100%

  6. SLO coverage
     = services with defined SLO / total production services
     Target: 100%

Monthly score: average of the 6 metrics above
  Score 90–100: Excellent monitoring maturity
  Score 70–89:  Good foundation, specific gaps to address
  Score 50–69:  Significant gaps; reliability at risk
  Score < 50:   Monitoring not yet reliable; high incident risk
```
