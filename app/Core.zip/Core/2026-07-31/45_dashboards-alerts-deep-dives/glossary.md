# Glossary: Dashboards, Alerts & Monitoring — Deep Dives

Every term from all 5 parts explained for an SRE beginner.

---

## Part 1 — Four Golden Signals

**Four Golden Signals**
Google SRE's framework for the four things that matter most to monitor: Latency (how slow?), Traffic (how much?), Errors (how broken?), Saturation (how full?). Every alert in a mature system maps to at least one of these.

**Latency**
The time between a user sending a request and receiving a useful response. Measured in milliseconds. Must be tracked with percentiles (p99), never averages.

**Percentile (p50, p95, p99, p999)**
A statistical way to describe latency. p99 = 99% of requests were faster than this value. p99 catches the worst 1% of user experiences that averages completely hide.

**Average Latency**
The mean response time across all requests. Dangerous to use for alerting because a few very slow requests (tail latency) are hidden when divided across thousands of fast requests. Always use percentiles instead.

**Tail Latency**
The slowest requests in your distribution — the p99, p99.9 cases. These represent users who had the worst experience. Often caused by GC pauses, lock contention, slow DB queries on specific data.

**Traffic**
The volume of requests hitting your system per second. The denominator for all rate calculations. Without traffic context, error counts are meaningless. 100 errors at 100 req/sec = 100% failure; at 100,000 req/sec = 0.1%.

**RPS (Requests Per Second)**
The standard unit of traffic measurement. Calculated from Prometheus counters with `rate(http_requests_total[5m])`.

**Error Rate**
Errors per second divided by total requests per second. The primary symptom signal. Always use error RATE, never raw error COUNT.

**Errors (5xx)**
HTTP server error responses (500–599). Indicate YOUR service failed to handle a request correctly. Always alert on 5xx rates.

**Errors (4xx)**
HTTP client error responses (400–499). Usually indicate the client sent bad data. Generally don't alert on 4xx rates except for spikes in 401/403 (potential attack) or large 400 increases (API contract broken).

**Saturation**
How full a resource is — CPU%, memory%, disk%, thread pool size, connection pool usage. The only golden signal that PREDICTS future failure rather than reporting current failure.

**Saturation as Leading Indicator**
Saturation rises BEFORE errors spike. High CPU → request queuing → latency rises → requests time out → errors increase. Monitoring saturation gives you advance warning.

**`rate()` (Prometheus function)**
Converts a counter (ever-increasing) into a per-second rate. `rate(http_requests_total[5m])` = requests per second averaged over the last 5 minutes. Required for all counter metrics.

**`histogram_quantile()` (Prometheus function)**
Calculates a percentile from a histogram metric. `histogram_quantile(0.99, ...)` = p99 latency. Only works with histogram metric types.

**Counter (Prometheus metric type)**
A metric that only increases, like an odometer. Request counts, error counts. Use `rate()` to get per-second values.

**Gauge (Prometheus metric type)**
A metric that goes up and down, like a thermometer. CPU%, memory usage, current connection count. Use directly without `rate()`.

**Histogram (Prometheus metric type)**
A metric that records observations in buckets (e.g., requests bucketed by latency range). Required for `histogram_quantile()`. Request duration is almost always a histogram.

---

## Part 2 — Dashboard Design

**Three-Layer Dashboard Hierarchy**
Layer 1 = Overview (is everything OK? — 5-second answer). Layer 2 = Service (which component? — 1-minute answer). Layer 3 = Debug (why? — 5–15 minute analysis). Never mix layers.

**Stat Panel (Grafana)**
A large number panel showing the current value of a metric. Best for availability %, error rate, p99 latency as single prominent numbers. Supports threshold-based background coloring.

**Time Series Panel (Grafana)**
A line graph showing how a metric changes over time. The most common panel type. Set Y-axis min=0 to avoid misleading scale.

**Gauge Panel (Grafana)**
A dial/arc visualization showing a value as a fraction of its capacity. Best for saturation metrics (CPU%, disk%, connection pool%). Immediately reads like "how full is this?"

**Heatmap Panel (Grafana)**
A 2D color visualization showing the distribution of values over time. Rows = latency buckets, columns = time, color = request count. Shows how latency distribution evolves in a way a single p99 line cannot.

**Table Panel (Grafana)**
A grid showing multiple rows (e.g., endpoints) and columns (error rate, latency, RPS). Best for per-endpoint comparison. Sort by error rate descending to surface the worst endpoint first.

**Logs Panel (Grafana)**
Displays live log lines from Loki, synchronized with the dashboard time range. Pairs log content with metric spikes without switching to a separate tool.

**Dashboard Variable**
A dropdown filter at the top of a Grafana dashboard that modifies all panel queries simultaneously. Common: `$namespace`, `$pod`, `$interval`. Makes one dashboard serve all services/environments.

**`$interval` Variable**
A special Grafana variable for the time bucket used in rate() queries. At 1-hour view, use 1m. At 7-day view, use 1h. Prevents data point overload and improves performance.

**Annotation (Grafana)**
A vertical marker drawn across ALL time series panels simultaneously when an event happens. Most important: deployment markers. "Did the error spike correlate with a deploy?" is answered instantly.

**Deployment Annotation**
A Grafana annotation that shows when each deployment happened. Drawn by querying `changes(kube_deployment_status_observed_generation[5m]) > 0`. The single most useful annotation for incident triage.

**Information Hierarchy (Dashboard design)**
The principle that the most critical information appears first, largest, and most prominently. Less important detail is further down or on a separate page. Prevents 3am cognitive overload.

**24-Column Grid (Grafana)**
Grafana's layout system. Each panel has a width (1–24) and height. Full-width = width 24. Half-width = width 12. Four equal stats = width 6 each.

**`Y-axis min = 0` Rule**
Setting the Y-axis minimum to zero prevents Grafana from auto-scaling charts in a way that makes small changes look catastrophic. A 0.080%→0.085% error rate change should NOT look like a vertical spike.

---

## Part 3 — Alert Design

**Alert Fatigue**
When on-call engineers receive so many noisy or false-positive alerts that they start ignoring pages. The most dangerous monitoring failure mode — a real critical alert gets dismissed as noise.

**Actionable Alert**
An alert where the on-call engineer has a clear, specific action to take (rollback, restart, scale up). Non-actionable = engineer looked at it, did nothing, it resolved itself.

**`for` Duration**
The minimum time an alert condition must be continuously true before the alert fires. Prevents alert storms from 1-second transient spikes. `for: 2m` = condition must be true for 2 continuous minutes.

**PENDING state (Prometheus alert)**
The state between when an alert condition becomes true and when `for` duration completes. Alert is visible in `/alerts` as "pending" but has NOT fired and has NOT notified anyone.

**FIRING state (Prometheus alert)**
The state when `for` duration has been exceeded. Alert is sent to Alertmanager, which routes it to Slack/PagerDuty.

**INACTIVE state (Prometheus alert)**
The alert condition is false. No alert is firing.

**Multi-window Alerting**
Using two time windows simultaneously to confirm a burn rate is real. Example: 1h window AND 5m window must both exceed the threshold. The long window filters spikes; the short window confirms the problem is still happening.

**Inhibition Rule (Alertmanager)**
A rule that suppresses lower-severity alerts when a higher-severity alert is already firing for the same service. Prevents one incident from generating 10 Slack messages.

**`group_by` (Alertmanager)**
Which labels determine whether alerts are grouped together into a single notification. Related alerts for the same service/namespace are sent as one message instead of individually.

**`group_wait` (Alertmanager)**
How long Alertmanager waits before sending the first notification for a new group. Gives time to batch multiple related alerts into one message.

**`group_interval` (Alertmanager)**
How often Alertmanager sends updates for an ongoing alert group (new alerts added to the group, existing alerts resolved).

**`repeat_interval` (Alertmanager)**
How long to wait before re-notifying if an alert is still firing. Prevents constant spam for long-running issues. Typically 4h for warnings, 2h for critical.

**`continue: false` (Alertmanager route)**
Stops routing after the first matching route. Without it, an alert matching multiple routes would be sent to all of them. Use `continue: true` only when you intentionally want duplicate delivery.

**Runbook URL**
Every alert must have a `runbook_url` annotation linking to step-by-step response instructions. Without it, on-call spends precious incident minutes researching what the alert means.

**Alert Precision Rate**
The fraction of alert fires that required a human action. Target: > 95%. Measures how trustworthy your alerting system is.

**Symptom Alert**
An alert that fires when users are experiencing impact (error rate high, latency high, SLO burning). Should be the primary type of alert that pages on-call.

**Cause Alert**
An alert that fires on infrastructure signals (high CPU, full disk) before users feel it. Should mostly be warnings (Slack), not pages. Only page for causes if they are PROVEN to always precede user impact.

---

## Part 4 — Config as Code

**Config as Code**
Managing monitoring configurations (alert rules, dashboards, Alertmanager routing) as files in a git repository rather than clicking in the UI. Enables review, versioning, rollback, and reproducibility.

**PrometheusRule CRD**
A Kubernetes Custom Resource Definition for defining Prometheus alert and recording rules. The Prometheus Operator watches for these objects and automatically loads them into Prometheus — no manual reload needed.

**Prometheus Operator**
A Kubernetes controller that manages Prometheus and Alertmanager deployments. Watches for PrometheusRule, ServiceMonitor, and PodMonitor CRDs and configures Prometheus automatically.

**Recording Rule**
A Prometheus rule that pre-computes a complex query and stores the result as a new metric. Makes alert evaluation faster (evaluates a simple metric instead of a complex query on every check interval).

**`promtool`**
The official CLI tool for Prometheus. Used to: validate rule file syntax (`check rules`), run unit tests (`test rules`), and query a local TSDB.

**Alert Unit Test**
A test file (`.yaml`) that verifies alert rules fire correctly given simulated input metrics, without a live Prometheus or real traffic. Runs with `promtool test rules`. Catches regressions when alert rules change.

**Grafonnet**
A library for generating Grafana dashboard JSON using Jsonnet (a programming language). Enables reusable components: define a latency panel template once, use it across 50 dashboards.

**Jsonnet**
A data templating language that produces JSON. Used with Grafonnet to write Grafana dashboards as code. Supports variables, functions, and imports — making dashboards DRY (Don't Repeat Yourself).

**Grafana Provisioning**
A Grafana feature that loads dashboards and datasources from files on the filesystem (mounted as Kubernetes ConfigMaps). Dashboards loaded this way are read-only in the UI — changes must go through git.

**Dashboard Drift**
When a dashboard in Grafana's UI is different from the version in git. Usually caused by someone editing the UI directly. Detected by comparing the exported JSON against the git version.

**`disableDeletion: true` (Grafana provisioning)**
A provisioning option that prevents Grafana from deleting dashboards that were removed from the provisioning source. Protects against accidentally deleting dashboards during deployment.

**`overwrite: true` (Grafana API)**
A parameter in the dashboard import API that replaces an existing dashboard with the same UID instead of creating a duplicate. Required for idempotent CI/CD deployments.

**`editable: false` (Dashboard JSON)**
A dashboard property that prevents editing the dashboard through the Grafana UI. Forces all changes to go through git. Prevents configuration drift.

**Idempotent Deployment**
A deployment that can be run multiple times and always produces the same result. Running `kubectl apply` twice should be safe. Idempotent CI/CD is required for reliable config-as-code workflows.

---

## Part 5 — Maintenance

**Alert Quality Audit**
A monthly review of all alerts that fired to assess: was it actionable? was it a false positive? was it a duplicate? did the runbook help? Prevents alert fatigue from accumulating over time.

**Alert Noise Score**
The fraction of alert fires that were actionable. `actionable_fires / total_fires`. Target: > 95%. Tracks the overall quality of your alerting system over time.

**Dashboard Freshness**
Whether a dashboard has been reviewed in the last 6 months. Stale dashboards may have wrong metric names, outdated thresholds, or missing panels for new service features.

**Dashboard Hygiene**
A set of rules ensuring dashboards remain accurate, useful, and discoverable: owner labels, runbook links, version control, tested in staging before production.

**Monitoring Health Score**
A composite monthly score (0–100%) combining alert precision, detection speed, dashboard coverage, runbook coverage, dashboard freshness, and SLO coverage. Tracks monitoring maturity over time.

**Drift Detection**
A script or job that compares the live Grafana dashboard against the version in git and alerts if they differ. Catches unauthorized UI edits before the next deployment overwrites them.

**Runbook Review**
The process of updating a runbook after an incident reveals that the steps were wrong, incomplete, or took too long. Should happen within 48 hours of every SEV1/SEV2 incident.

**SLO Budget Review**
A monthly analysis of how much error budget was consumed, which incidents consumed the most, and whether SLO targets are still appropriate. Input to reliability prioritization.

**Operational Excellence Review**
Another name for the monthly reliability review: SLO status, incident trends, alert quality, toil, action item progress. The mechanism for continuous improvement.

**`amtool`**
CLI for interacting with Alertmanager: list active alerts, create silences, test configuration, and validate routing. Runs locally against a live Alertmanager instance.

**Silence (Alertmanager)**
A time-limited suppression rule that prevents specific alerts from notifying during a known maintenance window. Always has an expiry — it cannot be permanent.

**jq**
A command-line JSON processor. Used to extract fields from Grafana API responses, clean up exported dashboard JSON, and compare JSON structures. Essential for scripting monitoring workflows.
