# Part 3 Deep Dive — Alert Design: From Philosophy to Production Rules

---

## The Alert Design Problem

Most monitoring systems have too many alerts, too noisy, and too many false positives. The result is alert fatigue — on-call engineers learn to ignore pages because most don't require action.

**The number that matters: what % of your pages required a human to do something?**

```
Industry target:          > 95% of pages require human action
Typical failing teams:    < 60% of pages require human action
                          (40% are false alarms, self-healing, or noise)

If on-call ignores 40% of alerts:
  → They might also ignore the 1 real critical alert
  → Alert fatigue kills people (in on-call context, causes burnout + real misses)
```

The solution: ruthlessly prune alerts. Fewer, higher-quality alerts are always better than more lower-quality alerts.

---

## Symptom vs Cause Alerts — The Most Important Distinction

### The Core Rule

```
PAGE ON: Symptoms (user-visible impact)
  ✓ Error rate > 1%          (users are failing)
  ✓ p99 latency > 2 seconds  (users are experiencing slowness)
  ✓ SLO burn rate > 14.4x   (budget exhausting, users will be affected)

SLACK/INFO ONLY: Causes (infrastructure signals)
  → CPU > 90%                (may cause symptoms, but hasn't yet)
  → Memory > 85%             (warning, investigate before it becomes a symptom)
  → Disk > 80%               (early warning, not urgent)
  → DB connections > 80%     (heads-up, not a 3am page)
```

### Why This Distinction Is So Hard to Apply

```
Engineer's instinct: "CPU is at 90%! Something bad is about to happen!"
Reality: CPU at 90% means...
  - Maybe latency will rise soon (saturation → latency → errors)
  - Maybe it's normal for this workload at this traffic level
  - Maybe the HPA is about to scale and fix it
  - Maybe the job that causes high CPU just finished
  
  Right response: Slack warning → someone checks during business hours
  Wrong response: Page on-call at 3am for high CPU alone

The correct trigger for a page: error rate is ALREADY elevated
The correct trigger for investigation: saturation is TRENDING toward a threshold
```

---

## The `for` Duration — The Most Misconfigured Alert Parameter

### What `for` Does

The `for` parameter defines the minimum continuous time that an alert condition must be true before the alert fires. Without it, a 1-second spike would generate a page.

```yaml
# Without `for` (dangerous):
- alert: HighErrorRate
  expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.01
  # Fires the INSTANT the condition is true
  # A single slow 5-second window causes a page

# With `for` (correct):
- alert: HighErrorRate
  expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.01
  for: 2m
  # Only fires if condition is true for 2 continuous minutes
  # Transient spikes (30s, 1 min) are silently ignored
```

### Choosing the Right `for` Duration

```
Alert Severity → `for` Duration

Critical (page at 3am):
  Error rate: for: 2m
  Why 2m: Long enough to filter 30-second spikes; short enough to catch real issues
  
  p99 latency: for: 5m  
  Why 5m: Latency fluctuates more than error rate; need sustained elevation

Warning (Slack notification):
  CPU > 80%: for: 10m
  Why 10m: CPU spikes are normal during traffic bursts; sustained = structural problem
  
  Memory > 85%: for: 15m
  Why 15m: Memory grows slowly; brief high usage is normal (GC hasn't run yet)

  Disk > 80%: for: 30m
  Why 30m: Disk doesn't fluctuate; 30m confirms it's not a log rotation artifact

Info (ticket, no notification):
  SLO slow burn: for: 1h
  Why 1h: Slow drain needs time to confirm it's real before creating work
```

### The Alert State Machine

```
States:

INACTIVE: Expression is false. No alert.

PENDING: Expression became true. Waiting for `for` duration to complete.
  At this state: alert is NOT yet firing, no notification sent
  At this state: visible in Prometheus /alerts as "pending"

FIRING: Expression has been true for >= `for` duration.
  At this state: Alertmanager receives the alert and routes it

RESOLVED: Expression became false while alert was FIRING.
  At this state: Alertmanager sends "resolved" notification
  Note: If expression becomes false while PENDING, it just returns to INACTIVE (no notification)
```

This means: if you set `for: 2m` and a spike lasts 90 seconds, NOBODY is notified. The alert went INACTIVE → PENDING → INACTIVE. This is the desired behavior — transient spikes don't wake people up.

---

## Multi-Window Multi-Burn-Rate Alerting — Full Derivation

### Why Single-Window Alerting Fails

```
Problem A: Single short window (5m)
  Alert: rate(errors[5m]) / rate(total[5m]) > 0.001
  
  5-minute spike of 10% error rate:
    → Page fires immediately
    → On-call wakes up
    → Error rate already recovered
    → Wasted wake-up (spike lasted 5 min, already done)
  
  Result: HIGH false positive rate (alert fatigue)

Problem B: Single long window (1h)
  Alert: rate(errors[1h]) / rate(total[1h]) > 0.001
  
  30-minute outage at 50% error rate:
    → 1h window shows ~25% average error rate during the hour
    → Alert fires at 25% (halfway through the outage)
    → On-call responds 30 minutes into user impact
  
  Result: SLOW detection (latency in catching sustained problems)

Solution: BOTH windows must be true simultaneously
  Critical: 1h window AND 5m window both above threshold
  → Long window: confirms it's sustained (not a spike)
  → Short window: confirms it's still happening NOW (not already resolved)
```

### The Full Four-Window System

```
Window pair 1: CRITICAL (page immediately)
  Condition: error_rate_1h > (14.4 × budget_rate)
             AND error_rate_5m > (14.4 × budget_rate)
  for: 2m
  Meaning: Budget will exhaust in ~2 days; wake someone up NOW
  Notification: PagerDuty (phone call)

Window pair 2: HIGH (investigate urgently)
  Condition: error_rate_6h > (6 × budget_rate)
             AND error_rate_30m > (6 × budget_rate)
  for: 15m
  Meaning: Budget draining fast; investigate in next hour
  Notification: Slack alert channel

Window pair 3: MEDIUM (investigate this sprint)
  Condition: error_rate_24h > (3 × budget_rate)
             AND error_rate_6h > (3 × budget_rate)
  for: 1h
  Meaning: Budget consuming at 3x rate; this sprint's reliability work
  Notification: Jira ticket auto-created

Window pair 4: LOW (monitor)
  Condition: error_rate_3d > (1 × budget_rate)
  for: 6h
  Meaning: Budget consuming (not accumulating); watch trend
  Notification: Dashboard annotation only
```

---

## Complete Prometheus Alert Rule Examples

### Alert Rule 1: SLO Fast Burn (Production-Grade)

```yaml
- alert: SLOFastBurn_CriticalWindow
  expr: |
    # Both 1h and 5m windows exceed critical threshold
    (
      sum(rate(http_requests_total{job="my-service", status=~"5.."}[1h]))
      / sum(rate(http_requests_total{job="my-service"}[1h]))
    ) > (14.4 * 0.001)
    and
    (
      sum(rate(http_requests_total{job="my-service", status=~"5.."}[5m]))
      / sum(rate(http_requests_total{job="my-service"}[5m]))
    ) > (14.4 * 0.001)
    # Guard: only evaluate when we have enough traffic (avoid noise on cold start)
    and sum(rate(http_requests_total{job="my-service"}[5m])) > 5
  for: 2m
  labels:
    severity: critical
    team: platform
    service: my-service
    slo_type: availability
  annotations:
    summary: "[CRITICAL] my-service SLO burning fast ({{ $value | humanizePercentage }} error rate)"
    description: |
      Service error rate: {{ $value | humanizePercentage }}
      Critical threshold: {{ printf "%.4f" (mulf 14.4 0.001) | humanizePercentage }}
      Estimated time to budget exhaustion: {{ printf "%.1f" (divf 2.08 (divf $value 0.001)) }} days
      
      IMMEDIATE ACTION: Check for recent deployments. If yes → rollback.
    runbook_url: "https://wiki.internal/runbooks/my-service-slo-fast-burn"
    dashboard_url: "https://grafana.internal/d/my-service-overview"
```

### Alert Rule 2: High p99 Latency

```yaml
- alert: HighP99Latency
  expr: |
    histogram_quantile(0.99,
      sum(rate(http_request_duration_seconds_bucket{job="my-service"}[5m])) by (le)
    ) > 2.0
    # Guard: only fire if there's meaningful traffic (avoid noise)
    and sum(rate(http_requests_total{job="my-service"}[5m])) > 1
  for: 5m
  labels:
    severity: warning
    team: platform
  annotations:
    summary: "p99 latency {{ $value | humanizeDuration }} on my-service (threshold: 2s)"
    description: |
      99th percentile latency has exceeded 2 seconds for 5+ minutes.
      1% of users are experiencing > 2s response times.
      
      Check:
        1. Recent deployments (kubectl rollout history deploy/my-service)
        2. DB query latency (check DB dashboard link below)
        3. Downstream service latency (check dependency dashboard)
    dashboard_url: "https://grafana.internal/d/my-service-debug"
    runbook_url: "https://wiki.internal/runbooks/high-latency"
```

### Alert Rule 3: Endpoint-Level Error Spike

```yaml
- alert: EndpointErrorSpike
  expr: |
    (
      sum(rate(http_requests_total{job="my-service", status=~"5.."}[5m])) by (handler)
      / sum(rate(http_requests_total{job="my-service"}[5m])) by (handler)
    ) > 0.10
    # Only fire for endpoints with at least 2 req/sec (avoid 1/1 = 100% noise)
    and sum(rate(http_requests_total{job="my-service"}[5m])) by (handler) > 2
  for: 3m
  labels:
    severity: warning
    team: platform
  annotations:
    summary: "Endpoint {{ $labels.handler }} error rate {{ $value | humanizePercentage }}"
    description: |
      Specific endpoint has high error rate; overall service SLO may still be OK
      if this endpoint has low traffic. Check if this is user-impacting.
```

### Alert Rule 4: Disk Filling (Proactive)

```yaml
- alert: DiskWillFillIn4Hours
  expr: |
    predict_linear(node_filesystem_avail_bytes{
      mountpoint="/",
      fstype!~"tmpfs|overlay"
    }[6h], 4 * 3600) < 0
  for: 10m
  labels:
    severity: critical
    team: platform
  annotations:
    summary: "Disk on {{ $labels.instance }} ({{ $labels.mountpoint }}) predicted full in < 4h"
    description: |
      Linear regression of last 6h disk usage predicts exhaustion in < 4 hours.
      Current free: {{ $value | humanize1024 }}B
      
      Immediate actions:
        1. Check largest directories: du -sh /var/log/* /tmp/*
        2. Check for runaway log files
        3. Manually extend PVC if needed
    runbook_url: "https://wiki.internal/runbooks/disk-full"

- alert: DiskWillFillIn24Hours
  expr: |
    predict_linear(node_filesystem_avail_bytes{
      mountpoint="/",
      fstype!~"tmpfs|overlay"
    }[6h], 24 * 3600) < 0
    and
    predict_linear(node_filesystem_avail_bytes{
      mountpoint="/",
      fstype!~"tmpfs|overlay"
    }[6h], 4 * 3600) >= 0   # Don't double-fire with the 4h alert
  for: 30m
  labels:
    severity: warning
    team: platform
  annotations:
    summary: "Disk on {{ $labels.instance }} predicted full in < 24h"
```

### Alert Rule 5: Pod Crash Loop

```yaml
- alert: PodCrashLooping
  expr: |
    rate(kube_pod_container_status_restarts_total{
      namespace="production"
    }[15m]) > 0
  for: 5m
  labels:
    severity: critical
    team: platform
  annotations:
    summary: "Pod {{ $labels.pod }} in {{ $labels.namespace }} is crash-looping"
    description: |
      Container {{ $labels.container }} has restarted in the last 15 minutes.
      
      Check logs: kubectl logs {{ $labels.pod }} -n {{ $labels.namespace }} --previous
      Check events: kubectl describe pod {{ $labels.pod }} -n {{ $labels.namespace }}
    runbook_url: "https://wiki.internal/runbooks/pod-crash-loop"
```

---

## Alertmanager Configuration — Full Production Setup

### Routing Tree Logic

```
Every alert enters the routing tree at the TOP and follows the FIRST matching route.
If no route matches, the DEFAULT receiver handles it.

Priority: Most specific match wins (routes are evaluated top-to-bottom).
```

```yaml
# alertmanager/alertmanager.yaml
global:
  resolve_timeout: 5m

route:
  # Group related alerts: alerts for the same service + namespace go together
  group_by: ['alertname', 'service', 'namespace']
  
  # Batching:
  group_wait: 30s       # Wait 30s before sending first notification (batch related alerts)
  group_interval: 5m    # Add new alerts to existing group every 5m (avoid repeated messages)
  repeat_interval: 4h   # Re-notify if still firing after 4h (reminder)
  
  receiver: 'slack-platform-warnings'   # default receiver

  routes:
    # Route 1: Critical SEV1/2 → PagerDuty (highest priority, phone call)
    - matchers:
        - severity="critical"
      receiver: 'pagerduty-critical'
      group_wait: 10s          # Don't batch critical — send immediately
      continue: false           # Stop routing here; don't also send to Slack

    # Route 2: Security alerts → dedicated security channel
    - matchers:
        - alertname=~".*Security.*|.*Auth.*|.*Cert.*"
      receiver: 'slack-security'
      continue: true            # Also send to default channel

    # Route 3: Database team alerts
    - matchers:
        - team="database"
      receiver: 'slack-database-team'
      continue: false

    # Route 4: Warning severity → general warnings channel
    - matchers:
        - severity="warning"
      receiver: 'slack-platform-warnings'

    # Route 5: Info / low severity → info channel (no noise in warnings)
    - matchers:
        - severity="info"
      receiver: 'slack-info'

receivers:
  - name: 'pagerduty-critical'
    pagerduty_configs:
      - service_key: '<PAGERDUTY_INTEGRATION_KEY>'
        severity: critical
        description: |
          {{ range .Alerts }}
          {{ .Annotations.summary }}
          {{ .Annotations.description }}
          Runbook: {{ .Annotations.runbook_url }}
          {{ end }}
        details:
          firing: '{{ .Alerts.Firing | len }}'
          resolved: '{{ .Alerts.Resolved | len }}'

  - name: 'slack-platform-warnings'
    slack_configs:
      - api_url: 'https://hooks.slack.com/services/XXXXXXX'
        channel: '#platform-alerts-warning'
        icon_emoji: ':warning:'
        title: |
          [{{ .Status | toUpper }}{{ if eq .Status "firing" }} :fire:{{ end }}]
          {{ .GroupLabels.alertname }}
        text: |
          *Service:* {{ .GroupLabels.service }}
          *Namespace:* {{ .GroupLabels.namespace }}
          {{ range .Alerts }}
          *Alert:* {{ .Annotations.summary }}
          *Details:* {{ .Annotations.description }}
          <{{ .Annotations.runbook_url }}|Runbook> | <{{ .Annotations.dashboard_url }}|Dashboard>
          {{ end }}
        send_resolved: true

  - name: 'slack-info'
    slack_configs:
      - api_url: 'https://hooks.slack.com/services/XXXXXXX'
        channel: '#platform-alerts-info'
        send_resolved: false   # Don't send "resolved" for info alerts (noisy)

inhibit_rules:
  # If critical is firing for a service, suppress warning for the same service
  # Rationale: Critical already pages someone; warning just adds noise
  - source_matchers:
      - severity="critical"
    target_matchers:
      - severity="warning"
    equal: ['service', 'namespace']
    
  # If a pod is crash-looping, suppress all other alerts for that pod
  - source_matchers:
      - alertname="PodCrashLooping"
    target_matchers:
      - alertname!="PodCrashLooping"
    equal: ['pod', 'namespace']
```

### The Inhibition Rule — Why It Matters

```
Without inhibition rule:
  Payment service goes down at 14:32
  Fires simultaneously:
    ✓ HighErrorRate (critical → PagerDuty page)
    ✓ HighP99Latency (warning → Slack message)
    ✓ DependencyDown_payment (warning → Slack message)
    ✓ SLOFastBurn (critical → PagerDuty page)
    ✓ RequestRateDrop (warning → Slack message)
  
  Result: on-call gets paged TWICE and gets 3 Slack messages for ONE incident
  On-call spends 5 minutes acknowledging duplicates before investigating

With inhibition rule:
  HighErrorRate fires (critical) → inhibits all warnings for same service
  SLOFastBurn fires (critical) → also fires (different alertname, same service)
  Total pages: 2 (the two criticals) → appropriate
  Total Slack messages: 0 (inhibited)
```

---

## Alert Naming Conventions

Well-named alerts are understood instantly, even at 3am:

```
Format: [Component][Condition][Window?]
Examples:
  PaymentServiceHighErrorRate    ← component + condition
  MyServiceSLOFastBurn           ← component + SLO signal + burn speed
  DiskWillFillIn4Hours           ← resource + prediction + time
  PodCrashLooping                ← component + behavior
  DBConnectionPoolSaturation     ← component + signal

Anti-patterns:
  Alert1                         ← meaningless
  HighCPU                        ← which service? which pod?
  ServiceDown                    ← which service?
  LowDiskSpace                   ← "low" is subjective; say the threshold
  PlatformAlert                  ← completely useless name
```

### Runbook URL — Required for Every Alert

Every alert MUST have a `runbook_url` annotation. No exceptions.

Without a runbook URL:
```
On-call gets paged at 3am for "EndpointErrorSpike"
On-call asks: What is this alert? What do I check? What do I do?
Time wasted researching: 15 minutes
Total incident time: 35 minutes

With runbook URL:
On-call gets paged → clicks link → follows steps 1-5 → resolved in 12 minutes
```

Runbook minimum content:
```markdown
## Runbook: EndpointErrorSpike

### What is this?
One API endpoint has >10% error rate for 3+ minutes.

### Immediate check (first 2 minutes)
1. Which endpoint? → Check Grafana: [link]
2. Recent deploy? → kubectl rollout history deploy/$SERVICE -n production

### If recent deploy: Rollback
kubectl rollout undo deployment/$SERVICE -n production
kubectl rollout status deployment/$SERVICE -n production -w

### If no recent deploy: Investigate
1. Check logs: kubectl logs -n production deploy/$SERVICE --tail=100 | grep ERROR
2. Check dependency health: [link to dependency dashboard]
3. Check DB: [link to DB dashboard]

### Escalate after: 15 minutes unresolved → page $SERVICE owner
```
