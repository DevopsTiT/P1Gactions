# Part 1 Deep Dive — The Four Golden Signals: Foundation of Everything

---

## Why This Is "The Foundation"

Every monitoring system in the world, no matter how complex, is measuring some subset of four things. Google's SRE book formalized this as the **Four Golden Signals** after observing that production systems fail in predictably similar ways regardless of technology stack.

If you understand nothing else about monitoring, understand these four. Every alert, every dashboard panel, every post-mortem eventually traces back to one or more of them.

```
The four golden signals are NOT:
  ✗ CPU usage
  ✗ Memory usage
  ✗ Disk I/O
  ✗ Network throughput

Those are CAUSES. The four golden signals are SYMPTOMS — what users feel.

The rule: alert on symptoms (golden signals), investigate causes (CPU, memory, etc.)
```

---

## Signal 1: Latency — "How Long Does It Take?"

### What Latency Really Means

Latency is the time elapsed between a user sending a request and receiving a useful response. "Useful" is important — a fast error response is not useful latency.

```
Request lifecycle (what contributes to latency):
  T+0ms     User clicks button
  T+5ms     Browser sends HTTP request
  T+25ms    Request crosses network to your load balancer
  T+27ms    Load balancer selects a backend pod
  T+30ms    Request reaches your service
  T+75ms    Service queries the database
  T+135ms   Database returns results
  T+142ms   Service serializes response
  T+145ms   Response starts leaving your service
  T+165ms   Response reaches user's browser
  T+165ms   User sees result

Total latency from user perspective: 165ms
Your service's contribution: 115ms (T+30 to T+145)
Network: 50ms (beyond your control)
```

### The Two Categories of Latency You Must Track Separately

```
Successful request latency:
  Time to serve requests that return HTTP 2xx/3xx
  This is the "happy path" performance

Failed request latency:
  Time to serve requests that return HTTP 4xx/5xx
  CRITICAL: must be tracked separately

Why separately?
  Scenario: Your service is down. Load balancer returns 503 in 1ms.
  If you mix success + failure latency:
    Average latency drops (fast failures drag the average down)
    p99 drops
    Dashboard shows "performance improved" during an outage
    THIS IS WRONG.

  Correct approach:
    Track success latency separately (is the happy path fast?)
    Track failure latency separately (how fast are we failing?)
    Know that fast failures can mask real latency regressions
```

### Why Average Latency Is Dangerous

This is one of the most important concepts in monitoring. Memorize this:

```
Scenario: 1,000 requests per second, SLO is p99 < 500ms

Request latencies (simplified):
  990 requests: 50ms each (typical)
  9 requests:   200ms each (slightly slow)
  1 request:    8,000ms (8 seconds — user abandoned and is angry)

Average = ((990 × 50) + (9 × 200) + (1 × 8000)) / 1000
        = (49,500 + 1,800 + 8,000) / 1000
        = 59,300 / 1000
        = 59.3ms

Dashboard shows: "Average latency 59.3ms" — looks great!
Reality: 1 user per second waits 8 seconds.
         At 1,000 req/sec that's 86,400 terrible experiences per day.

p99 shows: 8,000ms — SLO BREACH. Alert fires. SRE investigates.

Average hid the problem. p99 found it.
```

### Percentile Reference — What Each One Tells You

```
p50 (median):
  50% of requests were faster than this value
  Represents the "typical" user experience
  Most users experience roughly this latency
  Example: p50 = 45ms → most users get ~45ms

p75:
  75% of requests were faster
  Rarely used; p95 is more common
  Good for "nearly everyone" checks

p90:
  90% of requests were faster
  "The good-enough majority"
  Only 10% had worse experience

p95:
  95% of requests were faster
  Commonly used in SLOs
  "Only 1 in 20 users had worse experience"
  Good balance of signal vs noise

p99:
  99% of requests were faster
  The standard SLO latency percentile
  "Only 1 in 100 users had worse experience"
  Catches real tail latency issues

p99.9 (p999):
  99.9% of requests were faster
  Used for very high-volume services
  At 100,000 req/sec: 100 users/sec have worse experience
  Important for financial, medical, safety-critical systems

Rule of thumb: Monitor p50 (typical), p95 (most users), p99 (worst common case)
```

### Latency SLO Examples

```
API service (user-facing, interactive):
  SLO: p99 < 500ms for /api/* endpoints
  Why 500ms? Research shows users perceive > 500ms as "slow"
  Why p99? Catching 1% = good coverage without over-engineering

Database queries (internal):
  SLO: p99 < 100ms for SELECT queries
  p99 < 500ms for complex JOINs
  Why different? Queries are called many times per user request; each query's
  latency multiplies when you have N calls per request

Background jobs (non-interactive):
  SLO: 95% of jobs complete in < 5 minutes
  Why p95 not p99? Background jobs have more variance; strict p99 causes
  unnecessary alerts for occasional slow jobs

Real-time streaming (WebSocket, financial data):
  SLO: p99 < 50ms end-to-end
  Why 50ms? Human perception threshold for "real-time" feeling
```

### PromQL for Latency — The Complete Reference

```promql
# ── BASIC PERCENTILE ──────────────────────────────────────────────────

# p99 latency (last 5 minutes, all endpoints)
histogram_quantile(0.99,
  sum(rate(http_request_duration_seconds_bucket[5m])) by (le)
)

# p99 per endpoint (find which endpoint is slow)
histogram_quantile(0.99,
  sum(rate(http_request_duration_seconds_bucket[5m])) by (le, handler)
)

# ── SUCCESS VS FAILURE LATENCY ─────────────────────────────────────────

# p99 latency for successful requests only
histogram_quantile(0.99,
  sum(rate(http_request_duration_seconds_bucket{status!~"5.."}[5m])) by (le)
)

# p99 latency for failed requests only
histogram_quantile(0.99,
  sum(rate(http_request_duration_seconds_bucket{status=~"5.."}[5m])) by (le)
)

# ── TREND DETECTION ─────────────────────────────────────────────────────

# Is p99 latency growing? (compare now vs 1 hour ago)
histogram_quantile(0.99,
  sum(rate(http_request_duration_seconds_bucket[5m])) by (le)
)
/
histogram_quantile(0.99,
  sum(rate(http_request_duration_seconds_bucket[5m] offset 1h)) by (le)
)
# Result > 1.5 = latency 50% worse than 1h ago → investigate

# ── SLI: % of requests within latency threshold (better for SLO math) ──

# What % of requests completed in < 500ms?
sum(rate(http_request_duration_seconds_bucket{le="0.5"}[5m]))
/
sum(rate(http_request_duration_seconds_count[5m]))
# Returns: 0.987 = 98.7% within 500ms
```

### Alert Rules for Latency

```yaml
groups:
  - name: latency.alerts
    rules:

      # p99 latency breach (symptom alert — page on-call)
      - alert: HighP99Latency
        expr: |
          histogram_quantile(0.99,
            sum(rate(http_request_duration_seconds_bucket{job="my-service"}[5m])) by (le)
          ) > 2.0
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "p99 latency {{ $value | humanizeDuration }} exceeds 2s threshold"
          description: "Service is slow for 1% of users. Check DB queries and downstream dependencies."
          runbook_url: "https://wiki/runbooks/high-latency"

      # p99 latency regression vs 1 hour ago (catches slow drift)
      - alert: LatencyRegressionVs1HAgo
        expr: |
          (
            histogram_quantile(0.99,
              sum(rate(http_request_duration_seconds_bucket[5m])) by (le)
            )
          ) / (
            histogram_quantile(0.99,
              sum(rate(http_request_duration_seconds_bucket[5m] offset 1h)) by (le)
            )
          ) > 2.0
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: "p99 latency is 2x worse than 1 hour ago — regression detected"
```

---

## Signal 2: Traffic — "How Much Demand?"

### What Traffic Measures and Why It Matters

Traffic measures the volume of requests hitting your system. Without traffic context, every other signal is meaningless:

```
Scenario A:
  Error count: 100 errors/min
  Traffic:     100 requests/min
  Error rate:  100% → CATASTROPHIC

Scenario B:
  Error count: 100 errors/min
  Traffic:     100,000 requests/min
  Error rate:  0.1% → Within SLO

Same error count. Completely different severity. Traffic is the denominator.

This is why you should ALMOST NEVER alert on raw error counts.
Always alert on error RATE (errors / total traffic).
```

### Traffic Metric Types by Service

```
HTTP / REST API:
  Primary: Requests per second (RPS)
  Metric: rate(http_requests_total[5m])

Message queue consumer:
  Primary: Messages processed per second
  Metric: rate(kafka_consumer_records_consumed_total[5m])

gRPC service:
  Primary: RPCs per second
  Metric: rate(grpc_server_handled_total[5m])

WebSocket / streaming:
  Primary: Active concurrent connections
  Metric: websocket_connections_active (gauge, not counter)

Batch job:
  Primary: Records processed per second
  Metric: rate(records_processed_total[5m])

Database:
  Primary: Queries per second (QPS)
  Metric: rate(pg_stat_statements_calls_total[5m])
```

### Using Traffic for Anomaly Detection

Traffic is the best signal for detecting attacks, viral events, and cascade failures:

```promql
# Sudden traffic spike (possible DDoS or viral event)
# Alert if current RPS is 3x higher than 1 hour ago
rate(http_requests_total[5m])
/
rate(http_requests_total[5m] offset 1h) > 3.0

# Traffic DROP (possible upstream dependency failure)
# Alert if current RPS is less than 30% of 1 hour ago
rate(http_requests_total[5m])
/
rate(http_requests_total[5m] offset 1h) < 0.3

# Seasonal comparison (is today abnormally high vs last week same time?)
rate(http_requests_total[5m])
/
rate(http_requests_total[5m] offset 7d) > 2.0
```

### Traffic Per Endpoint — Finding Hot Spots

```promql
# Top 10 endpoints by traffic (find your hot paths)
topk(10,
  sum(rate(http_requests_total[5m])) by (handler)
)

# Traffic distribution across pods (are some pods overloaded?)
sum(rate(http_requests_total[5m])) by (pod)
# If one pod has 10x more traffic than others → load balancer issue
```

---

## Signal 3: Errors — "How Broken Is It?"

### Error Taxonomy — Not All Errors Are Equal

```
Category 1: Internal Server Errors (5xx) — YOUR fault
  500 Internal Server Error → unhandled exception, bug
  502 Bad Gateway           → upstream service returned bad response
  503 Service Unavailable   → service overloaded or down
  504 Gateway Timeout       → upstream service too slow

Category 2: Client Errors (4xx) — USER fault (mostly)
  400 Bad Request           → client sent malformed data (expected; don't alert)
  401 Unauthorized          → client not authenticated
  403 Forbidden             → client not authorized
  404 Not Found             → resource doesn't exist
  429 Too Many Requests     → rate limited (can be your fault if limits are wrong)

Category 3: Application-level errors — Invisible to HTTP
  HTTP 200 returned, but:
    - Response body contains {"error": "payment_failed"}
    - Response body schema is wrong
    - Data returned is corrupted/incomplete
    - Silent data loss (write acknowledged, data never saved)

Alert strategy:
  5xx → always alert (these are YOUR failures)
  4xx → usually don't alert (except spikes in 401/403 which may indicate attack)
  App-level → alert via business metrics (orders failing, payments failing)
```

### The Error Rate Formula (With All Variants)

```promql
# ── BASIC ERROR RATE ──────────────────────────────────────────────────

# Overall 5xx error rate
sum(rate(http_requests_total{status=~"5.."}[5m]))
/ sum(rate(http_requests_total[5m]))

# Error rate per endpoint (find which endpoint is broken)
sum(rate(http_requests_total{status=~"5.."}[5m])) by (handler)
/ sum(rate(http_requests_total[5m])) by (handler)

# ── EXCLUDING EXPECTED ERRORS ─────────────────────────────────────────

# SLO error rate: exclude 4xx that are "expected" (bad client requests)
# Only count 5xx as SLO-impacting errors
sum(rate(http_requests_total{status=~"5.."}[5m]))
/ sum(rate(http_requests_total[5m]))

# ── AVAILABILITY (inverse of error rate) ─────────────────────────────

# Availability percentage
(1 - (
  sum(rate(http_requests_total{status=~"5.."}[5m]))
  / sum(rate(http_requests_total[5m]))
)) * 100

# ── ERROR BUDGET CONSUMPTION ──────────────────────────────────────────

# How many "error credits" consumed this hour? (for 99.9% SLO)
sum(increase(http_requests_total{status=~"5.."}[1h]))
- (sum(increase(http_requests_total[1h])) * 0.001)
# Positive = over budget; negative = still within budget this hour
```

### Error Alert Design — The Complete Pattern

The key insight: **never alert on raw error counts, always on error rate**.

```yaml
groups:
  - name: error.alerts
    rules:

      # ── SYMPTOM ALERTS (page on-call) ────────────────────────────────

      # High error rate, any threshold (fast SLO burn)
      - alert: HighErrorRate
        expr: |
          (
            sum(rate(http_requests_total{job="my-service", status=~"5.."}[5m]))
            / sum(rate(http_requests_total{job="my-service"}[5m]))
          ) > 0.01   # > 1% error rate
        for: 2m
        labels:
          severity: critical
        annotations:
          summary: "Error rate {{ $value | humanizePercentage }} on my-service"
          description: |
            Current 5m error rate exceeds 1% SLO threshold.
            Check logs: kubectl logs -n production deploy/my-service --tail=100 | grep ERROR
          runbook_url: "https://wiki/runbooks/high-error-rate"

      # Per-endpoint error spike (catches partial failures)
      - alert: EndpointErrorSpike
        expr: |
          (
            sum(rate(http_requests_total{job="my-service", status=~"5.."}[5m])) by (handler)
            / sum(rate(http_requests_total{job="my-service"}[5m])) by (handler)
          ) > 0.05   # > 5% error rate on any single endpoint
          and
          sum(rate(http_requests_total{job="my-service"}[5m])) by (handler) > 1
          # Only fire if endpoint receives at least 1 req/sec (avoid noise on low-traffic endpoints)
        for: 3m
        labels:
          severity: warning
        annotations:
          summary: "Endpoint {{ $labels.handler }} error rate {{ $value | humanizePercentage }}"

      # ── TRAFFIC DROP (often means upstream failure) ───────────────────

      - alert: TrafficDrop50Percent
        expr: |
          (
            sum(rate(http_requests_total{job="my-service"}[5m]))
            / sum(rate(http_requests_total{job="my-service"}[5m] offset 1h))
          ) < 0.5
          and sum(rate(http_requests_total{job="my-service"}[5m])) > 1
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "Traffic to my-service dropped 50%+ vs 1 hour ago"
          description: "This often indicates upstream dependency failure or DNS issue"
```

---

## Signal 4: Saturation — "How Full Is It?"

### Why Saturation Is a LEADING Indicator

Saturation is the only one of the four golden signals that predicts future failure rather than reporting current failure. This makes it uniquely powerful for proactive monitoring.

```
The saturation-to-failure chain:

High saturation (90% CPU) → requests queue up → latency rises →
queue fills → requests start failing → error rate rises → outage

Timeline:
  T-10min: CPU reaches 90% (saturation alert fires if configured)
  T-5min:  p99 latency doubles (latency alert fires)
  T-0min:  Error rate crosses threshold (error alert fires, users hurt)

With saturation monitoring: 10-minute warning before user impact
Without saturation monitoring: only detect at T-0min (users already hurt)
```

### What to Measure for Saturation — Resource by Resource

```
CPU:
  Metric: rate(container_cpu_usage_seconds_total[5m]) /
          container_spec_cpu_quota * container_spec_cpu_period
  Threshold: Alert at 80% sustained; critical at 90%
  Warning sign: Also watch CPU throttling (more accurate than usage %)

Memory:
  Metric: container_memory_working_set_bytes /
          container_spec_memory_limit_bytes
  Threshold: Alert at 85%; OOMKill risk at 95%
  Working set = actual used memory (excluding evictable OS cache)

Disk:
  Metric: 1 - (node_filesystem_avail_bytes / node_filesystem_size_bytes)
  Threshold: Alert at 80%; critical at 90%
  Better: Use predict_linear to alert before hitting threshold

Database connections:
  Metric: pg_stat_activity_count / pg_settings_max_connections
  Threshold: Alert at 80%; critical at 90%
  Why critical: At 100%, new connections are rejected entirely

Thread pool:
  Metric: jvm_threads_states_threads{state="runnable"} /
          hikaricp_connections_max  (for connection pool)
  Threshold: Alert when active threads > 80% of pool size
  Impact: Thread pool exhaustion → requests queue → latency → errors

Queue depth:
  Metric: kafka_consumer_group_lag (for Kafka)
  Threshold: Service-dependent; alert when lag > N minutes of processing time
  Why: Growing lag means consumer can't keep up; eventual data loss or delay

Network:
  Metric: rate(node_network_receive_bytes_total[5m]) * 8 / 1e9  (Gbps)
  Compare against NIC capacity (e.g., 10Gbps)
  Threshold: Alert at 70% of NIC capacity
```

### The Saturation Dashboard Row

Every service dashboard should have a "Saturation" row with these panels:

```
Panel 1: CPU usage % of limit (time series, 0–100%)
  Alert zone: > 80% (yellow), > 90% (red)
  
Panel 2: Memory % of limit (time series, 0–100%)
  Alert zone: > 85% (yellow), > 95% (red)
  
Panel 3: DB connection pool % (time series, 0–100%)
  Alert zone: > 80% (yellow)
  
Panel 4: Request queue depth (time series)
  Specific to service type
  
Panel 5: Disk usage % (time series, 0–100%)
  Alert zone: > 80% (yellow), > 90% (red)
```

### PromQL for Saturation Signals

```promql
# ── CPU ──────────────────────────────────────────────────────────────

# CPU usage as % of limit (per pod)
(
  sum(rate(container_cpu_usage_seconds_total{container!=""}[5m])) by (pod, namespace)
  /
  sum(container_spec_cpu_quota{container!=""} / container_spec_cpu_period{container!=""}) by (pod, namespace)
) * 100

# CPU throttling ratio (more accurate signal)
rate(container_cpu_throttled_seconds_total{container!=""}[5m])
/ rate(container_cpu_usage_seconds_total{container!=""}[5m])
# > 0.25 = 25% of time throttled → CPU limit is too low

# ── MEMORY ──────────────────────────────────────────────────────────

# Memory % of limit (per pod)
(
  container_memory_working_set_bytes{container!=""}
  / container_spec_memory_limit_bytes{container!=""}
) * 100

# ── DISK ─────────────────────────────────────────────────────────────

# Disk used % per mount point
(1 - (node_filesystem_avail_bytes / node_filesystem_size_bytes)) * 100

# Predict disk full in < 4 hours
predict_linear(node_filesystem_avail_bytes[6h], 4 * 3600) < 0

# ── DATABASE CONNECTIONS ─────────────────────────────────────────────

# PostgreSQL connection saturation
(pg_stat_activity_count / pg_settings_max_connections) * 100

# HikariCP connection pool saturation (Java)
(hikaricp_connections_active / hikaricp_connections_max) * 100

# ── QUEUE / KAFKA ────────────────────────────────────────────────────

# Kafka consumer lag (messages behind)
kafka_consumer_group_lag{group="my-service-consumer"}

# Lag in time units (divide by consume rate to get "minutes behind")
kafka_consumer_group_lag{group="my-service-consumer"}
/ rate(kafka_consumer_records_consumed_total{group="my-service-consumer"}[5m])
# Result in seconds; > 300 = 5 minutes behind = alert
```

---

## How the Four Signals Work Together on a Single Dashboard

The canonical dashboard layout puts all four signals on one page:

```
ROW 1 — Traffic (the denominator for everything)
  [Panel] Requests per second (time series, last 6h)
  [Panel] Requests per second by endpoint (stacked area)

ROW 2 — Errors (the primary symptom signal)
  [Panel] Error rate % (time series — big, prominent, red when high)
  [Panel] Error count by type (5xx broken down)

ROW 3 — Latency (the secondary symptom signal)
  [Panel] p50 / p95 / p99 latency (three lines on one time series)
  [Panel] Latency heatmap (shows full distribution, not just percentiles)

ROW 4 — Saturation (the leading / cause signal)
  [Panel] CPU usage % of limit
  [Panel] Memory % of limit
  [Panel] DB connections %
  [Panel] Disk usage %

FOOTER ROW — Context
  [Panel] Recent deployments (annotations on the timeline)
  [Panel] Alerts currently firing for this service
```

### Reading the Dashboard During an Incident

```
Step 1: Look at TRAFFIC
  Is traffic normal, spiked, or dropped?
  If dropped → upstream failure, not your service's fault
  If spiked → capacity issue or attack

Step 2: Look at ERRORS
  What error rate? 1%? 50%? 100%?
  Which endpoints? All or specific one?
  Started gradually or suddenly?

Step 3: Look at LATENCY
  Did p99 spike before or after errors?
  Latency spike before errors → saturation cascaded into errors
  Errors with normal latency → logic error, not load problem

Step 4: Look at SATURATION
  If saturation is high → capacity or resource exhaustion is the cause
  If saturation is normal → logic bug, config change, or dependency failure

Step 5: Check deployment annotation line
  Any deploy right before the symptoms started?
  YES → rollback first, investigate second
```
