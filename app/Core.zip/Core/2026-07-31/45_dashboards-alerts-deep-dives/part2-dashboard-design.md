# Part 2 Deep Dive — Dashboard Design Principles

---

## Why Dashboard Design Is an Engineering Discipline

A badly designed dashboard causes incidents to last longer. When an on-call engineer opens Grafana at 3am, they need to understand the system state in under 10 seconds. Every second spent interpreting a confusing layout is a second of user impact.

Good dashboard design is about one thing: **information hierarchy**. The most critical information appears first, largest, and most prominently. Investigation detail is one click away, not on the same page.

---

## The Three-Layer Hierarchy — The Core Mental Model

Every service needs exactly three dashboards, not one. They serve different audiences and different questions:

```
LAYER 1 — Overview / Executive Dashboard
  Audience:    On-call SRE (first thing they open), management, anyone
  Question:    "Is the system OK right now?"
  Time to answer: < 5 seconds
  Content:     SLO status, error rate, p99 latency, request rate (big numbers)
  No detail:   No per-pod breakdown, no infrastructure metrics
  Link target: When something looks bad, links to Layer 2

LAYER 2 — Service / Team Dashboard
  Audience:    On-call SRE actively investigating
  Question:    "Which component is degraded?"
  Time to answer: < 60 seconds
  Content:     Per-endpoint breakdown, per-pod health, dependency status
  Link target: Specific broken component → Layer 3

LAYER 3 — Debug / Investigation Dashboard
  Audience:    The engineer who owns this service
  Question:    "Why is this specific component failing?"
  Time to answer: 5–15 minutes of analysis
  Content:     JVM heap, GC pauses, DB query stats, thread pool, raw logs
  Link target: Traces in Tempo/Jaeger, logs in Loki/Kibana
```

### Why Mixing Layers Creates Problems

```
Common mistake: One giant dashboard with everything on it

What happens at 3am:
  SRE opens dashboard
  Sees 50 panels
  Spends 3 minutes scrolling to find the relevant signal
  Makes a wrong first hypothesis because the critical panel is buried
  Wastes 10 minutes on the wrong investigation path

Correct approach:
  Layer 1 shows the problem in 5 seconds (e.g., "checkout endpoint error rate 35%")
  Link → Layer 2 shows it's the payment service call (dependency view)
  Link → Layer 3 shows the DB connection pool is at 100% (root cause)
  
  Total time to root cause: 3 minutes instead of 20
```

---

## Layer 1 — Overview Dashboard: Design in Detail

### The Big Stat Row (Top of Every Overview Dashboard)

The first row of a Layer 1 dashboard must answer "Is everything OK?" without reading a single graph. Use large Stat panels with threshold-based coloring:

```
Panel 1: Current Availability
  Query: (1 - sum(rate(http_requests_total{status=~"5.."}[5m]))
              / sum(rate(http_requests_total[5m]))) * 100
  Display: "99.94%"
  Green if > 99.9%, Yellow if 99.0–99.9%, Red if < 99.0%
  Size: Large (spans full width of 1/4 of the row)

Panel 2: Error Rate
  Query: sum(rate(http_requests_total{status=~"5.."}[5m]))
         / sum(rate(http_requests_total[5m])) * 100
  Display: "0.06%"
  Green if < 0.1%, Yellow if 0.1–1%, Red if > 1%

Panel 3: p99 Latency
  Query: histogram_quantile(0.99,
           sum(rate(http_request_duration_seconds_bucket[5m])) by (le)) * 1000
  Display: "342 ms"
  Green if < 500ms, Yellow if 500ms–2s, Red if > 2s

Panel 4: SLO Burn Rate (the most important stat)
  Query: (sum(rate(http_requests_total{status=~"5.."}[1h]))
          / sum(rate(http_requests_total[1h]))) / 0.001
  Display: "1.2x" (burn rate)
  Green if < 3x, Yellow if 3–6x, Orange if 6–14x, Red if > 14x
```

### Why SLO Burn Rate Is the Most Important Top Stat

```
Raw error rate "0.06%" tells you the current state.
SLO burn rate "1.2x" tells you what it MEANS.

Example A:
  Error rate: 0.06%
  Burn rate: 0.6x → below 1x → budget ACCUMULATING, not consuming
  Response: Everything is fine. No action needed.

Example B:
  Error rate: 0.14%
  Burn rate: 1.4x → above 1x → budget slowly consuming
  Response: Monitor. Not urgent. Fix within the sprint.

Example C:
  Error rate: 1.5%
  Burn rate: 15x → critical threshold exceeded → budget exhausted in ~2 days
  Response: Page on-call. Fix NOW.

The raw error rate in examples B and C are both "above 0.1%" —
the burn rate tells you the urgency difference precisely.
```

### The Second Row: Time Series (The Context Row)

Below the stat row, show the last 6 hours of key signals as time series:

```
Panel 1 (wide): Error rate over time
  - Shows the shape of the problem (sudden spike? gradual rise? recurring pattern?)
  - Add threshold line at SLO target (0.1%) for visual reference
  - Highlight area above threshold in red

Panel 2 (wide): p50 / p95 / p99 latency over time
  - Three lines on the same chart
  - Color: p50=green, p95=yellow, p99=red
  - When p99 shoots up but p50 stays flat → tail latency issue (specific slow queries/calls)
  - When all three rise together → general slowdown (CPU, DB, or load-related)

Annotation: Show deployment markers as vertical lines
  query: changes(kube_deployment_status_observed_generation{deployment="my-service"}[5m]) > 0
  This draws a vertical line every time a deployment happens
  Instantly correlates "problem started when" with "deployment happened when"
```

---

## Layer 2 — Service Dashboard: Design in Detail

### Per-Endpoint Breakdown

The most important feature of Layer 2: showing WHICH endpoint is having the problem.

```promql
# Error rate per endpoint (sorted to show worst first)
# Use in a table panel with sort by error rate descending
sum(rate(http_requests_total{status=~"5.."}[5m])) by (handler)
/ sum(rate(http_requests_total[5m])) by (handler)

# p99 latency per endpoint
histogram_quantile(0.99,
  sum(rate(http_request_duration_seconds_bucket[5m])) by (le, handler)
)

# Traffic per endpoint (shows if high-traffic endpoint has problem)
sum(rate(http_requests_total[5m])) by (handler)
```

Table panel configuration:
```
Column 1: handler (endpoint path)
Column 2: Error Rate (color: green < 0.1%, yellow 0.1–1%, red > 1%)
Column 3: p99 Latency (color: green < 500ms, yellow 500ms–2s, red > 2s)
Column 4: RPS (traffic context)
Sort: by Error Rate descending

This table immediately shows you: "POST /api/v1/checkout has 35% error rate"
```

### Per-Pod Health

Shows whether the problem is ONE pod (hardware/node issue) or ALL pods (code issue):

```promql
# Error rate per pod
sum(rate(http_requests_total{status=~"5.."}[5m])) by (pod)
/ sum(rate(http_requests_total[5m])) by (pod)

# CPU per pod
sum(rate(container_cpu_usage_seconds_total{container!=""}[5m])) by (pod)
/ sum(container_spec_cpu_quota / container_spec_cpu_period) by (pod)

# Memory per pod
container_memory_working_set_bytes{container!=""}
/ container_spec_memory_limit_bytes{container!=""}
```

Reading the per-pod view:
```
Scenario A: One pod has 100% error rate, all others 0%
  → That specific pod has a problem (node failure, OOMKill, corrupt state)
  → Fix: Delete that pod (kubectl delete pod <name>), let it reschedule
  → Do NOT rollback (code is fine)

Scenario B: All pods have the same elevated error rate
  → Code or configuration problem affecting all instances
  → Fix: Rollback the last deployment or fix the config

Scenario C: Error rate gradually climbing on all pods
  → Resource exhaustion (memory leak, disk filling, connection pool draining)
  → Fix: Depends on which resource (VPA, scale up, code fix)
```

### Dependency Health Row

Every Layer 2 dashboard must show the health of dependencies that this service calls:

```promql
# DB connection success rate
pg_up{job="my-service-db"}  # 1 = up, 0 = down

# Downstream service latency (outbound calls)
histogram_quantile(0.99,
  sum(rate(http_client_request_duration_seconds_bucket{target_service="payment-api"}[5m])) by (le)
)

# Downstream service error rate (outbound calls)
sum(rate(http_client_requests_total{target_service="payment-api", status=~"5.."}[5m]))
/ sum(rate(http_client_requests_total{target_service="payment-api"}[5m]))

# Cache hit rate (Redis)
rate(redis_hits_total[5m])
/ (rate(redis_hits_total[5m]) + rate(redis_misses_total[5m]))
```

When dependency health panels show: "payment-api error rate 100%"
The answer is clear: YOUR service is fine. PAYMENT API is down. Escalate to payment team.

---

## Panel Types — When to Use Each (Deep Reference)

### Time Series Panel

**When to use:** Showing how a value changes over time.
**Best for:** Error rate, latency, RPS, CPU usage, memory usage.
**Not for:** Showing current value; comparing categories that don't change over time.

```
Configuration best practices:
  - Set "Fill opacity" to 10–20% to make the area under the line visible
  - Use "Gradient fill" for a polished look
  - Set thresholds with colors (green below 0.1%, red above 1%)
  - Always label your Y-axis units (ms, %, req/s)
  - Set Y-axis min to 0 (never let Grafana auto-scale to hide small changes)

Why Y-axis min = 0 matters:
  With auto-scale:
    Error rate: 0.080% → 0.085% looks like a MASSIVE spike
    Y-axis shows 0.080 to 0.086 → the line goes from bottom to top
    On-call panics, wakes manager
    
  With min = 0:
    Same data shown on 0–100% scale
    0.080% → 0.085% is visually flat
    On-call sees: "This is tiny, not worth waking up about"
```

### Stat Panel (Big Number)

**When to use:** Current value of a single important metric.
**Best for:** SLO status, current availability %, current error rate, SLO burn rate.
**Not for:** Showing trends; comparing multiple values.

```
Configuration best practices:
  - Use "Last (not null)" value reduction (not Average)
  - Set threshold colors (green/yellow/red based on SLO thresholds)
  - Use large font size (36+) for the number
  - Include a sparkline (small time series below the big number)
  - Use value mappings: 1.0 = "HEALTHY", 0 = "DOWN"
```

### Gauge Panel

**When to use:** Showing saturation as a visual fraction of capacity.
**Best for:** CPU%, memory%, disk%, DB connection pool%.
**Not for:** Time-based trends; values that can exceed 100%.

```
Configuration:
  Min: 0, Max: 100
  Thresholds:
    0–60%: Green
    60–80%: Yellow (watch zone)
    80–95%: Orange (warning)
    95–100%: Red (critical)

Visual reading: Like a fuel gauge — you immediately see "tank is almost empty"
```

### Heatmap Panel

**When to use:** Visualizing the DISTRIBUTION of latency over time.
**Best for:** Latency (shows all percentiles simultaneously, not just p99).
**Not for:** Error rates; simple yes/no metrics.

```
What a heatmap shows that time series can't:
  Time series p99 = 850ms, p50 = 45ms
  This tells you: most are fast, a few are slow
  But: HOW MANY are slow? Is it getting worse over time? What's the shape?

  Heatmap shows: color intensity = number of requests at that latency
    Bright green at 40–60ms = most requests (dense cluster)
    Faint yellow at 800–900ms = small tail (sparse)
    Faint line at 800ms growing over time = tail getting worse

A heatmap tells the story of your latency distribution's evolution over time.
Use it alongside a p99 time series for the full picture.
```

### Table Panel

**When to use:** Comparing multiple dimensions (endpoint, pod, region) at once.
**Best for:** Top N endpoints by error rate; top N slow queries; pod comparison.
**Not for:** Time-based trends; single metrics.

```
Table panel configuration:
  - Sort by the most important column by default (usually error rate, descending)
  - Apply color thresholds to cells (red = bad, green = good)
  - Link cells to deeper dashboards (click on endpoint → open Layer 3 for that endpoint)
  - Show only the top N rows (avoid infinite scroll)
```

### Logs Panel

**When to use:** Showing live log tail correlated with metrics time range.
**Best for:** Pairing error rate spike with the actual error messages.
**Not for:** Replacing metrics dashboards.

```
Configuration:
  Data source: Loki
  Query: {namespace="production", app="my-service"} |= "ERROR"
  Time range: Synced to dashboard time range (so logs match the metric spike)
  
This panel answers: "What does the error look like in the logs?"
without needing to context-switch to a separate Loki/Kibana tab.
```

---

## Dashboard Variables — Making One Dashboard Serve All Services

Dashboard variables are dropdown filters at the top of the dashboard that modify every panel's query simultaneously.

### The Standard Variable Set

```
Variable 1: $namespace
  Type: Query
  Query: label_values(kube_pod_info, namespace)
  Multi-value: true (select multiple namespaces at once)
  Purpose: Switch between production, staging, dev

Variable 2: $deployment
  Type: Query
  Query: label_values(kube_deployment_labels{namespace="$namespace"}, deployment)
  Depends on: $namespace
  Purpose: Filter to specific service/deployment

Variable 3: $pod
  Type: Query
  Query: label_values(kube_pod_info{namespace="$namespace", created_by_name="$deployment"}, pod)
  Depends on: $namespace, $deployment
  Purpose: Drill into a specific pod

Variable 4: $interval
  Type: Interval
  Values: 1m, 5m, 15m, 1h
  Purpose: Dynamic rate() window
  Use in queries: rate(metric[$interval]) instead of rate(metric[5m])
  Why: At 1-hour time range, use $interval=1m for detail
        At 7-day time range, use $interval=1h to avoid data point overload
```

### Using Variables in Queries

```promql
# Without variables (hardcoded — only works for one service):
rate(http_requests_total{namespace="production", pod="my-service-abc"}[5m])

# With variables (works for any service the user selects):
rate(http_requests_total{namespace="$namespace", pod="$pod"}[$interval])

# With multi-value variable (handles multiple namespaces):
rate(http_requests_total{namespace=~"$namespace"}[$interval])
# Note: =~ (regex match) is required for multi-value variables
```

---

## Dashboard Layout Rules — The Grid

Grafana uses a 24-column grid. Every panel is placed with (x, y, width, height) coordinates.

### Standard Layout Dimensions

```
Full-width panel (stats row):    width=6, height=4 (4 panels = 24 columns total)
Half-width time series:          width=12, height=8
Full-width time series:          width=24, height=8
Small gauge:                     width=4, height=6 (6 fit in a row)
Table panel:                     width=24, height=10

Screen real estate priorities:
  Most important:  Top-left quadrant (eye goes here first)
  Second:          Top-right quadrant
  Third:           Middle section
  Last:            Bottom (debug detail, rarely needed at a glance)
```

### The Standard Layout Template

```
y=0  [Stat: Availability][Stat: Error Rate][Stat: p99 Latency][Stat: SLO Burn]
     w=6,h=4              w=6,h=4           w=6,h=4             w=6,h=4

y=4  [Time Series: Error Rate over time, last 6h                              ]
     w=24, h=8

y=12 [Time Series: p50/p95/p99 Latency  ] [Time Series: RPS by endpoint       ]
     w=12, h=8                              w=12, h=8

y=20 [Gauge: CPU%] [Gauge: Memory%] [Gauge: Disk%] [Gauge: DB Conn%] [Gauge: Queue]
     w=4,h=6        w=4,h=6          w=4,h=6         w=4,h=6            w=4,h=6

y=26 [Table: Per-endpoint error rate + latency + RPS                          ]
     w=24, h=10

y=36 [Logs: Recent ERROR logs correlated with time range                      ]
     w=24, h=8

(Layer 3 content goes below y=44 — or in a separate dashboard)
```

---

## Annotations — The Most Underused Dashboard Feature

Annotations add vertical markers to ALL time series panels simultaneously, showing when external events happened.

### The Most Important Annotation: Deployments

```
# Add this annotation to every service dashboard
Name: "Deployments"
Data source: Prometheus
Query: changes(kube_deployment_status_observed_generation{deployment="$deployment"}[5m]) > 0
Color: Orange
Show in: All panels

Effect: Every time a deployment happens, an orange vertical line appears
        across ALL time series panels in the dashboard.

At 3am during an incident:
  You see error rate spike at 14:32
  Orange deployment line at 14:20
  Connection is INSTANT: "deploy caused this, rollback now"
  Without annotation: manually correlate timestamps, takes 5 minutes
```

### Other Valuable Annotations

```
# HPA scaling events (pod count changed)
changes(kube_deployment_status_replicas{deployment="$deployment"}[5m]) != 0
Color: Blue

# Alert firing periods (shade the time when alerts were active)
ALERTS{alertname=~".*my-service.*", alertstate="firing"}
Color: Red, fill the area

# Kubernetes events (node problems, etc.)
# Use Loki annotation with query: {job="kubernetes-events"} |= "my-service"
Color: Yellow
```
