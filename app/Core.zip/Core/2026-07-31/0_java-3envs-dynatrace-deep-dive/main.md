# Every File in 38_java-3envs-dynatrace — Deep Dive

> **How to read this:** Each section covers one file (or related group of files). For each: what it IS, what every line DOES, and why it EXISTS — what specifically breaks without it.

---

## Project Map (Who Uses What, and in What Order)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  ONCE PER ENVIRONMENT (manual bootstrap):                                   │
│                                                                             │
│  terraform/environments/<env>/main.tf                                       │
│    → creates EKS cluster, VPC, IAM roles, ECR repos                        │
│    → calls module "dynatrace" → creates ALL Dynatrace config in DT tenant  │
│                                                                             │
│  kubectl apply -f gitops/<env>/bootstrap/root-app-<env>.yaml               │
│    → ArgoCD discovers and manages everything under gitops/<env>/            │
└─────────────────────────────────────────────────────────────────────────────┘
                           │
                           ▼ ArgoCD sync waves (automated):
                     
  wave -1:  gitops/<env>/namespaces/namespaces.yaml
              → creates payment-ns, order-ns, notification-ns, dynatrace, external-secrets
              → labels (team=, environment=) on each namespace
              → Dynatrace reads these labels → auto-tags every pod → management zones work
              
  wave  1:  gitops/<env>/networking/aws-load-balancer-controller.yaml
            gitops/<env>/networking/external-dns.yaml
              → ALB controller: Ingress objects now create real ALBs
              → ExternalDNS: Ingress objects now create Route53 DNS records
              
  wave  2:  gitops/<env>/secrets/cluster-secret-store.yaml
              → installs ESO + ClusterSecretStore
              → ESO can now read from AWS Secrets Manager using IRSA
              
  wave  3:  gitops/<env>/monitoring/dynatrace/dynatrace-operator.yaml
              → installs DT Operator + ExternalSecret (pulls DT tokens) + DynaKube
              → OneAgent DaemonSet starts on EVERY node
              → ActiveGate pod starts → routes metrics/traces to DT tenant
              
  wave  8:  gitops/<env>/app/payment-service/payment-service.yaml
            gitops/<env>/app/order-service/order-service.yaml
            gitops/<env>/app/notification-service/notification-service.yaml
              → deploys each service using Helm chart from charts/<service>/
              → each pod has team= and environment= labels → DT auto-tags them
              
                           │
                           ▼ Ongoing (event-driven):
                           
  .github/workflows/terraform-dynatrace-<env>.yaml
    → PR: terraform plan → comment on PR
    → merge: terraform apply → updates DT tenant config
    → triggers when EITHER environment config OR shared module changes

  .github/workflows/<service>-ci.yaml
    → test → build → dev deploy → smoke → staging → k6 → prod (manual approval)
    → each step: commits new image tag to gitops/<env>/app/<service>/
    → ArgoCD detects git commit → rolling update in the cluster
```

---

## `.github/workflows/terraform-dynatrace-dev.yaml`

**What it is:** CI/CD pipeline for Dynatrace Terraform configuration — dev environment only.

**Full breakdown line by line:**
```yaml
on:
  push:
    branches: [main]
    paths:
      - 'terraform/environments/dev/**'
      - 'terraform/modules/dynatrace/**'   ← CRITICAL LINE
  pull_request:
    branches: [main]
    paths:
      - 'terraform/environments/dev/**'
      - 'terraform/modules/dynatrace/**'
```

**Why `terraform/modules/dynatrace/**` is in the trigger paths:**
```
Scenario: you fix a bug in terraform/modules/dynatrace/main.tf
  (e.g., latency metric uses wrong unit — you change ms to µs conversion)

If paths only had 'terraform/environments/dev/**':
  The module file changed but the dev env file didn't change.
  CI does NOT trigger for dev.
  Dev runs old buggy module until you manually touch dev/main.tf.

With both paths:
  Module changes → ALL 3 env pipelines trigger.
  All 3 environments get the fix on their next apply.
  This is the correct behavior.
```

**`plan` job (PR only):**
```yaml
if: github.event_name == 'pull_request'
permissions:
  id-token: write      ← needed for OIDC AWS auth
  pull-requests: write ← needed to post the plan as a PR comment
```

```yaml
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789010:role/github-actions-dynatrace-plan
```
The `plan` role has read-only AWS permissions (Secrets Manager GetSecretValue, S3 GetObject for state). It CANNOT modify infrastructure. Even if the pipeline is hacked, the plan job cannot create or destroy anything.

```yaml
- name: Terraform Plan
  id: plan
  run: terraform plan -no-color 2>&1 | tee plan.txt
```
`tee` writes to stdout AND to `plan.txt` simultaneously. The next step reads `plan.txt` to post as a PR comment.

```yaml
- name: Post plan to PR
  uses: actions/github-script@v7
  with:
    script: |
      const plan = fs.readFileSync('...plan.txt', 'utf8');
      github.rest.issues.createComment({
        body: `## Dynatrace Dev Plan\n\`\`\`\n${plan.substring(0,65000)}\n\`\`\``
      });
```
`plan.substring(0,65000)` caps output at 65,000 chars. GitHub PR comments have a size limit — very long plans would silently fail to post without this truncation.

**`apply` job (merge to main only):**
```yaml
if: github.event_name == 'push'
role-to-assume: arn:aws:iam::123456789010:role/github-actions-dynatrace-apply
```
The `apply` role has write permissions. It is only assumed on push to main — never on PRs. This prevents a fork PR from applying Terraform.

```yaml
run: terraform apply -auto-approve -no-color
```
`-auto-approve` skips the interactive "yes/no" prompt — required in CI since there's no terminal. `-no-color` removes ANSI escape codes from logs (they render as garbage in GitHub Actions logs without a terminal).

**`terraform-dynatrace-production.yaml` difference:**
```yaml
apply:
  environment: production   ← the ONLY added line
```
The GitHub `environment: production` setting requires REQUIRED REVIEWERS to approve. The pipeline pauses after the plan and waits for a human to click Approve in the GitHub UI before `terraform apply` runs. Any DT config change in production requires explicit approval.

---

## `terraform/modules/dynatrace/variables.tf`

**What it is:** The contract between the module and its callers. Every value that differs per environment is declared here.

```hcl
variable "environment" {
  type = string   # "dev" | "staging" | "production"
}
```
Used throughout main.tf to:
- Name resources: `"${each.value}-${var.environment}-critical"`
- Conditionally create resources: `var.environment == "production" ? local.teams : toset([])`
- Filter metric events: `value = var.environment key = "environment"`

```hcl
variable "dt_env_url" {
  sensitive = true   ← Terraform redacts this from plan output + logs
}
variable "dt_api_token" {
  sensitive = true
}
```
`sensitive = true` means Terraform will NEVER print this value in `terraform plan` output, `terraform show`, or state file display commands. Values still exist in the state file (encrypted in S3), but they won't appear in CI logs.

```hcl
variable "pagerduty_integration_keys" {
  type    = map(string)
  default = {}   ← dev passes {} → PagerDuty resources use for_each on {} → 0 resources created
}
```
This is how dev gets no PagerDuty notifications without any `if` statements in main.tf. `for_each = {}` creates zero resources. Elegant — the module logic doesn't need to know whether PD is wanted.

```hcl
variable "services" {
  type = map(object({
    team             = string
    slo_target       = number
    health_check_url = string
    traffic_min_rps        = number
    error_rate_alert       = number
    latency_p99_ms         = number
    cpu_saturation_pct     = number
    memory_usage_pct       = number
    jvm_heap_pct           = number
    pod_restart_threshold  = number
    network_error_rate_pct = number
  }))
}
```
This type declaration enforces that every service entry must have ALL 11 fields. If you add a new service to dev/main.tf but forget `jvm_heap_pct`, Terraform validates and fails BEFORE running, not silently. You can't ship a half-configured service.

---

## `terraform/modules/dynatrace/main.tf`

This is the core of the entire project. Every Dynatrace resource is created here.

### Provider block

```hcl
provider "dynatrace" {
  dt_env_url   = var.dt_env_url
  dt_api_token = var.dt_api_token
}
```
The DT provider talks directly to the Dynatrace REST API. Credentials come from AWS Secrets Manager (read in the caller's main.tf, passed as variables). Never hardcoded.

---

### `locals { teams = ... }` — the team deduplication

```hcl
locals {
  teams = toset([for svc in values(var.services) : svc.team])
}
```

**What this does step by step:**
```
var.services has keys:
  "payment-service"      → team: "payments"
  "order-service"        → team: "orders"
  "notification-service" → team: "notifications"

values(var.services):
  → extracts just the objects (not the service names)

[for svc in values(...) : svc.team]:
  → ["payments", "orders", "notifications"]

toset(...):
  → { "notifications", "orders", "payments" }
  → a SET: no duplicates, even if 5 services all had team = "payments"
```

**Why this matters:** Management zones and alerting profiles are per TEAM, not per SERVICE. Two services from the same team share one management zone. The `toset()` deduplication ensures you don't create two "payments-production" management zones if payment-service and payments-audit both have `team = "payments"`.

---

### Management Zones

```hcl
resource "dynatrace_management_zone_v2" "team" {
  for_each = local.teams   ← creates one zone per team
  name     = "${each.value}-${var.environment}"
```

**What a management zone does:**
A management zone is a filter applied to the Dynatrace UI. When a team opens the DT web console scoped to their zone, they only see their services, hosts, and processes. Other teams' metrics are hidden. Alerts in the zone only come from that team's services.

**Three rules in each zone:**
```hcl
rule { type = "SERVICE" ... }        ← captures Spring Boot REST endpoints
rule { type = "PROCESS_GROUP" ... }  ← captures the JVM process itself
rule { type = "HOST" ... }           ← captures the EKS node the pod runs on
```

Each rule uses TWO conditions with AND logic:
```hcl
attribute_conditions {
  attribute = "SERVICE_TAGS"
  tag_value = "team:${each.value}"        ← e.g., "team:payments"
}
attribute_conditions {
  attribute = "SERVICE_TAGS"
  tag_value = "environment:${var.environment}"  ← e.g., "environment:production"
}
```

**Why BOTH tags are required (not just team):**
```
Without environment tag filter:
  payment-service in DEV tagged team:payments
  payment-service in PROD tagged team:payments
  
  Management zone "payments-production" would include BOTH dev and prod services.
  Dev noisy alerts → payment team sees dev garbage in their prod zone.
  
With both tags:
  Zone "payments-production" only shows entities tagged BOTH team:payments AND environment:production.
  Dev and prod are cleanly separated even in the same DT tenant.
```

---

### Alerting Profiles — 4 tiers

**CRITICAL (production only):**
```hcl
resource "dynatrace_alerting" "critical" {
  for_each = var.environment == "production" ? local.teams : toset([])
```
The ternary `? local.teams : toset([])` means: in dev and staging, `for_each = {}` → zero critical alerting profiles created → zero PagerDuty critical notifications configured. This is how "prod only" is enforced — no `if` in the notification code needed.

```hcl
  severity_level   = "AVAILABILITY"
  delay_in_minutes = 0
```
AVAILABILITY severity = service completely down (Dynatrace built-in problem type). Zero delay = page immediately. There is no scenario where a service being completely down is transient enough to wait.

**HIGH (production + staging):**
```hcl
for_each = contains(["production", "staging"], var.environment) ? local.teams : toset([])
severity_level   = "ERROR"
delay_in_minutes = 2
```
ERROR severity = elevated error rate or failed requests. 2-minute delay filters out brief spikes during rolling deploys — the new pod starts, health checks briefly fail, error rate ticks up for 60-90 seconds. Without the delay: every deploy causes a PagerDuty alert in staging.

**WARNING (all environments):**
```hcl
for_each         = local.teams   ← ALL environments
severity_level   = "SLOWDOWN"
delay_in_minutes = 5
```
SLOWDOWN = latency degradation. 5 minutes confirms it's sustained, not a burst. If P99 spikes for 30 seconds during a GC pause, this doesn't fire.

**INFO (all environments):**
```hcl
severity_level   = "RESOURCE_CONTENTION"
delay_in_minutes = 15
```
RESOURCE_CONTENTION = CPU, memory, heap trending high. 15 minutes because these metrics take time to confirm as real trends vs. transient bursts. Also adds `CUSTOM_ALERT` severity so manually-created DT metric events route here.

---

### Metric Events — 8 signals

#### Signal 1: Traffic Drop (most important)

```hcl
locals {
  services_with_traffic = {
    for name, svc in var.services : name => svc
    if svc.traffic_min_rps > 0   ← dev sets 0 → filtered out → no traffic alert in dev
  }
}

resource "dynatrace_metric_events" "traffic_drop" {
  for_each = local.services_with_traffic   ← dev gets 0 resources here
```

The dev/main.tf sets `traffic_min_rps = 0` for all services. The `if svc.traffic_min_rps > 0` filter eliminates them. Result: no traffic alert in dev. The module doesn't need to know — the data controls which resources exist.

```hcl
  model_properties {
    alert_condition  = "BELOW"      ← fires when traffic DROPS below threshold
    alert_on_no_data = true         ← fires even when DT receives ZERO data points
    violating_samples = 3           ← 3 consecutive minutes below threshold
  }
```

**`alert_on_no_data = true` — why this matters:**
```
Normal alert: fires when metric value crosses a threshold.
Problem: if DT stops receiving metrics (OneAgent dies, network issue, pod completely broken),
         the metric has no data points. Normal alert = nothing happens. Service is down. No page.

alert_on_no_data = true:
  If DT receives zero data for 3 consecutive minutes → alert fires as if threshold was crossed.
  Catches: OneAgent crash, network partition, service so broken it can't report metrics.
  
Only traffic_drop uses this. Other signals (error rate, latency) legitimately have no data
when traffic is zero — you don't want to alert on "no latency data" when the service has
no traffic.
```

```hcl
  query_definition {
    metric_key = "builtin:service.requestCount.server"
    entity_filter {
      conditions {
        value = each.key         # "payment-service"
        key   = "service.name"
      }
      conditions {
        value = var.environment  # "production"
        key   = "environment"
      }
    }
  }
```
The two entity filter conditions narrow the metric to ONLY that service in THAT environment. Without the environment condition, the production alert would fire when dev traffic is zero — both environments share the same DT tenant but have separate monitoring.

---

#### Signal 3: Latency P99 — the µs conversion

```hcl
  threshold = each.value.latency_p99_ms * 1000   # DT uses microseconds internally
```

**This is one of the most common Dynatrace mistakes:**
```
You want: alert when P99 > 300ms
You write: threshold = 300 (thinking "ms")
DT reads: threshold = 300 MICROSECONDS = 0.3ms
Result: alert fires constantly for EVERY request (all requests take more than 0.3ms)
       OR: you set threshold = 300000 thinking DT uses ms, but DT uses µs → alert never fires

Correct: threshold = 300 * 1000 = 300,000 microseconds = 300ms
The * 1000 in Terraform handles this automatically.
The variable stays human-readable (latency_p99_ms: 300) and the conversion happens in the module.
```

```hcl
  model_properties {
    event_type = "PERFORMANCE_EVENT"   ← maps to SLOWDOWN severity → warning alerting profile
    violating_samples  = 3             ← 3 consecutive 1-minute windows above threshold
    dealerting_samples = 3             ← 3 consecutive windows BELOW threshold to clear the alert
```
`dealerting_samples = 3` prevents alert flapping: if latency goes above/below threshold every minute, the alert stays open until it's clearly resolved for 3 full minutes.

---

#### Signal 6: JVM Heap

```hcl
  metric_key = "builtin:process.memory.jvm.heapUtilization"
  threshold  = each.value.jvm_heap_pct   # 70 (prod), 78 (staging), 85 (dev)
```

**Why the threshold differs dramatically per environment:**
```
dev:     -Xmx256m  (JVM_OPTS in values-dev.yaml)
         Spring Boot idle context fills ~180MB = 70% of 256m at IDLE
         Threshold at 70%: fires before you write a single line of code
         Threshold at 85%: fires only when heap is truly near exhaustion

staging: -Xmx512m
         k6 load test (50 VUs) fills heap to ~78% at peak
         Threshold at 78%: fires if k6 causes MORE than normal heap use → possible leak
         
prod:    -Xmx1024m
         Normal load: 30-50% heap. Heavy load: up to 65%
         Threshold at 70%: fires before G1GC starts showing long pauses
         G1GC pause time increases non-linearly above 70% → alert before users feel it
```

The JVM_OPTS in values-dev.yaml (`-Xmx256m`) → values-staging.yaml (`-Xmx512m`) → values.yaml (`-Xmx1024m`) directly determines these thresholds. They are coupled — if you change Xmx, you must also update the threshold.

---

#### Signal 7: Pod Restarts — the fastest detection

```hcl
  metric_key = "builtin:kubernetes.workload.pods.restarts"
  resolution = "5m"          ← 5-minute window (not 1m like other signals)
  model_properties {
    samples           = 1    ← only needs 1 sample
    violating_samples = 1    ← fires immediately on first detection
```

Pod restarts are counted over 5-minute windows. Even `samples = 1` / `violating_samples = 1` means: as soon as one 5-minute window shows > threshold restarts, fire immediately. No waiting. A crash loop is never a transient blip — it should always alert immediately.

**Different thresholds per env:**
```
dev:     5 restarts in 5min → pods restart often during development (config changes, code crashes)
staging: 3 restarts in 5min → rolling deploys expected but shouldn't loop
prod:    2 restarts in 5min → ANY restart loop is a real problem
```

---

### SLOs — error budget math

```hcl
resource "dynatrace_slo_v2" "availability" {
  target_success = each.value.slo_target       # 99.9 (prod), 95.0 (staging), 90.0 (dev)
  target_warning = each.value.slo_target - 0.1 # 99.8 (prod warning line)
  evaluation_window = "-1M"   # rolling 30-day window
  evaluation_type   = "AGGREGATE"
```

**The metric expression — how availability is calculated:**
```
metric_expression = <<-EOT
  100 *
  (total_requests - error_requests)
  / total_requests
EOT
```

This is: `100 * (good_requests / total_requests)` = the percentage of requests that succeeded.

For `slo_target = 99.9%`:
- Monthly error budget = 1 - 0.999 = 0.1% of requests
- Assuming 100 req/s for 30 days: budget = 100 × 86400 × 30 × 0.001 = 259,200 errors allowed per month

**Burn rate alerts:**
```hcl
error_budget_burn_rate {
  fast_burn_threshold = 14.4   ← burning budget 14.4× faster than normal
  slow_burn_threshold = 3.0    ← burning budget 3× faster than normal
}
```

**What these numbers mean:**
```
Normal burn rate = 1.0 (budget depletes exactly over 30 days)

Fast burn = 14.4×:
  14.4 = 1 / (1/24 + 1/(24*5)) ← consumes 2% of monthly budget in 1 hour
  DT fires: "you will exhaust monthly budget in ~2 days at this rate"
  Response: page oncall NOW

Slow burn = 3.0×:
  Consumes 10% of monthly budget in 24 hours
  DT fires: "you will exhaust monthly budget in ~10 days at this rate"
  Response: Slack warning, investigate before it becomes critical
  
Why 14.4 and 3.0 specifically:
  These are the Google SRE workbook standard burn rates.
  14.4 catches problems that would exhaust budget in ~2 days.
  3.0 catches slow degradation that would exhaust budget in ~10 days.
  Both are needed: fast-burn catches acute outages, slow-burn catches slow leaks.
```

**Latency SLO — count of requests WITHIN threshold:**
```hcl
resource "dynatrace_slo_v2" "latency" {
  metric_expression = <<-EOT
    100 *
    (requests where response_time ≤ latency_p99_ms * 1000)
    / total_requests
  EOT
```
"What percentage of requests completed within the P99 target?" If `slo_target = 99.9` and `latency_p99_ms = 300`: 99.9% of requests must finish in under 300ms. Same burn rate alerts apply.

---

### HTTP Synthetic Monitors

```hcl
resource "dynatrace_http_monitor" "health_check" {
  frequency = 5        # every 5 minutes
  locations = var.synthetic_locations  # ["Tokyo", "Singapore"] or just ["Tokyo"] in dev
```

**Dev uses only Tokyo, staging/production use both:**
```
dev:      only Tokyo (GEOLOCATION-6F55B7E4B5E7A52F)
staging:  Tokyo + Singapore
prod:     Tokyo + Singapore

Why dev uses only one:
  Dev services have no SLA. Two-location monitoring costs DT synthetic DDUs (billing units).
  Tokyo alone is sufficient to confirm dev service is alive.
  
Why prod needs two:
  Single-location failure ≠ service down.
  Failure pattern → action:
    Both Tokyo AND Singapore fail → real outage → PagerDuty
    Only Tokyo fails → Tokyo DT node issue OR regional DNS problem → Slack warning
    Only Singapore fails → same, from Singapore side
  Without two locations, you can't distinguish "service is down" from "DT Tokyo node issue".
```

**Body validation — both rules must PASS:**
```hcl
validation {
  rule { type = "httpStatusesList"; value = "2xx"; pass_if_found = true }
  rule { type = "patternConstraint"; value = "\"status\":\"UP\""; pass_if_found = true }
}
```

```
Why validate BOTH HTTP status AND body content:

Case 1: 200 OK + body {"status":"DOWN"}
  → HTTP layer is fine, Spring Boot is running
  → BUT the application itself is reporting a downstream failure (DB down, cache offline)
  → HTTP status check: PASS (200 = 2xx)
  → Body check: FAIL ("status":"DOWN" ≠ "status":"UP")
  → Synthetic: FAILS → alert fires → correct behavior

Case 2: 200 OK + body {"status":"UP"}
  → Both checks pass → service is truly healthy

Case 3: 503 + body {"status":"DOWN"}
  → HTTP check: FAIL (503 ≠ 2xx)
  → Synthetic: FAILS at step 1 → body check not even evaluated → alert fires
  
The double-check catches the subtle "200 but broken" state that HTTP-only monitoring misses.
```

```hcl
response_time_limit = each.value.latency_p99_ms * 3
```
If the health endpoint itself takes > 3× the P99 SLO to respond, the synthetic fails. This catches severe performance degradation even before error rates rise.

```hcl
anomaly_detection {
  outage_handling {
    global_consecutive_outage_count_threshold = 1   # 1 failure → alert
    local_consecutive_outage_count_threshold  = 3   # 3 consecutive local failures → alert
    local_outages_count_threshold             = 1
  }
}
```
Global outage: 1 failure from ALL locations → alert immediately (both Tokyo AND Singapore fail).
Local outage: 3 consecutive failures from ONE location → alert (filters transient location blips).

---

### Notifications

**PagerDuty wiring:**
```hcl
resource "dynatrace_pagerduty_notification" "critical" {
  for_each         = var.pagerduty_integration_keys
  alerting_profile = dynatrace_alerting.critical[each.key].id
```
`var.pagerduty_integration_keys` is `{}` in dev → `for_each = {}` → 0 PagerDuty notification resources created in dev. No explicit `if` needed — empty maps eliminate the resources.

```hcl
resource "dynatrace_pagerduty_notification" "high" {
  for_each = contains(["production", "staging"], var.environment) ? var.pagerduty_integration_keys : {}
```
High-severity PD notifications exist in staging AND production. This is the correct pattern: staging oncall gets notified of errors (so you can fix them before reaching prod), but CRITICAL (full outage) is production only.

**Slack message format:**
```hcl
message = "[${upper(var.environment)}] {State} | {ProblemSeverity} | {ProblemTitle} | {ProblemURL}"
```
`{State}` = OPEN or RESOLVED — you see resolution in Slack without checking DT.
`{ProblemURL}` = direct link to the DT problem event. One click from Slack to the full incident view.
`upper(var.environment)` = `[PRODUCTION]` vs `[dev]` — teams immediately know which env.

---

## `terraform/environments/dev/main.tf`

**Backend config:**
```hcl
backend "s3" {
  bucket         = "company-terraform-state-dev"
  key            = "dev/terraform.tfstate"
  dynamodb_table = "terraform-state-lock"
}
```
Separate S3 bucket per environment. Dev state is in dev account, staging state in staging account, production state in production account. They are completely isolated — a `terraform apply` in dev CANNOT accidentally modify production infrastructure, even if you run it from the wrong directory.

**Reading secrets from Secrets Manager (never hardcoded):**
```hcl
data "aws_secretsmanager_secret_version" "dt_api_token" {
  secret_id = "dev/dynatrace/api-token"
}
```
At `terraform apply` time, Terraform calls Secrets Manager and reads the value. The token is NEVER written to the `.tf` file, Git, or CI logs. The `sensitive = true` flag on the variable ensures Terraform won't print it in output.

**`pagerduty_integration_keys = {}`:**
Dev passes an empty map. The module's `for_each = var.pagerduty_integration_keys` creates 0 PagerDuty notification resources. Dev engineers never get paged. The module doesn't know or care — it just processes whatever map it's given.

**`synthetic_locations = ["GEOLOCATION-6F55B7E4B5E7A52F"]` (Tokyo only):**
Dev uses one location. Cost savings (DT synthetic DDUs). One location is enough to verify dev is alive; SLA-grade multi-region monitoring is unnecessary in dev.

**Dev threshold reasoning:**
```
notification-service latency_p99_ms = 3000 (vs payment-service's 2000):
  notification-service is ASYNC — it publishes to SQS/SNS.
  The API returns immediately ("status": "queued") but the actual delivery is background.
  3000ms P99 in dev reflects: SQS publish latency + JIT warmup + small dev node.
  In production: notification-service latency_p99_ms = 1000 (still higher than payment's 300).
  This reflects the async nature — it legitimately takes longer than payment.
```

---

## `terraform/environments/production/main.tf`

**`slo_target = 99.9` for payment-service:**
```
What 99.9% availability means in practice:
  Monthly error budget = 0.1% of all requests
  At 100 req/s: 100 × 86400 × 30 = 259,200,000 requests/month
  Budget = 259,200 allowed errors = 43.2 minutes of complete downtime per month
  
If payment goes down for 5 minutes: 100 × 300 = 30,000 errors
  → Burned 30,000 / 259,200 = 11.6% of monthly budget in 5 minutes
  → Fast-burn rate = 11.6% burned in 5 min / (0.1%/month ÷ 30 days ÷ 24h ÷ 60min)
  → 5 minutes at full outage = ~200× burn rate → fast_burn_threshold (14.4×) fires
```

**`traffic_min_rps = 10` for payment-service:**
```
10 req/min = 0.17 req/s. Even at 3am Tokyo, real users in other time zones should generate this.
Below 10 req/min for 3 consecutive minutes means:
  1. ALB stopped routing (misconfigured Ingress)
  2. DNS broke (ExternalDNS stopped working)
  3. Service crashed but error rate looks 0% (no requests to fail)
  4. Deploy broke the service entirely

This is the "silent outage" detector. It's the most important signal.
```

**`ignoreDifferences` in the gitops Application (production):**
```yaml
ignoreDifferences:
  - group: apps
    kind: Deployment
    jsonPointers: [/spec/replicas]
```
HPA automatically adjusts `spec.replicas` based on CPU load. Without this, ArgoCD would see: "Git says 3 replicas, cluster has 7 (scaled by HPA)" → ArgoCD REVERTS to 3 → HPA scales back to 7 → infinite loop.

`ignoreDifferences` tells ArgoCD: "I know replicas will differ — that's the HPA doing its job, don't touch it." Every other field is still enforced (image tag, env vars, resource limits).

---

## `gitops/<env>/monitoring/dynatrace/dynatrace-operator.yaml`

This single file contains THREE Kubernetes resources in order.

### Resource 1: ArgoCD Application (installs the Dynatrace Operator)

```yaml
spec:
  source:
    repoURL: https://raw.githubusercontent.com/Dynatrace/helm-charts/master/repos/stable
    chart: dynatrace-operator
    targetRevision: "1.3.0"
```
The Operator is installed from Dynatrace's official Helm chart registry. It deploys the DT Operator pod — the controller that reads DynaKube custom resources and manages OneAgent/ActiveGate.

```yaml
# dev resources:
limits: { cpu: 200m, memory: 256Mi }

# prod resources:
limits: { cpu: 500m, memory: 1Gi }
```
The Operator itself uses little CPU in steady state. Production gets more memory because it monitors more pods, more processes, more metrics.

---

### Resource 2: ExternalSecret (pulls DT tokens from Secrets Manager)

```yaml
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  annotations:
    argocd.argoproj.io/sync-wave: "3"   ← same wave as DynaKube
spec:
  target:
    name: dynakube   ← creates a K8s Secret named "dynakube"
  data:
    - secretKey: apiToken
      remoteRef: { key: dev/dynatrace/api-token }   ← path in Secrets Manager
    - secretKey: dataIngestToken
      remoteRef: { key: dev/dynatrace/paas-token }
```

**Why the secret is called "dynakube":**
The DynaKube resource (next block) has `tokens: dynakube` which tells the DT Operator: "find a K8s Secret named `dynakube` and use its `apiToken` and `dataIngestToken` fields for authentication." The name must match exactly.

**Two different tokens:**
```
apiToken:       DT API token. Used by the Operator to call DT management API.
                Needs scopes: activeGateTokenManagement.create, entities.read, settings.write, etc.
                
dataIngestToken (paas-token):  Used by OneAgent for data ingestion.
                Needs scopes: dataIngest, metrics.ingest, logs.ingest.
                
Separate tokens = separate permission scopes.
If someone steals dataIngestToken: they can ingest data, but cannot read entity info or change settings.
If someone steals apiToken: they can manage DT config, but dataIngestToken limits what data they can push.
Principle of least privilege.
```

---

### Resource 3: DynaKube — the master configuration

```yaml
apiVersion: dynatrace.com/v1beta1
kind: DynaKube
metadata:
  name: dynakube
spec:
  apiUrl: https://PLACEHOLDER.live.dynatrace.com/api
  tokens: dynakube   ← points to the K8s Secret created by ExternalSecret above
```

**classicFullStack:**
```yaml
classicFullStack:
  enabled: true
  tolerations:
    - key: node-role.kubernetes.io/control-plane
      operator: Exists
      effect: NoSchedule
```
`classicFullStack: enabled: true` deploys OneAgent as a **DaemonSet** — one pod per node, system-wide. The toleration allows OneAgent to run on control-plane nodes (which normally repel workloads). This ensures EVERY node is monitored, including the masters.

**What OneAgent does once running:**
```
1. Hooks into every JVM process via JVMTI (Java Tool Interface)
   → auto-instruments Spring Boot methods, HTTP calls, JDBC queries
   → captures: request count, duration, error rate, DB query time, JVM heap
   
2. Reads /proc/<pid>/... for process metrics (CPU, memory RSS)
   
3. Reads cgroup metrics for container-level data

4. Reads /var/lib/docker/containers/*.log (or equivalent) for container logs
   → logMonitoring.enabled: true sends these to DT log analytics

5. Sends all data to ActiveGate (not directly to DT tenant)
   → reduces TCP connections: 1 ActiveGate per cluster vs 1 connection per node
```

**ActiveGate — dev vs production:**
```yaml
# dev:
activeGate:
  replicas: 1

# production:
activeGate:
  replicas: 2
  topologySpreadConstraints:
    - maxSkew: 1
      topologyKey: topology.kubernetes.io/zone
      whenUnsatisfiable: DoNotSchedule
```

```
Dev: 1 ActiveGate replica. If it dies, DT loses metrics for ~2-3 minutes until it restarts.
     Acceptable in dev — no SLA.

Production: 2 ActiveGate replicas spread across 2 AZs.
     topologySpreadConstraints: "never put both ActiveGate pods in the same AZ"
     If AZ-a fails: AZ-b ActiveGate continues forwarding metrics to DT.
     No monitoring gap during AZ failure.
     
The common mistake (from the main.md Common Mistakes table):
  activeGate replicas: 1 in production → AZ failure = complete monitoring blackout
  You lose metrics + traces for the duration of the AZ outage
  SLO burn rate looks flat (no data = no bad data) → false green
```

**`capabilities: [routing, kubernetes-api-monitoring, log-analytics]`:**
```
routing:                     ActiveGate acts as a proxy. OneAgents send data to ActiveGate,
                             which batches and forwards to DT tenant. Reduces outbound connections.
                             
kubernetes-api-monitoring:   ActiveGate calls the Kubernetes API to collect cluster-level metrics:
                             pod counts, deployment health, node status, namespace quotas.
                             Populates the Kubernetes workloads view in DT.
                             
log-analytics:               ActiveGate receives container logs from OneAgent and ships them
                             to DT log analytics. Without this: logs are NOT sent to DT even
                             if logMonitoring.enabled = true.
```

---

## `gitops/<env>/namespaces/namespaces.yaml`

```yaml
annotations:
  argocd.argoproj.io/sync-wave: "-1"   ← wave MINUS ONE = first thing deployed
```

Wave -1 deploys before wave 0, wave 1, wave 2, etc. Namespaces must exist before any resources can be deployed into them. If namespaces were in wave 1 (same as ALB controller), they might race and the ALB controller deployment would fail with "namespace not found."

```yaml
namespaces:
  - name: payment-ns
    labels: { team: payments, environment: production }
```

**Why these labels are critical for Dynatrace:**
```
OneAgent on the node reads Kubernetes metadata for every pod it instruments.
It reads: which namespace is this pod in? what labels does that namespace have?

DT auto-tagging rule (configured once in DT UI):
  "if Kubernetes label 'team' exists → apply tag team:<label-value> to entity"
  "if Kubernetes label 'environment' exists → apply tag environment:<label-value> to entity"

Flow:
  1. payment-service pod starts in payment-ns
  2. OneAgent sees: namespace has labels team=payments, environment=production
  3. OneAgent tags payment-service entity: team:payments, environment:production
  4. Management zone "payments-production" rule: SERVICE where tag team:payments AND environment:production
  5. Payment-service entity appears in the payments team's zone
  6. Alerting profiles scoped to this zone → notifications go to the right team

If labels are missing → auto-tagging doesn't fire → entity appears in NO zone → no alerts.
This is listed in the Common Mistakes table because it's the #1 silent failure.
```

**`pod-security.kubernetes.io/enforce: restricted` (in dev version):**
This label on the namespace activates Kubernetes Pod Security Standards enforcement. `restricted` = strictest policy. Any pod that tries to run as root, use host networking, or request extra capabilities will be REJECTED by the API server. This is why the Deployment has `runAsNonRoot: true` and `capabilities.drop: [ALL]` — without those, the pod would fail to schedule.

---

## `gitops/<env>/secrets/cluster-secret-store.yaml`

Two resources in one file.

### Resource 1: ArgoCD Application (installs ESO)

```yaml
annotations:
  argocd.argoproj.io/sync-wave: "2"   ← after namespaces, before DynaKube tokens
```

```yaml
helm:
  values: |
    serviceAccount:
      annotations:
        eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-eso
```
ESO uses IRSA — the ESO pod's ServiceAccount is annotated with an IAM role ARN. When ESO calls Secrets Manager, it uses temporary credentials from that role. No AWS credentials stored in Kubernetes.

---

### Resource 2: ClusterSecretStore

```yaml
apiVersion: external-secrets.io/v1beta1
kind: ClusterSecretStore
metadata:
  name: aws-secrets-manager
spec:
  provider:
    aws:
      service: SecretsManager
      region: ap-northeast-1
      auth:
        jwt:
          serviceAccountRef:
            name: external-secrets
            namespace: external-secrets
```

**What ClusterSecretStore does:**
It is the connection configuration — "how do we talk to Secrets Manager?" Each ExternalSecret resource says `secretStoreRef: name: aws-secrets-manager` to reference this store. The ClusterSecretStore is cluster-wide (vs a SecretStore which is namespace-scoped).

**Wave ordering dependency:**
```
wave 2: ESO installed + ClusterSecretStore created
  → ESO controller is now running and can process ExternalSecret resources

wave 3: DynaKube ExternalSecret applied
  → ESO sees it, reads ClusterSecretStore config, calls Secrets Manager
  → Creates K8s Secret "dynakube" with the DT tokens
  
wave 3: DynaKube resource applied
  → DT Operator reads DynaKube.spec.tokens = "dynakube"
  → Finds the K8s Secret (just created by ESO)
  → Uses tokens to connect to DT tenant

If ESO were wave 4 and DynaKube were wave 3:
  DT Operator looks for "dynakube" Secret → doesn't exist yet → fails to connect
  OneAgent never starts
```

---

## `charts/namespaces/`

### `templates/namespace.yaml`

```yaml
{{- range .Values.namespaces }}
apiVersion: v1
kind: Namespace
metadata:
  name: {{ .name }}
  labels:
    {{- toYaml .labels | nindent 4 }}
---
{{- end }}
```

This Helm template loops over a list and renders one Namespace manifest per entry. The `---` separator between manifests is required — without it, Kubernetes YAML parsing fails.

The template is called differently per environment via the ArgoCD Application's inline values. Dev ArgoCD Application passes `environment: dev` and the label map includes `environment: dev`. Production passes `environment: production`. Same template, different data.

---

## `charts/payment-service/values.yaml` vs `values-dev.yaml`

### Production values.yaml — key decisions

```yaml
replicaCount: 3   ← 1 pod per AZ across 3 AZs
```
With `topologySpreadConstraints.whenUnsatisfiable: DoNotSchedule` (production), pods MUST spread across 3 AZs. K8s won't schedule 3 pods if only 2 AZs are available. If a node in AZ-c is down, pod 3 stays Pending until a new node is provisioned. This is the trade-off: hard zone spread = maximum resilience, but scheduling failures during AZ issues.

```yaml
- name: JVM_OPTS
  value: >-
    -Xms512m -Xmx1024m
    -XX:+UseContainerSupport
    -XX:MaxGCPauseMillis=200
    -XX:+UseG1GC
```
`-Xms512m`: JVM starts with 512MB heap already allocated. Without this, JVM starts at ~64MB and grows to 1024MB through multiple GC cycles → unpredictable latency spikes during startup as heap expands. Setting Xms close to Xmx eliminates heap expansion overhead.

`-XX:MaxGCPauseMillis=200`: G1GC target: keep GC pauses under 200ms. G1GC will adjust region sizes and GC frequency to try to meet this target. Direct impact on P99 latency.

```yaml
topologySpreadConstraints:
  - whenUnsatisfiable: DoNotSchedule   ← HARD (production)
```
vs dev:
```yaml
topologySpreadConstraints:
  - whenUnsatisfiable: ScheduleAnyway  ← SOFT (dev)
```
**Production uses HARD:** Zone spread is mandatory. A pod will wait in Pending rather than schedule in the wrong zone.
**Dev uses SOFT:** Dev cluster may have only 1 or 2 nodes. A hard zone constraint would prevent ALL pods from scheduling if the cluster is small. `ScheduleAnyway` schedules even if zone spread can't be achieved — dev functionality over resilience.

```yaml
startupProbe:
  failureThreshold: 60   # 60 × 10s = 10 minutes (production)
```
vs dev:
```yaml
startupProbe:
  failureThreshold: 120  # 20 minutes (dev)
```
Production JVM on m7g.xlarge with warm Docker layer cache: boots in ~60-90 seconds. 10 minutes (600s) is ample.
Dev JVM on t3.medium, possibly with a cold Docker cache pull (~200MB image): can take 3-5 minutes just to pull the image, then 90 seconds to boot. 20 minutes (1200s) prevents false "pod is stuck" kill during slow dev cold starts.

---

## `charts/payment-service/templates/external-secret.yaml`

```yaml
spec:
  refreshInterval: 1h
  data:
    - secretKey: DB_HOST
      remoteRef:
        key: {{ .Values.commonLabels.environment }}/payment-service/db-credentials
        property: host
```

**The environment-scoped secret path:**
`{{ .Values.commonLabels.environment }}` = "dev" / "staging" / "production". The secret path becomes:
- dev: `dev/payment-service/db-credentials`
- staging: `staging/payment-service/db-credentials`
- prod: `production/payment-service/db-credentials`

Each environment has its OWN database credentials in Secrets Manager. Dev pods cannot accidentally use production credentials — the path is baked into the template from the Helm values.

**`refreshInterval: 1h`:**
ESO re-reads from Secrets Manager every hour. When DB credentials rotate (e.g., via AWS Secrets Manager automatic rotation), the new credentials appear in the K8s Secret within 1 hour. The running pods pick up the new credentials on their next DB connection pool refresh (HikariCP revalidates connections). No pod restart needed for credential rotation.

**`creationPolicy: Owner`:**
If the ExternalSecret is deleted (e.g., ArgoCD deletes it), the K8s Secret it created is also automatically deleted. No orphaned secrets with stale credentials persisting after the service is removed.

---

## `charts/payment-service/templates/deployment.yaml`

### The `commonLabels` pattern

```yaml
metadata:
  labels:
    app: payment-service
    {{- range $k, $v := .Values.commonLabels }}
    {{ $k }}: {{ $v }}
    {{- end }}
```

`values.yaml` (production):
```yaml
commonLabels:
  team: payments
  environment: production
  app: payment-service
  managed-by: helm
```

`values-dev.yaml`:
```yaml
commonLabels:
  team: payments
  environment: dev
  app: payment-service
```

**Why these labels appear on the pod spec template (not just Deployment metadata):**
Labels on `metadata` go on the Deployment object. Labels on `spec.template.metadata` go on EVERY POD. Only pod-level labels are visible to:
- OneAgent (for DT auto-tagging)
- Kubernetes NetworkPolicy selectors
- Service selectors
- HPA label matchers

The template renders labels in BOTH places by using the same `{{- range }}` block in both `metadata` and `spec.template.metadata`.

### Security context

```yaml
spec.securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  fsGroup: 1000

container.securityContext:
  readOnlyRootFilesystem: true
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
```

These settings satisfy the `pod-security.kubernetes.io/enforce: restricted` namespace policy. If ANY of these are missing, the pod will be rejected at admission. The namespace policy acts as a backstop — even if someone accidentally removes the security context from the Helm template, the namespace policy blocks the pod.

### `imagePullPolicy: Always` in dev

```yaml
# values-dev.yaml:
image:
  pullPolicy: Always
```
vs production:
```yaml
# values.yaml:
image:
  pullPolicy: IfNotPresent
```
In dev, the image tag is often `latest-dev` (always the newest build). `IfNotPresent` would use a cached old image even when a new one is pushed — the tag hasn't changed. `Always` forces a pull on every pod start, ensuring dev always runs the latest code. In production, the tag IS the git SHA (unique per commit), so `IfNotPresent` correctly caches the specific version.

### jdwp debug port (dev only)

```yaml
# values-dev.yaml JVM_OPTS:
-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005
```
This enables the Java Debug Wire Protocol — lets IntelliJ/VSCode attach a remote debugger to the running JVM inside the Kubernetes pod. `suspend=n` is critical — without it, the JVM waits for a debugger to connect before executing ANY code, meaning the pod never passes its startupProbe → CrashLoopBackOff. `address=*:5005` binds to all interfaces; use `kubectl port-forward` to reach it safely.

---

## `terraform/modules/vpc/main.tf`

### Subnet sizing

```hcl
local.public_subnets   = cidrsubnet(vpc_cidr, 8, i+1)    # /24 → 254 IPs per AZ
local.private_subnets  = cidrsubnet(vpc_cidr, 4, i+16)   # /20 → 4094 IPs per AZ
local.database_subnets = cidrsubnet(vpc_cidr, 8, i+100)  # /24 → 254 IPs per AZ
```

**Why private subnets are /20 (4094 IPs):**
AWS VPC CNI (EKS networking): each pod gets its own IP from the VPC subnet. With 3 services × 3 environments × 20 replicas max each = 180 pod IPs needed at peak. But Kubernetes also creates IP addresses for services, endpoints, and has pre-allocated ENIs on each node. A /20 (4094 IPs) prevents IP exhaustion during autoscaling events.

Public subnets (/24 = 254 IPs) are just for NAT Gateways and ALBs — far fewer IPs needed.

### `one_nat_gateway_per_az = true`

```hcl
single_nat_gateway     = false
one_nat_gateway_per_az = true
```
3 NAT Gateways (one per AZ) vs 1 NAT Gateway. Cost: ~$32/month per NAT Gateway = $96/month for 3 vs $32 for 1.

**Why the extra cost is worth it in production:**
```
With single NAT Gateway:
  NAT is in AZ-a. Private subnets in AZ-b and AZ-c route through NAT in AZ-a.
  AZ-a fails → NAT dies → ALL pods in ALL AZs lose internet access
              → cannot pull new Docker images → deployments fail
              → cannot reach AWS APIs (ECR, Secrets Manager) → services break

With one per AZ:
  AZ-a fails → AZ-b pods use AZ-b NAT → AZ-c pods use AZ-c NAT → no disruption
```

### S3 VPC Endpoint

```hcl
resource "aws_vpc_endpoint" "s3" {
  vpc_endpoint_type = "Gateway"
  route_table_ids   = module.vpc.private_route_table_ids
}
```
S3 Gateway endpoint is FREE. Traffic to S3 (ECR layers are stored in S3, Terraform state is in S3, EBS CSI driver uses S3 for backups) routes through AWS's internal network instead of NAT Gateway. This eliminates NAT Gateway data processing charges for S3 traffic — can save significant cost at scale since ECR image pulls go through S3.

---

## `terraform/modules/eks/main.tf`

### EKS API endpoint access

```hcl
cluster_endpoint_private_access = true
cluster_endpoint_public_access  = false
```
The Kubernetes API server is NOT accessible from the internet. All `kubectl` commands must come from within the VPC (via a bastion host, VPN, or SSM tunnel). This eliminates the attack surface of an internet-facing Kubernetes API.

### System node taint

```hcl
taints = {
  dedicated = {
    key    = "dedicated"
    value  = "system"
    effect = "NO_SCHEDULE"
  }
}
```
System nodes have a taint. Only pods with a matching toleration can run on system nodes. This reserves system nodes for: CoreDNS, kube-proxy, aws-vpc-cni, and the DT Operator. Application pods (payment-service etc.) don't have the toleration → they're scheduled on separate worker nodes.

**Why isolation matters:**
```
Without taint: payment-service pod and CoreDNS pod on the same node.
  payment-service has a memory leak → uses all node RAM → CoreDNS OOMKilled
  DNS stops working → ALL services in the cluster break (can't resolve service names)

With taint: CoreDNS only runs on system nodes. Payment-service runs on worker nodes.
  Payment-service OOM → only payment-service affected → DNS continues working.
```

### `metadata_options.http_tokens = "required"`

```hcl
http_tokens = "required"   # IMDSv2 only
```
IMDSv2 = Instance Metadata Service version 2. Requires a session token to query instance metadata (including IAM role credentials). Without this, any process inside a pod (including malicious code) can call `http://169.254.169.254/latest/meta-data/iam/security-credentials/` and get the node's IAM credentials. With IMDSv2 required, this attack is blocked.

```hcl
http_put_response_hop_limit = 2
```
Default is 1 (only the instance itself can get IMDSv2 tokens). Setting to 2 allows pods running inside the instance (one network hop away) to get tokens for their IRSA ServiceAccount. Without this set to 2, IRSA doesn't work for pods.

### `cluster_encryption_config`

```hcl
cluster_encryption_config = {
  resources = ["secrets"]
}
```
Encrypts Kubernetes Secrets at rest in etcd using an AWS KMS key. Without this, Kubernetes Secrets are base64-encoded (not encrypted) in etcd. Anyone with etcd access (unlikely but possible) could read all secrets in plain text.

---

## `gitops/<env>/networking/aws-load-balancer-controller.yaml`

```yaml
annotations:
  argocd.argoproj.io/sync-wave: "1"
```
Wave 1 (after namespaces at -1, before apps at 8). If ALB controller weren't ready when the payment-service Ingress is applied at wave 8, the Ingress would stay in "Pending" state — no ALB created, service unreachable.

```yaml
values:
  replicaCount: 1   # dev
  # production uses 2 (not shown but understood from the pattern)
```
Dev: 1 ALB controller replica. Production would use 2 for HA — ALB controller restart takes ~30s, during which no new Ingresses are processed (existing ALBs continue working, but changes to Ingress don't take effect).

```yaml
eks.amazonaws.com/role-arn: arn:aws:iam::123456789010:role/company-dev-aws-load-balancer-controller
```
IRSA: the ALB controller pod has an IAM role that allows it to call `ec2:CreateLoadBalancer`, `elasticloadbalancing:*`, etc. Without this role, the controller can't call AWS APIs → Ingress stays Pending forever.

---

## `gitops/<env>/networking/external-dns.yaml`

```yaml
domainFilters:
  - dev.company.com   # dev
  # staging: staging.company.com
  # prod:    company.com
```
Critical safety setting. ExternalDNS only modifies Route53 records within this domain. Without `domainFilters`, a misconfigured Ingress in dev (e.g., `host: payment.company.com`) would overwrite the production DNS record. The filter ensures dev can only create `*.dev.company.com` records.

```yaml
txtOwnerId: "company-dev"
```
ExternalDNS creates TXT records in Route53 to track which records it owns. `txtOwnerId` scopes ownership to this cluster. Without it, if staging ExternalDNS sees a Route53 record created by dev ExternalDNS (with no txtOwnerId), it might delete it thinking it's an orphan. Unique ownership IDs prevent cross-cluster DNS deletion.

```yaml
policy: sync   # creates AND deletes
```
`sync` means ExternalDNS will DELETE Route53 records when the corresponding Ingress is deleted. Alternative is `upsert-only` which only creates/updates (safer but leaves orphan DNS records). `sync` + `domainFilters` together are safe — sync for the domain it owns, never touching outside records.

```yaml
interval: 1m
```
ExternalDNS polls Ingress resources every 1 minute. When a new Ingress is created, DNS propagates within ~1 minute. Without this, new services might take 3-5 minutes to get DNS entries.
