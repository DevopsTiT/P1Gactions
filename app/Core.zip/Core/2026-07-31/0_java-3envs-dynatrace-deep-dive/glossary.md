# Glossary — 38_java-3envs-dynatrace Deep Dive

Every term used in main.md. One entry per term — name, one-line definition, why it matters.

---

**Terraform module**
A reusable folder of `.tf` files that can be called multiple times with different inputs. The `modules/dynatrace/` folder is called once for dev, once for staging, once for production — same logic, different threshold values. Fix the module once → all 3 environments get the fix.

**`for_each` (Terraform)**
A meta-argument that creates one resource per item in a map or set. `for_each = local.teams` creates one management zone per team. `for_each = {}` (empty map) creates zero resources — the pattern used to skip PagerDuty resources in dev.

**`toset()` (Terraform)**
Converts a list to a set, removing duplicates. Used to deduplicate team names extracted from the services map — ensures one management zone per team even if multiple services share a team.

**`sensitive = true` (Terraform variable)**
Tells Terraform to never print this value in plan output, logs, or `terraform show`. The value still exists in the state file (encrypted in S3) but is redacted from all human-readable output. Used for DT API tokens and PagerDuty keys.

**`data "aws_secretsmanager_secret_version"`**
A Terraform data source that reads a secret's value from AWS Secrets Manager at `terraform apply` time. The secret value flows into variables but is never written to `.tf` files or Git. The only way to fetch credentials without hardcoding them.

**Dynatrace management zone**
A named filter in Dynatrace that scopes the UI and alerts to specific entities (services, hosts, processes). The "payments-production" zone shows only payment-related entities tagged with both `team:payments` AND `environment:production`. Teams see only their own data.

**Dynatrace alerting profile**
A rule that maps a problem severity level to a notification channel, with an optional delay. "If severity = AVAILABILITY, 0-minute delay → send to PagerDuty" is one alerting profile. 4 profiles per team (critical/high/warning/info) = different recipients and urgency per severity.

**`delay_in_minutes` (alerting profile)**
How long a problem must persist before the notification fires. 0 = immediate. 2 = wait 2 minutes. Used to filter transient blips during rolling deploys. The 2-minute HIGH delay means a pod that briefly fails health checks during startup doesn't page the oncall.

**AVAILABILITY (DT severity)**
Dynatrace built-in problem type meaning "service is completely down." The most severe level. Maps to the CRITICAL alerting profile → immediate PagerDuty phone call. Only created in production (dev is down intentionally sometimes).

**ERROR (DT severity)**
Dynatrace built-in problem type for elevated error rates or request failures. Maps to HIGH alerting profile → PagerDuty push notification with 2-minute delay. Created in production and staging.

**SLOWDOWN (DT severity)**
Dynatrace built-in problem type for latency degradation. Maps to WARNING alerting profile → Slack message with 5-minute delay. Created in all environments.

**RESOURCE_CONTENTION (DT severity)**
Dynatrace built-in problem type for CPU/memory/heap pressure. Maps to INFO alerting profile → #monitoring Slack channel with 15-minute delay. Created in all environments.

**Dynatrace metric event**
A Dynatrace configuration that says "when metric X crosses threshold Y for Z minutes, create a Problem of type T." This project creates 8 per service — one for each of the golden signals plus JVM-specific metrics.

**`alert_on_no_data = true`**
A metric event setting that fires the alert even when DT receives ZERO data points (not just when the value is wrong). Used only for the traffic drop signal — if DT stops receiving any data (service completely broken or OneAgent dead), the alert still fires. Without this, silent outages produce no alerts.

**`violating_samples` / `dealerting_samples`**
`violating_samples`: how many consecutive data windows must exceed the threshold before the alert fires. Prevents single-point spikes from paging. `dealerting_samples`: how many windows must be back in normal range before the alert clears. Prevents flapping (alert fires, clears, fires, clears every minute).

**`builtin:service.requestCount.server`**
Dynatrace's built-in metric key for the number of HTTP requests received by a service per minute. Used for the traffic drop signal — when requests fall below `traffic_min_rps` for 3 consecutive minutes, the silent outage alert fires.

**`builtin:service.response.time:percentile(99)`**
Dynatrace built-in metric for the P99 response time of a service. Measures the 99th percentile — the value that 99% of requests are FASTER than. The threshold is expressed in microseconds (Dynatrace's internal unit), so `latency_p99_ms * 1000` converts human-readable ms to µs.

**µs (microseconds) vs ms (milliseconds)**
Dynatrace stores latency metrics internally in microseconds (µs). 1 ms = 1,000 µs. If you set a threshold of `300` thinking "300ms", Dynatrace interprets it as 300 microseconds = 0.3ms — the alert fires on almost every request. Always multiply ms values by 1000 in DT metric expressions.

**`builtin:process.memory.jvm.heapUtilization`**
Dynatrace built-in metric for JVM heap used as a percentage of the maximum heap (-Xmx). 70% means the JVM is using 70% of its allocated maximum heap. G1GC pause times increase non-linearly above 70% — alerting before this point gives time to scale out or investigate before users notice.

**`builtin:kubernetes.workload.pods.restarts`**
Dynatrace built-in metric counted over a 5-minute window. Any restart over the threshold fires immediately (`samples: 1, violating_samples: 1`). A pod restart is never transient — it always means a crash, OOM kill, or failed readiness probe.

**Dynatrace SLO (Service Level Objective)**
A configured target stating "X% of requests must succeed" or "X% of requests must complete within Yms" over a rolling 30-day window. DT tracks compliance and how much of the monthly "error budget" has been spent. When the budget is burning too fast, burn rate alerts fire.

**Error budget**
The total amount of failures allowed in a month while still meeting the SLO. For 99.9% availability: 0.1% of requests can fail. For 100 req/s over 30 days: budget = 259,200 failed requests. Every outage burns part of this budget. Burn rate alerts fire when the budget is depleting too fast.

**Burn rate**
How fast the error budget is being consumed relative to normal. Burn rate 1.0 = budget depletes at exactly the right pace (used up on day 30). Burn rate 14.4 = budget will be exhausted in ~2 days. Burn rate 3.0 = budget will be exhausted in ~10 days. DT calculates burn rate in real time and fires alerts at 14.4× and 3.0×.

**Fast burn threshold (14.4)**
The Google SRE workbook standard. A burn rate of 14.4× means 2% of the monthly budget is consumed in 1 hour. At this rate, the monthly budget is gone in ~2 days. Requires immediate paging response.

**Slow burn threshold (3.0)**
A burn rate of 3.0× means 10% of the monthly budget is consumed in 24 hours. Budget exhausted in ~10 days. Requires investigation within a day — a Slack warning is sufficient.

**Dynatrace HTTP Synthetic monitor**
An active health check that DT sends from external nodes (Tokyo, Singapore) to your service's URL every 5 minutes. Validates both HTTP status (2xx) and response body (`"status":"UP"`). Unlike OneAgent (passive, inside the cluster), synthetics test from the same perspective as real users.

**DDU (Dynatrace Data Units)**
DT's billing unit for synthetic monitors. Each location × each check frequency × time = DDUs consumed. Dev uses 1 location to save DDUs. Production uses 2 locations for proper outage detection.

**Local outage vs global outage (synthetic)**
Local outage: only ONE Dynatrace monitoring location fails to reach the service. Could be a regional network issue at the DT node, not your fault. `local_consecutive_outage_count_threshold: 3` means 3 consecutive local failures before alerting. Global outage: ALL locations fail → real service outage → alert on first failure.

**DynaKube**
A Kubernetes custom resource (CRD) defined by the Dynatrace Operator. It is the configuration for "how should Dynatrace be deployed in this cluster?" It controls: whether to use OneAgent DaemonSet, ActiveGate configuration, token references, log monitoring settings. One DynaKube per cluster.

**OneAgent**
Dynatrace's monitoring agent. Runs as a DaemonSet (one pod per node). On each node it: hooks into JVM processes via JVMTI to auto-instrument them, reads container logs, collects host/process metrics, and forwards everything to ActiveGate. Zero application code changes needed.

**JVMTI (Java Tool Interface)**
A C API that lets external agents hook into a running JVM. OneAgent uses JVMTI to instrument Java methods (add entry/exit timing) at the bytecode level, without changing source code. This is how DT captures HTTP request durations, DB query times, and exception rates for Spring Boot apps without any annotations or SDK calls.

**ActiveGate**
A Dynatrace component that runs inside the cluster as a Deployment. It acts as a proxy: OneAgent pods on each node send data to ActiveGate, which batches and forwards to the DT tenant. Reduces outbound connections from 20+ (one per node) to 1 or 2. Also required for: Kubernetes API monitoring, log analytics, synthetic routing.

**`classicFullStack`**
DynaKube setting that deploys OneAgent as a DaemonSet (one per node). Alternative modes exist (cloud-native which uses a webhook injector, applicationOnly which only instruments pods). classicFullStack = most complete monitoring, least configuration.

**`logMonitoring.enabled: true`**
DynaKube setting that enables container log collection. OneAgent on each node reads container stdout/stderr and sends it to DT log analytics via ActiveGate. Without this, logs are NOT sent to DT even if the app prints JSON logs to stdout.

**`capabilities: [routing, kubernetes-api-monitoring, log-analytics]`**
Three ActiveGate capabilities. `routing`: accepts metric/trace data from OneAgent and forwards to DT. `kubernetes-api-monitoring`: ActiveGate calls the Kubernetes API to collect cluster-level metrics (pod counts, deployment health). `log-analytics`: receives log data from OneAgent and ships to DT.

**topologySpreadConstraints**
A Kubernetes pod scheduling directive that spreads pods across topology zones (AZs, nodes). `maxSkew: 1` means no zone can have more than 1 extra pod vs another zone. `whenUnsatisfiable: DoNotSchedule` (hard) = don't schedule if spread can't be achieved. `ScheduleAnyway` (soft) = schedule anyway, best-effort spread.

**`whenUnsatisfiable: DoNotSchedule` vs `ScheduleAnyway`**
Production uses `DoNotSchedule` (hard): a pod stays Pending rather than schedule in an over-filled zone. Maximum AZ resilience at the cost of scheduling flexibility. Dev uses `ScheduleAnyway` (soft): pod schedules even if zone spread is imperfect — necessary for small dev clusters with fewer nodes than AZs.

**ESO (External Secrets Operator)**
A Kubernetes controller that reads ExternalSecret resources and creates Kubernetes Secrets by fetching values from external systems (AWS Secrets Manager, HashiCorp Vault, etc.). Without ESO running, ExternalSecret CRDs are just YAML — nothing reads them or creates the actual K8s Secrets.

**ClusterSecretStore**
An ESO resource that defines the connection to a secret backend (AWS Secrets Manager, in this case). Cluster-scoped — works for ExternalSecrets in any namespace. Each ExternalSecret references the store by name (`aws-secrets-manager`). The store holds the HOW (credentials, region, service endpoint); the ExternalSecret holds the WHAT (which secret key to fetch).

**ExternalSecret**
An ESO custom resource that says: "read secret X from the ClusterSecretStore and create Kubernetes Secret Y with key Z." The DynaKube ExternalSecret reads DT tokens from Secrets Manager and creates the K8s Secret that DynaKube needs.

**`refreshInterval: 1h`**
ESO setting on an ExternalSecret. ESO re-reads the value from Secrets Manager every hour. When AWS Secrets Manager auto-rotates DB credentials, the Kubernetes Secret is updated within 1 hour. No pod restart needed — HikariCP reconnects with new credentials on next connection pool refresh.

**`creationPolicy: Owner`**
ESO setting that makes the K8s Secret owned by the ExternalSecret. When the ExternalSecret is deleted (e.g., via ArgoCD prune), the K8s Secret is also deleted. Prevents orphaned secrets with stale credentials persisting after a service is removed.

**ArgoCD sync-wave**
An annotation on Kubernetes resources (`argocd.argoproj.io/sync-wave: "3"`) that controls deployment order. Lower waves deploy first. Wave -1 deploys before wave 0 before wave 1 etc. Within a wave, all resources deploy in parallel. Waves ensure dependencies are ready before dependents start.

**ArgoCD `prune: true`**
Tells ArgoCD: if a YAML is removed from Git, delete the corresponding Kubernetes resource. Without prune, deleted YAMLs leave orphaned resources running (wasted cost, potential security risk).

**ArgoCD `selfHeal: true`**
Tells ArgoCD: if someone manually changes a Kubernetes resource with kubectl, revert it back to what Git says within ~3 minutes. Git is the single source of truth. Manual changes are undone automatically.

**`ignoreDifferences` (ArgoCD)**
Tells ArgoCD to ignore certain fields when comparing the cluster state to Git. Used for `spec.replicas` because HPA continuously changes replica count. Without this, ArgoCD fights HPA in an infinite loop: HPA scales to 7 pods, ArgoCD reverts to 3 (from Git), HPA scales back to 7.

**`finalizers: resources-finalizer.argocd.argoproj.io`**
A Kubernetes finalizer on ArgoCD Application objects. When you delete the Application, ArgoCD first deletes ALL Kubernetes resources it manages, then removes the finalizer and deletes the Application. Without it, deleting the Application leaves all the Kubernetes resources running as orphans.

**IRSA (IAM Roles for Service Accounts)**
A way for pods to get AWS IAM permissions without storing credentials. A Kubernetes ServiceAccount is annotated with an IAM role ARN. When the pod starts, the AWS SDK automatically gets temporary STS credentials for that role. Each service has its own minimal-permission role.

**IMDSv2 (Instance Metadata Service v2)**
A secure version of the EC2 metadata service that requires a session token before returning instance information (including IAM credentials). `http_tokens = "required"` forces IMDSv2. Without it, any process inside a pod can call `169.254.169.254` to steal the node's IAM credentials.

**`http_put_response_hop_limit = 2`**
An EC2 metadata setting that controls how many network hops can retrieve IMDSv2 tokens. Default 1 = only the instance. Setting 2 = pods inside the instance (one hop away) can also get tokens for IRSA. Without this set to 2, IRSA doesn't work — pods can't get AWS credentials.

**KMS (Key Management Service)**
AWS service for creating and managing encryption keys. `cluster_encryption_config.resources = ["secrets"]` encrypts Kubernetes Secrets at rest in etcd using a KMS key. Without this, Kubernetes Secrets are base64-encoded (not encrypted) in etcd storage.

**EKS managed node group**
An EKS feature where AWS manages the EC2 instances (patching, replacement, AMI updates). The taint `dedicated=system:NoSchedule` on system nodes reserves them for platform pods only — application pods don't tolerate this taint and schedule on separate worker nodes.

**NAT Gateway**
An AWS network component that lets private subnet resources (EKS nodes) make outbound internet connections while remaining unreachable from the internet. `one_nat_gateway_per_az = true` means each AZ has its own NAT — if one AZ fails, the other AZs can still make outbound connections. Single NAT = AZ failure cuts all outbound internet.

**S3 VPC Gateway Endpoint**
An AWS feature that routes traffic to S3 through AWS's internal network instead of NAT Gateway. It's free. Since ECR stores Docker layers in S3, EKS image pulls go through the endpoint — no NAT charges for image pulls. Significant cost saving at scale.

**`domainFilters` (ExternalDNS)**
Restricts ExternalDNS to only create/modify Route53 records within specific DNS zones. Dev ExternalDNS is limited to `dev.company.com`. This prevents a misconfigured dev Ingress with `host: payment.company.com` from overwriting production DNS records.

**`txtOwnerId` (ExternalDNS)**
A unique identifier per cluster used by ExternalDNS to track which Route53 records it owns via TXT records. Without it, one cluster's ExternalDNS might delete another cluster's DNS records thinking they're orphans.

**`policy: sync` (ExternalDNS)**
ExternalDNS will both CREATE records when Ingresses are added AND DELETE records when Ingresses are removed. Alternative `upsert-only` only creates. `sync` + `domainFilters` is the safe combination: ExternalDNS manages its domain completely, touching nothing else.

**`jdwp` (Java Debug Wire Protocol)**
A JVM feature that opens a TCP socket for a remote debugger to attach. `-agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=*:5005` enables it in dev values. `suspend=n` is critical — without it, the JVM waits indefinitely for a debugger to connect before running ANY code → pod never passes startupProbe → CrashLoopBackOff.

**`-Xms` / `-Xmx` (JVM heap flags)**
`-Xms` = initial heap size (JVM starts with this much heap pre-allocated). `-Xmx` = maximum heap size. Setting Xms close to Xmx (e.g., Xms512m Xmx1024m) prevents heap expansion overhead: JVM doesn't need to perform multiple GC cycles to grow the heap from a tiny initial size, reducing startup latency spikes.

**G1GC (Garbage First Garbage Collector)**
A JVM garbage collector designed for low-latency workloads. It runs GC incrementally across many small heap regions rather than one large collection, targeting configurable pause times (`-XX:MaxGCPauseMillis=200`). Good for REST APIs where consistent latency matters more than maximum throughput.

**`-XX:MaxGCPauseMillis=200`**
A G1GC hint: "try to keep GC pauses under 200ms." G1GC adjusts region size and GC frequency to meet this target. Direct impact on P99 latency — without it, G1GC may choose to do larger GC cycles with longer pauses to maximize throughput instead.

**`-XX:+UseContainerSupport`**
JVM flag (enabled by default since Java 11, but explicit is safer). Makes the JVM read cgroup memory limits instead of the host machine's total RAM. Without it: JVM on a 64GB host node sees 64GB total RAM → sets heap to 48GB → immediately exceeds the 1Gi container memory limit → pod is OOMKilled by Kubernetes.

**`-XX:MaxRAMPercentage=75.0`**
Sets heap to 75% of the available memory (as read by UseContainerSupport = the container limit). With `limits.memory: 1Gi`: heap = 768MB. The remaining 25% goes to JVM overhead: metaspace (class metadata), code cache (JIT-compiled code), thread stacks, and OS buffers.

**HikariCP**
Spring Boot's default JDBC connection pool for PostgreSQL. `minimum-idle: 2` keeps 2 connections open at all times (reduces cold-start latency). `maximum-pool-size: 10` caps connections per pod — with 3 pods in production, max 30 concurrent DB connections. When DB credentials rotate, HikariCP validates connections on next use and reconnects with new credentials.

**OTEL (OpenTelemetry)**
A vendor-neutral standard for distributed tracing and metrics. The Spring Boot apps use `micrometer-tracing-bridge-otel` + `opentelemetry-exporter-otlp` to send traces to Dynatrace via the OTLP protocol. `OTEL_EXPORTER_OTLP_ENDPOINT` points to the Dynatrace ActiveGate inside the cluster.

**OTLP (OpenTelemetry Protocol)**
The wire protocol for sending traces, metrics, and logs from an application to an observability backend. The Java apps connect to `http://dynatrace-activegate.dynatrace.svc:4318` using OTLP. Port 4318 = OTLP HTTP. ActiveGate accepts OTLP data and forwards it to the Dynatrace tenant.

**Distributed trace**
A record of a single user request as it flows through multiple services. Each service creates a "span" (timed unit of work). Spans are linked by a trace ID propagated in HTTP headers. Result in DT: one trace shows `order-service [120ms] → payment-service [80ms] → PostgreSQL SELECT [30ms]`. Identifies exactly where latency is coming from.

**`SHOW_SQL = true` (dev only)**
Spring Boot / Hibernate setting that logs every SQL query to stdout. Useful for debugging in dev — you can see every DB query the ORM generates. Must be disabled in staging/production: logs SQL with potentially sensitive data (user IDs, payment amounts) and produces enormous log volume under load.

**`pullPolicy: Always` (dev) vs `IfNotPresent` (prod)**
`Always`: pull image from ECR on every pod start, even if it's already cached on the node. Used in dev because the `latest-dev` tag always points to the newest image — caching would serve stale code. `IfNotPresent`: use cached image if already present. Used in production because the tag IS the git SHA (unique per commit) — no need to re-pull what you already have.

**readOnlyRootFilesystem: true**
Container security setting. The container's filesystem is read-only — no process can write to it. Prevents malware from writing backdoors, modifying configuration files, or injecting into logs. The `/tmp` emptyDir volume is explicitly added to give the JVM a writable directory for heap dumps.

**emptyDir (Memory)**
A Kubernetes volume backed by node RAM instead of disk. `medium: Memory, sizeLimit: 200Mi` — fast writes, capped at 200MB. Used for `/tmp` so the JVM can write heap dumps (`-XX:+HeapDumpOnOutOfMemoryError`). The cap prevents a pathological OOM scenario from writing an unlimited-size heap dump and consuming all node RAM.

**`capabilities.drop: ["ALL"]`**
Removes all Linux capabilities from the container process. Capabilities grant special OS permissions (raw sockets, kernel parameter modification, etc.). Most apps need none. Dropping all eliminates an entire class of privilege escalation attacks if the container is compromised.

**Pod Security Standards (restricted)**
Kubernetes built-in policy enforced at the namespace level via `pod-security.kubernetes.io/enforce: restricted`. The `restricted` level blocks pods that run as root, use host networking/PID, mount sensitive host paths, or request extra capabilities. The Deployment security context settings exist to satisfy this policy.

**`allowPrivilegeEscalation: false`**
Container security setting. Blocks the container from gaining MORE privileges than its parent process (via setuid, sudo, etc.). Without this, a process in the container could potentially escalate to root even if started as a non-root user.
