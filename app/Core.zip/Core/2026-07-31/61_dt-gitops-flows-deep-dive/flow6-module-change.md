# Flow 6 — Module Change (Affects All Environments): Deep Dive
## A bug in a Terraform module → 3 environments updated in one deployment cycle

---

## Decision Tree — Why All Three Pipelines Fire

```
SRE edits terraform/modules/dynatrace/main.tf
        │
        ├── Which path filters match this file?
        │   terraform/modules/dynatrace/**
        │
        ├── Which workflow files have this path trigger?
        │   terraform-dynatrace-dev.yaml        → triggers
        │   terraform-dynatrace-staging.yaml    → triggers
        │   terraform-dynatrace-production.yaml → triggers
        │
        └── Why does each environment workflow list the module path?
            Because any module change affects ALL environments that use it.
            Without module paths in triggers, only direct environment config
            file changes would trigger — the module fix would be stuck.
```

---

## E2E Flow Summary

```
[SRE opens PR: fix entity dimension key in dynatrace module]
        │
        ▼
[GitHub Actions: THREE pipelines fire simultaneously]
  terraform-dynatrace-dev.yaml       → plan job → PR comment (dev changes)
  terraform-dynatrace-staging.yaml   → plan job → PR comment (staging changes)
  terraform-dynatrace-production.yaml → plan job → PR comment (prod changes)
        │
        ▼ (reviewer sees all 3 plans in PR comments, approves PR)
        │
[PR merged to main]
        │
        ├── dev apply:     automatic, no gate → updates 9 DT resources in dev
        ├── staging apply: automatic, no gate → updates 9 DT resources in staging
        └── prod apply:    environment: production gate → human approval
                           → updates 9 DT resources in production
        │
        ▼
[All 3 environments: entity dimension key is now correct]
[Latency alerts now correctly scope to service entities, not process group instances]
```

---

## Part 1 — The Bug: What Was Wrong and Why It Mattered

The SRE noticed that latency alerts were firing for the wrong entity type.

**Before (wrong):**
```hcl
# terraform/modules/dynatrace/main.tf
resource "dynatrace_metric_events" "latency_p99" {
  event_entity_dimension_key = "dt.entity.process_group_instance"
  # ...
}
```

**What this caused:**
- The metric event was scoped to `process_group_instance` (a JVM process entity)
- But `builtin:service.response.time` is a SERVICE-level metric, not a process metric
- DT tried to match the metric's entity (SERVICE) to the filter (process_group_instance)
- Result: either no entity matched → alert fired globally → noisy
  or: wrong entity shown in Problem → SRE couldn't find the service in DT UI

**After (correct):**
```hcl
resource "dynatrace_metric_events" "latency_p99" {
  event_entity_dimension_key = "dt.entity.service"   # ← correct for HTTP metrics
}
```

**Why `dt.entity.service` is correct:**
- `builtin:service.response.time` measures HTTP request duration
- HTTP services are represented as `SERVICE` entities in Dynatrace
- The entity dimension key must match the entity type of the metric
- `dt.entity.service` → DT Problem will link to the correct service entity

---

## Part 2 — The Module Architecture: Why One Change Affects All Environments

The Terraform module pattern:

```
terraform/
  modules/
    dynatrace/
      main.tf        ← the module code (bug is here)
      variables.tf
      outputs.tf
  environments/
    dev/
      main.tf        ← calls module: source = "../../modules/dynatrace"
    staging/
      main.tf        ← calls module: source = "../../modules/dynatrace"
    production/
      main.tf        ← calls module: source = "../../modules/dynatrace"
```

**Each environment module call:**
```hcl
# terraform/environments/dev/main.tf
module "dynatrace" {
  source      = "../../modules/dynatrace"   # ← points to the shared module
  environment = "dev"
  services    = var.services
  # ... env-specific variables
}
```

When `terraform apply` runs for any environment, Terraform:
1. Loads `environments/dev/main.tf`
2. Resolves `source = "../../modules/dynatrace"` → loads `modules/dynatrace/main.tf`
3. The module code is substituted inline — the environment config and module code
   are combined at plan/apply time

**The fix in `modules/dynatrace/main.tf` affects ALL environments** because all
environments use the same module code. There is no separate copy per environment.

---

## Part 3 — What the Three Plans Show

All three plans show the SAME structural change, but with environment-specific values:

```
# Dev plan (in PR comment):
~ module.dynatrace.dynatrace_metric_events.latency_p99["payment-service"]
    event_entity_dimension_key: "dt.entity.process_group_instance" → "dt.entity.service"

~ module.dynatrace.dynatrace_metric_events.latency_p99["order-service"]
    event_entity_dimension_key: "dt.entity.process_group_instance" → "dt.entity.service"

~ module.dynatrace.dynatrace_metric_events.latency_p99["notification-service"]
    event_entity_dimension_key: "dt.entity.process_group_instance" → "dt.entity.service"

Plan: 0 to add, 3 to change, 0 to destroy.

# Staging plan: identical structure, same 3 resources
# Production plan: identical structure, same 3 resources

Total across all environments: 9 resources updated (3 services × 3 environments)
```

**The reviewer checks:**
- All 3 plans show the same change (expected — same module, same fix)
- No "destroy" actions (this is a property change, not a resource recreation)
- 3 resources per environment (3 services × 1 resource type = 3 — correct)
- The change is in the right direction (wrong value → correct value)

---

## Part 4 — Why Dev and Staging Apply Automatically

```yaml
# terraform-dynatrace-dev.yaml
apply:
  if: github.event_name == 'push' && github.ref == 'refs/heads/main'
  # NO "environment:" field → no approval gate
  steps:
    - run: terraform apply -auto-approve
```

```yaml
# terraform-dynatrace-staging.yaml
apply:
  if: github.event_name == 'push' && github.ref == 'refs/heads/main'
  # NO "environment:" field → no approval gate
  steps:
    - run: terraform apply -auto-approve
```

**Why no gate for dev and staging DT changes?**

DT configuration changes in dev and staging:
- Have no direct user impact (dev/staging are not customer-facing)
- Are easily reversible (revert the PR and re-apply)
- Need to be validated in non-production before production gets the change

Requiring manual approval for dev DT changes would create friction
that makes SREs reluctant to update DT configuration frequently.
The PR review + plan review IS the approval for non-production environments.

**The production gate is the critical checkpoint:**
By the time the production apply is requested, the SRE has seen:
- Dev apply: succeeded ✅ (DT resources updated without errors)
- Staging apply: succeeded ✅ (DT resources updated without errors)
- Staging latency alerts: are they working correctly now? Check in DT UI

This evidence supports the approval decision for production.

---

## Part 5 — Race Condition: What Happens If All Three Apply Simultaneously

All three workflows merge at the same time (when the PR is merged).
They all try to call `terraform apply` for different environments.

**Is there a conflict?** No, because:
- Each environment has its own S3 state bucket (separate keys, separate files)
- Each environment has its own DynamoDB lock table (or separate table entries)
- Each environment calls different Dynatrace API endpoints (same tenant but different resource IDs)

The three applies run in parallel and do not interfere with each other.

**What if two developers merge different module changes at the same time?**

```
PR A: dev merges at 14:00 (fixes entity dimension key)
PR B: dev merges at 14:00:30 (fixes threshold formula)

Both trigger all 3 environment pipelines.
Production apply for PR A runs at 14:05.
Production apply for PR B runs at 14:05:30.

DynamoDB lock prevents these from running simultaneously:
  PR A acquires lock → applies → releases lock
  PR B waits for lock → acquires lock → applies → releases lock

No corruption. Sequential execution enforced by DynamoDB lock.
```

---

## Part 6 — Propagation Rollback: If Production Apply Reveals a New Bug

The fix looked correct in dev and staging. But in production, a different issue emerges:
the `dt.entity.service` change causes all existing Problem states to reset
(because DT creates new Problem objects when the entity dimension changes).

**How the SRE reverts:**

```bash
# Revert the commit in git
git revert <commit-sha-of-the-module-fix>
# Creates a new commit that un-does the change

git push origin main → PR → review → merge
# All 3 environment pipelines fire again, this time reverting the change
```

**Why not `terraform destroy` and re-apply?**
`terraform destroy` would delete the metric event resources entirely —
then no alerts exist at all. Revert in git → re-apply is the correct approach:
it leaves the old (buggy) configuration in place while the correct fix is
developed and re-tested.

---

## Part 7 — Without Module Paths in Triggers: The Hidden Risk

If the path triggers were:

```yaml
# WRONG: only environment paths
paths:
  - 'terraform/environments/production/**'
  # modules/ NOT listed
```

And the SRE fixed the module bug in `terraform/modules/dynatrace/main.tf`:

```
terraform-dynatrace-production.yaml: DID NOT TRIGGER
(the file that changed is in modules/, not environments/)

Result:
  Production plan: never runs
  Production apply: never runs
  Production DT: still has the wrong entity dimension key
  
The SRE would need to manually trigger the pipeline or make a fake
change to environments/production/main.tf to force a trigger.
This is error-prone and creates confusion about WHY the environment
file was touched.
```

Including `terraform/modules/dynatrace/**` in the path triggers ensures
that any module change automatically propagates to all consuming environments
in the same deployment cycle.

**The correct trigger pattern:**

```yaml
# terraform-dynatrace-production.yaml
on:
  push:
    branches: [main]
    paths:
      - 'terraform/environments/production/**'   # direct env config changes
      - 'terraform/modules/dynatrace/**'         # module changes that affect this env
```
