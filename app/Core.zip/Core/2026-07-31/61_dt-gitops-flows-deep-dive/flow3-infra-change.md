# Flow 3 — Infrastructure Change (EKS Node Size): Deep Dive
## SRE changes a Terraform variable → AWS infrastructure changes → pods keep running

---

## Decision Tree — What Changes and What Doesn't

```
SRE edits terraform/environments/production/terraform.tfvars
  node_instance_types: ["m5.xlarge"] → ["m7g.xlarge"]
        │
        ├── Does this change Kubernetes manifests in gitops/?
        │   └── NO → ArgoCD does nothing (gitops/ is unchanged)
        │
        ├── Does this change Dynatrace monitoring config?
        │   └── NO → DT Terraform pipeline does nothing
        │
        ├── Does this trigger the infra pipeline?
        │   └── YES → terraform/environments/production/** matches
        │
        └── Does this affect all 3 environments?
            └── NO → only terraform/environments/production/** changed
                      Only the production plan runs (not dev and staging)
                      
NOTE: If the SRE changed terraform/modules/eks/main.tf instead,
      ALL THREE environments would get plans (see Flow 6 for module changes).
```

---

## E2E Flow Summary

```
[SRE opens PR: m5.xlarge → m7g.xlarge in production tfvars]
        │
        ▼
[GitHub Actions: terraform-infra.yaml — plan job (matrix, parallel)]
  plan-dev     → terraform plan (dev account)     → PR comment
  plan-staging → terraform plan (staging account) → PR comment
  plan-prod    → terraform plan (prod account)    → PR comment
        │
        ▼ (human reviews all 3 plans, verifies only prod shows a change)
        │
[PR merged to main]
        │
        ▼
[apply-dev (no gate)]
  → terraform apply → dev EKS unchanged (no tfvars change in dev)
  → fast exit (no-op)
        │
        ▼
[apply-staging (needs: apply-dev)]
  → terraform apply → staging EKS unchanged
  → fast exit
        │
        ▼
[apply-production (needs: apply-staging, environment: production gate)]
  Human approval → terraform apply
  → EKS managed node group update: m5.xlarge → m7g.xlarge
  → AWS rotates nodes (terminates old, launches new)
        │
        ▼
[K8s: existing pods rescheduled on new nodes automatically]
[OneAgent DaemonSet: auto-installs on new nodes within 60s]
[ArgoCD: no change (gitops/ unchanged)]
[Dynatrace: new nodes monitored automatically]
```

---

## Part 1 — Why the Parallel Matrix Plan Runs for All 3 Environments

```yaml
# terraform-infra.yaml (plan job)
strategy:
  matrix:
    environment: [dev, staging, production]
  fail-fast: false
```

**Why run dev and staging plans when only production changed?**

The answer is: the plan for dev and staging should show "No changes."
If it shows changes you didn't expect, something is wrong:
- Another SRE made a change you didn't know about
- A module you didn't touch has a drift
- A Terraform provider upgrade changed default values

The parallel plan for all environments is a safety check, not just for production.

**`fail-fast: false`:** If the dev plan fails (e.g., state lock is held),
the staging and production plans still run. You don't want a dev issue to
block you from seeing what the production plan would do.

### What Each Plan Shows

```
plan-dev output:
  No changes. Your infrastructure matches the configuration.

plan-staging output:
  No changes. Your infrastructure matches the configuration.

plan-prod output:
  ~ module.eks.aws_eks_node_group.workers:
      ~ launch_template {
          ~ instance_types = ["m5.xlarge"] → ["m7g.xlarge"]
        }
  Plan: 0 to add, 1 to change, 0 to destroy.
```

The reviewer sees that only 1 resource changes, only in production, and it is
exactly what was intended.

---

## Part 2 — Sequential Apply: Dev → Staging → Production

```yaml
# terraform-infra.yaml (apply jobs)
apply-dev:
  if: github.event_name == 'push'
  steps:
    - run: terraform apply

apply-staging:
  needs: apply-dev    # ← will not start until apply-dev succeeds
  steps:
    - run: terraform apply

apply-production:
  needs: apply-staging   # ← will not start until apply-staging succeeds
  environment: production  # ← manual approval gate
  steps:
    - run: terraform apply
```

**Why sequential (not parallel like the plan)?**

The plan can safely run in parallel — it makes no changes.
The apply MUST be sequential because:

1. **Dev is the canary for infra changes.** If the m7g.xlarge instance type
   has a configuration issue (wrong AMI, incompatible kernel version for the
   OneAgent, missing EBS optimization flag), dev will fail first.
   Staging and production are never touched.

2. **Prevents racing state writes.** If dev and prod apply simultaneously
   and both try to write to the same S3 state bucket prefix (even in separate
   keys), DynamoDB locking handles it — but it wastes time with lock contention.

3. **Provides rollback signal.** If dev apply succeeds but staging fails,
   the SRE knows the m7g instance works in dev (validated) but something
   is different between dev and staging (different IAM permissions, subnet
   configuration, etc.).

---

## Part 3 — What Happens in AWS During the Node Rotation

When Terraform applies `instance_types = ["m7g.xlarge"]` to the EKS managed node group:

### Phase 1: AWS Creates the Launch Template Update

```
AWS EKS Managed Node Group update process:
  1. AWS creates a new Launch Template version with m7g.xlarge
  2. AWS verifies the new instance type is available in all configured AZs
  3. AWS begins rotating nodes: launches new m7g nodes, terminates old m5 nodes
     in batches (typically 33% at a time for a 3-AZ cluster)
```

### Phase 2: Kubernetes Handles Pod Migration Transparently

```
Node rotation event:
  1. AWS cordons the old node (new pods will not be scheduled here)
  2. AWS drains the old node (existing pods are evicted)
     → Eviction respects PodDisruptionBudgets (PDBs)
     → Services with PDB: minAvailable=1 → at least 1 pod must stay running
     → Karpenter/cluster-autoscaler adds new capacity before eviction if needed

  3. Pods are rescheduled on new m7g nodes
     → Kubernetes scheduler picks the least-loaded new node
     → Pod starts, passes readinessProbe
     → Added to Service endpoints
     → Old pod on old node terminates

  4. Old m5 node is terminated by AWS
```

**Does ArgoCD do anything?** No. The Deployment spec in gitops/ does not reference
specific nodes. Kubernetes handles pod scheduling transparently. ArgoCD only
manages the desired state (the Deployment) — it does not manage where pods run.

### Phase 3: OneAgent Automatically Installs on New Nodes

```
New m7g node starts:
  1. K8s DaemonSet controller detects: new node exists, DaemonSet pod not on it
  2. Creates OneAgent pod on the new node
  3. OneAgent pod starts: downloads DT agent components from ECR cache
  4. Within 60 seconds: new node is fully monitored
  
  No manual action needed. DaemonSet + DynaKube CRD handles this automatically.
```

---

## Part 4 — Why m5.xlarge → m7g.xlarge Is Not Trivial

This looks like a simple value change, but has several implications the SRE
must understand before approving the plan:

**Architecture difference:**
- `m5.xlarge`: Intel x86_64
- `m7g.xlarge`: ARM Graviton3

Docker images must be multi-arch (`linux/amd64 + linux/arm64`).
If only `linux/amd64` images exist in ECR, pods will fail to schedule on m7g nodes
with `ErrImagePull: no matching manifest for linux/arm64`.

**The protection in this system:** CI builds multi-arch images (Flow 1 Part 3, Step 2).
Every image in ECR has both `amd64` and `arm64` manifests.

**Java performance note:** AWS Graviton3 is typically 40% faster and 60% cheaper
per unit of performance for Java workloads compared to Intel m5. This is the main
reason SREs make this change.

**OneAgent compatibility:** The DynaKube CRD specifies the OneAgent image tag.
The Dynatrace-provided OneAgent image is already multi-arch. No change needed there.

---

## Part 5 — The Production Approval Gate in Detail

```yaml
apply-production:
  needs: apply-staging
  environment: production
```

**The human reviewer checks before approving:**
1. Did `apply-dev` succeed? (GitHub shows green checkmark)
2. Did `apply-staging` succeed? (green checkmark)
3. Is the production plan showing exactly what was expected? (linked in the PR)
4. Is this change scheduled during a maintenance window?
5. Are the on-call engineers aware and ready to respond if something breaks?

**Timing considerations:**
- EKS node rotation takes 15–30 minutes for a typical 6-node cluster
- Graviton nodes take longer to start than Intel (different boot sequence, ARM AMI)
- The approval should happen during business hours with the SRE team available

**After applying:** The `terraform apply` command exits when the node group
update is SUBMITTED to AWS, not when it completes. AWS manages the rotation
asynchronously. The SRE must monitor the EKS console or use `kubectl get nodes -w`
to track completion.

---

## Part 6 — Dynatrace During Node Rotation: What You See

During the 15–30 minute node rotation window, Dynatrace shows:

```
Infrastructure → Hosts view:
  node-001 (m5.xlarge): MONITORED → UNAVAILABLE (being terminated)
  node-007 (m7g.xlarge): NEW → MONITORED (just came up)

Services view (payment-service):
  Entity health: HEALTHY (pods migrated successfully)
  Throughput: may show brief 5-10% dip during pod migration
  Latency: may show brief spike as new pods warm up JIT/JVM caches

Problems:
  If PDB is respected and rolling replacement is smooth:
    → No Problems open
  If a pod fails to start on m7g (e.g., missing arm64 image):
    → Metric event: availability drops
    → Problem opens: "[PRODUCTION] payment-service: Availability drop"
    → PagerDuty fires → SRE investigates
```

**The monitoring safety net:** If the node migration causes problems,
Dynatrace catches it within 3 minutes. The SRE can rollback by
changing `m7g.xlarge` back to `m5.xlarge` in Terraform (another PR → apply).
