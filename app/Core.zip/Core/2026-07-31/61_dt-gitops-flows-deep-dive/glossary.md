# 61 — DT GitOps Flows: Glossary

Every term from all 7 flows and the dependency/state sections, explained for an SRE beginner.

---

**GitOps**
A practice where the desired state of your infrastructure and applications is stored in a git repository, and automated systems continuously reconcile the real environment to match what git says. Git is the single source of truth — you never make changes directly; you always change git first.

**ArgoCD**
A Kubernetes-native tool that continuously monitors a git repository and ensures the Kubernetes cluster matches the YAML files stored there. When you push new code to git, ArgoCD detects the change and applies it to the cluster automatically. Runs inside the cluster itself.

**Sync Wave (`argocd.argoproj.io/sync-wave`)**
An ArgoCD annotation that controls the order in which resources are deployed. Wave -1 deploys before wave 0, which deploys before wave 1, and so on. Used to ensure prerequisites (like namespaces or CRD-installing operators) exist before the things that depend on them.

**App of Apps Pattern**
An ArgoCD pattern where one "root" Application manages a directory of other Application YAML files. Applying a single root Application causes ArgoCD to discover and manage all child Applications automatically. You apply one file manually; everything else is automated.

**`selfHeal: true` (ArgoCD)**
An ArgoCD setting that automatically reverts manual changes to the Kubernetes cluster. If an SRE runs `kubectl set image ...` to change a pod image directly, ArgoCD detects the cluster no longer matches git and immediately reverts the change within 3 minutes.

**`prune: true` (ArgoCD)**
An ArgoCD setting that deletes Kubernetes resources that have been removed from git. If you delete a Deployment YAML from gitops/, ArgoCD will delete the actual Deployment from the cluster on the next sync.

**Helm**
A package manager for Kubernetes. Instead of writing raw YAML manifests for every resource, you write a Helm chart (templates + values files) that renders into the final YAML at deploy time. Different environments use different values files (values-dev.yaml, values-prod.yaml) with the same templates.

**`helm template`**
The Helm command that renders the final YAML from a chart + values without deploying anything. ArgoCD runs this internally to compute what Kubernetes resources should exist, then compares to the running state to detect what needs to change.

**Rolling Update**
A Kubernetes deployment strategy where new pods are added one at a time and old pods are removed one at a time, ensuring that some pods are always running throughout the update. Zero downtime if configured correctly. Controlled by `maxUnavailable` and `maxSurge` parameters.

**`maxUnavailable: 0`**
Rolling update setting meaning: never take down an old pod until its replacement is fully ready. Guarantees that the service always has its full desired pod count serving traffic, even during updates.

**`maxSurge: 1`**
Rolling update setting meaning: allow one extra pod beyond the desired count during the update. This is what permits the new pod to start (as the extra) before the old one is removed.

**startupProbe**
A Kubernetes health check that runs only during pod startup. If it fails `failureThreshold` times, Kubernetes kills the pod. Configured with a long timeout (e.g., 20 minutes for Java) to give Spring Boot time to warm up without Kubernetes falsely thinking it crashed.

**readinessProbe**
A Kubernetes health check that signals to Kubernetes whether a pod should receive traffic. Only pods that pass readinessProbe are added to Service endpoints (i.e., reachable by the load balancer). Failed readinessProbe = pod is removed from traffic but NOT restarted.

**livenessProbe**
A Kubernetes health check that signals whether a pod is still alive. A failed livenessProbe causes Kubernetes to restart the pod. Used to recover from deadlocks or other states where the JVM is running but cannot process requests.

**preStop hook**
A lifecycle hook that runs before a pod receives SIGTERM. In this system: `sleep 15` — waits 15 seconds before starting shutdown, allowing the load balancer to remove the pod from its target group and in-flight requests to complete.

**Spring Boot Graceful Shutdown**
A Spring Boot feature that, when the JVM receives SIGTERM, waits for in-progress HTTP requests to complete (up to the configured timeout) before shutting down. Prevents "connection reset" errors during rolling updates.

**`/actuator/health`**
A Spring Boot endpoint exposed by the Spring Actuator library. Returns the health status of the application in JSON: `{"status": "UP"}`. Used by Kubernetes probes. `/actuator/health/readiness` and `/actuator/health/liveness` are separate sub-endpoints for the two probe types.

**GitHub Actions**
GitHub's built-in CI/CD system. Workflows are YAML files in `.github/workflows/`. They run when triggered by events (push, pull_request, schedule). Each workflow has jobs, each job has steps. Jobs can run in parallel (default) or sequentially (`needs:` field).

**Path Filter (`paths:` in GitHub Actions)**
A trigger condition that only fires the workflow if specific file paths were changed. Used to ensure the payment-service CI only runs when payment-service code changes, not when order-service changes. Prevents unnecessary CI runs.

**OIDC (OpenID Connect) in GitHub Actions**
A mechanism where GitHub generates a signed JWT for each workflow run, and AWS IAM verifies this JWT to grant temporary credentials. Eliminates the need to store long-lived `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` secrets in GitHub. Credentials expire in 1 hour.

**`[skip ci]`**
A conventional string placed in a git commit message that tells GitHub Actions not to trigger CI workflows for that commit. Used when CI itself commits to git (e.g., updating gitops/ with a new image tag) to prevent infinite trigger loops.

**`sed -i`**
A Unix command that edits a file in-place (modifies the file without creating a new one). In the CI pipeline: `sed -i "s|tag: \"old\"|tag: \"new\"|" file.yaml` replaces the old image tag with the new one directly in the gitops/ YAML file.

**Trivy**
An open-source vulnerability scanner for Docker images. Scans OS packages and application dependencies for known CVEs. In this pipeline: if a CRITICAL or HIGH CVE is found, the pipeline stops and the image is never deployed.

**CVE (Common Vulnerabilities and Exposures)**
A unique identifier for a known security vulnerability. Examples: CVE-2021-44228 (Log4Shell). Trivy checks Docker images against databases of known CVEs.

**ECR (Elastic Container Registry)**
AWS's managed Docker image registry. Images are stored per AWS account (dev account has dev ECR, prod account has prod ECR). Images are pushed by CI and pulled by Kubernetes when pods start.

**Multi-Arch Image (`linux/amd64 + linux/arm64`)**
A Docker image that contains layers for both Intel x86_64 and ARM64 (Graviton) architectures, stored under a single tag. When a pod pulls the image, Docker automatically selects the correct architecture for the node it's running on.

**Graviton (AWS)**
AWS's ARM-based server processors. Typically 40% faster and 60% more cost-effective per unit of compute for Java workloads compared to Intel equivalents. Instance type names include 'g' suffix: m7g, c7g, r7g.

**IRSA (IAM Roles for Service Accounts)**
A Kubernetes mechanism that allows a pod to assume an AWS IAM role based on its Kubernetes Service Account, using the EKS OIDC provider. No credentials stored in the pod — the identity is asserted by Kubernetes itself. Each service gets its own minimal IAM role.

**Terraform Module**
A reusable package of Terraform code that can be called multiple times with different inputs. In this system: the `dynatrace` module is called by dev, staging, and production environments — each environment passes different thresholds, target percentages, and alert channels.

**`terraform plan`**
A Terraform command that shows what changes would be made without actually making them. The diff output shows: `+` (add), `~` (change), `-` (destroy). Used in CI to produce a review document before any real changes are made.

**`terraform apply`**
A Terraform command that makes the planned changes real — creating, updating, or deleting cloud resources. In CI, runs automatically (dev/staging) or after human approval (production).

**`terraform plan -refresh-only`**
A Terraform command variant that ONLY shows changes that happened outside Terraform (drift) — not changes from your .tf files. The clean signal for "what changed in AWS/DT that Terraform doesn't know about?"

**`-detailed-exitcode`**
A `terraform plan` flag that changes the exit code behavior: 0=no changes, 1=error, 2=changes found. Used by drift detection to distinguish "no drift" (exit 0) from "drift found" (exit 2) in CI shell scripts.

**Terraform State File**
A JSON file stored in S3 that records what resources Terraform currently manages and their current attribute values. Required for Terraform to know what exists, what needs updating, and what was deleted. Losing the state file means Terraform loses track of everything it manages.

**DynamoDB State Lock**
An AWS DynamoDB table entry that prevents two `terraform apply` commands from running simultaneously. The first apply writes a lock record; the second sees the lock and waits (or fails). Prevents state file corruption from concurrent applies.

**Terraform `ignore_changes`**
A lifecycle block that tells Terraform to ignore changes to specific attributes. Used for resources managed by external processes (autoscalers change `desired_size`). Without it, auto-scaling activity would appear as drift every day.

**Drift (Terraform)**
The difference between what Terraform's state file records and what actually exists in AWS/DT. Drift occurs when resources are changed outside Terraform (manual AWS Console changes, auto-scaling, external processes).

**GitHub Environment (Production Gate)**
A GitHub Actions feature that pauses a job until a designated reviewer approves it. The `environment: production` line in a workflow triggers an approval email to required reviewers. Only after they approve does the job continue. Prevents untested changes from reaching production without human sign-off.

**DynaKube (Custom Resource)**
A Kubernetes Custom Resource defined by the Dynatrace Operator. Describes how Dynatrace should be deployed in the cluster: which nodes to put OneAgent on, how many ActiveGate replicas, which DT tenant to connect to, and where to find the authentication tokens.

**DaemonSet**
A Kubernetes resource that ensures exactly one pod runs on every node in the cluster (or a subset matching node selectors). OneAgent is deployed as a DaemonSet so every node is monitored. When new nodes are added, Kubernetes automatically schedules a DaemonSet pod on them.

**OneAgent**
Dynatrace's monitoring agent. Deploys as a DaemonSet pod on every Kubernetes node. Instruments JVMs via JVMTI, captures HTTP request metrics, distributed traces, and exceptions. Sends data to the ActiveGate, which forwards to the DT SaaS tenant.

**JVMTI (Java Virtual Machine Tool Interface)**
A low-level Java API that allows external programs (like OneAgent) to attach to a running JVM and instrument bytecode. OneAgent uses JVMTI to intercept method calls (like JDBC execute(), HTTP handler calls) without modifying application source code.

**ActiveGate**
A Dynatrace component that acts as a local relay/proxy between OneAgents in the cluster and the DT SaaS tenant. Buffers metrics, compresses data, and handles authentication. Deployed as a Deployment (not DaemonSet) with 2+ replicas for high availability.

**ESO (External Secrets Operator)**
A Kubernetes operator that reads secrets from external secret stores (AWS Secrets Manager, HashiCorp Vault, etc.) and creates Kubernetes Secret objects. Keeps K8s secrets in sync with the external store. Configured via ClusterSecretStore and ExternalSecret custom resources.

**ClusterSecretStore**
An ESO custom resource that configures how to connect to an external secrets store (e.g., AWS Secrets Manager in the dev account using IRSA). Cluster-scoped: any namespace can use it. Must exist before any ExternalSecret resource.

**ExternalSecret**
An ESO custom resource that specifies which external secret to fetch and which Kubernetes Secret to create. Example: "fetch `dev/dynatrace/api-token` from Secrets Manager and create K8s Secret `dynakube` with field `apiToken`."

**Management Zone (Dynatrace)**
A filter in Dynatrace that groups entities (services, hosts, processes) that share a tag. Example: `payments-production` management zone includes all entities tagged `team:payments` AND `environment:production`. Alerting profiles and dashboards can be scoped to a management zone.

**Metric Event (Dynatrace)**
A Dynatrace alert rule that monitors a specific metric and creates a "Problem" when the metric exceeds a threshold for N consecutive evaluation cycles. The core alerting mechanism in DT. Configured with entity filters, thresholds, and violation sample counts.

**`violating_samples` / `dealerting_samples`**
Metric event settings that require the metric to exceed the threshold N times before opening a Problem (`violating_samples = 3`), and to be below the threshold N times before closing it (`dealerting_samples = 3`). Prevents alert flapping from momentary spikes.

**Problem (Dynatrace)**
A Dynatrace event that represents a detected issue. Created automatically when metric events fire, synthetic checks fail, or anomaly detection triggers. Problems are enriched with root cause analysis, related changes, affected entities, and correlated traces.

**Alerting Profile (Dynatrace)**
A Dynatrace rule that filters which Problems trigger notifications and with what delay. Different profiles route different severities (AVAILABILITY, ERROR, PERFORMANCE) to different channels (PagerDuty, Slack) with different delays.

**`delay_in_minutes` (Alerting Profile)**
How long Dynatrace waits after a Problem is created before sending a notification. 0 = immediate. 2 = wait 2 minutes before paging. Used to avoid waking up on-call for Problems that resolve within a few minutes on their own.

**SLO (Service Level Objective)**
An internal reliability target. In DT: configured to measure what percentage of time a metric stays within acceptable bounds. Calculated over a rolling time window (e.g., 30 days). Used at monthly SLO reviews to determine if reliability targets are being met.

**Error Budget**
The allowed amount of SLO non-compliance. 99.9% availability SLO = 0.1% allowed non-compliance = 43.2 minutes per month. Consumed by incidents. When exhausted, risky changes (deployments) should pause until the budget recovers.

**`builtin:service.errors.server.rate`**
A Dynatrace built-in metric that measures the percentage of HTTP requests to a service that return 5xx status codes (server-side errors). Automatically calculated by OneAgent from instrumented JVMs. The key metric for error rate alerting.

**`builtin:service.response.time`**
A Dynatrace built-in metric that measures the duration of HTTP requests to a service. Used for latency alerting (`percentile(99)` = p99 latency). Automatically measured by OneAgent at the HTTP handler level.

**`dt.entity.service`**
The Dynatrace entity dimension key for HTTP service entities. Must match the entity type of the metric being monitored. `builtin:service.response.time` is a SERVICE metric → entity dimension must be `dt.entity.service`. Using the wrong entity type causes mismatched alerting.

**PagerDuty Integration Key**
A secret key that authorizes Dynatrace to create incidents in a specific PagerDuty service. Stored in AWS Secrets Manager, read by Terraform at apply time. Each team (payments, orders) has its own integration key pointing to their on-call rotation.

**`spring.application.name`**
A Spring Boot property (set in `application.properties`) that gives the application a human-readable name. OneAgent reads this value and uses it as the Dynatrace service entity name. Critical: if this is wrong, the DT entity name doesn't match the management zone filter, and alerts are misconfigured.

**k6**
An open-source load testing tool from Grafana Labs. Used in the staging pipeline (`test-staging` job) to simulate 50 virtual users for 3 minutes and verify the service can handle realistic load before promoting to production.

**`terraform plan -refresh-only -detailed-exitcode -no-color`**
The complete drift detection command. `-refresh-only`: only show real-world vs state drift. `-detailed-exitcode`: exit 2 if drift found. `-no-color`: removes ANSI color codes so the output can be stored in a file and included in a GitHub Issue body without formatting artifacts.

**`PIPESTATUS`**
A Bash array that captures the exit codes of all commands in a pipeline. `cmd1 | cmd2`: `${PIPESTATUS[0]}` = exit code of `cmd1`, `${PIPESTATUS[1]}` = exit code of `cmd2`. Used to capture Terraform's exit code even when its output is piped to `tee`.

**`tee`**
A Unix command that reads from stdin and writes to BOTH a file and stdout simultaneously. `terraform plan ... | tee drift.txt` shows the output in the terminal AND saves it to `drift.txt` for use in the GitHub Issue body.

**`aws eks update-kubeconfig`**
An AWS CLI command that adds the EKS cluster credentials to your local `~/.kube/config` file, allowing `kubectl` commands to connect to the cluster. Run once per cluster, per developer workstation. Output by `terraform output kubeconfig_command`.

**NAT Gateway (per-AZ)**
An AWS managed service that allows resources in private subnets to reach the internet (for outbound calls) without being directly accessible from the internet. Using one per availability zone (rather than one total) provides fault isolation: if one AZ has issues, the other AZs' outbound traffic is unaffected.

**`domainFilters` (ExternalDNS)**
A configuration setting that restricts ExternalDNS to only create DNS records for hostnames in specific domains. `domainFilters: ["dev.company.com"]` prevents the dev cluster's ExternalDNS from accidentally creating or deleting DNS records for `company.com` or `staging.company.com`.

**`txtOwnerId` (ExternalDNS)**
A unique identifier that ExternalDNS writes into Route53 TXT records to "claim ownership" of DNS entries it manages. When multiple clusters use the same Route53 zone, each cluster has a different `txtOwnerId`. This prevents the dev cluster from deleting DNS records owned by the staging cluster.

**`fail-fast: false` (GitHub Actions matrix)**
A GitHub Actions strategy setting that prevents the entire matrix job from stopping if one matrix variant fails. `fail-fast: false` means all three environment plans complete even if one fails. This lets the reviewer see all plans, not just the first failing one.
