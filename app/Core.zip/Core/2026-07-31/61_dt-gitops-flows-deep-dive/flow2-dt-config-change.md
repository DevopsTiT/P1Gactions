# Flow 2 — DT Config Change (Threshold Tuning): Deep Dive
## SRE edits a Terraform value → Dynatrace alert changes without touching code

---

## Decision Tree — Which Pipeline Fires

```
SRE edits terraform/environments/production/main.tf
        │
        ├── Which paths does this match?
        │   └── terraform/environments/production/**  → YES
        │   └── terraform/modules/dynatrace/**        → NO (main.tf, not a module)
        │
        └── Which workflows have this path trigger?
            └── terraform-dynatrace-production.yaml   → FIRES
            └── terraform-infra.yaml                  → NO (different path filter)
```

---

## E2E Flow Summary

```
[SRE opens PR: payment-service.latency_p99_ms: 300 → 400]
        │
        ▼
[GitHub Actions: terraform-dynatrace-production.yaml — plan job]
  OIDC → read-only plan role
  terraform init → S3 state backend
  terraform plan → shows exactly what DT resources change
  Posts plan as PR comment
        │
        ▼ (human reviews plan comment, approves PR)
        │
[PR merged to main]
        │
        ▼
[GitHub Actions: apply job]
  Pauses at "environment: production" gate
  Human approves the deployment
        │
        ▼
[terraform apply → Dynatrace REST API PUT calls]
  → Metric event threshold: 300000µs → 400000µs
  → SLO metric expression: le(...,300000) → le(...,400000)
        │
        ▼
[Dynatrace tenant: new threshold in effect immediately]
  All subsequent metric evaluations use 400ms threshold
```

---

## Part 1 — The Terraform Change: What the SRE Edits

The SRE opens `terraform/environments/production/main.tf` and finds:

```hcl
# terraform/environments/production/main.tf  (before)
module "dynatrace" {
  source = "../../modules/dynatrace"

  services = {
    "payment-service" = {
      latency_p99_ms  = 300     # ← this is what the SRE changes
      error_rate_pct  = 0.1
      availability_pct = 99.9
    }
    "order-service" = {
      latency_p99_ms  = 500
      error_rate_pct  = 0.2
      availability_pct = 99.5
    }
  }
}
```

The SRE changes `latency_p99_ms = 300` to `latency_p99_ms = 400`.

**Why would an SRE make this change?**

Common reasons:
1. The service legitimately got slower after a feature addition (more DB queries).
   The old threshold causes constant false-positive alerts on healthy behavior.
2. Load test results show p99 is normally 380ms — the 300ms threshold fires
   on every traffic spike even without a real problem.
3. The business decided that 400ms p99 is acceptable for this endpoint.

**The wrong way to handle this:** Silence the alert in PagerDuty.
This hides the alert without fixing the root cause and leaves the threshold wrong
in Terraform — making the next SRE who reads the code confused.

**The right way:** Update the threshold in Terraform. It is now code-reviewed,
version-controlled, and the reason is in the PR description.

---

## Part 2 — What the Plan Job Does and Why It Posts to the PR

### The Plan Job Authentication

```yaml
# terraform-dynatrace-production.yaml (plan job)
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789012:role/github-actions-dynatrace-plan
```

The `dynatrace-plan` role has an IAM policy that allows it to:
- Read from the S3 state bucket (to load current state)
- Read from DynamoDB (state locking table)
- Call Dynatrace API read-only operations (via Terraform provider)

It does NOT have permission to write to S3 (cannot update state) or
call Dynatrace API write operations. So `terraform plan` is read-only.

**Why a separate plan role?** Principle of least privilege.
A plan-only role can safely be used in a pull request context
where untrusted code could potentially be submitted.

### What terraform plan Outputs

```
# Plan posted as GitHub PR comment:

Terraform will perform the following actions:

  ~ dynatrace_metric_events.latency_p99["payment-service"]
      + threshold: 300000 → 400000

  ~ dynatrace_slo_v2.latency["payment-service"]
      metric_expression: "100*(... le(value,300000) ...)/(total)"
                      → "100*(... le(value,400000) ...)/(total)"

Plan: 0 to add, 2 to change, 0 to destroy.
```

**Why `300000` not `300`?** The Dynatrace API expects microseconds (µs).
300ms × 1000 = 300,000µs. In the Terraform module, the conversion happens:

```hcl
# terraform/modules/dynatrace/main.tf
resource "dynatrace_metric_events" "latency_p99" {
  for_each = var.services
  threshold = each.value.latency_p99_ms * 1000   # ms → µs
}
```

**The PR reviewer checks:**
- Is the plan diff what we expected? (Only 2 resources change, not 20)
- Is the direction correct? (300 → 400, not 400 → 300)
- Is the justification in the PR description? (Why is 400ms acceptable now?)

---

## Part 3 — The Apply Job: Manual Approval Gate Details

```yaml
# terraform-dynatrace-production.yaml (apply job)
apply:
  needs: plan
  if: github.event_name == 'push' && github.ref == 'refs/heads/main'
  environment: production   # ← PAUSE HERE
  steps:
    - uses: aws-actions/configure-aws-credentials@v4
      with:
        role-to-assume: arn:aws:iam::123456789012:role/github-actions-dynatrace-apply
```

**The `environment: production` line does three things:**
1. GitHub pauses the job and sends a review request email to required reviewers
2. The reviewer sees the job URL, clicks "Review deployments", clicks "Approve"
3. Only after approval does the job start running

**The apply role has write permissions:**
- Can write to the S3 state bucket (updates state after apply)
- Can write to DynamoDB (acquires state lock)
- Can call Dynatrace API write operations (PUT, POST, DELETE)

**State locking with DynamoDB:** When `terraform apply` starts, it writes a lock
record to DynamoDB. If a second apply starts simultaneously (e.g., two PRs merged
at the same time), the second one reads the lock and waits (or fails after timeout).
This prevents two applies from corrupting the state file simultaneously.

---

## Part 4 — What terraform apply Does to Dynatrace

When Terraform calls the Dynatrace provider to update the metric event:

```
Terraform Provider reads current state:
  state file: dynatrace_metric_events.latency_p99["payment-service"]
    id = "abc123-uuid-from-dynatrace-api"
    threshold = 300000

Terraform Provider computes: need to update id=abc123 to threshold=400000

Terraform Provider makes API call:
  PUT https://YOUR_TENANT.live.dynatrace.com/api/v2/settings/objects/abc123
  Body: {
    "schemaId": "builtin:anomaly-detection.metric-events",
    "value": {
      "queryDefinition": {
        "metricSelector": "builtin:service.response.time:percentile(99)...",
        "threshold": 400000,
        ...
      }
    }
  }
  
  Response: 200 OK

Terraform updates state file:
  threshold = 400000   ← now matches what's in Dynatrace
```

**What happens to in-progress alerts?** If a Problem is currently open because
latency was between 300ms–400ms (i.e., above old threshold but below new threshold),
Dynatrace re-evaluates immediately after the threshold change.
If the current value is now below the new threshold, the Problem closes within
3 evaluation cycles (3 minutes).

---

## Part 5 — The SLO Change: Why Two Resources Change Together

When you change `latency_p99_ms`, both a metric event AND an SLO change:

**The metric event** controls alerting:
> "Fire a Problem if p99 latency exceeds 400ms for 3 consecutive minutes."

**The SLO** controls compliance measurement:
> "Measure: what % of time is p99 latency below 400ms? Target: 95%."

These must use the same threshold. If the metric event says "alert above 400ms"
but the SLO says "measure below 300ms", you have contradictory monitoring:
- The SLO is showing compliance violations that don't result in alerts
- Engineers are confused about which number is "the real target"

The Terraform module enforces consistency by computing both from the same variable:

```hcl
# terraform/modules/dynatrace/main.tf

# Metric event: alerts when threshold breached
resource "dynatrace_metric_events" "latency_p99" {
  threshold = var.latency_p99_ms * 1000   # single source of truth
}

# SLO: measures compliance against same threshold
resource "dynatrace_slo_v2" "latency" {
  metric_expression = "100*(builtin:service.response.time:percentile(99):filter(le(value,${var.latency_p99_ms * 1000})))/(builtin:service.response.time:percentile(99))"
}
```

Changing `latency_p99_ms` in one place cascades to both resources automatically.
The SRE never needs to remember to update the SLO when they update the alert threshold.

---

## Part 6 — After Apply: Dynatrace Evaluation Loop

Dynatrace evaluates metric events every 60 seconds. The evaluation logic:

```
14:30:00 — terraform apply completes, threshold updated to 400000µs

14:31:00 — DT evaluation cycle:
  metric: builtin:service.response.time:percentile(99)
  filter: dt.entity.service = "payment-service" AND environment = "production"
  current value: 380000µs (380ms)
  threshold: 400000µs (new)
  380000 < 400000 → NOT in violation

  IF this service had an OPEN Problem for "latency_p99 > 300ms":
    Problem is re-evaluated: 380ms is now BELOW the new threshold
    → Problem state transitions to CLOSED
    → Resolution notification fires:
        Slack: "[PRODUCTION] RESOLVED | payment-service latency — threshold relaxed"
```

**What if the SRE made a mistake and set the threshold too high (e.g., 30000ms)?**
The drift detection job runs daily. But more importantly, the PR review process
should have caught this. This is why requiring a human review of the plan output
is not bureaucracy — it is the last safety net before a monitoring gap opens.
