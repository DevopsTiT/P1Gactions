# Dependency Web and State Map: Deep Dive
## What depends on what, and where truth lives in each system

---

## Part 1 — The Full Dependency Chain Explained

Every line in the dependency web means: "X cannot work without Y."
This section explains WHY each dependency exists and what breaks if the order is wrong.

---

### Dependency 1: S3 + DynamoDB → terraform init

```
S3 bucket (company-terraform-state-prod):
  WHY NEEDED: Terraform stores its state file here.
  The state file is the record of what Terraform currently manages.
  Without a state backend, Terraform stores state locally — which breaks
  team collaboration (two SREs can't share the same local state file).

DynamoDB table (terraform-state-locks):
  WHY NEEDED: State locking.
  When two Terraform applies run simultaneously, both would read the state,
  compute changes, and overwrite each other's updates — corrupting the state file.
  DynamoDB provides a distributed lock: the first apply acquires the lock,
  the second waits. Prevents race conditions.

terraform init reads terraform backend block:
  terraform {
    backend "s3" {
      bucket         = "company-terraform-state-prod"
      key            = "production/terraform.tfstate"
      region         = "ap-northeast-1"
      dynamodb_table = "terraform-state-locks"
    }
  }
  → Downloads providers, verifies S3 access, verifies DynamoDB access.
  → If either is missing: terraform init fails. No plan or apply is possible.
```

**Who creates S3 and DynamoDB?**
They CANNOT be created by Terraform itself (chicken-and-egg: Terraform needs them
to run, but Terraform would need to run to create them). They are created manually
or by a separate bootstrapping process before any Terraform work begins.

---

### Dependency 2: terraform apply → EKS cluster

```
EKS cluster MUST exist before:
  - kubectl commands work
  - ArgoCD can be installed
  - Any Kubernetes resource can be created

If an SRE tries to run kubectl before terraform apply creates the cluster:
  error: the server was unable to return a response
  (No server exists to connect to)

terraform apply outputs:
  cluster_endpoint   = "https://ABCDEF.gr7.ap-northeast-1.eks.amazonaws.com"
  cluster_name       = "company-production"
  oidc_issuer_url    = "https://oidc.eks.ap-northeast-1.amazonaws.com/id/ABCDEF"
  kubeconfig_command = "aws eks update-kubeconfig --name company-production --region ap-northeast-1"
```

**The OIDC issuer URL is critical:** It enables IRSA (IAM Roles for Service Accounts).
IRSA allows pods to call AWS APIs without stored credentials — using the EKS cluster's
identity provider. Without the OIDC issuer, no IRSA role can be created, and
service accounts cannot access AWS APIs.

---

### Dependency 3: kubectl access → ArgoCD install

```
ArgoCD is installed via:
  kubectl apply -n argocd -f https://.../install.yaml

This command sends 50+ Kubernetes resource manifests to the cluster API server.
Without kubectl access (which requires the EKS cluster to exist),
ArgoCD cannot be installed.

ArgoCD creates in the cluster:
  - 5 deployments (server, application-controller, dex, redis, repo-server)
  - 10+ RBAC resources (ClusterRoles, ClusterRoleBindings)
  - Custom Resource Definitions (Application, AppProject, ApplicationSet)
  - ConfigMaps and Secrets for ArgoCD configuration
```

---

### Dependency 4: ArgoCD running → root-app-dev.yaml apply

```
root-app-dev.yaml creates:
  apiVersion: argoproj.io/v1alpha1
  kind: Application   ← This is a Custom Resource defined by ArgoCD

If ArgoCD is not running:
  - The CRD "Application" does not exist
  - kubectl apply -f root-app-dev.yaml fails:
    error: unable to recognize "root-app-dev.yaml":
    no matches for kind "Application" in version "argoproj.io/v1alpha1"

After ArgoCD installs its CRDs, the "Application" kind exists.
root-app-dev.yaml can be applied.
ArgoCD detects the new Application and immediately begins syncing gitops/dev/.
```

---

### Dependency 5: Wave -1 Namespaces → Wave 2 ESO

```
External Secrets Operator deploys into namespace: external-secrets
If the external-secrets namespace doesn't exist, the ESO Helm chart install fails:
  Error: namespaces "external-secrets" not found

Wave -1 creates all required namespaces (including external-secrets).
Only after wave -1 completes does ArgoCD start wave 2.

Also: DT auto-tagging depends on namespace labels (wave -1).
If wave 8 services deployed before wave -1:
  - Pods start in unlabeled namespaces
  - OneAgent reads no team/environment labels
  - DT entities have no tags
  - Management zones include nothing
  - Alerts fire to nobody (no management zone match)
```

---

### Dependency 6: Wave 2 ESO → Wave 3 ExternalSecret

```
ExternalSecret is a Custom Resource defined by ESO.
If ESO is not installed (no CRD), creating an ExternalSecret fails.

ClusterSecretStore (also wave 2) must be Healthy before ExternalSecrets can work:
  ClusterSecretStore polls AWS Secrets Manager API to verify connectivity.
  Status: Ready = true → ESO can now fetch secrets from AWS Secrets Manager.

When ExternalSecret "dynakube-tokens" is processed:
  ESO reads the spec:
    secretStoreRef: cluster-secret-store
    data[0]: key: dev/dynatrace/api-token → secretKey: apiToken
    data[1]: key: dev/dynatrace/data-ingest-token → secretKey: dataIngestToken

  ESO calls AWS Secrets Manager API:
    GET /v2/secret?secretId=dev/dynatrace/api-token
    → Returns the actual DT API token value

  ESO creates K8s Secret:
    apiVersion: v1
    kind: Secret
    metadata:
      name: dynakube
    data:
      apiToken: <base64-encoded token>
      dataIngestToken: <base64-encoded token>
```

**What if the DT token is wrong or expired?**
The ExternalSecret status shows `SecretSyncError`. The DynaKube CRD cannot authenticate
to the DT tenant. OneAgent DaemonSet is never deployed. Services run but are NOT monitored.
This is a silent failure — pods appear healthy but no metrics flow to DT.

---

### Dependency 7: Wave 3 DynaKube → Wave 8 Java Services

```
Why must OneAgent be on the node BEFORE the Java service starts?

OneAgent instruments JVMs via JVMTI (Java Virtual Machine Tool Interface).
JVMTI is an attach API — it can attach to a running JVM.

BUT: if the JVM starts before OneAgent, the earliest bytecode-level
instrumentation is missed. Some startup events (class loading, initial
DB pool creation) happen before OneAgent can attach.

DynaKube deploys OneAgent as a DaemonSet — one pod per node.
DaemonSet pods start before regular workload pods (lower priority class,
but DaemonSet pods get node affinity that schedules them first).

When the payment-service pod starts:
  1. Kubernetes starts the container
  2. Java JVM starts (from the Spring Boot fat JAR)
  3. OneAgent (already running on the node) detects the new JVM via /proc scan
  4. OneAgent attaches via JVMTI before application classes are fully loaded
  5. OneAgent instruments: HTTP handlers, JDBC drivers, transaction managers
  6. All application behavior is captured from the first request

Without wave ordering: if payment-service deployed before OneAgent,
the first startup events (JVM init, Spring context creation, initial DB pool)
would not be instrumented. Service entity might not even be created correctly.
```

---

## Part 2 — The State Map: Where Truth Lives

Each system is the authoritative source for exactly one type of information.
Understanding this prevents confusion when systems disagree.

### Git Repository (main branch): Desired State of Everything

```
"What SHOULD the system look like?"

Source of truth for:
  gitops/dev/app/payment-service/payment-service.yaml
    → "payment-service in dev should be running image abc123"
  
  terraform/environments/production/main.tf
    → "production should have m7g.xlarge nodes, latency threshold 400ms"
  
  services/payment-service/src/
    → "the application code is this"
  
  charts/payment-service/
    → "the Helm chart template is this"

When git main disagrees with what's actually running:
  ArgoCD: re-syncs K8s to match gitops/
  Terraform: apply will bring AWS/DT to match .tf files
  
  Git is ALWAYS the winner. Never manually change production without
  first updating git. Manual changes are temporary — they get overwritten.
```

### Terraform State (S3 Bucket): What Terraform Currently Manages

```
"What Terraform THINKS is in AWS and DT"

Separate state files:
  company-terraform-state-dev/dev/terraform.tfstate
  company-terraform-state-stg/staging/terraform.tfstate
  company-terraform-state-prd/production/terraform.tfstate

Contains:
  - Resource IDs that Terraform manages:
      aws_eks_cluster.main.id = "company-production"
      dynatrace_metric_events.error_rate["payment-service"].id = "dt-uuid-abc123"
  - Current attribute values of every managed resource
  - Dependencies between resources

When state disagrees with git (.tf files):
  terraform plan shows what needs to change
  terraform apply makes it match .tf files

When state disagrees with real AWS/DT (drift):
  terraform plan -refresh-only shows the drift
  Daily drift detection catches this

When state is LOST (S3 bucket deleted):
  Terraform no longer knows what it manages
  You cannot safely apply (might recreate existing resources, creating duplicates)
  Recovery: terraform import or complete rebuild from scratch
  This is why: S3 versioning, S3 MFA delete, and S3 cross-region replication
  are all enabled on state buckets.
```

### ArgoCD (In-Cluster): Sync Status of gitops/ → K8s

```
"Does the K8s cluster match what gitops/ says it should?"

ArgoCD stores in its own database (in-cluster):
  Application "payment-service-dev":
    status: Synced                    ← cluster matches gitops/
    health: Healthy                   ← all pods are Running and Ready
    revision: abc123 (git SHA)        ← which git commit is deployed
    lastSyncTime: 2026-07-31T14:08Z

What ArgoCD does with this information:
  Synced + Healthy:   do nothing
  OutOfSync:          if auto-sync enabled → immediately apply the diff
  Degraded:           alert in ArgoCD UI (and optionally via webhook to Slack)

When ArgoCD and gitops/ disagree:
  ArgoCD ALWAYS wins → syncs cluster to match gitops/
  This prevents "configuration drift" in Kubernetes
  If an SRE runs `kubectl set image deployment/payment-service ...` manually:
    → ArgoCD detects the cluster no longer matches gitops/
    → selfHeal: true → ArgoCD immediately reverts the manual change
    → The manual change is undone within 3 minutes
  
  This is by design. Git is the source of truth.
  Manual kubectl changes are temporary in an ArgoCD-managed cluster.
```

### Dynatrace Tenant (SaaS): Real-Time Observability Data

```
"What is actually happening RIGHT NOW?"

DT stores:
  Metrics:          60-second resolution time series, retained 35 days
  Distributed traces: retained 10 days (configurable)
  Logs:             retained 10 days (from stdout via OneAgent)
  Problems:         open problems (real-time), closed problems (35 days history)
  SLO:              rolling 30-day compliance calculations

When DT disagrees with git (e.g., DT shows a metric event with threshold 300ms
but git has 400ms):
  This means Terraform hasn't been applied yet, or someone manually changed DT.
  Drift detection catches this.
  Next terraform apply will set DT to match git.

DT tenant is NOT the source of truth for configuration.
It is the source of truth for OBSERVATIONS.
Git is the source of truth for monitoring INTENT.
```

### AWS Secrets Manager: The Only Place Credentials Live

```
"Where are the actual secret values?"

Secrets Manager stores:
  dev/dynatrace/api-token          → DT API token for dev
  dev/dynatrace/data-ingest-token  → DT data ingest token for dev
  dev/payment-service/db-credentials → DB username, password, host, port
  dev/pagerduty/integration-keys   → PagerDuty service integration key
  dev/slack/webhook-urls           → Slack webhook URLs
  (same pattern for staging and production)

Credentials NEVER live in:
  ✗ Git repository (even in "secrets/" directory)
  ✗ Terraform .tf files or .tfvars
  ✗ Docker images
  ✗ K8s ConfigMaps
  ✗ GitHub Actions environment variables (except as references)

Credentials flow into the system via:
  Terraform: reads from Secrets Manager using `data "aws_secretsmanager_secret_version"`
             to pass DT token to DT provider and PD integration key to DT notification
  ESO: reads from Secrets Manager, creates K8s Secrets
       K8s Secrets are mounted as env vars in pods
  GitHub Actions: reads from Secrets Manager using aws-secretsmanager-get-secret-value
                  for CI-time credentials

Secrets Manager is the ONLY place where the actual values exist.
Everything else has references to Secrets Manager (ARNs, paths) but not the values.
```

### ECR (Per-Account): Docker Images by SHA

```
"What Docker images have been built, scanned, and validated at each stage?"

Dev ECR (account 123456789010):
  Contains: images that passed Gradle tests AND Trivy scan
  Tag format: git SHA (e.g., "abc123def456")
  Represents: "this code was tested and has no CRITICAL/HIGH CVEs"

Staging ECR (account 123456789011):
  Contains: images that ALSO passed dev smoke tests
  Represents: "this image worked correctly in dev (not just built successfully)"
  Note: images are copied from dev ECR, not rebuilt

Production ECR (account 123456789012):
  Contains: images that ALSO passed staging k6 load tests
  Represents: "this image worked correctly under realistic load in staging"
  These are the ONLY images that can be promoted to production.

The ECR chain enforces quality gates:
  Dev ECR → (smoke test passes) → Staging ECR → (load test passes) → Prod ECR → (deploy)
  
  An image can NEVER jump from dev ECR to prod ECR.
  It must pass each stage in sequence.
```

---

## Part 3 — When Systems Conflict: Resolution Order

```
Question: The K8s cluster is running image "old-sha" but gitops/ says "new-sha".
Who wins?
  → gitops/ (git repository). ArgoCD syncs cluster to match gitops/ within 3 minutes.

Question: DT has a metric event with threshold 300ms but terraform.tfvars says 400ms.
Who wins?
  → terraform.tfvars (git repository). Next terraform apply sets DT to 400ms.

Question: AWS EKS has 8 nodes but Terraform state and .tf files both say 6.
Who wins?
  → This is drift. Both state file and .tf files say 6. Real AWS says 8.
  → HUMAN DECIDES: codify (update .tf to 8) or revert (next apply sets AWS to 6).

Question: Terraform state says EKS cluster ID is "abc123" but the cluster was deleted.
Who wins?
  → Real AWS. terraform apply will try to update "abc123" and get "NotFound".
  → Resolution: terraform import or terraform state rm + recreate.

Question: Secrets Manager has a new DT token but the K8s Secret still has the old one.
Who wins?
  → ESO reconciles this automatically (default: every 1 hour).
  → The K8s Secret is updated to the new token value.
  → DT Operator reads the updated K8s Secret and reconnects to DT.
```
