# Flow 7 — Daily Drift Detection: Deep Dive
## Terraform detects infrastructure changed outside of Git — every detail explained

---

## Decision Tree — What Causes Drift and What to Do About It

```
Daily drift detection job finds exit code 2 (drift found)
        │
        ├── Who changed it?
        │   ├── SRE manually changed AWS Console → intentional manual override
        │   ├── AWS auto-scaling changed node count → expected AWS behavior
        │   ├── AWS rotated credentials → expected AWS behavior (drift is noise)
        │   └── Unknown → investigate before taking action
        │
        ├── Is the drift in a critical resource?
        │   ├── EKS node group: might affect capacity/performance
        │   ├── Security group: might affect network security
        │   ├── IAM role: might affect service permissions → investigate immediately
        │   └── EC2 tag: low severity, cosmetic
        │
        └── What to do?
            ├── Intentional manual change → codify it: update .tf file → PR → apply
            ├── Unwanted manual change   → revert: next terraform apply resets it
            └── AWS-managed drift        → update ignore_changes in Terraform
```

---

## E2E Flow Summary

```
[02:00 JST (17:00 UTC) — scheduled cron trigger]
        │
        ▼
[GitHub Actions: terraform-infra.yaml drift-detect job (matrix: 3 envs parallel)]
  Each environment:
    terraform init
    terraform plan -refresh-only -detailed-exitcode -no-color 2>&1 | tee drift.txt
    EXIT_CODE = 0 (no drift) | 1 (error) | 2 (drift found)
        │
        ├── EXIT 0: no drift → job succeeds, nothing created
        ├── EXIT 1: Terraform error → job fails → team sees failed workflow
        └── EXIT 2: drift found → GitHub Issue created with full plan output
        │
        ▼ (SRE reviews the issue)
        │
        ├── If drift is intentional → update Terraform → PR → apply
        └── If drift is accidental → leave it, next apply will reset it
```

---

## Part 1 — The Cron Trigger: Why 02:00 JST

```yaml
# terraform-infra.yaml
on:
  schedule:
    - cron: '0 17 * * *'   # 17:00 UTC = 02:00 JST
```

**Why 02:00 JST (17:00 UTC)?**
- Late night in Japan → low-traffic period, less likely to interfere with work
- Working hours in US Pacific (9:00 AM PST) and US Eastern (12:00 PM EST)
- This means US-based SREs see the drift report in their morning, in time to act before the Tokyo team wakes up

**Why once per day (not hourly)?**
- Terraform `plan -refresh-only` makes AWS API calls to read current state
- Running hourly across 3 environments would trigger ~90 API calls per hour
- AWS API rate limits could be hit
- Drift that matters (security group changes, IAM changes) is critical regardless
  of whether it was found after 1 hour or 24 hours — the response process is the same

---

## Part 2 — The `-refresh-only` Flag: Why This Specific Command

### Regular `terraform plan` vs `-refresh-only`

```
Regular terraform plan:
  1. Reads .tf files (desired state)
  2. Reads current state from S3 (state file)
  3. Calls AWS APIs to get current real state (refresh)
  4. Computes diff: desired .tf state vs real AWS state
  5. Shows: "what would change if I ran apply?"
  
  Problem: this shows BOTH:
    - Drift (real state differs from state file)
    - Pending config changes (state file differs from .tf files)
  
  You can't distinguish "someone changed AWS outside Terraform"
  from "SRE wrote new .tf code that hasn't been applied yet."

terraform plan -refresh-only:
  1. Reads current state from S3 (state file)
  2. Calls AWS APIs to get current real state (refresh)
  3. Computes diff: state file vs real AWS state ONLY
  4. Shows: "what changed in AWS that Terraform doesn't know about?"
  
  This ONLY shows drift — changes that happened outside Terraform.
  Pending .tf code changes are ignored.
  Clean, unambiguous signal.
```

### The `-detailed-exitcode` Flag

```
terraform plan -refresh-only -detailed-exitcode

Exit codes:
  0 = Success, no drift (real state matches state file)
  1 = Error (Terraform crashed, AWS credentials invalid, etc.)
  2 = Success, drift found (real state differs from state file)
```

This is what the GitHub Actions job reads:
```bash
terraform plan -refresh-only -detailed-exitcode -no-color 2>&1 | tee drift.txt
EXIT_CODE=${PIPESTATUS[0]}   # captures exit code of terraform, not tee

if [ "$EXIT_CODE" -eq 2 ]; then
  # Drift found — create GitHub Issue
elif [ "$EXIT_CODE" -eq 1 ]; then
  # Terraform error — mark job as failed
fi
```

---

## Part 3 — Scenario: Manual EKS Node Group Change

### How It Happens

An SRE is troubleshooting high CPU on the payment-service during a traffic spike.
They go to: AWS Console → EKS → company-production → Node Groups → workers
→ Actions → Edit → Desired size: 6 → 8 → Save

This is a click-ops operation. It takes 30 seconds but leaves no Terraform record.

### What the Drift Detection Sees

At 02:00 JST, `terraform plan -refresh-only` runs:

```bash
terraform plan -refresh-only -detailed-exitcode

Refreshing state...
  aws_eks_node_group.workers: Refreshing state...
  (calls AWS API: GET /clusters/company-production/nodegroups/workers)
  AWS returns: scaling_config.desired_size = 8

Comparing to state file:
  state file has: scaling_config.desired_size = 6

Diff found:
  ~ module.eks.aws_eks_node_group.workers:
      ~ scaling_config {
          ~ desired_size = 6 → 8   (drift!)
          # desired size was increased manually in AWS Console
        }

Plan: 0 to add, 0 to change, 0 to destroy.
Note: Objects have changed outside of Terraform.

Exit code: 2
```

### The GitHub Issue Created

```javascript
// GitHub Actions: create issue via API
github.rest.issues.create({
  owner: context.repo.owner,
  repo: context.repo.repo,
  title: "[DRIFT] Terraform infra drift detected in production – 2026-07-31",
  body: `
## Infrastructure Drift Detected

**Environment:** production
**Detected at:** 2026-07-31 17:00 UTC (02:00 JST)
**Detection job:** [link to GitHub Actions run]

## Drift Details
\`\`\`
~ module.eks.aws_eks_node_group.workers:
    ~ scaling_config {
        ~ desired_size = 6 → 8
      }
\`\`\`

## Action Required
Determine whether this change was intentional:

**If intentional (keep 8 nodes):**
Update \`terraform/environments/production/terraform.tfvars\`:
\`desired_size = 8\`
Then: PR → review → apply

**If accidental (revert to 6 nodes):**
The next \`terraform apply\` will revert to 6.
Or apply now: push to main and approve the production gate.
  `,
  labels: ["terraform-drift", "infrastructure", "production"]
})
```

---

## Part 4 — The Two Decisions: Codify or Revert

**Decision A: Codify the Change**

The 8-node count was a good decision. The SRE wanted to make it permanent.

```hcl
# terraform/environments/production/terraform.tfvars
# Before:
node_desired_size = 6

# After:
node_desired_size = 8
```

Open PR → review (plan shows no drift now, since .tf matches reality) → merge → apply.
`terraform apply` runs but makes no AWS changes (reality already matches the new code).
The state file is updated to record `desired_size = 8`.
Drift is gone. The change is now code-reviewed and tracked in git history.

**Decision B: Revert (Next Apply Resets It)**

The change was a quick emergency fix that should not be permanent.
The next `terraform apply` (which runs on any infra PR merge) will:
- Read .tf files: `desired_size = 6`
- Read real state: `desired_size = 8`
- Plan: scale down to 6
- Apply: AWS sets desired size back to 6

The SRE does nothing — the drift self-corrects on the next apply.

---

## Part 5 — What Drift Detection Does NOT Catch

**Auto-scaling changes (expected AWS behavior):**

```hcl
# terraform/modules/eks/main.tf
resource "aws_eks_node_group" "workers" {
  scaling_config {
    desired_size = var.node_desired_size   # starts at 6
    min_size     = 2
    max_size     = 20
  }
  
  # Ignore auto-scaling changes to desired_size
  lifecycle {
    ignore_changes = [scaling_config[0].desired_size]
  }
}
```

If Karpenter or Cluster Autoscaler changes `desired_size` to 12 to handle load,
the `ignore_changes` block tells Terraform: "don't show this as drift."
Without `ignore_changes`, the drift detection would create a GitHub Issue
every morning because the autoscaler has been adjusting node count all night.

**When to use `ignore_changes`:**
- Resources that are designed to be modified by external processes (autoscalers)
- Resources where AWS manages some attributes automatically (EC2 instance IDs)
- Tags that are managed by AWS billing systems

**When NOT to use `ignore_changes`:**
- Security groups (changes are security-critical and must be reviewed)
- IAM policies (changes affect service permissions)
- Core infrastructure (VPC, subnets, routing tables)

---

## Part 6 — Drift in Dynatrace Resources

The same drift detection runs for DT resources:

```yaml
# terraform-dynatrace-*.yaml also has a drift detect job
drift-detect:
  runs-on: ubuntu-latest
  steps:
    - run: |
        terraform plan -refresh-only -detailed-exitcode -no-color 2>&1 | tee drift.txt
        EXIT_CODE=${PIPESTATUS[0]}
```

**Common Dynatrace drift scenarios:**

```
Scenario 1: SRE manually edited a metric event threshold in DT UI
  Drift: threshold changed from 300000µs to 250000µs in DT
  Action: Either update Terraform (if intentional) or next apply reverts it

Scenario 2: SRE manually deleted an alerting profile in DT UI
  Drift: dynatrace_alerting resource disappeared from DT
  Action: Next terraform apply recreates it from Terraform state

Scenario 3: DT tenant version upgrade changed a default field value
  Drift: some internal DT API field changed automatically
  Action: Update ignore_changes in Terraform to suppress this noise
```

**The key principle:** The git repository is the source of truth for DT configuration.
Any manual change to DT configuration is temporary — the next Terraform apply
will override it. Drift detection surfaces these temporary changes so the team
can decide whether to make them permanent (update Terraform) or revert them.

---

## Part 7 — Drift Detection as a Security Control

Drift detection is not just an operational convenience — it is a security control.

**Security-relevant drift examples:**

```
Security Group drift:
  Real AWS: port 22 (SSH) open from 0.0.0.0/0
  Terraform state: port 22 NOT open

  This means someone opened SSH access to production nodes.
  Drift detection creates a GitHub Issue immediately.
  This is a security incident — requires investigation.

IAM role drift:
  Real AWS: IRSA role for payment-service has s3:GetObject on all S3 buckets
  Terraform state: IRSA role only has secretsmanager:GetSecretValue

  This means someone granted the payment-service pod access to all S3 data.
  This could be:
    - An accidental over-privileged IAM change
    - A credential compromise where an attacker expanded permissions

Drift detection catches this within 24 hours.
Without drift detection, this could persist indefinitely.
```

**Best practice:** For security-critical resources, reduce the drift detection interval:
```yaml
schedule:
  - cron: '0 */4 * * *'   # every 4 hours for security groups + IAM
  - cron: '0 17 * * *'    # daily for all other resources
```
