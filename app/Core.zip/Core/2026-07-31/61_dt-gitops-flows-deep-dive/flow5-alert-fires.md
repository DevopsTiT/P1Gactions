# Flow 5 — Alert Fires and Resolves: Deep Dive
## From a broken DB connection to a PagerDuty call to a resolved Problem — every minute explained

---

## Decision Tree — Which Alert Fires for Which Problem

```
A problem occurs in the payment-service in production
        │
        ├── What metric is violated?
        │   ├── error_rate > 0.1%       → ERROR severity Problem
        │   ├── availability < 99.9%    → AVAILABILITY severity Problem
        │   ├── latency_p99 > 400ms     → PERFORMANCE severity Problem
        │   └── synthetic check fails   → AVAILABILITY severity Problem
        │
        └── Which alerting profile matches this Problem?
            Profiles checked in priority order:
            │
            ├── payments-production-critical
            │   Matches: AVAILABILITY severity + payments-production zone
            │   → PagerDuty immediately (0 min delay)
            │
            ├── payments-production-high
            │   Matches: ERROR severity + payments-production zone
            │   → PagerDuty after 2-min delay
            │
            ├── payments-production-warning
            │   Matches: PERFORMANCE severity + payments-production zone
            │   → Slack after 5-min delay
            │
            └── payments-production-info
                Matches: all other severities
                → Slack with no page
```

---

## E2E Flow Summary

```
[14:00:00] payment-service error rate rises to 5%
[14:01–14:03] OneAgent reports → DT evaluates → 3 consecutive violations
[14:03:00] DT creates Problem: ERROR severity, payments-production zone
[14:03–14:05] Alerting profile: payments-production-high evaluates
[14:05:00] PagerDuty incident created → on-call engineer paged
[14:05–14:08] SRE investigates: DT shows "related deployment 2 min ago"
[14:08:00] SRE edits gitops/production/ → pushes rollback commit
[14:08–14:11] ArgoCD detects commit → rolling update with old image
[14:11–14:13] Error rate drops: 5% → 0%
[14:13–14:16] DT: 3 consecutive non-violations → Problem CLOSES
[14:16:00] Slack: [RESOLVED] notification
[14:16:00] PagerDuty: incident auto-resolved
```

---

## Part 1 — OneAgent: How It Detects the Error

The DB connection failure happens inside Java code. Here is the exact chain:

```java
// payment-service/src/main/java/.../PaymentRepository.java
// Spring Data JPA calls this internally:
Connection conn = dataSource.getConnection();   // ← THROWS here
// java.sql.SQLTransientConnectionException: Could not acquire connection from pool
// Root cause: PostgreSQL is unreachable (new deploy broke DB_HOST env var)
```

**OneAgent intercepts this at the bytecode level:**

```
Java JVM starts
  ↓
JVMTI attach: OneAgent loads as a JVM agent before application classes
  ↓
OneAgent instruments: javax.sql.DataSource.getConnection() method
  ↓
When getConnection() throws an exception:
  OneAgent captures:
    - Exception class: SQLTransientConnectionException
    - Stack trace (the full call chain)
    - Thread ID
    - Timestamp (nanosecond precision)
  
  OneAgent classifies: this exception caused the HTTP request handler to return 500
  OneAgent increments: service.errors.server.rate counter
```

**OneAgent also traces the full HTTP request:**
```
OneAgent creates a trace span for each incoming HTTP request:
  span.kind: server
  http.status_code: 500
  http.url: /api/v1/payments
  service.name: payment-service
  exception.type: SQLTransientConnectionException
  dt.entity.service: [payment-service entity ID]
```

**Metric aggregation:**
Every minute, OneAgent calculates the error rate:
```
builtin:service.errors.server.rate =
  (requests returning 5xx) / (total requests) × 100

At 14:00–14:01: 5.0%
At 14:01–14:02: 4.8%
At 14:02–14:03: 5.1%
```

These metrics are sent to the ActiveGate every 60 seconds.
ActiveGate buffers and forwards to the DT tenant.

---

## Part 2 — DT Metric Event Evaluation: The 3-Sample Rule

The metric event configuration (from Terraform):

```hcl
# terraform/modules/dynatrace/main.tf
resource "dynatrace_metric_events" "error_rate" {
  for_each = var.services

  event_entity_dimension_key = "dt.entity.service"
  summary                    = "[PRODUCTION] ${each.key}: High error rate (>0.1%)"
  event_type                 = "ERROR_EVENT"    # → ERROR severity Problem

  query_definition {
    metric_selector    = "builtin:service.errors.server.rate"
    threshold          = 0.1      # 0.1% = alert when > 0.1%
    threshold_type     = "STATIC"
    
    entity_filter {
      conditions {
        type     = "NAME"
        operator = "EQUALS"
        value    = each.key       # "payment-service"
      }
      conditions {
        type     = "TAG"
        operator = "EQUALS"
        value    = "environment:production"
      }
    }
  }

  model_properties {
    type                   = "STATIC_THRESHOLD"
    violating_samples      = 3   # must exceed threshold 3 times in a row
    dealerting_samples     = 3   # must be below threshold 3 times to close
    samples                = 5   # sliding window of last 5 samples
  }
}
```

**The evaluation timeline:**

```
14:00:00 — Metric received: error_rate = 5.0%
14:01:00 — DT evaluation:
  current_value: 5.0% > threshold: 0.1% → IN VIOLATION
  violating_samples: 1 / 3 needed → no Problem yet

14:02:00 — DT evaluation:
  current_value: 4.8% > 0.1% → IN VIOLATION
  violating_samples: 2 / 3 → no Problem yet

14:03:00 — DT evaluation:
  current_value: 5.1% > 0.1% → IN VIOLATION
  violating_samples: 3 / 3 → THRESHOLD MET → PROBLEM CREATED
```

**Why 3 consecutive samples before creating a Problem?**
A single spike (5% for 1 minute) might be:
- A brief traffic burst hitting a cache miss
- A single slow batch job completing
- A momentary external service hiccup

3 consecutive minutes of high error rate means the problem is sustained,
not a transient blip. This reduces false positives significantly.

**The 5-sample window:** Of the last 5 samples, 3 must be violations.
This means a brief recovery (1 sample below threshold) doesn't reset the counter.

---

## Part 3 — Problem Creation: What DT Builds Automatically

When DT creates a Problem, it correlates many data sources automatically:

```
Problem created at 14:03:00:
  title:    "[PRODUCTION] payment-service: High error rate (>0.1%)"
  severity: ERROR (from event_type = ERROR_EVENT)
  entity:   dt.entity.service:SERVICE-abc123 (payment-service)

DT immediately enriches the Problem:
  1. Related changes:
     "Deployment changed image tag 2 minutes ago (from abc111 to abc222)"
     (DT receives deployment events from CI via API call in the CI pipeline:
      POST /api/v2/events with eventType=CUSTOM_DEPLOYMENT, entity=payment-service)
  
  2. Related traces:
     "503 errors on POST /api/v1/payments (50 per minute)"
     (DT uses the distributed trace data from OneAgent spans)
  
  3. Root cause indicator (Smart alerting):
     "Exception SQLTransientConnectionException occurring in DB call"
     (From OneAgent's exception capture)
  
  4. Affected entities:
     "payment-service" AND "PostgreSQL database" (if OneAgent installed on DB host)
  
  5. Management zone:
     "payments-production" (because entity has tag team:payments + environment:production)
```

**The "related changes" correlation is crucial for SRE response:**
When the SRE opens the Problem URL from PagerDuty, the first thing they see is:
> "Deployment of payment-service was detected 2 minutes before this problem started."

This immediately points to the likely cause — no manual log searching needed.

---

## Part 4 — Alerting Profile Evaluation: Why the RIGHT Profile Fires

Four alerting profiles exist for the payments team in production:

```hcl
# payments-production-critical: fires immediately, PagerDuty
resource "dynatrace_alerting" "critical" {
  name = "payments-production-critical"
  rules {
    rule {
      delay_in_minutes = 0          # no delay
      severity_level   = "AVAILABILITY"   # only availability problems
      management_zone  = "payments-production"
    }
  }
}

# payments-production-high: fires after 2 min, PagerDuty
resource "dynatrace_alerting" "high" {
  name = "payments-production-high"
  rules {
    rule {
      delay_in_minutes = 2          # 2-minute delay
      severity_level   = "ERROR"    # error-level problems
      management_zone  = "payments-production"
    }
  }
}

# payments-production-warning: fires after 5 min, Slack only
resource "dynatrace_alerting" "warning" {
  name = "payments-production-warning"
  rules {
    rule {
      delay_in_minutes = 5
      severity_level   = "PERFORMANCE"
      management_zone  = "payments-production"
    }
  }
}
```

**For our error_rate Problem (severity = ERROR):**

```
Check critical profile:
  severity_level = AVAILABILITY required → ERROR ≠ AVAILABILITY → SKIP

Check high profile:
  severity_level = ERROR required → ERROR == ERROR ✅
  management_zone = payments-production required → ✅ (entity is tagged correctly)
  delay_in_minutes = 2 → start a 2-minute timer

At 14:05:00 (2 minutes after Problem creation at 14:03):
  Timer elapsed → fire notification for this profile
```

**Why the 2-minute delay on ERROR problems?**
Error rate spikes sometimes self-resolve within 1-2 minutes (auto-scaling kicks in,
a transient dependency hiccup clears). The 2-minute delay avoids paging the on-call
for problems that would have resolved on their own.
AVAILABILITY problems (service completely down) have zero delay — those need
immediate response regardless.

---

## Part 5 — PagerDuty Notification: The Full Chain

```hcl
# Notification resource (Terraform):
resource "dynatrace_notification" "pagerduty_high" {
  name             = "PagerDuty High – Payments"
  alerting_profile = dynatrace_alerting.high.id
  type             = "PAGERDUTY"
  active           = true

  pagerduty {
    service_api_key = "pd-key-payments-abc123"   # from Secrets Manager
    account         = "company"
    service_name    = "payment-service"
  }
}
```

**What DT sends to PagerDuty:**

```
POST https://events.pagerduty.com/v2/enqueue
{
  "routing_key": "pd-key-payments-abc123",
  "event_action": "trigger",
  "payload": {
    "summary": "OPEN | ERROR | [PRODUCTION] payment-service: High error rate (>0.1%)",
    "severity": "error",
    "source": "Dynatrace",
    "timestamp": "2026-07-31T14:05:00Z",
    "custom_details": {
      "problem_url": "https://YOUR_TENANT.live.dynatrace.com/ui/problems/...",
      "affected_entity": "payment-service",
      "management_zone": "payments-production",
      "related_changes": "Deployment updated 2 minutes ago"
    }
  }
}
```

**PagerDuty then:**
1. Looks up the on-call engineer for the `payment-service` service
2. Sends push notification to their PagerDuty app
3. If not acknowledged in 5 minutes → escalates to secondary on-call
4. If not acknowledged in 10 minutes → escalates to manager

---

## Part 6 — SRE Response: Using DT to Find the Root Cause Fast

The SRE opens the PagerDuty notification → clicks the Problem URL → sees:

```
Problem Summary:
  HIGH error rate (5% vs 0.1% threshold) on payment-service

AI-detected root cause:
  "Database connectivity issue affecting payment-service"
  "Exception: SQLTransientConnectionException"

Related changes:
  ⚡ Deployment detected 2 minutes before problem:
     payment-service: abc111 → abc222

Affected entities:
  SERVICE: payment-service
  DATABASE: PostgreSQL (company-dev-payments) ← listed because spans show DB calls
  
Logs (last 10 matching):
  14:00:01.234 ERROR PaymentRepository: Could not acquire connection from pool
  14:00:01.456 ERROR PaymentRepository: Could not acquire connection from pool
  ...
```

**The SRE decision:** The deploy 2 minutes ago is the most likely cause.
The log message confirms it: "Could not acquire connection from pool."
The new image probably has a wrong `DB_HOST` environment variable.

**Check the diff:**
```bash
git show abc222 -- services/payment-service/src/main/resources/application.yaml
# or
git diff abc111 abc222 -- gitops/production/app/payment-service/payment-service.yaml
```

Confirmed: the new deploy has `DB_HOST: postgres.staging.company.com` (wrong env).

---

## Part 7 — Rollback: The Manual Git Operation

```bash
# SRE runs these commands:
git log --oneline -- gitops/production/app/payment-service/payment-service.yaml
# abc2222 chore(deploy-prod): payment-service=abc222 [skip ci]  ← BROKEN
# abc1111 chore(deploy-prod): payment-service=abc111 [skip ci]  ← WORKING

# Edit the file directly
sed -i 's|tag: "abc222"|tag: "abc111"|' \
  gitops/production/app/payment-service/payment-service.yaml

git diff  # verify: only tag changed
git add gitops/production/app/payment-service/payment-service.yaml
git commit -m "chore(rollback-prod): payment-service=abc111 [skip ci]"
git push origin main
```

**Why edit gitops/ directly rather than using `kubectl rollout undo`?**

`kubectl rollout undo` reverts the K8s Deployment in the cluster.
But ArgoCD's `selfHeal: true` will detect the cluster state differs from gitops/ and
re-apply gitops/ within seconds — overwriting the rollback.

The cluster state MUST match gitops/. To rollback, you must update gitops/.
Only then will the rollback persist.

---

## Part 8 — Problem Closure: The 3-Sample Rule Again

```
14:11:00 — Rolling update completes, all pods running old image
14:11:30 — First requests succeed with old code
14:12:00 — DT evaluation: error_rate = 0.2% < 0.1% threshold
  Wait — 0.2% is still above threshold!
  
  (This is expected: the rolling update takes ~3 minutes. During the update,
   some pods are still running the broken image while others have the old image.
   Error rate gradually decreases as more pods are replaced.)

14:13:00 — DT evaluation: error_rate = 0.05% < 0.1% ✅
  dealerting_samples: 1 / 3

14:14:00 — error_rate = 0.02% < 0.1% ✅
  dealerting_samples: 2 / 3

14:15:00 — error_rate = 0.01% < 0.1% ✅
  dealerting_samples: 3 / 3 → PROBLEM CLOSES
```

**Why 3 samples to close (same as 3 to open)?**
A brief recovery (e.g., one minute of low error rate during the rollback rollout)
should not prematurely close the Problem if the service might still be unstable.
Requiring 3 consecutive sub-threshold samples confirms the fix is stable.

**Resolution notification:**

```
DT sends to Slack webhook (payments team):
  Message: "[PRODUCTION] RESOLVED | ERROR | [PRODUCTION] payment-service: High error rate (>0.1%)
            Duration: 12 minutes
            Problem URL: https://..."

DT sends to PagerDuty:
  PATCH /incidents/{id} → status: resolved
  PagerDuty auto-resolves the incident
  On-call engineer receives push notification: "incident resolved"
```

**Total incident duration:** ~12 minutes (14:03 Problem created → 14:15 Problem closed)
- Detection time (MTTD): 3 minutes (3 evaluation cycles)
- Alert delay: 2 minutes (alerting profile)
- Response + rollback: 5 minutes
- Recovery confirmation: 3 minutes (3 closing cycles)
