# Flow 1 — Code Deploy: Deep Dive
## The Most Common Path: Developer merge → Pod running in production

---

## Decision Tree — What Triggers What

```
Developer merges PR to main
        │
        ├── Did it touch services/payment-service/**?
        │   └── YES → payment-service-ci.yaml fires
        │
        ├── Did it touch charts/payment-service/**?
        │   └── YES → payment-service-ci.yaml fires (chart change = re-test + redeploy)
        │
        └── Did it touch gitops/** directly?
            └── YES → NOTHING fires in CI (ArgoCD handles gitops/ directly)
                      This is how rollbacks and hotfixes work without CI
```

---

## E2E Flow Summary

```
[PR merged to main]
      │
      ▼
[GitHub Actions: payment-service-ci.yaml]
  Job 1: test        → Gradle test + JaCoCo coverage (must be ≥ 70%)
  Job 2: build-dev   → Docker buildx → ECR dev → Trivy scan → sed image tag → git push
  Job 3: smoke-dev   → curl health + POST payment endpoint
  Job 4: promote-stg → re-tag image to staging ECR → update gitops/staging/
  Job 5: test-stg    → k6 load test 50 VUs × 3 min
  Job 6: promote-prd → manual approval gate (environment: production)
  Job 7: verify-prd  → smoke test + auto-rollback on failure
      │
      ▼ (each promotion step writes to gitops/ENV/app/payment-service/payment-service.yaml)
      │
      ▼
[ArgoCD detects git change within 3 minutes]
  → helm template → Deployment with new image tag
  → kubectl apply → rolling update
      │
      ▼
[EKS: new pod starts, passes probes, receives traffic, old pod drains]
      │
      ▼
[OneAgent instruments new JVM → metrics flow to DT tenant]
```

---

## Part 1 — GitHub Actions: Why This File Triggers

The CI file `payment-service-ci.yaml` has a path filter:

```yaml
on:
  push:
    branches: [main]
    paths:
      - 'services/payment-service/**'
      - 'charts/payment-service/**'
```

**Why `charts/` is included:** The Helm chart is the packaging definition for the
service. If a developer changes a liveness probe timeout, adds a new env var,
or changes resource limits — the chart changed even though no Java code changed.
The old image with the new chart configuration must be re-tested and re-deployed.

**Why `gitops/` is NOT listed:** The gitops/ directory is the deploy state, not
the source code. CI writes to gitops/ (step 6 below). If CI triggered on its own
gitops/ writes, it would create an infinite loop. `[skip ci]` in the commit
message is a second layer of protection — but the path filter is the primary guard.

---

## Part 2 — Job 1: Test (What Happens When It Fails)

```yaml
- name: Test and coverage
  run: ./gradlew test jacocoTestReport jacocoTestCoverageVerification
```

**What Gradle runs internally:**
1. `test` — compiles and runs all JUnit tests in `src/test/java/`
2. `jacocoTestReport` — generates `build/reports/jacoco/test/html/index.html` + XML
3. `jacocoTestCoverageVerification` — reads the XML, checks every rule:
   ```
   violationRules {
     rule { limit { minimum = 0.70 } }   // 70% line coverage across all classes
   }
   ```

**What happens if tests fail:**
- Gradle exits code 1
- GitHub Actions marks job `test` as FAILED
- All subsequent jobs have `needs: test` → they are all SKIPPED automatically
- No Docker image is built. No ECR push. No gitops/ update.
- The broken image never exists anywhere.

**What happens if coverage < 70%:**
- `jacocoTestCoverageVerification` task fails with exit code 1
- Same result: pipeline stops here

**Why coverage gate is at the test job, not a separate job:**
Running it separately would require re-running Gradle (expensive).
JaCoCo coverage verification runs in the same Gradle execution as the tests — zero extra cost.

---

## Part 3 — Job 2: Build and Deploy to Dev (Every Step Explained)

### Step 1: OIDC → AWS Role

```yaml
- uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789010:role/github-actions-payment-service
    aws-region: ap-northeast-1
```

**What OIDC means here:** GitHub Actions generates a signed JWT for this workflow run.
AWS IAM verifies the JWT against GitHub's OIDC provider endpoint.
If valid, AWS issues temporary credentials (STS AssumeRoleWithWebIdentity).
No static `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` secrets stored anywhere.

**Why this matters:** If the GitHub Actions runner is compromised, there are no
long-lived credentials to steal. The temporary credentials expire in 1 hour.

### Step 2: Docker buildx — linux/amd64 + linux/arm64

```yaml
- name: Build and push
  run: |
    docker buildx build \
      --platform linux/amd64,linux/arm64 \
      --tag $ECR_REGISTRY/payment-service:${{ github.sha }} \
      --push .
```

**Why two architectures:**
- `linux/amd64`: Intel/AMD x86_64 — what most CI runners and EC2 instances use today
- `linux/arm64`: AWS Graviton (ARM) — cheaper, more energy-efficient for Java workloads

Building both means the same image tag (`abc123`) works on both instance types.
When EKS schedules a pod on a Graviton node, Docker pulls the `arm64` manifest.
When scheduled on x86, it pulls the `amd64` manifest. The image tag is identical.

**`--push` flag:** pushes both manifests to ECR as a multi-arch image manifest list.
One tag, two layers.

### Step 3: IMAGE_TAG = github.sha

```
IMAGE_TAG = "abc123def456789..."   (40 character git SHA)
```

**Why git SHA, not `latest` or a version number:**

| Tag strategy | Problem |
|---|---|
| `latest` | Two pods can have "latest" but completely different code — no traceability |
| `v1.2.3` | Requires a tagging step — who creates the tag, when, following what rules? |
| `git-sha` | Immutable, unique, traceable: `git show abc123` tells you exactly what's in the image |

The SHA also directly links the running pod back to the PR that introduced it.
In Dynatrace, when a deployment event fires, the SHA appears in the event body.
SREs can `git show <SHA>` to see what changed.

### Step 4: Trivy Scan

```yaml
- name: Run Trivy vulnerability scanner
  uses: aquasecurity/trivy-action@master
  with:
    image-ref: ${{ env.ECR_REGISTRY }}/payment-service:${{ github.sha }}
    exit-code: '1'
    severity: 'CRITICAL,HIGH'
```

**What Trivy scans:**
- OS packages in the container layer (Alpine/Debian CVEs)
- Java dependency JARs (scans the fat JAR in the container)
- Known CVEs from NVD, GitHub Advisory Database, RedHat CVE DB

**`exit-code: '1'`:** If any CRITICAL or HIGH CVE is found, Trivy exits 1.
GitHub Actions sees a non-zero exit code → step fails → job fails → pipeline stops.
The image exists in ECR but no gitops/ file is updated → ArgoCD never deploys it.

**What about MEDIUM/LOW?** Not blocked. They are reported but the pipeline continues.
This is a policy decision: blocking on MEDIUM produces too many false positives
(especially from transitive Java dependencies that have no fix available).

### Step 5: sed — Update Image Tag in gitops/

```bash
sed -i "s|tag: \"PLACEHOLDER\"|tag: \"${IMAGE_TAG}\"|" \
  gitops/dev/app/payment-service/payment-service.yaml
```

**Before:**
```yaml
# gitops/dev/app/payment-service/payment-service.yaml
image:
  repository: 123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  tag: "abc0000old"   # ← current deployed tag
```

**After sed:**
```yaml
image:
  repository: 123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
  tag: "abc123def456"   # ← new tag, just built and scanned
```

**Why `sed` instead of something more sophisticated:**
- The gitops/ YAML file is already a complete Helm values file — only the tag changes
- `sed` is deterministic, fast, and visible in diffs
- Alternatives (yq, kustomize edit) require installing additional tools in CI

### Step 6: git commit + git push [skip ci]

```bash
git config user.name  "GitHub Actions Bot"
git config user.email "github-actions[bot]@users.noreply.github.com"
git add gitops/dev/app/payment-service/payment-service.yaml
git commit -m "chore(deploy-dev): payment-service=${IMAGE_TAG} [skip ci]"
git push origin main
```

**`[skip ci]` in the commit message:** GitHub Actions honors this convention —
it does NOT trigger any workflow on this push. This prevents the infinite loop:
CI commits to gitops/ → CI triggers again → CI commits again → ...

**What if two services merge at the same time?**
Both pipelines write to different files in gitops/, so there is no content conflict.
But both pipelines do `git push origin main` — the second one may fail with
"rejected: non-fast-forward". The pipeline handles this with `git pull --rebase`
before the push, retrying if needed.

### Step 7: `kubectl rollout status --timeout=8m`

```bash
kubectl rollout status deployment/payment-service \
  -n payment \
  --timeout=8m
```

**What this does:** Blocks the CI job and waits for Kubernetes to confirm that
the rolling update completed successfully. Reports success only when:
1. All new pods have passed their readinessProbe
2. All old pods have been terminated

**Why 8 minutes:** `startupProbe.failureThreshold = 40 × periodSeconds = 30s = 20 minutes`
in dev. But the `kubectl rollout status` timeout is for the TOTAL rollout, not per-pod.
8 minutes is chosen because a healthy Spring Boot app on Graviton starts in ~45 seconds.
If it takes more than 8 minutes, something is wrong — the CI job fails and the
on-call is notified before the staging promotion happens.

---

## Part 4 — ArgoCD: What Happens in the Cluster

### How ArgoCD Knows to Watch This File

The `root-app-dev.yaml` Application resource (applied once during Day 0 bootstrap)
creates a parent Application that watches `gitops/dev/` recursively:

```yaml
spec:
  source:
    repoURL: https://github.com/company/java-3envs
    targetRevision: main
    path: gitops/dev
    directory:
      recurse: true
```

ArgoCD discovers child Application YAML files recursively under `gitops/dev/`.
Each child Application (payment-service-dev, order-service-dev, etc.) watches
its own subdirectory and references the Helm chart to render.

### The 3-Minute Poll vs Webhook

By default ArgoCD polls the git repository every 3 minutes.
With a GitHub webhook configured, ArgoCD is notified immediately on each push.
The poll interval is a fallback.

**Net result:** After CI pushes the gitops/ change, ArgoCD detects it within
0–3 minutes. The total pipeline time from PR merge to production readiness is:
CI (8 min) + ArgoCD detect (3 min) + rolling update (2 min) = ~13 minutes minimum.

### What ArgoCD Does With the New Tag

```
ArgoCD detects: gitops/dev/app/payment-service/payment-service.yaml changed
  → reads the Application spec for payment-service-dev:
      source:
        chart: payment-service         ← from charts/payment-service/
        valueFiles: [values.yaml, values-dev.yaml]
        helm.parameters: image.tag=abc123def456

  → runs: helm template charts/payment-service
           -f charts/payment-service/values.yaml
           -f charts/payment-service/values-dev.yaml
           --set image.tag=abc123def456

  → produces: Kubernetes Deployment YAML with spec.template.spec.containers[0].image
              = "123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service:abc123def456"

  → sends Deployment to Kubernetes API via kubectl apply
```

---

## Part 5 — Rolling Update: Pod Lifecycle in Detail

```
Before rolling update:
  pod-1: payment-service:old-sha  ← serving traffic
  pod-2: payment-service:old-sha  ← serving traffic
  pod-3: payment-service:old-sha  ← serving traffic

maxUnavailable: 0  → zero pods can be removed before a replacement is Ready
maxSurge: 1        → one extra pod can be added beyond the desired count

Step 1: Kubernetes creates pod-4 (new image: abc123)
  State: [pod-1 live, pod-2 live, pod-3 live, pod-4 starting]

Step 2: pod-4 startupProbe passes (Spring Boot health endpoint UP)
  (startupProbe: GET /actuator/health, failureThreshold=40, periodSeconds=30)
  This gives Spring Boot up to 20 minutes to warm up caches, load configs, etc.

Step 3: pod-4 readinessProbe passes (GET /actuator/health/readiness → UP)
  Kubernetes adds pod-4 to Service endpoints
  ALB begins routing traffic to pod-4

Step 4: Kubernetes removes pod-1 from Service endpoints
  pod-1 receives SIGTERM → no new connections
  preStop.exec.command: sleep 15  ← allows in-flight requests to drain
  After 15s: Spring Boot shutdown begins:
    spring.lifecycle.timeout-per-shutdown-phase: 30s
    → completes in-flight requests (up to 30s)
    → closes DB connection pool
    → pod-1 terminates

Step 5-6: Repeat for pod-2, pod-3

Final state:
  pod-4: payment-service:abc123  ← serving traffic
  pod-5: payment-service:abc123  ← serving traffic
  pod-6: payment-service:abc123  ← serving traffic
  (pods 1, 2, 3 terminated)
```

**The key guarantee: `maxUnavailable: 0` means zero user-facing downtime.**
A new pod is ALWAYS ready before an old pod is removed.

---

## Part 6 — Promote to Production: The Manual Gate

```yaml
# in payment-service-ci.yaml
promote-to-production:
  needs: test-staging
  environment: production   # ← this is the magic line
  steps:
    - name: Wait for approval
      # GitHub pauses here. "production" environment has required_reviewers set.
      # An email is sent to the required reviewers.
      # They open GitHub → Environments → production → Review deployments → Approve
```

**What the reviewer sees before approving:**
- The staging test results (k6: p95 latency, error rate)
- The git diff of what is being deployed (link in the approval UI)
- Any custom deployment notes in the PR description

**Who can approve:** Only members of the GitHub team listed in the environment's
`required_reviewers` setting. This is configured in GitHub Settings → Environments → production.

**What happens if nobody approves within 72 hours:**
The workflow times out. The deployment does not happen.
The deployment must be re-triggered by a new push to main.

---

## Part 7 — Auto-Rollback on Production Failure

```yaml
verify-production:
  needs: promote-to-production
  steps:
    - name: Smoke test production
      id: smoke
      run: |
        curl -f https://api.company.com/actuator/health/liveness  || exit 1
        curl -f https://api.company.com/actuator/health/readiness || exit 1
        RESULT=$(curl -s -X POST https://api.company.com/api/v1/payments \
          -H "Content-Type: application/json" \
          -d '{"amount":1,"currency":"JPY","test":true}' | jq -r '.status')
        [ "$RESULT" = "created" ] || exit 1

    - name: Auto-rollback on failure
      if: failure()
      run: |
        # Get previous good tag from git log
        PREV_TAG=$(git log --format="%s" -- \
          gitops/production/app/payment-service/payment-service.yaml \
          | grep "chore(deploy-prod)" | sed -n '2p' \
          | grep -oP '(?<=payment-service=)\S+')

        sed -i "s|tag: \".*\"|tag: \"${PREV_TAG}\"|" \
          gitops/production/app/payment-service/payment-service.yaml

        git commit -m "chore(rollback-prod): payment-service=${PREV_TAG} [skip ci]"
        git push origin main
        echo "::error::Production smoke test failed. Auto-rolled back to ${PREV_TAG}"
```

**What auto-rollback does:** If the production smoke test fails, the CI job
immediately edits the gitops/production/ YAML back to the previous SHA,
commits it, and pushes. ArgoCD detects this within 3 minutes and rolls the
Deployment back. No human intervention required for the revert.

**Why the SRE still needs to investigate:** Auto-rollback restores service
but does not fix the root cause. A Dynatrace Problem is likely already open.
The SRE must still understand why the new image broke, fix it, and redeploy.
