# Flow 4 — New Environment Bootstrap (Day 0): Deep Dive
## Building a fully monitored Kubernetes environment from nothing, step by step

---

## Decision Tree — What Order Must Things Happen?

```
Nothing exists yet. What must be true before each step?
        │
        ├── BEFORE terraform init:
        │     S3 bucket must exist (created manually beforehand)
        │     DynamoDB table must exist (created manually beforehand)
        │     AWS account must have correct IAM roles
        │
        ├── BEFORE ArgoCD install:
        │     EKS cluster must exist (created by terraform)
        │     kubectl must be configured to reach the cluster
        │
        ├── BEFORE root-app bootstrap:
        │     ArgoCD must be running
        │     ArgoCD must have git credentials (read-only deploy key)
        │
        ├── BEFORE wave 2 (ESO) deploys:
        │     wave -1 namespaces must exist
        │     (ESO deploys into external-secrets namespace, which wave -1 creates)
        │
        ├── BEFORE wave 3 (DynaKube) works:
        │     wave 2 (ESO + ClusterSecretStore) must be running
        │     (the ExternalSecret that creates the DT token K8s secret requires ESO)
        │
        └── BEFORE wave 8 services start:
              wave 3 (OneAgent DaemonSet) must be running
              (OneAgent must be on the node before the JVM starts)
```

---

## E2E Flow Summary

```
[Step 1] terraform apply (manual, one-time)
  Creates: VPC, EKS, ECR, IAM, S3, DynaKube-ready IAM
  Also calls module "dynatrace": creates DT resources for this environment
  Duration: ~20 minutes

[Step 2] ArgoCD install (manual, one-time)
  kubectl apply -n argocd -f https://.../install.yaml
  Duration: ~3 minutes

[Step 3] Root app bootstrap (manual, one-time)
  kubectl apply -f gitops/dev/bootstrap/root-app-dev.yaml
  Duration: ArgoCD immediately starts syncing
  From this point: fully automated, wave by wave

[Wave -1] namespaces (labels required by DT auto-tagging)
[Wave  1] ALB controller + ExternalDNS (cluster networking)
[Wave  2] ESO + ClusterSecretStore (secrets pipeline)
[Wave  3] DynaKube + ExternalSecret for DT tokens (monitoring)
[Wave  8] Java services (payment, order, notification)

[Done] ~45 minutes after starting step 1: environment fully live and monitored
```

---

## Part 1 — Terraform Step: What Gets Created and Why Each Piece Exists

### VPC — The Network Foundation

```hcl
# terraform/modules/vpc/main.tf creates:
resource "aws_vpc" "main" {
  cidr_block = "10.10.0.0/16"    # 65,534 usable IPs
  
  enable_dns_hostnames = true     # required for EKS
  enable_dns_support   = true
}

# 3 public subnets (one per AZ) — for load balancers
resource "aws_subnet" "public" {
  count             = 3
  vpc_id            = aws_vpc.main.id
  cidr_block        = cidrsubnet("10.10.0.0/16", 4, count.index)   # /20 each
  availability_zone = data.aws_availability_zones.available.names[count.index]
  
  # Required for ALB: instances in public subnets get public IPs
  map_public_ip_on_launch = false   # pods don't need public IPs
  
  tags = {
    "kubernetes.io/role/elb" = "1"   # tells AWS LBC this is for public ALBs
  }
}

# 3 private subnets — where pods actually run
resource "aws_subnet" "private" {
  count      = 3
  cidr_block = cidrsubnet("10.10.0.0/16", 4, count.index + 3)
  
  tags = {
    "kubernetes.io/role/internal-elb" = "1"   # for internal NLBs
  }
}

# NAT gateways: one per AZ (not just one)
# Why per-AZ? If us-east-1a has a partial AWS outage, pods in us-east-1a
# can still reach the internet via the us-east-1a NAT gateway.
# One NAT = single point of failure for all outbound traffic.
resource "aws_nat_gateway" "main" {
  count         = 3
  allocation_id = aws_eip.nat[count.index].id
  subnet_id     = aws_subnet.public[count.index].id
}
```

### EKS Cluster

```hcl
resource "aws_eks_cluster" "main" {
  name     = "company-dev"
  role_arn = aws_iam_role.cluster.arn
  version  = "1.28"

  vpc_config {
    subnet_ids              = concat(aws_subnet.private[*].id, aws_subnet.public[*].id)
    endpoint_private_access = true    # kubectl works from within the VPC
    endpoint_public_access  = true    # kubectl works from developer laptops
    public_access_cidrs     = ["0.0.0.0/0"]  # can be restricted to office IPs
  }
  
  # OIDC issuer: enables IRSA (IAM Roles for Service Accounts)
  # This is what allows pods to call AWS APIs without storing credentials
}

# System node group: runs kube-system pods (CoreDNS, kube-proxy, etc.)
resource "aws_eks_node_group" "system" {
  taint {
    key    = "dedicated"
    value  = "system"
    effect = "NO_SCHEDULE"    # prevents user workloads from landing here
  }
}
```

### IRSA Roles — Why Every Service Gets Its Own Role

```hcl
# Each service gets its own IAM role
# This is the principle of least privilege for pods

resource "aws_iam_role" "payment_service" {
  assume_role_policy = jsonencode({
    Statement = [{
      Action    = "sts:AssumeRoleWithWebIdentity"
      Principal = { Federated = aws_iam_openid_connect_provider.eks.arn }
      Condition = {
        StringEquals = {
          "${aws_iam_openid_connect_provider.eks.url}:sub" =
            "system:serviceaccount:payment:payment-service"
        }
      }
    }]
  })
}

# payment-service can only access its own Secrets Manager paths
resource "aws_iam_policy" "payment_service" {
  policy = jsonencode({
    Statement = [{
      Effect   = "Allow"
      Action   = ["secretsmanager:GetSecretValue"]
      Resource = "arn:aws:secretsmanager:*:*:secret:dev/payment-service/*"
    }]
  })
}
```

**Why not one role for all services?**
If payment-service is compromised, it cannot access order-service's database credentials.
Each service's blast radius is limited to its own secrets.

### Dynatrace Module Call

```hcl
# terraform/environments/dev/main.tf
module "dynatrace" {
  source = "../../modules/dynatrace"
  
  environment = "dev"
  services    = var.services
  
  # Dev: relaxed thresholds, no PagerDuty
  pagerduty_integration_keys = {}     # empty map = zero PD resources created
  slack_webhook_urls = {
    "payments" = "https://hooks.slack.com/services/..."
    "orders"   = "https://hooks.slack.com/services/..."
  }
}
```

The module creates DT resources scoped to "dev":
- Management zone names: `payments-dev`, `orders-dev`, `notifications-dev`
- Metric event names: `[DEV] payment-service: High error rate`
- Alerting profiles: WARNING and INFO severity only (no CRITICAL/HIGH in dev)
- SLO targets: 90% (vs 99.9% in production)
- Synthetic locations: Tokyo only (vs 3 locations in production)
- Synthetic interval: 5 minutes (vs 5 minutes in production — same here)
- Notifications: Slack only (no PagerDuty — dev alerts don't wake anyone up)

---

## Part 2 — ArgoCD Install: What the install.yaml Contains

```bash
# Step 2: install ArgoCD
kubectl create namespace argocd
kubectl apply -n argocd \
  -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
```

**What `install.yaml` creates (simplified):**
- ArgoCD server (the UI and API server)
- ArgoCD application controller (watches git repos and K8s clusters)
- ArgoCD repo server (renders Helm/Kustomize templates)
- ArgoCD dex server (handles SSO)
- ArgoCD Redis (caches rendered manifests)
- CRDs: Application, ApplicationSet, AppProject

**Why install from the upstream URL rather than committing the manifest?**
For this specific one-time bootstrap, using the upstream URL is acceptable.
The ArgoCD version is pinned by the URL path (`stable` or a specific tag).
Alternative: commit the install.yaml to the repo and apply from there —
but then you have a 10,000-line manifest in your repo that must be updated manually.

**After install, configure git access:**
```bash
kubectl create secret generic argocd-github-credentials \
  -n argocd \
  --from-literal=type=git \
  --from-literal=url=https://github.com/company/java-3envs \
  --from-literal=password="$GITHUB_TOKEN"
```

ArgoCD needs read-only access to the git repository to poll for changes.

---

## Part 3 — Root App: The "App of Apps" Pattern Explained

```yaml
# gitops/dev/bootstrap/root-app-dev.yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: root-app-dev
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/company/java-3envs
    targetRevision: main
    path: gitops/dev          # ← watches this directory recursively
    directory:
      recurse: true           # ← finds all Application YAML files in subdirs
  destination:
    server: https://kubernetes.default.svc   # this cluster
    namespace: argocd
  syncPolicy:
    automated:
      prune: true      # delete K8s resources that are removed from git
      selfHeal: true   # if someone manually changes K8s, ArgoCD reverts it
```

**How "App of Apps" works:**

ArgoCD applies `root-app-dev.yaml`. This creates ONE Application (root-app-dev).
That Application watches `gitops/dev/` recursively for YAML files.
It finds other Application YAML files:
- `gitops/dev/namespaces/application.yaml` → creates namespaces-dev Application
- `gitops/dev/networking/application.yaml` → creates aws-lbc-dev Application
- `gitops/dev/app/payment-service/application.yaml` → creates payment-service-dev Application
- etc.

Each child Application manages its own set of K8s resources.
This is why you only ever manually apply ONE file (root-app-dev.yaml) and
everything else is automated.

---

## Part 4 — Sync Waves: Why Order Matters

Sync waves enforce ordering within a single ArgoCD sync cycle.
Lower wave number = deployed first. Next wave starts only after all resources
in the previous wave are healthy (Ready/Available).

### Wave -1: Namespaces (Must Be Absolutely First)

```yaml
# gitops/dev/namespaces/namespaces.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: payment
  annotations:
    argocd.argoproj.io/sync-wave: "-1"   # negative = before everything else
  labels:
    team: payments           # ← DT reads these labels
    environment: dev         # ← DT reads these labels
    app.kubernetes.io/part-of: payment-service
```

**Why wave -1?** Every other resource lives IN a namespace.
You cannot create a Deployment in the `payment` namespace if `payment` doesn't exist.
Namespaces must exist before anything else.

**Why labels on namespaces?** OneAgent reads K8s namespace labels.
When OneAgent instruments the payment-service JVM, it reads:
```
namespace: payment → labels: team=payments, environment=dev
```
OneAgent sends these as tags to Dynatrace:
```
dt.kubernetes.namespace.labels.team = "payments"
dt.kubernetes.namespace.labels.environment = "dev"
```
Dynatrace management zone rule:
```
Include entities where: tag("team:payments") AND tag("environment:dev")
→ Entity appears in management zone: payments-dev
```
**This is the link between Kubernetes metadata and Dynatrace monitoring scope.**

### Wave 1: AWS Load Balancer Controller and ExternalDNS

```
AWS Load Balancer Controller:
  Watches K8s Ingress resources
  When it sees: annotations: kubernetes.io/ingress.class: "alb"
  Creates: AWS Application Load Balancer
  Configures: target groups pointing to pod IPs
  
  MUST be running before payment-service deploys its Ingress (wave 8).
  If ALB controller is not running when Ingress is created, the ALB never appears.

ExternalDNS:
  Watches K8s Ingress resources
  When it sees: a new hostname (e.g., payment.dev.company.com)
  Creates: Route53 DNS record pointing to the ALB
  
  MUST be running before services need DNS records.
  domainFilters: ["dev.company.com"] prevents accidentally creating records for prod.
```

### Wave 2: External Secrets Operator (ESO) + ClusterSecretStore

```
ESO must be installed before any ExternalSecret resource is created.
Why? ExternalSecret is a custom resource defined by ESO.
Before ESO installs its CRDs, creating an ExternalSecret YAML produces:
  "no matches for kind ExternalSecret in version external-secrets.io/v1beta1"

ClusterSecretStore is a cluster-wide resource (not namespaced).
It configures: "how to reach AWS Secrets Manager in this account."
Once ClusterSecretStore is healthy, any ExternalSecret in any namespace can
reference it to pull a secret from Secrets Manager.
```

### Wave 3: DynaKube (Requires Wave 2 Products Running)

```
Wave 3 creates three resources:
  1. ExternalSecret "dynakube-tokens":
     spec:
       secretStoreRef:
         name: cluster-secret-store   # from wave 2
         kind: ClusterSecretStore
       data:
         - secretKey: apiToken
           remoteRef:
             key: dev/dynatrace/api-token   # in Secrets Manager
         - secretKey: dataIngestToken
           remoteRef:
             key: dev/dynatrace/data-ingest-token

  ESO reads these from AWS Secrets Manager
  ESO creates K8s Secret "dynakube" with the actual token values

  2. DynaKube CR:
     spec:
       apiUrl: https://YOUR_TENANT.live.dynatrace.com/api
       tokens: dynakube   # ← references the K8s Secret from step 1
       oneAgent:
         classicFullStack:
           nodeSelector: {}   # deploy on ALL nodes
     
     DT Operator reads this CR → deploys OneAgent DaemonSet

  3. DT Operator itself (Helm chart, also wave 3):
     Must be installed before DynaKube CR is created
     (DynaKube is a custom resource defined by the DT Operator)
```

**The dependency chain in wave 3:**
- DT Operator must be running (to process DynaKube CRD)
- ClusterSecretStore must be healthy (to process ExternalSecret)
- ExternalSecret "dynakube-tokens" must complete (to create K8s Secret "dynakube")
- K8s Secret "dynakube" must exist (DT Operator reads it to authenticate to DT)
- THEN DT Operator deploys OneAgent DaemonSet

ArgoCD's sync wave mechanism handles this ordering automatically.

### Wave 8: Java Services (Everything They Need Is Ready)

```
payment-service Application creates:
  - Deployment (replicas: 2 in dev)
  - Service (ClusterIP)
  - Ingress (annotations: create ALB) → ALB controller (wave 1) processes this
  - HPA (min: 2, max: 10 in dev)
  - ServiceAccount (with IRSA annotation → allows pod to call AWS APIs)
  - ExternalSecret for DB credentials:
      key: dev/payment-service/db-credentials → creates K8s Secret
      mounted as env vars: DB_HOST, DB_PORT, DB_USERNAME, DB_PASSWORD
  - PodDisruptionBudget: disabled in dev (minAvailable: 0)
    (dev doesn't need high availability)

When payment-service pod starts:
  1. OneAgent is already on the node (wave 3 put it there)
  2. OneAgent intercepts JVM startup via JVMTI attach
  3. OneAgent reads: spring.application.name = "payment-service" (from application.properties)
  4. OneAgent creates DT entity: SERVICE "payment-service"
  5. OneAgent reads K8s namespace labels: team=payments, environment=dev
  6. Entity is tagged: team:payments, environment:dev
  7. Management zone "payments-dev" rule matches this entity
  8. Entity appears in management zone scope
  9. Metric events for payment-service in dev start evaluating
  10. SLOs for payment-service in dev start measuring
```

---

## Part 5 — The Complete Timeline: 0 to Monitored

```
T+00:00 — Start terraform apply (dev environment)
T+01:00 — VPC created
T+03:00 — EKS control plane created (takes ~10 min total)
T+08:00 — Node groups join cluster
T+13:00 — ECR repos, IAM roles, S3 bucket created
T+18:00 — Dynatrace module: management zones, alerts, SLOs, synthetics created
T+20:00 — terraform apply completes

T+20:30 — Engineer runs ArgoCD install
T+23:00 — ArgoCD server running

T+23:30 — Engineer applies root-app-dev.yaml
T+23:31 — ArgoCD begins syncing wave -1

T+24:00 — Wave -1 complete: namespaces with labels exist
T+24:30 — Wave 1 starts: ALB controller Helm install
T+27:00 — Wave 1 complete: ALB controller and ExternalDNS running
T+27:30 — Wave 2 starts: ESO Helm install + ClusterSecretStore
T+29:00 — Wave 2 complete: ESO running, ClusterSecretStore healthy

T+29:30 — Wave 3 starts:
  ExternalSecret "dynakube-tokens" created
  ESO calls AWS Secrets Manager → gets DT API tokens
  K8s Secret "dynakube" created with token values
  DT Operator installed (Helm)
  DynaKube CR applied → DT Operator deploys OneAgent DaemonSet

T+33:00 — All nodes have OneAgent running
T+33:00 — Wave 3 complete

T+33:30 — Wave 8 starts:
  payment-service Deployment created (replicas: 2)
  Pods start → OneAgent attaches → JVM instrumented
  Readiness probes pass → pods added to Service endpoints
  ExternalSecret pulls DB credentials → pods have DB access
  Ingress created → ALB controller creates ALB → Route53 updated

T+38:00 — Wave 8 complete: all 3 services running

T+38:00 — DT tenant shows: payment-service entity, tagged team:payments
T+38:01 — Management zone "payments-dev" includes payment-service
T+38:30 — First synthetic check runs (Tokyo location)
T+38:30 — SLO evaluation begins

T+40:00 — Environment is fully operational and monitored.
```

**Total time from nothing to a fully monitored environment: ~40 minutes.**
And it is entirely reproducible — run the same steps for staging and production.
