# 61 — DT GitOps Flows: Commands Reference

All commands from all 7 flows and the dependency/state sections, organized by phase.

---

## Phase 0 — Verify Current State Before Any Change

```bash
# Check what image is currently deployed per environment
kubectl get deployment payment-service -n payment -o jsonpath='{.spec.template.spec.containers[0].image}'

# Check git history of gitops files (which image was deployed when)
git log --oneline -- gitops/production/app/payment-service/payment-service.yaml

# Check ArgoCD sync status for all applications
kubectl get applications -n argocd

# Check Terraform state for a specific resource
cd terraform/environments/production && terraform state list
cd terraform/environments/production && terraform state show module.dynatrace.dynatrace_metric_events.latency_p99

# Check DT metric event threshold (Flow 2)
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/settings/objects\
?schemaIds=builtin:anomaly-detection.metric-events&scopes=dt.entity.service" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.items[] | {objectId: .objectId, threshold: .value.queryDefinition.threshold}'
```

---

## Phase 1 — Flow 1: Code Deploy Commands

```bash
# Manual: trigger build after fixing a test failure
# (normally CI does this automatically)
./gradlew test jacocoTestReport jacocoTestCoverageVerification

# Check what the CI bot committed to gitops/
git log --oneline --all | grep "chore(deploy-"

# Watch the rolling update in real time
kubectl rollout status deployment/payment-service -n payment --timeout=8m

# Watch pods transition during rolling update
watch -n 2 "kubectl get pods -n payment -l app=payment-service"

# Check pod events (shows probe results, image pulls)
kubectl describe pod -n payment -l app=payment-service | grep -A 10 "Events:"

# Verify image tag after deploy
kubectl get deployment payment-service -n payment \
  -o jsonpath='{.spec.template.spec.containers[0].image}'

# Run smoke test manually
curl -f https://api.dev.company.com/actuator/health/liveness
curl -f https://api.dev.company.com/actuator/health/readiness
curl -s -X POST https://api.dev.company.com/api/v1/payments \
  -H "Content-Type: application/json" \
  -d '{"amount":1,"currency":"JPY","test":true}' | jq '.status'
```

---

## Phase 2 — Flow 1: Manual Rollback Commands

```bash
# See the last 5 deploys to production
git log --oneline -- gitops/production/app/payment-service/payment-service.yaml | head -5

# Identify the last known-good SHA
CURRENT=$(grep 'tag:' gitops/production/app/payment-service/payment-service.yaml | awk '{print $2}' | tr -d '"')
PREVIOUS=$(git log --format="%s" -- gitops/production/app/payment-service/payment-service.yaml \
  | grep "chore(deploy-prod)" | sed -n '2p' | grep -oP '(?<=payment-service=)\S+')
echo "Current (possibly broken): $CURRENT"
echo "Previous (known good): $PREVIOUS"

# Apply the rollback
sed -i "s|tag: \"${CURRENT}\"|tag: \"${PREVIOUS}\"|" \
  gitops/production/app/payment-service/payment-service.yaml
git diff  # verify only the tag changed

git add gitops/production/app/payment-service/payment-service.yaml
git commit -m "chore(rollback-prod): payment-service=${PREVIOUS} [skip ci]"
git push origin main

# Watch rollback take effect
kubectl rollout status deployment/payment-service -n payment
```

---

## Phase 3 — Flow 2: Terraform DT Config Change

```bash
# Before making a change: check current DT metric event thresholds
cd terraform/environments/production
terraform state show 'module.dynatrace.dynatrace_metric_events.latency_p99["payment-service"]'

# After editing main.tf: preview what would change
terraform plan

# Check which DT resources would be affected
terraform plan | grep -E "^  ~|^  \+|^  -"

# After the PR is merged and the workflow runs:
# Verify the new threshold in DT API
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/settings/objects/{objectId}" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.value.queryDefinition.threshold'
# Expected: 400000 (400ms in µs)

# Check SLO status after threshold change
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/slo?from=now-1h" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.slo[] | select(.name | contains("payment-service")) | {name, evaluatedPercentage, target}'
```

---

## Phase 4 — Flow 3: Infrastructure Change (Read-Only Checks)

```bash
# Check current EKS node group instance type
aws eks describe-nodegroup \
  --cluster-name company-production \
  --nodegroup-name workers \
  --query 'nodegroup.instanceTypes'

# Check current node types in the cluster
kubectl get nodes -o custom-columns='NAME:.metadata.name,INSTANCE:.metadata.labels.beta\.kubernetes\.io/instance-type'

# After node rotation: verify all nodes are new instance type
kubectl get nodes --show-labels | grep instance-type

# Verify OneAgent deployed on all new nodes
kubectl get pods -n dynatrace -l app.kubernetes.io/name=oneagent -o wide

# Check that pods are running on new nodes
kubectl get pods -n payment -o wide
```

---

## Phase 5 — Flow 4: Day-0 Bootstrap Commands

```bash
# Step 1: Terraform init and apply
cd terraform/environments/dev
terraform init
terraform plan   # review before apply
terraform apply  # creates VPC, EKS, ECR, IAM, DT resources

# Output the kubeconfig command
terraform output kubeconfig_command
# Example output: aws eks update-kubeconfig --name company-dev --region ap-northeast-1

# Configure kubectl
aws eks update-kubeconfig --name company-dev --region ap-northeast-1

# Verify cluster is accessible
kubectl get nodes
kubectl get namespaces

# Step 2: Install ArgoCD
kubectl create namespace argocd
kubectl apply -n argocd \
  -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml

# Wait for ArgoCD to be ready
kubectl wait --for=condition=available deployment/argocd-server \
  -n argocd --timeout=300s

# Get initial admin password
kubectl -n argocd get secret argocd-initial-admin-secret \
  -o jsonpath="{.data.password}" | base64 -d && echo

# Step 3: Bootstrap root app
kubectl apply -f gitops/dev/bootstrap/root-app-dev.yaml

# Watch ArgoCD sync waves progress
kubectl get applications -n argocd --watch

# Verify each wave completed
# Wave -1: namespaces
kubectl get namespaces | grep -E "payment|order|notification"

# Wave 1: ALB controller
kubectl get pods -n kube-system -l app.kubernetes.io/name=aws-load-balancer-controller

# Wave 2: ESO
kubectl get pods -n external-secrets

# Wave 3: DT operator and OneAgent
kubectl get pods -n dynatrace
kubectl get daemonset -n dynatrace oneagent

# Wave 8: services
kubectl get pods -n payment
kubectl get pods -n orders
kubectl get pods -n notifications

# Verify DT entity appeared
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/entities?entitySelector=type(SERVICE),tag(environment:dev)" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.entities[] | {entityId: .entityId, displayName: .displayName}'
```

---

## Phase 6 — Flow 5: Alert Investigation Commands

```bash
# When PagerDuty fires: check current error rate in DT
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=builtin:service.errors.server.rate\
&entitySelector=type(SERVICE),tag(environment:production),entityName(payment-service)\
&resolution=1m&from=now-10m" \
  -H "Authorization: Api-Token $DT_API_TOKEN" | jq '.resolution.data[].values'

# Check what deployed recently
git log --oneline --since="1 hour ago" -- 'gitops/production/**'

# Get the diff of the most recent deploy
LAST_SHA=$(git log --format="%H" -- gitops/production/app/payment-service/payment-service.yaml | head -1)
git show $LAST_SHA

# Check pod logs for error patterns
kubectl logs -n payment -l app=payment-service --since=5m | grep -i "error\|exception\|connection"

# Check open DT Problems
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/problems?status=open" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.problems[] | {problemId, title, severity, status, startTime}'

# After rollback: watch error rate return to normal
watch -n 30 "curl -s 'https://YOUR_TENANT.live.dynatrace.com/api/v2/metrics/query\
?metricSelector=builtin:service.errors.server.rate\
&entitySelector=type(SERVICE),entityName(payment-service)\
&resolution=1m&from=now-5m' \
  -H 'Authorization: Api-Token $DT_API_TOKEN' | jq '.resolution.data[].values[-1]'"
```

---

## Phase 7 — Flow 7: Drift Detection Commands

```bash
# Run drift detection manually (same as the daily job)
cd terraform/environments/production
terraform init
terraform plan -refresh-only -detailed-exitcode -no-color 2>&1 | tee drift.txt
echo "Exit code: $?"
# 0 = no drift, 2 = drift found, 1 = error

# View the drift output
cat drift.txt | grep -A 5 "Objects have changed outside"

# If drift found: check the specific resource
terraform state show 'module.eks.aws_eks_node_group.workers'

# Confirm what AWS currently shows (for EKS node group)
aws eks describe-nodegroup \
  --cluster-name company-production \
  --nodegroup-name workers \
  --query 'nodegroup.scalingConfig'

# If drift is intentional: update Terraform and plan again to confirm no drift
# Edit terraform.tfvars: node_desired_size = 8
terraform plan -refresh-only -detailed-exitcode
# Exit code should now be 0 (drift resolved because .tf matches reality)
```

---

## Phase 8 — Verify the Dependency Chain Is Healthy

```bash
# Check all ArgoCD applications and their sync status
kubectl get applications -n argocd -o custom-columns=\
'NAME:.metadata.name,SYNC:.status.sync.status,HEALTH:.status.health.status'

# Check ESO is able to reach Secrets Manager
kubectl get clustersecretstore cluster-secret-store -o jsonpath='{.status.conditions}'

# Check ExternalSecrets are syncing
kubectl get externalsecrets -A

# Verify DT tokens are in the K8s Secret
kubectl get secret dynakube -n dynatrace -o jsonpath='{.data}' | jq 'keys'
# Expected: ["apiToken", "dataIngestToken"]

# Check OneAgent DaemonSet coverage (all nodes should have a pod)
kubectl get daemonset oneagent -n dynatrace
# DESIRED and READY should match the number of nodes

# Verify DT management zone includes expected entities
curl -s "https://YOUR_TENANT.live.dynatrace.com/api/v2/entities\
?entitySelector=type(SERVICE),mzName(payments-production)&pageSize=50" \
  -H "Authorization: Api-Token $DT_API_TOKEN" \
  | jq '.entities[] | .displayName'
```
