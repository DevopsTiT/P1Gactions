# Terraform + Dynatrace + GitOps + ArgoCD + GitHub Actions — Flow Map & Logic

> **What this is:** The complete picture of how all five systems connect and talk to each other. Every arrow explained. Every trigger explained. No loose ends.

---

## The Master Flow Map

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│  DEVELOPER                                                                      │
│  git push / git merge to main                                                   │
└─────────────────────────┬───────────────────────────────────────────────────────┘
                          │
          ┌───────────────┴────────────────────────────────┐
          │                                                │
          ▼                                                ▼
  Changed: services/** or charts/**             Changed: terraform/environments/** or
                                                         terraform/modules/**
          │                                                │
          ▼                                                ▼
┌─────────────────────┐                      ┌────────────────────────────────┐
│  GITHUB ACTIONS     │                      │  GITHUB ACTIONS                │
│  <service>-ci.yaml  │                      │  terraform-*.yaml              │
│                     │                      │                                │
│  1. Test (Gradle)   │                      │  Infra pipeline:               │
│  2. Build Docker    │                      │   plan all 3 envs (matrix)     │
│  3. Trivy scan      │                      │   apply dev→stg→prod (seq)     │
│  4. Push to ECR     │                      │   drift detection (daily)      │
│  5. sed image tag   │                      │                                │
│  6. git commit      │                      │  DT pipeline:                  │
│     [skip ci]       │                      │   plan (PR comment)            │
│  7. git push →      │                      │   apply (on merge)             │
│     gitops/dev/     │                      │   prod: manual approval gate   │
└────────┬────────────┘                      └──────────────┬─────────────────┘
         │                                                   │
         │ pushes new image tag to:                          │ runs:
         │ gitops/<env>/app/<svc>/<svc>.yaml                 │ terraform apply
         │                                                   │
         ▼                                                   ▼
┌─────────────────────────────────────────┐    ┌────────────────────────────────────┐
│  GIT REPOSITORY                         │    │  DYNATRACE TENANT (SaaS)           │
│  (github.com/company/java-3envs)        │    │                                    │
│                                         │    │  Resources created/updated:        │
│  gitops/                                │    │  - Management zones                │
│    dev/                                 │    │  - Alerting profiles (4 tiers)     │
│      app/payment-service/              │    │  - 8 Metric events per service     │
│        payment-service.yaml            │    │  - SLOs (availability + latency)   │
│          image.tag: "abc123" ← CI wrote │    │  - HTTP Synthetic monitors         │
│      namespaces/namespaces.yaml        │    │  - PagerDuty notifications         │
│      networking/aws-lbc.yaml           │    │  - Slack notifications             │
│      secrets/cluster-secret-store.yaml │    │                                    │
│      monitoring/dynatrace/dynakube.yaml│    │  All scoped to:                    │
│  terraform/                             │    │  management_zone = team+env        │
│  charts/                                │    │  metric_event → entity filter =    │
│  services/                              │    │    "payment-service" + "production" │
└──────────┬──────────────────────────────┘    └──────────────┬─────────────────────┘
           │                                                   │
           │ ArgoCD polls every 3 minutes                      │ OneAgent sends metrics
           ▼                                                   │ to ActiveGate →
┌─────────────────────────────────────────┐                    │ DT evaluates every 1 min
│  ARGOCD (running inside each EKS cluster)│                    │
│                                         │                    │
│  root-app-dev.yaml applied manually     │                    │
│  → watches gitops/dev/ recursively      │                    │
│                                         │                    │
│  Detects: image tag changed in git      │                    │
│  → re-renders Helm chart               │                    │
│  → applies Deployment with new tag      │                    │
│  → rolling update: 0 downtime          │                    │
│                                         │                    │
│  Sync waves guarantee order:            │                    │
│   wave -1: namespaces (labels!)  ←──────────────────────────┘
│   wave  1: ALB controller               │  ↑ labels flow to DT
│   wave  1: ExternalDNS                  │    for management zones
│   wave  2: ESO + ClusterSecretStore     │
│   wave  3: DynaKube ← ExternalSecret   │
│            pulls DT tokens from         │
│            Secrets Manager             │
│   wave  8: payment-service ← new tag   │
│            order-service               │
│            notification-service        │
└──────────┬──────────────────────────────┘
           │
           ▼
┌─────────────────────────────────────────┐
│  EKS CLUSTER                            │
│                                         │
│  payment-service pod (new image abc123) │
│  order-service pod                      │
│  notification-service pod               │
│                                         │
│  OneAgent DaemonSet (one per node)      │
│  → hooks into all JVMs via JVMTI       │
│  → reads spring.application.name       │
│    = "payment-service"                  │
│  → creates DT service entity named     │
│    "payment-service"                    │
│  → sends metrics to ActiveGate         │
│                                         │
│  ActiveGate (2 replicas, HA)            │
│  → relays to DT tenant                  │
└─────────────────────────────────────────┘
```

---

## Logic Flow 1 — Code Deploy (The Most Common Path)

```
Developer merges PR to main
(changes: services/payment-service/src/...)

──────────────────────────────────────────────────────────────
GITHUB ACTIONS: payment-service-ci.yaml

  WHY TRIGGERS: path filter matches services/payment-service/**

  Job 1 — test:
    Runs: ./gradlew test jacocoTestReport jacocoTestCoverageVerification
    EXIT if: tests fail OR coverage < 70%
    → No image built. Pipeline stops.

  Job 2 — build-and-deploy-dev (needs: test, only on push):
    OIDC → assume role in account 123456789010
    docker buildx → linux/amd64 + linux/arm64 → push to dev ECR
    IMAGE_TAG = github.sha (e.g., "abc123def456...")
    Trivy scan → EXIT if CRITICAL/HIGH CVE
    sed → gitops/dev/app/payment-service/payment-service.yaml
              image.tag: "PLACEHOLDER" → "abc123def456..."
    git commit -m "chore(deploy-dev): payment-service=abc123 [skip ci]"
    git push → main
    kubectl rollout status --timeout=8m (blocks until pods ready)

──────────────────────────────────────────────────────────────
GIT REPOSITORY: receives the commit
  gitops/dev/app/payment-service/payment-service.yaml updated

──────────────────────────────────────────────────────────────
ARGOCD: detects change within 3 minutes (polling interval)

  WHY KNOWS TO CHECK: root-app-dev.yaml watches gitops/dev/ recursively
  
  Finds: payment-service.yaml has new image tag
  Action:
    helm template charts/payment-service
    valueFiles: [values.yaml, values-dev.yaml]
    inline values: image.tag = "abc123def456..."
    
    Renders → Kubernetes Deployment spec with new image
    Applies → Kubernetes API
    
    Kubernetes executes rolling update:
      maxUnavailable: 0  → no pod taken down until replacement is Ready
      maxSurge: 1        → one extra pod allowed temporarily
      
      New pod starts → passes startupProbe (up to 20 min in dev)
      → passes readinessProbe (/actuator/health/readiness returns UP)
      → added to Service endpoints (ALB routes to it)
      → old pod removed from endpoints → receives SIGTERM
      → preStop sleep 15s (in-flight requests finish)
      → Spring Boot graceful shutdown (30s max)
      → pod terminates

──────────────────────────────────────────────────────────────
GITHUB ACTIONS: smoke-test-dev (needs: build-and-deploy-dev)

  curl /actuator/health/liveness  → 200 required
  curl /actuator/health/readiness → 200 required
  POST /api/v1/payments           → assert status = "created"
  
  WHY: verifies the new pod actually serves traffic correctly,
       not just "K8s says it's ready"

──────────────────────────────────────────────────────────────
GITHUB ACTIONS: promote-to-staging (needs: smoke-test-dev)

  OIDC → assume role in 123456789010 (dev ECR read)
  OIDC → assume role in 123456789011 (staging ECR push)
  
  docker pull ECR_DEV:abc123
  docker tag  ECR_DEV:abc123 → ECR_STAGING:abc123
  docker push ECR_STAGING:abc123
  
  sed → gitops/staging/app/payment-service/payment-service.yaml
            image.tag: "old-sha" → "abc123"
  git pull origin main  ← prevent push rejection if other pipelines committed
  git commit + git push [skip ci]
  kubectl rollout status --timeout=10m on staging cluster

... → test-staging (k6 load test 50 VUs 3 min)
... → promote-to-production (environment: production → MANUAL APPROVAL GATE)
... → verify-production (smoke test + auto-rollback if fails)
```

---

## Logic Flow 2 — DT Config Change (Threshold Tuning)

```
SRE edits: terraform/environments/production/main.tf
  payment-service.latency_p99_ms: 300 → 400

──────────────────────────────────────────────────────────────
GITHUB ACTIONS: terraform-dynatrace-production.yaml

  WHY TRIGGERS: path filter matches terraform/environments/production/**

  Job: plan (on pull_request):
    OIDC → assume role: github-actions-dynatrace-plan (read-only)
    terraform init (connects to S3 state: company-terraform-state-prod)
    terraform plan →
      ~ dynatrace_metric_events.latency_p99["payment-service"]
          threshold: 300000 → 400000   (ms × 1000 = µs)
      ~ dynatrace_slo_v2.latency["payment-service"]
          metric_expression: le(...,300000) → le(...,400000)
    Posts plan as PR comment → reviewer approves

  Job: apply (on push to main):
    OIDC → assume role: github-actions-dynatrace-apply (write)
    github environment: production → PAUSES for human approval
    After approval:
    terraform apply -auto-approve
    → DT REST API: PUT /api/v2/settings/objects/abc123 (metric event)
    → DT REST API: PUT /api/v2/settings/objects/def456 (SLO)
    
    Result in DT tenant:
      latency alert now fires at 400ms instead of 300ms
      latency SLO now measures "requests under 400ms"

──────────────────────────────────────────────────────────────
DYNATRACE TENANT:
  Metric event evaluation continues every 1 min
  New threshold in effect immediately after apply
  Any in-progress Problems re-evaluated against new threshold
```

---

## Logic Flow 3 — Infrastructure Change (EKS Node Size)

```
SRE edits: terraform/environments/production/terraform.tfvars
  node_instance_types: ["m5.xlarge"] → ["m7g.xlarge"]

──────────────────────────────────────────────────────────────
GITHUB ACTIONS: terraform-infra.yaml

  WHY TRIGGERS: path filter matches terraform/environments/**
                (AND terraform/modules/eks/** OR vpc/** if module changed)

  Job: plan (matrix, parallel, on PR):
    3 jobs run simultaneously:
      plan-dev:     assume 123456789010 plan role → terraform plan
      plan-staging: assume 123456789011 plan role → terraform plan
      plan-prod:    assume 123456789012 plan role → terraform plan
    
    fail-fast: false → all 3 complete even if one fails
    Each posts plan comment to PR with ✅ or ⚠️ emoji
    Reviewer sees: prod plan shows EKS managed node group update

  Job: apply-dev (on push, no approval):
    terraform apply → EKS updates node group in company-dev account
    
  Job: apply-staging (needs: apply-dev):
    Sequential → only after dev apply succeeds
    
  Job: apply-production (needs: apply-staging, environment: production):
    PAUSES for manual approval
    After approval: terraform apply → EKS updates node group in company-prod account
    
  Why sequential: if the EKS update is broken (bad AMI, wrong instance type config),
    dev catches it → staging and prod are never touched.
    Dev is the canary for infrastructure changes.

──────────────────────────────────────────────────────────────
ARGOCD (no change needed):
  No gitops files changed → ArgoCD does nothing
  Existing pods continue running on new nodes (Karpenter/node rotation handles it)
  
DYNATRACE:
  OneAgent DaemonSet auto-installs on new nodes as they come up
  (K8s DaemonSet: always ensures one pod per node, including new nodes)
  New nodes immediately monitored
```

---

## Logic Flow 4 — New Environment Bootstrap (Day 0)

```
Platform engineer sets up a brand new environment from scratch.

──────────────────────────────────────────────────────────────
STEP 1 — TERRAFORM (manual, one-time):

  cd terraform/environments/dev
  terraform init   ← configures S3 backend, downloads providers
  terraform apply  ← creates:
    - VPC (10.10.0.0/16, 3 AZs, one NAT per AZ)
    - EKS cluster (company-dev)
    - System node group (dedicated=system taint)
    - IAM IRSA roles for each service
    - ECR repositories (payment, order, notification)
    - S3 state bucket exists already (created manually beforehand)
    
  Also calls module "dynatrace":
    → Creates in DT tenant for dev environment:
      management zones: notifications-dev, orders-dev, payments-dev
      alerting profiles: warning + info for all teams (no CRITICAL/HIGH in dev)
      8 metric events per service (relaxed thresholds)
      SLOs (90% target, dev only)
      Synthetics (Tokyo only, 5-min interval)
      Slack notifications → #alerts-<team>
      NO PagerDuty (pagerduty_integration_keys = {} → 0 PD resources)

──────────────────────────────────────────────────────────────
STEP 2 — ARGOCD INSTALL (manual, one-time):

  kubectl create namespace argocd
  kubectl apply -n argocd \
    -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
  kubectl wait --for=condition=available deployment/argocd-server -n argocd --timeout=300s

──────────────────────────────────────────────────────────────
STEP 3 — ROOT APP (manual, one-time):

  kubectl apply -f gitops/dev/bootstrap/root-app-dev.yaml
  
  This creates ONE ArgoCD Application that watches gitops/dev/ recursively.
  ArgoCD immediately starts syncing everything in gitops/dev/ in wave order:

  Wave -1: namespaces-dev Application
    → Renders charts/namespaces with values:
        payment-ns: labels team:payments, environment:dev
        order-ns:   labels team:orders, environment:dev
        ...
    → Creates 5 namespaces with labels
    → OneAgent will read these labels → DT auto-tags services → management zones work

  Wave 1:  aws-lbc-dev Application
    → Installs AWS Load Balancer Controller Helm chart
    → IRSA annotation: company-dev-aws-load-balancer-controller role
    → Controller can now create ALBs from Ingress resources
    
    external-dns-dev Application
    → Installs ExternalDNS Helm chart
    → domainFilters: dev.company.com ONLY
    → txtOwnerId: "company-dev" (prevents cross-cluster DNS deletion)

  Wave 2:  cluster-secret-store Application (ESO + ClusterSecretStore)
    → Installs External Secrets Operator
    → Creates ClusterSecretStore pointing to Secrets Manager in dev account
    → Now any ExternalSecret in any namespace can fetch from Secrets Manager

  Wave 3:  dynatrace-operator Application
    → Installs DT Operator Helm chart
    
    dynakube-tokens ExternalSecret (also wave 3)
    → ESO reads: dev/dynatrace/api-token from Secrets Manager
    → Creates K8s Secret "dynakube" with apiToken + dataIngestToken
    → (ESO can do this because wave 2 already installed ESO + ClusterSecretStore)
    
    DynaKube CR (also wave 3)
    → DT Operator reads DynaKube spec
    → Deploys OneAgent DaemonSet on every node
    → Deploys ActiveGate (1 replica for dev)
    → Within 5 minutes: all nodes have OneAgent running

  Wave 8:  payment-service-dev Application
    → helm template charts/payment-service
         valueFiles: [values.yaml, values-dev.yaml]
         inline values: ECR dev repo, dev IRSA role, dev hostname
    → Applies: Deployment, Service, Ingress, HPA, PDB(disabled in dev), ServiceAccount
    → ExternalSecret: pulls DB credentials from dev/payment-service/db-credentials
    → After pod starts: OneAgent attaches → reads spring.application.name = "payment-service"
    → DT entity "payment-service" appears in DT UI → tagged team:payments, environment:dev
    → Management zone "payments-dev" now includes payment-service entity
    
    (same for order-service, notification-service)

──────────────────────────────────────────────────────────────
STEP 4 — VERIFY (automated from this point):
  CI/CD pipelines trigger on every code push
  DT monitoring active for all services
  Day-0 complete. Environment is live.
```

---

## Logic Flow 5 — Alert Fires and Resolves

```
14:00:00 — payment-service error rate rises to 5% (new deploy broke DB connection)

──────────────────────────────────────────────────────────────
ONEAGENT (on each node running payment-service pods):
  Intercepts: JDBC execute() throws connection exception
  Records: HTTP request failed with 500 status
  Metric: builtin:service.errors.server.rate = 5.0%
  Sends to ActiveGate → DT tenant

──────────────────────────────────────────────────────────────
DT TENANT — Metric event evaluation loop (runs every 1 min):
  14:01:00 — evaluate error_rate["payment-service"]:
    value: 5.0% > threshold: 0.1% → IN VIOLATION
    violating_samples counter: 1 (need 3)
    
  14:02:00 — value: 4.8% > 0.1% → counter: 2
  14:03:00 — value: 5.1% > 0.1% → counter: 3 → THRESHOLD MET
  
  Creates Problem:
    severity:   ERROR (because event_type = ERROR_EVENT)
    title:      "[PRODUCTION] payment-service: High error rate (>0.1%)"
    entity:     dt.entity.service:payment-service
    zone:       payments-production (entity has tag team:payments + environment:production)

──────────────────────────────────────────────────────────────
ALERTING PROFILE EVALUATION:

  payments-production-critical:
    severity filter: AVAILABILITY only → ≠ ERROR → SKIP

  payments-production-high:
    severity filter: ERROR ✅
    management zone: payments-production ✅
    delay_in_minutes: 2 → start 2-minute timer

  (other profiles: wrong severity or wrong zone → all skipped)

──────────────────────────────────────────────────────────────
14:05:00 (2 minutes after Problem created):

  Timer elapsed → fire notification
  
  dynatrace_pagerduty_notification.high["payments"]:
    PagerDuty API call: create incident
    service_api_key: "pd-key-payments-abc123"
    message: "OPEN | ERROR | [PRODUCTION] payment-service: High error rate (>0.1%)"
    urgency: high
    
  PagerDuty → push notification to payments oncall engineer's phone
  
  dynatrace_slack_notification.warning.high["payments"] → NOT fired
  (high severity = PagerDuty, not Slack, in production)

──────────────────────────────────────────────────────────────
SRE RESPONSE:
  Opens DT Problem URL from PagerDuty
  Sees: "Related change: deployment updated image tag 2 minutes ago"
  Reads logs: "Could not acquire connection from pool: Connection refused"
  
  Decision: rollback
  
  git log --oneline -- gitops/production/app/payment-service/payment-service.yaml
  # abc1234 chore(deploy-prod): payment-service=new-sha [skip ci]  ← current (broken)
  # def5678 chore(deploy-prod): payment-service=old-sha [skip ci]  ← previous (working)
  
  sed -i 's|tag: "new-sha"|tag: "old-sha"|' gitops/production/app/...
  git commit -m "chore(rollback-prod): payment-service=old-sha [skip ci]"
  git push → main

──────────────────────────────────────────────────────────────
ARGOCD detects rollback commit within 3 minutes:
  Applies Deployment with old-sha image → rolling update → old pods running again
  error rate returns to 0% within 5 minutes of rollback commit

──────────────────────────────────────────────────────────────
DT TENANT — Metric event re-evaluation:
  14:15:00 — error_rate: 0% < 0.1% → NOT in violation
  dealerting_samples counter: 1 (need 3)
  14:16:00 — 0% → counter: 2
  14:17:00 — 0% → counter: 3 → PROBLEM CLOSES
  
  Slack notification sent (resolved message):
    dynatrace_slack_notification.warning["payments"] → #alerts-payments
    "[PRODUCTION] RESOLVED | ERROR | [PRODUCTION] payment-service: High error rate (>0.1%) | <link>"
  
  PagerDuty: incident auto-resolved
```

---

## Logic Flow 6 — Module Change (Affects All Environments)

```
SRE finds bug: latency metric event uses wrong entity dimension key.
Fix: terraform/modules/dynatrace/main.tf
  event_entity_dimension_key: "dt.entity.process_group_instance"
  → changed to: "dt.entity.service"  (correct for HTTP metrics)

──────────────────────────────────────────────────────────────
GITHUB ACTIONS triggers THREE pipelines simultaneously:

  terraform-dynatrace-dev.yaml
    WHY: paths: terraform/modules/dynatrace/** ← module path listed
    plan → posts to PR
    
  terraform-dynatrace-staging.yaml
    WHY: same path trigger
    plan → posts to PR
    
  terraform-dynatrace-production.yaml
    WHY: same path trigger
    plan → posts to PR
    
  ALL THREE plans show:
    ~ dynatrace_metric_events.latency_p99["payment-service"]
        event_entity_dimension_key: "dt.entity.process_group_instance" → "dt.entity.service"
    ~ dynatrace_metric_events.latency_p99["order-service"]      (same)
    ~ dynatrace_metric_events.latency_p99["notification-service"] (same)
    (3 services × 3 envs = 9 resources updated)

──────────────────────────────────────────────────────────────
On merge:
  Dev:     applies automatically (no gate)
  Staging: applies automatically (no gate)
  Prod:    pauses for environment: production approval → human approves → applies

Result: all 3 environments fixed in the same deployment cycle.
Without module paths in triggers: only environments whose config file changed
would trigger → you'd need to manually touch each env file to propagate the fix.
```

---

## Logic Flow 7 — Daily Drift Detection

```
Every day at 02:00 JST (17:00 UTC):

──────────────────────────────────────────────────────────────
GITHUB ACTIONS: terraform-infra.yaml (schedule trigger)
  drift-detect job (matrix: dev, staging, production in parallel):

  For each environment:
    terraform init
    terraform plan -refresh-only -detailed-exitcode -no-color 2>&1 | tee drift.txt
    EXIT_CODE=${PIPESTATUS[0]}
    # 0 = no drift, 1 = error, 2 = drift found
    
  If exit code 2 (drift found):
    github.rest.issues.create({
      title: "[DRIFT] Terraform infra drift detected in production",
      body: (full terraform plan output showing what changed),
      labels: ["terraform-drift", "infrastructure", "production"]
    })

──────────────────────────────────────────────────────────────
WHAT CAUSES DRIFT:

  Scenario: SRE manually changed EKS node group size in AWS Console
    Real AWS: node_desired_size = 8
    Terraform state: node_desired_size = 6
    
    Plan -refresh-only output:
      ~ module.eks.aws_eks_node_group.workers:
          ~ scaling_config {
              ~ desired_size = 6 -> 8   (drift!)
            }
    
    GitHub Issue created. SRE decides:
    Option A: update Terraform to codify the 8-node decision (terraform.tfvars update → PR → apply)
    Option B: next terraform apply will reset to 6 (revert the manual change)

──────────────────────────────────────────────────────────────
WHY -refresh-only (not regular plan):
  Regular plan: shows diff between .tf files AND real state
    → would show ALL pending config changes too (noise)
    → hard to isolate "what changed externally" from "what my code would change"
    
  -refresh-only: ONLY shows what changed externally (real world vs state)
    → clean signal: "something changed in AWS that Terraform didn't do"
    → no noise from code changes
```

---

## The Dependency Web — What Depends on What

```
┌────────────────────────────────────────────────────────────────────────────┐
│ WHAT MUST EXIST BEFORE WHAT CAN WORK                                       │
│                                                                            │
│  S3 bucket + DynamoDB table                                                │
│    ↓ needed by                                                             │
│  terraform init (state backend)                                            │
│    ↓ enables                                                               │
│  terraform apply (creates EKS, VPC, ECR, IRSA roles)                      │
│    ↓ outputs                                                               │
│  EKS cluster endpoint + OIDC issuer URL                                    │
│    ↓ needed by                                                             │
│  kubectl (engineers can now use kubectl)                                   │
│    ↓ enables                                                               │
│  ArgoCD install (kubectl apply manifests)                                  │
│    ↓ enables                                                               │
│  root-app-dev.yaml apply (ArgoCD bootstrap)                                │
│    ↓ triggers                                                              │
│  wave -1: namespaces (with DT auto-tag labels)                             │
│    ↓ required by                                                           │
│  wave 2: ESO (deploys into external-secrets namespace)                     │
│    ↓ required by                                                           │
│  wave 3: ExternalSecret for DT tokens (ESO must be running)               │
│    ↓ produces                                                              │
│  K8s Secret "dynakube" (DT tokens)                                        │
│    ↓ required by                                                           │
│  wave 3: DynaKube CR (needs the K8s Secret to authenticate to DT)        │
│    ↓ deploys                                                               │
│  OneAgent DaemonSet on every node                                          │
│    ↓ required by                                                           │
│  wave 8: Java service pods (OneAgent instruments them on start)            │
│    ↓ sends metrics to                                                      │
│  ActiveGate → DT tenant                                                    │
│    ↓ DT evaluates metric events → fires alerts via                        │
│  PagerDuty + Slack (Terraform configured these)                            │
│                                                                            │
│  GitHub Actions (triggers independently on git events):                    │
│    service-ci.yaml → builds image → pushes to ECR → updates gitops/       │
│      ↓ ArgoCD detects gitops change → deploys new image                   │
│    terraform-infra.yaml → manages EKS/VPC/IRSA                            │
│    terraform-dynatrace-*.yaml → manages DT config                         │
└────────────────────────────────────────────────────────────────────────────┘
```

---

## Trigger Summary — What Starts What

```
┌─────────────────────────────────────────┬──────────────────────────────────────┐
│  EVENT                                  │  WHAT RUNS                           │
├─────────────────────────────────────────┼──────────────────────────────────────┤
│ PR opened/updated (any file)            │ test job only (in matching CI file)  │
│ Merge: services/payment-service/**      │ payment-service-ci.yaml (all 7 jobs) │
│ Merge: charts/payment-service/**        │ payment-service-ci.yaml (same)       │
│ Merge: terraform/environments/dev/**    │ terraform-dynatrace-dev.yaml         │
│         OR terraform/modules/dynatrace/**│ terraform-infra.yaml (dev env only)  │
│ Merge: terraform/modules/eks/**         │ terraform-infra.yaml (all 3 envs)    │
│ Merge: gitops/**                        │ NOTHING (ArgoCD handles this)        │
│ ArgoCD poll (every 3 min)               │ ArgoCD sync (if gitops/ changed)     │
│ Daily 02:00 JST (cron schedule)         │ terraform-infra.yaml drift detection │
│ OneAgent detects new process            │ JVM instrumentation (automatic)      │
│ DT metric > threshold for N minutes    │ DT creates Problem                   │
│ DT Problem matches alerting profile    │ PagerDuty call / Slack message        │
└─────────────────────────────────────────┴──────────────────────────────────────┘
```

---

## State Map — What Stores Truth Where

```
┌───────────────────┬──────────────────────────────────────────────────────────┐
│ SYSTEM            │ WHAT IT IS THE SOURCE OF TRUTH FOR                       │
├───────────────────┼──────────────────────────────────────────────────────────┤
│ Git repo          │ Desired state of EVERYTHING:                             │
│ (main branch)     │  - gitops/: what should be in each K8s cluster           │
│                   │  - terraform/: what AWS + DT config should look like      │
│                   │  - services/: application source code                     │
│                   │  - charts/: Helm templates and values                     │
├───────────────────┼──────────────────────────────────────────────────────────┤
│ Terraform state   │ What Terraform currently MANAGES in AWS + DT:            │
│ (S3 bucket)       │  - Resource IDs (EKS cluster ID, DT metric event ID)     │
│                   │  - Current attribute values                               │
│                   │  Separate bucket per environment                          │
├───────────────────┼──────────────────────────────────────────────────────────┤
│ ArgoCD            │ Sync status of gitops/ → K8s cluster:                    │
│ (in-cluster)      │  - Is cluster state matching gitops/ (Synced/OutOfSync)  │
│                   │  - Last sync time                                          │
│                   │  - Application health (Healthy/Degraded)                  │
├───────────────────┼──────────────────────────────────────────────────────────┤
│ DT tenant         │ Real-time observability data:                             │
│ (SaaS)            │  - All metrics (60s resolution)                           │
│                   │  - Distributed traces (real-time)                         │
│                   │  - Logs (30s delay from stdout)                           │
│                   │  - Current alert/problem state                            │
│                   │  - SLO compliance (rolling 30 days)                       │
├───────────────────┼──────────────────────────────────────────────────────────┤
│ AWS Secrets       │ Credentials (the ONLY place these live):                 │
│ Manager           │  - DT API tokens                                          │
│                   │  - PagerDuty integration keys                             │
│                   │  - Slack webhook URLs                                     │
│                   │  - DB credentials per service per environment             │
├───────────────────┼──────────────────────────────────────────────────────────┤
│ ECR               │ Docker images by content-addressable SHA tag:            │
│ (per account)     │  - Dev ECR: all images that passed tests + Trivy         │
│                   │  - Staging ECR: images that passed dev smoke tests        │
│                   │  - Prod ECR: images that passed k6 staging tests          │
└───────────────────┴──────────────────────────────────────────────────────────┘
```
