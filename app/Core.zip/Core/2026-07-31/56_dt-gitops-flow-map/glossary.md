# Glossary — Terraform + Dynatrace + GitOps + ArgoCD + GitHub Actions Flow Map

Every term in main.md. Plain language for an SRE beginner.

---

**GitHub Actions**
CI/CD automation built into GitHub. YAML files in `.github/workflows/` run automated jobs when triggered by git events (push, PR, schedule). Each job runs on a fresh cloud VM. Why it matters: the automation engine — nothing deploys or configures without it.

**`on.paths` trigger filter**
A GitHub Actions setting that only starts the workflow when specific file paths changed. If no matching files changed, the workflow is completely skipped — no runner starts, no cost. Why it matters: prevents a DT config change from triggering a Java service rebuild.

**`github.sha`**
Built-in GitHub Actions variable — the 40-character git commit SHA. Used as the Docker image tag. Why it matters: unique per commit, immutable, traceable — `git show abc123` shows exactly what code is running in production.

**`[skip ci]`**
Text in a git commit message that prevents GitHub Actions from triggering on that commit. CI writes gitops YAML updates back to git — without this, that commit re-triggers CI endlessly. Why it matters: breaks the infinite loop.

**OIDC (OpenID Connect) for AWS**
GitHub Actions authenticates to AWS by exchanging a short-lived GitHub token for temporary AWS credentials. No stored secrets. Credentials expire in 15 minutes. Why it matters: the secure, credential-free way to call AWS APIs from CI.

**`environment: production` (GitHub Actions)**
A named deployment environment with required human reviewers. The pipeline pauses here and waits for a human to click Approve before the job runs. Why it matters: the production gate — no production change happens without explicit human sign-off after all automated checks pass.

**`fail-fast: false` (matrix strategy)**
In a matrix job (multiple envs running in parallel), prevents cancelling other jobs if one fails. Why it matters: lets you see all 3 environment plans even when one has an error — useful for diagnosing which env is affected.

**Sequential apply chain (`needs:`)**
`apply-staging: needs: apply-dev` means staging only runs after dev succeeds. Why it matters: dev is the canary — if a Terraform change breaks dev, staging and production are never touched.

**`terraform plan -refresh-only`**
Checks what changed in real AWS vs what Terraform's state expects — without planning any code changes. Why it matters: drift detection needs to show "someone changed something externally" without the noise of "here's what my code would change."

**`-detailed-exitcode`**
Changes terraform plan exit codes: 0 = no changes, 1 = error, 2 = changes pending. Why it matters: scripts use exit code 2 to detect drift; a normal plan always exits 0 even when changes exist.

**`${PIPESTATUS[0]}`**
Bash variable capturing the exit code of the first command in a pipe. `terraform plan | tee file.txt` → `${PIPESTATUS[0]}` gives terraform's exit code, not tee's. Why it matters: drift detection must read terraform's exit code 2, but `$?` always shows tee's 0.

**Drift (Terraform)**
When real AWS/DT state diverges from what Terraform's state file expects. Caused by manual console changes, API calls outside Terraform, or provider updates. Why it matters: undetected drift causes unexpected changes on the next `terraform apply`.

**ArgoCD**
A GitOps controller running inside the Kubernetes cluster. Polls a Git repository every 3 minutes and applies any changes it finds in the watched path. Why it matters: the delivery engine — CI updates gitops/, ArgoCD delivers it to the cluster.

**`root-app-dev.yaml`**
The single ArgoCD Application applied manually once to bootstrap an environment. It watches `gitops/dev/` recursively, discovering and managing all other Applications. Why it matters: one `kubectl apply` command sets up the entire environment's automated delivery.

**App of Apps pattern**
One ArgoCD Application watches a folder containing other Application YAMLs. The root app discovers and manages all child apps. Why it matters: reduces manual bootstrap to one command.

**sync-wave**
An ArgoCD annotation (`argocd.argoproj.io/sync-wave: "3"`) that controls deploy order. Lower numbers first. Why it matters: namespaces must exist before apps deploy into them; ESO must run before ExternalSecrets can fetch tokens.

**`prune: true` (ArgoCD)**
Deletes Kubernetes resources when their YAML is removed from Git. Why it matters: without this, deleting a service from gitops leaves orphaned pods running.

**`selfHeal: true` (ArgoCD)**
Reverts manual `kubectl` changes back to what Git says within ~3 minutes. Why it matters: Git is the only source of truth — manual changes don't stick.

**`recurse: true` (ArgoCD Application)**
Tells ArgoCD to scan the Git path recursively for Kubernetes manifests. Why it matters: the root app can discover all nested YAML files in the gitops folder without listing them individually.

**DynaKube**
A Kubernetes custom resource that configures how Dynatrace is deployed in the cluster (OneAgent mode, ActiveGate settings, token references). Why it matters: the single config object controlling the entire DT monitoring stack.

**ExternalSecret (ESO)**
A Kubernetes custom resource that fetches a secret from AWS Secrets Manager and creates a K8s Secret. The DT tokens ExternalSecret creates the "dynakube" K8s Secret that DynaKube needs. Why it matters: DT tokens never stored in Git — only in Secrets Manager.

**ClusterSecretStore**
An ESO resource defining how to connect to AWS Secrets Manager. Referenced by all ExternalSecrets in the cluster. Why it matters: one connection configuration, used by every ExternalSecret across all namespaces.

**OneAgent DaemonSet**
A Kubernetes DaemonSet that ensures exactly one OneAgent pod runs on every node. Hooks into all JVMs via JVMTI. Why it matters: automatic, zero-code-change instrumentation for all services.

**ActiveGate**
DT proxy deployment inside the cluster. OneAgent pods send data here; ActiveGate batches and forwards to DT SaaS tenant. Also polls K8s API for workload state. Why it matters: reduces outbound connections and handles log analytics.

**Management zone**
A DT filter scoping alerts and dashboards to specific entities (e.g., `team:payments AND environment:production`). Why it matters: payments team only gets paged for payment-service; wrong-team pages cause alert fatigue.

**DT auto-tagging rule**
A DT Settings rule (configured once in DT UI) that applies tags to entities based on Kubernetes namespace labels. Why it matters: the bridge between `namespaces.yaml` labels and DT management zone conditions.

**Alerting profile**
DT configuration mapping a Problem severity + management zone to a notification channel with a delay. Why it matters: the routing logic — ERROR severity → HIGH tier → PagerDuty push, not a phone call.

**Problem (DT)**
A DT event created when a metric event fires. Contains severity, affected entity, start time, root cause hints. Why it matters: what SREs investigate; it links to relevant traces, logs, and K8s events.

**`violating_samples`**
How many consecutive metric evaluation minutes must exceed the threshold before a Problem is created. Why it matters: prevents transient spikes from waking oncall — 1-minute CPU spike during GC won't page anyone.

**`dealerting_samples`**
How many consecutive minutes must return to normal before the Problem is closed. Why it matters: prevents flapping — alert fires, clears, fires, clears every minute.

**`alert_on_no_data`**
Fires the alert even when DT receives zero data points. Why it matters: the only signal that catches silent outages where the service is so broken it can't send any metrics.

**Error budget**
The allowed failures before breaching the SLO. For 99.9%: 0.1% of requests = ~43 minutes of downtime per month. Why it matters: quantifies reliability — depleted budget = freeze feature work and fix reliability.

**Burn rate**
How fast the error budget is consumed. 14.4× = budget exhausted in 2 days → PagerDuty. 3.0× = exhausted in 10 days → Slack warning. Why it matters: alerts before SLO is breached, not after.

**`x-dynatrace` header**
DT's proprietary HTTP trace context header. OneAgent injects it on outgoing calls and reads it on incoming calls to link spans into distributed traces. Why it matters: how cross-service tracing works without OTEL.

**Rolling update (`maxUnavailable: 0, maxSurge: 1`)**
Kubernetes deployment strategy: never terminate old pod before replacement is Ready. Why it matters: zero-downtime deploys — users never experience a gap in service.

**`preStop: sleep 15`**
A lifecycle hook that runs before K8s sends SIGTERM. Waits 15 seconds for ALB to deregister the pod. Why it matters: without this, ALB routes requests to a shutting-down pod → connection resets.

**Graceful shutdown**
Spring Boot waits up to 30 seconds for in-flight requests to finish when SIGTERM is received. Why it matters: combined with preStop sleep, ensures no requests are dropped during pod shutdown.

**IRSA (IAM Roles for Service Accounts)**
Links a Kubernetes ServiceAccount to an AWS IAM role. Pods automatically get temporary credentials for that role. Why it matters: no AWS keys stored in Kubernetes or Git.

**ECR (Elastic Container Registry)**
AWS Docker image registry. Separate ECR per environment. Why it matters: production ECR can only be written via CI — no engineer can bypass the test/scan/approval pipeline.

**Cross-account image promotion**
Copying a Docker image from dev ECR (account A) to staging ECR (account B) by pulling and re-pushing. Same SHA tag. Why it matters: identical bits flow through all environments — "works in dev, fails in prod" must be config, not code.

**Terraform state (S3)**
JSON file recording every resource Terraform manages, including DT internal IDs. One bucket per environment. Why it matters: without state, Terraform can't update or delete existing resources and creates duplicates.

**DynamoDB state lock**
A record preventing two simultaneous Terraform applies from corrupting state. Why it matters: two CI pipelines triggered simultaneously can't both apply at once.

**AWS Secrets Manager**
Encrypted secrets storage. The only place DT tokens, PD keys, and DB passwords live. Why it matters: secrets never in Git; Terraform and ESO read them at runtime.

**Canary environment (dev)**
Dev is applied first in the sequential infra pipeline. If it fails, staging and prod are never touched. Why it matters: dev catches broken Terraform changes before they reach production.

**`${PIPESTATUS[0]}`**
Already defined above. Key reminder: essential for drift detection where terraform exits with code 2.

**Source of truth table**
Each system owns specific data: Git = desired state, Terraform state = managed resource IDs, ArgoCD = sync status, DT tenant = real-time telemetry, Secrets Manager = credentials, ECR = image artifacts. Why it matters: knowing which system to trust for each type of information prevents confusion during incidents.
