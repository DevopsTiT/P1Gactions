# Common GitHub Actions Errors for Microservices — Deep Dive

---

## Error Decision Tree

```
GitHub Actions job fails
        │
        ├── Error in workflow YAML itself
        │         → Syntax error, invalid key, indentation
        │         → Part 1
        │
        ├── Authentication / Permission error
        │         → "denied", "unauthorized", "403", "no permission"
        │         → Part 2
        │
        ├── Docker / Container build error
        │         → "failed to solve", "COPY failed", "layer not found"
        │         → Part 3
        │
        ├── Test failure
        │         → "Tests failed", "Process exited with code 1"
        │         → Part 4
        │
        ├── Kubernetes / Deploy error
        │         → "Error from server", "helm: not found", "context deadline"
        │         → Part 5
        │
        ├── Secret / Env var error
        │         → Empty value, "secret not found", unexpected behaviour
        │         → Part 6
        │
        ├── Cache / Dependency error
        │         → "cache miss", slow build, "could not resolve"
        │         → Part 7
        │
        └── Runner / Resource error
                  → "runner out of disk", "OOM", "timeout"
                  → Part 8
```

---

## Part 1 — Workflow YAML Errors

### Error: `Invalid workflow file`

```
Error: .github/workflows/ci.yml (Line: 14, Col: 7):
  Mapping values are not allowed in this context
```

**Root cause:** YAML indentation is wrong. YAML uses spaces (NOT tabs) and indentation level is structural.

```yaml
# WRONG — tab character used instead of spaces
jobs:
	build:          ← tab character here causes parse failure
    runs-on: ubuntu-latest

# WRONG — wrong indentation level
jobs:
  build:
    runs-on: ubuntu-latest
      steps:        ← indented one level too deep
        - run: echo hi

# CORRECT
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - run: echo hi
```

**Fix:**
```bash
# Validate YAML locally before pushing
python3 -c "import yaml; yaml.safe_load(open('.github/workflows/ci.yml'))"

# Or use actionlint (purpose-built for GitHub Actions)
brew install actionlint
actionlint .github/workflows/ci.yml
```

---

### Error: `Unrecognized named-value: 'secrets'`

```
Error: Unrecognized named-value: 'secrets'.
  Located at position 1 within expression: secrets.MY_TOKEN
```

**Root cause:** Trying to use `secrets` context in an expression where it's not allowed (e.g., in `env:` at the top-level workflow scope, or in `if:` conditions).

```yaml
# WRONG — secrets cannot be used in workflow-level env
env:
  MY_TOKEN: ${{ secrets.MY_TOKEN }}    # ← fails at workflow level

# CORRECT — secrets only accessible at job or step level
jobs:
  build:
    runs-on: ubuntu-latest
    env:
      MY_TOKEN: ${{ secrets.MY_TOKEN }}  # ← works at job level
    steps:
      - run: echo "token is set"
        env:
          MY_TOKEN: ${{ secrets.MY_TOKEN }}  # ← works at step level
```

---

### Error: `Context access might be invalid`

```
Warning: Context access might be invalid: GITHUB_TOKEN
```

**Root cause:** Wrong context syntax. `GITHUB_TOKEN` is a secret, not a top-level context variable.

```yaml
# WRONG
password: ${{ GITHUB_TOKEN }}

# CORRECT
password: ${{ secrets.GITHUB_TOKEN }}
```

---

### Error: Job dependency cycle

```
Error: dependency cycle detected for job "deploy"
```

**Root cause:** Two jobs depend on each other through `needs:`.

```yaml
# WRONG — circular dependency
jobs:
  test:
    needs: deploy    # test needs deploy
  deploy:
    needs: test      # deploy needs test — CYCLE!

# CORRECT — linear dependency
jobs:
  test:
    runs-on: ubuntu-latest
  deploy:
    needs: test      # deploy waits for test
```

---

### Error: `if` expression evaluation fails

```
Error: The template is not valid. 
  Expected format: ${{ <expression> }}
```

**Root cause:** Incorrect syntax in `if:` conditions.

```yaml
# WRONG
- name: Deploy
  if: github.ref = 'refs/heads/main'   ← = should be ==

# WRONG
  if: ${{ github.ref == 'refs/heads/main' }}   ← ${{ }} not needed in if:

# CORRECT
- name: Deploy
  if: github.ref == 'refs/heads/main'

# CORRECT — multiple conditions
- name: Deploy
  if: github.ref == 'refs/heads/main' && github.event_name == 'push'
```

---

## Part 2 — Authentication & Permission Errors

### Error: `Error: denied: permission_denied`

```
Error: denied: permission_denied, repository and server both exist, 
but server lacks read/write permissions for repository
```

**Root cause:** The `GITHUB_TOKEN` doesn't have write access to the package registry, OR the package is in a different repository than the workflow.

```yaml
# Fix 1: Set explicit permissions in workflow
permissions:
  contents: read
  packages: write    # ← required for pushing to ghcr.io

jobs:
  build:
    runs-on: ubuntu-latest
    # permissions can also be set at job level
    permissions:
      packages: write
```

```bash
# Fix 2: For cross-repo pushes, use a Personal Access Token (PAT)
# Create PAT: GitHub → Settings → Developer settings → Personal access tokens
# Store as secret: repo settings → Secrets → Actions → New secret
# Use in workflow:
# password: ${{ secrets.PAT_TOKEN }}   ← not secrets.GITHUB_TOKEN
```

---

### Error: `Error: buildx: unauthorized`

```
Error response from daemon: unauthorized: 
  authentication required, visit https://docs.docker.com/...
```

**Root cause:** Docker login step failed or was skipped before the push step.

```yaml
# WRONG — no login step
- uses: docker/build-push-action@v5
  with:
    push: true
    tags: ghcr.io/myorg/myapp:latest
    # ← no login = unauthorized

# CORRECT — login before push
- name: Login to GHCR
  uses: docker/login-action@v3
  with:
    registry: ghcr.io
    username: ${{ github.actor }}
    password: ${{ secrets.GITHUB_TOKEN }}

- name: Build and push
  uses: docker/build-push-action@v5
  with:
    push: true
    tags: ghcr.io/myorg/myapp:latest
```

---

### Error: `Error: Process completed with exit code 1` on AWS login

```
Error: Could not load credentials from any providers
```

**Root cause:** OIDC not configured, or AWS credentials not set as secrets, or wrong role ARN.

```yaml
# Method 1: OIDC (recommended — no static keys)
permissions:
  id-token: write    # ← REQUIRED for OIDC — missing this = auth fails
  contents: read

- name: Configure AWS
  uses: aws-actions/configure-aws-credentials@v4
  with:
    role-to-assume: arn:aws:iam::123456789012:role/GitHubActionsRole
    aws-region: ap-northeast-1
    # If this fails: check IAM role's trust policy allows this repo/branch

# Method 2: Static credentials (fallback)
- name: Configure AWS
  uses: aws-actions/configure-aws-credentials@v4
  with:
    aws-access-key-id: ${{ secrets.AWS_ACCESS_KEY_ID }}
    aws-secret-access-key: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
    aws-region: ap-northeast-1
```

```bash
# Debug OIDC: check IAM trust policy includes correct subject
# Subject format: repo:OWNER/REPO:ref:refs/heads/BRANCH
# Example: repo:myorg/checkout:ref:refs/heads/main

# Check current role assumption
aws sts get-caller-identity
```

---

### Error: `Resource not accessible by integration`

```
HttpError: Resource not accessible by integration
```

**Root cause:** The action is trying to create a PR comment, label, or deployment but the `GITHUB_TOKEN` doesn't have the required permission.

```yaml
# Fix: add the specific permission needed
permissions:
  contents: read
  pull-requests: write    # for PR comments
  issues: write           # for issue comments
  deployments: write      # for deployment status
  statuses: write         # for commit status
  checks: write           # for check runs
```

---

## Part 3 — Docker Build Errors

### Error: `failed to solve: failed to read dockerfile`

```
ERROR [internal] load build definition from Dockerfile
failed to solve: failed to read dockerfile: 
  open Dockerfile: no such file or directory
```

**Root cause:** Workflow runs from the wrong directory, or Dockerfile is not in the expected location.

```yaml
# WRONG — running in wrong directory
- name: Build
  run: docker build -t myapp .
  # working-directory defaults to repo root
  # but Dockerfile is in services/checkout/

# CORRECT — specify context
- uses: docker/build-push-action@v5
  with:
    context: ./services/checkout    # ← directory containing Dockerfile
    file: ./services/checkout/Dockerfile  # ← explicit Dockerfile path

# OR: change working directory
- name: Build
  working-directory: ./services/checkout
  run: docker build -t myapp .
```

---

### Error: `COPY failed: file not found`

```
COPY failed: file not found in build context or excluded by .dockerignore: 
  stat target/app.jar: file does not exist
```

**Root cause:** The file you're trying to COPY into the image doesn't exist yet — the build step (Maven/Gradle) didn't run, or ran in a different job without artifact passing.

```yaml
# WRONG — build and docker in separate jobs without artifact passing
jobs:
  build:
    steps:
      - run: mvn package              # builds target/app.jar
  docker:
    needs: build
    steps:
      - uses: docker/build-push-action@v5  # ← target/app.jar missing!
        # different runner = different filesystem

# CORRECT — same job
jobs:
  build-and-push:
    steps:
      - uses: actions/checkout@v4
      - run: mvn package -DskipTests
      - uses: docker/build-push-action@v5

# OR: pass artifact between jobs
jobs:
  build:
    steps:
      - run: mvn package -DskipTests
      - uses: actions/upload-artifact@v4
        with:
          name: app-jar
          path: target/*.jar

  docker:
    needs: build
    steps:
      - uses: actions/download-artifact@v4
        with:
          name: app-jar
          path: target/
      - uses: docker/build-push-action@v5
```

---

### Error: `error: failed to solve: process "/bin/sh -c mvn package" did not complete successfully`

```
#12 [builder 5/6] RUN ./mvnw package
#12 ERROR: process "/bin/sh -c ./mvnw package" did not complete successfully: exit code: 1
```

**Root cause:** The build inside Docker failed. Usually a compilation error OR the Maven wrapper lacks execute permission.

```bash
# Fix 1: Check Maven wrapper has execute permission
git update-index --chmod=+x mvnw
git commit -m "fix: make mvnw executable"

# Fix 2: In Dockerfile, set permission
RUN chmod +x mvnw

# Fix 3: Debug by building locally with verbose output
DOCKER_BUILDKIT=1 docker build --progress=plain -t debug . 2>&1 | head -100
```

---

### Error: Multi-platform build fails

```
ERROR: failed to solve: no match for platform in manifest: 
  not found linux/arm64
```

**Root cause:** Base image doesn't support the requested platform.

```yaml
# Check if base image supports your target platform
# Before:
FROM eclipse-temurin:17-jre-alpine   # may not have arm64

# Fix: use multi-arch base image
FROM eclipse-temurin:17-jre           # has amd64, arm64

# OR: only build for linux/amd64 (most common for K8s on cloud)
- uses: docker/build-push-action@v5
  with:
    platforms: linux/amd64            # remove linux/arm64 if not needed
```

---

## Part 4 — Test Failures

### Error: `Tests failed` — can't see which test

```
[ERROR] Tests run: 47, Failures: 3, Errors: 0, Skipped: 0
BUILD FAILURE
```

**Fix: always publish test results for visibility**

```yaml
- name: Run tests
  run: mvn test --batch-mode
  # Don't add continue-on-error: true here — let it fail the job

- name: Publish test results
  uses: dorny/test-reporter@v1
  if: always()    # ← publish EVEN when tests fail — this is the point
  with:
    name: Maven Tests
    path: target/surefire-reports/*.xml
    reporter: java-junit
    fail-on-error: true

# After adding this: failed tests are visible as annotations on the PR
# Click "Checks" tab → "Maven Tests" → see exact failed test + stack trace
```

---

### Error: Integration tests fail — `Connection refused`

```
java.net.ConnectException: Connection refused: localhost:5432
```

**Root cause:** The service container (database) isn't ready yet, or the app is connecting to `localhost` but service containers are on a different hostname.

```yaml
# WRONG — service may not be ready
services:
  postgres:
    image: postgres:15
    # no health check = job starts before postgres is ready

# CORRECT — add health check
services:
  postgres:
    image: postgres:15-alpine
    env:
      POSTGRES_DB: testdb
      POSTGRES_USER: testuser
      POSTGRES_PASSWORD: testpass
    ports:
      - 5432:5432
    options: >-
      --health-cmd "pg_isready -U testuser"
      --health-interval 10s
      --health-timeout 5s
      --health-retries 5    # ← job waits for 5 healthy checks before starting steps

steps:
  - name: Run integration tests
    env:
      # Use localhost — service containers are port-mapped to localhost
      SPRING_DATASOURCE_URL: jdbc:postgresql://localhost:5432/testdb
      SPRING_DATASOURCE_USERNAME: testuser
      SPRING_DATASOURCE_PASSWORD: testpass
    run: mvn verify -Pintegration
```

---

### Error: Tests pass locally but fail in CI — timezone issue

```
Expected: 2026-07-31T10:00:00
Actual:   2026-07-31T01:00:00
```

**Root cause:** GitHub-hosted runners use UTC. Your local machine may use JST or another timezone.

```yaml
# Fix: set timezone in the job
- name: Run tests
  env:
    TZ: Asia/Tokyo     # or UTC to match CI in local dev
  run: mvn test
```

---

### Error: Flaky tests cause random pipeline failures

```
Tests run: 200, Failures: 1   ← sometimes passes, sometimes fails
```

```yaml
# Detect flakiness: retry failing tests once
- name: Run tests with retry
  run: |
    mvn test --batch-mode || {
      echo "First run failed, retrying once to detect flakiness..."
      mvn test --batch-mode
    }
    
# OR: use Maven Surefire rerun
- run: |
    mvn test \
      -Dsurefire.rerunFailingTestsCount=2 \
      --batch-mode
    # Retries each failing test 2 times
    # If passes on retry: marks as FLAKY (not FAILED)
    # Report shows which tests are flaky
```

---

## Part 5 — Kubernetes / Helm Deploy Errors

### Error: `Error: INSTALLATION FAILED: Kubernetes cluster unreachable`

```
Error: INSTALLATION FAILED: Kubernetes cluster unreachable: 
  Get "https://api.mycluster.com/version": dial tcp: no route to host
```

**Root cause:** The kubeconfig is missing, wrong, or the cluster is not accessible from GitHub-hosted runners (private cluster).

```yaml
# Fix for public cluster: store kubeconfig as secret
- name: Set up kubeconfig
  run: |
    mkdir -p ~/.kube
    echo "${{ secrets.KUBECONFIG }}" | base64 -d > ~/.kube/config
    kubectl cluster-info   # ← verify connection before deploying

# Fix for private cluster: use self-hosted runner inside the VPC
jobs:
  deploy:
    runs-on: [self-hosted, production-runner]  # runner inside your network
```

---

### Error: `Error: failed to get release: release: not found` on helm rollback

```
Error: failed to get release: release: not found
```

**Root cause:** Using `helm rollback` but the release was never installed with `helm upgrade --install`.

```yaml
# Always use --install flag (idempotent: install OR upgrade)
- run: |
    helm upgrade --install checkout ./charts/checkout \
      --namespace production \
      --create-namespace \      # create namespace if not exists
      --set image.tag=${{ github.sha }} \
      --wait \
      --timeout=10m
```

---

### Error: `Error: rendered manifests contain a resource that already exists`

```
Error: rendered manifests contain a resource that already exists. 
  Unable to continue with install: 
  ServiceAccount "checkout" in namespace "production" exists
```

**Root cause:** Resources were created outside of Helm (manually), so Helm doesn't own them.

```bash
# Fix: add the resource to Helm's tracking
kubectl annotate serviceaccount checkout \
  -n production \
  meta.helm.sh/release-name=checkout \
  meta.helm.sh/release-namespace=production

kubectl label serviceaccount checkout \
  -n production \
  app.kubernetes.io/managed-by=Helm

# Then retry the helm upgrade
```

---

### Error: `helm: command not found`

```
/home/runner/work/_temp/xxx.sh: line 1: helm: command not found
```

**Root cause:** Helm is not installed on the runner. GitHub-hosted runners have many tools pre-installed but Helm may not be the right version.

```yaml
# Fix: add helm setup step
- uses: azure/setup-helm@v3
  with:
    version: '3.13.0'    # pin exact version for reproducibility

# Then helm is available in subsequent steps
- run: helm version
- run: helm upgrade --install ...
```

---

### Error: `context deadline exceeded` during kubectl wait

```
error: timed out waiting for the condition on pods/checkout-xxx
```

**Root cause:** The pod never became Ready in time — likely because the new image is bad, readiness probe failing, or resource requests can't be scheduled.

```yaml
# Fix: add explicit timeout and check pod status on failure
- name: Deploy
  run: |
    helm upgrade --install checkout ./charts \
      --namespace production \
      --set image.tag=${{ github.sha }} \
      --wait \
      --timeout=10m
  
- name: Check pod status on failure
  if: failure()    # only runs if previous step failed
  run: |
    echo "=== Pod Status ==="
    kubectl get pods -n production -l app=checkout
    
    echo "=== Pod Events ==="
    kubectl describe pods -n production -l app=checkout | \
      grep -A 20 "Events:"
    
    echo "=== Pod Logs ==="
    kubectl logs -n production -l app=checkout --tail=50 --previous || \
      kubectl logs -n production -l app=checkout --tail=50
```

---

## Part 6 — Secret & Environment Variable Errors

### Error: Secret value is empty in step

```
Error: Login failed: username or password is incorrect
# But the secret IS set in GitHub settings
```

**Root cause 1:** Secret name typo — GitHub secrets are case-sensitive.

```yaml
# WRONG — secret is named REGISTRY_PASSWORD but workflow uses:
password: ${{ secrets.registry_password }}   ← wrong case

# CORRECT
password: ${{ secrets.REGISTRY_PASSWORD }}
```

**Root cause 2:** Secret defined in wrong scope (org vs repo vs environment).

```yaml
# Environment secrets only available when job targets that environment
jobs:
  deploy:
    environment: production   # ← without this, production secrets unavailable
    steps:
      - run: helm upgrade ... 
        env:
          KUBECONFIG: ${{ secrets.PROD_KUBECONFIG }}  # ← needs environment: production
```

**Root cause 3:** Pull request from a fork — fork PRs don't get secrets.

```yaml
# Forks can't access secrets for security reasons
# This is intentional — a fork could exfiltrate secrets

# Check if it's a fork:
- name: Check for fork
  run: |
    if [ "${{ github.event.pull_request.head.repo.fork }}" == "true" ]; then
      echo "This is a fork PR — secrets not available"
    fi

# Solution: use pull_request_target (runs in base repo context)
# WARNING: pull_request_target is dangerous if you run PR code
on:
  pull_request_target:   # has access to secrets even for forks
    types: [opened, synchronize]
```

---

### Error: Secret appears as `***` in output but command fails

```
Run docker login -u myuser -p ***
Error: unauthorized: incorrect username or password
```

**Root cause:** The secret value has special characters that are interpreted by the shell.

```bash
# WRONG — special chars in password break the command
docker login -u myuser -p ${{ secrets.REGISTRY_PASSWORD }}
# If password is: p@ss!w0rd#  → shell interprets ! # etc.

# CORRECT — use --password-stdin to avoid shell interpretation
echo "${{ secrets.REGISTRY_PASSWORD }}" | \
  docker login ghcr.io -u ${{ github.actor }} --password-stdin
```

---

### Error: Multiline secret broken

```
# Secret contains:
# -----BEGIN RSA PRIVATE KEY-----
# MIIEpAIBAAKCAQEA...
# -----END RSA PRIVATE KEY-----
# But when used, it loses newlines
```

```yaml
# WRONG — loses newlines
- run: echo "${{ secrets.SSH_KEY }}" > ~/.ssh/id_rsa

# CORRECT — preserve newlines with base64 encoding
# Store secret as base64: cat key.pem | base64
# Then decode in workflow:
- run: |
    mkdir -p ~/.ssh
    echo "${{ secrets.SSH_KEY_BASE64 }}" | base64 -d > ~/.ssh/id_rsa
    chmod 600 ~/.ssh/id_rsa
```

---

## Part 7 — Cache & Dependency Errors

### Error: `Cache not restored` — cache always misses

```
Cache not found for input keys: 
  maven-Linux-abc123def456...
Run actions/cache@v4
  ...
  Cache miss
```

**Root cause 1:** Cache key changes on every run because it includes something dynamic.

```yaml
# WRONG — includes timestamp or run number
key: maven-${{ runner.os }}-${{ github.run_number }}  # different every run

# CORRECT — key based on stable file content
key: maven-${{ runner.os }}-${{ hashFiles('**/pom.xml') }}
restore-keys: |
  maven-${{ runner.os }}-    # fallback: any maven cache for this OS
```

**Root cause 2:** Cache path is wrong.

```yaml
# Check actual cache path for your build tool:
# Maven:   ~/.m2/repository
# Gradle:  ~/.gradle/caches  AND  ~/.gradle/wrapper
# npm:     ~/.npm
# pip:     ~/.cache/pip
# Go:      ~/go/pkg/mod  AND  ~/.cache/go-build

- uses: actions/cache@v4
  with:
    path: |
      ~/.m2/repository
      !~/.m2/repository/com/mycompany   # exclude your own artifacts
    key: ${{ runner.os }}-maven-${{ hashFiles('**/pom.xml') }}
```

---

### Error: `npm ERR! code ERESOLVE` — dependency conflict

```
npm ERR! code ERESOLVE
npm ERR! ERESOLVE unable to resolve dependency tree
```

**Root cause:** Different npm version in CI vs local. Or `package-lock.json` is out of sync.

```yaml
# Always use npm ci (not npm install) in CI
- run: npm ci   # uses package-lock.json exactly, fails if out of sync

# Pin Node.js version
- uses: actions/setup-node@v4
  with:
    node-version: '20.11.0'   # pin exact version
    cache: npm
```

---

### Error: Maven can't download dependencies

```
[ERROR] Failed to execute goal: Could not resolve dependencies
  Could not transfer artifact org.springframework.boot:...
  Connection reset
```

**Root cause:** Transient network error to Maven Central, OR private registry requires auth.

```yaml
# Fix 1: Add retry logic
- name: Build with retry
  uses: nick-fields/retry@v2
  with:
    timeout_minutes: 15
    max_attempts: 3
    command: mvn package -DskipTests --batch-mode

# Fix 2: For private Artifactory/Nexus
- name: Configure Maven settings
  run: |
    mkdir -p ~/.m2
    cat > ~/.m2/settings.xml << 'EOF'
    <settings>
      <servers>
        <server>
          <id>company-repo</id>
          <username>${{ secrets.ARTIFACTORY_USER }}</username>
          <password>${{ secrets.ARTIFACTORY_TOKEN }}</password>
        </server>
      </servers>
    </settings>
    EOF
```

---

## Part 8 — Runner & Resource Errors

### Error: `No space left on device`

```
ERROR: error creating overlay mount to /var/lib/docker/...: 
  no space left on device
```

**Root cause:** GitHub-hosted runners have ~14GB disk. Large Docker builds with many layers fill it up.

```yaml
# Fix: free disk space before building
- name: Free disk space
  run: |
    echo "Before:"
    df -h /
    
    # Remove unused Docker images
    docker image prune -af
    
    # Remove pre-installed tools you don't need
    sudo rm -rf /usr/local/lib/android
    sudo rm -rf /usr/share/dotnet
    sudo rm -rf /opt/ghc
    
    echo "After:"
    df -h /

# Or use the cleanup action
- uses: jlumbroso/free-disk-space@main
  with:
    tool-cache: false    # keep tool cache
    android: true
    dotnet: true
    haskell: true
    large-packages: true
```

---

### Error: `The job was canceled because it exceeded the timeout`

```
The job running on runner GitHub Actions X has exceeded 
the maximum execution time of 360 minutes.
```

**Root cause:** No timeout set, and a step hung (waiting for input, infinite loop, slow test).

```yaml
jobs:
  build:
    timeout-minutes: 30    # job-level timeout (default is 360 min = 6 hours!)
    steps:
      - name: Integration tests
        timeout-minutes: 15  # step-level timeout
        run: mvn verify -Pintegration

      # Common hang: waiting for a port that never opens
      - name: Wait for service
        timeout-minutes: 2   # don't wait forever
        run: |
          until curl -sf http://localhost:8080/health; do
            sleep 2
          done
```

---

### Error: `OOMKilled` — runner runs out of memory

```
The runner has received a shutdown signal. This can happen when
the runner service is stopped, the virtual machine is shutdown,
or the job's memory resources have been exhausted.
```

**Root cause:** The job process (JVM, Docker build, etc.) exceeded available RAM (GitHub runners have 7GB).

```yaml
# Fix 1: Limit JVM heap explicitly
- run: mvn package -DskipTests
  env:
    MAVEN_OPTS: "-Xmx4g -Xms512m"   # max 4GB heap (leave 3GB for OS)

# Fix 2: Use larger runner (GitHub Teams/Enterprise)
jobs:
  build:
    runs-on: ubuntu-latest-8-cores   # 8 vCPU, 32GB RAM

# Fix 3: For parallel test sharding
strategy:
  matrix:
    shard: [1, 2, 3, 4]
# Each shard runs on a separate runner with full 7GB
```

---

## Part 9 — Microservice-Specific Patterns That Cause Issues

### Problem: Every microservice has a copy of the same workflow

```
repos/
  checkout-service/.github/workflows/ci.yml      # 250 lines
  payment-service/.github/workflows/ci.yml       # 248 lines (almost identical)
  user-service/.github/workflows/ci.yml          # 252 lines
  # Change deploy logic → update in 10+ repos
```

**Fix: Reusable workflows**

```yaml
# In central repo: .github/workflows/microservice-deploy.yml
on:
  workflow_call:
    inputs:
      service-name:
        required: true
        type: string
      image-tag:
        required: true
        type: string
    secrets:
      KUBECONFIG:
        required: true

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: |
          helm upgrade --install ${{ inputs.service-name }} \
            ./charts/${{ inputs.service-name }} \
            --set image.tag=${{ inputs.image-tag }}
        env:
          KUBECONFIG: ${{ secrets.KUBECONFIG }}
```

```yaml
# In each service repo: .github/workflows/ci.yml
jobs:
  deploy:
    uses: myorg/shared-workflows/.github/workflows/microservice-deploy.yml@main
    with:
      service-name: checkout
      image-tag: ${{ github.sha }}
    secrets:
      KUBECONFIG: ${{ secrets.PROD_KUBECONFIG }}
```

---

### Problem: One monorepo, multiple services — all pipelines trigger on every change

```
Push to microservices/checkout/src/App.java →
ALL 10 service pipelines trigger unnecessarily
```

**Fix: path-based triggers**

```yaml
# Each service's workflow only triggers on its own path
on:
  push:
    branches: [main]
    paths:
      - 'microservices/checkout/**'   # only this service's files
      - 'shared-libs/**'              # + shared library changes
  pull_request:
    paths:
      - 'microservices/checkout/**'
      - 'shared-libs/**'
```

---

### Problem: Deploy order matters but pipelines run independently

```
Service A depends on Service B's API
Both deployed simultaneously → Service A breaks briefly
```

**Fix: workflow ordering with `workflow_run`**

```yaml
# Deploy service B first, then trigger service A deployment
on:
  workflow_run:
    workflows: ["Deploy Service B"]   # triggers when this workflow completes
    types: [completed]
    branches: [main]

jobs:
  deploy-a:
    if: ${{ github.event.workflow_run.conclusion == 'success' }}
    runs-on: ubuntu-latest
    steps:
      - run: helm upgrade --install service-a ...
```

---

## Quick Error Reference Table

| Error Message | Likely Cause | Quick Fix |
|---|---|---|
| `Mapping values not allowed` | YAML indentation/tab | Run `actionlint`, check for tabs |
| `denied: permission_denied` | Missing `packages: write` | Add to `permissions:` block |
| `unauthorized` on docker push | Missing login step | Add `docker/login-action` before push |
| `COPY failed: file not found` | Separate build/docker jobs | Same job OR use upload-artifact |
| `Connection refused` to DB | Service not ready | Add `--health-cmd` to service |
| `helm: command not found` | Helm not installed | Add `azure/setup-helm@v3` |
| `cluster unreachable` | Bad kubeconfig or private cluster | Check secret encoding, use self-hosted runner |
| `No space left on device` | Large Docker build | Free disk space step at job start |
| `secret` is empty | Wrong name, wrong scope | Check case, check environment setting |
| `Cache miss` every run | Dynamic cache key | Use `hashFiles()` on dependency file |
| `exceeded timeout` | Hung process | Add `timeout-minutes` to jobs and steps |
| `Process exited with code 137` | OOM in runner | Limit JVM heap with `MAVEN_OPTS` |
