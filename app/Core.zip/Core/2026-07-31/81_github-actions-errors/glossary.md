# GitHub Actions Errors Glossary — SRE Beginner Reference

Every term from both files, explained plainly.

---

**GitHub Actions**
GitHub's built-in CI/CD system. Workflows are YAML files in `.github/workflows/`. Triggered by events (push, PR, schedule). Runs jobs on "runners" (virtual machines provided by GitHub or self-hosted). Free for public repos; uses quota for private repos.

**Workflow**
A YAML file in `.github/workflows/` that defines when to run (trigger) and what to do (jobs/steps). One repo can have many workflows. Each workflow file is independent.

**Job**
A group of steps that run sequentially on ONE runner machine. Multiple jobs in the same workflow run in parallel by default unless connected with `needs:`. Each job gets a fresh, clean machine.

**Step**
One unit of work inside a job. Either a `run:` (shell command) or `uses:` (pre-built action from GitHub marketplace). Steps in a job run sequentially and share the same filesystem.

**Runner**
The virtual machine that executes jobs. GitHub-hosted runners: `ubuntu-latest` (Linux, 4 CPU, 16GB RAM), `windows-latest`, `macos-latest`. Fresh machine for every job — nothing persists between runs.

**`uses:`**
A step keyword that runs a pre-built "Action" from GitHub Marketplace. Example: `uses: actions/checkout@v4` — runs the official checkout action. The `@v4` pins to a specific version.

**`run:`**
A step keyword that executes shell commands directly. `run: mvn test` runs Maven. Multi-line: use `|` (pipe) character and indent commands.

**`needs:`**
A job keyword that creates a dependency. `needs: [build, test]` means this job only starts after BOTH `build` and `test` complete successfully. Creates a DAG (dependency graph).

**`if:`**
A conditional that controls whether a step or job runs. `if: github.ref == 'refs/heads/main'` means only run on the main branch. `if: failure()` means only run when something failed.

**`continue-on-error: true`**
Makes a job/step not fail the overall workflow even when it exits with an error. Dangerous if overused — hides real failures. Only use when you genuinely want to continue despite the error.

**`always()`**
A status check function in `if:` conditions. `if: always()` runs regardless of whether previous steps passed or failed. Used for cleanup and notification steps that must always execute.

**`failure()`**
A status check function in `if:` conditions. `if: failure()` runs only when something in the job has failed. Used for rollback steps and debug diagnostics.

**`success()`**
A status check function in `if:` conditions. `if: success()` runs only when all previous steps succeeded. This is the default behavior when no `if:` is specified.

**`timeout-minutes:`**
How long a job or step is allowed to run before GitHub forcibly cancels it. Default for jobs: 360 minutes (6 hours — too long for most CI). Always set this to something reasonable (15-30 minutes for most jobs).

**`permissions:`**
A block that sets what the `GITHUB_TOKEN` is allowed to do. `packages: write` allows pushing to GitHub Container Registry. `pull-requests: write` allows posting PR comments. Least-privilege security principle.

**`GITHUB_TOKEN`**
An automatically generated token available in every workflow run. Has permissions to the repository where the workflow runs. NOT a static secret — it's regenerated per run and expires when the run ends. Used for pushing images to ghcr.io, creating releases, commenting on PRs.

**`secrets.GITHUB_TOKEN`**
How you reference the auto-generated token in a workflow. `${{ secrets.GITHUB_TOKEN }}`. Not actually stored as a secret — it's just accessed through the secrets context. Different from a Personal Access Token (PAT).

**PAT (Personal Access Token)**
A long-lived GitHub token created manually by a user. Stored as a repository or organization secret. Used when `GITHUB_TOKEN` doesn't have enough permissions (e.g., accessing other repositories, organizations). Must be manually rotated before expiry.

**OIDC (OpenID Connect)**
A protocol that lets GitHub Actions prove its identity to cloud providers (AWS, GCP, Azure) using short-lived cryptographic tokens instead of static credentials. No secrets to store or rotate. `permissions: id-token: write` is required to use OIDC.

**`id-token: write`**
The specific permission required for OIDC authentication. Without this in the `permissions:` block, GitHub Actions cannot generate the OIDC token needed to assume AWS IAM roles or authenticate to other cloud providers.

**IAM Trust Policy**
An AWS configuration on an IAM role that says "which identities are allowed to assume this role." For GitHub Actions OIDC, the trust policy specifies which GitHub repo and branch can assume the role. Must include the correct `sub` (subject) claim format: `repo:owner/repo:ref:refs/heads/branch`.

**`ghcr.io`**
GitHub Container Registry. A Docker image registry integrated with GitHub. Images are stored alongside your code repo. Free for public images; uses storage quota for private repos. Authentication uses `GITHUB_TOKEN` with `packages: write` permission.

**`docker/login-action`**
A GitHub Actions action that authenticates to a container registry. Must run BEFORE any push to a registry. Supports ghcr.io, ECR, Docker Hub, and others. Writes credentials to Docker's config file for subsequent steps.

**`docker/build-push-action`**
A GitHub Actions action that builds a Docker image and optionally pushes it to a registry. Supports BuildKit, multi-platform builds, and cache export/import. The `push: true` flag enables pushing after build.

**`docker/setup-buildx-action`**
Sets up Docker BuildKit (the modern build engine). Required before using advanced features like multi-platform builds or registry cache. Must run before `docker/build-push-action`.

**BuildKit**
The modern Docker build engine. Enables: parallel stage building, better layer caching, secret injection without leaking to image layers, multi-platform builds, and cache export/import. Enabled with `DOCKER_BUILDKIT=1` (default in Docker 23+).

**`cache-from` / `cache-to`**
Docker BuildKit parameters that import and export layer caches to/from external storage. `type=gha` uses GitHub Actions cache storage. `type=registry` stores cache as a separate tag in the container registry. Essential for fast Docker builds in CI.

**`hashFiles()`**
A GitHub Actions expression function that returns a SHA256 hash of one or more files. `hashFiles('**/pom.xml')` produces a unique hash based on pom.xml contents. Used as cache keys — if pom.xml changes, the hash changes, and the old cache is not used.

**`restore-keys:`**
Fallback cache keys tried in order when the primary key doesn't match. `maven-${{ runner.os }}-` matches any Maven cache for this OS, even with a different pom.xml hash. Partial hit is better than cold build — reuses old cache and updates it.

**`actions/cache@v4`**
The official GitHub action for caching files between workflow runs. You specify the path to cache and a key. Saves files after job completes; restores them at the start of future jobs with matching keys.

**`actions/upload-artifact`**
Stores files produced by one job so other jobs can download them. Necessary when build and deploy are in separate jobs (they run on different machines). Files persist for up to 90 days.

**`actions/download-artifact`**
Downloads files uploaded by `upload-artifact`. Used in jobs that consume files produced by earlier jobs. Must specify the same artifact name used when uploading.

**Service Container**
A Docker container that runs alongside a job to provide infrastructure (database, Redis, Kafka). Defined in the `services:` block of a job. GitHub starts it before any steps run and stops it after the job ends. `options:` can specify a health check that blocks job start until the service is ready.

**`--health-cmd`**
A Docker health check command specified in service container options. GitHub Actions waits for this check to pass before starting the job's steps. Without it, services might not be ready when tests try to connect. Example: `pg_isready` for PostgreSQL.

**`dorny/test-reporter`**
A GitHub Actions action that reads JUnit XML test results and creates a check run with annotations showing which tests failed. Makes test failures visible directly in the PR "Checks" tab without downloading artifacts.

**`continue-on-error:`**
A setting that prevents a failed step from failing the entire job. Use this carefully — it can mask real failures. Common valid use: run a step, capture its result in `id:`, then decide later what to do with the failure.

**`workflow_run:`**
A trigger that fires when another named workflow completes. Used to chain workflows: deploy Service B, then trigger Service A's deploy. `types: [completed]` + `if: conclusion == 'success'` prevents deploying when the prerequisite failed.

**`workflow_call:`**
A trigger that makes a workflow callable as a reusable subroutine from other workflows. Defines `inputs:` (like function parameters) and `secrets:` (secrets to accept from the caller). Enables centralizing shared pipeline logic.

**Reusable Workflow**
A workflow with `on: workflow_call:` that can be called by other workflows using `uses: org/repo/.github/workflows/name.yml@main`. Enables DRY (Don't Repeat Yourself) — one deploy template used by all microservices.

**`actionlint`**
A static analysis tool specifically for GitHub Actions workflow files. Catches: unknown runner labels, incorrect expression syntax, type mismatches, missing required inputs. Run locally before pushing workflow changes.

**tmate**
An open-source tool that creates an SSH session into a running process (including a GitHub Actions runner). The `mxschmitt/action-tmate` action pauses the job and prints an SSH command. Used for interactive debugging of CI failures you can't reproduce locally.

**`ACTIONS_STEP_DEBUG`**
A repository secret that, when set to `true`, enables verbose debug logging for all `run:` steps. Shows every command and its output. Set this when the normal log doesn't show enough detail to diagnose a failure.

**`ACTIONS_RUNNER_DEBUG`**
A repository secret that enables runner-level debug logging. Shows file operations, environment setup, and runner internals. Use together with `ACTIONS_STEP_DEBUG` for maximum visibility.

**`act`**
A command-line tool that runs GitHub Actions workflows locally using Docker. Useful for testing workflow changes without pushing to GitHub. Not 100% identical to real runners but catches most issues.

**Helm**
A Kubernetes package manager. Applications are packaged as "charts" with templates and a `values.yaml` file. `helm upgrade --install` deploys or updates an application. Stores release history as Kubernetes Secrets — enables `helm rollback`.

**`helm upgrade --install`**
Helm command that installs the chart if it doesn't exist, or upgrades it if it does. The `--install` flag makes it idempotent — safe to run whether first deploy or hundredth. `--wait` blocks until all pods are ready.

**`helm rollback`**
Reverts a Helm release to a previous revision. Kubernetes re-applies the old manifests via a rolling update. Each `helm upgrade` creates a new revision number — `helm history` shows all revisions.

**`helm --dry-run`**
Renders the Helm chart templates without applying anything to the cluster. Shows what Kubernetes YAML would be generated. Used to debug incorrect values or template rendering issues.

**`helm --debug`**
Prints the rendered manifests AND the computed values before applying. Shows exactly what Helm will send to Kubernetes. Useful when values are not being applied as expected.

**`kubectl rollout status`**
Waits for a Kubernetes Deployment rollout to complete and exits 0 on success, 1 on timeout. Used as a post-deploy gate: the CI step fails if pods don't become healthy within the timeout. `--timeout=5m` sets how long to wait.

**`ImagePullBackOff`**
A Kubernetes pod status meaning the cluster is failing to pull the container image. Causes: image tag doesn't exist, registry authentication failure, network issue. Check with `kubectl describe pod` → look at Events section.

**`context deadline exceeded`**
A Kubernetes/Go error meaning an operation timed out. In deploy context: pods didn't become ready within the `--timeout` specified in `helm upgrade`. Could mean: bad image, failing liveness probe, resource quota exceeded.

**`DOCKER_BUILDKIT=1`**
An environment variable that enables Docker's modern BuildKit build engine. Required for advanced features like `--mount=type=secret`, parallel multi-stage builds, and `--cache-from`/`--cache-to` with `type=gha`. Default in Docker 23+.

**`--progress=plain`**
A Docker build flag that shows ALL build output step-by-step instead of the default interactive display. Essential for debugging Docker builds in CI or when you need to see every RUN command's output.

**Fork PR**
A pull request from a repository that was forked (copied) from the original. GitHub intentionally does NOT pass repository secrets to fork PRs to prevent secrets from being exfiltrated by malicious forks. This causes CI failures for steps that need authentication.

**`pull_request_target`**
A GitHub Actions trigger that fires for PRs but runs in the context of the BASE repository (not the fork). Has access to secrets. DANGEROUS: if you checkout and run fork code with this trigger, malicious forks can access your secrets. Use with extreme caution.

**`environment:`**
A GitHub Actions job setting that assigns the job to a named deployment environment (dev, staging, production). Environment secrets are only available to jobs targeting that environment. Also enables protection rules like required reviewers.

**Protection Rule (GitHub Environment)**
A safeguard on a GitHub environment. Options: required reviewers (someone must approve), wait timer (mandatory pause), branch restrictions (only deploy from specific branches). Creates the human approval gate for production deploys.

**`concurrency:`**
A GitHub Actions block that prevents multiple workflow runs from executing simultaneously for the same group. `cancel-in-progress: true` cancels older runs when a new push comes in. Prevents 10 queued builds from a rapid series of commits.

**`working-directory:`**
A step or job setting that changes the current directory before running commands. Used in monorepos where each microservice has its own subdirectory. `working-directory: services/checkout` means all `run:` commands execute from that path.

**`paths:` trigger filter**
A `on: push:` configuration that only triggers the workflow when specific files change. `paths: ['services/checkout/**']` means the pipeline only runs when checkout service files change — prevents all 10 service pipelines from running on every commit in a monorepo.
