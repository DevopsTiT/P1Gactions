# GitHub Actions Errors — Deep Dive Troubleshooting Guide

---

## The Troubleshooting Mindset

```
Every GitHub Actions failure leaves evidence in one of three places:

1. The WORKFLOW LOG    → what step failed, what it printed
2. The RUNNER CONTEXT  → what environment variables, what files exist
3. EXTERNAL SYSTEMS    → registry, Kubernetes, AWS — check THEIR logs too

Beginner mistake: stare at the red X without reading the actual log output.
First thing ALWAYS: expand the failed step and read every line.
```

---

## Step 1 — Reading the GitHub Actions Log Correctly

### Finding the Real Error

GitHub Actions logs are long. The actual error is almost never at the top.

```
How to find it:

1. Click the failed job (red X)
2. All steps are shown — look for the RED step
3. Click the red step to expand it
4. SCROLL TO THE BOTTOM of that step's output
   → The error is almost always at the bottom
   → Errors often say "see above for details" — so scroll UP from the bottom
5. Look for lines starting with: ERROR, FAILED, Error:, fatal:, exit code
```

### Log Sections You Must Check

```
For a Docker build failure:
  ✓ The "Build and push" step → scroll to bottom → find "ERROR [stage N/M] RUN ..."
  ✓ Click "Show more" if log is truncated

For a Kubernetes deploy failure:
  ✓ The "Deploy" step → find "Error from server:" or "FAILED"
  ✓ Add a debug step AFTER with: kubectl describe pod / kubectl logs

For a test failure:
  ✓ The "Run tests" step → find "BUILD FAILURE" or "FAILED"
  ✓ Check the "Annotations" tab (below the job list) — shows exact failed test
  ✓ Download artifacts → open surefire-reports/*.xml
```

---

## Step 2 — Enable Debug Logging

When the log doesn't show enough detail, turn on verbose mode.

### Method 1: Repository Secret (Persistent)

```
GitHub UI:
Settings → Secrets and variables → Actions → New repository secret

Name:  ACTIONS_STEP_DEBUG
Value: true

Name:  ACTIONS_RUNNER_DEBUG
Value: true
```

Effect:
- `ACTIONS_STEP_DEBUG`: prints every command AND its output for all `run:` steps
- `ACTIONS_RUNNER_DEBUG`: prints runner-level debug (environment, file operations)

### Method 2: Re-run with Debug Enabled (One-Time)

```
GitHub UI:
Actions → select the failed run → "Re-run jobs" → "Re-run failed jobs"
→ Check "Enable debug logging"
→ Click "Re-run jobs"
```

No secret needed — debug mode applies to this single run only.

### Method 3: Add Debug Steps to Workflow

```yaml
- name: Debug environment
  run: |
    echo "=== GitHub Context ==="
    echo "ref: ${{ github.ref }}"
    echo "sha: ${{ github.sha }}"
    echo "actor: ${{ github.actor }}"
    echo "event: ${{ github.event_name }}"
    
    echo "=== Runner Environment ==="
    echo "OS: ${{ runner.os }}"
    uname -a
    df -h            # disk usage
    free -h          # memory
    docker info      # docker status
    
    echo "=== Working Directory ==="
    pwd
    ls -la           # list files
    
    echo "=== Environment Variables ==="
    env | sort | grep -v "SECRET\|PASSWORD\|TOKEN\|KEY"  # never print secrets

- name: Debug Docker
  run: |
    docker version
    docker images    # what images exist
    docker ps -a     # what containers are running
```

---

## Step 3 — Live SSH Debugging (tmate)

When you can't reproduce a failure locally, attach to the runner interactively.

```yaml
# Add this step AFTER the failing step
- name: Debug with tmate
  if: failure()     # only runs when something above failed
  uses: mxschmitt/action-tmate@v3
  with:
    limit-access-to-actor: true    # only YOU can SSH in
    timeout-minutes: 30            # closes after 30 min

# When this runs:
# The log shows:
#   SSH: ssh abc123@nyc1.tmate.io
# SSH into the runner, investigate manually:
#   ls -la target/          # do build artifacts exist?
#   cat ~/.m2/settings.xml  # is Maven config correct?
#   kubectl get pods        # can runner reach Kubernetes?
#   docker images           # what images are built?
```

**IMPORTANT:** Never do this on a public repo with a shared runner — anyone could SSH in. Use `limit-access-to-actor: true`.

---

## Deep Dive: Troubleshooting Each Error Category

---

## DTR-1 — YAML Validation Errors Deep Dive

### The Problem With YAML Indentation

YAML uses indentation to represent structure. One wrong space = completely different meaning.

```yaml
# What you wrote (looks right visually):
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout        ← 4 spaces indent
      uses: actions/checkout@v4

# What this parses as:
# "steps" is a key with a list value
# Each list item has "name" and "uses" as keys
# This is CORRECT for GitHub Actions format

# COMMON WRONG version:
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout      ← 6 spaces indent (extra 2)
      uses: actions/checkout@v4  ← 6 spaces — now "uses" is same level as "name"
                                 ← This makes "uses" a sibling key to "name", not a property of the step
```

### Actionlint: The Best YAML Debugger for GitHub Actions

```bash
# Install
brew install actionlint       # macOS
# OR
go install github.com/rhysd/actionlint/cmd/actionlint@latest

# Run against your workflow
actionlint .github/workflows/ci.yml

# Example output:
# .github/workflows/ci.yml:34:7: "on" is not a string [syntax-check]
# .github/workflows/ci.yml:52:12: label "ubuntu-lastest" is unknown [runner-label]
#   (note the typo: lastest vs latest)
# .github/workflows/ci.yml:78:5: expression syntax error [expression]

# Run against ALL workflows in repo
actionlint

# Useful flags
actionlint -format '{{range $err := .}}{{$err.Filepath}}:{{$err.Line}}:{{$err.Col}}: {{$err.Message}}{{"\n"}}{{end}}'
```

### Testing YAML Locally Before Pushing

```bash
# Check YAML syntax (not GitHub Actions specific)
python3 -c "import yaml; print(yaml.safe_load(open('.github/workflows/ci.yml')))"

# Validate with GitHub's own schema
pip install check-jsonschema
check-jsonschema \
  --schemafile https://json.schemastore.org/github-workflow.json \
  .github/workflows/ci.yml

# Or use VS Code with the YAML extension + GitHub Actions extension
# Shows red underlines for errors in real time
```

---

## DTR-2 — Authentication Errors Deep Dive

### Systematic Authentication Debug Process

```bash
# Step 1: What are you trying to authenticate to?
# ghcr.io → needs packages: write permission + github.actor + GITHUB_TOKEN
# ECR     → needs AWS credentials (OIDC or static)
# DockerHub → needs DOCKER_USERNAME + DOCKER_PASSWORD secrets
# Private registry → needs its own credentials

# Step 2: Check if the login step actually ran
# Look in the log for the login step — did it succeed or fail silently?

# Step 3: Check token scope
# GITHUB_TOKEN has limited permissions — check what it can do:
# github.com/settings/tokens (for PAT)
# For repo GITHUB_TOKEN: Settings → Actions → permissions
```

### Docker Login: All Registries

```yaml
# Registry 1: GitHub Container Registry (ghcr.io)
- name: Login to GHCR
  uses: docker/login-action@v3
  with:
    registry: ghcr.io
    username: ${{ github.actor }}
    password: ${{ secrets.GITHUB_TOKEN }}
  # Debug: if this fails, check workflow permissions block

# Registry 2: Amazon ECR
- name: Login to ECR
  id: login-ecr
  uses: aws-actions/amazon-ecr-login@v2
  # Debug: must configure-aws-credentials BEFORE this step

# Registry 3: Docker Hub
- name: Login to Docker Hub
  uses: docker/login-action@v3
  with:
    username: ${{ secrets.DOCKERHUB_USERNAME }}
    password: ${{ secrets.DOCKERHUB_TOKEN }}  # use token not password
  # Debug: check token hasn't expired, has push permission

# Verify login worked:
- name: Verify registry login
  run: docker info | grep -i "username\|registry"
```

### OIDC Authentication: Step-by-Step Debug

```yaml
# OIDC requires this permissions block — without it, token is not generated
permissions:
  id-token: write
  contents: read

# Debug step: check if OIDC token is being generated
- name: Debug OIDC
  run: |
    # This will print the token claim (not the actual token)
    curl -H "Authorization: bearer $ACTIONS_ID_TOKEN_REQUEST_TOKEN" \
         "$ACTIONS_ID_TOKEN_REQUEST_URL" | \
         python3 -c "import sys,json; d=json.load(sys.stdin); 
                     print('subject:', d.get('value','').split('.')[1])" 2>/dev/null || \
         echo "OIDC token not available — check permissions: id-token: write"
```

```bash
# AWS IAM Trust Policy: the most common OIDC misconfiguration
# Check the trust policy on your role

aws iam get-role --role-name GitHubActionsRole \
  --query 'Role.AssumeRolePolicyDocument' --output json

# The Subject condition must match your repo/branch:
# "repo:OWNER/REPO:ref:refs/heads/BRANCH"
# 
# Common mistakes:
# 1. Wrong repo name (case matters): "Myorg/repo" vs "myorg/repo"
# 2. Wrong branch: "main" vs "master"
# 3. Missing wildcard for all branches: "repo:myorg/myapp:*"

# Fix — update trust policy to allow all branches:
# "repo:myorg/checkout:ref:refs/heads/*"
# or all refs:
# "repo:myorg/checkout:*"
```

---

## DTR-3 — Docker Build Errors Deep Dive

### Build with Maximum Verbosity

```bash
# Local debug: build exactly as CI does, with full output
DOCKER_BUILDKIT=1 \
docker build \
  --progress=plain \    # show ALL steps (not the pretty summary)
  --no-cache \          # ignore cache (see real build, not cached)
  -t debug-build \
  . 2>&1 | tee build.log

# Search for the actual error
grep -n "ERROR\|FAILED\|error\|failed" build.log | head -30
```

### Layer-by-Layer Debugging

```bash
# When a specific RUN step fails, debug it by building up to that layer

# Add this to your Dockerfile temporarily:
# After each RUN that might fail, add a debug layer:
RUN echo "=== Layer 3 complete ===" && ls -la target/ && echo "JAR size:" && du -sh target/*.jar

# To build only up to a specific target:
docker build --target builder -t debug-builder .
docker run -it debug-builder bash
# Now you're inside the builder stage — run the failing command manually
```

### Multi-Service Repo: Context Path Problems

```bash
# Problem: workflow runs from repo root, but Dockerfile is deep in the tree
# repo/
#   microservices/
#     checkout/
#       Dockerfile
#       src/
# 
# WRONG: context is repo root, Dockerfile can't find src/
docker build -t checkout .
# Dockerfile: COPY src/ /app/src/  ← fails because src/ is not in root context

# CORRECT: context must be the service directory
docker build -t checkout microservices/checkout/
# OR use build-push-action with context:
```

```yaml
- uses: docker/build-push-action@v5
  with:
    context: microservices/checkout/    # build context = this directory
    file: microservices/checkout/Dockerfile  # Dockerfile location
    # All COPY paths in Dockerfile are relative to this context
```

---

## DTR-4 — Test Failures Deep Dive

### Extracting Test Results for Fast Diagnosis

```yaml
# Always upload test results even on failure
- name: Run tests
  id: test
  run: mvn test --batch-mode
  continue-on-error: true   # don't fail yet — collect artifacts first

- name: Upload test results
  uses: actions/upload-artifact@v4
  if: always()
  with:
    name: test-results-${{ github.run_number }}
    path: |
      target/surefire-reports/
      target/failsafe-reports/

- name: Publish test results as PR annotation
  uses: dorny/test-reporter@v1
  if: always()
  with:
    name: Maven Test Results
    path: target/surefire-reports/*.xml
    reporter: java-junit

# Now fail the job
- name: Fail if tests failed
  if: steps.test.outcome == 'failure'
  run: exit 1
```

### Environment Differences: CI vs Local

```bash
# Key differences between your laptop and GitHub Actions runner:
# Timezone:   Local = JST, Runner = UTC
# Locale:     Local = ja_JP.UTF-8, Runner = en_US.UTF-8
# Memory:     Local = varies, Runner = 7GB max
# Disk:       Local = varies, Runner = 14GB
# Network:    Local = your network, Runner = GitHub's network
# Docker:     Local = your Docker, Runner = separate Docker daemon

# Debug: print the environment at the start of your test job
- name: Print test environment
  run: |
    echo "TZ: $(date +%Z)"
    echo "Locale: $(locale)"
    echo "Java: $(java -version 2>&1)"
    echo "Maven: $(mvn --version)"
    echo "User: $(whoami)"
    echo "Home: $HOME"
    echo "Workspace: $GITHUB_WORKSPACE"
```

### Reproducing CI Test Failures Locally

```bash
# Run tests in a Docker container that matches the CI environment
docker run --rm \
  -v "$(pwd):/workspace" \
  -w /workspace \
  -e TZ=UTC \
  -e CI=true \
  eclipse-temurin:17-jdk \
  ./mvnw test --batch-mode

# This eliminates "works on my machine" — same JDK, same timezone, same CI flag
```

---

## DTR-5 — Kubernetes Deploy Errors Deep Dive

### The Deploy Debug Loop

```yaml
# Pattern: deploy → verify → debug on failure → rollback on failure
- name: Deploy to production
  id: deploy
  run: |
    helm upgrade --install checkout ./charts \
      --namespace production \
      --set image.tag=${{ github.sha }} \
      --wait --timeout=8m
  continue-on-error: true

- name: Gather debug info on failure
  if: steps.deploy.outcome == 'failure'
  run: |
    echo "======= DEPLOYMENT FAILED — GATHERING DIAGNOSTICS ======="
    
    echo "--- Recent Events ---"
    kubectl get events -n production \
      --sort-by='.lastTimestamp' | tail -20
    
    echo "--- Pod Status ---"
    kubectl get pods -n production -l app=checkout
    
    echo "--- Describe Failing Pods ---"
    kubectl describe pods -n production -l app=checkout | \
      grep -A 30 "Events:"
    
    echo "--- Logs (current) ---"
    kubectl logs -n production -l app=checkout \
      --tail=50 2>/dev/null || echo "No current logs"
    
    echo "--- Logs (previous — crashed container) ---"
    kubectl logs -n production -l app=checkout \
      --previous --tail=50 2>/dev/null || echo "No previous logs"
    
    echo "--- Helm History ---"
    helm history checkout -n production
    
    echo "--- Image Check ---"
    kubectl get deployment checkout -n production \
      -o jsonpath='{.spec.template.spec.containers[0].image}'

- name: Rollback on failure
  if: steps.deploy.outcome == 'failure'
  run: |
    echo "Rolling back to previous release..."
    helm rollback checkout -n production --wait
    echo "Rollback complete"
    exit 1   # fail the pipeline even though rollback succeeded
```

### Diagnosing `ImagePullBackOff` After Deploy

```bash
# In the debug step, if pods show ImagePullBackOff:

# Check 1: Does the image tag exist in the registry?
# The tag might not have been pushed successfully
echo "Checking image: ghcr.io/myorg/checkout:$GITHUB_SHA"
docker manifest inspect ghcr.io/myorg/checkout:$GITHUB_SHA || \
  echo "IMAGE DOES NOT EXIST — build/push step failed"

# Check 2: Can the cluster pull from the registry?
# The cluster needs image pull credentials
kubectl get secret regcred -n production || \
  echo "No image pull secret found"

# Check 3: Is the image name correct?
kubectl get deployment checkout -n production \
  -o jsonpath='{.spec.template.spec.containers[*].image}'
```

### Helm Values Not Being Applied

```bash
# Problem: helm upgrade appears to succeed but pods don't use new image

# Debug: check what values are actually set in the release
helm get values checkout -n production

# Check what the rendered manifest would look like
helm template checkout ./charts \
  --set image.tag=sha-abc123 | grep "image:"

# Check if values file is being read
helm upgrade --install checkout ./charts \
  --values charts/checkout/values-production.yaml \
  --set image.tag=sha-abc123 \
  --debug    # ← prints full rendered manifest before applying
  --dry-run  # ← don't actually apply, just show what would happen
```

---

## DTR-6 — Secret Errors Deep Dive

### The Secret Masking Problem

GitHub masks secret values in logs (replaces with `***`). This is good for security but makes debugging hard.

```yaml
# Debug technique: check if secret is set WITHOUT revealing it
- name: Verify secrets are set
  run: |
    # Check presence without printing value
    if [ -z "${{ secrets.REGISTRY_PASSWORD }}" ]; then
      echo "ERROR: REGISTRY_PASSWORD is empty or not set"
      exit 1
    else
      echo "REGISTRY_PASSWORD is set (length: ${#REGISTRY_PASSWORD})"
    fi
    
    if [ -z "${{ secrets.KUBECONFIG }}" ]; then
      echo "ERROR: KUBECONFIG is empty or not set"
      exit 1
    else
      echo "KUBECONFIG is set"
    fi
  env:
    REGISTRY_PASSWORD: ${{ secrets.REGISTRY_PASSWORD }}
    KUBECONFIG: ${{ secrets.KUBECONFIG }}
```

### Detecting Secret Encoding Issues

```yaml
# Problem: secret was stored with extra newline or space
- name: Debug secret encoding
  run: |
    # Check kubeconfig is valid YAML (common issue: stored incorrectly)
    echo "${{ secrets.KUBECONFIG }}" | python3 -c "
    import sys, yaml, base64
    content = sys.stdin.read().strip()
    
    # Try as raw YAML first
    try:
        data = yaml.safe_load(content)
        print('KUBECONFIG: valid raw YAML')
    except:
        pass
    
    # Try as base64
    try:
        decoded = base64.b64decode(content).decode()
        data = yaml.safe_load(decoded)
        print('KUBECONFIG: valid base64-encoded YAML')
    except:
        print('KUBECONFIG: INVALID - neither raw YAML nor base64')
    "
```

### Fork PRs and Secrets

```bash
# Problem: PR from a fork, tests fail because secrets are empty
# GitHub does NOT pass secrets to fork PRs (security feature)

# How to detect if running on a fork:
echo "Is fork: ${{ github.event.pull_request.head.repo.fork }}"
echo "Head owner: ${{ github.event.pull_request.head.repo.owner.login }}"
echo "Base owner: ${{ github.repository_owner }}"
```

```yaml
# Solution: skip secret-dependent steps for forks, use public registries
- name: Build Docker image
  run: docker build -t myapp:local .
  # No push for fork PRs — can't authenticate

- name: Push image (skip for forks)
  if: github.event.pull_request.head.repo.fork == false
  uses: docker/build-push-action@v5
  with:
    push: true
    tags: ghcr.io/myorg/myapp:${{ github.sha }}
```

---

## DTR-7 — Cache Errors Deep Dive

### Understanding Cache Hit vs Miss

```yaml
- name: Cache Maven dependencies
  id: maven-cache
  uses: actions/cache@v4
  with:
    path: ~/.m2/repository
    key: maven-${{ runner.os }}-${{ hashFiles('**/pom.xml') }}
    restore-keys: |
      maven-${{ runner.os }}-

# After this step:
# steps.maven-cache.outputs.cache-hit == 'true'  → exact match found
# steps.maven-cache.outputs.cache-hit == 'false' → restore-key match or miss

- name: Show cache result
  run: |
    echo "Cache hit: ${{ steps.maven-cache.outputs.cache-hit }}"
    echo "Cache path size: $(du -sh ~/.m2/repository 2>/dev/null || echo 'empty')"
```

### Force Cache Refresh When Dependencies Are Stale

```yaml
# Problem: cache has old dependencies, new ones not downloading

# Solution: manual cache busting by changing the key prefix
key: maven-v2-${{ runner.os }}-${{ hashFiles('**/pom.xml') }}
#         ↑ increment this version to invalidate ALL old caches

# OR via GitHub UI: Actions → Caches → Delete cache entries matching "maven-"
```

```bash
# CLI: delete caches using gh CLI
gh api /repos/myorg/myapp/actions/caches | \
  jq '.actions_caches[] | select(.key | startswith("maven-")) | .id' | \
  xargs -I{} gh api --method DELETE /repos/myorg/myapp/actions/caches/{}
```

---

## DTR-8 — Runner Resource Errors Deep Dive

### Disk Space Monitoring

```yaml
- name: Monitor disk throughout job
  run: |
    echo "=== Disk usage at job start ==="
    df -h /
    
    # Show what's using space
    du -sh /usr/local/lib/android 2>/dev/null && echo "^ android sdk"
    du -sh /usr/share/dotnet 2>/dev/null && echo "^ dotnet"
    du -sh /opt/ghc 2>/dev/null && echo "^ ghc/haskell"
    du -sh ~/.docker 2>/dev/null && echo "^ docker layers"

- name: Free disk space before large build
  run: |
    # Remove tools you don't use
    sudo rm -rf /usr/local/lib/android      # ~9GB
    sudo rm -rf /usr/share/dotnet           # ~2GB
    sudo rm -rf /opt/ghc                    # ~2GB
    sudo apt-get autoremove -y
    docker system prune -af --volumes       # remove all unused docker data
    
    echo "After cleanup:"
    df -h /
```

### Memory Profiling in CI

```yaml
- name: Monitor memory during tests
  run: |
    # Start memory monitor in background
    while true; do
      echo "$(date): $(free -m | grep Mem | awk '{print "Used: "$3"MB, Available: "$7"MB"}')"
      sleep 30
    done &
    MONITOR_PID=$!
    
    # Run the actual tests
    mvn test --batch-mode
    TEST_EXIT=$?
    
    # Kill monitor
    kill $MONITOR_PID 2>/dev/null
    
    exit $TEST_EXIT
```

### Understanding Runner Timeouts

```yaml
# Default timeout: 6 hours (360 minutes) — this is WAY too long
# For microservices, set aggressive timeouts:

jobs:
  build:
    timeout-minutes: 15      # entire build job: 15 min max

  test:
    timeout-minutes: 20      # test job: 20 min max

  deploy:
    timeout-minutes: 15      # deploy job: 15 min max

# Step-level timeouts for risky operations:
steps:
  - name: Wait for health check
    timeout-minutes: 5       # 5 min to become healthy
    run: |
      until kubectl rollout status deployment/checkout -n production; do
        echo "Still waiting..."
        sleep 5
      done

  - name: Integration tests
    timeout-minutes: 10
    run: mvn verify -Pintegration
```

---

## DTR-9 — Advanced Debug Techniques

### Workflow Debug with `act`

```bash
# Run GitHub Actions locally using Docker
brew install act

# List all workflows
act --list

# Run a specific workflow dry-run (no actual execution)
act push --dryrun

# Run specific job with debug
act push --job build --verbose

# Use custom secrets file
cat > .secrets << 'EOF'
REGISTRY_PASSWORD=mypassword
KUBECONFIG=base64encodedconfig
EOF
act push --secret-file .secrets

# Use specific runner image (closer to GitHub's)
act push -P ubuntu-latest=catthehacker/ubuntu:act-latest
```

### Comparing Local vs CI Build

```bash
# Build locally with the EXACT same conditions as CI
docker run --rm \
  -v "$(pwd):/workspace" \
  -v "/var/run/docker.sock:/var/run/docker.sock" \
  -w /workspace \
  -e CI=true \
  -e GITHUB_WORKSPACE=/workspace \
  -e GITHUB_SHA=$(git rev-parse HEAD) \
  -e GITHUB_REF=refs/heads/main \
  -e GITHUB_ACTOR=local-debug \
  ubuntu:22.04 \
  bash -c "
    apt-get install -y default-jdk maven docker.io
    ./mvnw package
  "
```

### Checking What's Pre-Installed on Runners

```yaml
# Print all pre-installed tools on the runner
- name: Show runner tools
  run: |
    echo "=== Java versions ==="
    ls /usr/lib/jvm/ 2>/dev/null || echo "none"
    
    echo "=== Docker ==="
    docker version
    
    echo "=== kubectl ==="
    kubectl version --client 2>/dev/null || echo "not installed"
    
    echo "=== helm ==="
    helm version 2>/dev/null || echo "not installed"
    
    echo "=== aws ==="
    aws --version 2>/dev/null || echo "not installed"
    
    echo "=== All installed packages (sample) ==="
    dpkg -l | grep -E "docker|kubectl|helm|java" | head -20

# OR: check GitHub's official documentation for what's pre-installed:
# https://github.com/actions/runner-images/blob/main/images/ubuntu/Ubuntu2204-Readme.md
```

---

## Checklists: Before You Push a Workflow

### New Workflow Checklist

```
□ Run actionlint locally — zero warnings
□ All secret names match exactly (case-sensitive) what's in repo settings
□ permissions: block includes all required scopes
□ timeout-minutes set on every job
□ cache keys use hashFiles() not dynamic values
□ Docker login step runs BEFORE build-push step
□ deploy job has environment: set if it needs environment secrets
□ if: conditions use == not = and no ${{ }} wrapper
□ Working directory correct for monorepo services
□ continue-on-error NOT used to hide real failures
```

### Deploy Workflow Checklist

```
□ Helm --wait flag included
□ Post-deploy health check step added
□ Rollback step on failure
□ Debug/diagnostic step on failure
□ Slack/notification step (always runs)
□ Timeout on deploy step (not unlimited)
□ environment: production set (requires manual approval gate)
□ Correct kubeconfig secret per environment (dev vs prod)
```

### Secret Setup Checklist

```
□ Repository secrets set for non-environment-specific values
□ Environment secrets set for environment-specific values (PROD_KUBECONFIG, DEV_KUBECONFIG)
□ Multiline secrets (kubeconfig, certs) stored as base64
□ No trailing newlines in secret values
□ PAT (Personal Access Token) used for cross-repo operations (not GITHUB_TOKEN)
□ PAT scope is minimal (read:packages for pulls, write:packages for pushes)
□ PAT expiry date noted (set reminder before it expires)
```
