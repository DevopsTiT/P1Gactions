# SRE Collaboration: Enhance Observability and Automation
## Deep Dive — Working with Engineering and Operations Teams

> SRE is a bridge role. You sit between engineering (who build features) and operations (who keep systems running). This doc explains how SREs collaborate with both teams to build better observability and remove manual toil through automation — with concrete examples, workflows, and pitfalls.

---

## Decision Tree — Who Owns What

```
                     "Something needs to change"
                                │
          ┌─────────────────────┼─────────────────────┐
          ▼                     ▼                     ▼
   "Alert fires too         "Service has          "Deploy takes
    often / wrong            no metrics"           45 minutes,
    team gets paged"              │                should be 10"
          │                       │                     │
   SRE owns:               SRE + Engineering:      SRE owns:
   Alert tuning            Decide what to          Pipeline
   Management zones        instrument               automation
   Notification routing    SRE provides:           Engineering
          │                  DT auto-               reviews:
   Engineering can:          instrumentation        test gate
   Accept or push            guide + templates      coverage
   back on thresholds        Engineering adds:
                             custom business
                             metrics via API
```

---

## E2E Flow — How Observability Gets Built Together

```
SPRINT PLANNING (Engineering + SRE together):
  New feature planned: "Batch payment processing"
  
  SRE asks 5 questions:
  1. What does success look like? → "95% of batch jobs complete in < 5 min"
  2. What can fail? → "DB timeouts, payment gateway down, memory pressure"
  3. How will we know it's failing? → "error count in log + batch_job_failed metric"
  4. Who gets paged when it fails? → "payments oncall, not platform team"
  5. What is the rollback plan? → "disable batch feature flag, drain queue"
  
  Output: pre-agreed SLOs, alert thresholds, runbook template

DEVELOPMENT (Engineering writes code):
  SRE provides:
    - Structured logging template (JSON format DT can parse)
    - OTEL custom metric API example (how to emit batch_jobs_completed counter)
    - DT dashboard template for batch jobs
  
  Engineering adds to code:
    meterRegistry.counter("batch.payment.completed").increment();
    meterRegistry.counter("batch.payment.failed",
      "reason", errorCode).increment();
    log.info("{\"event\":\"batch_complete\",\"jobId\":\"{}\",\"duration\":{}}", id, ms);

CODE REVIEW (SRE reviews observability):
  SRE checklist for every PR:
    □ Does the new feature emit logs in JSON format?
    □ Are custom metrics named following convention: <team>.<service>.<operation>?
    □ Are there runnable smoke tests covering the new endpoint?
    □ Is there a health check that reflects this feature's state?
    □ Does the new endpoint have a SLO target in the PR description?

DEPLOY (SRE runs post-deploy verification):
  After every production deploy:
    □ Run DQL: errors introduced in last 10 min?
    □ Check: new metrics appearing in DT?
    □ Run synthetic: new endpoint responding correctly?
    □ SLO dashboard: error budget still healthy?

RUNBOOK HANDOFF (SRE → Operations):
  After feature is stable:
    SRE writes runbook covering:
      - What the feature does (one paragraph)
      - How to check if it's healthy (DQL query + kubectl command)
      - What the alert means (for each alert that can fire)
      - How to fix the 3 most common failures
      - Escalation path
    
    Operations team reviews and approves runbook.
    SRE transfers oncall ownership to the feature team.
```

---

## Part 1 — Collaborating with Engineering on Observability

### The "observability contract" approach

```
Problem with typical SRE-engineering relationship:
  SRE: "Your service has no metrics"
  Engineer: "We're busy building features"
  SRE: "I can't tell if it's working"
  Engineer: "I'll add logging when there's a bug"
  → Incident happens → everyone scrambles

Observability contract (agreed BEFORE coding starts):
  For every new service or major feature, define:
  
  1. SLO target:
     "99.5% of batch jobs complete successfully per rolling 30 days"
  
  2. SLI definition:
     "successful_batch_jobs / total_batch_jobs × 100"
     Measured via: custom metric OR log count
  
  3. Alert owner:
     "payments team oncall, not platform team"
  
  4. Minimum instrumentation required (SRE provides template):
     - Structured JSON logs with event, result, duration fields
     - Counter metric: batch.payment.completed (success)
     - Counter metric: batch.payment.failed (failure, tagged by reason)
     - Gauge metric: batch.payment.queue_depth (for capacity planning)
  
  5. Runbook location:
     "Confluence: SRE/Runbooks/payment-batch-processing"

Why this works:
  Engineers know WHAT to instrument (no guessing).
  SRE knows WHAT to alert on (no post-incident scrambling).
  Both agree on the SLO (no arguments about thresholds later).
```

### Teaching engineers structured logging

```
BEFORE (what engineers naturally write):
  log.error("Database error for user " + userId + ": " + e.getMessage());
  
  Result in DT: "Database error for user user-abc123: Connection refused"
  Hard to aggregate: can't easily count errors by userId or error type.

AFTER (structured JSON logging — SRE teaches this):
  log.error("Database error",
    StructuredArguments.keyValue("userId", userId),
    StructuredArguments.keyValue("errorType", "DB_CONNECTION"),
    StructuredArguments.keyValue("operation", "getPaymentHistory"),
    e);

  Result in DT (if using logstash-logback-encoder):
  {
    "level": "ERROR",
    "userId": "user-abc123",
    "errorType": "DB_CONNECTION",
    "operation": "getPaymentHistory",
    "message": "Database error",
    "stack_trace": "..."
  }
  
  SRE can now query:
    DQL: filter j.errorType == "DB_CONNECTION" | summarize count(), by: j.operation
    = "How many DB errors per operation?" instantly aggregatable.

SRE provides a logging library snippet:
  build.gradle dependency:
    implementation 'net.logstash.logback:logstash-logback-encoder:7.4'
  
  logback-spring.xml:
    <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
      <encoder class="net.logstash.logback.encoder.LogstashEncoder" />
    </appender>
  
  After this: all log.info/warn/error calls produce JSON automatically.
  No code change needed per log call — just add the dependency + config.
```

### Custom metrics: OTEL vs Micrometer

```
Spring Boot provides Micrometer (built-in metrics library).
OTEL provides a vendor-neutral alternative.

SRE recommends: use Micrometer for Spring Boot custom metrics.
Reason: already included with Spring Boot Actuator, no additional dependency.

Template SRE provides to engineering:

@Service
public class BatchPaymentService {
    
    private final Counter completedCounter;
    private final Counter failedCounter;
    private final Gauge   queueDepthGauge;
    
    public BatchPaymentService(MeterRegistry registry, BatchQueue queue) {
        completedCounter = Counter.builder("batch.payment.completed")
            .description("Number of batch payments processed successfully")
            .register(registry);
        
        failedCounter = Counter.builder("batch.payment.failed")
            .description("Number of batch payments that failed")
            .tag("reason", "unknown")   // will be overridden per call
            .register(registry);
        
        queueDepthGauge = Gauge.builder("batch.payment.queue_depth",
                queue, BatchQueue::size)
            .description("Number of payments waiting in the batch queue")
            .register(registry);
    }
    
    public void processBatch(Payment payment) {
        try {
            // ... business logic ...
            completedCounter.increment();
        } catch (DatabaseException e) {
            registry.counter("batch.payment.failed",
                "reason", "DB_TIMEOUT").increment();
            throw e;
        } catch (GatewayException e) {
            registry.counter("batch.payment.failed",
                "reason", "GATEWAY_ERROR").increment();
            throw e;
        }
    }
}

These metrics are automatically:
  - Scraped by Dynatrace OneAgent via /actuator/metrics endpoint
  - Stored in DT with metric key: batch.payment.completed
  - Available for metric events, dashboards, SLOs
```

### Code review checklist (SRE provides to PR reviewers)

```
## Observability Checklist (required for all PRs touching business logic)

### Logging
- [ ] New code paths emit log.info/warn/error at meaningful points
- [ ] Log messages include context fields (userId, orderId, etc.) not just text
- [ ] No sensitive data in logs (passwords, card numbers, full SSNs)
- [ ] Startup conditions logged at INFO (e.g., "Feature flag X is enabled")
- [ ] Expected failures logged at WARN, unexpected at ERROR

### Metrics
- [ ] New counter/gauge/histogram created for significant operations
- [ ] Metric names follow convention: <team>.<service>.<operation>
- [ ] Failure reasons tagged (not just a single "failed" counter)
- [ ] Gauge correctly reflects current state (not cumulative count)

### Health checks
- [ ] /actuator/health/readiness reflects whether this feature can serve traffic
- [ ] New external dependency included in readiness indicator

### Runbook
- [ ] Runbook updated or created for new alert scenarios
- [ ] "What does this alert mean?" written in plain language
- [ ] "How to verify the system is healthy" section included
```

---

## Part 2 — Collaborating with Operations on Automation

### What operations wants automated

```
Operations (Ops) team toil (manual work SRE should automate):

1. DEPLOYMENT APPROVALS:
   Manual: Ops engineer manually checks DT dashboard before approving prod deploy
   Automated: CI/CD pipeline auto-checks: staging SLO healthy? smoke tests pass?
              Manual approval only needed for business validation, not technical checks.

2. SCALING:
   Manual: Ops engineer gets alert "high CPU" → logs into AWS console → adjusts HPA
   Automated: HPA manages scaling automatically. Karpenter provisions nodes.
              SRE writes the HPA config. Ops approves the scaling thresholds.

3. ALERT TRIAGE:
   Manual: Ops gets alert → opens DT → navigates to service → finds logs → reads stack trace
   Automated: Alert includes: DT problem URL + DQL query for this error type +
              kubectl command for pod logs + runbook link.
              First responder has everything in the PagerDuty notification.

4. CERTIFICATE RENEWAL:
   Manual: Ops calendar reminder → logs into ACM → requests renewal → validates → updates Ingress
   Automated: AWS Certificate Manager auto-renews. DT synthetic alerts 30 days before expiry.
              No manual action unless auto-renewal fails.

5. LOG ANALYSIS AFTER INCIDENTS:
   Manual: Ops engineer manually reads through CloudWatch/Kibana logs for hours
   Automated: SRE pre-writes a DQL "incident triage" notebook in DT.
              Ops runs: notebook → gets structured: when did it start, which pods,
              which error types, frequency over time. 10 minutes instead of 2 hours.
```

### Automating the alert notification

```
Problem: PagerDuty fires at 2am.
On-call engineer gets: "payment-service: High error rate"
They have to: open DT, navigate to service, check logs, find issue.
Time to first meaningful action: 15-30 minutes.

Improved alert notification (SRE configures via DT webhook):
  PagerDuty message:
  
  🚨 [PROD] payment-service: High error rate (2.3% > 0.1%)
  
  Started: 14:23:07 JST (8 minutes ago)
  Affected: 3/3 pods
  Error rate: 2.3% (threshold: 0.1%)
  
  🔍 Quick diagnosis:
  [View Problem in DT] → https://abc.live.dynatrace.com/ui/problems/P-1234
  [Recent errors] → DQL: fetch logs,from:now()-30m | filter service.name=="payment-service" | filter status=="ERROR" | limit 20
  
  📋 Likely causes:
  - Database connection issue (check /actuator/health)
  - Recent deploy at 14:22 (1 minute before incident)
  
  📖 Runbook: https://confluence.company.com/runbooks/payment-service
  
  kubectl quick checks:
    kubectl logs -n payment-ns -l app=payment-service --tail=50 --since=10m
    kubectl get pods -n payment-ns

How SRE builds this:
  DT Problem notification webhook (HTTP notification):
    URL: PagerDuty Events API v2
    Payload template:
    {
      "routing_key": "${var.pagerduty_key}",
      "event_action": "trigger",
      "payload": {
        "summary": "[${environment}] {ImpactedEntities[0].name}: {ProblemTitle}",
        "severity": "critical",
        "custom_details": {
          "problem_url": "{ProblemURL}",
          "dql_query": "fetch logs,from:now()-30m | filter service.name==\"{ImpactedEntities[0].name}\" | filter status==\"ERROR\" | limit 20",
          "runbook": "https://confluence.company.com/runbooks/{ImpactedEntities[0].name}"
        }
      }
    }
```

### Automating post-deploy verification

```
# .github/workflows/payment-service-ci.yaml

verify-production:
  name: Verify Production + Auto-Rollback
  needs: promote-to-production
  steps:
    - name: Wait for JVM warmup
      run: sleep 60

    - name: DT SLO health check
      run: |
        # Query DT API: is the payment-service SLO still healthy?
        SLO_STATUS=$(curl -sf \
          -H "Authorization: Api-Token ${{ secrets.DT_API_TOKEN }}" \
          "${{ secrets.DT_URL }}/api/v2/slo?sloSelector=name(\"payment-service Availability [production]\")" \
          | jq -r '.slo[0].status')
        
        echo "SLO status: $SLO_STATUS"
        if [ "$SLO_STATUS" != "SUCCESS" ]; then
          echo "❌ SLO degraded after deploy — triggering rollback"
          exit 1
        fi
        echo "✅ SLO healthy after deploy"

    - name: DT error rate check
      run: |
        # Query DT metrics API: any spike in error rate in last 5 min?
        ERROR_RATE=$(curl -sf \
          -H "Authorization: Api-Token ${{ secrets.DT_API_TOKEN }}" \
          "${{ secrets.DT_URL }}/api/v2/metrics/query?metricSelector=builtin:service.errors.server.rate:filter(eq(service.name,payment-service)):max&resolution=5m&from=now-5m" \
          | jq -r '.resolution.dataPoints[0][1]')
        
        if (( $(echo "$ERROR_RATE > 0.5" | bc -l) )); then
          echo "❌ Error rate ${ERROR_RATE}% > 0.5% — triggering rollback"
          exit 1
        fi
        echo "✅ Error rate ${ERROR_RATE}% — within threshold"

    - name: Auto-rollback on failure
      if: failure()
      run: |
        # Revert gitops tag to previous commit
        git pull origin main
        PREV_TAG=$(git log --oneline -- \
          gitops/production/app/payment-service/payment-service.yaml \
          | awk 'NR==2{print $1}' | xargs git show | grep 'tag:' | head -1 \
          | awk -F'"' '{print $2}')
        sed -i "s|tag: \".*\"|tag: \"$PREV_TAG\"|" \
          gitops/production/app/payment-service/payment-service.yaml
        git add . && git commit -m "chore(rollback): revert to $PREV_TAG [skip ci]"
        git push
        echo "🔄 Rolled back to $PREV_TAG"
```

### Automating runbook creation (SRE + Operations)

```
For every alert that exists, there must be a runbook.
SRE creates the template; operations fills in the domain knowledge.

Runbook template (SRE provides, Ops team fills in):
---
# Alert: payment-service High Error Rate

## What this alert means
Error rate for payment-service exceeded X% for more than 2 minutes.
This means approximately N payments per minute are failing.

## Impact
- **User impact**: Payment submissions returning errors
- **Business impact**: Revenue loss estimated at ¥5,000/minute at normal traffic
- **SLO impact**: Error budget burning at Nx rate

## Verify the alert is real
```
# Check current error rate (replace with actual DT link)
DT UI → Services → payment-service → Error analysis

# Or via kubectl:
kubectl logs -n payment-ns -l app=payment-service --tail=50 --since=5m | grep ERROR
```

## Common causes and fixes

### Cause 1: Database connection issue
**Signs**: Logs contain "Connection refused" or "Connection pool exhausted"

```
# Check DB connectivity:
kubectl exec -n payment-ns deploy/payment-service -- \
  curl -sf http://localhost:8080/actuator/health/readiness

# If status=DOWN: check RDS instance status in AWS console
# Or: check if DB password rotation happened (check ESO logs):
kubectl logs -n external-secrets deploy/external-secrets -l app.kubernetes.io/name=external-secrets --since=30m
```

**Fix**: Usually resolves within 60s after DB recovery. If not: restart pods.

### Cause 2: Recent deploy introduced bug
**Signs**: Errors started within 5 minutes of a gitops commit

```
# Check recent deploys:
git log --oneline -- gitops/production/app/payment-service/payment-service.yaml | head -5

# Rollback if needed:
# Edit gitops/production/app/payment-service/payment-service.yaml
# Change tag: to the previous SHA
# git commit + push → ArgoCD rolls back automatically
```

### Cause 3: Payment gateway API is down
**Signs**: Logs contain "GatewayTimeoutException" or HTTP 503 from gateway

```
# Check gateway status page: https://status.payment-gateway.com
# Check DT trace: Services → payment-service → trace → GatewayClient call → red
```

**Fix**: This is external. Escalate to payment gateway vendor.

## Escalation
- 15 min no progress → wake payments-lead
- 30 min no progress → wake engineering manager
- Payment gateway down > 30 min → invoke business continuity plan

## Related runbooks
- [payment-service High Latency](link)
- [payment-service Pod Restarts](link)
---
```

---

## Part 3 — Automation with Terraform (Observability as Code)

### Why "observability as code" matters

```
Manual DT configuration:
  SRE A creates a management zone in DT UI → month later leaves the company
  SRE B joins → cannot tell: what does this zone do? Why was it created?
  SRE B makes a change → breaks something → no audit trail

Observability as Code (Terraform):
  Every DT resource in Git:
    - Management zones
    - Alerting profiles
    - Metric events (8 signals per service)
    - SLOs
    - Synthetics
    - Notifications
  
  Benefits:
    → PR review: "SRE C wants to lower the latency threshold"
       → discussion in PR → approved → merged → applied
       → Full audit trail with author, reason (PR description), timestamp
    → Rollback: git revert → terraform apply → previous config restored
    → New environment: copy environments/dev/main.tf → change account ID → done
    → New service: add 8 lines to the services = { ... } map → PR → apply
       → 8 metric events + SLO + synthetic created automatically
```

### Adding a new service to all monitoring (one PR, complete coverage)

```hcl
# PR: "Add notification-service to Dynatrace monitoring"
# File: terraform/environments/production/main.tf
# Change: add one entry to the services map

module "dynatrace" {
  services = {
    # ... existing services ...
    
    # ADD THIS BLOCK:
    "notification-service" = {
      team             = "notifications"
      slo_target       = 99.0
      health_check_url = "https://notify.company.com/actuator/health"
      
      traffic_min_rps        = 3
      error_rate_alert       = 1.0
      latency_p99_ms         = 1000
      cpu_saturation_pct     = 80
      memory_usage_pct       = 80
      jvm_heap_pct           = 75
      pod_restart_threshold  = 2
      network_error_rate_pct = 1.0
    }
  }
}
```

```
What this one PR creates automatically (from the module):
  ✓ 1 Management zone rule: notifications-production
  ✓ 4 Alerting profiles: critical/high/warning/info
  ✓ 8 Metric events: all signals with production thresholds
  ✓ 1 Availability SLO: 99.0% rolling 30 days
  ✓ 1 Latency SLO: P99 < 1000ms
  ✓ 1 HTTP Synthetic: health check every 5 min from Tokyo + Singapore
  ✓ PagerDuty notification: HIGH alerts to notifications team
  ✓ Slack notification: WARNING to #alerts-notifications

Time to complete: 15 minutes (write PR) + 5 minutes (CI apply)
vs manual: 2-3 hours clicking through DT UI + likely missing something
```

### Drift detection (catch manual DT UI changes)

```
Problem: SRE B panics during an incident, changes a threshold in DT UI directly.
Emergency passes. Threshold stays changed. Nobody knows.
A week later: incident happens, threshold was wrong, alert didn't fire.

Solution: Terraform drift detection in CI

# .github/workflows/terraform-drift-check.yaml
name: Terraform Drift Detection

on:
  schedule:
    - cron: '0 9 * * 1'   # every Monday morning

jobs:
  drift-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Terraform Plan (detect drift)
        working-directory: terraform/environments/production
        run: |
          terraform init
          terraform plan -detailed-exitcode 2>&1 | tee plan.txt
          EXIT_CODE=${PIPESTATUS[0]}
          
          if [ $EXIT_CODE -eq 2 ]; then
            echo "⚠️ DRIFT DETECTED: DT config in UI differs from Terraform state"
            cat plan.txt
            # Post to Slack #sre-alerts
            curl -X POST $SLACK_WEBHOOK \
              -H 'Content-type: application/json' \
              --data "{\"text\":\"⚠️ Dynatrace config drift detected. Someone changed DT UI manually. Review plan.txt and run terraform apply to reconcile.\"}"
          elif [ $EXIT_CODE -eq 0 ]; then
            echo "✅ No drift — DT config matches Terraform state"
          fi

# -detailed-exitcode: exit 0 = no changes, exit 1 = error, exit 2 = changes detected
```

---

## Part 4 — Collaboration Anti-Patterns (What to Avoid)

```
ANTI-PATTERN 1: "SRE owns all observability, engineers don't touch DT"
  Problem: Engineers don't understand what DT monitors → write code with no metrics
           → SRE tries to infer instrumentation needs from outside → always incomplete
  Fix: Engineers own their service's DT dashboard. SRE owns the platform config.

ANTI-PATTERN 2: "Alert on everything, tune later"
  Problem: 50+ alerts fire daily → all ignored → real incident goes unnoticed
  Fix: Start with 3 alerts per service (traffic, errors, latency). Add more only after
       those 3 are correctly tuned and creating action.

ANTI-PATTERN 3: "SRE writes all runbooks alone"
  Problem: Runbooks lack domain knowledge. Operations team doesn't trust them.
           During incident: "this runbook is wrong, I'll wing it" → chaos.
  Fix: SRE writes structure/template. Engineer who built the feature writes content.
       Operations team reviews for clarity and completeness. All three sign off.

ANTI-PATTERN 4: "We'll add monitoring after launch"
  Problem: Feature launches → immediately has incident → no observability → blind.
  Fix: SRE attends sprint planning. Monitoring requirements defined BEFORE coding starts.
       No PR merged without observability checklist passing.

ANTI-PATTERN 5: "Automate everything immediately"
  Problem: Automated rollback triggers on a false positive → reverts a good deploy
           → 30 minutes of confusion before someone notices.
  Fix: Automate smoke tests. Keep auto-rollback conservative (only on smoke test failure,
       not on metric thresholds which can spike transiently during warmup).

ANTI-PATTERN 6: "One threshold for all environments"
  Problem: Production threshold (300ms) applied to dev → every JIT warmup triggers alert
           → engineers disable all DT alerts on dev → miss real dev issues.
  Fix: Per-environment thresholds managed in Terraform (dev: relaxed, prod: strict).
```

---

## Part 5 — Measuring Collaboration Success

### SRE toil reduction metrics

```
Track these every quarter:

1. MEAN TIME TO DETECT (MTTD):
   Time from problem start to first alert firing.
   Goal: < 5 minutes for P1 (payment-service down)
   How: DT Problem start time vs PagerDuty notification time
   
   Before automation: 15 min (human checks dashboard periodically)
   After automation: 2 min (synthetic fires, metric event fires within delay)

2. MEAN TIME TO DIAGNOSE (MTTD2):
   Time from alert firing to engineer understanding root cause.
   Goal: < 10 minutes
   How: incident postmortems, ask oncall team each quarter
   
   Before runbooks + DT: 45 min (find logs, understand service, diagnose)
   After runbooks + automated triage: 8 min (runbook shows DQL query, jump to trace)

3. ALERT NOISE RATIO:
   (False alerts / Total alerts) × 100%
   Goal: < 10% noise
   How: DT Problems → count "auto-resolved" (transient, probably noise) vs
        "resolved by human action" (real incidents)
   
   Before threshold tuning: 60% noise → oncall ignores alerts
   After tuning: 8% noise → oncall takes every alert seriously

4. DEPLOYMENT FREQUENCY:
   How many production deploys per week.
   Goal: increase (more frequent = smaller blast radius)
   How: count gitops commits to production/
   
   Before CI/CD automation: 1 deploy/week (manual, scary)
   After: 5 deploys/week (automated, verified, rollback automated)

5. FAILED DEPLOY RECOVERY TIME:
   Time from bad deploy detected to service recovered.
   Goal: < 5 minutes
   How: time between "first error" in logs and "rollback complete" in gitops
   
   Before auto-rollback: 25 min (detect → page oncall → manual rollback)
   After auto-rollback: 3 min (smoke test fails → git revert → ArgoCD applies)
```

### SRE-Engineering shared OKR example

```
Q3 OKR: Improve payment-service reliability

Objective: payment-service achieves 99.9% availability SLO

Key Results:
  KR1 (Engineering): 100% of payment endpoints covered by unit tests (coverage gate)
  KR2 (SRE): MTTD for payment-service incidents < 3 minutes
  KR3 (SRE + Engineering): Runbook exists and passes operations review for all 8 alerts
  KR4 (Engineering): Zero deploys without passing smoke tests
  KR5 (SRE): Auto-rollback working: last 5 bad deploys rolled back in < 5 min

Weekly sync agenda:
  - SLO error budget: consumed X% this week (was Y% last week)
  - Top 3 error types from DQL analysis this week
  - Any runbook gaps discovered during incidents this week
  - Next sprint: any new features with observability implications?
```

---

## Part 6 — Concrete Automation Examples

### Automation 1: Slack bot for DQL queries on demand

```
# Slash command: /dtlogs payment-service errors last 1h
# Returns: top 10 error messages from DT

# Lambda function triggered by Slack slash command:
import boto3, requests, json

def lambda_handler(event, context):
    service = event['text'].split()[0]      # "payment-service"
    window  = event['text'].split()[-1]     # "1h"
    
    dql = f"""
        fetch logs, from: now()-{window}
        | filter service.name == "{service}"
        | filter status == "ERROR"
        | summarize count = count(), by: {{ content }}
        | sort count desc
        | limit 10
    """
    
    response = requests.post(
        f"{DT_URL}/platform/storage/query/v1/query:execute",
        headers={"Authorization": f"Api-Token {DT_TOKEN}"},
        json={"query": dql}
    )
    
    results = response.json()['records']
    message = f"*Top errors for {service} (last {window})*\n"
    for r in results:
        message += f"• {r['count']}x: `{r['content'][:100]}`\n"
    
    # Post back to Slack
    requests.post(SLACK_WEBHOOK, json={"text": message})
```

### Automation 2: Pre-deploy SLO gate

```bash
#!/bin/bash
# pre-deploy-gate.sh — called by CI before promoting to production

SERVICE=$1
DT_URL=$2
DT_TOKEN=$3

# Query SLO health
RESPONSE=$(curl -sf \
  -H "Authorization: Api-Token $DT_TOKEN" \
  "$DT_URL/api/v2/slo?sloSelector=name(\"$SERVICE Availability [staging]\")&pageSize=1")

SLO_STATUS=$(echo $RESPONSE | jq -r '.slo[0].status')
ERROR_BUDGET=$(echo $RESPONSE | jq -r '.slo[0].errorBudget')

echo "SLO status: $SLO_STATUS"
echo "Error budget remaining: $ERROR_BUDGET%"

if [ "$SLO_STATUS" != "SUCCESS" ]; then
  echo "❌ DEPLOY BLOCKED: Staging SLO is not healthy ($SLO_STATUS)"
  echo "Resolve staging issues before promoting to production."
  exit 1
fi

if (( $(echo "$ERROR_BUDGET < 20" | bc -l) )); then
  echo "⚠️ WARNING: Only $ERROR_BUDGET% error budget remaining in staging"
  echo "Proceeding but please monitor carefully."
fi

echo "✅ Pre-deploy SLO gate passed"
exit 0
```

### Automation 3: Auto-create DT deploy event on every deploy

```yaml
# In CI pipeline: after successful deploy, record a deployment event in DT
# This appears in the DT Problem timeline: "Deploy at 14:22 → errors started at 14:23"
# Makes root cause analysis instant: "errors started exactly after this deploy"

- name: Record deploy event in Dynatrace
  run: |
    curl -sf -X POST \
      -H "Authorization: Api-Token ${{ secrets.DT_API_TOKEN }}" \
      -H "Content-Type: application/json" \
      "${{ secrets.DT_URL }}/api/v2/events/ingest" \
      --data '{
        "eventType": "CUSTOM_DEPLOYMENT",
        "title": "Deploy: payment-service=${{ env.IMAGE_TAG }}",
        "entitySelector": "type(SERVICE),entityName(payment-service)",
        "properties": {
          "git_sha":    "${{ env.IMAGE_TAG }}",
          "deployed_by": "${{ github.actor }}",
          "pipeline":   "${{ github.run_id }}",
          "environment": "production"
        }
      }'
```

```
Result in DT Problem timeline:
  14:20 [normal traffic]
  14:22 [DEPLOYMENT EVENT: payment-service=a1b2c3] ← visible marker
  14:23 [error rate starts rising]
  
  DT Davis AI: "Errors started 1 minute after deployment of a1b2c3"
  
  This takes the guesswork out of "did the deploy cause this?"
  Without deploy events: engineers spend 20 minutes correlating timestamps.
  With deploy events: instant correlation, 2 minutes.
```
