# Glossary — SRE Collaboration: Observability and Automation

Every term from main.md. One entry per term.

---

**SRE (Site Reliability Engineer)**
An engineer who applies software engineering practices to operations problems: reliability, scalability, and automation. Why it matters: SRE is the bridge between engineering (builds features) and operations (keeps systems running) — the role that owns observability infrastructure.

**Observability**
The ability to understand what a system is doing internally by examining its external outputs: logs, metrics, and traces. Why it matters: without observability, engineers are blind during incidents — they can see symptoms but not causes.

**Observability contract**
A pre-agreed definition (made before coding starts) of what a new service or feature will measure, what the SLO target is, who owns the alerts, and what the runbook covers. Why it matters: prevents the common failure mode of "we'll add monitoring after launch" — by then an incident has already happened.

**Structured logging (JSON)**
Writing application logs as JSON objects instead of plain text, with named fields for each data point. Why it matters: enables DQL queries like "count errors by errorCode" — impossible with plain text because each error message is unique and non-aggregatable.

**logstash-logback-encoder**
A Java library that makes Logback (Spring Boot's default logger) output JSON automatically for every log call. Why it matters: SRE provides this as a drop-in dependency — engineers add it to build.gradle and all logs become structured JSON with zero per-call code changes.

**Micrometer**
The metrics library built into Spring Boot Actuator. Provides Counter, Gauge, Timer, and Histogram types. Why it matters: the recommended way for Spring Boot engineers to emit custom business metrics — already available as a dependency, works automatically with DT OneAgent.

**Counter (Micrometer)**
A metric that only goes up — counts occurrences of an event (e.g., batch jobs completed). Why it matters: use for counting total events; DT can calculate rate-of-change from successive counter values.

**Gauge (Micrometer)**
A metric that can go up or down — reflects a current state (e.g., queue depth, active connections). Why it matters: use for measuring current capacity usage; Counters are wrong for this (they'd show a misleading ever-growing number).

**Tag (Micrometer)**
A key-value label attached to a metric to add dimensions for filtering. E.g., `tag("reason", "DB_TIMEOUT")` on a failure counter. Why it matters: enables DT queries like "how many failures with reason=DB_TIMEOUT vs reason=GATEWAY_ERROR?" — without tags, all failures look the same.

**SLO (Service Level Objective)**
A measurable reliability target agreed between the service team and its users: e.g., "99.9% of requests succeed over 30 days." Why it matters: the formal definition of "good enough" — provides a concrete shared standard between SRE and engineering.

**SLI (Service Level Indicator)**
The specific measurement used to evaluate the SLO: e.g., `successful_requests / total_requests × 100`. Why it matters: the SLI must be chosen carefully — HTTP success rate and business success rate are different things (HTTP 200 ≠ payment succeeded).

**Error budget**
The allowed amount of unreliability within an SLO window. At 99.9% over 30 days = 43.2 minutes of allowed downtime. Why it matters: when the error budget is exhausted, engineering should freeze feature deploys and focus on reliability.

**Runbook**
A step-by-step document that tells an on-call engineer what a specific alert means, how to verify it, how to fix common causes, and who to escalate to. Why it matters: written in advance so the 2am engineer doesn't have to figure out the system from scratch under pressure.

**Toil**
Repetitive, manual operational work that doesn't improve the system — it just keeps it running at the current state. Examples: manually scaling services, manually renewing certificates, manually checking dashboards. Why it matters: SRE's core job is to automate toil away; the freed time goes into reliability improvements.

**MTTD (Mean Time To Detect)**
Average time from when a problem starts to when the first alert fires. Why it matters: a 15-minute MTTD means problems silently affect users for 15 minutes before anyone knows.

**MTTD2 (Mean Time To Diagnose)**
Average time from when an alert fires to when the engineer understands the root cause. Why it matters: a 45-minute MTTD2 means the engineer spends 45 minutes navigating logs and dashboards before knowing what to fix.

**Alert noise ratio**
(False alerts / Total alerts) × 100%. If 60% of alerts are noise, engineers stop trusting alerts and start ignoring them — including real incidents. Why it matters: the leading cause of missed incidents is alert fatigue from too many false positives.

**Auto-rollback**
A CI/CD pipeline step that automatically reverts a bad deploy when production smoke tests fail. Why it matters: reduces failed deploy recovery time from 25 minutes (detect → page oncall → manual rollback) to 3 minutes.

**Smoke test**
A quick post-deploy check (3-5 critical HTTP calls) that verifies the service is alive and basic functionality works. Why it matters: catches "deploy broke everything" scenarios within minutes, triggering auto-rollback before widespread impact.

**Pre-deploy SLO gate**
A CI step that queries the DT API before promoting to production — if the staging SLO is not healthy, the deploy is blocked. Why it matters: prevents promoting a service to production when staging is already showing reliability problems.

**Deployment event (DT)**
A custom event injected into Dynatrace via API at deploy time (`event_type: CUSTOM_DEPLOYMENT`). Appears as a marker on the DT problem timeline. Why it matters: instantly correlates "errors started 1 minute after this deploy" — takes guesswork out of incident root cause analysis.

**Davis AI**
Dynatrace's AI engine that correlates events (like a deployment) with problems (like a sudden error rate increase) and shows the likely root cause in the Problem view. Why it matters: automatically flags "deployment X likely caused this incident" — saving 20+ minutes of manual timeline correlation.

**Drift detection (Terraform)**
Running `terraform plan` on a schedule to detect when manual changes in DT UI have diverged from the Terraform-managed state. Why it matters: manual DT UI changes made during incidents often never get reverted, causing unexpected behavior months later.

**`-detailed-exitcode` (Terraform)**
A Terraform flag that makes `terraform plan` exit with code 0 (no changes), 1 (error), or 2 (changes detected). Why it matters: used in drift detection CI to programmatically detect when DT configuration has drifted from Terraform state.

**Observability as Code**
The practice of managing all monitoring configuration (DT management zones, alerts, SLOs, dashboards) in version-controlled Terraform files instead of clicking through the DT UI. Why it matters: provides audit trail, rollback capability, peer review, and reproducibility across environments.

**PR observability checklist**
A list of requirements that every engineering PR must satisfy before merge: structured logs, metrics with tags, updated health checks, updated runbook. Why it matters: enforces "monitoring before launch" at the code review stage rather than after an incident.

**Oncall ownership transfer**
The process where SRE hands alert ownership to the feature team after the feature is stable and the runbook is reviewed. Why it matters: feature teams have the domain knowledge to diagnose their own features — SRE should not be oncall for every service forever.

**OTEL Events API**
The DT REST API endpoint `POST /api/v2/events/ingest` used to record custom events (deployments, config changes) in Dynatrace. Why it matters: powers deployment event markers in DT problem timelines; also used for CI/CD integration.

**Slack bot (DQL on demand)**
An automation where engineers type `/dtlogs payment-service errors 1h` in Slack and get the top 10 error messages back automatically via a Lambda function calling the DT API. Why it matters: removes the friction of "I need to open DT, navigate, remember DQL syntax" — engineers query logs directly in Slack.

**OKR (Objective and Key Result)**
A goal-setting framework: one qualitative Objective + 3-5 measurable Key Results. Why it matters: SRE and engineering sharing OKRs creates aligned incentives — engineering cares about test coverage because it affects the shared reliability goal.

**Quarterly threshold review**
A regular (every 3 months) process of evaluating whether alert thresholds are still correct given changes in traffic patterns, service behavior, and infrastructure. Why it matters: a threshold correct in Q1 (100 req/min baseline) may cause constant false alerts in Q4 (1000 req/min baseline after growth).

**Deploy event marker**
A vertical line on a DT metric chart showing exactly when a deployment happened. Why it matters: visual correlation between "metric changed at T" and "deploy happened at T-1min" — the fastest way to determine if a deploy caused an issue.

**Custom deployment event**
A DT event created via API with `eventType: CUSTOM_DEPLOYMENT` that links to a Kubernetes service entity and records the deployed version, deployer, and pipeline run. Why it matters: DT Davis AI uses these events when calculating root cause — "problem started 1 minute after deployment of SHA abc1234."

**Shared OKR**
A performance objective co-owned by SRE and engineering teams, ensuring both teams work toward the same reliability goals. Why it matters: prevents the anti-pattern where engineering optimizes for feature velocity while SRE optimizes for stability — shared OKRs align incentives.
