# Glossary — SRE Operations Deep Dive
Every term from main.md. One entry per term. SRE beginner level.

---

**SRE (Site Reliability Engineering)**
A discipline where software engineering practices are applied to operations problems. Coined at Google. SREs write code to automate operations, define measurable reliability targets, and balance feature development against reliability work. Why it matters: SRE turns "keep the lights on" from reactive firefighting into a disciplined, measurable engineering practice.

**SLI (Service Level Indicator)**
The specific metric being measured for a service. Examples: HTTP error rate, P99 latency, request success rate. Why it matters: the raw data that feeds an SLO — you can't set a target (SLO) without first choosing what to measure (SLI).

**SLO (Service Level Objective)**
A measurable reliability target. "99.9% of requests must return 2xx within 300ms over 30 days." Internal commitment — not a customer contract. Why it matters: defines objectively what "working" means. Replaces subjective debate about service health with a number.

**SLA (Service Level Agreement)**
A contractual commitment to customers. "If availability drops below 99.9%, you receive a credit." Stricter than SLOs — SLOs have a buffer above SLAs to avoid breaching customer contracts. Why it matters: breaching an SLA has direct financial consequences.

**Error budget**
The allowed amount of failure within an SLO window. For 99.9% monthly: 43.2 minutes. When budget is consumed, the SLO is breached. Why it matters: makes failure a resource to be managed, not a disaster to be avoided at all costs. Teams can spend budget on risky deploys or experiments — intentionally.

**Error budget policy**
A written team agreement on what to do at different budget levels. >50%: deploy freely. 20–50%: caution. <20%: reliability work only. 0%: mandatory postmortem before any features. Why it matters: without a policy, the budget number changes nothing about team behavior.

**Burn rate**
How fast error budget is being consumed relative to the SLO window. 1× = normal pace. 14.4× = budget gone in 2 days. Why it matters: burn rate alerts warn BEFORE the SLO is actually breached — gives time to act while budget remains.

**Fast burn threshold (14.4×)**
If consuming budget 14.4× faster than normal, it would be exhausted in 2 days (30/14.4). Triggers an urgent PagerDuty alert. Why it matters: the EARLY warning that an acute incident is eroding the reliability commitment quickly.

**Slow burn threshold (3×)**
Budget would be exhausted in 10 days (30/3). Triggers a Slack warning. Why it matters: catches chronic degradation — a service that's "fine right now" but trending toward SLO breach by end of month.

**Incident**
An event that causes or risks causing unacceptable impact on service reliability. Has states: TRIGGERED → ACKNOWLEDGED → RESOLVED. Why it matters: the central unit of reactive SRE work — every incident produces a postmortem that improves the system.

**P1/P2/P3/P4/P5 (incident priority)**
Classification by severity: P1 = production down, revenue impact; P2 = significant degradation; P3 = partial degradation; P4 = minor/cosmetic; P5 = informational. Why it matters: determines response time, who gets woken up, and escalation path.

**MTTA (Mean Time to Acknowledge)**
Average time from alert firing to an engineer acknowledging it. Target: <5 min for P1. Why it matters: high MTTA = incidents go unattended while users are affected. Measures on-call responsiveness and alert noise (engineers stop responding to noisy alerts).

**MTTR (Mean Time to Resolve)**
Average time from alert firing to the incident being resolved. Measures overall incident response effectiveness. Why it matters: high MTTR = long user impact. Driven by: runbook quality, system observability, rollback speed, engineer experience.

**PACE framework**
A structure for incident status updates: Problem (what's broken), Action (what you're doing), Cause (root cause if known), ETA (estimated resolution time). Post every 15 minutes. Why it matters: prevents silence during incidents — stakeholders need regular updates even if "no new findings."

**Incident Commander (IC)**
A designated role during major incidents (P1/P2). The IC coordinates responders, communicates status to stakeholders, and makes decisions. The IC does NOT investigate or fix — that's engineers' job. Why it matters: separating coordination from investigation prevents both from being done poorly.

**Mitigation**
Stopping the immediate user impact — often without knowing the root cause yet. Roll back the deploy, restart the pods, add capacity. Why it matters: SRE principle: mitigate first, understand later. Users don't care about your RCA while they can't pay.

**Resolution**
The permanent fix — root cause identified and corrected. Sometimes different from mitigation (rollback mitigates, adding missing DB index resolves). Why it matters: mitigation buys time; resolution prevents recurrence.

**Toil**
Manual, repetitive operational work with no lasting value. Scales with service growth. Examples: manually restarting pods, rotating passwords by hand, manually checking if a test passed. Why it matters: SRE target is <50% time on toil. High toil = low engineering work = system never improves.

**Toil elimination**
Replacing manual toil with automation, better systems, or architectural fixes. Pod OOM kill → fix the memory leak. Manual password rotation → RDS auto-rotation + ESO. Why it matters: the most valuable SRE work — each piece of toil eliminated is time that never returns.

**GameDay**
A planned exercise where SREs intentionally break things in a controlled way to verify that monitoring, alerts, and runbooks work correctly. Named after NFL game preparation. Why it matters: finding gaps in monitoring DURING a planned test (business hours, team assembled) is far better than finding them during a 3am production incident.

**Chaos engineering**
A discipline of deliberately injecting failures into systems to build confidence in their resilience. More structured than GameDay — follows scientific method: define steady state, inject failure, observe, fix gaps. Why it matters: builds muscle memory for incident response and reveals hidden failure modes before real incidents do.

**Progressive delivery**
Deploying changes to a small subset of users/traffic first, monitoring, then expanding. Patterns: ring deployment (1% → 10% → 50% → 100%), canary, blue-green, feature flags. Why it matters: limits blast radius of bad deploys — only 1% of users experience a bug before it's caught and rolled back.

**Canary deployment**
A deployment pattern where a new version is deployed to a small percentage (1-5%) of production traffic. The "canary in the coal mine" — if the canary dies (bad metrics), roll back before most users are affected. Why it matters: production is different from staging. Canary exposes production-specific issues with minimal user impact.

**Blue-green deployment**
Two identical environments (blue = current, green = new). Traffic switches from blue to green atomically. Rollback = switch back to blue. Why it matters: instant rollback with zero downtime — no need to redeploy, just flip the traffic switch.

**Feature flag**
A configuration toggle that enables/disables a feature at runtime without a deploy. The feature is deployed but disabled. Enabled for 1% → 10% → 100%. Why it matters: decouples deployment (code goes to production) from release (feature is turned on). Rollback = flip flag off, no deploy needed.

**Shift-left**
Finding bugs as early as possible in the development pipeline. Unit tests are "left" (fast, cheap). Production incidents are "right" (slow, expensive). Why it matters: fixing a bug in unit tests = 5 minutes. Fixing a bug in production = 30 minutes + user impact + postmortem. Move the discovery left.

**Deployment gate**
A mandatory check that must pass before a change can proceed to the next environment. Unit tests, Trivy scan, smoke tests, k6 load test, manual approval. Why it matters: each gate catches a different class of problem — none catches everything, but together they catch most bugs before production.

**Capacity planning**
The process of projecting future resource needs based on current usage trends and business forecasts, then ensuring infrastructure can handle predicted demand. Why it matters: running out of capacity during a marketing campaign = production incident + revenue loss.

**Headroom factor**
Current capacity ÷ current demand. `200 req/min capacity / 50 req/min demand = 4×`. If business projects 3× growth: `200 / 150 = 1.3× headroom` — too tight, need to scale. Why it matters: insufficient headroom means the next traffic spike = incident.

**VPA (Vertical Pod Autoscaler)**
A Kubernetes controller that adjusts CPU/memory requests and limits for existing pods based on observed usage. Requires pod restart to apply. Why it matters: right-sizes pods automatically — avoids both over-provisioning (wasted money) and under-provisioning (OOM kills).

**Load testing**
Simulating production-level traffic on a service to measure performance characteristics and find breaking points before real users do. Tool: k6. Why it matters: staging with real load reveals: JVM heap growth under load, HPA trigger points, connection pool sizing, latency regression from new code.

**k6 thresholds**
Pass/fail criteria coded directly into k6 test scripts. If `http_req_duration{p(99)} > 300ms` or `http_req_failed > 0.1%`, the test fails and CI pipeline stops. Why it matters: automatically blocks a deploy if load test reveals a performance regression — no human needs to read k6 output.

**Reliability review (pre-launch)**
A checklist-based review of a new service before it receives production traffic. Covers: SLOs defined, alerts configured, runbooks written, probes set, security hardened. Why it matters: catching missing monitors before launch = 10 minutes. Missing a monitor and having a silent outage = hours of user impact.

**Four Golden Signals**
Google SRE's framework for what every service must monitor: Traffic, Errors, Latency, Saturation. Collectively they describe the complete health picture of a service. Why it matters: if you monitor only one or two, you'll miss entire classes of failures.

**Traffic (golden signal)**
Requests per second/minute hitting a service. The baseline — all other signals are relative to traffic. Zero traffic = all other signals meaningless. Why it matters: traffic drop alert catches silent outages where error rate = 0% because there are no requests to fail.

**Errors (golden signal)**
The percentage of requests that fail (5xx HTTP codes, exceptions, timeouts). The most direct measure of user-facing failures. Why it matters: if error rate rises, users are experiencing failures right now.

**Latency (golden signal)**
Response time distribution — specifically P99 (the 99th percentile). Not average. Why P99: the average hides the slowest 1% of users who may be experiencing 5-second timeouts. Why it matters: P99 rising = users waiting. Distributed traces reveal where the time is being spent.

**Saturation (golden signal)**
How "full" a resource is — CPU, memory, JVM heap, DB connections, thread pool. A leading indicator that fires BEFORE errors and latency. Why it matters: JVM heap at 70% → alert → fix before OOM kill happens. Saturation gives advance warning.

**Blameless postmortem**
A postmortem culture where the goal is to fix SYSTEMS, not punish PEOPLE. Root cause language: "the system allowed X" not "engineer X failed." Why it matters: if engineers fear blame, they won't be honest in postmortems → organizational learning stops → same incidents repeat.

**Contributing factor**
A condition that made an incident worse but wasn't the root cause. Example: "k6 test was only 3 minutes (contributing factor) — too short to expose a memory leak (root cause: unbounded cache)." Why it matters: fixing contributing factors often prevents the same root cause from reaching production next time.

**Action item (postmortem)**
A specific task that prevents recurrence, with a named owner, Jira ticket, and due date. Vague action items ("improve monitoring") are not action items — they're wishes. Why it matters: without specific owners and dates, nothing gets done and the same incident happens again.

**Runbook**
A step-by-step operational guide for responding to a specific alert. Contains: immediate actions, investigation steps, common fixes, escalation path. Why it matters: enables a new on-call engineer to handle incidents they've never seen before by following the documented process.

**Architecture Decision Record (ADR)**
A document capturing a significant technical decision: what was decided, why, alternatives considered, consequences. Why it matters: 6 months later, when someone asks "why did we choose this approach?" — the ADR answers it without finding the original decision-maker.

**On-call rotation**
A repeating schedule assigning one engineer per week as the primary incident responder. The on-call engineer must acknowledge alerts within 5 minutes. Why it matters: production never sleeps — someone must always be reachable to respond to critical failures.

**Alert noise ratio**
The proportion of alert firings that were false positives (acknowledged + resolved with no action). >50% noise = threshold is wrong. Why it matters: high noise → engineers stop responding to alerts → real incidents are ignored.

**Toil tracking**
Measuring the proportion of time spent on manual operations vs engineering work. SRE target: <50% toil. Why it matters: if toil exceeds 50%, the team is in a maintenance trap — no capacity to improve the system, which means reliability degrades over time.

**DR (Disaster Recovery)**
A plan and environment for recovering service operation when the primary environment fails (region-level AWS failure, catastrophic data loss). Includes: failover procedures, RTO (Recovery Time Objective), RPO (Recovery Point Objective). Why it matters: tested DR is the difference between "we recovered in 20 minutes" and "we were down for 4 hours."

**RTO (Recovery Time Objective)**
The maximum acceptable time to restore service after a disaster. Example: "payment-service must be restored within 4 hours of a region failure." Why it matters: sets the expectation for DR readiness — if your RTO is 4 hours, your DR infrastructure and runbooks must enable 4-hour recovery.

**RPO (Recovery Point Objective)**
The maximum acceptable data loss in time. Example: "we can lose at most 5 minutes of payment transaction data in a disaster." Why it matters: drives the backup frequency and replication strategy — RPO of 5 minutes requires near-real-time replication, not hourly backups.
