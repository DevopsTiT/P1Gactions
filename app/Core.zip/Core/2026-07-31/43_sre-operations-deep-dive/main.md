# SRE Operations — Deep Dive
## What "Proven Experience in SRE" Actually Means Day-to-Day

> SRE = applying software engineering discipline to operations problems.
> This guide covers every pillar of SRE operations: what it is, why it exists,
> how it's done, and what "proven experience" looks like in practice.

---

## The SRE Mental Model — Before Anything Else

```
Traditional Ops mindset:
  "Keep the system running. Prevent ALL changes. Change = risk."
  Result: systems never improve. Technical debt accumulates. Incidents still happen.

SRE mindset:
  "Reliability is a feature. Measure it. Budget for failure. Enable safe change."
  Result: teams can move fast AND stay reliable — with math, not prayer.

The fundamental insight:
  100% reliability is impossible AND undesirable.
  Chasing 100% costs more than the benefit it provides.
  99.9% = 43 minutes downtime/month (acceptable for most services)
  The 0.1% budget is spent on: deploys, experiments, upgrades, learning.
  SRE defines HOW MUCH failure is acceptable, then manages to that budget.
```

---

## Pillar 1 — Service Level Objectives (SLOs) and Error Budgets

### What SLOs are and why they exist

```
An SLO answers: "What does 'working' mean for this service?"

Without SLOs:
  Engineer A: "The service is fine, latency is only 800ms"
  Product Manager: "800ms is terrible, users are complaining"
  → No common definition of "working" → endless debate during every incident

With SLOs:
  "payment-service: 99.9% of requests must return 2xx within 300ms"
  If we're at 99.95%: service is healthy, deploy features
  If we're at 99.8%: SLO is burning, freeze features, fix reliability
  → Objective measurement, no debate

SLOs define THREE things:
  SLI: Service Level Indicator — the METRIC being measured
    e.g., builtin:service.errors.server.rate
  SLO: Service Level Objective — the TARGET for that metric
    e.g., error rate must be < 0.1% over 30 days
  SLA: Service Level Agreement — the CONTRACT with users if SLO is missed
    e.g., "if availability drops below 99.9%, customers get a credit"
```

### Error budget in practice

```
99.9% availability over 30 days:
  Total minutes in 30 days = 43,200
  Error budget = 0.1% × 43,200 = 43.2 minutes

  How the budget gets SPENT:
    Planned maintenance:    10 min (rolling deploy of new version)
    Unplanned incident:     25 min (DB connection pool exhausted)
    Experiment (new route): 5 min  (A/B test with slightly higher error rate)
    Total spent:            40 min (93% of budget used in the month)
    Budget remaining:       3.2 min

  Decision: with 3.2 min remaining (7% of budget):
    → We should NOT deploy a risky change this week
    → Budget is nearly exhausted
    → Prioritize reliability work over feature work this sprint

Error budget policy — what the team does when budget runs low:
  > 50% remaining: normal operations, deploy freely
  20–50% remaining: caution, no risky changes without SRE review
  < 20% remaining: reliability work only, no new feature deploys
  0% (breach): mandatory postmortem, engineering focus on fixes before ANY features
```

### Burn rate alerts

```
Burn rate = how fast you're consuming error budget vs the expected pace

Expected pace:
  30-day budget consumed evenly: 1/30 per day = burn rate 1.0×

Fast burn (14.4×):
  Consuming 14.4× normal pace
  14.4 × 2 days = 30 days worth of budget gone in 2 days
  Action: PAGE immediately (fast_burn alert → PagerDuty)

Slow burn (3×):
  Budget exhausted in 10 days (30/3)
  Action: Slack notification, investigate this week

Why two thresholds?
  Fast burn catches acute incidents (error spike, outage)
  Slow burn catches chronic degradation (gradual latency creep, noise alerts)
  A service can be "within SLO" right now but on a trajectory to breach it in 10 days
```

---

## Pillar 2 — Incident Management

### The complete incident lifecycle

```
PHASE 1: DETECTION (0–2 min)
  How incidents are detected:
    a) Automated: Dynatrace alert → PagerDuty → on-call paged
    b) User report: customer calls support → support tickets SRE
    c) Proactive: SRE sees anomaly on dashboard during weekly review

  Goal: detect BEFORE users report it.
  Leading indicator > lagging indicator:
    Lagging: "5,000 users filed support tickets" (too late)
    Leading: "error rate crossed 0.1% threshold" (caught it early)

PHASE 2: RESPONSE (2–10 min)
  Three immediate actions:
    1. ACKNOWLEDGE in PagerDuty (stops escalation timer)
    2. POST in #incidents Slack channel:
       "Incident opened: payment-service P99 latency > 300ms. Investigating."
    3. OPEN the runbook for this alert

  Who does what:
    On-call engineer: investigate, fix
    Incident Commander (for P1): coordinate, communicate, make decisions
    Rule: if you're fixing, you're NOT communicating. These are separate jobs.

PHASE 3: INVESTIGATION (5–30 min)
  The RCA process (see separate RCA deep dive):
    1. Problems feed in Dynatrace → Davis AI suggestion
    2. Check deployments — what changed?
    3. Service map — is it isolated or cascading?
    4. Distributed traces — where is time spent?
    5. JVM metrics — heap, GC, threads
    6. Logs — what is the exact error?

PHASE 4: MITIGATION (variable)
  Mitigation ≠ root cause fix.
  Mitigation = stop the bleeding immediately.
    Roll back the bad deploy (5 min to mitigate, vs 3h to fix the bug)
    Restart the OOM-killed pods (immediate relief)
    Add capacity (scale up HPA, add replicas)
    Enable circuit breaker / feature flag to disable the broken feature
    Failover to DR environment

  SRE principle: mitigate first, understand later.
  Users don't care about your RCA. They care that the service works NOW.

PHASE 5: RESOLUTION
  Mitigation = bleeding stopped but root cause may not be fixed
  Resolution = root cause identified, permanent fix in place

  Sometimes they're the same:
    "Rolled back v2.3.1 (mitigation) and the memory leak is gone (resolution)"
  Sometimes they're separate:
    "Restarted pods (mitigation: service up, budget protected)"
    "Will add index to DB table (resolution: next sprint Jira ticket)"

PHASE 6: POST-INCIDENT
  Within 24h: draft postmortem
  Within 48h: finalize and share with team
  Within 1 week: all Jira action items created
  Within 1 month: critical action items closed
```

### The PACE update framework

```
Every 15 minutes during an active incident, post to #incidents:

P — Problem:   "payment-service error rate at 2.3%, 5xx on POST /payments"
A — Action:    "rolling back v2.3.1 now, ETA 5 min for rollback to complete"
C — Cause:     "preliminary: memory leak in new payment cache (heap hit 95%)"
E — ETA:       "service should recover within 5 min of rollback"

Even if nothing new: post "Still investigating. No new findings. ETA unknown."
Silence = panic for stakeholders.
Regular updates = confidence that someone is in control.
```

### Severity / Priority framework

```
P1 — CRITICAL:
  Complete service outage. Revenue impact. Users cannot complete core flows.
  Example: POST /payments returning 0 requests (silent outage or 5xx on all)
  Response: immediate page, all hands, incident commander assigned
  Target resolution: < 30 min

P2 — HIGH:
  Significant degradation. Some users affected. Revenue at risk.
  Example: payment-service latency P99 at 2000ms (SLO requires 300ms)
  Response: page on-call + lead engineer, same-day resolution
  Target resolution: < 4 hours

P3 — MEDIUM:
  Partial degradation. Non-critical functionality affected.
  Example: notification emails delayed by 30 minutes
  Response: Slack notification, business-hours investigation
  Target resolution: same business day or next sprint

P4 — LOW:
  Minor issue. No user impact. Technical debt or cosmetic.
  Example: DT alert firing on a metric that was tuned too tightly
  Response: Jira ticket, schedule in next sprint

P5 — INFORMATIONAL:
  Trend worth monitoring. No action needed now.
  Example: JVM heap slowly growing over 2 weeks (not yet concerning)
  Response: monitor, schedule threshold review
```

---

## Pillar 3 — On-Call Operations

### What good on-call looks like

```
The goal of on-call: right engineer, right tools, right information, minimum wake-ups.

Good on-call = BORING on-call.
  Number of incidents per rotation: 0–2 P1/P2 incidents per week
  Number of pages per night: 0 on most nights
  Alert noise ratio: < 20% false positives

Bad on-call = exhausting on-call.
  Multiple pages per night → engineers afraid of their own rotation → attrition
  Root cause: noisy alerts, recurring incidents without permanent fixes

SRE rule: if the same alert fires more than 3 times in a month, it is a systemic problem.
  Either: the service is genuinely unreliable → fix the service
  Or:     the alert threshold is wrong → fix the threshold
  Never: just acknowledge and move on (treating symptoms)
```

### The on-call runbook structure (every alert must have one)

```
Alert: [PROD] payment-service: error rate > 0.1%

Runbook: payment-service-error-rate.md (in Confluence)

## Overview
  What this alert means. What the user impact is.
  "payment-service HTTP 5xx rate above 0.1%. Users may see payment failures."

## Immediate Actions (first 5 minutes)
  1. Acknowledge in PagerDuty.
  2. Open Dynatrace → payment-service → error rate chart.
  3. Check if error rate is still rising or stabilizing.
  4. Post in #incidents: "Acknowledged payment-service error rate alert. Investigating."

## Investigation Steps
  1. Check Dynatrace Problems feed → Davis AI root cause suggestion.
  2. Check Deployments: was anything deployed in the last 60 min?
     DT → Service → Events → Deployment events
  3. Check distributed traces: filter by errors → find failing endpoint.
  4. Check logs: DT → Logs → filter ERROR level → what exception appears most?

## Common Root Causes and Fixes
  DB connection pool exhausted:
    Sign: HikariPool error in logs ("Connection is not available")
    Fix: kubectl rollout restart deployment/payment-service -n payment-ns
         (releases all connections, pool resets)
         Long-term: increase hikari.maximum-pool-size in application.yaml

  Bad deploy (new version introduced a bug):
    Sign: error rate started exactly when deployment event appears on chart
    Fix: check current image tag:
         kubectl get deployment payment-service -n payment-ns -o jsonpath='{.spec.template.spec.containers[0].image}'
         Roll back in gitops: revert the last commit to gitops/production/app/payment-service/payment-service.yaml
         git revert HEAD → git push → ArgoCD syncs → rolling deploy to previous version

  Downstream dependency (fraud-detection) failing:
    Sign: DT service map shows fraud-detection → RED
    Fix: check fraud-detection pods: kubectl get pods -n payments
         If OOMKilled: kubectl rollout restart deployment/fraud-detection -n payments

## Escalation
  If not resolved in 20 min:
    Escalate in PagerDuty → select "payments-senior-oncall"
    Message: "@lead-engineer payment-service error rate incident, tried X and Y, stuck because Z"

## Related Links
  - Dynatrace service: [payment-service DT link]
  - Postmortem template: [Confluence link]
  - Previous incidents: [Jira filter: label=payment-service AND type=incident]
```

### Toil reduction — the ongoing work of SRE

```
TOIL = manual, repetitive operational work that:
  - Has no permanent value (doing it again and again doesn't fix the root cause)
  - Scales with service growth (more users → more toil, linearly)
  - Is interruptive (breaks engineering work)

Examples of toil in a Java microservices environment:
  Manually restarting pods when memory leaks (same pod, every week)
  Manually rotating DB passwords (every 90 days, each service, each environment)
  Manually increasing connection pool size after each load test
  Manually checking "is the staging k6 test done yet?"

SRE target: < 50% of time on toil, > 50% on engineering work.
Measure: track toil vs project work each week in sprint planning.

Eliminating toil:
  Pod restarts for memory leaks → fix the memory leak (or add VPA to auto-resize)
  Manual password rotation → RDS automatic rotation + ESO refreshInterval
  Connection pool sizing → monitor with DT, set threshold, then resolve root cause in code
  "Is k6 done?" → k6 outputs results to CI, CI sends Slack notification automatically
```

---

## Pillar 4 — Change Management

### The SRE philosophy on change

```
Traditional ops: changes are dangerous. Freeze everything.
SRE: unreliability comes from BOTH change AND lack of change.
  Stale systems accumulate CVEs, technical debt, and unknown fragility.
  The safest system is one that changes frequently, safely, with good rollback.

The key: make changes small, tested, fast-to-rollback, and observable.
```

### Progressive delivery — how to deploy safely

```
RING DEPLOYMENT:
  Ring 0 (canary):  1% of production traffic → new version
  Ring 1:          10% of production traffic → if ring 0 is healthy after 10 min
  Ring 2:          50%
  Ring 3:         100%

  At each ring: watch error rate, P99 latency, JVM heap.
  If ANY metric exceeds threshold → abort, roll back ring.
  Users in rings 1-3 never see the bad version.

FEATURE FLAGS:
  Deploy code → disabled by default.
  Enable for:
    1% of users → watch metrics → 10% → 50% → 100%
  If bad: flip flag to off → instant rollback without a deploy.
  DT metric event fires → auto-disable flag (advanced integration).

BLUE-GREEN DEPLOY:
  Two identical environments: blue (current) and green (new).
  Route 0% traffic to green → verify green is healthy → switch 100% to green.
  Rollback: switch back to blue instantly (no deploy needed).
  Downside: 2× infrastructure cost during the swap window.

ROLLING UPDATE (what we use in Kubernetes):
  Replace pods one at a time.
  maxUnavailable: 0, maxSurge: 1 → never fewer than current replicas.
  Pod readiness probe must pass before old pod is terminated.
  If new pod fails probes → rollout pauses → old version still serving traffic.
```

### Deployment verification gates

```
Before merging ANY change to production, these gates must pass:

Gate 1: Unit tests (GitHub Actions: ./gradlew test)
  Catches: logic bugs, regression in existing behavior
  Speed: 1-3 minutes

Gate 2: Trivy security scan (GitHub Actions: aquasecurity/trivy-action)
  Catches: known CVEs in dependencies
  Speed: 2-5 minutes

Gate 3: Smoke tests in dev (post-deploy)
  Catches: integration failures, startup failures, config errors
  Speed: 5-10 minutes

Gate 4: k6 load test in staging
  Catches: performance regressions, resource exhaustion under load
  Speed: 3-10 minutes

Gate 5: Manual approval in PagerDuty GitHub Environment
  Catches: "is this a good time to deploy?" (end of business, known fragile period)
  Speed: human decision (1-60 min depending on context)

Gate 6: Production verification (post-deploy smoke test)
  Catches: production-specific config differences
  Speed: 2 minutes (automated)
  Auto-rollback: if smoke tests fail → git revert → ArgoCD syncs → rollback

If any gate fails → pipeline stops → no change reaches the next environment.
"Shift-left" principle: find bugs as early (left) in the pipeline as possible.
Finding a bug in Gate 1 (unit tests): 5 minutes, low cost, immediate feedback.
Finding a bug in Gate 6 (production verification): 30 minutes, user impact, expensive.
```

---

## Pillar 5 — Capacity Planning and Performance Engineering

### Capacity planning process

```
Quarterly capacity review:

1. COLLECT CURRENT USAGE
   For each service:
   - Average CPU utilization (last 30 days): DT → Metrics → builtin:process.cpu.usage
   - Peak CPU during k6 load test: from staging metrics
   - Current replica count and HPA settings
   - Cost per month (EC2 instances)

2. PROJECT FUTURE DEMAND
   - Business forecast: "next quarter we expect 3× users from marketing campaign"
   - Linear extrapolation: current 50 req/min → expected 150 req/min
   - Stress test result: service handles 200 req/min before SLO breach

3. CALCULATE HEADROOM
   Current capacity: 200 req/min (from load test)
   Current demand: 50 req/min
   Headroom factor: 200/50 = 4×
   Expected Q3 demand: 150 req/min
   Headroom with expected Q3: 200/150 = 1.3× (TIGHT — need to scale)

4. ACTION ITEMS
   - Increase HPA maxReplicas from 20 to 40 before campaign launch
   - Add 2 more EKS nodes to the node group (via Terraform)
   - Run k6 at 300 VUs to validate the new capacity

5. COST OPTIMIZATION (after scaling)
   - Review DT metrics: any service running at < 30% CPU on average?
     → Downsize CPU request, pack more pods per node, reduce instance count
   - Spot instances for non-critical workloads (staging, dev)
```

### VPA (Vertical Pod Autoscaler) vs HPA (Horizontal)

```
HPA (Horizontal): adds/removes REPLICAS based on CPU/memory/custom metrics.
  Good for: stateless services (add more payment-service pods under load)
  Limitation: each pod must be small enough to fit on available nodes

VPA (Vertical): resizes CPU/memory REQUESTS for existing pods.
  Good for: services with variable resource needs (notification-service at night vs day)
  Limitation: requires pod restart to apply new resource values
              cannot be combined with HPA on the same metric (both fighting)

In this project:
  payment-service: HPA (3→20 replicas based on CPU)
  order-service:   HPA (similar)
  notification-service: could use VPA (message processing load varies by time of day)
```

### Load testing as an SRE practice

```
k6 is run:
  1. After every staging deploy (in CI pipeline, automated)
  2. Before every major release (manual extended test)
  3. Quarterly for capacity planning

k6 test design (payment-service example):
  Ramp up:      0→50 VUs over 60s  (simulates traffic growing, not instant spike)
  Sustained:    50 VUs for 3 min   (the real test)
  Ramp down:    50→0 VUs over 30s  (verify graceful scale-down)

What to watch during k6:
  DT Metrics Explorer (live):
    - P99 latency: stays below 300ms? Or climbing?
    - Error rate: stays below 0.1%?
    - JVM heap: stays below 78% (staging threshold)?
    - Pod count: HPA adds replicas at what load?

  k6 output:
    http_req_duration{p(99)}: should be < 300ms (our production SLO)
    http_req_failed:          should be < 0.1%

Pass/fail criteria are codified in the k6 script:
  thresholds: {
    "http_req_duration{p(99)}": ["p(99) < 300"],  // fail if > 300ms
    "http_req_failed":           ["rate < 0.001"] // fail if > 0.1% errors
  }
```

---

## Pillar 6 — Reliability Engineering (Proactive Work)

### Reliability reviews (before production launches)

```
PRE-LAUNCH RELIABILITY CHECKLIST (for each new service):

Infrastructure:
  [ ] Service has SLO defined (availability + latency minimum)
  [ ] All 8 metric event alerts configured in DT (via Terraform)
  [ ] PagerDuty service created, integration key in Secrets Manager
  [ ] Runbook written in Confluence for each alert
  [ ] Synthetic monitor configured (Tokyo + Singapore)

Kubernetes:
  [ ] Resource requests and limits set correctly (tested with k6)
  [ ] HPA configured (min/max replicas, CPU target)
  [ ] PDB configured (minAvailable > 0 for services with replicaCount > 1)
  [ ] Probes configured (startup + readiness + liveness, correct paths)
  [ ] preStop hook: sleep 15 for ALB deregistration
  [ ] topologySpreadConstraints: 1 pod per AZ in production

Security:
  [ ] No secrets in environment variables or ConfigMaps (using ESO + Secrets Manager)
  [ ] readOnlyRootFilesystem: true
  [ ] runAsNonRoot: true
  [ ] IRSA configured (no static AWS credentials)
  [ ] Trivy scan passes (no CRITICAL CVEs)

Observability:
  [ ] Distributed traces flowing to DT (OTEL endpoint configured)
  [ ] Container logs appearing in DT Grail
  [ ] Custom business metrics emitted (if applicable)

Rollback:
  [ ] Rollback tested: image tag reverted, ArgoCD synced, service recovered
  [ ] Rollback time documented: target < 5 min for production
```

### Failure mode analysis — GameDay

```
GameDay = intentionally breaking things in a controlled environment to:
  a) Verify that alerts fire as expected
  b) Verify that runbooks are accurate
  c) Build muscle memory for incident response
  d) Find gaps in monitoring/runbooks before real incidents

Example GameDay exercise for payment-service:

Exercise 1: Kill all pods
  kubectl delete pods -l app=payment-service -n payment-ns
  Expected:
    - traffic drop alert fires within 5 min (no traffic = alert)
    - pods restart (Kubernetes self-heals)
    - readiness probe gates: traffic only returns when pods are truly ready
  Verify: DT shows traffic drop, alert fires, service recovers within X minutes

Exercise 2: Simulate DB connection pool exhaustion
  kubectl exec into the pod → force close connections
  OR: temporarily set spring.datasource.hikari.maximum-pool-size=1 in ConfigMap
  Expected:
    - HikariPool errors in logs
    - Error rate alert fires
    - Runbook: "restart pods to reset pool"

Exercise 3: Simulate node failure
  kubectl cordon node-1 && kubectl drain node-1 --ignore-daemonsets
  Expected:
    - PDB prevents draining last pod too quickly
    - topologySpreadConstraints: new pods land in other AZs
    - Service remains available throughout (verified via synthetic monitor)

After each exercise:
  1. Did the alert fire? (yes/no)
  2. Did the runbook work? (yes/no → update if not)
  3. Was the recovery time within SLO? (yes/no)
  4. What surprised us? (update runbook or alert)
```

### Chaos engineering principles

```
Principles for running chaos experiments in production (carefully):

Rule 1: Start small in non-prod (dev → staging → production)
Rule 2: Define the steady state FIRST ("at baseline, P99 = 200ms, error rate = 0.01%")
Rule 3: Inject the failure
Rule 4: Measure: did steady state hold?
Rule 5: Fix any gaps found before moving to production experiments
Rule 6: Run production experiments during business hours (oncall is awake)
Rule 7: Have a kill switch (immediately revert the experiment)

Tools:
  AWS Fault Injection Simulator (FIS): injects EC2 failures, network latency, AZ outages
  Chaos Mesh: injects Kubernetes failures (pod kills, network partitions, CPU stress)
  Manual: kubectl drain, kubectl delete pod, manually exhausting resources
```

---

## Pillar 7 — Postmortem Culture

### Writing a blameless postmortem

```
Rule: postmortems identify SYSTEM failures, not human failures.
"Engineer X made a mistake" → not useful. X will be more careful, others won't.
"The deploy pipeline allowed v2.3.1 to reach production without a DB index check" → useful.
  Fix the pipeline → problem can't happen again regardless of who deploys.

Postmortem template (5 required sections):

## 1. Summary (one paragraph)
  What: payment-service returned 5xx to 2,300 users
  When: 2026-07-31 14:32–15:02 JST (30 minutes)
  Impact: 847 failed payment attempts, estimated ¥420,000 revenue impact
  Root cause: memory leak in v2.3.1 payment cache → OOM kills
  Resolution: rolled back to v2.3.0

## 2. Timeline
  | Time (JST) | Event |
  |-----------|-------|
  | 14:20 | payment-service v2.3.1 deployed via ArgoCD sync |
  | 14:25 | JVM heap utilization crosses 85% (above 70% threshold) |
  | 14:32 | DT alert fires: payment-service error rate > 0.1% |
  | 14:32 | PagerDuty pages @sre-oncall |
  | 14:34 | @sre-oncall acknowledges |
  | 14:38 | Root cause identified: OOM kills from unbounded payment cache |
  | 14:41 | Rollback initiated: git revert to v2.3.0 |
  | 14:48 | ArgoCD synced, v2.3.0 running, error rate returning to baseline |
  | 15:02 | Error rate at 0.02%, incident resolved |

## 3. Root Cause
  v2.3.1 introduced PaymentCacheManager with no eviction policy.
  Under production load, the cache grew unbounded → heap at 95% → Full GC →
  GC unable to collect cache (strong references) → OOM kill.
  The cache is new code not covered by load tests in staging (k6 duration: 3 min
  — too short to expose a slow-growing memory leak).

## 4. Contributing Factors (not root causes, but made it worse)
  - k6 staging test duration (3 min) too short to detect memory leaks
  - JVM heap alert threshold at 70% fired but was classified as P3 (Slack only)
    A 5-minute delay meant alert fired at 14:25 but escalated at 14:32 via error rate

## 5. Action Items
  | Action | Owner | Priority | Jira | Due |
  |--------|-------|----------|------|-----|
  | Add LRU eviction to PaymentCacheManager (max 10,000 entries) | @backend-dev | P1 | PAY-234 | 2026-08-07 |
  | Extend k6 staging test from 3 min to 20 min (exposes slow leaks) | @sre-team | P2 | SRE-89 | 2026-08-14 |
  | Downgrade JVM heap P3 alert to P2 for production | @sre-team | P2 | SRE-90 | 2026-08-03 |
  | Add memory leak detection to code review checklist | @eng-lead | P3 | ENG-45 | 2026-08-21 |
```

### Postmortem review meeting

```
48 hours after the incident: 45-minute review meeting.

Agenda:
  5 min: Read the postmortem (everyone, in silence, not presented)
  10 min: Timeline walkthrough — any corrections?
  10 min: Root cause discussion — do we agree?
  15 min: Action items — are they specific enough? Do they have owners?
  5 min: What went WELL? (capture this — repeat it)

What WENT WELL is as important as what went wrong:
  "The DT traffic drop alert fired within 2 minutes"
    → We should keep alert_on_no_data = true on all services
  "The runbook for connection pool exhaustion was accurate"
    → Good: runbooks are being maintained

Rules:
  No blame. Names in the timeline describe what happened, not what was wrong.
  "Is this action item specific enough?" If not: make it specific before closing.
  Every action item must have: owner, Jira ticket, due date.
  Action items without owners are wishes, not plans.
```

---

## Pillar 8 — The SRE Weekly Rhythm

### What "proven SRE experience" looks like week-to-week

```
MONDAY — Weekly health review (30 min)
  1. SLO dashboard:
     - Each service: availability %, P99 latency %, error budget remaining
     - Any service < 50% budget? → add Jira ticket this sprint
  2. Alert noise review:
     - How many alert instances fired last week?
     - How many were acknowledged + resolved with no action? (false positives)
     - Any alert firing > 3×? → needs threshold tuning or root cause fix
  3. Open incidents from last week:
     - Were postmortems written for P1/P2?
     - Are action items assigned and dated?

TUESDAY-THURSDAY — Engineering work
  Project work (reliability engineering):
    - Implementing new alerting (adding new service to DT Terraform)
    - Writing runbooks for uncovered alert scenarios
    - Building a capacity planning dashboard
    - Automating toil (replacing manual password rotation with RDS auto-rotation)
    - Improving CI/CD pipeline (adding Trivy scan, improving rollback automation)

  On-call support:
    - Responding to P3/P4 alerts during business hours
    - Helping development teams onboard new services to monitoring
    - Code reviewing changes to Terraform DT config

FRIDAY — Retrospective + planning (30 min)
  1. Review this week's incidents: anything recurring?
  2. Toil tracking: how many hours were manual operations vs engineering work?
  3. Next sprint planning: what reliability work goes into next sprint?

EVERY 6 WEEKS — On-call rotation review
  1. How many pages did each on-call engineer receive?
  2. What was the most disruptive alert? → priority fix
  3. Are runbooks up to date?
  4. Does the schedule need adjustment?

QUARTERLY — Reliability review
  1. SLO target review: are targets still appropriate?
  2. Capacity planning: is current capacity sufficient for next quarter?
  3. Disaster recovery drill: failover test to DR environment
  4. Security review: Trivy findings, IMDS settings, IAM role permissions
```

---

## Pillar 9 — The Four Golden Signals in Practice

```
TRAFFIC — requests per second / requests per minute
  Why it matters: baseline for all other signals. All other metrics lie when traffic = 0.
  DT metric: builtin:service.requestCount.server
  SRE use: "is traffic normal? higher = possible overload. lower = possible silent outage."
  Alert: traffic_min_rps = 10 for payment-service (fires if traffic drops below 10 req/min)

ERRORS — % of requests that fail
  Why it matters: direct measure of user-facing failures
  DT metric: builtin:service.errors.server.rate
  SRE use: "is the error rate increasing? correlate with recent deploy or dependency failure"
  Alert: error_rate_alert = 0.1% for payment-service (0.1% = 1 in 1000 requests failing)

LATENCY — response time distribution (P99, not average)
  Why it matters: user experience. Average hides the worst cases.
  DT metric: builtin:service.response.time:percentile(99)
  SRE use: "P99 rising = something is slower. Distributed trace shows WHERE."
  Alert: latency_p99_ms = 300ms for payment-service

SATURATION — resource pressure (CPU, memory, JVM heap, connections, threads)
  Why it matters: leading indicator — saturation precedes errors and latency
  DT metrics: cpu.usage, memory.usage, jvm.heapUtilization, thread count
  SRE use: "saturation rising = trouble is coming. Fix before users notice."
  Alerts: cpu_saturation_pct = 70%, jvm_heap_pct = 70% for payment-service

SRE PRINCIPLE: always look at all four in sequence.
  Traffic normal, errors 0%, latency normal, but saturation rising:
  → Nothing is broken YET. But it will be.
  → Act now (scale out, investigate memory leak) before users are affected.
```

---

## Pillar 10 — Documentation Culture

```
SRE documentation is OPERATIONAL, not academic.
The test: "Can an on-call engineer follow this document at 3am while half-asleep?"

Required documentation for every production service:

1. RUNBOOK (one per alert)
   Location: Confluence → SRE Space → Runbooks → <service-name>
   Contents: alert description, immediate actions, investigation steps,
             common fixes, escalation path, related links
   Review cycle: every 3 months or after every incident that uses it

2. ARCHITECTURE DECISION RECORD (ADR)
   Location: Confluence → SRE Space → Architecture
   Contents: what was decided, why, alternatives considered, consequences
   When to write: any significant technical decision
   Key ADRs already written: "Why ArgoCD over Flux", "Why per-AZ NAT Gateways",
                              "Why DynaKube classicFullStack not appOnly"

3. POSTMORTEM
   Location: Confluence → SRE Space → Postmortems → YYYY-MM
   Contents: summary, timeline, root cause, contributing factors, action items
   When to write: within 48h of every P1/P2 incident

4. ONBOARDING GUIDE
   Location: Confluence → SRE Space → Onboarding
   Contents: tool access, architecture overview, first 2-week task list, who to ask
   Review cycle: when a new SRE joins (update based on their experience)

5. SLO CATALOG
   Location: Confluence → SRE Space → SLO Dashboard page
   Contents: each service, its SLOs, current status, error budget
   Updates: automated via DT → Confluence integration (or weekly manual review)
```

---

## What "Proven Experience" Looks Like in an Interview

```
When asked "describe your SRE experience", structure the answer:

1. What you MEASURED (SLOs, error budgets, MTTA, MTTR)
   "We defined SLOs for 8 services: 99.9% availability and 300ms P99 latency.
    We tracked error budgets weekly and used burn rate alerts to catch problems early."

2. What you RESPONDED TO (incidents, on-call)
   "I was primary on-call for a 6-person rotation.
    During my rotations I handled 2–3 incidents per week.
    Most significant: a DB connection pool exhaustion that took 22 minutes to resolve.
    The postmortem resulted in 3 action items, all closed within 2 weeks."

3. What you BUILT (tooling, automation, processes)
   "I built the DT Terraform module that configures all 8 metric events, 2 SLOs,
    and notifications for all 3 services × 3 environments.
    I added the auto-rollback logic to the CI pipeline: if production smoke tests fail,
    the pipeline reverts the gitops YAML and ArgoCD rolls back within 3 minutes."

4. What you IMPROVED (before and after)
   "Before: MTTA was 12 minutes average (engineers missed phone calls at night).
    After: I configured redundant notification rules (push + SMS + phone call chain),
    MTTA dropped to 4 minutes."

5. What you LEARNED (from incidents, postmortems)
   "The most valuable lesson from our postmortem practice:
    the root cause of most incidents was a CONFIG CHANGE, not a code bug.
    We now require all config changes to go through the same PR + review + staging gate
    as code changes. Incident rate dropped 60% over 3 months."
```
