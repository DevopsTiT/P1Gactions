# Glossary: JLPT N2 Roadmap

Every term from the roadmap explained for someone new to JLPT study.

---

**JLPT (Japanese Language Proficiency Test)**
日本語能力試験 — the standardized test of Japanese proficiency for non-native speakers. Run by the Japan Foundation twice per year (July and December). Five levels: N5 (easiest) to N1 (hardest). N2 is the second hardest.

**N2**
The second highest JLPT level. Recognized by Japanese universities and many companies as proof of working-level Japanese proficiency. Requires ~6,000 vocabulary words, ~1,000 kanji, and the ability to read newspaper-level Japanese.

**N3**
The middle JLPT level. The recommended entry point before studying for N2. Requires ~3,750 vocabulary and ~600 kanji. If you don't have N3-level Japanese yet, get there first before targeting N2.

**言語知識 (げんごちしき)**
The "Language Knowledge" section of the JLPT. Covers vocabulary, grammar, and reading. Combined time: 105 minutes for N2. Worth 0–120 points of the total 180.

**聴解 (ちょうかい)**
The "Listening" section of the JLPT. Tests comprehension of spoken Japanese. Time: ~50 minutes. Worth 0–60 points of the total 180.

**Subscore requirement**
A JLPT rule that requires you to pass EACH section above a minimum, not just the total. For N2: 言語知識 ≥ 19 points AND 聴解 ≥ 19 points required, even if your total is above 90. Fail one subscore = fail the whole exam.

**SRS (Spaced Repetition System)**
A memorization technique that schedules review of each card at increasing intervals — just before you're about to forget it. Far more efficient than re-reading notes. Anki is the most popular SRS application.

**Anki**
A free, open-source flashcard app that uses SRS. The most widely used tool for JLPT vocabulary and grammar study. Available as a desktop app (free), iOS app (paid), and Android app (free). AnkiWeb hosts shared decks — search "JLPT N2" to find ready-made vocabulary decks.

**AnkiWeb**
The website (ankiweb.net) where Anki users share free flashcard decks. You can download JLPT N2 vocabulary and grammar decks and import them into your Anki app instantly.

**Retention rate (Anki)**
The percentage of cards you answer correctly when they come up for review. Target ≥ 85%. If lower, reduce the number of new cards per day — you're adding more than your brain can absorb.

**新完全マスター (しんかんぜんマスター)**
"Shin Kanzen Master" — a series of JLPT study books widely considered the gold standard. There are separate books for grammar, vocabulary, kanji, reading, and listening for each level. Publisher: 3A Corporation.

**公式問題集 (こうしきもんだいしゅう)**
"Official Practice Test Collection" — the JLPT practice tests published by the exam creators themselves. The most accurate simulation of real exam questions and timing. Essential for Month 5–6 preparation.

**Shadowing**
A listening and speaking practice technique: listen to audio and repeat it simultaneously (not after — at the same time). Trains your brain to process Japanese at natural speed. Improves both listening comprehension and speaking fluency.

**Discourse marker**
A word or phrase that signals the logical relationship between sentences in an argument (e.g., "however," "therefore," "in summary"). In Japanese: しかし (however), したがって (therefore), つまり (in other words). Finding these in reading passages reveals the structure of the argument and often points directly to the answer.

**Short text comprehension (短文理解 たんぶんりかい)**
A JLPT reading question type with ~200 character texts. Read everything, answer directly. No skimming needed — the text is short enough to read fully.

**Medium text comprehension (中文理解 ちゅうぶんりかい)**
A JLPT reading question type with ~500 character texts. Use "question first" method: read the question before the text, then scan for the answer rather than reading every word.

**Long text comprehension (長文理解 ちょうぶんりかい)**
A JLPT reading question type with ~900 character texts. Read the first and last paragraph first (main idea is usually there), then scan for specific details the question asks about.

**Information search (情報検索 じょうほうけんさく)**
A JLPT reading question type using notices, advertisements, or charts. You must find specific information quickly. Do NOT read everything — scan for the relevant field only.

**Integrated comprehension (統合理解 とうごうりかい)**
A JLPT reading or listening question type that presents two texts or two speakers and asks you to compare, contrast, or synthesize them. Find the agreement or disagreement between the two.

**Quick response (即時応答 そくじおうとう)**
A JLPT listening question type. A short statement is made, and you choose the most natural response from three options. No long context — you hear one sentence and must answer immediately. Tests conversational naturalness.

**Task comprehension (課題理解 かだいりかい)**
A JLPT listening question type. A conversation describes a situation, and the question asks: what action will the person take next? Listen for the conclusion/decision.

**On'yomi (音読み)**
The Chinese-derived reading of a kanji. Usually used in compound words (熟語). Example: 決 → けつ (as in 決定 けってい). Most kanji have one or more on'yomi.

**Kun'yomi (訓読み)**
The native Japanese reading of a kanji. Usually used when the kanji appears alone or with hiragana suffixes. Example: 決 → き (as in 決める きめる). 

**Compound word (熟語 じゅくご)**
A word formed by combining two or more kanji. Most N2 vocabulary consists of two-kanji compounds. Learning kanji through their compounds is more useful than memorizing kanji readings in isolation.

**Wanikani**
A paid web app (wanikani.com) that teaches kanji and vocabulary using SRS and mnemonics. Structured into 60 levels. Levels 1–40 cover most N2 kanji. Effective but expensive — free alternatives include Anki + Shin Kanzen Master Kanji.

**Bunpro**
A web app (bunpro.io) that teaches Japanese grammar using SRS. Has a dedicated N2 grammar path. Useful as a supplement to a grammar textbook — reviews patterns automatically so they don't fade.

**NHK Web Easy (NHKウェブやさしい)**
A free website (web.nhk.or.jp/easy) with real Japanese news articles rewritten in simpler Japanese, with furigana (small phonetic reading above kanji) and audio. Excellent for reading + listening practice at N3–N2 level.

**Jisho (辞書)**
The free online Japanese dictionary at jisho.org. Shows JLPT level for each word (N5 through N1), stroke order for kanji, example sentences from Tatoeba, and full conjugation information.

**Furigana**
Small hiragana characters printed above kanji showing the reading. Appears in children's books and NHK Web Easy. JLPT exam texts do NOT have furigana — you must know kanji readings from memory.

**Mock exam (模擬試験 もぎしけん)**
A practice test that simulates real exam conditions: same format, same question types, same timing. Essential for building exam-day stamina and identifying weak areas. Target: ≥ 100/180 on mock exams before the real test.

**2B pencil**
The recommended pencil type for JLPT answer sheets. The exam uses optical mark recognition (bubble sheet scanning) — 2B produces a mark dark enough to be read correctly. HB is acceptable but 2B is safer.

**Admission ticket (受験票 じゅけんひょう)**
The official ticket mailed to you before the exam confirming your registration, exam date, and exam location. Required for entry — without it you cannot sit the exam.

**MTTA / MTTR (for this context: study metrics)**
Time-to-acquire and time-to-retain vocabulary. How quickly you learn a word and how long before you forget it without review. SRS (Anki) optimizes both by showing cards at exactly the right interval.

**Elimination method**
An exam technique: instead of trying to identify the single correct answer, eliminate options that are clearly wrong or not supported by the text. Often leaves 1–2 plausible options, increasing guessing odds to 50% even without certainty.

**Timed practice**
Practicing under exam time constraints. Essential from Month 4 onward. Without time pressure, reading feels easy — but in the real exam, running out of time is the most common cause of failure for prepared students.
