# JLPT N2 — Complete Study Roadmap

---

## First: Assess Where You Are Now

The roadmap length depends entirely on your current level. Be honest.

```
Where are you right now?
  │
  ├─ Passed N3 (or equivalent)           → 6-month roadmap (see below)
  │
  ├─ N3-level but no certificate         → 6-month roadmap
  │
  ├─ N4 level (basic grammar, ~1500 vocab) → 12-month roadmap
  │
  ├─ N5 level or beginner                → 18-24 month roadmap
  │                                         (get N3 first, then come back)
  │
  └─ Native/heritage speaker             → 3-month focused exam prep

This roadmap assumes N3-level entry → 6-month plan.
Adjust the phase lengths if you need more or less time.
```

---

## What N2 Requires (The Targets)

Before planning, know exactly what you're building toward:

```
Vocabulary:   ~6,000 words  (N5: ~800, N4: ~1,500, N3: ~3,750, N2: ~6,000)
Kanji:        ~1,000 kanji  (on top of the ~600 needed for N3)
Grammar:      ~170 grammar patterns (N2-specific)
Reading:      Long articles, editorials, letters, instructions
Listening:    Natural speech, news, conversations without visual aids

Pass threshold:
  Total ≥ 90/180 points
  語知識 subscore ≥ 19 (don't let any section drag you below)
  聴解 subscore ≥ 19
```

---

## The 6-Month Roadmap (Overview)

```
Month 1-2   │ FOUNDATION — Vocabulary + Kanji every day
Month 3     │ GRAMMAR — All N2 grammar patterns + sentence structure
Month 4     │ READING — Long text comprehension strategy
Month 5     │ INTEGRATION — Mix all skills + listening
Month 6     │ EXAM PREP — Mock tests + weak point drilling
```

Daily time commitment:
```
  Minimum:   45 min/day  (possible but slow)
  Recommended: 90 min/day  (covers the plan comfortably)
  Intensive: 2–3 hours/day (can compress to 4 months)
```

---

## Month 1–2 — Foundation: Vocabulary and Kanji

### Why Start Here

Grammar patterns are useless if you don't know the words. Kanji is the bottleneck for reading speed. Build vocabulary and kanji first — everything else accelerates afterward.

### Month 1 Target: Core N2 Vocabulary (first 1,500 words)

```
Daily routine (30 min):
  New cards:   20 new words per day
  Reviews:     SRS review session (Anki or similar)
  
1,500 words ÷ 20/day = 75 days (Month 1–2)

Recommended decks:
  Anki: "JLPT N2 Vocabulary" (search in AnkiWeb)
  Book: 新完全マスター語彙 N2 (Shin Kanzen Master Vocabulary N2)

Card format (each word):
  Front: 決定  (kanji)
  Back:  けってい  /  decision, determination
         Example: 決定を下す（けっていをくだす）= to make a decision
```

### Month 2 Target: N2 Kanji (first 500)

```
Daily routine (20 min):
  New kanji:  10 new kanji per day
  Review:     SRS session
  
500 kanji ÷ 10/day = 50 days

Kanji study method:
  1. Learn the reading (on'yomi, kun'yomi)
  2. Learn 2–3 compound words using that kanji
  3. Write it 3 times by hand (builds visual memory)
  4. Add to Anki for SRS review

Recommended:
  Book: 新完全マスター漢字 N2 (Shin Kanzen Master Kanji N2)
  App:  Wanikani (levels 1–30 cover most N2 kanji)
  
Target N2 kanji examples:
  影響 (えいきょう) — influence
  判断 (はんだん)   — judgment
  現象 (げんしょう) — phenomenon
  改善 (かいぜん)   — improvement
  状況 (じょうきょう) — situation/circumstances
```

### Month 1–2 Daily Schedule (Sample)

```
Morning (30 min):
  10 min — New vocabulary cards (20 words)
  20 min — Anki review (vocabulary + kanji)

Evening (30 min):
  20 min — New kanji (10 kanji + compounds)
  10 min — Review yesterday's kanji

Weekend extra (1 hour):
  Review weak vocab/kanji
  Read 1 short Japanese article (nhk web easy, or news)
  Identify unknown words → add to Anki
```

### Month 1–2 Checkpoints

```
End of Month 1:
  □ 600+ new N2 vocabulary words in Anki
  □ 300+ N2 kanji studied
  □ Anki retention rate ≥ 85% (if lower, reduce new cards/day)

End of Month 2:
  □ 1,500+ N2 vocabulary words in Anki
  □ 500+ N2 kanji studied
  □ Can recognize most kanji in a newspaper headline
  □ Reading simple Japanese sentences without dictionary for most words
```

---

## Month 3 — Grammar: All N2 Patterns

### The N2 Grammar Landscape

N2 has approximately 170 grammar patterns. They fall into categories:

```
Category 1: Formal / Written expressions (~40 patterns)
  〜において / においては      at / in (formal "in")
  〜に関して / に関する        regarding / concerning
  〜に対して / に対する        toward / against
  〜によって / による          by means of / due to
  〜をはじめ（として）         starting with / including
  〜に加えて                   in addition to

Category 2: Conditions and Concessions (~35 patterns)
  〜にもかかわらず             despite / in spite of
  〜としても                   even if / even though
  〜たとしても                 even if (hypothetical)
  〜ばかりに                   just because / simply because
  〜からといって               just because...doesn't mean
  〜ものの                     although / even though

Category 3: Limits and Extents (~25 patterns)
  〜限り（は）                 as long as / while
  〜に限らず                   not only / not limited to
  〜だけあって                 as expected (since/because)
  〜だけに                     precisely because / all the more
  〜というものの               although / while it's true that

Category 4: Expressing State / Result (~30 patterns)
  〜っぱなし                   leaving in a state / still doing
  〜きり                       just / only / since (and not since)
  〜次第                       as soon as / depending on
  〜ついでに                   while doing / taking the opportunity
  〜がてら                     while / on the occasion of

Category 5: Expectation and Obligation (~20 patterns)
  〜はずがない                 there's no way that...
  〜に違いない                 must be / no doubt
  〜べき                       should / ought to
  〜べきではない               should not
  〜わけがない                 there's no way / can't possibly

Category 6: Negative / Partial (~20 patterns)
  〜わけではない               it doesn't mean that
  〜というわけではない         it's not that
  〜ないわけにはいかない        can't help but / have to
  〜ないことはない             it's not that...can't (double negative)
```

### Month 3 Daily Grammar Study Routine

```
Day 1–5 of each week: Learn 5–7 new grammar patterns per day
  For each pattern:
    1. Read the rule (meaning + formation)
    2. Read 3 example sentences
    3. Write 1 sentence of your own
    4. Add to Anki (front: meaning cue, back: pattern + examples)

Day 6–7: Review + practice
  Use JLPT workbook grammar exercises
  Write 5 sentences using patterns from the week

Target: 35 patterns/week × 4 weeks = 140 patterns in Month 3
Remaining 30 patterns: revisit in Month 5

Recommended books:
  新完全マスター文法 N2 (Shin Kanzen Master Grammar N2)  ← the gold standard
  TRY! 日本語能力試験 N2 文法から伸ばす日本語
  
Online resource:
  Jlpt sensei (jlptsensei.com) — free grammar explanations with examples
```

### Grammar Pattern Cards (Anki Format)

```
Front:
  〜にもかかわらず
  Meaning: ___?

Back:
  Despite / In spite of
  Formation: Noun / Na-adj / Verb (plain form) + にもかかわらず
  
  Example 1: 雨にもかかわらず、試合は続いた。
             Despite the rain, the game continued.
  
  Example 2: 努力したにもかかわらず、試験に落ちた。
             Despite making effort, (I) failed the exam.
  
  Nuance: Written/formal. Strong contrast between expected and actual result.
  Compare with: のに (same meaning but casual/conversational)
```

### Month 3 Checkpoints

```
End of Month 3:
  □ 140+ grammar patterns studied
  □ Can identify grammar patterns in reading passages
  □ Can produce sentences using Month 3 grammar patterns
  □ Completed grammar section of one N2 practice test (aim ≥ 60%)
```

---

## Month 4 — Reading: Long Text Strategy

### Why Reading Gets Its Own Month

N2 reading is NOT about vocabulary or grammar alone. It requires:
- **Skimming** — find the main point fast (you have limited time)
- **Scanning** — locate specific information quickly
- **Inference** — understand what is implied, not stated
- **Discourse markers** — follow argument structure (しかし、そのため、つまり)

These are skills, not knowledge. They require practice with timed passages.

### N2 Reading Section Breakdown

```
Question type              │ Length      │ Strategy
───────────────────────────┼─────────────┼─────────────────────────────────
短文理解 (short text)       │ ~200 chars  │ Read all, answer directly
中文理解 (medium text)      │ ~500 chars  │ Read question first, then scan
長文理解 (long text)        │ ~900 chars  │ Read intro + conclusion, then fill
情報検索 (information scan) │ ads/notices │ Scan only — don't read everything
総合理解 (integrated)       │ 2 texts     │ Find the comparison/difference
```

### The "Question First" Method for Medium and Long Texts

```
Step 1: Read the QUESTION first (not the text)
  "この文章の筆者が言いたいことは何か"
  → You now know you're looking for the author's main argument

Step 2: Read only the first paragraph and last paragraph
  First paragraph: sets up the topic
  Last paragraph: usually contains the answer to "what is the author saying"

Step 3: Now scan for specific details the question asks about
  Don't read everything word by word

Step 4: Answer using elimination
  Cross out answers that are clearly wrong or not mentioned
  Among remaining answers, find the one most supported by the text

Why this works:
  N2 reading is timed. Reading every word → not enough time.
  The answer is almost always in the intro, the conclusion, or next to
  a discourse marker (しかし、そのため、つまり、その結果).
```

### Key Discourse Markers (Follow the Argument)

```
Contrast:       しかし / けれども / ところが / 一方（で）/ それに対して
Addition:       また / さらに / そのうえ / おまけに / それだけでなく
Cause/Result:   だから / そのため / したがって / その結果 / よって
Example:        たとえば / 具体的には / とくに
Summary:        つまり / すなわち / 要するに / 言い換えると
Contrast (but): とはいえ / もっとも / ただし / それでも
```

When you see `つまり` or `要するに`, the sentence that follows is almost always the answer to "what is the author saying."

### Month 4 Daily Reading Routine

```
Day 1–4: Timed passage practice (40 min)
  1 medium text + 1 long text
  Time yourself: medium = 8 min max, long = 12 min max
  After: check answers, analyze WHY wrong answers were wrong

Day 5: Vocabulary from passages (20 min)
  Find 10 unknown words from this week's passages
  Add to Anki

Day 6–7: Full section simulation (1 hour)
  Attempt the full reading section of one practice test under timed conditions
  Target: ≥ 65% correct by end of Month 4

Recommended:
  新完全マスター読解 N2 (Shin Kanzen Master Reading N2)
  JLPT official practice workbooks (日本語能力試験公式問題集 N2)
```

### Month 4 Checkpoints

```
End of Month 4:
  □ Consistent ≥ 65% on reading practice sections
  □ Reading 500-char passage in under 8 minutes (timed)
  □ Can identify author's argument without reading every sentence
  □ Know all key discourse markers and their function
```

---

## Month 5 — Integration: All Skills + Listening

### Why Listening Is Saved for Month 5

Listening requires a vocabulary and grammar base to work. Studying listening before you know the words is inefficient — you can't even process what you're hearing.

By Month 5: you have 1,500+ vocabulary, 140+ grammar patterns, and reading practice. Now listening comprehension will grow quickly.

### N2 Listening Section Breakdown

```
Question type                  │ Count │ Strategy
───────────────────────────────┼───────┼──────────────────────────────────────
課題理解 (task comprehension)   │  5q   │ What action will the person take?
ポイント理解 (key point)        │  6q   │ What detail is being asked about?
概要理解 (overview)             │  5q   │ What is the main message/attitude?
即時応答 (quick response)       │ 12q   │ Which response is most natural?
統合理解 (integrated)           │  4q   │ Two speakers — what do they agree on?
```

### Listening Study Method (Month 5)

```
Week 1–2: Shadowing (build ear + mouth)
  Source: NHK Web Easy audio, JLPT listening practice CDs
  Method:
    1. Listen once without looking at transcript
    2. Write down what you understood
    3. Listen again WITH transcript — find what you missed
    4. Shadow: listen and repeat simultaneously (improves processing speed)
  Daily: 20–30 min

Week 3–4: Practice tests (full listening sections, timed)
  Use official JLPT practice books with audio
  Simulate exam conditions: earphones, no pausing
  After: analyze errors — was it vocabulary? Grammar? Speed?
  Daily: 40 min

Recommended audio sources:
  公式問題集 N2 (official JLPT practice set — has real listening audio)
  新完全マスター聴解 N2
  NHK Web Easy (web.nhk.or.jp/easy) — news in simple Japanese, with audio
  
Target by end of Month 5:
  Listening practice section score ≥ 65%
```

### Month 5: Integration Week (Mix Everything)

The final week of Month 5 should be a "full test" week:

```
Take one complete N2 mock exam per day:
  Monday:    Vocabulary section (timed)
  Tuesday:   Grammar section (timed)
  Wednesday: Reading section (timed)
  Thursday:  Listening section (timed)
  Friday:    Full mock exam (all sections, real timing)
  Weekend:   Review all errors from the week

Score targets at end of Month 5:
  Vocabulary:  ≥ 65%
  Grammar:     ≥ 65%
  Reading:     ≥ 70%
  Listening:   ≥ 65%
  Total mock:  ≥ 100/180 (passing is 90; aim above to have buffer)
```

### Month 5 Checkpoints

```
End of Month 5:
  □ Completed at least 3 full mock N2 exams
  □ Total mock score consistently ≥ 100/180
  □ Both subscores ≥ 30 (well above the 19-point minimum)
  □ Identified top 3 weakest areas → these get Month 6 focus
```

---

## Month 6 — Exam Prep: Drilling Weak Points and Mock Tests

### The Month 6 Philosophy

Month 6 is NOT about learning new things. It is about:
1. Drilling your known weak points to near-automaticity
2. Getting comfortable with exam format and timing pressure
3. Reducing test-day anxiety through familiarity

### Week-by-Week Plan

```
Week 1: Weak Point Analysis and Drilling
  From your Month 5 mock results: identify top 3 weakest areas
  
  Common weak areas:
    Vocabulary? → 30 min/day of N2 vocab review (Anki + word lists)
    Grammar?    → re-do grammar section of Shin Kanzen Master
    Reading?    → 2 timed passages/day + discourse marker review
    Listening?  → 30 min/day shadowing + slow-down replay of difficult sections
  
  Schedule:
    Morning (45 min): weak point drilling
    Evening (30 min): Anki review (all decks — don't let cards accumulate)

Week 2: Full Mock Exam × 3
  Take 3 full mock exams this week under real conditions:
    - Real timing (no pausing)
    - Pencil and paper if exam is paper format
    - No phone, no dictionary
  
  After each: review every wrong answer
  Track scores — are they improving?

Week 3: Final Vocabulary and Grammar Sprint
  N2 vocabulary: final review of any cards with < 85% retention
  Grammar: final 30 remaining patterns (from Month 3 backlog)
  
  Daily:
    New grammar: 5 patterns/day × 6 days = 30 patterns done
    Anki: 45 min review
    Reading: 1 passage for fluency (not new material)

Week 4: Rest and Confidence
  DO NOT cram new material in the last week
  This is the week to consolidate, not expand
  
  Schedule:
    Day 1–4: Light review (Anki only, 30 min/day)
    Day 5:   One short mock section (just vocabulary or listening — stay sharp)
    Day 6:   Rest. Light Japanese media (anime, podcast) — listening only, no study
    Day 7:   Exam day (or final rest before exam)
```

### Exam Day Checklist

```
The night before:
  □ Prepare ID, exam admission ticket, pencils (2B recommended), eraser
  □ Know the exam location and travel time (add 20 min buffer)
  □ Sleep ≥ 7 hours — exhaustion hurts listening comprehension most
  □ Do NOT study new material — it creates anxiety, not knowledge

Exam morning:
  □ Light meal (not too heavy — alertness matters)
  □ Arrive 30 min early
  □ Quick scan of grammar notes on the train if needed (5 min max)
  □ Do NOT cram on the way in

During the exam:
  Vocabulary section:
    If you don't know a word → mark your best guess and move on (never skip)
    Time budget: ~3 min per question set

  Grammar section:
    Read the whole sentence before picking grammar
    Eliminate wrong options by formation rules (e.g., if requires a noun before it)

  Reading section:
    Question first method (see Month 4)
    If a passage is confusing → skip to next question, return if time allows
    Leave NO blank answers (guess if unsure)

  Listening section:
    Read the question and options BEFORE the audio plays (during setup time)
    Mark your answer immediately after hearing it — don't second-guess
    If you miss an answer → LET IT GO, focus on the next one
    Never go back — audio doesn't repeat
```

---

## Study Resources — Full Recommended Stack

### Books (Priority Order)

```
1. 新完全マスター 文法 N2    ← grammar (essential)
2. 新完全マスター 語彙 N2    ← vocabulary (essential)
3. 新完全マスター 漢字 N2    ← kanji
4. 新完全マスター 読解 N2    ← reading
5. 新完全マスター 聴解 N2    ← listening
6. 日本語能力試験公式問題集 N2 ← official practice tests (MUST HAVE for Month 5–6)
```

### Apps

```
Anki (free desktop, paid iOS)
  → Build vocabulary and grammar decks
  → Spaced repetition — the most efficient memorization method
  → Use existing JLPT N2 decks from AnkiWeb (search "JLPT N2")

Bunpro (bunpro.io)
  → Grammar SRS system — specifically for Japanese grammar
  → N2 grammar path is well-organized

Wanikani (wanikani.com)
  → Kanji + vocabulary SRS
  → Expensive but extremely effective for kanji
  → Levels 1–40 cover N2 kanji

Jisho (jisho.org)
  → The best Japanese dictionary — also shows JLPT level for each word
```

### Free Online Resources

```
JLPT Sensei:    jlptsensei.com         → grammar explanations + example sentences
NHK Web Easy:   web.nhk.or.jp/easy     → real news, simple Japanese, with audio
Tatoeba:        tatoeba.org            → example sentences for any word
Anki decks:     ankiweb.net            → search "JLPT N2" for free decks
```

---

## The Master Weekly Schedule (Sustainable Pace)

```
       Mon    Tue    Wed    Thu    Fri    Sat    Sun
──────────────────────────────────────────────────────────
6am    Anki   Anki   Anki   Anki   Anki   Anki   Rest
       30m    30m    30m    30m    30m    30m

7pm    Vocab  Gram   Gram   Read   Listen Full   Review
       30m    30m    30m    30m    30m    test   errors
                                          1hr    1hr

Total per week: ~5–6 hours
Total over 6 months: ~130–150 hours

This is the minimum. 90+ min/day = finish more comfortable.
```

---

## Progress Milestones (Paste This On Your Wall)

```
Month 1 end:  600 vocab in Anki, 300 kanji studied
Month 2 end:  1,500 vocab in Anki, 500 kanji studied
Month 3 end:  140 grammar patterns studied, ≥60% on grammar practice
Month 4 end:  Reading consistently ≥65%, passages in time limits
Month 5 end:  Full mock ≥100/180, both subscores ≥30
Month 6 end:  Exam taken. ✓

Exam day target:
  Vocabulary:  ≥70%
  Grammar:     ≥70%
  Reading:     ≥70%
  Listening:   ≥65%
  Total:       ≥120/180 (buffer above the 90-point pass line)
```
