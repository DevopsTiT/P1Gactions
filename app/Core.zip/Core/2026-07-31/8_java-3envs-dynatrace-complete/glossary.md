# Glossary — java-3envs-dynatrace-complete

Every tool, resource type, and concept in this project. One entry per term.

---

**GitHub Actions**
CI/CD automation built into GitHub. YAML files in `.github/workflows/` define jobs that run on events (push, PR, schedule). Each job runs in a fresh cloud VM. Used here for: building Docker images, running tests, promoting images across environments, applying Terraform.

**`on.paths` (GitHub Actions)**
A trigger filter that only runs the workflow when specific files change. `paths: ['services/payment-service/**']` means the workflow is skipped entirely if nothing under that path was touched. Prevents unrelated commits from triggering expensive build pipelines.

**`needs:` (GitHub Actions)**
Creates a sequential dependency between jobs. `needs: test` means "only run this job after test succeeds." If `test` fails, all downstream jobs are skipped automatically.

**`environment: production` (GitHub Actions)**
A named GitHub deployment environment with REQUIRED REVIEWERS configured. When a job has this setting, the pipeline pauses and waits for a human to click Approve in the GitHub UI before running. Used on all production-affecting jobs.

**`[skip ci]`**
A special string in a git commit message that prevents GitHub Actions from triggering workflows for that commit. CI writes updated image tags to gitops YAML files — without this tag, that commit would re-trigger CI, causing an infinite loop.

**`github.sha`**
A GitHub Actions built-in variable containing the 40-character git commit SHA. Used as the Docker image tag — every build gets a unique, traceable, immutable tag. `git show abc1234` shows exactly what code is in that image.

**ECR (Elastic Container Registry)**
AWS's managed Docker image registry. Each environment (dev/staging/production) has its own ECR in a separate AWS account. Images are promoted between accounts by pulling from one ECR and pushing to the next — the same git SHA tag travels through all three, proving the same bits reach production.

**Trivy**
Open-source Docker image vulnerability scanner by Aqua Security. Checks images against CVE databases. `severity: CRITICAL,HIGH` and `exit-code: 1` means: if any CRITICAL or HIGH CVE is found, the CI step fails and the image is never deployed anywhere.

**k6**
Load testing tool. Runs a JavaScript test script with configurable virtual users (VUs) for a duration. `--vus 50 --duration 3m` = 50 concurrent users sending requests for 3 minutes. The script defines error rate and latency thresholds — k6 exits non-zero if they're violated, failing CI.

**Auto-rollback**
Logic in `verify-production`: if production smoke tests fail after a deploy, a script reads the previous image tag from `git log`, reverts the gitops YAML to that tag, commits, and pushes. ArgoCD detects the revert and redeploys the old version within ~3 minutes.

**Terraform**
Infrastructure-as-Code tool. Reads `.tf` files and creates/modifies/destroys cloud resources (AWS, Dynatrace) via their APIs. State is stored in S3 to allow team collaboration. `terraform plan` shows what would change; `terraform apply` makes it real.

**Terraform module**
A reusable directory of `.tf` files called multiple times with different inputs. `terraform/modules/dynatrace/` is called once for dev, once for staging, once for production — same logic, different threshold values. Fix the module once → all 3 environments get the fix.

**`for_each = {}`**
When `for_each` receives an empty map, Terraform creates zero resources of that type. Used to skip PagerDuty resources in dev (passing `pagerduty_integration_keys = {}`). No `if` statements needed — the empty data eliminates the resources.

**Drift detection**
A daily scheduled CI job (`cron: '0 17 * * *'` = 02:00 JST) that runs `terraform plan -refresh-only -detailed-exitcode`. Exit code 2 = real AWS state differs from Terraform state (someone made a manual change). Creates a GitHub Issue automatically with the full diff.

**`plan -refresh-only`**
Terraform flag that only checks what changed in real AWS vs. what Terraform expects — without planning any config changes. Used for drift detection: shows "someone changed the node group size manually" without also planning "apply my .tf file changes."

**`plan -detailed-exitcode`**
Terraform flag that changes exit codes: 0 = success/no changes, 1 = error, 2 = success/changes pending. Required for drift detection — a normal plan returns 0 even when changes exist; `-detailed-exitcode` distinguishes "no drift" (0) from "drift found" (2).

**ArgoCD**
A Kubernetes GitOps controller. Watches a Git repository path and automatically applies any Kubernetes YAML it finds, keeping the cluster in sync with Git. `selfHeal: true` reverts manual `kubectl` changes within ~3 minutes.

**ArgoCD Application**
A Kubernetes custom resource (kind: Application) that defines: which Git repo/path to watch, which Kubernetes cluster/namespace to deploy to, and sync policy (auto/manual, prune, selfHeal). One Application per service per environment.

**App of Apps pattern**
A single root ArgoCD Application that watches a folder containing other Application YAMLs. `root-app-dev.yaml` is applied once manually; ArgoCD then discovers and manages everything in `gitops/dev/` recursively. Only one manual step needed to bootstrap an entire environment.

**sync-wave**
An ArgoCD annotation (`argocd.argoproj.io/sync-wave: "3"`) that controls deployment order. Lower numbers deploy first. Wave -1 (namespaces) → wave 1 (networking) → wave 2 (secrets) → wave 3 (monitoring) → wave 8 (apps). Within a wave, all resources deploy in parallel.

**`prune: true` (ArgoCD)**
Tells ArgoCD to delete Kubernetes resources when their YAML is removed from Git. Without this, deleted YAMLs leave orphaned pods, services, and secrets running indefinitely.

**`selfHeal: true` (ArgoCD)**
Tells ArgoCD to revert manual `kubectl edit` / `kubectl patch` changes back to what Git says within ~3 minutes. Git is the single source of truth. Manual changes don't stick.

**`ignoreDifferences` (ArgoCD)**
Tells ArgoCD to ignore specific fields when comparing cluster state to Git. Used for `spec.replicas` — HPA continuously changes replica count. Without this, ArgoCD fights HPA in an infinite loop (ArgoCD sets 3, HPA sets 7, ArgoCD reverts to 3, repeat).

**Helm**
Package manager for Kubernetes. A "chart" is a folder of Go templates + `values.yaml`. Helm renders the templates into actual Kubernetes YAML by substituting values. ArgoCD uses Helm to deploy services with per-environment overrides.

**`values.yaml` (Helm)**
The base (production) values file. Contains the strictest, production-grade defaults: 3 replicas, largest resources, WARN log level, hard topology spread, PDB enabled. All environments start from this base.

**`values-dev.yaml` / `values-staging.yaml`**
Environment override files. Only contain fields that differ from production. Dev: 1 replica, small resources, DEBUG logs, jdwp debug port, no PDB. Staging: 2 replicas, medium resources, INFO logs. Helm merges them: last file wins for each key.

**Helm `commonLabels`**
A map of labels rendered onto both the Deployment metadata AND pod spec template. Pod-level labels are what Dynatrace OneAgent reads for auto-tagging → management zone filtering. Both places get the same labels via `{{- range $k, $v := .Values.commonLabels }}`.

**ExternalSecret**
A Kubernetes custom resource (ESO) that reads a value from AWS Secrets Manager and creates a Kubernetes Secret. `refreshInterval: 1h` means rotated credentials are picked up within 1 hour — no pod restart needed. `creationPolicy: Owner` auto-deletes the K8s Secret when the ExternalSecret is deleted.

**ClusterSecretStore**
An ESO resource that defines the connection to AWS Secrets Manager (region, auth method). Cluster-scoped — works for ExternalSecrets in any namespace. All services reference it by name (`aws-secrets-manager`).

**ESO (External Secrets Operator)**
A Kubernetes controller that processes ExternalSecret resources and creates K8s Secrets by fetching from external secret backends (AWS Secrets Manager, Vault, etc.). Without ESO running, ExternalSecret CRDs are just inert YAML.

**IRSA (IAM Roles for Service Accounts)**
Mechanism to give Kubernetes pods AWS IAM permissions without storing credentials. A ServiceAccount is annotated with an IAM role ARN. When the pod starts, the AWS SDK automatically gets temporary STS credentials. No AWS keys ever stored in Kubernetes or Git.

**DynaKube**
A Kubernetes custom resource defined by the Dynatrace Operator. Configures how Dynatrace is deployed in the cluster: OneAgent DaemonSet mode, ActiveGate replicas, log monitoring, capabilities. One DynaKube per cluster.

**OneAgent (Dynatrace)**
Dynatrace's monitoring agent deployed as a DaemonSet (one pod per node). Hooks into every JVM process via JVMTI to auto-instrument Spring Boot apps — captures HTTP request counts, DB query times, JVM heap, GC pauses — with zero code changes required.

**ActiveGate (Dynatrace)**
A Dynatrace proxy/gateway that runs as a Deployment. OneAgent pods send data to ActiveGate (one connection per cluster), which batches and forwards to the DT tenant. Also handles: Kubernetes API monitoring, log analytics, synthetic routing. Dev: 1 replica. Production: 2 replicas spread across AZs.

**Dynatrace management zone**
A filter in Dynatrace that scopes the UI and alerts to specific entities. `payments-production` zone shows only services tagged `team:payments AND environment:production`. Each team sees only their own data. Driven by namespace labels → OneAgent auto-tagging → zone rules.

**Dynatrace alerting profile**
Maps a problem severity to a notification channel with an optional delay. `AVAILABILITY, 0 min → PagerDuty (production only)`. `ERROR, 2 min → PagerDuty (staging+prod)`. `SLOWDOWN, 5 min → Slack`. `RESOURCE_CONTENTION, 15 min → Slack #monitoring`.

**Dynatrace metric event**
Configuration that fires an alert when a metric crosses a threshold for N consecutive minutes. This project creates 8 per service: traffic drop, error rate, latency P99, CPU, memory, JVM heap, pod restarts, network errors.

**`alert_on_no_data = true`**
Metric event setting that fires even when Dynatrace receives ZERO data points (not just when a value is wrong). Used only on the traffic drop signal — catches silent outages where the service is so broken it can't even send metrics.

**Latency P99**
The response time value that 99% of requests are faster than. If P99 = 300ms: 99 out of 100 requests finish under 300ms. The slowest 1% may be slower. P99 reflects the worst experience most users have, while average hides slow outliers.

**µs (microseconds)**
Dynatrace stores latency internally in microseconds. 1ms = 1000µs. The module multiplies all `latency_p99_ms` values by 1000 (`threshold = each.value.latency_p99_ms * 1000`) so human-readable millisecond values are used in the config while DT gets the correct unit.

**SLO (Service Level Objective)**
A target like "99.9% of requests must succeed" measured over a rolling 30-day window. Dynatrace tracks compliance and the error budget (how much failure is allowed before the target is missed). Burn rate alerts fire when the budget is depleting too fast.

**Error budget**
The total allowed failures in a period while still meeting the SLO. For 99.9% availability: 0.1% of requests can fail. Burn rate alerts fire at 14.4× (budget exhausted in ~2 days) and 3.0× (exhausted in ~10 days).

**HTTP Synthetic monitor (Dynatrace)**
An active health check run from Dynatrace's external monitoring nodes (Tokyo, Singapore) every 5 minutes. Validates HTTP 2xx status AND body contains `"status":"UP"` (Spring Actuator format). Catches "200 but DOWN" — HTTP success with a broken app underneath.

**JIT (Just-In-Time compiler)**
Java's mechanism that compiles hot methods to optimized native code at runtime. Cold JVM: slow interpreted bytecode. After ~60 seconds of traffic: fast compiled code. This is why dev latency thresholds (2000ms) are 5-7× higher than production (300ms) — JIT needs time to warm up.

**G1GC**
Java's Garbage First garbage collector (`-XX:+UseG1GC`). Designed for low latency — runs GC incrementally across small heap regions. Pause times increase non-linearly above ~70% heap utilization, which is why production `jvm_heap_pct = 70` alerts before users feel GC impact.

**`-XX:+UseContainerSupport`**
JVM flag that reads cgroup memory limits (the container's limit) instead of host RAM. Without it: JVM on a 64GB host sees 64GB, sets heap to 48GB, immediately exceeds the 1Gi container limit → pod is OOMKilled instantly.

**`-Xms` / `-Xmx`**
JVM heap size flags. `-Xms` = initial heap (pre-allocated). `-Xmx` = maximum heap. Setting Xms close to Xmx prevents heap expansion overhead during startup (multiple GC cycles to grow from tiny to large heap → latency spikes). Dev: Xms128m/Xmx256m. Prod: Xms512m/Xmx1024m.

**jdwp (Java Debug Wire Protocol)**
JVM feature that opens a TCP port for a remote debugger. `address=*:5005` in dev values only. `suspend=n` is critical — without it, the JVM waits forever for a debugger to connect before running any code → pod never passes startupProbe → CrashLoopBackOff.

**startupProbe**
Kubernetes probe that only runs during pod startup. If it keeps failing past the threshold, K8s kills and restarts the pod. Dev uses `failureThreshold: 120` (20 min) because t3.medium + cold Docker cache can take 3-5 min just to pull the image. Production uses 60 (10 min) — faster hardware.

**readinessProbe**
Kubernetes probe that runs continuously. If it fails, K8s removes the pod from Service endpoints — no traffic is routed to it. The pod is NOT restarted. Checks `/actuator/health/readiness`. If the DB is down, pods report not-ready → ALB stops routing to them.

**livenessProbe**
Kubernetes probe that runs continuously. If it fails repeatedly, K8s kills and restarts the container. Checks `/actuator/health/liveness`. Only kills truly stuck/deadlocked processes — configured with a higher threshold than readiness.

**preStop lifecycle hook**
A command run inside the container before K8s sends SIGTERM. `sleep 15` gives the ALB time to deregister the pod from its target group before the app starts shutting down. Without it, the ALB may still route requests to the pod for a few seconds after SIGTERM → connection resets.

**Graceful shutdown (Spring Boot)**
`server.shutdown: graceful` makes Spring stop accepting new requests on SIGTERM but wait up to 30 seconds for in-flight requests to complete before exiting. Combined with preStop sleep 15: ALB deregisters → in-flight requests complete → container exits cleanly. No dropped requests.

**PDB (PodDisruptionBudget)**
Kubernetes resource that limits how many pods can be disrupted simultaneously. `minAvailable: 2` with 3 replicas = at most 1 pod evicted at once during node drains or Karpenter consolidation. Without PDB: all 3 pods could be evicted simultaneously → outage.

**HPA (HorizontalPodAutoscaler)**
Automatically scales pod count based on CPU and memory. Slow scale-down (`stabilizationWindowSeconds: 300`) prevents oscillation during traffic spikes. `ignoreDifferences` in ArgoCD prevents ArgoCD from reverting HPA-managed replica counts back to the Git value.

**topologySpreadConstraints**
Spreads pods across AZs. `whenUnsatisfiable: DoNotSchedule` (production) = hard requirement, pod stays Pending rather than schedule in the wrong zone. `ScheduleAnyway` (dev/staging) = best-effort, schedules even if zones are unbalanced. Dev clusters may have fewer nodes than AZs.

**`readOnlyRootFilesystem: true`**
Container security setting. The container filesystem is read-only — no process can write to it. Prevents malware from writing backdoors or modifying config files. The `/tmp` emptyDir volume is an explicit exception for JVM heap dumps.

**`capabilities.drop: [ALL]`**
Removes all Linux capabilities from the container process. No raw sockets, no kernel parameter modification, no privilege escalation. Most Spring Boot apps need none of these. Dropping all eliminates an entire attack surface class.

**Pod Security Standards (restricted)**
Kubernetes built-in policy enforced via namespace label `pod-security.kubernetes.io/enforce: restricted`. Blocks pods that run as root, use host networking, or request extra capabilities. The Deployment security context settings satisfy this policy — remove them and the pod is rejected at admission.

**NAT Gateway**
AWS component that lets private subnet resources (EKS pods) make outbound internet connections while remaining unreachable from the internet. One NAT per AZ (`one_nat_gateway_per_az = true`) means an AZ failure doesn't cut outbound internet for pods in other AZs.

**S3 VPC Gateway Endpoint**
Free AWS feature that routes S3 traffic through AWS's internal network instead of NAT Gateway. Since ECR stores Docker layers in S3, image pulls don't incur NAT data processing charges. Significant cost saving at scale.

**IMDSv2 (`http_tokens = required`)**
Requires a session token to query EC2 instance metadata (which includes IAM credentials). Without it, any process inside a pod can call `http://169.254.169.254` to steal the node's IAM role credentials. `http_put_response_hop_limit = 2` allows pods to use IRSA through one network hop.

**KMS encryption (`cluster_encryption_config`)**
Encrypts Kubernetes Secrets at rest in etcd using an AWS KMS key. Without this, Kubernetes Secrets are base64-encoded (not encrypted) in etcd — readable by anyone with etcd access.

**ExternalDNS**
Kubernetes controller that watches Ingress resources and automatically creates Route53 DNS records. `domainFilters: [dev.company.com]` restricts it to only modify records within that domain — prevents dev ExternalDNS from overwriting production DNS. `txtOwnerId` prevents cross-cluster DNS deletion.

**`policy: sync` (ExternalDNS)**
ExternalDNS both creates DNS records when Ingresses are added AND deletes them when Ingresses are removed. Safe because of `domainFilters` — it only manages records in its own domain.

**`SQS DLQ (Dead Letter Queue)`**
An SQS queue that receives messages that failed to process after N retries. notification-service smoke test checks `ApproximateNumberOfMessages = 0` on the DLQ. A non-zero DLQ means notification processing is failing silently — something is broken in the async pipeline.

**`fetch-depth: 0` (actions/checkout)**
Fetches the full git history (default is shallow/1 commit). Required for the auto-rollback script — it uses `git log` to find the previous image tag, which needs history going back at least 2 commits on the gitops file.
