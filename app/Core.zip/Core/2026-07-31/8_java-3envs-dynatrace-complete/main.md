# java-3envs-dynatrace — Complete Project

> 3 Java Spring Boot services × 3 AWS environments (dev/staging/production) with GitOps, Dynatrace observability, and full CI/CD. This is the standalone copy of the complete project — every file is here and ready to use.

---

## File Tree (82 files total)

```
java-3envs-dynatrace-complete/
│
├── .github/workflows/                              ← 8 CI/CD pipelines
│   ├── terraform-infra.yaml                        ← EKS+VPC: matrix plan, sequential apply, daily drift detection
│   ├── terraform-dynatrace-dev.yaml                ← DT config CI: plan on PR, apply on merge
│   ├── terraform-dynatrace-staging.yaml
│   ├── terraform-dynatrace-production.yaml         ← + manual approval gate
│   ├── payment-service-ci.yaml                     ← test→build→dev→smoke→staging→k6→prod→verify+rollback
│   ├── order-service-ci.yaml                       ← same pattern, order API
│   └── notification-service-ci.yaml                ← same pattern, async SQS/DLQ smoke test
│
├── terraform/
│   ├── modules/
│   │   ├── dynatrace/
│   │   │   ├── main.tf      ← THE MODULE: all DT resources (zones, alerts, SLOs, synthetics, notifications)
│   │   │   └── variables.tf ← all threshold variables with types enforced
│   │   ├── eks/
│   │   │   ├── main.tf      ← EKS cluster, private endpoint, system nodegroup, add-ons
│   │   │   └── variables.tf
│   │   └── vpc/
│   │       ├── main.tf      ← 3-AZ VPC, one NAT/AZ, S3 VPC endpoint
│   │       └── variables.tf
│   └── environments/
│       ├── dev/main.tf         ← calls dynatrace module, RELAXED thresholds, no PagerDuty
│       ├── staging/main.tf     ← MEDIUM thresholds, PagerDuty HIGH, 2 synth locations
│       └── production/main.tf  ← STRICT thresholds, PagerDuty CRITICAL+HIGH, 2 synth locations
│
├── gitops/
│   ├── dev/
│   │   ├── bootstrap/root-app-dev.yaml                    ← apply once → ArgoCD manages gitops/dev/
│   │   ├── namespaces/namespaces.yaml                     ← wave -1: namespaces + DT auto-tag labels
│   │   ├── networking/aws-load-balancer-controller.yaml   ← wave  1: ALB controller (1 replica)
│   │   ├── networking/external-dns.yaml                   ← wave  1: ExternalDNS, dev.company.com only
│   │   ├── secrets/cluster-secret-store.yaml              ← wave  2: ESO + ClusterSecretStore
│   │   ├── monitoring/dynatrace/dynatrace-operator.yaml   ← wave  3: DT Operator + DynaKube (1 ActiveGate)
│   │   ├── app/payment-service/payment-service.yaml       ← wave  8: ArgoCD Application (values+values-dev)
│   │   ├── app/order-service/order-service.yaml
│   │   └── app/notification-service/notification-service.yaml
│   ├── staging/  (same structure, staging account IDs, 2 ALB replicas, staging.company.com DNS)
│   └── production/ (same structure, prod account IDs, 2 ActiveGate HA replicas, company.com DNS)
│
├── charts/
│   ├── namespaces/
│   │   ├── Chart.yaml
│   │   ├── values.yaml
│   │   └── templates/namespace.yaml        ← loops over list, creates NS with labels
│   ├── payment-service/
│   │   ├── Chart.yaml
│   │   ├── values.yaml                     ← PRODUCTION: 3 replicas, Xmx 1024m, WARN logs
│   │   ├── values-dev.yaml                 ← DEV: 1 replica, Xmx 256m, DEBUG, jdwp:5005
│   │   ├── values-staging.yaml             ← STAGING: 2 replicas, Xmx 512m, INFO
│   │   └── templates/
│   │       ├── deployment.yaml             ← RollingUpdate, security contexts, probes, preStop
│   │       ├── external-secret.yaml        ← env-scoped DB creds from Secrets Manager
│   │       ├── hpa.yaml                    ← CPU+memory autoscaling, slow scale-down
│   │       ├── pdb.yaml                    ← conditional on pdb.enabled
│   │       ├── ingress.yaml                ← ALB annotations, HTTPS redirect
│   │       ├── service.yaml                ← ClusterIP
│   │       └── serviceaccount.yaml         ← IRSA annotation
│   ├── order-service/    (same 3-values + 7-template structure)
│   └── notification-service/ (same, but external-secret.yaml syncs SMTP+SNS, not DB creds)
│
└── services/
    ├── payment-service/Dockerfile   ← 2-stage: builder(JDK) → runtime(JRE), $JVM_OPTS entrypoint
    ├── order-service/Dockerfile     ← same
    └── notification-service/Dockerfile ← same
```

---

## ArgoCD Sync Wave Order

```
wave -1  namespaces/        → payment-ns, order-ns, notification-ns, dynatrace, external-secrets
          labels: team=X, environment=Y  → Dynatrace OneAgent reads these for auto-tagging

wave  1  networking/        → ALB controller (Ingress → ALB), ExternalDNS (Ingress → Route53)

wave  2  secrets/           → ESO (External Secrets Operator) + ClusterSecretStore
                              → can now read from AWS Secrets Manager via IRSA

wave  3  monitoring/        → DT Operator + ExternalSecret (DT tokens) + DynaKube
                              → OneAgent DaemonSet starts on every node
                              → ActiveGate routes metrics/traces to DT tenant

wave  8  app/               → payment-service, order-service, notification-service
                              → pods get team= and environment= labels → DT management zones
```

---

## CI/CD Flow (push to main → production)

```
1. Code push → payment-service-ci.yaml triggers
   job 1: ./gradlew test jacocoTestReport jacocoTestCoverageVerification (≥70% line coverage)
   job 2: docker buildx (amd64+arm64) → push to dev ECR → Trivy scan (CRITICAL/HIGH fail)
          sed image tag → gitops/dev/ → git commit [skip ci] → kubectl rollout status 8m
   job 3: smoke test dev (health + POST /api/v1/payments asserts status="created")
   job 4: cross-account promote dev→staging ECR → gitops/staging/ update → rollout 10m
   job 5: k6 load test staging (50 VUs, 3 min)
   job 6: MANUAL APPROVAL (environment: production gate) → promote staging→prod ECR
          gitops/production/ update → rollout 12m
   job 7: sleep 60 → smoke test prod → if fail: git log finds prev tag → rollback commit

2. ArgoCD (each cluster) detects gitops commit → re-renders Helm → rolling update
   maxUnavailable: 0 = zero downtime at every step
```

---

## Per-Environment Quick Reference

### Dynatrace thresholds

| Signal | Dev | Staging | Production (payment) |
|---|---|---|---|
| SLO | 90% | 95% | 99.9% |
| Traffic min | 0 (off) | 2 req/min | 10 req/min |
| Error rate | 10% | 1% | 0.1% |
| Latency P99 | 2000ms | 800ms | 300ms |
| JVM heap | 85% | 78% | 70% |
| Pod restarts | 5 | 3 | 2 |
| PagerDuty | none | HIGH only | CRITICAL+HIGH |
| Synthetics | Tokyo only | Tokyo+Singapore | Tokyo+Singapore |

### Helm values (payment-service)

| Setting | Dev | Staging | Production |
|---|---|---|---|
| Replicas | 1 | 2 | 3 |
| Xmx | 256m | 512m | 1024m |
| Memory limit | 512Mi | 768Mi | 1Gi |
| PDB | disabled | minAvailable:1 | minAvailable:2 |
| HPA max | 3 | 8 | 20 |
| LOG_LEVEL | DEBUG | INFO | WARN |
| pullPolicy | Always | IfNotPresent | IfNotPresent |
| jdwp debug | :5005 | no | no |
| topologySpread | ScheduleAnyway | ScheduleAnyway | DoNotSchedule |

---

## Bootstrap Commands (one-time per environment)

```bash
# 1. Apply Terraform infra (EKS + VPC + IRSA)
cd terraform/environments/dev && terraform init && terraform apply

# 2. Connect kubectl
aws eks update-kubeconfig --name company-dev --region ap-northeast-1

# 3. Install ArgoCD
kubectl create namespace argocd
kubectl apply -n argocd \
  -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
kubectl wait --for=condition=available deployment/argocd-server -n argocd --timeout=300s

# 4. Bootstrap — ArgoCD manages everything else
kubectl apply -f gitops/dev/bootstrap/root-app-dev.yaml

# 5. Apply Dynatrace Terraform (creates DT management zones, alerts, SLOs, synthetics)
terraform apply   # (same directory, module "dynatrace" block runs)

# Repeat steps 1-5 for staging (company-staging, 123456789011)
# and production  (company-prod, 123456789012)
```
