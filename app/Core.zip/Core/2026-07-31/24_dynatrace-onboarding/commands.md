# Dynatrace Onboarding — Commands Reference

---

## Phase 0 — Pre-flight Checks

```bash
# Test outbound HTTPS to Dynatrace from the host
curl -v https://<ENV_ID>.live.dynatrace.com/api/v1/time \
  -H "Authorization: Api-Token <API_TOKEN>"
# Expect: HTTP 200 with a timestamp

# Check available disk space (need 200MB+)
df -h /opt

# Check available RAM (need 512MB+ free)
free -m

# Confirm you are root or can sudo
id
# uid=0(root) or verify sudo access
```

---

## Phase 1 — OneAgent Install (Linux VM)

```bash
# Download installer using PaaS token
curl -o oneagent-installer.sh \
  "https://<ENV_ID>.live.dynatrace.com/api/v1/deployment/installer/agent/unix/default/latest" \
  -H "Authorization: Api-Token <PAAS_TOKEN>"

# Make executable
chmod +x oneagent-installer.sh

# Install with host group (always set this)
sudo ./oneagent-installer.sh --set-host-group=production-payments

# Install routing through ActiveGate (if no direct internet)
sudo ./oneagent-installer.sh \
  --set-server=https://<ACTIVEGATE_HOST>:9999 \
  --set-tenant=<ENV_ID> \
  --set-tenant-token=<PAAS_TOKEN> \
  --set-host-group=restricted-zone

# Verify service is running
systemctl status oneagent

# Tail the log to watch startup
tail -f /opt/dynatrace/oneagent/log/oneagent.log
```

---

## Phase 2 — Post-Install Agent Checks

```bash
# Confirm which server the agent is connected to
/opt/dynatrace/oneagent/agent/tools/oneagentctl --get-server

# Confirm host group
/opt/dynatrace/oneagent/agent/tools/oneagentctl --get-host-group

# Confirm agent version
/opt/dynatrace/oneagent/agent/tools/oneagentctl --version

# Change host group without reinstalling
sudo /opt/dynatrace/oneagent/agent/tools/oneagentctl \
  --set-host-group=new-group-name
sudo systemctl restart oneagent
```

---

## Phase 3 — Kubernetes Onboarding

```bash
# Add Helm repo
helm repo add dynatrace \
  https://raw.githubusercontent.com/Dynatrace/dynatrace-operator/main/config/helm/repos/stable
helm repo update

# Create namespace
kubectl create namespace dynatrace

# Create secret (API token + data ingest token)
kubectl create secret generic dynakube \
  --namespace=dynatrace \
  --from-literal="apiToken=<API_TOKEN>" \
  --from-literal="dataIngestToken=<DATA_INGEST_TOKEN>"

# Install Operator
helm install dynatrace-operator dynatrace/dynatrace-operator \
  --namespace dynatrace \
  --atomic

# Apply DynaKube resource
kubectl apply -f dynakube.yaml

# Watch pods come up
kubectl get pods -n dynatrace --watch

# Check DaemonSet (one pod per node expected)
kubectl get daemonset -n dynatrace

# Describe DynaKube for status / error messages
kubectl describe dynakube dynakube -n dynatrace

# Enable injection on a namespace (required for code-level tracing)
kubectl label namespace my-app-namespace dynatrace.com/inject=true

# Verify injection label on namespace
kubectl get namespace my-app-namespace --show-labels

# Restart pods to pick up injection (if already running)
kubectl rollout restart deployment/<my-app> -n my-app-namespace
```

---

## Phase 4 — ActiveGate Install

```bash
# Download ActiveGate installer from UI:
# Settings → Deployment → ActiveGate → Linux
# Then:
chmod +x activegate-installer.sh
sudo ./activegate-installer.sh

# Verify service
systemctl status dynatracegateway

# Check ActiveGate log
tail -f /var/log/dynatrace/gateway/dynatracegateway.log

# Test connectivity from a restricted host through ActiveGate
curl -v https://<ACTIVEGATE_IP>:9999/communication \
  -H "Authorization: Api-Token <PAAS_TOKEN>"
```

---

## Phase 5 — Tagging via API

```bash
# Tag a specific host entity
curl -X POST \
  "https://<ENV_ID>.live.dynatrace.com/api/v1/entity/infrastructure/hosts/<HOST_ID>/tags" \
  -H "Authorization: Api-Token <API_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"tags": [{"key": "team", "value": "payments"}, {"key": "env", "value": "production"}]}'

# List all hosts (get HOST_ID from here)
curl -s \
  "https://<ENV_ID>.live.dynatrace.com/api/v1/entity/infrastructure/hosts" \
  -H "Authorization: Api-Token <API_TOKEN>" | jq '.[].entityId, .[].displayName'

# Tag a service entity
curl -X POST \
  "https://<ENV_ID>.live.dynatrace.com/api/v2/tags?entitySelector=type(SERVICE),tag(team:payments)" \
  -H "Authorization: Api-Token <API_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"tags": [{"key": "slo-enabled", "value": "true"}]}'
```

---

## Phase 6 — Log Ingestion via API

```bash
# Send a single log event (no agent)
curl -X POST \
  "https://<ENV_ID>.live.dynatrace.com/api/v2/logs/ingest" \
  -H "Authorization: Api-Token <LOG_INGEST_TOKEN>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{
    "content": "ERROR: payment timeout for order 12345",
    "log.source": "/var/log/payments/app.log",
    "severity": "ERROR",
    "timestamp": "2026-07-31T10:00:00.000Z"
  }'
```

---

## Phase 7 — Post-Onboarding Validation

```bash
# Confirm agent is alive and connected
systemctl status oneagent
/opt/dynatrace/oneagent/agent/tools/oneagentctl --get-server

# Check how many processes the agent sees
/opt/dynatrace/oneagent/agent/tools/oneagentctl --get-monitored-processes 2>/dev/null \
  || grep -i "process" /opt/dynatrace/oneagent/log/oneagent.log | tail -20

# Check agent errors
grep -i "error\|warn\|fail" /opt/dynatrace/oneagent/log/oneagent.log | tail -30

# For K8s: confirm all nodes have an agent pod
kubectl get pods -n dynatrace -o wide
# Each node should have one oneagent-* pod in Running state

# For K8s: check injection worked in a pod
kubectl exec -n my-app-namespace <pod-name> -- \
  ls /opt/dynatrace/oneagent/ 2>/dev/null && echo "INJECTED" || echo "NOT INJECTED"
```
