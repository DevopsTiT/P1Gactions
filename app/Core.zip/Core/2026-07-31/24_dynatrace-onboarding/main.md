# Onboarding Servers & Applications into Dynatrace — SRE Deep Dive

---

## E2E Flow Summary

```
[Target host/app exists]
        │
        ▼
[Choose injection method] ─── Host? ──► OneAgent installer (infra + full-stack)
        │                  ─── Container/K8s? ──► DaemonSet / Operator
        │                  ─── Legacy/restricted? ──► ActiveGate + remote monitoring
        │                  ─── Logs/metrics only? ──► API ingestion / OTel
        ▼
[Install & configure agent]
        │
        ▼
[Agent phones home to Dynatrace cluster]
        │
        ▼
[Auto-discovery kicks in: processes, services, JVMs, DB calls]
        │
        ▼
[Tag / group entities via host groups, management zones, process group rules]
        │
        ▼
[Validate: host alive, services visible, traces flowing]
        │
        ▼
[Apply alerting, SLOs, dashboards for the new entity]
```

---

## Decision Tree — Which Onboarding Path?

```
Is the target a bare-metal or VM host?
  YES ──► Install OneAgent directly on OS
  NO  ──► Is it Kubernetes / OpenShift?
            YES ──► Use Dynatrace Operator (Helm or kubectl)
            NO  ──► Is it a Docker host (non-K8s)?
                      YES ──► OneAgent on Docker host  OR  container injection
                      NO  ──► Is it a SaaS/remote app you cannot install agents on?
                                YES ──► Synthetic monitors + API log ingestion
                                NO  ──► ActiveGate (PaaS, IBM MQ, SAP, etc.)
```

---

## Tool Map

| Tool / Component           | What it does in onboarding              |
|----------------------------|-----------------------------------------|
| OneAgent                   | Runs on host, auto-instruments everything |
| Dynatrace Operator         | Manages OneAgent DaemonSet on K8s       |
| ActiveGate                 | Proxy/gateway for restricted networks & extensions |
| Host Group                 | Logical grouping of hosts for rules     |
| Management Zone            | Visibility/permission scope by team     |
| Process Group Detection    | Rules to rename/merge/split process groups |
| Tagging Rules              | Auto-apply labels from env vars / host properties |
| Dynatrace API (metrics ingestion) | Push custom metrics / logs when agent is not possible |

---

## Part 1 — Concepts Before You Touch Anything

### 1.1 What Dynatrace Needs to "See" a Host

Dynatrace needs ONE of:
- **OneAgent** running on the OS (most powerful — full-stack, code-level tracing)
- **ActiveGate** pointing at the host (limited — infrastructure only, no code tracing)
- **API push** (metrics/logs you ship manually — no auto-discovery)

OneAgent is the gold standard. Everything else is a fallback.

### 1.2 Entity Model — What Gets Created After Onboarding

When OneAgent starts, Dynatrace auto-creates these entities in the UI:

```
HOST  (server itself — CPU, disk, network)
  └── PROCESS GROUP INSTANCE  (e.g. "nginx:8080 on host-A")
        └── SERVICE  (logical grouping of process groups doing the same job)
              └── SERVICE INSTANCE  (one JVM / one pod replica)
                    └── REQUEST  (individual HTTP call / DB query — traced)
```

Every entity gets a unique **Dynatrace Entity ID** (e.g. `HOST-abc123`).

### 1.3 Environments & Tenants

- **Environment** = one isolated Dynatrace tenant (URL like `https://xyz.live.dynatrace.com`)
- **Managed** = self-hosted cluster (you run the Dynatrace servers)
- **SaaS** = Dynatrace runs the cluster for you

For onboarding you always need: **Environment ID** + **PaaS Token** (to download OneAgent installer).

---

## Part 2 — Onboarding a Linux / Windows VM (OneAgent)

### 2.1 Pre-flight Checklist

Before installing:
1. Outbound HTTPS (443) from host → `<environment-id>.live.dynatrace.com`
2. If behind firewall: ActiveGate deployed in DMZ first, then agents route through it
3. OS user with `root` (Linux) or `Administrator` (Windows) privileges
4. At least 200 MB disk, 512 MB RAM free for the agent process

### 2.2 Get the Installer

In Dynatrace UI:
```
Settings → Deployment → OneAgent → Linux  (or Windows)
```
OR via API:

```bash
# Replace ENV_ID and PAAS_TOKEN with your values
curl -o oneagent-installer.sh \
  "https://<ENV_ID>.live.dynatrace.com/api/v1/deployment/installer/agent/unix/default/latest" \
  -H "Authorization: Api-Token <PAAS_TOKEN>"
```

> The PAAS Token is a dedicated token type — NOT your API token. Generate it at:
> Settings → Integration → Platform as a Service

### 2.3 Install on Linux

```bash
# Make executable
chmod +x oneagent-installer.sh

# Basic install (auto-detects everything)
sudo ./oneagent-installer.sh

# Install with host group (recommended — groups hosts for alerting & config)
sudo ./oneagent-installer.sh --set-host-group=production-payments

# Install routing through an ActiveGate (if no direct internet)
sudo ./oneagent-installer.sh \
  --set-server=https://<ACTIVEGATE_HOST>:9999 \
  --set-tenant=<ENV_ID> \
  --set-tenant-token=<PAAS_TOKEN>
```

After install, check the agent is running:

```bash
systemctl status oneagent
# Expected: active (running)

# Check agent log
tail -f /opt/dynatrace/oneagent/log/oneagent.log
```

### 2.4 What Happens Next (Auto-Discovery Timeline)

| Time after install | What Dynatrace discovers                   |
|--------------------|--------------------------------------------|
| 0–2 min            | Host appears in UI (CPU/mem/disk)          |
| 2–5 min            | Running processes detected                 |
| 5–10 min           | Services created (HTTP, DB, messaging)     |
| 10–30 min          | Full topology map, JVM metrics, traces     |

You do **not** need to restart your application for most runtimes. OneAgent injects into running JVMs via attach API. Some older runtimes (Node.js < 12, Python 2) require a process restart.

### 2.5 Verify the Host is Onboarded

In Dynatrace UI:
```
Infrastructure → Hosts → search for hostname
```

CLI verification:
```bash
# Check agent connectivity status
/opt/dynatrace/oneagent/agent/tools/oneagentctl --get-server
# Should return your environment URL or ActiveGate URL

# Check host group assignment
/opt/dynatrace/oneagent/agent/tools/oneagentctl --get-host-group

# Check agent version
/opt/dynatrace/oneagent/agent/tools/oneagentctl --version
```

---

## Part 3 — Onboarding Kubernetes (Dynatrace Operator)

### 3.1 Why Operator, Not Manual DaemonSet

The Operator manages:
- OneAgent DaemonSet lifecycle (upgrades, rollbacks)
- CSI driver for volume-based code module injection
- Automatic token rotation
- `DynaKube` CRD — one YAML to rule all onboarding config

### 3.2 Install the Operator

```bash
# Add Dynatrace Helm repo
helm repo add dynatrace https://raw.githubusercontent.com/Dynatrace/dynatrace-operator/main/config/helm/repos/stable
helm repo update

# Create namespace
kubectl create namespace dynatrace

# Create secret with API + PaaS tokens
kubectl create secret generic dynakube \
  --namespace=dynatrace \
  --from-literal="apiToken=<API_TOKEN>" \
  --from-literal="dataIngestToken=<DATA_INGEST_TOKEN>"

# Install operator
helm install dynatrace-operator dynatrace/dynatrace-operator \
  --namespace dynatrace \
  --atomic
```

### 3.3 Create a DynaKube Resource

This YAML is your entire onboarding config for a K8s cluster:

```yaml
# dynakube.yaml
apiVersion: dynatrace.com/v1beta1
kind: DynaKube
metadata:
  name: dynakube
  namespace: dynatrace
spec:
  apiUrl: https://<ENV_ID>.live.dynatrace.com/api
  skipCertCheck: false

  oneAgent:
    cloudNativeFullStack:    # Full-stack: infra + code-level tracing
      tolerations:
        - key: node-role.kubernetes.io/master
          operator: Exists
          effect: NoSchedule
      env:
        - name: ONEAGENT_ENABLE_VOLUME_STORAGE
          value: "true"

  activeGate:
    capabilities:
      - routing
      - kubernetes-monitoring
      - dynatrace-api
    resources:
      requests:
        cpu: 500m
        memory: 512Mi
      limits:
        cpu: 1000m
        memory: 1.5Gi
```

```bash
kubectl apply -f dynakube.yaml
```

### 3.4 Verify K8s Onboarding

```bash
# Operator pod running
kubectl get pods -n dynatrace

# OneAgent DaemonSet — one pod per node
kubectl get daemonset -n dynatrace

# Check DynaKube status
kubectl describe dynakube dynakube -n dynatrace
# Look for: Phase: Running

# Confirm nodes injected
kubectl get nodes -o custom-columns='NODE:.metadata.name,INJECTED:.metadata.labels.dynatrace\.com/agent-injected'
```

In UI:
```
Infrastructure → Kubernetes → your cluster name
```

### 3.5 Application Pod Injection (Code-Level Tracing)

For a pod to get code-level tracing (not just infra), the pod's namespace needs the annotation:

```bash
kubectl label namespace my-app-namespace \
  dynatrace.com/inject=true
```

For opt-out of a specific pod:
```yaml
# In pod spec annotations:
annotations:
  oneagent.dynatrace.com/inject: "false"
```

---

## Part 4 — Onboarding via ActiveGate (Remote / Restricted Hosts)

Use ActiveGate when:
- Hosts cannot reach Dynatrace directly (firewall, no internet)
- Monitoring remote services: JMX, SNMP, SAP, IBM MQ, VMware
- You need a Dynatrace API proxy for CI/CD pipelines

### 4.1 Deploy ActiveGate

```bash
# Download installer from Dynatrace UI:
# Settings → Deployment → ActiveGate → Linux

chmod +x activegate-installer.sh
sudo ./activegate-installer.sh

systemctl status dynatracegateway
```

### 4.2 Point OneAgents at ActiveGate

When installing OneAgent on restricted hosts:

```bash
sudo ./oneagent-installer.sh \
  --set-server=https://<ACTIVEGATE_IP>:9999 \
  --set-tenant=<ENV_ID> \
  --set-tenant-token=<PAAS_TOKEN> \
  --set-host-group=restricted-zone
```

---

## Part 5 — Tagging & Grouping After Onboarding

### 5.1 Why Tagging Matters

Without tags, all hosts/services land in one flat list. Tags let you:
- Filter dashboards by team/environment/region
- Apply alerting profiles only to production
- Restrict visibility via Management Zones

### 5.2 Auto-Tagging Rules (UI)

```
Settings → Tags → Automatically applied tags → Create rule
```

Example rule — tag hosts by environment variable:
```
Tag name: environment
Source: Environment variable
Key: ENV_NAME
Value: {env}
Apply to: PROCESS_GROUP
```

### 5.3 Tagging via API (Bulk Onboarding)

```bash
# Tag a host entity
curl -X POST \
  "https://<ENV_ID>.live.dynatrace.com/api/v1/entity/infrastructure/hosts/<HOST_ID>/tags" \
  -H "Authorization: Api-Token <API_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"tags": [{"key": "team", "value": "payments"}, {"key": "env", "value": "production"}]}'
```

### 5.4 Management Zones

Management Zones scope visibility. Create one per team:

```
Settings → Management Zones → Add management zone
```

Example rule:
```
Condition: Tag [team] equals payments
Apply to: Hosts, Services, Process Groups
```

---

## Part 6 — Process Group Detection (Application Naming)

By default Dynatrace may group multiple services under one generic "Java" process group. Fix this with detection rules.

### 6.1 Detection Rule in UI

```
Settings → Processes and containers → Process group detection → Add detection rule
```

Example — split by port:
```
Rule: If executable = "java" AND port = 8080 → Group name: "payments-service"
```

### 6.2 Custom Process Group Naming via Properties File

Create `/var/lib/dynatrace/oneagent/agent/config/processgrouplabel.properties`:

```properties
# Force-name this process group
process_group_name=checkout-api
```

Then restart the process (not the agent).

---

## Part 7 — Onboarding Logs (Log Monitoring)

### 7.1 Log Ingest via OneAgent (Auto-Discovery)

OneAgent auto-discovers logs for known frameworks (Nginx, Tomcat, Spring Boot). To add custom log paths:

```
Settings → Log Monitoring → Log sources and storage → Add custom log source
```

```
Log source path: /var/log/myapp/*.log
Process group: my-application
```

### 7.2 Log Ingest via API (No Agent)

```bash
# Send log lines to Dynatrace Logs API
curl -X POST \
  "https://<ENV_ID>.live.dynatrace.com/api/v2/logs/ingest" \
  -H "Authorization: Api-Token <LOG_INGEST_TOKEN>" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d '{
    "content": "ERROR: payment timeout for order 12345",
    "log.source": "/var/log/payments/app.log",
    "dt.entity.process_group_instance": "PROCESS_GROUP_INSTANCE-abc123",
    "severity": "ERROR",
    "timestamp": "2026-07-31T10:00:00.000Z"
  }'
```

---

## Part 8 — Post-Onboarding Validation Checklist

```bash
# 1. Host visible in UI
#    Infrastructure → Hosts → find hostname ✓

# 2. Agent version correct
/opt/dynatrace/oneagent/agent/tools/oneagentctl --version

# 3. Services auto-detected (check in UI)
#    Applications & Microservices → Services ✓

# 4. Traces flowing (for Java/Node/.NET apps)
#    Distributed Traces → check last 15 min ✓

# 5. Logs appearing
#    Logs → filter by host ✓

# 6. Alerts configured (do NOT rely on defaults for prod)
#    Alerting → Alerting profiles → assign to management zone ✓

# 7. SLO attached
#    Service-level objectives → link to onboarded service ✓
```

---

## Common Mistakes

| Mistake | Consequence | Fix |
|---------|-------------|-----|
| No host group assigned at install | All hosts land in "default" group; alerting rules don't apply | Reinstall with `--set-host-group=X` or use oneagentctl post-install |
| PAAS token used instead of API token for tagging | 403 errors on tag API calls | PAAS token = install only; API token = management operations |
| K8s namespace not labeled for injection | Pods get infra metrics but NO code tracing | `kubectl label namespace <ns> dynatrace.com/inject=true` |
| Firewall blocks agent → cluster (port 443) | Agent installs but never phones home; host "unreachable" | Add ActiveGate as proxy in same network zone |
| Process restart not done after agent install (Python/Node legacy) | No distributed traces, no JVM metrics | Restart the application process after OneAgent install |
| Management zone not created | All teams see all data — security/noise risk | Create zones before onboarding prod services |
