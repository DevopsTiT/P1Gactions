# Dynatrace Onboarding — Glossary

Every term, tool, and concept from main.md explained for an SRE beginner.

---

**OneAgent**
Dynatrace's main monitoring program you install on a server. Think of it as a spy that watches everything happening on the machine — CPU, memory, network, and every app running. It works automatically without you configuring what to watch.

**Dynatrace Environment**
One isolated Dynatrace account/workspace. Like a separate office building — everything inside belongs to one organization. Has its own URL (e.g. `https://xyz.live.dynatrace.com`).

**Environment ID**
The unique short code identifying your Dynatrace environment. It's the `xyz` part of `https://xyz.live.dynatrace.com`. You use it in API calls and installer commands.

**Tenant**
Another word for a Dynatrace environment. One tenant = one isolated monitoring workspace.

**SaaS (Dynatrace SaaS)**
Dynatrace hosts and manages the monitoring servers for you in their cloud. You just install agents on your machines and data flows to their servers.

**Managed (Dynatrace Managed)**
You run the Dynatrace server cluster yourself in your own datacenter. More control but more ops work.

**PaaS Token**
A special token (password) used only to download and install OneAgent installers. Think of it as a key just for the "delivery door" of the building. It cannot be used for anything else (not for APIs, not for tagging).

**API Token**
A general-purpose token for calling Dynatrace management APIs — tagging hosts, querying metrics, creating dashboards. Different from PaaS token. You generate it in Settings → Integration → Dynatrace API.

**Data Ingest Token**
A token specifically for pushing custom metrics or logs into Dynatrace via API. Used when you do not have an agent installed.

**Full-Stack Monitoring**
Monitoring that covers all layers at once: the server hardware (CPU/disk), the OS processes, the code running inside the process (method-level traces), and the requests between services. OneAgent in cloudNativeFullStack mode does all of this.

**Infrastructure Monitoring**
Monitoring limited to OS-level metrics: CPU, memory, disk, network. No code-level tracing. Cheaper but less visibility. Used when you cannot inject code (e.g. a black-box vendor service).

**Auto-Discovery**
OneAgent's ability to find and start monitoring processes, services, and connections automatically — without you telling it what to watch. Within minutes of install, Dynatrace knows your topology.

**ActiveGate**
A Dynatrace component that acts as a middle-man (proxy) between your agents/hosts and the Dynatrace environment. Required when hosts cannot reach the internet directly. Also used for remote monitoring of things like JMX, SAP, VMware where you cannot install an agent.

**Host Group**
A label you assign to a set of hosts so Dynatrace can apply rules to all of them together. Example: `production-payments` groups all payment service servers. Used for alerting profiles and configuration inheritance.

**Management Zone**
A visibility scope in Dynatrace. Controls which team can see which hosts/services. Like "this team's window into the data" — payments team sees only payment hosts, not the whole company's infrastructure.

**Entity**
Anything Dynatrace monitors and tracks — a host, a process, a service, a database, a Kubernetes pod. Each entity gets a unique ID (like `HOST-abc123` or `SERVICE-xyz789`).

**Entity ID**
The unique identifier Dynatrace assigns to every monitored thing. Looks like `HOST-abc123`. Used in API calls to reference a specific host or service.

**Process Group**
Dynatrace's way of grouping multiple instances of the same app together. Example: 5 JVM processes running the same jar on different hosts become one Process Group named "payments-service". Makes dashboards cleaner.

**Process Group Detection Rules**
Configuration that tells Dynatrace HOW to name and split process groups. By default it may put everything into one "Java" group. Rules let you say "name it by the command-line flag" or "split by port number".

**Service**
A logical grouping in Dynatrace representing a capability — like "checkout API" or "payment processor". Created automatically when OneAgent detects HTTP or DB calls. One service can span multiple host processes.

**Distributed Trace**
A recording of one request as it flows through multiple services. Example: user clicks "buy" → web server → payment API → database. Each step is recorded with timing. Helps find where a request is slow.

**Injection**
The act of OneAgent inserting monitoring code into a running application process. For Java, it uses the JVM attach API. For Kubernetes pods, it mounts a code module into the container. Without injection, you get infra metrics but no code-level tracing.

**DynaKube (Custom Resource)**
A Kubernetes YAML resource type that Dynatrace's Operator watches. You describe what you want (full-stack? infra only? routing?) in one DynaKube YAML, and the Operator makes it happen — creating DaemonSets, secrets, CSI drivers, etc.

**Dynatrace Operator**
A Kubernetes controller that manages all Dynatrace components inside a K8s cluster. You install it once (via Helm), then configure everything via a DynaKube resource. It handles upgrades and restarts automatically.

**DaemonSet**
A Kubernetes object that ensures one pod runs on every node in the cluster. Dynatrace uses a DaemonSet for OneAgent so every node gets monitored automatically, including new nodes added to the cluster.

**CSI Driver (Container Storage Interface)**
A Kubernetes storage plugin that Dynatrace uses to inject the OneAgent code module into application pods via a mounted volume. Enables code-level tracing without baking the agent into the application container image.

**cloudNativeFullStack**
A DynaKube mode that gives you the deepest monitoring: both infrastructure (node-level) AND code-level injection into application pods. Uses CSI driver for injection. Recommended for Kubernetes onboarding.

**Tagging**
Adding key-value labels to entities in Dynatrace (like `team=payments` or `env=production`). Used to filter dashboards, scope management zones, and target alerting rules. Can be done manually, via rules in UI, or via API.

**Auto-Tagging Rules**
Configuration in Dynatrace that automatically applies tags based on properties it can detect — environment variables, host names, process names, Kubernetes labels. Set-once, then every new entity matching the rule gets tagged automatically.

**oneagentctl**
A command-line tool installed with OneAgent at `/opt/dynatrace/oneagent/agent/tools/oneagentctl`. Used to check and change agent configuration (host group, server URL, version) without reinstalling.

**Log Monitoring**
Dynatrace's feature for collecting, storing, and searching log files. OneAgent can auto-discover logs from known applications. Custom log paths can be added. Logs can also be pushed via API without an agent.

**Log Ingest Token**
A token specifically scoped to the `logs.ingest` permission. Required when pushing log data to Dynatrace via API (`/api/v2/logs/ingest`).

**Synthetic Monitor**
A Dynatrace feature that simulates user interactions (HTTP pings, browser clicks) from locations around the world to check if a service is reachable and fast. Used for services where you cannot install an agent (SaaS apps, external APIs).

**SLO (Service Level Objective)**
A target for how reliable a service should be. Example: "99.9% of checkout requests succeed in under 500ms." After onboarding, you attach SLOs to services to track if you are meeting your reliability goals.

**Alerting Profile**
A Dynatrace configuration that controls which problems trigger alerts and who gets notified. After onboarding, you must assign an alerting profile to your management zone — otherwise alerts go nowhere or go to the wrong team.

**Topology Map (Smartscape)**
Dynatrace's auto-generated visual map of how services call each other. After onboarding, Dynatrace builds this automatically by watching network traffic between OneAgent-monitored processes.

**JVM Attach API**
A Java feature that lets external tools (like OneAgent) inject monitoring code into an already-running Java process — without restarting it. This is why OneAgent can start tracing Java apps immediately after install.

**Port 443 / HTTPS**
The network port used for encrypted web traffic. OneAgent sends all monitoring data to Dynatrace over HTTPS port 443. Your firewall must allow outbound connections on this port from monitored hosts to the Dynatrace environment URL.

**DMZ (Demilitarized Zone)**
A network segment that sits between your internal servers and the internet, with tighter firewall rules. ActiveGate is often placed in the DMZ so internal hosts (with no internet access) can route their agent data through it.

**Helm**
A package manager for Kubernetes, like `apt` or `brew` but for K8s applications. Used to install the Dynatrace Operator with a single `helm install` command instead of applying dozens of YAML files manually.

**kubectl**
The command-line tool for managing Kubernetes clusters. Used throughout K8s onboarding to apply YAMLs, check pod status, and label namespaces.

**Namespace (Kubernetes)**
A virtual partition inside a Kubernetes cluster. Like a folder — you group related pods together. Dynatrace injection must be enabled per namespace using a label (`dynatrace.com/inject=true`).

**Rollout Restart**
A Kubernetes command (`kubectl rollout restart`) that gradually replaces all pods in a deployment with fresh ones. Used after enabling Dynatrace injection so existing pods (which were not injected) get replaced by new ones that are.
