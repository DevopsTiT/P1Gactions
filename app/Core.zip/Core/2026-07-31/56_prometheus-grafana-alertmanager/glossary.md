# Prometheus + Grafana + Alertmanager — Glossary for SRE Beginners

Every term used in main.md, one entry per term.

---

**Prometheus**
An open-source monitoring system that collects metrics from services by pulling (HTTP GET) their `/metrics` endpoints on a schedule. Stores data in a time-series database on disk. Evaluates alerting rules and sends firing alerts to Alertmanager. The industry standard for Kubernetes monitoring.

**Grafana**
An open-source visualisation platform. Connects to Prometheus (and other data sources) via PromQL queries and renders dashboards with charts, gauges, and tables. Does NOT store metrics itself — it only reads from Prometheus.

**Alertmanager**
An open-source component that receives firing alerts from Prometheus and routes them to notification channels (PagerDuty, Slack, email). Handles deduplication, grouping, silences, and inhibitions. Think of it as the "alert router."

**PULL model**
Prometheus's data collection approach: Prometheus initiates the connection and GETs metrics from targets. The opposite of PUSH (where the agent sends data to a central server). Pull means Prometheus detects immediately when a target stops responding (instead of waiting for the agent to stop reporting).

**Metrics endpoint (`/metrics`)**
An HTTP endpoint that a service exposes to serve its current metric values in the OpenMetrics text format. Prometheus scrapes this URL on a schedule. For Spring Boot: `/actuator/prometheus`. For Node.js: a prom-client library endpoint.

**OpenMetrics format**
A text-based format for exposing metrics. Each line: `metric_name{label="value"} numeric_value`. The standard format that Prometheus expects from targets.

**Time series**
A sequence of (timestamp, value) pairs for a specific combination of metric name + labels. `http_requests_total{service="payment-service", status="200"}` is one time series. Prometheus stores millions of time series.

**Label**
A key-value pair attached to a metric that identifies a dimension of that metric. `{service="payment-service", status="500", method="POST"}`. Labels enable filtering and aggregation. Every unique label combination is a separate time series.

**Cardinality**
The number of unique time series in Prometheus. High cardinality (too many unique label combinations) causes Prometheus memory and performance issues. Avoid labels with unbounded values (user IDs, request IDs, timestamps — these create millions of time series).

**Counter**
A metric type that only increases (or resets to 0 on restart). Used for counting events: requests, errors, bytes. Always use `rate()` or `increase()` in PromQL to get meaningful values from counters.

**Gauge**
A metric type that can go up or down. Used for current-state values: memory usage, active connections, queue depth, CPU load. Query directly in PromQL without rate().

**Histogram**
A metric type that samples observations into configured buckets, plus a total sum and count. Used for measuring distributions: request latency, request size. Creates `_bucket`, `_sum`, and `_count` time series. Used with `histogram_quantile()` to calculate percentiles (P50, P99, etc.).

**Summary**
A metric type that computes quantiles on the CLIENT side (inside the service). Rarely used because client-side quantiles cannot be aggregated across multiple instances. Always prefer Histogram for services with multiple pods.

**PromQL (Prometheus Query Language)**
The query language for Prometheus. Used to select time series, compute rates, aggregate across labels, calculate percentiles. Results are used in Grafana dashboards and Prometheus alerting rules.

**`rate()`**
A PromQL function that calculates the per-second average rate of increase of a counter over a time window. `rate(http_requests_total[5m])` = average requests per second over the last 5 minutes. Accounts for counter resets (pod restarts).

**`irate()`**
A PromQL function that calculates the per-second rate using only the last two data points in the window. More responsive to sudden spikes but noisier than `rate()`. Use `rate()` for dashboards and alerts, `irate()` for debugging sudden events.

**`increase()`**
A PromQL function that calculates the total increase of a counter over a time window. `increase(http_requests_total[1h])` = total new requests in the last hour.

**`histogram_quantile()`**
A PromQL function that calculates a quantile (e.g., P99) from histogram bucket data. `histogram_quantile(0.99, rate(http_request_duration_seconds_bucket[5m]))` = 99th percentile latency over 5 minutes. Only works with Histogram metric type.

**`sum by ()`**
A PromQL aggregation that sums time series, keeping specific labels. `sum by (service) (rate(http_requests_total[5m]))` = one result per service. Without `by`: sums everything into a single number.

**`up` metric**
A special Prometheus-generated metric: `up{job="payment-service", instance="10.0.5.23:8080"} = 1` if the last scrape succeeded, `= 0` if it failed. Automatically created for every scrape target. The simplest "is this service reachable?" signal.

**scrape_interval**
How frequently Prometheus fetches metrics from each target. Default: 15s. Shorter intervals give more granular data but increase Prometheus CPU and storage load.

**evaluation_interval**
How frequently Prometheus evaluates recording rules and alerting rules. Should match scrape_interval (typically 15s or 30s).

**Recording rule**
A pre-computed PromQL expression that Prometheus evaluates on a schedule and stores as a new metric. Used to replace expensive repeated queries with a cheap time series lookup. Naming convention: `level:metric_name:operations`.

**TSDB (Time Series Database)**
Prometheus's built-in storage engine. Stores metric data in compressed 2-hour blocks on disk. Optimised for write-heavy workloads with many small samples. Default retention: 15 days.

**WAL (Write-Ahead Log)**
Prometheus writes every incoming scrape to the WAL immediately for durability. The WAL is then compacted into the main TSDB storage. If Prometheus crashes, it replays the WAL on restart to recover recent data.

**Retention**
How long Prometheus keeps data before deleting it. Configured with `--storage.tsdb.retention.time` (default: 15d). Longer retention requires more disk. For longer-term storage, use Thanos or Cortex.

**Alerting rule**
A PromQL expression evaluated by Prometheus that fires an alert when the expression returns a result (non-empty). Has a `for` duration requirement and labels/annotations. Sends firing alerts to Alertmanager.

**`for` duration (alerting rules)**
The minimum time a condition must be true before the alert fires. `for: 5m` means the PromQL must return results for 5 continuous minutes. Prevents false alerts from momentary spikes. Critical for avoiding alert fatigue.

**PENDING state (alert)**
When an alerting rule's condition first becomes true but the `for` duration hasn't elapsed yet. The alert is PENDING — it will become FIRING if the condition remains true long enough.

**FIRING state (alert)**
When an alerting rule's condition has been true for >= the `for` duration. Prometheus sends the firing alert to Alertmanager.

**RESOLVED state (alert)**
When a previously FIRING alert's condition becomes false. Prometheus sends a resolved notification to Alertmanager, which (if `send_resolved: true`) sends a resolution notification to the receiver.

**Alertmanager route**
A rule in Alertmanager's configuration that matches incoming alerts and directs them to a receiver. Routes form a tree — the first matching child route wins. Parent route is the fallback.

**`group_by`**
An Alertmanager setting that groups alerts with the same label values into a single notification. `group_by: [alertname, service]` means all HighErrorRate alerts for payment-service are bundled into one Slack message instead of one per pod.

**`group_wait`**
How long Alertmanager waits after receiving the first alert in a group before sending a notification. Allows related alerts that fire within this window to be grouped together. Default: 30s.

**`group_interval`**
After the first notification, how long to wait before sending another for the same group (if new alerts join or the group is still firing). Default: 5m.

**`repeat_interval`**
How long to wait before re-sending a notification for an alert group that hasn't changed. Prevents constant spamming. Default: 4h.

**Receiver**
An Alertmanager configuration block that defines where to send notifications: PagerDuty, Slack webhook, email, etc. Each receiver can have multiple notification methods.

**Inhibition rule**
An Alertmanager rule that suppresses (inhibits) certain alerts when a higher-severity related alert is firing. `NodeDown` inhibiting `PodCrashLooping` from the same node — the pod symptoms are noise when the node is down.

**Silence**
An Alertmanager rule that suppresses notifications for matching alerts during a time window. Used for planned maintenance. Set by SREs before maintenance starts, expires automatically.

**`continue: false`**
An Alertmanager route setting. When false: if this route matches, don't evaluate further routes (stops routing). When true: continue evaluating further routes even after a match. Allows an alert to be sent to multiple receivers.

**amtool**
The command-line interface for Alertmanager. Used to create silences, query active alerts, check routing configuration. `amtool silence add`, `amtool silence query`.

**Grafana dashboard**
A page in Grafana containing multiple panels (charts). Saved as JSON and can be version-controlled. Identified by a UID in the URL. Can be templated with variables for reusability.

**Grafana panel**
A single visualisation on a dashboard. Types: time series (line chart), gauge (speedometer), stat (single number), table, heatmap, bar chart. Each panel executes one or more PromQL queries.

**Grafana variable**
A dropdown parameter at the top of a dashboard. Queries Prometheus for valid values (e.g., all unique service labels). Panel queries use `$variable_name` to filter by the selected value. Makes one dashboard serve all services.

**Grafana data source**
The connection configuration between Grafana and a metrics backend. "Prometheus data source" = URL of the Prometheus server, authentication, query timeout. One dashboard can use multiple data sources.

**Grafana provisioning**
Configuring Grafana via config files instead of the UI. Datasource files and dashboard JSON files are loaded automatically from disk. Enables Grafana-as-code: configuration is in git, changes are applied by restarting/reloading.

**kube-prometheus-stack**
A Helm chart that installs the complete monitoring stack: Prometheus Operator, Prometheus, Alertmanager, Grafana, node-exporter, kube-state-metrics, and pre-built dashboards and rules. The standard way to deploy monitoring on Kubernetes.

**Prometheus Operator**
A Kubernetes controller that manages Prometheus, Alertmanager, and their configuration using custom resources (ServiceMonitor, PodMonitor, PrometheusRule). Instead of editing `prometheus.yml` directly, you create CRDs.

**ServiceMonitor**
A Kubernetes custom resource (CRD) that tells Prometheus Operator which services to scrape. Prometheus Operator reads ServiceMonitors and generates scrape configs for Prometheus. Deployed alongside the service being monitored.

**node-exporter**
A Prometheus exporter that runs as a DaemonSet (one pod per node). Exposes Linux system metrics: CPU, memory, disk, network from `/proc` and `/sys`. Provides the data for node-level dashboards and alerts.

**kube-state-metrics**
A service that watches the Kubernetes API server and exposes metrics about Kubernetes objects: deployment replicas, pod status, node conditions, resource requests/limits. Essential for Kubernetes-level dashboards and alerts.

**Kubernetes service discovery (`kubernetes_sd_configs`)**
Prometheus's ability to automatically discover scrape targets from the Kubernetes API. Instead of manually listing pod IPs, Prometheus queries Kubernetes for pods/services/nodes and updates its target list as pods start and stop.

**Relabeling**
A Prometheus mechanism to rename, drop, or modify labels during the scrape process. Used to: add useful labels (namespace, pod name), remove noisy labels, filter which pods to scrape based on annotations.

**SLO burn rate**
How fast the error budget is being consumed. 14.4× burn rate means the budget would be exhausted in 30 days / 14.4 = ~2 days. Multi-window SLO alerts fire when both a short window (5m) and a longer window (1h) show elevated burn rate simultaneously.

**Thanos**
An open-source project that adds long-term storage and global query view to Prometheus. Connects multiple Prometheus instances, deduplicates metrics from HA pairs, and stores data in S3 for years. Used when 15-day Prometheus retention isn't enough.

**Cortex / Mimir**
Cloud-native, horizontally scalable Prometheus-compatible backends. Accept Prometheus `remote_write` and store data in object storage. Used at scale when single-node Prometheus can't handle the load.

**`remote_write`**
A Prometheus feature that streams metrics to an external storage backend (Thanos, Cortex, Grafana Cloud) in real-time. Allows long-term retention beyond Prometheus's local disk.

**pushgateway**
A Prometheus component for short-lived jobs (batch jobs, cron jobs) that can't be scraped because they finish before Prometheus polls. The job pushes its metrics to the pushgateway, which holds them until Prometheus scrapes the gateway.

**`promtool`**
The Prometheus CLI utility. Used to: validate configuration files (`check config`), validate rule files (`check rules`), test alert rules against mock data (`test rules`), query live Prometheus (`query instant`).

**`histogram_quantile()` prerequisite**
`histogram_quantile()` requires the histogram buckets to cover the actual values. If all your requests take 250ms but your bucket boundaries are 0.1s, 0.5s, 1s, the P99 calculated will be an interpolation within the [0.1, 0.5] bucket, not exact. Good bucket boundaries: `[0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5]`.

**Alert fatigue**
When on-call engineers receive so many alerts (including false positives) that they start ignoring them. Caused by: missing `for` duration (noisy), wrong thresholds, alerting on symptoms instead of causes. Solved by: meaningful `for` durations, inhibition rules, well-tuned thresholds.

**PagerDuty integration key**
A service-specific key used to send alerts to a PagerDuty service. Each team gets its own integration key → their own escalation policy and on-call rotation. Alertmanager uses this key in the `pagerduty_configs.routing_key` field.
