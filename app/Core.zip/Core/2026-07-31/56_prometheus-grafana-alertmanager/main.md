# Prometheus + Grafana + Alertmanager — SRE Deep Dive

> The three-component observability stack: Prometheus collects metrics, Grafana visualises them, Alertmanager routes alerts to the right people. Used by every major SRE team alongside or instead of commercial tools like Dynatrace.

---

## The Observability Stack — How the Three Fit Together

```
┌─────────────────────────────────────────────────────────────────────┐
│                        TARGETS (services)                           │
│   payment-service:8080/metrics   order-service:8080/metrics        │
│   node-exporter:9100/metrics     kube-state-metrics:8080/metrics   │
└────────────────┬────────────────────────────────────────────────────┘
                 │  HTTP GET /metrics (every 15s — Prometheus PULLS)
                 ▼
┌─────────────────────────────────────────────────────────────────────┐
│                        PROMETHEUS                                   │
│  • Scrapes metrics from targets                                     │
│  • Stores time-series data (TSDB on disk)                           │
│  • Evaluates recording rules  (pre-computes expensive queries)      │
│  • Evaluates alerting rules   (fires when conditions are true)      │
│  • Exposes PromQL query API                                         │
└──────────┬────────────────────────────┬──────────────────────────────┘
           │                            │
           │  PromQL queries            │  ALERTS (HTTP POST)
           ▼                            ▼
┌──────────────────────┐    ┌──────────────────────────────────────────┐
│       GRAFANA        │    │              ALERTMANAGER                │
│ • Dashboards         │    │  • Receives firing alerts from Prometheus│
│ • Panels (charts)    │    │  • Groups related alerts (deduplication) │
│ • Variables          │    │  • Silences (maintenance windows)        │
│ • Alerting (optional)│    │  • Inhibitions (suppress downstream)     │
│ • Data source config │    │  • Routes to: PagerDuty/Slack/email      │
└──────────────────────┘    └──────────────────────────────────────────┘
```

**The PULL model (Prometheus scrapes targets):**
Unlike Dynatrace (agent pushes data), Prometheus PULLS metrics from targets. Every target exposes an HTTP endpoint `/metrics` in the OpenMetrics format. Prometheus fetches it on a schedule.

Advantage: Prometheus knows immediately if a target is DOWN (scrape fails) — no need to wait for the agent to stop sending.
Disadvantage: services must expose an HTTP endpoint. For services behind firewalls or in private networks, a pushgateway is needed.

---

## Part 1: Prometheus Deep Dive

### 1.1 The Data Model

```
Every metric in Prometheus is a combination of:
  metric_name{label1="value1", label2="value2"} VALUE TIMESTAMP

Examples from a Java Spring Boot service:
  http_requests_total{method="POST", endpoint="/api/v1/payments", status="200"} 8437 1690800000000
  http_requests_total{method="POST", endpoint="/api/v1/payments", status="500"} 12 1690800000000
  jvm_memory_used_bytes{area="heap", id="G1 Eden Space"} 104857600 1690800000000
  process_cpu_usage{} 0.0234 1690800000000
```

**The four metric types:**

```
1. COUNTER — only goes UP (or resets to 0 on restart)
   Use: counting events (requests, errors, bytes transferred)
   Example: http_requests_total
   In PromQL: use rate() to get per-second rate
   
   http_requests_total{status="500"} = 1247  ← total errors since startup
   rate(http_requests_total{status="500"}[5m]) = 0.041  ← errors/second

2. GAUGE — can go UP or DOWN
   Use: current state values (memory, CPU, queue depth, active connections)
   Example: jvm_memory_used_bytes, active_connections
   In PromQL: use directly or with aggregation
   
   jvm_memory_used_bytes{area="heap"} = 536870912  ← 512MB right now

3. HISTOGRAM — samples in configurable buckets
   Use: measuring distributions (latency, request size)
   Example: http_request_duration_seconds_bucket
   Creates 3 time series per metric:
     _bucket{le="0.1"} = requests taking ≤ 100ms
     _bucket{le="0.5"} = requests taking ≤ 500ms
     _bucket{le="+Inf"} = all requests (total count)
     _sum = sum of all durations
     _count = total count of observations
   
   Calculate P99 in PromQL:
     histogram_quantile(0.99, rate(http_request_duration_seconds_bucket[5m]))

4. SUMMARY — pre-computed quantiles (RARELY USE)
   Quantiles computed on the CLIENT side (can't aggregate across instances)
   Use histograms instead for anything where you need to aggregate.
```

### 1.2 The Scrape Lifecycle

```
Every 15 seconds (default scrape_interval), for each target:

1. Prometheus sends:
   GET http://payment-service:8080/metrics HTTP/1.1
   Accept: application/openmetrics-text; version=1.0.0, application/openmetrics-text, */*

2. Target responds:
   HTTP/1.1 200 OK
   Content-Type: text/plain; version=0.0.4
   
   # HELP http_requests_total Total HTTP requests
   # TYPE http_requests_total counter
   http_requests_total{method="GET",status="200"} 1234.0
   http_requests_total{method="POST",status="200"} 567.0
   http_requests_total{method="POST",status="500"} 8.0
   # HELP jvm_memory_used_bytes JVM memory usage
   # TYPE jvm_memory_used_bytes gauge
   jvm_memory_used_bytes{area="heap"} 5.36870912e+08
   ...

3. Prometheus parses and stores:
   Each line becomes a time series entry in the TSDB
   Key: (metric_name, label_set) → unique time series
   Value: (timestamp, float64 value)

4. Prometheus adds labels:
   job="payment-service"          ← from the scrape config job name
   instance="10.0.5.23:8080"     ← from the target's address
   environment="production"       ← from relabeling rules (if configured)
```

### 1.3 Prometheus Configuration (prometheus.yml)

```yaml
# /etc/prometheus/prometheus.yml

global:
  scrape_interval: 15s      # How often to scrape targets
  evaluation_interval: 15s  # How often to evaluate alerting rules
  scrape_timeout: 10s        # Max time to wait for a scrape response

  # Labels added to all time series AND alerts from this Prometheus
  external_labels:
    cluster: "production"
    region: "ap-northeast-1"
    # When Prometheus federates or sends to remote_write, these labels
    # identify WHICH Prometheus the data came from

# Alertmanager connection
alerting:
  alertmanagers:
    - static_configs:
        - targets: ["alertmanager:9093"]

# Recording and alerting rules (loaded from files)
rule_files:
  - "/etc/prometheus/rules/*.yaml"

# Scrape configurations
scrape_configs:

  # ── Prometheus itself ───────────────────────────────────────────────────────
  - job_name: "prometheus"
    static_configs:
      - targets: ["localhost:9090"]

  # ── Kubernetes pods with annotations ────────────────────────────────────────
  - job_name: "kubernetes-pods"
    kubernetes_sd_configs:           # ← Kubernetes service discovery
      - role: pod
    relabel_configs:
      # Only scrape pods with annotation: prometheus.io/scrape: "true"
      - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_scrape]
        action: keep
        regex: "true"
      # Use the port from annotation: prometheus.io/port: "8080"
      - source_labels: [__meta_kubernetes_pod_annotation_prometheus_io_port]
        action: replace
        target_label: __address__
        regex: (.+)
        replacement: $1
      # Add namespace label to all metrics
      - source_labels: [__meta_kubernetes_namespace]
        target_label: namespace
      # Add pod name label
      - source_labels: [__meta_kubernetes_pod_name]
        target_label: pod
      # Add container name label
      - source_labels: [__meta_kubernetes_pod_container_name]
        target_label: container

  # ── Node exporters ─────────────────────────────────────────────────────────
  - job_name: "node-exporter"
    kubernetes_sd_configs:
      - role: node
    relabel_configs:
      - action: replace
        source_labels: [__address__]
        regex: '(.+):.*'
        target_label: __address__
        replacement: '${1}:9100'
      - source_labels: [__meta_kubernetes_node_name]
        target_label: node

  # ── Java Spring Boot services (static config for dev) ────────────────────────
  - job_name: "payment-service"
    metrics_path: "/actuator/prometheus"   # Spring Boot Actuator endpoint
    static_configs:
      - targets:
          - "payment-service.payment-ns.svc.cluster.local:8080"
        labels:
          service: "payment-service"
          team: "payments"
          environment: "production"

  # ── kube-state-metrics ──────────────────────────────────────────────────────
  - job_name: "kube-state-metrics"
    static_configs:
      - targets: ["kube-state-metrics.kube-system.svc.cluster.local:8080"]
```

### 1.4 PromQL — The Query Language

PromQL is the language for querying Prometheus time series. Master this and you can build any dashboard or alert.

**Selectors:**
```promql
# All time series with this metric name:
http_requests_total

# Filter by label (exact match):
http_requests_total{service="payment-service"}

# Filter by label (regex):
http_requests_total{service=~"payment|order"}    # matches either
http_requests_total{status!~"2.."}               # NOT 2xx (4xx, 5xx)

# Range vector (last 5 minutes of data):
http_requests_total[5m]
```

**Aggregation operators:**
```promql
# Sum across all instances of a service:
sum(http_requests_total{service="payment-service"})

# Sum, keeping the 'status' label, dropping everything else:
sum by (status) (http_requests_total{service="payment-service"})

# Average CPU across all nodes:
avg(node_cpu_seconds_total)

# Max memory usage across all pods in a namespace:
max by (pod) (container_memory_usage_bytes{namespace="payment-ns"})

# Count how many pods are running per deployment:
count by (deployment) (kube_pod_status_phase{phase="Running"})
```

**Rate functions:**
```promql
# Per-second rate of a counter over last 5 minutes:
rate(http_requests_total[5m])
# Smoothed average: useful for dashboards

# Instant increase (for short intervals, captures spikes):
irate(http_requests_total[5m])
# Uses last 2 data points: useful for volatile metrics

# Total increase over a time window:
increase(http_requests_total[1h])
# Total new requests in the last hour
```

**Essential alert expressions:**

```promql
# ── Error rate (requests) ────────────────────────────────────────────────────
sum(rate(http_requests_total{status=~"5..",service="payment-service"}[5m]))
/ sum(rate(http_requests_total{service="payment-service"}[5m]))
> 0.001    # alert if > 0.1% error rate

# ── P99 latency (histogram) ──────────────────────────────────────────────────
histogram_quantile(
  0.99,
  sum by (le) (rate(http_request_duration_seconds_bucket{service="payment-service"}[5m]))
) > 0.300    # alert if P99 > 300ms

# ── JVM heap usage ───────────────────────────────────────────────────────────
jvm_memory_used_bytes{area="heap", service="payment-service"}
/ jvm_memory_max_bytes{area="heap", service="payment-service"}
> 0.80    # alert if > 80% heap used

# ── Pod not running ──────────────────────────────────────────────────────────
kube_deployment_status_replicas_unavailable{deployment="payment-service"} > 0

# ── Target down (scrape failed) ───────────────────────────────────────────────
up{job="payment-service"} == 0
# 'up' is a special metric: 1 if last scrape succeeded, 0 if failed

# ── CPU saturation (node) ────────────────────────────────────────────────────
1 - avg by (instance) (rate(node_cpu_seconds_total{mode="idle"}[5m])) > 0.80

# ── Disk space running out ────────────────────────────────────────────────────
(node_filesystem_avail_bytes{mountpoint="/"} / node_filesystem_size_bytes{mountpoint="/"})
< 0.10    # alert when < 10% disk free

# ── SLO burn rate (multi-window) ─────────────────────────────────────────────
# Fast burn (1h window, 14.4× rate)
(
  sum(rate(http_requests_total{status=~"5..",service="payment-service"}[1h]))
  / sum(rate(http_requests_total{service="payment-service"}[1h]))
) > (14.4 * 0.001)    # 0.001 = 1 - SLO_target (99.9% availability)
```

### 1.5 Recording Rules (Pre-Computation)

```yaml
# /etc/prometheus/rules/recording-rules.yaml
groups:
  - name: payment_service_recording
    interval: 30s    # compute every 30 seconds
    rules:

      # Pre-compute error rate (expensive PromQL, used in 5 dashboards)
      - record: job:http_error_rate:ratio_rate5m
        expr: |
          sum by (service) (rate(http_requests_total{status=~"5.."}[5m]))
          / sum by (service) (rate(http_requests_total[5m]))

      # Pre-compute P99 latency
      - record: job:http_p99_latency:histogram_quantile5m
        expr: |
          histogram_quantile(
            0.99,
            sum by (le, service) (rate(http_request_duration_seconds_bucket[5m]))
          )

      # Pre-compute request rate
      - record: job:http_request_rate:rate5m
        expr: |
          sum by (service) (rate(http_requests_total[5m]))
```

**Why recording rules matter:**
```
Without recording rules:
  5 Grafana dashboards each execute the error rate PromQL every 15 seconds:
    sum(rate(http_requests_total{status=~"5.."}[5m]))
    / sum(rate(http_requests_total[5m]))
  
  At 15s refresh: 5 queries × 4/min = 20 queries/min to Prometheus
  Each query scans millions of data points → CPU spikes → Prometheus slow

With recording rules:
  Prometheus pre-computes the result every 30s → stores as job:http_error_rate:ratio_rate5m
  5 dashboards query the pre-computed result → 5 instant lookups (no scan)
  Prometheus CPU: significantly reduced
```

### 1.6 Storage: The TSDB

```
Prometheus stores data in a custom time-series database (TSDB) on local disk.

Default retention: 15 days
Override: --storage.tsdb.retention.time=30d

Data layout on disk:
/prometheus/data/
  ├── 01ABCDEF/    ← 2-hour block (immutable after compaction)
  │   ├── chunks/  ← actual metric values (compressed)
  │   ├── index    ← label index for fast lookup
  │   └── meta.json
  ├── 01BCDEFG/    ← another 2-hour block
  ├── wal/          ← Write-Ahead Log (recent data, not yet compacted)
  └── chunks_head/ ← current in-memory data

Write path:
  Scrape → WAL (instant durability) → in-memory head chunk → compacted 2h block

Read path (PromQL):
  Query → find matching time series (via index) → read chunks from disk/memory

Capacity planning:
  ~ 1-2 bytes per sample (after compression)
  For 10,000 active time series scraped every 15s:
    10,000 × (1/15) samples/sec = 667 samples/sec
    667 × 1.5 bytes = ~1KB/sec = ~86MB/day = ~2.6GB/month
  
  Rule: plan for 2-3 bytes per sample × active_series × retention_days
```

---

## Part 2: Alertmanager Deep Dive

### 2.1 The Alert Lifecycle

```
Step 1: Prometheus fires alert
  Prometheus evaluates alerting rules every evaluation_interval (15s).
  When a rule's condition is TRUE for >= for duration, alert becomes FIRING.
  Prometheus POSTs to Alertmanager:
    POST http://alertmanager:9093/api/v2/alerts
    [
      {
        "labels": {
          "alertname": "HighErrorRate",
          "service": "payment-service",
          "severity": "critical",
          "namespace": "payment-ns"
        },
        "annotations": {
          "summary": "payment-service error rate > 1%",
          "description": "Error rate is 3.2% (threshold: 1%)",
          "runbook_url": "https://wiki.company.com/runbooks/high-error-rate"
        },
        "startsAt": "2026-07-31T14:30:00Z",
        "generatorURL": "http://prometheus:9090/graph?g0.expr=..."
      }
    ]

Step 2: Alertmanager processes
  - Receives the alert
  - Groups with other alerts firing at the same time (if same group_by labels)
  - Waits group_wait (30s) for more alerts to arrive before notifying
  - Routes to the correct receiver based on routing tree
  - Checks inhibitions: is there a higher-severity alert suppressing this one?
  - Checks silences: is this alert silenced?
  - If not suppressed: sends notification to receiver

Step 3: Notification sent
  - PagerDuty HTTP POST → creates an incident
  - Slack webhook POST → posts a message
  - Email SMTP → sends an email

Step 4: Alert resolves
  When the PromQL condition is FALSE for >= resolution_wait, alert becomes RESOLVED.
  Prometheus sends resolved alert to Alertmanager.
  Alertmanager sends resolve notification (if send_resolved: true).
```

### 2.2 Alertmanager Configuration

```yaml
# /etc/alertmanager/alertmanager.yml

global:
  # Default SMTP configuration (used if not overridden in receivers)
  smtp_from: "alertmanager@company.com"
  smtp_smarthost: "smtp.gmail.com:587"
  smtp_auth_username: "alerts@company.com"
  smtp_auth_password: "app-password"
  
  # How long to wait before resending an alert that hasn't resolved
  repeat_interval: 4h
  
  # How long to wait before sending after a resolved notification
  resolve_timeout: 5m

# ── TEMPLATES ────────────────────────────────────────────────────────────────
templates:
  - "/etc/alertmanager/templates/*.tmpl"

# ── ROUTING TREE ──────────────────────────────────────────────────────────────
route:
  # Default: all alerts go to slack-ops unless matched by a child route
  receiver: "slack-ops"
  
  # Group alerts with the same alertname, service, namespace into one notification
  group_by: ["alertname", "service", "namespace"]
  
  # Wait this long for more alerts before sending the first notification
  # (allows grouping related alerts that fire within 30s of each other)
  group_wait: 30s
  
  # After first notification, wait this long before sending another for the same group
  group_interval: 5m
  
  # Resend notifications even if nothing changed (repeated firing)
  repeat_interval: 4h
  
  # ── CHILD ROUTES (evaluated in order, first match wins) ───────────────────
  routes:
    # Critical production alerts → PagerDuty (wakes on-call)
    - matchers:
        - severity="critical"
        - environment="production"
      receiver: "pagerduty-production"
      group_wait: 10s        # shorter wait for critical alerts
      repeat_interval: 1h   # repeat after 1h if still firing
      continue: false        # don't fall through to parent route

    # High severity staging alerts → PagerDuty (not critical, just high)
    - matchers:
        - severity="critical"
        - environment="staging"
      receiver: "pagerduty-staging"
      continue: false

    # Warning alerts → team-specific Slack channels
    - matchers:
        - severity="warning"
        - team="payments"
      receiver: "slack-payments"
      continue: false

    - matchers:
        - severity="warning"
        - team="orders"
      receiver: "slack-orders"
      continue: false

    # Info/low severity → shared ops channel
    - matchers:
        - severity=~"info|low"
      receiver: "slack-ops"

# ── INHIBITION RULES ──────────────────────────────────────────────────────────
inhibit_rules:
  # If a node is DOWN, suppress pod-level alerts from that node
  # (pod alerts are symptoms of the node failure — not separate incidents)
  - source_matchers:
      - alertname="NodeDown"
    target_matchers:
      - alertname=~"PodCrashLooping|HighCPU|HighMemory"
    equal: ["node"]
    # "equal: [node]" means: the inhibiting and inhibited alerts must
    # have the SAME value for the "node" label to trigger inhibition
    # (only suppress pod alerts from the SAME node that is down)

  # If payment-service is completely down, suppress latency/error alerts from it
  - source_matchers:
      - alertname="ServiceDown"
      - service="payment-service"
    target_matchers:
      - alertname=~"HighLatency|HighErrorRate"
      - service="payment-service"
    equal: ["service", "environment"]

# ── RECEIVERS ─────────────────────────────────────────────────────────────────
receivers:
  - name: "pagerduty-production"
    pagerduty_configs:
      - routing_key: "your-pagerduty-integration-key-here"
        # Message body (Go template):
        description: '{{ template "pagerduty.description" . }}'
        severity: '{{ if eq .CommonLabels.severity "critical" }}critical{{ else }}warning{{ end }}'
        details:
          firing: '{{ template "slack.firing" . }}'
          runbook: '{{ (index .Alerts 0).Annotations.runbook_url }}'
        send_resolved: true

  - name: "pagerduty-staging"
    pagerduty_configs:
      - routing_key: "staging-pagerduty-key"
        severity: "warning"
        send_resolved: true

  - name: "slack-payments"
    slack_configs:
      - api_url: "https://hooks.slack.com/services/PAYMENTS_WEBHOOK"
        channel: "#alerts-payments"
        title: '{{ template "slack.title" . }}'
        text: '{{ template "slack.text" . }}'
        color: '{{ if eq .Status "firing" }}{{ if eq .CommonLabels.severity "critical" }}danger{{ else }}warning{{ end }}{{ else }}good{{ end }}'
        send_resolved: true
        actions:
          - type: button
            text: "Runbook"
            url: '{{ (index .Alerts 0).Annotations.runbook_url }}'
          - type: button
            text: "Dashboard"
            url: '{{ (index .Alerts 0).Annotations.dashboard_url }}'

  - name: "slack-orders"
    slack_configs:
      - api_url: "https://hooks.slack.com/services/ORDERS_WEBHOOK"
        channel: "#alerts-orders"
        title: '{{ template "slack.title" . }}'
        text: '{{ template "slack.text" . }}'
        send_resolved: true

  - name: "slack-ops"
    slack_configs:
      - api_url: "https://hooks.slack.com/services/OPS_WEBHOOK"
        channel: "#platform-alerts"
        title: '{{ template "slack.title" . }}'
        text: '{{ template "slack.text" . }}'
        send_resolved: true
```

### 2.3 Alerting Rules (Prometheus Side)

```yaml
# /etc/prometheus/rules/alerting-rules.yaml
groups:
  - name: payment_service_alerts
    rules:

      # ── Service completely down ────────────────────────────────────────────
      - alert: ServiceDown
        expr: up{job="payment-service"} == 0
        for: 1m      # must be down for 1 full minute before firing
                     # prevents flapping on brief network hiccups
        labels:
          severity: critical
          team: payments
          service: payment-service
          environment: "{{ $labels.environment }}"
        annotations:
          summary: "payment-service is down"
          description: "Prometheus cannot scrape {{ $labels.instance }}. Check pod status and network."
          runbook_url: "https://wiki.company.com/runbooks/service-down"
          dashboard_url: "https://grafana.company.com/d/service-overview?var-service=payment-service"

      # ── High error rate ────────────────────────────────────────────────────
      - alert: HighErrorRate
        expr: |
          sum by (service, environment) (
            rate(http_requests_total{status=~"5..", service="payment-service"}[5m])
          )
          / sum by (service, environment) (
            rate(http_requests_total{service="payment-service"}[5m])
          ) > 0.01
        for: 5m       # must be > 1% for 5 consecutive minutes
        labels:
          severity: critical
          team: payments
        annotations:
          summary: "High error rate on {{ $labels.service }}"
          description: "Error rate is {{ $value | humanizePercentage }} (threshold: 1%)"
          runbook_url: "https://wiki.company.com/runbooks/high-error-rate"

      # ── High P99 latency ───────────────────────────────────────────────────
      - alert: HighLatencyP99
        expr: |
          histogram_quantile(
            0.99,
            sum by (le, service) (
              rate(http_request_duration_seconds_bucket{service="payment-service"}[5m])
            )
          ) > 0.3
        for: 5m
        labels:
          severity: warning
          team: payments
        annotations:
          summary: "High P99 latency on {{ $labels.service }}"
          description: "P99 latency is {{ $value | humanizeDuration }} (threshold: 300ms)"

      # ── JVM heap saturation ────────────────────────────────────────────────
      - alert: JVMHeapHigh
        expr: |
          jvm_memory_used_bytes{area="heap", service="payment-service"}
          / jvm_memory_max_bytes{area="heap", service="payment-service"}
          > 0.80
        for: 5m
        labels:
          severity: warning
          team: payments
        annotations:
          summary: "JVM heap usage high on {{ $labels.pod }}"
          description: "Heap is {{ $value | humanizePercentage }} full. GC pressure increasing."

      # ── Pod crash looping ──────────────────────────────────────────────────
      - alert: PodCrashLooping
        expr: |
          rate(kube_pod_container_status_restarts_total{namespace=~"payment-ns|order-ns|notification-ns"}[5m])
          * 60 > 2    # more than 2 restarts per minute
        for: 5m
        labels:
          severity: critical
          team: payments
        annotations:
          summary: "Pod {{ $labels.pod }} is crash-looping"
          description: "Container {{ $labels.container }} is restarting {{ $value | humanize }} times/min"

      # ── Disk space low ────────────────────────────────────────────────────
      - alert: NodeDiskSpaceLow
        expr: |
          (
            node_filesystem_avail_bytes{mountpoint="/", fstype!="tmpfs"}
            / node_filesystem_size_bytes{mountpoint="/", fstype!="tmpfs"}
          ) < 0.10
        for: 10m
        labels:
          severity: warning
          team: platform
        annotations:
          summary: "Low disk space on {{ $labels.instance }}"
          description: "{{ $value | humanizePercentage }} disk space remaining on {{ $labels.mountpoint }}"

  # ── Multi-window SLO burn rate alert ──────────────────────────────────────
  - name: slo_alerts
    rules:
      - alert: SLOBurnRateFast
        expr: |
          (
            sum by (service) (rate(http_requests_total{status=~"5..", service="payment-service"}[1h]))
            / sum by (service) (rate(http_requests_total{service="payment-service"}[1h]))
          ) > 14.4 * 0.001
          and
          (
            sum by (service) (rate(http_requests_total{status=~"5..", service="payment-service"}[5m]))
            / sum by (service) (rate(http_requests_total{service="payment-service"}[5m]))
          ) > 14.4 * 0.001
        for: 2m
        labels:
          severity: critical
          team: payments
        annotations:
          summary: "Fast SLO burn rate on payment-service"
          description: "Burning error budget 14.4x faster than sustainable. Budget exhausted in ~2 days."
```

### 2.4 Silences — Maintenance Windows

```bash
# Create a silence via Alertmanager API (maintenance window)
curl -X POST http://alertmanager:9093/api/v2/silences \
  -H "Content-Type: application/json" \
  -d '{
    "matchers": [
      { "name": "service", "value": "payment-service", "isRegex": false },
      { "name": "environment", "value": "production", "isRegex": false }
    ],
    "startsAt": "2026-07-31T02:00:00Z",
    "endsAt":   "2026-07-31T04:00:00Z",
    "comment": "Scheduled maintenance: EKS node upgrade",
    "createdBy": "alice@company.com"
  }'

# List active silences
curl http://alertmanager:9093/api/v2/silences | jq '.[] | select(.status.state=="active")'

# Delete a silence
curl -X DELETE http://alertmanager:9093/api/v2/silences/SILENCE_ID
```

---

## Part 3: Grafana Deep Dive

### 3.1 Core Concepts

```
Data source: a connection to a metrics backend
  → Prometheus data source: URL, auth, scrape interval
  → Can have multiple data sources (production Prometheus, staging Prometheus)

Dashboard: a collection of panels
  → Saved as JSON (can be version-controlled in git)
  → URL contains dashboard UID: /d/abc123/payment-service-overview

Panel: a single visualisation
  → Types: time series, gauge, stat, table, heatmap, bar chart
  → Each panel has 1+ queries (PromQL expressions)

Variable: a dashboard-level template parameter
  → Dropdown at top of dashboard
  → Example: $service variable → changes all panel queries to show selected service
  → Makes one dashboard work for all services instead of one dashboard per service
```

### 3.2 Dashboard as Code (JSON)

```json
{
  "title": "Payment Service Overview",
  "uid": "payment-overview",
  "tags": ["payment", "sre"],
  "templating": {
    "list": [
      {
        "name": "service",
        "type": "query",
        "datasource": "Prometheus",
        "query": "label_values(up{job='payment-service'}, service)",
        "label": "Service"
      },
      {
        "name": "interval",
        "type": "interval",
        "options": ["1m", "5m", "10m", "30m"],
        "current": {"value": "5m"}
      }
    ]
  },
  "panels": [
    {
      "title": "Request Rate",
      "type": "timeseries",
      "gridPos": { "x": 0, "y": 0, "w": 12, "h": 8 },
      "targets": [
        {
          "expr": "sum by (status) (rate(http_requests_total{service=\"$service\"}[$interval]))",
          "legendFormat": "HTTP {{status}}"
        }
      ],
      "fieldConfig": {
        "defaults": {
          "unit": "reqps",
          "color": { "mode": "palette-classic" }
        }
      }
    },
    {
      "title": "Error Rate",
      "type": "timeseries",
      "gridPos": { "x": 12, "y": 0, "w": 12, "h": 8 },
      "targets": [
        {
          "expr": "sum(rate(http_requests_total{service=\"$service\",status=~\"5..\"}[$interval])) / sum(rate(http_requests_total{service=\"$service\"}[$interval]))",
          "legendFormat": "Error Rate"
        }
      ],
      "fieldConfig": {
        "defaults": {
          "unit": "percentunit",
          "thresholds": {
            "steps": [
              { "color": "green", "value": 0 },
              { "color": "yellow", "value": 0.001 },
              { "color": "red",    "value": 0.01  }
            ]
          }
        }
      }
    }
  ]
}
```

### 3.3 Grafana Provisioning (Infrastructure as Code)

```yaml
# /etc/grafana/provisioning/datasources/prometheus.yaml
apiVersion: 1
datasources:
  - name: Prometheus
    type: prometheus
    url: http://prometheus:9090
    access: proxy
    isDefault: true
    jsonData:
      timeInterval: "15s"    # matches Prometheus scrape_interval
      httpMethod: POST       # POST is more efficient for long queries
    editable: false           # prevent manual UI changes (use config as code)
```

```yaml
# /etc/grafana/provisioning/dashboards/dashboards.yaml
apiVersion: 1
providers:
  - name: "SRE Dashboards"
    folder: "SRE"
    type: file
    disableDeletion: true     # don't delete when file is removed
    updateIntervalSeconds: 30 # reload from disk every 30s
    allowUiUpdates: false      # changes in UI don't persist (code is truth)
    options:
      path: /etc/grafana/dashboards
      foldersFromFilesStructure: true
```

---

## Part 4: Deployment on Kubernetes (kube-prometheus-stack)

### 4.1 Install via Helm (recommended for production)

```bash
# Add Prometheus community Helm chart repository
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

# Create namespace
kubectl create namespace monitoring

# Install kube-prometheus-stack (Prometheus + Alertmanager + Grafana + exporters)
helm install kube-prometheus-stack \
  prometheus-community/kube-prometheus-stack \
  --namespace monitoring \
  --values values-production.yaml \
  --version 55.0.0    # pin version for reproducibility
```

```yaml
# values-production.yaml
prometheus:
  prometheusSpec:
    retention: 30d
    retentionSize: "50GB"
    replicas: 2             # HA: 2 Prometheus instances
    
    resources:
      requests: { cpu: 500m, memory: 2Gi }
      limits:   { cpu: 2000m, memory: 4Gi }
    
    storageSpec:
      volumeClaimTemplate:
        spec:
          storageClassName: gp3
          accessModes: [ReadWriteOnce]
          resources:
            requests:
              storage: 100Gi
    
    # Scrape every 15 seconds
    scrapeInterval: "15s"
    evaluationInterval: "15s"
    
    # Additional scrape configs (beyond what ServiceMonitors provide)
    additionalScrapeConfigs:
      - job_name: "payment-service"
        kubernetes_sd_configs:
          - role: pod
        relabel_configs:
          - source_labels: [__meta_kubernetes_pod_label_app]
            regex: payment-service
            action: keep

alertmanager:
  alertmanagerSpec:
    replicas: 3    # HA: odd number for gossip consensus
    resources:
      requests: { cpu: 100m, memory: 256Mi }
      limits:   { cpu: 500m, memory: 512Mi }
    storage:
      volumeClaimTemplate:
        spec:
          storageClassName: gp3
          resources:
            requests:
              storage: 5Gi

grafana:
  replicas: 2
  persistence:
    enabled: true
    storageClassName: gp3
    size: 10Gi
  
  adminPassword: ""    # use existing secret instead
  admin:
    existingSecret: grafana-admin-secret
    userKey: admin-user
    passwordKey: admin-password
  
  resources:
    requests: { cpu: 250m, memory: 512Mi }
    limits:   { cpu: 1000m, memory: 1Gi }
  
  sidecar:
    dashboards:
      enabled: true
      label: grafana_dashboard    # look for ConfigMaps with this label
    datasources:
      enabled: true
      label: grafana_datasource

nodeExporter:
  enabled: true    # deploys node-exporter DaemonSet

kubeStateMetrics:
  enabled: true    # collects Kubernetes object metrics

# Disable components you don't need (saves resources):
kubeEtcd:
  enabled: false   # managed EKS doesn't expose etcd metrics
kubeControllerManager:
  enabled: false   # managed EKS doesn't expose controller-manager metrics
kubeScheduler:
  enabled: false   # managed EKS doesn't expose scheduler metrics
```

### 4.2 ServiceMonitor — The Kubernetes-Native Scrape Config

```yaml
# ServiceMonitor for payment-service (deployed alongside the service)
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: payment-service-monitor
  namespace: payment-ns
  labels:
    release: kube-prometheus-stack    # must match Prometheus operator selector
spec:
  selector:
    matchLabels:
      app: payment-service
  namespaceSelector:
    matchNames:
      - payment-ns
  endpoints:
    - port: http              # matches the Service's port name
      path: /actuator/prometheus
      interval: 15s
      scrapeTimeout: 10s
      relabelings:
        - sourceLabels: [__meta_kubernetes_pod_name]
          targetLabel: pod
        - sourceLabels: [__meta_kubernetes_namespace]
          targetLabel: namespace
      # Add custom labels to all metrics from this service
      metricRelabelings:
        - action: labeldrop
          regex: "^(kubernetes_.*)$"   # drop excessive k8s labels
```

---

## Part 5: Production Best Practices

### 5.1 High Availability

```
Prometheus HA:
  Run 2 Prometheus instances with IDENTICAL configuration.
  Both scrape ALL targets independently.
  Both evaluate ALL rules independently.
  Use Thanos or Cortex for deduplication and long-term storage.
  
  Why not 2-instance primary/replica like Kafka?
  Prometheus stores time-series data locally — no native replication.
  2 independent instances + deduplication layer = HA without complexity.

Alertmanager HA:
  Run 3 instances with gossip protocol (Alertmanager uses mesh networking).
  Alertmanager instances gossip about what alerts they've sent.
  Prevents duplicate notifications: if instance A pages PagerDuty,
  instances B and C know not to also page PagerDuty for the same alert.
  Configuration: set --cluster.peer=alertmanager-1:9094 etc.
```

### 5.2 Naming Conventions

```promql
# Metric naming convention:
<namespace>_<subsystem>_<metric_name>_<unit>

Good examples:
  http_requests_total              ← namespace: http
  jvm_memory_used_bytes            ← unit suffix: bytes
  process_cpu_seconds_total        ← unit: seconds
  node_disk_io_time_seconds_total  ← full path: node/disk/io_time

Bad examples:
  requests                         ← no namespace, ambiguous
  memory                           ← no unit
  cpu_percent                      ← "percent" not a standard unit (use ratio 0-1)
  http_error_rate_ms               ← wrong unit for a rate

Recording rule naming convention:
  <level>:<metric_name>:<operations>
  Examples:
    job:http_request_rate:rate5m
    instance:node_cpu_saturation:rate5m
    service:http_error_rate:ratio_rate5m
```

### 5.3 Alert Quality Rules

```yaml
# Every alert MUST have:
annotations:
  summary: "Short one-line description of what is happening"
  description: "Longer description with actual values, context, and direction"
  runbook_url: "Link to runbook with diagnosis and fix steps"
  dashboard_url: "Link to Grafana dashboard for this service"

# Every alert MUST have:
labels:
  severity: "critical|warning|info"   # drives routing and escalation
  team: "payments|orders|platform"    # drives routing to team channel
  environment: "production|staging"   # drives routing and threshold

# FOR durations:
for: 5m   # ALWAYS set a for duration
           # Prevents alerts on momentary spikes
           # "for: 0m" means fire immediately → flapping, alert fatigue

# Alert names: action-oriented, not metric-oriented
# Good:
#   HighErrorRate, ServiceDown, JVMHeapSaturated, DiskSpaceLow
# Bad:
#   http_requests_total_5xx_alert, jvm_memory_bytes_over_threshold
```

---

## Part 6: Day-to-Day SRE Operations

### 6.1 Debugging a Firing Alert

```bash
# 1. Get alert details from Alertmanager UI or API
curl http://alertmanager:9093/api/v2/alerts | jq '.[] | select(.labels.alertname=="HighErrorRate")'

# 2. Run the alert's PromQL expression in Prometheus UI or CLI
curl -G "http://prometheus:9090/api/v1/query" \
  --data-urlencode 'query=sum by (service)(rate(http_requests_total{status=~"5..",service="payment-service"}[5m]))/sum by (service)(rate(http_requests_total{service="payment-service"}[5m]))' \
  | jq '.data.result'

# 3. Check raw scrape output from the target
curl http://payment-service:8080/actuator/prometheus | grep http_requests_total

# 4. Check if a specific pod is causing errors (drill down by pod)
curl -G "http://prometheus:9090/api/v1/query" \
  --data-urlencode 'query=sum by (pod)(rate(http_requests_total{status=~"5..",service="payment-service"}[5m]))' \
  | jq '.data.result | sort_by(-.value[1]) | .[0:5]'

# 5. Check Prometheus target health
curl http://prometheus:9090/api/v1/targets | jq '.data.activeTargets[] | select(.labels.service=="payment-service") | {health, lastError}'
```

### 6.2 Creating a Silence for Planned Maintenance

```bash
# Via amtool (Alertmanager CLI)
amtool silence add \
  --alertmanager.url=http://alertmanager:9093 \
  --author="alice@company.com" \
  --comment="Planned EKS upgrade 02:00-04:00 JST" \
  --duration=2h \
  service="payment-service" \
  environment="production"

# List active silences
amtool silence query --alertmanager.url=http://alertmanager:9093

# Expire a silence early
amtool silence expire --alertmanager.url=http://alertmanager:9093 SILENCE_ID
```

### 6.3 Checking Prometheus Rule Evaluation

```bash
# Check if rules are loaded correctly
curl http://prometheus:9090/api/v1/rules | jq '.data.groups[].rules[] | select(.type=="alerting") | {name, state, health}'

# Check which alerts are currently FIRING
curl http://prometheus:9090/api/v1/alerts | jq '.data.alerts[] | select(.state=="firing") | {labels, annotations, activeAt}'

# Validate rules before applying (promtool)
promtool check rules /etc/prometheus/rules/*.yaml

# Validate Prometheus config before applying
promtool check config /etc/prometheus/prometheus.yml

# Test alert rules against historical data
promtool test rules /etc/prometheus/tests/alert-tests.yaml
```

### 6.4 Alert Test File (promtool)

```yaml
# /etc/prometheus/tests/alert-tests.yaml
rule_files:
  - /etc/prometheus/rules/alerting-rules.yaml

tests:
  - interval: 1m
    input_series:
      # Simulate high error rate
      - series: 'http_requests_total{service="payment-service",status="500"}'
        values: '0+10x10'    # increases by 10 every minute for 10 minutes
      - series: 'http_requests_total{service="payment-service",status="200"}'
        values: '0+100x10'   # increases by 100 every minute

    alert_rule_test:
      - eval_time: 5m
        alertname: HighErrorRate
        exp_alerts:
          - exp_labels:
              severity: critical
              service: payment-service
            exp_annotations:
              summary: "High error rate on payment-service"
```

---

## Summary: Signal Table for payment-service

| Signal | PromQL | Alert | Threshold |
|--------|--------|-------|-----------|
| Service down | `up{job="payment-service"} == 0` | ServiceDown | immediate |
| Error rate | `rate(5xx)/rate(total)` | HighErrorRate | > 1% for 5m |
| P99 latency | `histogram_quantile(0.99, ...)` | HighLatencyP99 | > 300ms for 5m |
| JVM heap | `used/max heap` | JVMHeapHigh | > 80% for 5m |
| Pod restarts | `rate(restarts[5m]) * 60` | PodCrashLooping | > 2/min for 5m |
| CPU saturation | `1 - rate(cpu_idle)` | NodeCPUHigh | > 80% for 10m |
| Disk space | `avail/size` | NodeDiskSpaceLow | < 10% for 10m |
| SLO burn | `error_rate / (1 - slo_target)` | SLOBurnRateFast | > 14.4× for 2m |
