# Complete Project — java-3envs-dynatrace (All Files)

> All existing files from `38_java-3envs-dynatrace` plus the 4 missing workflow files from `4_missing-workflows`. This is the complete, production-ready project.

---

## Complete File Tree

```
java-3envs-dynatrace/
│
├── .github/workflows/
│   ├── terraform-infra.yaml                  ← NEW: EKS/VPC/IAM for all 3 envs
│   ├── terraform-dynatrace-dev.yaml          ← EXISTS
│   ├── terraform-dynatrace-staging.yaml      ← EXISTS
│   ├── terraform-dynatrace-production.yaml   ← EXISTS
│   ├── payment-service-ci.yaml               ← NEW: test→build→dev→staging→prod
│   ├── order-service-ci.yaml                 ← NEW: same pattern
│   └── notification-service-ci.yaml          ← NEW: same pattern
│
├── terraform/
│   ├── modules/
│   │   ├── dynatrace/
│   │   │   ├── main.tf        ← DT module: management zones, alerts, SLOs, synthetics
│   │   │   └── variables.tf   ← all threshold variables
│   │   ├── eks/
│   │   │   ├── main.tf        ← EKS cluster, node groups, add-ons
│   │   │   └── variables.tf
│   │   └── vpc/
│   │       ├── main.tf        ← VPC, subnets, NAT gateways, S3 endpoint
│   │       └── variables.tf
│   └── environments/
│       ├── dev/main.tf         ← calls dynatrace module + EKS + VPC with dev values
│       ├── staging/main.tf     ← same for staging
│       └── production/main.tf  ← same for production
│
├── gitops/
│   ├── dev/
│   │   ├── bootstrap/root-app-dev.yaml                    ← apply once: ArgoCD manages gitops/dev/
│   │   ├── namespaces/namespaces.yaml                     ← wave -1: 5 namespaces + labels
│   │   ├── networking/aws-load-balancer-controller.yaml   ← wave  1: ALB controller
│   │   ├── networking/external-dns.yaml                   ← wave  1: ExternalDNS
│   │   ├── secrets/cluster-secret-store.yaml              ← wave  2: ESO + ClusterSecretStore
│   │   ├── monitoring/dynatrace/dynatrace-operator.yaml   ← wave  3: DT Operator + DynaKube
│   │   ├── app/payment-service/payment-service.yaml       ← wave  8: ArgoCD Application
│   │   ├── app/order-service/order-service.yaml           ← wave  8
│   │   └── app/notification-service/notification-service.yaml ← wave 8
│   ├── staging/  (identical structure, staging account values)
│   └── production/ (identical structure, production account values)
│
├── charts/
│   ├── namespaces/
│   │   ├── Chart.yaml
│   │   ├── values.yaml
│   │   └── templates/namespace.yaml
│   ├── payment-service/
│   │   ├── Chart.yaml
│   │   ├── values.yaml          ← PRODUCTION defaults (replicas:3, Xmx:1024m)
│   │   ├── values-dev.yaml      ← DEV overrides (replicas:1, Xmx:256m, jdwp)
│   │   ├── values-staging.yaml  ← STAGING overrides (replicas:2, Xmx:512m)
│   │   └── templates/
│   │       ├── deployment.yaml
│   │       ├── external-secret.yaml
│   │       ├── hpa.yaml
│   │       ├── pdb.yaml
│   │       ├── ingress.yaml
│   │       ├── service.yaml
│   │       └── serviceaccount.yaml
│   ├── order-service/        (same 3-values + 7-template structure)
│   └── notification-service/ (same structure)
│
└── services/
    ├── payment-service/Dockerfile
    ├── order-service/Dockerfile
    └── notification-service/Dockerfile
```

---

## How All 8 Workflows Connect — Trigger Map

```
Git push to main (or PR raised)
           │
           ├── changed: terraform/environments/dev/**
           │   changed: terraform/modules/eks/**
           │   changed: terraform/modules/vpc/**           ──► terraform-infra.yaml (NEW)
           │                                                    matrix: plan dev+staging+prod in parallel
           │                                                    apply: dev → staging → prod (sequential)
           │                                                    schedule daily: drift detection
           │
           ├── changed: terraform/environments/dev/**
           │   changed: terraform/modules/dynatrace/**     ──► terraform-dynatrace-dev.yaml
           │
           ├── changed: terraform/environments/staging/**
           │   changed: terraform/modules/dynatrace/**     ──► terraform-dynatrace-staging.yaml
           │
           ├── changed: terraform/environments/production/**
           │   changed: terraform/modules/dynatrace/**     ──► terraform-dynatrace-production.yaml
           │                                                    (+ manual approval gate)
           │
           ├── changed: services/payment-service/**
           │   changed: charts/payment-service/**          ──► payment-service-ci.yaml (NEW)
           │                                                    test → dev → smoke → staging → k6 → prod
           │
           ├── changed: services/order-service/**
           │   changed: charts/order-service/**            ──► order-service-ci.yaml (NEW)
           │
           ├── changed: services/notification-service/**
           │   changed: charts/notification-service/**     ──► notification-service-ci.yaml (NEW)
           │
           └── changed: gitops/**                          ──► NOTHING (ArgoCD watches directly)
```

---

## E2E Flow — Code Push to Production (Complete Picture)

```
1. terraform-infra.yaml (one-time + on infra change)
   terraform apply → EKS cluster, VPC, IRSA roles, ECR repos created
   
2. Bootstrap ArgoCD (one-time manual per env):
   kubectl apply -f gitops/<env>/bootstrap/root-app-<env>.yaml
   
3. ArgoCD sync waves (automated):
   wave -1: namespaces (payment-ns, order-ns, notification-ns, dynatrace, external-secrets)
            labels: team=X, environment=Y  → Dynatrace auto-tagging reads these
   wave  1: ALB controller, ExternalDNS
   wave  2: ESO + ClusterSecretStore → can now pull from Secrets Manager
   wave  3: DT Operator + ExternalSecret (DT tokens) + DynaKube
            → OneAgent DaemonSet starts on every node
            → ActiveGate pod routes metrics to DT tenant
   wave  8: 3 Java services deployed via Helm
            → pods labelled team= and environment= → DT management zones capture them
   
4. terraform-dynatrace-<env>.yaml (on DT config change):
   terraform apply → management zones, alerts, SLOs, synthetics, notifications in DT
   
5. Developer pushes Java code:
   services/payment-service/src/... changed
   → payment-service-ci.yaml triggers:
     job 1: ./gradlew test jacocoTestReport jacocoTestCoverageVerification
            → JaCoCo enforces ≥70% line coverage
            → JUnit XML published to GitHub PR check
     
     job 2: build-and-deploy-dev (push events only)
            → Java 21 + Gradle build
            → Docker buildx (linux/amd64 + linux/arm64)
            → push to dev ECR: :${{ github.sha }} + :latest-dev
            → Trivy scan CRITICAL/HIGH → fail if found
            → sed image tag in gitops/dev/app/payment-service/payment-service.yaml
            → git commit "[skip ci]" + push
            → kubectl rollout status --timeout=8m
     
     job 3: smoke-test-dev
            → curl /actuator/health/liveness (200 required)
            → curl /actuator/health/readiness (200 required)
            → POST /api/v1/payments → assert status=="created"
     
     job 4: promote-to-staging
            → pull from dev ECR, re-tag, push to staging ECR (cross-account)
            → sed tag in gitops/staging/app/payment-service/payment-service.yaml
            → git commit "[skip ci]" + push
            → kubectl rollout status --timeout=10m (staging cluster)
     
     job 5: test-staging (k6 load test)
            → k6 --vus 50 --duration 3m against staging
     
     job 6: promote-to-production (environment: production → MANUAL APPROVAL)
            → pull from staging ECR, re-tag, push to prod ECR
            → sed tag in gitops/production/app/payment-service/payment-service.yaml
            → git commit "[skip ci]" + push
            → kubectl rollout status --timeout=12m (prod cluster)
     
     job 7: verify-production
            → sleep 60 → curl liveness + readiness
            → IF FAILS: auto-rollback via git log previous tag → revert → push
   
6. ArgoCD (running in each cluster) detects each gitops commit:
   → re-renders Helm chart with new image tag
   → rolling update: new pod starts → passes probes → old pod terminates
   → maxUnavailable: 0 = zero-downtime at every step
```

---

## The 4 New Workflow Files

See separate artifact files:
- `terraform-infra.yaml`
- `payment-service-ci.yaml`
- `order-service-ci.yaml`
- `notification-service-ci.yaml`

---

## Key Design Decisions Across All 8 Workflows

### Why `github.sha` as IMAGE_TAG (not `latest`)

```
Every git commit has a unique 40-char SHA (e.g., "a1b2c3d4e5f6...").
Used as image tag: 123456789010.dkr.ecr.../payment-service:a1b2c3d4

Benefits:
  - Traceability: "what code is running in prod?" → read tag → find commit in git
  - No overwrites: each build produces a unique tag, never collides
  - Rollback: previous SHA tag still exists in ECR, revert to it immediately
  - Identical image flows through all 3 ECRs with the same SHA tag
  
Convenience alias: :latest-dev also pushed (for docker pull convenience)
but ArgoCD uses the SHA tag — this is the source of truth
```

### Why separate ECR per AWS account

```
dev ECR:     123456789010.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
staging ECR: 123456789011.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service
prod ECR:    123456789012.dkr.ecr.ap-northeast-1.amazonaws.com/payment-service

Cross-account promotion: CI pulls from dev ECR → re-tags → pushes to staging ECR
Same SHA tag travels through all 3 accounts, proving the same bits reach production

Security: prod ECR write permission requires arn:aws:iam::123456789012:role/...
A dev engineer with dev account access cannot push to prod ECR directly
The promotion path through CI is the only way into production
```

### Why `[skip ci]` in every gitops commit

```
CI commits new image tag to gitops/dev/app/payment-service/payment-service.yaml
That commit triggers the payment-service-ci.yaml workflow (push to main)
That workflow commits a new tag → triggers again → infinite loop

[skip ci] in the commit message:
  git commit -m "chore(deploy-dev): payment-service=abc1234 [skip ci]"
  GitHub Actions reads this → does NOT trigger any workflows for this commit
  Loop broken.
```

### Why `gitops/**` triggers NO workflow

```
ArgoCD polls the Git repo every 3 minutes and auto-syncs any changes under gitops/<env>/.
A GitHub Actions workflow for gitops would:
  - Add latency (90+ seconds to start a runner vs ArgoCD's 3-min poll)
  - Duplicate work ArgoCD already does
  - Create race conditions between CI and ArgoCD

ArgoCD IS the gitops workflow. No separate CI needed.
```

### Why `terraform-infra.yaml` uses matrix but `terraform-dynatrace-*.yaml` uses separate files

```
Infrastructure (EKS/VPC/IAM):
  Changes affect all 3 environments equally (EKS version upgrade, VPC CIDR change)
  You want ONE PR that shows ALL 3 environment plans simultaneously
  Matrix: one file, parallel plans, sequential applies
  
Dynatrace config:
  Changes are often environment-specific (adjust dev threshold, not prod)
  A dev DT change should NOT trigger a prod DT plan
  Separate files: independent path triggers, dev changes stay in dev pipeline
```

---

## ArgoCD Sync Wave Order (Why This Order Matters)

```
wave -1  NAMESPACES
  Creates: payment-ns, order-ns, notification-ns, dynatrace, external-secrets
  Why first: every other resource is deployed INTO a namespace
             Kubernetes rejects resources that reference a non-existent namespace

wave  1  NETWORKING
  Creates: ALB Controller, ExternalDNS
  Why before apps: Ingress resources are applied at wave 8
                   If ALB controller isn't running, Ingress stays Pending forever

wave  2  SECRETS INFRASTRUCTURE
  Creates: ESO (External Secrets Operator) + ClusterSecretStore
  Why before wave 3: DynaKube's ExternalSecret (wave 3) needs ESO to process it
                     If ESO isn't running, ExternalSecret is just YAML → no K8s Secret created

wave  3  DYNATRACE
  Creates: DT Operator (Helm) + ExternalSecret (fetches DT tokens) + DynaKube
  Why before apps: OneAgent starts as DaemonSet on each node
                   When app pods start (wave 8), OneAgent already running → instruments immediately
                   
wave  8  APPLICATIONS
  Creates: payment-service, order-service, notification-service (Helm)
  Why last: all infrastructure (namespaces, networking, secrets, monitoring) must be ready
            Pods can now: route through ALB, pull secrets, be monitored by OneAgent
```

---

## Per-Environment Differences — Quick Reference

### Workflows

| | dev | staging | production |
|---|---|---|---|
| terraform-infra apply | sequential (after staging) | sequential (after dev) | manual approval gate |
| terraform-dynatrace apply | auto on merge | auto on merge | manual approval gate |
| service CI deploy | auto | auto | manual approval gate |
| Trivy scan | CRITICAL+HIGH | CRITICAL+HIGH | CRITICAL+HIGH |
| k6 load test | none | 50 VUs 3 min | none (smoke test only) |
| Auto-rollback | no | no | yes |

### Helm values (payment-service)

| | dev | staging | production |
|---|---|---|---|
| replicas | 1 | 2 | 3 |
| Xmx | 256m | 512m | 1024m |
| CPU limit | 500m | 800m | 1000m |
| Memory limit | 512Mi | 768Mi | 1Gi |
| PDB | disabled | minAvailable: 1 | minAvailable: 2 |
| HPA max | 3 | 8 | 20 |
| LOG_LEVEL | DEBUG | INFO | WARN |
| pullPolicy | Always | IfNotPresent | IfNotPresent |
| jdwp debug port | yes (5005) | no | no |
| topologySpread | ScheduleAnyway | ScheduleAnyway | DoNotSchedule |

### Dynatrace thresholds (payment-service)

| | dev | staging | production |
|---|---|---|---|
| SLO target | 90% | 95% | 99.9% |
| Traffic min | 0 (disabled) | 2 req/min | 10 req/min |
| Error rate | 10% | 1% | 0.1% |
| Latency P99 | 2000ms | 800ms | 300ms |
| JVM heap | 85% | 78% | 70% |
| Pod restarts | 5 | 3 | 2 |
| PagerDuty CRITICAL | no | no | yes |
| PagerDuty HIGH | no | yes | yes |
| Slack WARNING | yes | yes | yes |
| Synthetic locations | Tokyo only | Tokyo+Singapore | Tokyo+Singapore |
