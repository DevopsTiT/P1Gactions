# Glossary — Complete Project (All 8 Workflows)

Every term, tool, and concept used in main.md and the 4 new workflow files.

---

**GitHub Actions workflow**
A YAML file in `.github/workflows/` that defines automated jobs triggered by Git events (push, PR, schedule). Each job runs in a fresh virtual machine. Jobs in the same workflow can run in parallel or sequentially via `needs:`.

**`on.paths`**
A GitHub Actions trigger filter. The workflow only runs when the push/PR changes files matching the listed paths. `paths: ['services/payment-service/**']` means the workflow is skipped entirely if no files under that path changed. Prevents unrelated changes from triggering unnecessary builds.

**`needs:`**
A GitHub Actions dependency declaration. `needs: test` means "this job runs only after the `test` job completes successfully." Creates a sequential chain without a single monolithic job. If `test` fails, `build-and-deploy-dev` never starts.

**`environment: production` (GitHub Actions)**
A named deployment environment that can have REQUIRED REVIEWERS configured. When a job has `environment: production`, the pipeline pauses and waits for a human to click Approve in GitHub UI before the job runs. Used on all production-affecting jobs: DT apply, infra apply, promote-to-production.

**`fail-fast: false` (matrix)**
Matrix strategy setting. By default, if one matrix job fails, GitHub cancels all other in-progress matrix jobs. `fail-fast: false` lets all jobs complete even if one fails. Used in the infra plan matrix so all 3 env plans run even if dev plan fails — reviewer can see all 3 outputs.

**Matrix strategy**
GitHub Actions feature that runs the same job definition multiple times with different input values. `matrix: env: [dev, staging, production]` creates 3 parallel jobs. Used in `terraform-infra.yaml` to plan all 3 environments simultaneously on PR without duplicating the job definition.

**`github.sha`**
A built-in GitHub Actions variable containing the full 40-character git commit SHA of the push that triggered the workflow. Used as the Docker image tag — guarantees each build has a unique, traceable, immutable tag. Running `git show a1b2c3d4` instantly shows what code is in that image.

**ECR (Elastic Container Registry)**
AWS's managed Docker image registry. Each environment (dev/staging/production) has its own ECR in its own AWS account. Images are promoted by pulling from one ECR and pushing to the next — never by rebuilding. The same SHA tag travels through all 3 ECRs, proving the same bits reach production.

**Cross-account ECR promotion**
The process of copying a Docker image from one AWS account's ECR to another. Requires two `configure-aws-credentials` steps: one to authenticate to the source account (read), one to the destination account (write). The image is `docker pull`ed from source, `docker tag`ged, and `docker push`ed to destination.

**`docker buildx` (multi-arch)**
Docker's extended build tool that can produce images for multiple CPU architectures in one build. `platforms: linux/amd64,linux/arm64` creates one image that works on both Intel/AMD and ARM (Graviton) nodes. EKS clusters with Graviton nodes for cost savings require ARM support in the image.

**`cache-from: type=gha` / `cache-to: type=gha,mode=max`**
Docker layer caching integrated with GitHub Actions cache. On first build: all Docker layers are built fresh and cached. On subsequent builds: unchanged layers (base image, dependencies) are pulled from cache instead of rebuilt. Reduces build time from 5-8 minutes to 60-90 seconds for unchanged layers.

**Trivy (vulnerability scanner)**
An open-source Docker image security scanner by Aqua Security. Checks the image against CVE databases for known vulnerabilities. `severity: 'CRITICAL,HIGH'` and `exit-code: '1'` means: if any CRITICAL or HIGH CVE is found, the CI step fails and the image is never deployed to any environment.

**`ignore-unfixed: true` (Trivy)**
Skip CVEs that have no fix available yet. Without this, Trivy fails the build for vulnerabilities in base OS packages that cannot be patched (no fix released). `ignore-unfixed: true` focuses on actionable CVEs only.

**`sed -i "s|tag: \".*\"|tag: \"$TAG\"|"`**
A Unix stream editor command that replaces text in-place. In context: searches the gitops YAML file for any line matching `tag: "anything"` and replaces it with `tag: "new-sha"`. The `|` delimiter (instead of `/`) avoids escaping the `/` characters in image repository paths.

**`git diff --staged --quiet || git commit`**
A guard pattern that only commits if there are staged changes. `git diff --staged --quiet` exits 0 if no staged changes, non-zero if changes exist. `||` (OR): runs the right side only if the left side fails (non-zero). So: "if there are staged changes, commit them." Without this, an empty commit (no image tag change, e.g., re-running CI) would fail.

**`[skip ci]`**
A special string in a git commit message that tells GitHub Actions to not trigger any workflows for that commit. CI writes updated image tags to gitops YAML files and commits them. Without `[skip ci]`, that commit would trigger the CI workflow again → infinite loop of builds and deploys.

**`kubectl rollout status --timeout=8m`**
Kubernetes command that watches a Deployment rollout and exits 0 when all replicas are updated and healthy, or exits 1 if the timeout is reached. The timeout values differ per service and environment: prod payment-service gets 12m (JVM startup + Spring Boot on Graviton), notification-service gets 8m (simpler app, faster startup).

**`aws eks update-kubeconfig`**
AWS CLI command that writes a kubeconfig entry for the specified EKS cluster to `~/.kube/config`. Allows `kubectl` to connect to that cluster. The `--alias` flag gives the context a short name (dev, staging, prod) used in `--context dev` flags.

**Auto-rollback**
The `verify-production` job runs smoke tests after every production deploy. If the smoke test fails (`steps.smoke.outcome == 'failure'`), a shell script reads the PREVIOUS image tag from `git log`, updates the gitops YAML back to that tag, commits with `[skip ci]`, and pushes. ArgoCD detects the revert commit and redeploys the old version within ~3 minutes.

**`git log --oneline -- <file>`**
Shows the commit history for a specific file. `NR==2{print $1}` (awk) gets the SECOND line — the commit before the current one. `xargs git show | grep 'tag:'` extracts the image tag from that commit's diff. This is how auto-rollback finds the previously-working image tag without hardcoding it anywhere.

**`fetch-depth: 0` (actions/checkout)**
By default, `actions/checkout@v4` does a shallow clone (only the latest commit). `fetch-depth: 0` clones the full git history. Required for the auto-rollback script — it needs `git log` to show previous commits on the gitops file. Without full history, `git log` shows only the current commit.

**SQS DLQ (Dead Letter Queue)**
An Amazon SQS queue that receives messages that failed to be processed after N retries. If notification-service fails to process a message (e.g., invalid payload, downstream failure), SQS moves it to the DLQ. A non-empty DLQ means something is broken in the notification pipeline. The smoke test checks `ApproximateNumberOfMessages = 0`.

**`permissions: { id-token: write, contents: write }`**
GitHub Actions job-level permissions. `id-token: write` is required for OIDC AWS authentication — GitHub can request an ID token to exchange for AWS STS credentials. `contents: write` is required to push git commits (gitops tag updates). `pull-requests: write` is required to post plan comments on PRs.

**OIDC AWS authentication**
The `aws-actions/configure-aws-credentials@v4` action exchanges a GitHub OIDC token for temporary AWS STS credentials (access key + secret key + session token). No long-lived AWS credentials stored in GitHub Secrets. Credentials expire after the job. Each environment uses a different IAM role ARN (`arn:aws:iam::<account>:role/...`).

**`plan -detailed-exitcode`**
A Terraform flag that changes exit codes: 0 = success, no changes; 1 = error; 2 = success, changes pending. Used in drift detection — after `terraform plan -refresh-only -detailed-exitcode`, exit code 2 means "real AWS state differs from Terraform state" (drift detected). Exit code 0 = no drift.

**`plan -refresh-only`**
Terraform flag that only refreshes state from real AWS — it does NOT plan any configuration changes. Used for drift detection: shows what changed in AWS since the last `terraform apply`, without showing "what would happen if I applied my .tf files." Isolates real-world changes from config changes.

**Drift detection**
A scheduled CI job (runs daily via cron) that runs `terraform plan -refresh-only` to detect if real AWS resources have diverged from Terraform state. Common cause: someone modified infrastructure via AWS Console or CLI. Creates a GitHub Issue automatically when drift is found, with the full diff as the issue body.

**`cron: '0 17 * * *'`**
A GitHub Actions schedule trigger using cron syntax. `0 17 * * *` = "at 17:00 UTC every day" = 02:00 JST (Japan Standard Time, UTC+9). Running at 2am Tokyo time means the drift detection job runs during low-traffic hours, and any GitHub Issue created will be visible to engineers at the start of the workday.

**`actions/github-script@v7`**
A GitHub Actions action that runs JavaScript code with access to the GitHub API. Used to post Terraform plan output as a PR comment (`github.rest.issues.createComment`) and to create GitHub Issues for drift alerts (`github.rest.issues.create`). Avoids needing a separate API script file.

**`JaCoCo`**
Java Code Coverage library (Gradle plugin). Measures what percentage of source code lines are executed by tests. `jacocoTestCoverageVerification` enforces a minimum: if line coverage is below 70%, the Gradle build fails. CI never builds a Docker image for code that isn't sufficiently tested.

**`./gradlew test jacocoTestReport jacocoTestCoverageVerification --no-daemon`**
The complete test command. `test`: runs JUnit tests. `jacocoTestReport`: generates coverage report XML. `jacocoTestCoverageVerification`: checks coverage meets the minimum threshold. `--no-daemon`: disables the Gradle daemon (which persists between builds) — safer in CI where each runner is ephemeral.

**`mikepenz/action-junit-report@v4`**
A GitHub Actions action that reads JUnit XML test result files and annotates the PR with test failures directly in the Files Changed view. Engineers see exactly which lines failed without opening build logs. `if: always()` ensures this runs even when tests fail (so you see the failure annotations).

**Gradle cache (`actions/cache@v4`)**
Caches the Gradle dependency cache directory between CI runs. On first run: all dependencies downloaded from Maven Central (~200-300MB). On subsequent runs: cache hit, no download needed. Reduces job time from 3-4 minutes (download) to 30 seconds (cache restore).

**`docker/setup-buildx-action@v3`**
Installs and configures Docker Buildx — the extended Docker build engine required for multi-arch builds and advanced caching. Must be run before `docker/build-push-action@v5`. Without this, Docker can only build for the runner's native architecture (amd64).

**k6**
An open-source load testing tool. Runs a JavaScript test script with a specified number of virtual users (VUs) for a duration. `--vus 50 --duration 3m`: 50 concurrent users sending requests for 3 minutes. The k6 script defines pass/fail thresholds (error rate, P95 latency) — k6 exits non-zero if thresholds are violated, failing the CI job.

**Virtual Users (VUs)**
k6's concept of concurrent users. 50 VUs means 50 goroutines simultaneously sending HTTP requests. Each VU runs the test script in a loop for the test duration. 50 VUs × 3 minutes typically produces thousands of requests to the staging service.

**`notify.dev.company.com` / `notify.staging.company.com` / `notify.company.com`**
The different hostnames for notification-service across environments. Created automatically by ExternalDNS watching Ingress resources. The Ingress `host:` value in the Helm values file determines the hostname. Dev has `notify.dev.company.com`, staging has `notify.staging.company.com`, production has `notify.company.com`.

**`ApproximateNumberOfMessages` (SQS)**
An SQS queue attribute that returns an approximate count of messages in the queue. "Approximate" because SQS is distributed — the count may not be perfectly consistent for milliseconds. For the DLQ health check, any non-zero value indicates failures that need investigation.

**`github-actions-sqs-read` IAM role**
An IAM role with `sqs:GetQueueAttributes` permission. Used by the notification-service smoke test to check DLQ depth. A narrow-permission role — can only read queue attributes, not send or receive messages. Follows the principle of least privilege.

**`working-directory`**
A GitHub Actions job/step setting that changes the shell's working directory for that step. `working-directory: services/payment-service` means `./gradlew test` runs from inside `services/payment-service/`, where `build.gradle` is located.

**`if: failure() && steps.smoke.outcome == 'failure'`**
A GitHub Actions conditional that runs a step ONLY when a previous step fails in a specific way. `failure()` = the job is in a failure state. `steps.smoke.outcome == 'failure'` = specifically the smoke test step failed (not a different earlier step). Without `steps.smoke.outcome`, the rollback might run when the wrong step fails (e.g., a git push failure in promote-to-production).
