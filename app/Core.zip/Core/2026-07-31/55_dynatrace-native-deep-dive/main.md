# Dynatrace Without OTEL — Logic Flow Deep Dive (SRE Perspective)

> **Focus:** How every piece of Dynatrace works end-to-end using only OneAgent (no OTEL). Full logic chains: how data flows from pod → DT tenant → alert → your Slack/PagerDuty. Every "why" explained. No library changes, no env vars beyond `spring.application.name`.

---

## The Complete Flow Map

```
┌────────────────────────────────────────────────────────────────────────────┐
│  EKS CLUSTER                                                               │
│                                                                            │
│  ┌──────────────┐   ┌──────────────┐   ┌──────────────────────┐           │
│  │payment-service│   │order-service │   │notification-service  │           │
│  │   pod        │   │   pod        │   │     pod              │           │
│  │  Spring Boot │   │  Spring Boot │   │   Spring Boot        │           │
│  └──────┬───────┘   └──────┬───────┘   └──────────┬───────────┘           │
│         │                  │                        │                      │
│   ┌─────▼──────────────────▼────────────────────────▼─────────────────┐   │
│   │  OneAgent DaemonSet Pod (one per NODE — not per pod)              │   │
│   │                                                                   │   │
│   │  What it does:                                                    │   │
│   │  1. Attaches to every JVM via JVMTI                               │   │
│   │  2. Injects x-dynatrace header on every outgoing HTTP call       │   │
│   │  3. Reads x-dynatrace header on every incoming HTTP call         │   │
│   │  4. Reads /proc/<pid>/ for CPU + memory RSS                      │   │
│   │  5. Reads container log files (/var/log/containers/*.log)        │   │
│   │  6. Reports K8s pod/deployment metadata to ActiveGate            │   │
│   └─────────────────────────────┬─────────────────────────────────────┘   │
│                                 │ sends metrics + traces + logs           │
│   ┌─────────────────────────────▼─────────────────────────────────────┐   │
│   │  ActiveGate (Deployment, 2 replicas in prod spread across AZs)   │   │
│   │                                                                   │   │
│   │  Three jobs:                                                      │   │
│   │  1. Relay: receives from OneAgent, batches, forwards to DT       │   │
│   │  2. K8s API monitor: polls K8s API for workload state            │   │
│   │  3. Log analytics: processes + forwards logs to DT tenant        │   │
│   └─────────────────────────────┬─────────────────────────────────────┘   │
└─────────────────────────────────┼──────────────────────────────────────────┘
                                  │ HTTPS to DT SaaS tenant
                                  ▼
┌────────────────────────────────────────────────────────────────────────────┐
│  DYNATRACE TENANT (SaaS)                                                   │
│                                                                            │
│  Receives → Stores → Evaluates metric events → Creates Problems           │
│  Evaluates SLOs → Fires notifications (PagerDuty / Slack)                 │
│  Runs Synthetics (HTTP checks from Tokyo/Singapore)                        │
└────────────────────────────────────────────────────────────────────────────┘
```

---

## Part 1 — How OneAgent Knows About Your Java Service

### Step 1: Process detection

When a pod starts on a node, the OS kernel logs the new process. OneAgent monitors process events:

```
Node filesystem view that OneAgent reads:
  /proc/12345/exe        → /usr/bin/java (confirms: it's a JVM)
  /proc/12345/cmdline    → java -jar payment-service.jar
  /proc/12345/environ    → environment variables (reads spring.application.name)
  /proc/12345/net/       → open sockets (finds port 8080 listening)
```

OneAgent identifies: "this is a JVM, it listens on port 8080, spring.application.name = payment-service."

### Step 2: JVMTI attachment

```
Timeline after JVM process starts:

T+0s:    OS creates JVM process
T+0.1s:  OneAgent detects new java process via inotify on /proc
T+0.2s:  OneAgent calls: attach_to_jvm(pid=12345)
          → Uses JVMTI dynamic attach mechanism (jattach tool equivalent)
          → JVM acknowledges: "agent attached"
T+0.3s:  OneAgent agent code runs INSIDE the JVM
          → Instruments Spring MVC dispatcher servlet
          → Instruments RestTemplate / WebClient
          → Instruments HikariCP connection pool
          → Instruments Hibernate SQL executor
          → Hooks GC notification listener (gets called on every GC event)
T+0.5s:  First request arrives → OneAgent intercepts it at DispatcherServlet
          → Creates span: start_time, endpoint, thread_id
T+0.5+Xms: Request completes → OneAgent records: duration, status code, exception (if any)
          → Sends span data to ActiveGate
```

**Why JVMTI, not a Java agent in the jar:** JVMTI is an OS-level attach — no JAR modification, no build.gradle change, no classpath entry. OneAgent attaches from OUTSIDE the JVM. The application developer never knows it happened.

### Step 3: Service entity creation

DT creates a "Service" entity the first time it sees traffic for a process. The service name is determined in this priority order:

```
Priority 1: OTEL_SERVICE_NAME env var (not used in this setup)

Priority 2: spring.application.name property
  Source: application.yaml → spring.application.name: payment-service
  OneAgent reads this from the JVM's system properties via JVMTI
  Result: service entity named "payment-service"
  
Priority 3: Inferred from jar filename
  /app/payment-service-0.0.1-SNAPSHOT.jar
  DT strips version suffix → "payment-service"
  (less reliable, may include version string)
  
Priority 4: Process name (fallback)
  "java" (useless — all services would be named "java")

In this project: spring.application.name = "payment-service" (in application.yaml)
→ Service entity = "payment-service"
→ Matches Terraform services map key = "payment-service"
→ All metric events, SLOs, synthetics bind to this entity correctly ✅
```

---

## Part 2 — How Distributed Traces Work Without OTEL

### The x-dynatrace header mechanism

```
Scenario: order-service calls payment-service

order-service pod (on Node A, OneAgent attached):
  
  1. Application code calls:
     restTemplate.postForObject("http://payment-service/api/v1/payments", req, Map.class)
     
  2. OneAgent intercepts the RestTemplate.execute() method (via JVMTI bytecode injection)
  
  3. OneAgent creates an OUTGOING span:
     trace_id:   "0000000000000001" (assigned by DT)
     span_id:    "0000000000000001"
     start_time: 14:00:00.000
     
  4. OneAgent INJECTS a header into the outgoing HTTP request:
     x-dynatrace: FW4;3;x;0;0;0;0;4;abcdef123456;0;1
     (DT-proprietary format encoding: trace_id, span_id, sampling flag, etc.)
     
  5. HTTP request goes out WITH the header injected
     order-service application code never sees this — it's transparent
```

```
payment-service pod (on Node B, OneAgent attached):

  1. Incoming HTTP request arrives at port 8080
  
  2. OneAgent intercepts at the Servlet level (before Spring even processes it)
  
  3. OneAgent reads the x-dynatrace header from the incoming request
     Decodes: trace_id = "0000000000000001" (same as order-service's)
     
  4. OneAgent creates an INCOMING span:
     trace_id:   "0000000000000001"  ← SAME trace_id → links to order-service span
     span_id:    "0000000000000002"  ← new span for this service
     parent_id:  "0000000000000001"  ← points to order-service's span
     start_time: 14:00:00.010 (10ms after order-service made the call)
     
  5. Payment-service processes the request (DB call, etc.)
     OneAgent intercepts JDBC call → creates child span:
       span_id:    "0000000000000003"
       parent_id:  "0000000000000002"
       sql:        "INSERT INTO payments ..."
       duration:   35ms
       
  6. Request completes. OneAgent records payment-service span duration.
     Sends all spans to ActiveGate.
```

```
DT tenant receives:

Span 1 (from order-service OneAgent):
  trace_id:   "0000000000000001"
  span_id:    "0000000000000001"
  service:    "order-service"
  operation:  "POST /api/v1/payments"
  duration:   120ms
  
Span 2 (from payment-service OneAgent):
  trace_id:   "0000000000000001"  ← same! DT knows this is the same trace
  span_id:    "0000000000000002"
  parent_id:  "0000000000000001"
  service:    "payment-service"
  operation:  "POST /api/v1/payments"
  duration:   80ms
  
Span 3 (from payment-service OneAgent, JDBC call):
  trace_id:   "0000000000000001"
  span_id:    "0000000000000003"
  parent_id:  "0000000000000002"
  type:       "database"
  sql:        "INSERT INTO payments (id, amount, currency)"
  duration:   35ms

DT stitches by trace_id → one distributed trace:

  order-service: POST /api/v1/payments              [120ms]
  └── payment-service: POST /api/v1/payments        [80ms]
        └── PostgreSQL: INSERT INTO payments         [35ms]
```

### What happens when services are on different nodes

```
Node A has: order-service + Node A OneAgent
Node B has: payment-service + Node B OneAgent

Node A OneAgent sends span 1 to ActiveGate
Node B OneAgent sends span 2+3 to ActiveGate

ActiveGate (or DT tenant) correlates them by trace_id.
The OneAgents don't communicate with each other — only with ActiveGate.
ActiveGate/DT does the stitching.

This works even if Node A and Node B OneAgents send spans to different ActiveGate replicas
(both replicas forward to the same DT tenant → DT tenant correlates).
```

### Limitation: traces can't cross non-DT-monitored boundaries

```
EKS cluster (DT monitored)        External payment gateway (no DT)
  payment-service
       │
       │ x-dynatrace header injected
       ▼
  payment-gateway-api.com
       │
       │ Does not have OneAgent → doesn't read x-dynatrace
       │ Makes its own outgoing calls to banks
       │ Those calls: no trace context
       ▼
  bank-api.com (no DT, no trace context)

Result in DT: trace ends at "payment-service called payment-gateway-api.com"
You can see: payment-service duration = 800ms
              └── call to payment-gateway.api.com = 600ms (external → shown as slow external call)
You CANNOT see: what happened inside payment-gateway after receiving the call

For fully internal microservices (all in the same DT-monitored cluster):
  This limitation doesn't matter — all spans are captured.
```

---

## Part 3 — How Metrics Flow from JVM to Alert

### The complete data flow for one metric: JVM heap

```
INSIDE THE JVM (OneAgent via JVMTI):
  ┌─────────────────────────────────────────────────────┐
  │ JVM Memory Management API (exposed via JVMTI)       │
  │   G1GC heap regions: eden + survivor + old + humongous │
  │   Used: 716MB (out of Xmx 1024MB) = 69.9%          │
  │   Last GC: 50ms ago, pause time: 8ms                │
  └──────────────────────────┬──────────────────────────┘
                             │ OneAgent reads every 1 second
                             ▼
INSIDE ONEAGENT (on the node):
  ┌─────────────────────────────────────────────────────┐
  │ Metric: process.memory.jvm.heapUtilization = 69.9%  │
  │ Entity: process_group_instance:payment-service      │
  │ Timestamp: 2026-07-31T14:00:01Z                     │
  └──────────────────────────┬──────────────────────────┘
                             │ batched every 60 seconds
                             ▼
ACTIVEGATE (Deployment pod):
  ┌─────────────────────────────────────────────────────┐
  │ Receives batch of metrics from multiple OneAgents   │
  │ Compresses + forwards to DT tenant via HTTPS        │
  └──────────────────────────┬──────────────────────────┘
                             │
                             ▼
DT TENANT:
  ┌─────────────────────────────────────────────────────┐
  │ Stores: builtin:process.memory.jvm.heapUtilization  │
  │   entity=dt.entity.process_group_instance:abc123    │
  │   value=69.9                                        │
  │   timestamp=2026-07-31T14:00:01Z                    │
  │                                                     │
  │ Metric event evaluation (every 1 minute):           │
  │   Query: heapUtilization WHERE entity=payment-service│
  │   Result: 69.9                                      │
  │   Threshold: 70.0                                   │
  │   69.9 < 70.0 → NOT in violation                   │
  │   violating_samples counter: 0                      │
  └─────────────────────────────────────────────────────┘
```

```
60 seconds later: heap = 71.2%
  71.2 > 70.0 → IN VIOLATION
  violating_samples counter: 1 (need 5 for CPU, need 5 for JVM heap → 5 consecutive mins)
  No alert yet.

T+2min: heap = 72.1% → counter: 2
T+3min: heap = 73.5% → counter: 3
T+4min: heap = 74.2% → counter: 4
T+5min: heap = 75.1% → counter: 5 → THRESHOLD MET → CREATE PROBLEM

DT creates a Problem:
  Type:     RESOURCE_CONTENTION
  Title:    "[PRODUCTION] payment-service: JVM heap (>70% of Xmx)"
  Entity:   dt.entity.process_group_instance:payment-service-abc123
  Zone:     payments-production (matched via entity tags: team:payments + environment:production)
  Severity: RESOURCE_CONTENTION

INFO alerting profile for payments-production:
  Severity match: RESOURCE_CONTENTION ✅
  Management zone match: payments-production ✅
  Delay: 15 minutes
  → Wait 15 more minutes before firing notification

T+5min+15min = T+20min since heap first hit 70%:
  Slack notification sent to #monitoring:
  "[INFO][PRODUCTION] OPEN | payments | [PRODUCTION] payment-service: JVM heap (>70% of Xmx) | <link>"

Heap drops back below 70% for 5 consecutive minutes (dealerting_samples=5):
  DT closes the Problem
  Slack notification: "RESOLVED | ..."
```

### The complete metric event evaluation loop

```
Every 1 minute per metric per service:

1. DT evaluates: metric value for this service in this environment
2. Checks: is value above/below threshold?
3. Updates: violating_samples counter (increments if in violation, resets if not)
4. Checks: violating_samples >= required threshold?
5. If yes: creates Problem of the specified event_type
6. Problem routes through management zone + alerting profile
7. Alerting profile checks delay: has enough time passed?
8. If yes: fires notification (PagerDuty phone or Slack message)

Deduplication:
  Same metric event fires → same Problem still open → NO new notification
  One notification per Problem (not per metric violation).
  New notifications only when: Problem closes and reopens, or severity escalates.
```

---

## Part 4 — How Management Zones Route Alerts to the Right Team

### The full tagging chain (no manual action required)

```
STEP 1: Namespace YAML (gitops/<env>/namespaces/namespaces.yaml)
  kind: Namespace
  metadata:
    name: payment-ns
    labels:
      team: payments           ← label on the K8s namespace object
      environment: production  ← label on the K8s namespace object

STEP 2: K8s applies the namespace with labels
  kubectl get namespace payment-ns -o json
  → metadata.labels.team = "payments"
  → metadata.labels.environment = "production"

STEP 3: payment-service Pod scheduled into payment-ns
  Pod inherits namespace labels (Kubernetes behavior)
  Pod metadata also has: namespace = "payment-ns"

STEP 4: OneAgent reads pod metadata
  For each pod on the node, OneAgent calls:
  K8s API: GET /api/v1/namespaces/payment-ns
  Response: labels.team = "payments", labels.environment = "production"
  
  OneAgent maps: JVM process on this pod ← namespace has these labels
  
STEP 5: DT auto-tagging rule (configured ONCE in DT Settings UI)
  Rule definition:
    "If entity has Kubernetes namespace label 'team' with any value
     → apply DT tag: team:{label_value}"
    
    "If entity has Kubernetes namespace label 'environment' with any value
     → apply DT tag: environment:{label_value}"
    
  Result: payment-service service entity gets DT tags:
    team:payments
    environment:production

STEP 6: Management zone rule (Terraform) evaluates
  resource "dynatrace_management_zone_v2" "team" {
    rules {
      rule { type = "SERVICE"
        attribute_conditions {
          attribute = "SERVICE_TAGS"; tag_value = "team:payments"
        }
        attribute_conditions {
          attribute = "SERVICE_TAGS"; tag_value = "environment:production"
        }
      }
    }
  }
  
  payment-service has both tags → included in "payments-production" zone

STEP 7: Problem created for payment-service → zone = payments-production
  Alerting profile "payments-production-critical" checks:
    Is this problem in my management zone (payments-production)? YES
    Is severity = AVAILABILITY? YES
    Delay = 0 → fire PagerDuty immediately
    
  PagerDuty fires phone call to payments oncall engineer.
  Slack gets nothing (CRITICAL = PagerDuty only, not Slack for production AVAILABILITY)
```

### Why the AND condition in management zone rules matters

```
Rule A: tag "team:payments" AND "environment:production"
  Matches: payment-service in production
  Excludes: payment-service in dev (tagged team:payments + environment:dev)
  Excludes: order-service in production (tagged team:orders + environment:production)
  
  → payments team sees only their production service
  → Dev noise doesn't pollute production alerts

Rule B (hypothetical bad example): tag "team:payments" only
  Matches: payment-service in production
  Also matches: payment-service in dev
  Also matches: payment-service in staging
  
  → Dev payments team gets paged for dev pod restarts at 2am
  → Alert fatigue → they stop caring about alerts
  → Real production incident → ignored
```

---

## Part 5 — How SLOs Track Error Budget in Real Time

### The evaluation engine

```
DT evaluates the SLO every 1 hour (using the rolling -1M window):

Metric expression evaluated:
  numerator:   successful_requests = total_requests - error_requests
  denominator: total_requests
  result:      (successful / total) × 100 = SLO current value

Example calculation:
  Over last 30 days:
    Total requests:  259,200,000  (100 req/s × 30 days)
    Error requests:       30,000  (brief 5-minute outage last week)
    
    SLO = (259,200,000 - 30,000) / 259,200,000 × 100
        = 259,170,000 / 259,200,000 × 100
        = 99.9884%
    
    Target: 99.9%
    Current: 99.9884%
    Status: MET ✅
    Budget remaining: (0.1% - 0.0116%) / 0.1% × 100 = 88.4% remaining
```

### Burn rate calculation

```
Error budget = 1 - 0.999 = 0.001 (0.1% of requests can fail)
Normal consumption rate = 0.001 / (30 days × 24h × 60min) per minute
                        = 0.001 / 43,200
                        = 0.0000000231 per minute (or: budget exhausts in 30 days)

Current burn rate = actual consumption rate / normal rate

Example: outage causing 5% error rate for 1 hour:
  Errors during outage: 100 req/s × 3600s × 5% = 18,000 errors
  Error budget consumed: 18,000 / 259,200,000 = 0.00694%
  Percentage of budget: 0.00694% / 0.1% × 100 = 6.94% of monthly budget in 1 hour
  
  Normal consumption per hour: 0.1% / (30×24) = 0.000139% per hour
  Burn rate: 0.00694% / 0.000139% = 50× normal rate
  
  DT fast_burn_threshold = 14.4 → 50 > 14.4 → FAST BURN ALERT fires
  DT slow_burn_threshold = 3.0  → also triggers (50 > 3.0)
  
  Both PagerDuty AND Slack get alerts (fast burn = most severe)
```

### The rolling window effect

```
The -1M window means: "last 30 days from right now"

Monday morning: last week's outage (Tuesday 3am, lasted 10 minutes) is still in the window.
  SLO = 99.985% (budget partially consumed)
  
Next Tuesday morning: the outage has now "rolled off" the window.
  SLO resets to 99.999% (only last 30 days counted)
  Budget automatically refills as time passes without incidents.
  
This means:
  After a bad week: you have less budget for the rest of the month
  After a clean week: you accumulate budget for risk-taking (big deploys)
  Budget = a shared resource the team manages collectively
```

---

## Part 6 — How HTTP Synthetics Work (External Check Logic)

### The check execution flow

```
Every 5 minutes, DT's Tokyo synthetic node executes:

STEP 1: DNS resolution
  resolve: payment.company.com
  → returns: 3.X.X.X (ALB IP)
  FAIL condition: DNS resolution timeout or NXDOMAIN → synthetic fails immediately
  (catches: ExternalDNS stopped working, Route53 record deleted)

STEP 2: TCP connection
  TCP connect to 3.X.X.X:443
  FAIL condition: connection refused or timeout
  (catches: ALB health check failing, security group blocking port 443)

STEP 3: TLS handshake
  Present certificate: *.company.com (from ACM, certArn in Helm ingress values)
  accept_any_certificate = false → fail if cert is expired or hostname mismatch
  (catches: TLS cert expired, wrong cert attached to ALB listener)

STEP 4: HTTP request
  GET /actuator/health HTTP/1.1
  Host: payment.company.com

STEP 5: Validation 1 — HTTP status
  Response status: 200 → PASS (2xx range accepted)
  Response status: 503 → FAIL → synthetic fails
  (catches: all pods NotReady, ALB unhealthy targets, Spring Boot hard crash)

STEP 6: Validation 2 — Body content
  Response body: { "status": "UP", "components": { "db": { "status": "UP" } } }
  Pattern check: does body contain "status":"UP"? YES → PASS
  
  Response body: { "status": "DOWN", "components": { "db": { "status": "DOWN" } } }
  Pattern check: "status":"UP" NOT found → FAIL → synthetic fails
  (catches: DB connection failure, downstream dependency down — HTTP 200 but app broken)

STEP 7: Response time check
  response_time_limit = 900ms (3× P99 SLO of 300ms)
  Actual response time: 85ms → PASS
  Actual response time: 1200ms → FAIL → synthetic fails
  (catches: service severely degraded — technically alive but extremely slow)

ALL PASS → synthetic result: "OK"
ANY FAIL → synthetic result: "FAILED"
```

### The two-location logic

```
Tokyo check:   FAILED  at 14:00:00
Singapore check: PASSED at 14:00:00

DT evaluation:
  local_outages = true
  local_consecutive_outage_count_threshold = 3
  
  Only Tokyo failed: consecutive local failure count = 1
  No alert yet.

14:05:00: Tokyo: FAILED, Singapore: PASSED → local count = 2. No alert.
14:10:00: Tokyo: FAILED, Singapore: PASSED → local count = 3. ALERT.
  
  Problem: "payment-service local outage from Tokyo"
  Alerting profile: info tier → Slack #monitoring
  "This may be a Tokyo DT node network issue, not your service"

vs.

14:00:00: Tokyo: FAILED, Singapore: FAILED
  global_consecutive_outage_count_threshold = 1 → IMMEDIATE ALERT
  
  Problem: "payment-service global outage" (AVAILABILITY)
  Alerting profile: critical tier → PagerDuty phone call
```

### What synthetics catch that OneAgent misses

```
Scenario: deployment misconfigures the Ingress (wrong certArn)

OneAgent monitoring:
  Sees: payment-service pods are Running, readiness probes passing
  Metrics: request rate = 0 (no requests reaching the service)
  Traffic drop alert fires → but only after 3 consecutive minutes
  
Synthetic monitoring:
  STEP 3: TLS handshake fails (wrong cert)
  Fires immediately at the next 5-minute check
  Alert type: AVAILABILITY → PagerDuty immediately
  
Synthetic is faster to detect this class of infrastructure failure.

Scenario: payment.company.com DNS cached with wrong IP (TTL expired, Route53 changed)

OneAgent monitoring:
  Sees: service pods healthy, internal traffic fine
  Traffic drop alert fires eventually
  
Synthetic monitoring:
  STEP 1: DNS resolution returns wrong IP → TCP fails → alert fires
  Catches DNS issues before any real user hits them (at 5-minute interval)
```

---

## Part 7 — Notification Routing: Problem → PagerDuty/Slack

### The complete routing decision tree

```
Problem created:
  Title:    "[PRODUCTION] payment-service: Traffic drop (<10 req/min)"
  Type:     ERROR_EVENT → severity = ERROR (HIGH tier)
  Entity:   dt.entity.service:payment-service
  Tags:     team:payments, environment:production
  Zone:     payments-production

DT evaluates ALL alerting profiles:
  
  payments-production-critical:
    Severity filter: AVAILABILITY only
    Current problem severity: ERROR → NO MATCH → skip
    
  payments-production-high:
    Severity filter: ERROR ✅
    Management zone filter: payments-production ✅
    Delay: 2 minutes
    → Start 2-minute timer
    
  payments-production-warning:
    Severity filter: SLOWDOWN only
    Current problem severity: ERROR → NO MATCH → skip
    
  payments-production-info:
    Severity filter: RESOURCE_CONTENTION only
    Current problem severity: ERROR → NO MATCH → skip
    
  orders-production-high:
    Management zone filter: orders-production ≠ payments-production → NO MATCH → skip

2 minutes pass without error rate recovering:

  payments-production-high matches → fire notification

  Notification type: dynatrace_pagerduty_notification.high["payments"]
    service_api_key = "pd-integration-key-for-payments-team"
    
  PagerDuty receives:
    "OPEN: [PRODUCTION] payment-service: Traffic drop (<10 req/min)"
    Urgency: high
    → Push notification to on-call engineer's phone
    → If no acknowledgement in 30min → escalate to backup
```

### The Slack message format

```
Slack #alerts-payments receives:
  "[PRODUCTION] OPEN | ERROR | [PRODUCTION] payment-service: High error rate (>0.1%) | https://dt.company.com/e/P-123456"

Breaking down the format:
  [PRODUCTION]     = upper(var.environment) — immediate env identification
  OPEN             = {State} — distinguishes new alert from resolved
  ERROR            = {ProblemSeverity}
  [PRODUCTION]...  = {ProblemTitle} — the metric event summary string
  https://...      = {ProblemURL} — one click to DT problem view

When the problem resolves:
  "[PRODUCTION] RESOLVED | ERROR | [PRODUCTION] payment-service: High error rate (>0.1%) | https://..."
  
Engineers see resolution in Slack without logging into DT.
```

### Why PagerDuty keys are per-team (not global)

```
Terraform:
  pagerduty_integration_keys = {
    "payments"      = "pd-key-abc123"
    "orders"        = "pd-key-def456"  
    "notifications" = "pd-key-ghi789"
  }
  
  for_each = var.pagerduty_integration_keys
  → Creates one PagerDuty notification per team per alerting profile tier

Why per-team keys:
  payment-service alert → PagerDuty service "payments-oncall" → pages payments team
  order-service alert   → PagerDuty service "orders-oncall"   → pages orders team
  
  If one global key:
    payment-service alert → same PD service as order-service alert
    All oncall engineers get paged for all services
    Oncall: "this is orders' problem, why am I being woken up?"
    → Engineer escalates to orders team → 5-min delay in incident response
    
  Per-team keys: correct team paged directly, no routing overhead
```

---

## Part 8 — Log Flow and Log-Based Alerts (No OTEL Needed)

### How logs reach DT

```
In the JVM:
  log.info("{\"event\":\"payment_created\",\"amount\":100,\"currency\":\"JPY\"}")
  → Logback formats the string
  → Writes to stdout (System.out)
  
Kubernetes runtime:
  Container stdout → captured by containerd/docker
  Written to: /var/log/containers/payment-service-abc123_payment-ns_payment-service-def456.log
  
OneAgent on the node:
  Watches /var/log/containers/ for new log lines (inotify)
  Reads: timestamp + pod name + namespace + log line
  
  With logMonitoring: enabled: true in DynaKube:
  OneAgent ships these log lines to ActiveGate → DT tenant

DT Grail log analytics:
  Indexed fields: k8s.pod.name, k8s.namespace.name, k8s.container.name, log.level, timestamp
  Parsed from JSON: event, amount, currency (because the log line is JSON)
  Full-text search: available on all fields
  
  Query in DT: dt.entity.kubernetes_pod = payment-service-* AND event = "payment_created"
               | summarize count() by bin(timestamp, 5m)
```

### JSON structured logging and DT field parsing

```
Java log statement:
  log.info("{\"event\":\"payment_created\",\"payment_id\":\"pay_abc123\",\"amount\":100}");

DT receives this as a log line. Because it's valid JSON, DT auto-parses fields:
  log.event     = "payment_created"
  log.payment_id = "pay_abc123"
  log.amount    = 100
  log.level     = "INFO"
  k8s.pod.name  = "payment-service-7d9f6b-abc12"

vs. plain text log:
  log.info("Payment created: pay_abc123, amount: 100");
  DT receives: "Payment created: pay_abc123, amount: 100"
  No parsed fields → only full-text search → slower → less powerful queries

JSON logging is the key to useful DT log analytics.
application.yaml in this project:
  logging:
    pattern:
      console: '{"timestamp":"%d{...}","level":"%level","service":"payment-service","message":"%msg"}'
```

### Log-based metric for OOM detection (faster than pod_restarts metric)

```
The problem with pod_restarts signal:
  OOM happens → pod crashes → K8s restarts it → wait for next 5-min window → alert fires
  Total detection time: up to 5 minutes + K8s restart time = 3-8 minutes

Log-based approach:
  OOM happens → JVM logs: "Exception in thread ... java.lang.OutOfMemoryError: Java heap space"
  → OneAgent ships log → DT receives log line → log metric increments
  → Metric event fires → PagerDuty pages
  Total detection time: 30 seconds (log → ActiveGate → DT → evaluate → fire)
  
  How to set up in DT (one-time config in DT Settings UI, not Terraform today):
  
  1. DT UI → Metrics → Log metrics → Create
     Name: log.payment_service.oom
     Query: matchesValue(log.content, "*OutOfMemoryError*") 
            AND matchesValue(k8s.namespace.name, "payment-ns")
     Aggregate: count per minute
     
  2. Terraform: add to modules/dynatrace/main.tf
     resource "dynatrace_metric_events" "oom_error" {
       for_each   = var.services
       metric_key = "log.payment_service.oom"
       model_properties {
         threshold         = 1      # first occurrence = alert
         violating_samples = 1
         samples           = 1
       }
       event_type = "ERROR_EVENT"
     }
```

---

## Part 9 — Kubernetes Workload Monitoring Flow

### How ActiveGate collects K8s state

```
ActiveGate capability: kubernetes-api-monitoring

Every 60 seconds, ActiveGate calls:
  K8s API: GET /apis/apps/v1/namespaces/payment-ns/deployments
  Response:
    spec.replicas: 3                    (desired)
    status.availableReplicas: 3         (actually running and ready)
    status.unavailableReplicas: 0       (pods not ready)
    status.updatedReplicas: 3           (running new image version)
  
  K8s API: GET /api/v1/namespaces/payment-ns/events
  Response: recent events (pod scheduled, image pulled, probe failed, OOMKilled)
  
DT stores:
  builtin:kubernetes.deployment.replicas_available = 3
  builtin:kubernetes.deployment.replicas_desired   = 3
  builtin:kubernetes.workload.pods.restarts        = 0
```

### Pod restart alert logic

```
K8s pod restarts counter (from DT):
  builtin:kubernetes.workload.pods.restarts
  
  Metric resolution: 5m (counted in 5-minute windows)
  
  14:00 - 14:05: 0 restarts
  14:05 - 14:10: 0 restarts
  14:10 - 14:15: 3 restarts  ← pod crashed 3 times in 5 minutes
  
  Metric event evaluation:
    value = 3
    threshold = 2 (production: pod_restart_threshold = 2)
    3 > 2 → IN VIOLATION
    violating_samples = 1 (needs 1 sample → fires immediately)
    
  Problem created:
    "[PRODUCTION] payment-service: Pod restarting (>2 in 5 min)"
    event_type: ERROR_EVENT → ERROR severity → HIGH alerting profile
    → PagerDuty push notification (staging: HIGH → PagerDuty; production: HIGH → PagerDuty)
  
  SRE investigates:
    What caused the restart?
    
  kubectl describe pod <crashed-pod> -n payment-ns
  
  In Events section:
    15s ago  Warning  OOMKilled  payment-service  "OOM kill occurred"
  
  In Last State:
    Exit Code: 137 (SIGKILL from OOM)
    
  Action: check JVM heap metric (was it already at 70%? = expected OOM from memory leak)
          OR check RSS metric (was container limit too low?)
```

---

## Part 10 — The SRE Verification Checklist After a Deploy

### Commands to verify monitoring is working

```bash
# 1. Confirm pods are running the new image
kubectl get pods -n payment-ns --context prod -o custom-columns='NAME:.metadata.name,IMAGE:.spec.containers[0].image'
# Expected: payment-service-xxx   ...ecr.../payment-service:<new-sha>

# 2. Confirm DT sees the service (check if service entity exists)
# DT UI → Services → search "payment-service" → should show request count > 0

# 3. Confirm service name matches Terraform key (critical for alert routing)
# DT UI → payment-service → Properties and tags
# Should show: spring.application.name = "payment-service"
# AND tags: team:payments, environment:production
# If name is "payment-service-0.0.1-SNAPSHOT" → spring.application.name not being picked up

# 4. Confirm health check via synthetic is passing
# DT UI → Synthetic Monitors → "payment-service Health Check [production]"
# Status: ALL checks passing from all locations

# 5. Confirm SLO is calculating (not "No data")
# DT UI → SLOs → "payment-service Availability [production]"
# Should show a percentage, not "—"

# 6. Manually trigger a test alert (DT test notification)
# DT UI → Settings → Integrations → Problem notifications
# → payments-production-warning-slack → Test
# Should receive a test message in Slack #alerts-payments

# 7. Check error budget is not burning
# DT UI → SLOs → "payment-service Availability [production]"
# → Error budget remaining: should be close to 100% after clean deploy
# → Burn rate: should be close to 1.0 (normal consumption)

# 8. Read recent logs to confirm format is correct
# DT UI → Logs → filter: k8s.namespace.name = payment-ns AND log.level = INFO
# → Should see structured JSON log lines from the new pods
```

### After adding a new service: end-to-end verification

```bash
# After: new-service added to services map in terraform/environments/production/main.tf

# Step 1: Terraform created the DT resources
terraform show | grep "new-service"
# Should show: dynatrace_metric_events, dynatrace_slo_v2, dynatrace_http_monitor

# Step 2: Service entity appeared in DT
# DT UI → Services → filter management zone: "platform-production" (or relevant team zone)
# → "new-service" should appear within 5 minutes of first request

# Step 3: Verify tags are correct
# DT UI → new-service → Properties and tags
# Must show: team:platform AND environment:production
# If missing: check namespace labels in namespaces.yaml, check DT auto-tagging rules

# Step 4: Verify metric events are matching
# DT UI → Settings → Anomaly detection → Metric events
# → Filter by management zone: platform-production
# → Should see 8 events: traffic_drop, error_rate, latency_p99, cpu_saturation,
#    memory_usage, jvm_heap, pod_restarts, network_error_rate
# → Each should show "payment-service" as the entity filter value

# Step 5: Verify SLO is calculating
# DT UI → SLOs → "new-service Availability [production]"
# → Should show request count and current SLO %
# If "No data": check metric expression uses correct service.name filter

# Step 6: Trigger a test: what happens when the service returns an error?
# Temporarily introduce an error (e.g., send a request with invalid data)
# Wait 3-5 minutes
# DT UI → new-service → Failure rate → should show a spike
```

---

## Part 11 — Common Monitoring Failures and Root Causes

### "Metric events exist but alerts never fire"

```
Symptom: error rate clearly above threshold in DT graphs, but no PagerDuty/Slack alert

Root cause checklist:

1. Entity filter mismatch:
   Terraform: services = { "payment-service" = { ... } }
   DT entity: service.name = "payment-service-0.0.1-SNAPSHOT"
   
   Fix: ensure spring.application.name = "payment-service" in application.yaml
   Verify: DT UI → Services → click service → check entity name exactly

2. Management zone doesn't include the service:
   Service entity: missing "team:payments" or "environment:production" tag
   
   Root cause: namespace labels missing or DT auto-tagging rule not configured
   Verify: DT UI → Services → payment-service → Properties and tags
   Fix: add labels to namespace YAML + configure DT auto-tagging rules

3. Alerting profile doesn't match:
   Problem type: RESOURCE_CONTENTION
   Alerting profile: only handles AVAILABILITY (misconfigured)
   
   Fix: check alerting profile severity filter in Terraform + DT UI
   
4. Notification not connected to alerting profile:
   PD notification: points to wrong alerting profile ID
   
   Fix: terraform show → check dynatrace_pagerduty_notification.alerting_profile
   Should match the ID of dynatrace_alerting.high[team]
```

### "False alerts firing constantly"

```
Symptom: Slack flooded with "[PRODUCTION] payment-service: P99 latency >300ms"

Root cause checklist:

1. Threshold too low for current traffic pattern:
   Normal P99 = 280ms (close to 300ms threshold)
   Any traffic spike pushes P99 over threshold → alert fires → traffic normalizes → resolves
   
   Fix: raise threshold to 400ms or measure proper baseline first
   
   How to measure baseline:
   DT UI → payment-service → Response time → set time range: last 2 weeks
   Look at P99 chart: what is the sustained normal P99?
   Typical baseline × 3 = good threshold starting point

2. violating_samples too low:
   violating_samples = 1 → a single 1-minute spike fires the alert
   
   Fix: raise to violating_samples = 3 (3 consecutive minutes above threshold)

3. Missing dealerting_samples:
   dealerting_samples = 1 → any brief dip below threshold "resolves" the alert
   → metric spikes again 1 min later → new alert fires → Slack flooded
   
   Fix: set dealerting_samples = 3 (3 consecutive minutes below before resolving)
```

### "Silent outage — users complained before alert fired"

```
Symptom: production service was down for 15 minutes, PagerDuty never fired

Root cause checklist:

1. traffic_min_rps = 0 in production (should not be 0 in production):
   Fix: set to minimum expected traffic (e.g., 10 req/min for production)
   Verify: grep traffic_min_rps terraform/environments/production/main.tf

2. alert_on_no_data = false on traffic drop:
   If DT stops receiving metrics (ActiveGate restart, network issue):
   "no data" treated as "everything fine"
   
   Fix: always set alert_on_no_data = true for traffic drop signal only

3. Management zone missing — alert fired but to wrong zone:
   Check: DT UI → Problems → All → find the problem
   Check its management zone → if empty or wrong zone → alerting profile doesn't match

4. PagerDuty integration key wrong:
   Terraform uses correct key, but key was rotated in PagerDuty without updating Secrets Manager
   
   Fix: update production/dynatrace/pagerduty-keys in AWS Secrets Manager
   Run terraform apply to pick up new key
   Test: DT UI → Integrations → Test notification → verify PD receives it
```
