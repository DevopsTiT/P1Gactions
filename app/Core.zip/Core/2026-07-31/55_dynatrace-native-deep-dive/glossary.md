# Glossary — Dynatrace Native (No OTEL) Deep Dive

Every term in main.md. Plain language for an SRE beginner.

---

**OneAgent**
Dynatrace's monitoring agent. Runs as one pod per Kubernetes node (DaemonSet). Attaches to all JVM processes on the node and captures HTTP metrics, DB call timings, JVM heap, and logs automatically. Why it matters: the foundation of zero-code-change monitoring — everything flows from this.

**JVMTI (Java Tool Interface)**
A C API built into every JVM that allows external programs to attach to a running JVM and modify its bytecode at runtime. OneAgent uses this to wrap Spring Boot methods invisibly. Why it matters: makes "zero configuration Java monitoring" technically possible.

**Bytecode instrumentation**
Modifying compiled Java class files in memory at runtime to add timing code around methods. OneAgent does this after attaching to the JVM — the source code is untouched. Why it matters: captures HTTP request durations and DB call times without any developer action.

**Dynamic attach (JVM)**
The mechanism by which OneAgent attaches to a JVM that is already running. Uses the Java Attach API (equivalent to `jattach`). Why it matters: OneAgent doesn't need to be in the JVM startup command — it attaches after the process starts.

**`/proc/<pid>/`**
Linux filesystem directory that contains runtime information about a running process. OneAgent reads this for: CPU usage, memory RSS, open file descriptors, and process environment variables. Why it matters: how OneAgent gets host-level process metrics without modifying the application.

**inotify**
Linux kernel mechanism for watching filesystem events (file created, modified, deleted). OneAgent uses this to detect new log files and new JVM processes. Why it matters: makes detection near-instant (milliseconds) instead of polling every N seconds.

**`spring.application.name`**
A Spring Boot property in `application.yaml` that sets the application's name. DT OneAgent reads this via JVMTI to name the service entity in DT. Why it matters: must exactly match the Terraform `services = { "payment-service" = {...} }` map key for alerts and SLOs to bind to the correct entity.

**Service entity (DT)**
A Dynatrace object representing a monitored service — the thing that has response time, error rate, and throughput metrics. Named from `spring.application.name`. Why it matters: all metric events, SLOs, and management zone rules filter by this entity's name.

**`service.name` attribute**
The canonical name DT uses to identify a service entity, derived from `spring.application.name` (or OTEL_SERVICE_NAME if set). Why it matters: the string that metric event entity filters match against — if it doesn't match exactly, alerts are silent.

**`x-dynatrace` header**
Dynatrace's proprietary HTTP header for distributed trace context. OneAgent injects it on outgoing calls and reads it on incoming calls to link spans across services. Why it matters: this is how DT creates distributed traces without OTEL — completely transparent to application code.

**Trace context**
Information embedded in an HTTP header that allows a request's journey through multiple services to be linked together as one trace. DT native uses `x-dynatrace`; W3C standard uses `traceparent`. Why it matters: without propagating trace context, you only see isolated per-service spans, not the full picture.

**`trace_id`**
A unique identifier shared by all spans in one distributed trace. DT uses it to stitch together spans from different services into a single trace tree. Why it matters: the glue that turns separate service measurements into a connected cause-and-effect timeline.

**`span_id`**
A unique identifier for one unit of work within a trace (e.g., "payment-service handled this request" or "JDBC query ran for 35ms"). Each span knows its parent span ID. Why it matters: allows the trace tree structure to be rebuilt from individual spans.

**`parent_id`**
The span_id of the span that caused this span. "payment-service span" has parent_id = "order-service span." Why it matters: builds the hierarchical trace view showing which service called which.

**ActiveGate**
A Dynatrace proxy deployment inside the cluster. OneAgent pods send all data here; ActiveGate batches and forwards to the DT SaaS tenant. Also polls the Kubernetes API for workload state. Why it matters: reduces outbound connections from many (one per node) to few (one per ActiveGate replica).

**DT tenant**
The Dynatrace SaaS instance — the remote service at `https://abc12345.live.dynatrace.com`. Stores all metrics, traces, and logs. Runs metric event evaluations, SLO calculations, and fires notifications. Why it matters: the "brain" of the system — where all data is correlated and alerts are generated.

**Management zone**
A named filter in DT that scopes the UI and alerts to entities tagged with specific labels (e.g., `team:payments AND environment:production`). Why it matters: ensures each team only sees and gets paged for their own services.

**DT auto-tagging rule**
A rule configured in DT Settings (once, manually) that automatically applies tags to entities based on Kubernetes namespace labels. Why it matters: the bridge between `namespaces.yaml` labels and DT management zone conditions — without this rule, namespace labels have no effect in DT.

**Alerting profile**
A DT configuration that maps a Problem severity + management zone to a notification channel with a delay. Why it matters: determines who gets paged, through which channel, and with what delay — the routing logic for all alerts.

**Problem (DT)**
A Dynatrace event created when a metric event fires. Contains: severity, affected entity, start time, root cause hints. The "incident" object in DT. Why it matters: what SREs investigate during on-call; links to relevant traces, logs, and events.

**`event_type` (metric event)**
The severity DT assigns to a Problem created by this metric event. Options: `ERROR_EVENT` → ERROR severity → HIGH alerting profile. `PERFORMANCE_EVENT` → SLOWDOWN → WARNING. `RESOURCE_CONTENTION_EVENT` → INFO. Why it matters: controls which alerting profile tier handles the notification.

**`violating_samples`**
How many consecutive evaluation windows (minutes) must have the metric in violation before a Problem is created. Why it matters: prevents transient spikes from firing pages — a 1-minute CPU spike during GC won't alert if `violating_samples = 5`.

**`dealerting_samples`**
How many consecutive windows must return to normal before the Problem is closed. Why it matters: prevents "flapping" — an alert that fires and clears every other minute because the metric oscillates around the threshold.

**`alert_on_no_data`**
Metric event setting. When `true`, fires even when DT receives ZERO data points. Why it matters: if the service is so broken it can't send metrics, all other signals show green — only `alert_on_no_data = true` on traffic drop catches silent outages.

**Traffic drop signal**
The metric event that fires when request count falls below a minimum for 3 consecutive minutes. The most important signal. Why it matters: error rate, latency, CPU, and heap all show green when traffic is zero (nothing to measure) — only traffic drop detects silent outages.

**`builtin:service.requestCount.server`**
DT's built-in metric for incoming HTTP requests per minute to a service. Used by traffic drop and error rate signals. Why it matters: the fundamental throughput metric — tells you "how many requests is this service handling?"

**`builtin:service.errors.server.rate`**
DT's built-in metric for HTTP 5xx error rate (percentage). Used by the error rate signal. Why it matters: directly measures user-facing failures — every 1% here means 1 in 100 users gets an error.

**`builtin:service.response.time:percentile(99)`**
DT's built-in P99 latency metric in microseconds. Used by the latency signal. Why it matters: the 99th percentile captures the worst experience for 1% of users — better than average for user experience monitoring.

**`builtin:process.memory.jvm.heapUtilization`**
DT's built-in metric for JVM heap used as a percentage of `-Xmx`. Captured via JVMTI. Why it matters: G1GC pause times increase non-linearly above 70% — alerting here gives time to act before users feel it.

**`builtin:kubernetes.workload.pods.restarts`**
DT's built-in metric for pod restart count in a 5-minute window, collected by ActiveGate from the K8s API. Why it matters: restarts always indicate a real problem — OOMKill, crash loop, or deadlocked readiness probe.

**`builtin:host.net.errorRate`**
DT's built-in metric for packet-level network errors on a node's NIC. Why it matters: catches AWS-level network problems (bad ENI, NIC driver issue, VPC flow limits) that don't show up in HTTP error rates.

**G1GC (Garbage First Garbage Collector)**
Java's low-latency garbage collector. At 70-80% heap: enters "mixed mode" with longer pauses. At 90%+: may trigger full GC with 1-5 second stop-the-world. Why it matters: explains why heap alert threshold is 70% — alerting before G1GC degradation affects P99 latency.

**SLO (Service Level Objective)**
A reliability target: "99.9% of requests must succeed in any rolling 30-day period." DT tracks compliance and fires burn rate alerts. Why it matters: quantifies reliability commitments and tells engineers when to stop shipping features and fix reliability instead.

**Error budget**
The allowed failures before breaching the SLO. For 99.9%: 0.1% of requests = ~43 minutes of total downtime per month. Why it matters: a shared resource the team manages — nearly depleted budget = reliability freeze.

**Burn rate**
How fast the error budget is being consumed. 14.4× = budget gone in 2 days (page immediately). 3.0× = budget gone in 10 days (investigate today). Why it matters: alerts you before the SLO is breached, not after — proactive vs reactive.

**Rolling window (`-1M`)**
SLO evaluation covers the last 30 days from the current moment, continuously rolling forward. Why it matters: past incidents "roll off" after 30 days, naturally refilling error budget. Encourages reliability work spread across the month.

**HTTP Synthetic monitor**
An active health check that DT's external nodes (Tokyo, Singapore) send to your service's URL every 5 minutes. Why it matters: catches failures invisible to internal monitoring — DNS failures, TLS cert expiry, ALB misconfiguration — from the user's perspective.

**`accept_any_certificate = false`**
Synthetic setting that fails the check if the TLS certificate is expired or hostname mismatch. Why it matters: catches TLS cert issues before users see browser security warnings.

**Body pattern validation (`"status":"UP"`)**
Synthetic check that verifies the response body contains this string. Why it matters: Spring Boot can return HTTP 200 with `{"status":"DOWN"}` when the DB is down — body validation catches this "200 but broken" scenario.

**`response_time_limit`**
Synthetic setting that fails the check if the response takes longer than this value (in ms). Why it matters: catches severely degraded services that are technically alive but too slow to be useful.

**Local outage vs global outage (synthetic)**
Local: only one DT monitoring location fails (may be a DT node issue). Global: all locations fail simultaneously (real service outage). Why it matters: distinguishes "DT Tokyo node had a network hiccup" from "your service is actually down."

**Kubernetes events**
Records from the K8s API describing what happened to pods and deployments: scheduled, image pulled, probe failed, OOMKilled. ActiveGate collects these and shows them in the DT Kubernetes workload view. Why it matters: the timeline of events that caused a restart or CrashLoopBackOff.

**`logMonitoring: enabled: true`**
DynaKube setting that enables OneAgent to ship container logs to DT. Why it matters: without this, DT receives metrics and traces but no logs — you'd need a separate log shipper (Fluent Bit, Loki) to see log content.

**Grail (DT log analytics)**
Dynatrace's log storage and query engine. Receives logs from OneAgent, parses JSON fields automatically, and makes them queryable. Why it matters: where you go during an incident to read log lines and find the root cause.

**Log metric**
A DT metric derived from counting log lines matching a specific query. `matchesValue(log.content, "*OutOfMemoryError*")` counted per minute = a log-based metric. Why it matters: lets you alert on specific log patterns (OOM, specific exceptions) faster than waiting for K8s pod restart metrics.

**`/var/log/containers/*.log`**
The Linux path where containerd/Docker writes stdout from every container. OneAgent reads these files to ship container logs to DT. Why it matters: understanding this path helps when debugging "why aren't my logs appearing in DT?"

**JSON structured logging**
Writing log lines as JSON objects (`{"event":"payment_created","amount":100}`) instead of plain text. Why it matters: DT auto-parses JSON fields — each key becomes a queryable attribute in DT log analytics.

**OOMKilled**
Pod termination reason when a container's RSS memory exceeded its `limits.memory`. Exit code 137. Why it matters: a frequent root cause of pod restarts — the JVM heap + non-heap exceeded the container limit.

**CrashLoopBackOff**
Kubernetes state where a pod repeatedly crashes on startup. K8s backs off with exponential delay between restarts. Why it matters: indicates the application can't start (wrong config, missing secret, code bug) — DT pod_restarts metric fires, triggering investigation.

**`kubectl describe pod`**
Kubernetes command showing pod details including: container image, environment variables, resource requests/limits, probe configuration, and a timeline of recent events (scheduled, pulled, started, OOMKilled). Why it matters: the first command to run when a pod is restarting to understand why.

**`kubectl get events --sort-by='.lastTimestamp'`**
Lists all Kubernetes events in a namespace sorted by most recent. Why it matters: shows the sequence of what happened during a deploy or incident — probe failures, OOM kills, image pull errors — in chronological order.

**PagerDuty integration key**
A secret key unique to each PagerDuty service (per team). DT sends alert notifications to PagerDuty using this key. Why it matters: per-team keys ensure each team's PagerDuty service receives only their own alerts.

**`{State}` (DT notification variable)**
A placeholder in Slack notification messages that resolves to "OPEN" or "RESOLVED." Why it matters: engineers see resolution notifications in Slack without logging into DT — reduces time spent checking DT manually.

**Drift detection (monitoring config)**
Running `terraform plan -refresh-only` daily to detect if someone manually changed DT thresholds in the UI without updating Terraform code. Why it matters: ensures the thresholds you see in code are actually what's running in DT.
