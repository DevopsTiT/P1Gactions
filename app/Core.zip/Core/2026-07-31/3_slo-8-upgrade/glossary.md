# Glossary — 8 SLOs Upgrade
Every term from main.md and the Terraform files. One entry per term. SRE beginner level.

---

**SLO (Service Level Objective)**
A measurable reliability target. Example: "99.9% of HTTP requests must return 2xx." Why it matters: makes "is the service healthy?" a yes/no math answer, not a gut feeling.

**Error budget**
The allowed amount of failure within an SLO window. For 99.9% monthly: 43.2 minutes of failure budget per month. Why it matters: when it's gone, the SLO is breached — this drives engineering priority decisions.

**Burn rate**
How fast you're spending your error budget compared to the pace that would use it all in the window. Burn rate 1 = exactly on pace. Burn rate 14.4 = budget gone in 2 days. Why it matters: burn rate alerts warn BEFORE breach.

**`fast_burn_threshold: 14.4`**
Budget would be exhausted in 2 days at this rate (30 days / 14.4 = 2.08). Triggers urgent alert. Why it matters: act now or the SLO will breach before month-end.

**`slow_burn_threshold: 3.0`**
Budget would be exhausted in 10 days (30 / 3 = 10). Not urgent but needs attention. Why it matters: catches slow-growing reliability degradation before it becomes a crisis.

**`evaluation_window: "-1M"`**
Rolling 30-day window. The SLO always looks at the last 30 days from right now. Why it matters: unlike calendar months, there's no "reset" at month boundaries — reliability is always measured continuously.

**`evaluation_type: AGGREGATE`**
Counts ALL requests over the whole window as one pool. 1 million requests, 1000 failed = 99.9%. Why it matters: gives the true user experience, not an average-of-averages.

**`for_each = { for k, v in var.services : k => v if v.has_database }`**
Terraform conditional loop — creates a resource only for services where `has_database = true`. Like a `filter()` function. Why it matters: prevents creating broken "no data" SLOs for services that don't have the feature being measured.

**`has_database = true/false`**
Boolean flag in the services map. payment-service and order-service use PostgreSQL (true). notification-service uses Redis (false) — no SQL DB connections to measure. Why it matters: DB SLOs only make sense if the service has a relational database.

**`has_dependencies = true/false`**
Flag indicating whether this service calls other internal services. payment-service calls fraud-detection, order-service calls payment-service. Why it matters: dependency error rate SLO only applies when outbound calls exist.

**`is_message_consumer = true/false`**
Flag for services that read from a message queue (Kafka/SQS). order-service and notification-service consume queues; payment-service does not. Why it matters: message processing SLO requires the app to emit custom OTEL metrics — only useful if messages are actually consumed.

**`has_business_slo = true/false`**
Flag for services where a "business outcome" is meaningful. payment-service (POST /payments → money moves) and order-service (POST /orders → order created) = true. notification-service (async, fire-and-forget) = false. Why it matters: business transaction SLO measures outcomes, not HTTP status codes.

**SLO 1 — Availability**
Measures: what % of HTTP requests returned non-5xx. Formula: `(total - errors) / total × 100`. Metric: `builtin:service.requestCount.server` and `builtin:service.errors.server.count`. Why it matters: most fundamental SLO — is the service answering?

**SLO 2 — Latency P99**
Measures: what % of requests responded within the threshold time. Formula: `(requests ≤ threshold_ms) / total × 100`. Metric: `builtin:service.response.time` with `le()` filter. Why it matters: P99 shows the worst realistic user experience, not the average.

**SLO 3 — DB Error Rate**
Measures: what % of database calls succeeded. Formula: `(total DB calls - failed DB calls) / total × 100`. Metrics: `builtin:service.dbconnectioncount` and `builtin:service.dbconnectionfailcount`. Why it matters: retry logic can hide DB failures from the HTTP error rate — this SLO sees through the retries.

**SLO 4 — DB Query Latency**
Measures: what % of DB queries completed within threshold time. Formula: `(DB calls ≤ threshold_µs) / total × 100`. Why it matters: slow DB queries cause slow APIs — this fires before the API latency SLO does, giving you the root cause.

**`db_query_threshold_ms × 1000`**
Dynatrace stores all time metrics in microseconds (µs) internally. 100ms must be written as `100000` in metric expressions. Why it matters: using `100` instead of `100000` means the threshold is 100µs = 0.1ms — nearly every query would be "too slow" → constant false alerts.

**`builtin:service.dbconnectioncount`**
DT auto-captured metric: total number of database connection calls made by a service per minute. OneAgent captures this automatically from the JVM via JVMTI — no code change needed. Why it matters: denominator for both DB SLOs.

**`builtin:service.dbconnectionfailcount`**
DT auto-captured metric: number of failed DB calls. OneAgent catches exceptions thrown by JDBC drivers. Why it matters: numerator for DB error rate calculation.

**`builtin:service.dbconnectionlatency`**
DT auto-captured metric: latency of each individual DB call in microseconds. Used with `le()` filter in the DB latency SLO. Why it matters: allows calculating "what % of queries were fast enough."

**SLO 5 — Dependency Error Rate**
Measures: what % of outbound calls FROM this service TO other services succeeded. Formula: `(outbound calls - outbound failures) / outbound calls × 100`. Metrics: `builtin:service.requestCount.client` and `builtin:service.errors.client.count`. Why it matters: tells you whether a problem is in this service or in something it depends on.

**`.client` vs `.server` metrics**
`builtin:service.requestCount.client` = requests this service MADE (outbound). `builtin:service.requestCount.server` = requests this service RECEIVED (inbound). Why it matters: dependency SLO uses `.client`; availability SLO uses `.server`. Using the wrong one gives nonsense numbers.

**SLO 6 — Message Processing Rate**
Measures: what % of queue messages were processed without error. Formula: `(processed - failed) / processed × 100`. Metrics: `ext:custom.messages.processed.count` and `ext:custom.messages.failed.count`. Why it matters: queue failures go to DLQ silently — no HTTP error is thrown, so availability/error rate SLOs are completely blind to this.

**`ext:custom.*`**
DT metric prefix for app-emitted custom metrics sent via OTEL. DT doesn't capture business logic automatically — the app must emit these counters. Why it matters: SLOs 6 and 7 depend entirely on these metrics. If the app doesn't emit them, the SLO always shows "no data."

**Dead Letter Queue (DLQ)**
A separate queue where messages go after failing to process N times. Like a "failed messages bin" that won't block the main queue. Why it matters: without the message processing SLO, DLQ fills silently while all HTTP-based SLOs look green.

**`MeterRegistry` (Spring Boot)**
A Spring Boot / Micrometer component that records counters, gauges, and timers and exports them via OTEL. `meterRegistry.counter("name", "tag", "value").increment()` sends a counter to DT. Why it matters: the Java tool you use to emit the custom metrics that SLOs 6 and 7 depend on.

**SLO 7 — Business Transaction Rate**
Measures: what % of actual business operations completed successfully. Formula: `success.count / total.count × 100`. Metrics: `ext:custom.business.transaction.success.count` and `.total.count`. Why it matters: HTTP 200 ≠ business success. POST /payments returning `{"status":"declined"}` is HTTP 200 but a business failure. Only this SLO catches it.

**`has_business_slo = false` in dev**
In dev, no real orders or payments are placed — the counters are always 0. A SLO measuring `0 / 0` evaluates to "no data" or 0% → constant noise. Why it matters: disable this SLO in dev to avoid meaningless alerts from division-by-zero behavior.

**SLO 8 — GC Pause Time**
Measures: what % of each minute the JVM is NOT paused for garbage collection. Formula: `(60000 - gc_pause_ms_this_minute) / 60000 × 100`. Target: 99.5% → JVM may spend max 300ms/minute in GC. Why it matters: GC pauses freeze all threads — requests in-flight during a Full GC just wait. This SLO fires before latency SLO does, identifying root cause.

**`builtin:process.memory.jvm.garbageCollectionTime`**
DT auto-captured metric: total milliseconds spent in GC pauses per minute, per JVM process. OneAgent captures this via JVMTI — no code change needed. Why it matters: the raw measurement powering the GC pause SLO.

**G1GC (Garbage-First Garbage Collector)**
Default JVM garbage collector since Java 9. Divides heap into regions, collects garbage-filled ones first. Short minor GC pauses (5-20ms) every few seconds; occasional longer mixed GC pauses (50-300ms). Why it matters: at 70%+ heap utilization, G1GC runs more frequently and pauses get longer — the GC pause SLO catches this trend before it causes user-visible latency.

**Full GC**
A stop-the-world JVM garbage collection pass that collects the entire heap at once. Takes 2-10 seconds. ALL threads are paused during this time. Why it matters: any HTTP request in-flight during Full GC just freezes → P99 latency jumps to 5-10 seconds.

**`60000` (denominator in GC pause SLO)**
Total milliseconds in 1 minute: 60 seconds × 1000 = 60,000ms. Used as the denominator to calculate what percentage of time the JVM was NOT in GC pause. Why it matters: wrong denominator breaks the SLO entirely — using `100` gives wrong numbers.

**Terraform `object()` type**
A Terraform variable type that defines a struct with named fields and types. `map(object({ ... }))` = a map where each value must have exactly the fields defined. Why it matters: adding a new field to `object()` in `variables.tf` forces all callers (`environments/*/main.tf`) to provide that field — compile-time enforcement of configuration completeness.

**`for k, v in var.services : k => v if condition`**
Terraform `for` expression used inside `for_each` to filter a map. Creates a new map containing only entries where the condition is true. Why it matters: this is how DB SLOs are created only for services with `has_database = true` — the resource block is not created at all for others.

**Terraform `sensitive = true`**
Marks a variable as containing a secret — Terraform hides its value in plan/apply output and state file display. Why it matters: prevents DT API tokens and PagerDuty keys from appearing in CI logs.

**`data "aws_secretsmanager_secret_version"`**
Terraform data source that reads a secret value from AWS Secrets Manager at plan/apply time. The value is never hardcoded in `.tf` files. Why it matters: all sensitive values (DT tokens, PagerDuty keys, Slack webhooks) are fetched from Secrets Manager at runtime — nothing sensitive in Git.

**Microseconds vs Milliseconds (DT internal storage)**
Dynatrace stores ALL time-based metrics in microseconds (µs) internally, even when the original measurement was in milliseconds. 300ms = 300,000µs. Why it matters: the #1 most common SLO configuration mistake — forgetting to multiply by 1000 makes every latency threshold 1000× too strict.
