# Upgrade: 2 SLOs → 8 SLOs per Service

> Task: the diagram shows "2 SLOs (availability + latency)" — expand to all 8 common SLOs.
> This requires changes to 4 files: `modules/dynatrace/variables.tf`, `modules/dynatrace/main.tf`,
> and all 3 `environments/*/main.tf` callers.

---

## What Changes at a Glance

```
BEFORE (per service per environment):
  2 SLOs: availability, latency_p99

AFTER (per service per environment):
  8 SLOs:
    1. availability          ← existing (unchanged)
    2. latency_p99           ← existing (unchanged)
    3. db_error_rate         ← NEW: DB call success rate
    4. db_latency            ← NEW: % DB calls under threshold
    5. dependency_error_rate ← NEW: outbound call success rate
    6. message_processing    ← NEW: queue message success rate
    7. business_transaction  ← NEW: real business outcome success rate
    8. gc_pause              ← NEW: % time JVM NOT in GC pause

3 services × 8 SLOs × 3 environments = 72 SLOs total (from 18)
```

---

## Decision Tree — Which New SLOs Apply to Which Service?

```
payment-service:
  has_database?       YES → db_error_rate ✓, db_latency ✓
  has_dependencies?   YES → dependency_error_rate ✓  (calls fraud-detection)
  is_message_consumer? NO → message_processing ✗
  has_business_slo?   YES → business_transaction ✓  (POST /payments must actually pay)
  is_jvm?             YES → gc_pause ✓

order-service:
  has_database?       YES → db_error_rate ✓, db_latency ✓
  has_dependencies?   YES → dependency_error_rate ✓  (calls payment-service)
  is_message_consumer? YES → message_processing ✓  (reads order-events SQS queue)
  has_business_slo?   YES → business_transaction ✓
  is_jvm?             YES → gc_pause ✓

notification-service:
  has_database?       NO  → db_error_rate ✗, db_latency ✗  (uses Redis, not SQL)
  has_dependencies?   YES → dependency_error_rate ✓  (calls email/SMS provider APIs)
  is_message_consumer? YES → message_processing ✓  (primary queue consumer)
  has_business_slo?   NO  → business_transaction ✗  (async delivery, no "committed" outcome)
  is_jvm?             YES → gc_pause ✓
```

---

## File 1 of 4 — `modules/dynatrace/variables.tf` (expanded)

See: `terraform/modules/dynatrace/variables.tf`

Changes: added 8 new fields to the `services` object type.

---

## File 2 of 4 — `modules/dynatrace/main.tf` (6 new SLO resources added)

See: `terraform/modules/dynatrace/main.tf`

Changes: added `dynatrace_slo_v2` blocks for SLOs 3-8 after the existing 2 SLOs.
The existing management zones, alerting profiles, metric events, synthetics, and
notifications are UNCHANGED — only SLOs are expanded.

Key Terraform pattern used for conditional SLOs:

```hcl
# Only create for services where has_database = true:
resource "dynatrace_slo_v2" "db_error_rate" {
  for_each = { for k, v in var.services : k => v if v.has_database }
  ...
}

# Only create for services where is_message_consumer = true:
resource "dynatrace_slo_v2" "message_processing" {
  for_each = { for k, v in var.services : k => v if v.is_message_consumer }
  ...
}

# All services get this (all 3 are Java):
resource "dynatrace_slo_v2" "gc_pause" {
  for_each = var.services
  ...
}
```

---

## File 3-5 of 4 — Environment callers (new fields added to services map)

See: `terraform/environments/dev/main.tf`, `staging/main.tf`, `production/main.tf`

Each adds the 8 new fields per service. Thresholds follow the same
relaxed-→-strict pattern as all other thresholds in this project.

### New field threshold comparison

| Field | Dev | Staging | Production |
|-------|-----|---------|------------|
| `db_error_rate_slo` | 95.0 | 99.0 | 99.9 |
| `db_latency_slo` | 90.0 | 97.0 | 99.5 |
| `db_query_threshold_ms` | 2000 | 300 | 100 |
| `dependency_error_rate_slo` | 90.0 | 97.0 | 99.5 |
| `message_processing_slo` | 90.0 | 97.0 | 99.5 |
| `business_slo_target` | disabled | 97.0 | 99.9 |
| `gc_pause_slo` | 90.0 | 97.0 | 99.5 |

Why dev thresholds are very low (90%):
```
Dev DB is t3.micro RDS — cold queries routinely take 1-3 seconds.
Dev JVM on t3.medium with Xmx=256m — GC pauses are frequent.
has_business_slo = false in dev: no real orders/payments are placed, so
  business.transaction.success.count is always 0 → SLO would evaluate to 0% → noise.
```

---

## DT Metric Expression Reference

Each new SLO uses a DT metric expression formula. Here is what each one means:

### SLO 3 — DB Error Rate
```
Formula: (total DB calls - failed DB calls) / total DB calls × 100

builtin:service.dbconnectioncount     ← total DB calls made by this service
builtin:service.dbconnectionfailcount ← how many of those DB calls failed

Result: "X% of DB connections to this service's database succeeded"
```

### SLO 4 — DB Latency
```
Formula: (DB calls that finished under threshold) / total DB calls × 100

Uses le() filter: le(builtin:service.dbconnectionlatency, threshold_in_microseconds)
le = "less than or equal to"
threshold = db_query_threshold_ms × 1000 (DT stores microseconds, not ms)

Result: "X% of DB queries completed within target time"
```

### SLO 5 — Dependency Error Rate
```
Formula: (outbound calls - outbound failures) / outbound calls × 100

builtin:service.requestCount.CLIENT   ← requests this service MADE to others
builtin:service.errors.client.count   ← how many of those outbound calls failed

vs the existing availability SLO which uses:
builtin:service.requestCount.SERVER   ← requests RECEIVED by this service

.client = outbound (what we send)
.server = inbound  (what we receive)
```

### SLO 6 — Message Processing
```
Formula: (processed - failed) / processed × 100

Uses CUSTOM metrics emitted by the app via OTEL (not auto-captured by OneAgent):
ext:custom.messages.processed.count
ext:custom.messages.failed.count

App must emit these via MeterRegistry / OTEL counters.
See main.md Part 4 for the Java code.
```

### SLO 7 — Business Transaction
```
Formula: success / total × 100

Uses CUSTOM metrics:
ext:custom.business.transaction.success.count
ext:custom.business.transaction.total.count

Critical point: HTTP 200 ≠ business success.
POST /payments returning 200 with body {"status":"declined"} = HTTP OK, business FAIL.
This SLO measures real outcomes, not HTTP status codes.
```

### SLO 8 — GC Pause
```
Formula: (60000 - total_gc_pause_ms_this_minute) / 60000 × 100

builtin:process.memory.jvm.garbageCollectionTime  ← ms spent in GC this minute
60000 = total ms in 1 minute

Result: "X% of time this minute was NOT spent in GC pause"
Target 99.5% = JVM may spend at most 300ms/minute (0.5%) in GC.
```

---

## Part 4 — App Code Required for SLOs 6 and 7

SLOs 3, 4, 5, 8 use DT built-in metrics (auto-captured by OneAgent, no code needed).
SLOs 6 and 7 require the Java app to emit custom metrics via OTEL.

### Message processing (SLO 6) — notification-service and order-service

```java
// In MessageProcessor.java (Spring Boot)
@Service
public class MessageProcessor {

    @Autowired
    private MeterRegistry meterRegistry;

    @Value("${spring.profiles.active}")
    private String environment;

    public void processMessage(Message msg) {
        try {
            doProcess(msg);

            // increment on success
            meterRegistry.counter("messages.processed.count",
                "service", "notification-service",
                "environment", environment).increment();

        } catch (Exception e) {
            // increment on failure
            meterRegistry.counter("messages.failed.count",
                "service", "notification-service",
                "environment", environment).increment();

            // re-throw so message goes to DLQ
            throw e;
        }
    }
}
```

```yaml
# In charts/notification-service/values.yaml — OTEL export to DT ActiveGate
env:
  - name: OTEL_EXPORTER_OTLP_ENDPOINT
    value: "http://dynatrace-activegate.dynatrace.svc:4318"
  - name: OTEL_SERVICE_NAME
    value: "notification-service"
  - name: MANAGEMENT_METRICS_EXPORT_OTLP_ENABLED
    value: "true"

# OTEL sends MeterRegistry counters as ext:custom.messages.* metrics to DT
```

### Business transaction (SLO 7) — payment-service and order-service

```java
// In PaymentController.java
@RestController
public class PaymentController {

    @Autowired
    private MeterRegistry meterRegistry;

    @Value("${spring.profiles.active}")
    private String environment;

    @PostMapping("/api/v1/payments")
    public ResponseEntity<PaymentResult> processPayment(@RequestBody PaymentRequest req) {

        // always count total attempts
        meterRegistry.counter("business.transaction.total.count",
            "service", "payment-service",
            "environment", environment,
            "transaction_type", "payment").increment();

        PaymentResult result = paymentService.process(req);

        if (result.isSuccess()) {
            // only count when payment was ACTUALLY made (not declined, not error)
            meterRegistry.counter("business.transaction.success.count",
                "service", "payment-service",
                "environment", environment,
                "transaction_type", "payment").increment();
        }

        return ResponseEntity.ok(result);  // always 200, business outcome in body
    }
}
```

---

## Common Mistakes When Adding These SLOs

| Mistake | Symptom | Fix |
|---------|---------|-----|
| `db_query_threshold_ms` used directly in DT expression | DB latency SLO fires on every query (300 = 300µs = nearly instant) | Multiply by 1000: DT stores time in microseconds |
| Custom metrics not emitted by app | Message processing SLO always evaluates to "no data" | Add MeterRegistry counters + OTEL export config to app |
| `has_business_slo = true` in dev | SLO shows 0% (no real business transactions in dev) | Set `has_business_slo = false` in dev; disable cleanly |
| Same SLO threshold in all environments | Dev DB latency at 100ms fires constantly (cold JVM, t3.micro DB) | Use 2000ms dev, 300ms staging, 100ms prod |
| `for_each` uses `var.services` for DB SLO | Creates broken SLO for notification-service which has no DB | Use conditional: `if v.has_database` |
| GC metric expression unit wrong | SLO always shows 100% (dividing by wrong denominator) | Denominator = 60000 ms per minute, not 1 |
