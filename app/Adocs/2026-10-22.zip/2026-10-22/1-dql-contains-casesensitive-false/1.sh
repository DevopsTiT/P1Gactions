mkdir -p "/Users/k/Codes/Pra/P1GithubActions/P1Gactions/app/Adocs/2026-10-22/1-dql-contains-casesensitive-false"
cp -R "/Users/k/Learnings/AIProject/CursorFiles/Daily Files/2026-10-22/1-dql-contains-casesensitive-false/." "/Users/k/Codes/Pra/P1GithubActions/P1Gactions/app/Adocs/2026-10-22/1-dql-contains-casesensitive-false/"
