# Transform 63 To 65 DocNotif Financials Sonpovan

```
#63 cc-batch + DocNotif_Adj + failed=true?
#64 cc-batch + FinancialsEsc* + failed=true?
#65 sonpov* + WARN + Van7RecvAccountStatementCallApiTasklet + Message?
 → parse claimNumber + message → suffix chars 401–417
```

| Key point | Detail |
|---|---|
| #63 / #64 | Same shape; different work-item name |
| #65 | Extract claim `n/n`, Message body, and 17-char suffix after pos 400 |
| Note | Your draft used `startswith` — DQL is `startsWith` |

## Summary

**63** and **64** are failed CC batch work items. **65** is a Sonpovan WARN with claim number and a long Message; Splunk’s `substr(message,401,17)` becomes `substring(..., from:400, to:417)`.

---

## #63 DQL (live)

```
fetch logs, from:now()-24h
| fieldsAdd src = lower(coalesce(k8s.pod.name, host.name, log.source))
| filter startsWith(src, "cc-batch")
    or contains(log.source, "cc-batch", caseSensitive:false)
| filter contains(content, "Work item processed \"DocNotif_Adj\"", caseSensitive:false)
| filter contains(content, "failed=true", caseSensitive:false)
| sort timestamp desc
| fields timestamp, src, content
```

## #63 verify

```
fetch logs
| limit 1
| fieldsAdd dummy = "2026-10-15 09:12:34,567 INFO [worker-1] Work item processed \"DocNotif_Adj\" id=48213 failed=true elapsedMs=1520"
| fieldsAdd pod = "cc-batch-0"
| fields dummy, pod
| fieldsAdd src = lower(pod)
| filter startsWith(src, "cc-batch")
| filter contains(dummy, "Work item processed \"DocNotif_Adj\"", caseSensitive:false)
| filter contains(dummy, "failed=true", caseSensitive:false)
| fields src, dummy
```

---

## #64 DQL (live)

```
fetch logs, from:now()-24h
| fieldsAdd src = lower(coalesce(k8s.pod.name, host.name, log.source))
| filter startsWith(src, "cc-batch")
    or contains(log.source, "cc-batch", caseSensitive:false)
| filter contains(content, "Work item processed \"FinancialsEsc", caseSensitive:false)
| filter contains(content, "failed=true", caseSensitive:false)
| sort timestamp desc
| fields timestamp, src, content
```

## #64 verify

```
fetch logs
| limit 1
| fieldsAdd dummy = "2026-10-15 09:12:34,567 INFO [worker-2] Work item processed \"FinancialsEscalation_Adj\" id=77120 failed=true elapsedMs=3011"
| fieldsAdd pod = "cc-batch-1"
| fields dummy, pod
| fieldsAdd src = lower(pod)
| filter startsWith(src, "cc-batch")
| filter contains(dummy, "Work item processed \"FinancialsEsc", caseSensitive:false)
| filter contains(dummy, "failed=true", caseSensitive:false)
| fields src, dummy
```

---

## #65 Splunk

```
index="*sonpov*" WARN s.Van7RecvAccountStatementCallApiTasklet CASE(Message)
| rex field=_raw "(?<claimNb>[0-9]+/[0-9]+)"
| rex field=_raw "Message : (?<message>.*)"
| stats values(claimNb) as claimNumber, values(message) as message,
        values(eval(substr(message,401,17))) as suffix, values(_raw) as log by _time
```

## #65 DQL (live)

```
fetch logs, from:now()-24h
| fieldsAdd src = lower(coalesce(k8s.pod.name, host.name, log.source))
| filter contains(src, "sonpov", caseSensitive:false)
    or contains(log.source, "sonpov", caseSensitive:false)
| filter contains(content, "WARN", caseSensitive:false)
| filter contains(content, "Van7RecvAccountStatementCallApiTasklet", caseSensitive:false)
| filter contains(content, "Message", caseSensitive:false)
| parse content, "LD (DIGIT+ '/' DIGIT+):claimNumber"
| parse content, "LD 'Message : ' LD:message"
| fieldsAdd suffix = if(stringLength(message) > 400, substring(message, from:400, to:417), "")
| sort timestamp desc
| fields timestamp, src, claimNumber, message, suffix, content
```

If live logs use `VanTRecv...` instead of `Van7Recv...`, change that one string.

## #65 verify

```
fetch logs
| limit 1
| fieldsAdd dummy = "2026-10-15 09:12:34,567 WARN [step-1] Van7RecvAccountStatementCallApiTasklet - claim 2026/004512 Message : AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAERR-STMT-0042-API"
| fieldsAdd pod = "sonpovan-batch-7d9f8c6b5-x2k4q"
| fields dummy, pod
| fieldsAdd src = lower(pod)
| filter contains(src, "sonpov", caseSensitive:false)
| filter contains(dummy, "WARN", caseSensitive:false)
| filter contains(dummy, "Van7RecvAccountStatementCallApiTasklet", caseSensitive:false)
| filter contains(dummy, "Message", caseSensitive:false)
| parse dummy, "LD (DIGIT+ '/' DIGIT+):claimNumber"
| parse dummy, "LD 'Message : ' LD:message"
| fieldsAdd suffix = if(stringLength(message) > 400, substring(message, from:400, to:417), "")
| fields src, claimNumber, suffix, dummy
```

## Data flow map

```
#63: cc-batch → DocNotif_Adj + failed=true
#64: cc-batch → FinancialsEsc* + failed=true
#65: sonpov → WARN + tasklet → claimNumber + message + suffix
```

## Related files

| File | Role |
|---|---|
| `14-transform-63-to-65-docnotif-financials-sonpovan.dql` | All three |
| `14.sh` | Dual-write |

## Commands

See [14.sh](14.sh).
